//! Пішіннің ондық жолын тексеру және ажырату:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Басқаша айтқанда, екі ерекшелікті қоспағанда, өзгермелі нүктелік стандартты синтаксис: белгі жоқ, және "inf" және "NaN" өңделмеген.Бұларды (super::dec2flt) драйвер функциясы басқарады.
//!
//! Жарамды кірістерді тану салыстырмалы түрде оңай болғанымен, бұл модульге panic ешқашан сансыз жарамсыз вариацияларды қабылдамауға және басқа модульдердің өз кезегінде panic емес (немесе толып кетуіне) сенетін көптеген тексерулерді орындау қажет.
//!
//! Одан да жаманы, мұның бәрі кірудің бір өтуінде болады.
//! Сондықтан кез-келген нәрсені өзгерткенде абай болыңыз және басқа модульдермен қайта тексеріңіз.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Ондық жолдың қызықты бөліктері.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Ондық сандардың 18-ден азына кепілдендірілген ондық дәреже.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Енгізілген жолдың өзгермелі нүктенің дұрыс нөмірі екенін тексереді, егер олай болса, онда бүтін бөлікті, бөлшек бөлікті және көрсеткішті табыңыз.
/// Белгілермен жұмыс жасамайды.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // 'e' дейін сан жоқ
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Біз нүктеге дейін немесе одан кейін кем дегенде бір цифрды қажет етеміз.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Бөлшек бөліктен кейінгі қоқыс
            }
        }
        _ => Invalid, // Бірінші саннан кейінгі жолдар
    }
}

/// Бірінші таңбалы емес ондық сандарды өшіреді.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Көрсеткіштерді шығару және қателерді тексеру.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Көрсеткіштен кейінгі қоқыс
    }
    if number.is_empty() {
        return Invalid; // Бос көрсеткіш
    }
    // Осы сәтте бізде цифрлардың жарамды тізбегі болады.Мүмкін, `i64`-ге ену өте ұзақ болуы мүмкін, бірақ егер ол өте үлкен болса, кіріс нөлге немесе шексіздікке тең.
    // Ондық цифрлардағы әрбір нөл көрсеткішті +/-1-ге ғана реттейтін болғандықтан, exp=10 ^ 18 болғанда, ақырғы деңгейге қашықтан жақындау үшін кіріс 17 экзабайт (!) нөлге тең болуы керек.
    //
    // Бұл біз пайдалануымыз керек жағдай емес.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}