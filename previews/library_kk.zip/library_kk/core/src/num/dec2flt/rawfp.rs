//! IEEE 754 өзгермелі қалқымалы факторлары.Теріс сандармен жұмыс істеу қажет емес және қажет емес.
//! Қалыпты өзгермелі нүктелік сандар (frac, exp) сияқты канондық көрсетілімге ие, мәні 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)), мұндағы N-бит саны.
//!
//! Субнормальдар сәл өзгеше және таңқаларлық, бірақ сол принцип қолданылады.
//!
//! Алайда мұнда біз оларды f (оң) мәнімен (sig, k) ұсынамыз, мәні f *
//! 2 <sup>e</sup> .Бұл "hidden bit" мәнін жасаумен қатар, көрсеткішті мантисса ығысуымен өзгертеді.
//!
//! Басқаша айтқанда, әдетте қалқымалар (1) түрінде жазылады, бірақ мұнда олар (2) түрінде жазылады:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! (1)**бөлшек көрінісі** және (2)**интегралды көрінісі** деп атаймыз.
//!
//! Бұл модульдегі көптеген функциялар тек қалыпты сандармен жұмыс істейді.Dec2flt регулярлары консервативті түрде өте аз және өте үлкен сандар үшін әмбебап дұрыс баяу жолмен жүреді (M алгоритмі).
//! Бұл алгоритмге субнормальдар мен нөлдерді басқаратын тек next_float() қажет.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// `f32` және `f64` үшін барлық конверсиялық кодтардың қайталануын болдырмайтын trait көмекшісі.
///
/// Мұның не үшін қажет екенін ата-ана модулінің құжаттық түсініктемесінен қараңыз.
///
/// **ешқашан** ешқашан ** басқа түрлерге енгізілмеуі керек немесе dec2flt модулінен тыс қолданылуы керек.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// `to_bits` және `from_bits` қолданатын тип.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Шикі трансмутацияны бүтін санға орындайды.
    fn to_bits(self) -> Self::Bits;

    /// Бүтін саннан шикі трансмутацияны орындайды.
    fn from_bits(v: Self::Bits) -> Self;

    /// Осы санат кіретін санатты қайтарады.
    fn classify(self) -> FpCategory;

    /// Мантисса, дәреже және таңбаны бүтін сан ретінде береді.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Қалқымалы кодты шешеді.
    fn unpack(self) -> Unpacked;

    /// Дәл ұсынуға болатын шағын бүтін саннан шығарады.
    /// Panic, егер бүтін санды көрсету мүмкін болмаса, осы модульдегі басқа код ешқашан бұған жол бермейтіндігіне көз жеткізеді.
    fn from_int(x: u64) -> Self;

    /// Алдын ала есептелген кестеден 10 <sup>е</sup> мәнін алады.
    /// `e >= CEIL_LOG5_OF_MAX_SIG` үшін Panics.
    fn short_fast_pow10(e: usize) -> Self;

    /// Аты не дейді.
    /// Ішкі заттарды жонглрлеуге қарағанда және оны LLVM тұрақты бүктейді деп үміттенуден гөрі, кодты жазу оңайырақ.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Толып кетуді немесе нөлді шығара алмайтын кірістердің ондық цифрларына байланысты консервативті
    /// субнормальды.Мүмкін, максималды қалыпты мәннің ондық дәрежесі, сондықтан атау шығар.
    const MAX_NORMAL_DIGITS: usize;

    /// Егер ең маңызды ондық санның орын мәні осыдан үлкен болса, онда бұл сан шексіздікке дейін дөңгелектенеді.
    ///
    const INF_CUTOFF: i64;

    /// Егер ең маңызды ондық санның орын мәні осыдан аз болса, онда бұл сан нөлге дейін дөңгелектенеді.
    ///
    const ZERO_CUTOFF: i64;

    /// Көрсеткіштегі бит саны.
    const EXP_BITS: u8;

    /// Жасырын разрядты қосқанда * мәніндегі биттер саны.
    const SIG_BITS: u8;

    /// Жасырын битті *қоспағанда*, белгідегі биттер саны.
    const EXPLICIT_SIG_BITS: u8;

    /// Бөлшек ұсынудағы максималды заңды көрсеткіш.
    const MAX_EXP: i16;

    /// Субормальды қоспағанда, бөлшек ұсынудағы ең төменгі заңды көрсеткіш.
    const MIN_EXP: i16;

    /// `MAX_EXP` интегралды ұсыну үшін, яғни ауысыммен бірге.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` кодталған (яғни, ығысу мәнімен)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` интегралды ұсыну үшін, яғни ауысыммен бірге.
    const MIN_EXP_INT: i16;

    /// Интегралды ұсынуда максималды нормаланған мән.
    const MAX_SIG: u64;

    /// Интегралды ұсынудағы минималды нормаланған мән.
    const MIN_SIG: u64;
}

// Негізінен #34344 үшін уақытша шешім.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Мантисса, дәреже және таңбаны бүтін сан ретінде береді.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Көрсеткіштің қисаюы + мантисса ауысуы
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe барлық платформаларда `as` дөңгелектеуінің дұрыс еместігі белгісіз.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Мантисса, дәреже және таңбаны бүтін сан ретінде береді.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Көрсеткіштің қисаюы + мантисса ауысуы
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe барлық платформаларда `as` дөңгелектеуінің дұрыс еместігі белгісіз.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// `Fp`-ті ең жақын флоат түріне түрлендіреді.
/// Қалыптан тыс нәтижелермен жұмыс жасамайды.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 бит, сондықтан xe-нің мантисса ығысуы 63-ке тең
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// 64 биттік мәнді T::SIG_BITS битке дейін жартылай жұпқа дейін дөңгелектеңіз.
/// Көрсеткіштердің асып кетуіне жол бермейді.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Мантисса жылжуын реттеңіз
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Нормаланған сандар үшін кері `RawFloat::unpack()`.
/// Panics, егер мән немесе дәреже нормаланған сандар үшін жарамсыз болса.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Жасырын битті алып тастаңыз
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Көрсеткіштің қисаюына және мантиссаға ауысуына көрсеткішті реттеңіз
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // 0 ("+") деңгейінде белгіні қалдырыңыз, біздің сандарымыздың барлығы оң
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Субнормальды құрастырыңыз.0-ге тең мантиссаға жол беріліп, нөл құрылады.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Шифрланған дәреже-0, белгі биті-0, сондықтан біз тек биттерді қайта түсіндіруіміз керек.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Fp-мен шамалы шамды шамалаңыз.0.5 ULP шеңберінде жартылай жұппен дөңгелектенеді.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Біз `start` индексіне дейін барлық биттерді кесіп тастадық, яғни біз `start` мөлшерінде оңға жылжытамыз, сондықтан бұл бізге қажет көрсеткіш болып табылады.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Қиылған биттерге байланысты дөңгелек (half-to-even).
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Аргументтен қатаң кіші өзгермелі нүктенің ең үлкен санын табады.
/// Нормальды, нөлдік немесе деңгейлік ағынды өңдемейді.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Дәлелден қатаң үлкен өзгермелі нүктенің ең кіші санын табыңыз.
// Бұл операция қанықтырады, яғни next_float(inf) ==inf.
// Бұл модульдегі көптеген кодтардан айырмашылығы, бұл функция нөл, субнормаль және шексіздіктермен жұмыс істейді.
// Алайда, мұндағы барлық басқа кодтар сияқты, ол NaN және теріс сандармен жұмыс жасамайды.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Бұл шындық үшін тым жақсы сияқты, бірақ ол жұмыс істейді.
        // 0.0 нөлдік сөз ретінде кодталған.Субнормальдар 0х000м ... м, мұндағы m-мантисса.
        // Атап айтқанда, ең кіші субнормаль 0x0 ... 01, ал ең үлкені 0x000F ... F.
        // Ең кіші қалыпты сан-0x0010 ... 0, сондықтан бұл бұрыштық жағдай да жұмыс істейді.
        // Егер өсім мантиссадан асып кетсе, тасымалдау биті көрсеткішті біз қалағандай көбейтеді, ал мантисса биттері нөлге айналады.
        // Жасырын бит конвенциясы болғандықтан, бұл да біз қалаған нәрсе!
        // Соңында, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}