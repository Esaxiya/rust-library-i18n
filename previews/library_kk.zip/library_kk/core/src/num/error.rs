//! Интегралды типтерге түрлендірудің қателік түрлері.

use crate::convert::Infallible;
use crate::fmt;

/// Қате түрі тексерілген интегралды типті түрлендіру сәтсіз болған кезде қайтарылады.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // `Infallible` `!` үшін бүркеншік атқа айналған кезде жоғарыдағы `From<Infallible> for TryFromIntError` сияқты кодтың жұмыс істейтіндігіне көз жеткізу үшін мәжбүрлеудің орнына сәйкес келеді.
        //
        //
        match never {}
    }
}

/// Бүтін санды талдау кезінде қайтаруға болатын қате.
///
/// Бұл қате [`i8::from_str_radix`] сияқты алғашқы бүтін типтердегі `from_str_radix()` функциялары үшін қате түрі ретінде қолданылады.
///
/// # Ықтимал себептері
///
/// Басқа себептермен қатар, `ParseIntError`-ті бос кеңістіктің алдыңғы немесе артқы жағында, мысалы, стандартты кірістен алынған кезде лақтыруға болады.
///
/// [`str::trim()`] әдісін қолдану талдауға дейін бос орын қалмауын қамтамасыз етеді.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Бүтін санды талдауға әкелуі мүмкін әр түрлі қателіктерді сақтау үшін Enum.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Мән талданған бос.
    ///
    /// Басқа себептермен қатар, бұл нұсқа бос жолды талдау кезінде жасалады.
    Empty,
    /// Контексте жарамсыз цифр бар.
    ///
    /// Басқа себептермен қатар, бұл нұсқа құрамында ASCII емес Char бар жолды талдау кезінде жасалады.
    ///
    /// Бұл нұсқа `+` немесе `-` жолдың ішіне өздігінен немесе санның ортасында орналастырылған кезде де жасалады.
    ///
    ///
    InvalidDigit,
    /// Бүтін сан мақсатты бүтін типте сақтау үшін тым үлкен.
    PosOverflow,
    /// Бүтін сан мақсатты бүтін типте сақтау үшін тым кішкентай.
    NegOverflow,
    /// Мән нөл болды
    ///
    /// Бұл нұсқа талдау мәні нөлге тең болған кезде шығарылады, бұл нөлге жатпайтын типтер үшін заңсыз болады.
    ///
    Zero,
}

impl ParseIntError {
    /// Бүтін санды талдаудың егжей-тегжейлі себебін шығарады.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}