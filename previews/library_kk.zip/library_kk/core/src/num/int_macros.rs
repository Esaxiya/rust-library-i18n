macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Осы бүтін типпен ұсынылуы мүмкін ең кіші мән.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// Осы бүтін типпен ұсынылатын ең үлкен мән.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// Бұл бүтін типтің разряд өлшемі.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Берілген негіздегі жол кесіндісін бүтін санға айналдырады.
        ///
        /// Жол міндетті емес `+` немесе `-` белгісі, одан кейін цифрлар болады деп күтілуде.
        /// Алдыңғы және соңғы кеңістік қатені білдіреді.
        /// Цифрлар-бұл `radix` түріне байланысты осы таңбалардың жиынтығы:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// Бұл функция panics, егер `radix` 2-ден 36-ға дейінгі аралықта болмаса.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// `self` екілік көрінісінде олардың санын қайтарады.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// `self` екілік көрінісіндегі нөлдер санын қайтарады.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// `self` екілік көрінісіндегі жетекші нөлдер санын қайтарады.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// `self` екілік көрінісіндегі соңғы нөлдердің санын қайтарады.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// `self` екілік көрінісіндегі жетекші санын қайтарады.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// `self` екілік көрінісіндегі арттағылардың санын қайтарады.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// Алынған биттерді алынған бүтін санның соңына дейін орап, биттерді көрсетілген мөлшерге `n` солға жылжытады.
        ///
        ///
        /// Назар аударыңыз, бұл `<<` ауыстыру операторымен бірдей операция емес!
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// Қиылған биттерді алынған бүтін санның басына орап, биттерді көрсетілген мөлшерге, `n` оңға жылжытады.
        ///
        ///
        /// Назар аударыңыз, бұл `>>` ауыстыру операторымен бірдей операция емес!
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// Бүтін санның байт ретін өзгертеді.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// m= n.swap_bytes() болсын;
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// Бүтін сандағы биттердің ретін өзгертеді.
        /// Кішігірім бит ең маңызды битке, екінші аз мәнді бит екінші маңызды битке айналады және т.с.с.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// m= n.reverse_bits() болсын;
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// Бүтін санды үлкен еннан мақсаттың енділігіне айналдырады.
        ///
        /// Үлкен енда бұл тыйым салынады.Кішкентай енда байттар ауыстырылады.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// егер cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } басқа {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Бүтін санды кішкентай еняннан мақсаттың енділігіне айналдырады.
        ///
        /// Кішкентай енді бұл тыйым салынады.Үлкен енда байттар ауыстырылады.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// егер cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } басқа {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// `self`-ті мақсатты ендан үлкен енанға түрлендіреді.
        ///
        /// Үлкен енда бұл тыйым салынады.Кішкентай енда байттар ауыстырылады.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// егер cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } else { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // немесе болмау керек пе?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// `self`-ті мақсаттың ендан кішкентай енанға түрлендіреді.
        ///
        /// Кішкентай енді бұл тыйым салынады.Үлкен енда байттар ауыстырылады.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// егер cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } else { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Толық санды қосу.
        /// Егер `self + rhs` есептеледі, егер `None` толып кетсе, оны қайтарады.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Бүтін санды қосу тексерілмеген.Толып кету мүмкін емес деп есептегенде, `self + rhs` есептейді.
        /// Бұл кезде анықталмаған мінез-құлыққа әкеледі
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // ҚАУІПСІЗДІК: қоңырау шалушы `unchecked_add` қауіпсіздік шартын сақтауы керек.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Бүтін санды алып тастау.
        /// Егер `self - rhs` есептеледі, егер `None` толып кетсе, оны қайтарады.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Бүтін санды алып тастау.Толып кету мүмкін емес деп есептегенде, `self - rhs` есептейді.
        /// Бұл кезде анықталмаған мінез-құлыққа әкеледі
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // ҚАУІПСІЗДІК: қоңырау шалушы `unchecked_sub` қауіпсіздік шартын сақтауы керек.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Бүтін санды көбейту.
        /// Егер `self * rhs` есептеледі, егер `None` толып кетсе, оны қайтарады.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Бүтін санды көбейту.Толып кету мүмкін емес деп есептегенде, `self * rhs` есептейді.
        /// Бұл кезде анықталмаған мінез-құлыққа әкеледі
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // ҚАУІПСІЗДІК: қоңырау шалушы `unchecked_mul` қауіпсіздік шартын сақтауы керек.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Бүтін санның бөлінуі.
        /// Егер `rhs == 0` немесе бөлу толып кетсе, `None` қайтарып, `self / rhs` есептейді.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // ҚАУІПСІЗДІК: div нөлге және INT_MIN бойынша жоғарыда тексерілген
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Евклидтік бөліну.
        /// Егер `rhs == 0` немесе бөлу толып кетсе, `None` қайтарып, `self.div_euclid(rhs)` есептейді.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// Қалған қалдық.
        /// Егер `rhs == 0` немесе бөлу толып кетсе, `None` қайтарып, `self % rhs` есептейді.
        ///
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // ҚАУІПСІЗДІК: div нөлге және INT_MIN бойынша жоғарыда тексерілген
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Евклидтік қалдық.
        /// Егер `rhs == 0` немесе бөлу толып кетсе, `None` қайтарып, `self.rem_euclid(rhs)` есептейді.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Терістеу тексерілді.
        /// `-self` есептейді, егер `self == MIN` болса `None` қайтарады.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Солға жылжу тексерілді.
        /// `self << rhs`-ті есептейді, егер `rhs` `self`-дегі биттер санынан үлкен немесе тең болса, `None`-ті қайтарады.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Оңға жылжу тексерілді.
        /// `self >> rhs`-ті есептейді, егер `rhs` `self`-дегі биттер санынан үлкен немесе тең болса, `None`-ті қайтарады.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Абсолютті мән тексерілді.
        /// `self.abs()` есептейді, егер `self == MIN` болса `None` қайтарады.
        ///
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// Белгіленген деңгей.
        /// Егер `self.pow(exp)` есептеледі, егер `None` толып кетсе, оны қайтарады.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // exp!=0 болғандықтан, exp 1 болуы керек.
            // Көрсеткіштің соңғы битімен бөлек жұмыс жасаңыз, өйткені кейіннен базаны квадраттау қажет емес және қажетсіз асып кетуі мүмкін.
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Қанықтырғыш бүтін қосымша.
        /// Толып кетудің орнына сандық шектерге қаныққан `self + rhs` есептейді.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Қанықтырғыш бүтін азайту.
        /// Толып кетудің орнына сан шектеріне қаныққан `self - rhs` есептейді.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Қанықтырғыш бүтін теріске шығару.
        /// Толтырудың орнына `self == MIN` болса, `MAX` қайтарады, `-self` есептейді.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// Қанықтырушы абсолютті мән.
        /// Толтырудың орнына `self == MIN` болса, `MAX` қайтарады, `self.abs()` есептейді.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// Қанықтырғыш бүтін көбейту.
        /// Толып кетудің орнына сан шектеріне қаныққан `self * rhs` есептейді.
        ///
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// Қанықтырғыш бүтін дәрежелік көрсеткіш.
        /// Толып кетудің орнына сан шектеріне қаныққан `self.pow(exp)` есептейді.
        ///
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// (modular) қоспасын орау.
        /// Түрдің шекарасында айнала отырып, `self + rhs` есептейді.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// (modular) азайтуды орау.
        /// Түрдің шекарасында айнала отырып, `self - rhs` есептейді.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// (modular) көбейтуді орау.
        /// Түрдің шекарасында айнала отырып, `self * rhs` есептейді.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// (modular) бөлуін орау.Түрдің шекарасында айнала отырып, `self / rhs` есептейді.
        ///
        /// Мұндай орамның орын алуы мүмкін жалғыз жағдай-бұл `MIN / -1`-ті қол қойылған типке бөлу (мұндағы `MIN`-тип үшін минималды теріс мән);бұл `-MIN` эквивалентіне тең болады, бұл типті көрсетуге тым үлкен оң мән.
        /// Мұндай жағдайда бұл функция `MIN`-тің өзін қайтарады.
        ///
        /// # Panics
        ///
        /// Бұл функция panic болады, егер `rhs` 0 болса.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// Евклидтік бөлуді орау.
        /// Түрдің шекарасында айнала отырып, `self.div_euclid(rhs)` есептейді.
        ///
        /// Орам тек `MIN / -1` түрінде қол қойылған типте болады (мұндағы `MIN`-тип үшін минималды теріс мән).
        /// Бұл `-MIN` эквивалентіне тең, бұл типтегі көрініс үшін тым үлкен оң мән.
        /// Бұл жағдайда бұл әдіс `MIN`-тің өзін қайтарады.
        ///
        /// # Panics
        ///
        /// Бұл функция panic болады, егер `rhs` 0 болса.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// (modular) қалдықтарын орау.Түрдің шекарасында айнала отырып, `self % rhs` есептейді.
        ///
        /// Мұндай айналдыру ешқашан математикалық түрде болмайды;іске асыру артефактілері `x % y`-ті `MIN / -1` үшін қол қойылған типтегі жарамсыз етеді (мұндағы `MIN`-минималды теріс мән).
        ///
        /// Мұндай жағдайда бұл функция `0` мәнін қайтарады.
        ///
        /// # Panics
        ///
        /// Бұл функция panic болады, егер `rhs` 0 болса.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// Евклидтік қалдықты орау.Түрдің шекарасында айнала отырып, `self.rem_euclid(rhs)` есептейді.
        ///
        /// Орам тек `MIN % -1` түрінде қол қойылған типте болады (мұндағы `MIN`-тип үшін минималды теріс мән).
        /// Бұл жағдайда бұл әдіс 0 мәнін береді.
        ///
        /// # Panics
        ///
        /// Бұл функция panic болады, егер `rhs` 0 болса.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// (modular) терісін орау.Түрдің шекарасында айнала отырып, `-self` есептейді.
        ///
        /// Мұндай орамның орын алуы мүмкін жалғыз жағдай-бұл қол қойылған типтегі `MIN` мәнін жоққа шығару (мұндағы `MIN`-типтің минималды мәні);бұл типте көрсету үшін тым үлкен оң мән.
        /// Мұндай жағдайда бұл функция `MIN`-тің өзін қайтарады.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic бос жылжу солға;`self << mask(rhs)` береді, мұнда `mask` кез келген жоғары ретті `rhs` биттерін жояды, бұл ауысым түрдің енінен асып кетуіне әкелуі мүмкін.
        ///
        /// Назар аударыңыз, бұл *солға бұрылумен бірдей емес*;LHS ішінен жылжытылған биттер екінші жағына қайтарылғаннан гөрі, солға жылжудың RHS түрі диапазонмен шектеледі.
        ///
        /// Қарапайым бүтін типтер [`rotate_left`](Self::rotate_left) функциясын орындайды, бұл оның орнына қалағаныңыз болуы мүмкін.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // ҚАУІПСІЗДІК: түрдің биттік өлшемімен маска жасау біздің ауыспауымызды қамтамасыз етеді
            // шекарадан тыс
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Оңға Panic;`self >> mask(rhs)` береді, мұнда `mask` кез келген жоғары ретті `rhs` биттерін жояды, бұл ауысым түрдің енінен асып кетуіне әкеледі.
        ///
        /// Мұның * оңға бұрылумен бірдей емес екенін ескеріңіз;оңға жылжудың оң жағындағы RHS түрінің диапазонымен шектеледі, ал LHS-ден басқа ұшына қайтарылған биттер емес.
        ///
        /// Қарапайым бүтін типтер [`rotate_right`](Self::rotate_right) функциясын орындайды, бұл оның орнына қалағаныңыз болуы мүмкін.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // ҚАУІПСІЗДІК: түрдің биттік өлшемімен маска жасау біздің ауыспауымызды қамтамасыз етеді
            // шекарадан тыс
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// (modular) абсолютті мәнін орау.Түрдің шекарасында айнала отырып, `self.abs()` есептейді.
        ///
        /// Мұндай орамның пайда болуы мүмкін жалғыз жағдай-типке теріс минималды мәннің абсолютті мәнін қабылдау;бұл типте көрсету үшін тым үлкен оң мән.
        /// Мұндай жағдайда бұл функция `MIN`-тің өзін қайтарады.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// `self` абсолютті мәнін ешқандай орамасыз немесе үрейсіз есептейді.
        ///
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// (modular) көрсеткіштерін орау.
        /// Түрдің шекарасында айнала отырып, `self.pow(exp)` есептейді.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // exp!=0 болғандықтан, exp 1 болуы керек.
            // Көрсеткіштің соңғы битімен бөлек жұмыс жасаңыз, өйткені кейіннен базаны квадраттау қажет емес және қажетсіз асып кетуі мүмкін.
            //
            //
            acc.wrapping_mul(base)
        }

        /// `self` + `rhs` есептейді
        ///
        /// Арифметикалық толып кетудің болатындығын көрсететін логикалық циклмен бірге қосудың кортежін қайтарады.
        /// Егер толып кету болған болса, онда оралған мән қайтарылады.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self`, `rhs` есептейді
        ///
        /// Арифметикалық толып кетудің болатындығын көрсететін бульмен бірге алып тастау кортежін қайтарады.
        /// Егер толып кету болған болса, онда оралған мән қайтарылады.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` және `rhs` көбейтуін есептейді.
        ///
        /// Арифметикалық толып кетудің болатындығын көрсететін бульмен бірге көбейтудің кортежін қайтарады.
        /// Егер толып кету болған болса, онда оралған мән қайтарылады.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408, рас));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self`-ті `rhs`-ге бөлгенде бөлгішті есептейді.
        ///
        /// Бөлгіштің кортежін логикалық мәнмен бірге арифметикалық толып кетудің болатындығын көрсетеді.
        /// Егер толып кету орын алса, онда өздігінен қайтарылады.
        ///
        /// # Panics
        ///
        /// Бұл функция panic болады, егер `rhs` 0 болса.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// Евклидтік бөлудің `self.div_euclid(rhs)` бөлігін есептейді.
        ///
        /// Бөлгіштің кортежін логикалық мәнмен бірге арифметикалық толып кетудің болатындығын көрсетеді.
        /// Егер толып кету орын алса, онда `self` қайтарылады.
        ///
        /// # Panics
        ///
        /// Бұл функция panic болады, егер `rhs` 0 болса.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// `self`-ті `rhs`-ге бөлгенде қалдықты есептейді.
        ///
        /// Бөлінгеннен кейін қалдықтың кортежін логикалықпен бірге арифметикалық толып кетудің болатындығын көрсетеді.
        /// Егер толып кету болса, 0 қайтарылады.
        ///
        /// # Panics
        ///
        /// Бұл функция panic болады, егер `rhs` 0 болса.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// Толып жатқан эвклидтік қалдық.`self.rem_euclid(rhs)` есептейді.
        ///
        /// Бөлінгеннен кейін қалдықтың кортежін логикалықпен бірге арифметикалық толып кетудің болатындығын көрсетеді.
        /// Егер толып кету болса, 0 қайтарылады.
        ///
        /// # Panics
        ///
        /// Бұл функция panic болады, егер `rhs` 0 болса.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// Өзін-өзі теріске шығарады, егер бұл ең төменгі мәнге тең болса.
        ///
        /// Өзін-өзі жоққа шығарған версиясының кортежін логикалық мәнмен бірге толып кетудің болған-болмайтынын көрсетеді.
        /// Егер `self` минималды мән болса (мысалы, `i32` типіндегі мәндер үшін `i32::MIN`), онда минималды мән қайтадан оралады және `true` толып кету үшін қайтарылады.
        ///
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// Өзін `rhs` биттерімен ауыстырады.
        ///
        /// Ауыстырылған мән биттердің санынан үлкен не тең екендігін көрсететін логикалық мәнмен бірге меншіктің ауысқан нұсқасының кортежін қайтарады.
        /// Егер ығысу мәні тым үлкен болса, онда мән (N-1) маскирленеді, мұндағы N-бит саны, содан кейін бұл мән ығысуды орындау үшін қолданылады.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0х10, шын));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Өздігінен `rhs` битке ауысады.
        ///
        /// Ауыстырылған мән биттердің санынан үлкен не тең екендігін көрсететін логикалық мәнмен бірге меншіктің ауысқан нұсқасының кортежін қайтарады.
        /// Егер ығысу мәні тым үлкен болса, онда мән (N-1) маскирленеді, мұндағы N-бит саны, содан кейін бұл мән ығысуды орындау үшін қолданылады.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0х1, шын));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// `self` абсолютті мәнін есептейді.
        ///
        /// Абсолютті өзіндік нұсқасының кортежін логикамен бірге толып кетудің болған-болмайтынын көрсетеді.
        /// Егер өзіндік минимум болса
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// содан кейін минималды мән қайтадан оралады және толып кету үшін ақиқат қайтарылады.
        ///
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// Квадраттау арқылы дәрежелеуді қолдана отырып, өзін `exp` қуатына дейін көтереді.
        ///
        /// Көрсеткіштің кортежін bool-мен бірге толып кетудің болған-болмайтынын көрсетеді.
        ///
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, шын));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Толып кету_mul нәтижелерін сақтауға арналған сызылған орын.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // exp!=0 болғандықтан, exp 1 болуы керек.
            // Көрсеткіштің соңғы битімен бөлек жұмыс жасаңыз, өйткені кейіннен базаны квадраттау қажет емес және қажетсіз асып кетуі мүмкін.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// Квадраттау арқылы дәрежелеуді қолдана отырып, өзін `exp` қуатына дейін көтереді.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // exp!=0 болғандықтан, exp 1 болуы керек.
            // Көрсеткіштің соңғы битімен бөлек жұмыс жасаңыз, өйткені кейіннен базаны квадраттау қажет емес және қажетсіз асып кетуі мүмкін.
            //
            //
            acc * base
        }

        /// Евклидтің `self`-ті `rhs`-ге бөлу бөлігін есептейді.
        ///
        /// Бұл `n` бүтін `self = n * rhs + self.rem_euclid(rhs)`, `0 <= self.rem_euclid(rhs) < rhs` болатындай етіп есептейді.
        ///
        ///
        /// Басқаша айтқанда, нәтиже `self / rhs` бүтін `n` санына дейін дөңгелектеніп, `self >= n * rhs` болады.
        /// Егер `self > 0` болса, бұл нөлге қарай дөңгелектеуге тең болады (Rust бойынша әдепкі);
        /// егер `self < 0` болса, бұл +/-шексіздікке қарай дөңгелекке тең.
        ///
        /// # Panics
        ///
        /// Бұл функция panic болады, егер `rhs` 0 болса немесе бөлу толып кетсе.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// b=4 болсын;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 assert_eq!(a.div_euclid(-b), -1);//7>= -4*-1 assert_eq!((-a).div_euclid(b), -2);//-7>=4 *-2 assert_eq!((-a).div_euclid(-b), 2);//-7>= -4* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// `self (mod rhs)` минималды емес қалдықтарын есептейді.
        ///
        /// Бұл Евклидті бөлу алгоритмі бойынша жасалады-`r = self.rem_euclid(rhs)`, `self = rhs * self.div_euclid(rhs) + r` және `0 <= r < abs(rhs)` берілген.
        ///
        ///
        /// # Panics
        ///
        /// Бұл функция panic болады, егер `rhs` 0 болса немесе бөлу толып кетсе.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// b=4 болсын;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// `self` абсолютті мәнін есептейді.
        ///
        /// # Толып жатқан тәртіп
        ///
        /// Абсолюттік мәні
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// ретінде ұсыныла алмайды
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// және оны есептеуге тырысу толып кетуді тудырады.
        /// Бұл дегеніміз, түзету режиміндегі код бұл жағдайда panic іске қосады және оңтайландырылған код қайтарылады
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// panic жоқ.
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // Жоғарыдағы#[кірістіру] алып тастаудың артық семантикасы біз кірістірілген crate-ге тәуелді екенін білдіретінін ескеріңіз.
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// `self` белгісін көрсететін санды қайтарады.
        ///
        ///  - `0` егер сан нөлге тең болса
        ///  - `1` егер сан оң болса
        ///  - `-1` егер сан теріс болса
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// Егер `self` оң болса, `true`, ал егер нөл немесе теріс болса, `false` қайтарады.
        ///
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// Егер `self` теріс болса, `true`, ал егер нөл немесе оң болса, `false` мәнін қайтарады.
        ///
        ///
        /// # Examples
        ///
        /// Негізгі пайдалану:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// Осы бүтін санның жадын байт массиві ретінде XIX байт ретімен қайтарыңыз.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Осы бүтін санның жадын байт массиві ретінде аз-енді байт ретімен қайтарыңыз.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Осы бүтін санның жад көрінісін байт реті бойынша байт жиымы ретінде қайтарыңыз.
        ///
        /// Мақсатты платформаның жергілікті ендігі пайдаланылатындықтан, оның орнына портативті код [`to_be_bytes`] немесе [`to_le_bytes`] қолдануы керек.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     байт, егер cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } басқа {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // ҚАУІПСІЗДІК: const дыбысы, өйткені бүтін сандар қарапайым типтік типтер, сондықтан біз әрқашан жасай аламыз
        // оларды байт массивтеріне ауыстырыңыз
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // ҚАУІПСІЗДІК: бүтін сандар қарапайым көне деректер типтері, сондықтан біз оларды әрқашан өзгерте аламыз
            // массив байттары
            unsafe { mem::transmute(self) }
        }

        /// Осы бүтін санның жад көрінісін байт реті бойынша байт жиымы ретінде қайтарыңыз.
        ///
        ///
        /// [`to_ne_bytes`] мүмкіндігінше бұған қарағанда артықшылық беру керек.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// байт= num.as_ne_bytes();
        /// assert_eq!(
        ///     байт, егер cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } басқа {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // ҚАУІПСІЗДІК: бүтін сандар қарапайым көне деректер типтері, сондықтан біз оларды әрқашан өзгерте аламыз
            // массив байттары
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Үлкен ендіда байт массиві ретінде оның бүтін мәнін жасаңыз.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto пайдалану;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * кіріс=демалыс;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Бітім массиві ретінде кішкене енян түрінде оның бүтін мәнін жасаңыз.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto пайдалану;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * кіріс=демалыс;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Оның жадынан байт жиымы ретінде бүтін мән құрыңыз.
        ///
        /// Мақсатты платформаның жергілікті ендігі пайдаланылғандықтан, портативті код орнына [`from_be_bytes`] немесе [`from_le_bytes`] пайдаланғысы келеді.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } басқа {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto пайдалану;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * кіріс=демалыс;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // ҚАУІПСІЗДІК: const дыбысы, өйткені бүтін сандар қарапайым типтік типтер, сондықтан біз әрқашан жасай аламыз
        // оларға ауыстыру
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // ҚАУІПСІЗДІК: бүтін сандар қарапайым көне деректер типтері, сондықтан біз оларды әрқашан өзгерте аламыз
            unsafe { mem::transmute(bytes) }
        }

        /// Жаңа код пайдалануды жөн көруі керек
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Осы бүтін типпен ұсынылуы мүмкін ең кіші мәнді қайтарады.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// Жаңа код пайдалануды жөн көруі керек
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Осы бүтін типпен ұсынылуы мүмкін ең үлкен мәнді қайтарады.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}