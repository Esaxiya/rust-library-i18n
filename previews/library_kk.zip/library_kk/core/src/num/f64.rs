//! `f64` екі дәлдіктегі өзгермелі нүкте түріне тән тұрақтылар.
//!
//! *[See also the `f64` primitive type][f64].*
//!
//! Математикалық маңызды сандар `consts` ішкі модулінде берілген.
//!
//! Тікелей осы модульде анықталған тұрақтылық үшін (`consts` ішкі модулінде анықталғаннан өзгеше), жаңа код орнына тікелей `f64` типінде анықталған байланысты тұрақтылықты қолдануы керек.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// `f64` ішкі көрінісінің радиусы немесе негізі.
/// Оның орнына [`f64::RADIX`] қолданыңыз.
///
/// # Examples
///
/// ```rust
/// // ескірген жол
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f64::RADIX;
///
/// // көзделген жол
/// let r = f64::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f64`")]
pub const RADIX: u32 = f64::RADIX;

/// 2-базадағы маңызды цифрлар саны.
/// Оның орнына [`f64::MANTISSA_DIGITS`] қолданыңыз.
///
/// # Examples
///
/// ```rust
/// // ескірген жол
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::MANTISSA_DIGITS;
///
/// // көзделген жол
/// let d = f64::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f64`"
)]
pub const MANTISSA_DIGITS: u32 = f64::MANTISSA_DIGITS;

/// 10-базадағы маңызды сандардың шамамен саны.
/// Оның орнына [`f64::DIGITS`] қолданыңыз.
///
/// # Examples
///
/// ```rust
/// // ескірген жол
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::DIGITS;
///
/// // көзделген жол
/// let d = f64::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f64`")]
pub const DIGITS: u32 = f64::DIGITS;

/// [Machine epsilon] `f64` мәні.
/// Оның орнына [`f64::EPSILON`] қолданыңыз.
///
/// Бұл `1.0` пен келесі үлкен нөмірдің арасындағы айырмашылық.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // ескірген жол
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f64::EPSILON;
///
/// // көзделген жол
/// let e = f64::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f64`"
)]
pub const EPSILON: f64 = f64::EPSILON;

/// Шекті `f64` мәні.
/// Оның орнына [`f64::MIN`] қолданыңыз.
///
/// # Examples
///
/// ```rust
/// // ескірген жол
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN;
///
/// // көзделген жол
/// let min = f64::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f64`")]
pub const MIN: f64 = f64::MIN;

/// Ең кіші позитивті қалыпты `f64` мәні.
/// Оның орнына [`f64::MIN_POSITIVE`] қолданыңыз.
///
/// # Examples
///
/// ```rust
/// // ескірген жол
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_POSITIVE;
///
/// // көзделген жол
/// let min = f64::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f64`"
)]
pub const MIN_POSITIVE: f64 = f64::MIN_POSITIVE;

/// Шекті `f64` мәні.
/// Оның орнына [`f64::MAX`] қолданыңыз.
///
/// # Examples
///
/// ```rust
/// // ескірген жол
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX;
///
/// // көзделген жол
/// let max = f64::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f64`")]
pub const MAX: f64 = f64::MAX;

/// 2 дәрежелік минималды қалыпты қуаттан үлкен.
/// Оның орнына [`f64::MIN_EXP`] қолданыңыз.
///
/// # Examples
///
/// ```rust
/// // ескірген жол
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_EXP;
///
/// // көзделген жол
/// let min = f64::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f64`"
)]
pub const MIN_EXP: i32 = f64::MIN_EXP;

/// 2 дәрежелік максималды қуат.
/// Оның орнына [`f64::MAX_EXP`] қолданыңыз.
///
/// # Examples
///
/// ```rust
/// // ескірген жол
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_EXP;
///
/// // көзделген жол
/// let max = f64::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f64`"
)]
pub const MAX_EXP: i32 = f64::MAX_EXP;

/// 10 дәрежелік минималды қалыпты қуат.
/// Оның орнына [`f64::MIN_10_EXP`] қолданыңыз.
///
/// # Examples
///
/// ```rust
/// // ескірген жол
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_10_EXP;
///
/// // көзделген жол
/// let min = f64::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f64`"
)]
pub const MIN_10_EXP: i32 = f64::MIN_10_EXP;

/// 10 дәрежелік максималды қуат.
/// Оның орнына [`f64::MAX_10_EXP`] қолданыңыз.
///
/// # Examples
///
/// ```rust
/// // ескірген жол
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_10_EXP;
///
/// // көзделген жол
/// let max = f64::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f64`"
)]
pub const MAX_10_EXP: i32 = f64::MAX_10_EXP;

/// (NaN) нөмірі емес.
/// Оның орнына [`f64::NAN`] қолданыңыз.
///
/// # Examples
///
/// ```rust
/// // ескірген жол
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f64::NAN;
///
/// // көзделген жол
/// let nan = f64::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f64`")]
pub const NAN: f64 = f64::NAN;

/// Infinity (∞).
/// Оның орнына [`f64::INFINITY`] қолданыңыз.
///
/// # Examples
///
/// ```rust
/// // ескірген жол
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f64::INFINITY;
///
/// // көзделген жол
/// let inf = f64::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f64`"
)]
pub const INFINITY: f64 = f64::INFINITY;

/// Теріс шексіздік (−∞).
/// Оның орнына [`f64::NEG_INFINITY`] қолданыңыз.
///
/// # Examples
///
/// ```rust
/// // ескірген жол
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f64::NEG_INFINITY;
///
/// // көзделген жол
/// let ninf = f64::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f64`"
)]
pub const NEG_INFINITY: f64 = f64::NEG_INFINITY;

/// Негізгі математикалық тұрақтылар.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: математикадан тұрақтыға ауыстырыңыз.

    /// Архимедтің тұрақты (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f64 = 3.14159265358979323846264338327950288_f64;

    /// Толық шеңбер тұрақты (τ)
    ///
    /// 2π-ге тең.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f64 = 6.28318530717958647692528676655900577_f64;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f64 = 1.57079632679489661923132169163975144_f64;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f64 = 1.04719755119659774615421446109316763_f64;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f64 = 0.785398163397448309615660845819875721_f64;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f64 = 0.52359877559829887307710723054658381_f64;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f64 = 0.39269908169872415480783042290993786_f64;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f64 = 0.318309886183790671537767526745028724_f64;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f64 = 0.636619772367581343075535053490057448_f64;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f64 = 1.12837916709551257389615890312154517_f64;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f64 = 1.41421356237309504880168872420969808_f64;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f64 = 0.707106781186547524400844362104849039_f64;

    /// Эйлер нөмірі (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f64 = 2.71828182845904523536028747135266250_f64;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f64 = 3.32192809488736234787031942948939018_f64;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f64 = 1.44269504088896340735992468100189214_f64;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f64 = 0.301029995663981195213738894724493027_f64;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f64 = 0.434294481903251827651128918916605082_f64;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f64 = 0.693147180559945309417232121458176568_f64;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f64 = 2.30258509299404568401799145468436421_f64;
}

#[lang = "f64"]
#[cfg(not(test))]
impl f64 {
    /// `f64` ішкі көрінісінің радиусы немесе негізі.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// 2-базадағы маңызды цифрлар саны.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 53;
    /// 10-базадағы маңызды сандардың шамамен саны.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 15;

    /// [Machine epsilon] `f64` мәні.
    ///
    /// Бұл `1.0` пен келесі үлкен нөмірдің арасындағы айырмашылық.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f64 = 2.2204460492503131e-16_f64;

    /// Шекті `f64` мәні.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f64 = -1.7976931348623157e+308_f64;
    /// Ең кіші позитивті қалыпты `f64` мәні.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f64 = 2.2250738585072014e-308_f64;
    /// Шекті `f64` мәні.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f64 = 1.7976931348623157e+308_f64;

    /// 2 дәрежелік минималды қалыпты қуаттан үлкен.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -1021;
    /// 2 дәрежелік максималды қуат.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 1024;

    /// 10 дәрежелік минималды қалыпты қуат.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -307;
    /// 10 дәрежелік максималды қуат.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 308;

    /// (NaN) нөмірі емес.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f64 = 0.0_f64 / 0.0_f64;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f64 = 1.0_f64 / 0.0_f64;
    /// Теріс шексіздік (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f64 = -1.0_f64 / 0.0_f64;

    /// Егер бұл мән `NaN` болса, `true` мәнін қайтарады.
    ///
    /// ```
    /// let nan = f64::NAN;
    /// let f = 7.0_f64;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` портативті алаңдаушылыққа байланысты libcore-та көпшілікке қол жетімді емес, сондықтан бұл іске асыру жеке пайдалануға арналған.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f64 {
        f64::from_bits(self.to_bits() & 0x7fff_ffff_ffff_ffff)
    }

    /// Егер бұл мән оң шексіздікке немесе теріс шексіздікке тең болса, `true` мәнін, ал басқаша жағдайда `false` мәнін қайтарады.
    ///
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf = f64::INFINITY;
    /// let neg_inf = f64::NEG_INFINITY;
    /// let nan = f64::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Егер бұл сан шексіз немесе `NaN` болмаса, `true` мәнін қайтарады.
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf: f64 = f64::INFINITY;
    /// let neg_inf: f64 = f64::NEG_INFINITY;
    /// let nan: f64 = f64::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // NaN-мен бөлек жұмыс істеудің қажеті жоқ: егер өзін-өзі NaN болса, салыстыру дұрыс емес, дәл қалағандай.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Егер сан [subnormal] болса, `true` мәнін қайтарады.
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308_f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0_f64;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f64::NAN.is_subnormal());
    /// assert!(!f64::INFINITY.is_subnormal());
    /// // `0` пен `min` арасындағы мәндер нормадан тыс болып табылады.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Егер сан нөл, шексіз, [subnormal] немесе `NaN` болмаса, `true` мәнін қайтарады.
    ///
    ///
    /// ```
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0f64;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f64::NAN.is_normal());
    /// assert!(!f64::INFINITY.is_normal());
    /// // `0` пен `min` арасындағы мәндер нормадан тыс болып табылады.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Санның өзгермелі нүкте санатын қайтарады.
    /// Егер бір ғана қасиет тексерілетін болса, оның орнына нақты предикатты қолдану тезірек болады.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f64;
    /// let inf = f64::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u64 = 0x7ff0000000000000;
        const MAN_MASK: u64 = 0x000fffffffffffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Егер `self` позитивті таңбасы болса, соның ішінде `+0.0`, `NaN` оң таңбасы және оң шексіздігі болса, `true` қайтарады.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_positive")]
    #[inline]
    #[doc(hidden)]
    pub fn is_positive(self) -> bool {
        self.is_sign_positive()
    }

    /// Егер `self` теріс таңбасы болса, соның ішінде `-0.0`, `NaN` теріс таңбасы және теріс шексіздігі болса, `true` қайтарады.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        self.to_bits() & 0x8000_0000_0000_0000 != 0
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_negative")]
    #[inline]
    #[doc(hidden)]
    pub fn is_negative(self) -> bool {
        self.is_sign_negative()
    }

    /// Санның өзара (inverse) қабылдайды, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f64;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f64 {
        1.0 / self
    }

    /// Радиандарды градусқа түрлендіреді.
    ///
    /// ```
    /// let angle = std::f64::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_degrees(self) -> f64 {
        // Мұндағы бөлу 180/true шын мәніне қатысты дұрыс дөңгелектелген.
        // (Бұл f32-тен ерекшеленеді, мұнда дұрыс дөңгелектелген нәтиже алу үшін тұрақты мәнді қолдану керек).
        //
        self * (180.0f64 / consts::PI)
    }

    /// Дәрежелерді радианға айналдырады.
    ///
    /// ```
    /// let angle = 180.0_f64;
    ///
    /// let abs_difference = (angle.to_radians() - std::f64::consts::PI).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_radians(self) -> f64 {
        let value: f64 = consts::PI;
        self * (value / 180.0)
    }

    /// Екі санның максимумын қайтарады.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Егер аргументтердің бірі NaN болса, онда екіншісі қайтарылады.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f64) -> f64 {
        intrinsics::maxnumf64(self, other)
    }

    /// Екі санның минимумын қайтарады.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Егер аргументтердің бірі NaN болса, онда екіншісі қайтарылады.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f64) -> f64 {
        intrinsics::minnumf64(self, other)
    }

    /// Нөлге қарай дөңгелектеніп, мәні ақырлы және осы түрге сәйкес келеді деп, кез-келген қарабайыр бүтін типке ауысады.
    ///
    ///
    /// ```
    /// let value = 4.6_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Мән:
    ///
    /// * `NaN` емес
    /// * Шексіз емес
    /// * Бөлшек бөлігін кесіп тастағаннан кейін, `Int` қайтару түрінде танымал болыңыз
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // ҚАУІПСІЗДІК: қоңырау шалушы `FloatToInt::to_int_unchecked` қауіпсіздік шартын сақтауы керек.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// `u64`-ге шикі трансмутуация.
    ///
    /// Қазіргі уақытта бұл `transmute::<f64, u64>(self)` барлық платформалармен бірдей.
    ///
    /// Осы операцияның портативтілігі туралы біраз талқылау үшін `from_bits` бөлімін қараңыз (ешқандай мәселе жоқ).
    ///
    /// Бұл функция биттік мәнді емес,*сандық* мәнді сақтауға тырысатын `as` кастингінен ерекше екенін ескеріңіз.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((1f64).to_bits() != 1f64 as u64); // to_bits() кастинг емес!
    /// assert_eq!((12.5f64).to_bits(), 0x4029000000000000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u64 {
        // ҚАУІПСІЗДІК: `u64`-бұл қарапайым ескі деректер түрі, сондықтан біз оны әрқашан өзгерте аламыз
        unsafe { mem::transmute(self) }
    }

    /// `u64`-тен шикі трансмутуация.
    ///
    /// Қазіргі уақытта бұл `transmute::<u64, f64>(v)` барлық платформалармен бірдей.
    /// Бұл екі себеп бойынша керемет портативті болып шығады:
    ///
    /// * Floats және Ints барлық қолдау көрсетілетін платформаларда бірдей ендікке ие.
    /// * IEEE-754 қалтқылардың орналасу схемасын дәл анықтайды.
    ///
    /// Алайда бір ескерту бар: IEEE-754 2008 нұсқасына дейін NaN сигналдық битін қалай түсіндіру керек екендігі нақты көрсетілмеген.
    /// Көптеген платформалар (атап айтқанда x86 және ARM) 2008 жылы стандартталған интерпретацияны таңдады, бірақ кейбіреулері (атап айтқанда MIPS) алмады.
    /// Нәтижесінде, MIPS кезіндегі барлық сигналдық NaNs-x86-тағы тыныш NaN, және керісінше.
    ///
    /// Сигналдық кросс-платформаны сақтауға тырысқаннан гөрі, бұл нақты биттерді сақтауға мүмкіндік береді.
    /// Бұл дегеніміз, NaN-де кодталған кез-келген пайдалы жүктемелер осы әдіс нәтижесі желі арқылы x86 машинасынан MIPS-ге жіберілген жағдайда да сақталады.
    ///
    ///
    /// Егер осы әдістің нәтижелері оларды жасаған сол архитектурамен басқарылатын болса, онда портативтілікке қатысты мәселе болмайды.
    ///
    /// Егер кіріс NaN болмаса, онда тасымалдануға қатысты мәселе жоқ.
    ///
    /// Егер сіз сигнал беру туралы маңызды болмасаңыз (мүмкін), онда портативті алаңдаушылық жоқ.
    ///
    /// Бұл функция биттік мәнді емес,*сандық* мәнді сақтауға тырысатын `as` кастингінен ерекше екенін ескеріңіз.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f64::from_bits(0x4029000000000000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u64) -> Self {
        // ҚАУІПСІЗДІК: `u64`-бұл қарапайым көне деректер түрі, сондықтан біз оны әрқашан өзгерте аламыз
        // SNaN-тің қауіпсіздік мәселелері тым көп болды!Ура!
        unsafe { mem::transmute(v) }
    }

    /// Осы өзгермелі нүкте жадының көрінісін бай ені (network) байт ретімен байт жиымы ретінде қайтарыңыз.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_be_bytes();
    /// assert_eq!(bytes, [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 8] {
        self.to_bits().to_be_bytes()
    }

    /// Осы өзгермелі нүкте санының жадын бейнені байт жиымы ретінде аз ендиан байт ретімен қайтарыңыз.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 8] {
        self.to_bits().to_le_bytes()
    }

    /// Осы өзгермелі нүкте жадының көрінісін байт реті бойынша байт жиымы ретінде қайтарыңыз.
    ///
    /// Мақсатты платформаның жергілікті ендігі пайдаланылатындықтан, оның орнына портативті код [`to_be_bytes`] немесе [`to_le_bytes`] қолдануы керек.
    ///
    ///
    /// [`to_be_bytes`]: f64::to_be_bytes
    /// [`to_le_bytes`]: f64::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 8] {
        self.to_bits().to_ne_bytes()
    }

    /// Осы өзгермелі нүкте жадының көрінісін байт реті бойынша байт жиымы ретінде қайтарыңыз.
    ///
    ///
    /// [`to_ne_bytes`] мүмкіндігінше бұған қарағанда артықшылық беру керек.
    ///
    /// [`to_ne_bytes`]: f64::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f64;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 8] {
        // ҚАУІПСІЗДІК: `f64`-бұл қарапайым ескі деректер түрі, сондықтан біз оны әрқашан өзгерте аламыз
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Үлкен енинде байт жиымы ретінде ұсынылғаннан өзгермелі нүкте мәнін жасаңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_be_bytes([0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_be_bytes(bytes))
    }

    /// Кішкентай енинде байт жиымы ретінде ұсынылғаннан өзгермелі нүкте мәнін жасаңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_le_bytes([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_le_bytes(bytes))
    }

    /// Оны жергілікті ендіан байт жиымы ретінде ұсынғаннан өзгермелі нүкте мәнін жасаңыз.
    ///
    /// Мақсатты платформаның жергілікті ендігі пайдаланылғандықтан, портативті код орнына [`from_be_bytes`] немесе [`from_le_bytes`] пайдаланғысы келеді.
    ///
    ///
    /// [`from_be_bytes`]: f64::from_be_bytes
    /// [`from_le_bytes`]: f64::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_ne_bytes(bytes))
    }

    /// Өзіндік және басқа мәндер арасындағы ретті қайтарады.
    /// Жылжымалы нүктелер арасындағы стандартты ішінара салыстырудан айырмашылығы, бұл салыстыру әрқашан IOEE 754 (2008 ж. Редакциялау) өзгермелі нүкте стандартында анықталған totalOrder предикатына сәйкес тапсырыс береді.
    /// Мәндерге келесі ретпен тапсырыс беріледі:
    /// - Теріс тыныш NaN
    /// - Теріс сигнал NaN
    /// - Теріс шексіздік
    /// - Теріс сандар
    /// - Теріс субнормальды сандар
    /// - Теріс нөл
    /// - Оң нөл
    /// - Оң субнормальды сандар
    /// - Оң сандар
    /// - Оң шексіздік
    /// - Оң сигнал беру NaN
    /// - Оң тыныш NaN
    ///
    /// Бұл функция `f64`-тің [`PartialOrd`] және [`PartialEq`] іске асыруларымен әрдайым сәйкес келе бермейтінін ескеріңіз.Атап айтқанда, олар теріс және оң нөлді тең деп санайды, ал `total_cmp` тең емес.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f64,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f64::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f64::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f64::INFINITY, f64::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i64;
        let mut right = other.to_bits() as i64;

        // Теріс жағдайларда, екінің бүтін сандары сияқты орналасуға қол жеткізу үшін белгіден басқа барлық биттерді аударыңыз
        //
        // Неге бұл жұмыс істейді?IEEE 754 қалқымалы үш өрістен тұрады:
        // Бит, дәреже және мантисса.Көрсеткіш және мантисса өрістерінің жиынтығы тұтастай алғанда олардың разрядтық реті шамасы анықталған сандық шамасына тең болатын қасиетке ие.
        // Әдетте NaN мәндері бойынша шамалар анықталмайды, бірақ IEEE 754 totalOrder NaN мәндерін сонымен қатар разрядты ретпен анықтайды.Бұл құжат түсініктемесінде түсіндірілген тәртіпке әкеледі.
        // Алайда, шаманың көрінісі теріс және оң сандар үшін бірдей-тек белгі биті әр түрлі.
        // Қалқымалы белгілерді таңбалы бүтін сандар ретінде оңай салыстыру үшін, теріс сандар жағдайында дәрежелік және мантисса биттерін аудару керек.
        // Біз сандарды "two's complement" формасына тиімді түрлендіреміз.
        //
        // Флипинг жасау үшін біз оған маска және XOR жасаймыз.
        // Теріс таңбалы мәндерден біз "all-ones except for the sign bit" маскасын саласыз түрде есептейміз: оңға жылжу белгісі-бүтін санды кеңейтеді, сондықтан біз белгі биттерімен масканы "fill"-ге айналдырамыз, содан кейін тағы бір нөлдік разрядты итеру үшін белгісізге айналдырамыз.
        //
        // Оң мәндерде маска барлық нөлдер болып табылады, сондықтан бұл тыйым салынады.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 63) as u64) >> 1) as i64;
        right ^= (((right >> 63) as u64) >> 1) as i64;

        left.cmp(&right)
    }

    /// Егер NaN болмаса, белгілі бір интервалмен мәнді шектеңіз.
    ///
    /// Егер `self` `max`-тен үлкен болса `max`, ал `self` `min`-тен кіші болса `min` қайтарады.
    /// Әйтпесе, бұл `self` қайтарады.
    ///
    /// Егер бастапқы мән NaN болса, бұл функция NaN қайтаратынын ескеріңіз.
    ///
    /// # Panics
    ///
    /// Panics, егер `min > max`, `min`-NaN немесе `max`-NaN болса.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f64).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f64).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f64).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f64::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f64, max: f64) -> f64 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}