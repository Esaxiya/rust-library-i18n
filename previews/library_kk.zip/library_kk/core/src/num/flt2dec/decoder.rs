//! Қалқымалы мәнді жеке бөліктерге және қателіктер диапазонына декодтайды.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Декодталған қол қойылмаған ақырлы мән, мысалы:
///
/// - Бастапқы мән `mant * 2^exp`-ге тең.
///
/// - `(mant - minus)*2^exp`-тен `(mant + plus)* 2^exp`-ге дейінгі кез келген сан бастапқы мәнге дейін дөңгелектенеді.
/// Ауқым тек `inclusive` `true` болғанда ғана қосылады.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Көлемді мантисса.
    pub mant: u64,
    /// Төменгі қателіктер диапазоны.
    pub minus: u64,
    /// Жоғарғы қателіктер диапазоны.
    pub plus: u64,
    /// 2-негіздегі ортақ көрсеткіш.
    pub exp: i16,
    /// Қате диапазоны қосылған кезде дұрыс.
    ///
    /// IEEE 754-де бұл бастапқы мантисса біркелкі болған кезде дұрыс.
    pub inclusive: bool,
}

/// Декодталған қол қойылмаған мән.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Шексіз, оң немесе теріс.
    Infinite,
    /// Нөл, оң немесе теріс.
    Zero,
    /// Әрі қарай декодталған өрістермен ақырлы сандар.
    Finite(Decoded),
}

/// «Декодтау» болуы мүмкін өзгермелі нүкте түрі.
pub trait DecodableFloat: RawFloat + Copy {
    /// Минималды оң қалыпқа келтірілген мән.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Берілген өзгермелі нүкте санынан белгі (теріс болғанда шын) және `FullDecoded` мәнін қайтарады.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // көршілер: (мант, 2, экс)-(мант, экс)-(мант + 2, экс)
            // Float::integer_decode әрқашан экспонентті сақтайды, сондықтан мантисса субнормальділер үшін масштабталады.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // көршілер: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // мұндағы maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // көршілер: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}