/*!

Floating-point number to decimal conversion routines.

# Problem statement

We are given the floating-point number `v = f * 2^e` with an integer `f`,
and its bounds `minus` and `plus` such that any number between `v - minus` and
`v + plus` will be rounded to `v`. For the simplicity we assume that
this range is exclusive. Then we would like to get the unique decimal
representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero.

- It's correctly rounded when parsed back: `v - minus < V < v + plus`.
  Furthermore it is shortest such one, i.e., there is no representation
  with less than `n` digits that is correctly rounded.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Note that
  there might be two representations satisfying this uniqueness requirement,
  in which case some tie-breaking mechanism is used.

We will call this mode of operation as to the *shortest* mode. This mode is used
when there is no additional constraint, and can be thought as a "natural" mode
as it matches the ordinary intuition (it at least prints `0.1f32` as "0.1").

We have two more modes of operation closely related to each other. In these modes
we are given either the number of significant digits `n` or the last-digit
limitation `limit` (which determines the actual `n`), and we would like to get
the representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero, unless `n` was zero in which case only `k` is returned.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Again,
  there might be some tie-breaking mechanism.

When `limit` is given but not `n`, we set `n` such that `k - n = limit`
so that the last digit `d[n-1]` is scaled by `10^(k-n) = 10^limit`.
If such `n` is negative, we clip it to zero so that we will only get `k`.
We are also limited by the supplied buffer. This limitation is used to print
the number up to given number of fractional digits without knowing
the correct `k` beforehand.

We will call the mode of operation requiring `n` as to the *exact* mode,
and one requiring `limit` as to the *fixed* mode. The exact mode is a subset of
the fixed mode: the sufficiently large last-digit limitation will eventually fill
the supplied buffer and let the algorithm to return.

# Implementation overview

It is easy to get the floating point printing correct but slow (Russ Cox has
[demonstrated](http://research.swtch.com/ftoa) how it's easy), or incorrect but
fast (naïve division and modulo). But it is surprisingly hard to print
floating point numbers correctly *and* efficiently.

There are two classes of algorithms widely known to be correct.

- The "Dragon" family of algorithm is first described by Guy L. Steele Jr. and
  Jon L. White. They rely on the fixed-size big integer for their correctness.
  A slight improvement was found later, which is posthumously described by
  Robert G. Burger and R. Kent Dybvig. David Gay's `dtoa.c` routine is
  a popular implementation of this strategy.

- The "Grisu" family of algorithm is first described by Florian Loitsch.
  They use very cheap integer-only procedure to determine the close-to-correct
  representation which is at least guaranteed to be shortest. The variant,
  Grisu3, actively detects if the resulting representation is incorrect.

We implement both algorithms with necessary tweaks to suit our requirements.
In particular, published literatures are short of the actual implementation
difficulties like how to avoid arithmetic overflows. Each implementation,
available in `strategy::dragon` and `strategy::grisu` respectively,
extensively describes all necessary justifications and many proofs for them.
(It is still difficult to follow though. You have been warned.)

Both implementations expose two public functions:

- `format_shortest(decoded, buf)`, which always needs at least
  `MAX_SIG_DIGITS` digits of buffer. Implements the shortest mode.

- `format_exact(decoded, buf, limit)`, which accepts as small as
  one digit of buffer. Implements exact and fixed modes.

They try to fill the `u8` buffer with digits and returns the number of digits
written and the exponent `k`. They are total for all finite `f32` and `f64`
inputs (Grisu internally falls back to Dragon if necessary).

The rendered digits are formatted into the actual string form with
four functions:

- `to_shortest_str` prints the shortest representation, which can be padded by
  zeroes to make *at least* given number of fractional digits.

- `to_shortest_exp_str` prints the shortest representation, which can be
  padded by zeroes when its exponent is in the specified ranges,
  or can be printed in the exponential form such as `1.23e45`.

- `to_exact_exp_str` prints the exact representation with given number of
  digits in the exponential form.

- `to_exact_fixed_str` prints the fixed representation with *exactly*
  given number of fractional digits.

They all return a slice of preallocated `Part` array, which corresponds to
the individual part of strings: a fixed string, a part of rendered digits,
a number of zeroes or a small (`u16`) number. The caller is expected to
provide a large enough buffer and `Part` array, and to assemble the final
string from resulting `Part`s itself.

All algorithms and formatting functions are accompanied by extensive tests
in `coretests::num::flt2dec` module. It also shows how to use individual
functions.

*/

// бұл кең көлемде құжатталғанымен, бұл негізінен жеке болып табылады, ол тек тестілеу үшін жария болады.
// бізді әшкерелеме.
#![doc(hidden)]
#![unstable(
    feature = "flt2dec",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

pub use self::decoder::{decode, DecodableFloat, Decoded, FullDecoded};

use crate::mem::MaybeUninit;

pub mod decoder;
pub mod estimator;

/// Цифрларды генерациялау алгоритмдері.
pub mod strategy {
    pub mod dragon;
    pub mod grisu;
}

/// Ең қысқа режимге қажет буфердің минималды мөлшері.
///
/// Мұны алу өте маңызды емес, бірақ бұл нәтиже ең қысқа нәтиже беретін алгоритмдерден алынған ондық сандардың максималды саны.
///
/// Нақты формула-`ceil(# bits in mantissa * log_10 2 + 1)`.
pub const MAX_SIG_DIGITS: usize = 17;

/// `d` ондық цифрлардан тұрғанда, соңғы цифрды көбейтіп, тасымалдауды таратыңыз.
/// Ұзындығы өзгерген кезде келесі цифрды қайтарады.
#[doc(hidden)]
pub fn round_up(d: &mut [u8]) -> Option<u8> {
    match d.iter().rposition(|&c| c != b'9') {
        Some(i) => {
            // d [i + 1..n]-барлығы тоғыз
            d[i] += 1;
            for j in i + 1..d.len() {
                d[j] = b'0';
            }
            None
        }
        None if d.len() > 0 => {
            // 999..999 үлкейтілген дәрежемен 1000..000 дейін дөңгелектейді
            d[0] = b'1';
            for j in 1..d.len() {
                d[j] = b'0';
            }
            Some(b'0')
        }
        None => {
            // бос буфер дөңгелектенеді (біртүрлі, бірақ ақылға қонымды)
            Some(b'1')
        }
    }
}

/// Пішімделген бөліктер.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Part<'a> {
    /// Нөлдік цифрлар саны.
    Zero(usize),
    /// 5 цифрына дейінгі әріптік сан.
    Num(u16),
    /// Берілген байттардың сөзбе-сөз көшірмесі.
    Copy(&'a [u8]),
}

impl<'a> Part<'a> {
    /// Берілген бөліктің байт ұзындығын қайтарады.
    pub fn len(&self) -> usize {
        match *self {
            Part::Zero(nzeroes) => nzeroes,
            Part::Num(v) => {
                if v < 1_000 {
                    if v < 10 {
                        1
                    } else if v < 100 {
                        2
                    } else {
                        3
                    }
                } else {
                    if v < 10_000 { 4 } else { 5 }
                }
            }
            Part::Copy(buf) => buf.len(),
        }
    }

    /// Берілген буферге бөлігін жазады.
    /// Жазылған байттардың санын қайтарады немесе буфер жеткіліксіз болса, `None`.
    /// (Ол буферде ішінара жазылған байттарды қалдыруы мүмкін; бұған сенбеңіз.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        let len = self.len();
        if out.len() >= len {
            match *self {
                Part::Zero(nzeroes) => {
                    for c in &mut out[..nzeroes] {
                        *c = b'0';
                    }
                }
                Part::Num(mut v) => {
                    for c in out[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                }
                Part::Copy(buf) => {
                    out[..buf.len()].copy_from_slice(buf);
                }
            }
            Some(len)
        } else {
            None
        }
    }
}

/// Бір немесе бірнеше бөлікті қамтитын форматталған нәтиже.
/// Мұны байт буферіне жазуға немесе бөлінген жолға түрлендіруге болады.
#[allow(missing_debug_implementations)]
#[derive(Clone)]
pub struct Formatted<'a> {
    /// `""`, `"-"` немесе `"+"` белгілерін білдіретін байт кесіндісі.
    pub sign: &'static str,
    /// Пішімделген бөліктер белгіден және қосымша нөлдік толтырудан кейін көрсетілетін болады.
    pub parts: &'a [Part<'a>],
}

impl<'a> Formatted<'a> {
    /// Біріктірілген форматталған нәтиженің байт ұзындығын қайтарады.
    pub fn len(&self) -> usize {
        let mut len = self.sign.len();
        for part in self.parts {
            len += part.len();
        }
        len
    }

    /// Барлық форматталған бөліктерді берілген буферге жазады.
    /// Жазылған байттардың санын қайтарады немесе буфер жеткіліксіз болса, `None`.
    /// (Ол буферде ішінара жазылған байттарды қалдыруы мүмкін; бұған сенбеңіз.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < self.sign.len() {
            return None;
        }
        out[..self.sign.len()].copy_from_slice(self.sign.as_bytes());

        let mut written = self.sign.len();
        for part in self.parts {
            let len = part.write(&mut out[written..])?;
            written += len;
        }
        Some(written)
    }
}

/// `0.<...buf...> * 10^exp` ондық сандарын, кем дегенде, бөлшек цифрлардың берілген санымен ондық пішінге форматтайды.
///
/// Нәтиже берілген бөліктер массивінде сақталады және жазылған бөліктердің бір бөлігі қайтарылады.
///
/// `frac_digits` `buf` нақты бөлшек цифрларының санынан аз болуы мүмкін;
/// ол еленбейді және толық цифрлар басылып шығады.Ол тек көрсетілген цифрлардан кейін қосымша нөлдерді басып шығару үшін қолданылады.
/// Осылайша 0-дің `frac_digits` мәні тек берілген цифрларды басып шығаратынын білдіреді, ал басқа ешнәрсе болмайды.
///
fn digits_to_dec_str<'a>(
    buf: &'a [u8],
    exp: i16,
    frac_digits: usize,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 4);

    // егер соңғы цифрлық позицияда шектеу болса, `buf` виртуалды нөлдермен сол жақта толтырылады деп есептеледі.
    // виртуалды нөлдердің саны, `nzeroes`, `max(0, exp + frac_digits - buf.len())`-ге тең, сонда `exp - buf.len() - nzeroes` цифрының орны `-frac_digits` аспайды:
    //
    //
    //                       |<-virtual->|
    //       | <----buf----> |нөлдер |эксп
    //    0. 1 2 3 4 5 6 7 8 9 _ _ _ _ _ _ x 10
    //    |                  |           |
    // 10 ^ exp 10^(exp-buf.len()) 10^(exp-buf.len()-nzeroes)
    //
    // `nzeroes` толып кетпеуі үшін әр жағдайға жеке есептеледі.
    //

    if exp <= 0 {
        // ондық нүкте цифрлар алдында көрсетілген: [0.][000...000][1234][____]
        let minus_exp = -(exp as i32) as usize;
        parts[0] = MaybeUninit::new(Part::Copy(b"0."));
        parts[1] = MaybeUninit::new(Part::Zero(minus_exp));
        parts[2] = MaybeUninit::new(Part::Copy(buf));
        if frac_digits > buf.len() && frac_digits - buf.len() > minus_exp {
            parts[3] = MaybeUninit::new(Part::Zero((frac_digits - buf.len()) - minus_exp));
            // ҚАУІПСІЗДІК: біз `..4` элементтерін инициализацияладық.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
        } else {
            // ҚАУІПСІЗДІК: біз `..3` элементтерін инициализацияладық.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
        }
    } else {
        let exp = exp as usize;
        if exp < buf.len() {
            // ондық нүкте көрсетілген сандардың ішінде: [12][.][34][____]
            parts[0] = MaybeUninit::new(Part::Copy(&buf[..exp]));
            parts[1] = MaybeUninit::new(Part::Copy(b"."));
            parts[2] = MaybeUninit::new(Part::Copy(&buf[exp..]));
            if frac_digits > buf.len() - exp {
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits - (buf.len() - exp)));
                // ҚАУІПСІЗДІК: біз `..4` элементтерін инициализацияладық.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // ҚАУІПСІЗДІК: біз `..3` элементтерін инициализацияладық.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
            }
        } else {
            // ондық нүкте көрсетілген сандардан кейін болады: [1234][____0000] немесе [1234][__][.][__].
            parts[0] = MaybeUninit::new(Part::Copy(buf));
            parts[1] = MaybeUninit::new(Part::Zero(exp - buf.len()));
            if frac_digits > 0 {
                parts[2] = MaybeUninit::new(Part::Copy(b"."));
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits));
                // ҚАУІПСІЗДІК: біз `..4` элементтерін инициализацияладық.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // ҚАУІПСІЗДІК: біз `..2` элементтерін инициализацияладық.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) }
            }
        }
    }
}

/// Берілген `0.<...buf...> * 10^exp` ондық сандарын, ең болмағанда, маңызды цифрлардың берілген санымен экспоненциалды формаға келтіреді.
///
/// `upper` `true` болғанда, дәреженің префиксі `E` болады;әйтпесе бұл `e`.
/// Нәтиже берілген бөліктер массивінде сақталады және жазылған бөліктердің бір бөлігі қайтарылады.
///
/// `min_digits` `buf` нақты мәндерінің санынан аз болуы мүмкін;
/// ол еленбейді және толық цифрлар басылып шығады.Ол тек көрсетілген цифрлардан кейін қосымша нөлдерді басып шығару үшін қолданылады.
/// Сонымен, `min_digits == 0` тек берілген цифрларды ғана басатындығын білдіреді, ал басқа ешнәрсе болмайды.
///
fn digits_to_exp_str<'a>(
    buf: &'a [u8],
    exp: i16,
    min_ndigits: usize,
    upper: bool,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 6);

    let mut n = 0;

    parts[n] = MaybeUninit::new(Part::Copy(&buf[..1]));
    n += 1;

    if buf.len() > 1 || min_ndigits > 1 {
        parts[n] = MaybeUninit::new(Part::Copy(b"."));
        parts[n + 1] = MaybeUninit::new(Part::Copy(&buf[1..]));
        n += 2;
        if min_ndigits > buf.len() {
            parts[n] = MaybeUninit::new(Part::Zero(min_ndigits - buf.len()));
            n += 1;
        }
    }

    // 0.1234 x 10 ^ exp= 1.234 x 10 ^ (exp-1)
    let exp = exp as i32 - 1; // exp i16::MIN болған кезде тасқыннан аулақ болыңыз
    if exp < 0 {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E-" } else { b"e-" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(-exp as u16));
    } else {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E" } else { b"e" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(exp as u16));
    }
    // ҚАУІПСІЗДІК: біз `..n + 2` элементтерін инициализацияладық.
    unsafe { MaybeUninit::slice_assume_init_ref(&parts[..n + 2]) }
}

/// Белгілерді форматтау параметрлері.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Sign {
    /// `-`-ті тек нөлдік емес мәндер үшін басып шығарады.
    Minus, // -inf -1 0 0 1 инф. Нан
    /// `-`-ті кез келген теріс мәндерге (теріс нөлді қосқанда) ғана басып шығарады.
    MinusRaw, // -inf -1 -0 0 1 инф нан
    /// Нөлдік емес теріс мәндер үшін `-` немесе басқа жағдайда `+` басып шығарады.
    MinusPlus, // -inf -1 +0 +0 +1 + inf nan
    /// Кез-келген теріс мәндер үшін `-`-ті (теріс нөлді қоса) немесе басқаша `+`-ді басып шығарады.
    MinusPlusRaw, // -inf -1 -0 +0 +1 + inf nan
}

/// Пішімделетін белгіге сәйкес статикалық байт жолын қайтарады.
/// Ол `""`, `"+"` немесе `"-"` болуы мүмкін.
fn determine_sign(sign: Sign, decoded: &FullDecoded, negative: bool) -> &'static str {
    match (*decoded, sign) {
        (FullDecoded::Nan, _) => "",
        (FullDecoded::Zero, Sign::Minus) => "",
        (FullDecoded::Zero, Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (FullDecoded::Zero, Sign::MinusPlus) => "+",
        (FullDecoded::Zero, Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
        (_, Sign::Minus | Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (_, Sign::MinusPlus | Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
    }
}

/// Берілген өзгермелі нүктелік санды, ең болмағанда, бөлшек цифрлардың берілген санымен ондық түрге келтіреді.
/// Нәтиже берілген байт буферін сызат ретінде пайдалану кезінде берілген бөліктер массивінде сақталады.
/// `upper` қазіргі уақытта пайдаланылмаған, бірақ future ақырғы емес мәндердің жағдайын өзгерту туралы шешім қабылдауға қалдырылған, яғни `inf` және `nan`.
///
/// Көрсетілетін бірінші бөлік әрқашан `Part::Sign` болып табылады (егер ешқандай белгі көрсетілмеген болса, бос жол болуы мүмкін).
///
/// `format_shortest` цифрларды қалыптастыру функциясы болуы керек.
/// Ол буфердің инициалданған бөлігін қайтаруы керек.
/// Бұл үшін сізге `strategy::grisu::format_shortest` керек болар.
///
/// `frac_digits` `v` нақты бөлшек цифрларының санынан аз болуы мүмкін;
/// ол еленбейді және толық цифрлар басылып шығады.Ол тек көрсетілген цифрлардан кейін қосымша нөлдерді басып шығару үшін қолданылады.
/// Осылайша 0-дің `frac_digits` мәні тек берілген цифрларды басып шығаратынын білдіреді, ал басқа ешнәрсе болмайды.
///
/// Байт буферінің ұзындығы кем дегенде `MAX_SIG_DIGITS` байт болуы керек.
/// `frac_digits = 10` бар `[+][0.][0000][2][0000]` сияқты ең нашар жағдайға байланысты кем дегенде 4 бөлік болуы керек.
///
///
///
pub fn to_shortest_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);
    assert!(buf.len() >= MAX_SIG_DIGITS);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // ҚАУІПСІЗДІК: біз `..1` элементтерін инициализацияладық.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // ҚАУІПСІЗДІК: біз `..1` элементтерін инициализацияладық.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // ҚАУІПСІЗДІК: біз `..2` элементтерін инициализацияладық.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // ҚАУІПСІЗДІК: біз `..1` элементтерін инициализацияладық.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
        }
    }
}

/// Берілген өзгермелі нүкте санын алынған дәрежеге байланысты ондық түрге немесе экспоненциалды формаға келтіреді.
/// Нәтиже берілген байт буферін сызат ретінде пайдалану кезінде берілген бөліктер массивінде сақталады.
/// `upper` ақырғы емес мәндердің жағдайын (`inf` және `nan`) немесе дәрежелік префикстің жағдайын (`e` немесе `E`) анықтау үшін қолданылады.
/// Көрсетілетін бірінші бөлік әрқашан `Part::Sign` болып табылады (егер ешқандай белгі көрсетілмеген болса, бос жол болуы мүмкін).
///
/// `format_shortest` цифрларды қалыптастыру функциясы болуы керек.
/// Ол буфердің инициалданған бөлігін қайтаруы керек.
/// Бұл үшін сізге `strategy::grisu::format_shortest` керек болар.
///
/// `dec_bounds`-бұл `(lo, hi)` кортежі, сондықтан сан тек `10^lo <= V < 10^hi` болғанда ондық түрінде форматталады.
/// Бұл нақты `v` орнына *айқын*`V` екенін ескеріңіз!Сонымен, экспоненциалды формадағы кез-келген басылған көрсеткіш кез-келген шатасудан аулақ бола отырып, осы ауқымда бола алмайды.
///
///
/// Байт буферінің ұзындығы кем дегенде `MAX_SIG_DIGITS` байт болуы керек.
/// `[+][1][.][2345][e][-][6]` сияқты ең нашар жағдайға байланысты кем дегенде 6 бөлік болуы керек.
///
///
///
///
///
pub fn to_shortest_exp_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    dec_bounds: (i16, i16),
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(dec_bounds.0 <= dec_bounds.1);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // ҚАУІПСІЗДІК: біз `..1` элементтерін инициализацияладық.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // ҚАУІПСІЗДІК: біз `..1` элементтерін инициализацияладық.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            parts[0] = if dec_bounds.0 <= 0 && 0 < dec_bounds.1 {
                MaybeUninit::new(Part::Copy(b"0"))
            } else {
                MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }))
            };
            // ҚАУІПСІЗДІК: біз `..1` элементтерін инициализацияладық.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            let vis_exp = exp as i32 - 1;
            let parts = if dec_bounds.0 as i32 <= vis_exp && vis_exp < dec_bounds.1 as i32 {
                digits_to_dec_str(buf, exp, 0, parts)
            } else {
                digits_to_exp_str(buf, exp, 0, upper, parts)
            };
            Formatted { sign, parts }
        }
    }
}

/// Берілген декодталған дәрежеден есептелген максималды буфер өлшемі үшін өте жуық жуықтауды (жоғарғы шек) қайтарады.
///
/// Нақты шегі:
///
/// - кезде `exp < 0`, максималды ұзындығы-`ceil(log_10 (5^-exp * (2^64 - 1)))`.
/// - кезде `exp >= 0`, максималды ұзындығы-`ceil(log_10 (2^exp * (2^64 - 1)))`.
///
/// `ceil(log_10 (x^exp * (2^64 - 1)))` `ceil(log_10 (2^64 - 1)) + ceil(exp *log_10 x)`-тен аз, бұл өз кезегінде `20 + (1 + exp* log_10 x)`-тен аз.
/// Біз `log_10 2 < 5/16` және `log_10 5 < 12/16` фактілерін қолданамыз, бұл біздің мақсатымызға жеткілікті.
///
/// Бұл бізге не үшін керек?`format_exact` функциялары соңғы цифрмен шектелмейінше, буферді толығымен толтырады, бірақ сұралған цифрлардың саны күлкілі көп болуы мүмкін (айталық, 30000 цифр).
///
/// Буфердің басым көпшілігі нөлдермен толтырылады, сондықтан біз барлық буферді алдын-ала бөлгіміз келмейді.
/// Демек, кез-келген келтірілген дәлелдер үшін
/// 8200 байт буфер `f64` үшін жеткілікті болуы керек.Мұны ең нашар жағдайдың нақты санымен салыстырыңыз: 770 байт (`exp = -1074` болғанда).
///
///
///
///
///
fn estimate_max_buf_len(exp: i16) -> usize {
    21 + ((if exp < 0 { -12 } else { 5 } * exp as i32) as usize >> 4)
}

/// Жылжымалы нүкте санын экспоненциалды формаға дәл берілген сандық мәндермен форматтар.
/// Нәтиже берілген байт буферін сызат ретінде пайдалану кезінде берілген бөліктер массивінде сақталады.
/// `upper` экспонентті префикстің жағдайын анықтау үшін қолданылады (`e` немесе `E`).
/// Көрсетілетін бірінші бөлік әрқашан `Part::Sign` болып табылады (егер ешқандай белгі көрсетілмеген болса, бос жол болуы мүмкін).
///
/// `format_exact` цифрларды қалыптастыру функциясы болуы керек.
/// Ол буфердің инициалданған бөлігін қайтаруы керек.
/// Бұл үшін сізге `strategy::grisu::format_exact` керек болар.
///
/// Егер байлық буферінің ұзындығы кемінде `ndigits` байт болуы керек, егер `ndigits` соншалықты үлкен болмаса, онда тек цифрлардың белгіленген саны ғана жазылмайды.
/// (`f64` үшін бұрылу нүктесі 800-ге жуық, сондықтан 1000 байт жеткілікті болуы керек.) `[+][1][.][2345][e][-][6]` сияқты ең нашар жағдайға байланысты кем дегенде 6 бөлік болуы керек.
///
///
///
///
///
pub fn to_exact_exp_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    ndigits: usize,
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(ndigits > 0);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // ҚАУІПСІЗДІК: біз `..1` элементтерін инициализацияладық.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // ҚАУІПСІЗДІК: біз `..1` элементтерін инициализацияладық.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if ndigits > 1 {
                // [0.][0000][e0]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(ndigits - 1));
                parts[2] = MaybeUninit::new(Part::Copy(if upper { b"E0" } else { b"e0" }));
                Formatted {
                    sign,
                    // ҚАУІПСІЗДІК: біз `..3` элементтерін инициализацияладық.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }));
                Formatted {
                    sign,
                    // ҚАУІПСІЗДІК: біз `..1` элементтерін инициализацияладық.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= ndigits || buf.len() >= maxlen);

            let trunc = if ndigits < maxlen { ndigits } else { maxlen };
            let (buf, exp) = format_exact(decoded, &mut buf[..trunc], i16::MIN);
            Formatted { sign, parts: digits_to_exp_str(buf, exp, ndigits, upper, parts) }
        }
    }
}

/// Бөлшек цифрлардың дәл берілген өзгермелі нүкте санын ондық бөлшекке келтіреді.
/// Нәтиже берілген байт буферін сызат ретінде пайдалану кезінде берілген бөліктер массивінде сақталады.
/// `upper` қазіргі уақытта пайдаланылмаған, бірақ future ақырғы емес мәндердің жағдайын өзгерту туралы шешім қабылдауға қалдырылған, яғни `inf` және `nan`.
/// Көрсетілетін бірінші бөлік әрқашан `Part::Sign` болып табылады (егер ешқандай белгі көрсетілмеген болса, бос жол болуы мүмкін).
///
/// `format_exact` цифрларды қалыптастыру функциясы болуы керек.
/// Ол буфердің инициалданған бөлігін қайтаруы керек.
/// Бұл үшін сізге `strategy::grisu::format_exact` керек болар.
///
/// Егер байтақ буфер шығысқа жеткілікті болуы керек, егер `frac_digits` соншалықты үлкен болмаса, онда цифрлардың тіркелген саны ғана жазылмайды.
/// (`f64`-тің бұрылу нүктесі 800-ге жуық, ал 1000 байт жеткілікті болуы керек.) `[+][0.][0000][2][0000]` сияқты ең нашар жағдайға байланысты кем дегенде 4 бөлік болуы керек, `frac_digits = 10`-пен бірге.
///
///
///
///
///
pub fn to_exact_fixed_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // ҚАУІПСІЗДІК: біз `..1` элементтерін инициализацияладық.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // ҚАУІПСІЗДІК: біз `..1` элементтерін инициализацияладық.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // ҚАУІПСІЗДІК: біз `..2` элементтерін инициализацияладық.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // ҚАУІПСІЗДІК: біз `..1` элементтерін инициализацияладық.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= maxlen);

            // бұл `frac_digits` күлкілі үлкен болуы мүмкін *.
            // `format_exact` бұл жағдайда цифрларды көрсетуді әлдеқайда ертерек аяқтайды, өйткені біз `maxlen`-пен қатаң шектелеміз.
            //
            let limit = if frac_digits < 0x8000 { -(frac_digits as i16) } else { i16::MIN };
            let (buf, exp) = format_exact(decoded, &mut buf[..maxlen], limit);
            if exp <= limit {
                // шектеу орындалмады, сондықтан бұл `exp` болғанына қарамастан нөлге теңелуі керек.
                // бұл шектеу тек соңғы дөңгелектенуден кейін орындалған жағдайды қамтымайды;бұл `exp = limit + 1`-пен үнемі кездесетін жағдай.
                //
                debug_assert_eq!(buf.len(), 0);
                if frac_digits > 0 {
                    // [0.][0000]
                    parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                    parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                    Formatted {
                        sign,
                        // ҚАУІПСІЗДІК: біз `..2` элементтерін инициализацияладық.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                    }
                } else {
                    parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                    Formatted {
                        sign,
                        // ҚАУІПСІЗДІК: біз `..1` элементтерін инициализацияладық.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                    }
                }
            } else {
                Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
            }
        }
    }
}