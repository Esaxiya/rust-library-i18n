//! «Жылжымалы нүкте сандарын жылдам және дәл басып шығару» 3-суретінің тікелей дерлік (бірақ сәл оңтайландырылған) Rust аудармасы [^ 1].
//!
//!
//! [^1]: Burger, RG және Dybvig, RK 1996. Жылжымалы нүктелі сандарды басып шығару
//!   тез және дәл.Белгі емес.31, 5 (1996 ж. Мамыр), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// 10 ^ (2 ^ n) арналған «Digit`s» алдын-ала есептелген массивтері
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// тек `x < 16 * scale` кезінде қолдануға болады;`scaleN` `scale.mul_small(N)` болуы керек
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Айдаһар үшін ең қысқа режим.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // форматталатын `v` саны белгілі:
    // - `mant * 2^exp`-ге тең;
    // - алдында `(mant - 2 *minus)* 2^exp` бастапқы түрінде;және
    // - содан кейін бастапқы типтегі `(mant + 2 *plus)* 2^exp`.
    //
    // `minus` және `plus` нөлге тең болмайтыны анық.(шексіздіктер үшін біз ауқымнан тыс мәндерді қолданамыз.) сонымен бірге кем дегенде бір цифр құрылады деп есептейміз, яғни `mant` нөлге тең бола алмайды.
    //
    // бұл сонымен қатар `low = (mant - minus)*2^exp` пен `high = (mant + plus)* 2^exp` арасындағы кез-келген сан дәл осы өзгермелі нүкте санына сәйкес келетіндігін білдіреді, оның шекаралары бастапқы мантисса жұп болған кезде де енгізілген (яғни, `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` бұл `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // `10^(k_0-1) < high <= 10^(k_0+1)`-ті қанағаттандыратын бастапқы кірістерден `k_0` бағалаңыз.
    // тығыз `k` қанағаттандыратын `10^(k-1) < high <= 10^k` кейінірек есептеледі.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // `{mant, plus, minus} * 2^exp`-ті бөлшек түріне түрлендіріңіз:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // `mant`-ті `10^k`-ге бөліңіз.қазір `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // `mant + plus > scale` (немесе `>=`) болған кезде түзету.
    // біз іс жүзінде `scale` модификациясын жасамаймыз, өйткені оның орнына алғашқы көбейтуді өткізіп жіберуге болады.
    // енді `scale < mant + plus <= scale * 10` және біз цифрларды шығаруға дайынбыз.
    //
    // `scale - plus < mant < scale` болғанда, `d[0]` * нөлге тең болатынын ескеріңіз.
    // бұл жағдайда дөңгелектеу шарты дереу іске қосылады (төменде `up`).
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // `scale`-ті 10-ға масштабтауға тең
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // сандық генерацияға арналған `(2, 4, 8) * scale` кэші.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // инварианттар, мұнда `d[0..n-1]`-әзірге жасалған цифрлар:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (осылайша `mant / scale < 10`), мұндағы `d[i..j]`-`d [i] * 10 ^ (ji) + ... үшін стенография.
        // + d [j-1] * 10 + d[j]`.

        // бір цифрды құру: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // бұл өзгертілген Dragon алгоритмінің жеңілдетілген сипаттамасы.
        // ыңғайлы болу үшін көптеген аралық туындылар мен толықтығы туралы дәлелдер алынып тасталады.
        //
        // өзгертілген инварианттардан бастаңыз, өйткені біз `n` жаңарттық:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // `d[0..n-1]`-бұл `low` пен `high` арасындағы ең қысқа көрініс, яғни `d[0..n-1]` келесілерді де қанағаттандырады, бірақ `d[0..n-2]` сәйкес келмейді:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (биективтілік: цифрлар `v` дейін дөңгелек);және
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (соңғы цифр дұрыс)
        //
        // екінші шарт `2 * mant <= scale` дейін жеңілдетеді.
        // `mant`, `low` және `high` бойынша инварианттарды шешу бірінші шарттың қарапайым нұсқасын береді: `-plus < mant < minus`.
        // өйткені `-plus < 0 <= mant`, бізде `mant < minus` және `2 * mant <= scale` болған кездегі ең қысқа көрініс бар.
        // (алғашқы мантисса жұп болғанда, біріншісі `mant <= minus` болады).
        //
        // екіншісі орындалмаған кезде (`2 * mant> шкаласы`), біз соңғы цифрды үлкейтуіміз керек.
        // бұл жағдайды қалпына келтіру үшін жеткілікті: біз сандық генерация `0 <= v / 10^(k-n) - d[0..n-1] < 1`-ке кепілдік беретінін білеміз.
        // бұл жағдайда бірінші шарт `-plus < mant - scale < minus` болады.
        // өйткені ұрпақтан кейінгі `mant < scale`, бізде `scale < mant + plus` бар.
        // (тағы да, бұл бастапқы мантисса жұп болған кезде `scale <= mant + plus` болады.)
        //
        // Қысқасын айтқанда:
        // - `mant < minus` (немесе `<=`) болған кезде `down` тоқтаңыз және дөңгелектеңіз (цифрларды сол күйінде сақтаңыз).
        // - `scale < mant + plus` (немесе `<=`) болғанда, `up` тоқтаңыз және дөңгелектеңіз (соңғы цифрды көбейтіңіз).
        // - әйтпесе генерациялауды жалғастырыңыз.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // бізде ең қысқа ұсыныс бар, дөңгелектеуге өтіңіз

        // инварианттарды қалпына келтіру.
        // бұл алгоритмді әрдайым тоқтатуға мәжбүр етеді: `minus` және `plus` әрқашан жоғарылайды, бірақ `mant` модулі `scale` және `scale` тіркелген.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // дөңгелектеу i) тек дөңгелектеу шарты басталған кезде болады, немесе іі) екі жағдай да басталғанда және галстуктың бұзылуы дөңгелектеуді қалайды.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // егер дөңгелектеу ұзындығын өзгертсе, дәреже көрсеткіші де өзгеруі керек.
        // бұл жағдайды орындау өте қиын сияқты (мүмкін емес), бірақ біз мұнда қауіпсіз әрі дәйекті болып отырмыз.
        //
        // ҚАУІПСІЗДІК: біз жоғарыда аталған жадты инициализацияладық.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // ҚАУІПСІЗДІК: біз жоғарыда аталған жадты инициализацияладық.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Айдаһар үшін нақты және белгіленген режимді енгізу.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // `10^(k_0-1) < v <= 10^(k_0+1)`-ті қанағаттандыратын бастапқы кірістерден `k_0` бағалаңыз.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // `mant`-ті `10^k`-ге бөліңіз.қазір `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // `mant + plus >= scale` кезінде түзету, мұнда `plus / scale = 10^-buf.len() / 2`.
    // белгіленген мөлшердегі бигнумды сақтау үшін біз `mant + floor(plus) >= scale` қолданамыз.
    // біз іс жүзінде `scale` модификациясын жасамаймыз, өйткені оның орнына алғашқы көбейтуді өткізіп жіберуге болады.
    // қайтадан ең қысқа алгоритммен `d[0]` нөлге тең болуы мүмкін, бірақ соңында дөңгелектенеді.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // `scale`-ті 10-ға масштабтауға тең
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // егер біз соңғы цифрлық шектеумен жұмыс істейтін болсақ, екі реттік дөңгелектеуді болдырмау үшін буферді нақты көрсетілгенге дейін қысқартуымыз керек.
    //
    // Біз дөңгелектеу кезінде буферді қайтадан үлкейтуіміз керек екенін ескеріңіз!
    let mut len = if k < limit {
        // ой, біз тіпті *бір* цифр шығара алмаймыз.
        // бұл, мысалы, бізде 9.5 сияқты нәрсе болған кезде және оны 10-ға дейін дөңгелектеу кезінде мүмкін болады.
        // біз бос буферді қайтарамыз, кейінірек дөңгелектеу жағдайын қоспағанда, ол `k == limit` кезінде пайда болады және дәл бір цифрды шығаруы керек.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // сандық генерацияға арналған `(2, 4, 8) * scale` кэші.
        // (бұл қымбат болуы мүмкін, сондықтан оларды буфер бос болған кезде есептемеңіз.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // келесі сандар нөлге тең, біз осында тоқтаймыз * дөңгелектеуге тырыспаңыз!қалған цифрларды толтырыңыз.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // ҚАУІПСІЗДІК: біз жоғарыда аталған жадты инициализацияладық.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // дөңгелектеу, егер келесі сандар дәл 5000 ... болса, цифрлардың ортасында тоқтасақ, алдыңғы цифрды тексеріп, жұпқа дөңгелектеуге тырысыңыз (яғни, алдыңғы цифр жұп болған кезде дөңгелектеуді болдырмаңыз).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // ҚАУІПСІЗДІК: `buf[len-1]` инициализацияланған.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // егер дөңгелектеу ұзындығын өзгертсе, дәреже көрсеткіші де өзгеруі керек.
        // бірақ бізге белгіленген цифрлар саны сұралды, сондықтан буферді өзгертпеңіз ...
        // ҚАУІПСІЗДІК: біз жоғарыда аталған жадты инициализацияладық.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... егер оның орнына бізден нақты дәлдік сұралмаса.
            // егер біз түпнұсқа буфер бос болса, қосымша цифрды тек `k == limit` (edge жағдайы) кезінде қосуға болатындығын тексеруіміз керек.
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // ҚАУІПСІЗДІК: біз жоғарыда аталған жадты инициализацияладық.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}