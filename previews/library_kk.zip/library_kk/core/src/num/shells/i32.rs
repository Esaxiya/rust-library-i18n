//! 32 биттік таңбаланған бүтін типтің тұрақтылары.
//!
//! *[See also the `i32` primitive type][i32].*
//!
//! Жаңа код байланыстырылған тұрақтыларды тікелей қарабайыр типке қолдануы керек.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i32`"
)]

int_module! { i32 }