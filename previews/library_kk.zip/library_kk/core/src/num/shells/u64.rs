//! 64 биттік белгісіз бүтін типтің тұрақтылары.
//!
//! *[See also the `u64` primitive type][u64].*
//!
//! Жаңа код байланыстырылған тұрақтыларды тікелей қарабайыр типке қолдануы керек.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u64`"
)]

int_module! { u64 }