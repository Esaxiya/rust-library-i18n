//! `Clone` trait 'тікелей көшірілмейтін' типтерге арналған.
//!
//! Rust-да кейбір қарапайым типтер "implicitly copyable" болып табылады және оларды тағайындағанда немесе аргумент ретінде бергенде қабылдағыш бастапқы мәнін орнында қалдырып көшірмесін алады.
//! Бұл типтер көшіру үшін бөлуді қажет етпейді және түпкілікті аяқтаушылары жоқ (яғни оларда меншіктелген қораптар жоқ немесе [`Drop`] қондырғысы жоқ), сондықтан компилятор оларды көшіруге арзан әрі қауіпсіз деп санайды.
//!
//! Басқа типтер үшін көшірмелер [`Clone`] trait-ті қолдану және [`clone`] әдісін қолдану арқылы нақты түрде жасалуы керек.
//!
//! [`clone`]: Clone::clone
//!
//! Негізгі пайдалану мысалы:
//!
//! ```
//! let s = String::new(); // String типі Clone-ді іске асырады
//! let copy = s.clone(); // сондықтан біз оны клондауымызға болады
//! ```
//!
//! Clone trait-ті оңай іске асыру үшін сіз `#[derive(Clone)]` қолдана аласыз.Мысал:
//!
//! ```
//! #[derive(Clone)] // біз trait клонын Morpheus struct-ке қосамыз
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // енді біз оны клондауымызға болады!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Нысанды нақты қайталау мүмкіндігіне арналған жалпы trait.
///
/// [`Copy`]-тен ерекшеленеді, бұл [`Copy`] айқын емес және өте арзан, ал `Clone` әрқашан айқын және қымбат болмауы мүмкін.
/// Осы сипаттамаларды орындау үшін Rust сізге [`Copy`]-ті қайта қосуға мүмкіндік бермейді, бірақ сіз `Clone`-ті қайта қосуға және ерікті кодты іске қосуға болады.
///
/// `Clone` [`Copy`] қарағанда жалпы болғандықтан, сіз [`Copy`] кез келген нәрсені `Clone` автоматты түрде жасай аласыз.
///
/// ## Derivable
///
/// Егер барлық өрістер `Clone` болса, бұл trait-ті `#[derive]` көмегімен пайдалануға болады.[`Clone`]-ті енгізу әр өрісте [`clone`] шақырады.
///
/// [`clone`]: Clone::clone
///
/// Жалпы құрылым үшін `#[derive]` жалпы параметрлерге байланысты `Clone` қосу арқылы шартты түрде `Clone` жүзеге асырады.
///
/// ```
/// // `derive` Оқуға арналған клонды іске асырады<T>T клон болған кезде.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## `Clone`-ті қалай қолдануға болады?
///
/// [`Copy`] типтері `Clone` маңызды емес орындалуы керек.Ресми түрде:
/// егер `T: Copy`, `x: T` және `y: &T` болса, онда `let x = y.clone();` `let x = *y;`-ге тең.
/// Қолмен жүзеге асыру осы инвариантты сақтау үшін мұқият болуы керек;дегенмен, қауіпті код жад қауіпсіздігін қамтамасыз ету үшін оған сенбеуі керек.
///
/// Мысал ретінде функция көрсеткішін ұстайтын жалпы құрылымды алуға болады.Бұл жағдайда `Clone`-ті іске асыру «туынды» бола алмайды, бірақ келесідей жүзеге асырылуы мүмкін:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Қосымша орындаушылар
///
/// [implementors listed below][impls]-тен басқа келесі типтер де `Clone`-ті жүзеге асырады:
///
/// * Функция элементтерінің түрлері (яғни әр функция үшін анықталған типтер)
/// * Функция нұсқағышының түрлері (мысалы, `fn() -> i32`)
/// * Массив типтері, барлық өлшемдер үшін, егер элемент түрі `Clone`-ті қолданса (мысалы, `[i32; 123456]`)
/// * Tuple типтері, егер әрбір компонент `Clone`-ті қолданса (мысалы, `()`, `(i32, bool)`)
/// * Жабу түрлері, егер олар қоршаған ортадан ешқандай мән алмаса немесе барлық алынған мәндер `Clone`-ті қолданса.
///   Ортақ сілтеме арқылы алынған айнымалылар әрқашан `Clone`-ті қолданады (референт болмаса да), ал өзгертілетін сілтеме арқылы алынған айнымалылар ешқашан `Clone`-ті қолданбайды.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Мәннің көшірмесін қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str Clone іске асырады
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// `source`-тен көшіру-тапсырманы орындайды.
    ///
    /// `a.clone_from(&b)` функционалдығы бойынша `a = b.clone()`-ге тең, бірақ қажет емес бөлулерді болдырмау үшін `a` ресурстарын қайта пайдалану үшін қайта анықтауға болады.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// trait `Clone` имплизиясын жасайтын макросты шығарыңыз.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): бұл құрылымдар тек#[туынды] арқылы типтің кез-келген компоненті Clone немесе Copy көшірмелерін орындайтынын растау үшін қолданылады.
//
//
// Бұл құрылымдар ешқашан пайдаланушы кодында болмауы керек.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Қарапайым типтерге арналған `Clone`-ті енгізу.
///
/// Rust-де сипатталмайтын іске асырулар `traits::SelectionContext::copy_clone_conditions()`-те `rustc_trait_selection`-де жүзеге асырылады.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Ортақ сілтемелерді клондауға болады, бірақ өзгермелі сілтемелер *мүмкін емес*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Ортақ сілтемелерді клондауға болады, бірақ өзгермелі сілтемелер *мүмкін емес*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}