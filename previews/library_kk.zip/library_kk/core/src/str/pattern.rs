//! Pattern API жолы.
//!
//! Pattern API жол арқылы іздеу кезінде әр түрлі өрнек түрлерін пайдаланудың жалпы механизмін ұсынады.
//!
//! Толығырақ ақпаратты traits [`Pattern`], [`Searcher`], [`ReverseSearcher`] және [`DoubleEndedSearcher`] қараңыз.
//!
//! Бұл API тұрақсыз болғанымен, ол [`str`] түріндегі тұрақты API арқылы көрінеді.
//!
//! # Examples
//!
//! [`Pattern`] [`&str`][`str`], [`&str`][`str`] кесінділеріне және `FnMut(char) -> bool` іске асыратын функциялар мен жабылуларға арналған тұрақты API-де [implemented][pattern-impls] болып табылады.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // char үлгісі
//! assert_eq!(s.find('n'), Some(2));
//! // сызықтар үлгісі
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // жабу үлгісі
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Жолдық өрнек.
///
/// `Pattern<'a>` іске асырылатын типті [`&'a str`][str] іздеуге арналған жол үлгісі ретінде пайдалануға болатындығын білдіреді.
///
/// Мысалы, `'a'` және `"aa"` екеуі де `"baaaab"` жолындағы `1` индексімен сәйкес келетін үлгілер.
///
/// trait өзі байланыстырылған [`Searcher`] типті құрастырушы ретінде жұмыс істейді, ол өрнектің пайда болу жолдарын нақты жолмен жасайды.
///
///
/// Үлгінің түріне байланысты [`str::find`] және [`str::contains`] сияқты әдістердің әрекеті өзгеруі мүмкін.
/// Төмендегі кестеде кейбір мінез-құлықтар сипатталған.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Бұл үлгіні іздестіруші
    type Searcher: Searcher<'a>;

    /// Іздеу үшін `self` және `haystack` байланыстырушы іздестіруді жасайды.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Үлгінің шабындықтың кез келген жеріне сәйкес келетіндігін тексереді
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Үлгінің шабындықтың алдыңғы жағынан сәйкес келетіндігін тексереді
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Үлгінің шабындықтың артқы жағында сәйкестігін тексереді
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Сәйкес келсе шабындықтың алдыңғы бөлігінен оюды алып тастайды.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // ҚАУІПСІЗДІК: `Searcher` жарамды индекстерді қайтаратыны белгілі.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Сәйкес келсе шабындықтың артындағы өрнекті алып тастайды.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // ҚАУІПСІЗДІК: `Searcher` жарамды индекстерді қайтаратыны белгілі.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// [`Searcher::next()`] немесе [`ReverseSearcher::next_back()`] қоңырауының нәтижесі.
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Үлгінің сәйкестігі `haystack[a..b]`-те табылғанын білдіреді.
    ///
    Match(usize, usize),
    /// `haystack[a..b]` үлгісінің мүмкін сәйкестігі ретінде қабылданбағанын білдіреді.
    ///
    /// Екі матч арасында бірден көп `Reject` болуы мүмкін екенін ескеріңіз, оларды біреуіне біріктірудің қажеті жоқ.
    ///
    ///
    Reject(usize, usize),
    /// Итерацияны аяқтайтын шабындықтың әр байтына барғанын білдіреді.
    ///
    Done,
}

/// Ішекті өрнекті іздеуші.
///
/// Бұл trait жолдың алдыңғы (left)-ден басталатын үлгінің сәйкес келмейтін сәйкестіктерін іздеу әдістерін ұсынады.
///
/// Оны [`Pattern`] trait байланысты `Searcher` түрлері жүзеге асырады.
///
/// trait қауіпті деп белгіленді, өйткені [`next()`][Searcher::next] әдістерімен қайтарылған индекстер шабындықта жарамды utf8 шекараларында тұруы қажет.
/// Бұл trait тұтынушыларына шабындықты жұмыс уақытын қосымша тексерусіз кесуге мүмкіндік береді.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Ізделетін негізгі жол үшін Getter
    ///
    /// Әрдайым бірдей [`&str`][str] қайтарады.
    fn haystack(&self) -> &'a str;

    /// Алдыңғыдан бастап келесі іздеу қадамын орындайды.
    ///
    /// - Егер `haystack[a..b]` үлгіге сәйкес келсе, [`Match(a, b)`][SearchStep::Match] қайтарады.
    /// - Егер `haystack[a..b]` өрнекке сәйкес келмесе, ішінара болса да, [`Reject(a, b)`][SearchStep::Reject] береді.
    /// - Егер шабындықтың әр байты бар болса, [`Done`][SearchStep::Done] қайтарады.
    ///
    /// [`Match`][SearchStep::Match] және [`Reject`][SearchStep::Reject] мәндерінің ағынында [`Done`][SearchStep::Done] дейінгі деңгейге көршілес, қабаттаспайтын, бүкіл шабындықты қамтитын және utf8 шекараларында орналасқан индекстері болады.
    ///
    ///
    /// [`Match`][SearchStep::Match] нәтижесі барлық сәйкес келетін үлгіні қамтуы керек, бірақ [`Reject`][SearchStep::Reject] нәтижелері ерікті көптеген іргелес фрагменттерге бөлінуі мүмкін.Екі диапазонның ұзындығы нөлге тең болуы мүмкін.
    ///
    /// Мысал ретінде `"aaa"` үлгісі мен `"cbaaaaab"` пішендері ағынды шығаруы мүмкін
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Келесі [`Match`][SearchStep::Match] нәтижесін табады.[`next()`][Searcher::next] қараңыз.
    ///
    /// [`next()`][Searcher::next]-тен айырмашылығы, осы және [`next_reject`][Searcher::next_reject] мәндерінің қайтарылатындығына кепілдік жоқ.
    /// Бұл `(start_match, end_match)` қайтарады, мұнда start_match-матч басталатын индекс, ал end_match-матч аяқталғаннан кейінгі индекс.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Келесі [`Reject`][SearchStep::Reject] нәтижесін табады.[`next()`][Searcher::next] және [`next_match()`][Searcher::next_match] қараңыз.
    ///
    /// [`next()`][Searcher::next]-тен айырмашылығы, осы және [`next_match`][Searcher::next_match] мәндерінің қайтарылатындығына кепілдік жоқ.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Жолдық өрнек үшін кері іздеуші.
///
/// Бұл trait жолдың артқы (right)-тен басталатын үлгінің сәйкес келмейтін сәйкестіктерін іздеу әдістерін ұсынады.
///
/// Оны [`Pattern`] trait байланысты [`Searcher`] түрлері жүзеге асырады, егер үлгі оны артқы жағынан іздеуді қолдаса.
///
///
/// Осы trait қайтарған индекс диапазондары кері бағыттағы іздеудің дәл сәйкес келуі талап етілмейді.
///
/// Осы trait қауіпті деп белгіленгендіктен, оларды trait [`Searcher`] ата-анасынан көріңіз.
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Келесі іздеу қадамын артқы жағынан бастайды.
    ///
    /// - Егер `haystack[a..b]` үлгіге сәйкес келсе, [`Match(a, b)`][SearchStep::Match] қайтарады.
    /// - Егер `haystack[a..b]` өрнекке сәйкес келмесе, ішінара болса да, [`Reject(a, b)`][SearchStep::Reject] береді.
    /// - Егер шабындықтың әр байты бар болса, [`Done`][SearchStep::Done] қайтарады
    ///
    /// [`Match`][SearchStep::Match] және [`Reject`][SearchStep::Reject] мәндерінің ағынында [`Done`][SearchStep::Done] дейінгі деңгейге көршілес, қабаттаспайтын, бүкіл шабындықты қамтитын және utf8 шекараларында орналасқан индекстері болады.
    ///
    ///
    /// [`Match`][SearchStep::Match] нәтижесі барлық сәйкес келетін үлгіні қамтуы керек, бірақ [`Reject`][SearchStep::Reject] нәтижелері ерікті көптеген іргелес фрагменттерге бөлінуі мүмкін.Екі диапазонның ұзындығы нөлге тең болуы мүмкін.
    ///
    /// Мысал ретінде `"aaa"` өрнегі мен `"cbaaaaab"` шабындық `[Reject(7, 8), Match(4, 7), Reject(1, 4) ағыны шығаруы мүмкін Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Келесі [`Match`][SearchStep::Match] нәтижесін табады.
    /// [`next_back()`][ReverseSearcher::next_back] қараңыз.
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Келесі [`Reject`][SearchStep::Reject] нәтижесін табады.
    /// [`next_back()`][ReverseSearcher::next_back] қараңыз.
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// trait маркері [`ReverseSearcher`]-ті [`DoubleEndedIterator`] іске асыру үшін қолдануға болатындығын білдіреді.
///
/// Ол үшін [`Searcher`] және [`ReverseSearcher`] мағыналары келесі шарттарды сақтауы керек:
///
/// - `next()` барлық нәтижелері кері тәртіпте `next_back()` нәтижелерімен бірдей болуы керек.
/// - `next()` және `next_back()` мәндер диапазонының екі ұшы ретінде әрекет етуі керек, яғни олар "walk past each other" бола алмайды.
///
/// # Examples
///
/// `char::Searcher` бұл `DoubleEndedSearcher`, өйткені [`char`] іздеу үшін екі жағынан бірдей әрекет ететін бір-бірден қарау қажет.
///
/// `(&str)::Searcher` бұл `DoubleEndedSearcher` емес, өйткені `"aaa"` пішеніндегі `"aa"` өрнегі оны іздеуге байланысты `"[aa]a"` немесе `"a[aa]"` сәйкес келеді.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Char үшін импл
/////////////////////////////////////////////////////////////////////////////

/// `<char as Pattern<'a>>::Searcher` үшін байланысты тип.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // қауіпсіздік инварианты: `finger`/`finger_back` жарамды utf8 байт индексі болуы керек `haystack` Бұл инвариантты *next_match және next_match_back ішінде* бұзуға болады, бірақ олар саусақпен жарамды код нүктесінің шекарасында шығу керек.
    //
    //
    /// `finger` - алға іздеудің ағымдағы байт индексі.
    /// Ол өз индексіндегі байттан бұрын бар екенін елестетіп көріңіз, яғни
    /// `haystack[finger]` алға қарай іздеу кезінде біз тілімнің алғашқы байты болып табылады
    ///
    finger: usize,
    /// `finger_back` - кері іздеудің ағымдағы байт индексі.
    /// Ол өз индексіндегі байттан кейін бар екенін елестетіп көріңіз, яғни
    /// шабындық (саусақ_қайта, 1)-біз алға қарай іздеу кезінде тексеру керек тілімнің соңғы байты (және, осылайша, next_back()) қоңырауы кезінде тексерілетін бірінші байт).
    ///
    finger_back: usize,
    /// Ізделіп жатқан кейіпкер
    needle: char,

    // қауіпсіздік инвариантты: `utf8_size` 5-тен кем болуы керек
    /// `needle` байт саны utf8 кодталған кезде алады.
    utf8_size: usize,
    /// utf8 кодталған көшірмесі `needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // ҚАУІПСІЗДІК: 1-4 `get_unchecked` қауіпсіздігіне кепілдік береді
        // 1. `self.finger` және `self.finger_back` бір кодты шекарада сақталады (бұл инвариантты)
        // 2. `self.finger >= 0` өйткені ол 0-ден басталып, тек өседі
        // 3. `self.finger < self.finger_back` өйткені әйтпесе `iter` char `SearchStep::Done` қайтарады
        // 4.
        // `self.finger` пішен аяқталғанға дейін келеді, өйткені `self.finger_back` соңында басталады және тек азаяды
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // utf-8 ретінде қайта кодтамай, ағымдағы таңбаның байт офсетін қосыңыз
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // шабындықты соңғы кейіпкер табылғаннан кейін алыңыз
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // utf8 кодталған иненің соңғы байты ҚАУІПСІЗДІК: бізде `utf8_size < 5` инварианты бар
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Жаңа саусақ-бұл біз тапқан байттың индексі және оған бір, өйткені біз кейіпкердің соңғы байтына арналғанбыз.
                //
                // Бұл бізге әрқашан UTF8 шекарасында саусақ бере бермейтінін ескеріңіз.
                // Егер біз өз кейіпкерімізді * таппасақ, онда біз 3 байтты немесе 4 байтты таңбаның соңғы емес байтына индекстелген болар едік.
                // Біз келесі жарамды байтқа өте алмаймыз, өйткені ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` тәрізді таңбалар бізге әрқашан үшінші байтты екінші байтты табуға мәжбүр етеді.
                //
                //
                // Алайда, бұл мүлдем жақсы.
                // Бізде self.finger-тің UTF8 шекарасында екендігі туралы инвариант болғанымен, бұл инвариантта бұл әдіске сенбейді (ол CharSearcher::next())-ке негізделген).
                //
                // Біз бұл әдістен тек жолдың соңына жеткенде немесе бірдеңе тапқан кезде ғана шығамыз.Біз бірдеңе тапқан кезде `finger` UTF8 шекарасына қойылады.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // ештеңе таппады, шығу
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // Search trait-ден әдепкі іске асыруды next_reject-ге жіберейік
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // ҚАУІПСІЗДІК: жоғарыдағы next() түсініктемесін қараңыз
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // utf-8 ретінде қайта кодтамай, ағымдағы таңбаның жылжуын шегеру
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // пішенге дейін жинаңыз, бірақ соңғы ізделген кейіпкерді қоспаңыз
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // utf8 кодталған иненің соңғы байты ҚАУІПСІЗДІК: бізде `utf8_size < 5` инварианты бар
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // біз self.finger есебімен өтілген кесінді іздедік, бастапқы индексті қайтару үшін self.finger қосыңыз
                //
                let index = self.finger + index;
                // memrchr біз тапқымыз келетін байттың индексін қайтарады.
                // Егер ASCII таңбасы болса, біз шынымен де жаңа саусағымыздың болуын қалайтын едік ("after" кері итерация парадигмасында табылған сипаттама).
                //
                // Мультибайттық жолдар үшін біз олардағы байттардың саны бойынша ASCII-ге қарағанда көбірек өтуіміз керек
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // табылған таңбадан бұрын саусақты жылжытыңыз (яғни, бастапқы индексінде)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Мұнда біз finger_back=index, size + 1 өлшемдерін қолдана алмаймыз.
                // Егер біз басқа өлшемді таңбаның (немесе басқа символдың орта байтының) соңғы белгілерін тапқан болсақ, саусағыңыздың артқы жағын `index` деңгейіне дейін төмендету керек.
                // Бұл `finger_back`-ті бұдан әрі шекарада болуға мүмкіндік бермейді, бірақ бұл дұрыс, өйткені біз бұл функциядан тек шекарада немесе шабындық толығымен ізделгенде ғана шығамыз.
                //
                //
                // Келесі_матчтен айырмашылығы, мұнда utf-8-те қайталанатын байттар проблемасы жоқ, өйткені біз соңғы байтты іздеп жатырмыз, ал біз кері байқаған кезде ғана соңғы байтты таба аламыз.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // ештеңе таппады, шығу
                return None;
            }
        }
    }

    // next_reject_back іздеушінің trait әдепкі іске асырылуын қолдануына рұқсат етіңіз
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Берілген [`char`]-ке тең белгілерді іздейді.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// MultiCharEq орамына арналған импл
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Ішкі байт кесіндісінің ұзындығын салыстырып, ағымдағы токтың ұзындығын табыңыз
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Ішкі байт кесіндісінің ұзындығын салыстырып, ағымдағы токтың ұзындығын табыңыз
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// &[Char] үшін импл
/////////////////////////////////////////////////////////////////////////////

// Todo: Мағынасы түсініксіз болғандықтан өзгерту/жою.

/// `<&[char] as Pattern<'a>>::Searcher` үшін байланысты тип.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Бөлшектегі [`char`]-ның кез келгеніне тең болатын белгілерді іздейді.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// F: FnMut(char)-> bool үшін импл
/////////////////////////////////////////////////////////////////////////////

/// `<F as Pattern<'a>>::Searcher` үшін байланысты тип.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Берілген предикатқа сәйкес келетін [`char`] іздейді.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// &&str
/////////////////////////////////////////////////////////////////////////////

/// `&str` импл. Делегаттары.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// &str үшін импл
/////////////////////////////////////////////////////////////////////////////

/// Бөлінбейтін ішкі жолды іздеу.
///
/// Әр таңбаның шекарасында бос матчтарды қайтару ретінде `""` үлгісін қолданады.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Үлгінің шабындықтың алдыңғы жағынан сәйкес келетіндігін тексереді.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Сәйкес келсе шабындықтың алдыңғы бөлігінен оюды алып тастайды.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // ҚАУІПСІЗДІК: префикстің бар екендігі расталды.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Үлгінің шабындықтың артқы жағында сәйкестігін тексереді.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Сәйкес келсе шабындықтың артындағы өрнекті алып тастайды.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // ҚАУІПСІЗДІК: жұрнақ жаңа ғана бар екендігі тексерілді.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Екі жақты подстринг іздеуші
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// `<&str as Pattern<'a>>::Searcher` үшін байланысты тип.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // бос ине барлық белгілерді қабылдамайды және олардың арасындағы барлық бос жолдарға сәйкес келеді
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher жарамды *Match* индексін шығарады, егер ол дұрыс сәйкестендірсе және ал шөптер мен инелер жарамды болса, онда алгоритмнен алшақтық * кез келген индекске түсуі мүмкін, бірақ біз оларды келесі таңбалар шекарасына дейін қолмен жүргіземіз. , сондықтан олар utf-8 қауіпсіз.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // келесі шекара шекарасына өту
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // компиляторды екі жағдайды бөлек мамандандыруға шақыру үшін `true` және `false` жағдайларын жазып алыңыз.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // келесі шекара шекарасына өту
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // X002 сияқты `true` және `false` жазыңыз
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Екі жақты іздеу алгоритмінің ішкі күйі.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// критикалық факторизация индексі
    crit_pos: usize,
    /// кері ине үшін факторизацияның критикалық индексі
    crit_pos_back: usize,
    period: usize,
    /// `byteset` бұл кеңейту (екі жақты алгоритмнің бөлігі емес);
    /// бұл 64 биттік "fingerprint", мұнда әрбір жиынтық бит `j` инедегі (байт&63)==j сәйкес келеді.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// индексі, біз оған сәйкес келдік
    memory: usize,
    /// инеге индекс, содан кейін біз сәйкес келдік
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Мұнда не болып жатқанын ерекше оқылатын түсініктеме Крочемор мен Риттердің "Text Algorithms", ch 13 кітабынан табуға болады.
        // "Algorithm CP" кодын бетте қараңыз.
        // 323.
        //
        // Не болып жатыр, бізде иненің критикалық факторизациясы (u, v) бар, және u&v [.. периоды] жұрнағы екенін анықтағымыз келеді.
        // Егер ол болса, біз "Algorithm CP1" қолданамыз.
        // Әйтпесе біз ине кезеңі үлкен болған кезде оңтайландырылған "Algorithm CP2" қолданамыз.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // қысқа периодты жағдай-период кері ине үшін жеке критикалық факторизацияны дәл есептеп шығарады x=u 'v' мұндағы | v '|<period(x).
            //
            // Мұны қазірдің өзінде белгілі болған кезең жеделдетеді.
            // $ X= "acba" $ сияқты жағдай кері бағытта (crit_pos=1, period=3) фактураланған болуы мүмкін екенін ескеріңіз, және шамамен кері кезеңмен (crit_pos=2, period=2).
            // Біз берілген кері факторизацияны қолданамыз, бірақ нақты кезеңді сақтаймыз.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // ұзақ мерзімді жағдай-біз нақты кезеңге жуықтаймыз және есте сақтауды қолданбаймыз.
            //
            //
            // max(|u|, |v|) + 1 шекарасы бойынша периодты жуықтаңыз.
            // Критикалық факторизация әрі қарай, әрі кері іздеу үшін тиімді.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Кезеңнің ұзақ екенін білдіретін жалған мән
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Two-Way-тің негізгі идеяларының бірі-инені екіге бөліп, (u, v) бөліп, шабындықта v-ны солдан оңға қарай сканерлеу арқылы табуға тырысамыз.
    // Егер v сәйкес болса, онда біз оны оңнан солға қарай сканерлеу арқылы сәйкестендіруге тырысамыз.
    // Сәйкес келмеген кезде біз қаншалықты секіре аламыз, барлығы (u, v) ине үшін маңызды факторизация болып табылатындығына негізделген.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` курсор ретінде `self.position` пайдаланады
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Тілімдер isize диапазонымен шектелген деп есептесек, бізде іздеу үшін орын бар екеніне көз жеткізіңіз + ине_ласт толып кете алмайды.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Біздің подстринге қатысы жоқ үлкен бөліктермен тез өткізіп жіберіңіз
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Иненің оң жақ бөлігі сәйкес келетінін тексеріңіз
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Иненің сол жақ бөлігі сәйкес келетінін тексеріңіз
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Біз сәйкестік таптық!
            let match_pos = self.position;

            // Note: сәйкес келетін сәйкестіктер болу үшін needle.len() орнына self.period қосыңыз
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // сәйкестендіру үшін needle.len(), self.period мәндеріне қойылды
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // `next()` идеяларын орындайды.
    //
    // Анықтамалар симметриялы, period(x) = period(reverse(x)) және local_period(u, v) = local_period(reverse(v), reverse(u)), егер (u, v) критикалық факторизация болса, (reverse(v), reverse(u)).
    //
    //
    // Кері жағдай үшін біз x=u 'v' (`crit_pos_back` өрісі) критикалық факторизациясын есептедік.Бізге | u | қажет<period(x) форвардтық жағдай үшін және осылайша | v '|<period(x) керісінше.
    //
    // Шөп үйіндісі арқылы кері іздеу үшін алдымен u ', сосын v' сәйкес келетін, кері ине салынған кері шөп арқылы алға қарай іздейміз.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` `self.end` курсоры ретінде пайдаланады, сондықтан `next()` және `next_back()` тәуелсіз болады.
        //
        let old_end = self.end;
        'search: loop {
            // Соңында іздейтін жеріміз бар-жоғын тексеріңіз, needle.len() орын қалмаған кезде оралады, бірақ кесінділер ұзындығының шектеулеріне байланысты ол ешқашан пішеннің ұзындығына оралмайды.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Біздің подстринге қатысы жоқ үлкен бөліктермен тез өткізіп жіберіңіз
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Иненің сол жақ бөлігі сәйкес келетінін тексеріңіз
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Иненің оң жақ бөлігі сәйкес келетінін тексеріңіз
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Біз сәйкестік таптық!
            let match_pos = self.end - needle.len();
            // Note: needle.len() орнына self.period ішкі матчтары сәйкес келеді
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // `arr` максималды жұрнағын есептеңіз.
    //
    // Максималды жұрнақ-`arr` ықтимал критикалық факторизациясы (u, v).
    //
    // Қайтарады (`i`, `p`), мұндағы `i`-v, ал `p`-v кезеңінің бастапқы индексі.
    //
    // `order_greater` лексикалық тәртіптің `<` немесе `>` екенін анықтайды.
    // Екі тапсырысты да есептеу керек-ең үлкен `i`-ге тапсырыс беру маңызды факторизация береді.
    //
    //
    // Ұзақ кезеңдер үшін нәтиже кезеңі дәл емес (ол өте қысқа).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Қағаздағы i сәйкес келеді
        let mut right = 1; // Қағаздағы j-ге сәйкес келеді
        let mut offset = 0; // Қағаздағы k-ға сәйкес келеді, бірақ 0-ден басталады
        // 0-ге негізделген индекстеуді сәйкестендіру үшін.
        let mut period = 1; // Қағаздағы p-ге сәйкес келеді

        while let Some(&a) = arr.get(right + offset) {
            // `left` `right` болған кезде кіріс болады.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Суффикс кішірек, период-бұл барлық префикс.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Ағымдағы кезеңді қайталау арқылы алға жылжу.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Суффикс үлкенірек, қазіргі орналасқан жерінен қайта бастаңыз.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // `arr` кері санының максималды жұрнағын есептеңіз.
    //
    // Максималды жұрнақ-бұл `arr` ықтимал критикалық факторизациясы (u ', v').
    //
    // `i` қайтарады, мұндағы `i`-артқы жағынан v 'бастапқы индексі;
    // `known_period` кезеңіне жеткен кезде дереу оралады.
    //
    // `order_greater` лексикалық тәртіптің `<` немесе `>` екенін анықтайды.
    // Екі тапсырысты да есептеу керек-ең үлкен `i`-ге тапсырыс беру маңызды факторизация береді.
    //
    //
    // Ұзақ кезеңдер үшін нәтиже кезеңі дәл емес (ол өте қысқа).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Қағаздағы i сәйкес келеді
        let mut right = 1; // Қағаздағы j-ге сәйкес келеді
        let mut offset = 0; // Қағаздағы k-ға сәйкес келеді, бірақ 0-ден басталады
        // 0-ге негізделген индекстеуді сәйкестендіру үшін.
        let mut period = 1; // Қағаздағы p-ге сәйкес келеді
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Суффикс кішірек, период-бұл барлық префикс.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Ағымдағы кезеңді қайталау арқылы алға жылжу.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Суффикс үлкенірек, қазіргі орналасқан жерінен қайта бастаңыз.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy алгоритмге сәйкес келмейтін материалдарды мүмкіндігінше тез өткізіп жіберуге немесе ол бас тартуды салыстырмалы түрде тез шығаратын режимде жұмыс істеуге мүмкіндік береді.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Аралықтарды мүмкіндігінше тез сәйкестендіріп жіберіңіз
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Жіберу үнемі бас тартады
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}