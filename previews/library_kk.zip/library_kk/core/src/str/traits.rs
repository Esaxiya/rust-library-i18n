//! `str` үшін Trait енгізілімдері.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Жіптерге тапсырыс беруді жүзеге асырады.
///
/// Жолдар байт мәндері бойынша [lexicographically](Ord#lexicographical-comparison) реттелген.
/// Бұл код кестелеріндегі позициялар негізінде Unicode кодына тапсырыс береді.
/// Бұл міндетті түрде тілге және тілге байланысты өзгеретін "alphabetical" тапсырысымен бірдей емес.
/// Мәдени тұрғыдан қабылданған стандарттарға сәйкес жолдарды сұрыптау үшін `str` типіне жатпайтын жергілікті арнайы деректер қажет.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Жолдарға салыстыру операцияларын орындайды.
///
/// Жолдар [lexicographically](Ord#lexicographical-comparison) байт мәндерімен салыстырылады.
/// Бұл код кестелеріндегі позициялар негізінде Unicode кодтық нүктелерін салыстырады.
/// Бұл міндетті түрде тілге және тілге байланысты өзгеретін "alphabetical" тапсырысымен бірдей емес.
/// Мәдени тұрғыдан қабылданған стандарттарға сәйкес жолдарды салыстыру үшін `str` типіне жатпайтын жергілікті арнайы деректер қажет.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// `&self[..]` немесе `&mut self[..]` синтаксисімен ішкі жолдарды кесуді жүзеге асырады.
///
/// Барлық жолдың кесіндісін қайтарады, яғни `&self` немесе `&mut self` мәндерін қайтарады.«&Self»-ге тең [0 ..
/// len] `немесе`&mut mut [0 ..
/// len]`.
/// Басқа индекстеу операцияларынан айырмашылығы, бұл ешқашан panic болмайды.
///
/// Бұл операция *O*(1).
///
/// 1.20.0-ге дейін бұл индекстеу операциялары `Index` және `IndexMut` тікелей іске асырылуымен қолдау тапты.
///
/// `&self[0 .. len]` немесе `&mut self[0 .. len]`-ге тең.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// `&self[begin .. end]` немесе `&mut self[begin .. end]` синтаксисімен ішкі жолдарды кесуді жүзеге асырады.
///
/// Берілген жолдың кесіндісін байт ауқымынан қайтарады [`begin`, `end`).
///
/// Бұл операция *O*(1).
///
/// 1.20.0-ге дейін бұл индекстеу операциялары `Index` және `IndexMut` тікелей іске асырылуымен қолдау тапты.
///
/// # Panics
///
/// Егер Panics, егер `begin` немесе `end` таңбаның бастапқы байт ығысуын көрсетпесе (`is_char_boundary` анықтағандай), егер `begin > end` болса немесе `end > len` болса.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // бұлар panic болады:
/// // 2-байт `ö` ішінде:
/// // &s [2 ..3];
///
/// // 8 байт `老`&s шегінде жатыр [1 ..
/// // 8];
///
/// // байт 100 жолдың сыртында&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // ҚАУІПСІЗДІК: `start` және `end`-дің шекара шекарасында тұрғанын тексеріп,
            // және біз қауіпсіз сілтеме арқылы өтіп жатырмыз, сондықтан қайтарылатын мән де бір болады.
            // Біз сондай-ақ жарықтық шекараларын тексердік, сондықтан бұл UTF-8 жарамды.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // ҚАУІПСІЗДІК: жай `start` және `end` сызықтарының шекарасында тұрғанын тексеріңіз.
            // Біз көрсеткіштің ерекше екенін білеміз, өйткені біз оны `slice`-тен алдық.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // ҚАУІПСІЗДІК: қоңырау шалушы `self` `slice` шекарасында екеніне кепілдік береді
        // бұл `add` үшін барлық шарттарды қанағаттандырады.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // ҚАУІПСІЗДІК: `get_unchecked` үшін түсініктемелерді қараңыз.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary индекстің [0, .len()] деңгейінде екенін тексереді, себебі `get`-ті NLL ақаулығына байланысты қайта қолдана алмайды.
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // ҚАУІПСІЗДІК: `start` және `end`-дің шекара шекарасында тұрғанын тексеріп,
            // және біз қауіпсіз сілтеме арқылы өтіп жатырмыз, сондықтан қайтарылатын мән де бір болады.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// `&self[.. end]` немесе `&mut self[.. end]` синтаксисімен ішкі жолдарды кесуді жүзеге асырады.
///
/// Берілген жолдың кесіндісін байт ауқымынан қайтарады [`0`, `end`).
/// `&self[0 .. end]` немесе `&mut self[0 .. end]`-ге тең.
///
/// Бұл операция *O*(1).
///
/// 1.20.0-ге дейін бұл индекстеу операциялары `Index` және `IndexMut` тікелей іске асырылуымен қолдау тапты.
///
/// # Panics
///
/// Panics, егер `end` таңбаның бастапқы байт ығысуын көрсетпесе (`is_char_boundary` анықталғандай) немесе егер `end > len` болса.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // ҚАУІПСІЗДІК: `end`-тің шекарада тұрғанын тексеріп,
            // және біз қауіпсіз сілтеме арқылы өтіп жатырмыз, сондықтан қайтарылатын мән де бір болады.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // ҚАУІПСІЗДІК: `end`-тің шекарада тұрғанын тексеріп,
            // және біз қауіпсіз сілтеме арқылы өтіп жатырмыз, сондықтан қайтарылатын мән де бір болады.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // ҚАУІПСІЗДІК: `end`-тің шекарада тұрғанын тексеріп,
            // және біз қауіпсіз сілтеме арқылы өтіп жатырмыз, сондықтан қайтарылатын мән де бір болады.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// `&self[begin ..]` немесе `&mut self[begin ..]` синтаксисімен ішкі жолдарды кесуді жүзеге асырады.
///
/// Берілген жолдың кесіндісін байт ауқымынан қайтарады [`begin`, `len`).«&Self»-ке тең [бастау ..
/// len] `немесе`&mut mut [бастау ..
/// len]`.
///
/// Бұл операция *O*(1).
///
/// 1.20.0-ге дейін бұл индекстеу операциялары `Index` және `IndexMut` тікелей іске асырылуымен қолдау тапты.
///
/// # Panics
///
/// Panics, егер `begin` таңбаның бастапқы байт ығысуын көрсетпесе (`is_char_boundary` анықталғандай) немесе егер `begin > len` болса.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // ҚАУІПСІЗДІК: `start`-тің шекарада тұрғанын тексеріп,
            // және біз қауіпсіз сілтеме арқылы өтіп жатырмыз, сондықтан қайтарылатын мән де бір болады.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // ҚАУІПСІЗДІК: `start`-тің шекарада тұрғанын тексеріп,
            // және біз қауіпсіз сілтеме арқылы өтіп жатырмыз, сондықтан қайтарылатын мән де бір болады.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // ҚАУІПСІЗДІК: қоңырау шалушы `self` `slice` шекарасында екеніне кепілдік береді
        // бұл `add` үшін барлық шарттарды қанағаттандырады.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // ҚАУІПСІЗДІК: `get_unchecked`-ке ұқсас.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // ҚАУІПСІЗДІК: `start`-тің шекарада тұрғанын тексеріп,
            // және біз қауіпсіз сілтеме арқылы өтіп жатырмыз, сондықтан қайтарылатын мән де бір болады.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// `&self[begin ..= end]` немесе `&mut self[begin ..= end]` синтаксисімен ішкі жолдарды кесуді жүзеге асырады.
///
/// Берілген жолдың тілімін [`begin`, `end`] байт ауқымынан қайтарады.`&self [begin .. end + 1]` немесе `&mut self[begin .. end + 1]`-ге тең, егер `end` `usize` үшін максималды мәнге ие болмаса.
///
/// Бұл операция *O*(1).
///
/// # Panics
///
/// Panics, егер `begin` таңбаның бастапқы байт ығысуын көрсетпесе (`is_char_boundary` анықталғандай), егер `end` таңбаның байттың ығысуын көрсетпесе (`end + 1` не бастапқы байттың ығысуы немесе `len`-ге тең), егер `begin > end` немесе егер `end >= len` болса.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // ҚАУІПСІЗДІК: қоңырау шалушы `get_unchecked` қауіпсіздік шартын сақтауы керек.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // ҚАУІПСІЗДІК: қоңырау шалушы `get_unchecked_mut` қауіпсіздік шартын сақтауы керек.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// `&self[..= end]` немесе `&mut self[..= end]` синтаксисімен ішкі жолдарды кесуді жүзеге асырады.
///
/// Берілген жолдың кесіндісін [0, `end`] байт ауқымынан қайтарады.
/// `&self [0 .. end + 1]`-ге тең, егер `end` `usize` үшін максималды мәнге ие болмаса.
///
/// Бұл операция *O*(1).
///
/// # Panics
///
/// Егер Panics, егер `end` таңбаның байттың ығысуын көрсетпесе (`end + 1` немесе `is_char_boundary` анықтаған бастапқы байттың ығысуы немесе `len`-ге тең) немесе `end >= len` болса.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // ҚАУІПСІЗДІК: қоңырау шалушы `get_unchecked` қауіпсіздік шартын сақтауы керек.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // ҚАУІПСІЗДІК: қоңырау шалушы `get_unchecked_mut` қауіпсіздік шартын сақтауы керек.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Жолдан мәнді талдау
///
/// `FromStr`-дің [`from_str`] әдісі көбінесе [[str`] [`parse`] әдісі арқылы жасырын қолданылады.
/// Мысалдар үшін [«талдау»] құжаттамасын қараңыз.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` өмірлік параметрі жоқ, сондықтан сіз өмір бойы параметрі жоқ типтерді ғана талдай аласыз.
///
/// Басқаша айтқанда, сіз `i32`-ті `FromStr`-пен талдауға болады, бірақ `&i32` емес.
/// Құрамында `i32` бар құрылымды талдауға болады, бірақ құрамында `&i32` жоқ.
///
/// # Examples
///
/// `FromStr`-ті `Point` үлгісінде негіздеу:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Байланыстырылған қате, оны талдаудан қайтаруға болады.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Осы түрдегі мәнді қайтару үшін `s` жолын ажыратады.
    ///
    /// Егер талдау сәтті болса, [`Ok`] ішіндегі мәнді қайтарыңыз, әйтпесе жол дұрыс форматталмаған кезде ішкі [`Err`] үшін қате қайтарылады.
    /// Қате түрі trait қолдану үшін тән.
    ///
    /// # Examples
    ///
    /// `FromStr` іске асыратын [`i32`] бар негізгі пайдалану:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// `bool` жолынан талдаңыз.
    ///
    /// `Result<bool, ParseBoolError>` береді, өйткені `s` талдануы мүмкін немесе болмауы мүмкін.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Көбінесе, `str`-те `.parse()` әдісі дұрысырақ болатындығын ескеріңіз.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}