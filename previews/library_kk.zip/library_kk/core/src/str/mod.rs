//! Жолдарды манипуляциялау.
//!
//! Толығырақ ақпаратты [`std::str`] модулінен қараңыз.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. шекарадан тыс
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. begin <=end
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. таңба шекарасы
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // кейіпкерді табыңыз
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` len және char шекарасынан аз болуы керек
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// `self` ұзындығын қайтарады.
    ///
    /// Бұл ұзындық [`char`] s немесе графемада емес, байтта.
    /// Басқаша айтқанда, бұл адам жіптің ұзындығын есептейтін нәрсе болмауы мүмкін.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // әдемі f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// `true` қайтарады, егер `self` нөлдік байт болса.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// `Индекс`-байт UTF-8 кодтық нүкте ретіндегі бірінші байт немесе жолдың соңы екенін тексереді.
    ///
    ///
    /// Жолдың басы мен соңы (`индекс== self.len()`) шекара болып саналғанда.
    ///
    /// Егер `index` `self.len()`-тен үлкен болса, `false` қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // `老` басталуы
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // екінші байт `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // `老` үшінші байты
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 және len әрқашан жақсы.
        // Чекті оңай оңтайландыратындай етіп, бұл жағдайда оқудың жолдық деректерін өткізіп жібере алатындай етіп 0-ге нақты түрде тексеріңіз.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Бұл сиқырлы эквивалент: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Жол кесіндісін байт тіліміне түрлендіреді.
    /// Байт кесіндісін жолдық тілімге қайта айналдыру үшін [`from_utf8`] функциясын қолданыңыз.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // ҚАУІПСІЗДІК: const дыбысы, өйткені біз екі типті бірдей орналасумен ауыстырамыз
        unsafe { mem::transmute(self) }
    }

    /// Өзгеретін жол кесіндісін өзгертілетін байт тіліміне түрлендіреді.
    ///
    /// # Safety
    ///
    /// Қоңырау шалушы қарыздың аяқталуына және оның негізінде `str` қолданылғанға дейін тілімнің мазмұны UTF-8 жарамды екендігіне көз жеткізуі керек.
    ///
    ///
    /// Мазмұны UTF-8 жарамсыз `str` пайдалану-бұл анықталмаған тәртіп.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // ҚАУІПСІЗДІК: `&str`-тен `&[u8]`-қа дейінгі құрам `str`-тен бастап қауіпсіз
        // `&[u8]` сияқты орналасуы бар (тек libstd бұл кепілдікке ие бола алады).
        // Меңзерді ажырату қауіпсіз, өйткені ол өзгертілетін сілтемелерден тұрады, олар жазбалар үшін жарамды болады.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Жол кесіндісін шикі көрсеткішке түрлендіреді.
    ///
    /// Жолдық тілімдер байттың кесіндісі болғандықтан, шикі көрсеткіш [`u8`]-ге нұсқайды.
    /// Бұл меңзер жол кесіндісінің бірінші байтын көрсетеді.
    ///
    /// Қоңырау шалушы қайтарылған көрсеткіштің ешқашан жазылмайтындығына көз жеткізуі керек.
    /// Егер сізге жол кесіндісінің мазмұнын өзгерту керек болса, [`as_mut_ptr`] пайдаланыңыз.
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Өзгеретін жол кесіндісін шикі көрсеткішке түрлендіреді.
    ///
    /// Жолдық тілімдер байттың кесіндісі болғандықтан, шикі көрсеткіш [`u8`]-ге нұсқайды.
    /// Бұл меңзер жол кесіндісінің бірінші байтын көрсетеді.
    ///
    /// Жолдық кесінді тек UTF-8 күйінде қалатындай етіп өзгертілгеніне көз жеткізу сіздің міндетіңіз.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// `str` субстилиясын қайтарады.
    ///
    /// Бұл `str` индекстеудің дүрбелең емес баламасы.
    /// Эквивалентті индекстеу әрекеті panic болған кезде [`None`] мәнін қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // UTF-8 реттілігінің шекарасында емес индекстер
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // шекарадан тыс
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// `str` өзгермелі субсликасын қайтарады.
    ///
    /// Бұл `str` индекстеудің дүрбелең емес баламасы.
    /// Эквивалентті индекстеу әрекеті panic болған кезде [`None`] мәнін қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // дұрыс ұзындық
    /// assert!(v.get_mut(0..5).is_some());
    /// // шекарадан тыс
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// `str` тексерілмеген субсликасын қайтарады.
    ///
    /// Бұл `str` индекстеудің тексерілмеген баламасы.
    ///
    /// # Safety
    ///
    /// Осы функцияның қоңырау шалушылары келесі алғышарттардың орындалуына жауапты:
    ///
    /// * Бастапқы индекс соңғы индекстен аспауы керек;
    /// * Индекстер түпнұсқа кесінді шеңберінде болуы керек;
    /// * Индекстер UTF-8 реттілік шекарасында орналасуы керек.
    ///
    /// Бұл орындалмаса, қайтарылған жол кесіндісі жарамсыз жадқа сілтеме жасай алады немесе `str` типімен байланысқан инварианттарды бұзуы мүмкін.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // ҚАУІПСІЗДІК: қоңырау шалушы `get_unchecked` қауіпсіздік шартын сақтауы керек;
        // кесінді анықталмайды, өйткені `self` қауіпсіз сілтеме болып табылады.
        // Қайтарылған сілтеме қауіпсіз, себебі `SliceIndex` имплдары бұған кепілдік беруі керек.
        unsafe { &*i.get_unchecked(self) }
    }

    /// `str` өзгертілетін, тексерілмеген субсликасын қайтарады.
    ///
    /// Бұл `str` индекстеудің тексерілмеген баламасы.
    ///
    /// # Safety
    ///
    /// Осы функцияның қоңырау шалушылары келесі алғышарттардың орындалуына жауапты:
    ///
    /// * Бастапқы индекс соңғы индекстен аспауы керек;
    /// * Индекстер түпнұсқа кесінді шеңберінде болуы керек;
    /// * Индекстер UTF-8 реттілік шекарасында орналасуы керек.
    ///
    /// Бұл орындалмаса, қайтарылған жол кесіндісі жарамсыз жадқа сілтеме жасай алады немесе `str` типімен байланысқан инварианттарды бұзуы мүмкін.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // ҚАУІПСІЗДІК: қоңырау шалушы `get_unchecked_mut` қауіпсіздік шартын сақтауы керек;
        // кесінді анықталмайды, өйткені `self` қауіпсіз сілтеме болып табылады.
        // Қайтарылған сілтеме қауіпсіз, себебі `SliceIndex` имплдары бұған кепілдік беруі керек.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Қауіпсіздік тексерістерін айналып өтіп, басқа жол кесіндісінен жол кесіндісін жасайды.
    ///
    /// Әдетте бұл ұсынылмайды, оны сақтықпен қолданыңыз!Қауіпсіз баламаны [`str`] және [`Index`] қараңыз.
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Бұл жаңа тілім `begin`-тен `end`-ге дейін, соның ішінде `begin`, бірақ `end` қоспағанда.
    ///
    /// Оның орнына өзгертілетін жол кесіндісін алу үшін [`slice_mut_unchecked`] әдісін қараңыз.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Осы функцияның қоңырау шалушылары үш алғышарттың орындалуы үшін жауап береді:
    ///
    /// * `begin` `end` аспауы керек.
    /// * `begin` және `end` жол кесіндісінде байт позициялары болуы керек.
    /// * `begin` және `end` UTF-8 реттілік шекарасында орналасуы керек.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // ҚАУІПСІЗДІК: қоңырау шалушы `get_unchecked` қауіпсіздік шартын сақтауы керек;
        // кесінді анықталмайды, өйткені `self` қауіпсіз сілтеме болып табылады.
        // Қайтарылған сілтеме қауіпсіз, себебі `SliceIndex` имплдары бұған кепілдік беруі керек.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Қауіпсіздік тексерістерін айналып өтіп, басқа жол кесіндісінен жол кесіндісін жасайды.
    /// Әдетте бұл ұсынылмайды, оны сақтықпен қолданыңыз!Қауіпсіз баламаны [`str`] және [`IndexMut`] қараңыз.
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Бұл жаңа тілім `begin`-тен `end`-ге дейін, соның ішінде `begin`, бірақ `end` қоспағанда.
    ///
    /// Оның орнына өзгермейтін жол кесіндісін алу үшін [`slice_unchecked`] әдісін қараңыз.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Осы функцияның қоңырау шалушылары үш алғышарттың орындалуы үшін жауап береді:
    ///
    /// * `begin` `end` аспауы керек.
    /// * `begin` және `end` жол кесіндісінде байт позициялары болуы керек.
    /// * `begin` және `end` UTF-8 реттілік шекарасында орналасуы керек.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // ҚАУІПСІЗДІК: қоңырау шалушы `get_unchecked_mut` қауіпсіздік шартын сақтауы керек;
        // кесінді анықталмайды, өйткені `self` қауіпсіз сілтеме болып табылады.
        // Қайтарылған сілтеме қауіпсіз, себебі `SliceIndex` имплдары бұған кепілдік беруі керек.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Бір жол кесіндісін индекс бойынша екіге бөліңіз.
    ///
    /// `mid` аргументі жолдың басынан бастап байттың орнын толтыруы керек.
    /// Ол сонымен қатар UTF-8 кодтық нүктесінің шекарасында болуы керек.
    ///
    /// Қайтарылған екі тілім жолдық тілімнің басынан бастап `mid`-ге, ал `mid`-тен жолдық тілімнің соңына дейін созылады.
    ///
    /// Оның орнына өзгертілетін жол кесектерін алу үшін [`split_at_mut`] әдісін қараңыз.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics, егер `mid` UTF-8 код нүктесінің шекарасында болмаса немесе ол жол кесіндісінің соңғы кодтық нүктесінің соңынан өткен болса.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_шекаралық индекстің [0, .len()]
        if self.is_char_boundary(mid) {
            // ҚАУІПСІЗДІК: `mid`-тің шекарада екенін тексеріңіз.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Бір өзгеретін жол кесіндісін индекс бойынша екіге бөліңіз.
    ///
    /// `mid` аргументі жолдың басынан бастап байттың орнын толтыруы керек.
    /// Ол сонымен қатар UTF-8 кодтық нүктесінің шекарасында болуы керек.
    ///
    /// Қайтарылған екі тілім жолдық тілімнің басынан бастап `mid`-ге, ал `mid`-тен жолдық тілімнің соңына дейін созылады.
    ///
    /// Оның орнына өзгермейтін жол тілімдерін алу үшін [`split_at`] әдісін қараңыз.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics, егер `mid` UTF-8 код нүктесінің шекарасында болмаса немесе ол жол кесіндісінің соңғы кодтық нүктесінің соңынан өткен болса.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_шекаралық индекстің [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // ҚАУІПСІЗДІК: `mid`-тің шекарада екенін тексеріңіз.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Жолдың кесіндісіндегі [`char`] s бойынша қайталаушыны қайтарады.
    ///
    /// Жолдық тілім жарамды UTF-8-тен тұратындықтан, біз [`char`] жолдық кесінді арқылы қайталай аламыз.
    /// Бұл әдіс осындай итераторды қайтарады.
    ///
    /// [`char`] Unicode скалярлық мәнін білдіретінін және сіздің 'character' деген не екендігіңізге сәйкес келмеуі мүмкін екенін есте ұстаған жөн.
    ///
    /// Графикалық кластерлер бойынша қайталау сіз қалаған нәрсе болуы мүмкін.
    /// Бұл функцияны Rust стандартты кітапханасы қамтамасыз етпейді, оның орнына crates.io тексеріңіз.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Есіңізде болсын, ['char`] таңбалар туралы түйсігіңізге сәйкес келмеуі мүмкін:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // 'y̆' емес
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Итераторды жол кесіндісінің [`char`] s және олардың позицияларына қайтарады.
    ///
    /// Жолдық тілім жарамды UTF-8-тен тұратындықтан, біз [`char`] жолдық кесінді арқылы қайталай аламыз.
    /// Бұл әдіс итераторды қайтарады [char '], сондай-ақ олардың байт позициялары.
    ///
    /// Итератор кортеждерді береді.Позиция бірінші, [`char`] екінші.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Есіңізде болсын, ['char`] таңбалар туралы түйсігіңізге сәйкес келмеуі мүмкін:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // емес (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // Мұндағы 3-ке назар аударыңыз, соңғы таңба екі байтты қабылдады
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Жолдық кесінді байттарының үстінен қайталағыш.
    ///
    /// Жолдық кесінді байт тізбегінен тұратын болғандықтан, жолдық тілім арқылы байт бойынша қайталай аламыз.
    /// Бұл әдіс осындай итераторды қайтарады.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Бос кеңістік арқылы жіп кесіндісін бөледі.
    ///
    /// Қайтарылған итератор бос жолдың кез-келген бос кеңістігімен бөлінген жол тілімдерін қайтарады.
    ///
    ///
    /// 'Whitespace' Unicode derived Core property `White_Space` шарттарына сәйкес анықталады.
    /// Егер сіз оның орнына тек ASCII бос кеңістігінде бөлгіңіз келсе, [`split_ascii_whitespace`] пайдаланыңыз.
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Бос кеңістіктің барлық түрлері қарастырылады:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Жолдық кесінді ASCII бос кеңістігі бойынша бөледі.
    ///
    /// Қайтарылған итератор ASCII бос кеңістігінің кез келген мөлшерімен бөлінген бастапқы жол кесіндісінің ішкі тілімдері болып табылатын жол кесінділерін қайтарады.
    ///
    ///
    /// Unicode `Whitespace` орнына бөлу үшін [`split_whitespace`] пайдаланыңыз.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// ASCII бос кеңістігінің барлық түрлері қарастырылады:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Жолдың кесіндісі сияқты жолдың үстінен қайталағыш.
    ///
    /// Сызықтар (`\n`) жаңа жолымен немесе (`\r\n`) желілік берілісімен кареткалардың қайтуымен аяқталады.
    ///
    /// Соңғы жолдың соңы міндетті емес.
    /// Соңғы жолдың аяқталуымен аяқталатын жол, ақырғы жолдың аяқталуынсыз, әйтпесе бірдей жолмен бірдей жолдарды қайтарады.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Соңғы жолдың аяқталуы қажет емес:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Жолдың үстінен қайталағыш.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// UTF-16 ретінде кодталған жолға `u16` итераторын қайтарады.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Егер берілген өрнек осы жол кесіндісінің ішкі тілімімен сәйкес келсе, `true` мәнін қайтарады.
    ///
    /// Егер ол болмаса, `false` қайтарады.
    ///
    /// [pattern] `&str`, [`char`], [`char`] s кесіндісі немесе таңба сәйкес келетіндігін анықтайтын функция немесе жабылу болуы мүмкін.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Егер берілген үлгі осы жол кесіндісінің префиксімен сәйкес келсе, `true` мәнін қайтарады.
    ///
    /// Егер ол болмаса, `false` қайтарады.
    ///
    /// [pattern] `&str`, [`char`], [`char`] s кесіндісі немесе таңба сәйкес келетіндігін анықтайтын функция немесе жабылу болуы мүмкін.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Егер берілген үлгі осы жол кесіндісінің суффиксімен сәйкес келсе, `true` мәнін қайтарады.
    ///
    /// Егер ол болмаса, `false` қайтарады.
    ///
    /// [pattern] `&str`, [`char`], [`char`] s кесіндісі немесе таңба сәйкес келетіндігін анықтайтын функция немесе жабылу болуы мүмкін.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Үлгіге сәйкес келетін осы жол кесіндісінің бірінші таңбасының байт индексін қайтарады.
    ///
    /// Егер үлгі сәйкес келмесе, [`None`] мәнін қайтарады.
    ///
    /// [pattern] `&str`, [`char`], [`char`] s кесіндісі немесе таңба сәйкес келетіндігін анықтайтын функция немесе жабылу болуы мүмкін.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Қарапайым өрнектер:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Нүктесіз стильді және жабылуды қолданатын күрделі өрнектер:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Үлгіні таппау:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Осы жол кесіндісіндегі үлгінің бірінші оң жақ сәйкестігінің байт индексін қайтарады.
    ///
    /// Егер үлгі сәйкес келмесе, [`None`] мәнін қайтарады.
    ///
    /// [pattern] `&str`, [`char`], [`char`] s кесіндісі немесе таңба сәйкес келетіндігін анықтайтын функция немесе жабылу болуы мүмкін.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Қарапайым өрнектер:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Жабылатын күрделі үлгілер:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Үлгіні таппау:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Осы жол кесіндісінің ішкі жолдарының үстінен итератор, өрнекпен сәйкес келетін таңбалармен бөлінген.
    ///
    /// [pattern] `&str`, [`char`], [`char`] s кесіндісі немесе таңба сәйкес келетіндігін анықтайтын функция немесе жабылу болуы мүмкін.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Итератордың әрекеті
    ///
    /// Қайтарылған итератор [`DoubleEndedIterator`] болады, егер өрнек кері іздеуге мүмкіндік берсе және forward/reverse іздеу бірдей элементтерді берсе.
    /// Бұл, мысалы, [`char`] үшін дұрыс, бірақ `&str` үшін емес.
    ///
    /// Егер үлгі кері іздеуге мүмкіндік берсе, бірақ оның нәтижелері алға қарай іздеуден өзгеше болуы мүмкін болса, [`rsplit`] әдісін қолдануға болады.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Қарапайым өрнектер:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Егер өрнек сызықшалар болса, онда кез-келген кейіпкердің пайда болуына бөліңіз:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Жабуды қолдана отырып, неғұрлым күрделі үлгі:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Егер жолда бірнеше іргелес сепараторлар болса, онда сіз шығуда бос жолдармен аяқталасыз:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Іргелес сепараторлар бос жолмен бөлінеді.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Жолдың басындағы немесе соңындағы бөлгіштер бос жолдармен көрші болады.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Бос жолды сепаратор ретінде қолданған кезде, ол жолдағы барлық символдарды жолдың басымен және соңымен бірге бөледі.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Бос кеңістік сепаратор ретінде пайдаланылған кезде, іргелес сепараторлар таңқаларлық әрекетке әкелуі мүмкін.Бұл код дұрыс:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Бұл _not_ сізге береді:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Бұл әрекет үшін [`split_whitespace`] пайдаланыңыз.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Осы жол кесіндісінің ішкі жолдарының үстінен итератор, өрнекпен сәйкес келетін таңбалармен бөлінген.
    /// `split` шығарған итератордан ерекшеленеді, сол кезде `split_inclusive` сәйкес келетін бөлікті субстриннің аяқтаушысы ретінде қалдырады.
    ///
    ///
    /// [pattern] `&str`, [`char`], [`char`] s кесіндісі немесе таңба сәйкес келетіндігін анықтайтын функция немесе жабылу болуы мүмкін.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Егер жолдың соңғы элементі сәйкес келсе, онда бұл элемент алдыңғы ішкі жолдың аяқтаушысы болып саналады.
    /// Бұл ішкі жол итератор қайтарған соңғы элемент болады.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Берілген жол кесіндісінің астарларының үстінен итератор, өрнекпен сәйкестендірілген және кері тәртіпте берілген таңбалармен бөлінген.
    ///
    /// [pattern] `&str`, [`char`], [`char`] s кесіндісі немесе таңба сәйкес келетіндігін анықтайтын функция немесе жабылу болуы мүмкін.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Итератордың әрекеті
    ///
    /// Қайтарылған итератор өрнектің кері іздеуді қолдайтынын талап етеді, егер forward/reverse іздеуі бірдей элементтерге ие болса, ол [`DoubleEndedIterator`] болады.
    ///
    ///
    /// Алдыңғы жағынан қайталау үшін [`split`] әдісін қолдануға болады.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Қарапайым өрнектер:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Жабуды қолдана отырып, неғұрлым күрделі үлгі:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Берілген жол кесіндісінің астындағы жолдар бойынша, өрнекпен сәйкес келетін таңбалармен бөлінген итератор.
    ///
    /// [pattern] `&str`, [`char`], [`char`] s кесіндісі немесе таңба сәйкес келетіндігін анықтайтын функция немесе жабылу болуы мүмкін.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`]-ге тең, тек бос жолдар бос болса, өткізіп жіберіледі.
    ///
    /// [`split`]: str::split
    ///
    /// Бұл әдісті үлгі бойынша _separated_ емес, _terminated_ болатын жолдық деректер үшін пайдалануға болады.
    ///
    /// # Итератордың әрекеті
    ///
    /// Қайтарылған итератор [`DoubleEndedIterator`] болады, егер өрнек кері іздеуге мүмкіндік берсе және forward/reverse іздеу бірдей элементтерді берсе.
    /// Бұл, мысалы, [`char`] үшін дұрыс, бірақ `&str` үшін емес.
    ///
    /// Егер үлгі кері іздеуге мүмкіндік берсе, бірақ оның нәтижелері алға қарай іздеуден өзгеше болуы мүмкін болса, [`rsplit_terminator`] әдісін қолдануға болады.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Үлгі бойынша сәйкес келетін және кері тәртіпте берілген таңбалармен бөлінген `self` ішкі тізбектерінің үстіндегі итератор.
    ///
    /// [pattern] `&str`, [`char`], [`char`] s кесіндісі немесе таңба сәйкес келетіндігін анықтайтын функция немесе жабылу болуы мүмкін.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`]-ге тең, тек бос жолдар бос болса, өткізіп жіберіледі.
    ///
    /// [`split`]: str::split
    ///
    /// Бұл әдісті үлгі бойынша _separated_ емес, _terminated_ болатын жолдық деректер үшін пайдалануға болады.
    ///
    /// # Итератордың әрекеті
    ///
    /// Қайтарылған итератор өрнектің кері іздеуді қолдайтындығын талап етеді, егер forward/reverse іздеуі бірдей элементтерге ие болса, ол екі еселенеді.
    ///
    ///
    /// Алдыңғы жағынан қайталау үшін [`split_terminator`] әдісін қолдануға болады.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Берілген жол кесіндісінің жолдарымен, өрнекпен бөлінген, ең көбі `n` элементтерін қайтарумен шектелетін итератор.
    ///
    /// Егер `n` ішкі жолдары қайтарылса, онда соңғы ішкі жолда (`n`-ші жол) жолдың қалдығы болады.
    ///
    /// [pattern] `&str`, [`char`], [`char`] s кесіндісі немесе таңба сәйкес келетіндігін анықтайтын функция немесе жабылу болуы мүмкін.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Итератордың әрекеті
    ///
    /// Қайтарылған итератор екі мәрте аяқталмайды, өйткені оны қолдау тиімді емес.
    ///
    /// Егер өрнек кері іздеуге мүмкіндік берсе, [`rsplitn`] әдісін қолдануға болады.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Қарапайым өрнектер:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Жабуды қолдана отырып, неғұрлым күрделі үлгі:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Бұл жол кесіндісінің жолдарының үстінен итератор, жолдың соңынан бастап, өрнекпен бөлінген, ең көбі `n` элементтерін қайтарумен шектеледі.
    ///
    ///
    /// Егер `n` ішкі жолдары қайтарылса, онда соңғы ішкі жолда (`n`-ші жол) жолдың қалдығы болады.
    ///
    /// [pattern] `&str`, [`char`], [`char`] s кесіндісі немесе таңба сәйкес келетіндігін анықтайтын функция немесе жабылу болуы мүмкін.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Итератордың әрекеті
    ///
    /// Қайтарылған итератор екі мәрте аяқталмайды, өйткені оны қолдау тиімді емес.
    ///
    /// Алдыңғы жағынан бөлу үшін [`splitn`] әдісін қолдануға болады.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Қарапайым өрнектер:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Жабуды қолдана отырып, неғұрлым күрделі үлгі:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Көрсетілген бөлгіштің бірінші пайда болуында жолды бөліп, префиксті бөлгішке дейін және бөлгіштен кейін жұрнақты қайтарады.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Жолды көрсетілген бөлгіштің соңғы пайда болуы бойынша бөліп, префиксті бөлгішке дейін және бөлгіштен кейін жұрнақты қайтарады.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Берілген жол кесіндісіндегі үлгінің сәйкес келмейтін сәйкестіктерінің үстінен итератор.
    ///
    /// [pattern] `&str`, [`char`], [`char`] s кесіндісі немесе таңба сәйкес келетіндігін анықтайтын функция немесе жабылу болуы мүмкін.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Итератордың әрекеті
    ///
    /// Қайтарылған итератор [`DoubleEndedIterator`] болады, егер өрнек кері іздеуге мүмкіндік берсе және forward/reverse іздеу бірдей элементтерді берсе.
    /// Бұл, мысалы, [`char`] үшін дұрыс, бірақ `&str` үшін емес.
    ///
    /// Егер үлгі кері іздеуге мүмкіндік берсе, бірақ оның нәтижелері алға қарай іздеуден өзгеше болуы мүмкін болса, [`rmatches`] әдісін қолдануға болады.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Осы жол кесіндісіндегі үлгінің сәйкес емес матчтарының үстінен итератор кері тәртіппен шығарылды.
    ///
    /// [pattern] `&str`, [`char`], [`char`] s кесіндісі немесе таңба сәйкес келетіндігін анықтайтын функция немесе жабылу болуы мүмкін.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Итератордың әрекеті
    ///
    /// Қайтарылған итератор өрнектің кері іздеуді қолдайтынын талап етеді, егер forward/reverse іздеуі бірдей элементтерге ие болса, ол [`DoubleEndedIterator`] болады.
    ///
    ///
    /// Алдыңғы жағынан қайталау үшін [`matches`] әдісін қолдануға болады.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Осы жол кесіндісіндегі үлгінің сәйкес емес сәйкестіктерін, сондай-ақ матч басталатын индексті итератор.
    ///
    /// Х01Х шеңберіндегі `pat` матчтары үшін сәйкес келетін тек бірінші матчқа сәйкес келетін индекстер қайтарылады.
    ///
    /// [pattern] `&str`, [`char`], [`char`] s кесіндісі немесе таңба сәйкес келетіндігін анықтайтын функция немесе жабылу болуы мүмкін.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Итератордың әрекеті
    ///
    /// Қайтарылған итератор [`DoubleEndedIterator`] болады, егер өрнек кері іздеуге мүмкіндік берсе және forward/reverse іздеу бірдей элементтерді берсе.
    /// Бұл, мысалы, [`char`] үшін дұрыс, бірақ `&str` үшін емес.
    ///
    /// Егер үлгі кері іздеуге мүмкіндік берсе, бірақ оның нәтижелері алға қарай іздеуден өзгеше болуы мүмкін болса, [`rmatch_indices`] әдісін қолдануға болады.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // тек алғашқы `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// `self` ішіндегі үлгінің сәйкес келмеген матчтарын итератор матч индексімен бірге кері тәртіпте берді.
    ///
    /// Х01Х шеңберіндегі `pat` матчтары үшін тек соңғы матчқа сәйкес келетін индекстер қайтарылады.
    ///
    /// [pattern] `&str`, [`char`], [`char`] s кесіндісі немесе таңба сәйкес келетіндігін анықтайтын функция немесе жабылу болуы мүмкін.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Итератордың әрекеті
    ///
    /// Қайтарылған итератор өрнектің кері іздеуді қолдайтынын талап етеді, егер forward/reverse іздеуі бірдей элементтерге ие болса, ол [`DoubleEndedIterator`] болады.
    ///
    ///
    /// Алдыңғы жағынан қайталау үшін [`match_indices`] әдісін қолдануға болады.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // тек соңғы `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Бос кеңістікті алып тастаған және жолдың кесіндісін қайтарады.
    ///
    /// 'Whitespace' Unicode derived Core property `White_Space` шарттарына сәйкес анықталады.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Бос кеңістікті алып тастаған жол кесіндісін қайтарады.
    ///
    /// 'Whitespace' Unicode derived Core property `White_Space` шарттарына сәйкес анықталады.
    ///
    /// # Мәтіннің бағыттылығы
    ///
    /// Жол дегеніміз байт тізбегі.
    /// `start` бұл контекстте сол байт жолының бірінші орнын білдіреді;ағылшын немесе орыс сияқты солдан оңға қарай сол жақта, ал араб немесе иврит сияқты оңнан солға тілдер үшін бұл оң жақта болады.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Бос орын жойылған жол кесіндісін қайтарады.
    ///
    /// 'Whitespace' Unicode derived Core property `White_Space` шарттарына сәйкес анықталады.
    ///
    /// # Мәтіннің бағыттылығы
    ///
    /// Жол дегеніміз байт тізбегі.
    /// `end` бұл контекстте сол байт жолының соңғы позициясы;ағылшын немесе орыс тілдері үшін солдан оңға қарай оң жағы, ал араб немесе иврит сияқты оңнан солға тілдер үшін сол жағы болады.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Бос кеңістікті алып тастаған жол кесіндісін қайтарады.
    ///
    /// 'Whitespace' Unicode derived Core property `White_Space` шарттарына сәйкес анықталады.
    ///
    /// # Мәтіннің бағыттылығы
    ///
    /// Жол дегеніміз байт тізбегі.
    /// 'Left' бұл контекстте сол байт жолының бірінші орнын білдіреді;«солдан оңға» емес, «оңнан солға» араб немесе иврит тілдері үшін бұл _right_ жағы болады, сол жақ емес.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Бос орын жойылған жол кесіндісін қайтарады.
    ///
    /// 'Whitespace' Unicode derived Core property `White_Space` шарттарына сәйкес анықталады.
    ///
    /// # Мәтіннің бағыттылығы
    ///
    /// Жол дегеніміз байт тізбегі.
    /// 'Right' бұл контекстте сол байт жолының соңғы позициясы;«солдан оңға» емес, «оңнан солға» араб немесе иврит тілдері үшін бұл _left_ жағы болады, оң емес.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Бірнеше рет жойылған үлгіге сәйкес келетін барлық префикстері мен жұрнақтары бар жол кесіндісін қайтарады.
    ///
    /// [pattern] [`char`], [`char`] s кесіндісі немесе таңба сәйкес келетіндігін анықтайтын функция немесе жабылу болуы мүмкін.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Қарапайым өрнектер:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Жабуды қолдана отырып, неғұрлым күрделі үлгі:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Ертедегі матчты есіңізде сақтаңыз, егер төменде түзетіңіз
            // соңғы матч басқаша
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // ҚАУІПСІЗДІК: `Searcher` жарамды индекстерді қайтаратыны белгілі.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Бірнеше рет жойылған үлгіге сәйкес келетін барлық префикстері бар жол кесіндісін қайтарады.
    ///
    /// [pattern] `&str`, [`char`], [`char`] s кесіндісі немесе таңба сәйкес келетіндігін анықтайтын функция немесе жабылу болуы мүмкін.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Мәтіннің бағыттылығы
    ///
    /// Жол дегеніміз байт тізбегі.
    /// `start` бұл контекстте сол байт жолының бірінші орнын білдіреді;ағылшын немесе орыс сияқты солдан оңға қарай сол жақта, ал араб немесе иврит сияқты оңнан солға тілдер үшін бұл оң жақта болады.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // ҚАУІПСІЗДІК: `Searcher` жарамды индекстерді қайтаратыны белгілі.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Префиксі жойылған жол кесіндісін қайтарады.
    ///
    /// Егер жол `prefix` өрнегінен басталса, `Some` оралған ішкі жолды префикстен кейін қайтарады.
    /// `trim_start_matches`-тен айырмашылығы, бұл әдіс префиксті тура бір рет алып тастайды.
    ///
    /// Егер жол `prefix`-тен басталмаса, `None` мәнін қайтарады.
    ///
    /// [pattern] `&str`, [`char`], [`char`] s кесіндісі немесе таңба сәйкес келетіндігін анықтайтын функция немесе жабылу болуы мүмкін.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Қосымшасы жойылған жол кесіндісін қайтарады.
    ///
    /// Егер жол `suffix` өрнегімен аяқталса, ішкі жолды `Some` оралған жұрнақтың алдында қайтарады.
    /// `trim_end_matches`-тен айырмашылығы, бұл әдіс жұрнақты дәл бір рет алып тастайды.
    ///
    /// Егер жол `suffix`-мен аяқталмаса, `None` мәнін қайтарады.
    ///
    /// [pattern] `&str`, [`char`], [`char`] s кесіндісі немесе таңба сәйкес келетіндігін анықтайтын функция немесе жабылу болуы мүмкін.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Бірнеше рет жойылған үлгіге сәйкес келетін барлық жұрнақтары бар жол кесіндісін қайтарады.
    ///
    /// [pattern] `&str`, [`char`], [`char`] s кесіндісі немесе таңба сәйкес келетіндігін анықтайтын функция немесе жабылу болуы мүмкін.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Мәтіннің бағыттылығы
    ///
    /// Жол дегеніміз байт тізбегі.
    /// `end` бұл контекстте сол байт жолының соңғы позициясы;ағылшын немесе орыс тілдері үшін солдан оңға қарай оң жағы, ал араб немесе иврит сияқты оңнан солға тілдер үшін сол жағы болады.
    ///
    ///
    /// # Examples
    ///
    /// Қарапайым өрнектер:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Жабуды қолдана отырып, неғұрлым күрделі үлгі:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // ҚАУІПСІЗДІК: `Searcher` жарамды индекстерді қайтаратыны белгілі.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Бірнеше рет жойылған үлгіге сәйкес келетін барлық префикстері бар жол кесіндісін қайтарады.
    ///
    /// [pattern] `&str`, [`char`], [`char`] s кесіндісі немесе таңба сәйкес келетіндігін анықтайтын функция немесе жабылу болуы мүмкін.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Мәтіннің бағыттылығы
    ///
    /// Жол дегеніміз байт тізбегі.
    /// 'Left' бұл контекстте сол байт жолының бірінші орнын білдіреді;«солдан оңға» емес, «оңнан солға» араб немесе иврит тілдері үшін бұл _right_ жағы болады, сол жақ емес.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Бірнеше рет жойылған үлгіге сәйкес келетін барлық жұрнақтары бар жол кесіндісін қайтарады.
    ///
    /// [pattern] `&str`, [`char`], [`char`] s кесіндісі немесе таңба сәйкес келетіндігін анықтайтын функция немесе жабылу болуы мүмкін.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Мәтіннің бағыттылығы
    ///
    /// Жол дегеніміз байт тізбегі.
    /// 'Right' бұл контекстте сол байт жолының соңғы позициясы;«солдан оңға» емес, «оңнан солға» араб немесе иврит тілдері үшін бұл _left_ жағы болады, оң емес.
    ///
    ///
    /// # Examples
    ///
    /// Қарапайым өрнектер:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Жабуды қолдана отырып, неғұрлым күрделі үлгі:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Бұл жол кесіндісін басқа түрге бөледі.
    ///
    /// `parse` өте жалпы болғандықтан, типті шығаруда қиындықтар тудыруы мүмкін.
    /// Осылайша, `parse`-сіз 'turbofish' деп аталатын синтаксисті көретін бірнеше уақыттың бірі: `::<>`.
    ///
    /// Бұл қорытынды алгоритміне қай типті талдағыңыз келетінін нақты түсінуге көмектеседі.
    ///
    /// `parse` [`FromStr`] trait-ді іске асыратын кез-келген түрге талдау жасай алады.
    ///

    /// # Errors
    ///
    /// Егер бұл жол кесіндісін қажетті түрге бөлу мүмкін болмаса, [`Err`] қайтарады.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// `four` түсіндірмесінің орнына 'turbofish' пайдалану:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Талданбады:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Осы жолдағы барлық таңбалардың ASCII ауқымында екендігін тексереді.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Біз мұнда әр байтты таңба ретінде қарастыра аламыз: барлық көп байт таңбалары ascii ауқымында емес байттан басталады, сондықтан біз онымен тоқтаймыз.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Екі жолдың ASCII регистрге сәйкес келмейтін сәйкестігін тексереді.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)`-мен бірдей, бірақ уақытша материалдарды бөлмей және көшірмей.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Бұл жолды орнына ASCII бас әріптің эквивалентіне айналдырады.
    ///
    /// 'a'-тен 'z'-ке дейінгі ASCII әріптері 'A'-тен 'Z'-ге дейін салыстырылады, бірақ ASCII емес әріптер өзгермейді.
    ///
    /// Бұрыннан өзгермеген жаңа жоғарғы мәнді қайтару үшін [`to_ascii_uppercase()`] пайдаланыңыз.
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // ҚАУІПСІЗДІК: қауіпсіз, өйткені біз екі түрді бірдей орналасумен ауыстырамыз.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Бұл жолды орнына орнына кіші ASCII кіші әріпіне түрлендіреді.
    ///
    /// 'A'-тен 'Z'-ке дейінгі ASCII әріптері 'a'-тен 'z'-ге дейін салыстырылады, бірақ ASCII емес әріптер өзгермейді.
    ///
    /// Бұрыннан өзгермеген жаңа кіші мәнді қайтару үшін [`to_ascii_lowercase()`] пайдаланыңыз.
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // ҚАУІПСІЗДІК: қауіпсіз, өйткені біз екі түрді бірдей орналасумен ауыстырамыз.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// `self`-те [`char::escape_debug`]-мен бірге жүретін итераторды қайтарыңыз.
    ///
    ///
    /// Note: тек жолды бастайтын кеңейтілген графикалық кодтық нүктелерден қашып кетеді.
    ///
    /// # Examples
    ///
    /// Итератор ретінде:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!`-ті тікелей пайдалану:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Екеуі тең:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// `to_string` пайдалану:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// `self`-те [`char::escape_default`]-мен бірге жүретін итераторды қайтарыңыз.
    ///
    ///
    /// # Examples
    ///
    /// Итератор ретінде:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!`-ті тікелей пайдалану:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Екеуі тең:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// `to_string` пайдалану:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// `self`-те [`char::escape_unicode`]-мен бірге жүретін итераторды қайтарыңыз.
    ///
    ///
    /// # Examples
    ///
    /// Итератор ретінде:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!`-ті тікелей пайдалану:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Екеуі тең:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// `to_string` пайдалану:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Бос стр жасайды
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Бос өзгермелі str жасайды
    #[inline]
    fn default() -> Self {
        // ҚАУІПСІЗДІК: бос жол жарамды UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Белгілі, клонды фн түрі
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // ҚАУІПСІЗДІК: қауіпсіз емес
        unsafe { from_utf8_unchecked(bytes) }
    };
}