#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Компилятордың кіріктірілген типтерінің орналасуына арналған құрылымдық анықтамалардан тұрады.
//!
//! Оларды шикі ұсыныстарды тікелей манипуляциялау үшін қауіпті кодтағы трансмуттардың мақсаты ретінде пайдалануға болады.
//!
//!
//! Олардың анықтамасы әрқашан `rustc_middle::ty::layout` анықталған ABI-ге сәйкес келуі керек.
//!

/// `&dyn SomeTrait` сияқты trait нысанын ұсыну.
///
/// Бұл құрылым `&dyn SomeTrait` және `Box<dyn AnotherTrait>` сияқты типтерге ие.
///
/// `TraitObject` макеттерге сәйкес келетініне кепілдік берілген, бірақ бұл trait нысандарының түрі емес (мысалы, өрістерге `&dyn SomeTrait`-те тікелей қол жетімді емес) және ол орналасуды басқармайды (анықтаманы өзгерту `&dyn SomeTrait` орналасуын өзгертпейді).
///
/// Ол тек төменгі деңгейдегі бөлшектермен жұмыс жасауды қажет ететін қауіпті кодпен пайдалануға арналған.
///
/// Барлық trait нысандарына жалпы сілтеме жасау мүмкіндігі жоқ, сондықтан бұл типтің мәндерін құрудың жалғыз жолы-[`std::mem::transmute`][transmute] сияқты функциялар.
/// Сол сияқты, `TraitObject` мәнінен шын trait нысанын құрудың жалғыз жолы-`transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Сәйкес келмеген типтермен trait нысанын синтездеу-бұл vtable деректер көрсеткіші көрсететін мәннің түріне сәйкес келмейтін-анықталмаған тәртіпке әкелуі мүмкін.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // мысалы trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // компилятор trait объектісін жасасын
/// let object: &dyn Foo = &value;
///
/// // шикі өкілдікке қараңыз
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // деректер көрсеткіші-бұл `value` адресі
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // `i32` vtable-ді `object`-тен абайлаңыз, басқа `i32` нұсқайтын жаңа нысан салу
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // ол біз `other_value`-тен тікелей trait нысанын салғандай жұмыс істеуі керек
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}