//! Композициялық сыртқы итерация.
//!
//! Егер сіз өзіңізді қандай да бір коллекциямен тапсаңыз және аталған коллекция элементтеріне операция жасау қажет болса, сіз тез арада 'iterators'-ке жүгінесіз.
//! Итерматикалық Rust кодында итераторлар көп қолданылады, сондықтан олармен танысқан жөн.
//!
//! Толығырақ түсіндірмес бұрын, осы модульдің құрылымы туралы сөйлесейік:
//!
//! # Organization
//!
//! Бұл модуль көбіне типтер бойынша ұйымдастырылған:
//!
//! * [Traits] негізгі бөлігі: бұл traits итераторлардың қандай түрін және олармен не істеуге болатындығын анықтайды.Осы traits әдістері қосымша оқуға уақыт бөлуге тұрарлық.
//! * [Functions] кейбір негізгі итераторларды құрудың пайдалы әдістерін ұсыныңыз.
//! * [Structs] көбінесе осы модульдің traits-дегі әртүрлі әдістердің қайтару түрлері болып табылады.Әдетте сіз `struct` емес, `struct` жасайтын әдісті қарастырғыңыз келеді.
//! Неліктен туралы толығырақ ақпаратты '[Іске асыратын итератор](#іске асырушы-итератор)' бөлімінен қараңыз.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Міне бітті!Итераторларды қарастырайық.
//!
//! # Iterator
//!
//! Бұл модульдің жүрегі мен жаны-[`Iterator`] trait.[`Iterator`] ядросы келесідей:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Итераторда [`next`] әдісі бар, ол шақырылған кезде [`Опция`] 'қайтарады<Item>«.
//! [`next`] элементтер болғанша [`Some(Item)`] қайтарады және олардың бәрі таусылып болғаннан кейін, қайталану аяқталғанын білдіретін `None` қайтарады.
//! Жеке итераторлар қайталануды жалғастыруды таңдауы мүмкін, сондықтан [`next`]-ге қайта қоңырау шалу қайтадан [`Some(Item)`]-ті қайтара бастайды немесе бастай алмайды (мысалы, [`TryIter`] қараңыз).
//!
//!
//! [«Итератордың» толық анықтамасына бірқатар басқа әдістер де кіреді, бірақ олар [`next`] үстіне салынған әдепкі әдістер, сондықтан сіз оларды ақысыз аласыз.
//!
//! Итераторлар да композитор болып табылады және өңдеудің күрделі түрлерін жасау үшін оларды тізбектеу әдеттегідей.Толығырақ ақпаратты төмендегі [Adapters](#adapters) бөлімінен қараңыз.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Итерацияның үш формасы
//!
//! Топтамадан итераторларды құруға болатын үш жалпы әдіс бар:
//!
//! * `iter()`, ол `&T` үстінен қайталанады.
//! * `iter_mut()`, ол `&mut T` үстінен қайталанады.
//! * `into_iter()`, ол `T` үстінен қайталанады.
//!
//! Стандартты кітапханадағы әртүрлі заттар қажет болған жағдайда үшеуінің біреуін немесе бірнешеуін орындай алады.
//!
//! # Итераторды енгізу
//!
//! Өзіңіздің итераторыңызды құру екі кезеңнен тұрады: итератор күйін ұстап тұру үшін `struct` құру, содан кейін сол `struct` үшін [`Iterator`] енгізу.
//! Сондықтан осы модульде құрылымдардың саны өте көп: әр итератор мен итератор адаптеріне арналған біреу.
//!
//! `1`-тен `5`-ге дейін есептелетін `Counter` итераторын жасайық:
//!
//! ```
//! // Біріншіден, құрылым:
//!
//! /// Бірден беске дейін есептелетін итератор
//! struct Counter {
//!     count: usize,
//! }
//!
//! // біз санымыздың бірден басталғанын қалаймыз, сондықтан көмек ретінде new() әдісін қосайық.
//! // Бұл өте қажет емес, бірақ ыңғайлы.
//! // `count`-ті нөлден бастайтынымызды ескеріңіз, неге `next()`'s іске асырылуында төменде қарастырамыз.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Содан кейін біз `Counter` үшін `Iterator` енгіземіз:
//!
//! impl Iterator for Counter {
//!     // біз usize-мен есептейтін боламыз
//!     type Item = usize;
//!
//!     // next() жалғыз қажетті әдіс
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Біздің санымызды көбейтіңіз.Сондықтан біз нөлден бастадық.
//!         self.count += 1;
//!
//!         // Санай біткенімізді немесе аяқтамағанымызды тексеріңіз.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Енді біз оны қолдана аламыз!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! [`next`]-ге осылай қоңырау шалу қайталана береді.Rust сіздің итераторыңызда [`next`] қоңырау шала алатын құрылымға ие, ол `None` жеткенше.Келесіге өтейік.
//!
//! Сондай-ақ, `Iterator` `next` ішіне қоңырау шалатын `nth` және `fold` сияқты әдістердің әдепкі орындалуын қамтамасыз ететіндігін ескеріңіз.
//! Сонымен қатар, `nth` және `fold` сияқты әдістердің тапсырыс бойынша орындалуын жазуға болады, егер итератор оларды `next` қоңырауынсыз тиімді есептей алса.
//!
//! # `for` циклдар және `IntoIterator`
//!
//! Rust-тің `for` цикл синтаксисі-бұл итераторларға арналған қант.Мұнда `for` негізгі мысалы:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Бұл сандарды бір-беске дейін, әрқайсысы өз жолында басып шығарады.Бірақ сіз мұнда бірдеңе байқайсыз: біз ешқашан vector-де итератор жасау үшін ештеңе шақырған емеспіз.Не береді?
//!
//! Стандартты кітапханада затты итераторға айналдыруға арналған trait бар: [`IntoIterator`].
//! Бұл trait-те [`into_iter`] әдісі бар, ол [`IntoIterator`]-ті итераторға айналдырады.
//! Сол `for` циклін қайтадан қарастырайық және оны компилятор не түрлендіреді:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust мұны қантсыздандырады:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Біріншіден, біз мәнге `into_iter()` деп атаймыз.Содан кейін, біз X002 көрінгенше, [`next`]-ге қайта-қайта қоңырау шалып, қайтарылатын итераторға сәйкес келеміз.
//! Сол кезде біз `break` циклынан шығып, қайталауды аяқтадық.
//!
//! Мұнда тағы бір жіңішке бит бар: стандартты кітапханада [`IntoIterator`]-тің қызықты орындалуы бар:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Басқаша айтқанда, барлық [«Итераторлар» [`IntoIterator`]-ті өздерін қайтару арқылы жүзеге асырады.Бұл екі нәрсені білдіреді:
//!
//! 1. Егер сіз [`Iterator`] жазып жатсаңыз, оны `for` циклімен пайдалануға болады.
//! 2. Егер сіз коллекцияны құрып жатсаңыз, оған [`IntoIterator`] қолдану сіздің коллекцияңызды `for` циклімен пайдалануға мүмкіндік береді.
//!
//! # Анықтама арқылы қайталау
//!
//! [`into_iter()`] мәні бойынша `self` қабылдайтын болғандықтан, `for` циклын коллекция бойынша қайталау үшін сол коллекцияны тұтынады.Жиі коллекцияны тұтынбай-ақ қайталанғыңыз келуі мүмкін.
//! Көптеген коллекцияларда шартты түрде `iter()` және `iter_mut()` деп аталатын сілтемелер бойынша итераторларды ұсынатын әдістер ұсынылған:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` әлі де осы функцияға тиесілі.
//! ```
//!
//! Егер `C` типті коллекция `iter()`-ті қамтамасыз етсе, онда ол `&C` үшін `IntoIterator`-ті жүзеге асырады, тек `iter()` деп атайды.
//! Сол сияқты, `iter_mut()`-ті ұсынатын `C` жиынтығы, `&mut C` үшін `IntoIterator`-ті `iter_mut()`-ге беру арқылы жүзеге асырады.Бұл ыңғайлы стенографияны ұсынады:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // `values.iter_mut()` сияқты
//!     *x += 1;
//! }
//! for x in &values { // `values.iter()` сияқты
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Көптеген коллекциялар `iter()` ұсынады, бірақ барлығы `iter_mut()` ұсынады.
//! Мысалы, [`HashSet<T>`] немесе [`HashMap<K, V>`] кілттерінің мутациясы, егер кілттер өзгерген болса, коллекцияны сәйкес емес күйге келтіруі мүмкін, сондықтан бұл коллекциялар тек `iter()` ұсынады.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! [`Iterator`] қабылдайтын және тағы бір [`Iterator`] қайтаратын функциялар көбінесе 'адаптердің адаптері' деп аталады, өйткені олар 'адаптердің формасы
//! pattern'.
//!
//! Жалпы итератор адаптеріне [`map`], [`take`] және [`filter`] жатады.
//! Толығырақ олардың құжаттарын қараңыз.
//!
//! Егер итератор адаптері panics болса, итератор анықталмаған (бірақ жадында қауіпсіз) күйде болады.
//! Бұл күйге Rust нұсқаларында бірдей болуға кепілдік берілмейді, сондықтан сіз дүрбелеңге түскен итератордың қайтарған дәл мәндеріне сенуден аулақ болуыңыз керек.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Итераторлар (және [adapters](#adapters)) итераторы *жалқау*. Бұл дегеніміз, тек итераторды құру _do_ көп емес. [`next`]-ге қоңырау шалғанға дейін ештеңе болмайды.
//! Итераторды тек оның жанама әсерлері үшін жасаған кезде кейде бұл шатасудың көзі болып табылады.
//! Мысалы, [`map`] әдісі қайталанатын әрбір элементтің жабылуын шақырады:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Бұл ешқандай мәндерді басып шығармайды, өйткені біз оны қолданудың орнына тек итераторды құрдық.Компилятор бізге мұндай мінез-құлық туралы ескертеді:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! [`map`]-ті оның жағымсыз әсерлері үшін жазудың идиомалық тәсілі-`for` циклін қолдану немесе [`for_each`] әдісін шақыру:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Итераторды бағалаудың тағы бір кең тараған тәсілі-жаңа жинақ шығару үшін [`collect`] әдісін қолдану.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Итераторлар шектеулі болуы шарт емес.Мысал ретінде, ашық диапазон-шексіз қайталаушы:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Шексіз қайталаушыны ақырғыға айналдыру үшін [`take`] итератор адаптерін қолдану әдеттегідей:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Бұл `0` пен `4` сандарын әрқайсысы өз жолында басып шығарады.
//!
//! Есіңізде болсын, шексіз итераторлардағы әдістер, тіпті нәтижені соңғы уақытта математикалық жолмен анықтауға болатын әдістер де тоқтатылмауы мүмкін.
//! Нақтырақ айтқанда, жалпы жағдайда итератордағы барлық элементтерден өтуді қажет ететін [`min`] сияқты әдістер кез-келген шексіз итераторлар үшін сәтті оралмауы мүмкін.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // О жоқ!Шексіз цикл!
//! // `ones.min()` шексіз цикл тудырады, сондықтан біз бұл нүктеге жете алмаймыз!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;