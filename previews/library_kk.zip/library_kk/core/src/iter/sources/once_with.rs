use crate::iter::{FusedIterator, TrustedLen};

/// Берілген жабылуға шақыру арқылы мәнді дәл бір рет жалқау шығаратын итератор жасайды.
///
/// Бұл әдетте бір мәнді генераторды [`chain()`] итерацияның басқа түрлеріне бейімдеу үшін қолданылады.
/// Мүмкін сізде барлығын қамтитын итератор бар шығар, бірақ сізге қосымша ерекше жағдай қажет.
/// Мүмкін сізде итераторларда жұмыс істейтін функция бар шығар, бірақ сізге тек бір мәнді өңдеу керек.
///
/// [`once()`]-тен айырмашылығы, бұл функция сұраныс бойынша жалқау мән тудырады.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Негізгі пайдалану:
///
/// ```
/// use std::iter;
///
/// // бірі-ең жалғыз нөмір
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // біреуі ғана, біз бұған қол жеткіземіз
/// assert_eq!(None, one.next());
/// ```
///
/// Басқа итератормен бірге тізбек құру.
/// Айталық, біз `.foo` каталогының әр файлы бойынша, сонымен қатар конфигурация файлы бойынша қайталауды қалаймыз,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // біз DirEntry-s итераторынан PathBufs итераторына айналуымыз керек, сондықтан картаны қолданамыз
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // енді біздің итератор тек конфигурация файлына арналған
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // екі итераторды бір үлкен итераторға біріктіріңіз
/// let files = dirs.chain(config);
///
/// // бұл бізге .foo және .foorc файлдарының барлығын береді
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Берілген `F: FnOnce() -> A` жабылуын қолдану арқылы `A` типті жалғыз элементті шығаратын итератор.
///
///
/// Бұл `struct` [`once_with()`] функциясы арқылы жасалған.
/// Толығырақ оның құжаттамасын қараңыз.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}