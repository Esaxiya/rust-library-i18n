use crate::fmt;

/// Әр қайталану қамтамасыз етілген `F: FnMut() -> Option<T>` жабылуын шақыратын жаңа итератор жасайды.
///
/// Бұл арнайы типті құрудың синтаксисін қолданбай және ол үшін [`Iterator`] trait-ді қолданбай, кез-келген мінез-құлықпен реттелетін итератор құруға мүмкіндік береді.
///
/// `FromFn` итераторы жабудың әрекеті туралы болжам жасамайтындығын ескеріңіз, сондықтан [`FusedIterator`]-ті консервативті түрде қолданбайды немесе [`Iterator::size_hint()`]-ті өзінің әдепкі `(0, None)` мәнінен шығарып тастайды.
///
///
/// Жабу күйді қайталау бойынша бақылау үшін түсірілімдер мен қоршаған ортаны қолдана алады.Итератордың қолданылуына байланысты, бұл жабу кезінде [`move`] кілт сөзін көрсетуді талап етуі мүмкін.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Келіңіздер, [module-level documentation] есептегіш итераторын қайтадан енгізейік:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Біздің санымызды көбейтіңіз.Сондықтан біз нөлден бастадық.
///     count += 1;
///
///     // Санай біткенімізді немесе аяқтамағанымызды тексеріңіз.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Әр қайталану `F: FnMut() -> Option<T>` жабылуын шақыратын итератор.
///
/// Бұл `struct` [`iter::from_fn()`] функциясы арқылы жасалған.
/// Толығырақ оның құжаттамасын қараңыз.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}