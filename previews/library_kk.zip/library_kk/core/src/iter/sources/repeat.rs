use crate::iter::{FusedIterator, TrustedLen};

/// Бір элементті шексіз қайталайтын жаңа итератор жасайды.
///
/// `repeat()` функциясы бір мәнді қайта-қайта қайталайды.
///
/// `repeat()` сияқты шексіз итераторлар оларды ақырлы ету үшін жиі [`Iterator::take()`] сияқты адаптерлерде қолданылады.
///
/// Егер сізге қажет итератордың элемент түрі `Clone`-ті қолданбаса немесе қайталанатын элементті жадта сақтағыңыз келмесе, оның орнына [`repeat_with()`] функциясын қолдануға болады.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Негізгі пайдалану:
///
/// ```
/// use std::iter;
///
/// // төртінші төрт саны:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // иә, әлі төртеу
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// [`Iterator::take()`] көмегімен ақырлы өту:
///
/// ```
/// use std::iter;
///
/// // бұл соңғы мысал тым көп болды.Тек төрт төртеу болсын.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... және біз қазір аяқтадық
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Элементті шексіз қайталайтын итератор.
///
/// Бұл `struct` [`repeat()`] функциясы арқылы жасалған.Толығырақ оның құжаттамасын қараңыз.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}