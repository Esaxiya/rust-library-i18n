use crate::iter::{FusedIterator, TrustedLen};

/// Элементті дәл бір рет беретін итератор жасайды.
///
/// Бұл әдетте бір мәнді [`chain()`] басқа итерация түрлеріне бейімдеу үшін қолданылады.
/// Мүмкін сізде барлығын қамтитын итератор бар шығар, бірақ сізге қосымша ерекше жағдай қажет.
/// Мүмкін сізде итераторларда жұмыс істейтін функция бар шығар, бірақ сізге тек бір мәнді өңдеу керек.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Негізгі пайдалану:
///
/// ```
/// use std::iter;
///
/// // бірі-ең жалғыз нөмір
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // біреуі ғана, біз бұған қол жеткіземіз
/// assert_eq!(None, one.next());
/// ```
///
/// Басқа итератормен бірге тізбек құру.
/// Айталық, біз `.foo` каталогының әр файлы бойынша, сонымен қатар конфигурация файлы бойынша қайталауды қалаймыз,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // біз DirEntry-s итераторынан PathBufs итераторына айналуымыз керек, сондықтан картаны қолданамыз
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // енді біздің итератор тек конфигурация файлына арналған
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // екі итераторды бір үлкен итераторға біріктіріңіз
/// let files = dirs.chain(config);
///
/// // бұл бізге .foo және .foorc файлдарының барлығын береді
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Элементті дәл бір рет беретін итератор.
///
/// Бұл `struct` [`once()`] функциясы арқылы жасалған.Толығырақ оның құжаттамасын қараңыз.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}