use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// *Мұрагер* және *предшественник* операциялары туралы түсініктері бар объектілер.
///
/// *Мұрагер* операциясы үлкенді салыстыратын мәндерге қарай жылжиды.
/// *Предшественник* операциясы азырақ салыстырылатын мәндерге қарай жылжиды.
///
/// # Safety
///
/// Бұл trait-бұл `unsafe`, себебі оның орындалуы `unsafe trait TrustedLen` іске асырылуының қауіпсіздігі үшін дұрыс болуы керек, ал әйтпесе осы trait пайдалану нәтижелеріне `unsafe` коды дұрыс және тізімделген міндеттемелерді орындау үшін сенуге болады.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// `start`-тен `end`-ге жету үшін *ізбасар* қадамдарының санын қайтарады.
    ///
    /// Егер қадамдар саны `usize`-тен асып кетсе (немесе шексіз болса немесе `end` ешқашан қол жеткізілмесе), `None` қайтарады.
    ///
    ///
    /// # Invariants
    ///
    /// Кез келген `a`, `b` және `n` үшін:
    ///
    /// * `steps_between(&a, &b) == Some(n)` егер және `Step::forward_checked(&a, n) == Some(b)` болса ғана
    /// * `steps_between(&a, &b) == Some(n)` егер және `Step::backward_checked(&a, n) == Some(a)` болса ғана
    /// * `steps_between(&a, &b) == Some(n)` тек `a <= b` болса
    ///   * Қорытынды: егер `a == b` болса ғана `steps_between(&a, &b) == Some(0)`
    ///   * `a <= b`-тің _not_-ті `steps_between(&a, &b) != None` білдіретінін ескеріңіз;
    ///     бұл жағдайда `b`-ге жету үшін `usize::MAX` қадамдары қажет болады
    /// * `steps_between(&a, &b) == None` егер `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// `self` `count` рет *мұрагерін* алу арқылы алынатын мәнді қайтарады.
    ///
    /// Егер бұл `Self` қолдайтын мәндер ауқымынан асып кетсе, `None` мәнін қайтарады.
    ///
    /// # Invariants
    ///
    /// Кез келген `a`, `n` және `m` үшін:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// X0 `n + m` асып кетпейтін кез келген `a`, `n` және `m` үшін:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// Кез келген `a` және `n` үшін:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// `self` `count` рет *мұрагерін* алу арқылы алынатын мәнді қайтарады.
    ///
    /// Егер бұл `Self` қолдайтын мәндер ауқымынан асып кетсе, онда бұл функция panic, орау немесе қанықтыруға рұқсат етіледі.
    ///
    /// Ұсынылатын мінез-құлық түзетулерді қосқан кезде panic, ал басқаша орау немесе қанықтыру болып табылады.
    ///
    /// Қауіпсіз код толып кеткеннен кейін тәртіптің дұрыстығына сенбеуі керек.
    ///
    /// # Invariants
    ///
    /// Толып кету болмайтын кез келген `a`, `n` және `m` үшін:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// Толып кету болмайтын кез келген `a` және `n` үшін:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// `self` `count` рет *мұрагерін* алу арқылы алынатын мәнді қайтарады.
    ///
    /// # Safety
    ///
    /// Бұл әрекеттің `Self` қолдайтын мәндер ауқымынан асып кетуі анықталмаған мінез-құлық.
    /// Егер сіз оның толып кетпейтіндігіне кепілдік бере алмасаңыз, оның орнына `forward` немесе `forward_checked` пайдаланыңыз.
    ///
    /// # Invariants
    ///
    /// Кез келген `a` үшін:
    ///
    /// * егер `b > a` сияқты `b` болса, `Step::forward_unchecked(a, 1)`-ге қоңырау шалуға болады
    /// * егер `b`, `steps_between(&a, &b) == Some(n)` сияқты `steps_between(&a, &b) == Some(n)` бар болса, кез-келген `m <= n` үшін `Step::forward_unchecked(a, m)` қоңырау шалуға болады.
    ///
    ///
    /// Толып кету болмайтын кез келген `a` және `n` үшін:
    ///
    /// * `Step::forward_unchecked(a, n)` `Step::forward(a, n)`-ге тең
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// *Предшественникті* алу арқылы алынған мәнді қайтарады `self` `count` рет.
    ///
    /// Егер бұл `Self` қолдайтын мәндер ауқымынан асып кетсе, `None` мәнін қайтарады.
    ///
    /// # Invariants
    ///
    /// Кез келген `a`, `n` және `m` үшін:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// Кез келген `a` және `n` үшін:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// *Предшественникті* алу арқылы алынған мәнді қайтарады `self` `count` рет.
    ///
    /// Егер бұл `Self` қолдайтын мәндер ауқымынан асып кетсе, онда бұл функция panic, орау немесе қанықтыруға рұқсат етіледі.
    ///
    /// Ұсынылатын мінез-құлық түзетулерді қосқан кезде panic, ал басқаша орау немесе қанықтыру болып табылады.
    ///
    /// Қауіпсіз код толып кеткеннен кейін тәртіптің дұрыстығына сенбеуі керек.
    ///
    /// # Invariants
    ///
    /// Толып кету болмайтын кез келген `a`, `n` және `m` үшін:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// Толып кету болмайтын кез келген `a` және `n` үшін:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// *Предшественникті* алу арқылы алынған мәнді қайтарады `self` `count` рет.
    ///
    /// # Safety
    ///
    /// Бұл әрекеттің `Self` қолдайтын мәндер ауқымынан асып кетуі анықталмаған мінез-құлық.
    /// Егер сіз оның толып кетпейтіндігіне кепілдік бере алмасаңыз, оның орнына `backward` немесе `backward_checked` пайдаланыңыз.
    ///
    /// # Invariants
    ///
    /// Кез келген `a` үшін:
    ///
    /// * егер `b < a` сияқты `b` болса, `Step::backward_unchecked(a, 1)`-ге қоңырау шалуға болады
    /// * егер `b`, `steps_between(&b, &a) == Some(n)` сияқты `steps_between(&b, &a) == Some(n)` бар болса, кез-келген `m <= n` үшін `Step::backward_unchecked(a, m)` қоңырау шалуға болады.
    ///
    ///
    /// Толып кету болмайтын кез келген `a` және `n` үшін:
    ///
    /// * `Step::backward_unchecked(a, n)` `Step::backward(a, n)`-ге тең
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Бұлар әлі макрожасалған, өйткені бүтін әріпсандар әр түрлі типке қарай шешіледі.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // ҚАУІПСІЗДІК: қоңырау шалушы `start + n` асып кетпейтіндігіне кепілдік беруі керек.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // ҚАУІПСІЗДІК: қоңырау шалушы `start - n` асып кетпейтіндігіне кепілдік беруі керек.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // Түзету кезінде panic толып кетуіне әкеледі.
            // Бұл шығарылымдардың толықтай оңтайлануы керек.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Мысалы, математиканы орап алыңыз `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // Түзету кезінде panic толып кетуіне әкеледі.
            // Бұл шығарылымдардың толықтай оңтайлануы керек.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Мысалы, математиканы орап алыңыз `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Бұл $u_narrower <=usize-ге негізделген
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // егер n ауқымнан тыс болса, `unsigned_start + n` да болады
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // егер n ауқымнан тыс болса, `unsigned_start - n` да болады
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Бұл $i_narrower <=usize
                        //
                        // Изизге кастинг енін кеңейтеді, бірақ белгіні сақтайды.
                        // Wiz_isub кеңістігінде wrapping_sub пайдаланыңыз және isize ауқымына сыймайтын айырмашылықты есептеу үшін usize үшін құйыңыз.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Қаптама `Step::forward(-120_i8, 200) == Some(80_i8)` сияқты жағдайларды өңдейді, дегенмен 200 i8 ауқымынан тыс.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // Қосымшадан асып кетті
                            }
                        }
                        // Егер n, мысалы, ауқымнан тыс болса
                        // u8, онда ол i8 үшін барлық ауқымнан үлкен, сондықтан `any_i8 + n` міндетті түрде i8-тен асып түседі.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Қаптама `Step::forward(-120_i8, 200) == Some(80_i8)` сияқты жағдайларды өңдейді, дегенмен 200 i8 ауқымынан тыс.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // Сұйықтау толып кетті
                            }
                        }
                        // Егер n, мысалы, ауқымнан тыс болса
                        // u8, онда ол i8 үшін барлық ауқымнан үлкен, сондықтан `any_i8 - n` міндетті түрде i8-тен асып түседі.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // Егер айырмашылық тым үлкен болса
                            // i128, ол аз мөлшерде қолдану үшін өте үлкен болады.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // ҚАУІПСІЗДІК: res-жарамды юникодты скаляр
            // (0xD800..0xE000 емес, 0x110000 төмен)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // ҚАУІПСІЗДІК: res-жарамды юникодты скаляр
        // (0xD800..0xE000 емес, 0x110000 төмен)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // ҚАУІПСІЗДІК: қоңырау шалушы оның толып кетпеуіне кепілдік беруі керек
        // char үшін мәндер ауқымы.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // ҚАУІПСІЗДІК: қоңырау шалушы оның толып кетпеуіне кепілдік беруі керек
            // char үшін мәндер ауқымы.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // ҚАУІПСІЗДІК: бұған дейінгі келісімшартқа байланысты бұл кепілдендірілген
        // қоңырау шалушы жарамды болуы мүмкін.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // ҚАУІПСІЗДІК: қоңырау шалушы оның толып кетпеуіне кепілдік беруі керек
        // char үшін мәндер ауқымы.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // ҚАУІПСІЗДІК: қоңырау шалушы оның толып кетпеуіне кепілдік беруі керек
            // char үшін мәндер ауқымы.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // ҚАУІПСІЗДІК: бұған дейінгі келісімшартқа байланысты бұл кепілдендірілген
        // қоңырау шалушы жарамды болуы мүмкін.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // ҚАУІПСІЗДІК: жай тексерілген алғышарт
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // ҚАУІПСІЗДІК: жай тексерілген алғышарт
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Бұл макростар әртүрлі диапазон түрлері үшін `ExactSizeIterator` имплимдерін жасайды.
//
// * `ExactSizeIterator::len` әрқашан дәл `usize` қайтару үшін қажет, сондықтан ешқандай ауқым `usize::MAX`-тен артық болмауы мүмкін.
//
// * `Range<_>`-тегі бүтін типтер үшін бұл `usize`-тен кішірек немесе ені бар типтер үшін қолданылады.
//   `RangeInclusive<_>` ішіндегі бүтін типтер үшін бұл, мысалы, `usize` қарағанда *қатаң тар* типтерге қатысты
//   `(0..=u64::MAX).len()` `u64::MAX + 1` болар еді.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Бұлар жоғарыдағы пікірлерге сәйкес келмейді, бірақ оларды жою үлкен өзгеріс болар еді, өйткені олар Rust 1.0.0 жағдайында тұрақтандырылды.
    // Мәселен, мысалы
    // `(0..66_000_u32).len()` мысалы, 16 биттік платформаларда қатесіз немесе ескертусіз құрастырады, бірақ дұрыс емес нәтиже береді.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Бұлар жоғарыдағы пікірлерге сәйкес келмейді, бірақ оларды жою үлкен өзгеріс болар еді, өйткені олар Rust 1.26.0 жағдайында тұрақтандырылды.
    // Мәселен, мысалы
    // `(0..=u16::MAX).len()` мысалы, 16 биттік платформаларда қатесіз немесе ескертусіз құрастырады, бірақ дұрыс емес нәтиже береді.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // ҚАУІПСІЗДІК: жай тексерілген алғышарт
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // ҚАУІПСІЗДІК: жай тексерілген алғышарт
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // ҚАУІПСІЗДІК: жай тексерілген алғышарт
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // ҚАУІПСІЗДІК: жай тексерілген алғышарт
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // ҚАУІПСІЗДІК: жай тексерілген алғышарт
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // ҚАУІПСІЗДІК: жай тексерілген алғышарт
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}