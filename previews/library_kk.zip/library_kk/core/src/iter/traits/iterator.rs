// ignore-tidy-filelength бұл файл тек `Iterator` анықтамасынан тұрады.
// Мұны бірнеше файлға бөлу мүмкін емес.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Итераторлармен жұмыс істеуге арналған интерфейс.
///
/// Бұл trait негізгі итераторы.
/// Әдетте итераторлардың тұжырымдамасы туралы көбірек білу үшін [module-level documentation] қараңыз.
/// Атап айтқанда, сіз [implement `Iterator`][impl] әдісін білгіңіз келуі мүмкін.
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Қайталанатын элементтер түрі.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Итераторды алға жылжытады және келесі мәнді қайтарады.
    ///
    /// Итерация аяқталғаннан кейін [`None`] қайтарады.
    /// Жеке итераторларды енгізу итерацияны жалғастыруды таңдауы мүмкін, сондықтан `next()`-ге қайта қоңырау шалу кез-келген уақытта [`Some(Item)`]-ті қайтара бастайды немесе бастамауы мүмкін.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // next() нөміріне қоңырау келесі мәнді қайтарады ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... содан кейін Ешқайсысы аяқталғаннан кейін.
    /// assert_eq!(None, iter.next());
    ///
    /// // Қосымша қоңыраулар `None` қайтаруы мүмкін немесе болмауы мүмкін.Мұнда олар әрқашан болады.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Итератордың қалған ұзындығының шектерін қайтарады.
    ///
    /// Нақты айтқанда, `size_hint()` кортежді қайтарады, мұнда бірінші элемент төменгі шекара, ал екінші элемент жоғарғы шекара болып табылады.
    ///
    /// Кортеждің екінші жартысы қайтарылады [Option`]`<`[`usize`]`> `.
    /// Мұндағы [`None`] дегеніміз не жоғары шекара жоқ, не жоғарғы шекара [`usize`]-тен үлкен дегенді білдіреді.
    ///
    /// # Іске асыру туралы ескертулер
    ///
    /// Итератордың іске асырылуы элементтердің жарияланған санын беретіні орындалмайды.Қате итератор элементтердің төменгі шекарасынан аз немесе жоғарғы шекарасынан көп түсім бере алады.
    ///
    /// `size_hint()` бірінші кезекте итератордың элементтері үшін орын сақтау сияқты оңтайландыру үшін қолдануға арналған, бірақ мысалы, қауіпті кодтағы тексерулерді өткізбеу керек.
    /// `size_hint()`-ті дұрыс қолданбау жад қауіпсіздігін бұзбауы керек.
    ///
    /// Айтуынша, іске асыру дұрыс бағалауды қамтамасыз етуі керек, әйтпесе бұл trait протоколының бұзылуы болар еді.
    ///
    /// Әдепкі іске қосу кез келген итераторға сәйкес келетін «(0,» [«None`]») «мәнін қайтарады.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Неғұрлым күрделі мысал:
    ///
    /// ```
    /// // Жұп сандар нөлден онға дейін.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Біз нөлден он есеге дейін қайталануымыз мүмкін.
    /// // Бес екенін біле отырып, filter()-ті қолданбай мүмкін болмас еді.
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // chain() көмегімен тағы бес санды қосайық
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // қазір екі шекара да беске артты
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// `None`-ті жоғарғы шекара үшін қайтару:
    ///
    /// ```
    /// // шексіз итератордың жоғарғы шегі жоқ, ал максималды төменгі шегі жоқ
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Итерация санын санап, оны қайтарып, итераторды тұтынады.
    ///
    /// Бұл әдіс [`None`] кездескенге дейін бірнеше рет [`next`] қоңырау шалып, [`Some`]-ті қанша рет көргенін қайтарады.
    /// Назар аударыңыз, егер итераторда ешқандай элементтер болмаса да, [`next`] кем дегенде бір рет шақырылуы керек.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Толып жатқан тәртіп
    ///
    /// Бұл әдіс толып кетуден қорғалмайды, сондықтан [`usize::MAX`] элементтерінен көп итератор элементтерін санау дұрыс емес нәтиже береді немесе panics.
    ///
    /// Егер түзету мәлімдемелері қосылса, panic кепілдендірілген.
    ///
    /// # Panics
    ///
    /// Итераторда [`usize::MAX`] элементтері көп болса, бұл функция panic болуы мүмкін.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Соңғы элементті қайтарып, итераторды тұтынады.
    ///
    /// Бұл әдіс итераторды [`None`] қайтарғанға дейін бағалайды.
    /// Бұл ретте ол ағымдағы элементтің есебін жүргізеді.
    /// [`None`] қайтарылғаннан кейін, `last()` көрген соңғы элементін қайтарады.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Итераторды `n` элементтері бойынша жоғарылатады.
    ///
    /// Бұл әдіс `n` элементтерін [`None`] кездескенге дейін [`next`]-ті `n`-ге дейін шақыру арқылы асыға жібереді.
    ///
    /// `advance_by(n)` итератор `n` элементтерімен сәтті алға жылжытса, [`Ok(())`][Ok] қайтарады немесе егер [`None`] кездессе [`Err(k)`][Err], мұндағы `k`-итератор элементтері таусылмас бұрын алға басатын элементтер саны (яғни
    /// итератордың ұзындығы).
    /// `k` әрқашан `n`-тен аз болатынын ескеріңіз.
    ///
    /// `advance_by(0)` қоңырауына қоңырау шалу ешқандай элементтерді тұтынбайды және әрқашан [`Ok(())`][Ok] қайтарады.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // тек `&4` өткізіп жіберілді
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Итератордың `n`-ші элементін қайтарады.
    ///
    /// Көптеген индекстеу операциялары сияқты, санау нөлден басталады, сондықтан `nth(0)` бірінші мәнді, `nth(1)` екіншісін және т.б.
    ///
    /// Алдыңғы барлық элементтер, сондай-ақ қайтарылған элемент қайталағыштан жұмсалатынын ескеріңіз.
    /// Бұл дегеніміз, алдыңғы элементтер жойылады, сонымен қатар `nth(0)` бір итераторға бірнеше рет қоңырау шалу әртүрлі элементтерді қайтарады.
    ///
    ///
    /// `nth()` егер `n` итератордың ұзындығынан үлкен немесе тең болса, [`None`] мәнін қайтарады.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// `nth()` нөміріне бірнеше рет қоңырау шалу итергішті кері қайтармайды:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Егер `n + 1` элементтерінен аз болса, `None` қайтару:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Бір нүктеден басталатын итератор жасайды, бірақ әр қайталанған кезде берілген мөлшерге қадам жасайды.
    ///
    /// 1-ескерту: итератордың бірінші элементі берілген қадамға қарамастан әрдайым қайтарылады.
    ///
    /// 2-ескерту: елемейтін элементтер тартылатын уақыт белгіленбеген.
    /// `StepBy` өзін `next(), nth(step-1), nth(step-1),…` тізбегі сияқты ұстайды, бірақ сонымен қатар өзін еркін ұстай алады
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Кейбір итераторлар үшін өнімділік себептеріне байланысты қандай әдіс қолданылуы мүмкін.
    /// Екінші жол итераторды ертерек жылжытады және көп заттарды тұтынуы мүмкін.
    ///
    /// `advance_n_and_return_first` баламасы:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Егер берілген қадам `0` болса, әдіс panic болады.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Екі итераторды қабылдайды және кезекпен екеуінде де жаңа итератор жасайды.
    ///
    /// `chain()` алдымен бірінші итератордың мәндері бойынша, содан кейін екінші итератордың мәндері бойынша қайталанатын жаңа итераторды қайтарады.
    ///
    /// Басқаша айтқанда, ол екі итераторды тізбекке біріктіреді.🔗
    ///
    /// [`once`] әдетте бір мәнді басқа итерация түрлерінің тізбегіне бейімдеу үшін қолданылады.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `chain()` аргументі [`IntoIterator`]-ті қолданатындықтан, біз [`Iterator`]-ке ғана емес, [`Iterator`]-ке айналдыруға болатын кез-келген нәрсені жібере аламыз.
    /// Мысалы, (`&[T]`) тілімдері [`IntoIterator`]-ті жүзеге асырады, сондықтан оны `chain()`-ге тікелей беруге болады:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Егер сіз Windows API-мен жұмыс жасасаңыз, сіз [`OsStr`]-ті `Vec<u16>`-ге түрлендіргіңіз келуі мүмкін:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// Екі итераторды жұптардың бір итераторына дейін көбейтіңіз.
    ///
    /// `zip()` екінші итератордың үстінен қайталанатын жаңа итераторды қайтарады, бірінші элемент бірінші итератордан келетін кортежді қайтарады, ал екінші элемент екінші итератордан шығады.
    ///
    ///
    /// Басқаша айтқанда, ол екі итераторды біртұтас етіп қысқартады.
    ///
    /// Егер кез-келген итератор [`None`] мәнін қайтарса, [`next`] қысылған итератордан [`None`] мәнін алады.
    /// Егер бірінші итератор [`None`] мәнін қайтарса, онда `zip` тұйықталады және екінші итераторда `next` шақырылмайды.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` аргументі [`IntoIterator`]-ті қолданатындықтан, біз [`Iterator`]-ке ғана емес, [`Iterator`]-ке айналдыруға болатын кез-келген нәрсені жібере аламыз.
    /// Мысалы, (`&[T]`) тілімдері [`IntoIterator`]-ті жүзеге асырады, сондықтан оны `zip()`-ге тікелей беруге болады:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` көбінесе шексіз итераторды ақырғыға ауыстыру үшін қолданылады.
    /// Бұл жұмыс істейді, өйткені ақырлы итератор найзағай аяқталып [`None`] оралады.`(0..)` көмегімен зипирование [`enumerate`]-қа ұқсас болуы мүмкін:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// `separator` көшірмесін бастапқы итератордың іргелес элементтері арасында орналастыратын жаңа итератор жасайды.
    ///
    /// Егер `separator` [`Clone`]-ті қолданбаса немесе оны есептеу қажет болса, [`intersperse_with`]-ті қолданыңыз.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // `a`-тен бірінші элемент.
    /// assert_eq!(a.next(), Some(&100)); // Бөлгіш.
    /// assert_eq!(a.next(), Some(&1));   // `a` келесі элементі.
    /// assert_eq!(a.next(), Some(&100)); // Бөлгіш.
    /// assert_eq!(a.next(), Some(&2));   // `a` соңғы элементі.
    /// assert_eq!(a.next(), None);       // Итератор аяқталды.
    /// ```
    ///
    /// `intersperse` жалпы элементтің көмегімен итератор элементтеріне қосылу өте пайдалы болуы мүмкін:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// `separator` жасаған элементті бастапқы итератордың іргелес элементтерінің арасына орналастыратын жаңа итератор жасайды.
    ///
    /// Жабу элемент итератордың іргелес екі элементінің арасына орналастырылған сайын дәл бір рет аталады;
    /// нақты, егер негізгі итератор екі элементтен аз өнім алса және соңғы элемент алынғаннан кейін жабылу деп аталмайды.
    ///
    ///
    /// Егер итератор элементі [`Clone`]-ті қолданса, [`intersperse`] пайдалану оңайырақ болуы мүмкін.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // `v`-тен бірінші элемент.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Бөлгіш.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // `v` келесі элементі.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Бөлгіш.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // `v`-тен соңғы элемент.
    /// assert_eq!(it.next(), None);               // Итератор аяқталды.
    /// ```
    ///
    /// `intersperse_with` сепараторды есептеу қажет болған жағдайда қолдануға болады:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Жабу элементті жасау үшін оның контекстін өзгертеді.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Жабуды қабылдайды және әр элементтің жабылуын шақыратын итератор жасайды.
    ///
    /// `map()` аргументі арқылы бір итераторды екіншісіне айналдырады:
    /// [`FnMut`] іске асыратын нәрсе.Ол жаңа итераторды шығарады, ол бастапқы итератордың әрбір элементінде осы жабылуды атайды.
    ///
    /// Егер сіз ойлау түрлерін жақсы білсеңіз, онда сіз `map()` туралы ойлауға болады:
    /// Егер сізде `A` типті элементтер беретін итератор болса, және сіз басқа `B` типті итераторды қаласаңыз, `map()`-ті `A` қабылдайтын және `B` қайтаратын жабуды өткізіп пайдалана аласыз.
    ///
    ///
    /// `map()` тұжырымдамалық жағынан [`for`] циклына ұқсас.Алайда, `map()` жалқау болғандықтан, оны басқа итераторлармен жұмыс істегенде жақсы қолданады.
    /// Егер сіз жанама әсер ету үшін цикл жасасаңыз, [`for`]-ті `map()`-ге қарағанда идиомалық деп санайды.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Егер сіз қандай да бір жанама әсер жасасаңыз, [`for`]-тен `map()`-ге артықшылық беріңіз:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // мұны жасамаңыз:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // ол тіпті орындалмайды, өйткені ол жалқау.Бұл туралы Rust ескертеді.
    ///
    /// // Оның орнына келесі үшін қолданыңыз:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Итератордың әр элементіне жабылуды шақырады.
    ///
    /// Бұл итераторда [`for`] циклін қолдануға тең, бірақ `break` және `continue` жабылуынан мүмкін емес.
    /// Әдетте `for` циклін қолдану идиомалыққа сәйкес келеді, бірақ `for_each` ұзағырақ итератор тізбектерінің соңында элементтерді өңдегенде түсінікті болуы мүмкін.
    ///
    /// Кейбір жағдайларда `for_each` циклге қарағанда жылдамырақ болуы мүмкін, өйткені ол `Chain` сияқты адаптерлерде ішкі итерацияны қолданады.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Осындай кішігірім мысал үшін `for` циклы таза болуы мүмкін, бірақ `for_each` функционалды стильді ұзағырақ итераторлармен ұстаған жөн:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Итератор жасайды, ол элементтің берілуін анықтау үшін жабуды қолданады.
    ///
    /// Берілген элементтің жабылуы `true` немесе `false` мәнін қайтаруы керек.Қайтарылған итератор тек жабылу ақиқат болатын элементтерді береді.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `filter()`-ге жабылу сілтемені қабылдайтындықтан және көптеген итераторлар сілтемелер бойынша қайталанатындықтан, бұл мүмкін түсініксіз жағдайға алып келеді, мұнда жабылу түрі екі сілтеме болып табылады:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // екі * с керек!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Оның орнына дәлелді жою үшін деструктивтеу әдісін қолдану қажет:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // екеуі де және *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// немесе екеуі де:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // екі &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// осы қабаттардың
    ///
    /// `iter.filter(f).next()` `iter.find(f)` эквивалентіне тең екенін ескеріңіз.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Сүзетін де, картасын да көрсететін итератор жасайды.
    ///
    /// Қайтарылған итератор тек жабылған `Some(value)` мәнін беретін мәндерді ғана береді.
    ///
    /// `filter_map` [`filter`] және [`map`] тізбектерін дәлірек жасау үшін қолдануға болады.
    /// Төмендегі мысалда `map().filter().map()`-ті `filter_map`-ге бір қоңырауға қалай қысқартуға болатындығы көрсетілген.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Міне, дәл сол мысал, бірақ [`filter`] және [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Ағымдағы қайталану санын және келесі мәнін беретін итератор жасайды.
    ///
    /// Қайталаушы `(i, val)` жұптарын береді, мұндағы `i`-қайталанудың ағымдағы индексі, ал `val`-итератор қайтарған мән.
    ///
    ///
    /// `enumerate()` оның санын [`usize`] ретінде сақтайды.
    /// Егер сіз басқа өлшемді бүтін санмен санағыңыз келсе, [`zip`] функциясы ұқсас функционалдылықты қамтамасыз етеді.
    ///
    /// # Толып жатқан тәртіп
    ///
    /// Бұл әдіс толып кетуден қорғамайды, сондықтан [`usize::MAX`] элементтерін көп санағанда қате нәтиже шығады немесе panics.
    /// Егер түзету мәлімдемелері қосылса, panic кепілдендірілген.
    ///
    /// # Panics
    ///
    /// Қайтарылған итератор panic мүмкін, егер қайтарылатын индекс [`usize`]-тен асып кетсе.
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Итераторды жасайды, ол [`peek`] көмегімен итератордың келесі элементіне оны қолданбай қарай алады.
    ///
    /// Итераторға [`peek`] әдісін қосады.Қосымша ақпарат алу үшін оның құжаттамасын қараңыз.
    ///
    /// [`peek`] бірінші рет шақырылған кезде негізгі итератор әлі де жетілдірілгеніне назар аударыңыз: келесі элементті алу үшін [`next`] негізгі итераторға шақырылады, демек кез-келген жанама әсерлер (яғни
    ///
    /// [`next`] әдісінің келесі мәнін алудан басқа кез келген нәрсе пайда болады.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() бізге future нұсқасын көруге мүмкіндік береді
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // біз бірнеше рет peek() жасай аламыз, итератор алға жылжымайды
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // итератор аяқталғаннан кейін peek() да аяқталады
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// [«Өткізіп жіберу] элементтерін предикатқа негізделген итератор жасайды.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` жабылуды дәлел ретінде қабылдайды.Ол жабылуды итератордың әрбір элементіне шақырады және `false` қайтарғанша элементтерді елемейді.
    ///
    /// `false` қайтарылғаннан кейін, `skip_while()`'s жұмысы аяқталады, ал қалған элементтер беріледі.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `skip_while()`-ге жабылу сілтемені қабылдайтындықтан және көптеген итераторлар сілтемелердің үстінен қайталанатындықтан, бұл мүмкін түсініксіз жағдайға алып келеді, мұнда жабылу аргументінің типі екі сілтеме болып табылады:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // екі * с керек!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Бастапқы `false` кейін тоқтату:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // бұл жалған болар еді, өйткені бізде жалған болған, skip_while() енді қолданылмайды
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Предикат негізінде элементтер беретін итератор жасайды.
    ///
    /// `take_while()` жабылуды дәлел ретінде қабылдайды.Ол бұл жабылуды итератордың әрбір элементіне шақырады және `true` қайтарған кезде элементтерді береді.
    ///
    /// `false` қайтарылғаннан кейін, `take_while()`'s жұмысы аяқталады, ал қалған элементтер еленбейді.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take_while()`-ге жабылу сілтемені қабылдайтындықтан және көптеген итераторлар сілтемелер бойынша қайталанатындықтан, бұл мүмкін түсініксіз жағдайға алып келеді, мұнда жабылу түрі екі сілтеме болып табылады:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // екі * с керек!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Бастапқы `false` кейін тоқтату:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Бізде нөлден аз элементтер көп, бірақ бізде жалған болғандықтан, take_while() енді қолданылмайды
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take_while()` мәнін қосу керек пе, жоқ па, соны қарау керек болғандықтан, итераторларды тұтыну оның жойылғанын көреді:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` бұдан былай жоқ, өйткені ол қайталанудың тоқтауы керек екенін білу үшін жұмсалған, бірақ қайтадан итераторға орналастырылмаған.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Екі предикат пен карталарға негізделген элементтер беретін итератор жасайды.
    ///
    /// `map_while()` жабылуды дәлел ретінде қабылдайды.
    /// Ол бұл жабылуды итератордың әрбір элементіне шақырады және [`Some(_)`][`Some`] қайтарған кезде элементтерді береді.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Міне, дәл сол мысал, бірақ [`take_while`] және [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Бастапқы [`None`] кейін тоқтату:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Бізде u32-ге сыйатын элементтер көп (4, 5), бірақ `map_while` `-3` үшін `None`-ті қайтарды (`predicate` `None`-ті қайтарған кезде) және `collect` бірінші `None`-та тоқтайды.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// `map_while()` мәнін қосу керек пе, жоқ па, соны қарау керек болғандықтан, итераторларды тұтыну оның жойылғанын көреді:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` бұдан былай жоқ, өйткені ол қайталанудың тоқтауы керек екенін білу үшін жұмсалған, бірақ қайтадан итераторға орналастырылмаған.
    ///
    /// [`take_while`]-тен айырмашылығы, бұл итератор **біріктірілмеген**.
    /// Сондай-ақ, бірінші [`None`] қайтарылғаннан кейін бұл итератордың не қайтаратыны көрсетілмеген.
    /// Егер сізге балқытылған итератор қажет болса, [`fuse`] пайдаланыңыз.
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Бірінші `n` элементтерін өткізіп жіберетін итератор жасайды.
    ///
    /// Олар тұтынылғаннан кейін қалған элементтер алынады.
    /// Бұл әдісті тікелей жоққа шығарудың орнына, `nth` әдісін жоққа шығарыңыз.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Оның алғашқы `n` элементтерін беретін итератор жасайды.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` оны ақырлы ету үшін жиі шексіз итератормен қолданылады:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Егер `n` элементтерінен аз болса, `take` өзін негізгі итератордың өлшемімен шектейді:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Ішкі күйді сақтайтын және жаңа итератор шығаратын [`fold`] ұқсас итератор адаптері.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` екі аргумент алады: ішкі күйді қалыптастыратын бастапқы мән және екі аргументпен жабылу, біріншісі ішкі күйге өзгермелі сілтеме, ал екіншісі итератор элементі.
    ///
    /// Жабу қайталанулар арасындағы күйді бөлісу үшін ішкі күйге тағайындалуы мүмкін.
    ///
    /// Қайталау кезінде жабу итератордың әрбір элементіне қолданылады және жабылудан қайтарылатын мән, яғни [`Option`] итератормен шығарылады.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // әрбір итерация, біз күйді элементке көбейтеміз
    ///     *state = *state * x;
    ///
    ///     // сонда біз мемлекет жоққа шығарамыз
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Карта сияқты жұмыс істейтін, бірақ кіріктірілген құрылымды тегістейтін итератор жасайды.
    ///
    /// [`map`] адаптері өте пайдалы, бірақ жабылу аргументі мәндерді шығарған кезде ғана.
    /// Егер ол орнына итератор шығарса, қосымша жанама қабат пайда болады.
    /// `flat_map()` бұл қосымша қабатты өздігінен жояды.
    ///
    /// Сіз `flat_map(f)`-ті [`map`] ping-тің мағыналық эквиваленті ретінде қарастыра аласыз, содан кейін `map(f).flatten()`-тегідей [` тегістеңіз].
    ///
    /// `flat_map()` туралы ойлаудың тағы бір тәсілі: [«картаның» жабылуы әр элемент үшін бір элементті қайтарады, ал `flat_map()`'s жабылуы әр элемент үшін қайталаушыны қайтарады.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() итераторды қайтарады
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Ұяланған құрылымды тегістейтін итератор жасайды.
    ///
    /// Бұл сіздің итераторларыңызда немесе итераторларға айналуы мүмкін нәрселердің итераторында болғанда және жанама деңгейдің бір деңгейін алып тастағыңыз келгенде пайдалы.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Картаға түсіру, содан кейін тегістеу:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() итераторды қайтарады
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Сондай-ақ, сіз мұны [`flat_map()`] тұрғысынан қайта жаза аласыз, бұл жағдайда неғұрлым нақты ниет білдіретіндіктен қолайлы:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() итераторды қайтарады
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Тегістеу бір уақытта ұя салудың бір деңгейін ғана алып тастайды:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Мұнда біз `flatten()` "deep" тегістеуін жасамайтынын көреміз.
    /// Оның орнына ұя салудың бір деңгейі ғана жойылады.Яғни, егер сіз `flatten()` өлшемді массивін қолдансаңыз, нәтиже бір өлшемді емес, екі өлшемді болады.
    /// Бір өлшемді құрылымды алу үшін сізге қайтадан `flatten()` керек.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Бірінші [`None`] кейін аяқталатын итератор жасайды.
    ///
    /// Итератор [`None`] қайтарғаннан кейін future қоңыраулары қайтадан [`Some(T)`] әкелуі мүмкін немесе бермеуі мүмкін.
    /// `fuse()` итераторды бейімдейді, ол [`None`] берілгеннен кейін оның әрқашан [`None`] мәңгіге оралуын қамтамасыз етеді.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// // Кейбір және Ешқандай ауысатын итератор
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // егер ол тең болса, Some(i32), басқасы Жоқ
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // біз өз итераторымыздың алға-артқа қарай жүргенін көре аламыз
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // дегенмен, оны біріктіргеннен кейін ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // ол әрқашан бірінші реттен кейін `None` оралады.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Итератордың әрбір элементімен мәнді өткізе отырып, бірдеңе жасайды.
    ///
    /// Итераторларды пайдалану кезінде сіз олардың бірнеше тізбегін жиі байланыстырасыз.
    /// Мұндай кодпен жұмыс жасау барысында сіз құбырдың әртүрлі бөліктерінде не болып жатқанын тексергіңіз келуі мүмкін.Ол үшін `inspect()` нөміріне қоңырау шалыңыз.
    ///
    /// Соңғы кодта болғаннан гөрі, `inspect()`-ті жөндеу құралы ретінде пайдалану жиі кездеседі, бірақ қолданбалар оны кейбір жағдайларда қателер жойылғанға дейін тіркеу қажет болған жағдайда пайдалы деп санайды.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // бұл итератордың реттілігі күрделі.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // не болып жатқанын тексеру үшін inspect() қоңырауларын қосайық
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Бұл басып шығарады:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Қателерді жоюдан бұрын оларды тіркеу:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Бұл басып шығарады:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Итераторды тұтынудан гөрі қарызға алады.
    ///
    /// Бұл бастапқы итераторға меншік құқығын сақтай отырып, итератор адаптерін қолдануға мүмкіндік беру үшін пайдалы.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // егер біз қайтадан қайталауды қолданып көрсек, ол нәтиже бермейді.
    /// // Келесі жол «қате: жылжытылған мәнді пайдалану: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // қайтадан көрейік
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // оның орнына біз .by_ref() қосамыз
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // қазір бұл өте жақсы:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Итераторды коллекцияға айналдырады.
    ///
    /// `collect()` кез-келген қайталанатын нәрсені алып, оны тиісті жинаққа айналдыра алады.
    /// Бұл әртүрлі контекстте қолданылатын стандартты кітапханадағы ең қуатты әдістердің бірі.
    ///
    /// `collect()` қолданылатын ең негізгі үлгі-бір коллекцияны басқасына айналдыру.
    /// Сіз коллекцияны алып, [`iter`]-ке қоңырау шалып, көптеген түрлендірулер жасайсыз, содан кейін `collect()`.
    ///
    /// `collect()` типтік жинақ емес типтердің даналарын да жасай алады.
    /// Мысалы, [`String`] құрылғысын [`char`] дан құрастыруға болады, ал [`Result<T, E>`][`Result`] элементтерінің итераторын `Result<Collection<T>, E>` ішіне жинауға болады.
    ///
    /// Қосымша ақпаратты төмендегі мысалдардан қараңыз.
    ///
    /// `collect()` өте жалпы болғандықтан, типті шығаруда қиындықтар тудыруы мүмкін.
    /// Осылайша, `collect()`-сіз 'turbofish' деп аталатын синтаксисті көретін бірнеше уақыттың бірі: `::<>`.
    /// Бұл қорытынды алгоритміне қай коллекцияны жинағалы отырғаныңызды нақты түсінуге көмектеседі.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Бізге `: Vec<i32>` сол жақта қажет болғанын ескеріңіз.Себебі, біз оның орнына [`VecDeque<T>`] жинай аламыз:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// `doubled` түсіндірмесінің орнына 'turbofish' пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// `collect()` тек сіз жинайтын нәрсеге ғана назар аударатындықтан, сіз `_` ішінара түртіндісін турбо балықпен бірге пайдалана аласыз:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// [`String`] жасау үшін `collect()` пайдалану:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Егер сізде [«Нәтиже» тізімі болса<T, E>`][« Нәтиже »], сіз олардың кез-келгенінің орындалмағанын көру үшін `collect()` пайдалана аласыз:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // бізге бірінші қатені жібереді
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // жауаптар тізімін береді
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Одан екі топтама жасай отырып, итераторды қолданады.
    ///
    /// `partition()`-ге берілген предикат `true` немесе `false` мәнін қайтара алады.
    /// `partition()` `true` қайтарған барлық элементтерді және `false` қайтарған барлық элементтерді қайтарады.
    ///
    ///
    /// Сондай-ақ, [`is_partitioned()`] және [`partition_in_place()`] қараңыз.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Берілген предикатқа сәйкес осы итератордың элементтерін *орнында* өзгертеді, осылайша `true` қайтаратындардың бәрі `false` қайтаратындардың бәрінен бұрын болады.
    ///
    /// Табылған `true` элементтерінің санын қайтарады.
    ///
    /// Бөлінген элементтердің салыстырмалы тәртібі сақталмайды.
    ///
    /// Сондай-ақ, [`is_partitioned()`] және [`partition()`] қараңыз.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Жұптар мен коэффициенттер арасындағы орын
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: санау толып кетті деп уайымдауымыз керек пе?Бұдан көп нәрсеге ие болудың жалғыз жолы
        // `usize::MAX` өзгертілетін сілтемелер бөлуге пайдалы емес ZST сілтемелерімен ...

        // Бұл "factory" жабылу функциялары `Self`-тің кең пейілдігін болдырмау үшін бар.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Бірінші `false`-ті бірнеше рет тауып, оны соңғы `true`-мен ауыстырыңыз.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Осы итератордың элементтері берілген предикатқа сәйкес бөлінгендігін тексереді, осылайша `true` қайтаратындардың бәрі `false` қайтаратындардың бәрінен озады.
    ///
    ///
    /// Сондай-ақ, [`partition()`] және [`partition_in_place()`] қараңыз.
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Барлық элементтер `true`-ті тексереді немесе бірінші сөйлем `false`-ге тоқтайды және біз бұдан кейін `true` элементтерінің жоқтығын тексереміз.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Функцияны сәтті қайтып, жалғыз, соңғы мән шығарған кезде оны қолданатын итератор әдісі.
    ///
    /// `try_fold()` екі аргумент алады: бастапқы мән және екі аргументпен жабылу: 'accumulator' және элемент.
    /// Жабу аккумулятор келесі итерация үшін болуы керек мәнмен сәтті оралады немесе ол (short-circuiting) дереу қоңырау шалушыға таралатын қате мәнімен бірге сәтсіздікке әкеледі.
    ///
    ///
    /// Бастапқы мән-бұл аккумулятордың бірінші қоңырау кезінде алатын мәні.Егер жабуды қолдану итератордың барлық элементтеріне сәйкес келсе, `try_fold()` соңғы аккумуляторды сәттілік ретінде қайтарады.
    ///
    /// Бүктеу сізде бірдеңе жинақталған кезде пайдалы болады және одан бір мән шығарғыңыз келеді.
    ///
    /// # Орындаушыларға ескерту
    ///
    /// Басқа (forward) әдістерінің бірнешеуі осыған байланысты әдепкі іске асыруларға ие, сондықтан әдепкі `for` циклін іске асырудан әлдеқайда жақсы нәрсе істей алатын болса, оны нақты жүзеге асыруға тырысыңыз.
    ///
    /// Атап айтқанда, `try_fold()` қоңырауын осы итератордан тұратын ішкі бөліктерге орналастыруға тырысыңыз.
    /// Егер бірнеше қоңыраулар қажет болса, `?` операторы аккумулятор мәнін тізбектеуге ыңғайлы болуы мүмкін, бірақ ерте қайтарылғанға дейін сақталуы керек кез келген инварианттардан сақ болыңыз.
    /// Бұл `&mut self` әдісі, сондықтан бұл жерде қате болғаннан кейін қайталануды жалғастыру керек.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // массивтің барлық элементтерінің тексерілген қосындысы
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Бұл қосынды 100 элементті қосқанда толып кетеді
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Ол қысқа тұйықталғандықтан, қалған элементтер итератор арқылы қол жетімді.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Итератордың әр элементіне қате функцияны қолданатын, алғашқы қатені тоқтатып, сол қатені қайтаратын итератор әдісі.
    ///
    ///
    /// Мұны [`for_each()`]-тің бұзылатын түрі немесе [`try_fold()`]-тің азаматтығы жоқ нұсқасы ретінде қарастыруға болады.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Ол қысқа тұйықталған, сондықтан қалған элементтер әлі де итераторда:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Әр элементті операцияны қолдану арқылы аккумуляторға бүктейді, соңғы нәтижені қайтарады.
    ///
    /// `fold()` екі аргумент алады: бастапқы мән және екі аргументпен жабылу: 'accumulator' және элемент.
    /// Жабу аккумуляторда келесі итерация үшін болуы керек мәнді қайтарады.
    ///
    /// Бастапқы мән-бұл аккумулятордың бірінші қоңырау кезінде алатын мәні.
    ///
    /// Осы жабуды итератордың барлық элементтеріне қолданғаннан кейін, `fold()` аккумуляторды қайтарады.
    ///
    /// Бұл операция кейде 'reduce' немесе 'inject' деп аталады.
    ///
    /// Бүктеу сізде бірдеңе жинақталған кезде пайдалы болады және одан бір мән шығарғыңыз келеді.
    ///
    /// Note: `fold()` және сол сияқты барлық итераторды айналып өтетін әдістер шексіз итераторлар үшін, тіпті нәтижесі ақырғы уақытта анықталатын traits үшін де аяқталмауы мүмкін.
    ///
    /// Note: Егер аккумулятор түрі мен элемент типі бірдей болса, [`reduce()`] алғашқы элементті бастапқы мән ретінде пайдалану үшін қолданыла алады.
    ///
    /// # Орындаушыларға ескерту
    ///
    /// Басқа (forward) әдістерінің бірнешеуі осыған байланысты әдепкі іске асыруларға ие, сондықтан әдепкі `for` циклін іске асырудан әлдеқайда жақсы нәрсе істей алатын болса, оны нақты жүзеге асыруға тырысыңыз.
    ///
    ///
    /// Атап айтқанда, `fold()` қоңырауын осы итератордан тұратын ішкі бөліктерге орналастыруға тырысыңыз.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // жиымның барлық элементтерінің қосындысы
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Келіңіздер, қайталанудың әр қадамын мына жерде қарастырайық:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Сонымен, біздің қорытынды нәтижеміз, `6`.
    ///
    /// Итераторларды көп қолданбаған адамдар үшін нәтижені қалыптастыру үшін `for` циклін тізбесі бар заттар қолданады.Оларды `fold()`s-ге айналдыруға болады:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // цикл үшін:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // олар бірдей
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Төмендету әрекетін бірнеше рет қолдану арқылы элементтерді жалғызға дейін азайтады.
    ///
    /// Егер итератор бос болса, [`None`] мәнін қайтарады;әйтпесе азайту нәтижесін қайтарады.
    ///
    /// Кем дегенде бір элементі бар итераторлар үшін бұл [`fold()`] итератордың бірінші элементімен бастапқы мәнмен бірдей, әрбір келесі элементтерді оған бүктейді.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Максималды мәнді табыңыз:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Итератордың әрбір элементі предикатқа сәйкес келетіндігін тексереді.
    ///
    /// `all()` `true` немесе `false` қайтаратын жабуды алады.Ол осы жабылуды итератордың әрбір элементіне қолданады және егер олардың барлығы `true` мәнін алса, онда `all()` де солай болады.
    /// Егер олардың кез-келгені `false` қайтарса, ол `false` мәнін қайтарады.
    ///
    /// `all()` қысқа тұйықталу;басқаша айтқанда, ол `false` тапқаннан кейін өңдеуді тоқтатады, егер басқа қандай жағдай болмасын, нәтиже де `false` болады.
    ///
    ///
    /// Бос итератор `true` қайтарады.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Бірінші `false`-ті тоқтату:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // біз әлі де `iter` қолдана аламыз, өйткені элементтер көп.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Итератордың кез-келген элементі предикатқа сәйкес келетіндігін тексереді.
    ///
    /// `any()` `true` немесе `false` қайтаратын жабуды алады.Ол осы жабылуды итератордың әрбір элементіне қолданады және егер олардың кез-келгені `true` мәнін алса, онда `any()` мәні де солай болады.
    /// Егер олардың барлығы `false` мәнін қайтарса, ол `false` мәнін қайтарады.
    ///
    /// `any()` қысқа тұйықталу;басқаша айтқанда, ол `true` тапқаннан кейін өңдеуді тоқтатады, егер басқа қандай жағдай болмасын, нәтиже де `true` болады.
    ///
    ///
    /// Бос итератор `false` қайтарады.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Бірінші `true`-ті тоқтату:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // біз әлі де `iter` қолдана аламыз, өйткені элементтер көп.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Предикатты қанағаттандыратын итератор элементін іздейді.
    ///
    /// `find()` `true` немесе `false` қайтаратын жабуды алады.
    /// Ол осы жабылуды итератордың әрбір элементіне қолданады және егер олардың кез-келгені `true` мәнін берсе, онда `find()` [`Some(element)`] мәнін қайтарады.
    /// Егер олардың барлығы `false` мәнін қайтарса, ол [`None`] мәнін қайтарады.
    ///
    /// `find()` қысқа тұйықталу;басқаша айтқанда, ол жабылу `true` қайтарылғаннан кейін өңдеуді тоқтатады.
    ///
    /// `find()` сілтемені қабылдайтындықтан және көптеген итераторлар сілтемелердің үстінен қайталанатындықтан, бұл аргумент екі сілтеме болатын түсініксіз жағдайға әкеледі.
    ///
    /// Сіз бұл әсерді `&&x` көмегімен төмендегі мысалдардан көре аласыз.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Бірінші `true`-ті тоқтату:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // біз әлі де `iter` қолдана аламыз, өйткені элементтер көп.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// `iter.find(f)` `iter.filter(f).next()` эквивалентіне тең екенін ескеріңіз.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Итератор элементтеріне функцияны қолданады және бірінші емес нәтижені береді.
    ///
    ///
    /// `iter.find_map(f)` `iter.filter_map(f).next()`-ге тең.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Итератор элементтеріне функцияны қолданады және алғашқы шын нәтижені немесе бірінші қатені қайтарады.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Итератордан элементті іздейді, оның индексін қайтарады.
    ///
    /// `position()` `true` немесе `false` қайтаратын жабуды алады.
    /// Ол осы жабылуды итератордың әрбір элементіне қолданады және егер олардың біреуі `true` мәнін берсе, онда `position()` [`Some(index)`] мәнін қайтарады.
    /// Егер олардың барлығы `false` мәнін қайтарса, ол [`None`] мәнін қайтарады.
    ///
    /// `position()` қысқа тұйықталу;басқаша айтқанда, ол `true` тапқаннан кейін өңдеуді тоқтатады.
    ///
    /// # Толып жатқан тәртіп
    ///
    /// Бұл әдіс толып кетуден сақтандырмайды, сондықтан егер [`usize::MAX`] сәйкес келмейтін элементтер болса, ол қате нәтиже шығарады немесе panics.
    ///
    /// Егер түзету мәлімдемелері қосылса, panic кепілдендірілген.
    ///
    /// # Panics
    ///
    /// Егер итераторда `usize::MAX` сәйкес келмейтін элементтер болса, бұл функция panic болуы мүмкін.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Бірінші `true`-ті тоқтату:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // біз әлі де `iter` қолдана аламыз, өйткені элементтер көп.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Қайтарылған индекс итератор күйіне байланысты
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Итератордағы элементті оң жақтан іздейді, оның индексін қайтарады.
    ///
    /// `rposition()` `true` немесе `false` қайтаратын жабуды алады.
    /// Ол осы жабылуды итератордың әр элементіне аяғынан бастап қолданады және егер олардың біреуі `true` мәнін берсе, онда `rposition()` [`Some(index)`] мәнін қайтарады.
    ///
    /// Егер олардың барлығы `false` мәнін қайтарса, ол [`None`] мәнін қайтарады.
    ///
    /// `rposition()` қысқа тұйықталу;басқаша айтқанда, ол `true` тапқаннан кейін өңдеуді тоқтатады.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Бірінші `true`-ті тоқтату:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // біз әлі де `iter` қолдана аламыз, өйткені элементтер көп.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Бұл жерде толып кетуді тексерудің қажеті жоқ, өйткені `ExactSizeIterator` элементтердің саны `usize`-ке сәйкес келетіндігін білдіреді.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Итератордың максималды элементін қайтарады.
    ///
    /// Егер бірнеше элементтер бірдей максимум болса, соңғы элемент қайтарылады.
    /// Егер итератор бос болса, [`None`] қайтарылады.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Итератордың минималды элементін қайтарады.
    ///
    /// Егер бірнеше элемент бірдей минималды болса, бірінші элемент қайтарылады.
    /// Егер итератор бос болса, [`None`] қайтарылады.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Көрсетілген функциядан максималды мән беретін элементті қайтарады.
    ///
    ///
    /// Егер бірнеше элементтер бірдей максимум болса, соңғы элемент қайтарылады.
    /// Егер итератор бос болса, [`None`] қайтарылады.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Көрсетілген салыстыру функциясына қатысты максималды мән беретін элементті қайтарады.
    ///
    ///
    /// Егер бірнеше элементтер бірдей максимум болса, соңғы элемент қайтарылады.
    /// Егер итератор бос болса, [`None`] қайтарылады.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Көрсетілген функциядан минималды мән беретін элементті қайтарады.
    ///
    ///
    /// Егер бірнеше элемент бірдей минималды болса, бірінші элемент қайтарылады.
    /// Егер итератор бос болса, [`None`] қайтарылады.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Көрсетілген салыстыру функциясына қатысты минималды мән беретін элементті қайтарады.
    ///
    ///
    /// Егер бірнеше элемент бірдей минималды болса, бірінші элемент қайтарылады.
    /// Егер итератор бос болса, [`None`] қайтарылады.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Итератордың бағытын өзгертеді.
    ///
    /// Әдетте, итераторлар солдан оңға қарай қайталанады.
    /// `rev()` қолданғаннан кейін итератор оның орнына оңнан солға қарай қайталанады.
    ///
    /// Бұл тек итератордың соңы болған жағдайда ғана мүмкін болады, сондықтан `rev()` тек [`DoubleEndedIterator`] s-де жұмыс істейді.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Жұптардың итераторын жұп контейнерге айналдырады.
    ///
    /// `unzip()` екі топтаманы шығаратын жұптардың бүкіл итераторын тұтынады: бірі жұптардың сол жақ элементтерінен, ал екіншісі оң элементтерінен.
    ///
    ///
    /// Бұл функция, кейбір мағынада, [`zip`]-ке қарама-қарсы.
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Оның барлық элементтерін көшіретін итератор жасайды.
    ///
    /// Бұл сізге `&T`-тен асатын итератор болған кезде пайдалы, бірақ сізге `T`-тен жоғары итератор қажет.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // көшірілгені .map(|&x| x) сияқты
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Барлық элементтерді қосатын итератор жасайды.
    ///
    /// Бұл сізге `&T`-тен асатын итератор болған кезде пайдалы, бірақ сізге `T`-тен жоғары итератор қажет.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // клондалған бүтін сандар үшін .map(|&x| x) сияқты
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Итераторды шексіз қайталайды.
    ///
    /// [`None`]-ке тоқтаудың орнына, итератор қайтадан басынан басталады.Қайталаудан кейін ол қайтадан басында басталады.Тағы да.
    /// Тағы да.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Итератор элементтерін қосады.
    ///
    /// Әр элементті алады, оларды біріктіреді және нәтижені қайтарады.
    ///
    /// Бос итератор типтің нөлдік мәнін қайтарады.
    ///
    /// # Panics
    ///
    /// `sum()` және қарабайыр бүтін типті қайтару кезінде бұл әдіс panic болады, егер есептеу толып кетсе және отладка бекітуі қосылса.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Барлық итератордың бойымен қайталанады, барлық элементтерді көбейтеді
    ///
    /// Бос итератор типтің бір мәнін қайтарады.
    ///
    /// # Panics
    ///
    /// `product()`-ге қоңырау шалғанда және қарабайыр бүтін тип қайтарылады, егер есептеу толып кетсе және отладка бекітуі қосылса, әдіс panic болады.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) осы [`Iterator`] элементтерін басқаларымен салыстырады.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) көрсетілген салыстыру функциясына қатысты осы [`Iterator`] элементтерін басқаларымен салыстырады.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) осы [`Iterator`] элементтерін басқаларымен салыстырады.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) көрсетілген салыстыру функциясына қатысты осы [`Iterator`] элементтерін басқаларымен салыстырады.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Осы [`Iterator`] элементтерінің басқаларымен тең екендігін анықтайды.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Көрсетілген теңдік функциясына қатысты осы [`Iterator`] элементтерінің басқаларымен тең екендігін анықтайды.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Осы [`Iterator`] элементтерінің басқаларымен тең еместігін анықтайды.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Осы [`Iterator`] элементтерінің басқаларына қарағанда [lexicographically](Ord#lexicographical-comparison) аз екенін анықтайды.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Осы [`Iterator`] элементтерінің [lexicographically](Ord#lexicographical-comparison) басқаға кем немесе тең болатындығын анықтайды.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Осы [`Iterator`] элементтерінің басқаларынан [lexicographically](Ord#lexicographical-comparison) артық екенін анықтайды.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Осы [`Iterator`] элементтерінің [lexicographically](Ord#lexicographical-comparison) басқаларынан үлкен немесе тең екендігін анықтайды.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Осы итератордың элементтері сұрыпталғанын тексереді.
    ///
    /// Яғни, `a` әр элементіне және оның келесі `b` элементіне `a <= b` сәйкес келуі керек.Егер итератор дәл нөл немесе бір элемент берсе, `true` қайтарылады.
    ///
    /// Егер `Self::Item` тек `PartialOrd` болса, бірақ `Ord` болмаса, жоғарыдағы анықтама кез-келген екі тармақты салыстыруға келмейтін болса, бұл функция `false` қайтаратынын білдіреді.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Берілген компаратор функциясы арқылы осы итератордың элементтері сұрыпталғанын тексереді.
    ///
    /// Бұл функция `PartialOrd::partial_cmp`-ті пайдаланудың орнына берілген `compare` функциясын қолдана отырып, екі элементтің орналасуын анықтайды.
    /// Бұдан басқа, бұл [`is_sorted`]-ге тең;қосымша ақпарат алу үшін оның құжаттамасын қараңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Берілген кілттерді шығару функциясы арқылы осы итератордың элементтері сұрыпталғанын тексереді.
    ///
    /// Итератор элементтерін тікелей салыстырудың орнына, бұл функция `f` анықтаған элементтердің кілттерін салыстырады.
    /// Бұдан басқа, бұл [`is_sorted`]-ге тең;қосымша ақпарат алу үшін оның құжаттамасын қараңыз.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// [TrustedRandomAccess] қараңыз
    // Ерекше атау-әдіс шешілуіндегі аттардың соқтығысуын болдырмау, #76479 қараңыз.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}