use crate::ops::{ControlFlow, Try};

/// Екі жағынан да элементтер шығара алатын итератор.
///
/// `DoubleEndedIterator`-ті іске асыратын нәрсе, [`Iterator`]-ті іске асыратын нәрсеге қарағанда бір қосымша қабілетке ие: артқы жағынан, сондай-ақ алдыңғы жағынан «заттар» алу мүмкіндігі.
///
///
/// Алға да, артқа да бір диапазонда жұмыс істейтінін және қиылыспайтынын ескеру маңызды: итерация ортасында кездескенде аяқталады.
///
/// [`Iterator`] протоколына ұқсас түрде, бір рет `DoubleEndedIterator` [`None`]-ті [`next_back()`]-тен қайтарады, оны қайта шақыру [`Some`]-ті қайтара алады немесе қайтармауы да мүмкін.
/// [`next()`] және [`next_back()`] осы мақсат үшін ауыстырылады.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Негізгі пайдалану:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Итератордың соңынан элементті алып тастайды.
    ///
    /// Басқа элементтер болмаған кезде `None` қайтарады.
    ///
    /// [trait-level] құжаттарында толығырақ мәліметтер бар.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// «DoubleEndedIterator» әдістерінің элементтері [Iterator`] әдістерінің әдістерінен өзгеше болуы мүмкін:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Итераторды артқы жағынан `n` элементтерімен алға жылжытады.
    ///
    /// `advance_back_by` - [`advance_by`] нұсқасының кері нұсқасы.Бұл әдіс `n` элементтерін [`None`] кездескенге дейін [`next_back`]-ті `n`-ке дейін шақыру арқылы артқы жағынан бастайды.
    ///
    /// `advance_back_by(n)` егер итератор `n` элементтерімен алға жылжып кетсе, [`Ok(())`] қайтарады немесе егер [`None`] кездессе, [`Err(k)`] болады, мұндағы `k`-итератордың элементтері бітпей тұрып алға басқан элементтер саны (яғни
    /// итератордың ұзындығы).
    /// `k` әрқашан `n`-тен аз болатынын ескеріңіз.
    ///
    /// `advance_back_by(0)` қоңырауына қоңырау шалу ешқандай элементтерді тұтынбайды және әрқашан [`Ok(())`] қайтарады.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // тек `&3` өткізіп жіберілді
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Итератордың соңынан `n`th элементін қайтарады.
    ///
    /// Бұл [`Iterator::nth()`]-тің кері нұсқасы.
    /// Көптеген индекстеу операциялары сияқты, санау нөлден басталады, сондықтан `nth_back(0)` бірінші мәнді соңынан, `nth_back(1)` екіншіден және т.б.
    ///
    ///
    /// Аяқталған және қайтарылған элемент арасындағы барлық элементтер, соның ішінде қайтарылған элемент тұтынылатынын ескеріңіз.
    /// Бұл сонымен қатар `nth_back(0)`-ті бір итераторда бірнеше рет шақырған кезде әртүрлі элементтер қайтарылатындығын білдіреді.
    ///
    /// `nth_back()` егер `n` итератордың ұзындығынан үлкен немесе тең болса, [`None`] мәнін қайтарады.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// `nth_back()` нөміріне бірнеше рет қоңырау шалу итергішті кері қайтармайды:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Егер `n + 1` элементтерінен аз болса, `None` қайтару:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Бұл [`Iterator::try_fold()`] кері нұсқасы: ол итератордың артқы жағынан басталатын элементтерді алады.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Ол қысқа тұйықталғандықтан, қалған элементтер итератор арқылы қол жетімді.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Итератор элементтерін артқы жағынан бастап жалғыз, соңғы мәнге дейін төмендететін итератор әдісі.
    ///
    /// Бұл [`Iterator::fold()`] нұсқасының кері нұсқасы: итератордың артқы жағынан бастап элементтерді алады.
    ///
    /// `rfold()` екі аргумент алады: бастапқы мән және екі аргументпен жабылу: 'accumulator' және элемент.
    /// Жабу аккумуляторда келесі итерация үшін болуы керек мәнді қайтарады.
    ///
    /// Бастапқы мән-бұл аккумулятордың бірінші қоңырау кезінде алатын мәні.
    ///
    /// Осы жабуды итератордың барлық элементтеріне қолданғаннан кейін, `rfold()` аккумуляторды қайтарады.
    ///
    /// Бұл операция кейде 'reduce' немесе 'inject' деп аталады.
    ///
    /// Бүктеу сізде бірдеңе жинақталған кезде пайдалы болады және одан бір мән шығарғыңыз келеді.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // а-ның барлық элементтерінің қосындысы
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Бұл мысал жолды бастапқы мәннен бастап және әр элементтің артқы жағынан алдыңғы жағына дейін жалғастырады:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Артқы жағынан предикатты қанағаттандыратын итератор элементін іздейді.
    ///
    /// `rfind()` `true` немесе `false` қайтаратын жабуды алады.
    /// Ол осы жабылуды итератордың әр элементіне, аяғынан бастап қолданады және егер олардың кез-келгені `true` мәнін берсе, онда `rfind()` [`Some(element)`] мәнін береді.
    /// Егер олардың барлығы `false` мәнін қайтарса, ол [`None`] мәнін қайтарады.
    ///
    /// `rfind()` қысқа тұйықталу;басқаша айтқанда, ол жабылу `true` қайтарылғаннан кейін өңдеуді тоқтатады.
    ///
    /// `rfind()` сілтемені қабылдайтындықтан және көптеген итераторлар сілтемелердің үстінен қайталанатындықтан, бұл аргумент екі сілтеме болатын түсініксіз жағдайға әкеледі.
    ///
    /// Сіз бұл әсерді `&&x` көмегімен төмендегі мысалдардан көре аласыз.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Бірінші `true`-ті тоқтату:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // біз әлі де `iter` қолдана аламыз, өйткені элементтер көп.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}