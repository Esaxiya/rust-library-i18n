/// Оның нақты ұзындығын білетін итератор.
///
/// Көптеген [Итераторлар] қанша рет қайталанатынын білмейді, ал кейбіреулері.
/// Егер итератор қанша рет қайталай алатынын білсе, бұл ақпаратқа қол жетімділік пайдалы болуы мүмкін.
/// Мысалы, егер сіз артқа қарай итерация жасағыңыз келсе, жақсы бастама оның соңы қайда екенін білуіңіз керек.
///
/// `ExactSizeIterator` іске асырған кезде сіз [`Iterator`]-ті де қолдануыңыз керек.
/// Мұны істеген кезде, [`Iterator::size_hint`]*іске асырылуы итератордың нақты мөлшерін қайтаруы керек*.
///
/// [`len`] әдісі әдепкі іске асыруға ие, сондықтан оны әдетте қолдануға болмайды.
/// Дегенмен, сіз әдепкіге қарағанда анағұрлым тиімді іске асыруды қамтамасыз ете аласыз, сондықтан оны бұл жағдайда жоққа шығару мағынасы бар.
///
///
/// Бұл trait қауіпсіз trait екенін ескеріңіз, сондықтан қайтарылған ұзындықтың дұрыс екендігіне *кепілдік бере алмайды* және * мүмкін емес.
/// Демек, `unsafe` коды **[`Iterator::size_hint`] дұрыстығына** сенбеуі керек.
/// Тұрақсыз және қауіпті [`TrustedLen`](super::marker::TrustedLen) trait бұған қосымша кепілдік береді.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Негізгі пайдалану:
///
/// ```
/// // ақырлы диапазон оның қанша рет қайталанатынын нақты біледі
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// [module-level docs]-те біз [`Iterator`]-ті қолдандық, `Counter`.
/// Ол үшін `ExactSizeIterator` енгізейік:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Біз қайталанудың қалған санын оңай есептей аламыз.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Енді біз оны қолдана аламыз!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Итератордың нақты ұзындығын қайтарады.
    ///
    /// Іске асыру итератордың [`None`] мәнін қайтармас бұрын [`Some(T)`] мәнінен [`Some(T)`] мәнінен көп қайтаратынын қамтамасыз етеді.
    ///
    /// Бұл әдіс әдепкі іске асыруға ие, сондықтан оны тікелей енгізбеу керек.
    /// Алайда, егер сіз тиімді іске асыруды қамтамасыз ете алсаңыз, мұны жасай аласыз.
    /// Мысал үшін [trait-level] құжаттарын қараңыз.
    ///
    /// Бұл функция [`Iterator::size_hint`] функциясымен бірдей қауіпсіздік кепілдіктеріне ие.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// // ақырлы диапазон оның қанша рет қайталанатынын нақты біледі
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Бұл тұжырым тым қорғанысты, бірақ инвариантты тексереді
        // trait кепілдік берген.
        // Егер бұл trait rust-ішкі болса, біз debug_assert қолдана аламыз !;assert_eq!барлық Rust қолданушыларының орындалуын тексереді.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Итератор бос болса, `true` қайтарады.
    ///
    /// Бұл әдіс [`ExactSizeIterator::len()`] көмегімен әдепкі іске асыруға ие, сондықтан оны өзіңіз енгізудің қажеті жоқ.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}