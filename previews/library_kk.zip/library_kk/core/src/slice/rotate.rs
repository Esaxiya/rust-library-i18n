// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// `[mid-left, mid+right)` диапазонын `mid` кезіндегі элемент бірінші элемент болатындай етіп айналдырады.Эквивалентті `left` элементтерін солға немесе `right` элементтерін оңға бұрады.
///
/// # Safety
///
/// Көрсетілген диапазон оқу және жазу үшін жарамды болуы керек.
///
/// # Algorithm
///
/// 1-алгоритм `left + right` шамалары үшін немесе үлкен `T` үшін қолданылады.
/// Элементтер `mid - left`-тен басталатын және `left + right` модулі бойынша `right` қадамдарымен алға жылжытылатын соңғы позицияларына ауысады, осылайша тек бір уақытша қажет.
/// Ақыр соңында, біз `mid - left`-ге қайта келеміз.
/// Алайда, егер `gcd(left + right, right)` 1 болмаса, жоғарыда аталған қадамдар элементтерді өткізіп жіберді.
/// Мысалға:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Бақытымызға орай, аяқталған элементтер арасындағы өткізіп жіберілгендер саны әрқашан тең болады, сондықтан біз бастапқы позициямыздың орнын толтырып, көп айналым жасай аламыз (айналымдардың жалпы саны-`gcd(left + right, right)` value)).
///
/// Ақырғы нәтиже-барлық элементтер бір рет және бір рет аяқталады.
///
/// Алгоритм 2 егер `left + right` үлкен болса, бірақ `min(left, right)` стек буферіне сыйып кететіндей аз болса қолданылады.
/// `min(left, right)` элементтері буферге көшіріледі, қалғандары үшін `memmove` қолданылады, ал буфердегі элементтер пайда болған жердің қарама-қарсы жағындағы тесікке жылжытылады.
///
/// Векторландыруға болатын алгоритмдер `left + right` жеткілікті үлкен болғанда жоғарыда көрсетілгендерден асып түседі.
/// 1-алгоритмді векторизациялауға болады және көптеген раундтарды бір уақытта орындайды, бірақ орта есеппен `left + right` болғанға дейін өте аз айналымдар болады, және бір раундтың ең жаман жағдайы әрдайым болады.
/// Оның орнына 3 алгоритмі `min(left, right)` элементтерін кішігірім айналу мәселесі қалғанға дейін бірнеше рет ауыстыруды қолданады.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// кезде `left < right` ауыстыру сол жақтан орын алады.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. егер бұл жағдайлар тексерілмеген болса, төмендегі алгоритмдер сәтсіздікке ұшырауы мүмкін
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Алгоритм 1 Микробменмарксттер кездейсоқ ауысулардың орташа өнімділігі шамамен `left + right == 32` дейін жақсы екенін көрсетеді, бірақ ең нашар көрсеткіш 16-ға жуықтайды.
            // 24 орта жол ретінде таңдалды.
            // Егер `T` өлшемі 4 `usize`-ден үлкен болса, онда бұл алгоритм басқа алгоритмдерден де асып түседі.
            //
            //
            let x = unsafe { mid.sub(left) };
            // бірінші турдың басталуы
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` қолмен `gcd(left + right, right)` есептеу арқылы табуға болады, бірақ gcd-ді жанама әсер ретінде есептейтін бір циклды орындау керек, содан кейін қалған бөлігін жасау
            //
            //
            let mut gcd = right;
            // Эталондық көрсеткіштер уақытша уақытты бір рет оқудың орнына бір рет артқа көшірудің, содан кейін уақытша жазудың орнына жылдам ауыстырудың жылдамырақ болатындығын көрсетеді.
            // Бұл уақытша уақытты ауыстыру немесе ауыстыру циклде екеуін басқарудың орнына бір ғана жад мекен-жайын қолданатындығына байланысты болуы мүмкін.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // `i` ұлғайтудың орнына оның шекарадан тыс екенін тексерудің орнына, `i` келесі өсім бойынша шекарадан тыс шығатынын тексереміз.
                // Бұл көрсеткіштердің немесе `usize` кез келген оралуына жол бермейді.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // бірінші айналымның аяқталуы
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // егер бұл `left + right >= 15` болса, бұл шартты болуы керек
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // бөлікті көбірек дөңгелектермен аяқтаңыз
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` өлшемі нөлге тең емес, сондықтан оның мөлшеріне бөлген жөн.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // 2-алгоритм. `[T; 0]` мұның T-ге сәйкес келуін қамтамасыз етеді
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // 3-алгоритм. Ауыстырудың баламалы тәсілі бар, оған осы алгоритмнің соңғы ауыстырылатын жерін табуды және осы алгоритм сияқты іргелес бөліктерді ауыстырудың орнына сол соңғы бөлікті қолдануды жатқызуға болады, бірақ бұл әлі де жылдам.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Алгоритм 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}