//! Тіліктердің итераторлары қолданатын макростар.

// Бос және len сызықтары өнімділікке үлкен өзгеріс әкеледі
macro_rules! is_empty {
    // ZST итераторының ұзындығын кодтау тәсілі бұл ZST үшін де, ZST емес үшін де жұмыс істейді.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Кейбір шектеулерден құтылу үшін (`position` қараңыз), біз ұзындығын күтпеген әдіспен есептейміз.
// («Codegen/slice-position-bounds-check» арқылы тексерілген.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // біз кейде қауіпті блок ішінде қолданыламыз

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Бұл _cannot_ `unchecked_sub` пайдаланады, өйткені біз ZST кесінділерінің ұзын итераторларының ұзындығын көрсету үшін орауға тәуелдіміз.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Біз `start <= end` екенін білеміз, сондықтан `offset_from`-тен жақсы жасай аламыз, оған қол қою қажет.
            // Мұнда тиісті жалаушаларды орнату арқылы біз LLVM-ге айта аламыз, бұл шекаралық тексерулерді жоюға көмектеседі.
            // ҚАУІПСІЗДІК: инвариантты тип бойынша, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Сондай-ақ, LLVM-ге көрсеткіштердің типтік еселіктерден бөлек екенін айта отырып, ол `len() == 0`-ті `(end - start) < size` орнына `start == end`-ке дейін оңтайландыруы мүмкін.
            //
            // ҚАУІПСІЗДІК: инвариант типі бойынша көрсеткіштер теңестіріледі
            //         олардың арасындағы қашықтық пуинт мөлшерінің еселігі болуы керек
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// `Iter` және `IterMut` итераторларының жалпы анықтамасы
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Бірінші элементті қайтарады және итератордың басын 1-ге алға жылжытады.
        // Қапталған функциямен салыстырғанда өнімділікті айтарлықтай жақсартады.
        // Итератор бос болмауы керек.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Соңғы элементті қайтарады және итератордың ұшын 1-ге артқа жылжытады.
        // Қапталған функциямен салыстырғанда өнімділікті айтарлықтай жақсартады.
        // Итератор бос болмауы керек.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // T ZST болғанда, қайталағыштың соңын `n` артқа жылжыту арқылы итераторды кішірейтеді.
        // `n` `self.len()` аспауы керек.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Итератордан тілім жасауға арналған көмекші функция.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // ҚАУІПСІЗДІК: итератор тілімшеден меңзермен жасалған
                // `self.ptr` және ұзындығы `len!(self)`.
                // Бұл `from_raw_parts` үшін барлық алғышарттардың орындалуына кепілдік береді.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Итератордың басталуын `offset` элементтерімен алға жылжытуға арналған көмекші функция, ескі стартты қайтарады.
            //
            // Қауіпті, себебі офсеттік деңгей `self.len()` аспауы керек.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // ҚАУІПСІЗДІК: қоңырау шалушы `offset` `self.len()` аспайтынына кепілдік береді,
                    // сондықтан бұл жаңа көрсеткіш `self` ішінде және нөлдік емес екеніне кепілдік береді.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Итератордың ұшын `offset` элементтерімен артқа жылжытуға, жаңа ұшын қайтаруға арналған көмекші функция.
            //
            // Қауіпті, себебі офсеттік деңгей `self.len()` аспауы керек.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // ҚАУІПСІЗДІК: қоңырау шалушы `offset` `self.len()` аспайтынына кепілдік береді,
                    // ол `isize`-тен асып кетпеуіне кепілдік береді.
                    // Сонымен, алынған көрсеткіш `slice` шекарасында болады, ол `offset` үшін басқа талаптарды орындайды.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // кесінділермен жүзеге асырылуы мүмкін, бірақ бұл тексеруді болдырмайды

                // ҚАУІПСІЗДІК: `assume` қоңыраулары тілімнің басталу көрсеткішінен бастап қауіпсіз
                // нөлге тең болмауы керек, ал ZST емес кесінділерде нөлдік емес аяқтауыш болуы керек.
                // `next_unchecked!` нөміріне қоңырау шалу қауіпсіз, өйткені алдымен итератордың бос екенін тексереміз.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Бұл итератор қазір бос.
                    if mem::size_of::<T>() == 0 {
                        // Біз мұны осылай жасауымыз керек, өйткені `ptr` ешқашан 0 болмауы мүмкін, бірақ `end` болуы мүмкін (ораманың арқасында).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // ҚАУІПСІЗДІК: егер T ZST болмаса, end 0-ге тең болмайды, өйткені ptr 0-ге тең емес және end>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // ҚАУІПСІЗДІК: Біз шекарамыз.`post_inc_start` тіпті ZST үшін дұрыс нәрсе жасайды.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Біз `try_fold` пайдаланатын әдепкі іске асыруды жоққа шығарамыз, өйткені бұл қарапайым іске қосу LLVM IR аз шығарады және тез құрастырылады.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Біз `try_fold` пайдаланатын әдепкі іске асыруды жоққа шығарамыз, өйткені бұл қарапайым іске қосу LLVM IR аз шығарады және тез құрастырылады.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Біз `try_fold` пайдаланатын әдепкі іске асыруды жоққа шығарамыз, өйткені бұл қарапайым іске қосу LLVM IR аз шығарады және тез құрастырылады.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Біз `try_fold` пайдаланатын әдепкі іске асыруды жоққа шығарамыз, өйткені бұл қарапайым іске қосу LLVM IR аз шығарады және тез құрастырылады.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Біз `try_fold` пайдаланатын әдепкі іске асыруды жоққа шығарамыз, өйткені бұл қарапайым іске қосу LLVM IR аз шығарады және тез құрастырылады.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Біз `try_fold` пайдаланатын әдепкі іске асыруды жоққа шығарамыз, өйткені бұл қарапайым іске қосу LLVM IR аз шығарады және тез құрастырылады.
            // Сондай-ақ, `assume` шекараны тексеруден аулақ болады.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // ҚАУІПСІЗДІК: бізде циклдің инвариантты болуы кепілдендірілген:
                        // кезде `i >= n`, `self.next()` `None` қайтарады және цикл үзіледі.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Біз `try_fold` пайдаланатын әдепкі іске асыруды жоққа шығарамыз, өйткені бұл қарапайым іске қосу LLVM IR аз шығарады және тез құрастырылады.
            // Сондай-ақ, `assume` шекараны тексеруден аулақ болады.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // ҚАУІПСІЗДІК: `i` `n`-тен төмен болуы керек, өйткені ол `n`-тен басталады
                        // және тек азаяды.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // ҚАУІПСІЗДІК: қоңырау шалушы `i` шектеулі екеніне кепілдік беруі керек
                // негізгі тілім, сондықтан `i` `isize`-тен асып кете алмайды, ал қайтарылған сілтемелерге тілімнің элементіне сілтеме жасалады және осылайша жарамды болады.
                //
                // Сондай-ақ, қоңырау шалушы бізді ешқашан бірдей индекспен шақырмайтындығымызға кепілдік беретінін және осы подциклге кіретін басқа әдістер шақырылмайтындығына кепілдік беретіндігін ескеріңіз, сондықтан қайтарылған сілтеме өзгертілген жағдайда жарамды
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // кесінділермен жүзеге асырылуы мүмкін, бірақ бұл тексеруді болдырмайды

                // ҚАУІПСІЗДІК: `assume` қоңыраулары қауіпсіз, өйткені тілімнің басталу көрсеткіші нөл болмауы керек,
                // және ZST емес кесінділерде де нөлдік емес көрсеткіш болуы керек.
                // `next_back_unchecked!` нөміріне қоңырау шалу қауіпсіз, өйткені алдымен итератордың бос екенін тексереміз.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Бұл итератор қазір бос.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // ҚАУІПСІЗДІК: Біз шекарамыз.`pre_dec_end` тіпті ZST үшін дұрыс нәрсе жасайды.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}