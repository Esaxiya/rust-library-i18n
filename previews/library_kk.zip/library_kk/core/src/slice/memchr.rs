// Түпнұсқа енгізу rust-memchr-ден алынды.
// Авторлық құқық 2015 Эндрю Галлант, блюс және Николас Кох

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Қысқартуды қолданыңыз.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Егер `x` құрамында нөлдік байт болса, `true` қайтарады.
///
/// *Matters Computational*, Дж. Арндт:
///
/// «Идея-байттардың әрқайсысынан біреуін алып тастау, содан кейін қарыздың ең маңыздыға дейін көбейтілген байттарын іздеу.
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// `text` ішіндегі `x` байтына сәйкес келетін бірінші индексті қайтарады.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Шағын кесектерге арналған жылдам жол
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Бір уақытта екі `usize` сөзін оқып, бір байт мәнін іздеңіз.
    //
    // `text`-ті үш бөлікке бөліңіз
    // - тураланбаған бастапқы бөлік, бірінші сөздің алдында мәтіннің мекен-жайы тураланған
    // - дене, бір уақытта 2 сөзбен сканерлеңіз
    // - соңғы қалған бөлігі, <2 сөз мөлшері

    // тураланған шекараға дейін іздеу
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // мәтіннің негізгі бөлігін іздеу
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // ҚАУІПСІЗДІК: уақыттың предикаты кем дегенде 2 * usize_bytes қашықтыққа кепілдік береді
        // жылжу мен тілімнің соңы арасында.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // сәйкес келетін байт болса, үзіліс
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Дене циклы тоқтаған нүктеден кейін байтты табыңыз.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// `text` ішіндегі `x` байтына сәйкес келетін соңғы индексті қайтарады.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Бір уақытта екі `usize` сөзін оқып, бір байт мәнін іздеңіз.
    //
    // Split `text` үш бөлікке бөлінеді:
    // - тураланбаған құйрық, соңғы сөзден кейін мәтіндегі адрес тураланғаннан кейін,
    // - бір уақытта 2 сөзбен сканерленген дене,
    // - бірінші қалған байт, <2 сөз өлшемі.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Біз мұны тек префикс пен жұрнақтың ұзындығын алу үшін атаймыз.
        // Ортасында біз әрқашан екі бөлікті бірден өңдейміз.
        // ҚАУІПСІЗДІК: `[u8]`-ті `[usize]`-ге ауыстыру, `align_to` өңдейтін өлшем айырмашылықтарын қоспағанда, қауіпсіз.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Мәтіннің негізгі бөлігін іздеңіз, min_aligned_offset кесіп өтпейтіндігіне көз жеткізіңіз.
    // ығысу әрқашан тураланған, сондықтан `>`-ті тексеру жеткілікті және мүмкін болатын асып кетуден сақтайды.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // ҚАУІПСІЗДІК: ығысу len, suffix.len(), егер ол үлкен болса, басталады
        // min_aligned_offset (prefix.len()) қалған қашықтық кем дегенде 2 * түйінді_байт.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Егер сәйкес келетін байт болса, үзіліс жасаңыз.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Дене циклінің тоқтаған нүктесіне дейін байтты табыңыз.
    text[..offset].iter().rposition(|elt| *elt == x)
}