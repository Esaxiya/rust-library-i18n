//! ASCII `[u8]` операциялары.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Осы тілімдегі барлық байттардың ASCII ауқымында екенін тексереді.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Екі тілімнің ASCII регистрге сәйкес келмейтін сәйкестігін тексереді.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)`-мен бірдей, бірақ уақытша материалдарды бөлмей және көшірмей.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Бұл тілімді орнына ASCII бас әріптің эквивалентіне айналдырады.
    ///
    /// 'a'-тен 'z'-ке дейінгі ASCII әріптері 'A'-тен 'Z'-ге дейін салыстырылады, бірақ ASCII емес әріптер өзгермейді.
    ///
    /// Бұрыннан өзгермеген жаңа жоғарғы мәнді қайтару үшін [`to_ascii_uppercase`] пайдаланыңыз.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Бұл тілімді орнына ASCII кіші әріптің баламасына айналдырады.
    ///
    /// 'A'-тен 'Z'-ке дейінгі ASCII әріптері 'a'-тен 'z'-ге дейін салыстырылады, бірақ ASCII емес әріптер өзгермейді.
    ///
    /// Бұрыннан өзгермеген жаңа кіші мәнді қайтару үшін [`to_ascii_lowercase`] пайдаланыңыз.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Егер `v` сөзіндегі байт nonascii (>=128) болса, `true` береді.
/// `../str/mod.rs`-тен Snarfed, ол utf8 тексеру үшін ұқсас нәрсе жасайды.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Белгіленген уақыттағы операциялардың орнына уақыт бойынша пайдалану операцияларын қолданатын ASCII оңтайландырылған тесті (мүмкіндігінше).
///
/// Біз қолданатын алгоритм өте қарапайым.Егер `s` тым қысқа болса, біз әр байтты тексеріп, оны аяқтаймыз.Әйтпесе:
///
/// - Реттелмеген жүктеме бар бірінші сөзді оқыңыз.
/// - Меңзерді туралаңыз, кейінгі сөздерді тураланған жүктемелермен соңына дейін оқыңыз.
/// - Соңғы `usize`-ті `s`-тен тураланбаған жүктемемен оқыңыз.
///
/// Егер осы жүктемелердің кез-келгені `contains_nonascii` (above) шындыққа айналатын нәрсе шығарса, онда біз оның жалған екенін білеміз.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Егер біз сөзді орындаудан ештеңе ұтпасақ, скалярлық айналымға қайта оралыңыз.
    //
    // Біз мұны `size_of::<usize>()` `usize` үшін жеткіліксіз туралауға болатын архитектуралар үшін жасаймыз, өйткені бұл edge таңқаларлық жағдай.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Біз әрдайым бірінші сөзді тураланбаған түрде оқимыз, яғни `align_offset` дегеніміз
    // 0, біз бірдей мәнді қайтадан тураланған оқылым үшін оқимыз.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // ҚАУІПСІЗДІК: Біз `len < USIZE_SIZE`-ті жоғарыда растаймыз.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Біз мұны жоғарыда, жанама түрде тексердік.
    // `offset_to_aligned` не `align_offset`, не `USIZE_SIZE` екенін ескеріңіз, екеуі де жоғарыда тексерілген.
    //
    debug_assert!(offset_to_aligned <= len);

    // ҚАУІПСІЗДІК: word_ptr-бұл (дұрыс тураланған) usize ptr, біз оны оқу үшін қолданамыз
    // тілімнің ортаңғы бөлігі.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` - циклды тексеруге қолданылатын `word_ptr` байт индексі.
    let mut byte_pos = offset_to_aligned;

    // Паранойа туралануды тексереді, өйткені біз көптеген теңестірілмеген жүктемелерді жасаймыз.
    // Іс жүзінде бұл `align_offset`-те қатеге тыйым салу мүмкін емес болуы керек.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Кейінгі сөздерді соңғы тураланған сөзге дейін оқып шығыңыз, тек кейінірек құйрықты тексеру кезінде жасалатын соңғы тураланған сөзді қоспағанда, құйрық әрдайым бір branch `byte_pos == len` дейін ең көбі бір `usize` болатындығына көз жеткізіңіз.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Ақыл-ойдың оқылымның шектеулі екенін тексеріңіз
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Біздің `byte_pos` туралы жорамалдарымыз да солай.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // ҚАУІПСІЗДІК: Біз `word_ptr` дұрыс тураланғанын білеміз (сондықтан
        // `align_offset`), және бізде `word_ptr` пен соңына дейін байт жеткілікті екенін білеміз
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // ҚАУІПСІЗДІК: Біз бұл `byte_pos <= len - USIZE_SIZE` екенін білеміз, бұл дегеніміз
        // осы `add`-тен кейін, `word_ptr` ең соңында бір рет болады.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Тек бір `usize` қалғанын тексеру үшін денсаулықты тексеру.
    // Бұған біздің цикл жағдайымыз кепілдік беруі керек.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // ҚАУІПСІЗДІК: Бұл біз басында тексеретін `len >= USIZE_SIZE`-ке негізделген.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}