//! Бөлшектерді сұрыптау
//!
//! Бұл модульде Орсон Питерстің шаблондарды жеңетін кворссортына негізделген сұрыптау алгоритмі бар: <https://github.com/orlp/pdqsort>
//!
//!
//! Тұрақсыз сұрыптау libcore-мен үйлесімді, себебі ол біздің тұрақты сұрыптауды жүзеге асыруға қарағанда, жадты бөлмейді.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Түсірген кезде `src`-тен `dest`-ке көшіреді.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // ҚАУІПСІЗДІК: Бұл көмекші сынып.
        //          Дұрыс болу үшін оның қолданылуын қараңыз.
        //          Атап айтқанда, `src` және `dst` `ptr::copy_nonoverlapping` талаптарына сәйкес келмейтініне сенімді болу керек.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Үлкен немесе тең элемент кездескенше бірінші элементті оңға жылжытады.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // ҚАУІПСІЗДІК: Төмендегі қауіпті операциялар байланыстырылған тексерусіз индекстеуді қамтиды (`get_unchecked` және `get_unchecked_mut`)
    // және (`ptr::copy_nonoverlapping`) жадын көшіру.
    //
    // а.Индекстеу:
    //  1. Массивтің өлшемін>=2 етіп тексердік.
    //  2. Біз жасайтын барлық индекстеу әрқашан ең көп дегенде {0 <= index < len} аралығында болады.
    //
    // б.Жадты көшіру
    //  1. Жарамдылығына кепілдік берілген сілтемелерге сілтеме аламыз.
    //  2. Олар бір-бірімен қабаттаса алмайды, өйткені біз кесінділердің айырмашылық индекстеріне көрсеткіштер аламыз.
    //     Атап айтқанда, `i` және `i-1`.
    //  3. Егер кесінді дұрыс тураланған болса, элементтер дұрыс тураланған.
    //     Тілімнің дұрыс тураланғанына көз жеткізу қоңырау шалушының міндеті.
    //
    // Толығырақ білу үшін төмендегі түсініктемелерді қараңыз.
    unsafe {
        // Егер алғашқы екі элемент ретсіз болса ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Бірінші элементті стекке бөлінген айнымалыға оқыңыз.
            // Егер келесі салыстыру әрекеті panics болса, `hole` түсіп кетеді және автоматты түрде элементті тілімге қайта жазады.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // `I`-ші элементті бір орынға солға қарай жылжытыңыз, осылайша тесікті оңға жылжытыңыз.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` құлайды және осылайша `tmp`-ті `v`-тегі қалған тесікке көшіреді.
        }
    }
}

/// Соңғы элементті кіші немесе тең элемент кездескенше солға жылжытады.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // ҚАУІПСІЗДІК: Төмендегі қауіпті операциялар байланыстырылған тексерусіз индекстеуді қамтиды (`get_unchecked` және `get_unchecked_mut`)
    // және (`ptr::copy_nonoverlapping`) жадын көшіру.
    //
    // а.Индекстеу:
    //  1. Массивтің өлшемін>=2 етіп тексердік.
    //  2. Біз жасайтын барлық индекстеу әрқашан ең көп дегенде `0 <= index < len-1` аралығында болады.
    //
    // б.Жадты көшіру
    //  1. Жарамдылығына кепілдік берілген сілтемелерге сілтеме аламыз.
    //  2. Олар бір-бірімен қабаттаса алмайды, өйткені біз кесінділердің айырмашылық индекстеріне көрсеткіштер аламыз.
    //     Атап айтқанда, `i` және `i+1`.
    //  3. Егер кесінді дұрыс тураланған болса, элементтер дұрыс тураланған.
    //     Тілімнің дұрыс тураланғанына көз жеткізу қоңырау шалушының міндеті.
    //
    // Толығырақ білу үшін төмендегі түсініктемелерді қараңыз.
    unsafe {
        // Егер соңғы екі элемент ретсіз болса ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Соңғы элементті стекке бөлінген айнымалы түрінде оқыңыз.
            // Егер келесі салыстыру әрекеті panics болса, `hole` түсіп кетеді және автоматты түрде элементті тілімге қайта жазады.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // `I`-ші элементті бір орынға оңға қарай жылжытыңыз, сөйтіп тесікті солға жылжытыңыз.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` құлайды және осылайша `tmp`-ті `v`-тегі қалған тесікке көшіреді.
        }
    }
}

/// Тілімді ішінара бірнеше рет реттелмеген элементтерді ауыстыру арқылы сұрыптайды.
///
/// Егер кесінді соңында сұрыпталған болса, `true` қайтарады.Бұл функция ең нашар *O*(*n*) болып табылады.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Ауыстырылатын көршілес тыс жұптардың максималды саны.
    const MAX_STEPS: usize = 5;
    // Егер тілім бұдан қысқа болса, ешқандай элементтерді ауыстырмаңыз.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // ҚАУІПСІЗДІК: Біз `i < len` көмегімен нақты тексеруді жасадық.
        // Біздің барлық кейінгі индекстеу тек `0 <= index < len` ауқымында
        unsafe {
            // Көршілес, тәртіптен тыс элементтердің келесі жұбын табыңыз.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Біттік пе?
        if i == len {
            return true;
        }

        // Өнімділік құны бар элементтерді қысқа массивтерге ауыстырмаңыз.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Табылған жұп элементтерін ауыстырыңыз.Бұл оларды дұрыс тәртіпке келтіреді.
        v.swap(i - 1, i);

        // Кішірек элементті солға жылжытыңыз.
        shift_tail(&mut v[..i], is_less);
        // Үлкен элементті оңға жылжытыңыз.
        shift_head(&mut v[i..], is_less);
    }

    // Шектелген қадамдар бойынша бөлімді сұрыптай алмадым.
    false
}

/// *O*(*n*^ 2) ең нашар болатын кірістіруді сұрыптау арқылы тілімді сұрыптайды.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Х00Х-ны *O*(*n*\*log(* n*)) ең нашар жағдайға кепілдік беретін үйінді портын пайдаланып сұрыптайды.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Бұл екілік үйме инвариантты `parent >= child`-ті құрметтейді.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // `node` балалары:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Үлкен баланы таңдаңыз.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Егер инвариант `node` деңгейінде болса, тоқтаңыз.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Үлкен баламен `node` ауыстырыңыз, бір адым төмен жылжытыңыз және електен өткізіңіз.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Үйінді сызықтық уақытта құрастырыңыз.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Үйіндіден максималды элементтерді шығарыңыз.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// `v`-ті `pivot`-тен кіші элементтерге бөледі, содан кейін `pivot`-тен үлкен немесе оған тең элементтер болады.
///
///
/// `pivot`-тен кіші элементтер санын қайтарады.
///
/// Бөлу тармақталу операцияларының құнын барынша азайту мақсатында блок-блок бойынша орындалады.
/// Бұл идея [BlockQuicksort][pdf] қағазында көрсетілген.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Әдеттегі блоктағы элементтер саны.
    const BLOCK: usize = 128;

    // Бөлу алгоритмі келесі қадамдарды аяқталғанға дейін қайталайды:
    //
    // 1. Бұрылысқа тең немесе үлкен элементтерді анықтау үшін блокты сол жағынан қадағалаңыз.
    // 2. Бұрылғыштан кіші элементтерді анықтау үшін блокты оң жақтан қадағалаңыз.
    // 3. Анықталған элементтерді сол және оң жақ арасында ауыстырыңыз.
    //
    // Элементтер блогы үшін келесі айнымалыларды сақтаймыз:
    //
    // 1. `block` - Блоктағы элементтер саны.
    // 2. `start` - `offsets` жиымына меңзерді бастаңыз.
    // 3. `end` - `offsets` жиымына көрсеткішті аяқтаңыз.
    // 4. `офсеттер, блок ішіндегі тәртіптен тыс элементтердің көрсеткіштері.

    // Ағымдағы блок сол жақта (`l`-тен `l.add(block_l)`)-ге дейін).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Ағымдағы блок оң жақта (`r.sub(block_r)` to `r`) бастап).
    // ҚАУІПСІЗДІК: .add() құжаттамасында `vec.as_ptr().add(vec.len())` әрқашан қауіпсіз екендігі ерекше айтылады
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Біз VLA-ны алған кезде, `min(v.len(), 2 * BLOCK) ұзындығының бір массивін құрып көріңіз
    // ұзындығы `BLOCK` екі өлшемді массивке қарағанда.VLA-лар кэштен тиімді болуы мүмкін.

    // `l` (inclusive) және `r` (exclusive) көрсеткіштері арасындағы элементтер санын қайтарады.
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Біз `l` және `r` жақындаған кезде блок-блокты бөлуге дайынбыз.
        // Содан кейін қалған элементтерді бөлу үшін бірнеше қосымша жұмыстар жасаймыз.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Қалған элементтердің саны (бұрылыспен салыстырылмайды).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Блоктың өлшемдерін сол және оң жақ блоктары қабаттаспайтындай етіп реттеңіз, бірақ барлық қалған аралықты жабатындай етіп туралаңыз.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // `block_l` элементтерін сол жағынан қадағалаңыз.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // ҚАУІПСІЗДІК: Төмендегі қауіпсіздік техникасы бойынша операциялар `offset` пайдалануды қамтиды.
                //         Функция талап ететін шарттарға сәйкес біз оларды қанағаттандырамыз, өйткені:
                //         1. `offsets_l` стекпен бөлінген және осылайша бөлек бөлінген объект болып саналады.
                //         2. `is_less` функциясы `bool` мәнін қайтарады.
                //            `bool` құюы ешқашан `isize` асып кетпейді.
                //         3. Біз `block_l` `<= BLOCK` болатынына кепілдік бердік.
                //            Сонымен қатар, бастапқыда `end_l` стекте жарияланған `offsets_` басталу көрсеткішіне орнатылды.
                //            Осылайша, біз ең нашар жағдайда да (`is_less` барлық шақырулары жалған болып шығады) біз ең көп дегенде 1 байт соңына жететінімізді білеміз.
                //        Мұндағы тағы бір қауіпті операция-бұл `elem`-ті ажырату.
                //        Алайда, бастапқыда `elem` әрқашан жарамды болатын тілімнің басталу көрсеткіші болды.
                unsafe {
                    // Тармақсыз салыстыру.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // `block_r` элементтерін оң жағынан қадағалаңыз.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // ҚАУІПСІЗДІК: Төмендегі қауіпсіздік техникасы бойынша операциялар `offset` пайдалануды қамтиды.
                //         Функция талап ететін шарттарға сәйкес біз оларды қанағаттандырамыз, өйткені:
                //         1. `offsets_r` стекпен бөлінген және осылайша бөлек бөлінген объект болып саналады.
                //         2. `is_less` функциясы `bool` мәнін қайтарады.
                //            `bool` құюы ешқашан `isize` асып кетпейді.
                //         3. Біз `block_r` `<= BLOCK` болатынына кепілдік бердік.
                //            Сонымен қатар, `end_r` бастапқыда стекте жарияланған `offsets_` басталу көрсеткішіне орнатылды.
                //            Осылайша, біз ең нашар жағдайда да (`is_less` барлық шақырулары шындыққа сәйкес келеді) біз ең көп дегенде 1 байт соңына жететінімізді білеміз.
                //        Мұндағы тағы бір қауіпті операция-бұл `elem`-ті ажырату.
                //        Алайда, `elem` бастапқыда `1 *sizeof(T)` соңынан өткен болатын және біз оны қол жеткізбес бұрын оны `1* sizeof(T)`-ке азайттық.
                //        Сонымен қатар, `block_r` `BLOCK` және `elem`-тен аз деп тұжырымдалды, сондықтан ең көп дегенде тілімнің басына нұсқайды.
                unsafe {
                    // Тармақсыз салыстыру.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Сол және оң жақ арасында ауыстырылатын тәртіптен тыс элементтер саны.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Сол уақытта бір жұпты ауыстырудың орнына, циклдық ауыстыруды орындау тиімдірек.
            // Бұл айырбастауға қатаң эквивалент емес, бірақ аз жад операцияларын қолдана отырып, ұқсас нәтиже береді.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Сол жақ блоктағы барлық тәртіптен тыс элементтер жылжытылды.Келесі блокқа өту.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Оң жақ блоктағы барлық тәртіптен тыс элементтер жылжытылды.Алдыңғы блокқа өту.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Енді тек ең көп дегенде бір блокты (солға да, оңға да) жылжыту керек, тәртіптен тыс элементтері бар.
    // Мұндай қалған элементтерді өз блогының аяғына дейін жылжытуға болады.
    //

    if start_l < end_l {
        // Сол жақ блок қалады.
        // Оның қалыптан тыс қалған элементтерін оң жақ шетке жылжытыңыз.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Оң жақ блок қалады.
        // Оның қалыптан тыс қалған элементтерін сол жаққа жылжытыңыз.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Басқа ештеңе істемейміз, біттік.
        width(v.as_mut_ptr(), l)
    }
}

/// `v`-ті `v[pivot]`-тен кіші элементтерге бөледі, содан кейін `v[pivot]`-тен үлкен немесе оған тең элементтер болады.
///
///
/// Кортежін қайтарады:
///
/// 1. `v[pivot]`-тен кіші элементтер саны.
/// 2. Егер `v` бұрыннан бөлінген болса.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Бұрышты тілімнің басына қойыңыз.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Тиімділік үшін цифрды стекке бөлінген айнымалыға оқыңыз.
        // Егер келесі салыстыру әрекеті panics болса, онда бұрылыс автоматты түрде тілімге қайта жазылады.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Тапсырыссыз элементтердің бірінші жұбын табыңыз.
        let mut l = 0;
        let mut r = v.len();

        // ҚАУІПСІЗДІК: Төмендегі қауіпсіздікке массив индекстелуі жатады.
        // Біріншісі: біз мұнда `l < r` көмегімен шекараны тексереміз.
        // Екіншісі үшін: бізде бастапқыда `l == 0` және `r == v.len()` бар, және біз индекстеу кезінде `l < r` екенін тексердік.
        //                     Осыдан біз `r` кем дегенде `r == l` болуы керек екенін білеміз, ол біріншісінен бастап жарамды.
        unsafe {
            // Айналдырғыштан үлкен немесе оған тең бірінші элементті табыңыз.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Айналмалы мәннен кіші соңғы элементті табыңыз.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` ауқымнан шығып, бұрышты (ол стекке бөлінген айнымалы болып табылады) қайтадан бастапқы тілімге жазады.
        // Бұл қадам қауіпсіздікті қамтамасыз етуде өте маңызды!
        //
    };

    // Бөлшекті екі бөліктің арасына қойыңыз.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// `v`-ті `v[pivot]`-ге тең элементтерге бөледі, содан кейін `v[pivot]`-ден үлкен элементтер.
///
/// Бұрылысқа тең элементтер санын қайтарады.
/// `v`-де бұрылыс шеңберінен кіші элементтер болмайды деп есептеледі.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Бұрышты тілімнің басына қойыңыз.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Тиімділік үшін цифрды стекке бөлінген айнымалыға оқыңыз.
    // Егер келесі салыстыру әрекеті panics болса, онда бұрылыс автоматты түрде тілімге қайта жазылады.
    // ҚАУІПСІЗДІК: Мұндағы көрсеткіш жарамды, өйткені ол тілімге сілтеме жасау арқылы алынады.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Енді тілімді бөліңіз.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // ҚАУІПСІЗДІК: Төмендегі қауіпсіздікке массив индекстелуі жатады.
        // Біріншісі: біз мұнда `l < r` көмегімен шекараны тексереміз.
        // Екіншісі үшін: бізде бастапқыда `l == 0` және `r == v.len()` бар, және біз индекстеу кезінде `l < r` екенін тексердік.
        //                     Осыдан біз `r` кем дегенде `r == l` болуы керек екенін білеміз, ол біріншісінен бастап жарамды.
        unsafe {
            // Айналдырғыштан үлкен бірінші элементті табыңыз.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Бұрылысқа тең соңғы элементті табыңыз.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Біттік пе?
            if l >= r {
                break;
            }

            // Табылған жұптың орнына келген элементтерді ауыстырыңыз.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Біз бұрылысқа тең `l` элементтерін таптық.Бұрамның өзін есепке алу үшін 1 қосыңыз.
    l + 1

    // `_pivot_guard` ауқымнан шығып, бұрышты (ол стекке бөлінген айнымалы болып табылады) қайтадан бастапқы тілімге жазады.
    // Бұл қадам қауіпсіздікті қамтамасыз етуде өте маңызды!
}

/// Квиксорста теңгерімсіз бөлімдер тудыруы мүмкін заңдылықтарды бұзу үшін кейбір элементтерді шашыратады.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Джордж Марсаглия шығарған "Xorshift RNGs" қағаздан жасалған псевдобаромен сандар генераторы.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Осы санның модулі бойынша кездейсоқ сандарды алыңыз.
        // Сан `usize`-ке сәйкес келеді, өйткені `len` `isize::MAX`-тен үлкен емес.
        let modulus = len.next_power_of_two();

        // Кейбір негізгі үміткерлер осы индекске жақын болады.Оларды рандомизациялайық.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // `len` модулі бойынша кездейсоқ санды шығарыңыз.
            // Алайда, қымбат операцияларды болдырмау үшін біз алдымен оны екі модуль бойынша қабылдаймыз, содан кейін ол `[0, len - 1]` ауқымына сәйкес келгенше `len`-ге азаяды.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` `2 * len`-тен аз екеніне кепілдік беріледі.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// `v` шеңберін таңдайды және кесінді сұрыпталған болса, индекс пен `true` мәнін қайтарады.
///
/// Процесс барысында `v` ішіндегі элементтер қайта реттелуі мүмкін.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Медиана әдісін таңдаудың минималды ұзындығы.
    // Қысқа тілімдерде үшеудің қарапайым медианасы әдісі қолданылады.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Осы функцияда орындалатын своптардың максималды саны.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Біз үш бұрышты таңдау керек болатын индекс.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Индекстерді сұрыптау кезінде біз орындайтын своптардың жалпы санын есептейді.
    let mut swaps = 0;

    if len >= 8 {
        // `v[a] <= v[b]` болатындай етіп индекстерді ауыстырады.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // `v[a] <= v[b] <= v[c]` болатындай етіп индекстерді ауыстырады.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // `v[a - 1], v[a], v[a + 1]` медианасын табады және индексті `a`-ге сақтайды.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // `a`, `b` және `c` маңайындағы медианаларды табыңыз.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // `a`, `b` және `c` аралықтарын табыңыз.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Своптардың максималды саны орындалды.
        // Тіліктің төмендеуі немесе көбіне кемуі мүмкін, сондықтан кері бағыт оны тезірек сұрыптауға көмектеседі.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// `v`-ны рекурсивті түрде сұрыптайды.
///
/// Егер тілімде бастапқы массивте предшественник болса, ол `pred` ретінде көрсетілген.
///
/// `limit` - `heapsort`-ге ауысқанға дейінгі рұқсат етілген теңгерімсіз бөлімдер саны.
/// Егер нөл болса, бұл функция бірден үйіндіге ауысады.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ұзындығы бойынша кесінділер кірістіру сұрыптауының көмегімен сұрыпталады.
    const MAX_INSERTION: usize = 20;

    // Егер соңғы бөлім жеткілікті түрде теңдестірілген болса.
    let mut was_balanced = true;
    // Егер соңғы бөлім элементтерді араластырмаса (кесінді бөлініп қойылған болса).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Кірістіруді сұрыптау арқылы өте қысқа тілімдер сұрыпталады.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Егер бұрылысты таңдау өте көп болса, `O(n * log(n))` жағдайына кепілдік беру үшін жай үйіндіге қайта оралыңыз.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Егер соңғы бөлу теңгерімсіз болса, айналадағы кейбір элементтерді араластыру арқылы тілімдегі үлгілерді сынап көріңіз.
        // Осы жолы жақсырақ бұрылыс таңдаймыз деп үміттенеміз.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Бұраманы таңдап, кесіндінің сұрыпталғанын болжап көріңіз.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Егер соңғы бөлу дұрыс теңдестірілген болса және элементтер араласпаса, және бұрылыс таңдауы болжам жасаса, тілім әлдеқашан сұрыпталған болуы мүмкін ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Бірнеше рет жұмыс істемейтін элементтерді анықтап, оларды дұрыс позицияларға ауыстыруға тырысыңыз.
            // Егер кесінді толығымен сұрыпталған болса, біз аяқтадық.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Егер таңдалған бұрылыс алдыңғыға тең болса, онда бұл тілімдегі ең кішкентай элемент.
        // Бөлшекке тең элементтерге және элементтерге бөліңіз.
        // Бұл жағдай, әдетте, тілімде көптеген қайталанатын элементтер болған кезде соғылады.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Бұрылғыдан үлкен элементтерді сұрыптауды жалғастырыңыз.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Тілімді бөліңіз.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Бөлікті `left`, `pivot` және `right` бөліктеріне бөліңіз.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Қысқа жолға рекурсивті қоңыраулардың жалпы санын азайту және стек кеңістігін аз тұтыну үшін ғана барыңыз.
        // Содан кейін ұзын жағымен жалғастырыңыз (бұл құйрықты рекурсияға ұқсас).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// *O*(*n*\*log(* n*)) ең нашар) үлгісін жеңілдететін жылдамдықты пайдаланып, `v` сұрыптайды.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Сұрыптаудың нөлдік өлшемдер бойынша мағыналы әрекеті жоқ.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Теңгерімсіз бөлімдердің санын `floor(log2(len)) + 1`-мен шектеңіз.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Осы ұзындықтағы кесінділер үшін оларды сұрыптау жылдамырақ болады.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Бұрышты таңдаңыз
        let (pivot, _) = choose_pivot(v, is_less);

        // Егер таңдалған бұрылыс алдыңғыға тең болса, онда бұл тілімдегі ең кішкентай элемент.
        // Бөлшекке тең элементтерге және элементтерге бөліңіз.
        // Бұл жағдай, әдетте, тілімде көптеген қайталанатын элементтер болған кезде соғылады.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Егер біз индекстен өткен болсақ, онда біз жақсыбыз.
                if mid > index {
                    return;
                }

                // Әйтпесе, бұрылыс мәнінен үлкен элементтерді сұрыптауды жалғастырыңыз.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Бөлікті `left`, `pivot` және `right` бөліктеріне бөліңіз.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Егер mid==индексі болса, онда біз аяқтадық, өйткені partition() ортасынан кейінгі барлық элементтер ортасынан үлкен немесе тең болатындығына кепілдік береді.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Сұрыптаудың нөлдік өлшемдер бойынша мағыналы әрекеті жоқ.Ештеңе істеме.
    } else if index == v.len() - 1 {
        // Max элементін тауып, оны массивтің соңғы орнына қойыңыз.
        // Біз `unwrap()`-ті еркін қолдана аламыз, өйткені v бос болмауы керек екенін білеміз.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Min элементін тауып, оны массивтің бірінші орнына қойыңыз.
        // Біз `unwrap()`-ті еркін қолдана аламыз, өйткені v бос болмауы керек екенін білеміз.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}