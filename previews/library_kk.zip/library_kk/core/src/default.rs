//! `Default` trait әдепкі мәндері болуы мүмкін типтерге арналған.

#![stable(feature = "rust1", since = "1.0.0")]

/// Түрге пайдалы әдепкі мән беру үшін trait.
///
/// Кейде сіз қандай да бір әдепкі мәнге қайта оралғыңыз келеді және оның не екеніне мән бермейсіз.
/// Бұл жиі нұсқалардың жиынтығын анықтайтын «struct`»-термен келеді:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// Кейбір әдепкі мәндерді қалай анықтауға болады?Сіз `Default` қолдана аласыз:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// Енді сіз барлық әдепкі мәндерді аласыз.Rust `Default`-ті әртүрлі қарабайыр типтерге қолданады.
///
/// Егер сіз белгілі бір опцияны жоққа шығарғыңыз келсе, бірақ басқа әдепкі параметрлерді сақтаңыз:
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// Осы trait-ті `#[derive]` көмегімен қолдануға болады, егер барлық өрістер `Default`-ті қолданса.
/// D «шығарған кезде», өрістің әр түрі үшін әдепкі мән қолданылады.
///
/// ## `Default`-ті қалай қолдануға болады?
///
/// Сіздің типіңіздің мәнін қайтаратын `default()` әдісі үшін енгізуді қамтамасыз етіңіз, ол әдепкі болуы керек:
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// Түр үшін "default value" қайтарады.
    ///
    /// Әдепкі мәндер-бұл бастапқы мән, идентификация мәні немесе әдепкі ретінде мағынасы болуы мүмкін кез келген нәрсе.
    ///
    ///
    /// # Examples
    ///
    /// Кірістірілген әдепкі мәндерді пайдалану:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// Өзіңіз жасай аласыз:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// `Default` trait сәйкес типтің әдепкі мәнін қайтарыңыз.
///
/// Қайтарылатын түрі мәтінмәннен шығарылады;бұл `Default::default()`-ге тең, бірақ теру қысқа.
///
/// Мысалға:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// trait `Default` имплизиясын жасайтын макросты шығарыңыз.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }