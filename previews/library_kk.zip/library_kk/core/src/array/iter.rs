//! Массивтерге арналған `IntoIter` итераторын анықтайды.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// [array] итераторы.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Бұл біз қайталап отырған жиым.
    ///
    /// `i` индексі бар элементтер, онда `alive.start <= i < alive.end` әлі шығарылмаған және алаптың жарамды жазулары болып табылады.
    /// `i < alive.start` немесе `i >= alive.end` индекстері бар элементтер қазірдің өзінде алынған және оларға енді қол жетімді болмауы керек!Бұл өлі элементтер мүлдем инициализацияланбаған күйде болуы мүмкін!
    ///
    ///
    /// Сонымен, инварианттар:
    /// - `data[alive]` тірі (яғни жарамды элементтерден тұрады)
    /// - `data[..alive.start]` және `data[alive.end..]` қайтыс болды (яғни элементтер оқылған және енді оларға қол тигізбеу керек!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// `data` элементтері әлі алынған жоқ.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Берілген `array` үстінен жаңа итератор жасайды.
    ///
    /// *Ескерту*: бұл әдіс 0future-де, [`IntoIterator` is implemented for arrays][array-into-iter]-тен кейін күшін жоюы мүмкін.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // `value` типі мұнда `&i32` орнына `i32` болып табылады
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // ҚАУІПСІЗДІК: Мұндағы трансмутут қауіпсіз болып табылады.`MaybeUninit` құжаттары
        // promise:
        //
        // > `MaybeUninit<T>` бірдей өлшемге және туралауға кепілдік беріледі
        // > `T` ретінде.
        //
        // Құжаттар тіпті `MaybeUninit<T>` жиымынан `T` жиымына ауыстыруды көрсетеді.
        //
        //
        // Осылайша, инициализация инварианттарды қанағаттандырады.

        // FIXME(LukasKalbertodt): const generics-пен жұмыс жасағаннан кейін мұнда `mem::transmute`-ті қолданыңыз:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Осы уақытқа дейін біз `mem::transmute_copy`-ті биттік көшірмені басқа түр ретінде жасай аламыз, содан кейін `array`-ті ұмытпаңыз, сондықтан ол түсірілмейді.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Барлық элементтердің өзгеріссіз кесіндісін қайтарады.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // ҚАУІПСІЗДІК: Біз `alive` ішіндегі барлық элементтердің дұрыс инициалданғанын білеміз.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Барлық элементтердің өзгермейтін кесіндісін қайтарады.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // ҚАУІПСІЗДІК: Біз `alive` ішіндегі барлық элементтердің дұрыс инициалданғанын білеміз.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Алдыңғы жағынан келесі индексті алыңыз.
        //
        // `alive.start`-ті 1-ге арттыру `alive`-ке қатысты инвариантты сақтайды.
        // Алайда, осы өзгеріске байланысты, аз уақыт ішінде тірі аймақ енді `data[alive]` емес, `data[idx..alive.end]` болады.
        //
        self.alive.next().map(|idx| {
            // Массивтен элементті оқыңыз.
            // ҚАУІПСІЗДІК: `idx`-бұл бұрынғы "alive" аймағындағы индекс
            // массив.Бұл элементті оқу `data[idx]` қазір өлі деп саналады дегенді білдіреді (яғни қол тигізбеңіз).
            // `idx` тірі аймақтың басталуы болғандықтан, тірі аймақ қайтадан `data[alive]` болып табылады, барлық инварианттарды қалпына келтіреді.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Артқы жағынан келесі индексті алыңыз.
        //
        // `alive.end`-ті 1-ге азайту `alive`-ге қатысты инвариантты сақтайды.
        // Алайда, осы өзгеріске байланысты, аз уақыт ішінде тірі аймақ енді `data[alive]` емес, `data[alive.start..=idx]` болады.
        //
        self.alive.next_back().map(|idx| {
            // Массивтен элементті оқыңыз.
            // ҚАУІПСІЗДІК: `idx`-бұл бұрынғы "alive" аймағындағы индекс
            // массив.Бұл элементті оқу `data[idx]` қазір өлі деп саналады дегенді білдіреді (яғни қол тигізбеңіз).
            // `idx` тірі аймақтың соңы болғандықтан, тірі аймақ қайтадан `data[alive]` болып, барлық инварианттарды қалпына келтіреді.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // ҚАУІПСІЗДІК: Қауіпсіз: `as_mut_slice` дәл тілімшені қайтарады
        // әлі шығарылмаған және түсіру керек элементтердің
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // «Live.start <=» инвариантты болғандықтан ешқашан ағып кетпейді
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Итератор шынымен де дұрыс ұзындық туралы хабарлайды.
// "alive" элементтерінің саны (әлі де берілетін болады)-бұл `alive` диапазонының ұзындығы.
// Бұл диапазон `next` немесе `next_back` ұзындығында азаяды.
// Ол әрдайым сол әдістерде 1-ге азаяды, бірақ егер `Some(_)` қайтарылса ғана.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Есіңізде болсын, бізге дәл бірдей тірі диапазонға сәйкес келудің қажеті жоқ, сондықтан біз `self` қай жерде болғанына қарамастан 0-ге теңестіруге болады.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Барлық тірі элементтерді клондау.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Жаңа массивке клон жазып, оның тірі ауқымын жаңартыңыз.
            // Егер panics клондау болса, біз алдыңғы элементтерді дұрыс тастаймыз.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Әлі шығарылмаған элементтерді ғана басып шығарыңыз: енді алынған элементтерге қол жеткізе алмаймыз.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}