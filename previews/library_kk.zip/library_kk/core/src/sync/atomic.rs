//! Атом түрлері
//!
//! Атомдық типтер жіптер арасындағы қарапайым жадтық байланысты қамтамасыз етеді және басқа қатарлас типтердің құрылыс материалы болып табылады.
//!
//! Бұл модуль [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`] және т.с.с. қоса қарабайыр типтердің таңдалған санының атомдық нұсқаларын анықтайды.
//! Атомдық типтер дұрыс қолданылған кезде ағындар арасындағы жаңартуларды синхрондауға мүмкіндік беретін операцияларды ұсынады.
//!
//! Әр әдіс [`Ordering`] қабылдайды, ол осы операция үшін жад тосқауылының беріктігін білдіреді.Бұл тапсырыстар [C++20 atomic orderings][1] сияқты.Қосымша ақпарат алу үшін [nomicon][2] қараңыз.
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Атомдық айнымалылар ағындар арасында бөлісуге қауіпсіз (олар [`Sync`]-ті қолданады), бірақ олар өздері бөлісу механизмін ұсынбайды және Rust-тің [threading model](../../../std/thread/index.html#the-threading-model)-ін ұстанады.
//!
//! Атомдық айнымалыны бөлудің ең кең тараған тәсілі-оны [`Arc`][arc]-ке (атомдық-сілтеме бойынша есептелген ортақ сілтеме) орналастыру.
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Атом типтерін статикалық айнымалыларда сақтауға болады, олар [`AtomicBool::new`] сияқты тұрақты инициализаторлар көмегімен инициалданған.Атомдық статика көбінесе жалқау ғаламдық инициализация үшін қолданылады.
//!
//! # Portability
//!
//! Бұл модульдегі барлық атом түрлері, егер олар қол жетімді болса, [lock-free] екеніне кепілдік береді.Бұл олардың ішкі мутекске ие болмайтындығын білдіреді.Атом түрлері мен операциялары күтуге жол берілмейді.
//! Бұл дегеніміз, `fetch_or` сияқты операциялар салыстыру және ауыстыру циклімен жүзеге асырылуы мүмкін.
//!
//! Атомдық операцияларды нұсқаулық деңгейінде үлкенірек атомдармен жүзеге асыруға болады.Мысалы, кейбір платформаларда `AtomicI8`-ті енгізу үшін 4 байтты атомдық нұсқаулық қолданылады.
//! Бұл эмуляция кодтың дұрыстығына әсер етпеуі керек екенін ескеріңіз, бұл жай ғана білу керек.
//!
//! Бұл модульдегі атом түрлері барлық платформаларда болмауы мүмкін.Мұндағы атом типтері кеңінен қол жетімді, алайда жалпыға қол жетімді деп санауға болады.Кейбір ерекше ерекшеліктер:
//!
//! * PowerPC және 32 биттік көрсеткіштері бар MIPS платформаларында `AtomicU64` немесе `AtomicI64` типтері жоқ.
//! * ARM `armv5te` сияқты емес `armv5te` сияқты платформалар тек `load` және `store` операцияларын қамтамасыз етеді, және `swap`, `fetch_add` және т.б.салыстыру және ауыстыру (CAS) операцияларын қолдамайды.
//! Сонымен қатар, Linux-те бұл CAS операциялары [operating system support] арқылы жүзеге асырылады, бұл өнімділік айыппұлымен бірге келуі мүмкін.
//! * ARM `thumbv6m` бар нысандар тек `load` және `store` операцияларын қамтамасыз етеді, және `swap`, `fetch_add` және т.б.салыстыру және ауыстыру (CAS) операцияларын қолдамайды.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! future платформаларын қосуға болатындығын ескеріңіз, оларда кейбір атомдық операцияларға қолдау жоқ.Максималды портативті код қандай атом түрлері қолданылатындығына мұқият болғысы келеді.
//! `AtomicUsize` және `AtomicIsize` әдетте ең портативті болып табылады, бірақ тіпті олар барлық жерде қол жетімді емес.
//! Анықтама үшін, `std` кітапханасы сілтегіштің атомын қажет етеді, бірақ `core` қажет етпейді.
//!
//! Қазіргі уақытта сізге атомдармен кодты шартты түрде құрастыру үшін `#[cfg(target_arch)]` қолдану қажет.future тұрақтануы мүмкін тұрақсыз `#[cfg(target_has_atomic)]` бар.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Қарапайым айналдыру:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Басқа жіптің құлпын босатқанша күтіңіз
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Тікелей ағындардың ғаламдық санын сақтаңыз:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Жіптер арасында қауіпсіз түрде бөлінетін логикалық тип.
///
/// Бұл типтің жадтағы көрінісі [`bool`] сияқты.
///
/// **Ескерту**: бұл түр тек `u8` атомдық жүктемелер мен дүкендерді қолдайтын платформаларда қол жетімді.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// `false` инициализацияланған `AtomicBool` жасайды.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Жіберу AtomicBool үшін жанама түрде жүзеге асырылады.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Жіптер арасында қауіпсіз түрде бөлінетін шикі нұсқағыш түрі.
///
/// Бұл типтің жадтағы көрінісі `*mut T` сияқты.
///
/// **Ескертпе**: бұл тип тек атомдық жүктемелерді және көрсеткіштерді сақтайтын платформаларда қол жетімді.
/// Оның мөлшері мақсатты меңзердің өлшеміне байланысты.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Нөлдік `AtomicPtr<T>` жасайды.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Атомдық жадқа тапсырыс беру
///
/// Жадының реті атомдық операциялардың жадыны синхрондау тәсілін көрсетеді.
/// Ең әлсіз [`Ordering::Relaxed`]-де тек операциямен тікелей әсер ететін жад синхрондалады.
/// Екінші жағынан, [`Ordering::SeqCst`] операцияларының қоймаға жүктелетін жұбы басқа жадты үндестіреді, сонымен қатар барлық ағындардағы осындай операциялардың жалпы тәртібін сақтайды.
///
///
/// Rust жадына тапсырыс-[the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Қосымша ақпарат алу үшін [nomicon] қараңыз.
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Реттеу шектеулері жоқ, тек атомдық операциялар.
    ///
    /// C ++ 20-дағы [`memory_order_relaxed`] сәйкес келеді.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Дүкенмен біріктірілгенде, барлық алдыңғы операциялар [`Acquire`] (немесе одан да күшті) тапсырысымен осы мәннің кез-келген жүктемесіне дейін тапсырыс береді.
    ///
    /// Атап айтқанда, барлық алдыңғы жазбалар осы мәннің [`Acquire`] (немесе одан да күшті) жүктемесін орындайтын барлық ағындарға көрінеді.
    ///
    /// Бұл тапсырысты жүктемелер мен қоймаларды біріктіретін операцияға пайдалану [`Relaxed`] жүктеме операциясына әкелетініне назар аударыңыз!
    ///
    /// Бұл тапсырыс дүкенді орындай алатын операцияларға ғана қатысты.
    ///
    /// C ++ 20-дағы [`memory_order_release`] сәйкес келеді.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Егер жүктемені қосқанда, егер жүктелген мәнді дүкен операциясы [`Release`] (немесе одан да күшті) тапсырысымен жазған болса, онда барлық келесі операциялар осы дүкеннен кейін реттеледі.
    /// Атап айтқанда, барлық кейінгі жүктемелер дүкенге дейін жазылған деректерді көреді.
    ///
    /// Бұл тапсырысты жүктемелер мен дүкендерді біріктіретін операция үшін пайдалану [`Relaxed`] дүкенінің жұмысына әкелетініне назар аударыңыз!
    ///
    /// Бұл тапсырыс жүктемені орындай алатын операцияларға ғана қатысты.
    ///
    /// C ++ 20-дағы [`memory_order_acquire`] сәйкес келеді.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// [`Acquire`] және [`Release`] екеуінің де әсерлері бар:
    /// Жүктер үшін ол [`Acquire`] тапсырысын қолданады.Дүкендерде ол [`Release`] тапсырысын қолданады.
    ///
    /// Назар аударыңыз, егер `compare_and_swap` жағдайында бұл операция ешқандай дүкен өткізбеуі мүмкін, демек ол тек [`Acquire`] тапсырысымен.
    ///
    /// Алайда, `AcqRel` ешқашан [`Relaxed`] қатынастарын орындай алмайды.
    ///
    /// Бұл тапсырыс тек жүктемелер мен дүкендерді біріктіретін операцияларға ғана қатысты.
    ///
    /// C ++ 20-дағы [`memory_order_acq_rel`] сәйкес келеді.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// [«Acquire`]/[` Release`]/[AcqRel`] сияқты (сәйкесінше жүктеу, сақтау және дүкенмен жүктеу операциялары үшін) барлық тізбектердің барлық дәйекті операцияларды бірдей тәртіппен көруіне қосымша кепілдік .
    ///
    ///
    /// C ++ 20-дағы [`memory_order_seq_cst`] сәйкес келеді.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// X001-ге инициализацияланған [`AtomicBool`].
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Жаңа `AtomicBool` жасайды.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Негізгі [`bool`]-ге өзгертілетін сілтемені қайтарады.
    ///
    /// Бұл қауіпсіз, өйткені өзгермелі анықтама басқа ағындардың атомдық деректерге бір уақытта қол жеткізе алмайтындығына кепілдік береді.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // ҚАУІПСІЗДІК: өзгермелі сілтеме бірегей меншік құқығына кепілдік береді.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// `&mut bool`-ке атомдық қол жеткізуді алыңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // ҚАУІПСІЗДІК: өзгермелі сілтеме бірегей меншікке кепілдік береді, және
        // `bool` және `Self` екеуінің теңестіруі 1-ге тең.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Атомды жұмсайды және қамтылған мәнді қайтарады.
    ///
    /// Бұл қауіпсіз, өйткені `self`-ті мәндер бойынша өткізу, басқа ағындардың атомдық деректерге бір уақытта қол жеткізбейтіндігіне кепілдік береді.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// bool мәнін жүктейді.
    ///
    /// `load` осы операцияның жадының реттілігін сипаттайтын [`Ordering`] аргументін алады.
    /// Мүмкін мәндер-[`SeqCst`], [`Acquire`] және [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, егер `order` [`Release`] немесе [`AcqRel`] болса.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // ҚАУІПСІЗДІК: кез-келген мәліметтер жарысының алдын-алуды атом меншікті және шикі заттар жүзеге асырмайды
        // берілген сілтеме дұрыс, өйткені біз оны анықтамадан алдық.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// bool мәнін сақтайды.
    ///
    /// `store` осы операцияның жадының реттілігін сипаттайтын [`Ordering`] аргументін алады.
    /// Мүмкін мәндер-[`SeqCst`], [`Release`] және [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, егер `order` [`Acquire`] немесе [`AcqRel`] болса.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // ҚАУІПСІЗДІК: кез-келген мәліметтер жарысының алдын-алуды атом меншікті және шикі заттар жүзеге асырмайды
        // берілген сілтеме дұрыс, өйткені біз оны анықтамадан алдық.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Алдыңғы мәнді қайтарып, bool мәнін сақтайды.
    ///
    /// `swap` осы операцияның жадының реттілігін сипаттайтын [`Ordering`] аргументін алады.Тапсырыстың барлық режимдері мүмкін.
    /// [`Acquire`]-ті пайдалану осы операцияның сақтау бөлігін [`Relaxed`]-ге, ал [`Release`]-ті пайдалану [`Relaxed`]-ті құрайды.
    ///
    ///
    /// **Note:** Бұл әдіс тек `u8`-те атомдық операцияларды қолдайтын платформаларда қол жетімді.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // ҚАУІПСІЗДІК: деректер жарыстарының алдын-алуды атомның ішкі факторлары жүзеге асырады.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Ағымдағы мән `current` мәнімен бірдей болса, [`bool`] мәнін сақтайды.
    ///
    /// Қайтарылатын мән әрқашан алдыңғы мән болып табылады.Егер ол `current`-ге тең болса, онда мән жаңартылды.
    ///
    /// `compare_and_swap` сонымен қатар осы операцияның жадының реттілігін сипаттайтын [`Ordering`] аргументін алады.
    /// Назар аударыңыз, [`AcqRel`]-ті қолданған кезде де операция сәтсіздікке ұшырауы мүмкін, сондықтан `Acquire` жүктемесін орындайды, бірақ `Release` семантикасы жоқ.
    /// Егер [`Acquire`] пайдалану болса, бұл операцияның сақтау бөлігін [`Relaxed`] құрайды, ал егер [`Release`]-ті қолданса, [`Relaxed`] жүктеме бөлігін құрайды.
    ///
    /// **Note:** Бұл әдіс тек `u8`-те атомдық операцияларды қолдайтын платформаларда қол жетімді.
    ///
    /// # `compare_exchange` және `compare_exchange_weak` көшу
    ///
    /// `compare_and_swap` жадқа тапсырыс беру үшін келесі кескінмен `compare_exchange`-ге тең:
    ///
    /// Түпнұсқа |Табыс |Сәтсіздік
    /// -------- | ------- | -------
    /// Босаңсыған |Босаңсыған |Бос емес сатып алу |Сатып алу |Шығарылымды сатып алу |Шығарылым |Босаңсыған AcqRel |AcqRel |SeqCst сатып алу |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` салыстыру сәтті болған кезде де жалған сәтсіздікке жол беріледі, бұл компиляторға салыстыру және ауыстыру циклде қолданылған кезде жақсы құрастыру кодын жасауға мүмкіндік береді.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Ағымдағы мән `current` мәнімен бірдей болса, [`bool`] мәнін сақтайды.
    ///
    /// Қайтарылатын мән-бұл жаңа мәннің жазылғанын және алдыңғы мәнді қамтитындығын көрсететін нәтиже.
    /// Сәтті болған кезде бұл мәнге `current`-ке тең кепілдік беріледі.
    ///
    /// `compare_exchange` осы операцияның жадының орналасуын сипаттау үшін екі [`Ordering`] аргументін алады.
    /// `success` егер `current`-пен салыстыру сәтті болса, оқылатын-түрлендіретін-жазылатын операцияға қажетті тапсырысты сипаттайды.
    /// `failure` салыстыру сәтсіз болған кезде орын алатын жүктеме жұмысына қажетті тапсырыс беруді сипаттайды.
    /// [`Acquire`]-ті сәтті тапсырыс ретінде пайдалану дүкенді [`Relaxed`] операциясының бөлігі етеді, ал [`Release`]-ті [`Relaxed`] сәтті жүктейді.
    ///
    /// Сәтсіздікке тапсырыс беру тек [`SeqCst`], [`Acquire`] немесе [`Relaxed`] болуы мүмкін және сәтті тапсырыс берудің баламасы немесе әлсіз болуы керек.
    ///
    /// **Note:** Бұл әдіс тек `u8`-те атомдық операцияларды қолдайтын платформаларда қол жетімді.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // ҚАУІПСІЗДІК: деректер жарыстарының алдын-алуды атомның ішкі факторлары жүзеге асырады.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Ағымдағы мән `current` мәнімен бірдей болса, [`bool`] мәнін сақтайды.
    ///
    /// [`AtomicBool::compare_exchange`]-тен айырмашылығы, бұл функция салыстыру сәтті болған кезде де жалған түрде істен шығуға мүмкіндік береді, бұл кейбір платформаларда тиімді кодты тудыруы мүмкін.
    ///
    /// Қайтарылатын мән-бұл жаңа мәннің жазылғанын және алдыңғы мәнді қамтитындығын көрсететін нәтиже.
    ///
    /// `compare_exchange_weak` осы операцияның жадының орналасуын сипаттау үшін екі [`Ordering`] аргументін алады.
    /// `success` егер `current`-пен салыстыру сәтті болса, оқылатын-түрлендіретін-жазылатын операцияға қажетті тапсырысты сипаттайды.
    /// `failure` салыстыру сәтсіз болған кезде орын алатын жүктеме жұмысына қажетті тапсырыс беруді сипаттайды.
    /// [`Acquire`]-ті сәтті тапсырыс ретінде пайдалану дүкенді [`Relaxed`] операциясының бөлігі етеді, ал [`Release`]-ті [`Relaxed`] сәтті жүктейді.
    /// Сәтсіздікке тапсырыс беру тек [`SeqCst`], [`Acquire`] немесе [`Relaxed`] болуы мүмкін және сәтті тапсырыс берудің баламасы немесе әлсіз болуы керек.
    ///
    /// **Note:** Бұл әдіс тек `u8`-те атомдық операцияларды қолдайтын платформаларда қол жетімді.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // ҚАУІПСІЗДІК: деректер жарыстарының алдын-алуды атомның ішкі факторлары жүзеге асырады.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Логикалық мәні бар логикалық "and".
    ///
    /// Ағымдағы мән мен `val` аргументі бойынша логикалық "and" әрекетін орындайды және нәтижеге жаңа мәнді қояды.
    ///
    /// Алдыңғы мәнді қайтарады.
    ///
    /// `fetch_and` осы операцияның жадының реттілігін сипаттайтын [`Ordering`] аргументін алады.Тапсырыстың барлық режимдері мүмкін.
    /// [`Acquire`]-ті пайдалану осы операцияның сақтау бөлігін [`Relaxed`]-ге, ал [`Release`]-ті пайдалану [`Relaxed`]-ті құрайды.
    ///
    ///
    /// **Note:** Бұл әдіс тек `u8`-те атомдық операцияларды қолдайтын платформаларда қол жетімді.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // ҚАУІПСІЗДІК: деректер жарыстарының алдын-алуды атомның ішкі факторлары жүзеге асырады.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Логикалық мәні бар логикалық "nand".
    ///
    /// Ағымдағы мән мен `val` аргументі бойынша логикалық "nand" әрекетін орындайды және нәтижеге жаңа мәнді қояды.
    ///
    /// Алдыңғы мәнді қайтарады.
    ///
    /// `fetch_nand` осы операцияның жадының реттілігін сипаттайтын [`Ordering`] аргументін алады.Тапсырыстың барлық режимдері мүмкін.
    /// [`Acquire`]-ті пайдалану осы операцияның сақтау бөлігін [`Relaxed`]-ге, ал [`Release`]-ті пайдалану [`Relaxed`]-ті құрайды.
    ///
    ///
    /// **Note:** Бұл әдіс тек `u8`-те атомдық операцияларды қолдайтын платформаларда қол жетімді.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Біз мұнда atomic_nand қолдана алмаймыз, себебі ол жарамсыз мәнмен bool әкелуі мүмкін.
        // Бұл атомдық операция ішкі 8 биттік бүтін санмен жасалатындықтан болады, бұл жоғарғы 7 битті орнатады.
        //
        // Сондықтан біз оның орнына fetch_xor немесе swap қолданамыз.
        if val {
            // ! (x&true)== !x Біз bool-ны төңкеруіміз керек.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true Біз bool мәнін шын мәніне қоюымыз керек.
            //
            self.swap(true, order)
        }
    }

    /// Логикалық мәні бар логикалық "or".
    ///
    /// Ағымдағы мән мен `val` аргументі бойынша логикалық "or" әрекетін орындайды және нәтижеге жаңа мәнді қояды.
    ///
    /// Алдыңғы мәнді қайтарады.
    ///
    /// `fetch_or` осы операцияның жадының реттілігін сипаттайтын [`Ordering`] аргументін алады.Тапсырыстың барлық режимдері мүмкін.
    /// [`Acquire`]-ті пайдалану осы операцияның сақтау бөлігін [`Relaxed`]-ге, ал [`Release`]-ті пайдалану [`Relaxed`]-ті құрайды.
    ///
    ///
    /// **Note:** Бұл әдіс тек `u8`-те атомдық операцияларды қолдайтын платформаларда қол жетімді.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // ҚАУІПСІЗДІК: деректер жарыстарының алдын-алуды атомның ішкі факторлары жүзеге асырады.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Логикалық мәні бар логикалық "xor".
    ///
    /// Ағымдағы мән мен `val` аргументі бойынша логикалық "xor" әрекетін орындайды және нәтижеге жаңа мәнді қояды.
    ///
    /// Алдыңғы мәнді қайтарады.
    ///
    /// `fetch_xor` осы операцияның жадының реттілігін сипаттайтын [`Ordering`] аргументін алады.Тапсырыстың барлық режимдері мүмкін.
    /// [`Acquire`]-ті пайдалану осы операцияның сақтау бөлігін [`Relaxed`]-ге, ал [`Release`]-ті пайдалану [`Relaxed`]-ті құрайды.
    ///
    ///
    /// **Note:** Бұл әдіс тек `u8`-те атомдық операцияларды қолдайтын платформаларда қол жетімді.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // ҚАУІПСІЗДІК: деректер жарыстарының алдын-алуды атомның ішкі факторлары жүзеге асырады.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Өзгеретін көрсеткішті негізгі [`bool`] мәніне қайтарады.
    ///
    /// Алынған бүтін санға атомдық емес оқу және жазу мәліметтер жарысы бола алады.
    /// Бұл әдіс көбінесе FFI үшін пайдалы, мұнда функционалды қолтаңба `&AtomicBool` орнына `*mut bool` қолдана алады.
    ///
    /// `*mut` сілтемесін осы атомға ортақ сілтемеден қайтару қауіпсіз, себебі атом түрлері интерьердің өзгергіштігімен жұмыс істейді.
    /// Атомның барлық модификациялары жалпы сілтеме арқылы мәнді өзгертеді және атомдық операцияларды қолданған кезде оны қауіпсіз жасай алады.
    /// Қайтарылған шикі меңзерді кез-келген пайдалану үшін `unsafe` блогы қажет және сол шектеуді сақтау керек: ондағы әрекеттер атомдық болуы керек.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Мәнді алып, оған қосымша жаңа мән беретін функцияны қолданады.Егер `Some(_)` функциясы қайтарылса, басқасы `Err(previous_value)` болса, `Result`-тің `Result` мәнін қайтарады.
    ///
    /// Note: Бұл функция функцияны бірнеше рет шақыруы мүмкін, егер мәні осы уақыт аралығында басқа ағындардан өзгертілсе, егер функция `Some(_)` қайтаратын болса, бірақ функция сақталған мәнге бір рет қана қолданылған болады.
    ///
    ///
    /// `fetch_update` осы операцияның жадының орналасуын сипаттау үшін екі [`Ordering`] аргументін алады.
    /// Біріншісі операцияның сәтті аяқталуы үшін қажетті тапсырысты сипаттайды, ал екіншісі жүктемелерге қажетті тапсырысты сипаттайды.
    /// Олар сәйкесінше [`AtomicBool::compare_exchange`]-тің сәтті және сәтсіз тапсырысына сәйкес келеді.
    ///
    /// [`Acquire`]-ті сәтті тапсырыс ретінде пайдалану дүкенді [`Relaxed`] операциясының бөлігі етеді, ал [`Release`]-ті [`Relaxed`] сәтті жүктемесі жасайды.
    /// (failed) жүктемесіне тапсырыс беру тек [`SeqCst`], [`Acquire`] немесе [`Relaxed`] болуы мүмкін және ол сәтті тапсырыс берудің баламасы немесе әлсіз болуы керек.
    ///
    /// **Note:** Бұл әдіс тек `u8`-те атомдық операцияларды қолдайтын платформаларда қол жетімді.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Жаңа `AtomicPtr` жасайды.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Негізгі көрсеткішке өзгертілетін сілтемені қайтарады.
    ///
    /// Бұл қауіпсіз, өйткені өзгермелі анықтама басқа ағындардың атомдық деректерге бір уақытта қол жеткізе алмайтындығына кепілдік береді.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Меңзерге атомдық қатынасты алыңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - өзгермелі сілтеме бірегей меншікке кепілдік береді.
        //  - `*mut T` және `Self` түзулері жоғарыда көрсетілгендей rust қолдайтын барлық платформаларда бірдей.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Атомды жұмсайды және қамтылған мәнді қайтарады.
    ///
    /// Бұл қауіпсіз, өйткені `self`-ті мәндер бойынша өткізу, басқа ағындардың атомдық деректерге бір уақытта қол жеткізбейтіндігіне кепілдік береді.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Меңзерден мән жүктеледі.
    ///
    /// `load` осы операцияның жадының реттілігін сипаттайтын [`Ordering`] аргументін алады.
    /// Мүмкін мәндер-[`SeqCst`], [`Acquire`] және [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, егер `order` [`Release`] немесе [`AcqRel`] болса.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // ҚАУІПСІЗДІК: деректер жарыстарының алдын-алуды атомның ішкі факторлары жүзеге асырады.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Мәнді көрсеткішке сақтайды.
    ///
    /// `store` осы операцияның жадының реттілігін сипаттайтын [`Ordering`] аргументін алады.
    /// Мүмкін мәндер-[`SeqCst`], [`Release`] және [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, егер `order` [`Acquire`] немесе [`AcqRel`] болса.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // ҚАУІПСІЗДІК: деректер жарыстарының алдын-алуды атомның ішкі факторлары жүзеге асырады.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Алдыңғы мәнді қайтарып, мәнді көрсеткішке сақтайды.
    ///
    /// `swap` осы операцияның жадының реттілігін сипаттайтын [`Ordering`] аргументін алады.Тапсырыстың барлық режимдері мүмкін.
    /// [`Acquire`]-ті пайдалану осы операцияның сақтау бөлігін [`Relaxed`]-ге, ал [`Release`]-ті пайдалану [`Relaxed`]-ті құрайды.
    ///
    ///
    /// **Note:** Бұл әдіс көрсеткіштердегі атомдық операцияларды қолдайтын платформаларда ғана қол жетімді.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // ҚАУІПСІЗДІК: деректер жарыстарының алдын-алуды атомның ішкі факторлары жүзеге асырады.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Ағымдағы мән `current` мәнімен бірдей болса, көрсеткішті мәнге сақтайды.
    ///
    /// Қайтарылатын мән әрқашан алдыңғы мән болып табылады.Егер ол `current`-ге тең болса, онда мән жаңартылды.
    ///
    /// `compare_and_swap` сонымен қатар осы операцияның жадының реттілігін сипаттайтын [`Ordering`] аргументін алады.
    /// Назар аударыңыз, [`AcqRel`]-ті қолданған кезде де операция сәтсіздікке ұшырауы мүмкін, сондықтан `Acquire` жүктемесін орындайды, бірақ `Release` семантикасы жоқ.
    /// Егер [`Acquire`] пайдалану болса, бұл операцияның сақтау бөлігін [`Relaxed`] құрайды, ал егер [`Release`]-ті қолданса, [`Relaxed`] жүктеме бөлігін құрайды.
    ///
    /// **Note:** Бұл әдіс көрсеткіштердегі атомдық операцияларды қолдайтын платформаларда ғана қол жетімді.
    ///
    /// # `compare_exchange` және `compare_exchange_weak` көшу
    ///
    /// `compare_and_swap` жадқа тапсырыс беру үшін келесі кескінмен `compare_exchange`-ге тең:
    ///
    /// Түпнұсқа |Табыс |Сәтсіздік
    /// -------- | ------- | -------
    /// Босаңсыған |Босаңсыған |Бос емес сатып алу |Сатып алу |Шығарылымды сатып алу |Шығарылым |Босаңсыған AcqRel |AcqRel |SeqCst сатып алу |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` салыстыру сәтті болған кезде де жалған сәтсіздікке жол беріледі, бұл компиляторға салыстыру және ауыстыру циклде қолданылған кезде жақсы құрастыру кодын жасауға мүмкіндік береді.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Ағымдағы мән `current` мәнімен бірдей болса, көрсеткішті мәнге сақтайды.
    ///
    /// Қайтарылатын мән-бұл жаңа мәннің жазылғанын және алдыңғы мәнді қамтитындығын көрсететін нәтиже.
    /// Сәтті болған кезде бұл мәнге `current`-ке тең кепілдік беріледі.
    ///
    /// `compare_exchange` осы операцияның жадының орналасуын сипаттау үшін екі [`Ordering`] аргументін алады.
    /// `success` егер `current`-пен салыстыру сәтті болса, оқылатын-түрлендіретін-жазылатын операцияға қажетті тапсырысты сипаттайды.
    /// `failure` салыстыру сәтсіз болған кезде орын алатын жүктеме жұмысына қажетті тапсырыс беруді сипаттайды.
    /// [`Acquire`]-ті сәтті тапсырыс ретінде пайдалану дүкенді [`Relaxed`] операциясының бөлігі етеді, ал [`Release`]-ті [`Relaxed`] сәтті жүктейді.
    ///
    /// Сәтсіздікке тапсырыс беру тек [`SeqCst`], [`Acquire`] немесе [`Relaxed`] болуы мүмкін және сәтті тапсырыс берудің баламасы немесе әлсіз болуы керек.
    ///
    /// **Note:** Бұл әдіс көрсеткіштердегі атомдық операцияларды қолдайтын платформаларда ғана қол жетімді.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // ҚАУІПСІЗДІК: деректер жарыстарының алдын-алуды атомның ішкі факторлары жүзеге асырады.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Ағымдағы мән `current` мәнімен бірдей болса, көрсеткішті мәнге сақтайды.
    ///
    /// [`AtomicPtr::compare_exchange`]-тен айырмашылығы, бұл функция салыстыру сәтті болған кезде де жалған сәтсіздікке жол беріледі, бұл кейбір платформаларда тиімді кодты тудыруы мүмкін.
    ///
    /// Қайтарылатын мән-бұл жаңа мәннің жазылғанын және алдыңғы мәнді қамтитындығын көрсететін нәтиже.
    ///
    /// `compare_exchange_weak` осы операцияның жадының орналасуын сипаттау үшін екі [`Ordering`] аргументін алады.
    /// `success` егер `current`-пен салыстыру сәтті болса, оқылатын-түрлендіретін-жазылатын операцияға қажетті тапсырысты сипаттайды.
    /// `failure` салыстыру сәтсіз болған кезде орын алатын жүктеме жұмысына қажетті тапсырыс беруді сипаттайды.
    /// [`Acquire`]-ті сәтті тапсырыс ретінде пайдалану дүкенді [`Relaxed`] операциясының бөлігі етеді, ал [`Release`]-ті [`Relaxed`] сәтті жүктейді.
    /// Сәтсіздікке тапсырыс беру тек [`SeqCst`], [`Acquire`] немесе [`Relaxed`] болуы мүмкін және сәтті тапсырыс берудің баламасы немесе әлсіз болуы керек.
    ///
    /// **Note:** Бұл әдіс көрсеткіштердегі атомдық операцияларды қолдайтын платформаларда ғана қол жетімді.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // ҚАУІПСІЗДІК: бұл ішкі қауіпті, себебі ол шикі нұсқағышта жұмыс істейді
        // бірақ біз көрсеткіштің жарамды екендігіне сенімдіміз (біз оны `UnsafeCell`-тен алғанбыз) және атомдық операцияның өзі бізге `UnsafeCell` мазмұнын қауіпсіз түрде өзгертуге мүмкіндік береді.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Мәнді алып, оған қосымша жаңа мән беретін функцияны қолданады.Егер `Some(_)` функциясы қайтарылса, басқасы `Err(previous_value)` болса, `Result`-тің `Result` мәнін қайтарады.
    ///
    /// Note: Бұл функция функцияны бірнеше рет шақыруы мүмкін, егер мәні осы уақыт аралығында басқа ағындардан өзгертілсе, егер функция `Some(_)` қайтаратын болса, бірақ функция сақталған мәнге бір рет қана қолданылған болады.
    ///
    ///
    /// `fetch_update` осы операцияның жадының орналасуын сипаттау үшін екі [`Ordering`] аргументін алады.
    /// Біріншісі операцияның сәтті аяқталуы үшін қажетті тапсырысты сипаттайды, ал екіншісі жүктемелерге қажетті тапсырысты сипаттайды.
    /// Олар сәйкесінше [`AtomicPtr::compare_exchange`]-тің сәтті және сәтсіз тапсырысына сәйкес келеді.
    ///
    /// [`Acquire`]-ті сәтті тапсырыс ретінде пайдалану дүкенді [`Relaxed`] операциясының бөлігі етеді, ал [`Release`]-ті [`Relaxed`] сәтті жүктемесі жасайды.
    /// (failed) жүктемесіне тапсырыс беру тек [`SeqCst`], [`Acquire`] немесе [`Relaxed`] болуы мүмкін және ол сәтті тапсырыс берудің баламасы немесе әлсіз болуы керек.
    ///
    /// **Note:** Бұл әдіс көрсеткіштердегі атомдық операцияларды қолдайтын платформаларда ғана қол жетімді.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// `bool`-ті `AtomicBool` түрлендіреді.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Бұл макростанция кейбір архитектураларда қолданылмай қалады.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Ағындар арасында қауіпсіз түрде бөлінетін бүтін тип.
        ///
        /// Бұл типтің жадтағы көрінісі, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Атомдық және атомдық емес түрлер арасындағы айырмашылықтар туралы, сондай-ақ осы типтегі портативтілік туралы ақпарат алу үшін [module-level documentation] қараңыз.
        ///
        ///
        /// **Note:** Бұл тип тек атомдық жүктемелерді және [`.] Дүкендерін қолдайтын платформаларда қол жетімді
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Атомдық бүтін `0` инициализациясы.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Жіберу жанама түрде жүзеге асырылады.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Жаңа атомдық бүтін сан жасайды.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Негізгі бүтін санға өзгертілетін сілтемені қайтарады.
            ///
            /// Бұл қауіпсіз, өйткені өзгермелі анықтама басқа ағындардың атомдық деректерге бір уақытта қол жеткізе алмайтындығына кепілдік береді.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// mut some_int=123 болсын;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - өзгермелі сілтеме бірегей меншікке кепілдік береді.
                //  - `$int_type` және `Self` туралануы бірдей, $cfg_align уәде еткен және жоғарыда тексерілген.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Атомды жұмсайды және қамтылған мәнді қайтарады.
            ///
            /// Бұл қауіпсіз, өйткені `self`-ті мәндер бойынша өткізу, басқа ағындардың атомдық деректерге бір уақытта қол жеткізбейтіндігіне кепілдік береді.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Атомдық бүтін саннан мән жүктеледі.
            ///
            /// `load` осы операцияның жадының реттілігін сипаттайтын [`Ordering`] аргументін алады.
            /// Мүмкін мәндер-[`SeqCst`], [`Acquire`] және [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics, егер `order` [`Release`] немесе [`AcqRel`] болса.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // ҚАУІПСІЗДІК: деректер жарыстарының алдын-алуды атомның ішкі факторлары жүзеге асырады.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Мәнді атомдық бүтін санға сақтайды.
            ///
            /// `store` осы операцияның жадының реттілігін сипаттайтын [`Ordering`] аргументін алады.
            ///  Мүмкін мәндер-[`SeqCst`], [`Release`] және [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics, егер `order` [`Acquire`] немесе [`AcqRel`] болса.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // ҚАУІПСІЗДІК: деректер жарыстарының алдын-алуды атомның ішкі факторлары жүзеге асырады.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Алдыңғы мәнді қайтара отырып, мәнді атомның бүтін санына сақтайды.
            ///
            /// `swap` осы операцияның жадының реттілігін сипаттайтын [`Ordering`] аргументін алады.Тапсырыстың барлық режимдері мүмкін.
            /// [`Acquire`]-ті пайдалану осы операцияның сақтау бөлігін [`Relaxed`]-ге, ал [`Release`]-ті пайдалану [`Relaxed`]-ті құрайды.
            ///
            ///
            /// **Ескерту**: Бұл әдіс тек атомдық операцияларды қолдайтын платформаларда қол жетімді
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // ҚАУІПСІЗДІК: деректер жарыстарының алдын-алуды атомның ішкі факторлары жүзеге асырады.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Ағымдағы мән `current` мәнімен бірдей болса, мәнді атом бүтін санына сақтайды.
            ///
            /// Қайтарылатын мән әрқашан алдыңғы мән болып табылады.Егер ол `current`-ге тең болса, онда мән жаңартылды.
            ///
            /// `compare_and_swap` сонымен қатар осы операцияның жадының реттілігін сипаттайтын [`Ordering`] аргументін алады.
            /// Назар аударыңыз, [`AcqRel`]-ті қолданған кезде де операция сәтсіздікке ұшырауы мүмкін, сондықтан `Acquire` жүктемесін орындайды, бірақ `Release` семантикасы жоқ.
            ///
            /// Егер [`Acquire`] пайдалану болса, бұл операцияның сақтау бөлігін [`Relaxed`] құрайды, ал егер [`Release`]-ті қолданса, [`Relaxed`] жүктеме бөлігін құрайды.
            ///
            /// **Ескерту**: Бұл әдіс тек атомдық операцияларды қолдайтын платформаларда қол жетімді
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # `compare_exchange` және `compare_exchange_weak` көшу
            ///
            /// `compare_and_swap` жадқа тапсырыс беру үшін келесі кескінмен `compare_exchange`-ге тең:
            ///
            /// Түпнұсқа |Табыс |Сәтсіздік
            /// -------- | ------- | -------
            /// Босаңсыған |Босаңсыған |Бос емес сатып алу |Сатып алу |Шығарылымды сатып алу |Шығарылым |Босаңсыған AcqRel |AcqRel |SeqCst сатып алу |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` салыстыру сәтті болған кезде де жалған сәтсіздікке жол беріледі, бұл компиляторға салыстыру және ауыстыру циклде қолданылған кезде жақсы құрастыру кодын жасауға мүмкіндік береді.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Ағымдағы мән `current` мәнімен бірдей болса, мәнді атом бүтін санына сақтайды.
            ///
            /// Қайтарылатын мән-бұл жаңа мәннің жазылғанын және алдыңғы мәнді қамтитындығын көрсететін нәтиже.
            /// Сәтті болған кезде бұл мәнге `current`-ке тең кепілдік беріледі.
            ///
            /// `compare_exchange` осы операцияның жадының орналасуын сипаттау үшін екі [`Ordering`] аргументін алады.
            /// `success` егер `current`-пен салыстыру сәтті болса, оқылатын-түрлендіретін-жазылатын операцияға қажетті тапсырысты сипаттайды.
            /// `failure` салыстыру сәтсіз болған кезде орын алатын жүктеме жұмысына қажетті тапсырыс беруді сипаттайды.
            /// [`Acquire`]-ті сәтті тапсырыс ретінде пайдалану дүкенді [`Relaxed`] операциясының бөлігі етеді, ал [`Release`]-ті [`Relaxed`] сәтті жүктейді.
            ///
            /// Сәтсіздікке тапсырыс беру тек [`SeqCst`], [`Acquire`] немесе [`Relaxed`] болуы мүмкін және сәтті тапсырыс берудің баламасы немесе әлсіз болуы керек.
            ///
            /// **Ескерту**: Бұл әдіс тек атомдық операцияларды қолдайтын платформаларда қол жетімді
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // ҚАУІПСІЗДІК: деректер жарыстарының алдын-алуды атомның ішкі факторлары жүзеге асырады.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Ағымдағы мән `current` мәнімен бірдей болса, мәнді атом бүтін санына сақтайды.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// бұл функция салыстырмалы түрде сәтті болған кезде де жалған түрде істен шығуға мүмкіндік береді, бұл кейбір платформаларда тиімдірек код әкелуі мүмкін.
            /// Қайтарылатын мән-бұл жаңа мәннің жазылғанын және алдыңғы мәнді қамтитындығын көрсететін нәтиже.
            ///
            /// `compare_exchange_weak` осы операцияның жадының орналасуын сипаттау үшін екі [`Ordering`] аргументін алады.
            /// `success` егер `current`-пен салыстыру сәтті болса, оқылатын-түрлендіретін-жазылатын операцияға қажетті тапсырысты сипаттайды.
            /// `failure` салыстыру сәтсіз болған кезде орын алатын жүктеме жұмысына қажетті тапсырыс беруді сипаттайды.
            /// [`Acquire`]-ті сәтті тапсырыс ретінде пайдалану дүкенді [`Relaxed`] операциясының бөлігі етеді, ал [`Release`]-ті [`Relaxed`] сәтті жүктейді.
            ///
            /// Сәтсіздікке тапсырыс беру тек [`SeqCst`], [`Acquire`] немесе [`Relaxed`] болуы мүмкін және сәтті тапсырыс берудің баламасы немесе әлсіз болуы керек.
            ///
            /// **Ескерту**: Бұл әдіс тек атомдық операцияларды қолдайтын платформаларда қол жетімді
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// mut mut= val.load(Ordering::Relaxed) болсын;
            /// цикл {let new=old * 2;
            ///     матч val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // ҚАУІПСІЗДІК: деректер жарыстарының алдын-алуды атомның ішкі факторлары жүзеге асырады.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Алдыңғы мәнді қайтара отырып, ағымдағы мәнге қосылады.
            ///
            /// Бұл операция толып кетуге оралады.
            ///
            /// `fetch_add` осы операцияның жадының реттілігін сипаттайтын [`Ordering`] аргументін алады.Тапсырыстың барлық режимдері мүмкін.
            /// [`Acquire`]-ті пайдалану осы операцияның сақтау бөлігін [`Relaxed`]-ге, ал [`Release`]-ті пайдалану [`Relaxed`]-ті құрайды.
            ///
            ///
            /// **Ескерту**: Бұл әдіс тек атомдық операцияларды қолдайтын платформаларда қол жетімді
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // ҚАУІПСІЗДІК: деректер жарыстарының алдын-алуды атомның ішкі факторлары жүзеге асырады.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Алдыңғы мәнді қайтара отырып, ағымдағы мәннен шығарады.
            ///
            /// Бұл операция толып кетуге оралады.
            ///
            /// `fetch_sub` осы операцияның жадының реттілігін сипаттайтын [`Ordering`] аргументін алады.Тапсырыстың барлық режимдері мүмкін.
            /// [`Acquire`]-ті пайдалану осы операцияның сақтау бөлігін [`Relaxed`]-ге, ал [`Release`]-ті пайдалану [`Relaxed`]-ті құрайды.
            ///
            ///
            /// **Ескерту**: Бұл әдіс тек атомдық операцияларды қолдайтын платформаларда қол жетімді
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // ҚАУІПСІЗДІК: деректер жарыстарының алдын-алуды атомның ішкі факторлары жүзеге асырады.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Ағымдағы мәнмен биттік "and".
            ///
            /// Ағымдағы мән мен `val` аргументі бойынша биттік "and" әрекетін орындайды және нәтижеге жаңа мән орнатады.
            ///
            /// Алдыңғы мәнді қайтарады.
            ///
            /// `fetch_and` осы операцияның жадының реттілігін сипаттайтын [`Ordering`] аргументін алады.Тапсырыстың барлық режимдері мүмкін.
            /// [`Acquire`]-ті пайдалану осы операцияның сақтау бөлігін [`Relaxed`]-ге, ал [`Release`]-ті пайдалану [`Relaxed`]-ті құрайды.
            ///
            ///
            /// **Ескерту**: Бұл әдіс тек атомдық операцияларды қолдайтын платформаларда қол жетімді
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // ҚАУІПСІЗДІК: деректер жарыстарының алдын-алуды атомның ішкі факторлары жүзеге асырады.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Ағымдағы мәнмен биттік "nand".
            ///
            /// Ағымдағы мән мен `val` аргументі бойынша биттік "nand" әрекетін орындайды және нәтижеге жаңа мән орнатады.
            ///
            /// Алдыңғы мәнді қайтарады.
            ///
            /// `fetch_nand` осы операцияның жадының реттілігін сипаттайтын [`Ordering`] аргументін алады.Тапсырыстың барлық режимдері мүмкін.
            /// [`Acquire`]-ті пайдалану осы операцияның сақтау бөлігін [`Relaxed`]-ге, ал [`Release`]-ті пайдалану [`Relaxed`]-ті құрайды.
            ///
            ///
            /// **Ескерту**: Бұл әдіс тек атомдық операцияларды қолдайтын платформаларда қол жетімді
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // ҚАУІПСІЗДІК: деректер жарыстарының алдын-алуды атомның ішкі факторлары жүзеге асырады.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Ағымдағы мәнмен биттік "or".
            ///
            /// Ағымдағы мән мен `val` аргументі бойынша биттік "or" әрекетін орындайды және нәтижеге жаңа мән орнатады.
            ///
            /// Алдыңғы мәнді қайтарады.
            ///
            /// `fetch_or` осы операцияның жадының реттілігін сипаттайтын [`Ordering`] аргументін алады.Тапсырыстың барлық режимдері мүмкін.
            /// [`Acquire`]-ті пайдалану осы операцияның сақтау бөлігін [`Relaxed`]-ге, ал [`Release`]-ті пайдалану [`Relaxed`]-ті құрайды.
            ///
            ///
            /// **Ескерту**: Бұл әдіс тек атомдық операцияларды қолдайтын платформаларда қол жетімді
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // ҚАУІПСІЗДІК: деректер жарыстарының алдын-алуды атомның ішкі факторлары жүзеге асырады.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Ағымдағы мәнмен биттік "xor".
            ///
            /// Ағымдағы мән мен `val` аргументі бойынша биттік "xor" әрекетін орындайды және нәтижеге жаңа мән орнатады.
            ///
            /// Алдыңғы мәнді қайтарады.
            ///
            /// `fetch_xor` осы операцияның жадының реттілігін сипаттайтын [`Ordering`] аргументін алады.Тапсырыстың барлық режимдері мүмкін.
            /// [`Acquire`]-ті пайдалану осы операцияның сақтау бөлігін [`Relaxed`]-ге, ал [`Release`]-ті пайдалану [`Relaxed`]-ті құрайды.
            ///
            ///
            /// **Ескерту**: Бұл әдіс тек атомдық операцияларды қолдайтын платформаларда қол жетімді
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // ҚАУІПСІЗДІК: деректер жарыстарының алдын-алуды атомның ішкі факторлары жүзеге асырады.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Мәнді алып, оған қосымша жаңа мән беретін функцияны қолданады.Егер `Some(_)` функциясы қайтарылса, басқасы `Err(previous_value)` болса, `Result`-тің `Result` мәнін қайтарады.
            ///
            /// Note: Бұл функция функцияны бірнеше рет шақыруы мүмкін, егер мәні осы уақыт аралығында басқа ағындардан өзгертілсе, егер функция `Some(_)` қайтаратын болса, бірақ функция сақталған мәнге бір рет қана қолданылған болады.
            ///
            ///
            /// `fetch_update` осы операцияның жадының орналасуын сипаттау үшін екі [`Ordering`] аргументін алады.
            /// Біріншісі операцияның сәтті аяқталуы үшін қажетті тапсырысты сипаттайды, ал екіншісі жүктемелерге қажетті тапсырысты сипаттайды.Бұлар сәттілік пен сәтсіздікке байланысты бұйрықтарға сәйкес келеді
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// [`Acquire`]-ті сәтті тапсырыс ретінде пайдалану дүкенді [`Relaxed`] операциясының бөлігі етеді, ал [`Release`]-ті [`Relaxed`] сәтті жүктемесі жасайды.
            /// (failed) жүктемесіне тапсырыс беру тек [`SeqCst`], [`Acquire`] немесе [`Relaxed`] болуы мүмкін және ол сәтті тапсырыс берудің баламасы немесе әлсіз болуы керек.
            ///
            /// **Ескерту**: Бұл әдіс тек атомдық операцияларды қолдайтын платформаларда қол жетімді
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Тапсырыс: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Тапсырыс: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Ағымдағы мәнмен максимум.
            ///
            /// Ағымдағы мәннің максимумы мен `val` аргументін табады және жаңа мәнді нәтижеге қояды.
            ///
            /// Алдыңғы мәнді қайтарады.
            ///
            /// `fetch_max` осы операцияның жадының реттілігін сипаттайтын [`Ordering`] аргументін алады.Тапсырыстың барлық режимдері мүмкін.
            /// [`Acquire`]-ті пайдалану осы операцияның сақтау бөлігін [`Relaxed`]-ге, ал [`Release`]-ті пайдалану [`Relaxed`]-ті құрайды.
            ///
            ///
            /// **Ескерту**: Бұл әдіс тек атомдық операцияларды қолдайтын платформаларда қол жетімді
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// жол=42;
            /// max_foo=foo.fetch_max (бар, Ordering::SeqCst).max(bar);
            /// бекіту! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // ҚАУІПСІЗДІК: деректер жарыстарының алдын-алуды атомның ішкі факторлары жүзеге асырады.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Ағымдағы мәнмен минимум.
            ///
            /// Ағымдағы мәннің минимумы мен `val` аргументін табады және нәтижеге жаңа мәнді қояды.
            ///
            /// Алдыңғы мәнді қайтарады.
            ///
            /// `fetch_min` осы операцияның жадының реттілігін сипаттайтын [`Ordering`] аргументін алады.Тапсырыстың барлық режимдері мүмкін.
            /// [`Acquire`]-ті пайдалану осы операцияның сақтау бөлігін [`Relaxed`]-ге, ал [`Release`]-ті пайдалану [`Relaxed`]-ті құрайды.
            ///
            ///
            /// **Ескерту**: Бұл әдіс тек атомдық операцияларды қолдайтын платформаларда қол жетімді
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// бар=12;
            /// min_foo=foo.fetch_min (бар, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // ҚАУІПСІЗДІК: деректер жарыстарының алдын-алуды атомның ішкі факторлары жүзеге асырады.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Өзгеретін көрсеткішті негізгі бүтін санға қайтарады.
            ///
            /// Алынған бүтін санға атомдық емес оқу және жазу мәліметтер жарысы бола алады.
            /// Бұл әдіс көбінесе функционалдық қолтаңба қолдануы мүмкін FFI үшін пайдалы
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// `*mut` сілтемесін осы атомға ортақ сілтемеден қайтару қауіпсіз, себебі атом түрлері интерьердің өзгергіштігімен жұмыс істейді.
            /// Атомның барлық модификациялары жалпы сілтеме арқылы мәнді өзгертеді және атомдық операцияларды қолданған кезде оны қауіпсіз жасай алады.
            /// Қайтарылған шикі меңзерді кез-келген пайдалану үшін `unsafe` блогы қажет және сол шектеуді сақтау керек: ондағы әрекеттер атомдық болуы керек.
            ///
            ///
            /// # Examples
            ///
            /// «» (extern-declaration) елемеу
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// сыртқы "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // ҚАУІПСІЗДІК: `my_atomic_op` атомдық болғанша қауіпсіз.
            /// қауіпті {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // ҚАУІПСІЗДІК: қоңырау шалушы `atomic_store` қауіпсіздік шартын сақтауы керек.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // ҚАУІПСІЗДІК: қоңырау шалушы `atomic_load` қауіпсіздік шартын сақтауы керек.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ҚАУІПСІЗДІК: қоңырау шалушы `atomic_swap` қауіпсіздік шартын сақтауы керек.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Алдыңғы мәнді қайтарады (__sync_fetch_and_add сияқты).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ҚАУІПСІЗДІК: қоңырау шалушы `atomic_add` қауіпсіздік шартын сақтауы керек.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Алдыңғы мәнді қайтарады (__sync_fetch_and_sub сияқты).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ҚАУІПСІЗДІК: қоңырау шалушы `atomic_sub` қауіпсіздік шартын сақтауы керек.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // ҚАУІПСІЗДІК: қоңырау шалушы `atomic_compare_exchange` қауіпсіздік шартын сақтауы керек.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // ҚАУІПСІЗДІК: қоңырау шалушы `atomic_compare_exchange_weak` қауіпсіздік шартын сақтауы керек.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ҚАУІПСІЗДІК: қоңырау шалушы `atomic_and` қауіпсіздік шартын сақтауы керек
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ҚАУІПСІЗДІК: қоңырау шалушы `atomic_nand` қауіпсіздік шартын сақтауы керек
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ҚАУІПСІЗДІК: қоңырау шалушы `atomic_or` қауіпсіздік шартын сақтауы керек
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ҚАУІПСІЗДІК: қоңырау шалушы `atomic_xor` қауіпсіздік шартын сақтауы керек
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// максималды мәнді қайтарады (қол қойылған салыстыру)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ҚАУІПСІЗДІК: қоңырау шалушы `atomic_max` қауіпсіздік шартын сақтауы керек
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// минималды мәнді қайтарады (қол қойылған салыстыру)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ҚАУІПСІЗДІК: қоңырау шалушы `atomic_min` қауіпсіздік шартын сақтауы керек
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// максималды мәнді қайтарады (қол қойылмаған салыстыру)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ҚАУІПСІЗДІК: қоңырау шалушы `atomic_umax` қауіпсіздік шартын сақтауы керек
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// мин мәнін қайтарады (қол қойылмаған салыстыру)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ҚАУІПСІЗДІК: қоңырау шалушы `atomic_umin` қауіпсіздік шартын сақтауы керек
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Атом қоршауы.
///
/// Көрсетілген тәртіпке байланысты қоршау компилятор мен процессордың айналасындағы жад операцияларының белгілі бір түрлерін қайта реттеуге мүмкіндік бермейді.
/// Бұл атомдық операциялармен немесе басқа жіптердегі қоршаулармен өзара байланысты синхронизация жасайды.
///
/// (Кем дегенде) [`Release`] семантикасына тапсырыс беретін 'A' қоршау, егер X және Y операциялары болған жағдайда ғана, 'M' кейбір атомдық объектілерінде жұмыс істейтін, егер A тізбектелген болса, (кем дегенде) [`Acquire`] семантикасымен 'B' қоршаумен үндестіріледі. Х, У синхрондалады, ал В өзгереді және М өзгереді.
/// Бұл А мен В арасындағы тәуелділікті қамтамасыз етеді.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// [`Release`] немесе [`Acquire`] семантикасы бар атомдық операциялар да қоршаумен үндестіре алады.
///
/// [`SeqCst`] тапсырысымен қоршау, сонымен қатар [`Acquire`] және [`Release`] семантикасына ие, басқа [`SeqCst`] операцияларының және/немесе қоршаулардың ғаламдық бағдарламалық тәртібіне қатысады.
///
/// [`Acquire`], [`Release`], [`AcqRel`] және [`SeqCst`] тапсырыстарын қабылдайды.
///
/// # Panics
///
/// Panics, егер `order` [`Relaxed`] болса.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Спинлокқа негізделген өзара алып тастау.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Ескі мән `false` болғанша күтіңіз.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Бұл қоршау `unlock` дүкенімен үндестіріледі.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // ҚАУІПСІЗДІК: атом қоршауын пайдалану қауіпсіз.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Компилятордың жадының қоршауы.
///
/// `compiler_fence` машина кодын шығармайды, бірақ компиляторға қайта тапсырыс берудің жад түрлерін шектейді.Дәлірек айтқанда, берілген [`Ordering`] семантикасына байланысты, компиляторға `compiler_fence` қоңырауының басқа жағына қоңырау шалғанға дейін немесе одан кейін оқуға немесе жазуға қозғалуға тыйым салынуы мүмкін.Бұл **аппараттық құралдың* мұндай қайта тапсырыс беруге ** ** кедергі жасамайтынын ескеріңіз.
///
/// Бұл бір ағынды, орындау контекстінде проблема емес, бірақ басқа ағындар бір уақытта жадты өзгерте алатын кезде, [`fence`] сияқты синхрондаудың күшті примитивтері қажет.
///
/// Әр түрлі тапсырыс семантикасы кедергі келтіретін қайта тапсырыс:
///
///  - [`SeqCst`] көмегімен осы тармақ бойынша оқуды және жазуды қайта реттеуге жол берілмейді.
///  - [`Release`] көмегімен оқудың және жазудың алдындағы кейінгі жазбалардан өту мүмкін емес.
///  - [`Acquire`] көмегімен келесі оқулар мен жазуларды алдыңғы оқулардан бұрын жылжыту мүмкін емес.
///  - [`AcqRel`] көмегімен жоғарыда аталған екі ереже де орындалады.
///
/// `compiler_fence` әдетте жіптің *өзімен* жарысуын болдырмау үшін ғана пайдалы.Яғни, егер берілген ағын кодтың бір бөлігін орындайтын болса, содан кейін үзіліп, басқа жерде кодты орындай бастаса (әлі де сол тізбекте, ал концептуалды түрде сол ядрода болса).Дәстүрлі бағдарламаларда бұл сигнал өңдеушісі тіркелген кезде ғана болуы мүмкін.
/// Төмен деңгейлі кодта мұндай жағдайлар үзілістерді өңдеу кезінде, жасыл жіптерді алдын-ала имплементациялау кезінде және т.б. туындауы мүмкін.
/// Қызықты оқырмандар Linux ядросының [memory barriers] туралы талқылауын оқуға шақырылады.
///
/// # Panics
///
/// Panics, егер `order` [`Relaxed`] болса.
///
/// # Examples
///
/// `compiler_fence` болмаса, келесі кодтағы `assert_eq!` барлық ағындарда болғанына қарамастан, сәттілікке *кепілдік бермейді*.
/// Неліктен екенін білу үшін, компилятор дүкендерді `IMPORTANT_VARIABLE` және `IS_READ`-ке ауыстыра алады, өйткені олар екеуі де `Ordering::Relaxed`.Егер ол орын алса және сигнал өңдегіш `IS_READY` жаңартылғаннан кейін шақырылса, онда сигнал өңдеуші `IS_READY=1`, бірақ `IMPORTANT_VARIABLE=0` көрінеді.
/// `compiler_fence` пайдалану бұл жағдайды түзетеді.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // ертерек жазудың осы сәттен тыс қозғалуына жол бермеңіз
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // ҚАУІПСІЗДІК: атом қоршауын пайдалану қауіпсіз.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Процессорға бос күтуге болатын спин-циклдің ішінде («айналдыру құлпы») сигнал береді.
///
/// Бұл функция [`hint::spin_loop`] пайдасына шешілмеген.
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}