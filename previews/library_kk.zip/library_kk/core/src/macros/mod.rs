#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Қоңырау шалушының шығарылымына байланысты `$crate::panic::panic_2015` немесе `$crate::panic::panic_2021` мәндеріне дейін кеңейеді.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Екі өрнектің бір-біріне тең екендігін растайды ([`PartialEq`] көмегімен).
///
/// panic-де бұл макрос өрнектердің мәндерін олардың түзету көріністерімен басып шығарады.
///
///
/// [`assert!`] сияқты, бұл макростың екінші формасы бар, мұнда тапсырыс бойынша panic хабарламасын беруге болады.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Төмендегі қайта туылу әдейі жасалған.
                    // Оларсыз қарызға арналған стек ұясы мәндер салыстырылғанға дейін инициализацияланып, айтарлықтай баяулауға әкеледі.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Төмендегі қайта туылу әдейі жасалған.
                    // Оларсыз қарызға арналған стек ұясы мәндер салыстырылғанға дейін инициализацияланып, айтарлықтай баяулауға әкеледі.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Екі өрнектің бір-біріне тең еместігін растайды ([`PartialEq`] көмегімен).
///
/// panic-де бұл макрос өрнектердің мәндерін олардың түзету көріністерімен басып шығарады.
///
///
/// [`assert!`] сияқты, бұл макростың екінші формасы бар, мұнда тапсырыс бойынша panic хабарламасын беруге болады.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Төмендегі қайта туылу әдейі жасалған.
                    // Оларсыз қарызға арналған стек ұясы мәндер салыстырылғанға дейін инициализацияланып, айтарлықтай баяулауға әкеледі.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Төмендегі қайта туылу әдейі жасалған.
                    // Оларсыз қарызға арналған стек ұясы мәндер салыстырылғанға дейін инициализацияланып, айтарлықтай баяулауға әкеледі.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Логикалық өрнек жұмыс кезінде `true` екенін растайды.
///
/// Егер бұл берілген өрнекті жұмыс уақытында `true` деңгейіне дейін бағалау мүмкін болмаса, бұл [`panic!`] макросын шақырады.
///
/// [`assert!`] сияқты, бұл макростың да екінші нұсқасы бар, мұнда тапсырыс бойынша panic хабарламасын беруге болады.
///
/// # Uses
///
/// [`assert!`]-тен айырмашылығы, `debug_assert!` операторлары әдепкі бойынша тек оңтайландырылмаған құрылымдарда қосылады.
/// Оңтайландырылған құрастыру егер `-C debug-assertions` компиляторға берілмесе, `debug_assert!` операторларын орындамайды.
/// Бұл `debug_assert!`-ті шығарылымда болуы өте қымбат, бірақ әзірлеу кезінде пайдалы болуы мүмкін чектерге пайдалы етеді.
/// `debug_assert!` кеңейту нәтижесі әрдайым тексеріліп отырады.
///
/// Тексерілмеген тұжырым сәйкес келмейтін күйдегі бағдарламаның жұмысын жалғастыра береді, бұл күтпеген салдарға алып келуі мүмкін, бірақ бұл тек қауіпсіз кодта болған жағдайда қауіпсіздікті енгізбейді.
///
/// Бекітулердің тиімділігі, жалпы алғанда, өлшенбейді.
/// [`assert!`]-ті `debug_assert!`-ге ауыстыру мұқият профильден кейін ғана, ең бастысы қауіпсіз кодта ғана ұсынылады!
///
/// # Examples
///
/// ```
/// // осы тұжырымдарға арналған panic хабары берілген өрнектің жолдық мәні болып табылады.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // өте қарапайым функция
/// debug_assert!(some_expensive_computation());
///
/// // теңшелетін хабарламамен бекітіңіз
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Екі өрнектің бір-біріне тең екендігін дәлелдейді.
///
/// panic-де бұл макрос өрнектердің мәндерін олардың түзету көріністерімен басып шығарады.
///
/// [`assert_eq!`]-тен айырмашылығы, `debug_assert_eq!` операторлары әдепкі бойынша тек оңтайландырылмаған құрылымдарда қосылады.
/// Оңтайландырылған құрастыру егер `-C debug-assertions` компиляторға берілмесе, `debug_assert_eq!` операторларын орындамайды.
/// Бұл `debug_assert_eq!`-ті шығарылымда болуы өте қымбат, бірақ әзірлеу кезінде пайдалы болуы мүмкін чектерге пайдалы етеді.
///
/// `debug_assert_eq!` кеңейту нәтижесі әрдайым тексеріліп отырады.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Екі өрнектің бір-біріне тең еместігін дәлелдейді.
///
/// panic-де бұл макрос өрнектердің мәндерін олардың түзету көріністерімен басып шығарады.
///
/// [`assert_ne!`]-тен айырмашылығы, `debug_assert_ne!` операторлары әдепкі бойынша оңтайландырылмаған құрылымдарда ғана қосылады.
/// Оңтайландырылған құрастыру егер `-C debug-assertions` компиляторға берілмесе, `debug_assert_ne!` операторларын орындамайды.
/// Бұл `debug_assert_ne!`-ті шығарылымда болуы өте қымбат, бірақ әзірлеу кезінде пайдалы болуы мүмкін чектерге пайдалы етеді.
///
/// `debug_assert_ne!` кеңейту нәтижесі әрдайым тексеріліп отырады.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Берілген өрнектің берілген үлгілердің кез-келгеніне сәйкес келетіндігін қайтарады.
///
/// `match` өрнегі сияқты, өрнектің еркімен `if` және өрнекпен байланысқан атауларға рұқсаты бар қорғаушы өрнек болуы мүмкін.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Нәтижені ашады немесе оның қатесін таратады.
///
/// `?` операторы `try!` орнына қосылды және оның орнына қолданылуы керек.
/// Сонымен қатар, `try`-бұл Rust 2018-де сақталған сөз, сондықтан оны қолдану керек болса, сізге [raw-identifier syntax][ris] пайдалану қажет болады: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` берілген [`Result`] сәйкес келеді.`Ok` нұсқасында өрнек оралған мәннің мәніне ие болады.
///
/// Егер `Err` нұсқасы болса, ол ішкі қатені қалпына келтіреді.Содан кейін `try!` конверсияны `From` көмегімен жүзеге асырады.
/// Бұл мамандандырылған және жалпы қателер арасындағы автоматты түрлендіруді қамтамасыз етеді.
/// Алынған қате кейін бірден қайтарылады.
///
/// Ерте қайтарылғандықтан, `try!` тек [`Result`] қайтаратын функцияларда қолданыла алады.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Қателерді жылдам қайтарудың қолайлы әдісі
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Қателерді жылдам қайтарудың алдыңғы әдісі
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Бұл балама:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Пішімделген деректерді буферге жазады.
///
/// Бұл макро 'writer', формат жолын және аргументтер тізімін қабылдайды.
/// Дәлелдер көрсетілген формат жолына сәйкес форматталады және нәтиже жазушыға беріледі.
/// Жазушы `write_fmt` әдісімен кез келген құндылық болуы мүмкін;әдетте бұл [`fmt::Write`] немесе [`io::Write`] trait іске асырылуынан туындайды.
/// Макрос `write_fmt` әдісі қайтарғанның бәрін қайтарады;әдетте [`fmt::Result`] немесе [`io::Result`].
///
/// Пішім жолының синтаксисі туралы қосымша ақпарат алу үшін [`std::fmt`] бөлімін қараңыз.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Модуль `std::fmt::Write` және `std::io::Write` екеуін де импорттай алады және `write!`-ті екеуін де жүзеге асыратын объектілерге шақыра алады, өйткені нысандар әдетте екеуін де жүзеге асырмайды.
///
/// Алайда, модуль traits білікті импорттауы керек, сондықтан олардың атаулары сәйкес келмейді:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt қолданады
///     write!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt қолданады
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Бұл макросты `no_std` қондырғыларында да қолдануға болады.
/// `no_std` қондырғысында сіз компоненттер туралы егжей-тегжейлі жауап бересіз.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Пішімделген деректерді буферге, жаңа жол қосылып жазыңыз.
///
/// Барлық платформаларда жаңа жол тек (`\n`/`U+000A`) LINE FEED таңбасы болып табылады (қосымша CARRIAGE RETURN (`\r`/`U+000D`) жоқ).
///
/// Қосымша ақпарат алу үшін [`write!`] қараңыз.Пішім жолының синтаксисі туралы ақпаратты [`std::fmt`] бөлімінен қараңыз.
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Модуль `std::fmt::Write` және `std::io::Write` екеуін де импорттай алады және `write!`-ті екеуін де жүзеге асыратын объектілерге шақыра алады, өйткені нысандар әдетте екеуін де жүзеге асырмайды.
/// Алайда, модуль traits білікті импорттауы керек, сондықтан олардың атаулары сәйкес келмейді:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt қолданады
///     writeln!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt қолданады
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Қол жетімді емес кодты көрсетеді.
///
/// Бұл компилятор кейбір кодтардың қол жетімді еместігін анықтай алмайтын кез-келген уақытта пайдалы.Мысалға:
///
/// * Қолдарды күзет шарттарымен сәйкестендіру.
/// * Динамикалық түрде тоқтатылатын циклдар.
/// * Динамикалық түрде тоқтатылатын итераторлар.
///
/// Егер кодқа қол жетімді еместігі анықталса, бағдарлама [`panic!`] көмегімен дереу тоқтатылады.
///
/// Бұл макростың қауіпті аналогы-[`unreachable_unchecked`] функциясы, ол кодқа жеткенде анықталмаған мінез-құлықты тудырады.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Бұл әрқашан [`panic!`] болады.
///
/// # Examples
///
/// Қол матчтары:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // түсініктеме берілсе қате құрастыру
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // x/3-тің ең кедей енгізілімдерінің бірі
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Орындалмаған кодты "not implemented" хабарламасымен дүрбелең арқылы көрсетеді.
///
/// Бұл сіздің кодты теруді тексеруге мүмкіндік береді, егер сіз trait прототипін жасасаңыз немесе енгізсеңіз, ол сізге қолдануды жоспарламайтын бірнеше әдісті қажет етеді.
///
/// `unimplemented!` пен [`todo!`] арасындағы айырмашылық мынада: `todo!` функционалдылықты кейінірек іске асыруға ниет білдірсе, ал хабарлама "not yet implemented" болса, `unimplemented!` мұндай шағымдар жасамайды.
/// Оның хабарламасы-"not implemented".
/// Сондай-ақ, кейбір IDE-де «todo!» Таңбасы болады.
///
/// # Panics
///
/// Бұл әрдайым [`panic!`] болады, өйткені `unimplemented!`-бұл `panic!` үшін тіркелген, нақты хабарламасы бар стенография.
///
/// `panic!` сияқты, бұл макроста теңшелетін мәндерді көрсетуге арналған екінші форма бар.
///
/// # Examples
///
/// Бізде trait `Foo` бар деп айтыңыз:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Біз `Foo`-ті 'MyStruct' үшін іске асырғымыз келеді, бірақ қандай да бір себептермен `bar()` функциясын жүзеге асырудың мәні бар.
/// `baz()` және `qux()`-ті `Foo`-ті жүзеге асырған кезде анықтау қажет болады, бірақ біз `unimplemented!`-ті олардың анықтамаларында кодты құрастыруға мүмкіндік беру үшін қолдана аламыз.
///
/// Егер әлі де орындалмаған әдістерге қол жеткізілсе, біз бағдарламамыздың жұмысын тоқтатқымыз келеді.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // `baz` үшін `MyStruct` мағынасы жоқ, сондықтан бізде бұл жерде ешқандай қисын жоқ.
/////
///         // Бұл "thread 'main' panicked at 'not implemented'" көрсетеді.
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Мұнда бізде қисын бар, орындалмағанға хабарлама қосуға болады!жіберіп алғандығымызды көрсету үшін.
///         // Мұнда: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Аяқталмаған кодты көрсетеді.
///
/// Егер сіз прототип жасасаңыз және кодты теруді тексергіңіз келсе, бұл сізге пайдалы болуы мүмкін.
///
/// [`unimplemented!`] пен `todo!` арасындағы айырмашылық мынада: `todo!` функционалдылықты кейінірек іске асыруға ниет білдірсе, ал хабарлама "not yet implemented" болса, `unimplemented!` мұндай шағымдар жасамайды.
/// Оның хабарламасы-"not implemented".
/// Сондай-ақ, кейбір IDE-де «todo!» Таңбасы болады.
///
/// # Panics
///
/// Бұл әрқашан [`panic!`] болады.
///
/// # Examples
///
/// Міне, кейбір орындалатын кодтардың мысалы.Бізде trait `Foo` бар:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Біз `Foo`-ті өзіміздің бір түрімізге енгізгіміз келеді, сонымен бірге алдымен `bar()`-де жұмыс істегіміз келеді.Біздің кодты құрастыру үшін біз `baz()`-ті қолдануымыз керек, сондықтан біз `todo!`-ті қолдана аламыз:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // іске асыру осында жүреді
///     }
///
///     fn baz(&self) {
///         // әзірге baz()-ті енгізу туралы алаңдамайық
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // біз тіпті baz() қолданбаймыз, сондықтан бұл жақсы.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Кіріктірілген макростардың анықтамалары.
///
/// Макроқасиеттердің көп бөлігі (тұрақтылық, көріну және т.б.) мұнда бастапқы кодтан алынған, кеңейту функцияларынан басқа, макро кірістерді шығысқа түрлендіреді, бұл функцияларды компилятор қамтамасыз етеді.
///
///
pub(crate) mod builtin {

    /// Кездесу кезінде берілген қате туралы хабарламада компиляция сәтсіз аяқталады.
    ///
    /// Бұл макросты crate шартты компиляция стратегиясын қате жағдайларға қатысты қате туралы жақсы хабарлармен қамтамасыз ету үшін қолданған кезде қолдану керек.
    ///
    /// Бұл [`panic!`]-тің компилятор деңгейіндегі формасы, бірақ *орындалу уақытында* емес,*компиляция* кезінде қате жібереді.
    ///
    /// # Examples
    ///
    /// Осындай екі мысал-макростар және `#[cfg]` орталары.
    ///
    /// Егер макростің жарамсыз мәндері берілсе, компилятордың қателігін шығарыңыз.
    /// Соңғы branch болмаса, компилятор қате жібереді, бірақ қате туралы хабарламада екі жарамды мән туралы айтылмайды.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Егер бірқатар мүмкіндіктердің бірі қол жетімді болмаса, компилятор қатесін жіберіңіз.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Жолды форматтаудың басқа макростарының параметрлерін құрастырады.
    ///
    /// Бұл макрост әрбір қосымша аргумент үшін `{}` бар форматты жолды әріптік формада қабылдау арқылы жұмыс істейді.
    /// `format_args!` шығыс жол ретінде түсіндірілуін қамтамасыз ететін қосымша параметрлерді дайындайды және аргументтерді бір типке канондық етеді.
    /// [`Display`] trait-ді іске асыратын кез-келген мәнді `format_args!`-ке беруге болады, сондай-ақ кез-келген [`Debug`]-ті форматтау жолында `{:?}`-ке беруге болады.
    ///
    ///
    /// Бұл макрос [`fmt::Arguments`] типін шығарады.Бұл мәнді пайдалы қайта бағыттауды жүзеге асыру үшін [`std::fmt`] ішіндегі макростарға беруге болады.
    /// Барлық басқа форматтау макростарын ([«формат!»], [`write!`], [`println!`] және т.с.с.) осы прокси арқылы жүзеге асырады.
    /// `format_args!`, оның алынған макростарынан айырмашылығы, үйінділерді бөлуден аулақ болады.
    ///
    /// `format_args!` `Debug` және `Display` контекстінде қайтаратын [`fmt::Arguments`] мәнін төменде көрсетілгендей пайдалануға болады.
    /// Мысалда сонымен қатар `Debug` және `Display` форматтарының бірдей болатындығы көрсетілген: `format_args!` форматындағы интерполяцияланған жол.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Қосымша ақпарат алу үшін [`std::fmt`] құжаттамасын қараңыз.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// `format_args`-мен бірдей, бірақ соңында жаңа жол қосады.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Компиляция кезінде қоршаған ортаның айнымалысын тексереді.
    ///
    /// Бұл макрос компиляция кезінде аталған орта айнымалысының мәніне дейін кеңейіп, `&'static str` типінің өрнегін береді.
    ///
    ///
    /// Егер қоршаған орта айнымалысы анықталмаса, онда компиляция қатесі шығады.
    /// Компиляция қатесін шығармау үшін оның орнына [`option_env!`] макросын қолданыңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Сіз қате туралы хабарламаны жолды екінші параметр ретінде беру арқылы теңшей аласыз:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Егер `documentation` ортасының айнымалысы анықталмаса, келесі қате пайда болады:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Компиляция кезінде қоршаған ортаның айнымалысын қалауы бойынша тексереді.
    ///
    /// Егер аталған орта айнымалысы компиляция кезінде болса, онда ол `Option<&'static str>` типті өрнекке айналады, оның мәні қоршаған ортаның айнымалы мәнінің `Some` құрайды.
    /// Егер қоршаған ортаның айнымалысы болмаса, онда бұл `None` дейін кеңейеді.
    /// Бұл түр туралы көбірек ақпарат алу үшін [`Option<T>`][Option] бөлімін қараңыз.
    ///
    /// Осы макросты қолданған кезде компиляция уақытының қателігі ешқашан қоршаған ортаның айнымалысының бар-жоғына қарамастан шығарылмайды.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Идентификаторларды бір идентификаторға біріктіреді.
    ///
    /// Бұл макроста үтірмен бөлінген идентификаторлардың кез-келген санын алады және олардың барлығын біріктіріп, жаңа идентификатор болып табылатын өрнек береді.
    /// Гигиена бұл макро жергілікті айнымалыларды ұстай алмайтындай етіп жасайтынын ескеріңіз.
    /// Сондай-ақ, жалпы ереже бойынша, макростарға тек элементте, мәлімдемеде немесе өрнек жағдайында ғана рұқсат етіледі.
    /// Бұл дегеніміз, сіз осы макросты қолданыстағы айнымалыларға, функцияларға немесе модульдерге сілтеме жасау үшін қолдана аласыз, бірақ онымен жаңасын анықтай алмайсыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (жаңа, қызықты, атауы) { }//осылайша қолдануға болмайды!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Әріптерді статикалық жіп кесіндісіне біріктіреді.
    ///
    /// Бұл макроста кез-келген үтірмен бөлінген литерал қабылданады және `&'static str` типті өрнек береді, ол солдан оңға қарай тізбектелген барлық литералдарды білдіреді.
    ///
    ///
    /// Бүтін және өзгермелі нүктелік литералдар тізбектелу үшін қатаңдалған.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ол шақырылған жол нөміріне дейін кеңейтіледі.
    ///
    /// [`column!`] және [`file!`] көмегімен бұл макростар әзірлеушілерге дерек көзі ішіндегі орналасу туралы түзету туралы ақпарат береді.
    ///
    /// Кеңейтілген өрнектің `u32` типі бар және ол 1-ге негізделген, сондықтан әр файлдағы бірінші жол 1-ге, екіншісі 2-ге және т.б.
    /// Бұл жалпы компиляторлардың немесе танымал редакторлардың қателік туралы хабарламаларына сәйкес келеді.
    /// Қайтарылған жол *міндетті түрде*`line!` шақыру сызығының өзі емес, `line!` макросының шақырылуына әкелетін алғашқы макро шақыру болып табылады.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Ол шақырылған баған нөміріне дейін кеңейтіледі.
    ///
    /// [`line!`] және [`file!`] көмегімен бұл макростар әзірлеушілерге дерек көзі ішіндегі орналасу туралы түзету туралы ақпарат береді.
    ///
    /// Кеңейтілген өрнектің `u32` типі бар және ол 1-ге негізделген, сондықтан әр жолдағы бірінші баған 1-ге, екіншісі 2-ге және т.б.
    /// Бұл жалпы компиляторлардың немесе танымал редакторлардың қателік туралы хабарламаларына сәйкес келеді.
    /// Қайтарылған баған *міндетті түрде*`column!` шақыру сызығының сызығы емес, `column!` макросының шақырылуына әкелетін алғашқы макро шақыру болып табылады.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Ол шақырылған файл атауын кеңейтеді.
    ///
    /// [`line!`] және [`column!`] көмегімен бұл макростар әзірлеушілерге дерек көзі ішіндегі орналасу туралы түзету туралы ақпарат береді.
    ///
    /// Кеңейтілген өрнектің `&'static str` типі бар, ал қайтарылған файл `file!` макросының шақыруы емес, `file!` макросының шақырылуына әкелетін алғашқы макро шақыру болып табылады.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Оның аргументтерін анықтайды.
    ///
    /// Бұл макростан `&'static str` типінің өрнегін береді, бұл макроға өткен барлық tokens стринфикациясы.
    /// Макро шақырудың синтаксисіне ешқандай шектеулер қойылмайды.
    ///
    /// tokens енгізуінің кеңейтілген нәтижелері future өзгеруі мүмкін екенін ескеріңіз.Шығарылымға сенетін болсаңыз, абай болуыңыз керек.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Жол ретінде UTF-8 кодталған файлды қамтиды.
    ///
    /// Файл ағымдағы файлға қатысты орналасқан (модульдердің табылуына ұқсас).
    /// Берілген жол компиляция кезінде платформаға тән тәсілмен түсіндіріледі.
    /// Мәселен, мысалы, `\` кері сызығы бар Windows жолымен шақыру Unix-те дұрыс құрастырылмайды.
    ///
    ///
    /// Бұл макроста файл мазмұны болып табылатын `&'static str` типінің өрнегі пайда болады.
    ///
    /// # Examples
    ///
    /// Бір каталогта келесі мазмұнмен екі файл бар деп есептеңіз:
    ///
    /// 'spanish.in' файлы:
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// 'main.rs' файлы:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs' компиляциясы және алынған екілік жүйені іске қосу "adiós" басып шығарады.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Файлды байт массивіне сілтеме ретінде қосады.
    ///
    /// Файл ағымдағы файлға қатысты орналасқан (модульдердің табылуына ұқсас).
    /// Берілген жол компиляция кезінде платформаға тән тәсілмен түсіндіріледі.
    /// Мәселен, мысалы, `\` кері сызығы бар Windows жолымен шақыру Unix-те дұрыс құрастырылмайды.
    ///
    ///
    /// Бұл макроста файл мазмұны болып табылатын `&'static [u8; N]` типінің өрнегі пайда болады.
    ///
    /// # Examples
    ///
    /// Бір каталогта келесі мазмұнмен екі файл бар деп есептеңіз:
    ///
    /// 'spanish.in' файлы:
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// 'main.rs' файлы:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs' компиляциясы және алынған екілік жүйені іске қосу "adiós" басып шығарады.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ағымдағы модуль жолын көрсететін жолға дейін кеңейеді.
    ///
    /// Ағымдағы модуль жолын crate root-ге дейін апаратын модульдердің иерархиясы деп санауға болады.
    /// Қайтарылған жолдың бірінші компоненті-қазіргі кезде құрастырылып жатқан crate атауы.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Конфигурация жалауларының логикалық тіркесімдерін компиляция кезінде бағалайды.
    ///
    /// `#[cfg]` атрибутына қосымша, бұл макро конфигурация жалауларын логикалық өрнекті бағалауға мүмкіндік беру үшін ұсынылған.
    /// Бұл жиі қайталанбайтын кодқа әкеледі.
    ///
    /// Бұл макросқа берілген синтаксис [`cfg`] атрибутымен бірдей синтаксис.
    ///
    /// `cfg!`, `#[cfg]`-тен айырмашылығы, ешбір кодты алып тастамайды және тек шын немесе жалған деп бағаланады.
    /// Мысалы, if/else өрнегіндегі барлық блоктар, егер `cfg!` бағалайтынына қарамастан, шарт үшін `cfg!` қолданылған кезде жарамды болуы керек.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Файлды мәнмәтінге сәйкес өрнек немесе элемент ретінде талдайды.
    ///
    /// Файл ағымдағы файлға қатысты орналасқан (модульдердің табылуына ұқсас).Берілген жол компиляция кезінде платформаға тән тәсілмен түсіндіріледі.
    /// Мәселен, мысалы, `\` кері сызығы бар Windows жолымен шақыру Unix-те дұрыс құрастырылмайды.
    ///
    /// Бұл макросты қолдану көбінесе жаман идея болып табылады, өйткені егер файл өрнек ретінде талданса, оны қоршаған ортаға гигиеналық емес түрде орналастырады.
    /// Бұл айнымалылардың немесе функциялардың ағымдағы файлда бірдей атауы бар айнымалылар немесе функциялар болған жағдайда, файл күткеннен өзгеше болуына әкелуі мүмкін.
    ///
    ///
    /// # Examples
    ///
    /// Бір каталогта келесі мазмұнмен екі файл бар деп есептеңіз:
    ///
    /// 'monkeys.in' файлы:
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// 'main.rs' файлы:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs' компиляциясы және алынған екілік жүйені іске қосу "🙈🙊🙉🙈🙊🙉" басып шығарады.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Логикалық өрнек жұмыс кезінде `true` екенін растайды.
    ///
    /// Егер бұл берілген өрнекті жұмыс уақытында `true` деңгейіне дейін бағалау мүмкін болмаса, бұл [`panic!`] макросын шақырады.
    ///
    /// # Uses
    ///
    /// Бекіту әрдайым түзету кезінде де, шығарылымда да тексеріледі және оларды өшіру мүмкін емес.
    /// Әдепкі бойынша шығарылымдарда қосылмаған бекіту туралы [`debug_assert!`] қараңыз.
    ///
    /// Қауіпсіз код жұмыс уақытының инварианттарын қолдану үшін `assert!`-ке сенім артуы мүмкін, егер бұл бұзылған жағдайда қауіпсіздікке әкелуі мүмкін.
    ///
    /// `assert!`-тің басқа жағдайларына қауіпсіз кодтағы жұмыс уақытының инварианттарын сынау және енгізу кіреді (оның бұзылуы қауіпсіздікке әкелмейді).
    ///
    ///
    /// # Жеке хабарламалар
    ///
    /// Бұл макростың екінші формасы бар, онда panic таңдамалы хабарламасы форматтауға арналған аргументтермен немесе онсыз ұсынылуы мүмкін.
    /// Бұл форма үшін синтаксис үшін [`std::fmt`] қараңыз.
    /// Пішім аргументі ретінде қолданылатын өрнектер, егер тұжырым орындалмаса ғана бағаланады.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // осы тұжырымдарға арналған panic хабары берілген өрнектің жолдық мәні болып табылады.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // өте қарапайым функция
    ///
    /// assert!(some_computation());
    ///
    /// // теңшелетін хабарламамен бекітіңіз
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Ішкі құрастыру.
    ///
    /// Пайдалану үшін [unstable book] оқыңыз.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM стиліндегі кірістірілген құрастыру.
    ///
    /// Пайдалану үшін [unstable book] оқыңыз.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Модуль деңгейіндегі кірістірілген құрастыру.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Басып шығарулар tokens-ді стандартты шығарылымға жіберді.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Басқа макростарды жөндеу үшін пайдаланылатын бақылау функциясын қосады немесе ажыратады.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Туынды макростарды қолдану үшін қолданылатын атрибуттық макро.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Функцияға қолданылған төлсипат макросы, оны бірлік сынағына айналдыру үшін.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Функцияға арналған атрибуттық макросты эталондық тестке айналдыру үшін қолданылады.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]` және `#[bench]` макростарының егжей-тегжейі.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Әлемдік бөлгіш ретінде тіркеу үшін статикалық атрибуттың макросы статикалыққа қолданылады.
    ///
    /// Сондай-ақ, [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html) қараңыз.
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Өткен жолға қол жетімді болса, ол қолданылатын элементті сақтайды, әйтпесе оны алып тастайды.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Қолданылатын код фрагментіндегі барлық `#[cfg]` және `#[cfg_attr]` атрибуттарын кеңейтеді.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// `rustc` компиляторының тұрақсыз орындалу бөлшектері, пайдаланбаңыз.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// `rustc` компиляторының тұрақсыз орындалу бөлшектері, пайдаланбаңыз.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}