//! Стандартты кітапханада Panic қолдауы.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// panic туралы ақпарат беретін құрылым.
///
/// `PanicInfo` құрылым [`set_hook`] функциясы орнатылған panic hook-ге беріледі.
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// panic-мен байланысты пайдалы жүктемені қайтарады.
    ///
    /// Бұл әдетте, бірақ әрқашан емес, `&'static str` немесе [`String`] болады.
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// Егер `core` crate-тен `panic!` макросы (`std`-тен емес) форматтау жолымен және кейбір қосымша аргументтермен қолданылса, ол хабарламаны, мысалы, [`fmt::write`] көмегімен пайдалануға дайын етіп қайтарады
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// Егер бар болса, panic шыққан жер туралы ақпаратты қайтарады.
    ///
    /// Бұл әдіс әрқашан [`Some`]-ті қайтарады, бірақ бұл future нұсқаларында өзгеруі мүмкін.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: Егер бұл кейде «Жоқ» деп өзгертілсе,
        // бұл жағдайды std::panicking::default_hook және std::panicking::begin_panic_fmt-та қарастыру.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: біз downcast_ref қолдана алмаймыз: :<String>() Мұнда
        // String libcore-да қол жетімді емес!
        // `std::panic!` бірнеше аргументтермен шақырылған кезде пайдалы жүктеме-бұл String, бірақ бұл жағдайда хабарлама да қол жетімді.
        //

        self.location.fmt(formatter)
    }
}

/// panic орналасқан жері туралы ақпаратты қамтитын құрылым.
///
/// Бұл құрылымды [`PanicInfo::location()`] жасайды.
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// Теңдік пен тапсырыс бойынша салыстырулар файлда, жолда, содан кейін баған басымдығында жасалады.
/// Файлдар `Path` емес, жолдармен салыстырылады, бұл күтпеген болуы мүмкін.
/// Толығырақ талқылау үшін [«Location: : file»] құжаттамасын қараңыз.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// Осы функцияның қоңырау шалушысының бастапқы орнын қайтарады.
    /// Егер бұл функцияның қоңырау шалушысы түсіндірмеленсе, онда оның қоңырау орны қайтарылады және қадағаланбаған функциялар денесіндегі бірінші қоңырауға стек бойынша жалғасады.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// Ол шақырылған [`Location`] қайтарады.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// Осы функцияның анықтамасынан [`Location`] қайтарады.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // бірдей бақыланбаған функцияны басқа жерде іске қосу бізге бірдей нәтиже береді
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // бақыланатын функцияны басқа жерде іске қосу басқа мән шығарады
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// panic шыққан бастапқы файлдың атын қайтарады.
    ///
    /// # `&str`, `&Path` емес
    ///
    /// Қайтарылған атау компиляция жүйесіндегі бастапқы жолға сілтеме жасайды, бірақ оны тікелей `&Path` ретінде көрсету дұрыс емес.
    /// Құрастырылған код мазмұнды қамтамасыз ететін жүйеден гөрі басқа `Path` іске асырылуымен басқа жүйеде жұмыс істей алады және бұл кітапханада басқа "host path" типі жоқ.
    ///
    /// Ең таңқаларлық мінез-құлық, "the same" файлына модуль жүйесіндегі бірнеше жолдар арқылы қол жетімді болған кезде пайда болады (әдетте `#[path = "..."]` атрибутын немесе сол сияқты), бұл бірдей код сияқты көрінетіндіктен, осы функциядан әртүрлі мәндерді қайтарады.
    ///
    ///
    /// # Cross-compilation
    ///
    /// Бұл мән хост платформасы мен мақсатты платформа айырмашылығы болған кезде `Path::new` немесе ұқсас конструкторларға өтуге жарамайды.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// panic шыққан жол нөмірін қайтарады.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// panic пайда болған бағанды қайтарады.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// Libstd-тен libstd-ден `panic_unwind`-ге және басқа panic жұмыс уақытына мәліметтер жіберу үшін қолданылатын ішкі trait.
/// Жақында тұрақтандыруға арналмаған, пайдаланбаңыз.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// Мазмұнға толық иелік ету.
    /// Қайтару түрі іс жүзінде `Box<dyn Any + Send>`, бірақ біз `Box`-ті libcore-да қолдана алмаймыз.
    ///
    /// Осы әдіс шақырылғаннан кейін, `self`-де кейбір әдепкі мәндер ғана қалады.
    /// Бұл әдіске екі рет қоңырау шалу немесе осы әдісті шақырғаннан кейін `get`-ке қоңырау шалу-қате.
    ///
    /// Аргумент panic жұмыс уақыты (`__rust_start_panic`) тек қарызға алынған `dyn BoxMeUp` алады, өйткені алынған.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// Тек мазмұнын қарызға алыңыз.
    fn get(&mut self) -> &(dyn Any + Send);
}