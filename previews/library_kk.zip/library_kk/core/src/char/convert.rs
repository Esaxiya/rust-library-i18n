//! Таңбаларды түрлендіру.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// `u32`-ті `char`-ге түрлендіреді.
///
/// Барлық [`char`] жарамды [`u32`] s-ге тең болатындығын ескеріңіз
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Алайда, керісінше дұрыс емес: [[u32`] барлық жарамды [`char`] с емес.
/// `from_u32()` егер кіріс [`char`] үшін жарамды мән болмаса, `None` мәнін қайтарады.
///
/// Бұл тексерулерді елемейтін бұл функцияның қауіпті нұсқасын [`from_u32_unchecked`] бөлімінен қараңыз.
///
///
/// # Examples
///
/// Негізгі пайдалану:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Кіріс жарамсыз [`char`] болмаған кезде `None` қайтару:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Жарамдылығын ескермей, `u32`-ті `char`-ке ауыстырады.
///
/// Барлық [`char`] жарамды [`u32`] s-ге тең болатындығын ескеріңіз
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Алайда, керісінше дұрыс емес: [[u32`] барлық жарамды [`char`] с емес.
/// `from_u32_unchecked()` бұны елемейді және [`char`]-ке соқырлықпен жібереді, мүмкін жарамсызын жасайды.
///
///
/// # Safety
///
/// Бұл функция қауіпті, себебі ол жарамсыз `char` мәндерін құруы мүмкін.
///
/// Бұл функцияның қауіпсіз нұсқасын [`from_u32`] функциясын қараңыз.
///
/// # Examples
///
/// Негізгі пайдалану:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // ҚАУІПСІЗДІК: қоңырау шалушы `i` жарамды мән екеніне кепілдік беруі керек.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// [`char`]-ті [`u32`] түрлендіреді.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// [`char`]-ті [`u64`] түрлендіреді.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Char кодтық нүктенің мәніне жіберіледі, содан кейін нөлге 64 битке дейін кеңейтіледі.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] қараңыз
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// [`char`]-ті [`u128`] түрлендіреді.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Char кодтық нүктенің мәніне жіберіледі, содан кейін нөлге 128 битке дейін кеңейтіледі.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] қараңыз
        c as u128
    }
}

/// Байтты 0x00 ..=0xFF форматында кодтық нүктесі бірдей мәнге ие болатын `char`-ге U + 0000 ..=U + 00FF түрінде бейнелейді.
///
/// Юникод IANA ISO-8859-1 деп атайтын таңбалық кодтауымен байтты тиімді декодтайтындай етіп жасалған.
/// Бұл кодтау ASCII-мен үйлесімді.
///
/// Бұл ISO/IEC 8859-1 ака-дан өзгеше екенін ескеріңіз
/// ISO 8859-1 (бір дефис кем), ол "blanks" шамасын қалдырады, олар ешқандай таңбаға берілмейді.
/// ISO-8859-1 (IANA) оларды C0 және C1 басқару кодтарына тағайындайды.
///
/// Бұл Windows-1252 ака-дан *басқаша* екенін ескеріңіз
/// 1252 код парағы, бұл ISO/IEC 8859-1 суперсетігі, ол тыныш белгілеріне және әр түрлі латын таңбаларына кейбір (барлығы емес!) бос орындарды тағайындайды.
///
/// Одан әрі шатастыру үшін [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` және `windows-1252`-бұл барлық бос орындарды тиісті C0 және C1 басқару кодтарымен толтыратын Windows-1252 суперсетіне арналған бүркеншік аттар.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// [`u8`]-ті [`char`] түрлендіреді.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Char талдағанда қайтарылатын қате.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // ҚАУІПСІЗДІК: бұл юникодтың заңды мәні екенін тексерді
            Ok(unsafe { transmute(i) })
        }
    }
}

/// u32-тен char-ға түрлендіру сәтсіз болған кезде қате түрі қайтарылды.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Берілген радиустағы цифрды `char`-ке ауыстырады.
///
/// Мұндағы 'radix' кейде оны 'base' деп те аталады.
/// Екіге тең радиус, екілік санды, ондық радиусты, ондықты және он алтылық он алтылық радиусты, кейбір ортақ мәндерді береді.
///
/// Ерікті радикалдарға қолдау көрсетіледі.
///
/// `from_digit()` егер берілген радиуста цифр болмаса, `None` мәнін қайтарады.
///
/// # Panics
///
/// Panics, егер 36-дан үлкен радиус берілсе.
///
/// # Examples
///
/// Негізгі пайдалану:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // 11-ондық-бұл 16-негіздегі бір цифр
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Кіріс сан болмаған кезде `None` қайтару:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// panic тудыратын үлкен радикалдан өту:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}