//! импл char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// `char` кодының ең жоғарғы жарамды коды болуы мүмкін.
    ///
    /// `char`-бұл [Unicode Scalar Value], бұл оның [Code Point] екенін білдіреді, бірақ белгілі бір ауқымдағы ғана.
    /// `MAX` бұл [Unicode Scalar Value] жарамды ең жоғарғы жарамды код нүктесі.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () кодты декодтау кезінде қатені көрсету үшін Юникодта қолданылады.
    ///
    /// Бұл, мысалы, [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy)-ге дұрыс қалыптаспаған UTF-8 байттарын беру кезінде пайда болуы мүмкін.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Unicode бөліктері `char` және `str` әдістеріне негізделген [Unicode](http://www.unicode.org/) нұсқасы.
    ///
    /// Юникодтың жаңа нұсқалары жүйелі түрде шығарылады, содан кейін стандартты кітапханадағы Unicode-ге байланысты барлық әдістер жаңартылады.
    /// Сондықтан кейбір `char` және `str` әдістерінің мінез-құлқы және осы тұрақты мәні уақыт өткен сайын өзгереді.
    /// Бұл *өзгеріс деп саналмайды*.
    ///
    /// Нұсқаларды нөмірлеу схемасы [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4)-де түсіндірілген.
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Жүктелмеген суррогаттарды «Err» деп қайтара отырып, `iter`-те UTF-16 кодталған нүктелерінің үстінен итератор жасайды.
    ///
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// `Err` нәтижелерін ауыстыру сипатымен ауыстыру арқылы шығын декодерін алуға болады:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// `u32`-ті `char`-ге түрлендіреді.
    ///
    /// Барлық «char» жарамды [`u32`] s-ге тең болатынын ескеріңіз
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Алайда, керісінше дұрыс емес: барлық жарамды [`u32 '] жарамды` char`с емес.
    /// `from_u32()` егер кіріс `char` үшін жарамды мән болмаса, `None` мәнін қайтарады.
    ///
    /// Бұл тексерулерді елемейтін бұл функцияның қауіпті нұсқасын [`from_u32_unchecked`] бөлімінен қараңыз.
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Кіріс жарамсыз `char` болмаған кезде `None` қайтару:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Жарамдылығын ескермей, `u32`-ті `char`-ке ауыстырады.
    ///
    /// Барлық «char» жарамды [`u32`] s-ге тең болатынын ескеріңіз
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Алайда, керісінше дұрыс емес: барлық жарамды [`u32 '] жарамды` char`с емес.
    /// `from_u32_unchecked()` бұны елемейді және `char`-ке соқырлықпен жібереді, мүмкін жарамсызын жасайды.
    ///
    ///
    /// # Safety
    ///
    /// Бұл функция қауіпті, себебі ол жарамсыз `char` мәндерін құруы мүмкін.
    ///
    /// Бұл функцияның қауіпсіз нұсқасын [`from_u32`] функциясын қараңыз.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // ҚАУІПСІЗДІК: қауіпсіздік шартын қоңырау шалушы сақтауы керек.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Берілген радиустағы цифрды `char`-ке ауыстырады.
    ///
    /// Мұндағы 'radix' кейде оны 'base' деп те аталады.
    /// Екіге тең радиус, екілік санды, ондық радиусты, ондықты және он алтылық он алтылық радиусты, кейбір ортақ мәндерді береді.
    ///
    /// Ерікті радикалдарға қолдау көрсетіледі.
    ///
    /// `from_digit()` егер берілген радиуста цифр болмаса, `None` мәнін қайтарады.
    ///
    /// # Panics
    ///
    /// Panics, егер 36-дан үлкен радиус берілсе.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // 11-ондық-бұл 16-негіздегі бір цифр
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Кіріс сан болмаған кезде `None` қайтару:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// panic тудыратын үлкен радикалдан өту:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// `char` берілген радиустағы цифр екенін тексереді.
    ///
    /// Мұндағы 'radix' кейде оны 'base' деп те аталады.
    /// Екіге тең радиус, екілік санды, ондық радиусты, ондықты және он алтылық он алтылық радиусты, кейбір ортақ мәндерді береді.
    ///
    /// Ерікті радикалдарға қолдау көрсетіледі.
    ///
    /// [`is_numeric()`]-мен салыстырғанда бұл функция тек `0-9`, `a-z` және `A-Z` таңбаларын таниды.
    ///
    /// 'Digit' тек келесі символдар ретінде анықталған:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// 'digit' туралы толығырақ түсіну үшін [`is_numeric()`] қараңыз.
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics, егер 36-дан үлкен радиус берілсе.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// panic тудыратын үлкен радикалдан өту:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// `char`-ті берілген радиустағы цифрға айналдырады.
    ///
    /// Мұндағы 'radix' кейде оны 'base' деп те аталады.
    /// Екіге тең радиус, екілік санды, ондық радиусты, ондықты және он алтылық он алтылық радиусты, кейбір ортақ мәндерді береді.
    ///
    /// Ерікті радикалдарға қолдау көрсетіледі.
    ///
    /// 'Digit' тек келесі символдар ретінде анықталған:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Егер `char` берілген радиустағы цифрға сілтеме жасамаса, `None` мәнін қайтарады.
    ///
    /// # Panics
    ///
    /// Panics, егер 36-дан үлкен радиус берілсе.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Сандық емес нәтиже беру нәтижесіз аяқталады:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// panic тудыратын үлкен радикалдан өту:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // коды мұнда `radix` тұрақты және 10 немесе одан кіші жағдайлардың орындалу жылдамдығын жақсарту үшін бөлінеді
        //
        let val = if likely(radix <= 10) {
            // Егер цифр болмаса, радикалдан үлкен сан құрылады.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Таңбаның он алтылық Unicode қашуын беретін «char`s» түріндегі итераторды қайтарады.
    ///
    /// Бұл `\u{NNNNNN}` формасындағы Rust синтаксисімен таңбалардан қашады, мұндағы `NNNNNN`-оналтылық бейнелеу.
    ///
    ///
    /// # Examples
    ///
    /// Итератор ретінде:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!`-ті тікелей пайдалану:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Екеуі тең:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// `to_string` пайдалану:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // or-ing 1 c==0 үшін кодтың бір цифрды басып шығаруға болатындығын және (ол бірдей)(31, 32) ағынды болдырмауын қамтамасыз етеді
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // ең маңызды он алтылық санның индексі
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Кеңейтілген графикалық код нүктелерінен қашуға мүмкіндік беретін `escape_debug` кеңейтілген нұсқасы.
    /// Бұл бізге жолдың басында болған кезде бос емес белгілер сияқты таңбаларды жақсырақ форматтауға мүмкіндік береді.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Таңбаның қашып кету кодын `char`s ретінде беретін итераторды қайтарады.
    ///
    /// Бұл `str` немесе `char` іске қосуларына ұқсас таңбалардан қашып кетеді.
    ///
    ///
    /// # Examples
    ///
    /// Итератор ретінде:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!`-ті тікелей пайдалану:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Екеуі тең:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// `to_string` пайдалану:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Таңбаның қашып кету кодын `char`s ретінде беретін итераторды қайтарады.
    ///
    /// Әдепкі бойынша, әр түрлі тілдерде, соның ішінде C++ 11 және осыған ұқсас C-отбасылық тілдерде заңды болып табылатын литералдар шығаруға бейімділік таңдалады.
    /// Нақты ережелер:
    ///
    /// * Tab `\t` ретінде қашып кетті.
    /// * Арбаны қайтару `\r` ретінде қашып кетті.
    /// * Желілік берілім `\n` ретінде қашып кетті.
    /// * Бір баға ұсынысы `\'` ретінде қашып кетті.
    /// * Екі баға ұсынысы `\"` ретінде қашып кетті.
    /// * Артқы сызық `\\` ретінде қашып кетті.
    /// * `0x20` .. `0x7e` қоса 'басып шығарылатын ASCII' диапазонындағы кез-келген таңбадан қашпайды.
    /// * Барлық басқа таңбаларға Unicode қашықтықтан он алтылық берілген;[`escape_unicode`] қараңыз.
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Итератор ретінде:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!`-ті тікелей пайдалану:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Екеуі тең:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// `to_string` пайдалану:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Егер UTF-8 кодталған болса, бұл `char` қажет болатын байт санын қайтарады.
    ///
    /// Бұл байт саны әрдайым 1-ден 4-ке дейін, қоса алғанда.
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str` типі оның мазмұны UTF-8 екендігіне кепілдік береді, сондықтан `&str`-те әр кодтық нүкте `char` ретінде ұсынылған болса, біз оның ұзындығын салыстыра аламыз:
    ///
    ///
    /// ```
    /// // Чарстар ретінде
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // екеуі де үш байт түрінде ұсынылуы мүмкін
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // &str ретінде бұл екеуі UTF-8 кодталған
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // олардың барлығы алты байт алатындығын көреміз ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... дәл &str сияқты
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Егер UTF-16 кодталған болса, `char` қажет болатын 16 биттік код бірліктерінің санын қайтарады.
    ///
    ///
    /// Осы тұжырымдаманы көбірек түсіндіру үшін [`len_utf8()`] құжаттамасын қараңыз.
    /// Бұл функция айна, бірақ UTF-8 орнына UTF-16 үшін.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Берілген байт буферіне бұл таңбаны UTF-8 ретінде кодтайды, содан кейін кодталған таңбаны қамтитын буфердің кіші бөлімін қайтарады.
    ///
    ///
    /// # Panics
    ///
    /// Буфер жеткіліксіз болса, Panics.
    /// Ұзындығы төрт буфер кез-келген `char` кодтауға жеткілікті үлкен.
    ///
    /// # Examples
    ///
    /// Осы екі мысалда да 'ß' екі байтты кодтайды.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Тым аз буфер:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // ҚАУІПСІЗДІК: `char` суррогат емес, сондықтан бұл UTF-8 жарамды.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Берілген `u16` буферіне бұл таңбаны UTF-16 ретінде кодтайды, содан кейін кодталған таңбаны қамтитын буфердің кіші бөлімін қайтарады.
    ///
    ///
    /// # Panics
    ///
    /// Буфер жеткіліксіз болса, Panics.
    /// Ұзындығы 2 буфер кез-келген `char` кодтауға жеткілікті үлкен.
    ///
    /// # Examples
    ///
    /// Осы мысалдардың екеуінде де '𝕊' екі `u16 'кодтайды.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Тым аз буфер:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Егер `char`-те `Alphabetic` қасиеті болса, `true` қайтарады.
    ///
    /// `Alphabetic` [Unicode Standard] 4-тарауында (таңбалардың қасиеттері) сипатталған және [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-де көрсетілген.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // махаббат-бұл көп нәрсе, бірақ бұл әріптік емес
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Егер `char`-те `Lowercase` қасиеті болса, `true` қайтарады.
    ///
    /// `Lowercase` [Unicode Standard] 4-тарауында (таңбалардың қасиеттері) сипатталған және [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-де көрсетілген.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Түрлі қытай сценарийлері мен пунктуациялары жоқ, сондықтан:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Егер `char`-те `Uppercase` қасиеті болса, `true` қайтарады.
    ///
    /// `Uppercase` [Unicode Standard] 4-тарауында (таңбалардың қасиеттері) сипатталған және [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-де көрсетілген.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Түрлі қытай сценарийлері мен пунктуациялары жоқ, сондықтан:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Егер `char`-те `White_Space` қасиеті болса, `true` қайтарады.
    ///
    /// `White_Space` [Unicode Character Database][ucd] [`PropList.txt`]-де көрсетілген.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // үзілмейтін кеңістік
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Егер `char` [`is_alphabetic()`] немесе [`is_numeric()`]-ге сәйкес келсе, `true` қайтарады.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Егер `char` басқару кодтары үшін жалпы санатқа ие болса, `true` қайтарады.
    ///
    /// Басқару кодтары (`Cc` жалпы санаты бар кодтық нүктелер) [Unicode Standard] 4-тарауында (таңбалардың қасиеттері) сипатталған және [Unicode Character Database][ucd] [`UnicodeData.txt`]-де көрсетілген.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// // U + 009C, STRING ТЕРМИНАТОРЫ
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Егер `char`-те `Grapheme_Extend` қасиеті болса, `true` қайтарады.
    ///
    /// `Grapheme_Extend` [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] сипатталған және [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] көрсетілген.
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Егер `char` сандарға арналған жалпы санаттардың бірі болса, `true` қайтарады.
    ///
    /// Сандарға арналған жалпы санаттар (ондық цифрлар үшін `Nd`, әріп тәрізді сандық белгілер үшін `Nl` және басқа сандық белгілер үшін `No`) [Unicode Character Database][ucd] [`UnicodeData.txt`]-те көрсетілген.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Негізгі пайдалану:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Осы `char` картасының кіші әріптерін бір немесе бірнеше етіп беретін итераторды қайтарады
    /// `char`s.
    ///
    /// Егер бұл `char`-де кіші әріппен салыстыру болмаса, итератор бірдей `char` береді.
    ///
    /// Егер бұл `char`-те [Unicode Character Database][ucd] [`UnicodeData.txt`] келтірілген бір-біріне кіші әріптермен салыстыру болса, итератор `char`-ны береді.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Егер бұл `char` арнайы қарастыруды қажет етсе (мысалы, бірнеше ``char ''), итератор [`SpecialCasing.txt`] келтірген`char` (лар) ды береді.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Бұл операция шартсыз картаны бейімделусіз орындайды.Яғни конверсия контекст пен тілге тәуелді емес.
    ///
    /// [Unicode Standard] бөлімінде 4-тарауда (таңбалардың сипаттары) жалпы жағдайларды салыстыру, ал 3-тарауда (Conformance) жағдайларды түрлендірудің әдепкі алгоритмін қарастырады.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Итератор ретінде:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!`-ті тікелей пайдалану:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Екеуі тең:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// `to_string` пайдалану:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Кейде нәтиже бірнеше таңбадан тұрады:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Үлкен және кіші әріптері жоқ таңбалар өздеріне айналады.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Осы `char` картасының бас әріптерін бір немесе бірнеше етіп беретін итераторды қайтарады
    /// `char`s.
    ///
    /// Егер бұл `char`-де бас әріппен салыстыру болмаса, итератор бірдей `char` береді.
    ///
    /// Егер бұл `char`-те [Unicode Character Database][ucd] [`UnicodeData.txt`] ұсынған бір-бірден бас әріппен бейнелеу болса, итератор `char` береді.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Егер бұл `char` арнайы қарастыруды қажет етсе (мысалы, бірнеше ``char ''), итератор [`SpecialCasing.txt`] келтірген`char` (лар) ды береді.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Бұл операция шартсыз картаны бейімделусіз орындайды.Яғни конверсия контекст пен тілге тәуелді емес.
    ///
    /// [Unicode Standard] бөлімінде 4-тарауда (таңбалардың сипаттары) жалпы жағдайларды салыстыру, ал 3-тарауда (Conformance) жағдайларды түрлендірудің әдепкі алгоритмін қарастырады.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Итератор ретінде:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!`-ті тікелей пайдалану:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Екеуі тең:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// `to_string` пайдалану:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Кейде нәтиже бірнеше таңбадан тұрады:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Үлкен және кіші әріптері жоқ таңбалар өздеріне айналады.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Тіл туралы ескерту
    ///
    /// Латын тіліндегі 'i' эквивалентінің екі түрінің орнына бес түрі бар:
    ///
    /// * 'Dotless': I/ı, кейде ï деп жазылады
    /// * 'Dotted': İ/i
    ///
    /// Нүктелі 'i' латынмен бірдей екенін ескеріңіз.Сондықтан:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Мұндағы `upper_i` мәні мәтін тіліне сүйенеді: егер біз `en-US`-те болсақ, ол `"I"`, ал егер `tr_TR`-те болсақ, онда `"İ"` болуы керек.
    /// `to_uppercase()` мұны ескермейді, сондықтан:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// тілдерге қатысты.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Мәннің ASCII ауқымында екендігін тексереді.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Мәннің көшірмесін ASCII бас әріптің эквивалентіне айналдырады.
    ///
    /// 'a'-тен 'z'-ке дейінгі ASCII әріптері 'A'-тен 'Z'-ге дейін салыстырылады, бірақ ASCII емес әріптер өзгермейді.
    ///
    /// Орнындағы мәнді бас әріпке айналдыру үшін [`make_ascii_uppercase()`] пайдаланыңыз.
    ///
    /// ASCII емес таңбалардан басқа ASCII таңбаларын бас әріпке айналдыру үшін [`to_uppercase()`] пайдаланыңыз.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Мәннің ASCII кіші эквивалентіндегі көшірмесін жасайды.
    ///
    /// 'A'-тен 'Z'-ке дейінгі ASCII әріптері 'a'-тен 'z'-ге дейін салыстырылады, бірақ ASCII емес әріптер өзгермейді.
    ///
    /// Орындағы мәнді кішірейту үшін [`make_ascii_lowercase()`] пайдаланыңыз.
    ///
    /// ASCII таңбаларына қосымша ASCII символдарын кішірейту үшін [`to_lowercase()`] пайдаланыңыз.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Екі мәннің ASCII регистрге сәйкес келмейтін сәйкестігін тексереді.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)`-ге тең.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Бұл типті орнына ASCII бас әріптің баламасына айналдырады.
    ///
    /// 'a'-тен 'z'-ке дейінгі ASCII әріптері 'A'-тен 'Z'-ге дейін салыстырылады, бірақ ASCII емес әріптер өзгермейді.
    ///
    /// Бұрыннан өзгермеген жаңа жоғарғы мәнді қайтару үшін [`to_ascii_uppercase()`] пайдаланыңыз.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Бұл түрді орнына ASCII кіші әріптің эквивалентіне айналдырады.
    ///
    /// 'A'-тен 'Z'-ке дейінгі ASCII әріптері 'a'-тен 'z'-ге дейін салыстырылады, бірақ ASCII емес әріптер өзгермейді.
    ///
    /// Бұрыннан өзгермеген жаңа кіші мәнді қайтару үшін [`to_ascii_lowercase()`] пайдаланыңыз.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Мәннің ASCII алфавиттік таңбасы екенін тексереді:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', немесе
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Мәннің ASCII бас әріп таңбасы екенін тексереді:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Мәннің ASCII кіші таңбасы екенін тексереді:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Мәннің ASCII әріптік-цифрлық таңбасы екенін тексереді:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', немесе
    /// - U + 0061 'a' ..=U + 007A 'z', немесе
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Мәннің ASCII ондық таңбасы екенін тексереді:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Мән ASCII он алтылық цифры екенін тексереді:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', немесе
    /// - U + 0041 'A' ..=U + 0046 'F', немесе
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Мәннің ASCII тыныс белгісі екенін тексереді:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, немесе
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, немесе
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, немесе
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Мәннің ASCII графикалық таңбасы екенін тексереді:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Мәннің ASCII бос кеңістік таңбасы екенін тексереді:
    /// U + 0020 кеңістік, U + 0009 горизонтальды таблица, U + 000A сызықты қоректендіру, U + 000C формалы тамақтандыру немесе U + 000D КӨШІМДІ ҚАЙТАРУ.
    ///
    /// Rust WhatWG Infra Standard [definition of ASCII whitespace][infra-aw] қолданады.Кең қолданыста тағы бірнеше анықтамалар бар.
    /// Мысалы, [the POSIX locale][pct] құрамына U + 000B VERTICAL TAB және барлық жоғарыда келтірілген таңбалар кіреді, бірақ дәл сол сипаттамадан-[Bourne shell ішіндегі "field splitting" үшін әдепкі ереже][bfs]*тек* SPACE, HORIZONTAL TAB және Бос кеңістік ретінде LINE FEED.
    ///
    ///
    /// Егер сіз бұрыннан бар файл пішімін өңдейтін бағдарлама жазып жатсаңыз, онда осы функцияны қолданар алдында осы кеңістіктің бос кеңістіктің анықтамасы қандай екенін тексеріңіз.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Мәннің ASCII басқару таңбасы екенін тексереді:
    /// U + 0000 NUL ..=U + 001F БІРЛІКТІ СЕПЕРАТОР, немесе U + 007F ЖОЮ.
    /// Бос кеңістіктегі ASCII таңбаларының көпшілігі басқарушы таңбалар болып табылатындығына назар аударыңыз, бірақ SPACE жоқ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Берілген байт буферіне шикі u32 мәнін UTF-8 ретінде кодтайды, содан кейін кодталған таңбаны қамтитын буфердің кіші бөлімін қайтарады.
///
///
/// `char::encode_utf8`-тен айырмашылығы, бұл әдіс суррогат диапазонындағы кодтық нүктелермен де жұмыс істейді.
/// (Суррогат диапазонында `char` құру UB.) Нәтиже [generalized UTF-8] жарамды, бірақ UTF-8 жарамсыз.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Буфер жеткіліксіз болса, Panics.
/// Ұзындығы төрт буфер кез-келген `char` кодтауға жеткілікті үлкен.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Берілген `u16` буферіне шикі u32 мәнін UTF-16 ретінде кодтайды, содан кейін кодталған таңбаны қамтитын буфердің кіші бөлімін қайтарады.
///
///
/// `char::encode_utf16`-тен айырмашылығы, бұл әдіс суррогат диапазонындағы кодтық нүктелермен де жұмыс істейді.
/// (Суррогаттар диапазонында `char` құру-UB.)
///
/// # Panics
///
/// Буфер жеткіліксіз болса, Panics.
/// Ұзындығы 2 буфер кез-келген `char` кодтауға жеткілікті үлкен.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // ҚАУІПСІЗДІК: әр қол жазу үшін биттердің бар-жоғын тексереді
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP құлап түседі
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Қосымша ұшақтар суррогаттарды бұзады.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}