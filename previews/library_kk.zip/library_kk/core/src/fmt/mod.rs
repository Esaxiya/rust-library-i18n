//! Жолдарды пішімдеуге және басып шығаруға арналған утилиталар.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// `Formatter::align` қайтарылған ықтимал туралау
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Мазмұн солға тураланған болуы керек.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Мазмұн оң жақта тураланған болуы керек.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Мазмұнның ортасына сәйкестендірілуі керек екенін көрсету.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// Пішімдеуші әдістермен қайтарылған тип.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// Хабарламаны ағынға пішімдеу кезінде қайтарылатын қате түрі.
///
/// Бұл түр қате жіберілгеннен басқа қатені жіберуді қолдамайды.
/// Кез-келген қосымша ақпарат басқа тәсілдермен берілу үшін ұйымдастырылуы керек.
///
/// Есіңізде болсын, `fmt::Error` түрін [`std::io::Error`] немесе [`std::error::Error`]-мен шатастырмау керек, бұл сіздің ауқымыңызда болуы мүмкін.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// Юникодты қабылдайтын буферлерге немесе ағындарға жазуға немесе пішімдеуге арналған trait.
///
/// Бұл trait UTF-8 кодталған деректерді ғана қабылдайды және [flushable] емес.
/// Егер сіз тек Unicode-ді қабылдағыңыз келсе және сізге жуу қажет болмаса, сіз осы trait-ді қолданғаныңыз жөн;
/// әйтпесе сіз [`std::io::Write`] қолдануыңыз керек.
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// Осы жазушыға жолдың кесіндісін жазады, жазу сәтті болған-болмағанын қайтарады.
    ///
    /// Бұл әдіс барлық жол кесіндісі сәтті жазылған жағдайда ғана сәттілікке жетеді және бұл әдіс барлық деректер жазылғанға немесе қате пайда болғанға дейін қайтарылмайды.
    ///
    ///
    /// # Errors
    ///
    /// Бұл функция қате кезінде [`Error`] данасын қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// Осы жазушыға [`char`] жазады, жазудың сәтті болғанын қайтарады.
    ///
    /// Бір [`char`] бірнеше байт түрінде кодталуы мүмкін.
    /// Бұл әдіс барлық байт тізбегі сәтті жазылған жағдайда ғана сәттілікке жетеді және бұл әдіс барлық деректер жазылғанға немесе қате пайда болғанға дейін қайтарылмайды.
    ///
    ///
    /// # Errors
    ///
    /// Бұл функция қате кезінде [`Error`] данасын қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// Осы trait қондырғыларымен бірге [`write!`] макросын қолдануға арналған желім.
    ///
    /// Әдетте бұл әдіс қолмен емес, [`write!`] макросының өзі арқылы шақырылуы керек.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// Пішімдеуге арналған конфигурация.
///
/// `Formatter` форматтауға байланысты әр түрлі нұсқаларды ұсынады.
/// Пайдаланушылар тікелей «Formatter» құрастырмайды;өзгертуге болатын сілтеме [`Debug`] және [`Display`] сияқты traits форматтаудың `fmt` әдісіне беріледі.
///
///
/// `Formatter`-пен өзара әрекеттесу үшін сіз пішімдеуге байланысты әртүрлі опцияларды өзгертудің әртүрлі әдістерін шақырасыз.
/// Мысалдар үшін төмендегі `Formatter` анықталған әдістердің құжаттамасын қараңыз.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// Аргумент-бұл `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result` эквивалентіне сәйкес ішінара қолданылатын оңтайландырылған ішінара қолданылатын пішімдеу функциясы.

extern "C" {
    type Opaque;
}

/// Бұл құрылым Xprintf функцияларының отбасы қабылдайтын жалпы "argument" білдіреді.Онда берілген мәнді форматтауға арналған функция бар.
/// Компиляция кезінде функция мен мәннің дұрыс типтерге ие екендігі қамтамасыз етіледі, содан кейін бұл құрылым аргументтерді бір типке канонизациялау үшін қолданылады.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// Бұл форматтау инфрақұрылымында indices/counts-мен байланысты функция көрсеткішінің бір тұрақты мәніне кепілдік береді.
//
// Назар аударыңыз, бұл функция дұрыс болмайды, өйткені функциялар әрқашан LLVM IR-ге дейін түсіріліп unnamed_addr деп белгіленеді, сондықтан олардың мекен-жайы LLVM үшін маңызды болып саналмайды және сол сияқты as_usize құрамы қате жинақталған болуы мүмкін.
//
// Іс жүзінде біз ешқашан us_ize емес деректерді қолданбаймыз (пішімдеу аргументтерінің статикалық генерациясы туралы), сондықтан бұл тек қосымша тексеру.
//
// Біз, ең алдымен, `USIZE_MARKER` функциясының көрсеткішінде бірінші аргумент ретінде `&usize` қабылдайтын функцияларға сәйкес келетін *тек* адрестің болуын қамтамасыз еткіміз келеді.
// Мұндағы read_volatile біз жіберілген сілтемедегі usize-ді қауіпсіз дайындай алатындығымызды және бұл мекен-жайдың usize емес қабылдау функциясын көрсетпейтіндігімізді қамтамасыз етеді.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // ҚАУІПСІЗДІК: ptr-сілтеме
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // ҚАУІПСІЗДІК: `mem::transmute(x)` қауіпсіз, өйткені
        //     1. `&'b T` ол `'b`-ден шыққан өмірді сақтайды (өмір шексіз болмас үшін)
        //     2.
        //     `&'b T` және `&'b Opaque` бірдей жад орналасуына ие (`T` `Sized` болғанда, дәл осында), `mem::transmute(f)` қауіпсіз, өйткені `fn(&T, &mut Formatter<'_>) -> Result` және `fn(&Opaque, &mut Formatter<'_>) -> Result` бірдей ABI-ге ие (егер `T` `Sized` болса)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // ҚАУІПСІЗДІК: `formatter` өрісі тек USIZE_MARKER күйіне орнатылады, егер
            // мәні usize, сондықтан бұл қауіпсіз
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// format_args форматындағы v1 форматындағы жалаушалар
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// Format_args! () Макросын қолданғанда, бұл функция аргументтер құрылымын құру үшін қолданылады.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// Бұл функция стандарттаудың стандартты емес параметрлерін көрсету үшін қолданылады.
    /// Жарамды аргументтер құрылымын құру үшін `pieces` жиымы кем дегенде `fmt` ұзақтығына ие болуы керек.
    /// Сонымен қатар, `fmt` ішіндегі кез келген `Count`, яғни `CountIsParam` немесе `CountIsNextParam`, `argumentusize` көмегімен құрылған аргументті көрсетуі керек.
    ///
    /// Алайда, мұны жасамау қауіпсіздікті тудырмайды, бірақ жарамсыз деп санайды.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// Пішімделген мәтіннің ұзындығын бағалайды.
    ///
    /// Бұл `format!` пайдалану кезінде бастапқы `String` сыйымдылығын орнатуға арналған.
    /// Note: бұл төменгі немесе жоғарғы шекара емес.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // Егер пішім жолы аргументтен басталса, кесінділердің ұзындығы маңызды болмаса, ештеңені алдын-ала бөлуге болмайды.
            //
            //
            0
        } else {
            // Кейбір аргументтер бар, сондықтан кез-келген қосымша итеру жолды қайта бөледі.
            //
            // Бұған жол бермеу үшін біз бұл жерде "pre-doubling" сыйымдылығына ие боламыз.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// Бұл құрылым форматтың қауіпсіз алдын-ала жинақталған нұсқасын және оның аргументтерін ұсынады.
/// Мұны жұмыс кезінде жасау мүмкін емес, өйткені оны қауіпсіз орындау мүмкін емес, сондықтан ешқандай конструкторлар берілмейді және өрістер модификацияның алдын алу үшін жеке болып табылады.
///
///
/// [`format_args!`] макросы осы құрылымның данасын қауіпсіз жасайды.
/// Макрос форматтау жолын компиляция кезінде тексереді, сондықтан [`write()`] және [`format()`] функцияларын пайдалану қауіпсіз орындалуы мүмкін.
///
/// Төменде көрсетілгендей [`format_args!`] `Debug` және `Display` контексттерінде қайтаратын `Arguments<'a>` қолдана аласыз.
/// Мысалда сонымен қатар `Debug` және `Display` форматтарының бірдей болатындығы көрсетілген: `format_args!` форматындағы интерполяцияланған жол.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // Басып шығару үшін жол бөліктерін форматтаңыз.
    pieces: &'a [&'static str],

    // Толтырғыш сипаттамалары немесе егер барлық сипаттамалар әдепкі болса, `None` ("{}{}" сияқты).
    fmt: Option<&'a [rt::v1::Argument]>,

    // Интерполяцияның динамикалық аргументтері, жол бөліктерімен қабаттасуы керек.
    // (Әрбір аргументтің алдында жол бөлігі болады).
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// Егер пішімделетін аргумент болмаса, форматталған жолды алыңыз.
    ///
    /// Мұны ең маңызды емес жағдайда бөлуді болдырмау үшін пайдалануға болады.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` шығарылымды бағдарламалаушыға арналған, күйін келтіру контекстінде пішімдеуі керек.
///
/// Жалпы айтқанда, сізге `derive` және `Debug` енгізу керек.
///
/// Балама форматты `#?` спецификаторымен бірге қолданған кезде нәтиже әдемі басылған.
///
/// Пішімдегіштер туралы қосымша ақпаратты [the module-level documentation][module] бөлімінен қараңыз.
///
/// [module]: ../../std/fmt/index.html
///
/// Егер барлық өрістерде `Debug` орындалса, бұл trait-ті `#[derive]` көмегімен пайдалануға болады.
/// Құрылымдар үшін «шығарылғанда», ол `struct` атын, содан кейін `{`, содан кейін әр өрістің аты мен `Debug` мәнінің үтірмен бөлінген тізімін, содан кейін `}` пайдаланады.
/// `Enum`s үшін ол варианттың атын, егер қажет болса, `(`, содан кейін өрістердің `Debug` мәндерін, содан кейін `)` пайдаланады.
///
/// # Stability
///
/// Туынды `Debug` форматтары тұрақты емес, сондықтан future Rust нұсқаларында өзгеруі мүмкін.
/// Сонымен қатар, стандартты кітапхана ұсынған типтердің `Debug` орындалуы (`libstd`, `libcore`, `liballoc` және т.б.) тұрақты емес, сонымен қатар future Rust нұсқаларымен өзгеруі мүмкін.
///
///
/// # Examples
///
/// Іске асыру:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Қолмен жүзеге асыру:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Қолмен жүзеге асыруға көмектесетін [`Formatter`] құрылымында бірқатар көмекші әдістер бар, мысалы, [`debug_struct`].
///
/// `Debug` `derive` немесе [`Formatter`] жүйесіндегі түзеткіш құрастырушы API-ні қолдана отырып, балама жалаушаның көмегімен әдемі басып шығаруды қолдайды: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// `#?` көмегімен әдемі басып шығару:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// Берілген форматтағыштың көмегімен мәнді форматтайды.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// `Debug` макросын prelude-тен trait `Debug`-ті қайта экспорттауға арналған бөлек модуль.
pub(crate) mod macros {
    /// trait `Debug` имплизиясын жасайтын макросты шығарыңыз.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// Бос формат үшін trait форматы, `{}`.
///
/// `Display` [`Debug`]-ге ұқсас, бірақ `Display` пайдаланушыға арналған шығысқа арналған, сондықтан оны шығару мүмкін емес.
///
///
/// Пішімдегіштер туралы қосымша ақпаратты [the module-level documentation][module] бөлімінен қараңыз.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `Display`-ті келесі түрге енгізу:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// Берілген форматтағыштың көмегімен мәнді форматтайды.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` trait өзінің шығуын base-8 сан түрінде форматтауы керек.
///
/// Қарапайым таңбалы бүтін сандар үшін (`i8`-`i128` және `isize`), теріс мәндер екеуінің толықтауышы ретінде форматталады.
///
///
/// Қосымша жалауша, `#`, шығыс алдында `0o` қосады.
///
/// Пішімдегіштер туралы қосымша ақпаратты [the module-level documentation][module] бөлімінен қараңыз.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` көмегімен негізгі пайдалану:
///
/// ```
/// let x = 42; // 42 сегіздік бойынша '52'
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// `Octal`-ті келесі түрге енгізу:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // i32 іске асыруға өкіл
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// Берілген форматтағыштың көмегімен мәнді форматтайды.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait шығарылымын екілік түрінде сан ретінде форматтауы керек.
///
/// Қарапайым таңбалы бүтін сандар үшін ([`i8`]-[`i128`] және [`isize`]), теріс мәндер екеуінің толықтауышы ретінде форматталады.
///
///
/// Қосымша жалауша, `#`, шығыс алдында `0b` қосады.
///
/// Пішімдегіштер туралы қосымша ақпаратты [the module-level documentation][module] бөлімінен қараңыз.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// [`i32`] көмегімен негізгі пайдалану:
///
/// ```
/// let x = 42; // 42-екіліктегі '101010'
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// `Binary`-ті келесі түрге енгізу:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // i32 іске асыруға өкіл
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// Берілген форматтағыштың көмегімен мәнді форматтайды.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` trait өзінің шығуын он алтылық сан түрінде, ал кіші әріппен `a` пен `f` болатындай етіп форматтауы керек.
///
/// Қарапайым таңбалы бүтін сандар үшін (`i8`-`i128` және `isize`), теріс мәндер екеуінің толықтауышы ретінде форматталады.
///
///
/// Қосымша жалауша, `#`, шығыс алдында `0x` қосады.
///
/// Пішімдегіштер туралы қосымша ақпаратты [the module-level documentation][module] бөлімінен қараңыз.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` көмегімен негізгі пайдалану:
///
/// ```
/// let x = 42; // 42-он алтылықтағы '2a'
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// `LowerHex`-ті келесі түрге енгізу:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // i32 іске асыруға өкіл
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// Берілген форматтағыштың көмегімен мәнді форматтайды.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait өзінің шығуын он алтылық сан түрінде, ал үлкен әріппен `A` пен `F` болатындай етіп форматтауы керек.
///
/// Қарапайым таңбалы бүтін сандар үшін (`i8`-`i128` және `isize`), теріс мәндер екеуінің толықтауышы ретінде форматталады.
///
///
/// Қосымша жалауша, `#`, шығыс алдында `0x` қосады.
///
/// Пішімдегіштер туралы қосымша ақпаратты [the module-level documentation][module] бөлімінен қараңыз.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` көмегімен негізгі пайдалану:
///
/// ```
/// let x = 42; // 42-он алтылықтағы '2A'
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// `UpperHex`-ті келесі түрге енгізу:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // i32 іске асыруға өкіл
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// Берілген форматтағыштың көмегімен мәнді форматтайды.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait оның шығуын жад орны ретінде форматтауы керек.
/// Бұл әдетте он алтылық ретінде ұсынылады.
///
/// Пішімдегіштер туралы қосымша ақпаратты [the module-level documentation][module] бөлімінен қараңыз.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `&i32` көмегімен негізгі пайдалану:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // бұл '0x7f06092ac6d0' сияқты нәрсе шығарады
/// ```
///
/// `Pointer`-ті келесі түрге енгізу:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // біз қолдана алатын Pointer-ті іске асыратын `*const T`-ке ауысу үшін `as` пайдаланыңыз
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// Берілген форматтағыштың көмегімен мәнді форматтайды.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// `LowerExp` trait өзінің шығуын ғылыми белгілерде кіші регистрмен `e` форматымен форматтауы керек.
///
/// Пішімдегіштер туралы қосымша ақпаратты [the module-level documentation][module] бөлімінен қараңыз.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` көмегімен негізгі пайдалану:
///
/// ```
/// let x = 42.0; // 42.0 ғылыми белгіде '4.2e1' болып табылады
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// `LowerExp`-ті келесі түрге енгізу:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // f64 іске асыруға өкіл
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// Берілген форматтағыштың көмегімен мәнді форматтайды.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` trait өзінің шығуын ғылыми белгіде `E` үлкен регистрімен пішімдеуі керек.
///
/// Пішімдегіштер туралы қосымша ақпаратты [the module-level documentation][module] бөлімінен қараңыз.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` көмегімен негізгі пайдалану:
///
/// ```
/// let x = 42.0; // 42.0 ғылыми белгіде '4.2E1' болып табылады
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// `UpperExp`-ті келесі түрге енгізу:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // f64 іске асыруға өкіл
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// Берілген форматтағыштың көмегімен мәнді форматтайды.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `write` функциясы шығыс ағынды және `format_args!` макросымен алдын ала компиляцияланатын `Arguments` құрылымын алады.
///
///
/// Аргументтер берілген формат жолына сәйкес берілген шығыс ағынына форматталады.
///
/// # Examples
///
/// Негізгі пайдалану:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// Назар аударыңыз, [`write!`] пайдалану жақсы болуы мүмкін.Мысал:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // Біз барлық аргументтер үшін форматтаудың әдепкі параметрлерін қолдана аламыз.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // Әрбір спецификада сәйкес келетін аргумент бар, оның алдында жол бөлігі болады.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // ҚАУІПСІЗДІК: arg және args.args бірдей аргументтерден шығады,
                // бұл индекстердің әрқашан шекарасында болатындығына кепілдік береді.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // Бір ғана артқы жол бөлігі болуы мүмкін.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // ҚАУІПСІЗДІК: аргументтер мен аргументтер бірдей аргументтерден туындайды,
    // бұл индекстердің әрқашан шекарасында болатындығына кепілдік береді.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // Дәлелді шығарыңыз
    debug_assert!(arg.position < args.len());
    // ҚАУІПСІЗДІК: аргументтер мен аргументтер бірдей аргументтерден туындайды,
    // бұл оның индексіне әрқашан кепілдік береді.
    let value = unsafe { args.get_unchecked(arg.position) };

    // Содан кейін шынымен біраз басып шығарыңыз
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // ҚАУІПСІЗДІК: cnt және аргументтер бірдей аргументтерден шығады,
            // бұл индекстің кепілдігі әрқашан шектерде болады.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// Бір нәрсе аяқталғаннан кейін толтыру.`Formatter::padding` арқылы қайтарылды.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// Осы постты толтырыңыз.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // Біз мұны өзгерткіміз келеді
            buf: wrap(self.buf),

            // Оларды сақтаңыз
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // Барлық форматтау traits қолдана алатын форматтау аргументтерін толтыруға және өңдеуге қолданылатын көмекші әдістер.
    //

    /// Str-ге шығарылған бүтін санға дұрыс толтыруды орындайды.
    /// Str-де *осы әдіспен қосылатын бүтін санға арналған белгі болмауы керек*.
    ///
    /// # Arguments
    ///
    /// * түпнұсқа сан оң немесе нөлге тең болғанымен, теріс емес.
    /// * префикс, егер '#' таңбасы (Alternate) берілсе, бұл санның алдына қою керек префикс.
    ///
    /// * buf, сан форматталған байт жиымы
    ///
    /// Бұл функция жалаушаларды, сондай-ақ минималды енді дұрыс есепке алады.
    /// Бұл дәлдікті ескермейді.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // Біз "-" нөмірін шығарудан алып тастауымыз керек.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // Егер ол бар болса, белгіні, содан кейін сұралса, префиксті жазады
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // `width` өрісі бұл уақытта `min-width` параметрінен көбірек болады.
        match self.width {
            // Егер ұзындыққа минималды талаптар болмаса, онда біз байттарды жаза аламыз.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Минималды енден асып кеткендігімізді тексеріңіз, егер болса, онда біз тек байттарды жаза аламыз.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Толтыру таңбасы нөлге тең болса, таңба мен префикс толтырудан бұрын жүреді
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // Әйтпесе, белгі мен префикс толтырудан кейін жүреді
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Бұл функция жолдың кесіндісін алады және көрсетілген тиісті форматтау жалауларын қолданғаннан кейін оны ішкі буферге шығарады.
    /// Жалпы жолдар үшін танылған жалаулар:
    ///
    /// * ені, шығарылатын заттың минималды ені
    /// * fill/align - егер қандай да бір жолды төсеу керек болса, нені шығаруға болады және оны қайда шығаруға болады
    /// * дәлдік, шығарылатын максималды ұзындық, егер осы ұзындықтан ұзын болса, жол кесіледі
    ///
    /// Бұл функция `flag` параметрлерін елемейді.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // Алдыңызда жылдам жол бар екеніне көз жеткізіңіз
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // `precision` өрісі форматталатын жол үшін `max-width` ретінде түсіндірілуі мүмкін.
        //
        let s = if let Some(max) = self.precision {
            // Егер біздің жіп дәлдіктен ұзын болса, онда бізде кесу болуы керек.
            // Алайда `fill`, `width` және `align` сияқты басқа жалаушалар әдеттегідей жұмыс істеуі керек.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // LLVM бұл жерде `..i` panic `&s[..i]` болмайтындығын дәлелдей алмайды, бірақ біз оның panic бола алмайтынын білеміз.
                // `unsafe` болдырмау үшін `get` + `unwrap_or` пайдаланыңыз, әйтпесе мұнда panic қатысты кодтар шығармаңыз.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // `width` өрісі бұл уақытта `min-width` параметрінен көбірек болады.
        match self.width {
            // Егер біз максималды ұзындықта болсақ және ұзындыққа қойылатын талаптар болмаса, онда біз тек жолды шығара аламыз
            //
            None => self.buf.write_str(s),
            // Егер біз максималды енге жетпесек, онда ең аз енден асып кеткендігімізді тексеріңіз, егер бұл болса, жолды шығару сияқты оңай.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // Егер біз максималды және минималды ендердің екеуінде де болсақ, онда ең төменгі енін көрсетілген жолмен толтырыңыз + туралау.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Алдын ала толтыруды жазып, жазылмаған толтыруды қайтарыңыз.
    /// Қоңырау шалушылар толтырылғаннан кейін жазуды қамтамасыз етуге жауапты.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// Пішімделген бөліктерді алады және төсемді қолданады.
    /// Қоңырау шалушы қазірдің өзінде бөлшектерді қажетті дәлдікпен жасады деп болжайды, сондықтан `self.precision` елемеуі мүмкін.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // белгіге қатысты нөлдік төсеме үшін біз алдымен белгіні көрсетеміз және бізде басынан белгі жоқ сияқты әрекет етеміз.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // белгі әрқашан бірінші орынға шығады
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // форматталған бөліктерден белгіні алып тастаңыз
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // қалған бөліктер қарапайым төсеу процесі арқылы өтеді.
            let len = formatted.len();
            let ret = if width <= len {
                // төсем жоқ
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // бұл жалпы жағдай және біз төте жол қабылдаймыз
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // ҚАУІПСІЗДІК: Бұл `flt2dec::Part::Num` және `flt2dec::Part::Copy` үшін қолданылады.
            // `flt2dec::Part::Num` үшін пайдалану қауіпсіз, өйткені `c` әрбір char `b'0'` пен `b'9'` аралығында, демек `s` жарамды UTF-8.
            // Сондай-ақ, `flt2dec::Part::Copy(buf)` үшін пайдалану іс жүзінде қауіпсіз болуы мүмкін, өйткені `buf` қарапайым ASCII болуы керек, бірақ біреудің `buf` үшін жаман мәнде `flt2dec::to_shortest_str`-ге өтуі мүмкін, өйткені бұл жалпыға ортақ функция.
            //
            // FIXME: Бұл UB-ге әкелуі мүмкін екенін анықтаңыз.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 нөл
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// Осы форматтаушыға негізделген кейбір буферге деректерді жазады.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // Бұл балама:
    ///         // жаз! (форматтаушы, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// Осы данаға кейбір форматталған ақпаратты жазады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// Пішімдеуге арналған жалаушалар
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// Туралау болған кезде 'fill' ретінде қолданылатын таңба.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // Біз ">" көмегімен оңға туралауды орнаттық.
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// Түзудің қандай түрі сұралғанын көрсететін жалауша.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// Шығарылым болуы керек бүтін сан ені бойынша.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // Егер біз ені алсақ, оны қолданамыз
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // Әйтпесе біз ерекше ештеңе жасамаймыз
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// Сандық типтер үшін қосымша дәлдік.
    /// Сонымен қатар, жол түрлері үшін максималды ені.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // Егер біз дәлдік алсақ, оны қолданамыз.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // Әйтпесе, біз 2 мәнін орнатамыз.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// `+` жалаушасының көрсетілгендігін анықтайды.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// `-` жалаушасының көрсетілгендігін анықтайды.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // Сіз минус белгісін қалайсыз ба?Бар!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// `#` жалаушасының көрсетілгендігін анықтайды.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// `0` жалаушасының көрсетілгендігін анықтайды.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // Біз форматтаушының параметрлерін елемейміз.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: Осы екі жалауша үшін қандай жалпыға ортақ API қажет екенін шешіңіз.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// Құрылымдарға арналған [`fmt::Debug`] қондырғыларын жасауға көмектесу үшін [`DebugStruct`] құрастырушысын жасайды.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// Корольдік құрылымдар үшін `fmt::Debug` іске асыруларына көмектесуге арналған `DebugTuple` құрастырушысын жасайды.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// Тізімге ұқсас құрылымдар үшін `fmt::Debug` іске асыруларын жасауға көмектесетін `DebugList` құрастырушысын жасайды.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// Жиынтық құрылымдарға арналған `fmt::Debug` іске асыруларына көмектесу үшін `DebugSet` құрастырушысын жасайды.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// Осы күрделі мысалда біз матчтардың тізімін құру үшін [`format_args!`] және `.debug_set()`-ті қолданамыз:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// Картаға ұқсас құрылымдар үшін `fmt::Debug` іске асыруларын жасауға көмектесетін `DebugMap` құрастырушысын жасайды.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// traits негізгі пішімдеуін енгізу

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // Егер картан қашу керек болса, осы уақытқа дейін артта қалушылықты жазып, жазыңыз, әйтпесе өткізіп жіберіңіз
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // Қосымша жалаушаны LowerHex арнайы ретінде қарастырады, ол 0x префиксінің қолданылуын білдіреді.
        // Біз оны нөлге ұзарту керек пе, жоқ па, соны анықтау үшін қолданамыз, содан кейін сөзсіз префиксті алу үшін орнатамыз.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// Display/Debug-ті әртүрлі негізгі типтерге енгізу

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // RefCell автоматты түрде қарызға алынған, сондықтан біз оның мәнін қарастыра алмаймыз.
                // Оның орнына толтырғышты көрсетіңіз.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// Егер сіз тестілер осында болады деп күткен болсаңыз, оның орнына core/tests/fmt.rs файлын қараңыз, мұнда барлық rt::Piece құрылымдарын құрудан гөрі оңайырақ.
//
// Сонымен қатар, бөлуді қажет ететіндер үшін crate бөлуінде тесттер бар.