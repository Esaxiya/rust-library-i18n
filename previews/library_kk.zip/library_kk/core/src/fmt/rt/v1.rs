//! Бұл ifmt қолданатын ішкі модуль!жұмыс уақыты.Бұл құрылымдар алдын-ала форматтау жолдарын компиляциялау үшін статикалық жиымдарға шығарылады.
//!
//! Бұл анықтамалар олардың `ct` эквиваленттеріне ұқсас, бірақ олар статикалық түрде бөлінетіндігімен және жұмыс уақытына аздап оңтайландырылғандығымен ерекшеленеді.
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Пішімдеу директивасының бөлігі ретінде сұрауға болатын мүмкін туралау.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Мазмұн солға тураланған болуы керек.
    Left,
    /// Мазмұн оң жақта тураланған болуы керек.
    Right,
    /// Мазмұнның ортасына сәйкестендірілуі керек екенін көрсету.
    Center,
    /// Туралау сұралмады.
    Unknown,
}

/// [width](https://doc.rust-lang.org/std/fmt/#width) және [precision](https://doc.rust-lang.org/std/fmt/#precision) спецификаторлары қолданады.
#[derive(Copy, Clone)]
pub enum Count {
    /// Тура санмен көрсетілген, мәнді сақтайды
    Is(usize),
    /// `$` және `*` синтаксистерінің көмегімен көрсетілген, индексті `args`-ге сақтайды
    Param(usize),
    /// Белгілі емес
    Implied,
}