//! Қарапайым traits және типтердің негізгі қасиеттерін көрсететін типтер.
//!
//! Rust түрлерін меншікті қасиеттеріне қарай әртүрлі пайдалы тәсілдермен жіктеуге болады.
//! Бұл жіктемелер traits ретінде ұсынылған.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Жіп шекаралары арқылы тасымалданатын типтер.
///
/// Бұл trait компилятордың орындылығын анықтаған кезде автоматты түрде іске асырылады.
///
/// «Жіберу» түріне мысал ретінде [`rc::Rc`][`Rc`] сілтеме-санау көрсеткішін алуға болады.
/// Егер екі сілтеме есептелген бірдей мәнді көрсететін [`Rc`]-ті клондау әрекетін жасаса, олар сілтеме санын бір уақытта жаңартуға тырысуы мүмкін, бұл [undefined behavior][ub], өйткені [`Rc`] атомдық операцияларды қолданбайды.
///
/// Оның немере ағасы [`sync::Arc`][arc] атомдық операцияларды қолданады (кейбір үстеме шығындар), демек, `Send`.
///
/// Толығырақ [the Nomicon](../../nomicon/send-and-sync.html) қараңыз.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Компиляция кезінде белгілі тұрақты мөлшері бар типтер.
///
/// Барлық типтік параметрлердің `Sized` шекарасы бар.Бұл шектеуді жою үшін арнайы синтаксис `?Sized` қолдануға болады, егер ол орынсыз болса.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//қате: өлшемі [i32] үшін орындалмаған
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Ерекшелік-бұл trait-нің айқын емес `Self` түрі.
/// trait-дің айқын емес `Sized` байланысы жоқ, өйткені [trait объектісі] үйлесімсіз, өйткені trait барлық мүмкін орындалушылармен жұмыс істеуі керек, сондықтан кез-келген мөлшерде болуы мүмкін.
///
///
/// Rust сізге `Sized`-ті trait-мен байланыстыруға мүмкіндік берсе де, сіз оны кейіннен trait нысанын құру үшін пайдалана алмайсыз:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // y: &dyn Bar= &Impl;//қате: trait `Bar` объектіге айналуы мүмкін емес
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // мысалы, `[T]: !Default`-ті бағалауды қажет ететін әдепкі үшін
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Динамикалық өлшемді типке дейін "unsized" болуы мүмкін типтер.
///
/// Мысалы, `[i8; 2]` массив типі `Unsize<[i8]>` және `Unsize<dyn fmt::Debug>`-ті жүзеге асырады.
///
/// `Unsize`-тің барлық орындалуын компилятор автоматты түрде ұсынады.
///
/// `Unsize` үшін жүзеге асырылады:
///
/// - `[T; N]` бұл `Unsize<[T]>`
/// - `T` `T: Trait` болғанда `Unsize<dyn Trait>` болады
/// - `Foo<..., T, ...>` егер `Unsize<Foo<..., U, ...>>` болса, егер:
///   - `T: Unsize<U>`
///   - Foo құрылым
///   - Тек `Foo` өрісінің `T` қатысатын түрі бар
///   - `T` басқа өрістер типіне кірмейді
///   - `Bar<T>: Unsize<Bar<U>>`, егер `Foo` соңғы өрісі `Bar<T>` типіне ие болса
///
/// `Unsize` [`ops::CoerceUnsized`]-мен бірге "user-defined" контейнерлеріне, мысалы, [`Rc`]-ге динамикалық өлшемді түрлерін алуға мүмкіндік беру үшін қолданылады.
/// Қосымша мәлімет алу үшін [DST coercion RFC][RFC982] және [the nomicon entry on coercion][nomicon-coerce] қараңыз.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Үлгі матчтарында қолданылатын тұрақтылар үшін trait қажет.
///
/// `PartialEq` шығаратын кез-келген тип осы trait-ді *оның* параметрлері `Eq`-ті жүзеге асыратынына қарамастан * автоматты түрде жүзеге асырады.
///
/// Егер `const` элементінде осы trait-ді қолданбайтын қандай да бір түр болса, онда (1.) типі де `PartialEq`-ті қолданбайды (демек, тұрақты код салыстыру әдісін ұсынбайды, бұл кодты жасау мүмкін деп санайды) немесе (2.)-ті өзі * *`PartialEq` нұсқасы (біз құрылымдық-теңдік салыстыруға сәйкес келмейді).
///
///
/// Жоғарыдағы екі сценарийдің кез-келгенінде біз осындай тұрақты түрін шаблон матчында қолданудан бас тартамыз.
///
/// [structural match RFC][RFC1445] және [issue 63438]-ті қараңыз, бұл атрибуттарға негізделген дизайннан осы trait-ге көшуге түрткі болды.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Үлгі матчтарында қолданылатын тұрақтылар үшін trait қажет.
///
/// `Eq` шығаратын кез-келген тип осы trait-ді *оның* типтік параметрлері `Eq`-ті жүзеге асыратынына қарамастан * автоматты түрде жүзеге асырады.
///
/// Бұл біздің типтік жүйеміздегі шектеулерді жоюға арналған хак.
///
/// # Background
///
/// Үлгілік матчтарда қолданылатын конструкциялардың `#[derive(PartialEq, Eq)]` атрибутына ие болуын талап етеміз.
///
/// Неғұрлым идеалды әлемде біз бұл талапты `StructuralPartialEq` trait *және*`Eq` trait екеуінің де орындалуын тексеру арқылы тексере аламыз.
/// Дегенмен, сізде *`derive(PartialEq, Eq)`* жасайтын ADT болуы мүмкін және біз компилятор қабылдағанын қалайтын жағдай бола аламыз, бірақ тұрақты типтің `Eq` орындалмауы мүмкін.
///
/// Атап айтқанда, келесі жағдай:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Жоғарыда келтірілген кодтағы мәселе `Wrap<fn(&())>`-тің `PartialEq`-ті де, `Eq`-ті де қолданбайтындығында, өйткені «үшін <'a> fn(&'a _)` does not implement those traits.)
///
/// Сондықтан, біз `StructuralPartialEq` және жай `Eq` үшін аңғал тексеруге сене алмаймыз.
///
/// Мұнымен айналысу үшін біз (`#[derive(PartialEq)]` және `#[derive(Eq)]`) туындыларының әрқайсысы енгізген екі бөлек traits-ді қолданамыз және олардың екеуінің де құрылымдық-сәйкестік тексеру бөлігі ретінде бар-жоғын тексереміз.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Тек биттерді көшіру арқылы олардың мәндерін көбейтуге болатын типтер.
///
/// Әдепкі бойынша, айнымалы байланыстарда «жылжыту семантикасы» болады.Басқа сөздермен айтқанда:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` `y`-ге көшті, сондықтан оны пайдалану мүмкін емес
///
/// // println! («{: ?}», x);//қате: жылжытылған мәнді пайдалану
/// ```
///
/// Алайда, егер тип `Copy`-ті қолданса, оның орнына «семантиканың көшірмесі» болады:
///
/// ```
/// // Біз `Copy` бағдарламасын ала аламыз.
/// // `Clone` қажет, өйткені бұл супертрейтер `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` бұл `x` көшірмесі
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Осы екі мысалда айырмашылық тек сізге тапсырмадан кейін `x`-ке кіруге рұқсат беруіңізде екенін ескеру маңызды.
/// Сорғыш астында көшірме де, қозғалыс та биттердің жадқа көшірілуіне әкелуі мүмкін, дегенмен бұл кейде оңтайландырылады.
///
/// ## `Copy`-ті қалай қолдануға болады?
///
/// `Copy`-ті сіздің түріңізге енгізудің екі әдісі бар.Ең қарапайымы-`derive` пайдалану:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Сіз сондай-ақ `Copy` және `Clone` қолмен енгізе аласыз:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Екеуінің арасында шамалы айырмашылық бар: `derive` стратегиясы сонымен қатар тип параметрлеріне байланысты `Copy` қояды, ол әрдайым қажет емес.
///
/// ## `Copy` пен `Clone` арасындағы айырмашылық неде?
///
/// Көшірмелер жанама түрде пайда болады, мысалы, `y = x` тапсырмасының бөлігі ретінде.`Copy` әрекеті шамадан тыс жүктелмейді;бұл әрдайым қарапайым даналық көшірме.
///
/// Клондау-бұл айқын әрекет, `x.clone()`.[`Clone`]-ті енгізу мәндерді қауіпсіз көбейту үшін кез-келген типтегі мінез-құлықты қамтамасыз ете алады.
/// Мысалы, [`Clone`]-ті [`String`]-ке енгізу үшін үйіндіге бағытталған буферді көшіру керек.
/// Қарапайым [`String`] мәндерінің көшірмесі жолды екі рет босатуға әкелетін көрсеткішті көшіреді.
/// Осы себепті [`String`]-[`Clone`], бірақ `Copy` емес.
///
/// [`Clone`] бұл `Copy` супертрейті, сондықтан `Copy`-тің бәрі де [`Clone`]-ті іске асыруы керек.
/// Егер тип `Copy` болса, оның [`Clone`] орындалуы тек `*self` қайтаруы керек (жоғарыдағы мысалды қараңыз).
///
/// ## Менің типім қашан `Copy` болуы мүмкін?
///
/// Егер оның барлық компоненттері `Copy` қолданса, тип `Copy`-ті қолдана алады.Мысалы, бұл құрылым `Copy` болуы мүмкін:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Құрылым `Copy`, ал [`i32`]-`Copy`, сондықтан `Point`-`Copy` бола алады.
/// Керісінше, қарастырайық
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// `PointList` құрылымы `Copy`-ті іске асыра алмайды, өйткені [`Vec<T>`] `Copy` емес.Егер біз `Copy` іске асыруға тырыссақ, қате пайда болады:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Ортақ сілтемелер (`&T`) сонымен қатар `Copy` болып табылады, сондықтан *X* X *емес*`T` типтегі сілтемелер болған жағдайда да, тип `Copy` болуы мүмкін.
/// `Copy`-ті жүзеге асыра алатын келесі құрылымды қарастырыңыз, өйткені ол тек біздің *Copy емес типтегі `PointList`-ке* ортақ сілтеме * ұстайды:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Менің түрім `Copy` бола алмайтын кезде *?
///
/// Кейбір түрлерін қауіпсіз көшіру мүмкін емес.Мысалы, `&mut T` көшірмесі лақап өзгертілетін сілтеме жасайды.
/// [`String`] көшірмесі ['String`] буферін басқарудың екі еселенген ақысыздығына әкелетін жауапкершілікті қайталайды.
///
/// Соңғы жағдайды жалпылай отырып, [`Drop`]-ті қолданатын кез-келген тип `Copy` бола алмайды, өйткені ол өзінің жеке [`size_of::<T>`] байттарынан басқа кейбір ресурстарды басқарады.
///
/// Егер сіз `Copy`-ді «Copy» емес деректерді қамтитын құрылымға немесе энумға енгізгіңіз келсе, сіз [E0204] қатесін аласыз.
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Менің түрім `Copy` қашан * болуы керек?
///
/// Жалпы, егер сіздің _can_ типіңіз `Copy`-ті қолданатын болса, ол қажет.
/// Есіңізде болсын, `Copy` енгізу сіздің типтегі жалпыға ортақ API бөлігі болып табылады.
/// Егер түр future-да «көшірмесі» болмауы мүмкін болса, API өзгермеуін болдырмау үшін `Copy` енгізілімін қазір қалдырған жөн.
///
/// ## Қосымша орындаушылар
///
/// [implementors listed below][impls]-тен басқа келесі типтер де `Copy`-ті жүзеге асырады:
///
/// * Функция элементтерінің түрлері (яғни әр функция үшін анықталған типтер)
/// * Функция нұсқағышының түрлері (мысалы, `fn() -> i32`)
/// * Массив типтері, барлық өлшемдер үшін, егер элемент түрі `Copy`-ті қолданса (мысалы, `[i32; 123456]`)
/// * Tuple типтері, егер әрбір компонент `Copy`-ті қолданса (мысалы, `()`, `(i32, bool)`)
/// * Жабу түрлері, егер олар қоршаған ортадан ешқандай мән алмаса немесе барлық алынған мәндер `Copy`-ті қолданса.
///   Ортақ сілтеме арқылы алынған айнымалылар әрқашан `Copy`-ті қолданады (референт болмаса да), ал өзгертілетін сілтеме арқылы алынған айнымалылар ешқашан `Copy`-ті қолданбайды.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Бұл өмір бойы қанағаттанбағандықтан `Copy`-ті қолданбайтын типті көшіруге мүмкіндік береді (`A<'_>` тек `A<'static>: Copy` және `A<'_>: Clone` болғанда).
// Бізде бұл қасиет әзірге стандартты кітапханада бар бірнеше `Copy` мамандандырулары болғандықтан ғана бар, сондықтан дәл қазір мұндай мінез-құлықты қауіпсіз етудің мүмкіндігі жоқ.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// trait `Copy` имплизиясын жасайтын макросты шығарыңыз.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Ағындар арасында сілтемелерді бөлісуге болатын түрлер.
///
/// Бұл trait компилятордың орындылығын анықтаған кезде автоматты түрде іске асырылады.
///
/// Дәл анықтама: `T` түрі [`Sync`], егер `&T` [`Send`] болса ғана.
/// Басқаша айтқанда, егер `&T` сілтемелерін ағындар арасында беру кезінде [undefined behavior][ub] мүмкіндігі болмаса (мәліметтер жарысын қосқанда).
///
/// Күткендей, [`u8`] және [`f64`] сияқты қарабайыр типтердің барлығы-[`Sync`], сонымен қатар оларды қамтитын қарапайым жиынтық типтері, мысалы, кортеждер, құрылымдар мен энумдар.
/// Негізгі [`Sync`] типтерінің мысалдарына `&T` сияқты "immutable" типтері және қарапайым тұқым қуалайтын өзгергіштікке ие, мысалы, [`Box<T>`][box], [`Vec<T>`][vec] және көптеген басқа коллекциялар жатады.
///
/// (Контейнер [«Синхрондау») болу үшін жалпы параметрлер [`Sync`] болуы керек.)
///
/// Анықтаманың таңқаларлық салдары-бұл `&mut T`-`Sync` (егер `T`-`Sync` болса), бұл синхронды емес мутацияны қамтамасыз етуі мүмкін сияқты.
/// Айла-шарғы, ортақ сілтеме (яғни `& &mut T`) негізінде өзгертілетін сілтеме тек `& &T` сияқты оқуға айналады.
/// Демек, деректер жарысының қаупі жоқ.
///
/// `Sync` емес типтер-бұл "interior mutability" жіпке қауіпсіз емес формада, мысалы [`Cell`][cell] және [`RefCell`][refcell].
/// Бұл түрлер өзгермейтін, ортақ сілтеме арқылы да олардың мазмұнын мутациялауға мүмкіндік береді.
/// Мысалы, [`Cell<T>`][cell] әдісі бойынша `set` әдісі `&self` қабылдайды, сондықтан оған тек [`&Cell<T>`][cell] ортақ сілтемесі қажет.
/// Әдіс синхрондауды жүзеге асырмайды, сондықтан [`Cell`][cell] `Sync` бола алмайды.
///
/// «Sync» түріне жатпайтын тағы бір мысал-сілтеме санау көрсеткіші [`Rc`][rc].
/// Кез келген [`&Rc<T>`][rc] сілтемесін ескере отырып, сіз сілтемелерді атомдық емес жолмен өзгерте отырып, жаңа [`Rc<T>`][rc] клондауыңызға болады.
///
/// Ішкі жіптің қауіпсіз өзгеруі қажет болған жағдайда, Rust [atomic data types] және [`sync::Mutex`][mutex] және [`sync::RwLock`][rwlock] арқылы айқын құлыптауды қамтамасыз етеді.
/// Бұл типтер кез-келген мутация деректердің жарыстарын тудырмайтындығына кепілдік береді, сондықтан олардың түрлері `Sync`.
/// Сол сияқты, [`sync::Arc`][arc] ақаусыз [`Rc`][rc] аналогын ұсынады.
///
/// Интерьердің өзгергіштігі бар кез-келген типтер [`cell::UnsafeCell`][unsafecell] орамасын value(s) айналасында қолдануы керек, ол ортақ сілтеме арқылы мутациялануы мүмкін.
/// Мұны істемеу [undefined behavior][ub] болып табылады.
/// Мысалы, [`transmute`][transmute]-ing `&T` бастап `&mut T` дейін жарамсыз.
///
/// `Sync` туралы толығырақ ақпаратты [the Nomicon][nomicon-send-and-sync] бөлімінен қараңыз.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): бір рет бета нұсқасында `rustc_on_unimplemented`-ге ноталар қосуды қолдайтын болса және жабудың қажеттілік тізбегінің кез келген жерінде бар-жоғын тексеру үшін кеңейтілген болса, оны (#48534) ретінде кеңейтіңіз:
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Нөлдік өлшемді тип "act like"-ге тиесілі заттарды `T` маркасына белгілеу үшін қолданылады.
///
/// Сіздің типке `PhantomData<T>` өрісін қосу компиляторға сіздің типіңіз `T` типінің мәнін сақтайтындай әрекет ететінін айтады, бірақ ол ондай емес.
/// Бұл ақпарат белгілі бір қауіпсіздік қасиеттерін есептеу кезінде қолданылады.
///
/// `PhantomData<T>`-ті қалай қолдану керектігін тереңірек түсіну үшін [the Nomicon](../../nomicon/phantom-data.html)-тен қараңыз.
///
/// # Сұмдық ескерту 👻👻👻
///
/// Олардың екеуінің де есімдері қорқынышты болғанымен, `PhantomData` және «елес түрлері» бір-біріне қатысты, бірақ бірдей емес.Фантом типінің параметрі-бұл жай ғана ешқашан пайдаланылмайтын типтік параметр.
/// Rust-де бұл көбінесе компиляторға шағымданады, ал шешім `PhantomData` арқылы "dummy" қолданысын қосады.
///
/// # Examples
///
/// ## Өмір бойы пайдаланылмаған параметрлер
///
/// Мүмкін, `PhantomData`-тің ең көп таралған қолданылуы-бұл өмір бойы пайдаланылмайтын параметрге ие құрылым, әдетте кейбір қауіпті кодтардың бөлігі ретінде.
/// Мысалы, мұнда `*const T` типті екі көрсеткіш бар, мүмкін бір жерде массивке бағытталған құрылым `Slice` келтірілген:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Мұндағы негізгі деректер тек `'a` өмір бойы жарамды, сондықтан `Slice` `'a`-тен аспауы керек.
/// Алайда, бұл ниет кодта көрсетілмеген, өйткені `'a` өмір бойы қолданылмайды, сондықтан оның қандай деректерге қатысты екендігі белгісіз.
/// Біз мұны компиляторға *егер*`Slice` құрылымында `&'a T` сілтемесі бар болса * әрекет етуі арқылы түзете аламыз:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Бұл өз кезегінде `T: 'a` аннотациясын талап етеді, бұл `T` кез-келген сілтемелер өмір бойы `'a` ішінде жарамды екенін көрсетеді.
///
/// `Slice` инициализациясы кезінде сіз жай `phantom` өрісі үшін `PhantomData` мәнін бересіз:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Пайдаланылмаған тип параметрлері
///
/// Кейде сізде құрылымның "tied" қандай типке жататындығын көрсететін пайдаланылмаған типтік параметрлер болады, дегенмен бұл құрылымның өзінде нақты деректер жоқ.
/// Мұнда [FFI] пайда болатын мысал келтірілген.
/// Шетелдік интерфейс әртүрлі типтегі Rust мәндеріне сілтеме жасау үшін `*mut ()` типті тұтқаларды қолданады.
/// Біз Rust түрін `ExternalResource` құрылымындағы фантом типті параметрді қолданып қадағалаймыз, ол тұтқаны орайды.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Меншік құқығы және түсуді тексеру
///
/// `PhantomData<T>` типті өрісті қосу сіздің типіңізде `T` типті мәліметтер бар екенін көрсетеді.Бұл өз кезегінде сіздің типіңіз жойылған кезде, ол `T` типіндегі бір немесе бірнеше дананы түсіруі мүмкін дегенді білдіреді.
/// Бұл Rust компиляторының [drop check] анализіне әсер етеді.
///
/// Егер сіздің құрылымыңыз `T` типтегі деректерге *иелік етпейтін болса, онда меншік құқығын көрсетпеу үшін `PhantomData<&'a T>` (ideally) немесе `PhantomData<* const T>` (егер ешқандай қызмет ету мерзімі болмаса) сияқты анықтама түрін қолданған жөн.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Enum дискриминанттарының түрін көрсету үшін қолданылатын ішкі trait компиляторы.
///
/// Бұл trait автоматты түрде әр типке енгізіледі және [`mem::Discriminant`]-ке ешқандай кепілдік бермейді.
/// `DiscriminantKind::Discriminant` пен `mem::Discriminant` аралығында ауыстыру **анықталмаған тәртіп** болып табылады.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// `mem::Discriminant` талап ететін trait bounds-ті қанағаттандыратын дискриминанттың түрі.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Компилятор-ішкі trait типтің кез-келген `UnsafeCell` ішіне кіретіндігін, бірақ жанама емес екенін анықтау үшін қолданылады.
///
/// Бұл, мысалы, осындай типтегі `static` тек оқуға болатын статикалық жадқа немесе жазылатын статикалық жадқа орналастырылуына әсер етеді.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Бекіткеннен кейін қауіпсіз жылжытылатын түрлері.
///
/// Rust-дің өзінде қозғалмайтын типтер туралы түсінік жоқ және ол қозғалыстарды әрқашан қауіпсіз деп санайды (мысалы, тағайындау немесе [`mem::replace`] арқылы).
///
/// Оның орнына [`Pin`][Pin] типі типтік жүйе арқылы қозғалудың алдын алу үшін қолданылады.[`Pin<P<T>>`][Pin] орамасына оралған `P<T>` көрсеткіштерін сыртқа шығару мүмкін емес.
/// Бекіту туралы қосымша ақпаратты [`pin` module] құжаттамасынан қараңыз.
///
/// `T` үшін `Unpin` trait-ті іске асыру типті бекітудің шектеулерін көтереді, содан кейін `T`-ті [`mem::replace`] сияқты функциялармен [`Pin<P<T>>`][Pin]-тен жылжытуға мүмкіндік береді.
///
///
/// `Unpin` бекітілмеген деректер үшін ешқандай нәтиже жоқ.
/// Атап айтқанда, [`mem::replace`] қуана-қуана `!Unpin` деректерін жылжытады (ол `T: Unpin` кезінде ғана емес, кез-келген `&mut T` үшін жұмыс істейді).
/// Алайда, сіз [`Pin<P<T>>`][Pin] ішіне оралған деректерге [`mem::replace`] қолдана алмайсыз, өйткені сіз оған қажет `&mut T` ала алмайсыз және *бұл* жүйенің жұмыс жасауына себеп болады.
///
/// Мысалы, мұны тек `Unpin` іске асыратын түрлерде жасауға болады:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // `mem::replace`-ге қоңырау шалу үшін бізге өзгертілетін анықтама қажет.
/// // Біз мұндай анықтаманы (implicitly) арқылы `Pin::deref_mut` арқылы ала аламыз, бірақ бұл мүмкін, өйткені `String` `Unpin`-ті қолданады.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Бұл trait автоматты түрде кез-келген типке енгізіледі.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// `Unpin`-ті қолданбайтын маркер түрі.
///
/// Егер типте `PhantomPinned` болса, ол `Unpin`-ны әдепкі бойынша қолданбайды.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Қарапайым типтерге арналған `Copy`-ті енгізу.
///
/// Rust-де сипатталмайтын іске асырулар `traits::SelectionContext::copy_clone_conditions()`-те `rustc_trait_selection`-де жүзеге асырылады.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Ортақ сілтемелерді көшіруге болады, бірақ өзгертілетін сілтемелер *мүмкін емес*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}