//! Тапсырыс беру және салыстыру үшін функционалдылық.
//!
//! Бұл модульде мәндерге тапсырыс беруге және салыстыруға арналған әртүрлі құралдар бар.Қысқаша:
//!
//! * [`Eq`] және [`PartialEq`]-бұл мәндер арасындағы сәйкесінше толық және ішінара теңдікті анықтауға мүмкіндік беретін traits.
//! Оларды жүзеге асыру `==` және `!=` операторларына артық жүктеме береді.
//! * [`Ord`] және [`PartialOrd`]-бұл traits, сәйкесінше мәндер арасындағы толық және ішінара тәртіпті анықтауға мүмкіндік береді.
//!
//! Оларды жүзеге асыру `<`, `<=`, `>` және `>=` операторларына артық жүктеме береді.
//! * [`Ordering`] [`Ord`] және [`PartialOrd`] негізгі функцияларымен қайтарылған энум болып табылады және тапсырыс беруді сипаттайды.
//! * [`Reverse`] - бұл тапсырысты оңай өзгертуге мүмкіндік беретін құрылым.
//! * [`max`] және [`min`]-бұл [`Ord`]-тен шығатын және екі мәннің максимумын немесе минимумын табуға мүмкіндік беретін функциялар.
//!
//! Қосымша мәліметтер алу үшін тізімдегі әрбір элементтің тиісті құжаттамасын қараңыз.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation) теңдікті салыстыру үшін Trait.
///
/// Бұл trait толық эквиваленттік қатынасы жоқ типтер үшін ішінара теңдікке мүмкіндік береді.
/// Мысалы, өзгермелі нүкте сандарында `NaN != NaN`, сондықтан өзгермелі нүкте типтері `PartialEq` енгізеді, бірақ [`trait@Eq`] емес.
///
/// Ресми түрде теңдік болуы керек (барлық `a`, `b`, `c` типтегі `A`, `B`, `C` үшін):
///
/// - **Симметриялы**: егер `A: PartialEq<B>` және `B: PartialEq<A>` болса, онда **`a==b`` b==a`** білдіреді;және
///
/// - **Өтпелі**: егер `A: PartialEq<B>` және `B: PartialEq<C>` және `A:
///   Жартылай теңдеу<C>`, онда **` a==b`және `b == c` a==c`** білдіреді.
///
/// `B: PartialEq<A>` (symmetric) және `A: PartialEq<C>` (transitive) имплимдері мәжбүрлеп қолданылмайтынына назар аударыңыз, бірақ бұл талаптар олар болған кезде қолданылады.
///
/// ## Derivable
///
/// Бұл trait-ті `#[derive]` көмегімен пайдалануға болады.Сызбалар бойынша `шығарғанда`, барлық өрістер тең болса, екі даналар тең болады, ал егер өрістер тең болмаса, тең болмайды.Enum-де «шығарылғанда», әр нұсқа өзіне тең, ал басқа нұсқаларға тең емес.
///
/// ## `PartialEq`-ті қалай қолдануға болады?
///
/// `PartialEq` тек [`eq`] әдісін іске асыруды талап етеді;[`ne`] оны шартты түрде анықтайды.[`ne`]*кез-келген қолмен орындалуы*[`eq`]-тің [`ne`]-ке қатаң кері екендігі туралы ережені сақтауы керек;яғни, егер `a != b` болса ғана `!(a == b)`.
///
/// `PartialEq`, [`PartialOrd`] және [`Ord`]*іске асырулары* бір-бірімен келісуі керек.traits-нің бір бөлігін шығару және басқаларын қолмен енгізу арқылы оларды кездейсоқтыққа душар ету оңай.
///
/// Екі кітап бірдей форматта қарастырылатын доменге мысал, мысалы, егер олардың ISBN сәйкес келсе, форматтары әр түрлі болса да:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Екі түрлі типті қалай салыстыруға болады?
///
/// Сіз салыстыруға болатын түр «PartialEq» типтік параметрімен басқарылады.
/// Мысалы, алдыңғы кодты сәл өзгертейік:
///
/// ```
/// // Туынды құрал<BookFormat>==<BookFormat>салыстырулар
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Іске асыру<Book>==<BookFormat>салыстырулар
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Іске асыру<BookFormat>==<Book>салыстырулар
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// `impl PartialEq for Book`-ті `impl PartialEq<BookFormat> for Book`-ге ауыстыру арқылы біз «BookFormat»-ті «Book`s»-пен салыстыруға мүмкіндік береміз.
///
/// Құрылымның кейбір өрістерін елемейтін жоғарыдағы сияқты салыстыру қауіпті болуы мүмкін.Бұл ішінара эквиваленттік қатынасқа қойылатын талаптардың күтпеген бұзылуына әкелуі мүмкін.
/// Мысалы, егер біз `PartialEq<Book>`-тің `BookFormat`-ге қатысты орындалуын сақтасақ және `Book`-ке `PartialEq<Book>`-тің қосылуын қосқан болсақ (немесе `#[derive]` арқылы немесе бірінші мысалдан қолмен енгізу арқылы), онда нәтиже транзитивтілікті бұзады:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Бұл әдіс `self` және `other` мәндерінің тең болуын тексереді және оны `==` қолданады.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Бұл әдіс `!=`-ті тексереді.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// trait `PartialEq` имплизиясын жасайтын макросты шығарыңыз.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation) теңдікті салыстыру үшін Trait.
///
/// Бұл дегеніміз, `a == b` және `a != b` қатаң инверсиялардан басқа, теңдік (барлық `a`, `b` және `c` үшін) болуы керек:
///
/// - reflexive: `a == a`;
/// - симметриялы: `a == b` `b == a` білдіреді;және
/// - өтпелі: `a == b` және `b == c` `a == c` білдіреді.
///
/// Бұл қасиетті компилятор тексере алмайды, сондықтан `Eq` [`PartialEq`]-ны білдіреді және ешқандай қосымша әдістері жоқ.
///
/// ## Derivable
///
/// Бұл trait-ті `#[derive]` көмегімен пайдалануға болады.
/// «Шығарып алу» кезінде, `Eq`-те ешқандай қосымша әдістер болмағандықтан, бұл компиляторға тек жартылай эквиваленттік қатынастан гөрі эквиваленттік қатынас екенін хабарлайды.
///
/// `derive` стратегиясы барлық өрістерді `Eq` талап ететіндігін ескеретінін ескеріңіз, бұл әрдайым қажет емес.
///
/// ## `Eq`-ті қалай қолдануға болады?
///
/// Егер сіз `derive` стратегиясын қолдана алмасаңыз, онда сіздің типіңізде ешқандай әдіс жоқ `Eq` орындалатындығын көрсетіңіз:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // бұл әдіс түрдің кез-келген компоненті#[туынды] өзін-өзі жүзеге асыратындығын растау үшін#[туынды] арқылы ғана қолданылады, ал қазіргі туынды инфрақұрылым осы бекітуді осы trait әдісін қолданбай орындауды білдіреді.
    //
    //
    // Мұны ешқашан қолмен жүзеге асыруға болмайды.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// trait `Eq` имплизиясын жасайтын макросты шығарыңыз.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: бұл құрылым тек#[derive] to арқылы қолданылады
// типтің кез-келген компоненті теңдеуді жүзеге асырады деп бекітіңіз.
//
// Бұл құрылым ешқашан пайдаланушы кодында болмауы керек.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Ordering`-бұл екі мәнді салыстырудың нәтижесі.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// Салыстырылған мән басқасынан аз болатын тапсырыс.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// Салыстырылған мән басқа мәнге тең болатын тапсырыс.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// Салыстырылған мән басқасынан үлкен болатын тапсырыс.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Егер тапсырыс `Equal` нұсқасы болса, `true` қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Егер тапсырыс `Equal` нұсқасы болмаса, `true` қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Егер тапсырыс `Less` нұсқасы болса, `true` қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Егер тапсырыс `Greater` нұсқасы болса, `true` қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Егер тапсырыс `Less` немесе `Equal` нұсқасы болса, `true` қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Егер тапсырыс `Greater` немесе `Equal` нұсқасы болса, `true` қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// `Ordering`-ті қайтарады.
    ///
    /// * `Less` `Greater` болады.
    /// * `Greater` `Less` болады.
    /// * `Equal` `Equal` болады.
    ///
    /// # Examples
    ///
    /// Негізгі мінез-құлық:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Бұл әдісті салыстыруды қалпына келтіру үшін пайдалануға болады:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // массивті үлкенінен кішісіне қарай сұрыптау.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Екі тапсырыс тізбегі.
    ///
    /// `Equal` болмаған кезде `self` қайтарады.Әйтпесе `other` қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Берілген функциямен тізбекті тізбектей береді.
    ///
    /// `Equal` болмаған кезде `self` қайтарады.
    /// Әйтпесе `f`-ге қоңырау шалып, нәтижені қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Кері тапсырыс үшін көмекші құрылым.
///
/// Бұл құрылым [`Vec::sort_by_key`] сияқты функцияларда қолданылатын көмекші болып табылады және кілттің бір бөлігіне кері тапсырыс беру үшін қолданыла алады.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait [total order](https://en.wikipedia.org/wiki/Total_order) құрайтын типтерге арналған.
///
/// Тапсырыс-бұл жалпы тапсырыс, егер ол (барлық `a`, `b` және `c` үшін):
///
/// - жалпы және асимметриялық: `a < b`, `a == b` немесе `a > b` дәл біреуінің дәлдігі;және
/// - өтпелі, `a < b` және `b < c` `a < c` білдіреді.`==` және `>` үшін бірдей болуы керек.
///
/// ## Derivable
///
/// Бұл trait-ті `#[derive]` көмегімен пайдалануға болады.
/// Құрылымдардан шыққан кезде, құрылым мүшелерінің жоғарыдан төмен декларациялау тәртібі негізінде [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) тапсырыс жасайды.
///
/// Enum-де «шығарылғанда», нұсқалар жоғарыдан төменге қарай дискриминантты ретімен реттеледі.
///
/// ## Лексикографиялық салыстыру
///
/// Лексикографиялық салыстыру-бұл келесі қасиеттерге ие операция:
///  - Екі реттілік элемент бойынша салыстырылады.
///  - Бірінші сәйкес келмейтін элемент лексикографиялық тұрғыдан қай реттіліктің басқасынан кем немесе үлкен екенін анықтайды.
///  - Егер бір тізбектің екіншісінің префиксі болса, қысқа лексикографиялық жағынан басқасынан аз болады.
///  - Егер екі дәйектіліктің эквивалентті элементтері болса және олардың ұзындығы бірдей болса, онда тізбектер лексикографиялық жағынан тең болады.
///  - Бос реттілік лексикографиялық жағынан кез-келген бос емес реттіліктен азырақ.
///  - Екі бос тізбек лексикографиялық жағынан тең.
///
/// ## `Ord`-ті қалай қолдануға болады?
///
/// `Ord` түрінің [`PartialOrd`] және [`Eq`] болуын талап етеді (ол үшін [`PartialEq`] қажет).
///
/// Содан кейін сіз [`cmp`] үшін бағдарламаны анықтауыңыз керек.Сіз өз түріңіздің өрістерінде [`cmp`] пайдалану пайдалы болуы мүмкін.
///
/// [`PartialEq`], [`PartialOrd`] және `Ord`*іске асырулары* бір-бірімен келісуі керек.
/// Яғни `a.cmp(b) == Ordering::Equal`, егер барлық `a` және `b` үшін `a == b` және `Some(a.cmp(b)) == a.partial_cmp(b)` болса ғана.
/// traits-нің бір бөлігін шығару және басқаларын қолмен енгізу арқылы оларды кездейсоқтыққа душар ету оңай.
///
/// `id` және `name` мәндерін ескермей, адамдарды тек бой бойынша сұрыптағыңыз келетін мысал:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Бұл әдіс `self` пен `other` аралығында [`Ordering`] мәнін қайтарады.
    ///
    /// Шарт бойынша `self.cmp(&other)`, егер шын болса, `self <operator> other` өрнегіне сәйкес келетін ретті қайтарады.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Екі мәннің максимумын салыстырады және қайтарады.
    ///
    /// Егер салыстыру олардың теңдігін анықтаса, екінші аргументті береді.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Екі мәннің минимумын салыстырады және қайтарады.
    ///
    /// Егер салыстыру олардың теңдігін анықтаса, бірінші аргументті береді.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Мәнді белгілі бір аралықпен шектеңіз.
    ///
    /// Егер `self` `max`-тен үлкен болса `max`, ал `self` `min`-тен кіші болса `min` қайтарады.
    /// Әйтпесе, бұл `self` қайтарады.
    ///
    /// # Panics
    ///
    /// Panics, егер `min > max` болса.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// trait `Ord` имплизиясын жасайтын макросты шығарыңыз.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait-сұрыптау реті бойынша салыстыруға болатын мәндер үшін.
///
/// Салыстыру барлық `a`, `b` және `c` үшін қанағаттандыруы керек:
///
/// - асимметрия: егер `a < b` болса `!(a > b)`, сонымен қатар `a > b` `!(a < b)`-ті білдіреді;және
/// - өтімділік: `a < b` және `b < c` `a < c` білдіреді.`==` және `>` үшін бірдей болуы керек.
///
/// Бұл талаптар trait симметриялы және өтпелі түрде жүзеге асырылуы керек екенін білдіреді: егер `T: PartialOrd<U>` және `U: PartialOrd<V>`, содан кейін `U: PartialOrd<T>` және `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// Бұл trait-ті `#[derive]` көмегімен пайдалануға болады.Құрылымдардан алынған кезде, құрылым мүшелерінің жоғарыдан төмен декларациялау тәртібі негізінде лексикографиялық ретке келтіреді.
/// Enum-де «шығарылғанда», нұсқалар жоғарыдан төменге қарай дискриминантты ретімен реттеледі.
///
/// ## `PartialOrd`-ті қалай қолдануға болады?
///
/// `PartialOrd` тек [`partial_cmp`] әдісін іске асыруды қажет етеді, ал басқалары әдепкі іске асырулардан пайда болады.
///
/// Алайда басқаларын жалпы тәртібі жоқ түрлер үшін бөлек жүзеге асыруға болады.
/// Мысалы, өзгермелі нүктелік сандар үшін `NaN < 0 == false` және `NaN >= 0 == false` (қар.
/// IEEE 754-2008 бөлімі 5.11).
///
/// `PartialOrd` сіздің түріңіздің [`PartialEq`] болуын талап етеді.
///
/// [`PartialEq`], `PartialOrd` және [`Ord`]*іске асырулары* бір-бірімен келісуі керек.
/// traits-нің бір бөлігін шығару және басқаларын қолмен енгізу арқылы оларды кездейсоқтыққа душар ету оңай.
///
/// Егер сіздің типіңіз [`Ord`] болса, сіз [`partial_cmp`]-ті [`cmp`] көмегімен жүзеге асыра аласыз:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Сондай-ақ, [`partial_cmp`] түрін сіздің өрістеріңізде қолдану пайдалы болуы мүмкін.
/// Мұнда сұрыптауға қолданылатын жалғыз өріс болатын өзгермелі `height` өрісі бар `Person` типтерінің мысалы келтірілген:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Бұл әдіс, егер бар болса, `self` және `other` мәндері арасындағы ретті қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Салыстыру мүмкін болмаған кезде:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Бұл әдіс (`self` және `other` үшін)-дан азырақ тестілейді және оны `<` операторы қолданады.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Бұл әдіс (`self` және `other` үшін) аз немесе оған тең сынайды және оны `<=` операторы қолданады.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Бұл әдіс (`self` және `other` үшін)-тен үлкен сынайды және оны `>` операторы қолданады.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Бұл әдіс (`self` және `other` үшін) үлкен немесе тең болатындығын тексереді және оны `>=` операторы қолданады.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// trait `PartialOrd` имплизиясын жасайтын макросты шығарыңыз.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Екі мәннің минимумын салыстырады және қайтарады.
///
/// Егер салыстыру олардың теңдігін анықтаса, бірінші аргументті береді.
///
/// Ішкі [`Ord::min`] бүркеншік атын қолданады.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Көрсетілген салыстыру функциясына қатысты екі минимумды қайтарады.
///
/// Егер салыстыру олардың теңдігін анықтаса, бірінші аргументті береді.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Көрсетілген функциядан минималды мән беретін элементті қайтарады.
///
/// Егер салыстыру олардың теңдігін анықтаса, бірінші аргументті береді.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Екі мәннің максимумын салыстырады және қайтарады.
///
/// Егер салыстыру олардың теңдігін анықтаса, екінші аргументті береді.
///
/// Ішкі [`Ord::max`] бүркеншік атын қолданады.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Көрсетілген салыстыру функциясына қатысты екі мәннің максимумын қайтарады.
///
/// Егер салыстыру олардың теңдігін анықтаса, екінші аргументті береді.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Көрсетілген функциядан максималды мән беретін элементті қайтарады.
///
/// Егер салыстыру олардың теңдігін анықтаса, екінші аргументті береді.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Қарабайыр типтер үшін PartialEq, Eq, PartialOrd және Ord-тің орындалуы
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // Мұндағы тапсырыс неғұрлым оңтайлы құрастыру жасау үшін маңызды.
                    // Қосымша ақпарат алу үшін <https://github.com/rust-lang/rust/issues/63758> қараңыз.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // I8-ге құйып, айырмашылықты Тапсырысқа ауыстыру оңтайлы құрастыруды тудырады.
            //
            // Қосымша ақпарат алу үшін <https://github.com/rust-lang/rust/issues/66780> қараңыз.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // ҚАУІПСІЗДІК: bool ретінде i8 0 немесе 1 мәнін береді, сондықтан айырмашылық басқа болуы мүмкін емес
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &көрсеткіштер

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}