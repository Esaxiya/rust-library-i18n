//! Бөлісетін өзгермелі контейнерлер.
//!
//! Rust жадының қауіпсіздігі осы ережеге негізделген: `T` нысанын ескере отырып, келесілердің біреуіне ғана қол жеткізуге болады:
//!
//! - (`&T`) объектісіне бірнеше өзгермейтін сілтемелері бар (**лақаптау** деп те аталады).
//! - Нысанға бір өзгеретін сілтеме (`&&mut T`) бар (**өзгергіштік** деп те аталады).
//!
//! Мұны Rust компиляторы қолданады.Алайда, бұл ереже жеткілікті икемді емес жағдайлар бар.Кейде объектіге бірнеше сілтеме жасау қажет, бірақ оны өзгертеді.
//!
//! Бөлісетін өзгермелі контейнерлер өзгергіштікке басқарылатын тәсілмен, бүркеншік атпен болған жағдайда да мүмкіндік береді.[`Cell<T>`] және [`RefCell<T>`] екеуі бұны бір бұрандалы тәсілмен жасауға мүмкіндік береді.
//! Алайда, `Cell<T>` де, `RefCell<T>` те қауіпсіз емес (олар [`Sync`]-ті қолданбайды).
//! Егер сізге бірнеше ағындар арасында лақаптау және мутация жасау қажет болса, [`Mutex<T>`], [`RwLock<T>`] немесе [`atomic`] типтерін қолдануға болады.
//!
//! `Cell<T>` және `RefCell<T>` типтерінің мәндері ортақ сілтемелер арқылы мутацияға ұшырауы мүмкін (яғни
//! жалпы `&T` типі), ал Rust типтерінің көпшілігі тек бірегей (`&mut T`) сілтемелер арқылы мутациялануы мүмкін.
//! Біз `Cell<T>` және `RefCell<T>` «тұқым қуалайтын өзгергіштікті» көрсететін типтік Rust түрлерінен айырмашылығы «ішкі өзгергіштікті» қамтамасыз етеді деп айтамыз.
//!
//! Жасуша түрлері екі түрлі болады: `Cell<T>` және `RefCell<T>`.`Cell<T>` ішкі өзгергіштікті `Cell<T>` ішіне және одан тыс мәндерді жылжыту арқылы жүзеге асырады.
//! Мәндердің орнына сілтемелерді қолдану үшін мутацияға дейін жазу құлпын сатып алып, `RefCell<T>` типін қолдану керек.`Cell<T>` ағымдағы ішкі мәнді алу және өзгерту әдістерін ұсынады:
//!
//!  - [`Copy`]-ті іске асыратын типтер үшін [`get`](Cell::get) әдісі ағымдағы интерьер мәнін шығарады.
//!  - [`Default`]-ті іске асыратын типтер үшін [`take`](Cell::take) әдісі ағымдағы ішкі мәнді [`Default::default()`]-ке ауыстырады және ауыстырылған мәнді қайтарады.
//!  - Барлық типтер үшін [`replace`](Cell::replace) әдісі ағымдағы интерьер мәнін ауыстырады және ауыстырылған мәнді қайтарады, ал [`into_inner`](Cell::into_inner) әдісі `Cell<T>` жұмсайды және ішкі мәнді қайтарады.
//!  Сонымен қатар, [`set`](Cell::set) әдісі ішкі мәнді ауыстырады, ауыстырылған мәнді төмендетеді.
//!
//! `RefCell<T>` ішкі динамикаға уақытша, эксклюзивті, өзгермелі қол жетімділікті талап ете алатын процесс-«динамикалық қарыз алуды» жүзеге асыру үшін Rust өмір сүру уақытын пайдаланады.
//! RefCell үшін қарыз<T>Rust-тің жергілікті сілтеме түрлерінен айырмашылығы, олар компиляция кезінде толығымен статикалық түрде бақыланады.
//! `RefCell<T>` қарыздары динамикалық болғандықтан, өзара қарызға алынған мәнді алуға тырысуға болады;бұл орын алған кезде panic ағыны пайда болады.
//!
//! # Интерьердің өзгергіштігін қашан таңдау керек
//!
//! Көбінесе мұраны өзгертетін өзгергіштік, мұнда мәнді өзгертуге бірыңғай қол жетімділік болуы керек, бұл Rust-қа сілтемелерді бүркеншікке жіберу туралы ой қозғауға мүмкіндік беретін, бұзылу қателерін статикалық түрде болдырмайтын негізгі тілдік элементтердің бірі.
//! Осыған байланысты тұқым қуалайтын өзгергіштікке басымдық беріледі, ал ішкі өзгергіштік-бұл соңғы шешім.
//! Ұяшық типтері мутацияға жол бермейді, өйткені оны басқаша болдырмауға болады, сондықтан ішкі өзгергіштік орынды болады, тіпті *қолданылуы керек*.
//!
//! * Өзгермейтін 'inside' өзгергіштігін енгізу
//! * Логикалық-өзгермейтін әдістерді енгізу бөлшектері.
//! * [`Clone`]-тің мутациялық енгізілімдері.
//!
//! ## Өзгермейтін 'inside' өзгергіштігін енгізу
//!
//! [`Rc<T>`] және [`Arc<T>`] қоса алғанда, көптеген ақылды меңзер түрлері клонданатын және бірнеше тараптар арасында ортақ пайдаланылатын контейнерлерді ұсынады.
//! Құрамындағы мәндер бірнеше реттік болуы мүмкін болғандықтан, оларды `&mut` емес, тек `&` арқылы алуға болады.
//! Ұяшықсыз бұл ақылды көрсеткіштердің ішіндегі деректерді мутациялау мүлдем мүмкін емес еді.
//!
//! Өзгергіштікті қалпына келтіру үшін `RefCell<T>`-ті ортақ сілтегіш түрлеріне қою өте кең таралған:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Динамикалық қарыздың көлемін шектеу үшін жаңа блок жасаңыз
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Егер біз кэштің алдыңғы қарызының қолдану аясынан шығып кетуіне жол бермеген болсақ, келесі қарыз динамикалық panic ағынына әкелетінін ескеріңіз.
//!     //
//!     // Бұл `RefCell` пайдалану қаупі.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Бұл мысалда `Arc<T>` емес, `Rc<T>` қолданылатынын ескеріңіз.`RefCell<T>бұл жалғыз ағынды сценарийлерге арналған.Егер сізге көп ағынды жағдайда ортақ өзгергіштік қажет болса, [`RwLock<T>`] немесе [`Mutex<T>`] қолдануды қарастырыңыз.
//!
//! ## Логикалық-өзгермейтін әдістерді енгізу бөлшектері
//!
//! Кейде API-де "under the hood" болып жатқан мутациялар туралы айтпаған жөн болар.
//! Бұл логикалық тұрғыдан операция өзгермейтін болғандықтан болуы мүмкін, бірақ, мысалы, кэштеу мутацияны жүзеге асыруға мәжбүр етеді;немесе `&self` қабылдауға бастапқыда анықталған trait әдісін енгізу үшін сізде мутация қолдануыңыз керек.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Қымбат есептеу осында өтеді
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## `Clone`-тің мутациялық енгізілімдері
//!
//! Бұл бұрынғы жағдайдың ерекше, бірақ жиі кездесетін жағдайы: өзгермейтін болып көрінетін операциялар үшін өзгергіштікті жасыру.
//! [`clone`](Clone::clone) әдісі бастапқы мәнді өзгертпейді деп күтілуде және `&mut self` емес, `&self` қабылданады деп жарияланды.
//! Сондықтан `clone` әдісінде болатын кез-келген мутация ұяшық типтерін қолдануы керек.
//! Мысалы, [`Rc<T>`] сілтеме санақтарын `Cell<T>` ішінде сақтайды.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Өзгеретін жад орны.
///
/// # Examples
///
/// Бұл мысалда `Cell<T>` өзгермейтін құрылымның ішіндегі мутацияға мүмкіндік беретінін көруге болады.
/// Басқаша айтқанда, бұл "interior mutability" мүмкіндік береді.
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ҚАТЕ: `my_struct` өзгермейді
/// // my_struct.regular_field =жаңа_мән;
///
/// // ЖҰМЫС: `my_struct` өзгермейтін болса да, `special_field`-`Cell`,
/// // әрқашан мутацияға ұшырауы мүмкін
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Толығырақ [module-level documentation](self) қараңыз.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// T үшін `Default` мәнімен `Cell<T>` жасайды.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Берілген мәнді қамтитын жаңа `Cell` жасайды.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Құрамындағы мәнді орнатады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Екі ұяшықтың мәндерін ауыстырады.
    /// `std::mem::swap` айырмашылығы-бұл функцияға `&mut` сілтемесін қажет етпейді.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // ҚАУІПСІЗДІК: егер бұл бөлек жіптерден шақырылса, қауіпті болуы мүмкін, бірақ `Cell`
        // бұл `!Sync`, сондықтан бұл болмайды.
        // Бұл сонымен қатар кез-келген көрсеткішті жарамсыз етпейді, өйткені `Cell` осы ұяшықтардың кез-келгеніне ештеңе бағытталмайтындығына көз жеткізеді.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Құрамындағы мәнді `val`-мен ауыстырады және ескі мәнді қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // ҚАУІПСІЗДІК: егер бұл бөлек ағыннан шақырылса, деректер жарыстарын тудыруы мүмкін,
        // бірақ `Cell`-бұл `!Sync`, сондықтан бұл болмайды.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Мәнді ашады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Құрамындағы мәннің көшірмесін қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // ҚАУІПСІЗДІК: егер бұл бөлек ағыннан шақырылса, деректер жарыстарын тудыруы мүмкін,
        // бірақ `Cell`-бұл `!Sync`, сондықтан бұл болмайды.
        unsafe { *self.value.get() }
    }

    /// Құрамындағы функцияны функцияны пайдаланып жаңартады және жаңа мәнді қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Осы ұяшықтағы негізгі деректерге шикі көрсеткішті қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Негізгі деректерге өзгертілетін сілтемені қайтарады.
    ///
    /// Бұл қоңырау `Cell`-ті бір уақытта өзгертеді (жинақ кезінде), бұл біздің жалғыз анықтамаға ие екендігімізге кепілдік береді.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `&mut T`-тен `&Cell<T>` қайтарады
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // ҚАУІПСІЗДІК: `&mut` бірегей қол жетімділікті қамтамасыз етеді.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Ұяшықтың мәнін алады, оның орнына `Default::default()` қалдырады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// `&Cell<[T]>`-тен `&[Cell<T>]` қайтарады
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // ҚАУІПСІЗДІК: `Cell<T>` жадының орналасуы `T` сияқты.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Қарыз алудың динамикалық тексерілген ережелері бар өзгертілетін жад орны
///
/// Толығырақ [module-level documentation](self) қараңыз.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// [`RefCell::try_borrow`] қайтарған қате.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// [`RefCell::try_borrow_mut`] қайтарған қате.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Оң мәндер белсенді `Ref` санын білдіреді.Теріс мәндер белсенді `RefMut` санын білдіреді.
// Бірнеше `RefMut` бір уақытта, егер олар `RefCell`-тің бір-біріне сәйкес келмейтін компоненттеріне қатысты болса ғана белсенді бола алады (мысалы, тілімнің әр түрлі диапазоны).
//
// `Ref` және `RefMut`-бұл екі сөздің өлшемі, сондықтан `usize` ауқымының жартысынан асып кету үшін «Ref» немесе «RefMut» ешқашан жеткіліксіз болады.
// Осылайша, `BorrowFlag` ешқашан толып кетпейді немесе толып кетпейді.
// Алайда, бұл кепілдік емес, өйткені патологиялық бағдарлама бірнеше рет жасай алады, содан кейін mem::forget `Ref`s немесе`RefMut`s.
// Осылайша, барлық кодтар қауіпсіздікті болдырмау үшін немесе толып кету немесе толып кету жағдайында өзін дұрыс ұстау үшін толып кету мен толып кетуді анық тексеруі керек (мысалы, BorrowRef::new қараңыз).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Құрамында `value` бар жаңа `RefCell` жасайды.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// `RefCell` тұтынады, оралған мәнді қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Бұл функция мәні бойынша `self` (`RefCell`) алатындықтан, компилятор оның қазіргі уақытта алынбағанын статикалық түрде тексереді.
        //
        self.value.into_inner()
    }

    /// Екеуі деинициализациясыз, ескі мәнді қайтара отырып, оралған мәнді жаңасымен ауыстырады.
    ///
    ///
    /// Бұл функция [`std::mem::replace`](../mem/fn.replace.html) сәйкес келеді.
    ///
    /// # Panics
    ///
    /// Panics, егер мән қазіргі уақытта қарызға алынған болса.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Ескі мәнді қайтара отырып, оралған мәнді `f` есептелген жаңасымен ауыстырады, екеуін деинициализацияламай.
    ///
    ///
    /// # Panics
    ///
    /// Panics, егер мән қазіргі уақытта қарызға алынған болса.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// `self` оралған мәнін `other` оралған мәнімен ауыстырады, біреуін деинициализацияламай.
    ///
    ///
    /// Бұл функция [`std::mem::swap`](../mem/fn.swap.html) сәйкес келеді.
    ///
    /// # Panics
    ///
    /// Panics, егер кез-келген `RefCell` мәні қарызға алынған болса.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Оралған құнды өзгертпестен қарызға алады.
    ///
    /// Қарыз қайтарылған `Ref` көлемінен шыққанға дейін созылады.
    /// Бір уақытта бірнеше өзгермейтін қарыздар алуға болады.
    ///
    /// # Panics
    ///
    /// Panics, егер мәні қазіргі уақытта өзгертіліп алынған болса.
    /// Дүрбелең емес нұсқа үшін [`try_borrow`](#method.try_borrow) пайдаланыңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// panic мысалы:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Оралған мәнді өзгертпестен қарызға алады, егер қате қазіргі уақытта өзгеріп отырса, қате қайтарылады.
    ///
    ///
    /// Қарыз қайтарылған `Ref` көлемінен шыққанға дейін созылады.
    /// Бір уақытта бірнеше өзгермейтін қарыздар алуға болады.
    ///
    /// Бұл [`borrow`](#method.borrow)-нің дүрбелең емес нұсқасы.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // ҚАУІПСІЗДІК: `BorrowRef` тек өзгермейтін қол жетімділікке кепілдік береді
            // қарызға алынған кездегі мәнге дейін.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Маңызды түрде оралған құнды қарызға алады.
    ///
    /// Қарыз қайтарылған `RefMut`-ге дейін немесе одан алынған барлық RefMut-тің ауқымынан шыққанға дейін созылады.
    ///
    /// Бұл қарыз белсенді болған кезде құнды алуға болмайды.
    ///
    /// # Panics
    ///
    /// Panics, егер мән қазіргі уақытта қарызға алынған болса.
    /// Дүрбелең емес нұсқа үшін [`try_borrow_mut`](#method.try_borrow_mut) пайдаланыңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// panic мысалы:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Маңызды түрде оралған мәнді қарызға алады, егер мән қазіргі уақытта алынған болса, қатені қайтарады.
    ///
    ///
    /// Қарыз қайтарылған `RefMut`-ге дейін немесе одан алынған барлық RefMut-тің ауқымынан шыққанға дейін созылады.
    /// Бұл қарыз белсенді болған кезде құнды алуға болмайды.
    ///
    /// Бұл [`borrow_mut`](#method.borrow_mut)-нің дүрбелең емес нұсқасы.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // ҚАУІПСІЗДІК: `BorrowRef` бірегей қол жетімділікке кепілдік береді.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Осы ұяшықтағы негізгі деректерге шикі көрсеткішті қайтарады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Негізгі деректерге өзгертілетін сілтемені қайтарады.
    ///
    /// Бұл қоңырау `RefCell`-ті өзгертеді (компиляция кезінде), сондықтан динамикалық тексерулер қажет емес.
    ///
    /// Алайда сақ болыңыз: бұл әдіс `self`-ті өзгеріске ұшыратады деп күтеді, бұл `RefCell`-ті пайдалану кезінде әдетте болмайды.
    ///
    /// Егер `self` өзгермейтін болса, оның орнына [`borrow_mut`] әдісін қарастырыңыз.
    ///
    /// Сонымен қатар, бұл әдіс тек ерекше жағдайларға арналған және әдетте сіз қалағандай болмайтынын ескеріңіз.
    /// Егер күмән туындаса, оның орнына [`borrow_mut`] қолданыңыз.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Ағып кеткен күзетшілердің `RefCell` күйіне әсерін болдырмаңыз.
    ///
    /// Бұл қоңырау [`get_mut`]-ге ұқсас, бірақ мамандандырылған.
    /// Қарыздардың болмауын қамтамасыз ету үшін ол `RefCell`-ті өзгерте отырып алады, содан кейін мемлекеттік бақылаудың ортақ қарыздарын қалпына келтіреді.
    /// Бұл кейбір `Ref` немесе `RefMut` қарыздары пайда болған жағдайда маңызды.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Оралған мәнді өзгертпестен қарызға алады, егер қате қазіргі уақытта өзгеріп отырса, қате қайтарылады.
    ///
    /// # Safety
    ///
    /// `RefCell::borrow`-тен айырмашылығы, бұл әдіс қауіпті, өйткені ол `Ref` мәнін қайтармайды, осылайша қарыз жалаушасын өзгертусіз қалдырады.
    /// Осы әдіспен қайтарылған сілтеме тірі кезінде `RefCell`-ті өзара қарызға алу-бұл анықталмаған тәртіп.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // ҚАУІПСІЗДІК: Біз қазір ешкім белсенді жазбайтынын тексереміз, бірақ ол солай
            // қоңырау шалушының жауап қайтарылған сілтеме қолданылмайынша ешкім жазбайтындығына жауап береді.
            // Сондай-ақ, `self.value.get()` `self`-ке тиесілі мәнге сілтеме жасайды және осылайша `self` өмір бойы жарамды екеніне кепілдік береді.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// `Default::default()` орнына қойып, оралған мәнді алады.
    ///
    /// # Panics
    ///
    /// Panics, егер мән қазіргі уақытта қарызға алынған болса.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics, егер мәні қазіргі уақытта өзгертіліп алынған болса.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// T үшін `Default` мәнімен `RefCell<T>` жасайды.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics, егер кез-келген `RefCell` мәні қарызға алынған болса.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics, егер кез-келген `RefCell` мәні қарызға алынған болса.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics, егер кез-келген `RefCell` мәні қарызға алынған болса.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, егер кез-келген `RefCell` мәні қарызға алынған болса.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, егер кез-келген `RefCell` мәні қарызға алынған болса.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, егер кез-келген `RefCell` мәні қарызға алынған болса.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics, егер кез-келген `RefCell` мәні қарызға алынған болса.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Несиені ұлғайту келесі жағдайда оқымайтын мәнге (<=0) әкелуі мүмкін:
            // 1. Бұл <0 болды, яғни жазбаша қарыздар бар, сондықтан Rust сілтеме жасырын ережелеріне байланысты оқуға қарыз алуға рұқсат бере алмаймыз
            // 2.
            // Бұл isize::MAX (оқу қарыздарының максималды мөлшері) болды және ол isize::MIN-ге толды (жазбаша қарыздардың максималды мөлшері), сондықтан біз қосымша оқуға рұқсат бере алмаймыз, өйткені isize көптеген оқылған қарыздарды көрсете алмайды (бұл жағдайда ғана болуы мүмкін сіз mem::forget шамалы тұрақты мөлшерден көп, бұл жақсы тәжірибе емес)
            //
            //
            //
            //
            None
        } else {
            // Несиені ұлғайту келесі жағдайда оқу мәніне (> 0) әкелуі мүмкін:
            // 1. Бұл=0 болды, яғни қарызға алынған жоқ, және біз бірінші оқылған қарызды аламыз
            // 2. Бұл> 0 және <isize::MAX болды, яғни
            // оқылған қарыздар болды, және оқудың көлемі тағы бір оқылған қарызға ие болатындай үлкен
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Бұл Ref болғандықтан, біз қарыздың жалаушасын оқудың қарызы деп білеміз.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Қарыз есептегішінің жазбаша қарызға толып кетуіне жол бермеңіз.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Алынған сілтемені `RefCell` қорабындағы мәнге орайды.
/// `RefCell<T>`-ден алынған өзгермейтін қарызға арналған орам түрі.
///
/// Толығырақ [module-level documentation](self) қараңыз.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// `Ref` көшірмесі.
    ///
    /// `RefCell` қазірдің өзінде өзгеріссіз қарызға алынған, сондықтан бұл мүмкін емес.
    ///
    /// Бұл `Ref::clone(...)` ретінде қолдануды қажет ететін функция.
    /// `Clone` іске асырылуы немесе әдісі `RefCell` мазмұнын клондау үшін `r.borrow().clone()` кеңінен қолдануға кедергі келтіреді.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Қарызға алынған мәліметтер компоненті үшін жаңа `Ref` жасайды.
    ///
    /// `RefCell` қазірдің өзінде өзгеріссіз қарызға алынған, сондықтан бұл мүмкін емес.
    ///
    /// Бұл `Ref::map(...)` ретінде қолдануды қажет ететін функция.
    /// Әдіс `Deref` арқылы қолданылатын `RefCell` мазмұнындағы аттас әдістерге кедергі келтіреді.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Қарызға алынған деректердің қосымша компоненті үшін жаңа `Ref` жасайды.
    /// Түпнұсқа күзет `Err(..)` ретінде қайтарылады, егер жабу `None` қайтарса.
    ///
    /// `RefCell` қазірдің өзінде өзгеріссіз қарызға алынған, сондықтан бұл мүмкін емес.
    ///
    /// Бұл `Ref::filter_map(...)` ретінде қолдануды қажет ететін функция.
    /// Әдіс `Deref` арқылы қолданылатын `RefCell` мазмұнындағы аттас әдістерге кедергі келтіреді.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Алынған деректердің әртүрлі компоненттері үшін `Ref`-ті бірнеше `Ref`-ге бөледі.
    ///
    /// `RefCell` қазірдің өзінде өзгеріссіз қарызға алынған, сондықтан бұл мүмкін емес.
    ///
    /// Бұл `Ref::map_split(...)` ретінде қолдануды қажет ететін функция.
    /// Әдіс `Deref` арқылы қолданылатын `RefCell` мазмұнындағы аттас әдістерге кедергі келтіреді.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Негізгі деректерге сілтеме жасаңыз.
    ///
    /// Негізгі `RefCell` ешқашан өзгертіле отырып қарызға алынбайды және әрқашан өзгеріссіз алынған болып көрінеді.
    ///
    /// Сілтемелердің тұрақты санынан гөрі ағып кету жақсы емес.
    /// Барлығы аз мөлшерде ағып кету болған жағдайда, `RefCell`-ны қайтадан қарызға алуға болады.
    ///
    /// Бұл `Ref::leak(...)` ретінде қолдануды қажет ететін функция.
    /// Әдіс `Deref` арқылы қолданылатын `RefCell` мазмұнындағы аттас әдістерге кедергі келтіреді.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Осы сілтемені ұмыта отырып, біз RefCell ішіндегі қарыз есептегіші өмір бойы `'b` ішінде пайдаланылмаған күйіне қайта оралмауын қамтамасыз етеміз.
        // Анықтамалық бақылау күйін қалпына келтіру үшін қарызға алынған RefCell-ке бірегей сілтеме қажет.
        // Басқа ұяшықтан өзгертілетін сілтемелер жасауға болмайды.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Алынған мәліметтер компоненті үшін жаңа `RefMut` жасайды, мысалы, enum нұсқасы.
    ///
    /// `RefCell` қазірдің өзінде қарызға алынған, сондықтан бұл мүмкін емес.
    ///
    /// Бұл `RefMut::map(...)` ретінде қолдануды қажет ететін функция.
    /// Әдіс `Deref` арқылы қолданылатын `RefCell` мазмұнындағы аттас әдістерге кедергі келтіреді.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): қарызды тексеру
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Қарызға алынған деректердің қосымша компоненті үшін жаңа `RefMut` жасайды.
    /// Түпнұсқа күзет `Err(..)` ретінде қайтарылады, егер жабу `None` қайтарса.
    ///
    /// `RefCell` қазірдің өзінде қарызға алынған, сондықтан бұл мүмкін емес.
    ///
    /// Бұл `RefMut::filter_map(...)` ретінде қолдануды қажет ететін функция.
    /// Әдіс `Deref` арқылы қолданылатын `RefCell` мазмұнындағы аттас әдістерге кедергі келтіреді.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): қарызды тексеру
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // ҚАУІПСІЗДІК: функция ұзақ уақыт бойы эксклюзивті сілтемеде болады
        // оның қоңырауының `orig` арқылы, ал сілтеме тек функционалды шақырудың ішінде сілтеме жасалынған, эксклюзивті сілтеменің қашып кетуіне жол бермейді.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // ҚАУІПСІЗДІК: жоғарыдағыдай.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Алынған деректердің әртүрлі компоненттері үшін `RefMut`-ті бірнеше `RefMut`-ке бөледі.
    ///
    /// Негізгі `RefCell` екі қайтарылған RefMut-тің қолданылу аясынан шыққанға дейін өзгермелі түрде қарыз болып қала береді.
    ///
    /// `RefCell` қазірдің өзінде қарызға алынған, сондықтан бұл мүмкін емес.
    ///
    /// Бұл `RefMut::map_split(...)` ретінде қолдануды қажет ететін функция.
    /// Әдіс `Deref` арқылы қолданылатын `RefCell` мазмұнындағы аттас әдістерге кедергі келтіреді.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Негізгі деректерге өзгермелі сілтеме жасаңыз.
    ///
    /// Негізгі `RefCell`-ті қайтадан алуға болмайды және әрқашан өзгертілген түрде пайда болады, бұл қайтарылған интерьерге интерьерге ғана сілтеме жасайды.
    ///
    ///
    /// Бұл `RefMut::leak(...)` ретінде қолдануды қажет ететін функция.
    /// Әдіс `Deref` арқылы қолданылатын `RefCell` мазмұнындағы аттас әдістерге кедергі келтіреді.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Осы BorrowRefMut-ті ұмыта отырып, біз RefCell-дегі қарыз есептегіші `'b` өмір бойы UNUSED-ке оралмайтындығына кепілдік береміз.
        // Анықтамалық бақылау күйін қалпына келтіру үшін қарызға алынған RefCell-ке бірегей сілтеме қажет.
        // Осы уақыт ішінде бастапқы ұяшықтан басқа сілтемелер жасалуы мүмкін емес, сондықтан ағымдағы қарыз қалған өмір бойы жалғыз сілтеме болады.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: BorrowRefMut::clone-тен айырмашылығы, жаңа инициалды құру үшін шақырылады
        // өзгертілетін сілтеме, сондықтан қазіргі уақытта сілтемелер болмауы керек.
        // Осылайша, клон өзгертілетін қайта санауды арттырған кезде, біз бұл жерде тек UNUSED-ден UNUSED, 1-ге өтуге мүмкіндік береміз.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // `BorrowRefMut` клонын клондайды.
    //
    // Бұл әрбір `BorrowRefMut` бастапқы объектінің нақты, бір-біріне сәйкес келмейтін диапазонына өзгермелі сілтемені бақылау үшін пайдаланылған жағдайда ғана жарамды.
    //
    // Бұл Clone имплинде жоқ, сондықтан код оны жасырын шақырмауы керек.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Қарыз есептегішінің ағып кетуіне жол бермеңіз.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// `RefCell<T>`-тен алынатын өзгермелі мәнге арналған орауыш түрі.
///
/// Толығырақ [module-level documentation](self) қараңыз.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Rust ішіндегі ішкі өзгергіштік үшін негізгі қарабайыр.
///
/// Егер сізде `&T` анықтамасы болса, онда әдетте Rust-де компилятор `&T` өзгермейтін деректерге нұсқайтындығы негізінде оңтайландыруларды орындайды.Бұл деректерді өзгерту, мысалы, бүркеншік ат арқылы немесе `&T`-ті `&mut T`-ге ауыстыру, анықталмаған әрекет деп саналады.
/// `UnsafeCell<T>` `&T` үшін өзгермейтіндік кепілдігінен бас тарту: `&UnsafeCell<T>` ортақ сілтемесі мутацияланатын деректерге нұсқауы мүмкін.Бұл "interior mutability" деп аталады.
///
/// `Cell<T>` және `RefCell<T>` сияқты ішкі өзгергіштікке мүмкіндік беретін барлық басқа түрлері, олардың деректерін орау үшін `UnsafeCell` ішін пайдаланады.
///
/// `UnsafeCell` ортақ сілтемелер үшін өзгермейтін кепілдікке ғана әсер ететінін ескеріңіз.Өзгеретін сілтемелердің бірегейлігіне кепілдік әсер етпейді.`&mut`, тіпті `UnsafeCell<T>` арқылы да лақап ат алудың * заңды әдісі жоқ.
///
/// `UnsafeCell` API өзі техникалық тұрғыдан өте қарапайым: [`.get()`] сізге оның мазмұнына `*mut T` шикі көрсеткішін береді.Сол шикі көрсеткішті дұрыс пайдалану абстракция дизайнері ретінде _you_ дейін.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Rust лақап атының нақты ережелері біршама өзгеріске ұшырайды, бірақ негізгі мәселелер дау тудырмайды:
///
/// - Егер сіз өмір бойы `'a` бар қауіпсіз сілтеме жасасаңыз (немесе `&T` немесе `&mut T` сілтемесі), оған қауіпсіз код қол жетімді болса (мысалы, сіз оны қайтарған болсаңыз), онда сіз деректерге осы сілтемеге қайшы келетін кез келген жолмен қол жеткізбеуіңіз керек `'a`.
/// Мысалы, егер сіз `*mut T`-ті `UnsafeCell<T>`-тен алып, оны `&T`-ге тастасаңыз, онда `T`-тегі мәліметтер өзгермейтін болып қалуы керек (`T` ішінде табылған кез-келген `UnsafeCell` деректерін модуль бойынша) осы сілтеменің қызмет ету мерзімі аяқталғанға дейін.
/// Сол сияқты, егер сіз қауіпсіз кодқа шығарылған `&mut T` сілтемесін жасасаңыз, онда сіз `UnsafeCell` ішіндегі деректерге осы сілтеме аяқталғанға дейін қол жеткізбеуіңіз керек.
///
/// - Кез-келген уақытта сіз деректер жарыстарынан аулақ болуыңыз керек.Егер бірнеше ағындар бірдей `UnsafeCell`-ке қол жеткізе алса, онда кез-келген жазбада барлық басқа қол жетімділіктермен (немесе атомиканы қолданумен) байланыста тиісті жағдай болуы керек.
///
/// Тиісті дизайнға көмектесу үшін келесі сценарийлер бір ағынды код үшін заңды деп жарияланды:
///
/// 1. `&T` сілтемесін қауіпсіз кодқа жіберуге болады және ол басқа `&T` сілтемелерімен бірге өмір сүре алады, бірақ `&mut T`-пен емес
///
/// 2. `&mut T` сілтемесі қауіпсіз кодқа жіберілуі мүмкін, егер онымен бірге басқа `&mut T` немесе `&T` болмаса.`&mut T` әрқашан бірегей болуы керек.
///
/// `&UnsafeCell<T>` мазмұнын өзгерту (басқа `&UnsafeCell<T>` ұяшықтың бүркеншік атына сілтеме жасаған кезде де) дұрыс болғанын ескеріңіз (егер сіз жоғарыда келтірілген инварианттарды басқа жолмен қолданған болсаңыз), бірнеше `&mut UnsafeCell<T>` бүркеншік аттарының болуы әлі де анықталмаған.
/// Яғни, `UnsafeCell`-бұл _shared_ accesses (_i.e._-пен, `&UnsafeCell<_>` сілтемесі арқылы ерекше өзара әрекеттесуге арналған);_exclusive_ accesses (_e.g._-пен жұмыс істегенде ешқандай сиқыр жоқ, `&mut UnsafeCell<_>` арқылы): ұяшық та, оралған мән де сол `&mut` қарызының мерзімі ішінде өзгертілмеуі мүмкін.
///
/// Мұны [`.get_mut()`] аксессоры көрсетеді, бұл _safe_ getter, ол `&mut T` береді.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Мұнда `UnsafeCell<_>` мазмұнын дыбыстық өзгертетін мысал келтірілген, бұл ұяшыққа бірнеше сілтемелер болғанына қарамастан:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Бірдей `x`-ке бірнеше/бір уақытта/ортақ сілтемелер алыңыз.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // ҚАУІПСІЗДІК: осы ауқымда «x» мазмұнына басқа сілтемелер жоқ,
///     // сондықтан біздікі бірегей.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- қарыз-+
///     *p1_exclusive += 27; // |
/// } // <---------- осы сәттен әрі аса алмайды -------------------+
///
/// unsafe {
///     // ҚАУІПСІЗДІК: бұл шеңберде ешкім «x» мазмұнына эксклюзивті қол жетімділікті күтпейді,
///     // бір уақытта бірнеше жалпы қол жетімділікке қол жеткізе аламыз.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Келесі мысалда `UnsafeCell<T>`-ке эксклюзивті қол жетімділік оның `T`-ке эксклюзивті қол жетімділікті білдіретін фактіні көрсетеді:
///
/// ```rust
/// #![forbid(unsafe_code)] // эксклюзивті қол жетімділікпен,
///                         // `UnsafeCell` мөлдір оп-пакет, сондықтан мұнда `unsafe` қажет емес.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // `x` үшін компиляция уақытында тексерілген бірегей сілтеме алыңыз.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Эксклюзивті анықтама арқылы біз мазмұнын ақысыз өзгерте аламыз.
/// *p_unique.get_mut() = 0;
/// // Немесе, баламалы түрде:
/// x = UnsafeCell::new(0);
///
/// // Біз құндылыққа иелік еткенде, оның мазмұнын ақысыз алуға болады.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Көрсетілген мәнді орайтын `UnsafeCell` жаңа данасын салады.
    ///
    ///
    /// Ішкі құндылыққа әдістер арқылы қол жетімділіктің барлығы-`unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Мәнді ашады.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Өзгеретін көрсеткішті оралған мәнге жеткізеді.
    ///
    /// Мұны кез-келген нұсқағышқа жіберуге болады.
    /// `&mut T` трансляциясы кезінде қол жетімділіктің бірегей екендігіне көз жеткізіңіз (белсенді сілтемелер жоқ, өзгертілуі мүмкін немесе жоқ) және `&T`-ге тасталғанда мутациялар мен өзгермелі бүркеншік аттар болмайтындығына көз жеткізіңіз
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // #[repr(transparent)] болғандықтан, біз `UnsafeCell<T>`-тен `T`-ге көрсеткішті жібере аламыз.
        // Бұл libstd-дің ерекше мәртебесін пайдаланады, пайдаланушының кодына компилятордың future нұсқаларында жұмыс істейтініне кепілдік жоқ!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Негізгі деректерге өзгертілетін сілтемені қайтарады.
    ///
    /// Бұл қоңырау `UnsafeCell`-ті қарызға алады (компиляция кезінде), бұл біздің жалғыз анықтамаға ие екендігімізге кепілдік береді.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Өзгеретін көрсеткішті оралған мәнге жеткізеді.
    /// [`get`]-тен айырмашылығы-бұл функция уақытша сілтемелерді жасамау үшін пайдалы шикі көрсеткішті қабылдайды.
    ///
    /// Нәтижені кез-келген нұсқағышқа беруге болады.
    /// `&mut T` трансляциясы кезінде қол жетімділіктің бірегей екендігіне көз жеткізіңіз (белсенді сілтемелер жоқ, өзгертілуі мүмкін немесе жоқ) және `&T`-ге тасталғанда мутациялар мен өзгермелі бүркеншік аттар болмайтындығына көз жеткізіңіз.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// `UnsafeCell`-ті біртіндеп инициализациялау үшін `raw_get` қажет, өйткені `get`-ке қоңырау шалу үшін инициализацияланбаған мәліметтерге сілтеме жасау қажет болады:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // #[repr(transparent)] болғандықтан, біз `UnsafeCell<T>`-тен `T`-ге көрсеткішті жібере аламыз.
        // Бұл libstd-дің ерекше мәртебесін пайдаланады, пайдаланушының кодына компилятордың future нұсқаларында жұмыс істейтініне кепілдік жоқ!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// T үшін `Default` мәнімен бірге `UnsafeCell` жасайды.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}