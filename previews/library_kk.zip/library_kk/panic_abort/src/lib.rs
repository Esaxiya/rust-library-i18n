//! Rust panics процестерін тоқтату арқылы енгізу
//!
//! Іске асырумен салыстырғанда, бұл crate * әлдеқайда қарапайым!Айтуынша, бұл әмбебап емес, бірақ міне!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" жүк көтергіштігі және қарастырылып отырған платформадағы тиісті аборт.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // std::sys::abort_internal қоңырау шалыңыз
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Windows жүйесінде процессорға арналған __fastfail механизмін қолданыңыз.Windows 8 және одан кейінгі нұсқаларда бұл процестің кез-келген ерекшелік өңдеушілерін іске қоспай дереу тоқтатады.
            // Windows-тің алдыңғы нұсқаларында бұл нұсқаулар тізбегі қол жетімділікті бұзу ретінде қарастырылады, процесті тоқтатады, бірақ барлық ерекшеліктерді өңдеушілерді айналып өтпестен.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: бұл libstd-дің `abort_internal`-тегідей жүзеге асыру
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Бұл ... біртүрлі.Tl; dr;бұл дұрыс байланыстыру үшін қажет, төменде неғұрлым ұзақ түсініктеме берілген.
//
// Дәл қазір біз жеткізетін libcore/libstd екілік файлдарының барлығы `-C panic=unwind` көмегімен құрастырылған.Бұл екілік файлдардың мүмкіндігінше көп жағдайлармен үйлесімді болуын қамтамасыз ету үшін жасалады.
// Алайда, компилятор `-C panic=unwind` көмегімен құрастырылған барлық функциялар үшін "personality function" талап етеді.Бұл жеке функция `rust_eh_personality` таңбасына сәйкес кодталған және `eh_personality` lang элементімен анықталады.
//
// So...
// Неліктен тек осы ланг элементін анықтамасқа?Жақсы сұрақ!panic жұмыс уақытының байланысу тәсілі-бұл компилятордың crate қоймасында "sort of" болатындығымен, бірақ басқа байланыстырылмаған жағдайда ғана.
//
// Бұл crate және panic_unwind crate екеуі де компилятордың crate қоймасында пайда болуы мүмкін дегенді білдіреді және егер екеуі де `eh_personality` lang элементін анықтаса, ол қате жібереді.
//
// Бұл үшін компилятор тек `eh_personality` анықталуы керек, егер panic жұмыс уақыты байланыстырылатын жұмыс уақыты болса, әйтпесе оны анықтау қажет емес (дұрыс).
// Бұл жағдайда бұл кітапхана тек осы белгіні анықтайды, сондықтан кем дегенде бір жерде жеке тұлға болады.
//
// Негізінен бұл таңба libcore/libstd екілік файлына сыммен қосылу үшін ғана анықталған, бірақ оны ешқашан атауға болмайды, өйткені біз жұмыс істеп тұрған уақытты байланыстырмаймыз.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // X86_64-pc-windows-gnu-де біз өз кадрларымызды беру кезінде `ExceptionContinueSearch`-ті қайтару қажет жеке функциямызды қолданамыз.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Жоғарыда айтылғандай, бұл қазіргі уақытта Emscripten-де қолданылатын `eh_catch_typeinfo` lang элементіне сәйкес келеді.
    //
    // panics ерекше жағдайларды жасамайтындықтан және шетелдік ерекшеліктер қазіргі уақытта UB-мен бірге -C panic=тоқтатылғандықтан (өзгертілуі мүмкін), кез келген catch_unwind қоңыраулары бұл типті ешқашан пайдаланбайды.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Бұл екеуін i686-pc-windows-gnu-тегі стартап объектілері деп атайды, бірақ олар ешнәрсе жасаудың қажеті жоқ, сондықтан денелер ноуп болады.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}