//! Жаңа макростарды анықтау кезінде макро авторларға арналған қолдау кітапханасы.
//!
//! Стандартты таратумен қамтамасыз етілген бұл кітапхана процедуралық тұрғыдан анықталған макро анықтамалардың интерфейстерінде тұтынылатын типтерді ұсынады, мысалы, функцияларға ұқсас `#[proc_macro]` макростар, `#[proc_macro_attribute]` макро атрибуттар және қолданушы туынды атрибуттар `#[proc_macro_derive]`.
//!
//!
//! Толығырақ [the book] қараңыз.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Proc_macro ағымдағы жұмыс істеп тұрған бағдарламаға қол жетімді болғандығын анықтайды.
///
/// Proc_macro crate тек процедуралық макростарды қолдануға арналған.Осы crate panic-дегі барлық функциялар, егер процедуралық макростың сыртынан шақырылса, мысалы, құрастыру сценарийінен немесе блок тестінен немесе қарапайым Rust бинарынан.
///
/// Макросты және макросты емес жағдайларды қолдауға арналған Rust кітапханаларын ескере отырып, `proc_macro::is_available()` proc_macro API-сін қолдану үшін қажетті инфрақұрылымның қазіргі уақытта қол жетімді екендігін анықтайтын паникаға жол бермейді.
/// Егер процедуралық макростың ішінен шақырылса, «екіншісінен» жалған болса, «қайтарады».
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// tokens дерексіз ағыны немесе дәлірек айтқанда token ағаштарының дәйектілігін көрсететін осы crate ұсынған негізгі тип.
/// Бұл тип сол token ағаштары бойынша қайталануға және керісінше, бірқатар token ағаштарын бір ағынға жинауға арналған интерфейстерді ұсынады.
///
///
/// Бұл `#[proc_macro]`, `#[proc_macro_attribute]` және `#[proc_macro_derive]` анықтамаларының кірісі де, шығысы да.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// `TokenStream::from_str`-тен қате қайтарылды.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// token ағаштары жоқ бос `TokenStream` қайтарады.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Осы `TokenStream` бос екенін тексереді.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Жіпті tokens-ге үзуге және сол tokens-ді token ағынына талдауға тырысу.
/// Бірқатар себептерге байланысты сәтсіздікке ұшырауы мүмкін, мысалы, егер жолда теңгерілмеген бөлгіштер немесе тілде жоқ таңбалар болса.
///
/// Бөлшектелген ағындағы барлық tokens `Span::call_site()` аралықты алады.
///
/// NOTE: кейбір қателер `LexError` қайтарудың орнына panics тудыруы мүмкін.Біз бұл қателерді кейінірек «LexError»-ке өзгерту құқығымызды сақтаймыз.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, көпір тек `to_string` ұсынады, оған негізделген `fmt::Display` іске қосады (екеуінің арасындағы әдеттегі қатынастың керісінше).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// token ағыны `Delimiter::None` бөлгіштері мен теріс сандық әріптік белгілері бар «TokenTree: : Group`» қоспағанда, шығынсыз конверттелетін жол ретінде сол token ағынына (модуль аралықтары) жол ретінде шығарады.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// token-ді түзетуге ыңғайлы түрде басып шығарады.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Бір token ағашын қамтитын token ағыны жасайды.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Бірқатар ағынға бірқатар token ағаштарын жинайды.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// token ағындарындағы "flattening" жұмысы бірнеше token ағындарынан бір ағынға token ағаштарын жинайды.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Мүмкін болатын if/when оңтайландырылған енгізілімін қолданыңыз.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Итераторлар сияқты `TokenStream` типіне арналған жалпыға қол жетімді мәліметтер.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// «TokenStream»-тің «TokenTree»-теріндегі итератор.
    /// Итерация-"shallow", мысалы, итератор бөлінген топтарға қайта оралмайды және тұтас топтарды token ағаштары ретінде қайтарады.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` ерікті tokens қабылдайды және кірісті сипаттайтын `TokenStream`-ке дейін кеңейеді.
/// Мысалы, `quote!(a + b)` өрнек шығарады, ол бағалау кезінде `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Белгіленбеу `$` көмегімен жүзеге асырылады және тек келесі идентификаторды белгіленбеген термин ретінде қабылдау арқылы жұмыс істейді.
/// `$`-ге дәйексөз келтіру үшін `$$` пайдаланыңыз.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Макро кеңейту туралы ақпаратпен бірге бастапқы код аймағы.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Берілген `message` бар `self` аралығында жаңа `Diagnostic` жасайды.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Макро анықтама сайтында шешілетін аралық.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Ағымдағы процедуралық макросты қолдану уақыты.
    /// Осы аралықта жасалған сәйкестендіргіштер макроқоңырау шалатын жерде тікелей жазылғандай шешіледі (шақыру алаңының гигиенасы) және макро қоңырау сайтындағы басқа код оларға да сілтеме жасай алады.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Аралық `macro_rules` гигиенасын білдіреді, кейде макро анықтамалар сайтында (жергілікті айнымалылар, белгілер, `$crate`), кейде макробайланыс сайтында (қалғаны) шешіледі.
    ///
    /// Аралықтың орналасуы қоңырау шалу сайтынан алынды.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Осы сілтеме жасалатын бастапқы файл.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// Алдыңғы макро кеңеюдегі tokens үшін `Span`, егер ол бар болса, `self` жасалған.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// `self` жасалған бастапқы кодтың аралығы.
    /// Егер бұл `Span` басқа макро кеңейтулерден жасалмаса, онда қайтарылатын мән `*self` мәнімен бірдей.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Осы уақытқа арналған бастапқы файлда бастапқы line/column алады.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Осы аралыққа арналған бастапқы файлда line/column аяқталуын алады.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// `self` және `other` қамтитын жаңа аралық жасайды.
    ///
    /// `None` қайтарады, егер `self` және `other` әр түрлі файлдар болса.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// line/column ақпаратымен бірдей `self` жаңа аралықты жасайды, бірақ ол таңбаларды `other` деңгейінде шешеді.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// `self` сияқты атау ажыратымдылығымен, бірақ `other` ақпаратымен line/column жаңа аралық жасайды.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Аралықтармен салыстырып, олардың тең екендігіне көз жеткізіңіз.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Бір аралықта бастапқы мәтінді қайтарады.
    /// Бұл бос орындар мен түсініктемелерді қоса, бастапқы кодты сақтайды.
    /// Егер нәтиже нақты бастапқы кодқа сәйкес келсе ғана нәтиже береді.
    ///
    /// Note: Макростың бақыланатын нәтижесі тек бастапқы мәтінге емес, тек tokens-ге сенуі керек.
    ///
    /// Бұл функцияның нәтижесі тек диагностика үшін қолданылған жақсы күш болып табылады.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Аралықты түзетуге ыңғайлы түрде басып шығарады.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// `Span` басы немесе соңын білдіретін жолдар бағанының жұбы.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Аралық (inclusive) басталатын немесе аяқталатын бастапқы файлдағы 1 индекстелген жол.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Аралық (inclusive) басталатын немесе аяқталатын бастапқы файлдағы 0 индекстелген баған (UTF-8 таңбаларында).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Берілген `Span` бастапқы файлы.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Осы бастапқы файлға жол алады.
    ///
    /// ### Note
    /// Егер осы `SourceFile`-пен байланысты код аралығы сыртқы макросты, бұл макросты құрса, бұл файлдық жүйеде нақты жол болмауы мүмкін.
    /// Тексеру үшін [`is_real`] пайдаланыңыз.
    ///
    /// Сонымен қатар, егер `is_real` `true`-ті қайтарса да, егер `--remap-path-prefix` пәрмен жолында берілген болса, берілген жол шынымен дұрыс болмауы мүмкін.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Егер бұл бастапқы файл сыртқы макростың кеңеюімен жасалмаса және нақты бастапқы файл болса, `true` қайтарады.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Бұл интерактивті аралықтар іске асырылғанға дейін және бізде сыртқы макростарда жасалынған нақты файлдар болуы мүмкін.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Бір token немесе token ағаштарының бөлінген тізбегі (мысалы, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Жақша бөлгіштермен қоршалған token ағыны.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Идентификатор.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Бір тыныс белгісі (`+`, `,`, `$` және т.б.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Сөзбе-сөз таңба (`'a'`), жол (`"hello"`), (`2.3`) саны және т.б.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Құрылған token немесе бөлінген ағынның `span` әдісіне өкілеттік бере отырып, осы ағаштың аралығын қайтарады.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// *Тек осы token* үшін аралықты теңшейді.
    ///
    /// Егер бұл token `Group` болса, онда бұл әдіс ішкі tokens әрқайсысының ұзақтығын теңшемейтінін ескеріңіз, бұл жай әр варианттың `set_span` әдісіне өкілеттік береді.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// token ағашын жөндеуге ыңғайлы түрде басып шығарады.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Бұлардың әрқайсысы алынған типтегі түзетулерде құрылым түріндегі атауға ие, сондықтан қосымша жанама қабатпен алаңдамаңыз
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, көпір тек `to_string` ұсынады, оған негізделген `fmt::Display` іске қосады (екеуінің арасындағы әдеттегі қатынастың керісінше).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// token ағашын шығынсыз конверттелетін жол ретінде `Delimiter::None` бөлгіштерімен және теріс сандық әріптермен «TokenTree: : Group`» қоспағанда, сол token ағашына (модуль аралығы) қайтарады.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Бөлінген token ағыны.
///
/// `Group` ішіне `TokenStream` кіреді, оны «бөлгіштер» қоршап тұр.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// token ағаштарының бірізділігі қалай бөлінгенін сипаттайды.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Мысалы, "macro variable" `$var`-тен шығатын tokens айналасында пайда болатын айқын емес бөлгіш.
    /// `$var * 3` сияқты жағдайларда оператордың басымдықтарын сақтау маңызды, егер `$var`-`1 + 2` болса.
    /// Айқын емес бөлгіштер token ағынының жол бойымен айналуы кезінде жол бойынан аман қалмауы мүмкін.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Берілген бөлгіш пен token ағынымен жаңа `Group` жасайды.
    ///
    /// Бұл конструктор осы топтың аралығын `Span::call_site()` деңгейіне қояды.
    /// Аралықты өзгерту үшін төмендегі `set_span` әдісін қолдануға болады.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Осы `Group` бөлгішін қайтарады
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Осы `Group` ішінде бөлінген tokens-тің `TokenStream` мәнін қайтарады.
    ///
    /// Қайтарылған token ағыны жоғарыда қайтарылған бөлгішті қамтымайтынын ескеріңіз.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Осы token ағынының бөлгіштері үшін бүкіл `Group` ауқымын қайтарады.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Осы топтың ашылу бөлгішін көрсетіп, аралықты қайтарады.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Осы топтың соңғы бөлгішін көрсетіп, аралықты қайтарады.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Ішкі tokens емес, осы «топтың» бөлгіштерінің аралығын теңшейді.
    ///
    /// Бұл әдіс осы топтың барлық ішкі tokens аралықты **орнатпайды**, керісінше `Group` деңгейінде tokens бөлгішін ғана орнатады.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, көпір тек `to_string` ұсынады, оған негізделген `fmt::Display` іске қосады (екеуінің арасындағы әдеттегі қатынастың керісінше).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Топты `Delimiter::None` бөлгіштері бар «TokenTree: : Group`» қоспағанда, шығынсыз конверттелетін жолға айналдырады (модуль аралығы).
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct`-бұл `+`, `-` немесе `#` сияқты бір тыныс белгілері.
///
/// `+=` сияқты көп таңбалы операторлар `Punct` екі формасы ретінде ұсынылған, олар `Spacing` формаларын қайтарған.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// `Punct`-тен кейін бірден басқа `Punct` немесе оның артынан басқа token немесе бос кеңістік келеді ме.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// мысалы, `+`-`+ =`, `+ident` немесе `+()` кезіндегі `Alone`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// мысалы, `+`-`+=` немесе `'#` кезіндегі `Joint`.
    /// Сонымен қатар, `'` бір дәйексөз идентификаторлармен қосылып, `'ident` өмір сүру уақытын құра алады.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Берілген таңбадан және интервалдан жаңа `Punct` жасайды.
    /// `ch` аргументі тілмен рұқсат етілген тыныс белгілері болуы керек, әйтпесе функция panic болады.
    ///
    /// Қайтарылған `Punct` стандартты `Span::call_site()` ұзақтығына ие болады, оны төмендегі `set_span` әдісімен конфигурациялауға болады.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Осы тыныс белгінің мәнін `char` ретінде қайтарады.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Осы тыныс белгісінің интервалын қайтарады, оның token ағынында бірден басқа `Punct` болатынын, сондықтан оларды (`Joint`) көп таңбалы операторға біріктіруге болатындығын немесе оны басқа token немесе бос кеңістіктегі (`Alone`) операторы қосатындығын көрсетеді. аяқталды.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Осы тыныс белгінің аралығын қайтарады.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Осы тыныс белгінің аралығын теңшеңіз.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, көпір тек `to_string` ұсынады, оған негізделген `fmt::Display` іске қосады (екеуінің арасындағы әдеттегі қатынастың керісінше).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Тыныс белгілерін қайтадан сол таңбаға қайта оралатын жол ретінде басады.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// (`ident`) идентификаторы.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Берілген `string` және көрсетілген `span` бар жаңа `Ident` жасайды.
    /// `string` аргументі тілмен рұқсат етілген жарамды идентификатор болуы керек (мысалы, `self` немесе `fn` кілт сөздерін қоса).Әйтпесе, функция panic болады.
    ///
    /// Қазіргі уақытта rustc-те орналасқан `span` осы сәйкестендіргіштің гигиеналық ақпаратын конфигурациялайтынын ескеріңіз.
    ///
    /// Осы уақытқа дейін `Span::call_site()` айқын түрде "call-site" гигиенасын қолданады, яғни осы аралықта жасалған идентификаторлар тікелей макро қоңырау өтетін жерде жазылғандай шешіледі, ал макро қоңырау сайтындағы басқа код сілтеме жасай алады. оларды да.
    ///
    ///
    /// Кейінірек `Span::def_site()` сияқты аралықтар "definition-site" гигиенасына қосылуға мүмкіндік береді, яғни осы аралықта жасалған идентификаторлар макро анықтаманың орналасқан жерінде шешіледі және макро қоңырау сайтындағы басқа код оларға сілтеме жасай алмайды.
    ///
    /// Гигиенаның маңыздылығына байланысты бұл конструктор, басқа tokens-тен айырмашылығы, құрылыста `Span` көрсетілуін талап етеді.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// `Ident::new` сияқты, бірақ (`r#ident`) шикі идентификаторын жасайды.
    /// `string` аргументі тілмен рұқсат етілген жарамды идентификатор болуы мүмкін (кілт сөздерді қосқанда, мысалы, `fn`).
    /// Жол сегменттерінде қолдануға болатын кілт сөздер (мысалы.)
    /// `self`, `super`) қолдау көрсетілмейді және panic тудырады.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// [`to_string`](Self::to_string) қайтарған барлық жолды қамтитын осы `Ident` аралығын қайтарады.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Осы `Ident` ұзақтығын конфигурациялайды, мүмкін оның гигиеналық жағдайын өзгертеді.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, көпір тек `to_string` ұсынады, оған негізделген `fmt::Display` іске қосады (екеуінің арасындағы әдеттегі қатынастың керісінше).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Идентификаторды қайтадан сол идентификаторға шығынсыз айырбасталатын жол ретінде басып шығарады.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// (`"hello"`) әріптік жолы, (`b"hello"`) байт жолы, (`'a'`) символы, (`b'a'`) байт символы, бүтін немесе өзгермелі нүктенің нөмірі (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// `true` және `false` сияқты логикалық әріптер мұнда жатпайды, олар «Ident`s».
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Көрсетілген мәнмен әріптік жаңа суффиксті жасайды.
        ///
        /// Бұл функция `1u32` сияқты бүтін сан жасайды, мұнда көрсетілген бүтін мән token бірінші бөлігі болып табылады, ал интеграл соңында да жалғанады.
        /// Теріс сандардан жасалған әріптер `TokenStream` немесе жолдар арқылы айналу кезінде аман қалмауы мүмкін және екі tokens (`-` және позитивті әріптік) болып бөлінуі мүмкін.
        ///
        ///
        /// Осы әдіс арқылы жасалған әріптік белгілерде `Span::call_site()` аралығы бар, оны төмендегі `set_span` әдісімен конфигурациялауға болады.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Көрсетілген мәнмен жаңа бекітілмеген бүтін санды жасайды.
        ///
        /// Бұл функция `1` сияқты бүтін сан жасайды, онда көрсетілген бүтін мән token бірінші бөлігі болып табылады.
        /// Бұл token-да ешқандай суффикс көрсетілмеген, яғни `Literal::i8_unsuffixed(1)` сияқты шақырулар `Literal::u32_unsuffixed(1)`-ге тең.
        /// Теріс сандардан жасалған литералдар `TokenStream` немесе жолдар арқылы ауысу кезінде аман қалмауы мүмкін және екі tokens (`-` және позитивті әріптік) болып бөлінуі мүмкін.
        ///
        ///
        /// Осы әдіс арқылы жасалған әріптік белгілерде `Span::call_site()` аралығы бар, оны төмендегі `set_span` әдісімен конфигурациялауға болады.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Жаңа бекітілмеген өзгермелі нүктелі сөзбе-сөз жасайды.
    ///
    /// Бұл конструктор `Literal::i8_unsuffixed` сияқты, флоат мәні тікелей token-ге шығарылады, бірақ ешқандай суффикс қолданылмайды, сондықтан оны компиляторда кейінірек `f64` деп айтуға болады.
    ///
    /// Теріс сандардан жасалған литералдар `TokenStream` немесе жолдар арқылы ауысу кезінде аман қалмауы мүмкін және екі tokens (`-` және позитивті әріптік) болып бөлінуі мүмкін.
    ///
    /// # Panics
    ///
    /// Бұл функция көрсетілген флоттың ақырлы болуын талап етеді, мысалы, егер ол шексіздікке немесе NaN болса, бұл функция panic болады.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Жаңа суффиксті өзгермелі нүктелі сөзбе-сөз жасайды.
    ///
    /// Бұл конструктор `1.0f32` сияқты сөзбе-сөз жасайды, мұнда көрсетілген мән token алдыңғы бөлігі, ал `f32` token жұрнағы болады.
    /// Бұл token әрқашан компиляторда `f32` болуы мүмкін.
    /// Теріс сандардан жасалған литералдар `TokenStream` немесе жолдар арқылы ауысу кезінде аман қалмауы мүмкін және екі tokens (`-` және позитивті әріптік) болып бөлінуі мүмкін.
    ///
    ///
    /// # Panics
    ///
    /// Бұл функция көрсетілген флоттың ақырлы болуын талап етеді, мысалы, егер ол шексіздікке немесе NaN болса, бұл функция panic болады.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Жаңа бекітілмеген өзгермелі нүктелі сөзбе-сөз жасайды.
    ///
    /// Бұл конструктор `Literal::i8_unsuffixed` сияқты, флоат мәні тікелей token-ге шығарылады, бірақ ешқандай суффикс қолданылмайды, сондықтан оны компиляторда кейінірек `f64` деп айтуға болады.
    ///
    /// Теріс сандардан жасалған литералдар `TokenStream` немесе жолдар арқылы ауысу кезінде аман қалмауы мүмкін және екі tokens (`-` және позитивті әріптік) болып бөлінуі мүмкін.
    ///
    /// # Panics
    ///
    /// Бұл функция көрсетілген флоттың ақырлы болуын талап етеді, мысалы, егер ол шексіздікке немесе NaN болса, бұл функция panic болады.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Жаңа суффиксті өзгермелі нүктелі сөзбе-сөз жасайды.
    ///
    /// Бұл конструктор `1.0f64` сияқты сөзбе-сөз жасайды, мұнда көрсетілген мән token алдыңғы бөлігі, ал `f64` token жұрнағы болады.
    /// Бұл token компиляторда әрқашан `f64` болуы мүмкін.
    /// Теріс сандардан жасалған литералдар `TokenStream` немесе жолдар арқылы ауысу кезінде аман қалмауы мүмкін және екі tokens (`-` және позитивті әріптік) болып бөлінуі мүмкін.
    ///
    ///
    /// # Panics
    ///
    /// Бұл функция көрсетілген флоттың ақырлы болуын талап етеді, мысалы, егер ол шексіздікке немесе NaN болса, бұл функция panic болады.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// String сөзбе-сөз.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Таңба сөзбе-сөз.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Байт сөзбе-сөз.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Осы сөзбе-сөз жазылған аралықты қайтарады.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Осы сөзбе-сөз байланысты аралықты конфигурациялайды.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// `range` ауқымындағы тек бастапқы байттарды қамтитын `self.span()` жиынтығы болып табылатын `Span` мәнін қайтарады.
    /// Болашақ кесілген уақыт `self` шегінен тыс болса, `None` қайтарады.
    ///
    // FIXME(SergioBenitez): байт диапазонының көздің UTF-8 шекарасынан басталып аяқталуын тексеріңіз.
    // әйтпесе, бастапқы мәтін басылған кезде panic басқа жерде пайда болуы мүмкін.
    // FIXME(SergioBenitez): пайдаланушыға `self.span()` шынымен нені бейнелейтінін білуге мүмкіндік жоқ, сондықтан бұл әдісті қазіргі кезде тек соқыр деп атауға болады.
    // Мысалы, 'c' таңбасы үшін `to_string()` "'\u{63}'" қайтарады;пайдаланушыға бастапқы мәтіннің 'c' екенін немесе оның '\u{63}' екенін білу мүмкіндігі жоқ.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) `Option::cloned`-ге ұқсас, бірақ `Bound<&T>` үшін.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, көпір тек `to_string` ұсынады, оған негізделген `fmt::Display` іске қосады (екеуінің арасындағы әдеттегі қатынастың керісінше).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Сөзбе-сөз жоғалтпай конверттелетін жолға айналдырады (өзгермелі нүктелік литералдар үшін дөңгелектеуді қоспағанда).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Қоршаған ортаның айнымалыларына бақылау.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Қоршаған ортаның айнымалы мәнін алыңыз және оны тәуелділік туралы ақпарат құру үшін қосыңыз.
    /// Компиляторды орындайтын құрылыс жүйесі айнымалыға компиляция кезінде қол жеткізілгенін біледі және осы айнымалының мәні өзгерген кезде құрастыруды қайта орындай алады.
    ///
    /// Сонымен қатар, тәуелділікті қадағалау үшін бұл функция стандартты кітапхананың `env::var`-ге тең болуы керек, тек дәлел UTF-8 болуы керек.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}