# `rustc-std-workspace-core` crate

See crate on fikseeritud ja tühi crate, mis sõltub lihtsalt `libcore`-st ja eksportib kogu selle sisu uuesti.
crate on standardraamatukogu võimestamise sõltuvus crates.io-st sõltuvast crates-st

Crates crates.io-il, et standardraamatukogu sõltub vajadusest sõltuda crates.io-i `rustc-std-workspace-core` crate-ist, mis on tühi.

Kasutame `[patch]`-i, et see selles hoidlas selle crate-ga alistada.
Selle tulemusena tõmbab crates crates.io-is sõltuvuse edge kuni `libcore`, selles hoidlas määratletud versiooni.
See peaks tõmbama kõik sõltuvuse servad tagamaks, et Cargo ehitab crates edukalt!

Pange tähele, et crates.io-i crates peab kõigist õigesti töötama sõltuma sellest crate-ist nimega `core`.Selleks saavad nad kasutada järgmist.

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Kasutades klahvi `package`, nimetatakse crate ümber `core`-ks, see tähendab, et see näeb välja

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

kui Cargo kutsub kompilaatorit, vastab kompilaatori sisestatud implitsiitsele `extern crate core`-direktiivile.




