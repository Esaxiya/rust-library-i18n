#![feature(no_core)]
#![no_core]

// Miks seda crate-i vaja on, leiate artiklist rustc-std-workspace-core.

// Nimetage crate ümber, et vältida liballocis vastuolu eraldusmooduliga.
extern crate alloc as foo;

pub use foo::*;