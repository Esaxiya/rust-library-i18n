// rsbegin.o ja rsend.o on nn "compiler runtime startup objects".
// Need sisaldavad koodi, mis on vajalik kompilaatori käituse õigeks initsialiseerimiseks.
//
// Kui käivitatav või dylib-pilt on lingitud, on nende kahe objektifaili vahel kõik kasutajakood ja teegid "sandwiched", nii et rsbegin.o-i kood või andmed saavad pildi vastavas jaotises esimeseks, samas kui kood ja andmed rsend.o-st saavad viimasteks.
// Seda efekti saab kasutada nii sümbolite paigutamiseks lõigu algusesse või lõppu kui ka vajalike päiste või jaluste sisestamiseks.
//
// Pange tähele, et mooduli tegelik sisestuspunkt asub käitusaja C käivitusobjektis (tavaliselt nimetatakse seda `crtX.o`-ks), mis seejärel kutsub esile teiste käituse komponentide initsialiseerimise tagasihelistamised (registreeritud veel ühe spetsiaalse pildiosa kaudu).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Märgib korstna raami lahti kerimise infosektsiooni algust
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Kraapimisruum lahtirullija sisemiseks raamatupidamiseks.
    // See on määratletud kui `struct object` failis $ GCC/unfind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Lõdvendage info registration/deregistration rutiinid.
    // Vaadake libpanic_unwindi dokumente.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // registreerige lahtiühendamise teave mooduli käivitamisel
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // tühistamise ajal registreerimine tühistatakse
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-spetsiifiline init/uninit rutiinne registreerimine
    pub mod mingw_init {
        // MinGW käivitusobjektid (crt0.o/dllcrt0.o) kutsuvad käivitamisel ja väljumisel globaalsed konstruktorid jaotistes .ctors ja .dtors.
        // DLL-ide korral tehakse seda DLL-i laadimisel ja tühjendamisel.
        //
        // Linker sorteerib jaotised, mis tagab, et meie tagasihelistamised asuvad loendi lõpus.
        // Kuna konstruktoreid käitatakse vastupidises järjekorras, tagab see, et meie tagasihelistamised on esimesed ja viimased.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C initsialiseerimise tagasihelistamised
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C lõpetamise tagasihelistamised
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}