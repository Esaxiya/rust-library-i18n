use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri on liiga aeglane
fn exact_sanity_test() {
    // See test töötab lõpuks, mida võin ainult oletada, et `exp2` teegi funktsiooni nurgakujuline juhtum on määratletud mis tahes C käituse ajal, mida me kasutame.
    // VS 2013-s oli sellel funktsioonil ilmselt viga, kuna see test ebaõnnestus lingimisel, kuid VS 2015-ga näib viga parandatud, kuna test töötab suurepäraselt.
    //
    // Viga näib olevat erinevus `exp2(-1057)`-i tagastusväärtuses, kus VS 2013-s tagastab bittmustriga 0x2 topelt ja VS 2015-s 0x20000.
    //
    //
    // Praegu lihtsalt ignoreerige seda testi MSVC-l, kuna seda testitakse nagunii mujal ja me pole eriti huvitatud iga platvormi exp2-i rakenduse testimisest.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}