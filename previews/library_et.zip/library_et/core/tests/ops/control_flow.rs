use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // See ei ole stabiilne pind, kuid aitab `?`-i nende vahel odavalt hoida, isegi kui LLVM ei saa seda alati praegu ära kasutada.
    //
    // (Kahjuks pole tulemus ja valik vastuolulised, nii et ControlFlow ei saa mõlemaga sobida.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}