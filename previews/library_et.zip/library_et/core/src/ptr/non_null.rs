use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` kuid nullist erinev ja muutuv.
///
/// See on sageli õige, mida toorviidete abil andmestruktuuride ülesehitamisel kasutada, kuid lõppkokkuvõttes on seda täiendavate omaduste tõttu ohtlikum kasutada.Kui te pole kindel, kas peaksite kasutama `NonNull<T>`-i, kasutage lihtsalt `*mut T`-i!
///
/// Erinevalt `*mut T`-st peab kursor olema alati nullist erinev, isegi kui osuti ei tehta kunagi allahindlust.Seda selleks, et enums saaks seda keelatud väärtust kasutada diskrimineerijana-`Option<NonNull<T>>` on sama suur kui `* mut T`.
/// Kursor võib siiski rippuda, kui sellele ei viidata.
///
/// Erinevalt `*mut T`-ist valiti `NonNull<T>` ühilduvaks `T`-i suhtes.See võimaldab kasutada varianti `NonNull<T>` kovariatsioonitüüpide ehitamisel, kuid toob kaasa ebamugavuse ohu, kui seda kasutatakse tüübis, mis tegelikult ei tohiks olla muutuv.
/// (`*mut T`-i puhul tehti vastupidine valik, kuigi tehniliselt võis ebamugavust põhjustada ainult ebaturvaliste funktsioonide kutsumine.)
///
/// Kovariantsus on õige enamiku ohutute abstraktsioonide puhul, näiteks `Box`, `Rc`, `Arc`, `Vec` ja `LinkedList`.See on nii, kuna nad pakuvad avalikku API-d, mis järgib Rust tavalisi jagatud XOR-i muutuvaid reegleid.
///
/// Kui teie tüüp ei saa ohutult muutuda, peate muutumatuse tagamiseks veenduma, et see sisaldab mõnda täiendavat välja.Sageli on see väli [`PhantomData`] tüüpi nagu `PhantomData<Cell<T>>` või `PhantomData<&'a mut T>`.
///
/// Pange tähele, et `NonNull<T>`-l on `&T`-i jaoks `From`-i eksemplar.Kuid see ei muuda tõsiasja, et jagatud viite kaudu (osutatakse a-st saadud osuti) kaudu muteerimine on määratlemata käitumine, välja arvatud juhul, kui mutatsioon toimub [`UnsafeCell<T>`]-i sees.Sama kehtib ka muudetava viite loomise kohta jagatud viite põhjal.
///
/// Selle `From`-i eksemplari kasutamisel ilma `UnsafeCell<T>`-ina on teie kohustus tagada, et `as_mut`-i ei kutsuta kunagi ja `as_ptr`-i ei kasutata kunagi mutatsiooniks.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` osutid pole `Send`, kuna nende viidatud andmed võivad olla varjunimed.
// NB, see pole vajalik, kuid peaks pakkuma paremaid veateateid.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` osutid pole `Sync`, kuna nende viidatud andmed võivad olla varjunimed.
// NB, see pole vajalik, kuid peaks pakkuma paremaid veateateid.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Loob uue rippuva, kuid hästi joondatud `NonNull`.
    ///
    /// See on kasulik laisalt eraldatavate tüüpide initsialiseerimiseks, nagu seda teeb `Vec::new`.
    ///
    /// Pange tähele, et kursori väärtus võib potentsiaalselt tähistada kehtivat osutit `T`-le, mis tähendab, et seda ei tohi kasutada "not yet initialized"-i valvuriväärtusena.
    /// Laiskalt eraldavad tüübid peavad lähtestamist jälgima mõnel muul viisil.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // OHUTUS: mem::align_of() tagastab nullist erineva kasutuse, mis seejärel valatakse
        // kuni * mut T.
        // Seetõttu pole `ptr` null ja new_unchecked()-i helistamise tingimused on täidetud.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Tagastab jagatud viited väärtusele.Erinevalt [`as_ref`]-st ei nõua see väärtuse initsialiseerimist.
    ///
    /// Muutuva vaste kohta vt [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Sellele meetodile helistades peate veenduma, et kõik järgnevad vastavad tõele:
    ///
    /// * Kursor peab olema korralikult joondatud.
    ///
    /// * See peab olema "dereferencable" määratletud tähenduses [the module documentation].
    ///
    /// * Peate jõustama Rust varjunimede reeglid, kuna tagastatav eluiga `'a` on valitud meelevaldselt ega kajasta tingimata andmete tegelikku eluiga.
    ///
    ///   Eelkõige ei tohi selle eluea jooksul mälu, millele osuti osutab, muteeruda (välja arvatud `UnsafeCell` sees).
    ///
    /// See kehtib isegi siis, kui selle meetodi tulemus on kasutamata!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // OHUTUS: helistaja peab tagama, et `self` vastab kõigile nõuetele
        // nõuded viitele.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Tagastab väärtusele ainulaadsed viited.Erinevalt [`as_mut`]-st ei nõua see väärtuse initsialiseerimist.
    ///
    /// Jagatud kolleegi kohta vt [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Sellele meetodile helistades peate veenduma, et kõik järgnevad vastavad tõele:
    ///
    /// * Kursor peab olema korralikult joondatud.
    ///
    /// * See peab olema "dereferencable" määratletud tähenduses [the module documentation].
    ///
    /// * Peate jõustama Rust varjunimede reeglid, kuna tagastatav eluiga `'a` on valitud meelevaldselt ega kajasta tingimata andmete tegelikku eluiga.
    ///
    ///   Eelkõige ei tohi selle eluea jooksul mälu, millele osuti osutab, juurde pääseda (lugeda või kirjutada) ühegi teise osuti kaudu.
    ///
    /// See kehtib isegi siis, kui selle meetodi tulemus on kasutamata!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // OHUTUS: helistaja peab tagama, et `self` vastab kõigile nõuetele
        // nõuded viitele.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Loob uue `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` peab olema null-null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // OHUTUS: helistaja peab tagama, et `ptr` pole null.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Loob uue `NonNull`-i, kui `ptr` pole null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // OHUTUS: Kursor on juba kontrollitud ja pole null
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Teostab sama funktsionaalsust nagu [`std::ptr::from_raw_parts`], välja arvatud see, et tagastatakse `NonNull`-osuti, vastupidiselt toorele `*const`-osutile.
    ///
    ///
    /// Lisateavet leiate [`std::ptr::from_raw_parts`] dokumentatsioonist.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // OHUTUS: `ptr::from::raw_parts_mut` tulemus pole null, kuna `data_address` on.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Lagundada (võimalik, et lai) osuti aadressi ja metaandmete komponentideks.
    ///
    /// Osuti saab hiljem [`NonNull::from_raw_parts`]-iga taastada.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Omandab aluseks oleva `*mut`-osuti.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Tagastab väärtusele jagatud viite.Kui väärtus võib olla initsialiseerimata, tuleb selle asemel kasutada [`as_uninit_ref`]-i.
    ///
    /// Muutuva vaste kohta vt [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Sellele meetodile helistades peate veenduma, et kõik järgnevad vastavad tõele:
    ///
    /// * Kursor peab olema korralikult joondatud.
    ///
    /// * See peab olema "dereferencable" määratletud tähenduses [the module documentation].
    ///
    /// * Kursor peab osutama `T` initsialiseeritud eksemplarile.
    ///
    /// * Peate jõustama Rust varjunimede reeglid, kuna tagastatav eluiga `'a` on valitud meelevaldselt ega kajasta tingimata andmete tegelikku eluiga.
    ///
    ///   Eelkõige ei tohi selle eluea jooksul mälu, millele osuti osutab, muteeruda (välja arvatud `UnsafeCell` sees).
    ///
    /// See kehtib isegi siis, kui selle meetodi tulemus on kasutamata!
    /// (Initsialiseerimise osas pole veel lõplikult otsustatud, kuid seni, kuni see on veel tehtud, on ainus ohutu lähenemisviis tagada nende initsialiseerimine.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // OHUTUS: helistaja peab tagama, et `self` vastab kõigile nõuetele
        // nõuded viitele.
        unsafe { &*self.as_ptr() }
    }

    /// Tagastab väärtusele kordumatu viite.Kui väärtus võib olla initsialiseerimata, tuleb selle asemel kasutada [`as_uninit_mut`]-i.
    ///
    /// Jagatud kolleegi kohta vt [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Sellele meetodile helistades peate veenduma, et kõik järgnevad vastavad tõele:
    ///
    /// * Kursor peab olema korralikult joondatud.
    ///
    /// * See peab olema "dereferencable" määratletud tähenduses [the module documentation].
    ///
    /// * Kursor peab osutama `T` initsialiseeritud eksemplarile.
    ///
    /// * Peate jõustama Rust varjunimede reeglid, kuna tagastatav eluiga `'a` on valitud meelevaldselt ega kajasta tingimata andmete tegelikku eluiga.
    ///
    ///   Eelkõige ei tohi selle eluea jooksul mälu, millele osuti osutab, juurde pääseda (lugeda või kirjutada) ühegi teise osuti kaudu.
    ///
    /// See kehtib isegi siis, kui selle meetodi tulemus on kasutamata!
    /// (Initsialiseerimise osas pole veel lõplikult otsustatud, kuid seni, kuni see on veel tehtud, on ainus ohutu lähenemisviis tagada nende initsialiseerimine.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // OHUTUS: helistaja peab tagama, et `self` vastab kõigile nõuetele
        // muutuva viite nõuded.
        unsafe { &mut *self.as_ptr() }
    }

    /// Heidab teist tüüpi osuti juurde.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // OHUTUS: `self` on `NonNull`-osuti, mis pole tingimata null-null
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Loob nullist toore viilu õhukest kursorit ja pikkust.
    ///
    /// `len` argument on **elementide** arv, mitte baitide arv.
    ///
    /// See funktsioon on ohutu, kuid tagastusväärtuse mahaarvamine on ohtlik.
    /// Viilude ohutusnõuded leiate [`slice::from_raw_parts`] dokumentatsioonist.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // looge viipekursor, kui alustate kursorit esimesele elemendile
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Pange tähele, et see näide näitab kunstlikult selle meetodi kasutamist, kuid "laske viil= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // OHUTUS: `data` on `NonNull`-osuti, mis pole tingimata null-null
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Tagastab nullväärtuseta toore viilu pikkuse.
    ///
    /// Tagastatav väärtus on **elementide** arv, mitte baitide arv.
    ///
    /// See funktsioon on ohutu isegi siis, kui nullist toorest viilu ei saa viilule viidata, kuna osuti puudub kehtiv aadress.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Tagastab viiruse puhvrisse mittetühja kursori.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // OHUTUS: Me teame, et `self` pole null.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Tagastab toore osuti viilu puhvrisse.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Tagastab jagatud viite võimaliku initsialiseerimata väärtuste viilule.Erinevalt [`as_ref`]-st ei nõua see väärtuse initsialiseerimist.
    ///
    /// Muutuva vaste kohta vt [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Sellele meetodile helistades peate veenduma, et kõik järgnevad vastavad tõele:
    ///
    /// * `ptr.len() * mem::size_of::<T>()` paljude baitide lugemiseks peab kursor olema [valid] ja see peab olema korralikult joondatud.See tähendab eelkõige:
    ///
    ///     * Selle osa kogu mälu peab jääma ühte eraldatud objekti!
    ///       Lõigud ei saa kunagi ulatuda mitme eraldatud objekti vahel.
    ///
    ///     * Kursor peab olema joondatud ka nullpikkuste viilude puhul.
    ///     Selle üks põhjus on see, et loendi paigutuse optimeerimine võib tugineda viidete (sealhulgas mis tahes pikkusega viiludele) joondamisele ja mitte-nullile, et eristada neid muudest andmetest.
    ///
    ///     Nullpikkuste viilude jaoks saate [`NonNull::dangling()`]-i abil kasutada kursorit, mida saab kasutada kui `data`.
    ///
    /// * Viilu kogu suurus `ptr.len() * mem::size_of::<T>()` ei tohi olla suurem kui `isize::MAX`.
    ///   Vaadake seadme [`pointer::offset`] ohutusdokumentatsiooni.
    ///
    /// * Peate jõustama Rust varjunimede reeglid, kuna tagastatav eluiga `'a` on valitud meelevaldselt ega kajasta tingimata andmete tegelikku eluiga.
    ///   Eelkõige ei tohi selle eluea jooksul mälu, millele osuti osutab, muteeruda (välja arvatud `UnsafeCell` sees).
    ///
    /// See kehtib isegi siis, kui selle meetodi tulemus on kasutamata!
    ///
    /// Vaadake ka [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // OHUTUS: helistaja peab järgima `as_uninit_slice`-i ohutuslepingut.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Tagastab unikaalse viite võimaliku initsialiseerimata väärtuste viilule.Erinevalt [`as_mut`]-st ei nõua see väärtuse initsialiseerimist.
    ///
    /// Jagatud kolleegi kohta vt [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Sellele meetodile helistades peate veenduma, et kõik järgnevad vastavad tõele:
    ///
    /// * Kursor peab olema paljude baitide `ptr.len() * mem::size_of::<T>()` lugemise ja kirjutamise jaoks [valid] ning see peab olema korralikult joondatud.See tähendab eelkõige:
    ///
    ///     * Selle osa kogu mälu peab jääma ühte eraldatud objekti!
    ///       Lõigud ei saa kunagi ulatuda mitme eraldatud objekti vahel.
    ///
    ///     * Kursor peab olema joondatud ka nullpikkuste viilude puhul.
    ///     Selle üks põhjus on see, et loendi paigutuse optimeerimine võib tugineda viidete (sealhulgas mis tahes pikkusega viiludele) joondamisele ja mitte-nullile, et eristada neid muudest andmetest.
    ///
    ///     Nullpikkuste viilude jaoks saate [`NonNull::dangling()`]-i abil kasutada kursorit, mida saab kasutada kui `data`.
    ///
    /// * Viilu kogu suurus `ptr.len() * mem::size_of::<T>()` ei tohi olla suurem kui `isize::MAX`.
    ///   Vaadake seadme [`pointer::offset`] ohutusdokumentatsiooni.
    ///
    /// * Peate jõustama Rust varjunimede reeglid, kuna tagastatav eluiga `'a` on valitud meelevaldselt ega kajasta tingimata andmete tegelikku eluiga.
    ///   Eelkõige ei tohi selle eluea jooksul mälu, millele osuti osutab, juurde pääseda (lugeda või kirjutada) ühegi teise osuti kaudu.
    ///
    /// See kehtib isegi siis, kui selle meetodi tulemus on kasutamata!
    ///
    /// Vaadake ka [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // See on ohutu, kuna `memory` kehtib paljude baitide `memory.len()`-i lugemise ja kirjutamise jaoks.
    /// // Pange tähele, et `memory.as_mut()`-i helistamine pole siin lubatud, kuna sisu võib olla initsialiseerimata.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // OHUTUS: helistaja peab järgima `as_uninit_slice_mut`-i ohutuslepingut.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Tagastab toore osuti elemendile või alamklassile, ilma piiride kontrollimiseta.
    ///
    /// Selle meetodi kutsumine piirivälise indeksiga või juhul, kui `self` ei ole välistatav, on *[määratlemata käitumine]*, isegi kui saadud kursorit ei kasutata.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // OHUTUS: helistaja tagab, et `self` on üle viidav ja `index` piirideta.
        // Seetõttu ei saa saadud kursor olla NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // OHUTUS: kordumatu kursor ei saa olla null, seega on selle tingimused
        // new_unchecked() austatakse.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // OHUTUS: Muutuv viide ei saa olla null.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // OHUTUS: viide ei saa olla null, seega on selle tingimused
        // new_unchecked() austatakse.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}