use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Tagastab `true`, kui osuti on null.
    ///
    /// Pange tähele, et suurusteta tüüpidel on palju võimalikke nullkursse, kuna arvesse võetakse ainult algandmete osutit, mitte nende pikkust, vtable-d jne.
    /// Seetõttu ei pruugi kaks nulli osutit ikkagi üksteisega võrdsed olla.
    ///
    /// ## Käitumine konst hindamise ajal
    ///
    /// Kui seda funktsiooni kasutatakse const-i hindamise ajal, võib see tagastada `false`-i osutajate jaoks, mis osutuvad käituse ajal nulliks.
    /// Täpsemalt, kui mõne mälu osuti on väljaspool selle piire nihutatud nii, et saadud osuti on null, tagastab funktsioon ikkagi `false`.
    ///
    /// CTFE ei saa kuidagi teada selle mälu absoluutset positsiooni, seega ei saa me öelda, kas kursor on null või mitte.
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Võrdle valamise kaudu õhukese osuti abil, nii et paksud näpunäited kaaluvad ainult nende "data"-osa tühisust.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Heidab teist tüüpi osuti juurde.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Lagundada (võimalik, et lai) osuti aadressi ja metaandmete komponentideks.
    ///
    /// Osuti saab hiljem [`from_raw_parts_mut`]-iga taastada.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Tagastab `None`, kui kursor on null, või tagastab `Some`-i pakitud väärtusele jagatud viite.Kui väärtus võib olla initsialiseerimata, tuleb selle asemel kasutada [`as_uninit_ref`]-i.
    ///
    /// Muutuva vaste kohta vt [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Sellele meetodile helistades peate veenduma, et *kas* kursor on NULL *või* kõik järgmine vastab tõele:
    ///
    /// * Kursor peab olema korralikult joondatud.
    ///
    /// * See peab olema "dereferencable" määratletud tähenduses [the module documentation].
    ///
    /// * Kursor peab osutama `T` initsialiseeritud eksemplarile.
    ///
    /// * Peate jõustama Rust varjunimede reeglid, kuna tagastatav eluiga `'a` on valitud meelevaldselt ega kajasta tingimata andmete tegelikku eluiga.
    ///   Eelkõige ei tohi selle eluea jooksul mälu, millele osuti osutab, muteeruda (välja arvatud `UnsafeCell` sees).
    ///
    /// See kehtib isegi siis, kui selle meetodi tulemus on kasutamata!
    /// (Initsialiseerimise osas pole veel lõplikult otsustatud, kuid seni, kuni see on veel tehtud, on ainus ohutu lähenemisviis tagada nende initsialiseerimine.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Tühi kontrollimata versioon
    ///
    /// Kui olete kindel, et osuti ei saa kunagi olla null ja otsite mingisugust `as_ref_unchecked`-i, mis tagastab `Option<&T>` asemel `&T`, siis tea, et saate kursori otse kõrvale jätta.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // OHUTUS: helistaja peab tagama, et `self` kehtib a
        // viide, kui see pole null.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Tagastab `None`, kui osuti on null, või tagastab `Some`-i pakitud väärtusele jagatud viite.
    /// Erinevalt [`as_ref`]-st ei nõua see väärtuse initsialiseerimist.
    ///
    /// Muutuva vaste kohta vt [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Sellele meetodile helistades peate veenduma, et *kas* kursor on NULL *või* kõik järgmine vastab tõele:
    ///
    /// * Kursor peab olema korralikult joondatud.
    ///
    /// * See peab olema "dereferencable" määratletud tähenduses [the module documentation].
    ///
    /// * Peate jõustama Rust varjunimede reeglid, kuna tagastatav eluiga `'a` on valitud meelevaldselt ega kajasta tingimata andmete tegelikku eluiga.
    ///
    ///   Eelkõige ei tohi selle eluea jooksul mälu, millele osuti osutab, muteeruda (välja arvatud `UnsafeCell` sees).
    ///
    /// See kehtib isegi siis, kui selle meetodi tulemus on kasutamata!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // OHUTUS: helistaja peab tagama, et `self` vastab kõigile nõuetele
        // nõuded viitele.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Arvutab nihke kursori järgi.
    ///
    /// `count` on T ühikutes;nt `count` 3 tähistab `3 * size_of::<T>()` baitide nihet.
    ///
    /// # Safety
    ///
    /// Kui mõnda järgmistest tingimustest rikutakse, on tulemuseks määratlemata käitumine:
    ///
    /// * Nii algus-kui ka tulemuskursor peavad olema kas eraldatud objekti piirides või ühe baidi kaugusel sama eraldatud objekti lõpust.
    /// Pange tähele, et Rust-s peetakse iga (stack-allocated) muutujat eraldi eraldatud objektiks.
    ///
    /// * Arvutatud nihe **baitides** ei saa `isize`-i üle voolata.
    ///
    /// * Piirangus olev nihe ei saa tugineda aadressiruumi "wrapping around".See tähendab, et lõpmatu täpsusega summa **baitides** peab mahtuma kasutamisse.
    ///
    /// Koostaja ja standardraamatukogu püüavad üldiselt tagada, et eraldised ei jõuaks kunagi suuruse juurde, kus nihe on murettekitav.
    /// Näiteks tagavad `Vec` ja `Box`, et nad ei eralda kunagi rohkem kui `isize::MAX` baiti, seega on `vec.as_ptr().add(vec.len())` alati ohutu.
    ///
    /// Enamik platvorme ei suuda põhimõtteliselt isegi sellist jaotust koostada.
    /// Näiteks ei saa ükski teadaolev 64-bitine platvorm kunagi teenida 2 <sup>63-</sup> baidist päringut lehe-tabeli piirangute või aadressiruumi jagamise tõttu.
    /// Kuid mõned 32-ja 16-bitised platvormid võivad edukalt teenida rohkem kui `isize::MAX` baiti päringuid näiteks füüsilise aadressi laiendusega.
    ///
    /// Sellisena võib otse eraldajatelt või mälukaardistatud failidest *hangitud mälu* olla selle funktsiooniga töötamiseks liiga suur.
    ///
    /// Kui neid piiranguid on raske täita, kaaluge selle asemel [`wrapping_offset`] kasutamist.
    /// Selle meetodi ainus eelis on see, et see võimaldab kompilaatori agressiivsemat optimeerimist.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // OHUTUS: helistaja peab järgima `offset`-i ohutuslepingut.
        // Saadud kursor kehtib kirjutamise jaoks, kuna helistaja peab tagama, et see osutab samale eraldatud objektile nagu `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Arvutab kursori nihke mähkimisaritmeetika abil.
    /// `count` on T ühikutes;nt `count` 3 tähistab `3 * size_of::<T>()` baitide nihet.
    ///
    /// # Safety
    ///
    /// See toiming ise on alati ohutu, kuid saadud kursori kasutamine pole nii.
    ///
    /// Saadud kursor jääb kinnitatud samale eraldatud objektile, millele `self` osutab.
    /// Seda ei tohi * kasutada teisele eraldatud objektile juurdepääsuks.Pange tähele, et Rust-s peetakse iga (stack-allocated) muutujat eraldi eraldatud objektiks.
    ///
    /// Teisisõnu, `let z = x.wrapping_offset((y as isize) - (x as isize))` ei muuda `z` sama, mis `y`, isegi kui eeldame, et `T`-il on suurus `1` ja ülevoolu pole: `z` on endiselt seotud objektiga, millele `x` on kinnitatud, ja selle kõrvalejuhtimine on määratlemata käitumine, välja arvatud juhul, kui `x` ja `y` punkt samasse eraldatud objekti.
    ///
    /// Võrreldes [`offset`]-iga, lükkab see meetod põhimõtteliselt samasse eraldatud objekti jäämise nõude: [`offset`] on objekti piiride ületamisel kohene määratlemata käitumine;`wrapping_offset` toodab osuti, kuid viib siiski määratlemata käitumiseni, kui kursor on alla viidud, kui see on väljaspool objekti, millele see on kinnitatud.
    /// [`offset`] saab paremini optimeerida ja on seetõttu eelistatav jõudlustundlikus koodis.
    ///
    /// Viivitatud kontroll võtab arvesse ainult viidatud kursori väärtust, mitte lõpptulemuse arvutamisel kasutatud vaheväärtusi.
    /// Näiteks on `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` alati sama mis `x`.Teisisõnu on lubatud eraldatud objektist lahkuda ja seejärel hiljem uuesti sisestada.
    ///
    /// Kui peate ületama objekti piire, heitke kursor täisarvule ja tehke aritmeetika seal.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// // Kordage toore osuti abil kahe elemendi kaupa
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // OHUTUS: sisemisel `arith_offset`-il pole helistamiseks eeltingimusi.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Tagastab `None`, kui osuti on null, või tagastab `Some`-i pakitud väärtusele kordumatu viite.Kui väärtus võib olla initsialiseerimata, tuleb selle asemel kasutada [`as_uninit_mut`]-i.
    ///
    /// Jagatud kolleegi kohta vt [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Sellele meetodile helistades peate veenduma, et *kas* kursor on NULL *või* kõik järgmine vastab tõele:
    ///
    /// * Kursor peab olema korralikult joondatud.
    ///
    /// * See peab olema "dereferencable" määratletud tähenduses [the module documentation].
    ///
    /// * Kursor peab osutama `T` initsialiseeritud eksemplarile.
    ///
    /// * Peate jõustama Rust varjunimede reeglid, kuna tagastatav eluiga `'a` on valitud meelevaldselt ega kajasta tingimata andmete tegelikku eluiga.
    ///   Eelkõige ei tohi selle eluea jooksul mälu, millele osuti osutab, juurde pääseda (lugeda või kirjutada) ühegi teise osuti kaudu.
    ///
    /// See kehtib isegi siis, kui selle meetodi tulemus on kasutamata!
    /// (Initsialiseerimise osas pole veel lõplikult otsustatud, kuid seni, kuni see on veel tehtud, on ainus ohutu lähenemisviis tagada nende initsialiseerimine.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // See prinditakse: "[4, 2, 3]".
    /// ```
    ///
    /// # Tühi kontrollimata versioon
    ///
    /// Kui olete kindel, et osuti ei saa kunagi olla null ja otsite mingisugust `as_mut_unchecked`-i, mis tagastab `Option<&mut T>` asemel `&mut T`, siis tea, et saate kursori otse kõrvale jätta.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // See prinditakse: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // OHUTUS: helistaja peab tagama, et `self` kehtib
        // muudetav viide, kui see pole null.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Tagastab `None`, kui osuti on null, või tagastab `Some`-i pakitud väärtusele kordumatu viite.
    /// Erinevalt [`as_mut`]-st ei nõua see väärtuse initsialiseerimist.
    ///
    /// Jagatud kolleegi kohta vt [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Sellele meetodile helistades peate veenduma, et *kas* kursor on NULL *või* kõik järgmine vastab tõele:
    ///
    /// * Kursor peab olema korralikult joondatud.
    ///
    /// * See peab olema "dereferencable" määratletud tähenduses [the module documentation].
    ///
    /// * Peate jõustama Rust varjunimede reeglid, kuna tagastatav eluiga `'a` on valitud meelevaldselt ega kajasta tingimata andmete tegelikku eluiga.
    ///
    ///   Eelkõige ei tohi selle eluea jooksul mälu, millele osuti osutab, juurde pääseda (lugeda või kirjutada) ühegi teise osuti kaudu.
    ///
    /// See kehtib isegi siis, kui selle meetodi tulemus on kasutamata!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // OHUTUS: helistaja peab tagama, et `self` vastab kõigile nõuetele
        // nõuded viitele.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Annab vastuseks, kas kaks osutit on võrdsed.
    ///
    /// Käitusajal käitub see funktsioon nagu `self == other`.
    /// Mõnes kontekstis (nt kompileerimisaegne hindamine) ei ole aga alati võimalik määrata kahe osuti võrdsust, nii et see funktsioon võib võltslikult tagastada `false` osutajate jaoks, mis hiljem osutuvad võrdseks.
    ///
    /// Kuid kui see tagastab `true`, on osutid võrdsed.
    ///
    /// See funktsioon on [`guaranteed_ne`] peegel, kuid mitte selle pöördfunktsioon.On kursori võrdlusi, mille puhul mõlemad funktsioonid tagastavad `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Tagastusväärtus võib sõltuvalt kompilaatori versioonist muutuda ja ebaturvaline kood ei pruugi selle funktsiooni tulemusele tugineda.
    /// Seda funktsiooni soovitatakse kasutada ainult jõudluse optimeerimiseks, kui selle funktsiooni võltsitud `false`-i tagastusväärtused ei mõjuta tulemust, vaid ainult jõudlust.
    /// Selle meetodi kasutamise tagajärgi käituse ja kompileerimisaja koodi erinevaks käitumiseks pole uuritud.
    /// Seda meetodit ei tohiks kasutada selliste erinevuste loomiseks ja seda ei tohiks ka stabiliseerida enne, kui oleme sellest teemast paremini aru saanud.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Tagastab, kas kaks osutit on garanteeritud ebavõrdseks.
    ///
    /// Käitusajal käitub see funktsioon nagu `self != other`.
    /// Mõnes kontekstis (nt kompileerimisaegne hindamine) pole aga alati võimalik kindlaks teha kahe osuti ebavõrdsust, nii et see funktsioon võib võltslikult tagastada `false` osutajate jaoks, mis hiljem osutuvad tegelikult ebavõrdseteks.
    ///
    /// Kuid kui see tagastab `true`, on näpunäited ebavõrdsed.
    ///
    /// See funktsioon on [`guaranteed_eq`] peegel, kuid mitte selle pöördfunktsioon.On kursori võrdlusi, mille puhul mõlemad funktsioonid tagastavad `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Tagastusväärtus võib sõltuvalt kompilaatori versioonist muutuda ja ebaturvaline kood ei pruugi selle funktsiooni tulemusele tugineda.
    /// Seda funktsiooni soovitatakse kasutada ainult jõudluse optimeerimiseks, kui selle funktsiooni võltsitud `false`-i tagastusväärtused ei mõjuta tulemust, vaid ainult jõudlust.
    /// Selle meetodi kasutamise tagajärgi käituse ja kompileerimisaja koodi erinevaks käitumiseks pole uuritud.
    /// Seda meetodit ei tohiks kasutada selliste erinevuste loomiseks ja seda ei tohiks ka stabiliseerida enne, kui oleme sellest teemast paremini aru saanud.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Arvutab kahe osuti vahelise kauguse.Tagastatav väärtus on T ühikutes: kaugus baitides jagatakse `mem::size_of::<T>()`-ga.
    ///
    /// See funktsioon on pöördfunktsioon [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Kui mõnda järgmistest tingimustest rikutakse, on tulemuseks määratlemata käitumine:
    ///
    /// * Nii algus-kui ka teine osuti peab olema kas eraldatud objekti piirides või ühe baidi kaugusel sama eraldatud objekti lõpust.
    /// Pange tähele, et Rust-s peetakse iga (stack-allocated) muutujat eraldi eraldatud objektiks.
    ///
    /// * Mõlemad osutid peavad olema *tuletatud* sama objekti kursorist.
    ///   (Vaadake näidet allpool.)
    ///
    /// * Osutajate vaheline kaugus baitides peab olema `T` suuruse täpne kordne.
    ///
    /// * Osutajate vaheline kaugus **baitides** ei saa `isize`-i üle lasta.
    ///
    /// * Piiride vaheline kaugus ei saa tugineda "wrapping around"-i aadressiruumile.
    ///
    /// Rust tüübid ei ole kunagi suuremad kui `isize::MAX` ja Rust eraldised ei ümbritse kunagi aadressiruumi, nii et mis tahes Rust tüüpi `T` teatud väärtuses asuvad kaks osutit vastavad alati kahele viimasele tingimusele.
    ///
    /// Tavaline raamatukogu tagab ka selle, et eraldised ei jõua kunagi suuruseni, kus nihe on murettekitav.
    /// Näiteks tagavad `Vec` ja `Box`, et nad ei eralda kunagi rohkem kui `isize::MAX` baiti, seega vastab `ptr_into_vec.offset_from(vec.as_ptr())` alati kahele viimasele tingimusele.
    ///
    /// Enamik platvorme ei suuda põhimõtteliselt isegi nii suurt eraldist luua.
    /// Näiteks ei saa ükski teadaolev 64-bitine platvorm kunagi teenida 2 <sup>63-</sup> baidist päringut lehe-tabeli piirangute või aadressiruumi jagamise tõttu.
    /// Kuid mõned 32-ja 16-bitised platvormid võivad edukalt teenida rohkem kui `isize::MAX` baiti päringuid näiteks füüsilise aadressi laiendusega.
    /// Sellisena võib otse eraldajatelt või mälukaardistatud failidest *hangitud mälu* olla selle funktsiooniga töötamiseks liiga suur.
    /// (Pange tähele, et ka [`offset`] ja [`add`] on sarnase piiranguga ning seetõttu ei saa neid kasutada ka nii suurte eraldiste korral.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// See funktsioon panics, kui `T` on nullsuurusega tüüp ("ZST").
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Vale* kasutamine:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Tehke ptr2_other ptr2-st "alias", kuid tuletatud ptr1-st.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Kuna ptr2_other ja ptr2 tuletatakse erinevatele objektidele osutavatest osuritest, on nende nihke arvutamine määratlemata käitumine, kuigi need osutavad samale aadressile!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Määratlemata käitumine
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // OHUTUS: helistaja peab järgima `offset_from`-i ohutuslepingut.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Arvutab kursori nihke (mugavus `.offset(count as isize)`) jaoks.
    ///
    /// `count` on T ühikutes;nt `count` 3 tähistab `3 * size_of::<T>()` baitide nihet.
    ///
    /// # Safety
    ///
    /// Kui mõnda järgmistest tingimustest rikutakse, on tulemuseks määratlemata käitumine:
    ///
    /// * Nii algus-kui ka tulemuskursor peavad olema kas eraldatud objekti piirides või ühe baidi kaugusel sama eraldatud objekti lõpust.
    /// Pange tähele, et Rust-s peetakse iga (stack-allocated) muutujat eraldi eraldatud objektiks.
    ///
    /// * Arvutatud nihe **baitides** ei saa `isize`-i üle voolata.
    ///
    /// * Piirangus olev nihe ei saa tugineda aadressiruumi "wrapping around".See tähendab, et lõpmatu täpsusega summa peab mahtuma `usize`-i.
    ///
    /// Koostaja ja standardraamatukogu püüavad üldiselt tagada, et eraldised ei jõuaks kunagi suuruse juurde, kus nihe on murettekitav.
    /// Näiteks tagavad `Vec` ja `Box`, et nad ei eralda kunagi rohkem kui `isize::MAX` baiti, seega on `vec.as_ptr().add(vec.len())` alati ohutu.
    ///
    /// Enamik platvorme ei suuda põhimõtteliselt isegi sellist jaotust koostada.
    /// Näiteks ei saa ükski teadaolev 64-bitine platvorm kunagi teenida 2 <sup>63-</sup> baidist päringut lehe-tabeli piirangute või aadressiruumi jagamise tõttu.
    /// Kuid mõned 32-ja 16-bitised platvormid võivad edukalt teenida rohkem kui `isize::MAX` baiti päringuid näiteks füüsilise aadressi laiendusega.
    ///
    /// Sellisena võib otse eraldajatelt või mälukaardistatud failidest *hangitud mälu* olla selle funktsiooniga töötamiseks liiga suur.
    ///
    /// Kui neid piiranguid on raske täita, kaaluge selle asemel [`wrapping_add`] kasutamist.
    /// Selle meetodi ainus eelis on see, et see võimaldab kompilaatori agressiivsemat optimeerimist.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // OHUTUS: helistaja peab järgima `offset`-i ohutuslepingut.
        unsafe { self.offset(count as isize) }
    }

    /// Arvutab nihke kursori järgi (mugavus `.offset ((loetakse isize).wrapping_neg())`).
    ///
    /// `count` on T ühikutes;nt `count` 3 tähistab `3 * size_of::<T>()` baitide nihet.
    ///
    /// # Safety
    ///
    /// Kui mõnda järgmistest tingimustest rikutakse, on tulemuseks määratlemata käitumine:
    ///
    /// * Nii algus-kui ka tulemuskursor peavad olema kas eraldatud objekti piirides või ühe baidi kaugusel sama eraldatud objekti lõpust.
    /// Pange tähele, et Rust-s peetakse iga (stack-allocated) muutujat eraldi eraldatud objektiks.
    ///
    /// * Arvutatud nihe ei tohi ületada `isize::MAX`**baiti**.
    ///
    /// * Piirangus olev nihe ei saa tugineda aadressiruumi "wrapping around".See tähendab, et lõpmatu täpsusega summa peab mahtuma kasutamisse.
    ///
    /// Koostaja ja standardraamatukogu püüavad üldiselt tagada, et eraldised ei jõuaks kunagi suuruse juurde, kus nihe on murettekitav.
    /// Näiteks tagavad `Vec` ja `Box`, et nad ei eralda kunagi rohkem kui `isize::MAX` baiti, seega on `vec.as_ptr().add(vec.len()).sub(vec.len())` alati ohutu.
    ///
    /// Enamik platvorme ei suuda põhimõtteliselt isegi sellist jaotust koostada.
    /// Näiteks ei saa ükski teadaolev 64-bitine platvorm kunagi teenida 2 <sup>63-</sup> baidist päringut lehe-tabeli piirangute või aadressiruumi jagamise tõttu.
    /// Kuid mõned 32-ja 16-bitised platvormid võivad edukalt teenida rohkem kui `isize::MAX` baiti päringuid näiteks füüsilise aadressi laiendusega.
    ///
    /// Sellisena võib otse eraldajatelt või mälukaardistatud failidest *hangitud mälu* olla selle funktsiooniga töötamiseks liiga suur.
    ///
    /// Kui neid piiranguid on raske täita, kaaluge selle asemel [`wrapping_sub`] kasutamist.
    /// Selle meetodi ainus eelis on see, et see võimaldab kompilaatori agressiivsemat optimeerimist.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // OHUTUS: helistaja peab järgima `offset`-i ohutuslepingut.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Arvutab kursori nihke mähkimisaritmeetika abil.
    /// (mugavus `.wrapping_offset(count as isize)`) jaoks
    ///
    /// `count` on T ühikutes;nt `count` 3 tähistab `3 * size_of::<T>()` baitide nihet.
    ///
    /// # Safety
    ///
    /// See toiming ise on alati ohutu, kuid saadud kursori kasutamine pole nii.
    ///
    /// Saadud kursor jääb kinnitatud samale eraldatud objektile, millele `self` osutab.
    /// Seda ei tohi * kasutada teisele eraldatud objektile juurdepääsuks.Pange tähele, et Rust-s peetakse iga (stack-allocated) muutujat eraldi eraldatud objektiks.
    ///
    /// Teisisõnu, `let z = x.wrapping_add((y as usize) - (x as usize))` ei muuda `z` sama, mis `y`, isegi kui eeldame, et `T`-il on suurus `1` ja ülevoolu pole: `z` on endiselt seotud objektiga, millele `x` on kinnitatud, ja selle kõrvalejuhtimine on määratlemata käitumine, välja arvatud juhul, kui `x` ja `y` punkt samasse eraldatud objekti.
    ///
    /// Võrreldes [`add`]-iga, lükkab see meetod põhimõtteliselt samasse eraldatud objekti jäämise nõude: [`add`] on objekti piiride ületamisel kohene määratlemata käitumine;`wrapping_add` toodab osuti, kuid viib siiski määratlemata käitumiseni, kui kursor on alla viidud, kui see on väljaspool objekti, millele see on kinnitatud.
    /// [`add`] saab paremini optimeerida ja on seetõttu eelistatav jõudlustundlikus koodis.
    ///
    /// Viivitatud kontroll võtab arvesse ainult viidatud kursori väärtust, mitte lõpptulemuse arvutamisel kasutatud vaheväärtusi.
    /// Näiteks on `x.wrapping_add(o).wrapping_sub(o)` alati sama mis `x`.Teisisõnu on lubatud eraldatud objektist lahkuda ja seejärel hiljem uuesti sisestada.
    ///
    /// Kui peate ületama objekti piire, heitke kursor täisarvule ja tehke aritmeetika seal.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// // Kordage toore osuti abil kahe elemendi kaupa
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // See silmus prindib "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Arvutab kursori nihke mähkimisaritmeetika abil.
    /// (mugavuse jaoks .wrapping_offset ((arvestatakse isize).wrapping_neg())`)-iga
    ///
    /// `count` on T ühikutes;nt `count` 3 tähistab `3 * size_of::<T>()` baitide nihet.
    ///
    /// # Safety
    ///
    /// See toiming ise on alati ohutu, kuid saadud kursori kasutamine pole nii.
    ///
    /// Saadud kursor jääb kinnitatud samale eraldatud objektile, millele `self` osutab.
    /// Seda ei tohi * kasutada teisele eraldatud objektile juurdepääsuks.Pange tähele, et Rust-s peetakse iga (stack-allocated) muutujat eraldi eraldatud objektiks.
    ///
    /// Teisisõnu, `let z = x.wrapping_sub((x as usize) - (y as usize))` ei muuda `z` sama, mis `y`, isegi kui eeldame, et `T`-il on suurus `1` ja ülevoolu pole: `z` on endiselt seotud objektiga, millele `x` on kinnitatud, ja selle kõrvalejuhtimine on määratlemata käitumine, välja arvatud juhul, kui `x` ja `y` punkt samasse eraldatud objekti.
    ///
    /// Võrreldes [`sub`]-iga, lükkab see meetod põhimõtteliselt samasse eraldatud objekti jäämise nõude: [`sub`] on objekti piiride ületamisel kohene määratlemata käitumine;`wrapping_sub` toodab osuti, kuid viib siiski määratlemata käitumiseni, kui kursor on alla viidud, kui see on väljaspool objekti, millele see on kinnitatud.
    /// [`sub`] saab paremini optimeerida ja on seetõttu eelistatav jõudlustundlikus koodis.
    ///
    /// Viivitatud kontroll võtab arvesse ainult viidatud kursori väärtust, mitte lõpptulemuse arvutamisel kasutatud vaheväärtusi.
    /// Näiteks on `x.wrapping_add(o).wrapping_sub(o)` alati sama mis `x`.Teisisõnu on lubatud eraldatud objektist lahkuda ja seejärel hiljem uuesti sisestada.
    ///
    /// Kui peate ületama objekti piire, heitke kursor täisarvule ja tehke aritmeetika seal.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// // Kordage toorosuti abil kahe elemendi (backwards) kaupa
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // See silmus prindib "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Määrab kursori väärtuseks `ptr`.
    ///
    /// Juhul, kui `self` on (fat)-osuti suurusteta, mõjutab see toiming ainult osutiosa, samas kui (thin)-osuti suurusega tüüpide jaoks on see sama efekt kui lihtsal määramisel.
    ///
    /// Saadud kursori alguspunkt on `val`, st rasvapoolse kursori puhul on see toiming semantiliselt sama mis uue rasvapoolse kursori loomine andmeanduri väärtusega `val`, kuid metaandmetega `self`.
    ///
    ///
    /// # Examples
    ///
    /// See funktsioon on peamiselt kasulik bait-osuti aritmeetika võimaldamiseks potentsiaalselt rasvade osutajate puhul:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // prindib "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // OHUTUS: õhukese osuti korral on need toimingud identsed
        // lihtsale ülesandele.
        // Rasvapoolse kursori korral on praeguse rasvapoolse kursori paigutuse rakendamise korral sellise kursori esimene väli alati andmekursor, mis samuti määratakse.
        //
        unsafe { *thin = val };
        self
    }

    /// Loeb väärtust `self`-ist ilma seda teisaldamata.
    /// See jätab `self`-is mälu muutmata.
    ///
    /// Ohutusprobleeme ja näiteid leiate jaotisest [`ptr::read`].
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // OHUTUS: helistaja peab järgima ``-i ohutuslepingut.
        unsafe { read(self) }
    }

    /// Teeb väärtuse kõikuva lugemise `self`-ist ilma seda liigutamata.See jätab `self`-is mälu muutmata.
    ///
    /// Volatiilsete toimingute eesmärk on toimida I/O-mälus ja kompilaator ei saa neid teiste lenduvate toimingute korral kindlasti valida ega järjestada.
    ///
    ///
    /// Ohutusprobleeme ja näiteid leiate jaotisest [`ptr::read_volatile`].
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // OHUTUS: helistaja peab järgima `read_volatile`-i ohutuslepingut.
        unsafe { read_volatile(self) }
    }

    /// Loeb väärtust `self`-ist ilma seda teisaldamata.
    /// See jätab `self`-is mälu muutmata.
    ///
    /// Erinevalt `read`-st võib kursor olla joondamata.
    ///
    /// Ohutusprobleeme ja näiteid leiate jaotisest [`ptr::read_unaligned`].
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // OHUTUS: helistaja peab järgima `read_unaligned`-i ohutuslepingut.
        unsafe { read_unaligned(self) }
    }

    /// Kopeerib `count * size_of<T>` baiti `self`-st `dest`-i.
    /// Allikas ja sihtkoht võivad kattuda.
    ///
    /// NOTE: sellel on sama argumentide järjekord nagu [`ptr::copy`].
    ///
    /// Ohutusprobleeme ja näiteid leiate jaotisest [`ptr::copy`].
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // OHUTUS: helistaja peab järgima `copy`-i ohutuslepingut.
        unsafe { copy(self, dest, count) }
    }

    /// Kopeerib `count * size_of<T>` baiti `self`-st `dest`-i.
    /// Allikas ja sihtkoht ei pruugi * kattuda.
    ///
    /// NOTE: sellel on sama argumentide järjekord nagu [`ptr::copy_nonoverlapping`].
    ///
    /// Ohutusprobleeme ja näiteid leiate jaotisest [`ptr::copy_nonoverlapping`].
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // OHUTUS: helistaja peab järgima `copy_nonoverlapping`-i ohutuslepingut.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Kopeerib `count * size_of<T>` baiti `src`-st `self`-i.
    /// Allikas ja sihtkoht võivad kattuda.
    ///
    /// NOTE: sellel on [`ptr::copy`]*vastupidine* argumentide järjekord.
    ///
    /// Ohutusprobleeme ja näiteid leiate jaotisest [`ptr::copy`].
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // OHUTUS: helistaja peab järgima `copy`-i ohutuslepingut.
        unsafe { copy(src, self, count) }
    }

    /// Kopeerib `count * size_of<T>` baiti `src`-st `self`-i.
    /// Allikas ja sihtkoht ei pruugi * kattuda.
    ///
    /// NOTE: sellel on [`ptr::copy_nonoverlapping`]*vastupidine* argumentide järjekord.
    ///
    /// Ohutusprobleeme ja näiteid leiate jaotisest [`ptr::copy_nonoverlapping`].
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // OHUTUS: helistaja peab järgima `copy_nonoverlapping`-i ohutuslepingut.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Käivitab osutatava väärtuse hävitaja (kui see on olemas).
    ///
    /// Ohutusprobleeme ja näiteid leiate jaotisest [`ptr::drop_in_place`].
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // OHUTUS: helistaja peab järgima `drop_in_place`-i ohutuslepingut.
        unsafe { drop_in_place(self) }
    }

    /// Kirjutab mälu asukoha etteantud väärtusega üle vana väärtust lugemata või maha viskamata.
    ///
    ///
    /// Ohutusprobleeme ja näiteid leiate jaotisest [`ptr::write`].
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // OHUTUS: helistaja peab järgima `write`-i ohutuslepingut.
        unsafe { write(self, val) }
    }

    /// Kutsub määratud kursoril mäluseade, määrates `count * size_of::<T>()` baiti mälu alates `self` kuni `val`.
    ///
    ///
    /// Ohutusprobleeme ja näiteid leiate jaotisest [`ptr::write_bytes`].
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // OHUTUS: helistaja peab järgima `write_bytes`-i ohutuslepingut.
        unsafe { write_bytes(self, val, count) }
    }

    /// Teeb mälu asukoha volatiilse kirjutamise etteantud väärtusega ilma vana väärtust lugemata või viskamata.
    ///
    /// Volatiilsete toimingute eesmärk on toimida I/O-mälus ja kompilaator ei saa neid teiste lenduvate toimingute korral kindlasti valida ega järjestada.
    ///
    ///
    /// Ohutusprobleeme ja näiteid leiate jaotisest [`ptr::write_volatile`].
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // OHUTUS: helistaja peab järgima `write_volatile`-i ohutuslepingut.
        unsafe { write_volatile(self, val) }
    }

    /// Kirjutab mälu asukoha etteantud väärtusega üle vana väärtust lugemata või maha viskamata.
    ///
    ///
    /// Erinevalt `write`-st võib kursor olla joondamata.
    ///
    /// Ohutusprobleeme ja näiteid leiate jaotisest [`ptr::write_unaligned`].
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // OHUTUS: helistaja peab järgima `write_unaligned`-i ohutuslepingut.
        unsafe { write_unaligned(self, val) }
    }

    /// Asendab väärtuse `self` väärtusega `src`, tagastades vana väärtuse, kukutamata.
    ///
    ///
    /// Ohutusprobleeme ja näiteid leiate jaotisest [`ptr::replace`].
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // OHUTUS: helistaja peab järgima `replace`-i ohutuslepingut.
        unsafe { replace(self, src) }
    }

    /// Vahetab väärtused kahes sama tüüpi muutuvas asukohas, kummaski deinitsialiseerimata.
    /// Need võivad kattuda, erinevalt `mem::swap`-st, mis on muidu samaväärne.
    ///
    /// Ohutusprobleemide ja näidete kohta vt [`ptr::swap`].
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // OHUTUS: helistaja peab järgima `swap`-i ohutuslepingut.
        unsafe { swap(self, with) }
    }

    /// Arvutab nihke, mida tuleb osutada kursorile, et see oleks joondatud `align`-iga.
    ///
    /// Kui osutit pole võimalik joondada, tagastab rakendus `usize::MAX`.
    /// Rakendusel on lubatud *alati* tagastada `usize::MAX`.
    /// Ainult teie algoritmi toimivus võib sõltuda siin kasutatava nihke saamisest, mitte selle õigsusest.
    ///
    /// Nihe väljendub `T` elementide arvus, mitte baitides.Tagastatud väärtust saab kasutada meetodil `wrapping_add`.
    ///
    /// Puuduvad igasugused garantiid, et kursori tasaarvestamine ei ületa ega lähe kaugemale eraldisest, millele osuti osutab.
    ///
    /// Helistaja ülesanne on tagada, et tagastatud nihe oleks korrektne kõigis muudes tingimustes peale joondamise.
    ///
    /// # Panics
    ///
    /// Funktsioon panics, kui `align` ei ole aste kahest.
    ///
    /// # Examples
    ///
    /// Juurdepääs külgnevale `u8`-le kui `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // kui kursorit saab joondada `offset` kaudu, osutaks see eraldisest väljapoole
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // OHUTUS: `align`-i võimsus on üle 2
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Tagastab toore viilu pikkuse.
    ///
    /// Tagastatav väärtus on **elementide** arv, mitte baitide arv.
    ///
    /// See funktsioon on ohutu isegi siis, kui toorest viilu ei saa viide viide viita, kuna osuti on null või joondamatu.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // OHUTUS: see on ohutu, kuna `*const [T]` ja `FatPtr<T>` on sama paigutusega.
            // Selle garantii saab anda ainult `std`.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Tagastab toore osuti viilu puhvrisse.
    ///
    /// See on samaväärne `self`-i valamisega `*mut T`-i, kuid tüübikindlam.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Tagastab toore osuti elemendile või alamklassile, ilma piiride kontrollimiseta.
    ///
    /// Selle meetodi kutsumine piirivälise indeksiga või juhul, kui `self` ei ole välistatav, on *[määratlemata käitumine]*, isegi kui saadud kursorit ei kasutata.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // OHUTUS: helistaja tagab, et `self` on üle viidav ja `index` piirideta.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Tagastab `None`, kui osuti on null, või tagastab jagatud viilu `Some`-i pakitud väärtusele.
    /// Erinevalt [`as_ref`]-st ei nõua see väärtuse initsialiseerimist.
    ///
    /// Muutuva vaste kohta vt [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Sellele meetodile helistades peate veenduma, et *kas* kursor on NULL *või* kõik järgmine vastab tõele:
    ///
    /// * `ptr.len() * mem::size_of::<T>()` paljude baitide lugemiseks peab kursor olema [valid] ja see peab olema korralikult joondatud.See tähendab eelkõige:
    ///
    ///     * Selle osa kogu mälu peab jääma ühte eraldatud objekti!
    ///       Lõigud ei saa kunagi ulatuda mitme eraldatud objekti vahel.
    ///
    ///     * Kursor peab olema joondatud ka nullpikkuste viilude puhul.
    ///     Selle üks põhjus on see, et loendi paigutuse optimeerimine võib tugineda viidete (sealhulgas mis tahes pikkusega viiludele) joondamisele ja mitte-nullile, et eristada neid muudest andmetest.
    ///
    ///     Nullpikkuste viilude jaoks saate [`NonNull::dangling()`]-i abil kasutada kursorit, mida saab kasutada kui `data`.
    ///
    /// * Viilu kogu suurus `ptr.len() * mem::size_of::<T>()` ei tohi olla suurem kui `isize::MAX`.
    ///   Vaadake seadme [`pointer::offset`] ohutusdokumentatsiooni.
    ///
    /// * Peate jõustama Rust varjunimede reeglid, kuna tagastatav eluiga `'a` on valitud meelevaldselt ega kajasta tingimata andmete tegelikku eluiga.
    ///   Eelkõige ei tohi selle eluea jooksul mälu, millele osuti osutab, muteeruda (välja arvatud `UnsafeCell` sees).
    ///
    /// See kehtib isegi siis, kui selle meetodi tulemus on kasutamata!
    ///
    /// Vaadake ka [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // OHUTUS: helistaja peab järgima `as_uninit_slice`-i ohutuslepingut.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Tagastab `None`, kui osuti on null, või tagastab `Some`-i pakitud väärtusele unikaalse viilu.
    /// Erinevalt [`as_mut`]-st ei nõua see väärtuse initsialiseerimist.
    ///
    /// Jagatud kolleegi kohta vt [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Sellele meetodile helistades peate veenduma, et *kas* kursor on NULL *või* kõik järgmine vastab tõele:
    ///
    /// * Kursor peab olema paljude baitide `ptr.len() * mem::size_of::<T>()` lugemise ja kirjutamise jaoks [valid] ning see peab olema korralikult joondatud.See tähendab eelkõige:
    ///
    ///     * Selle osa kogu mälu peab jääma ühte eraldatud objekti!
    ///       Lõigud ei saa kunagi ulatuda mitme eraldatud objekti vahel.
    ///
    ///     * Kursor peab olema joondatud ka nullpikkuste viilude puhul.
    ///     Selle üks põhjus on see, et loendi paigutuse optimeerimine võib tugineda viidete (sealhulgas mis tahes pikkusega viiludele) joondamisele ja mitte-nullile, et eristada neid muudest andmetest.
    ///
    ///     Nullpikkuste viilude jaoks saate [`NonNull::dangling()`]-i abil kasutada kursorit, mida saab kasutada kui `data`.
    ///
    /// * Viilu kogu suurus `ptr.len() * mem::size_of::<T>()` ei tohi olla suurem kui `isize::MAX`.
    ///   Vaadake seadme [`pointer::offset`] ohutusdokumentatsiooni.
    ///
    /// * Peate jõustama Rust varjunimede reeglid, kuna tagastatav eluiga `'a` on valitud meelevaldselt ega kajasta tingimata andmete tegelikku eluiga.
    ///   Eelkõige ei tohi selle eluea jooksul mälu, millele osuti osutab, juurde pääseda (lugeda või kirjutada) ühegi teise osuti kaudu.
    ///
    /// See kehtib isegi siis, kui selle meetodi tulemus on kasutamata!
    ///
    /// Vaadake ka [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // OHUTUS: helistaja peab järgima `as_uninit_slice_mut`-i ohutuslepingut.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Näitajate võrdsus
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}