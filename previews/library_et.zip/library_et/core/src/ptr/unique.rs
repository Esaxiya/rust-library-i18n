use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Ümbris toore null-nulliga `*mut T` ümber, mis näitab, et selle ümbrise valdaja omab referenti.
/// Kasulik selliste abstraktsioonide ehitamiseks nagu `Box<T>`, `Vec<T>`, `String` ja `HashMap<K, V>`.
///
/// Erinevalt `*mut T`-ist käitub `Unique<T>` "as if"-ga, see oli `T`-i eksemplar.
/// See rakendab `Send`/`Sync`-i, kui `T` on `Send`/`Sync`.
/// See tähendab ka sellist tugevat pseudonüümi garantiid, mida `T`-i eksemplar võib oodata:
/// kursori viidet ei tohiks muuta, kui pole ainulaadset teed sellele, et sellele ainulaadne oleks.
///
/// Kui te pole kindel, kas `Unique` i kasutamine teie eesmärkidel on õige, kaaluge nõrgema semantikaga `NonNull` kasutamist.
///
///
/// Erinevalt `*mut T`-st peab kursor olema alati nullist erinev, isegi kui kursorit ei tehta kunagi alla.
/// Seda selleks, et enums saaks seda keelatud väärtust kasutada diskrimineerijana-`Option<Unique<T>>` on sama suur kui `Unique<T>`.
/// Kursor võib siiski rippuda, kui sellele ei viidata.
///
/// Erinevalt `*mut T`-st on `Unique<T>` ühilduv üle `T`.
/// See peaks alati olema õige iga tüübi puhul, mis järgib Unique'i varjunõudeid.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: sellel markeril ei ole dispersioonile tagajärgi, kuid see on vajalik
    // et dropck saaks aru, et me omame loogiliselt `T`-i.
    //
    // Üksikasju vt:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` osutid on `Send`, kui `T` on `Send`, kuna nende viidatud andmed on unias.
/// Pange tähele, et seda aliasing-invarianti tüübisüsteem ei sunni;`Unique`-i kasutav abstraktsioon peab selle jõustama.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` osutid on `Sync`, kui `T` on `Sync`, kuna nende viidatud andmed on unias.
/// Pange tähele, et seda aliasing-invarianti tüübisüsteem ei sunni;`Unique`-i kasutav abstraktsioon peab selle jõustama.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Loob uue rippuva, kuid hästi joondatud `Unique`.
    ///
    /// See on kasulik laisalt eraldatavate tüüpide initsialiseerimiseks, nagu seda teeb `Vec::new`.
    ///
    /// Pange tähele, et kursori väärtus võib potentsiaalselt tähistada kehtivat osutit `T`-le, mis tähendab, et seda ei tohi kasutada "not yet initialized"-i valvuriväärtusena.
    /// Laiskalt eraldavad tüübid peavad lähtestamist jälgima mõnel muul viisil.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // OHUTUS: mem::align_of() tagastab kehtiva nullindikaatori.The
        // new_unchecked()-i helistamise tingimused on seega täidetud.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Loob uue `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` peab olema null-null.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // OHUTUS: helistaja peab tagama, et `ptr` pole null.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Loob uue `Unique`-i, kui `ptr` pole null.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // OHUTUS: Kursor on juba kontrollitud ja pole null.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Omandab aluseks oleva `*mut`-osuti.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Eristab sisu.
    ///
    /// Saadud eluiga on seotud iseendaga, nii et see käitub "as if", see oli tegelikult T-i eksemplar, mida laenatakse.
    /// Kui on vaja pikemat (unbound) eluiga, kasutage `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // OHUTUS: helistaja peab tagama, et `self` vastab kõigile nõuetele
        // nõuded viitele.
        unsafe { &*self.as_ptr() }
    }

    /// Muutub sisu sisuliselt ära.
    ///
    /// Saadud eluiga on seotud iseendaga, nii et see käitub "as if", see oli tegelikult T-i eksemplar, mida laenatakse.
    /// Kui on vaja pikemat (unbound) eluiga, kasutage `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // OHUTUS: helistaja peab tagama, et `self` vastab kõigile nõuetele
        // muutuva viite nõuded.
        unsafe { &mut *self.as_ptr() }
    }

    /// Heidab teist tüüpi osuti juurde.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // OHUTUS: Unique::new_unchecked() loob uue unikaalsuse ja vajadused
        // antud kursor ei ole null.
        // Kuna me liigume iseendana kui osuti, ei saa see olla null.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // OHUTUS: Muutuv viide ei saa olla null
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}