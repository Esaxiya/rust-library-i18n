//! Haldage mälu käsitsi toorviitade abil.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Paljud selle mooduli funktsioonid võtavad tooreid näpunäiteid argumentidena ja loevad nendest või kirjutavad neile.Et see oleks ohutu, peavad need osutid olema *kehtivad*.
//! Kursori kehtivus sõltub operatsioonist, milles seda kasutatakse (lugemine või kirjutamine), ja mälu ulatusest, milleni juurdepääsetakse (st mitu baiti on read/written).
//! Enamik funktsioone kasutab `*mut T` ja `* const T`, et pääseda juurde ainult ühele väärtusele, mille puhul dokumentatsioon jätab suuruse välja ja eeldab kaudselt, et see on `size_of::<T>()` baiti.
//!
//! Kehtivuse täpsed reeglid pole veel kindlaks määratud.Sel hetkel pakutavad garantiid on väga minimaalsed:
//!
//! * [null]-osuti ei kehti *kunagi*, isegi mitte [size zero][zst]-i juurdepääsude jaoks.
//! * Kursori kehtivuse tagamiseks on vajalik, kuid mitte alati piisav, et osuti oleks *viidatav*: kursorist algava antud suurusega mälu vahemik peab kõik jääma ühe eraldatud objekti piiridesse.
//!
//! Pange tähele, et Rust-s peetakse iga (stack-allocated) muutujat eraldi eraldatud objektiks.
//! * Isegi [size zero][zst] operatsioonide puhul ei tohi kursor osutada jaotatud mälule, st tehingu tegemine muudab osutid kehtetuks isegi nullsuuruste toimingute korral.
//! Mistahes nullist erineva täisarvu *literaali* osuti valamine kehtib nullsuuruste juurdepääsude korral, isegi kui sellel aadressil juhtub olema mõni mälu ja see jaotatakse.
//! See vastab teie enda eraldaja kirjutamisele: nullmõõduliste objektide eraldamine pole eriti keeruline.
//! Nullsuuruste juurdepääsude korral kehtiva osuti saamiseks on kanooniline viis [`NonNull::dangling`].
//! * Kõik selle mooduli funktsioonide poolt tehtud juurdepääsud on *mitteaatomilised*[atomic operations]-i tähenduses, mida kasutatakse lõimede sünkroonimiseks.
//! See tähendab, et määratlemata käitumine on teha kaks samaaegset juurdepääsu samale asukohale erinevatest lõimedest, välja arvatud juhul, kui mõlemad juurdepääsud loetakse ainult mälust.
//! Pange tähele, et need hõlmavad sõnaselgelt [`read_volatile`] ja [`write_volatile`]: Lenduvaid juurdepääsusid ei saa kasutada lõimedevaheliseks sünkroonimiseks.
//! * Osutajale viite valamise tulemus kehtib seni, kuni alusobjekt on aktiivne ja samale mälule juurdepääsuks ei kasutata ühtegi viidet (ainult tooreid näpunäiteid).
//!
//! Nendest aksioomidest koos [`offset`] hoolika kasutamisega kursori aritmeetikas piisab paljude kasulike asjade õigeks rakendamiseks ebaturvalises koodis.
//! Tugevamad garantiid antakse lõpuks, kuna [aliasing] reeglid on väljatöötamisel.
//! Lisateavet leiate nii [book]-st kui ka jaotisest [undefined behavior][ub]-le pühendatud viidetes.
//!
//! ## Alignment
//!
//! Eespool määratletud kehtivad toored osutid pole tingimata õigesti joondatud (kus "proper" joondus on määratletud pointee tüübiga, st `*const T` peab olema joondatud `mem::align_of::<T>()`-iga).
//! Kuid enamus funktsioone nõuavad nende argumentide nõuetekohast joondamist ja ütlevad selle nõude sõnaselgelt oma dokumentatsioonis.
//! Märkimisväärsed erandid sellest on [`read_unaligned`] ja [`write_unaligned`].
//!
//! Kui funktsioon nõuab õiget joondamist, teeb see seda isegi siis, kui juurdepääs on 0-ga, st isegi kui mälu tegelikult ei puudutata.Kaaluge sellistel juhtudel [`NonNull::dangling`] kasutamist.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Käivitab osutatava väärtuse hävitaja (kui see on olemas).
///
/// See on semantiliselt samaväärne [`ptr::read`]-i helistamise ja tulemuse kõrvale jätmisega, kuid sellel on järgmised eelised:
///
/// * Suuremat tüüpi tüüpide nagu trait objektide viskamiseks on *vajalik* kasutada `drop_in_place`-i, kuna neid ei saa virnale lugeda ja tavaliselt maha visata.
///
/// * Optimeerijale on sõbralikum seda teha [`ptr::read`]-i kaudu käsitsi eraldatud mälu mahakukkumisel (nt `Box`/`Rc`/`Vec`-i rakendustes), kuna koostaja ei pea koopia välja elamiseks tõestama, et see on heli.
///
///
/// * Seda saab kasutada andmete [pinned] kukutamiseks, kui `T` pole `repr(packed)` (kinnitatud andmeid ei tohi enne nende viskamist teisaldada).
///
/// Joondamata väärtusi ei saa paigale visata, need tuleb kõigepealt kopeerida joondatud asukohta, kasutades [`ptr::read_unaligned`]-i.Pakitud struktuuride puhul teeb kompilaator selle käigu automaatselt.
/// See tähendab, et pakitud konstruktsioonide väljad ei visata oma kohale.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Käitumine on määratlemata, kui rikutakse mõnda järgmistest tingimustest:
///
/// * `to_drop` peab olema nii lugemise kui ka kirjutamise puhul [valid].
///
/// * `to_drop` peavad olema korralikult joondatud.
///
/// * Väärtus `to_drop` point to peab langemisel kehtima, mis võib tähendada, et see peab toetama täiendavaid invariante, see sõltub tüübist.
///
/// Lisaks, kui `T` pole [`Copy`], võib teravdatud väärtuse kasutamine pärast `drop_in_place`-i kutsumist põhjustada määratlemata käitumise.Pange tähele, et `*to_drop = foo` loetakse kasutuseks, kuna see põhjustab väärtuse uuesti langemise.
/// [`write()`] saab kasutada andmete ülekirjutamiseks, ilma et need loobuksid.
///
/// Pange tähele, et isegi kui `T`-l on suurus `0`, peab kursor olema NULL-väline ja õigesti joondatud.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Eemaldage vector-st viimane üksus käsitsi:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Hankige töötlemata kursor `v`-i viimase elemendi juurde.
///     let ptr = &mut v[1] as *mut _;
///     // Viimase üksuse kukkumise vältimiseks lühendage `v`.
///     // Me teeme seda kõigepealt, et vältida probleeme, kui `drop_in_place` on alla panics.
///     v.set_len(1);
///     // Ilma `drop_in_place`-i kõneta ei visataks viimast eset kunagi maha ja selle hallatav mälu lekiks.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Veenduge, et viimane üksus visati maha.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Pange tähele, et kompilaator teostab selle koopia automaatselt pakitud struktuuride viskamisel, st te ei pea tavaliselt selliste probleemide pärast muretsema, kui te ei helista `drop_in_place`-ile käsitsi.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Siinsel koodil pole tähtsust, selle asendab kompilaator tõelise tilgaliimiga.
    //

    // OHUTUS: vt ülaltoodud kommentaari
    unsafe { drop_in_place(to_drop) }
}

/// Loob nulltoore kursori.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Loob nullmuutuva toore kursori.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// `T: Clone`-i sidumise vältimiseks on vajalik käsitsi implantaat.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// `T: Copy`-i sidumise vältimiseks on vajalik käsitsi implantaat.
impl<T> Copy for FatPtr<T> {}

/// Moodustab kursorist ja pikkusest toore viilu.
///
/// `len` argument on **elementide** arv, mitte baitide arv.
///
/// See funktsioon on ohutu, kuid tegelikult on tagastusväärtuse kasutamine ebaturvaline.
/// Viilude ohutusnõuded leiate [`slice::from_raw_parts`] dokumentatsioonist.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // looge viipekursor, kui alustate kursorit esimesele elemendile
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // OHUTUS: Väärtusele pääsemine liidust `Repr` on turvaline alates * const [T]
        //
        // ja FatPtril on samad mäluplaanid.Selle garantii saab anda ainult std.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Teostab sama funktsionaalsust nagu [`slice_from_raw_parts`], välja arvatud see, et tagastatakse toores muutuv viil, vastupidiselt töötlemata muutumatule lõigule.
///
///
/// Lisateavet leiate [`slice_from_raw_parts`] dokumentatsioonist.
///
/// See funktsioon on ohutu, kuid tegelikult on tagastusväärtuse kasutamine ebaturvaline.
/// Viilude ohutusnõuded leiate [`slice::from_raw_parts_mut`] dokumentatsioonist.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // määrake viilu indeksis väärtus
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // OHUTUS: Väärtusele pääsemine liidust `Repr` on turvaline, kuna * mut [T]
        // ja FatPtril on samad mäluplaanid
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Vahetab väärtused kahes sama tüüpi muutuvas asukohas, kummaski deinitsialiseerimata.
///
/// Kuid järgmise kahe erandi korral on see funktsioon semantiliselt samaväärne [`mem::swap`]-iga:
///
///
/// * See töötab toorviitade asemel viidete asemel.
/// Kui viited on saadaval, tuleks eelistada [`mem::swap`]-i.
///
/// * Kaks osutatavat väärtust võivad kattuda.
/// Kui väärtused kattuvad, kasutatakse `x`-i mälu kattuvat piirkonda.
/// Seda näitab järgmine näide allpool.
///
/// # Safety
///
/// Käitumine on määratlemata, kui rikutakse mõnda järgmistest tingimustest:
///
/// * Nii `x` kui ka `y` peavad olema nii lugemiseks kui ka kirjutamiseks [valid].
///
/// * Nii `x` kui ka `y` peavad olema õigesti joondatud.
///
/// Pange tähele, et isegi kui `T`-l on suurus `0`, peavad osutid olema NULL-välised ja õigesti joondatud.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Kahe kattumatu piirkonna vahetamine:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // see on `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // see on `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Kahe kattuva piirkonna vahetamine:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // see on `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // see on `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Lõigu indeksid `1..3` kattuvad `x` ja `y` vahel.
///     // Mõistlikud tulemused oleksid nende jaoks `[2, 3]`, nii et indeksid `0..3` on `[1, 2, 3]` (sobivad `y`-ga enne `swap`-i);või et need oleksid `[0, 1]`, nii et indeksid `1..4` on `[0, 1, 2]` (vastavad `x`-le enne `swap`-i).
/////
///     // See rakendus on määratletud viimase valiku tegemiseks.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Andke endale tööks kriimuruumi.
    // Me ei pea tilkade pärast muretsema: `MaybeUninit` ei tee kukkumisel midagi.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Tehke vahetus OHUTUS: helistaja peab tagama, et `x` ja `y` kehtivad kirjutamise jaoks ja on õigesti joondatud.
    // `tmp` ei saa kattuda ei `x` ega `y`, kuna `tmp` eraldati virnale eraldi eraldatud objektina.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` ja `y` võivad kattuda
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Vahetab `count * size_of::<T>()` baiti kahe mälupiirkonna vahel, mis algavad punktidest `x` ja `y`.
/// Need kaks piirkonda ei tohi üksteisega kattuda.
///
/// # Safety
///
/// Käitumine on määratlemata, kui rikutakse mõnda järgmistest tingimustest:
///
/// * Mõlemad `x` ja `y` peavad olema nii loendamise kui kirjutamise korral arvuga [valid] *
///   suurus_of: :<T>() `baiti.
///
/// * Nii `x` kui ka `y` peavad olema õigesti joondatud.
///
/// * `x`-st algav mälupiirkond suurusega `count *
///   suurus_of: :<T>() `baidid ei tohi * kattuda sama suurusega `y`-st algava mälupiirkonnaga.
///
/// Pange tähele, et isegi kui tegelikult kopeeritud suurus (`count * size_of: :<T>()`) on `0`, osutid peavad olema NULL-välised ja õigesti joondatud.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Põhikasutus:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // OHUTUS: helistaja peab tagama, et `x` ja `y` on
    // kehtib kirjutamise korral ja õigesti joondatud.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Allpool olevast ploki optimeerimisest väiksemate tüüpide korral vahetage koodegeeni pessimiseerimise vältimiseks lihtsalt otse.
    //
    if mem::size_of::<T>() < 32 {
        // OHUTUS: helistaja peab tagama `x` ja `y` kehtivuse
        // kirjutuste jaoks, korralikult joondatud ja kattumatud.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // OHUTUS: helistaja peab järgima `swap_nonoverlapping`-i ohutuslepingut.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Siinkohal on simd kasutada x&y tõhusaks vahetamiseks.
    // Testimine näitab, et 32-baidise või 64-baidise vahetamine korraga on kõige tõhusam Inteli Haswell E protsessorite jaoks.
    // LLVM suudab paremini optimeerida, kui anname struktuurile #[repr(simd)], isegi kui me seda struktuuri otseselt ei kasuta.
    //
    //
    // FIXME repr(simd) katki emscriptenil ja redoksil
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Looge x&y läbi, kopeerides need korraga `Block`. Optimeerija peaks enamiku NB-tüüpide korral silmuse täielikult lahti rullima
    // Me ei saa loopi jaoks kasutada, kuna `range` implantaat kutsub `mem::swap` rekursiivselt
    //
    let mut i = 0;
    while i + block_size <= len {
        // Looge tühjendusruumina mõni initsialiseerimata mälu. `t`-i deklareerimine väldib virna joondamist, kui see silmus on kasutamata
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // OHUTUS: Nagu `i < len` ja helistaja peab tagama, et `x` ja `y` kehtivad
        // `len`-baitide puhul peavad `x + i` ja `y + i` olema kehtivad aadressid, mis täidavad `add`-i ohutuslepingut.
        //
        // Samuti peab helistaja tagama, et `x` ja `y` kehtivad kirjutamise korral, õigesti joondatud ja kattumatud, mis täidab `copy_nonoverlapping`-i ohutuslepingut.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Vaheta x&y baitide plokk, kasutades ajutise puhvrina t. Seda tuleks optimeerida tõhusateks SIMD-toiminguteks, kui see on saadaval
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Vahetage ülejäänud baidid
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // OHUTUS: vt eelmist ohutuskommentaari.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Liigutab `src` teravasse `dst`, tagastades eelmise `dst` väärtuse.
///
/// Kumbagi väärtust ei langeta.
///
/// See funktsioon on semantiliselt samaväärne [`mem::replace`]-iga, välja arvatud see, et see töötab toornäitajate asemel viidete asemel.
/// Kui viited on saadaval, tuleks eelistada [`mem::replace`]-i.
///
/// # Safety
///
/// Käitumine on määratlemata, kui rikutakse mõnda järgmistest tingimustest:
///
/// * `dst` peab olema nii lugemise kui ka kirjutamise puhul [valid].
///
/// * `dst` peavad olema korralikult joondatud.
///
/// * `dst` peab osutama `T`-tüüpi korralikult initsialiseeritud väärtusele.
///
/// Pange tähele, et isegi kui `T`-l on suurus `0`, peab kursor olema NULL-väline ja õigesti joondatud.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` oleks sama mõju, ilma et oleks vaja ohtlikku blokeerimist.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // OHUTUS: helistaja peab tagama, et `dst` kehtib
    // valatud muutuvale viitele (kehtib kirjutamise korral, joondatud, initsialiseeritud) ja ei saa `src`-i kattuda, kuna `dst` peab osutama eraldatud objektile.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // ei saa kattuda
    }
    src
}

/// Loeb väärtust `src`-ist ilma seda teisaldamata.See jätab `src`-is mälu muutmata.
///
/// # Safety
///
/// Käitumine on määratlemata, kui rikutakse mõnda järgmistest tingimustest:
///
/// * `src` peab lugemiste jaoks olema [valid].
///
/// * `src` peavad olema korralikult joondatud.Kui see pole nii, kasutage [`read_unaligned`]-i.
///
/// * `src` peab osutama `T`-tüüpi korralikult initsialiseeritud väärtusele.
///
/// Pange tähele, et isegi kui `T`-l on suurus `0`, peab kursor olema NULL-väline ja õigesti joondatud.
///
/// # Examples
///
/// Põhikasutus:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Rakendage [`mem::swap`] käsitsi:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Looge `tmp`-is väärtusest `a` biti kaupa koopia.
///         let tmp = ptr::read(a);
///
///         // Sel hetkel väljumine (kas selgesõnalise tagasipöördumise või funktsiooni kutsumise abil, mille panics) põhjustab `tmp`-i väärtuse languse, samal ajal kui `a` viitab endiselt samale väärtusele.
///         // See võib vallandada määratlemata käitumise, kui `T` pole `Copy`.
/////
/////
///
///         // Looge `a`-is väärtusest `b` biti kaupa koopia.
///         // See on ohutu, kuna muutlikud viited ei saa varjunime.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Nagu ülalpool, võib siit väljumine käivitada määratlemata käitumise, kuna samale väärtusele viitavad `a` ja `b`.
/////
///
///         // Liigutage `tmp` kausta `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` on teisaldatud (`write` võtab oma teise argumendi omandiõiguse), seega ei kaota siin midagi kaudselt.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Tagastatud väärtuse omandiõigus
///
/// `read` loob `T`-i bitipõhise koopia, olenemata sellest, kas `T` on [`Copy`].
/// Kui `T` pole [`Copy`], võib nii tagastatud väärtuse kui ka väärtuse `*src` kasutamine rikkuda mälu ohutust.
/// Pange tähele, et `*src`-ile määramine loetakse kasutuseks, kuna see üritab `* src`-is väärtust langetada.
///
/// [`write()`] saab kasutada andmete ülekirjutamiseks, ilma et need loobuksid.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` osutab nüüd samale alusmälule nagu `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // `s2`-ile määramine põhjustab selle algväärtuse languse.
///     // Sellest punktist kaugemale ei tohi `s`-i enam kasutada, kuna alusmälu on vabastatud.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // `s`-ile määramine põhjustab vana väärtuse uuesti langemise, mille tulemuseks on määratlemata käitumine.
/////
///     // s= String::from("bar");//VIGA
///
///     // `ptr::write` saab kasutada väärtuse ülekirjutamiseks ilma seda viskamata.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // OHUTUS: helistaja peab tagama, et `src` kehtib lugemiste jaoks.
    // `src` ei saa `tmp`-i kattuda, kuna `tmp` eraldati virnale eraldi eraldatud objektina.
    //
    //
    // Kuna me just kirjutasime `tmp`-i kehtiva väärtuse, on see garanteeritud korralikult initsialiseerimine.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Loeb väärtust `src`-ist ilma seda teisaldamata.See jätab `src`-is mälu muutmata.
///
/// Erinevalt [`read`]-ist töötab `read_unaligned` joondamata osutitega.
///
/// # Safety
///
/// Käitumine on määratlemata, kui rikutakse mõnda järgmistest tingimustest:
///
/// * `src` peab lugemiste jaoks olema [valid].
///
/// * `src` peab osutama `T`-tüüpi korralikult initsialiseeritud väärtusele.
///
/// Nagu [`read`], loob ka `read_unaligned` faili `T` bitipõhise koopia, olenemata sellest, kas `T` on [`Copy`].
/// Kui `T` ei ole [`Copy`], saab [violate memory safety][read-ownership] kasutada nii tagastatud väärtust kui ka väärtust `*src`-l.
///
/// Pange tähele, et isegi kui `T`-l on suurus `0`, ei tohi kursor olla NULL-väline.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## `packed` konstruktsioonidel
///
/// Praegu on võimatu luua tooreid näpunäiteid pakitud struktuuri joondamata väljadele.
///
/// Kui proovite luua `unaligned`-i struktuuriväljale toore osuti sellise avaldisega nagu `&packed.unaligned as *const FieldType`, luuakse enne joondamiseks kursoriks teisendamata vahepealne viide.
///
/// See, et see viide on ajutine ja kohe valatud, ei oma tähtsust, kuna koostaja loodab alati, et viited on õigesti joondatud.
/// Selle tulemusena põhjustab `&packed.unaligned as *const FieldType` kasutamine teie programmis viivitamatu* määratlemata käitumise *.
///
/// Näide sellest, mida mitte teha ja kuidas see on seotud `read_unaligned`-iga, on järgmine:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Siin proovime võtta 32-bitise täisarvu aadressi, mis pole joondatud.
///     let unaligned =
///         // Siin luuakse ajutine joondamata viide, mille tulemuseks on määratlemata käitumine, olenemata sellest, kas viidet kasutatakse või mitte.
/////
///         &packed.unaligned
///         // Toorele osutile ülekandmine ei aita;viga juhtus juba.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Otse juurdepääs joondamata väljadele nt `packed.unaligned`-iga on siiski ohutu.
///
///
///
///
///
///
// FIXME: Uuendage dokumente RFC #2582 ja sõprade tulemuste põhjal.
/// # Examples
///
/// Kasutamisväärtuse lugemine baidipuhvrist:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // OHUTUS: helistaja peab tagama, et `src` kehtib lugemiste jaoks.
    // `src` ei saa `tmp`-i kattuda, kuna `tmp` eraldati virnale eraldi eraldatud objektina.
    //
    //
    // Kuna me just kirjutasime `tmp`-i kehtiva väärtuse, on see garanteeritud korralikult initsialiseerimine.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Kirjutab mälu asukoha etteantud väärtusega üle vana väärtust lugemata või maha viskamata.
///
/// `write` ei viska `dst` sisu maha.
/// See on ohutu, kuid see võib lekitada eraldisi või ressursse, seega tuleks hoolitseda selle eest, et objekt ei kirjutataks üle, mis tuleks maha visata.
///
///
/// Lisaks ei lase see `src`-i alla.Semantiliselt liigutatakse `src` asukohta, millele `dst` osutab.
///
/// See sobib initsialiseerimata mälu initsialiseerimiseks või mälu ülekirjutamiseks, mis on varem olnud [`read`].
///
/// # Safety
///
/// Käitumine on määratlemata, kui rikutakse mõnda järgmistest tingimustest:
///
/// * `dst` peab kirjutuste jaoks olema [valid].
///
/// * `dst` peavad olema korralikult joondatud.Kui see pole nii, kasutage [`write_unaligned`]-i.
///
/// Pange tähele, et isegi kui `T`-l on suurus `0`, peab kursor olema NULL-väline ja õigesti joondatud.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Põhikasutus:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Rakendage [`mem::swap`] käsitsi:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Looge `tmp`-is väärtusest `a` biti kaupa koopia.
///         let tmp = ptr::read(a);
///
///         // Sel hetkel väljumine (kas selgesõnalise tagasipöördumise või funktsiooni kutsumise abil, mille panics) põhjustab `tmp`-i väärtuse languse, samal ajal kui `a` viitab endiselt samale väärtusele.
///         // See võib vallandada määratlemata käitumise, kui `T` pole `Copy`.
/////
/////
///
///         // Looge `a`-is väärtusest `b` biti kaupa koopia.
///         // See on ohutu, kuna muutlikud viited ei saa varjunime.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Nagu ülalpool, võib siit väljumine käivitada määratlemata käitumise, kuna samale väärtusele viitavad `a` ja `b`.
/////
///
///         // Liigutage `tmp` kausta `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` on teisaldatud (`write` võtab oma teise argumendi omandiõiguse), seega ei kaota siin midagi kaudselt.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Helistame otse sisemistele funktsioonidele, et vältida loodud koodis funktsioonikõnesid, kuna `intrinsics::copy_nonoverlapping` on ümbrisfunktsioon.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // OHUTUS: helistaja peab tagama, et `dst` kehtib kirjutuste jaoks.
    // `dst` ei saa `src`-i kattuda, kuna helistajal on muudetav juurdepääs `dst`-ile, samas kui `src` kuulub sellele funktsioonile.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Kirjutab mälu asukoha etteantud väärtusega üle vana väärtust lugemata või maha viskamata.
///
/// Erinevalt [`write()`]-st võib kursor olla joondamata.
///
/// `write_unaligned` ei viska `dst` sisu maha.See on ohutu, kuid see võib lekitada eraldisi või ressursse, seega tuleks hoolitseda selle eest, et objekt ei kirjutataks üle, mis tuleks maha visata.
///
/// Lisaks ei lase see `src`-i alla.Semantiliselt liigutatakse `src` asukohta, millele `dst` osutab.
///
/// See sobib initsialiseerimata mälu initsialiseerimiseks või varem [`read_unaligned`]-iga loetud mälu ülekirjutamiseks.
///
/// # Safety
///
/// Käitumine on määratlemata, kui rikutakse mõnda järgmistest tingimustest:
///
/// * `dst` peab kirjutuste jaoks olema [valid].
///
/// Pange tähele, et isegi kui `T`-l on suurus `0`, ei tohi kursor olla NULL-väline.
///
/// [valid]: self#safety
///
/// ## `packed` konstruktsioonidel
///
/// Praegu on võimatu luua tooreid näpunäiteid pakitud struktuuri joondamata väljadele.
///
/// Kui proovite luua `unaligned`-i struktuuriväljale toore osuti sellise avaldisega nagu `&packed.unaligned as *const FieldType`, luuakse enne joondamiseks kursoriks teisendamata vahepealne viide.
///
/// See, et see viide on ajutine ja kohe valatud, ei oma tähtsust, kuna koostaja loodab alati, et viited on õigesti joondatud.
/// Selle tulemusena põhjustab `&packed.unaligned as *const FieldType` kasutamine teie programmis viivitamatu* määratlemata käitumise *.
///
/// Näide sellest, mida mitte teha ja kuidas see on seotud `write_unaligned`-iga, on järgmine:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Siin proovime võtta 32-bitise täisarvu aadressi, mis pole joondatud.
///     let unaligned =
///         // Siin luuakse ajutine joondamata viide, mille tulemuseks on määratlemata käitumine, olenemata sellest, kas viidet kasutatakse või mitte.
/////
///         &mut packed.unaligned
///         // Toorele osutile ülekandmine ei aita;viga juhtus juba.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Otse juurdepääs joondamata väljadele nt `packed.unaligned`-iga on siiski ohutu.
///
///
///
///
///
///
///
///
///
// FIXME: Uuendage dokumente RFC #2582 ja sõprade tulemuste põhjal.
/// # Examples
///
/// Kirjutage baidipuhvrisse usize väärtus:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // OHUTUS: helistaja peab tagama, et `dst` kehtib kirjutuste jaoks.
    // `dst` ei saa `src`-i kattuda, kuna helistajal on muudetav juurdepääs `dst`-ile, samas kui `src` kuulub sellele funktsioonile.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Helistame sisemisele otse, et vältida loodud koodis funktsioonikõnesid.
        intrinsics::forget(src);
    }
}

/// Teeb väärtuse kõikuva lugemise `src`-ist ilma seda liigutamata.See jätab `src`-is mälu muutmata.
///
/// Volatiilsete toimingute eesmärk on toimida I/O-mälus ja kompilaator ei saa neid teiste lenduvate toimingute korral kindlasti valida ega järjestada.
///
/// # Notes
///
/// Rust-l pole praegu rangelt ja formaalselt määratletud mälumudelit, mistõttu "volatile" siinkohal täpne semantika võib aja jooksul muutuda.
/// Nagu öeldud, lõpeb semantika peaaegu alati [C11's definition of volatile][c11]-iga üsna sarnaselt.
///
/// Kompilaator ei tohiks muuta lendmälu toimingute suhtelist järjekorda ega arvu.
/// Lendmälu toimingud nullsuuruste tüüpide puhul (nt kui nulli suuruse tüüp edastatakse `read_volatile`-le) on noops ja neid võidakse ignoreerida.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Käitumine on määratlemata, kui rikutakse mõnda järgmistest tingimustest:
///
/// * `src` peab lugemiste jaoks olema [valid].
///
/// * `src` peavad olema korralikult joondatud.
///
/// * `src` peab osutama `T`-tüüpi korralikult initsialiseeritud väärtusele.
///
/// Nagu [`read`], loob ka `read_volatile` faili `T` bitipõhise koopia, olenemata sellest, kas `T` on [`Copy`].
/// Kui `T` ei ole [`Copy`], saab [violate memory safety][read-ownership] kasutada nii tagastatud väärtust kui ka väärtust `*src`-l.
/// Kuid mitte ["Kopeeri"] tüüpi salvestamine kõikuvasse mällu on peaaegu kindlasti vale.
///
/// Pange tähele, et isegi kui `T`-l on suurus `0`, peab kursor olema NULL-väline ja õigesti joondatud.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Nii nagu C-s, ei mõjuta operatsiooni muutlikkus küsimusi, mis hõlmavad samaaegset juurdepääsu mitmest lõimest.Lenduvad juurdepääsud käituvad selles osas täpselt nagu mitteaatomjuurdepääsud.
///
/// Eelkõige on määratlemata käitumine võistlus `read_volatile` ja mis tahes samasse asukohta kirjutamise operatsioonide vahel.
///
/// # Examples
///
/// Põhikasutus:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Pole paanikat, et koodegeni mõju väiksem oleks.
        abort();
    }
    // OHUTUS: helistaja peab järgima `volatile_load`-i ohutuslepingut.
    unsafe { intrinsics::volatile_load(src) }
}

/// Teeb mälu asukoha volatiilse kirjutamise etteantud väärtusega ilma vana väärtust lugemata või viskamata.
///
/// Volatiilsete toimingute eesmärk on toimida I/O-mälus ja kompilaator ei saa neid teiste lenduvate toimingute korral kindlasti valida ega järjestada.
///
/// `write_volatile` ei viska `dst` sisu maha.See on ohutu, kuid see võib lekitada eraldisi või ressursse, seega tuleks hoolitseda selle eest, et objekt ei kirjutataks üle, mis tuleks maha visata.
///
/// Lisaks ei lase see `src`-i alla.Semantiliselt liigutatakse `src` asukohta, millele `dst` osutab.
///
/// # Notes
///
/// Rust-l pole praegu rangelt ja formaalselt määratletud mälumudelit, mistõttu "volatile" siinkohal täpne semantika võib aja jooksul muutuda.
/// Nagu öeldud, lõpeb semantika peaaegu alati [C11's definition of volatile][c11]-iga üsna sarnaselt.
///
/// Kompilaator ei tohiks muuta lendmälu toimingute suhtelist järjekorda ega arvu.
/// Lendmälu toimingud nullsuuruste tüüpide puhul (nt kui nulli suuruse tüüp edastatakse `write_volatile`-le) on noops ja neid võidakse ignoreerida.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Käitumine on määratlemata, kui rikutakse mõnda järgmistest tingimustest:
///
/// * `dst` peab kirjutuste jaoks olema [valid].
///
/// * `dst` peavad olema korralikult joondatud.
///
/// Pange tähele, et isegi kui `T`-l on suurus `0`, peab kursor olema NULL-väline ja õigesti joondatud.
///
/// [valid]: self#safety
///
/// Nii nagu C-s, ei mõjuta operatsiooni muutlikkus küsimusi, mis hõlmavad samaaegset juurdepääsu mitmest lõimest.Lenduvad juurdepääsud käituvad selles osas täpselt nagu mitteaatomjuurdepääsud.
///
/// Eelkõige on võistlus `write_volatile` ja mis tahes muu toimingu (lugemine või kirjutamine) vahel samas kohas määratlemata käitumine.
///
/// # Examples
///
/// Põhikasutus:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Pole paanikat, et koodegeni mõju väiksem oleks.
        abort();
    }
    // OHUTUS: helistaja peab järgima `volatile_store`-i ohutuslepingut.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Joondage kursor `p`.
///
/// Arvutage nihe (`stride` sammu elementidena), mis tuleb rakendada kursorile `p`, nii et kursor `p` oleks joondatud `a`-iga.
///
/// Note: See rakendus on hoolikalt kohandatud mitte panic-le.Selle jaoks on UB panic.
/// Ainus reaalne muudatus, mida siin saab teha, on `INV_TABLE_MOD_16` ja sellega seotud konstantide muutmine.
///
/// Kui otsustame kunagi teha võimaluse nimetada `a`-ga olemuslikku, mis ei ole kahe jõud, on tõenäoliselt mõistlikum vahetada lihtsalt naiivse rakenduse asemel, mitte proovida seda kohandada, et seda muudatust kohandada.
///
///
/// Kõik küsimused lähevad aadressile@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Nende olemuste otsene kasutamine parandab koodegeeni oluliselt opt-tasemel <=
    // 1, kus nende operatsioonide meetodiversioonid pole joondatud.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Arvutage `x` modulo `m` multiplikatiivne modulaarne pöördväärtus.
    ///
    /// See juurutus on kohandatud `align_offset`-i jaoks ja sellel on järgmised eeldused:
    ///
    /// * `m` on kahe jõud;
    /// * `x < m`; (kui `x ≥ m`, sisestage selle asemel `x % m`)
    ///
    /// Selle funktsiooni rakendamine ei tohi olla panic.Kunagi.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Mitmekordne modulaarne pöördlauamoodul 2=16.
        ///
        /// Pange tähele, et see tabel ei sisalda väärtusi, kus inverset pole olemas (st `0⁻¹ mod 16`, `2⁻¹ mod 16` jne puhul)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo, millele `INV_TABLE_MOD_16` on mõeldud.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // OHUTUS: `m` peab olema kahe võimsus, seega nullist erinev.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Me kordame "up"-i järgmise valemi abil:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // kuni 2²ⁿ ≥ m.Siis saame redutseerida soovitud `m`-ni, võttes tulemuse `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Pange tähele, et siin kasutame pakkimisoperatsioone tahtlikult-algses valemis kasutatakse näiteks lahutamist `mod n`.
                // Täiesti hea on teha neile hoopis `mod usize::MAX`, sest tulemuse `mod n` võtame nagunii lõpus.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // OHUTUS: `a` on kahe võimsus, seega nullist erinev.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` juhtumit saab arvutada lihtsamalt `-p (mod a)`-i kaudu, kuid see takistab LLVM-i võimalust valida juhiseid nagu `lea`.Selle asemel arvutame
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // mis jaotab toiminguid kandevõime ümber, kuid pessimiseerib `and`-i piisavalt, et LLVM saaks kasutada erinevaid teadaolevaid optimeerimisi.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Juba joondatud.Jah!
        return 0;
    } else if stride == 0 {
        // Kui kursor ei ole joondatud ja element on nullsuur, siis ei joondata kunagi ühtegi elementide hulka kursorit.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // OHUTUS: a on kahe võimsus, seega nullist erinev.stride==0 juhtumit käsitletakse eespool.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // OHUTUS: gcdpow on ülemise piiriga, mis on maksimaalselt bittide arv usize'is.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // OHUTUS: gcd on alati suurem või võrdne 1-ga.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // See branch lahendab järgmise lineaarse kongruentsivõrrandi:
        //
        // ` p + so = 0 mod a `
        //
        // `p` siin on kursori väärtus `s`, `T` samm, X-nihe nihkes `T`s ja `a`, soovitud joondus.
        //
        // Kui `g = gcd(a, s)` ja ülaltoodud tingimus väidavad, et `p` jagub ka `g`-ga, võime tähistada `a' = a/g`, `s' = s/g`, `p' = p/g`, siis muutub see samaväärseks:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Esimene termin on "the relative alignment of `p` to `a`" (jagatud `g`-ga), teine termin "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (jagatud jälle `g`-ga).
        //
        // Jaotamine `g`-ga on vajalik selleks, et muuta pöördvorm hästi vormituks, kui `a` ja `s` ei ole kaaspraimitavad.
        //
        // Pealegi pole selle lahuse tulemuseks "minimal", seega on vaja võtta tulemus `o mod lcm(s, a)`.Saame `lcm(s, a)` asendada lihtsalt `a'`-ga.
        //
        //
        //
        //
        //

        // OHUTUS: `gcdpow` ülemine piir ei ületa `a`-s olevate 0-bitiste arvude arvu.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // OHUTUS: `a2` pole nullist erinev.`a` nihutamine `gcdpow` võrra ei saa ühtegi seatud bitti välja nihutada
        // `a`-is (millest tal on täpselt üks).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // OHUTUS: `gcdpow` ülemine piir ei ületa `a`-s olevate 0-bitiste arvude arvu.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // OHUTUS: `gcdpow`-i ülemine piir ei ole suurem kui 0-biti lõpus olev arv
        // `a`.
        // Lisaks ei saa lahutamine ületada, sest `a2 = a >> gcdpow` on alati rangelt suurem kui `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // OHUTUS: `a2` on kahe võim, nagu eespool tõestatud.`s2` on rangelt väiksem kui `a2`
        // kuna `(s % a) >> gcdpow` on rangelt väiksem kui `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Ei saa üldse joondada.
    usize::MAX
}

/// Võrdleb võrdõiguslikkuse tooreid näpunäiteid.
///
/// See on sama mis operaatori `==` kasutamine, kuid vähem üldine:
/// argumendid peavad olema `*const T`-i toored näpunäited, mitte midagi, mis rakendab `PartialEq`-i.
///
/// Seda saab kasutada, et võrrelda `&T`-viiteid (mis kaudselt sundivad `*const T`-i) nende aadressi järgi, selle asemel, et võrrelda neile osutatavaid väärtusi (mida teeb `PartialEq for &T`-i juurutamine).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Viilusid võrreldakse ka nende pikkuse (rasvaviidad) järgi:
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits-i võrreldakse ka nende rakendamisega:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Osutajatel on võrdne aadress.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Objektidel on võrdne aadress, kuid `Trait`-l on erinevad rakendused.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // `*const u8`-i viite teisendamine võrdleb aadressi.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash toores pointer.
///
/// Seda saab kasutada `&T`-i viite räsimiseks (mis kaudselt sundib `*const T`-i) selle aadressi järgi, mitte selle väärtuse järgi, millele see osutab (mida teeb rakendus `Hash for &T`).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Funktsioonide osutajate implikatsioonid
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: AVR-i jaoks on vajalik kasutatav vahepealne näitleja
                // nii, et lähtefunktsiooniosuti aadressiruum säiliks lõplikus funktsioonikursoris.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: AVR-i jaoks on vajalik kasutatav vahepealne näitleja
                // nii, et lähtefunktsiooniosuti aadressiruum säiliks lõplikus funktsioonikursoris.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // 0 parameetriga variadic-funktsiooni pole
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Looge `const` töötlemata kursor kohale ilma vaheviidet loomata.
///
/// `&`/`&mut`-iga viite loomine on lubatud ainult siis, kui kursor on õigesti joondatud ja osutab lähtestatud andmetele.
/// Juhtudel, kui need nõuded ei kehti, tuleks selle asemel kasutada tooreid näpunäiteid.
/// Kuid `&expr as *const _` loob viite enne toores osuti valamist ja selle viite suhtes kehtivad samad reeglid nagu kõigile teistele viidetele.
///
/// Selle makro abil saab luua toore kursori *ilma* viite loomata.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` tekitaks joondamata viite ja oleks seega määratlemata käitumine!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Looge `mut` töötlemata kursor kohale ilma vaheviidet loomata.
///
/// `&`/`&mut`-iga viite loomine on lubatud ainult siis, kui kursor on õigesti joondatud ja osutab lähtestatud andmetele.
/// Juhtudel, kui need nõuded ei kehti, tuleks selle asemel kasutada tooreid näpunäiteid.
/// Kuid `&mut expr as *mut _` loob viite enne toores osuti valamist ja selle viite suhtes kehtivad samad reeglid nagu kõigile teistele viidetele.
///
/// Selle makro abil saab luua toore kursori *ilma* viite loomata.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` tekitaks joondamata viite ja oleks seega määratlemata käitumine!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` sunnib viite loomise asemel välja kopeerima.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}