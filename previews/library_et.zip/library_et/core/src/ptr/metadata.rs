#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Annab osuti metaandmete tüübile mis tahes osutatava tüübi jaoks.
///
/// # Kursori metaandmed
///
/// Rust töötlemata kursori tüüpe ja viite tüüpe võib pidada kaheks osaks:
/// andmekursor, mis sisaldab väärtuse mäluaadressi ja mõningaid metaandmeid.
///
/// Nii staatilise suurusega tüüpide puhul (mis rakendavad `Sized` traits) kui ka tüüpide `extern` puhul on osutid väidetavalt õhukesed: metaandmed on nullsuurused ja nende tüüp on `()`.
///
///
/// [dynamically-sized types][dst]-i osutajad on väidetavalt "laiad" või "paksud", neil on nullist erinevad metaandmed:
///
/// * Struktuuride puhul, mille viimane väli on DST, on metaandmed viimase välja metaandmed
/// * Tüübi `str` puhul on metaandmed pikkus baitides kui `usize`
/// * Selliste viilutüüpide puhul nagu `[T]` on metaandmete pikkus üksustes `usize`
/// * trait objektide nagu `dyn SomeTrait` korral on metaandmed [`DynMetadata<Self>`][DynMetadata] (nt `DynMetadata<dyn SomeTrait>`)
///
/// future-is võib keel Rust omandada uut tüüpi tüüpe, millel on erinevad osuti metaandmed.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Selle trait-i punkt on `Metadata`-ga seotud tüüp, milleks on `()` või `usize` või `DynMetadata<_>`, nagu eespool kirjeldatud.
/// Seda rakendatakse automaatselt igat tüüpi.
/// Võib eeldada, et seda rakendatakse üldises kontekstis, isegi ilma vastava sidemeta.
///
/// # Usage
///
/// Toorviiturid saab nende [`to_raw_parts`]-meetodiga lahustada andme-aadressi ja metaandmete komponentideks.
///
/// Alternatiivina saab [`metadata`]-funktsiooniga eraldada ainult metaandmeid.
/// Viite saab [`metadata`]-le edastada ja kaudselt sundida.
///
/// (possibly-wide)-osuti saab selle aadressi ja metaandmete põhjal uuesti kokku panna [`from_raw_parts`] või [`from_raw_parts_mut`] abil.
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Metaandmete tüüp osutites ja viited `Self`-le.
    #[lang = "metadata_type"]
    // NOTE: Hoidke `static_assert_expected_bounds_for_metadata`-is trait bounds-i
    //
    // `library/core/src/ptr/metadata.rs`-is sünkroonis siinolevatega:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Selle trait varjunime rakendavate vihjete tüübid on "õhukesed".
///
/// See hõlmab staatiliselt suurusega tüüpe ja `extern` tüüpe.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: kas see ei stabiliseeru enne, kui trait varjunimed on keeles stabiilsed?
pub trait Thin = Pointee<Metadata = ()>;

/// Eemaldage osuti metaandmete komponent.
///
/// Tüüpide `*mut T`, `&T` või `&mut T` väärtused saab otse sellele funktsioonile edastada, kuna need sunnivad kaudselt `* const T`-i.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // OHUTUS: Väärtusele pääsemine liidult `PtrRepr` on turvaline, kuna * const T
    // ja PtrComponents<T>on ühesugused mäluplaanid.
    // Selle garantii saab anda ainult std.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Moodustab andmeaadressi ja metaandmete hulgast (possibly-wide) toore osuti.
///
/// See funktsioon on ohutu, kuid tagastatud kursor pole tingimata ohutu.
/// Viilude kohta vaadake ohutusnõudeid [`slice::from_raw_parts`] dokumentatsioonist.
/// Objektide trait puhul peavad metaandmed tulema kursorilt samale aluseks olevale eraldatud tüübile.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // OHUTUS: Väärtusele pääsemine liidult `PtrRepr` on turvaline, kuna * const T
    // ja PtrComponents<T>on ühesugused mäluplaanid.
    // Selle garantii saab anda ainult std.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Teostab sama funktsionaalsust nagu [`from_raw_parts`], välja arvatud see, et tagastatakse töötlemata `*mut`-osuti, erinevalt toorest `* const`-osutist.
///
///
/// Lisateavet leiate [`from_raw_parts`] dokumentatsioonist.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // OHUTUS: Väärtusele pääsemine liidult `PtrRepr` on turvaline, kuna * const T
    // ja PtrComponents<T>on ühesugused mäluplaanid.
    // Selle garantii saab anda ainult std.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// `T: Copy`-i sidumise vältimiseks on vajalik käsitsi implantaat.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// `T: Clone`-i sidumise vältimiseks on vajalik käsitsi implantaat.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// `Dyn = dyn SomeTrait` trait objektitüübi metaandmed.
///
/// See on osutus vtable (virtuaalse kõnetabeli) kursorile, mis esindab kogu vajalikku teavet trait objekti sees salvestatud betoonitüübi manipuleerimiseks.
/// See sisaldab eelkõige järgmist:
///
/// * tüübi suurus
/// * tüübi joondamine
/// * osuti tüübi `drop_in_place` implikatsioonile (võib olla tavaliste vanade andmete puhul keelatud)
/// * viitab kõigile meetoditele trait tüübi rakendamiseks
///
/// Pange tähele, et esimesed kolm on erilised, kuna need on vajalikud mis tahes trait-objekti eraldamiseks, paigutamiseks ja jaotamiseks.
///
/// Seda struktuuri on võimalik nimetada tüübiparameetriga, mis ei ole objekt `dyn` trait (näiteks `DynMetadata<u64>`), kuid mitte selle struktuuri tähenduslikku väärtust.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Kõigi vtabelite ühine eesliide.Sellele järgnevad funktsiooninupud trait meetodite jaoks.
///
/// `DynMetadata::size_of` jms privaatne rakenduse detail
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Tagastab selle vtable-ga seotud tüübi suuruse.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Tagastab selle vtable-ga seotud tüübi joonduse.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Tagastab suuruse ja joonduse koos `Layout`-iga
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // OHUTUS: koostaja andis selle vtable betooni Rust tüübi jaoks välja
        // on teadaolevalt kehtiv paigutus.Sama põhjendus nagu `Layout::for_value`-is.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// `Dyn: $Trait`-i piiride vältimiseks on vaja käsitsi implantaate.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}