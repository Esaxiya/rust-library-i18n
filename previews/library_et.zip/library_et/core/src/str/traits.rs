//! `str`-i Trait-i rakendused.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Rakendab stringide järjestust.
///
/// Stringid on [lexicographically](Ord#lexicographical-comparison) järjestatud nende baitide väärtuste järgi.
/// See tellib Unicode'i koodipunktid vastavalt nende positsioonidele kooditabelites.
/// See ei pruugi olla sama mis "alphabetical"-i järjekord, mis varieerub keelte ja lokaadi järgi.
/// Stringide sortimine vastavalt kultuuriliselt aktsepteeritud standarditele nõuab lokaadispetsiifilisi andmeid, mis jäävad väljapoole `str` tüüpi reguleerimisala.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Rakendab stringide võrdlustoiminguid.
///
/// Stringi võrreldakse [lexicographically](Ord#lexicographical-comparison)-ga nende baitide väärtuste järgi.
/// Nii võrreldakse Unicode'i koodipunkte vastavalt nende positsioonidele kooditabelites.
/// See ei pruugi olla sama mis "alphabetical"-i järjekord, mis varieerub keelte ja lokaadi järgi.
/// Stringide võrdlemine kultuuriliselt aktsepteeritud standardite järgi nõuab lokaadispetsiifilisi andmeid, mis jäävad väljapoole `str` tüüpi reguleerimisala.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Rakendab alamstringide viilutamist süntaksiga `&self[..]` või `&mut self[..]`.
///
/// Tagastab kogu stringi viilu, st tagastab `&self` või `&mut self`.Samaväärne `&self'iga [0 ..
/// len] `või`&vaigista ise [0 ..
/// len]`.
/// Erinevalt teistest indekseerimistoimingutest ei saa see kunagi olla panic.
///
/// See toiming on *O*(1).
///
/// Enne 1.20.0-i toetasid neid indekseerimistoiminguid `Index` ja `IndexMut` otsene rakendamine.
///
/// Samaväärne `&self[0 .. len]` või `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Rakendab alamstringide viilutamist süntaksiga `&self[begin .. end]` või `&mut self[begin .. end]`.
///
/// Tagastab antud stringi viilu baitide vahemikust [`start`, `end`).
///
/// See toiming on *O*(1).
///
/// Enne 1.20.0-i toetasid neid indekseerimistoiminguid `Index` ja `IndexMut` otsene rakendamine.
///
/// # Panics
///
/// Panics, kui `begin` või `end` ei osuta märgi algbaidi nihkele (nagu määratleb `is_char_boundary`), kui `begin > end` või `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // need on panic:
/// // 2. bait asub `ö`-s:
/// // &s [2 .3];
///
/// // 8. bait asub `老`&s piires [1 ..
/// // 8];
///
/// // bait 100 on väljaspool stringi&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // OHUTUS: lihtsalt kontrollisite, kas `start` ja `end` on söepiiril,
            // ja me edastame ohutu võrdlusaluse, seega on ka tagastusväärtus üks.
            // Kontrollisime ka söe piire, nii et see kehtib UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // OHUTUS: kontrollige lihtsalt, kas `start` ja `end` on söepiiril.
            // Me teame, et kursor on ainulaadne, kuna saime selle `slice`-ist.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // OHUTUS: helistaja tagab, et `self` on `slice` piirides
        // mis vastab kõigile `add`-i tingimustele.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // OHUTUS: vaadake `get_unchecked` kommentaare.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary kontrollib, kas indeks on asukohas [0, .len()] ei saa XLLX-i uuesti kasutada nagu ülal, NLL-i probleemide tõttu
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // OHUTUS: lihtsalt kontrollisite, kas `start` ja `end` on söepiiril,
            // ja me edastame ohutu võrdlusaluse, seega on ka tagastusväärtus üks.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Rakendab alamstringide viilutamist süntaksiga `&self[.. end]` või `&mut self[.. end]`.
///
/// Tagastab antud stringi viilu baitide vahemikust ["0", `end`).
/// Samaväärne `&self[0 .. end]` või `&mut self[0 .. end]`.
///
/// See toiming on *O*(1).
///
/// Enne 1.20.0-i toetasid neid indekseerimistoiminguid `Index` ja `IndexMut` otsene rakendamine.
///
/// # Panics
///
/// Panics, kui `end` ei osuta märgi algbaidi nihkele (nagu määratletud `is_char_boundary`-ga) või kui `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // OHUTUS: lihtsalt kontrollisite, kas `end` on söepiiril,
            // ja me edastame ohutu võrdlusaluse, seega on ka tagastusväärtus üks.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // OHUTUS: lihtsalt kontrollisite, kas `end` on söepiiril,
            // ja me edastame ohutu võrdlusaluse, seega on ka tagastusväärtus üks.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // OHUTUS: lihtsalt kontrollisite, kas `end` on söepiiril,
            // ja me edastame ohutu võrdlusaluse, seega on ka tagastusväärtus üks.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Rakendab alamstringide viilutamist süntaksiga `&self[begin ..]` või `&mut self[begin ..]`.
///
/// Tagastab antud stringi viilu baitide vahemikust [`start`, `len`).Võrdne `&self'iga [algab ..
/// len] `või`&mut ise [alusta ..
/// len]`.
///
/// See toiming on *O*(1).
///
/// Enne 1.20.0-i toetasid neid indekseerimistoiminguid `Index` ja `IndexMut` otsene rakendamine.
///
/// # Panics
///
/// Panics, kui `begin` ei osuta märgi algbaidi nihkele (nagu määratletud `is_char_boundary`-ga) või kui `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // OHUTUS: lihtsalt kontrollisite, kas `start` on söepiiril,
            // ja me edastame ohutu võrdlusaluse, seega on ka tagastusväärtus üks.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // OHUTUS: lihtsalt kontrollisite, kas `start` on söepiiril,
            // ja me edastame ohutu võrdlusaluse, seega on ka tagastusväärtus üks.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // OHUTUS: helistaja tagab, et `self` on `slice` piirides
        // mis vastab kõigile `add`-i tingimustele.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // OHUTUS: identne `get_unchecked`-iga.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // OHUTUS: lihtsalt kontrollisite, kas `start` on söepiiril,
            // ja me edastame ohutu võrdlusaluse, seega on ka tagastusväärtus üks.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Rakendab alamstringide viilutamist süntaksiga `&self[begin ..= end]` või `&mut self[begin ..= end]`.
///
/// Tagastab antud stringi osa baidivahemikust [`begin`, `end`].Samaväärne `&self [begin .. end + 1]` või `&mut self[begin .. end + 1]`, välja arvatud juhul, kui `end` on `usize` maksimaalse väärtusega.
///
/// See toiming on *O*(1).
///
/// # Panics
///
/// Panics, kui `begin` ei osuta tähemärgi algbaidi nihkele (nagu määratletud `is_char_boundary`-ga), kui `end` ei osuta märgi lõppbaidi nihkele (`end + 1` on kas algbaidi nihe või võrdne `len`-ga), kui `begin > end` või kui `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // OHUTUS: helistaja peab järgima `get_unchecked`-i ohutuslepingut.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // OHUTUS: helistaja peab järgima `get_unchecked_mut`-i ohutuslepingut.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Rakendab alamstringide viilutamist süntaksiga `&self[..= end]` või `&mut self[..= end]`.
///
/// Tagastab antud stringi viilu baidivahemikust [0, `end`].
/// Samaväärne `&self [0 .. end + 1]`-ga, välja arvatud juhul, kui `end`-l on `usize`-i maksimaalne väärtus.
///
/// See toiming on *O*(1).
///
/// # Panics
///
/// Panics, kui `end` ei osuta märgi lõppbaidi nihkele (`end + 1` on kas algbaidi nihe vastavalt `is_char_boundary` määratlusele või võrdne `len`-ga) või kui `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // OHUTUS: helistaja peab järgima `get_unchecked`-i ohutuslepingut.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // OHUTUS: helistaja peab järgima `get_unchecked_mut`-i ohutuslepingut.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Sõeluge stringist väärtus
///
/// `FromStr`i meetodit [`from_str`] kasutatakse sageli kaudselt, läbi meetodi [`str`] [`parse`].
/// Näidete saamiseks vaadake ["parse"] dokumentatsiooni.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` tal pole eluaegset parameetrit ja seega saate sõeluda ainult tüüpe, mis ise eluaegset parameetrit ei sisalda.
///
/// Teisisõnu, saate `i32`-i `FromStr`-iga sõeluda, kuid mitte `&i32`-i.
/// Võite sõeluda struktuuri, mis sisaldab `i32`-i, kuid mitte sellist, mis sisaldab `&i32`-i.
///
/// # Examples
///
/// `FromStr`-i põhiline juurutamine näites `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Seotud tõrge, mille saab sõelumisel tagastada.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Sõelub seda tüüpi väärtuse tagastamiseks stringi `s`.
    ///
    /// Kui sõelumine õnnestub, tagastage väärtus [`Ok`] sees. Vastasel juhul, kui string on valesti vormindatud, tagastage sisemisele [`Err`]-le omane tõrge.
    /// Veatüüp on spetsiifiline trait rakendamisele.
    ///
    /// # Examples
    ///
    /// Põhikasutus `FromStr`-ga, tüüp, mis rakendab `FromStr`-i:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Sõeluge `bool` stringist.
    ///
    /// Saab `Result<bool, ParseBoolError>`, sest `s` võib tegelikult olla parseldatav või mitte.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Pange tähele, et paljudel juhtudel on `.parse()`-i meetod `.parse()` õigem.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}