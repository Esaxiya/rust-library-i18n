//! Määrab massiivide jaoks `IntoIter`-i omandis oleva iteraatori.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Mitteväärtuslik kordaja [array].
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// See on massiiv, mida me kordame.
    ///
    /// Elemendid indeksiga `i`, kus `alive.start <= i < alive.end`, pole veel välja antud ja need on kehtivad massiivi kirjed.
    /// Indeksitega `i < alive.start` või `i >= alive.end` elemendid on juba välja antud ja neile ei tohi enam juurde pääseda!Need surnud elemendid võivad olla isegi täiesti initsialiseerimata olekus!
    ///
    ///
    /// Seega on invariandid järgmised:
    /// - `data[alive]` on elus (st sisaldab kehtivaid elemente)
    /// - `data[..alive.start]` ja `data[alive.end..]` on surnud (st elemendid olid juba loetud ja neid ei tohi enam puudutada!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// `data`-i elemendid, mida pole veel saadud.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Loob antud iteraatori üle antud `array`.
    ///
    /// *Märkus*: see meetod võib future-is olla pärast [`IntoIterator` is implemented for arrays][array-into-iter]-i aegunud.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // `value` tüüp on siin `i32`, mitte `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // OHUTUS: siinne muundamine on tegelikult ohutu.`MaybeUninit`-i dokumendid
        // promise:
        //
        // > `MaybeUninit<T>` on tagatud sama suuruse ja joondusega
        // > kui `T`.
        //
        // Dokumendid näitavad isegi ülekannet massiivi `MaybeUninit<T>` massiivist `T`.
        //
        //
        // Sellega rahuldab see initsialiseerimine invariante.

        // FIXME(LukasKalbertodt): kasutage siin tegelikult `mem::transmute`-i, kui see töötab konst genericidega:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Seni saame `mem::transmute_copy`-iga luua bitipõhise koopia erinevat tüüpi, seejärel unustada `array`, nii et see ei kukuks.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Tagastab muutumatu osa kõigist elementidest, mida pole veel saadud.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // OHUTUS: Me teame, et kõik `alive`-i elemendid on korralikult lähtestatud.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Tagastab muudetava osa kõigist elementidest, mida pole veel saadud.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // OHUTUS: Me teame, et kõik `alive`-i elemendid on korralikult lähtestatud.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Hankige järgmine indeks esiküljest.
        //
        // `alive.start` suurendamine 1 võrra hoiab `alive`-i muutumatut.
        // Kuid selle muudatuse tõttu pole lühikese aja jooksul elus tsoon enam `data[alive]`, vaid `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Loe massiivist elementi.
            // OHUTUS: `idx` on indeks endises "alive" piirkonnas
            // massiiv.Selle elemendi lugemine tähendab, et `data[idx]`-i peetakse praegu surnuks (st ärge puudutage).
            // Kuna `idx` oli elutsooni algus, on elus tsoon nüüd uuesti `data[alive]`, taastades kõik invariandid.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Hankige järgmine indeks tagantpoolt.
        //
        // `alive.end` vähendamine 1 võrra hoiab muutumatut `alive` osas.
        // Kuid selle muudatuse tõttu pole lühikese aja jooksul elus tsoon enam `data[alive]`, vaid `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Loe massiivist elementi.
            // OHUTUS: `idx` on indeks endises "alive" piirkonnas
            // massiiv.Selle elemendi lugemine tähendab, et `data[idx]`-i peetakse praegu surnuks (st ärge puudutage).
            // Kuna `idx` oli elutsooni lõpp, on elus tsoon nüüd uuesti `data[alive]`, taastades kõik invariandid.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // OHUTUS: See on ohutu: `as_mut_slice` tagastab täpselt alamviilu
        // elementidest, mida pole veel välja tõstetud ja mis jäävad alles.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Ei hakka kunagi voolama muutumatu `elus.alusta <=tõttu
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Kordaja teatab õige pikkuse.
// "alive"-i elementide arv (mis ikkagi saadakse) on vahemiku `alive` pikkus.
// Selle vahemiku pikkust vähendatakse kas `next` või `next_back`.
// Nendes meetodites vähendatakse seda alati 1-ga, kuid ainult juhul, kui tagastatakse `Some(_)`.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Pange tähele, et me ei pea tegelikult vastama täpselt samale elusale vahemikule, nii et me võime lihtsalt kloonida 0-nihkesse, olenemata sellest, kus `self` asub.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Kloonige kõik elusad elemendid.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Kirjutage kloon uude massiivi, seejärel värskendage selle elusat vahemikku.
            // Kloonimisel panics viskame eelmised üksused õigesti.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Printige ainult need elemendid, mida veel ei saadud: me ei saa enam saadud elementidele juurde pääseda.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}