//! Libcore prelude
//!
//! See moodul on mõeldud libcore'i kasutajatele, kes ei lingi ka libstd-ga.
//! See moodul imporditakse vaikimisi, kui `#![no_std]`-i kasutatakse samamoodi kui tavalise teegi prelude-i.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// 2015. aasta põhituum prelude.
///
/// Lisateavet leiate [module-level documentation](self)-st.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Tuumiku prelude 2018. aasta versioon.
///
/// Lisateavet leiate [module-level documentation](self)-st.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Tuumiku prelude 2021. aasta versioon.
///
/// Lisateavet leiate [module-level documentation](self)-st.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Lisage veel asju.
}