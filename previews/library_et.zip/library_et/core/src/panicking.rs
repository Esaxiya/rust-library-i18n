//! Libcore'i Panic tugi
//!
//! Põhiraamatukogu ei saa paanikat määratleda, küll aga deklareerib see paanikat.
//! See tähendab, et libcore'i sees olevad funktsioonid on lubatud panic-le, kuid et see oleks kasulik, peab ülesvoolu crate määratlema paanika, et libcore saaks kasutada.
//! Praegune paanikaliides on:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! See määratlus lubab paanikasse sattuda mis tahes üldsõnumiga, kuid see ei võimalda `Box<Any>` väärtusega ebaõnnestumist.
//! (`PanicInfo` sisaldab lihtsalt `&(dyn Any + Send)`-i, mille jaoks täidame näites " PanicInfo: : internal_constructor` näiva väärtuse.) Selle põhjuseks on see, et libcore'il pole lubatud eraldada.
//!
//!
//! See moodul sisaldab veel mõnda paanikafunktsiooni, kuid need on kompilaatori jaoks ainult vajalikud üksused.Selle ühe funktsiooni kaudu suunatakse kõik panics kanalid.
//! Tegelik sümbol deklareeritakse atribuudi `#[panic_handler]` kaudu.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Libcore'i `panic!` makro aluseks olev rakendamine, kui vormindust ei kasutata.
#[cold]
// mitte kunagi sisse, välja arvatud juhul, kui panic_immediate_abort, et vältida nii palju kui võimalik kõnesaitidel koodi paisumist
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // vajalik koodegenile panic jaoks ülevoolu ja muude `Assert` MIR terminalide jaoks
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Kasutage X_00X faili format_args! ("{}", Expr) asemel, et vähendada üldkulusid.
    // Formaat_args!makro kasutab str-i Display trait kirjutamiseks expr, mis kutsub Formatter::pad-i, mis peab mahutama stringi kärpimist ja polsterdamist (kuigi siin pole ühtegi kasutatud).
    //
    // Arguments::new_v1 kasutamine võib lubada kompilaatoril väljundbinaarist välja jätta Formatter::pad, säästes kuni paar kilobaiti.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // vajalik konst-hinnatud panics jaoks
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // vajalik koodegenile panic jaoks OOB array/slice juurdepääsul
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Libcore'i `panic!` makro aluseks olev rakendamine vormindamisel.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // MÄRKUS See funktsioon ei ületa kunagi FFI piiri;see on Rust-to-Rust-kõne, mis lahendatakse funktsioonile `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // OHUTUS: `panic_impl` on määratletud turvalises Rust-koodis ja seega on sellega turvaline helistada.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// `assert_eq!` ja `assert_ne!` makrode sisemine funktsioon
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}