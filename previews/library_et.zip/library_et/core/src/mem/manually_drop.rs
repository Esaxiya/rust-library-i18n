use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Ümbris, mis takistab kompilaatoril automaatselt helistada `T` hävitajale.
/// See ümbris on 0-hinnaga.
///
/// `ManuallyDrop<T>` rakendatakse sama paigutuse optimeerimist kui `T`.
/// Seetõttu ei mõjuta see * mingit mõju eeldustele, mida kompilaator oma sisu kohta teeb.
/// Näiteks `ManuallyDrop<&mut T>`-i initsialiseerimine [`mem::zeroed`]-iga on määratlemata käitumine.
/// Kui peate käsitsema initsialiseerimata andmeid, kasutage selle asemel [`MaybeUninit<T>`]-i.
///
/// Pange tähele, et `ManuallyDrop<T>`-is oleva väärtuse juurde pääsemine on ohutu.
/// See tähendab, et `ManuallyDrop<T>`-i, mille sisu on ära visatud, ei tohi avalikkuse ohutu API kaudu eksponeerida.
/// Vastavalt on `ManuallyDrop::drop` ohtlik.
///
/// # `ManuallyDrop` ja loobu järjekorrast.
///
/// Rust-l on täpselt määratletud väärtused [drop order].
/// Veendumaks, et väljad või kohalikud paigutatakse kindlas järjekorras, korraldage deklaratsioonid ümber nii, et kaudne kukutamise järjekord oleks õige.
///
/// Väljalangemise järjekorra juhtimiseks on võimalik kasutada `ManuallyDrop`-i, kuid see nõuab ebaturvalist koodi ja lahti keeramise korral on seda raske õigesti teha.
///
///
/// Näiteks kui soovite veenduda, et konkreetne väli langeks teiste järele, tehke sellest struktuuri viimane väli:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` visatakse pärast `children`-i maha.
///     // Rust tagab, et väljad kukutatakse deklareerimise järjekorras.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Paki käsitsi langetatav väärtus.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Väärtust saate endiselt ohutult opereerida
    /// assert_eq!(*x, "Hello");
    /// // Kuid `Drop`-i siin ei käivitata
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Eemaldab väärtuse `ManuallyDrop` konteinerist.
    ///
    /// See võimaldab väärtust uuesti langetada.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // See loobub `Box`-st.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Võtab `ManuallyDrop<T>` konteineri väärtuse välja.
    ///
    /// See meetod on mõeldud peamiselt langevate väärtuste teisaldamiseks.
    /// Selle asemel, et kasutada väärtuse käsitsi langetamiseks [`ManuallyDrop::drop`]-i, võite selle meetodi abil võtta väärtuse ja kasutada seda vastavalt soovile.
    ///
    /// Võimaluse korral on eelistatav kasutada selle asemel [`into_inner`][`ManuallyDrop::into_inner`], mis hoiab ära `ManuallyDrop<T>`-i sisu dubleerimise.
    ///
    ///
    /// # Safety
    ///
    /// See funktsioon liigutab sisalduva väärtuse semantiliselt välja, takistamata edasist kasutamist, jättes selle konteineri oleku muutmata.
    /// Teie kohustus on tagada, et seda `ManuallyDrop` ei kasutataks uuesti.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // OHUTUS: loeme viitest, mis on tagatud
        // kehtima lugemiste jaoks.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Sisestatud väärtus langeb käsitsi.See on täpselt samaväärne [`ptr::drop_in_place`]-i kutsumisega koos osutiga sisalduvale väärtusele.
    /// Sellisena, kui sisalduv väärtus ei ole pakitud struktuur, kutsutakse destruktorit paigale ilma väärtust liigutamata ja seega saab seda kasutada [pinned]-i andmete ohutuks viskamiseks.
    ///
    /// Kui teil on väärtuse omandiõigus, saate selle asemel kasutada [`ManuallyDrop::into_inner`]-i.
    ///
    /// # Safety
    ///
    /// See funktsioon käivitab sisalduva väärtuse hävitaja.
    /// Välja arvatud destruktori enda tehtud muudatused, jääb mälu muutmata ja nii palju kui kompilaatoril on endiselt bitimustrit, mis kehtib tüübi `T` jaoks.
    ///
    ///
    /// Kuid seda "zombie"-väärtust ei tohiks ohutu koodiga kokku puutuda ja seda funktsiooni ei tohiks kutsuda rohkem kui üks kord.
    /// Väärtuse kasutamine pärast selle langetamist või väärtuse mitu korda langetamine võib põhjustada määratlemata käitumise (olenevalt sellest, mida `drop` teeb).
    /// Tüübisüsteem takistab seda tavaliselt, kuid `ManuallyDrop`-i kasutajad peavad neid garantiisid toetama ilma kompilaatori abita.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // OHUTUS: me viskame väärtuse, millele osutatakse muudetava viitega
        // mis on garanteeritud, et see kehtib kirjutiste jaoks.
        // Helistaja ülesanne on veenduda, et `slot` i uuesti maha ei visata.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}