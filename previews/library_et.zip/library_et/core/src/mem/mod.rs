//! Põhifunktsioonid mäluga tegelemiseks.
//!
//! See moodul sisaldab funktsioone tüüpide suuruse ja joonduse pärimiseks, mälu initsialiseerimiseks ja manipuleerimiseks.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Omandab väärtuse **omandiõiguse ja "forgets"-i, ilma et see hävitajat käivitaks**.
///
/// Kõik ressursid, mida väärtus haldab, näiteks kuhjamälu või failikäepide, jäävad igaveseks kättesaamatusse olekusse.Kuid see ei taga, et selle mälu viited jäävad kehtima.
///
/// * Kui soovite lekitada mälu, vaadake jaotist [`Box::leak`].
/// * Kui soovite saada mälule toore osuti, vt [`Box::into_raw`].
/// * Kui soovite väärtuse korralikult käsutada, käivitades selle hävitaja, vaadake jaotist [`mem::drop`].
///
/// # Safety
///
/// `forget` ei ole märgitud kui `unsafe`, kuna Rust ohutusgarantiid ei sisalda garantiid, et destruktorid töötavad alati.
/// Näiteks võib programm luua referentstsükli, kasutades [`Rc`][rc]-i, või helistada [`process::exit`][exit]-ile, et väljuda ilma destruktoriteta.
/// Seega ei muuda `mem::forget`-i lubamine turvalisest koodist põhimõtteliselt Rust ohutusgarantiisid.
///
/// See tähendab, et ressursside nagu mälu või I/O objektide lekitamine on tavaliselt ebasoovitav.
/// Vajadus ilmneb mõnel FFI või ebaturvalise koodi spetsiaalsel kasutamisel, kuid isegi siis eelistatakse tavaliselt [`ManuallyDrop`]-i.
///
/// Kuna väärtuse unustamine on lubatud, peab iga teie kirjutatud `unsafe`-kood seda võimalust lubama.Te ei saa väärtust tagastada ja eeldada, et helistaja käivitab tingimata väärtuse hävitaja.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// `mem::forget` kanooniline ohutu kasutamine on `Drop` trait rakendatud väärtuse hävitajast möödahiilimine.Näiteks lekib see `File`, st
/// nõuda muutuja poolt võetud ruumi, kuid mitte kunagi sulgeda selle aluseks olevat ressurssi:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// See on kasulik, kui alusvara omandiõigused kanti varem koodile väljaspool Rust, näiteks toores faili kirjeldaja C-koodile edastamise kaudu.
///
/// # Suhe `ManuallyDrop`-iga
///
/// Kuigi `mem::forget`-i saab kasutada ka *mälu* omandiõiguse ülekandmiseks, on see veaohtlik.
/// [`ManuallyDrop`] selle asemel tuleks kasutada.Mõelge näiteks sellele koodile:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Ehitage `String`, kasutades `v` sisu
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // lekib `v`, kuna selle mälu haldab nüüd `s`
/// mem::forget(v);  // ERROR, v on vale ja seda ei tohi funktsioonile edastada
/// assert_eq!(s, "Az");
/// // `s` on kaudselt maha jäetud ja selle mälu hajutatud.
/// ```
///
/// Ülaltoodud näites on kaks probleemi:
///
/// * Kui `String`-i ehitamise ja `mem::forget()`-i kutsumise vahele lisataks rohkem koode, põhjustaks selles sisalduv panic topelt tasuta, kuna sama mälu käsitsevad nii `v` kui ka `s`.
/// * Pärast `v.as_mut_ptr()`-ile helistamist ja andmete omandiõiguse edastamist `s`-ile on `v` väärtus kehtetu.
/// Isegi kui väärtus lihtsalt viiakse `mem::forget`-i (mis seda ei kontrolli), on mõnel tüübil nende väärtuste suhtes ranged nõuded, mis muudavad need rippumise korral kehtetuks või ei kuulu enam nende omandisse.
/// Kehtetute väärtuste mis tahes kasutamine, sealhulgas nende edastamine funktsioonidele või nende tagastamine, kujutab endast määratlemata käitumist ja võib kompilaatori tehtud eeldusi rikkuda.
///
/// `ManuallyDrop`-le üleminek väldib mõlemat probleemi:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Enne `v` i tooreks osadeks lahti võtmist veenduge, et see ei kukuks!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Nüüd võtke `v` lahti.Need toimingud ei saa panic-d, seega ei saa lekkeid olla.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Lõpuks ehitage `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` on kaudselt maha jäetud ja selle mälu hajutatud.
/// ```
///
/// `ManuallyDrop` takistab jõuliselt topeltvaba kasutamist, sest enne millegi muu tegemist keelame `v` hävitaja.
/// `mem::forget()` ei luba seda, sest see võtab ära oma argumendi, sundides meid sellele helistama alles pärast seda, kui `v`-ist kõik vajalik välja tõmmatakse.
/// Isegi kui `ManuallyDrop` ehitamise ja stringi ehitamise vahel võeti kasutusele panic (mida ei saa juhtuda näidatud koodis), tooks see kaasa lekke ja mitte topeltvaba.
/// Teisisõnu, `ManuallyDrop` eksib lekke poolel, selle asemel et eksida (topelt) kukutamise küljel.
///
/// Samuti takistab `ManuallyDrop` meid pärast omandiõiguse üleandmist `s`-ile "touch" `v`-le-täielikult välditakse `v`-iga suhtlemise viimast etappi selle hävitamiseks ilma hävitaja käitamiseta.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Nagu [`forget`], aktsepteerib ka suurusteta väärtusi.
///
/// See funktsioon on lihtsalt alusplaat, mis on mõeldud eemaldamiseks, kui `unsized_locals`-funktsioon stabiliseerub.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Tagastab tüübi suuruse baitides.
///
/// Täpsemalt, see on baitides nihkumine selle üksuse tüübi massiivi järjestikuste elementide vahel, kaasa arvatud joonduspolster.
///
/// Seega on mis tahes tüüpi `T` ja pikkusega `n` puhul `[T; n]` suurus `n * size_of::<T>()`.
///
/// Üldiselt ei ole tüübi suurus kompileerimisel stabiilne, kuid konkreetsed tüübid, näiteks primitiivsed.
///
/// Järgmises tabelis on toodud primitiivide suurus.
///
/// Tüüp |suurus: <Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 sümboli |4
///
/// Lisaks on `usize` ja `isize` sama suurusega.
///
/// Tüüpidel `*const T`, `&T`, `Box<T>`, `Option<&T>` ja `Option<Box<T>>` on kõigil sama suurus.
/// Kui `T` on suurusega, on kõigil neil tüüpidel sama suurus kui `usize`.
///
/// Kursori muutlikkus ei muuda selle suurust.Sellisena on `&T` ja `&mut T` sama suurusega.
/// Samamoodi ka `*const T` ja `* mut T` puhul.
///
/// # `#[repr(C)]` üksuste suurus
///
/// Üksuste `C`-esitusel on määratletud paigutus.
/// Selle paigutuse korral on ka üksuste suurus stabiilne seni, kuni kõigi väljade suurus on stabiilne.
///
/// ## Struktuuride suurus
///
/// `structs` puhul määratakse suurus järgmise algoritmiga.
///
/// Deklaratsiooni järjekorras järjestatud struktuuri iga välja jaoks:
///
/// 1. Lisage välja suurus.
/// 2. Ümardage praegune suurus järgmise välja [alignment] lähima korrutiseni.
///
/// Lõpuks ümardage struktuuri suurus selle [alignment] lähima korrutiseni.
/// Struktuuri joondamine on tavaliselt kõigi selle väljade suurim joondus;seda saab muuta `repr(align(N))`-i kasutamisega.
///
/// Erinevalt `C`-st ei ümardata nullsuuruseid struktuure ühe baidini.
///
/// ## Enumsi suurus
///
/// Enumitel, millel pole muid andmeid peale diskrimineerija, on sama suur suurus kui platvormil, millele need on koostatud.
///
/// ## Ametiühingute suurus
///
/// Ametiühingu suurus on selle suurima välja suurus.
///
/// Erinevalt `C`-ist ei ümardata nullsuuruseid liite ühe baidini.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Mõned ürgsed
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Mõned massiivid
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Kursori suuruse võrdsus
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Kasutades `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Esimese välja suurus on 1, seega lisage suurusele 1.Suurus on 1.
/// // Teise välja joondus on 2, seega lisage polstri suurusele 1.Suurus on 2.
/// // Teise välja suurus on 2, seega lisage suurusele 2.Suurus on 4.
/// // Kolmanda välja joondus on 1, seega lisage poldi suurusele 0.Suurus on 4.
/// // Kolmanda välja suurus on 1, seega lisage suurusele 1.Suurus on 5.
/// // Lõpuks on struktuuri joondus 2 (kuna selle väljade suurim joondus on 2), lisage polsterduse suurusele 1.
/// // Suurus on 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple konstruktsioonid järgivad samu reegleid.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Pange tähele, et väljade ümberkorraldamine võib suurust vähendada.
/// // Mõlemad poldibaidid saame eemaldada, pannes `third` enne `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Liidu suurus on suurima välja suurus.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Tagastab teravdatud väärtuse suuruse baitides.
///
/// See on tavaliselt sama mis `size_of::<T>()`.
/// Kui aga `T` *-l pole staatiliselt teadaolevat suurust, nt lõik [`[T]`][slice] või [trait object], saab dünaamiliselt tuntud suuruse saamiseks kasutada `size_of_val`-i.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // OHUTUS: `val` on viide, seega on see kehtiv toores pointer
    unsafe { intrinsics::size_of_val(val) }
}

/// Tagastab teravdatud väärtuse suuruse baitides.
///
/// See on tavaliselt sama mis `size_of::<T>()`.Kui aga `T` *-l pole staatiliselt teadaolevat suurust, nt viilu [`[T]`][slice] või [trait object], saab dünaamiliselt tuntud suuruse saamiseks kasutada `size_of_val_raw`-i.
///
/// # Safety
///
/// Seda funktsiooni on turvaline helistada ainult siis, kui täidetud on järgmised tingimused:
///
/// - Kui `T` on `Sized`, on selle funktsiooni helistamine alati ohutu.
/// - Kui `T` suurusteta saba on:
///     - [slice], siis peab viilu saba pikkus olema initsialiseeritud täisarv ja *kogu väärtuse* suurus (dünaamiline saba pikkus + staatilise suurusega eesliide) peab mahtuma `isize`-i.
///     - [trait object], siis peab kursori vtable-osake osutama kehtivale vtable-le, mis on omandatud suurustamata sunnil ja *kogu väärtuse* suurus (dünaamiline saba pikkus + staatilise suurusega prefiks) peab mahtuma `isize`-i.
///
///     - (unstable) [extern type], siis on selle funktsiooni kutsumine alati ohutu, kuid võib panic või muul viisil vale väärtuse tagastada, kuna välise tüübi paigutus pole teada.
///     See on sama käitumine kui [`size_of_val`], kui viidatakse tüübile, millel on välise tüübi saba.
///     - muidu pole konservatiivselt lubatud seda funktsiooni kutsuda.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // OHUTUS: helistaja peab esitama kehtiva toornäidiku
    unsafe { intrinsics::size_of_val(val) }
}

/// Tagastab tüübi [ABI] vajaliku minimaalse joonduse.
///
/// Iga viide tüübi `T` väärtusele peab olema selle arvu korrutis.
///
/// See on joondamine, mida kasutatakse struktuuriväljadel.See võib olla väiksem kui eelistatud joondus.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Tagastab väärtuse, millele `val` osutab, vajaliku minimaalse joonduse [ABI].
///
/// Iga viide tüübi `T` väärtusele peab olema selle arvu korrutis.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // OHUTUS: val on viide, seega on see kehtiv toores pointer
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Tagastab tüübi [ABI] vajaliku minimaalse joonduse.
///
/// Iga viide tüübi `T` väärtusele peab olema selle arvu korrutis.
///
/// See on joondamine, mida kasutatakse struktuuriväljadel.See võib olla väiksem kui eelistatud joondus.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Tagastab väärtuse, millele `val` osutab, vajaliku minimaalse joonduse [ABI].
///
/// Iga viide tüübi `T` väärtusele peab olema selle arvu korrutis.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // OHUTUS: val on viide, seega on see kehtiv toores pointer
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Tagastab väärtuse, millele `val` osutab, vajaliku minimaalse joonduse [ABI].
///
/// Iga viide tüübi `T` väärtusele peab olema selle arvu korrutis.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Seda funktsiooni on turvaline helistada ainult siis, kui täidetud on järgmised tingimused:
///
/// - Kui `T` on `Sized`, on selle funktsiooni helistamine alati ohutu.
/// - Kui `T` suurusteta saba on:
///     - [slice], siis peab viilu saba pikkus olema initsialiseeritud täisarv ja *kogu väärtuse* suurus (dünaamiline saba pikkus + staatilise suurusega eesliide) peab mahtuma `isize`-i.
///     - [trait object], siis peab kursori vtable-osake osutama kehtivale vtable-le, mis on omandatud suurustamata sunnil ja *kogu väärtuse* suurus (dünaamiline saba pikkus + staatilise suurusega prefiks) peab mahtuma `isize`-i.
///
///     - (unstable) [extern type], siis on selle funktsiooni kutsumine alati ohutu, kuid võib panic või muul viisil vale väärtuse tagastada, kuna välise tüübi paigutus pole teada.
///     See on sama käitumine kui [`align_of_val`], kui viidatakse tüübile, millel on välise tüübi saba.
///     - muidu pole konservatiivselt lubatud seda funktsiooni kutsuda.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // OHUTUS: helistaja peab esitama kehtiva toornäidiku
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Tagastab `true`, kui `T`-tüüpi väärtuste langemine on oluline.
///
/// See on puhtalt optimeerimise vihje ja seda võib rakendada konservatiivselt:
/// see võib anda `true`-i tagasi tüüpide puhul, mida tegelikult pole vaja loobuda.
/// Sellisena oleks alati tagastav `true` selle funktsiooni sobiv rakendamine.Kuid kui see funktsioon tegelikult tagastab `false`, siis võite olla kindel, et `T` kukutamisel pole kõrvaltoimeid.
///
/// Selliste asjade nagu kollektsioonide madalad rakendused, mis peavad oma andmed käsitsi kukutama, peaksid seda funktsiooni kasutama, et vältida asjatut kogu sisu hävitamisel viskamist.
///
/// See ei pruugi muuta väljalaskejärke (kus silmus, millel pole kõrvalmõjusid, on hõlpsasti tuvastatav ja kõrvaldatav), kuid on silumisjärkude jaoks sageli suur võit.
///
/// Pange tähele, et [`drop_in_place`] teostab seda kontrolli juba, nii et kui teie töökoormust saab vähendada mõnele väikesele arvule [`drop_in_place`]-kõnedele, pole selle kasutamine vajalik.
/// Pange tähele, et saate [`drop_in_place`]-i viilu ja see kontrollib kõiki väärtusi ühe needs_drop-iga.
///
/// Tüübid, nagu Vec, on seetõttu lihtsalt `drop_in_place(&mut self[..])` ilma `needs_drop`-i selgesõnaliselt kasutamata.
/// Seevastu sellised tüübid nagu [`HashMap`] peavad väärtused ükshaaval kukutama ja peaksid seda API-d kasutama.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Siin on näide selle kohta, kuidas kogu võib `needs_drop`-i kasutada:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // loobuge andmetest
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Tagastab tüübi `T` väärtuse, mida tähistab nullbaidimuster.
///
/// See tähendab, et näiteks pole `(u8, u16)`-is polsterdusbaiti tingimata nullitud.
///
/// Pole mingit garantiid, et kogu nulliga baidimuster tähistab mõne `T` tüübi kehtivat väärtust.
/// Näiteks pole nullbaidimuster musterite (`&T`, `&mut T`) ja funktsioonide osutajate jaoks kehtiv väärtus.
/// `zeroed`-i kasutamine sellistel tüüpidel põhjustab [undefined behavior][ub]-i kohe, kuna [the Rust compiler assumes][inv]-l on initsialiseeritud muutujas alati kehtiv väärtus.
///
///
/// Sellel on sama efekt kui [`MaybeUninit::zeroed().assume_init()`][zeroed]-il.
/// Mõnikord on see FFI jaoks kasulik, kuid seda tuleks üldiselt vältida.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Selle funktsiooni õige kasutamine: täisarvu lähtestamine nulliga.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Selle funktsiooni vale* kasutamine: viite lähtestamine nulliga.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Määratlemata käitumine!
/// let _y: fn() = unsafe { mem::zeroed() }; // Ja jälle!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // OHUTUS: helistaja peab tagama, et `T` puhul kehtib nullväärtus.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Möödub Rust tavapärasest mälu lähtestamise kontrollist, teeseldes `T` tüüpi väärtuse loomist, tehes samas üldse mitte midagi.
///
/// **See funktsioon on aegunud.** Kasutage selle asemel [`MaybeUninit<T>`]-i.
///
/// Amortiseerimise põhjus on see, et funktsiooni ei saa põhimõtteliselt õigesti kasutada: sellel on sama efekt kui [`MaybeUninit::uninit().assume_init()`][uninit]-il.
///
/// Nagu [`assume_init` documentation][assume_init] selgitab, on [the Rust compiler assumes][inv], mis väärtused korralikult lähtestatakse.
/// Selle tagajärjel helistatakse nt
/// `mem::uninitialized::<bool>()` põhjustab `bool`-i tagastamisel kohese määratlemata käitumise, mis pole kindlasti kas `true` või `false`.
/// Halvem, tõepoolest initsialiseerimata mälu, nagu see, mis siia tagastatakse, on eriline selle poolest, et koostaja teab, et sellel pole fikseeritud väärtust.
/// Seetõttu on initsialiseerimata andmete olemasolu muutujas määratlemata, isegi kui sellel muutujal on täisarv.
/// (Pange tähele, et initsialiseerimata täisarvude reeglid pole veel lõplikud, kuid enne kui need on, on soovitatav neid vältida.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // OHUTUS: helistaja peab tagama, et `T` puhul kehtib ühtsustatud väärtus.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Vahetab väärtused kahes muutuvas kohas, kummaski deinitsialiseerimata.
///
/// * Kui soovite vahetada vaikeväärtuse või näiva väärtusega, vaadake jaotist [`take`].
/// * Kui soovite vahetada möödunud väärtusega, tagastades vana väärtuse, vt [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // OHUTUS: toored näpunäited on loodud ohututest muudetavatest viidetest, mis vastavad kõigile standarditele
    // `ptr::swap_nonoverlapping_one`-i piirangud
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Asendab `dest` vaikeväärtusega `T`, tagastades eelmise `dest` väärtuse.
///
/// * Kui soovite asendada kahe muutuja väärtused, vaadake jaotist [`swap`].
/// * Kui soovite vaikeväärtuse asemel asendada edastatud väärtusega, vaadake jaotist [`replace`].
///
/// # Examples
///
/// Lihtne näide:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` võimaldab omandada struktuurivälja, asendades selle väärtusega "empty".
/// Ilma `take`-iga saate kokku puutuda järgmiste probleemidega:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Pange tähele, et `T` ei pruugi [`Clone`]-i rakendada, seega ei saa see isegi `self.buf`-i kloonida ja lähtestada.
/// Kuid `take`-i saab kasutada `self.buf` algväärtuse lahutamiseks `self`-ist, mis võimaldab selle tagastada:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Teisaldab `src` viidatud `dest`-i, tagastades eelmise `dest`-väärtuse.
///
/// Kumbagi väärtust ei langeta.
///
/// * Kui soovite asendada kahe muutuja väärtused, vaadake jaotist [`swap`].
/// * Kui soovite asendada vaikeväärtusega, vaadake jaotist [`take`].
///
/// # Examples
///
/// Lihtne näide:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` lubab struktuurivälja tarbimist, asendades selle teise väärtusega.
/// Ilma `replace`-iga saate kokku puutuda järgmiste probleemidega:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Pange tähele, et `T` ei pruugi tingimata rakendada [`Clone`]-i, nii et me ei saa liikumise vältimiseks isegi `self.buf[i]`-i kloonida.
/// Kuid `replace`-i saab kasutada selle indeksi algväärtuse lahutamiseks `self`-ist, mis võimaldab selle tagastada:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // OHUTUS: me loeme `dest`-ist, kuid kirjutame sinna hiljem otse `src`-i,
    // selline, et vana väärtust ei dubleerita.
    // Midagi ei visata ja siin ei saa midagi panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Kõrvaldab väärtuse.
///
/// Seda tehes nimetatakse argumenti rakenduseks [`Drop`][drop].
///
/// See ei tee tõhusat tüüpi tüüpide puhul, mis rakendavad `Copy`, nt
/// integers.
/// Sellised väärtused kopeeritakse ja _then_ viiakse funktsiooni, nii et väärtus püsib ka pärast selle funktsiooni väljakutset.
///
///
/// See funktsioon pole maagia;see on sõna otseses mõttes määratletud kui
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Kuna `_x` viiakse funktsiooni, langeb see automaatselt enne funktsiooni naasmist.
///
/// [drop]: Drop
///
/// # Examples
///
/// Põhikasutus:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // selgesõnaliselt loobuda vector-st
/// ```
///
/// Kuna [`RefCell`] rakendab laenureegleid käitusajal, saab `drop` vabastada [`RefCell`] laenu:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // loobuda selles pesas olevast muutuvast laenust
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// `drop` ei mõjuta täisarvusid ega muid [`Copy`]-i rakendavaid tüüpe.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // `x` koopia teisaldatakse ja visatakse maha
/// drop(y); // `y` koopia teisaldatakse ja visatakse maha
///
/// println!("x: {}, y: {}", x, y.0); // endiselt saadaval
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Tõlgendab `src` tüüpi `&U` ja loeb seejärel `src` ilma sisestatud väärtust teisaldamata.
///
/// See funktsioon eeldab, et osuti `src` kehtib [`size_of::<U>`][size_of]-baitide jaoks, teisendades `&T`-st `&U`-i ja lugedes seejärel `&U`-i (välja arvatud see, et seda tehakse õigesti ka siis, kui `&U` muudab rangemad joondusnõuded kui `&T`).
/// Samuti loob see `src`-ist välja kolimise asemel ohutult koopia sisestatud väärtusest.
///
/// See ei ole kompileerimisaja viga, kui `T` ja `U` on erineva suurusega, kuid soovitame seda funktsiooni kasutada ainult seal, kus `T` ja `U` on sama suurusega.See funktsioon käivitab [undefined behavior][ub], kui `U` on suurem kui `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Kopeerige andmed 'foo_array'-ist ja käsitlege neid kui 'Foo'-i
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Kopeeritud andmete muutmine
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // 'foo_array' sisu ei oleks tohtinud muutuda
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Kui U-l on suurem joondusnõue, ei pruugi src olla sobivalt joondatud.
    if align_of::<U>() > align_of::<T>() {
        // OHUTUS: `src` on viide, mis kehtib lugemiste jaoks.
        // Helistaja peab tagama, et tegelik transmutatsioon on ohutu.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // OHUTUS: `src` on viide, mis kehtib lugemiste jaoks.
        // Kontrollisime just, et `src as *const U` oli korralikult joondatud.
        // Helistaja peab tagama, et tegelik transmutatsioon on ohutu.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Läbipaistmatu tüüp, mis tähistab loendit eristavat osa.
///
/// Lisateavet leiate selle mooduli funktsioonist [`discriminant`].
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Neid trait rakendusi ei saa tuletada, sest me ei soovi T-le mingeid piire

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Tagastab väärtuse, mis identifitseerib `v`-i loendi variandi.
///
/// Kui `T` pole loend, ei too selle funktsiooni kutsumine määratlemata käitumist, kuid tagastusväärtus on täpsustamata.
///
///
/// # Stability
///
/// Kui loendi määratlus muutub, võib loendivariandi diskrimineerija muutuda.
/// Mõne variandi diskrimineerija ei muutu sama kompilaatoriga kompileerimiste vahel.
///
/// # Examples
///
/// Seda saab kasutada andmeid kandvate loendite võrdlemiseks, arvestamata tegelikke andmeid:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Tagastab loenditüübi `T` variantide arvu.
///
/// Kui `T` pole loend, ei too selle funktsiooni kutsumine määratlemata käitumist, kuid tagastusväärtus on täpsustamata.
/// Samamoodi, kui `T` on loend, millel on rohkem variante kui `usize::MAX`, pole tagastusväärtus täpsustatud.
/// Asustamata variante arvestatakse.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}