use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// `T`-i initsialiseerimata eksemplaride koostamiseks pakenditüüp.
///
/// # Initsialiseerimine muutumatu
///
/// Koostaja eeldab üldiselt, et muutuja initsialiseeritakse vastavalt muutuja tüübi nõuetele.Näiteks peab viitetüübi muutuja olema joondatud ja mitte-NULL.
/// See on muutumatu variant, mida tuleb alati kaitsta ka ebaturvalises koodis.
/// Selle tagajärjel põhjustab viitetüübi muutuja null-initsialiseerimine hetkelise [undefined behavior][ub]-i, olenemata sellest, kas see viide kunagi harjub mälu juurde pääsema:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // määratlemata käitumine!⚠️
/// // `MaybeUninit<&i32>`-iga vastav kood:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // määratlemata käitumine!⚠️
/// ```
///
/// Seda kasutab kompilaator mitmesuguste optimeerimiste jaoks, näiteks käitamisaja kontrollimiseks ja `enum` paigutuse optimeerimiseks.
///
/// Samamoodi võib täielikult initsialiseerimata mälus olla sisu, samas kui `bool` peab alati olema `true` või `false`.Seega on initsialiseerimata `bool`-i loomine määratlemata käitumine:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // määratlemata käitumine!⚠️
/// // `MaybeUninit<bool>`-iga vastav kood:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // määratlemata käitumine!⚠️
/// ```
///
/// Pealegi on initsialiseerimata mälu eriline selle poolest, et sellel pole fikseeritud väärtust ("fixed" tähendab "it won't change without being written to").Sama initsialiseerimata baidi mitu korda lugemine võib anda erinevaid tulemusi.
/// See muudab määratlemata käitumise initsialiseerimata andmete muutujaks, isegi kui sellel muutujal on täisarvu tüüp, mis muidu mahutab mis tahes *fikseeritud* bitise mustri:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // määratlemata käitumine!⚠️
/// // `MaybeUninit<i32>`-iga vastav kood:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // määratlemata käitumine!⚠️
/// ```
/// (Pange tähele, et initsialiseerimata täisarvude reeglid pole veel lõplikud, kuid enne kui need on, on soovitatav neid vältida.)
///
/// Lisaks pidage meeles, et enamikul tüüpidel on täiendavaid invariante, lisaks sellele, et neid peetakse ainult tüübi tasandil initsialiseeritud.
/// Näiteks "1" initsialiseeritud [`Vec<T>`] loetakse initsialiseeritud (praeguse rakenduse kohaselt; see ei kujuta endast stabiilset garantiid), sest kompilaatori ainus nõue, et andmekursor ei tohi olla null.
/// Sellise `Vec<T>` loomine ei põhjusta *kohest* määratlemata käitumist, kuid põhjustab kõige ohutumate toimingute (sealhulgas selle kukutamise) korral määratlemata käitumise.
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` võimaldab ebaturvalisel koodil initsialiseerimata andmetega hakkama saada.
/// See on signaal koostajale, mis näitab, et siin olevaid andmeid ei tohi * initsialiseerida:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Looge selgesõnaliselt initsialiseerimata viide.
/// // Koostaja teab, et `MaybeUninit<T>`-is olevad andmed võivad olla valed ja seega pole see UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Määrake see kehtivaks väärtuseks.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Eemaldage lähtestatud andmed-see on lubatud ainult *pärast*`x`-i korralikku lähtestamist!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Seejärel teab kompilaator, et ta ei peaks selle koodi kohta tegema valesid oletusi ega optimeerimisi.
///
/// Võite mõelda, et `MaybeUninit<T>` on natuke sarnane `Option<T>`-ga, kuid ilma jooksuaja jälgimiseta ja ilma ohutuskontrollita.
///
/// ## out-pointers
///
/// "out-pointers"-i rakendamiseks võite kasutada `MaybeUninit<T>`-i: selle asemel, et funktsioonilt andmeid tagastada, edastage see mõne (uninitialized)-mällu kursor, kuhu tulemus panna.
/// See võib olla kasulik, kui helistajal on oluline kontrollida, kuidas tulem mälu salvestatakse, ja soovite vältida tarbetuid liigutusi.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` ei viska vana sisu maha, mis on oluline.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Nüüd teame, et `v` on initsialiseeritud!See tagab ka vector korraliku kukkumise.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Massiivi initsialiseerimine elementide kaupa
///
/// `MaybeUninit<T>` saab kasutada elementide kaupa suure massiivi initsialiseerimiseks:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Looge initsialiseerimata massiiv `MaybeUninit`.
///     // `assume_init` on ohutu, kuna tüüp, mille väidame siin initsialiseerinud olevat, on hunnik `Võib-olla Uninit'e, mis ei vaja lähtestamist.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // `MaybeUninit` i kukutamine ei tee midagi.
///     // Seega toore osuti määramine `ptr::write` asemel ei põhjusta vana initsialiseerimata väärtuse langemist.
/////
///     // Samuti, kui selle tsükli ajal on panic, on meil mäluleke, kuid mälu ohutusega seotud probleeme pole.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Kõik lähtestatakse.
///     // Teisendage massiiv initsialiseeritud tüübiks.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Võite töötada ka osaliselt initsialiseeritud massiividega, mida võiks leida madalama taseme datastruktuurides.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Looge initsialiseerimata massiiv `MaybeUninit`.
/// // `assume_init` on ohutu, kuna tüüp, mille väidame siin initsialiseerinud olevat, on hunnik `Võib-olla Uninit'e, mis ei vaja lähtestamist.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Loendage meile määratud elementide arv.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Massiivi iga üksuse jaoks tilk, kui me selle eraldasime.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Struktuuri lähtestamine valdkonniti
///
/// Struktuuride lähtestamiseks väljade kaupa saate kasutada `MaybeUninit<T>`-i ja makrot [`std::ptr::addr_of_mut`]:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // `name` välja lähtestamine
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // `list` välja initsialiseerimine Kui siin on panic, lekib X0 `String` välja `name`.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Kõik väljad on lähtestatud, seega lähtestatud Foo saamiseks helistame `assume_init`-ile.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` garanteeritakse, et sellel on sama suurus, joondus ja ABI kui `T`-il:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Pidage siiski meeles, et tüüp *, mis sisaldab*`MaybeUninit<T>`, ei pruugi olla sama paigutus;Rust ei taga üldiselt, et `Foo<T>`-i väljad oleksid sama järjestusega kui `Foo<U>`, isegi kui `T` ja `U` on sama suuruse ja joondusega.
///
/// Veelgi enam, kuna mis tahes bitiväärtus kehtib `MaybeUninit<T>` puhul, ei saa kompilaator rakendada non-zero/niche-filling-i optimeerimisi, mille tulemuseks võib olla suurem suurus:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Kui `T` on FFI-ohutu, on seda ka `MaybeUninit<T>`.
///
/// Kuigi `MaybeUninit` on `#[repr(transparent)]` (mis näitab, et see tagab sama suuruse, joonduse ja ABI kui `T`), ei muuda see * ühtegi eelnevat hoiatust.
/// `Option<T>` ja `Option<MaybeUninit<T>>` võivad endiselt olla erineva suurusega ning tüübid, mis sisaldavad välja `T` tüüpi välja, võivad olla paigutatud (ja suurusega) erinevalt, kui see väli oleks `MaybeUninit<T>`.
/// `MaybeUninit` on liidutüüp ja ametiühingute `#[repr(transparent)]` on ebastabiilne (vt [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Aja jooksul võivad `#[repr(transparent)]`-i täpsed garantiid liitudel areneda ja `MaybeUninit` võib jääda või mitte jääda `#[repr(transparent)]`-iks.
/// `MaybeUninit<T>` tagab *alati*, et sellel on sama suurus, joondus ja ABI nagu `T`;lihtsalt see, kuidas `MaybeUninit` seda garantiid rakendab, võib areneda.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Langi ese, et saaksime sellesse mähkida teisi tüüpe.See on kasulik generaatorite jaoks.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // `T::clone()`-ile helistamata ei saa me teada, kas oleme selleks piisavalt lähtestatud.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Loob uue `MaybeUninit<T>`, mis lähtestatakse antud väärtusega.
    /// Selle funktsiooni tagastusväärtusele on turvaline helistada [`assume_init`]-ile.
    ///
    /// Pange tähele, et `MaybeUninit<T>` i viskamine ei kutsu iialgi `T` tilkakoodi.
    /// Teie kohustus on tagada, et `T` initsialiseerimise korral kukuks ära.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Loob uue `MaybeUninit<T>` initsialiseerimata olekus.
    ///
    /// Pange tähele, et `MaybeUninit<T>` i viskamine ei kutsu iialgi `T` tilkakoodi.
    /// Teie kohustus on tagada, et `T` initsialiseerimise korral kukuks ära.
    ///
    /// Mõned näited leiate [type-level documentation][MaybeUninit]-st.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Looge uus `MaybeUninit<T>` üksuste massiiv initsialiseerimata olekus.
    ///
    /// Note: future Rust versioonis võib see meetod osutuda tarbetuks, kui massiivi sõnasõnaline süntaks lubab [repeating const expressions](https://github.com/rust-lang/rust/issues/49147)-i.
    ///
    /// Allpool toodud näites võiks seejärel kasutada `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`-i.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Tagastab (võib-olla väiksema) andmete loo, mis tegelikult loeti
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // OHUTUS: Initsialiseerimata `[MaybeUninit<_>; LEN]` kehtib.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Loob uue `MaybeUninit<T>` initsialiseerimata olekus, kusjuures mälu on täidetud `0`-baitidega.`T`-st sõltub, kas see juba õigesti lähtestab.
    ///
    /// Näiteks lähtestatakse `MaybeUninit<usize>::zeroed()`, kuid `MaybeUninit<&'static i32>::zeroed()` mitte seetõttu, et viited ei tohi olla nullid.
    ///
    /// Pange tähele, et `MaybeUninit<T>` i viskamine ei kutsu iialgi `T` tilkakoodi.
    /// Teie kohustus on tagada, et `T` initsialiseerimise korral kukuks ära.
    ///
    /// # Example
    ///
    /// Selle funktsiooni õige kasutamine: struktuuri lähtestamine nulliga, kus kõik struktuuri väljad võivad bitimudeli 0 kehtiva väärtusena hoida.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Selle funktsiooni vale* kasutamine: `x.zeroed().assume_init()`-i kutsumine, kui `0` ei ole tüübi jaoks sobiv bitimuster:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Paari sees loome `NotZero`, millel pole kehtivat diskrimineerijat.
    /// // See on määratlemata käitumine.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // OHUTUS: `u.as_mut_ptr()` osutab eraldatud mälule.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Määrab `MaybeUninit<T>` väärtuse.
    /// See kirjutab üle kõik varasemad väärtused ilma seda viskamata, seega olge ettevaatlik ja ärge kasutage seda kaks korda, kui te ei soovi destruktori käitamist vahele jätta.
    ///
    /// Teie mugavuse huvides tagastab see ka muudetava viite `self` (nüüd ohutult initsialiseeritud) sisule.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // OHUTUS: me just algatasime selle väärtuse.
        unsafe { self.assume_init_mut() }
    }

    /// Saab viidet sisalduvale väärtusele.
    /// Sellest kursorist lugemine või referentsiks muutmine on määratlemata käitumine, kui `MaybeUninit<T>` pole lähtestatud.
    /// Mällu kirjutamine, millele see osuti (non-transitively) osutab, on määratlemata käitumine (välja arvatud `UnsafeCell<T>` sees).
    ///
    /// # Examples
    ///
    /// Selle meetodi õige kasutamine:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Looge `MaybeUninit<T>`-i viide.See on okei, kuna algatasime selle.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// * Selle meetodi ebaõige kasutamine:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Oleme loonud viite initsialiseerimata vector-le!See on määratlemata käitumine.⚠️
    /// ```
    ///
    /// (Pange tähele, et initsialiseerimata andmetele viitamise reeglid pole veel lõplikud, kuid enne kui need on, on soovitatav neid vältida.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` ja `ManuallyDrop` on mõlemad `repr(transparent)`, nii et saame kursori heita.
        self as *const _ as *const T
    }

    /// Saab sisalduva väärtuse muudetava kursori.
    /// Sellest kursorist lugemine või referentsiks muutmine on määratlemata käitumine, kui `MaybeUninit<T>` pole lähtestatud.
    ///
    /// # Examples
    ///
    /// Selle meetodi õige kasutamine:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Looge `MaybeUninit<Vec<u32>>`-i viide.
    /// // See on okei, kuna algatasime selle.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// * Selle meetodi ebaõige kasutamine:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Oleme loonud viite initsialiseerimata vector-le!See on määratlemata käitumine.⚠️
    /// ```
    ///
    /// (Pange tähele, et initsialiseerimata andmetele viitamise reeglid pole veel lõplikud, kuid enne kui need on, on soovitatav neid vältida.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` ja `ManuallyDrop` on mõlemad `repr(transparent)`, nii et saame kursori heita.
        self as *mut _ as *mut T
    }

    /// Eemaldab väärtuse `MaybeUninit<T>` konteinerist.See on suurepärane viis andmete langemise tagamiseks, kuna saadud `T` allub tavapärasele tilkade käitlemisele.
    ///
    /// # Safety
    ///
    /// Helistaja peab tagama, et `MaybeUninit<T>` on tõesti initsialiseeritud olekus.Sellele helistamine, kui sisu pole veel täielikult vormistatud, põhjustab kohest määratlemata käitumist.
    /// [type-level documentation][inv] sisaldab selle initsialiseerumisvariandi kohta lisateavet.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Lisaks pidage meeles, et enamikul tüüpidel on täiendavaid invariante, lisaks sellele, et neid peetakse ainult tüübi tasandil initsialiseeritud.
    /// Näiteks "1" initsialiseeritud [`Vec<T>`] loetakse initsialiseeritud (praeguse rakenduse kohaselt; see ei kujuta endast stabiilset garantiid), sest kompilaatori ainus nõue, et andmekursor ei tohi olla null.
    ///
    /// Sellise `Vec<T>` loomine ei põhjusta *kohest* määratlemata käitumist, kuid põhjustab kõige ohutumate toimingute (sealhulgas selle kukutamise) korral määratlemata käitumise.
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Selle meetodi õige kasutamine:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// * Selle meetodi ebaõige kasutamine:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` ei olnud veel initsialiseeritud, mistõttu see viimane rida põhjustas määratlemata käitumist.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // OHUTUS: helistaja peab tagama, et `self` lähtestatakse.
        // See tähendab ka seda, et `self` peab olema `value` variant.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Loeb väärtust konteinerilt `MaybeUninit<T>`.Saadud `T`-i suhtes kohaldatakse tavalist tilgakäsitlust.
    ///
    /// Võimaluse korral on eelistatav kasutada selle asemel [`assume_init`], mis hoiab ära `MaybeUninit<T>`-i sisu dubleerimise.
    ///
    /// # Safety
    ///
    /// Helistaja peab tagama, et `MaybeUninit<T>` on tõesti initsialiseeritud olekus.Sellele helistamine, kui sisu pole veel täielikult vormistatud, põhjustab määratlemata käitumist.
    /// [type-level documentation][inv] sisaldab selle initsialiseerumisvariandi kohta lisateavet.
    ///
    /// Pealegi jätab see `MaybeUninit<T>`-i samade andmete koopia.
    /// Andmete mitme koopia kasutamisel (helistades `assume_init_read` mitu korda või helistades kõigepealt `assume_init_read` ja seejärel [`assume_init`]) on teie kohustus tagada, et need andmed tõepoolest dubleeriksid.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Selle meetodi õige kasutamine:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` on `Copy`, seega võime lugeda mitu korda.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `None` väärtuse paljundamine on okei, seega võime lugeda mitu korda.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// * Selle meetodi ebaõige kasutamine:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Lõime nüüd kaks eksemplari samast vector-st, mille tulemuseks on topeltvaba ⚠️, kui nad mõlemad kukuvad!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // OHUTUS: helistaja peab tagama, et `self` lähtestatakse.
        // `self.as_ptr()`-ist lugemine on ohutu, kuna `self` tuleks lähtestada.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Laseb sisalduva väärtuse oma kohale.
    ///
    /// Kui teil on `MaybeUninit` omand, võite selle asemel kasutada [`assume_init`]-i.
    ///
    /// # Safety
    ///
    /// Helistaja peab tagama, et `MaybeUninit<T>` on tõesti initsialiseeritud olekus.Sellele helistamine, kui sisu pole veel täielikult vormistatud, põhjustab määratlemata käitumist.
    ///
    /// Lisaks peavad olema täidetud kõik `T` tüüpi täiendavad invariandid, kuna `T` (või selle liikmete) `Drop`-i rakendus võib sellele tugineda.
    /// Näiteks "1" initsialiseeritud [`Vec<T>`] loetakse initsialiseeritud (praeguse rakenduse kohaselt; see ei kujuta endast stabiilset garantiid), sest kompilaatori ainus nõue, et andmekursor ei tohi olla null.
    ///
    /// Sellise `Vec<T>` viskamine põhjustab aga määratlemata käitumist.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // OHUTUS: helistaja peab tagama, et `self` lähtestatakse ja
        // rahuldab kõiki `T` invariante.
        // Väärtuse paigale kukutamine on sellisel juhul ohutu.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Saab jagatud viite sisalduvale väärtusele.
    ///
    /// See võib olla kasulik, kui soovime juurdepääsu `MaybeUninit`-ile, mis on initsialiseeritud, kuid kellel pole `MaybeUninit`-i omandiõigust (takistades `.assume_init()`)-i kasutamist.
    ///
    /// # Safety
    ///
    /// Sellele helistamine, kui sisu pole veel täielikult vormistatud, põhjustab määratlemata käitumist: helistaja peab tagama, et `MaybeUninit<T>` on tõesti lähtestatud olekus.
    ///
    ///
    /// # Examples
    ///
    /// ### Selle meetodi õige kasutamine:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // `x`-i lähtestamine:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Nüüd, kui meie `MaybeUninit<_>` on teadaolevalt initsialiseeritud, on okei luua sellele ühine viide:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // OHUTUS: `x` on lähtestatud.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Selle meetodi valed* kasutused:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Oleme loonud viite initsialiseerimata vector-le!See on määratlemata käitumine.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Initsialiseerige `MaybeUninit`, kasutades `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Viide initsialiseerimata `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // OHUTUS: helistaja peab tagama, et `self` lähtestatakse.
        // See tähendab ka seda, et `self` peab olema `value` variant.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Saab muudetava (unique) viite sisalduvale väärtusele.
    ///
    /// See võib olla kasulik, kui soovime juurdepääsu `MaybeUninit`-ile, mis on initsialiseeritud, kuid kellel pole `MaybeUninit`-i omandiõigust (takistades `.assume_init()`)-i kasutamist.
    ///
    /// # Safety
    ///
    /// Sellele helistamine, kui sisu pole veel täielikult vormistatud, põhjustab määratlemata käitumist: helistaja peab tagama, et `MaybeUninit<T>` on tõesti lähtestatud olekus.
    /// Näiteks ei saa `.assume_init_mut()`-i kasutada `MaybeUninit`-i lähtestamiseks.
    ///
    /// # Examples
    ///
    /// ### Selle meetodi õige kasutamine:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Initsialiseerib *kõik* sisendpuhvri baidid.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // `buf`-i lähtestamine:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Nüüd teame, et `buf` on initsialiseeritud, nii et saaksime selle `.assume_init()`-ga.
    /// // Kuid `.assume_init()` kasutamine võib käivitada 2048 baiti `memcpy`.
    /// // Selle kinnitamiseks, et meie puhver on initsialiseeritud ilma seda kopeerimata, uuendame `&mut MaybeUninit<[u8; 2048]>`-i versiooniks `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // OHUTUS: `buf` on lähtestatud.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Nüüd saame `buf`-i kasutada tavalise viiluna:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Selle meetodi valed* kasutused:
    ///
    /// Väärtuse lähtestamiseks ei saa `.assume_init_mut()`-i kasutada:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Oleme loonud (mutable) viite initsialiseerimata `bool`-le!
    ///     // See on määratlemata käitumine.⚠️
    /// }
    /// ```
    ///
    /// Näiteks ei saa te [`Read`]-i initsialiseerimata puhvrisse viia:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) viide initsialiseerimata mälule!
    ///                             // See on määratlemata käitumine.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Samuti ei saa kasutada otsest väljapääsu põllult valdkonnale järkjärguliseks lähtestamiseks:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) viide initsialiseerimata mälule!
    ///                  // See on määratlemata käitumine.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) viide initsialiseerimata mälule!
    ///                  // See on määratlemata käitumine.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Praegu loodame, et ülaltoodu on vale, st meil on viiteid initsialiseerimata andmetele (nt `libcore/fmt/float.rs`-is).
    // Enne stabiliseerimist peaksime reeglite osas langetama lõpliku otsuse.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // OHUTUS: helistaja peab tagama, et `self` lähtestatakse.
        // See tähendab ka seda, et `self` peab olema `value` variant.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Eemaldab väärtused massiivi `MaybeUninit` mahutitest.
    ///
    /// # Safety
    ///
    /// Helistaja peab tagama, et kõik massiivi elemendid oleksid initsialiseeritud.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // OHUTUS: Nüüd on kõigi elementide lähtestamisel turvaline
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Helistaja tagab, et kõik massiivi elemendid lähtestatakse
        // * `MaybeUninit<T>` ja T-l on tagatud sama paigutus
        // * Võib-ollaUnint ei lange, seega pole topeltvabastusi ja seega on teisendamine ohutu
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Eeldades, et kõik elemendid on initsialiseeritud, hankige neile viil.
    ///
    /// # Safety
    ///
    /// Helistaja peab tagama, et `MaybeUninit<T>` elemendid on tõesti initsialiseeritud.
    ///
    /// Sellele helistamine, kui sisu pole veel täielikult vormistatud, põhjustab määratlemata käitumist.
    ///
    /// Lisateavet ja näiteid leiate jaotisest [`assume_init_ref`].
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // OHUTUS: viilu valamine `*const [T]`-le on ohutu, kuna helistaja tagab selle
        // `slice` on initsialiseeritud ja "Võib-olla Uninit" on garanteeritud sama paigutusega kui `T`.
        // Saadud osuti on kehtiv, kuna see viitab `slice` omandis olevale mälule, mis on viide ja seega garanteeritud, et see kehtib lugemiste jaoks.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Eeldades, et kõik elemendid on initsialiseeritud, hankige neile muudetav lõik.
    ///
    /// # Safety
    ///
    /// Helistaja peab tagama, et `MaybeUninit<T>` elemendid on tõesti initsialiseeritud.
    ///
    /// Sellele helistamine, kui sisu pole veel täielikult vormistatud, põhjustab määratlemata käitumist.
    ///
    /// Lisateavet ja näiteid leiate jaotisest [`assume_init_mut`].
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // OHUTUS: sarnane `slice_get_ref` ohutusnõuetega, kuid meil on
        // muutuv viide, mis kehtib ka kirjutiste puhul.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Saab massiivi esimese elemendi kursori.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Saab massiivi esimese elemendi jaoks muudetava kursori.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Kopeerib elemendid `src`-ist `this`-i, tagastades muutuva viite `this` nüüd initsialiseeritud sisule.
    ///
    /// Kui `T` ei rakenda `Copy`-i, kasutage [`write_slice_cloned`]-i
    ///
    /// See sarnaneb [`slice::copy_from_slice`]-ga.
    ///
    /// # Panics
    ///
    /// See funktsioon on panic, kui kahel lõigul on erinev pikkus.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // OHUTUS: oleme just kopeerinud kõik len-i elemendid reservvõimsusse
    /// // veci esimesed src.len() elemendid kehtivad nüüd.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // OHUTUS: &[T] ja&[Võib-ollaUninit<T>] on sama paigutusega
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // OHUTUS: kehtivad elemendid on just kopeeritud `this`-i, nii et see on initsialiseeritud
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Kloonib elemendid `src`-st `this`-ni, tagastades muutuva viite `this` nüüd initsialiseeritud sisule.
    /// Juba initsialiseeritud elemente ei visata.
    ///
    /// Kui `T` rakendab `Copy`, kasutage [`write_slice`]
    ///
    /// See sarnaneb [`slice::clone_from_slice`]-iga, kuid ei lase olemasolevaid elemente maha visata.
    ///
    /// # Panics
    ///
    /// See funktsioon on panic, kui kahel lõigul on erinev pikkus või kui rakendatakse `Clone` panics.
    ///
    /// Kui on panic, visatakse juba kloonitud elemendid maha.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // OHUTUS: oleme just klooninud kõik lensi elemendid reservvõimsusse
    /// // veci esimesed src.len() elemendid kehtivad nüüd.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // erinevalt copy_from_slice'ist ei kutsu see viilu clone_from_slice seda seetõttu, et `MaybeUninit<T: Clone>` ei rakenda klooni.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // OHUTUS: see toores viil sisaldab ainult initsialiseeritud objekte
                // sellepärast on lubatud see maha visata.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Peame need viilutama sõnaselgelt sama pikkusega
        // piirikontrolli tühistamiseks ja optimeerija loob memcpy lihtsate juhtumite jaoks (näiteks T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // valvurit on vaja b/c panic võib juhtuda klooni ajal
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // OHUTUS: kehtivad elemendid on `this`-i just kirjutatud, nii et see on initsialiseeritud
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}