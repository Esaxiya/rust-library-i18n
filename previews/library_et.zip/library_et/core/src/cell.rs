//! Jagatavad muudetavad konteinerid.
//!
//! Rust mälu ohutus põhineb sellel reeglil: objekti `T` korral on võimalik ainult üks järgmistest:
//!
//! - Objektil on mitu muutumatut viidet (`&T`) (tuntud ka kui **aliasing**).
//! - Objektil on üks muudetav viide (&mut T). (Tuntud ka kui **mutatsioon**).
//!
//! Selle sunnib kompilaator Rust.Siiski on olukordi, kus see reegel ei ole piisavalt paindlik.Mõnikord nõutakse, et objektil oleks mitu viidet ja see siiski muteeritakse.
//!
//! Jagatavad muudetavad mahutid on olemas, et võimaldada juhitavat muutuvust isegi aliasimise korral.Nii [`Cell<T>`] kui ka [`RefCell<T>`] võimaldavad seda teha ühe keermega.
//! Kuid ei `Cell<T>` ega `RefCell<T>` pole niiditurvalised (need ei rakenda [`Sync`]-i).
//! Kui peate mitme lõime vahel muutma aliasimist ja mutatsiooni, on võimalik kasutada tüüpe [`Mutex<T>`], [`RwLock<T>`] või [`atomic`].
//!
//! Tüüpide `Cell<T>` ja `RefCell<T>` väärtusi võib muteerida jagatud viidete kaudu (st
//! tavaline tüüp `&T`), samas kui enamikku Rust tüüpe saab muteerida ainult unikaalsete (&&T T) viidete kaudu.
//! Me ütleme, et `Cell<T>` ja `RefCell<T>` tagavad "sisemuutuvuse", erinevalt tüüpilisest Rust tüübist, millel on "pärilik muutlikkus".
//!
//! Rakutüüpe on kahte maitset: `Cell<T>` ja `RefCell<T>`.`Cell<T>` rakendab siseruumi muutlikkust, liigutades väärtusi `Cell<T>`-st sisse ja välja.
//! Väärtuste asemel viidete kasutamiseks tuleb kasutada tüüpi `RefCell<T>`, hankides enne muteerimist kirjutusluku.`Cell<T>` pakub meetodeid praeguse siseväärtuse hankimiseks ja muutmiseks:
//!
//!  - Tüüpide puhul, mis rakendavad [`Copy`], saab meetod [`get`](Cell::get) praeguse siseväärtuse.
//!  - Tüüpide puhul, mis rakendavad [`Default`], asendab meetod [`take`](Cell::take) praeguse interjööri väärtuse väärtusega [`Default::default()`] ja tagastab asendatud väärtuse.
//!  - Kõigi tüüpide puhul asendab meetod [`replace`](Cell::replace) praeguse interjööri väärtuse ja tagastab asendatud väärtuse ning meetod [`into_inner`](Cell::into_inner) kulutab `Cell<T>` ja tagastab sisemise väärtuse.
//!  Lisaks asendab [`set`](Cell::set) meetod sisemise väärtuse, kukutades asendatud väärtuse.
//!
//! `RefCell<T>` kasutab dünaamilise laenamise rakendamiseks Rust elueaid-protsessi, mille käigus saab taotleda ajutist, eksklusiivset, muutuvat juurdepääsu sisemisele väärtusele.
//! Laenab `RefCelli jaoks<T>s jälgitakse käitusajal, erinevalt Rust natiivsetest viitetüüpidest, mida kompileerimise ajal jälgitakse täielikult staatiliselt.
//! Kuna `RefCell<T>`-i laenud on dünaamilised, on võimalik proovida laenata juba vastastikku laenatud väärtust;kui see juhtub, saadakse niit panic.
//!
//! # Millal valida interjööri muutlikkus
//!
//! Levinum pärilik muutlikkus, kus väärtuse muteerimiseks peab olema ainulaadne juurdepääs, on üks võtmekeele elemente, mis võimaldab Rust-l tugevalt osutada osuti aliasimisele, vältides staatiliselt krahhivigu.
//! Seetõttu eelistatakse pärilikku muutlikkust ja sisemuutlikkus on viimane abinõu.
//! Kuna rakutüübid võimaldavad mutatsiooni seal, kus see muidu keelataks, võib juhtuda, et sisemuutuvus võib olla asjakohane või tuleb kasutada isegi *
//!
//! * Tutvustame muutumatuse 'inside' muutlikkust
//! * Loogiliselt muutumatute meetodite rakendamise üksikasjad.
//! * [`Clone`] rakenduste mutatsioon.
//!
//! ## Tutvustame muutumatuse 'inside' muutlikkust
//!
//! Paljud jagatud nutikursori tüübid, sealhulgas [`Rc<T>`] ja [`Arc<T>`], pakuvad konteinereid, mida saab kloonida ja jagada mitme osapoole vahel.
//! Kuna sisalduvad väärtused võivad olla mitmekordsed, saab neid laenata ainult `&`-iga, mitte `&mut`-ga.
//! Ilma rakkudeta oleks nende nutikate osutite sees olevaid andmeid üldse võimatu mutateerida.
//!
//! Seejärel on `RefCell<T>`-i lisamine jagatud osutitüüpide sisse, et uuesti sisse tuua:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Dünaamilise laenu ulatuse piiramiseks looge uus plokk
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Pange tähele, et kui me ei oleks lasknud vahemälu eelmisel laenul langeda reguleerimisalast välja, põhjustaks järgmine laenamine dünaamilise lõime panic.
//!     //
//!     // See on `RefCell` kasutamise peamine oht.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Pange tähele, et selles näites kasutatakse `Rc<T>`-i, mitte `Arc<T>`-i.RefCell<T>s on mõeldud ühe lõimega stsenaariumide jaoks.Kaaluge [`RwLock<T>`] või [`Mutex<T>`] kasutamist, kui vajate mitme lõimega olukorras jagatud muutlikkust.
//!
//! ## Loogiliselt muutumatute meetodite rakendamise üksikasjad
//!
//! Mõnikord võib olla soovitav mitte paljastada API-s mutatsiooni "under the hood" toimumist.
//! Selle põhjuseks võib olla asjaolu, et operatsioon on loogiliselt muutumatu, kuid nt vahemälu sunnib rakendust mutatsiooni sooritama;või sellepärast, et trait-meetodi rakendamiseks, mis oli algselt määratletud `&self`-i võtmiseks, peate kasutama mutatsiooni.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Siia läheb kallis arvutus
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## `Clone` rakenduste mutatsioon
//!
//! See on lihtsalt eelmise eriline, kuid tavaline juhtum: muutumatuna tunduvate toimingute muutlikkuse varjamine.
//! Eeldatakse, et meetod [`clone`](Clone::clone) ei muuda lähteväärtust ja väidetakse, et see võtab `&self`, mitte `&mut self`.
//! Seetõttu peavad kõik `clone`-meetodil esinevad mutatsioonid kasutama rakutüüpe.
//! Näiteks säilitab [`Rc<T>`] oma `Cell<T>`-i loendused.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Muutuv mälu asukoht.
///
/// # Examples
///
/// Selles näites näete, et `Cell<T>` võimaldab mutatsiooni muutumatu struktuuri sees.
/// Teisisõnu võimaldab see "interior mutability"-i.
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // VIGA: `my_struct` on muutumatu
/// // my_struct.regular_field =uus_väärtus;
///
/// // TÖÖD: kuigi `my_struct` on muutumatu, on `special_field` `Cell`,
/// // mida saab alati muteerida
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Lisateavet leiate [module-level documentation](self)-st.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Loob `Cell<T>`, mille väärtuseks on T väärtus `Default`.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Loob uue `Cell`, mis sisaldab antud väärtust.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Määrab sisalduva väärtuse.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Vahetab kahe lahtri väärtused.
    /// `std::mem::swap`-i erinevus seisneb selles, et see funktsioon ei vaja `&mut`-viiteid.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // OHUTUS: See võib olla riskantne, kui seda kutsutakse eraldi lõimedest, kuid `Cell`
        // on `!Sync`, nii et seda ei juhtu.
        // See ei muuda ühtegi osutit kehtetuks, kuna `Cell` tagab, et kumbagi neist lahtritest ei osuta midagi muud.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Asendab sisalduva väärtuse väärtusega `val` ja tagastab vana sisalduva väärtuse.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // OHUTUS: See võib põhjustada andmesõite, kui seda kutsutakse eraldi lõimest,
        // kuid `Cell` on `!Sync`, nii et seda ei juhtu.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Tühistab väärtuse.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Tagastab sisalduva väärtuse koopia.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // OHUTUS: See võib põhjustada andmesõite, kui seda kutsutakse eraldi lõimest,
        // kuid `Cell` on `!Sync`, nii et seda ei juhtu.
        unsafe { *self.value.get() }
    }

    /// Uuendab sisalduvat väärtust funktsiooni abil ja tagastab uue väärtuse.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Tagastab selle lahtri alusandmetele toore kursori.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Tagastab muudetava viite alusandmetele.
    ///
    /// See kõne laenab `Cell`-i mutatiivselt (kompileerimise ajal), mis tagab, et meil on ainus viide.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Tagastab `&mut T`-i `&Cell<T>`-st
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // OHUTUS: `&mut` tagab ainulaadse juurdepääsu.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Võtab lahtri väärtuse, jättes selle asemele `Default::default()`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Tagastab `&Cell<[T]>`-i `&[Cell<T>]`-st
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // OHUTUS: `Cell<T>`-l on sama mälu paigutus kui `T`-il.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Dünaamiliselt kontrollitud laenureeglitega muudetav mälu asukoht
///
/// Lisateavet leiate [module-level documentation](self)-st.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// [`RefCell::try_borrow`] tagastas vea.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// [`RefCell::try_borrow_mut`] tagastas tõrke.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Positiivsed väärtused tähistavad aktiivse `Ref` arvu.Negatiivsed väärtused tähistavad aktiivse `RefMut` arvu.
// Mitu "RefMut" saab korraga olla aktiivne ainult siis, kui see viitab `RefCell`-i erinevatele, mitte kattuvatele komponentidele (nt viilu erinevad vahemikud).
//
// `Ref` ja `RefMut` on mõlemad kahe sõna suurused ja seega pole tõenäoliselt kunagi piisavalt Refi või RefMut, et ületada pool `usize` vahemikust.
// Seega ei lähe `BorrowFlag` tõenäoliselt kunagi üle ega alla.
// Kuid see ei ole garantii, kuna patoloogiline programm võib korduvalt luua ja seejärel mem::forget `Ref` või`RefMut`.
// Seega peab kogu kood ohutuse vältimiseks selgesõnaliselt kontrollima ülevoolu ja-voolu, või vähemalt käituma õigesti ülevoolu või-voolu korral (nt vt BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Loob uue `RefCell`, mis sisaldab `value`-i.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Tarbib `RefCell`, tagastades pakitud väärtuse.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Kuna see funktsioon võtab väärtuse `self` (`RefCell`), kontrollib kompilaator staatiliselt, et seda pole praegu laenatud.
        //
        self.value.into_inner()
    }

    /// Asendab pakitud väärtuse uuega, tagastades vana väärtuse, kummaski deinitsialiseerimata.
    ///
    ///
    /// See funktsioon vastab [`std::mem::replace`](../mem/fn.replace.html)-le.
    ///
    /// # Panics
    ///
    /// Panics, kui väärtus on praegu laenatud.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Asendab pakitud väärtuse uuega, mis on arvutatud `f`-st, tagastades vana väärtuse, kummaski deinitsialiseerimata.
    ///
    ///
    /// # Panics
    ///
    /// Panics, kui väärtus on praegu laenatud.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Vahetab `self` pakitud väärtuse `other` pakitud väärtusega, kummalegi deinitsialiseerimata.
    ///
    ///
    /// See funktsioon vastab [`std::mem::swap`](../mem/fn.swap.html)-le.
    ///
    /// # Panics
    ///
    /// Panics, kui mõlema `RefCell` väärtus on praegu laenatud.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Laenab pakitud väärtuse muutumatult.
    ///
    /// Laen kestab seni, kuni tagastatud `Ref` väljub ulatusest.
    /// Korraga saab välja võtta mitu muutumatut laenu.
    ///
    /// # Panics
    ///
    /// Panics, kui väärtus on praegu vastastikku laenatud.
    /// Paanikavaba variandi jaoks kasutage [`try_borrow`](#method.try_borrow)-i.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// panic näide:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Laenab pakitud väärtuse muutumatult, tagastades vea, kui väärtus on praegu vastastikku laenatud.
    ///
    ///
    /// Laen kestab seni, kuni tagastatud `Ref` väljub ulatusest.
    /// Korraga saab välja võtta mitu muutumatut laenu.
    ///
    /// See on [`borrow`](#method.borrow)-i paanikavaba variant.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // OHUTUS: `BorrowRef` tagab ainult muutumatu juurdepääsu
            // väärtuseni laenamise ajal.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Laenab pakitud väärtust muutlikult.
    ///
    /// Laen kestab seni, kuni tagastatud `RefMut` või kõik sellest tuletatud `RefMut`-id väljuvad.
    ///
    /// Väärtust ei saa laenata, kui see laen on aktiivne.
    ///
    /// # Panics
    ///
    /// Panics, kui väärtus on praegu laenatud.
    /// Paanikavaba variandi jaoks kasutage [`try_borrow_mut`](#method.try_borrow_mut)-i.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// panic näide:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Laenab pakitud väärtuse muutlikult, tagastades vea, kui väärtus on praegu laenatud.
    ///
    ///
    /// Laen kestab seni, kuni tagastatud `RefMut` või kõik sellest tuletatud `RefMut`-id väljuvad.
    /// Väärtust ei saa laenata, kui see laen on aktiivne.
    ///
    /// See on [`borrow_mut`](#method.borrow_mut)-i paanikavaba variant.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // OHUTUS: `BorrowRef` tagab ainulaadse juurdepääsu.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Tagastab selle lahtri alusandmetele toore kursori.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Tagastab muudetava viite alusandmetele.
    ///
    /// See kõne laenab `RefCell`-i muutuvalt (kompileerimise ajal), nii et dünaamilisi kontrolle pole vaja.
    ///
    /// Kuid olge ettevaatlik: see meetod eeldab, et `self` on muudetav, mida `RefCell`-i kasutamisel tavaliselt ei tehta.
    ///
    /// Kui `self` pole muudetav, vaadake selle asemel meetodit [`borrow_mut`].
    ///
    /// Pange tähele, et see meetod on mõeldud ainult erilistel asjaoludel ja pole tavaliselt see, mida soovite.
    /// Kahtluste korral kasutage selle asemel [`borrow_mut`]-i.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Tühjendage lekkinud kaitsmete mõju `RefCell` laenuolekule.
    ///
    /// See kõne sarnaneb [`get_mut`]-iga, kuid on rohkem spetsialiseerunud.
    /// See laenab `RefCell`-i muutumatult, et tagada laenude puudumine, ja lähtestab seejärel jagatud laene jälgiva oleku.
    /// See on asjakohane, kui mõni `Ref` või `RefMut` laen on lekkinud.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Laenab pakitud väärtuse muutumatult, tagastades vea, kui väärtus on praegu vastastikku laenatud.
    ///
    /// # Safety
    ///
    /// Erinevalt `RefCell::borrow`-st pole see meetod ohtlik, kuna see ei tagasta `Ref`-i, jättes seega laenulipu puutumata.
    /// `RefCell`-i laenamine vastupidi, kui selle meetodi abil tagastatud viide on elus, on määratlemata käitumine.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // OHUTUS: Kontrollime, et keegi praegu aktiivselt ei kirjutaks, aga on
            // helistaja kohustus tagada, et keegi ei kirjutaks enne, kui tagastatud viidet enam ei kasutata.
            // Samuti viitab `self.value.get()` `self`-le kuuluvale väärtusele ja on seega garanteeritud, et see kehtib kogu `self`-i eluea jooksul.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Võtab pakitud väärtuse, jättes `Default::default()` oma kohale.
    ///
    /// # Panics
    ///
    /// Panics, kui väärtus on praegu laenatud.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics, kui väärtus on praegu vastastikku laenatud.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Loob `RefCell<T>`, mille väärtuseks on T väärtus `Default`.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics, kui mõlema `RefCell` väärtus on praegu laenatud.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics, kui mõlema `RefCell` väärtus on praegu laenatud.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics, kui mõlema `RefCell` väärtus on praegu laenatud.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, kui mõlema `RefCell` väärtus on praegu laenatud.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, kui mõlema `RefCell` väärtus on praegu laenatud.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, kui mõlema `RefCell` väärtus on praegu laenatud.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics, kui mõlema `RefCell` väärtus on praegu laenatud.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Laenu suurendamine võib põhjustada lugemata väärtuse (<=0) järgmistel juhtudel:
            // 1. See oli <0, st on laenuvõtteid, nii et me ei saa lugeda laenu lubada, kuna Rust on viidatud aliasimisreeglid
            // 2.
            // See oli isize::MAX (lugemislaenude maksimaalne summa) ja see voolas üle isize::MIN-i (laenude kirjutamise maksimaalne summa), nii et me ei saa lubada täiendavat lugemislaenu, kuna isize ei saa esindada nii palju loetud laene (see võib juhtuda ainult siis, kui mem::forget rohkem kui väike püsiv kogus `Ref'e, mis pole hea tava)
            //
            //
            //
            //
            None
        } else {
            // Laenu suurendamine võib põhjustada lugemisväärtuse (> 0) järgmistel juhtudel:
            // 1. See oli=0, st seda ei laenatud ja võtame esimese loetud laenu
            // 2. See oli> 0 ja <isize::MAX, st
            // seal oli loetud laene ja isize on piisavalt suur, et esindada veel ühe loetud laenu olemasolu
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Kuna see viide on olemas, teame, et laenulipp on lugemislaen.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Vältige laenuloenduri ülevoolamist kirjutamislaenuks.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Pakib `RefCell`-i lahtrisse laenatud viite väärtusele.
/// `RefCell<T>`-st muutumatult laenatud väärtuse ümbrise tüüp.
///
/// Lisateavet leiate [module-level documentation](self)-st.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Kopeerib `Ref`.
    ///
    /// `RefCell` on juba muutumatult laenatud, nii et see ei saa ebaõnnestuda.
    ///
    /// See on seotud funktsioon, mida tuleb kasutada kui `Ref::clone(...)`.
    /// `Clone`-i rakendamine või meetod häiriks `r.borrow().clone()`-i laialdast kasutamist `RefCell`-i sisu kloonimiseks.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Valmistab laenatud andmete komponendi jaoks uue `Ref`.
    ///
    /// `RefCell` on juba muutumatult laenatud, nii et see ei saa ebaõnnestuda.
    ///
    /// See on seotud funktsioon, mida tuleb kasutada kui `Ref::map(...)`.
    /// Meetod häiriks `Deref` kaudu kasutatava `RefCell` sisu samanimelisi meetodeid.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Valmistab laenatud andmete valikuliseks komponendiks uue `Ref`-i.
    /// Algne kaitse tagastatakse kui `Err(..)`, kui sulgur tagastab `None`.
    ///
    /// `RefCell` on juba muutumatult laenatud, nii et see ei saa ebaõnnestuda.
    ///
    /// See on seotud funktsioon, mida tuleb kasutada kui `Ref::filter_map(...)`.
    /// Meetod häiriks `Deref` kaudu kasutatava `RefCell` sisu samanimelisi meetodeid.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Jagab `Ref` laenatud andmete erinevate komponentide jaoks mitmeks Ref-ks.
    ///
    /// `RefCell` on juba muutumatult laenatud, nii et see ei saa ebaõnnestuda.
    ///
    /// See on seotud funktsioon, mida tuleb kasutada kui `Ref::map_split(...)`.
    /// Meetod häiriks `Deref` kaudu kasutatava `RefCell` sisu samanimelisi meetodeid.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Teisenda alusandmete viiteks.
    ///
    /// Aluseks olevat `RefCell`-i ei saa enam kunagi mutatiivselt laenata ja see tundub alati juba muutumatult laenatud.
    ///
    /// Ei ole hea mõte lekitada rohkem kui pidev arv viiteid.
    /// `RefCell`-i saab muutumatult uuesti laenata, kui lekkeid on kokku tulnud vähem.
    ///
    /// See on seotud funktsioon, mida tuleb kasutada kui `Ref::leak(...)`.
    /// Meetod häiriks `Deref` kaudu kasutatava `RefCell` sisu samanimelisi meetodeid.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Selle viite unustades tagame, et RefCelli laenulett ei saa `'b` eluea jooksul tagasi KASUTAMATA.
        // Viite jälgimise oleku lähtestamine eeldaks unikaalset viidet laenatud RefCellile.
        // Esialgsest lahtrist ei saa enam muudetavaid viiteid luua.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Valmistab laenatud andmete komponendi jaoks uue `RefMut`, nt loendivariandi.
    ///
    /// `RefCell` on juba vastastikku laenatud, nii et see ei saa ebaõnnestuda.
    ///
    /// See on seotud funktsioon, mida tuleb kasutada kui `RefMut::map(...)`.
    /// Meetod häiriks `Deref` kaudu kasutatava `RefCell` sisu samanimelisi meetodeid.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): parandama laenutšekki
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Valmistab laenatud andmete valikuliseks komponendiks uue `RefMut`-i.
    /// Algne kaitse tagastatakse kui `Err(..)`, kui sulgur tagastab `None`.
    ///
    /// `RefCell` on juba vastastikku laenatud, nii et see ei saa ebaõnnestuda.
    ///
    /// See on seotud funktsioon, mida tuleb kasutada kui `RefMut::filter_map(...)`.
    /// Meetod häiriks `Deref` kaudu kasutatava `RefCell` sisu samanimelisi meetodeid.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): parandama laenutšekki
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // OHUTUS: funktsioon kehtib kogu eksklusiivse viite kohta
        // `orig`-i kaudu ja kursor on viidatud ainult funktsioonikõne sees, mitte kunagi ei võimalda ainuõige viide pääseda.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // OHUTUS: sama mis ülal.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Jagab `RefMut` laenatud andmete erinevate komponentide jaoks mitmeks RefMut-ks.
    ///
    /// Aluseks olev `RefCell` jääb vastastikku laenuks seni, kuni mõlemad tagastatud "RefMut" rakendusalast välja lähevad.
    ///
    /// `RefCell` on juba vastastikku laenatud, nii et see ei saa ebaõnnestuda.
    ///
    /// See on seotud funktsioon, mida tuleb kasutada kui `RefMut::map_split(...)`.
    /// Meetod häiriks `Deref` kaudu kasutatava `RefCell` sisu samanimelisi meetodeid.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Teisenda muudetavaks viiteks alusandmetele.
    ///
    /// Aluseks olevat `RefCell`-i ei saa uuesti laenata ja see ilmub alati juba vastastikku laenatuna, mistõttu tagastatud viide on ainus interjöör.
    ///
    ///
    /// See on seotud funktsioon, mida tuleb kasutada kui `RefMut::leak(...)`.
    /// Meetod häiriks `Deref` kaudu kasutatava `RefCell` sisu samanimelisi meetodeid.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Selle BorrowRefMut unustades tagame, et RefCelli laenulett ei saa `'b` eluea jooksul tagasi KASUTAMATA.
        // Viite jälgimise oleku lähtestamine eeldaks unikaalset viidet laenatud RefCellile.
        // Selle eluea jooksul ei saa algsest lahtrist täiendavaid viiteid luua, mistõttu praegune laen on ainus viide ülejäänud eluea jaoks.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Erinevalt BorrowRefMut::clone-ist kutsutakse initsiaal loomiseks uus
        // muudetav viide ja seega ei tohi praegu ühtegi olemasolevat viidet olla.
        // Seega, kuigi kloon suurendab muudetavat tagasiarvestust, lubame siin sõnaselgelt minna ainult KASUTAMATULT KASUTATULE, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Kloonib aadressi `BorrowRefMut`.
    //
    // See kehtib ainult siis, kui iga `BorrowRefMut`-i kasutatakse muutuva viite jälgimiseks algse objekti selgelt eristuvale, mitte kattuvale vahemikule.
    //
    // See pole klooni implikatsioonis, nii et kood seda kaudselt ei kutsu.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Vältige laenuloenduri allavoolu.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// `RefCell<T>`-lt vastastikku laenatud väärtuse ümbrise tüüp.
///
/// Lisateavet leiate [module-level documentation](self)-st.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Rust sisemuutlikkuse tuum.
///
/// Kui teil on viide `&T`, siis tavaliselt kompilaator teostab Rust-is optimeerimisi teadmise põhjal, et `&T` osutab muutumatutele andmetele.Nende andmete muteerimist, näiteks pseudonüümi kaudu või `&T`-i `&mut T`-i muundamise teel, peetakse määratlemata käitumiseks.
/// `UnsafeCell<T>` loobub muutumatuse garantiist `&T` jaoks: jagatud viide `&UnsafeCell<T>` võib viidata andmetele, mida muteeritakse.Seda nimetatakse "interior mutability".
///
/// Kõik muud sisemist muutlikkust võimaldavad tüübid, näiteks `Cell<T>` ja `RefCell<T>`, kasutavad andmete sisestamiseks sisemiselt `UnsafeCell`-i.
///
/// Pange tähele, et `UnsafeCell` mõjutab ainult jagatud viidete muutumatuse garantiid.Muutumatute viidete ainulaadsuse garantii ei muutu.`&mut`-i varjunime saamiseks pole * seaduslikku viisi, isegi mitte `UnsafeCell<T>`-ga.
///
/// `UnsafeCell` API ise on tehniliselt väga lihtne: [`.get()`] annab teile selle sisule toore osuti `*mut T`.Abstraktsiooni kujundaja ülesanne on seda toores osutit õigesti kasutada.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Täpsed Rust varjunime reeglid on mõnevõrra muutlikud, kuid põhipunktid pole vaidlustatud:
///
/// - Kui loote turvalise viite eluaegse `'a`-ga (kas `&T`-või `&mut T`-viitega), millele pääseb juurde turvalise koodi abil (näiteks seetõttu, et selle tagastasite), ei tohi te andmetele juurde pääseda viisil, mis on ülejäänud viitega vastuolus `'a`-st.
/// Näiteks tähendab see seda, et kui võtate `*mut T` `UnsafeCell<T>`-ist ja valate `&T`-i, siis `T`-is olevad andmed peavad muutumatuks jääma (moduleerige loomulikult kõik `T`-is leitud `UnsafeCell`-andmed), kuni selle viite eluiga lõpeb.
/// Samamoodi, kui loote `&mut T`-viite, mis on välja antud ohutule koodile, ei tohi te `UnsafeCell`-i andmetele juurde pääseda enne, kui see viide aegub.
///
/// - Igal ajal peate vältima andmesõite.Kui mitmel niidil on juurdepääs samale `UnsafeCell`-ile, peavad kõik kirjutised olema kõigi teiste juurdepääsudega (või kasutage aatomeid) korral enne juhtumisi.
///
/// Korraliku kujunduse hõlbustamiseks tunnistatakse üheahelalise koodi jaoks selgelt seaduslikuks järgmised stsenaariumid:
///
/// 1. `&T` viite saab vabastada turvalisele koodile ja seal võib see eksisteerida koos teiste `&T` viidetega, kuid mitte `&mut T`
///
/// 2. `&mut T` viite võib anda turvalisele koodile tingimusel, et sellega ei eksisteeri muud `&mut T` ega `&T`.`&mut T` peab alati olema kordumatu.
///
/// Pange tähele, et kuigi `&UnsafeCell<T>`-i sisu muteerimine (isegi kui muud `&UnsafeCell<T>`-i viitenimed on lahtris) on korras (tingimusel, et ülaltoodud invariante sunnite mingil muul viisil), on siiski mitme `&mut UnsafeCell<T>`-varjunime määratlemata käitumine.
/// See tähendab, et `UnsafeCell` on ümbris, mis on loodud spetsiaalse interaktsiooni saavutamiseks _shared_ accesses (_i.e._-iga, läbi `&UnsafeCell<_>`-viite);_exclusive_ accesses (_e.g._-iga, läbi `&mut UnsafeCell<_>`-i, pole mingit võluvõimalust: lahtrit ega pakitud väärtust ei tohi selle `&mut`-i laenamise ajaks pseudonüümis kasutada.
///
/// Seda esitleb [`.get_mut()`]-i juurdepääsuprogramm, mis on _safe_ getter, mis annab `&mut T`-i.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Siin on näide, kuidas `UnsafeCell<_>`-i sisu korralikult muteerida, hoolimata sellest, et lahtrit aliaseerib mitu viidet:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Hankige mitu/jagatud viidet samale `x`-ile.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // OHUTUS: selles valdkonnas pole muid viiteid x-i sisule,
///     // nii et meie oma on tegelikult ainulaadne.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- laenata-+
///     *p1_exclusive += 27; // |
/// } // <---------- ei saa sellest punktist kaugemale minna -------------------+
///
/// unsafe {
///     // OHUTUS: selles ulatuses ei eelda keegi, et tal oleks ainuõiguslik juurdepääs x-i sisule,
///     // nii et meil võib olla korraga mitu jagatud juurdepääsu.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Järgmine näide näitab asjaolu, et ainuõiguslik juurdepääs `UnsafeCell<T>`-le tähendab ka ainuõiget juurdepääsu selle `T`-le:
///
/// ```rust
/// #![forbid(unsafe_code)] // ainuõiguslike juurdepääsudega,
///                         // `UnsafeCell` on läbipaistev keelatud ümbris, nii et siin pole vaja `unsafe`-i.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Hankige kompileerimise ajal kontrollitud ainulaadne viide `x`-ile.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Eksklusiivse viitega saame sisu tasuta muteerida.
/// *p_unique.get_mut() = 0;
/// // Või samaväärselt:
/// x = UnsafeCell::new(0);
///
/// // Kui meil on väärtus, saame selle sisu välja võtta tasuta.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Ehitab uue `UnsafeCell`-i eksemplari, mis ümbritseb määratud väärtust.
    ///
    ///
    /// Kogu juurdepääs sisemisele väärtusele meetodite kaudu on `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Tühistab väärtuse.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Hõlmab pakitud väärtuse muutuva kursori.
    ///
    /// Seda saab visata ükskõik milliseks osutiks.
    /// Veenduge, et `&mut T`-i ülekandmisel oleks juurdepääs ainulaadne (pole aktiivseid viiteid, muudetav või mitte) ja veenduge, et `&T`-i ülekandmisel ei toimuks mutatsioone ega muutuvaid varjunimesid
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Saame #[repr(transparent)]-i tõttu lihtsalt kursori `UnsafeCell<T>`-st `T`-i heita.
        // See kasutab ära libstd eristaatust, pole kasutajakoodile mingit garantiid, et see toimiks kompilaatori future versioonides!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Tagastab muudetava viite alusandmetele.
    ///
    /// See kõne laenab `UnsafeCell`-i mutatiivselt (kompileerimise ajal), mis tagab, et meil on ainus viide.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Hõlmab pakitud väärtuse muutuva kursori.
    /// Erinevus [`get`]-st on see, et see funktsioon aktsepteerib toores osutit, mis on kasulik ajutiste viidete loomise vältimiseks.
    ///
    /// Tulemuse saab visata mis tahes osuti juurde.
    /// Veenduge, et `&mut T`-i ülekandmisel oleks juurdepääs ainulaadne (aktiivseid viiteid pole, muudetavad või mitte) ja veenduge, et `&T`-i ülekandmisel ei toimuks mutatsioone ega muutuvaid varjunimesid.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// `UnsafeCell`-i järkjärguline initsialiseerimine nõuab `raw_get`-i, kuna `get`-i kutsumiseks oleks vaja luua viide initsialiseerimata andmetele:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Saame #[repr(transparent)]-i tõttu lihtsalt kursori `UnsafeCell<T>`-st `T`-i heita.
        // See kasutab ära libstd eristaatust, pole kasutajakoodile mingit garantiid, et see toimiks kompilaatori future versioonides!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Loob `UnsafeCell`, mille väärtus T on `Default`.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}