//! Koostaja olemus.
//!
//! Vastavad definitsioonid on `compiler/rustc_codegen_llvm/src/intrinsic.rs`-is.
//! Vastavad konstitutsioonid on `compiler/rustc_mir/src/interpret/intrinsics.rs`-is
//!
//! # Const olemused
//!
//! Note: kõik muutused olemuse püsivuses tuleks keelemeeskonnaga arutada.
//! See hõlmab muutusi konstantsuse stabiilsuses.
//!
//! Sisemise kompileerimise ajal kasutatavaks muutmiseks peate rakenduse kopeerima <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs>-ist `compiler/rustc_mir/src/interpret/intrinsics.rs`-i ja lisama `#[rustc_const_unstable(feature = "foo", issue = "01234")]` sisemisse.
//!
//!
//! Kui väidetavalt kasutatakse sisemist omadust `const fn`-st koos atribuudiga `rustc_const_stable`, peab sisemine omadus olema ka `rustc_const_stable`.
//! Sellist muudatust ei tohiks teha ilma T-langi konsultatsioonita, sest see küpsetab keelde funktsiooni, mida pole ilma kompilaatori toeta kasutajakoodis võimalik korrata.
//!
//! # Volatiles
//!
//! Lenduvad sisemised funktsioonid pakuvad toiminguid, mis on mõeldud toimima I/O-mälus ja mida kompilaator garanteerib, et neid ei saa teiste lenduvate sisemiste omaduste korral ümber korraldada.Vaadake [[volatile]]-i LLVM-i dokumentatsiooni.
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Aatomi sisemised omadused võimaldavad masinasõnadega ühiseid aatomioperatsioone, millel on mitu võimalikku mälu järjestust.Nad järgivad sama semantikat kui C++ 11.Vaadake [[atomics]]-i LLVM-i dokumentatsiooni.
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Kiire värskendus mälu tellimisele:
//!
//! * Hankige tõke luku omandamiseks.Järgnevad lugemised ja kirjutamised toimuvad pärast tõket.
//! * Vabastus, tõke luku vabastamiseks.Eelnev lugemine ja kirjutamine toimub enne tõket.
//! * Garanteeritakse järjestikku järjepidevate järjestikuste toimingute järjekord.See on aatomitüüpidega töötamise standardrežiim ja see on samaväärne Java `volatile`-ga.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Seda importi kasutatakse dokumendisiseste linkide lihtsustamiseks
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // OHUTUS: vt `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, need olemused võtavad tooreid näpunäiteid, kuna need muteerivad varjatud mälu, mis ei kehti ei `&` ega `&mut` puhul.
    //

    /// Salvestab väärtuse, kui praegune väärtus on sama kui `old`.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `compare_exchange` kaudu, edastades [`Ordering::SeqCst`] nii `success` kui `failure` parameetritena.
    ///
    /// Näiteks, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Salvestab väärtuse, kui praegune väärtus on sama kui `old`.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `compare_exchange` kaudu, edastades [`Ordering::Acquire`] nii `success` kui `failure` parameetritena.
    ///
    /// Näiteks, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Salvestab väärtuse, kui praegune väärtus on sama kui `old`.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`] tüüpidele meetodi `compare_exchange` kaudu, edastades [`Ordering::Release`] `success` ja [`Ordering::Relaxed`] `failure` parameetritena.
    /// Näiteks, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Salvestab väärtuse, kui praegune väärtus on sama kui `old`.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`] tüüpidele meetodi `compare_exchange` kaudu, edastades [`Ordering::AcqRel`] `success` ja [`Ordering::Acquire`] `failure` parameetritena.
    /// Näiteks, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Salvestab väärtuse, kui praegune väärtus on sama kui `old`.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `compare_exchange` kaudu, edastades [`Ordering::Relaxed`] nii `success` kui `failure` parameetritena.
    ///
    /// Näiteks, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Salvestab väärtuse, kui praegune väärtus on sama kui `old`.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`] tüüpidele meetodi `compare_exchange` kaudu, edastades [`Ordering::SeqCst`] `success` ja [`Ordering::Relaxed`] `failure` parameetritena.
    /// Näiteks, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Salvestab väärtuse, kui praegune väärtus on sama kui `old`.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`] tüüpidele meetodi `compare_exchange` kaudu, edastades [`Ordering::SeqCst`] `success` ja [`Ordering::Acquire`] `failure` parameetritena.
    /// Näiteks, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Salvestab väärtuse, kui praegune väärtus on sama kui `old`.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`] tüüpidele meetodi `compare_exchange` kaudu, edastades [`Ordering::Acquire`] `success` ja [`Ordering::Relaxed`] `failure` parameetritena.
    /// Näiteks, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Salvestab väärtuse, kui praegune väärtus on sama kui `old`.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`] tüüpidele meetodi `compare_exchange` kaudu, edastades [`Ordering::AcqRel`] `success` ja [`Ordering::Relaxed`] `failure` parameetritena.
    /// Näiteks, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Salvestab väärtuse, kui praegune väärtus on sama kui `old`.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `compare_exchange_weak` kaudu, edastades [`Ordering::SeqCst`] nii `success` kui `failure` parameetritena.
    ///
    /// Näiteks, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Salvestab väärtuse, kui praegune väärtus on sama kui `old`.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `compare_exchange_weak` kaudu, edastades [`Ordering::Acquire`] nii `success` kui `failure` parameetritena.
    ///
    /// Näiteks, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Salvestab väärtuse, kui praegune väärtus on sama kui `old`.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`] tüüpidele meetodi `compare_exchange_weak` kaudu, edastades [`Ordering::Release`] `success` ja [`Ordering::Relaxed`] `failure` parameetritena.
    /// Näiteks, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Salvestab väärtuse, kui praegune väärtus on sama kui `old`.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`] tüüpidele meetodi `compare_exchange_weak` kaudu, edastades [`Ordering::AcqRel`] `success` ja [`Ordering::Acquire`] `failure` parameetritena.
    /// Näiteks, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Salvestab väärtuse, kui praegune väärtus on sama kui `old`.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `compare_exchange_weak` kaudu, edastades [`Ordering::Relaxed`] nii `success` kui `failure` parameetritena.
    ///
    /// Näiteks, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Salvestab väärtuse, kui praegune väärtus on sama kui `old`.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`] tüüpidele meetodi `compare_exchange_weak` kaudu, edastades [`Ordering::SeqCst`] `success` ja [`Ordering::Relaxed`] `failure` parameetritena.
    /// Näiteks, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Salvestab väärtuse, kui praegune väärtus on sama kui `old`.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`] tüüpidele meetodi `compare_exchange_weak` kaudu, edastades [`Ordering::SeqCst`] `success` ja [`Ordering::Acquire`] `failure` parameetritena.
    /// Näiteks, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Salvestab väärtuse, kui praegune väärtus on sama kui `old`.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`] tüüpidele meetodi `compare_exchange_weak` kaudu, edastades [`Ordering::Acquire`] `success` ja [`Ordering::Relaxed`] `failure` parameetritena.
    /// Näiteks, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Salvestab väärtuse, kui praegune väärtus on sama kui `old`.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`] tüüpidele meetodi `compare_exchange_weak` kaudu, edastades [`Ordering::AcqRel`] `success` ja [`Ordering::Relaxed`] `failure` parameetritena.
    /// Näiteks, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Laadib kursori praeguse väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `load` kaudu, edastades [`Ordering::SeqCst`] kui `order`.
    /// Näiteks, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Laadib kursori praeguse väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `load` kaudu, edastades [`Ordering::Acquire`] kui `order`.
    /// Näiteks, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Laadib kursori praeguse väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `load` kaudu, edastades [`Ordering::Relaxed`] kui `order`.
    /// Näiteks, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Salvestab väärtuse määratud mälukohta.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `store` kaudu, edastades [`Ordering::SeqCst`] kui `order`.
    /// Näiteks, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Salvestab väärtuse määratud mälukohta.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `store` kaudu, edastades [`Ordering::Release`] kui `order`.
    /// Näiteks, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Salvestab väärtuse määratud mälukohta.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `store` kaudu, edastades [`Ordering::Relaxed`] kui `order`.
    /// Näiteks, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Salvestab väärtuse määratud mälukohta, tagastades vana väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `swap` kaudu, edastades [`Ordering::SeqCst`] kui `order`.
    /// Näiteks, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Salvestab väärtuse määratud mälukohta, tagastades vana väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `swap` kaudu, edastades [`Ordering::Acquire`] kui `order`.
    /// Näiteks, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Salvestab väärtuse määratud mälukohta, tagastades vana väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `swap` kaudu, edastades [`Ordering::Release`] kui `order`.
    /// Näiteks, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Salvestab väärtuse määratud mälukohta, tagastades vana väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `swap` kaudu, edastades [`Ordering::AcqRel`] kui `order`.
    /// Näiteks, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Salvestab väärtuse määratud mälukohta, tagastades vana väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `swap` kaudu, edastades [`Ordering::Relaxed`] kui `order`.
    /// Näiteks, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Lisab praegusele väärtusele, tagastades eelmise väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `fetch_add` kaudu, edastades [`Ordering::SeqCst`] kui `order`.
    /// Näiteks, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lisab praegusele väärtusele, tagastades eelmise väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `fetch_add` kaudu, edastades [`Ordering::Acquire`] kui `order`.
    /// Näiteks, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lisab praegusele väärtusele, tagastades eelmise väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `fetch_add` kaudu, edastades [`Ordering::Release`] kui `order`.
    /// Näiteks, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lisab praegusele väärtusele, tagastades eelmise väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `fetch_add` kaudu, edastades [`Ordering::AcqRel`] kui `order`.
    /// Näiteks, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lisab praegusele väärtusele, tagastades eelmise väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `fetch_add` kaudu, edastades [`Ordering::Relaxed`] kui `order`.
    /// Näiteks, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Lahutage praegusest väärtusest, tagastades eelmise väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `fetch_sub` kaudu, edastades [`Ordering::SeqCst`] kui `order`.
    /// Näiteks, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lahutage praegusest väärtusest, tagastades eelmise väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `fetch_sub` kaudu, edastades [`Ordering::Acquire`] kui `order`.
    /// Näiteks, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lahutage praegusest väärtusest, tagastades eelmise väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `fetch_sub` kaudu, edastades [`Ordering::Release`] kui `order`.
    /// Näiteks, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lahutage praegusest väärtusest, tagastades eelmise väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `fetch_sub` kaudu, edastades [`Ordering::AcqRel`] kui `order`.
    /// Näiteks, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lahutage praegusest väärtusest, tagastades eelmise väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `fetch_sub` kaudu, edastades [`Ordering::Relaxed`] kui `order`.
    /// Näiteks, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Pisuti ja praeguse väärtusega, tagastades eelmise väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `fetch_and` kaudu, edastades [`Ordering::SeqCst`] kui `order`.
    /// Näiteks, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pisuti ja praeguse väärtusega, tagastades eelmise väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `fetch_and` kaudu, edastades [`Ordering::Acquire`] kui `order`.
    /// Näiteks, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pisuti ja praeguse väärtusega, tagastades eelmise väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `fetch_and` kaudu, edastades [`Ordering::Release`] kui `order`.
    /// Näiteks, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pisuti ja praeguse väärtusega, tagastades eelmise väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `fetch_and` kaudu, edastades [`Ordering::AcqRel`] kui `order`.
    /// Näiteks, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pisuti ja praeguse väärtusega, tagastades eelmise väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `fetch_and` kaudu, edastades [`Ordering::Relaxed`] kui `order`.
    /// Näiteks, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Pisuti praeguse väärtusega nand, tagastades eelmise väärtuse.
    ///
    /// Selle sisemise omaduse stabiliseeritud versioon on [`AtomicBool`] tüübil saadaval meetodi `fetch_nand` kaudu, edastades [`Ordering::SeqCst`] kui `order`.
    /// Näiteks, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pisuti praeguse väärtusega nand, tagastades eelmise väärtuse.
    ///
    /// Selle sisemise omaduse stabiliseeritud versioon on [`AtomicBool`] tüübil saadaval meetodi `fetch_nand` kaudu, edastades [`Ordering::Acquire`] kui `order`.
    /// Näiteks, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pisuti praeguse väärtusega nand, tagastades eelmise väärtuse.
    ///
    /// Selle sisemise omaduse stabiliseeritud versioon on [`AtomicBool`] tüübil saadaval meetodi `fetch_nand` kaudu, edastades [`Ordering::Release`] kui `order`.
    /// Näiteks, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pisuti praeguse väärtusega nand, tagastades eelmise väärtuse.
    ///
    /// Selle sisemise omaduse stabiliseeritud versioon on [`AtomicBool`] tüübil saadaval meetodi `fetch_nand` kaudu, edastades [`Ordering::AcqRel`] kui `order`.
    /// Näiteks, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pisuti praeguse väärtusega nand, tagastades eelmise väärtuse.
    ///
    /// Selle sisemise omaduse stabiliseeritud versioon on [`AtomicBool`] tüübil saadaval meetodi `fetch_nand` kaudu, edastades [`Ordering::Relaxed`] kui `order`.
    /// Näiteks, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Pisuti või praeguse väärtusega, tagastades eelmise väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `fetch_or` kaudu, edastades [`Ordering::SeqCst`] kui `order`.
    /// Näiteks, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pisuti või praeguse väärtusega, tagastades eelmise väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `fetch_or` kaudu, edastades [`Ordering::Acquire`] kui `order`.
    /// Näiteks, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pisuti või praeguse väärtusega, tagastades eelmise väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `fetch_or` kaudu, edastades [`Ordering::Release`] kui `order`.
    /// Näiteks, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pisuti või praeguse väärtusega, tagastades eelmise väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `fetch_or` kaudu, edastades [`Ordering::AcqRel`] kui `order`.
    /// Näiteks, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pisuti või praeguse väärtusega, tagastades eelmise väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `fetch_or` kaudu, edastades [`Ordering::Relaxed`] kui `order`.
    /// Näiteks, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Pisuti xor praeguse väärtusega, tagastades eelmise väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `fetch_xor` kaudu, edastades [`Ordering::SeqCst`] kui `order`.
    /// Näiteks, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pisuti xor praeguse väärtusega, tagastades eelmise väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `fetch_xor` kaudu, edastades [`Ordering::Acquire`] kui `order`.
    /// Näiteks, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pisuti xor praeguse väärtusega, tagastades eelmise väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `fetch_xor` kaudu, edastades [`Ordering::Release`] kui `order`.
    /// Näiteks, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pisuti xor praeguse väärtusega, tagastades eelmise väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `fetch_xor` kaudu, edastades [`Ordering::AcqRel`] kui `order`.
    /// Näiteks, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pisuti xor praeguse väärtusega, tagastades eelmise väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`atomic`] tüüpidel saadaval meetodi `fetch_xor` kaudu, edastades [`Ordering::Relaxed`] kui `order`.
    /// Näiteks, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimaalne praeguse väärtusega, kasutades allkirjastatud võrdlust.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`] allkirjastatud täisarvutüüpidel meetodi `fetch_max` kaudu, edastades [`Ordering::SeqCst`] kui `order`.
    /// Näiteks, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimaalne praeguse väärtusega, kasutades allkirjastatud võrdlust.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`] allkirjastatud täisarvutüüpidel meetodi `fetch_max` kaudu, edastades [`Ordering::Acquire`] kui `order`.
    /// Näiteks, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimaalne praeguse väärtusega, kasutades allkirjastatud võrdlust.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`] allkirjastatud täisarvutüüpidel meetodi `fetch_max` kaudu, edastades [`Ordering::Release`] kui `order`.
    /// Näiteks, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimaalne praeguse väärtusega, kasutades allkirjastatud võrdlust.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`] allkirjastatud täisarvutüüpidel meetodi `fetch_max` kaudu, edastades [`Ordering::AcqRel`] kui `order`.
    /// Näiteks, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimaalne praeguse väärtusega.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`] allkirjastatud täisarvutüüpidel meetodi `fetch_max` kaudu, edastades [`Ordering::Relaxed`] kui `order`.
    /// Näiteks, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimaalne praeguse väärtusega, kasutades allkirjastatud võrdlust.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`] allkirjastatud täisarvutüüpidel meetodi `fetch_min` kaudu, edastades [`Ordering::SeqCst`] kui `order`.
    /// Näiteks, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimaalne praeguse väärtusega, kasutades allkirjastatud võrdlust.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`] allkirjastatud täisarvutüüpidel meetodi `fetch_min` kaudu, edastades [`Ordering::Acquire`] kui `order`.
    /// Näiteks, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimaalne praeguse väärtusega, kasutades allkirjastatud võrdlust.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`] allkirjastatud täisarvutüüpidel meetodi `fetch_min` kaudu, edastades [`Ordering::Release`] kui `order`.
    /// Näiteks, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimaalne praeguse väärtusega, kasutades allkirjastatud võrdlust.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`] allkirjastatud täisarvutüüpidel meetodi `fetch_min` kaudu, edastades [`Ordering::AcqRel`] kui `order`.
    /// Näiteks, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimaalne praeguse väärtusega, kasutades allkirjastatud võrdlust.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`] allkirjastatud täisarvutüüpidel meetodi `fetch_min` kaudu, edastades [`Ordering::Relaxed`] kui `order`.
    /// Näiteks, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimaalne praeguse väärtusega, kasutades allkirjastamata võrdlust.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`]-i allkirjastamata täisarvude tüüpidel meetodi `fetch_min` kaudu, edastades [`Ordering::SeqCst`]-i `order`-na.
    /// Näiteks, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimaalne praeguse väärtusega, kasutades allkirjastamata võrdlust.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`]-i allkirjastamata täisarvude tüüpidel meetodi `fetch_min` kaudu, edastades [`Ordering::Acquire`]-i `order`-na.
    /// Näiteks, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimaalne praeguse väärtusega, kasutades allkirjastamata võrdlust.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`]-i allkirjastamata täisarvude tüüpidel meetodi `fetch_min` kaudu, edastades [`Ordering::Release`]-i `order`-na.
    /// Näiteks, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimaalne praeguse väärtusega, kasutades allkirjastamata võrdlust.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`]-i allkirjastamata täisarvude tüüpidel meetodi `fetch_min` kaudu, edastades [`Ordering::AcqRel`]-i `order`-na.
    /// Näiteks, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimaalne praeguse väärtusega, kasutades allkirjastamata võrdlust.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`]-i allkirjastamata täisarvude tüüpidel meetodi `fetch_min` kaudu, edastades [`Ordering::Relaxed`]-i `order`-na.
    /// Näiteks, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimaalne praeguse väärtusega, kasutades allkirjastamata võrdlust.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`]-i allkirjastamata täisarvude tüüpidel meetodi `fetch_max` kaudu, edastades [`Ordering::SeqCst`]-i `order`-na.
    /// Näiteks, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimaalne praeguse väärtusega, kasutades allkirjastamata võrdlust.
    ///
    /// Selle olemuse stabiliseeritud versioon on X0 `fetch_max`-meetodi kaudu saadaval [`atomic`]-i allkirjastamata täisarvutüüpidel, edastades [`Ordering::Acquire`]-i `order`-na.
    /// Näiteks, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimaalne praeguse väärtusega, kasutades allkirjastamata võrdlust.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`]-i allkirjastamata täisarvude tüüpidel meetodi `fetch_max` kaudu, edastades [`Ordering::Release`]-i `order`-na.
    /// Näiteks, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimaalne praeguse väärtusega, kasutades allkirjastamata võrdlust.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`]-i allkirjastamata täisarvude tüüpidel meetodi `fetch_max` kaudu, edastades [`Ordering::AcqRel`]-i `order`-na.
    /// Näiteks, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimaalne praeguse väärtusega, kasutades allkirjastamata võrdlust.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval [`atomic`]-i allkirjastamata täisarvude tüüpidel meetodi `fetch_max` kaudu, edastades [`Ordering::Relaxed`]-i `order`-na.
    /// Näiteks, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Sisemine `prefetch` on vihje koodigeneraatorile eeltõmbamise käsu sisestamiseks, kui see on toetatud;muidu on see keelatud.
    /// Eelhanked ei mõjuta programmi käitumist, kuid võivad muuta selle jõudlusomadusi.
    ///
    /// `locality` argument peab olema konstantne täisarv ja see on ajalise paikkonna spetsifikaator vahemikus (0), ilma paikkonnata kuni (3), äärmiselt lokaalne vahemälus.
    ///
    ///
    /// Sellel olemusel pole stabiilset vastet.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Sisemine `prefetch` on vihje koodigeneraatorile eeltõmbamise käsu sisestamiseks, kui see on toetatud;muidu on see keelatud.
    /// Eelhanked ei mõjuta programmi käitumist, kuid võivad muuta selle jõudlusomadusi.
    ///
    /// `locality` argument peab olema konstantne täisarv ja see on ajalise paikkonna spetsifikaator vahemikus (0), ilma paikkonnata kuni (3), äärmiselt lokaalne vahemälus.
    ///
    ///
    /// Sellel olemusel pole stabiilset vastet.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Sisemine `prefetch` on vihje koodigeneraatorile eeltõmbamise käsu sisestamiseks, kui see on toetatud;muidu on see keelatud.
    /// Eelhanked ei mõjuta programmi käitumist, kuid võivad muuta selle jõudlusomadusi.
    ///
    /// `locality` argument peab olema konstantne täisarv ja see on ajalise paikkonna spetsifikaator vahemikus (0), ilma paikkonnata kuni (3), äärmiselt lokaalne vahemälus.
    ///
    ///
    /// Sellel olemusel pole stabiilset vastet.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Sisemine `prefetch` on vihje koodigeneraatorile eeltõmbamise käsu sisestamiseks, kui see on toetatud;muidu on see keelatud.
    /// Eelhanked ei mõjuta programmi käitumist, kuid võivad muuta selle jõudlusomadusi.
    ///
    /// `locality` argument peab olema konstantne täisarv ja see on ajalise paikkonna spetsifikaator vahemikus (0), ilma paikkonnata kuni (3), äärmiselt lokaalne vahemälus.
    ///
    ///
    /// Sellel olemusel pole stabiilset vastet.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Aatomi tara.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval versioonis [`atomic::fence`], läbides [`Ordering::SeqCst`] kui `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Aatomi tara.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval versioonis [`atomic::fence`], läbides [`Ordering::Acquire`] kui `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Aatomi tara.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval versioonis [`atomic::fence`], läbides [`Ordering::Release`] kui `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Aatomi tara.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval versioonis [`atomic::fence`], läbides [`Ordering::AcqRel`] kui `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Ainult kompilaatorite jaoks mõeldud mälutõke.
    ///
    /// Mälupääsud ei ole kompilaatori poolt selle barjääri kaudu kunagi ümber korraldatud, kuid juhiseid selle kohta ei väljastata.
    /// See sobib sama lõime toimingute jaoks, mis võivad olla ennetatud, näiteks signaalikäsitlejatega suhtlemisel.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval versioonis [`atomic::compiler_fence`], läbides [`Ordering::SeqCst`] kui `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Ainult kompilaatorite jaoks mõeldud mälutõke.
    ///
    /// Mälupääsud ei ole kompilaatori poolt selle barjääri kaudu kunagi ümber korraldatud, kuid juhiseid selle kohta ei väljastata.
    /// See sobib sama lõime toimingute jaoks, mis võivad olla ennetatud, näiteks signaalikäsitlejatega suhtlemisel.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval versioonis [`atomic::compiler_fence`], läbides [`Ordering::Acquire`] kui `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Ainult kompilaatorite jaoks mõeldud mälutõke.
    ///
    /// Mälupääsud ei ole kompilaatori poolt selle barjääri kaudu kunagi ümber korraldatud, kuid juhiseid selle kohta ei väljastata.
    /// See sobib sama lõime toimingute jaoks, mis võivad olla ennetatud, näiteks signaalikäsitlejatega suhtlemisel.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval versioonis [`atomic::compiler_fence`], läbides [`Ordering::Release`] kui `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Ainult kompilaatorite jaoks mõeldud mälutõke.
    ///
    /// Mälupääsud ei ole kompilaatori poolt selle barjääri kaudu kunagi ümber korraldatud, kuid juhiseid selle kohta ei väljastata.
    /// See sobib sama lõime toimingute jaoks, mis võivad olla ennetatud, näiteks signaalikäsitlejatega suhtlemisel.
    ///
    /// Selle olemuse stabiliseeritud versioon on saadaval versioonis [`atomic::compiler_fence`], läbides [`Ordering::AcqRel`] kui `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Sisemine maagia, mis saab oma tähenduse funktsioonile lisatud atribuutidest.
    ///
    /// Näiteks kasutab andmevoog seda staatiliste väidete sisestamiseks, nii et `rustc_peek(potentially_uninitialized)` kontrolliks tegelikult, kas andmevoog arvutas tõepoolest, et see on initsialiseerimata selles juhtimisvoo punktis.
    ///
    ///
    /// Seda olemust ei tohiks kasutada väljaspool kompilaatorit.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Katkestab protsessi täitmise.
    ///
    /// Selle toimingu kasutajasõbralikum ja stabiilsem versioon on [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Teavitab optimeerijat, et koodis pole seda punkti võimalik saavutada, mis võimaldab edasist optimeerimist.
    ///
    /// NB, see erineb `unreachable!()`-i makrost väga erinevalt: erinevalt makrost, mille panics selle käivitamisel on *määratlemata käitumine* jõuda selle funktsiooniga tähistatud koodini.
    ///
    ///
    /// Selle olemuse stabiliseeritud versioon on [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Teavitab optimeerijat, et tingimus on alati tõene.
    /// Kui tingimus on vale, pole käitumist määratletud.
    ///
    /// Sellele sisemisele koodile ei genereerita, kuid optimeerija püüab seda (ja selle seisundit) pääsude vahel säilitada, mis võib häirida ümbritseva koodi optimeerimist ja vähendada jõudlust.
    /// Seda ei tohiks kasutada, kui optimeerija saab invariandi ise avastada või kui see ei võimalda olulisi optimeerimisi.
    ///
    /// Sellel olemusel pole stabiilset vastet.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Vihjeid koostajale, et branch tingimus on tõenäoliselt tõene.
    /// Tagastab talle edastatud väärtuse.
    ///
    /// Mis tahes muul kui `if`-lausetega kasutamisel pole tõenäoliselt mõju.
    ///
    /// Sellel olemusel pole stabiilset vastet.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Vihjeid koostajale, et branch tingimus on tõenäoliselt vale.
    /// Tagastab talle edastatud väärtuse.
    ///
    /// Mis tahes muul kui `if`-lausetega kasutamisel pole tõenäoliselt mõju.
    ///
    /// Sellel olemusel pole stabiilset vastet.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Käivitab siluril kontrollimiseks murdepunktilõksu.
    ///
    /// Sellel olemusel pole stabiilset vastet.
    pub fn breakpoint();

    /// Tüübi suurus baitides.
    ///
    /// Täpsemalt, see on baitide nihe järjestikuste sama tüüpi üksuste, sealhulgas joonduspolstri, vahel.
    ///
    ///
    /// Selle olemuse stabiliseeritud versioon on [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Tüübi minimaalne joondamine.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Tüübi eelistatud joondamine.
    ///
    /// Sellel olemusel pole stabiilset vastet.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Viidatud väärtuse suurus baitides.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Viidatud väärtuse nõutav joondamine.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Saab staatilise stringi viilu, mis sisaldab tüübi nime.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Saab identifikaatori, mis on määratud tüübile globaalselt ainulaadne.
    /// See funktsioon tagastab tüübi jaoks sama väärtuse, olenemata sellest, millises crate-is seda kutsutakse.
    ///
    ///
    /// Selle olemuse stabiliseeritud versioon on [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Valvur ohtlike funktsioonide jaoks, mida ei saa kunagi käivitada, kui `T` on asustamata:
    /// See teeb staatiliselt kas panic või ei tee midagi.
    ///
    /// Sellel olemusel pole stabiilset vastet.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Valvur ohtlike funktsioonide jaoks, mida ei saa kunagi käivitada, kui `T` ei võimalda null-initsialiseerimist: see teeb staatiliselt kas panic või ei tee midagi.
    ///
    ///
    /// Sellel olemusel pole stabiilset vastet.
    pub fn assert_zero_valid<T>();

    /// Valvur ohtlike funktsioonide jaoks, mida ei saa kunagi käivitada, kui `T`-il on valed bitimustrid: see teeb staatiliselt kas panic või ei tee midagi.
    ///
    ///
    /// Sellel olemusel pole stabiilset vastet.
    pub fn assert_uninit_valid<T>();

    /// Saab viite staatilisele `Location`, mis näitab, kuhu seda kutsuti.
    ///
    /// Kaaluge selle asemel [`core::panic::Location::caller`](crate::panic::Location::caller) kasutamist.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Liigutab väärtuse reguleerimisalast välja ilma tilga liimi kasutamata.
    ///
    /// See eksisteerib ainult [`mem::forget_unsized`] puhul;tavaline `forget` kasutab selle asemel `ManuallyDrop`-i.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Tõlgendab ühe tüübi väärtuse bitte uuesti teiseks tüübiks.
    ///
    /// Mõlemal tüübil peab olema sama suurus.
    /// Originaal ega tulemus ei pruugi olla [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` on semantiliselt samaväärne ühe tüübi bitikiirusega teise liikumisega.See kopeerib bitid lähteväärtusest sihtväärtusesse, unustab siis originaali.
    /// See on samaväärne C-ga `memcpy` kapoti all, täpselt nagu `transmute_copy`.
    ///
    /// Kuna `transmute` on kõrvalväärtusega toiming, ei muretse *transmuteeritud väärtuste endi joondamine*.
    /// Nagu kõigi muude funktsioonide puhul, tagab ka kompilaator juba nii `T` kui ka `U` korraliku joondamise.
    /// Väärtuste muundamisel, mis *osutavad mujale*(nt osutid, viited, lahtrid ...), peab helistaja tagama osutatavate väärtuste õige joondamise.
    ///
    /// `transmute` on **uskumatult** ohtlik.Selle funktsiooniga [undefined behavior][ub]-i tekitamiseks on palju võimalusi.`transmute` peaks olema absoluutne viimane võimalus.
    ///
    /// [nomicon](../../nomicon/transmutes.html)-l on täiendav dokumentatsioon.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// On mõned asjad, mille jaoks `transmute` on tõeliselt kasulik.
    ///
    /// Kursori muutmine funktsioonikursoriks.See pole * kaasaskantav masinatele, kus funktsiooninäidikud ja andmeosutid on erineva suurusega.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Eluea pikendamine või muutumatu eluea lühendamine.See on arenenud, väga ohtlik Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Ärge heitke meelt: `transmute`-i paljusid kasutusviise saab saavutada muude vahenditega.
    /// Allpool on `transmute` tavalised rakendused, mida saab asendada ohutumate konstruktsioonidega.
    ///
    /// Toore bytes(`&[u8]`) muutmine `u32`, `f64` jne:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // selle asemel kasutage `u32::from_ne_bytes`-i
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // või kasutage lõppsuse määramiseks `u32::from_le_bytes` või `u32::from_be_bytes`
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Kursori muutmine `usize`-ks:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Kasutage selle asemel `as` valatud
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// `*mut T`-i muutmine `&mut T`-ks:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Kasutage selle asemel laenu
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// `&mut T`-i muutmine `&mut U`-ks:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Pange nüüd `as` kokku ja võtke tagasi, märkige, et `as` aheldamine pole transitiivne
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// `&str`-i muutmine `&[u8]`-ks:
    ///
    /// ```
    /// // see pole hea viis seda teha.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Võite kasutada `str::as_bytes`-i
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Või kasutage lihtsalt baidistringi, kui teil on stringi literaali üle kontroll
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// `Vec<&T>`-i muutmine `Vec<Option<&T>>`-ks.
    ///
    /// Konteineri sisetüübi teisendamiseks peate kindlasti rikkuma konteineri invariante.
    /// `Vec` puhul tähendab see, et nii sisetüüpide suurus *kui ka joondus* peavad vastama.
    /// Teised konteinerid võivad tugineda tüübi suurusele, joondusele või isegi `TypeId`-le, sel juhul ei ole ümbermuutmine konteinerite invariante rikkumata üldse võimalik.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // kloonige vector, kuna me neid hiljem uuesti kasutame
    /// let v_clone = v_orig.clone();
    ///
    /// // Transmute kasutamine: see tugineb `Vec`-i täpsustamata andmete paigutusele, mis on halb mõte ja võib põhjustada määratlemata käitumise.
    /////
    /// // See pole aga koopia.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // See on soovitatud ja ohutu viis.
    /// // See kopeerib kogu vector siiski uude massiivi.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // See on "transmuting" ja `Vec` õige kopeerimata, ebaturvaline viis, tuginedes andmete paigutusele.
    /// // Selle asemel, et sõna otseses mõttes `transmute`-i kutsuda, sooritame kursori näitamise, kuid algse sisemise tüübi (`&i32`) teisendamiseks uueks (`Option<&i32>`) on sellel kõigil samad hoiatused.
    /////
    /// // Lisaks ülaltoodud teabele vaadake ka [`from_raw_parts`] dokumentatsiooni.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Värskendage seda, kui vec_into_raw_parts on stabiliseerunud.
    ///     // Veenduge, et originaali vector ei visata.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// `split_at_mut` juurutamine:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Selle tegemiseks on mitu võimalust ja järgmise (transmute)-viisiga on mitu probleemi.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // esimene: transmuteerimine pole tüüpturvaline;kontrollib ainult seda, et T ja
    ///         // U on sama suurusega.
    ///         // Teiseks, siin on teil kaks muudetavat viidet, mis osutavad samale mälule.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Sellega saab lahti tüübi ohutusprobleemidest;`&mut *` annab* ainult *`&mut T` `&mut T` või `* mut T`-st.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // teil on siiski kaks muutuvat viidet, mis osutavad samale mälule.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Nii teeb seda standardraamatukogu.
    /// // See on parim meetod, kui peate midagi sellist tegema
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Sellel on nüüd kolm muudetavat viidet, mis osutavad samale mälule.`slice`, väärtus ret.0 ja väärtus ret.1.
    ///         // `slice` ei kasutata kunagi pärast `let ptr = ...` ja seetõttu saab seda käsitleda kui "dead", ja seetõttu on teil ainult kaks tõelist muutuvat viilu.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Kuigi see muudab sisemise konst stabiilseks, on meil konst fn-is mõni kohandatud kood
    // kontrollid, mis takistavad selle kasutamist `const fn`-s.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Tagastab `true`, kui tegelik tüüp, mis on märgitud kui `T`, nõuab tilkliimi;tagastab `false`, kui `T` jaoks ette nähtud tegelik tüüp rakendab `Copy`.
    ///
    ///
    /// Kui tegelik tüüp ei vaja tilgaliimi ega rakenda `Copy`-i, pole selle funktsiooni tagastusväärtus täpsustatav.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Arvutab nihke kursori järgi.
    ///
    /// Seda rakendatakse sisemisena, et vältida teisendamist täisarvuks ja täisarvuks, kuna teisendamine viskaks varjunime ära.
    ///
    /// # Safety
    ///
    /// Nii algus-kui ka tulemuskursor peavad olema kas piirides või üks bait mööda eraldatud objekti lõppu.
    /// Kui ükskõik milline osuti on väljaspool piire või tekib aritmeetiline ülevool, põhjustab tagastatud väärtuse edasine kasutamine määratlemata käitumise.
    ///
    ///
    /// Selle olemuse stabiliseeritud versioon on [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Arvutab kursori nihke, mis võib olla mähitud.
    ///
    /// Seda rakendatakse sisemisena, et vältida teisendamist täisarvuks ja täisarvuks, kuna teisendamine pärsib teatud optimeerimisi.
    ///
    /// # Safety
    ///
    /// Erinevalt sisemisest `offset`-st ei piira see sisemine tulemuseks olevat osutit eraldatud objekti lõppu viimiseks ühe baidi taga ja see ümbritseb kahe komplemendi aritmeetikat.
    /// Saadud väärtus ei pruugi tingimata kehtida, et seda mälule tegelikult juurde pääseda.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Samaväärne sobiva sisemise `llvm.memcpy.p0i8.0i8.*`-ga, suurusega `count`*`size_of::<T>()` ja joondusega
    ///
    /// `min_align_of::<T>()`
    ///
    /// Lenduva parameetri väärtuseks on seatud `true`, nii et seda ei optimeerita, kui suurus pole võrdne nulliga.
    ///
    /// Sellel olemusel pole stabiilset vastet.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Samaväärne sobiva sisemise `llvm.memmove.p0i8.0i8.*`-ga, suurusega `count* size_of::<T>()` ja joondusega
    ///
    /// `min_align_of::<T>()`
    ///
    /// Lenduva parameetri väärtuseks on seatud `true`, nii et seda ei optimeerita, kui suurus pole võrdne nulliga.
    ///
    /// Sellel olemusel pole stabiilset vastet.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Samaväärne sobiva sisemise `llvm.memset.p0i8.*`-ga, suurusega `count* size_of::<T>()` ja joondusega `min_align_of::<T>()`.
    ///
    ///
    /// Lenduva parameetri väärtuseks on seatud `true`, nii et seda ei optimeerita, kui suurus pole võrdne nulliga.
    ///
    /// Sellel olemusel pole stabiilset vastet.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Teeb lenduva koormuse `src`-osuti abil.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Teeb `dst`-i osuti lenduva salvestuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Teeb kõikuva koormuse `src`-osuti abil Kursorit pole vaja joondada.
    ///
    ///
    /// Sellel olemusel pole stabiilset vastet.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Teeb `dst`-i osuti lenduva salvestuse.
    /// Kursorit pole vaja joondada.
    ///
    /// Sellel olemusel pole stabiilset vastet.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Tagastab `f32` ruutjuure
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Tagastab `f64` ruutjuure
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Tõstab `f32` täisarvu.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Tõstab `f64` täisarvu.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Tagastab `f32` siinuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Tagastab `f64` siinuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Tagastab `f32` koosinuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Tagastab `f64` koosinuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Tõstab `f32` võimsuseks `f32`.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Tõstab `f64` võimsuseks `f64`.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Tagastab `f32`-i eksponendi.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Tagastab `f64`-i eksponendi.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Tagastab `f32` võimsusele tõstetud 2.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Tagastab `f64` võimsusele tõstetud 2.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Tagastab `f32` loomuliku logaritmi.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Tagastab `f64` loomuliku logaritmi.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Tagastab `f32`-i 10 logaritmi.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Tagastab `f64`-i 10 logaritmi.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Tagastab `f32`-i 2. logaritmi.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Tagastab `f64`-i 2. logaritmi.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Tagastab `f32` väärtuste `a * b + c`.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Tagastab `f64` väärtuste `a * b + c`.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Tagastab `f32` absoluutväärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Tagastab `f64` absoluutväärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Tagastab minimaalse kahe `f32` väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Tagastab minimaalse kahe `f64` väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Tagastab maksimaalselt kahe `f32` väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Tagastab maksimaalselt kahe `f64` väärtuse.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Kopeerib `f32`-väärtuste jaoks märgi `y`-ist `x`-i.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Kopeerib `f64`-väärtuste jaoks märgi `y`-ist `x`-i.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Tagastab suurima täisarvu, mis on väiksem kui `f32` või sellega võrdne.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Tagastab suurima täisarvu, mis on väiksem kui `f64` või sellega võrdne.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Tagastab väikseima täisarvu, mis on suurem või võrdne `f32`-ga.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Tagastab väikseima täisarvu, mis on suurem või võrdne `f64`-ga.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Tagastab `f32` täisarvu.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Tagastab `f64` täisarvu.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Tagastab lähima täisarvu väärtusele `f32`.
    /// Võib tõsta ebatäpse ujukomaerandi, kui argument pole täisarv.
    pub fn rintf32(x: f32) -> f32;
    /// Tagastab lähima täisarvu väärtusele `f64`.
    /// Võib tõsta ebatäpse ujukomaerandi, kui argument pole täisarv.
    pub fn rintf64(x: f64) -> f64;

    /// Tagastab lähima täisarvu väärtusele `f32`.
    ///
    /// Sellel olemusel pole stabiilset vastet.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Tagastab lähima täisarvu väärtusele `f64`.
    ///
    /// Sellel olemusel pole stabiilset vastet.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Tagastab lähima täisarvu väärtusele `f32`.Ümardab pooljuhtumid nullist eemale.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Tagastab lähima täisarvu väärtusele `f64`.Ümardab pooljuhtumid nullist eemale.
    ///
    /// Selle olemuse stabiliseeritud versioon on
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Ujukliide, mis võimaldab optimeerimist algebraliste reeglite alusel.
    /// Võib eeldada, et sisendid on piiratud.
    ///
    /// Sellel olemusel pole stabiilset vastet.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Ujuki lahutamine, mis võimaldab optimeerimist algebraliste reeglite alusel.
    /// Võib eeldada, et sisendid on piiratud.
    ///
    /// Sellel olemusel pole stabiilset vastet.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Ujukkorrutamine, mis võimaldab optimeerimist algebraliste reeglite alusel.
    /// Võib eeldada, et sisendid on piiratud.
    ///
    /// Sellel olemusel pole stabiilset vastet.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Ujukjaotus, mis võimaldab optimeerimist algebraliste reeglite alusel.
    /// Võib eeldada, et sisendid on piiratud.
    ///
    /// Sellel olemusel pole stabiilset vastet.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Ujukijääk, mis võimaldab optimeerimist algebraliste reeglite alusel.
    /// Võib eeldada, et sisendid on piiratud.
    ///
    /// Sellel olemusel pole stabiilset vastet.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Teisendage LLVM-i fptoui/fptosi-iga, mis võib ulatuda vahemikust väljapoole jäävate väärtuste jaoks undef-i
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Stabiliseeritud kui [`f32::to_int_unchecked`] ja [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Tagastab täisarvu `T` määratud bittide arvu
    ///
    /// Selle olemuse stabiliseeritud versioonid on täisarvulistel primitiividel saadaval meetodi `count_ones` kaudu.
    /// Näiteks,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Tagastab `T` juhtivate tühjendusbittide arvu täisarvutüübis `T`.
    ///
    /// Selle olemuse stabiliseeritud versioonid on täisarvulistel primitiividel saadaval meetodi `leading_zeros` kaudu.
    /// Näiteks,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x` väärtusega `0` tagastab `T` biti laiuse.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Nagu `ctlz`, kuid eriti ohtlik, kuna see tagastab `undef`, kui antakse `x` väärtusega `0`.
    ///
    ///
    /// Sellel olemusel pole stabiilset vastet.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Tagastab täisarvutüübis `T` olevate tühistamata bittide arvu (zeroes).
    ///
    /// Selle olemuse stabiliseeritud versioonid on täisarvulistel primitiividel saadaval meetodi `trailing_zeros` kaudu.
    /// Näiteks,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `x` väärtusega `0` tagastab `T` biti laiuse:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Nagu `cttz`, kuid eriti ohtlik, kuna see tagastab `undef`, kui antakse `x` väärtusega `0`.
    ///
    ///
    /// Sellel olemusel pole stabiilset vastet.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Pöörab baidid täisarvu tüübiga `T`.
    ///
    /// Selle olemuse stabiliseeritud versioonid on täisarvulistel primitiividel saadaval meetodi `swap_bytes` kaudu.
    /// Näiteks,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Pöörab bitid täisarvu `T`.
    ///
    /// Selle olemuse stabiliseeritud versioonid on täisarvulistel primitiividel saadaval meetodi `reverse_bits` kaudu.
    /// Näiteks,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Teostab kontrollitud täisarvude liitmise.
    ///
    /// Selle olemuse stabiliseeritud versioonid on täisarvulistel primitiividel saadaval meetodi `overflowing_add` kaudu.
    /// Näiteks,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Teostab kontrollitud täisarvu lahutamise
    ///
    /// Selle olemuse stabiliseeritud versioonid on täisarvulistel primitiividel saadaval meetodi `overflowing_sub` kaudu.
    /// Näiteks,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Teostab kontrollitud täisarvu korrutamise
    ///
    /// Selle olemuse stabiliseeritud versioonid on täisarvulistel primitiividel saadaval meetodi `overflowing_mul` kaudu.
    /// Näiteks,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Teostab täpse jaotuse, mille tulemuseks on määratlemata käitumine, kus `x % y != 0` või `y == 0` või `x == T::MIN && y == -1`
    ///
    ///
    /// Sellel olemusel pole stabiilset vastet.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Teostab kontrollimata jaotuse, mille tulemuseks on määratlemata käitumine, kus `y == 0` või `x == T::MIN && y == -1`
    ///
    ///
    /// Selle sisemise ohutu ümbrised on täisarvulistel primitiividel saadaval meetodi `checked_div` kaudu.
    /// Näiteks,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Tagastab kontrollimata jaotuse ülejäänud osa, mille tulemuseks on määratlemata käitumine `y == 0` või `x == T::MIN && y == -1` korral
    ///
    ///
    /// Selle sisemise ohutu ümbrised on täisarvulistel primitiividel saadaval meetodi `checked_rem` kaudu.
    /// Näiteks,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Teostab kontrollimatu vasaknihke, mille tulemuseks on määratlemata käitumine, kui `y < 0` või `y >= N`, kus N on T laius bittides.
    ///
    ///
    /// Selle sisemise ohutu ümbrised on täisarvulistel primitiividel saadaval meetodi `checked_shl` kaudu.
    /// Näiteks,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Teostab kontrollimatu parempoolse nihke, mille tulemuseks on määratlemata käitumine, kui `y < 0` või `y >= N`, kus N on T laius bittides.
    ///
    ///
    /// Selle sisemise ohutu ümbrised on täisarvulistel primitiividel saadaval meetodi `checked_shr` kaudu.
    /// Näiteks,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Tagastab kontrollimata liitmise tulemuse, mille tulemuseks on määratlemata käitumine `x + y > T::MAX` või `x + y < T::MIN` korral.
    ///
    ///
    /// Sellel olemusel pole stabiilset vastet.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Tagastab kontrollimata lahutamise tulemuse, mille tulemuseks on määratlemata käitumine `x - y > T::MAX` või `x - y < T::MIN` korral.
    ///
    ///
    /// Sellel olemusel pole stabiilset vastet.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Tagastab kontrollimatu korrutise tulemuse, mille tulemuseks on määratlemata käitumine `x *y > T::MAX` või `x* y < T::MIN` korral.
    ///
    ///
    /// Sellel olemusel pole stabiilset vastet.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Teeb pöörde vasakule.
    ///
    /// Selle olemuse stabiliseeritud versioonid on täisarvulistel primitiividel saadaval meetodi `rotate_left` kaudu.
    /// Näiteks,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Teeb pöörde paremale.
    ///
    /// Selle olemuse stabiliseeritud versioonid on täisarvulistel primitiividel saadaval meetodi `rotate_right` kaudu.
    /// Näiteks,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Tagastab (a + b) mod 2 <sup>N</sup>, kus N on T laius bittides.
    ///
    /// Selle olemuse stabiliseeritud versioonid on täisarvulistel primitiividel saadaval meetodi `wrapping_add` kaudu.
    /// Näiteks,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Tagastab (a, b) mod 2 <sup>N</sup>, kus N on T laius bittides.
    ///
    /// Selle olemuse stabiliseeritud versioonid on täisarvulistel primitiividel saadaval meetodi `wrapping_sub` kaudu.
    /// Näiteks,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Tagastab (a * b) mod 2 <sup>N</sup>, kus N on T laius bittides.
    ///
    /// Selle olemuse stabiliseeritud versioonid on täisarvulistel primitiividel saadaval meetodi `wrapping_mul` kaudu.
    /// Näiteks,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Arvutab `a + b`, küllastudes numbriliste piiridega.
    ///
    /// Selle olemuse stabiliseeritud versioonid on täisarvulistel primitiividel saadaval meetodi `saturating_add` kaudu.
    /// Näiteks,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Arvutab `a - b`, küllastudes numbriliste piiridega.
    ///
    /// Selle olemuse stabiliseeritud versioonid on täisarvulistel primitiividel saadaval meetodi `saturating_sub` kaudu.
    /// Näiteks,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Tagastab 'v' variandi diskrimineerija väärtuse;
    /// kui `T`-l pole diskrimineerijat, tagastab `0`.
    ///
    /// Selle olemuse stabiliseeritud versioon on [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Tagastab valatud `T` tüüpi variantide arvu väärtusele `usize`;
    /// kui `T`-l pole variante, tagastab `0`.Asustamata variante arvestatakse.
    ///
    /// Selle olemuse stabiliseeritav versioon on [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust-i "try catch"-konstruktsioon, mis kutsub funktsioonipunkti `try_fn` andmekursoriga `data`.
    ///
    /// Kolmas argument on funktsioon, mida nimetatakse juhul, kui esineb panic.
    /// See funktsioon viib andmekursori ja kursori tabatud sihtmärgipõhise erandi objekti juurde.
    ///
    /// Lisateavet leiate nii kompilaatori allikast kui ka std-i saagi rakendamisest.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Kiirgab LLVM-i järgi `!nontemporal`-i poodi (vt nende dokumente).
    /// Ilmselt ei muutu kunagi stabiilseks.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Lisateavet leiate `<*const T>::offset_from` dokumentatsioonist.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Lisateavet leiate `<*const T>::guaranteed_eq` dokumentatsioonist.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Lisateavet leiate `<*const T>::guaranteed_ne` dokumentatsioonist.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Jaota kompileerimise ajal.Seda ei tohiks käivitamise ajal helistada.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Mõned funktsioonid on siin määratletud, kuna need tehti selles moodulis kogemata stabiilsena kättesaadavaks.
// Vaadake <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` kuulub samuti sellesse kategooriasse, kuid seda ei saa pakendada, kuna kontrollitakse, kas `T` ja `U` on sama suurusega.)
//

/// Kontrollib, kas `ptr` on `align_of::<T>()`-i suhtes õigesti joondatud.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Kopeerib `count *size_of::<T>()` baiti `src`-st `dst`-i.Allikas ja sihtkoht ei tohi* kattuda.
///
/// Mälupiirkondade puhul, mis võivad kattuda, kasutage selle asemel [`copy`]-i.
///
/// `copy_nonoverlapping` on semantiliselt samaväärne C-ga [`memcpy`], kuid argumentide järjekord on vahetatud.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Käitumine on määratlemata, kui rikutakse mõnda järgmistest tingimustest:
///
/// * `src` peab olema [valid], kui loete `count * size_of::<T>()` baiti.
///
/// * `dst` `count * size_of::<T>()`-baitide kirjutamisel peab olema [valid].
///
/// * Nii `src` kui ka `dst` peavad olema õigesti joondatud.
///
/// * `src`-st algav mälupiirkond suurusega `count *
///   suurus_of: :<T>() `baidid ei tohi * kattuda sama suurusega `dst`-st algava mälupiirkonnaga.
///
/// Nagu [`read`], loob ka `copy_nonoverlapping` faili `T` bitipõhise koopia, olenemata sellest, kas `T` on [`Copy`].
/// Kui `T` ei ole [`Copy`], saab [violate memory safety][read-ownership] kasutada *mõlema* väärtusi piirkonnas, mis algab `*src`-st, ja piirkonnas, mis algab `* dst`-st.
///
///
/// Pange tähele, et isegi kui tegelikult kopeeritud suurus (`count * size_of: :<T>()`) on `0`, osutid peavad olema NULL-välised ja õigesti joondatud.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Rakendage [`Vec::append`] käsitsi:
///
/// ```
/// use std::ptr;
///
/// /// Teisaldab kõik `src` elemendid `dst`-i, jättes `src`-i tühjaks.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Veenduge, et `dst`-is on piisavalt ruumi kogu `src`-i mahutamiseks.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Kõne tasaarvestamiseks on alati ohutu, kuna `Vec` ei eralda kunagi rohkem kui `isize::MAX` baiti.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Kärpige `src` sisu viskamata.
///         // Me teeme seda kõigepealt, et vältida probleeme juhul, kui midagi on allpool panics.
///         src.set_len(0);
///
///         // Need kaks piirkonda ei saa kattuda, kuna muudetavad viited ei pseudonüümi ja kahel erineval vektoril ei saa olla sama mälu.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Teavitage `dst`-i, et see sisaldab nüüd `src`-i sisu.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Tehke neid kontrolle ainult käitamise ajal
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Pole paanikat, et koodegeni mõju väiksem oleks.
        abort();
    }*/

    // OHUTUS: `copy_nonoverlapping`-i ohutusleping peab olema
    // helistaja kinnitas.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Kopeerib `count * size_of::<T>()` baiti `src`-st `dst`-i.Allikas ja sihtkoht võivad kattuda.
///
/// Kui allikas ja sihtkoht ei kattu * kunagi, saab selle asemel kasutada [`copy_nonoverlapping`]-i.
///
/// `copy` on semantiliselt samaväärne C-ga [`memmove`], kuid argumentide järjekord on vahetatud.
/// Kopeerimine toimub nii, nagu oleksid baidid kopeeritud `src`-st ajutisse massiivi ja seejärel massiivist `dst`-i.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Käitumine on määratlemata, kui rikutakse mõnda järgmistest tingimustest:
///
/// * `src` peab olema [valid], kui loete `count * size_of::<T>()` baiti.
///
/// * `dst` `count * size_of::<T>()`-baitide kirjutamisel peab olema [valid].
///
/// * Nii `src` kui ka `dst` peavad olema õigesti joondatud.
///
/// Nagu [`read`], loob ka `copy` faili `T` bitipõhise koopia, olenemata sellest, kas `T` on [`Copy`].
/// Kui `T` ei ole [`Copy`], saab [violate memory safety][read-ownership] kasutada nii väärtusi piirkonnas `*src` algavas kui ka piirkonnas `* dst` algavas piirkonnas.
///
///
/// Pange tähele, et isegi kui tegelikult kopeeritud suurus (`count * size_of: :<T>()`) on `0`, osutid peavad olema NULL-välised ja õigesti joondatud.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Looge ohtlikust puhvrist tõhusalt Rust vector:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` peab olema tüübi järgi õigesti joondatud ja nullist erinev.
/// /// * `ptr` peab kehtima `T` tüüpi külgnevate elementide `elts` lugemisel.
/// /// * Neid funktsioone ei tohi pärast funktsiooni kutsumist kasutada, välja arvatud juhul, kui `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // OHUTUS: Meie eeltingimus tagab allika joondamise ja kehtivuse,
///     // ja `Vec::with_capacity` tagab, et meil on nende kirjutamiseks kasutatav ruum.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // OHUTUS: Me lõime selle juba varem sellise mahutavusega,
///     // ja eelmine `copy` on need elemendid initsialiseerinud.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Tehke neid kontrolle ainult käitamise ajal
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Pole paanikat, et koodegeni mõju väiksem oleks.
        abort();
    }*/

    // OHUTUS: helistaja peab kinni pidama seadme `copy` ohutuslepingust.
    unsafe { copy(src, dst, count) }
}

/// Määrab mälu `count * size_of::<T>()` baiti alates `dst` kuni `val`.
///
/// `write_bytes` on sarnane C-ga [`memset`], kuid määrab `count * size_of::<T>()`-baitide väärtuseks `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Käitumine on määratlemata, kui rikutakse mõnda järgmistest tingimustest:
///
/// * `dst` `count * size_of::<T>()`-baitide kirjutamisel peab olema [valid].
///
/// * `dst` peavad olema korralikult joondatud.
///
/// Lisaks peab helistaja tagama, et `count * size_of::<T>()`-baitide kirjutamine antud mälupiirkonda annab kehtiva väärtuse `T`.
/// `T`-na kirjutatud mälupiirkonna kasutamine, mis sisaldab `T`-i valet väärtust, on määratlemata käitumine.
///
/// Pange tähele, et isegi kui tegelikult kopeeritud suurus (`count * size_of: :<T>()`) on `0`, osuti ei tohi olla NULL ja õigesti joondatud.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Põhikasutus:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Kehtetu väärtuse loomine:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Lekib varem hoitud väärtuse, kirjutades `Box<T>`-i nullkursoriga üle.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Siinkohal põhjustab `v`-i kasutamine või mahajätmine määratlemata käitumise.
/// // drop(v); // ERROR
///
/// // Isegi selle lekitamine `v` "uses"-st ja seega on see määratlemata käitumine.
/// // mem::forget(v); // ERROR
///
/// // Tegelikult on `v` põhitüübi paigutusvariandide järgi kehtetu, seega on kõik seda puudutavad * toimingud määratlemata.
/////
/// // olgu v2 =v;//VIGA
///
/// unsafe {
///     // Paneme selle asemel kehtiva väärtuse
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Nüüd on kast korras
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // OHUTUS: helistaja peab kinni pidama seadme `write_bytes` ohutuslepingust.
    unsafe { write_bytes(dst, val, count) }
}