#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future tähistab asünkroonset arvutust.
///
/// future on väärtus, mis ei pruugi arvutust veel lõpetada.
/// Selline "asynchronous value" võimaldab lõimel jätkata kasuliku töö tegemist, kuni see ootab väärtuse kättesaadavaks muutumist.
///
///
/// # `poll` meetod
///
/// future põhimeetod, `poll`,*proovib* lahendada future lõplikuks väärtuseks.
/// See meetod ei blokeeri, kui väärtus pole valmis.
/// Selle asemel on praegune ülesanne plaanitud äratada, kui on võimalik edasise edenemisega uuesti küsitluse teel.
/// Meetodile `poll` edastatud `context` võib anda [`Waker`], mis on käepide praeguse ülesande äratamiseks.
///
/// future-i kasutamisel ei helista te tavaliselt otse `poll`-i, vaid selle asemel väärtus `.await`.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Lõpetamisel toodetud väärtuse tüüp.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Proovige lahendada future lõplikuks väärtuseks, registreerides praeguse ülesande äratamiseks, kui väärtus pole veel saadaval.
    ///
    /// # Tagastusväärtus
    ///
    /// See funktsioon tagastab:
    ///
    /// - [`Poll::Pending`] kui future pole veel valmis
    /// - [`Poll::Ready(val)`] selle future tulemusega `val`, kui see on edukalt lõppenud.
    ///
    /// Kui future on valmis, ei peaks kliendid seda uuesti `poll`-i tegema.
    ///
    /// Kui future pole veel valmis, tagastab `poll` `Poll::Pending` ja salvestab praegusest [`Context`]-st kopeeritud [`Waker`]-i klooni.
    /// Seejärel äratatakse see [`Waker`] üles, kui future saab edasi liikuda.
    /// Näiteks helistab future, kui pesa muutub loetavaks, [`Waker`]-il `.clone()`-i ja salvestab selle.
    /// Kui mujale jõuab signaal, mis näitab, et pesa on loetav, kutsutakse [`Waker::wake`] ja äratatakse pesa future ülesanne.
    /// Kui ülesanne on üles äratatud, peaks ta uuesti proovima `poll` future-i, mis võib anda lõpliku väärtuse või mitte.
    ///
    /// Pange tähele, et korduvalt `poll`-i kõnede korral peaks ajakava saama ajastada ainult kõige uuemale kõnele edastatud [`Context`]-i [`Waker`].
    ///
    /// # Käitusaja omadused
    ///
    /// Ainuüksi tulevikud on *inertsed*;nende edasiliikumiseks tuleb *aktiivselt* küsitleda, mis tähendab, et iga kord, kui praegune ülesanne üles äratatakse, peaks see aktiivselt uuesti küsitlema kuni futures, mille vastu ta on endiselt huvitatud.
    ///
    /// Funktsiooni `poll` ei kutsuta tihedas ringis korduvalt-selle asemel tuleks seda kutsuda ainult siis, kui future näitab, et see on valmis edasiminekuks (helistades `wake()`).
    /// Kui olete Unix-i `poll(2)`-või `select(2)`-süsteemikõnedega tuttav, tasub märkida, et futures tavaliselt *ei* kannatab samu probleeme nagu "all wakeups must poll all events";need sarnanevad pigem `epoll(4)`-ga.
    ///
    /// Rakenduse `poll` peaks püüdma kiiresti naasta ja see ei tohiks blokeerida.Kiire tagastamine hoiab ära lõimede või sündmussilmuste tarbetu ummistumise.
    /// Kui ennetähtaegselt on teada, et kõne `poll`-ile võib veidi aega võtta, tuleks töö X10X-i kiire naasmise tagamiseks niidipooli (või midagi sarnast) maha laadida.
    ///
    /// # Panics
    ///
    /// Kui future on valmis (X0 `poll`-ilt tagastas `Ready`), võib selle `poll`-meetodi uuesti kutsumine panic-i igaveseks blokeerida või põhjustada muid probleeme;`Future` trait ei sea sellise kõne mõjudele nõudeid.
    /// Kuna meetod `poll` ei ole tähistatud `unsafe`, kehtivad Rust tavapärased reeglid: kõned ei tohi kunagi põhjustada määratlemata käitumist (mälu rikkumine, `unsafe` funktsioonide vale kasutamine vms), olenemata future olekust.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}