#![stable(feature = "futures_api", since = "1.36.0")]

//! Asünkroonsed väärtused.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Seda tüüpi on vaja, kuna:
///
/// a) Generaatorid ei saa rakendust `for<'a, 'b> Generator<&'a mut Context<'b>>` rakendada, seega peame edastama toore osuti (vt <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Toored osutid ja `NonNull` ei ole `Send` ega `Sync`, nii et see muudaks ka iga future non-Send/Sync-i ja me ei taha seda.
///
/// Samuti lihtsustab see `.await` HIR langetamist.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Mähi generaator future-i.
///
/// See funktsioon tagastab `GenFuture` all, kuid peidab selle `impl Trait`-is, et anda paremaid veateateid (pigem `impl Future` kui `GenFuture<[closure.....]>`).
///
// See on `const`, et vältida lisavigu pärast `const async fn`-ist taastumist
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Me tugineme asjaolule, et async/await futures on kinnisvara, et luua aluseks olevasse generaatorisse iseenesest viitavaid laene.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // OHUTUS: Ohutu, sest me oleme !Unpin + !Drop ja see on lihtsalt väliprojektsioon.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Taaskäivitage generaator, muutes `&mut Context`-i `NonNull`-i toornäituriks.
            // `.await` langetamine heidab selle turvaliselt tagasi `&mut Context`-i.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // OHUTUS: helistaja peab tagama, et `cx.0` on kehtiv osut
    // mis vastab kõigile muudetava viite nõuetele.
    unsafe { &mut *cx.0.as_ptr().cast() }
}