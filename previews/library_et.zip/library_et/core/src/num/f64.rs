//! `f64` kahekordse täpsusega ujukoma tüübile omased konstandid.
//!
//! *[See also the `f64` primitive type][f64].*
//!
//! Matemaatiliselt olulised arvud on toodud `consts` alamoodulis.
//!
//! Selles moodulis otseselt määratletud konstantide puhul (eristatuna `consts`-alamoodulis määratletutest) peaks uus kood kasutama seonduvaid konstante, mis on määratletud otse tüübil `f64`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// `f64` sisemise kujutise raadius või alus.
/// Kasutage selle asemel [`f64::RADIX`]-i.
///
/// # Examples
///
/// ```rust
/// // aegunud viis
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f64::RADIX;
///
/// // ettenähtud viisil
/// let r = f64::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f64`")]
pub const RADIX: u32 = f64::RADIX;

/// Oluliste numbrite arv baasis 2.
/// Kasutage selle asemel [`f64::MANTISSA_DIGITS`]-i.
///
/// # Examples
///
/// ```rust
/// // aegunud viis
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::MANTISSA_DIGITS;
///
/// // ettenähtud viisil
/// let d = f64::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f64`"
)]
pub const MANTISSA_DIGITS: u32 = f64::MANTISSA_DIGITS;

/// Ligikaudne oluliste numbrite arv baasis 10.
/// Kasutage selle asemel [`f64::DIGITS`]-i.
///
/// # Examples
///
/// ```rust
/// // aegunud viis
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::DIGITS;
///
/// // ettenähtud viisil
/// let d = f64::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f64`")]
pub const DIGITS: u32 = f64::DIGITS;

/// [Machine epsilon] väärtus `f64`.
/// Kasutage selle asemel [`f64::EPSILON`]-i.
///
/// See on erinevus `1.0` ja järgmise suurema esindatava arvu vahel.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // aegunud viis
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f64::EPSILON;
///
/// // ettenähtud viisil
/// let e = f64::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f64`"
)]
pub const EPSILON: f64 = f64::EPSILON;

/// Väikseim lõplik `f64` väärtus.
/// Kasutage selle asemel [`f64::MIN`]-i.
///
/// # Examples
///
/// ```rust
/// // aegunud viis
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN;
///
/// // ettenähtud viisil
/// let min = f64::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f64`")]
pub const MIN: f64 = f64::MIN;

/// Väikseim positiivne normaalne `f64` väärtus.
/// Kasutage selle asemel [`f64::MIN_POSITIVE`]-i.
///
/// # Examples
///
/// ```rust
/// // aegunud viis
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_POSITIVE;
///
/// // ettenähtud viisil
/// let min = f64::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f64`"
)]
pub const MIN_POSITIVE: f64 = f64::MIN_POSITIVE;

/// Suurim lõplik `f64` väärtus.
/// Kasutage selle asemel [`f64::MAX`]-i.
///
/// # Examples
///
/// ```rust
/// // aegunud viis
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX;
///
/// // ettenähtud viisil
/// let max = f64::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f64`")]
pub const MAX: f64 = f64::MAX;

/// Üks suurem kui 2 eksponendi minimaalne võimalik normvõimsus.
/// Kasutage selle asemel [`f64::MIN_EXP`]-i.
///
/// # Examples
///
/// ```rust
/// // aegunud viis
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_EXP;
///
/// // ettenähtud viisil
/// let min = f64::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f64`"
)]
pub const MIN_EXP: i32 = f64::MIN_EXP;

/// 2 eksponendi maksimaalne võimalik võimsus.
/// Kasutage selle asemel [`f64::MAX_EXP`]-i.
///
/// # Examples
///
/// ```rust
/// // aegunud viis
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_EXP;
///
/// // ettenähtud viisil
/// let max = f64::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f64`"
)]
pub const MAX_EXP: i32 = f64::MAX_EXP;

/// Minimaalne võimalik normvõimsus 10 eksponenti.
/// Kasutage selle asemel [`f64::MIN_10_EXP`]-i.
///
/// # Examples
///
/// ```rust
/// // aegunud viis
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_10_EXP;
///
/// // ettenähtud viisil
/// let min = f64::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f64`"
)]
pub const MIN_10_EXP: i32 = f64::MIN_10_EXP;

/// Maksimaalne võimalik võimsus 10 eksponenti.
/// Kasutage selle asemel [`f64::MAX_10_EXP`]-i.
///
/// # Examples
///
/// ```rust
/// // aegunud viis
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_10_EXP;
///
/// // ettenähtud viisil
/// let max = f64::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f64`"
)]
pub const MAX_10_EXP: i32 = f64::MAX_10_EXP;

/// Mitte number (NaN).
/// Kasutage selle asemel [`f64::NAN`]-i.
///
/// # Examples
///
/// ```rust
/// // aegunud viis
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f64::NAN;
///
/// // ettenähtud viisil
/// let nan = f64::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f64`")]
pub const NAN: f64 = f64::NAN;

/// Infinity (∞).
/// Kasutage selle asemel [`f64::INFINITY`]-i.
///
/// # Examples
///
/// ```rust
/// // aegunud viis
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f64::INFINITY;
///
/// // ettenähtud viisil
/// let inf = f64::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f64`"
)]
pub const INFINITY: f64 = f64::INFINITY;

/// Negatiivne lõpmatus (−∞).
/// Kasutage selle asemel [`f64::NEG_INFINITY`]-i.
///
/// # Examples
///
/// ```rust
/// // aegunud viis
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f64::NEG_INFINITY;
///
/// // ettenähtud viisil
/// let ninf = f64::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f64`"
)]
pub const NEG_INFINITY: f64 = f64::NEG_INFINITY;

/// Matemaatilised põhikonstandid.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: asendada cmath matemaatiliste konstantidega.

    /// Archimedese konstant (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f64 = 3.14159265358979323846264338327950288_f64;

    /// Täisringi konstant (τ)
    ///
    /// Võrdne 2π-ga.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f64 = 6.28318530717958647692528676655900577_f64;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f64 = 1.57079632679489661923132169163975144_f64;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f64 = 1.04719755119659774615421446109316763_f64;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f64 = 0.785398163397448309615660845819875721_f64;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f64 = 0.52359877559829887307710723054658381_f64;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f64 = 0.39269908169872415480783042290993786_f64;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f64 = 0.318309886183790671537767526745028724_f64;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f64 = 0.636619772367581343075535053490057448_f64;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f64 = 1.12837916709551257389615890312154517_f64;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f64 = 1.41421356237309504880168872420969808_f64;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f64 = 0.707106781186547524400844362104849039_f64;

    /// Euleri number (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f64 = 2.71828182845904523536028747135266250_f64;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f64 = 3.32192809488736234787031942948939018_f64;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f64 = 1.44269504088896340735992468100189214_f64;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f64 = 0.301029995663981195213738894724493027_f64;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f64 = 0.434294481903251827651128918916605082_f64;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f64 = 0.693147180559945309417232121458176568_f64;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f64 = 2.30258509299404568401799145468436421_f64;
}

#[lang = "f64"]
#[cfg(not(test))]
impl f64 {
    /// `f64` sisemise kujutise raadius või alus.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Oluliste numbrite arv baasis 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 53;
    /// Ligikaudne oluliste numbrite arv baasis 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 15;

    /// [Machine epsilon] väärtus `f64`.
    ///
    /// See on erinevus `1.0` ja järgmise suurema esindatava arvu vahel.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f64 = 2.2204460492503131e-16_f64;

    /// Väikseim lõplik `f64` väärtus.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f64 = -1.7976931348623157e+308_f64;
    /// Väikseim positiivne normaalne `f64` väärtus.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f64 = 2.2250738585072014e-308_f64;
    /// Suurim lõplik `f64` väärtus.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f64 = 1.7976931348623157e+308_f64;

    /// Üks suurem kui 2 eksponendi minimaalne võimalik normvõimsus.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -1021;
    /// 2 eksponendi maksimaalne võimalik võimsus.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 1024;

    /// Minimaalne võimalik normvõimsus 10 eksponenti.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -307;
    /// Maksimaalne võimalik võimsus 10 eksponenti.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 308;

    /// Mitte number (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f64 = 0.0_f64 / 0.0_f64;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f64 = 1.0_f64 / 0.0_f64;
    /// Negatiivne lõpmatus (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f64 = -1.0_f64 / 0.0_f64;

    /// Tagastab `true`, kui see väärtus on `NaN`.
    ///
    /// ```
    /// let nan = f64::NAN;
    /// let f = 7.0_f64;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` pole libcore'is avalikult kättesaadav, kuna on mures teisaldatavuse pärast, seega on see rakendus isiklikult sisekasutuseks.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f64 {
        f64::from_bits(self.to_bits() & 0x7fff_ffff_ffff_ffff)
    }

    /// Tagastab `true`, kui see väärtus on positiivne lõpmatus või negatiivne lõpmatus, ja muul juhul `false`.
    ///
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf = f64::INFINITY;
    /// let neg_inf = f64::NEG_INFINITY;
    /// let nan = f64::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Tagastab `true`, kui see arv pole lõpmatu ega `NaN`.
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf: f64 = f64::INFINITY;
    /// let neg_inf: f64 = f64::NEG_INFINITY;
    /// let nan: f64 = f64::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // NaN-i pole vaja eraldi käsitleda: kui mina on NaN, pole võrdlus õige, täpselt nii nagu soovitud.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Tagastab `true`, kui number on [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308_f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0_f64;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f64::NAN.is_subnormal());
    /// assert!(!f64::INFINITY.is_subnormal());
    /// // Väärtused `0` ja `min` vahel on ebaharilikud.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Tagastab `true`, kui arv pole null, lõpmatu, [subnormal] või `NaN`.
    ///
    ///
    /// ```
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0f64;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f64::NAN.is_normal());
    /// assert!(!f64::INFINITY.is_normal());
    /// // Väärtused `0` ja `min` vahel on ebaharilikud.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Tagastab arvu ujukoma kategooria.
    /// Kui testida kavatsetakse ainult ühte omadust, on selle asemel konkreetse predikaadi kasutamine kiirem.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f64;
    /// let inf = f64::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u64 = 0x7ff0000000000000;
        const MAN_MASK: u64 = 0x000fffffffffffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Tagastab `true`, kui `self`-l on positiivne märk, sealhulgas `+0.0`, positiivse märgibitiga "NaN" ja lõpmatu.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_positive")]
    #[inline]
    #[doc(hidden)]
    pub fn is_positive(self) -> bool {
        self.is_sign_positive()
    }

    /// Tagastab `true`, kui `self`-l on negatiivne märk, sealhulgas `-0.0`, negatiivse märgibitiga "NaN" ja lõpmatu negatiivne.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        self.to_bits() & 0x8000_0000_0000_0000 != 0
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_negative")]
    #[inline]
    #[doc(hidden)]
    pub fn is_negative(self) -> bool {
        self.is_sign_negative()
    }

    /// Võtab numbri vastastikuse (inverse), `1/x`.
    ///
    /// ```
    /// let x = 2.0_f64;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f64 {
        1.0 / self
    }

    /// Teisendab radiaanid kraadidesse.
    ///
    /// ```
    /// let angle = std::f64::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_degrees(self) -> f64 {
        // Jaotus on siin õigesti ümardatud tegeliku väärtuse 180/π suhtes.
        // (See erineb f32-st, kus korrektselt ümardatud tulemuse tagamiseks tuleb kasutada konstandi.)
        //
        self * (180.0f64 / consts::PI)
    }

    /// Teisendab kraadid radiaanideks.
    ///
    /// ```
    /// let angle = 180.0_f64;
    ///
    /// let abs_difference = (angle.to_radians() - std::f64::consts::PI).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_radians(self) -> f64 {
        let value: f64 = consts::PI;
        self * (value / 180.0)
    }

    /// Tagastab kahe numbri maksimumi.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Kui üks argumentidest on NaN, tagastatakse teine argument.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f64) -> f64 {
        intrinsics::maxnumf64(self, other)
    }

    /// Tagastab kahe numbri miinimumi.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Kui üks argumentidest on NaN, tagastatakse teine argument.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f64) -> f64 {
        intrinsics::minnumf64(self, other)
    }

    /// Ümardab nulli poole ja teisendab suvaliseks primitiivseks täisarvutüübiks, eeldades, et väärtus on piiratud ja sobib sellesse tüüpi.
    ///
    ///
    /// ```
    /// let value = 4.6_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Väärtus peab:
    ///
    /// * Ära ole `NaN`
    /// * Ära ole lõpmatu
    /// * Olge esindatav tagasitüübis `Int`, pärast selle murdosa eemaldamist
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // OHUTUS: helistaja peab järgima `FloatToInt::to_int_unchecked`-i ohutuslepingut.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Toores transmutatsioon `u64`-le.
    ///
    /// See on kõigil platvormidel praegu identne `transmute::<f64, u64>(self)`-iga.
    ///
    /// Selle toimingu kaasaskantavuse arutamiseks vt `from_bits` (probleeme pole peaaegu üldse).
    ///
    /// Pange tähele, et see funktsioon erineb `as`-ülekandest, mis püüab säilitada *numbrilist* väärtust, mitte biti väärtust.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((1f64).to_bits() != 1f64 as u64); // to_bits() ei ole casting!
    /// assert_eq!((12.5f64).to_bits(), 0x4029000000000000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u64 {
        // OHUTUS: `u64` on tavaline vana andmetüüp, nii et saame selle alati teisendada
        unsafe { mem::transmute(self) }
    }

    /// Toores transmutatsioon `u64`-ist.
    ///
    /// See on kõigil platvormidel praegu identne `transmute::<u64, f64>(v)`-iga.
    /// Selgub, et see on uskumatult kaasaskantav kahel põhjusel:
    ///
    /// * Ujukitel ja Intsidel on kõigil toetatud platvormidel sama otsustusvõime.
    /// * IEEE-754 määratleb ujukite bittide paigutuse väga täpselt.
    ///
    /// Siiski on üks hoiatus: enne IEEE-754 2008. aasta versiooni ei olnud NaN-signaalibitti tõlgendamine tegelikult täpsustatud.
    /// Enamik platvorme (eriti x86 ja ARM) valisid tõlgenduse, mis 2008. aastal lõpuks standardiseeriti, kuid mõned ei teinud seda (eriti MIPS).
    /// Selle tulemusena on kõik signaaliga NaN-id MIPS-is vaiksed NaN-id x86-is ja vastupidi.
    ///
    /// Selle rakendamise asemel soositakse signalisatsiooniülese platvormi säilitamist, kuid see soosib täpsete bitide säilitamist.
    /// See tähendab, et kõik NaN-ide kodeeritud kasulikud koormused säilivad ka siis, kui selle meetodi tulemus saadetakse üle võrgu x86-masinast MIPS-i.
    ///
    ///
    /// Kui selle meetodi tulemustega manipuleerib ainult sama arhitektuur, mis need on loonud, siis pole kaasaskantavuse probleemi.
    ///
    /// Kui sisend pole NaN, siis pole kaasaskantavuse probleem.
    ///
    /// Kui te ei hooli signaalimisest (väga tõenäoline), siis pole kaasaskantavuse mure.
    ///
    /// Pange tähele, et see funktsioon erineb `as`-ülekandest, mis püüab säilitada *numbrilist* väärtust, mitte biti väärtust.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f64::from_bits(0x4029000000000000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u64) -> Self {
        // OHUTUS: `u64` on tavaline vana andmetüüp, nii et saame sellest alati teisendada
        // Selgub, et sNaNi ohutusprobleemid olid liiga suured!Hurraa!
        unsafe { mem::transmute(v) }
    }

    /// Tagastab selle ujukomaarvu kujutise baidimassiivina suureotsa (network)-baidi järjekorras.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_be_bytes();
    /// assert_eq!(bytes, [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 8] {
        self.to_bits().to_be_bytes()
    }

    /// Tagastab selle ujukoma numbri kujutise baidimassiivina väikeste endide baitide järjekorras.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 8] {
        self.to_bits().to_le_bytes()
    }

    /// Tagastab selle ujukoma numbri mäluesituse baitide massiivina emakeelse baidi järjekorras.
    ///
    /// Kuna kasutatakse sihtplatvormi looduslikku endiaansust, peaks kaasaskantav kood selle asemel kasutama vastavalt [`to_be_bytes`] või [`to_le_bytes`].
    ///
    ///
    /// [`to_be_bytes`]: f64::to_be_bytes
    /// [`to_le_bytes`]: f64::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 8] {
        self.to_bits().to_ne_bytes()
    }

    /// Tagastab selle ujukoma numbri mäluesituse baitide massiivina emakeelse baidi järjekorras.
    ///
    ///
    /// [`to_ne_bytes`] võimaluse korral tuleks sellele eelistada.
    ///
    /// [`to_ne_bytes`]: f64::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f64;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 8] {
        // OHUTUS: `f64` on tavaline vana andmetüüp, nii et saame selle alati teisendada
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Looge selle kujutamisel ujukoma väärtus baidimassiivina suurtes endiaanides.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_be_bytes([0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_be_bytes(bytes))
    }

    /// Looge selle esitusviisist hõljuva punkti väärtus baidimassiivina väikese endiaanina.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_le_bytes([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_le_bytes(bytes))
    }

    /// Looge ujukoma väärtus selle esitusviisist natiivsetes endiides baitide massiivina.
    ///
    /// Kuna kasutatakse sihtplatvormi looduslikku endiaansust, soovib kaasaskantav kood selle asemel kasutada vastavalt vajadusele [`from_be_bytes`] või [`from_le_bytes`].
    ///
    ///
    /// [`from_be_bytes`]: f64::from_be_bytes
    /// [`from_le_bytes`]: f64::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_ne_bytes(bytes))
    }

    /// Tagastab järjestuse enese ja muude väärtuste vahel.
    /// Erinevalt ujukomaarvude tavapärasest osalisest võrdlusest saadakse selle võrdluse abil alati tellimus vastavalt totalOrderi predikaadile, nagu on määratletud IEEE 754 (2008. aasta redaktsioon) ujukoma standardis.
    /// Väärtused on järjestatud järgmises järjekorras:
    /// - Negatiivne vaikne NaN
    /// - Negatiivne signaal NaN
    /// - Negatiivne lõpmatus
    /// - Negatiivsed arvud
    /// - Negatiivsed subnormaalsed arvud
    /// - Negatiivne null
    /// - Positiivne null
    /// - Positiivsed ebaharilikud arvud
    /// - Positiivsed arvud
    /// - Positiivne lõpmatus
    /// - Positiivne signaal NaN
    /// - Positiivne vaikne NaN
    ///
    /// Pange tähele, et see funktsioon ei ole alati kooskõlas `f64`-i rakendustega [`PartialOrd`] ja [`PartialEq`].Eelkõige peavad nad negatiivset ja positiivset nulli võrdseks, samas kui `total_cmp` mitte.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f64,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f64::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f64::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f64::INFINITY, f64::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i64;
        let mut right = other.to_bits() as i64;

        // Negatiivide korral klappige kõik bitid, välja arvatud märk, et saavutada kahe komplemendi täisarvudega sarnane paigutus
        //
        // Miks see töötab?IEEE 754 ujukid koosnevad kolmest väljast:
        // Märgibitt, eksponent ja mantissa.Eksponent-ja mantissa väljade komplektil tervikuna on omadus, et nende bittjärjestus on võrdne arvulise suurusega, kus suurus on määratletud.
        // Suurust ei määratleta tavaliselt NaN-i väärtuste järgi, kuid IEEE 754 totalOrder määratleb NaN-väärtused ka järgides bittjärjestust.See toob kaasa dokumendi kommentaaris selgitatud korra.
        // Negatiivsete ja positiivsete arvude puhul on suurusjärgu esitus siiski sama-erinev on ainult märgibitt.
        // Ujukite märkide täisarvudena hõlpsaks võrdlemiseks peame negatiivsete arvude korral eksponendi ja mantissa biti ümber pöörama.
        // Teisendame numbrid tõhusalt vormingusse "two's complement".
        //
        // Lehitsemise jaoks konstrueerime selle vastu maski ja XOR.
        // "all-ones except for the sign bit" maski arvutame harutult negatiivselt allkirjastatud väärtuste põhjal: parempoolne nihutamismärk pikendab täisarvu, nii et me "fill" maski märkibittidega ja teisendame seejärel märkimata, et lükata veel üks nullbit.
        //
        // Positiivsete väärtuste puhul on mask kõik nullid, nii et see on keelatud.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 63) as u64) >> 1) as i64;
        right ^= (((right >> 63) as u64) >> 1) as i64;

        left.cmp(&right)
    }

    /// Piirake väärtus kindla intervalliga, kui see pole NaN.
    ///
    /// Tagastab `max`, kui `self` on suurem kui `max`, ja `min`, kui `self` on väiksem kui `min`.
    /// Vastasel juhul tagastatakse `self`.
    ///
    /// Pange tähele, et see funktsioon tagastab NaN, kui ka algväärtus oli NaN.
    ///
    /// # Panics
    ///
    /// Panics, kui `min > max`, `min` on NaN või `max` on NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f64).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f64).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f64).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f64::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f64, max: f64) -> f64 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}