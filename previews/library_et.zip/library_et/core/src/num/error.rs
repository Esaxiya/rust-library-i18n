//! Veatüübid integreeritud tüüpideks teisendamiseks.

use crate::convert::Infallible;
use crate::fmt;

/// Veatüüp tagastati, kui kontrollitud integraalse tüübi teisendamine ebaõnnestub.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Sobitage pigem sundimise asemel, et veenduda, et ülaltoodud kood `From<Infallible> for TryFromIntError` töötab ka siis, kui `Infallible`-st saab `!`-i pseudonüüm.
        //
        //
        match never {}
    }
}

/// Viga, mille saab tagastada täisarvu parsimisel.
///
/// Seda viga kasutatakse funktsioonide `from_str_radix()` tõrke tüübina primitiivsete täisarvude tüüpidel, näiteks [`i8::from_str_radix`].
///
/// # Võimalikud põhjused
///
/// Muude põhjuste hulgas võib `ParseIntError` visata stringi ees või taga oleva tühimiku tõttu, nt kui see on saadud standardsisendist.
///
/// [`str::trim()`]-meetodi kasutamine tagab, et enne sõelumist ei jää tühikuid.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum salvestab erinevat tüüpi vead, mis võivad põhjustada täisarvu parsimise nurjumise.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Sõeluv väärtus on tühi.
    ///
    /// Lisaks muudele põhjustele konstrueeritakse see variant tühja stringi parsimisel.
    Empty,
    /// Sisaldab kontekstis valet numbrit.
    ///
    /// Lisaks muudele põhjustele konstrueeritakse see variant stringi parsimisel, mis sisaldab mitte-ASCII sümboleid.
    ///
    /// See variant konstrueeritakse ka siis, kui `+` või `-` paigutatakse stringi sisse kas eraldi või numbri keskel.
    ///
    ///
    InvalidDigit,
    /// Täisarv on sihtarvu täisarvu salvestamiseks liiga suur.
    PosOverflow,
    /// Täisarv on sihtarvu täisarvu salvestamiseks liiga väike.
    NegOverflow,
    /// Väärtus oli null
    ///
    /// See variant väljastatakse siis, kui sõelumisstringi väärtus on null, mis oleks nullist erinevate tüüpide puhul ebaseaduslik.
    ///
    Zero,
}

impl ParseIntError {
    /// Väljendab täisarvu nurjumise üksikasjaliku põhjuse.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}