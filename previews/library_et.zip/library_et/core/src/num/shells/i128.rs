//! Konstantse 128-bitise allkirjastatud täisarvu tüübiga.
//!
//! *[See also the `i128` primitive type][i128].*
//!
//! Uus kood peaks kasutama seotud konstandid otse primitiivse tüübi jaoks.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i128`"
)]

int_module! { i128, #[stable(feature = "i128", since="1.26.0")] }