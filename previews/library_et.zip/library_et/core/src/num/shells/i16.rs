//! Konstantse 16-bitise allkirjastatud täisarvu tüübiga.
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! Uus kood peaks kasutama seotud konstandid otse primitiivse tüübi jaoks.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }