//! Kursori suurusega signeeritud täisarvu tüübi konstandid.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! Uus kood peaks kasutama seotud konstandid otse primitiivse tüübi jaoks.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }