//! Paberi erinevad algoritmid.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Tähendusbittide arv Fp-s
const P: u32 = 64;

// Salvestame lihtsalt kõigi * eksponentide parima lähenduse, nii et muutuja "h" ja sellega seotud tingimused võib välja jätta.
// See müüb jõudlust paari kilobaiti ruumi jaoks.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Enamikus arhitektuurides on ujukomaoperatsioonidel selgesõnaline bittisuurus, seetõttu määratakse arvutamise täpsus operatsiooni kohta.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// x86-is kasutatakse ujukitoiminguteks x87 FPU-d, kui laiendusi SSE/SSE2 pole saadaval.
// x87 FPU töötab vaikimisi 80-bitise täpsusega, mis tähendab, et toimingud ümardatakse 80-bitini, mis põhjustab topelt ümardamise, kui väärtused esitatakse lõpuks
//
// 32/64 biti ujukväärtused.Selle ületamiseks saab FPU kontrollsõna seada nii, et arvutused sooritatakse soovitud täpsusega.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Struktuur, mida kasutatakse FPU kontrollsõna algväärtuse säilitamiseks, nii et selle saab struktuuri langedes taastada.
    ///
    ///
    /// x87 FPU on 16-bitine register, mille väljad on järgmised:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Kõigi väljade dokumentatsioon on saadaval tarkvara IA-32 Architectures Developer Manual (1. köide).
    ///
    /// Ainus väli, mis on järgmise koodi jaoks asjakohane, on PC, Precision Control.
    /// See väli määrab FPU tehtud toimingute täpsuse.
    /// Selle saab seada järgmisele:
    ///  - 0b00, ühe täpsusega, st 32-bitine
    ///  - 0b10, topelttäpsus, st 64-bitine
    ///  - 0b11, kahekordne laiendatud täpsus, st 80-bitine (vaikeseisund) 0b01 väärtus on reserveeritud ja seda ei tohiks kasutada.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // OHUTUS: `fldcw` juhis on auditeeritud, et see saaks õigesti töötada
        // mis tahes `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: LLVM 8 ja LLVM 9 toetamiseks kasutame ATT süntaksit.
                options(att_syntax, nostack),
            )
        }
    }

    /// Määrab FPU täpsusvälja väärtuseks `T` ja tagastab `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Arvutage välja `T` jaoks sobiva välja Precision Control väärtus.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bitti
            8 => 0x0200, // 64 bitti
            _ => 0x0300, // vaikimisi 80 bitti
        };

        // Hankige juhtsõna algväärtus, et see hiljem taastada, kui struktuur `FPUControlWord` langeb. OHUTUS: `fnstcw`-käsk on kontrollitud, et see saaks õigesti töötada mis tahes `u16`-iga
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: LLVM 8 ja LLVM 9 toetamiseks kasutame ATT süntaksit.
                options(att_syntax, nostack),
            )
        }

        // Määrake juhtsõna soovitud täpsusega.
        // See saavutatakse vana täpsuse (bitid 8 ja 9, 0x300) maskeerimisega ja asendatakse ülalkirjeldatud täpsusega lipuga.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Bellerophoni kiire tee masinasuuruste täisarvude ja ujukite abil.
///
/// See eraldatakse eraldi funktsiooniks, nii et seda saab proovida enne bignumi koostamist.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Võrdleme lõpu lähedal täpset väärtust MAX_SIG-ga, see on lihtsalt kiire ja odav tagasilükkamine (ja vabastab ka ülejäänud koodi alamvoolu muretsemisest).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Kiire tee sõltub olulisel määral aritmeetika ümardamisest õige bittide arvuni ilma vahepealse ümardamiseta.
    // x86-is (ilma SSE või SSE2) nõuab see x87 FPU-virna täpsuse muutmist nii, et see ümardaks otse 64/32-bitini.
    // Funktsioon `set_precision` hoolitseb arhitektuuride täpsuse seadmise eest, mis vajavad selle seadistamist globaalse oleku muutmisega (nagu x87 FPU juhtsõna).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Juhtumit e <0 ei saa teiseks oksaks kokku panna.
    // Negatiivsete jõudude tulemuseks on korduv murdosa binaaris, mis on ümardatud, mis põhjustab lõpptulemuses tõelisi (ja aeg-ajalt üsna märkimisväärseid!) Vigu.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algoritm Bellerophon on triviaalne kood, mida õigustab mitte triviaalne numbriline analüüs.
///
/// See ümardab "f" 64-bitise tähisega ujukiks ja korrutab selle `10^e` parima lähendusega (samas ujukomaformaadis).Õige tulemuse saamiseks piisab sellest sageli.
/// Kui tulemus on aga kahe kõrvuti asuva (ordinary) ujuki vahepeal poolel teel, tähendab kahe ümardamise korrutamisel saadud ümardamisviga, et tulemus võib mõne bitiga välja lülituda.
/// Kui see juhtub, parandab korduv algoritm R asjad ära.
///
/// Käsitsi laineline "close to halfway" on täpsustatud paberil tehtud arvnäitajate abil.
/// Clingeri sõnadega:
///
/// > Kalle, mis on väljendatud kõige vähem olulise biti ühikutes, on veaga seotud
/// > f * 10 ^ e lähenduskoha arvutamisel kogunenud.(Slop on
/// > ei ole seotud tõelise veaga, kuid piirab lähenduste z ja
/// > parimat võimalikku lähendust, mis kasutab p tähendusbitti.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Juhtumid abs(e) <log5(2^N) on fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Kas kalle on piisavalt suur, et n-bitini ümardamisel muutust teha?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Iteratiivne algoritm, mis parandab `f * 10^e` ujukoma lähendust.
///
/// Iga iteratsioon saab ühe ühiku viimasel kohal lähemale, mille lähenemine võtab muidugi kohutavalt kaua aega, kui `z0` on isegi kergelt välja lülitatud.
/// Õnneks, kui seda kasutatakse Bellerophoni varuvarustusena, on lähtearvestus maksimaalselt ühe ULP-ga välja lülitatud.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Leidke positiivsed täisarvud `x`, `y` nii, et `x / y` oleks täpselt `(f *10^e) / (m* 2^k)`.
        // See väldib mitte ainult `e` ja `k` märkidega tegelemist, vaid välistame ka `10^e` ja `2^k` kahe ühise jõu numbriteks väiksemaks muuta.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // See on kirjutatud natuke kohmakalt, kuna meie bignumid ei toeta negatiivseid arve, seega kasutame absoluutväärtust + märgi teavet.
        // M_digitsiga korrutamine ei saa üle voolata.
        // Kui `x` või `y` on piisavalt suured, et peame muretsema ülevoolu pärast, siis on need ka piisavalt suured, et `make_ratio` on vähendanud murdosa 2 ^ 64 või rohkem.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Enam pole x-i vaja, salvestage clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Ikka vajate y, tehke koopia.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Arvestades `x = f` ja `y = m`, kus `f` tähistab sisendi kümnendkohti nagu tavaliselt ja `m` on ujukoma lähenduse tähendus, muutke suhe `x / y` võrdseks `(f *10^e) / (m* 2^k)`-ga, mida võib vähendada kahe võimsus, mõlemal on ühine.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, välja arvatud see, et vähendame murdosa mõne kahekordse astmega.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m See ei saa üle voolata, kuna see nõuab positiivset `e` ja negatiivset `k`, mis võib juhtuda ainult äärmiselt lähedaste väärtuste korral, mis tähendab, et `e` ja `k` on suhteliselt väikesed.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Ka see ei saa üle voolata, vt eespool.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), vähendades jällegi kahe ühisjõuga.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Kontseptuaalselt on algoritm M lihtsaim viis kümnendkoha teisendamiseks ujukiks.
///
/// Moodustame suhe, mis on võrdne `f * 10^e`-ga, seejärel viskame kahe võimsuse, kuni see annab kehtiva ujukimärgi.
/// Binaarne eksponent `k` on kordajate arv, mille korrutasime lugeja või nimetaja kahega, st kogu aeg võrdub `f *10^e` väärtusega `(u / v)* 2^k`.
/// Kui oleme tähenduse välja selgitanud, peame ümardama, kontrollides jaotuse ülejäänud osa, mida tehakse abifunktsioonides allpool.
///
///
/// See algoritm on üliaeglane, isegi `quick_start()`-s kirjeldatud optimeerimise korral.
/// Kuid see on kõige lihtsam algoritmidest, mis kohanduvad ülevoolu, alavoolu ja ebaharilike tulemuste jaoks.
/// See teostus võtab üle, kui Bellerophon ja Algorithm R on üle jõu käinud.
/// Ala-ja ülevoolu tuvastamine on lihtne: suhe pole endiselt vahemikus olev tähendus, kuid minimum/maximum eksponent on saavutatud.
/// Ülevoolu korral tagastame lihtsalt lõpmatuse.
///
/// Alamvoolu ja alamnormide käsitlemine on keerulisem.
/// Üks suur probleem on see, et minimaalse eksponendi korral võib suhe tähendusrühma jaoks olla endiselt liiga suur.
/// Vaadake üksikasju underflow()-st.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // PARANDA võimalikku optimeerimist: üldistage suur_to_fp nii, et saaksime siin teha ekvivalendi fp_to_float(big_to_fp(u)), ainult ilma kahekordse ümardamiseta.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Peame peatuma minimaalse eksponendi juures, kui ootame `k < T::MIN_EXP_INT`-ni, siis oleksime kahekordistunud.
            // Kahjuks tähendab see, et peame lisama normaaljuhud minimaalse astmega.
            // FIXME leiab elegantsema formuleeringu, kuid käivitage `tiny-pow10` test, et veenduda selle õigsuses!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Jätab enamiku algoritmi M iteratsioonide vahele, kontrollides bitipikkust.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Biti pikkus on kahe põhilogaritmi hinnang ja log(u / v) = log(u), log(v).
    // Hinnang on välja lülitatud maksimaalselt 1 võrra, kuid alati alahinnatud, nii et vead log(u) ja log(v) puhul on sama märgiga ja tühistatakse (kui mõlemad on suured).
    // Seetõttu on viga log(u / v) puhul samuti üks.
    // Sihtsuhe on selline, kus u/v on vahemikus.Seega on meie lõpetamistingimuseks log2(u / v), mis on tähendusbitid, plus/minus üks.
    // FIXME Teise biti vaatamine võib hinnangut paremaks muuta ja vältida veel mõningaid jaotusi.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Ala-või alanormaalne.Jätke see põhifunktsioonile.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Ülevool.Jätke see põhifunktsioonile.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Suhe ei ole vahemikus olev tähis minimaalse eksponendiga, seega peame üleliigsed bitid ümardama ja eksponenti vastavalt kohandama.
    // Tegelik väärtus näeb nüüd välja selline:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q kärp.(esindatud rem)
    //
    // Seega, kui ümardatud bitid on!= 0.5 ULP, otsustavad nad ümardamise ise.
    // Kui need on võrdsed ja ülejäänud on nullist erinev, tuleb väärtus ikkagi ülespoole ümardada.
    // Alles siis, kui ümardatud bittid on 1/2 ja ülejäänud on null, on meil olukord pooleldi ühtlane.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Tavaline ümmargune kuni tasavägine, hägustunud ümardamise järelejäänud jagunemise põhjal.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}