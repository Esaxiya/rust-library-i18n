//! Peaaegu otsene (kuid veidi optimeeritud) Rust tõlge joonisele 3 teemal "Ujuvate punktide numbrite kiire ja täpne printimine" [^ 1].
//!
//!
//! [^1]: Burger, RG ja Dybvig, RK 1996. Ujukomaarvude printimine
//!   kiiresti ja täpselt.SIGPLAN Ei.31, 5 (mai 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// 10 ^ (2 ^ n) eelnevalt arvutatud "numbri" massiivid
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// kasutatav ainult siis, kui `x < 16 * scale`;`scaleN` peaks olema `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Lühim režiimi rakendamine Dragonile.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // number `v` vormindamiseks on teadaolevalt:
    // - võrdub `mant * 2^exp`;
    // - millele eelneb originaaltüübis `(mant - 2 *minus)* 2^exp`;ja
    // - järgneb originaaltüübis `(mant + 2 *plus)* 2^exp`.
    //
    // ilmselgelt ei saa `minus` ja `plus` olla null.(lõpmatuste puhul kasutame vahemikust väljas olevaid väärtusi.) Samuti eeldame, et genereeritakse vähemalt üks number, st ka `mant` ei saa olla null.
    //
    // see tähendab ka seda, et mis tahes arv vahemikus `low = (mant - minus)*2^exp` kuni `high = (mant + plus)* 2^exp` kaardistatakse selle täpse ujukomaarvuga, piirid lisatakse ka siis, kui algne mantissa oli paaris (st `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` on `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // hinnata `k_0` algsetest sisenditest, mis vastavad `10^(k_0-1) < high <= 10^(k_0+1)`-le.
    // tihedalt seotud `k`, mis vastab `10^(k-1) < high <= 10^k`-ile, arvutatakse hiljem.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // teisendage `{mant, plus, minus} * 2^exp` murdvormiks nii, et:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // jagage `mant` `10^k`-ga.nüüd `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // parandus, kui `mant + plus > scale` (või `>=`).
    // me ei muuda tegelikult `scale`-i, kuna selle asemel võime esialgse korrutamise vahele jätta.
    // nüüd `scale < mant + plus <= scale * 10` ja oleme valmis numbreid genereerima.
    //
    // Pange tähele, et `d[0]`*võib* olla null, kui `scale - plus < mant < scale`.
    // sel juhul käivitatakse ümardamise tingimus (`up` allpool) kohe.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // vastab `scale`-i skaleerimisele 10-ga
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // vahemälu `(2, 4, 8) * scale` numbrite genereerimiseks.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // invariandid, kus `d[0..n-1]` on seni genereeritud numbrid:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (seega `mant / scale < 10`), kus `d[i..j]` on `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // genereerige üks number: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // see on muudetud draakoni algoritmi lihtsustatud kirjeldus.
        // paljud vahepealsed tuletised ja täielikkuse argumendid jäetakse mugavuse huvides välja.
        //
        // alustage muudetud invariantidest, kuna oleme `n`-i värskendanud:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // Oletame, et `d[0..n-1]` on lühim esitus `low` ja `high` vahel, st `d[0..n-1]` vastab mõlemale järgnevale, kuid `d[0..n-2]` mitte:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijektiivsus: numbrid ümardatakse `v`-ni);ja
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (viimane number on õige).
        //
        // teine tingimus lihtsustub `2 * mant <= scale`-iks.
        // invariantide lahendamine `mant`, `low` ja `high` osas annab esimese tingimuse lihtsama versiooni: `-plus < mant < minus`.
        // alates `-plus < 0 <= mant` on meil `mant < minus` ja `2 * mant <= scale` korral kõige lühem kujutis.
        // (esimesest saab `mant <= minus`, kui algne mantissa on ühtlane.)
        //
        // kui teine ei pea kinni ("2 * mant> skaala"), peame viimast numbrit suurendama.
        // sellest piisab selle seisundi taastamiseks: me juba teame, et numbrite genereerimine tagab `0 <= v / 10^(k-n) - d[0..n-1] < 1`-i.
        // sel juhul saab esimesest tingimusest `-plus < mant - scale < minus`.
        // alates põlvkonnast `mant < scale` on meil `scale < mant + plus`.
        // (jällegi saab sellest `scale <= mant + plus`, kui algne mantissa on ühtlane.)
        //
        // lühidalt:
        // - peatage ja ümardage `down` (hoidke numbreid kujul), kui `mant < minus` (või `<=`).
        // - peatus ja ümardage `up` (suurendage viimast numbrit), kui `scale < mant + plus` (või `<=`).
        // - genereeri muudmoodi.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // meil on lühim esindatus, jätkake ümardamisega

        // taastada invariandid.
        // see muudab algoritmi alati lõppevaks: `minus` ja `plus` suurenevad alati, kuid `mant` lõigatakse moodulina `scale` ja `scale` on fikseeritud.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // ümardamine toimub siis, kui i) käivitati ainult ümardamise tingimus või ii) mõlemad tingimused käivitati ja lipsude purustamine eelistab ümardamist.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // kui ümardamine ülespoole muudab pikkust, peaks ka eksponent muutuma.
        // tundub, et seda tingimust on väga raske täita (võib-olla võimatu), kuid me oleme siin lihtsalt ohutud ja järjekindlad.
        //
        // OHUTUS: me algatasime selle mälu eespool.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // OHUTUS: me algatasime selle mälu eespool.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Draakoni täpne ja fikseeritud režiimis rakendamine.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // hinnata `k_0` algsetest sisenditest, mis vastavad `10^(k_0-1) < v <= 10^(k_0+1)`-le.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // jagage `mant` `10^k`-ga.nüüd `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // parandus, kui `mant + plus >= scale`, kus `plus / scale = 10^-buf.len() / 2`.
    // fikseeritud suurusega bignumi säilitamiseks kasutame tegelikult `mant + floor(plus) >= scale`-i.
    // me ei muuda tegelikult `scale`-i, kuna selle asemel võime esialgse korrutamise vahele jätta.
    // jällegi lühima algoritmiga võib `d[0]` olla null, kuid ümardatakse lõpuks ülespoole.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // vastab `scale`-i skaleerimisele 10-ga
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // kui töötame viimase numbri piiranguga, peame kahekordse ümardamise vältimiseks puhvrit enne tegelikku renderdamist lühendama.
    //
    // pange tähele, et ümardamise korral peame puhvrit uuesti suurendama!
    let mut len = if k < limit {
        // oih, me ei saa isegi * ühte numbrit toota.
        // see on võimalik, kui meil on näiteks 9.5 sarnane ja see ümardatakse kümneni.
        // tagastame tühja puhvri, välja arvatud hilisem ümardamise juhtum, mis tekib siis, kui `k == limit` ja peab tootma täpselt ühe numbri.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // vahemälu `(2, 4, 8) * scale` numbrite genereerimiseks.
        // (see võib olla kallis, nii et ärge arvutage neid, kui puhver on tühi.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // järgmised numbrid on kõik nullid, peatume siin, ärge proovige ümardamist!pigem täitke ülejäänud numbrid.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // OHUTUS: me algatasime selle mälu eespool.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // ümardamine ülespoole, kui peatume numbrite keskel, kui järgmised numbrid on täpselt 5000 ..., kontrollige eelnevat numbrit ja proovige ümardada paariliseks (st vältige ümardamist ülespoole, kui eelmine number on paaris).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // OHUTUS: `buf[len-1]` lähtestatakse.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // kui ümardamine ülespoole muudab pikkust, peaks ka eksponent muutuma.
        // kuid meile on taotletud fikseeritud arvu numbreid, nii et ärge muutke puhvrit ...
        // OHUTUS: me algatasime selle mälu eespool.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... kui meilt pole selle asemel fikseeritud täpsust palutud.
            // Samuti peame kontrollima, et kui algne puhver oli tühi, saab täiendava numbri lisada ainult siis, kui `k == limit` (juhtum edge).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // OHUTUS: me algatasime selle mälu eespool.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}