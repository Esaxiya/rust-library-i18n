//! Dekodeerib ujukoma väärtuse üksikuteks osadeks ja vea vahemikeks.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Dekodeeritud allkirjastamata lõplik väärtus, nii et:
///
/// - Algne väärtus on võrdne väärtusega `mant * 2^exp`.
///
/// - Mis tahes arv vahemikus `(mant - minus)*2^exp` kuni `(mant + plus)* 2^exp` ümardatakse algväärtuseni.
/// Vahemik on kaasav ainult siis, kui `inclusive` on `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Skaalastatud mantissa.
    pub mant: u64,
    /// Madalam vea vahemik.
    pub minus: u64,
    /// Ülemine vea vahemik.
    pub plus: u64,
    /// 2. baasi jagatud eksponent.
    pub exp: i16,
    /// Tõsi, kui vea vahemik on kaasav.
    ///
    /// Standardis IEEE 754 kehtib see siis, kui algne mantissa oli ühtlane.
    pub inclusive: bool,
}

/// Dekodeeritud allkirjastamata väärtus.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Lõpmatused, kas positiivsed või negatiivsed.
    Infinite,
    /// Null, kas positiivne või negatiivne.
    Zero,
    /// Lõplikud numbrid koos edasiste dekodeeritud väljadega.
    Finite(Decoded),
}

/// Ujukoma tüüp, mida saab `dekodeerida`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Minimaalne positiivne normaliseeritud väärtus.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Tagastab antud ujukoma numbri märgi (tõene, kui negatiivne) ja `FullDecoded` väärtuse.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // naabrid: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode säilitab alati eksponendi, nii et mantissa skaleeritakse alamnormide järgi.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // naabrid: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // kus maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // naabrid: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}