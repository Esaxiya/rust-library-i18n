Panics praegune lõim.

See võimaldab programmil kohe lõpetada ja anda programmi helistajale tagasisidet.
`panic!` tuleks kasutada, kui programm jõuab taastamatusse olekusse.

See makro on ideaalne viis tingimuste kinnitamiseks näite koodis ja testides.
`panic!` on tihedalt seotud nii [`Option`][ounwrap] kui ka [`Result`][runwrap] loendite meetodiga `unwrap`.
Mõlemad rakendused kutsuvad `panic!`-i, kui neile on seatud [`None`] või [`Err`] variandid.

`panic!()`-i kasutamisel saate määrata stringi kasuliku koormuse, mis on ehitatud [`format!`]-i süntaksit kasutades.
Seda kasulikku koormust kasutatakse panic süstimisel helistavasse Rust lõime, põhjustades lõime täielikult panic-ni.

Vaikimisi `std` hook käitumine, st
kood, mis töötab kohe pärast panic käivitamist, peab printima sõnumi kasuliku koorma `stderr` koos `panic!()` kõne file/line/column teabega.

[`std::panic::set_hook()`] abil saate panic hook alistada.
Rakenduse hook sees on panic-le juurdepääs kui `&dyn Any + Send`, mis sisaldab kas `&str` või `String` tavaliste `panic!()`-invokatsioonide jaoks.
panic-le, mille väärtus on teist tüüpi, saab kasutada [`panic_any`]-i.

[`Result`] enum on sageli parem lahendus vigadest taastumiseks kui `panic!` makro kasutamine.
Seda makrot tuleks kasutada, et vältida valede väärtuste kasutamist, näiteks välistest allikatest.
Üksikasjalikku teavet tõrkeotsingu kohta leiate [book]-ist.

Vigade esilekutsumisel kompileerimise ajal vaadake ka makrot [`compile_error!`].

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Praegune rakendamine

Kui põhilõng panics lõpetab see kõik teie lõimed ja lõpetab teie programmi koodiga `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





