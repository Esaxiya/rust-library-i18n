#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Laieneb kas `$crate::panic::panic_2015` või `$crate::panic::panic_2021`, olenevalt helistaja väljaandest.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Kinnitab, et kaks avaldist on üksteisega võrdsed (kasutades [`PartialEq`]).
///
/// Rakendusel panic prindib see makro avaldiste väärtused koos silumisega.
///
///
/// Nagu [`assert!`], on ka sellel makrol teine vorm, kus saab esitada kohandatud panic-sõnumi.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Allpool toodud laenud on tahtlikud.
                    // Ilma nendeta initsialiseeritakse laenu pinu pesa juba enne väärtuste võrdlemist, mis viib märgatava aeglustumiseni.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Allpool toodud laenud on tahtlikud.
                    // Ilma nendeta initsialiseeritakse laenu pinu pesa juba enne väärtuste võrdlemist, mis viib märgatava aeglustumiseni.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Kinnitab, et kaks avaldist pole üksteisega võrdsed (kasutades [`PartialEq`]).
///
/// Rakendusel panic prindib see makro avaldiste väärtused koos silumisega.
///
///
/// Nagu [`assert!`], on ka sellel makrol teine vorm, kus saab esitada kohandatud panic-sõnumi.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Allpool toodud laenud on tahtlikud.
                    // Ilma nendeta initsialiseeritakse laenu pinu pesa juba enne väärtuste võrdlemist, mis viib märgatava aeglustumiseni.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Allpool toodud laenud on tahtlikud.
                    // Ilma nendeta initsialiseeritakse laenu pinu pesa juba enne väärtuste võrdlemist, mis viib märgatava aeglustumiseni.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Kinnitab, et boolean avaldis on käituse ajal `true`.
///
/// See käivitab makro [`panic!`], kui pakutavat avaldist ei saa käituse ajal hinnata `true`-ga.
///
/// Nagu [`assert!`], on ka sellel makrol teine versioon, kus saab pakkuda kohandatud panic-sõnumit.
///
/// # Uses
///
/// Erinevalt [`assert!`]-ist on `debug_assert!`-i väited vaikimisi lubatud ainult optimeerimata järkudes.
/// Optimeeritud järk ei täida `debug_assert!`-lauseid, kui `-C debug-assertions` pole kompilaatorile edastatud.
/// See muudab `debug_assert!`-i kasulikuks kontrollide jaoks, mis on väljalaskekonstruktsioonis esinemiseks liiga kallid, kuid võivad olla abiks arenduse ajal.
/// `debug_assert!` laiendamise tulemus on alati tüübikontroll.
///
/// Kontrollimata väide võimaldab vastuolulises olekus programmi jätkata, millel võivad olla ootamatud tagajärjed, kuid see ei põhjusta ohutust seni, kuni see juhtub ainult turvalises koodis.
///
/// Väidete tulemusmaksumus pole aga üldiselt mõõdetav.
/// [`assert!`] asendamine `debug_assert!`-iga on seega soovitatav alles pärast põhjalikku profileerimist ja mis veelgi tähtsam-ainult ohutu koodina!
///
/// # Examples
///
/// ```
/// // nende väidete teade panic on antud avaldise täpsustatud väärtus.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // väga lihtne funktsioon
/// debug_assert!(some_expensive_computation());
///
/// // kinnitada kohandatud sõnumiga
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Kinnitab, et kaks avaldist on üksteisega võrdsed.
///
/// Rakendusel panic prindib see makro avaldiste väärtused koos silumisega.
///
/// Erinevalt [`assert_eq!`]-ist on `debug_assert_eq!`-i väited vaikimisi lubatud ainult optimeerimata järkudes.
/// Optimeeritud järk ei täida `debug_assert_eq!`-lauseid, kui `-C debug-assertions` pole kompilaatorile edastatud.
/// See muudab `debug_assert_eq!`-i kasulikuks kontrollide jaoks, mis on väljalaskekonstruktsioonis esinemiseks liiga kallid, kuid võivad olla abiks arenduse ajal.
///
/// `debug_assert_eq!` laiendamise tulemus on alati tüübikontroll.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Väidab, et kaks avaldist pole üksteisega võrdsed.
///
/// Rakendusel panic prindib see makro avaldiste väärtused koos silumisega.
///
/// Erinevalt [`assert_ne!`]-ist on `debug_assert_ne!`-i väited vaikimisi lubatud ainult optimeerimata järkudes.
/// Optimeeritud järk ei täida `debug_assert_ne!`-lauseid, kui `-C debug-assertions` pole kompilaatorile edastatud.
/// See muudab `debug_assert_ne!`-i kasulikuks kontrollide jaoks, mis on väljalaskekonstruktsioonis esinemiseks liiga kallid, kuid võivad olla abiks arenduse ajal.
///
/// `debug_assert_ne!` laiendamise tulemus on alati tüübikontroll.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Tagastab, kas antud avaldis sobib mõne antud mustriga.
///
/// Nagu `match` avaldises, võib ka mustrile soovi korral järgneda `if` ja valveavaldis, millel on juurdepääs mustriga seotud nimedele.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Tühistab tulemuse või levitab selle viga.
///
/// Operaator `?` lisati `try!` asendamiseks ja seda tuleks kasutada.
/// Lisaks on `try` Rust 2018-s reserveeritud sõna, nii et kui peate seda kasutama, peate kasutama [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` sobib antud [`Result`]-ga.`Ok` variandi korral on avaldisel pakitud väärtuse väärtus.
///
/// `Err` variandi korral saab see sisemise vea.Seejärel teostab `try!` teisenduse, kasutades `From`-i.
/// See võimaldab automaatset teisendamist spetsialiseeritud vigade ja üldisemate vahel.
/// Seejärel tagastatakse tekkinud viga kohe.
///
/// Varajase tagastamise tõttu saab `try!`-i kasutada ainult funktsioonides, mis tagastavad [`Result`]-i.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Eelistatud meetod vigade kiireks tagastamiseks
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Eelmine vigade kiire tagastamise meetod
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // See on samaväärne järgmisega:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Kirjutab vormindatud andmed puhvrisse.
///
/// See makro aktsepteerib 'writer'-i, vormingu stringi ja argumentide loendit.
/// Argumendid vormindatakse vastavalt määratud vormingustringile ja tulemus edastatakse kirjutajale.
/// Kirjutajaks võib olla mis tahes väärtus `write_fmt`-meetodil;üldiselt tuleneb see kas [`fmt::Write`] või [`io::Write`] trait rakendamisest.
/// Makro tagastab meetodi `write_fmt` tagastamise;tavaliselt [`fmt::Result`] või [`io::Result`].
///
/// Vormindistringi süntaksite kohta leiate lisateavet jaotisest [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Moodul võib importida nii `std::fmt::Write` kui ka `std::io::Write` ja helistada `write!` objektidele, mis mõlemad rakendavad, kuna objektid ei rakenda tavaliselt mõlemat.
///
/// Kuid moodul peab importima kvalifitseeritud traits, nii et nende nimed ei oleks vastuolus:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // kasutab fmt::Write::write_fmt-i
///     write!(&mut v, "s = {:?}", s)?; // kasutab io::Write::write_fmt-i
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Seda makrot saab kasutada ka `no_std`-i seadistustes.
/// `no_std` seadistuses vastutate komponentide juurutamise üksikasjade eest.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Kirjutage vormindatud andmed puhvrisse, lisades uue rea.
///
/// Kõigil platvormidel on uus rida ainult LINE FEED-tähemärk (`\n`/`U+000A`) (täiendavat CARRIAGE RETURN (`\r`/`U+000D`)-i pole.
///
/// Lisateavet leiate artiklist [`write!`].Vormingstringi süntaksit käsitleva teabe leiate artiklist [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Moodul võib importida nii `std::fmt::Write` kui ka `std::io::Write` ja helistada `write!` objektidele, mis mõlemad rakendavad, kuna objektid ei rakenda tavaliselt mõlemat.
/// Kuid moodul peab importima kvalifitseeritud traits, nii et nende nimed ei oleks vastuolus:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // kasutab fmt::Write::write_fmt-i
///     writeln!(&mut v, "s = {:?}", s)?; // kasutab io::Write::write_fmt-i
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Näitab kättesaamatut koodi.
///
/// See on kasulik igal ajal, kui kompilaator ei suuda tuvastada, et mõni kood on kättesaamatu.Näiteks:
///
/// * Sobita relvad valvuritingimustega.
/// * Dünaamiliselt lõppevad aasad.
/// * Dünaamiliselt lõppevad iteraatorid.
///
/// Kui tuvastamine, et kood on kättesaamatu, osutub valeks, lõpetab programm kohe [`panic!`]-ga.
///
/// Selle makro ebaturvaline vaste on funktsioon [`unreachable_unchecked`], mis põhjustab koodini jõudmisel määratlemata käitumise.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// See on alati [`panic!`].
///
/// # Examples
///
/// Mängu relvad:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // kompileerimise viga, kui seda kommenteeritakse
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // üks x/3 kõige kehvemaid rakendusi
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Näitab rakendamata koodi, paaniliselt "not implemented"-sõnumiga.
///
/// See võimaldab teie koodil tüübikontrolli teha, mis on kasulik juhul, kui prototüüpite või rakendate trait-i, mis nõuab mitut meetodit, mida te ei kavatse kõiki kasutada.
///
/// `unimplemented!` ja [`todo!`] erinevus seisneb selles, et kuigi `todo!` annab edasi funktsiooni hiljem rakendamise kavatsuse ja sõnum on "not yet implemented", ei esita `unimplemented!` selliseid väiteid.
/// Selle sõnum on "not implemented".
/// Ka mõned IDE-d tähistavad märkmeid.
///
/// # Panics
///
/// See on alati [`panic!`], kuna `unimplemented!` on `panic!`-i jaoks lihtsalt fikseeritud, konkreetse sõnumiga lühike.
///
/// Nagu `panic!`, on ka sellel makrol kohandatud väärtuste kuvamiseks teine vorm.
///
/// # Examples
///
/// Oletame, et meil on trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Soovime `Foo`-i rakendada 'MyStruct'-i jaoks, kuid millegipärast on mõttekas rakendada ainult funktsiooni `bar()`.
/// `baz()` ja `qux()` tuleb `Foo`-i rakendamisel ikkagi määratleda, kuid nende koodide kompileerimiseks saame nende definitsioonides kasutada `unimplemented!`-i.
///
/// Kui rakendamata meetodid saavutatakse, tahame ikkagi, et meie programm peatuks.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // `baz`-l ja `MyStruct`-l pole mõtet, nii et meil pole siin üldse loogikat.
/////
///         // See kuvab "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Meil on siin mingi loogika. Saame lisada sõnumi rakendamata!meie tegematajätmise kuvamiseks.
///         // See kuvab: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Näitab lõpetamata koodi.
///
/// See võib olla kasulik, kui teete prototüüpe ja soovite lihtsalt oma koodi sisestada.
///
/// [`unimplemented!`] ja `todo!` erinevus seisneb selles, et kuigi `todo!` annab edasi funktsiooni hiljem rakendamise kavatsuse ja sõnum on "not yet implemented", ei esita `unimplemented!` selliseid väiteid.
/// Selle sõnum on "not implemented".
/// Ka mõned IDE-d tähistavad märkmeid.
///
/// # Panics
///
/// See on alati [`panic!`].
///
/// # Examples
///
/// Siin on näide mõnest pooleliolevast koodist.Meil on trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Soovime rakendada `Foo` ühte oma tüüpi, kuid tahame kõigepealt töötada ka ainult `bar()`-iga.Meie koodi kompileerimiseks peame rakendama `baz()`, et saaksime kasutada `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // rakendamine käib siin
///     }
///
///     fn baz(&self) {
///         // ärme nüüd muretsege baz() juurutamise pärast
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // me ei kasuta isegi baz()-i, nii et see on hea.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Sisseehitatud makrode mõisted.
///
/// Enamik makroomadustest (stabiilsus, nähtavus jne) on siinsest lähtekoodist võetud, välja arvatud laiendusfunktsioonid, mis muudavad makrosisendid väljunditeks, need funktsioonid pakub kompilaator.
///
///
pub(crate) mod builtin {

    /// Põhjustab kompileerimise nurjumist etteantud tõrketeatega.
    ///
    /// Seda makrot tuleks kasutada siis, kui crate kasutab ekslike tingimuste korral paremate veateadete pakkumiseks tingimuslikku kompileerimisstrateegiat.
    ///
    /// See on [`panic!`] kompilaatori taseme vorm, kuid annab *kompileerimise* ajal vea, mitte käitusaja * ajal.
    ///
    /// # Examples
    ///
    /// Kaks sellist näidet on makrod ja `#[cfg]` keskkonnad.
    ///
    /// Parem kompilaatori viga, kui makro edastatakse valed väärtused.
    /// Ilma lõpliku branch-ta väljastaks kompilaator ikkagi vea, kuid veateates ei mainita kahte kehtivat väärtust.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Laske kompilaatori viga, kui üks paljudest funktsioonidest pole saadaval.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ehitab parameetrid teistele stringi vormindamise makrodele.
    ///
    /// See makro toimib, võttes iga järgmise edastatud argumendi jaoks `{}`-i sisaldava vormindusstringi.
    /// `format_args!` valmistab ette täiendavad parameetrid, et väljundit saaks tõlgendada stringina, ja kanoniseerib argumendid ühte tüüpi.
    /// Kõik väärtused, mis rakendavad [`Display`] trait, saab edastada `format_args!`-ile, nagu ka kõik [`Debug`]-i rakendused saab vormindamisstringi kaudu edastada `{:?}`-le.
    ///
    ///
    /// See makro toodab väärtust tüüpi [`fmt::Arguments`].Selle väärtuse saab kasuliku ümbersuunamise teostamiseks [`std::fmt`]-s makrodele edastada.
    /// Kõik muud vormindusmakrod ([`format!`], [`write!`], [`println!`] jne) on selle kaudu puhverserveriga ühendatud.
    /// `format_args!`, erinevalt tuletatud makrodest väldib hunnikute eraldamist.
    ///
    /// Võite kasutada [`fmt::Arguments`]-väärtust, mille `format_args!` tagastab `Debug`-ja `Display`-kontekstides, nagu allpool näha.
    /// Näide näitab ka seda, et `Debug` ja `Display` vormistatakse samaks: interpoleeritud vormingus string `format_args!`-is.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Lisateavet leiate [`std::fmt`]-i dokumentatsioonist.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Sama mis `format_args`, kuid lisab lõpuks uue rea.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Kontrollib kompileerimise ajal keskkonnamuutujat.
    ///
    /// See makro laieneb kompileerimise ajal nimetatud keskkonnamuutuja väärtuseni, saades `&'static str` tüüpi avaldise.
    ///
    ///
    /// Kui keskkonnamuutuja pole määratletud, väljastatakse kompileerimisviga.
    /// Kompileerimisvea väljastamiseks kasutage hoopis makrot [`option_env!`].
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Veateadet saate kohandada, edastades stringi teise parameetrina:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Kui keskkonnamuutujat `documentation` pole määratletud, kuvatakse järgmine tõrge:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Valikuliselt kontrollib kompileerimise ajal keskkonnamuutujat.
    ///
    /// Kui nimetatud keskkonnamuutuja on kompileerimise ajal olemas, laieneb see `Option<&'static str>` tüüpi avaldiseks, mille väärtus on keskkonnamuutuja väärtus `Some`.
    /// Kui keskkonnamuutujat pole, laieneb see versioonile `None`.
    /// Selle tüübi kohta lisateavet leiate jaotisest [`Option<T>`][Option].
    ///
    /// Selle makro kasutamisel ei väljastata kunagi kompileerimisaja viga, olenemata sellest, kas keskkonnamuutuja on olemas või mitte.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Liidab identifikaatorid üheks tunnuseks.
    ///
    /// See makro võtab suvalise arvu komadega eraldatud identifikaatoreid ja liidab need kõik ühte, saades avaldise, mis on uus identifikaator.
    /// Pange tähele, et hügieen muudab selle selliseks, et see makro ei saa kohalikke muutujaid hõivata.
    /// Üldreeglina on makrod lubatud ainult üksuse, lause või avaldise positsioonis.
    /// See tähendab, et kui võite seda makrot kasutada olemasolevatele muutujatele, funktsioonidele või moodulitele viitamiseks, ei saa te sellega uut määratleda.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (uus, lõbus, nimi) { }//pole sellisel viisil kasutatav!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Liidab literaalid staatiliseks stringiviiluks.
    ///
    /// See makro võtab suvalise arvu komadega eraldatud literaale, saades `&'static str` tüüpi avaldise, mis tähistab kõiki vasakult paremale liidetud literaale.
    ///
    ///
    /// Liitmise jaoks on täis-ja ujukoma-liitrid piiratud.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Laieneb rea numbrini, millel seda kutsuti.
    ///
    /// [`column!`] ja [`file!`] puhul pakuvad need makrod arendajatele silumisinfot allika asukoha kohta.
    ///
    /// Laiendatud avaldise tüüp on `u32` ja see on 1-põhine, nii et iga faili esimene rida hinnatakse väärtusele 1, teine väärtusele 2 jne.
    /// See on kooskõlas levinud kompilaatorite või populaarsete toimetajate veateadetega.
    /// Tagastatav rida *pole tingimata*`line!`-i kutse enda rida, vaid pigem esimene makrokutse, mis viib `line!`-makro kutsumiseni.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Laieneb veerunumbrini, kus seda kasutati.
    ///
    /// [`line!`] ja [`file!`] puhul pakuvad need makrod arendajatele silumisinfot allika asukoha kohta.
    ///
    /// Laiendatud avaldise tüüp on `u32` ja see on 1-põhine, nii et iga rea esimene veerg on väärtuseks 1, teine väärtuseks 2 jne.
    /// See on kooskõlas levinud kompilaatorite või populaarsete toimetajate veateadetega.
    /// Tagastatud veerg pole *tingimata*`column!`-i kutsungi rida, vaid pigem esimene makroekutse, mis viib `column!`-makro kutsumiseni.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Laieneb failinimeni, milles seda kutsuti.
    ///
    /// [`line!`] ja [`column!`] puhul pakuvad need makrod arendajatele silumisinfot allika asukoha kohta.
    ///
    /// Laiendatud avaldise tüüp on `&'static str` ja tagastatud fail ei ole makro `file!` esilekutsumine, vaid pigem esimene makroekutse, mis viib makro `file!` esilekutsumiseni.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Rõhutab oma argumendid.
    ///
    /// See makro annab `&'static str`-tüüpi avaldise, mis on kõigi makrole edastatud tokens-i string.
    /// Makroekutse enda süntaksile pole piiranguid seatud.
    ///
    /// Pange tähele, et sisendi tokens laiendatud tulemused võivad future-s muutuda.Kui loodate väljundile, peaksite olema ettevaatlik.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Sisaldab stringina UTF-8-i kodeeritud faili.
    ///
    /// Fail asub praeguse faili suhtes (sarnaselt moodulite leidmisele).
    /// Pakutavat teed tõlgendatakse kompileerimise ajal platvormispetsiifiliselt.
    /// Nii näiteks ei kompromiteerita Windows-teega, mis sisaldab tagasilööke `\`, Unix-is õigesti.
    ///
    ///
    /// See makro annab `&'static str`-tüüpi avaldise, mis on faili sisu.
    ///
    /// # Examples
    ///
    /// Oletame, et samas kataloogis on kaks järgmise sisuga faili:
    ///
    /// Fail 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Fail 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs' kompileerimine ja selle tulemusel binaarse käivitamine prindib "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Sisaldab faili viidetena baitide massiivile.
    ///
    /// Fail asub praeguse faili suhtes (sarnaselt moodulite leidmisele).
    /// Pakutavat teed tõlgendatakse kompileerimise ajal platvormispetsiifiliselt.
    /// Nii näiteks ei kompromiteerita Windows-teega, mis sisaldab tagasilööke `\`, Unix-is õigesti.
    ///
    ///
    /// See makro annab `&'static [u8; N]`-tüüpi avaldise, mis on faili sisu.
    ///
    /// # Examples
    ///
    /// Oletame, et samas kataloogis on kaks järgmise sisuga faili:
    ///
    /// Fail 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Fail 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs' kompileerimine ja selle tulemusel binaarse käivitamine prindib "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Laieneb stringini, mis tähistab praegust mooduliteed.
    ///
    /// Praegust mooduliteed võib mõelda kui moodulite hierarhiat, mis viib tagasi üles crate root-ni.
    /// Esimene tagastatud tee komponent on praegu koostatava crate nimi.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Hinnab konfiguratsioonilippide boolean kombinatsioone kompileerimise ajal.
    ///
    /// Lisaks atribuudile `#[cfg]` on see makro ette nähtud ka konfiguratsioonilippude tõeväärtuse hindamiseks.
    /// See põhjustab sageli vähem dubleeritud koodi.
    ///
    /// Sellele makrole antud süntaks on sama süntaks kui atribuut [`cfg`].
    ///
    /// `cfg!`, erinevalt `#[cfg]`-st ei eemalda ühtegi koodi ja hindab ainult tõeseks või valeks.
    /// Näiteks peavad if/else-i avaldise kõik plokid kehtima, kui seisundit `cfg!` kasutatakse, olenemata sellest, mida `cfg!` hindab.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Sõelab faili avaldise või üksusena vastavalt kontekstile.
    ///
    /// Fail asub praeguse faili suhtes (sarnaselt moodulite leidmisele).Pakutavat teed tõlgendatakse kompileerimise ajal platvormispetsiifiliselt.
    /// Nii näiteks ei kompromiteerita Windows-teega, mis sisaldab tagasilööke `\`, Unix-is õigesti.
    ///
    /// Selle makro kasutamine on sageli halb mõte, sest kui fail sõeluda avaldisena, paigutatakse see ümbritsevasse koodi ebahügieeniliselt.
    /// Selle tulemusel võivad muutujad või funktsioonid erineda faili eeldatavast, kui praeguses failis on muutujaid või funktsioone, millel on sama nimi.
    ///
    ///
    /// # Examples
    ///
    /// Oletame, et samas kataloogis on kaks järgmise sisuga faili:
    ///
    /// Fail 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Fail 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs' kompileerimine ja selle tulemusel binaarse käivitamine prindib "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Kinnitab, et boolean avaldis on käituse ajal `true`.
    ///
    /// See käivitab makro [`panic!`], kui pakutavat avaldist ei saa käituse ajal hinnata `true`-ga.
    ///
    /// # Uses
    ///
    /// Väiteid kontrollitakse alati nii silumise kui ka väljalaske järkudes ja neid ei saa keelata.
    /// Vaadake jaotisest [`debug_assert!`] väiteid, mis pole versiooniehitustes vaikimisi lubatud.
    ///
    /// Ebaturvaline kood võib `assert!`-il tugineda käitamisaja invariantide sundimiseks, mis rikkumise korral võib põhjustada ohutuse.
    ///
    /// Muud `assert!`-i kasutusjuhtumid hõlmavad käitamisaja invariantide testimist ja jõustamist turvalises koodis (mille rikkumine ei saa põhjustada ohutust).
    ///
    ///
    /// # Kohandatud sõnumid
    ///
    /// Sellel makrol on teine vorm, kus kohandatud panic-sõnumi saab esitada vormindamise argumentidega või ilma.
    /// Selle vormi süntaks vaadake jaotisest [`std::fmt`].
    /// Vormingargumentidena kasutatavaid väljendeid hinnatakse ainult siis, kui väide ebaõnnestub.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // nende väidete teade panic on antud avaldise täpsustatud väärtus.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // väga lihtne funktsioon
    ///
    /// assert!(some_computation());
    ///
    /// // kinnitada kohandatud sõnumiga
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Sisseehitus.
    ///
    /// Kasutamiseks lugege [unstable book]-i.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM-stiilis sisemine kokkupanek.
    ///
    /// Kasutamiseks lugege [unstable book]-i.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Mooduli tasemel sisemine kokkupanek.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Prindid viisid tokens standardväljundisse.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Lubab või keelab jälgimisfunktsionaalsuse, mida kasutatakse teiste makrode silumisel.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Tuletusmakrode rakendamiseks kasutatud atribuutmakro.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Funktsioonile rakendatud atribuutmakro, et muuta see ühikutestiks.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Funktsioonile rakendatud atribuutmakro, et muuta see võrdlustestiks.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]` ja `#[bench]` makrode rakendusdetail.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Staatilisele atribuudimakrole, et registreerida see globaalse eraldajana.
    ///
    /// Vaadake ka [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Hoiab üksuse, millele see on rakendatud, kui läbitud tee on juurdepääsetav, ja eemaldab selle muul juhul.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Laiendab kõiki `#[cfg]` ja `#[cfg_attr]` atribuute koodifragmendis, millele seda rakendatakse.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// `rustc` kompilaatori ebastabiilne juurutusdetail, ärge kasutage.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// `rustc` kompilaatori ebastabiilne juurutusdetail, ärge kasutage.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}