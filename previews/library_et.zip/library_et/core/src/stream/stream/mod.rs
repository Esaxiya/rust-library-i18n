use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Liides asünkroonsete iteraatoritega tegelemiseks.
///
/// See on peamine voog trait.
/// Voogude kontseptsiooni kohta lisateabe saamiseks vaadake [module-level documentation]-i.
/// Eelkõige võiksite teada, kuidas [implement `Stream`][impl]-i teha.
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Voo kaudu saadavate üksuste tüüp.
    type Item;

    /// Proovige selle voo järgmine väärtus välja tõmmata, registreerides praeguse ülesande äratamiseks, kui väärtus pole veel saadaval, ja tagastades `None`, kui voog on ammendatud.
    ///
    /// # Tagastusväärtus
    ///
    /// Tagasiväärtusi on mitu, millest igaüks näitab erinevat voo olekut:
    ///
    /// - `Poll::Pending` tähendab, et selle voo järgmine väärtus pole veel valmis.Rakendused tagavad, et praegusest ülesandest teavitatakse, kui järgmine väärtus võib olla valmis.
    ///
    /// - `Poll::Ready(Some(val))` tähendab, et voog on edukalt tootnud väärtuse `val` ja võib järgmistel `poll_next`-kõnedel toota täiendavaid väärtusi.
    ///
    /// - `Poll::Ready(None)` tähendab, et voog on lõppenud ja `poll_next`-i ei tohiks uuesti käivitada.
    ///
    /// # Panics
    ///
    /// Kui voog on lõppenud (`Ready(None)` from `poll_next`) tagastatakse, selle `poll_next`-meetodi uuesti kutsumine võib panic igaveseks blokeerida või põhjustada muid probleeme; `Stream` trait ei sea sellise kõne mõjudele nõudeid.
    ///
    /// Kuna meetod `poll_next` pole `unsafe`-ga tähistatud, kehtivad Rust tavapärased reeglid: kõned ei tohi kunagi põhjustada määratlemata käitumist (mälu rikkumine, `unsafe`-funktsioonide vale kasutamine vms), olenemata voo olekust.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Tagastab voo ülejäänud pikkuse piirid.
    ///
    /// Täpsemalt tagastab `size_hint()` dupleksi, kus esimene element on alumine piir ja teine element on ülemine piir.
    ///
    /// Tagastatava dupleksi teine pool on ["Valik"] "<" ["kasutage"] ">".
    /// [`None`] tähendab siin seda, et kas pole teada ülemist piiri või ülemine piir on suurem kui [`usize`].
    ///
    /// # Rakendamise märkused
    ///
    /// Ei ole sunnitud, et voo juurutamine annab deklareeritud arvu elemente.Lollakas voog võib anda vähem kui elementide alumine piir või rohkem kui ülemine piir.
    ///
    /// `size_hint()` on mõeldud peamiselt kasutamiseks optimeerimiseks, näiteks ruumi reserveerimiseks voo elementidele, kuid seda ei tohi usaldada nt ohutute koodide piirikontrollide välja jätmisele.
    /// `size_hint()` i vale rakendamine ei tohiks põhjustada mäluohutuse rikkumisi.
    ///
    /// See tähendab, et rakendus peaks andma õige hinnangu, sest vastasel juhul oleks see trait protokolli rikkumine.
    ///
    /// Vaikimisi rakendamine tagastab mis tahes voo jaoks õige "(0," ["Puudub"] ")".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}