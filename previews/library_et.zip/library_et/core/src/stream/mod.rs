//! Komponeeritav asünkroonne iteratsioon.
//!
//! Kui futures on asünkroonsed väärtused, siis voogud on asünkroonsed iteraatorid.
//! Kui olete leidnud mingisuguse asünkroonse kollektsiooni ja peate selle kollektsiooni elementidega toimingu sooritama, satute kiiresti 'streams'-i.
//! Vooge kasutatakse palju idiomaatilises asünkroonses Rust-koodis, seega tasub nendega tuttavaks saada.
//!
//! Enne kui selgitada rohkem, räägime sellest, kuidas see moodul on üles ehitatud:
//!
//! # Organization
//!
//! See moodul on suures osas korraldatud tüübi järgi:
//!
//! * [Traits] on põhiosa: need traits määratlevad, millised voogud on olemas ja mida saate nendega teha.Nende traits meetodid on väärt lisauuringuaega.
//! * Funktsioonid pakuvad mõningaid kasulikke viise põhivoogude loomiseks.
//! * Struktuurid on sageli selle mooduli traits erinevate meetodite tagasitüübid.Tavaliselt soovite vaadata meetodit, mis loob `struct`, mitte `struct`-i ennast.
//! Lisateavet selle kohta leiate jaotisest " [Streami juurutamine](#implementing-voog)`.
//!
//! [Traits]: #traits
//!
//! See selleks!Kaevame voogudesse.
//!
//! # Stream
//!
//! Selle mooduli süda ja hing on [`Stream`] trait.[`Stream`] tuum näeb välja selline:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Erinevalt `Iterator`-st teeb `Stream` vahet [`poll_next`]-meetodil, mida kasutatakse `Stream`-i rakendamisel, ja (to-be-implemented)-`next`-meetodil, mida kasutatakse voo tarbimisel.
//!
//! `Stream`-i tarbijad peavad arvestama ainult `next`-ga, mis helistamisel tagastab future, mis annab `Option<Stream::Item>`.
//!
//! `next` tagastatav future annab `Some(Item)`, kui elemente on ja kui need kõik on ammendatud, annab `None`, mis näitab, et iteratsioon on lõppenud.
//! Kui ootame midagi asünkroonset lahendamist, ootab future, kuni voog on taas valmis andma.
//!
//! Üksikud voogud võivad valida iteratsiooni jätkamise ja nii võib `next`-i uuesti kutsumine anda `Some(Item)`-i mingil hetkel uuesti või mitte.
//!
//! [`Stream`] täielik määratlus sisaldab ka mitmeid muid meetodeid, kuid need on vaikemeetodid, mis on ehitatud [`poll_next`]-i peale ja nii saate neid tasuta.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Streami juurutamine
//!
//! Oma voo loomine hõlmab kahte sammu: `struct`-i loomine voo oleku hoidmiseks ja seejärel [`Stream`]-i juurutamine selle `struct` jaoks.
//!
//! Koostame voo nimega `Counter`, mis loeb väärtusest `1` kuni `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Esiteks:
//!
//! /// Oja, mida loetakse ühest viieni
//! struct Counter {
//!     count: usize,
//! }
//!
//! // me tahame, et meie arv algab ühest, nii et lisame abiks new()-meetodi.
//! // See pole tingimata vajalik, kuid on mugav.
//! // Pange tähele, et alustame `count`-i nullist, näeme, miks `poll_next()`'s-i juurutamisel allpool.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Seejärel juurutame oma `Counter`-i jaoks `Stream`:
//!
//! impl Stream for Counter {
//!     // me loeme koos usize'iga
//!     type Item = usize;
//!
//!     // poll_next() on ainus nõutav meetod
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Suurendage meie arvu.Seetõttu alustasime nullist.
//!         self.count += 1;
//!
//!         // Kontrollige, kas oleme loendamise lõpetanud või mitte.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Vood on *laisad*.See tähendab, et ainult voo loomine ei ole _do_ päris suur.Midagi tegelikult ei juhtu enne, kui helistate `next`-ile.
//! Voo tekitamisel ainult selle kõrvalmõjude pärast tekitab see mõnikord segadust.
//! Koostaja hoiatab meid sellise käitumise eest:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;