//! Moodul laenatud andmetega töötamiseks.

#![stable(feature = "rust1", since = "1.0.0")]

/// Andmete laenamiseks trait.
///
/// Rakenduses Rust on tavaline pakkuda erinevat tüüpi juhtumite jaoks erinevat tüüpi esitusi.
/// Näiteks saab väärtuse salvestuskoha ja halduse konkreetseks kasutamiseks sobivalt valida osuti tüüpide kaudu, näiteks [`Box<T>`] või [`Rc<T>`].
/// Lisaks nendele üldistele ümbristele, mida saab kasutada mis tahes tüüpi, pakuvad mõned tüübid valikulisi tahke, mis pakuvad potentsiaalselt kulukat funktsionaalsust.
/// Sellise tüübi näiteks on [`String`], mis lisab põhi [`str`]-le stringi pikendamise võimaluse.
/// See nõuab lisateabe hoidmist lihtsa, muutumatu stringi jaoks ebavajalikuna.
///
/// Need tüübid võimaldavad juurdepääsu alusandmetele viidete abil nende andmete tüübile.Väidetavalt on nad seda tüüpi "laenatud".
/// Näiteks [`Box<T>`] saab laenata kui `T`, samas kui [`String`] saab laenata kui `str`.
///
/// Tüübid väljendavad, et neid saab laenata teatud tüüpi `T`, rakendades `Borrow<T>`, pakkudes trait-i meetodis [`borrow`] viidet `T`-le.Tüüp võib vabalt laenata mitme erineva tüübina.
/// Kui ta soovib tüübina laenata-võimaldades alusandmeid muuta, saab ta [`BorrowMut<T>`]-i täiendavalt rakendada.
///
/// Täiendavate traits juurutuste pakkumisel tuleb kaaluda, kas nad peaksid selle aluseks oleva tüübi esindamisel toimima identselt põhitüübi omadega.
/// Üldkood kasutab tavaliselt `Borrow<T>`-i, kui see tugineb nende täiendavate trait-rakenduste identsele käitumisele.
/// Need traits ilmuvad tõenäoliselt täiendava trait bounds-na.
///
/// Eelkõige peavad `Eq`, `Ord` ja `Hash` olema laenatud ja omandis olevate väärtuste suhtes samaväärsed: `x.borrow() == y.borrow()` peaks andma sama tulemuse kui `x == y`.
///
/// Kui üldkood peab lihtsalt töötama kõigi tüüpide puhul, mis võivad viidata seotud tüübile `T`, on sageli parem kasutada [`AsRef<T>`]-i, kuna rohkem tüüpe saab seda turvaliselt rakendada.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Andmekoguna omab [`HashMap<K, V>`] nii võtmeid kui ka väärtusi.Kui võtme tegelikud andmed on pakitud mingisse haldustüüpi, peaks siiski olema võimalik väärtust otsida, kasutades viidet võtme andmetele.
/// Näiteks kui võti on string, siis on see tõenäoliselt salvestatud koos räsikaardiga [`String`]-ga, samas kui [`&str`][`str`]-i abil peaks olema võimalik otsida.
/// Seega peab `insert` töötama `String`-ga, samas kui `get` peab saama kasutada `&str`-i.
///
/// Pisut lihtsustatult näevad `HashMap<K, V>`-i asjakohased osad välja järgmised:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // väljad on välja jäetud
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Kogu räsikaart on võtmetüübi `K` jaoks üldine.Kuna need võtmed on salvestatud räsikaardiga, peavad selle tüübi omad olema võtme andmed.
/// Võtmeväärtuste paari sisestamisel antakse kaardile selline `K` ja see peab leidma õige räsiriba ning kontrollima, kas võti on selle `K` põhjal juba olemas.Seetõttu vajab see `K: Hash + Eq`-i.
///
/// Kaardilt väärtuse otsimisel peaks otsitava võtmena lisama viide `K`-le, et sellise omandiväärtuse loomine oleks alati vajalik.
/// Stringivõtmete jaoks tähendaks see seda, et `String` väärtus tuleb luua ainult juhtumite otsimiseks, kus saadaval on ainult `str`.
///
/// Selle asemel on meetod `get` üldine aluseks olevate võtmeandmete tüübi suhtes, mida ülaltoodud meetodi allkirjas nimetatakse `Q`.Selles öeldakse, et `K` võtab laenu `Q`-iga, nõudes seda `K: Borrow<Q>`-i.
/// Nõudes lisaks `Q: Hash + Eq`-i, annab see märku nõudest, et `K` ja `Q` omaksid `Hash` ja `Eq` traits rakendusi, mis annavad identsed tulemused.
///
/// `get`-i rakendamine tugineb eelkõige `Hash`-i identsetele rakendustele, määrates võtme räsimahu, kutsudes `Hash::hash`-i väärtusele `Q`, isegi kui see sisestas võtme `K`-väärtuselt arvutatud räsi väärtuse põhjal.
///
///
/// Selle tagajärjel räsikaart puruneb, kui `Q`-väärtust pakkiv `K` tekitab teistsuguse räsi kui `Q`.Näiteks kujutage ette, et teil on tüüp, mis murrab stringi, kuid võrdleb nende väiketähti ignoreerivaid ASCII tähti:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Kuna kaks võrdset väärtust peavad tooma sama räsiväärtuse, peab `Hash` juurutamine ignoreerima ka ASCII-juhtumeid:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Kas `CaseInsensitiveString` saab rakendust `Borrow<str>` rakendada?See võib kindlasti anda viite stringi viilule selle sisalduva stringi kaudu.
/// Kuid kuna selle `Hash`-i rakendamine erineb, käitub see erinevalt `str`-st ja seetõttu ei tohi see tegelikult `Borrow<str>`-i rakendada.
/// Kui ta soovib lubada teistele juurdepääsu `str`-i aluseks olevale `str`-ile, saab ta seda teha ka `AsRef<str>`-i kaudu, millel pole täiendavaid nõudeid.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Laenab muutumatult omandiväärtuselt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// trait andmete vastastikuseks laenamiseks.
///
/// [`Borrow<T>`] kaaslasena võimaldab see trait tüübil laenata alusetüübina, pakkudes muutuvat viidet.
/// Lisateavet laenamise kui teise liigi kohta leiate jaotisest [`Borrow<T>`].
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Varasemalt laenab omandiväärtuselt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}