use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Kuigi seda funktsiooni kasutatakse ühes kohas ja selle rakendamine võiks olla joondatud, muutsid varasemad katsed seda teha rustc aeglasemaks:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Mäluploki paigutus.
///
/// `Layout` eksemplar kirjeldab konkreetset mälu paigutust.
/// Ehitate `Layout` üles sisendina, mida eraldajale anda.
///
/// Kõigil paigutustel on seotud suurus ja joondamine kahega.
///
/// (Pange tähele, et paigutustel ei pea olema nullist erinev suurus, isegi kui `GlobalAlloc` nõuab, et kõigi mälupäringute suurus oleks nullist erinev.
/// Helistaja peab kas tagama, et sellised tingimused on täidetud, kasutama spetsiifilisemaid nõudeid puudutavaid eraldajaid või kasutama leebemat `Allocator`-liidest.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // taotletud mäluploki suurus baitides mõõdetuna.
    size_: usize,

    // taotletud mäluplokki joondamine baitides.
    // tagame, et see on alati kahest võimust, sest API-d nagu `posix_memalign` seda nõuavad ja see on mõistlik piirang paigutusekonstruktoritele kehtestamiseks.
    //
    //
    // (Kuid me ei vaja analoogselt `joondamist>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Ehitab `Layout` antud `size` ja `align`-st või tagastab `LayoutError`, kui mõni järgmistest tingimustest pole täidetud:
    ///
    /// * `align` ei tohi olla null,
    ///
    /// * `align` peab olema kahe jõud,
    ///
    /// * `size`, kui ümardatakse `align` lähima mitmekordseni, ei tohi see üle voolata (st ümardatud väärtus peab olema väiksem või võrdne `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (kahe võimsus tähendab joondamist!=0.)

        // Ümardatud suurus on:
        //   size_rounded_up=(suurus + joondus, 1)&! (joondus, 1);
        //
        // Teame ülevalt, et joondus!=0.
        // Kui lisamine (joondamine, 1) ei lähe üle, siis on ümardamine hästi.
        //
        // Ja vastupidi,&-maskimine!-Ga (joondage, 1) lahutab ainult madala järgu bitid.
        // Seega, kui summaga toimub ülevool, ei saa&-mask selle ülevoolu tagasivõtmiseks piisavalt lahutada.
        //
        //
        // Ülaltoodu tähendab, et summeerimise ülevoolu kontrollimine on nii vajalik kui ka piisav.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // OHUTUS: `from_size_align_unchecked`-i tingimused on olnud
        // kontrollitud ülal.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Loob paigutuse, möödudes kõigist kontrollidest.
    ///
    /// # Safety
    ///
    /// See funktsioon on ohtlik, kuna see ei kontrolli [`Layout::from_size_align`]-i eeltingimusi.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // OHUTUS: helistaja peab tagama, et `align` on suurem kui null.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Selle paigutuse mäluploki minimaalne suurus baitides.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Selle paigutuse mäluploki minimaalne baitide joondus.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Ehitab `Layout`, mis sobib `T` tüüpi väärtuse hoidmiseks.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // OHUTUS: Rust tagab joonduse, et see on kahe ja
        // garanteeritud kombinatsioon size + align sobib meie aadressiruumi.
        // Selle tulemusena kasutage siin kontrollimata konstruktorit, et vältida panics koodi sisestamist, kui see pole piisavalt hästi optimeeritud.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Koostab paigutuse, mis kirjeldab kirjet, mida saab kasutada `T`-i tugistruktuuri eraldamiseks (mis võib olla trait või muu suurusteta tüüp nagu viil).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // OHUTUS: vaadake `new`-i põhjendusi, miks see kasutab ebaturvalist varianti
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Koostab paigutuse, mis kirjeldab kirjet, mida saab kasutada `T`-i tugistruktuuri eraldamiseks (mis võib olla trait või muu suurusteta tüüp nagu viil).
    ///
    /// # Safety
    ///
    /// Seda funktsiooni on turvaline helistada ainult siis, kui täidetud on järgmised tingimused:
    ///
    /// - Kui `T` on `Sized`, on selle funktsiooni helistamine alati ohutu.
    /// - Kui `T` suurusteta saba on:
    ///     - [slice], siis peab viilu saba pikkus olema intialiseeritud täisarv ja *kogu väärtuse* suurus (dünaamiline saba pikkus + staatilise suurusega eesliide) peab mahtuma `isize`-i.
    ///     - [trait object], siis peab kursori vtable-osake osutama sobimatu vtable-le tüübi `T` jaoks, mille on omandanud mõõtmeteta koersioon ja *kogu väärtuse* suurus (dünaamiline saba pikkus + staatilise suurusega prefiks) peab mahtuma `isize`-i.
    ///
    ///     - (unstable) [extern type], siis on selle funktsiooni kutsumine alati ohutu, kuid võib panic või muul viisil vale väärtuse tagastada, kuna välise tüübi paigutus pole teada.
    ///     See on sama käitumine kui [`Layout::for_value`] viitega välise tüübi sabale.
    ///     - muidu pole konservatiivselt lubatud seda funktsiooni kutsuda.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // OHUTUS: edastame helistajale nende funktsioonide eeltingimused
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // OHUTUS: vaadake `new`-i põhjendusi, miks see kasutab ebaturvalist varianti
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Loob `NonNull`, mis on rippuv, kuid selle paigutuse jaoks hästi joondatud.
    ///
    /// Pange tähele, et kursori väärtus võib potentsiaalselt tähistada kehtivat kursorit, mis tähendab, et seda ei tohi kasutada "not yet initialized" valvuriväärtusena.
    /// Laiskalt eraldavad tüübid peavad lähtestamist jälgima mõnel muul viisil.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // OHUTUS: joondus on tagatud nullist erinevana
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Loob kirje kirjeldava paigutuse, mis mahutab `self`-ga sama paigutuse väärtuse, kuid mis on joondatud joondusega `align` (mõõdetuna baitides).
    ///
    ///
    /// Kui `self` vastab juba ettenähtud joondusele, tagastab `self`.
    ///
    /// Pange tähele, et see meetod ei lisa üldmõõdule ühtegi polstrit, olenemata sellest, kas tagastatud paigutusel on erinev joondus.
    /// Teisisõnu, kui `K`-l on suurus 16, on `K.align_to(32)`-il *endiselt* suurus 16.
    ///
    /// Tagastab vea, kui `self.size()` ja antud `align` kombinatsioon rikub jaotises [`Layout::from_size_align`] loetletud tingimusi.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Tagastab polstrimahu, mille peame sisestama pärast `self`, et järgmine aadress rahuldaks `align` (mõõdetuna baitides).
    ///
    /// nt kui `self.size()` on 9, tagastab `self.padding_needed_for(4)` 3, sest see on minimaalne baitide arv 4-joondatud aadressi saamiseks (eeldades, et vastav mäluplokk algab 4-joondatud aadressist).
    ///
    ///
    /// Selle funktsiooni tagastusväärtusel pole mingit tähendust, kui `align` ei ole kahe astme aste.
    ///
    /// Pange tähele, et tagastatud väärtuse kasulikkus nõuab, et `align` oleks väiksem või võrdne kogu eraldatud mäluploki algusaadressi joondusega.Üks viis selle piirangu rahuldamiseks on tagada `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Ümardatud väärtus on:
        //   len_rounded_up=(len + joondus, 1)&! (joondus, 1);
        // ja siis tagastame polstrite erinevuse: `len_rounded_up - len`.
        //
        // Kasutame mooduliaritmeetikat kogu ulatuses:
        //
        // 1. joondamine on garanteeritud> 0, seega joondamine, 1 kehtib alati.
        //
        // 2.
        // `len + align - 1` võib üle voolata maksimaalselt `align - 1` võrra, nii et&-mask koos `!(align - 1)`-ga tagab, et ülevoolu korral on `len_rounded_up` ise 0.
        //
        //    Seega annab tagastatav polster `len`-ile lisamisel 0, mis triviaalselt rahuldab joondust `align`.
        //
        // (Loomulikult peaksid katsed eraldada mäluplokke, mille suurus ja täidis ülalnimetatud viisil ületäituvad, põhjustama eraldajale niikuinii viga.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Loob paigutuse, ümardades selle paigutuse suuruse mitmekordse paigutuse joonduseni.
    ///
    ///
    /// See on samaväärne `padding_needed_for`-i tulemuse lisamisega paigutuse praegusele suurusele.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // See ei saa üle voolata.Tsiteerides paigutuse muutumatut varianti:
        // > `size`, ümardatuna `align` lähima korrutiseni,
        // > ei tohi üle voolata (st ümardatud väärtus peab olema väiksem kui
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Loob paigutuse, mis kirjeldab `self`-i `n`-i eksemplaride kirjet, kusjuures igaühe vahel on sobiv kogus polste, et tagada igale eksemplarile soovitud suurus ja joondus.
    /// Edu korral tagastab `(k, offs)`, kus `k` on massiivi paigutus ja `offs` on massiivi iga elemendi alguse vaheline kaugus.
    ///
    /// Aritmeetilise ülevoolu korral tagastab `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // See ei saa üle voolata.Tsiteerides paigutuse muutumatut varianti:
        // > `size`, ümardatuna `align` lähima korrutiseni,
        // > ei tohi üle voolata (st ümardatud väärtus peab olema väiksem kui
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // OHUTUS: self.align on juba teadaolevalt kehtiv ja jaotuse_suurus on olnud
        // polsterdatud juba.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Loob paigutuse, mis kirjeldab kirjet `self`, millele järgneb `next`, koos vajaliku polsterdusega, et tagada `next` õige joondamine, kuid *pole järeltäidet*.
    ///
    /// C-esituse paigutuse `repr(C)` sobitamiseks peaksite pärast paigutuse laiendamist kõigi väljadega helistama `pad_to_align`-ile.
    /// (Rust vaikimisi kujutise paigutust `repr(Rust)`, as it is unspecified.) ei saa kuidagi sobitada
    ///
    /// Pange tähele, et saadud paigutuse joondamine on maksimaalne kui `self` ja `next`, et tagada mõlema osa joondamine.
    ///
    /// Tagastab `Ok((k, offset))`, kus `k` on liidetud kirje paigutus ja `offset` on liidetud kirje sisse põimitud `next` alguse suhteline asukoht baitides (eeldades, et kirje ise algab nihkest 0).
    ///
    ///
    /// Aritmeetilise ülevoolu korral tagastab `LayoutError`.
    ///
    /// # Examples
    ///
    /// `#[repr(C)]` struktuuri paigutuse ja väljade nihete arvutamiseks selle väljade paigutusest tehke järgmist.
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Ärge unustage `pad_to_align`-iga viimistleda!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // testige, kas see töötab
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Loob paigutuse, mis kirjeldab `self`-i `n`-i eksemplaride kirjet, ilma et iga eksemplari vahel oleks täidis.
    ///
    /// Pange tähele, et erinevalt `repeat`-st ei taga `repeat_packed`, et `self` korduvad eksemplarid oleksid õigesti joondatud, isegi kui `self` antud eksemplar on õigesti joondatud.
    /// Teisisõnu, kui massiivi eraldamiseks kasutatakse `repeat_packed`-i tagastatud paigutust, ei ole garanteeritud, et kõik massiivi elemendid oleksid õigesti joondatud.
    ///
    /// Aritmeetilise ülevoolu korral tagastab `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Loob paigutuse, mis kirjeldab kirjet `self`, millele järgneb `next`, ilma et nende kahe vahel oleks täiendavat polsterdust.
    /// Kuna polstrit pole sisestatud, pole `next` joondamine asjakohane ja seda ei kaasata *üldse* saadud paigutusse.
    ///
    ///
    /// Aritmeetilise ülevoolu korral tagastab `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Loob `[T; n]`-i kirjet kirjeldava paigutuse.
    ///
    /// Aritmeetilise ülevoolu korral tagastab `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// `Layout::from_size_align`-le või mõnele muule `Layout`-konstruktorile antud parameetrid ei vasta selle dokumenteeritud piirangutele.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (vajame seda trait vea allavoolu jaoks)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}