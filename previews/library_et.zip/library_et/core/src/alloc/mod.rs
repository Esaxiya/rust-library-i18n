//! Mälu eraldamise API-d

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Viga `AllocError` viitab jaotuse ebaõnnestumisele, mis võib olla tingitud ressursside ammendumisest või millestki valest, kui ühendate antud sisendargumendid selle eraldajaga.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (vajame seda trait vea allavoolu jaoks)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Rakendusega `Allocator` saab eraldada, kasvatada, kahandada ja jaotada meelevaldseid andmeplokke, mida on kirjeldatud [`Layout`][] kaudu.
///
/// `Allocator` on mõeldud rakendamiseks ZST-idel, viidetel või nutitelefonidel, kuna sellist eraldajat nagu `MyAlloc([u8; N])` ei saa teisaldada, ilma et kursoreid eraldatud mällu värskendataks.
///
/// Erinevalt [`GlobalAlloc`][]-ist on `Allocator`-is lubatud nullsuurused eraldised.
/// Kui aluseks olev eraldaja seda ei toeta (nagu jemalloc) või tagastab nullkursori (näiteks `libc::malloc`), peab see rakenduse kätte saama.
///
/// ### Praegu eraldatud mälu
///
/// Mõni meetod nõuab, et mäluplokk eraldataks * eraldaja kaudu.See tähendab, et:
///
/// * selle mäluploki algusaadressi tagastasid varem [`allocate`], [`grow`] või [`shrink`] ja
///
/// * mäluplokki ei ole hiljem jagatud, kus plokid jaotatakse kas otse, edastades need [`deallocate`]-le, või muudeti neid X0 [`grow`]-i või [`shrink`]-i edastamise kaudu, mis tagastab `Ok`.
///
/// Kui `grow` või `shrink` on tagastanud `Err`, jääb möödunud kursor kehtima.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Mälu mahutamine
///
/// Mõni meetod nõuab, et paigutus *mahuks* mäluplokki.
/// "fit"-i paigutuse jaoks tähendab mäluplokk (või samaväärselt "fit"-i jaoks mõeldud mäluploki jaoks paigutust) seda, et peavad vastama järgmistele tingimustele:
///
/// * Plokk tuleb eraldada sama joondusega nagu [`layout.align()`] ja
///
/// * Esitatud [`layout.size()`] peab jääma vahemikku `min ..= max`, kus:
///   - `min` on ploki eraldamiseks viimati kasutatud paigutuse suurus ja
///   - `max` on uusim tegelik suurus, mis on tagastatud seadmetelt [`allocate`], [`grow`] või [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Eraldajalt tagastatud mäluplokid peavad osutama kehtivale mälule ja säilitama kehtivuse, kuni eksemplar ja kõik selle kloonid kukutatakse,
///
/// * eraldaja kloonimine või teisaldamine ei tohi sellest eraldajast tagastatud mäluplokke kehtetuks muuta.Kloonitud eraldaja peab käituma nagu sama eraldaja ja
///
/// * suvalise [*currently allocated*]-tüüpi mäluploki osuti võib edastada eraldaja mis tahes muule meetodile.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Mäluploki eraldamise katsed.
    ///
    /// Edu korral tagastab [`NonNull<[u8]>`][NonNull], mis vastab `layout`-i suuruse ja joondamise garantiidele.
    ///
    /// Tagastataval plokil võib olla suurem suurus kui `layout.size()` määratleb ja selle sisu võib initsialiseeruda või mitte.
    ///
    /// # Errors
    ///
    /// Tagastav `Err` näitab, et kas mälu on otsas või `layout` ei vasta jaoturi suuruse või joondamise piirangutele.
    ///
    /// Rakendustel soovitatakse `Err`-i tagastada mälu ammendumise asemel paanika või katkestamise korral, kuid see pole range nõue.
    /// (Täpsemalt: see on *seaduslik* rakendada see trait aluseks oleva natiivse eraldamise teegi kohal, mis katkestab mälu ammendumise.)
    ///
    /// Kliente, kes soovivad eraldamise vea tõttu arvutamise katkestada, soovitatakse kutsuda funktsiooni [`handle_alloc_error`], selle asemel et otse kutsuda `panic!`-i või muud sarnast.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Käitub nagu `allocate`, kuid tagab ka tagastatud mälu null-initsialiseerimise.
    ///
    /// # Errors
    ///
    /// Tagastav `Err` näitab, et kas mälu on otsas või `layout` ei vasta jaoturi suuruse või joondamise piirangutele.
    ///
    /// Rakendustel soovitatakse `Err`-i tagastada mälu ammendumise asemel paanika või katkestamise korral, kuid see pole range nõue.
    /// (Täpsemalt: see on *seaduslik* rakendada see trait aluseks oleva natiivse eraldamise teegi kohal, mis katkestab mälu ammendumise.)
    ///
    /// Kliente, kes soovivad eraldamise vea tõttu arvutamise katkestada, soovitatakse kutsuda funktsiooni [`handle_alloc_error`], selle asemel et otse kutsuda `panic!`-i või muud sarnast.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // OHUTUS: `alloc` tagastab kehtiva mäluploki
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Jaotab mälu, millele `ptr` viitab.
    ///
    /// # Safety
    ///
    /// * `ptr` peab selle eraldaja kaudu tähistama mälu plokki [*currently allocated*] ja
    /// * `layout` peab [*fit*] selle mälu blokeerima.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Mäluploki laiendamise katsed.
    ///
    /// Tagastab uue [`NonNull<[u8]>`][NonNull], mis sisaldab kursorit ja eraldatud mälu tegelikku suurust.Kursor sobib `new_layout` kirjeldatud andmete hoidmiseks.
    /// Selle saavutamiseks võib eraldaja laiendada jaotist, millele `ptr` viitab, et see sobiks uue paigutusega.
    ///
    /// Kui see tagastab `Ok`, on `ptr` viidatud mäluploki omandiõigus sellele eraldajale üle antud.
    /// Mälu võib vabaneda või mitte, ja seda tuleks pidada kasutuskõlbmatuks, kui seda ei saadeta selle meetodi tagastusväärtuse kaudu helistajale uuesti tagasi.
    ///
    /// Kui see meetod tagastab `Err`, pole mäluploki omandiõigust sellele eraldajale üle antud ja mäluploki sisu ei muutu.
    ///
    /// # Safety
    ///
    /// * `ptr` peab selle eraldaja kaudu tähistama mälu plokki [*currently allocated*].
    /// * `old_layout` peab [*fit*] see mäluplokk olema (argument `new_layout` ei pea seda sobima.).
    /// * `new_layout.size()` peab olema suurem kui `old_layout.size()` või sellega võrdne.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Tagastab `Err`, kui uus paigutus ei vasta jaoturi suuruse ja joondaja piirangutele või kui kasvamine muul viisil nurjub.
    ///
    /// Rakendustel soovitatakse `Err`-i tagastada mälu ammendumise asemel paanika või katkestamise korral, kuid see pole range nõue.
    /// (Täpsemalt: see on *seaduslik* rakendada see trait aluseks oleva natiivse eraldamise teegi kohal, mis katkestab mälu ammendumise.)
    ///
    /// Kliente, kes soovivad eraldamise vea tõttu arvutamise katkestada, soovitatakse kutsuda funktsiooni [`handle_alloc_error`], selle asemel et otse kutsuda `panic!`-i või muud sarnast.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // OHUTUS: kuna `new_layout.size()` peab olema suurem või võrdne
        // `old_layout.size()`, nii vana kui ka uus mälujaotus kehtivad `old_layout.size()`-baitide lugemis-ja kirjutamisreeglite jaoks.
        // Kuna vana jaotust ei olnud veel jagatud, ei saa see `new_ptr`-i kattuda.
        // Seega on kõne `copy_nonoverlapping`-ile ohutu.
        // `dealloc`-i ohutuslepingut peab helistaja järgima.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Käitub nagu `grow`, kuid tagab ka selle, et uus sisu seatakse enne tagastamist nulli.
    ///
    /// Pärast edukat helistamist sisaldab mäluplok järgmist sisu
    /// `grow_zeroed`:
    ///   * Baiti `0..old_layout.size()` säilitatakse algsest jaotusest.
    ///   * Baidid `old_layout.size()..old_size` kas säilitatakse või nullitakse, sõltuvalt eraldaja rakendusest.
    ///   `old_size` viitab mäluploki suurusele enne `grow_zeroed`-kõnet, mis võib olla suurem kui suurus, mida selle eraldamisel algselt taotleti.
    ///   * Baiti `old_size..new_size` nullitakse.`new_size` viitab `grow_zeroed`-kõne tagastatud mäluploki suurusele.
    ///
    /// # Safety
    ///
    /// * `ptr` peab selle eraldaja kaudu tähistama mälu plokki [*currently allocated*].
    /// * `old_layout` peab [*fit*] see mäluplokk olema (argument `new_layout` ei pea seda sobima.).
    /// * `new_layout.size()` peab olema suurem kui `old_layout.size()` või sellega võrdne.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Tagastab `Err`, kui uus paigutus ei vasta jaoturi suuruse ja joondaja piirangutele või kui kasvamine muul viisil nurjub.
    ///
    /// Rakendustel soovitatakse `Err`-i tagastada mälu ammendumise asemel paanika või katkestamise korral, kuid see pole range nõue.
    /// (Täpsemalt: see on *seaduslik* rakendada see trait aluseks oleva natiivse eraldamise teegi kohal, mis katkestab mälu ammendumise.)
    ///
    /// Kliente, kes soovivad eraldamise vea tõttu arvutamise katkestada, soovitatakse kutsuda funktsiooni [`handle_alloc_error`], selle asemel et otse kutsuda `panic!`-i või muud sarnast.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // OHUTUS: kuna `new_layout.size()` peab olema suurem või võrdne
        // `old_layout.size()`, nii vana kui ka uus mälujaotus kehtivad `old_layout.size()`-baitide lugemis-ja kirjutamisreeglite jaoks.
        // Kuna vana jaotust ei olnud veel jagatud, ei saa see `new_ptr`-i kattuda.
        // Seega on kõne `copy_nonoverlapping`-ile ohutu.
        // `dealloc`-i ohutuslepingut peab helistaja järgima.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Katsed mäluplokki kahandada.
    ///
    /// Tagastab uue [`NonNull<[u8]>`][NonNull], mis sisaldab kursorit ja eraldatud mälu tegelikku suurust.Kursor sobib `new_layout` kirjeldatud andmete hoidmiseks.
    /// Selle saavutamiseks võib eraldaja kahandada `ptr` viidatud jaotust, et see sobiks uue paigutusega.
    ///
    /// Kui see tagastab `Ok`, on `ptr` viidatud mäluploki omandiõigus sellele eraldajale üle antud.
    /// Mälu võib vabaneda või mitte, ja seda tuleks pidada kasutuskõlbmatuks, kui seda ei saadeta selle meetodi tagastusväärtuse kaudu helistajale uuesti tagasi.
    ///
    /// Kui see meetod tagastab `Err`, pole mäluploki omandiõigust sellele eraldajale üle antud ja mäluploki sisu ei muutu.
    ///
    /// # Safety
    ///
    /// * `ptr` peab selle eraldaja kaudu tähistama mälu plokki [*currently allocated*].
    /// * `old_layout` peab [*fit*] see mäluplokk olema (argument `new_layout` ei pea seda sobima.).
    /// * `new_layout.size()` peab olema väiksem kui `old_layout.size()` või sellega võrdne.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Tagastab `Err`, kui uus paigutus ei vasta jaoturi suuruse ja joondaja piirangutele või kui kokkutõmbamine muul viisil ebaõnnestub.
    ///
    /// Rakendustel soovitatakse `Err`-i tagastada mälu ammendumise asemel paanika või katkestamise korral, kuid see pole range nõue.
    /// (Täpsemalt: see on *seaduslik* rakendada see trait aluseks oleva natiivse eraldamise teegi kohal, mis katkestab mälu ammendumise.)
    ///
    /// Kliente, kes soovivad eraldamise vea tõttu arvutamise katkestada, soovitatakse kutsuda funktsiooni [`handle_alloc_error`], selle asemel et otse kutsuda `panic!`-i või muud sarnast.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // OHUTUS: kuna `new_layout.size()` peab olema väiksem või võrdne
        // `old_layout.size()`, nii vana kui ka uus mälujaotus kehtivad `new_layout.size()`-baitide lugemis-ja kirjutamisreeglite jaoks.
        // Kuna vana jaotust ei olnud veel jagatud, ei saa see `new_ptr`-i kattuda.
        // Seega on kõne `copy_nonoverlapping`-ile ohutu.
        // `dealloc`-i ohutuslepingut peab helistaja järgima.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Loob selle `Allocator`-i eksemplari jaoks "by reference"-adapteri.
    ///
    /// Tagastatud adapter kasutab ka `Allocator`-i ja laenab selle lihtsalt.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // OHUTUS: helistaja peab kinni pidama ohutuslepingust
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // OHUTUS: helistaja peab kinni pidama ohutuslepingust
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // OHUTUS: helistaja peab kinni pidama ohutuslepingust
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // OHUTUS: helistaja peab kinni pidama ohutuslepingust
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}