use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Mälujagur, mida saab atribuudi `#[global_allocator]` kaudu registreerida standardraamatukogu vaikimisi.
///
/// Mõni meetod nõuab, et mäluplokk eraldataks * eraldaja kaudu.See tähendab, et:
///
/// * selle mäluploki algusaadress tagastati varem eelmise kõne abil eraldusmeetodile, näiteks `alloc`, ja
///
/// * mäluplokki ei ole hiljem jagatud, kus plokid jaotatakse kas edastades tehingujaotuse meetodile, näiteks `dealloc`, või suunates ümberjaotamise meetodile, mis tagastab nullist osuti.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` trait on `unsafe` trait mitmel põhjusel ja rakendajad peavad tagama nende lepingute järgimise:
///
/// * See on määratlemata käitumine, kui globaalsed eraldajad lõdvestuvad.Selle piirangu võib rakenduses future tühistada, kuid praegu võib mis tahes nimetatud funktsiooni funktsioon panic põhjustada mälu ebaturvalisust.
///
/// * `Layout` päringud ja arvutused üldiselt peavad olema õiged.Selle trait helistajatel on lubatud tugineda igal meetodil määratletud lepingutele ja rakendajad peavad tagama, et sellised lepingud jäävad tõeks.
///
/// * Te ei pruugi tugineda tegelikult toimuvatele eraldistele, isegi kui allikas sisaldab selgesõnalisi kuhja eraldisi.
/// Optimeerija võib tuvastada kasutamata jaotused, mille ta saab kas täielikult kõrvaldada või kolida virna ja seega mitte kunagi eraldajat kutsuda.
/// Optimeerija võib lisaks eeldada, et jaotamine on eksimatu, nii et kood, mis varem jaoturi rikete tõttu ebaõnnestus, võib nüüd äkki töötada, kuna optimeerija töötas ümber eraldamise vajaduse.
/// Konkreetsemalt öeldes on järgmine koodinäide ebamõistlik, olenemata sellest, kas teie kohandatud eraldaja lubab loendada, kui palju eraldisi on juhtunud.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Pange tähele, et ülalnimetatud optimeerimised pole ainsad rakendatavad optimeerimised.Te ei pruugi üldjuhul loota kuhjaga seotud jaotustele, kui neid saab programmi käitumist muutmata eemaldada.
///   See, kas jaotused toimuvad või mitte, ei kuulu programmi käitumise hulka, isegi kui selle saaks tuvastada eraldaja kaudu, mis jälgib eraldisi printimise või muul viisil kõrvaltoimete abil.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Eraldage mälu vastavalt `layout`-i kirjeldusele.
    ///
    /// Tagastab kursori äsja eraldatud mällu või null, mis näitab eraldamise tõrkeid.
    ///
    /// # Safety
    ///
    /// See funktsioon on ebaturvaline, kuna määratlemata käitumine võib ilmneda juhul, kui helistaja ei taga, et `layout` on nullist erinev.
    ///
    /// (Laienduse alamkategooriad võivad anda käitumisele täpsemad piirid, näiteks tagavad null-suuruse jaotustaotluse korral valvuriaadressi või nullkursori.)
    ///
    /// Eraldatud mäluplokki võib lähtestada või mitte.
    ///
    /// # Errors
    ///
    /// Nullkursori tagastamine näitab, et kas mälu on otsas või `layout` ei vasta selle eraldaja suuruse või joonduse piirangutele.
    ///
    /// Rakendusi soovitatakse mälu ammendumise asemel tühistamise asemel katkestada, kuid see pole range nõue.
    /// (Täpsemalt: see on *seaduslik* rakendada see trait aluseks oleva natiivse eraldamise teegi kohal, mis katkestab mälu ammendumise.)
    ///
    /// Kliente, kes soovivad eraldamise vea tõttu arvutamise katkestada, soovitatakse kutsuda funktsiooni [`handle_alloc_error`], selle asemel et otse kutsuda `panic!`-i või muud sarnast.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Jaotage antud `ptr`-osuti mäluplok antud `layout`-iga.
    ///
    /// # Safety
    ///
    /// See funktsioon on ohtlik, kuna määratlemata käitumine võib tekkida juhul, kui helistaja ei taga kõiki järgmisi toiminguid:
    ///
    ///
    /// * `ptr` peab tähistama selle eraldaja kaudu praegu eraldatud mäluplokki,
    ///
    /// * `layout` peab olema sama paigutus, mida kasutati mäluploki eraldamiseks.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Käitub nagu `alloc`, kuid tagab ka sisu tagastamise enne nulli nullimist.
    ///
    /// # Safety
    ///
    /// See funktsioon on ohtlik samadel põhjustel, mis on ka `alloc`.
    /// Eraldatud mäluploki lähtestamine on aga garanteeritud.
    ///
    /// # Errors
    ///
    /// Nullkursori tagastamine näitab, et kas mälu on otsas või `layout` ei vasta jaoturi suuruse või joondamise piirangutele, nagu `alloc`-is.
    ///
    /// Kliente, kes soovivad eraldamise vea tõttu arvutamise katkestada, soovitatakse kutsuda funktsiooni [`handle_alloc_error`], selle asemel et otse kutsuda `panic!`-i või muud sarnast.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // OHUTUS: helistaja peab kinni pidama seadme `alloc` ohutuslepingust.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // OHUTUS: kui eraldamine õnnestus, siis piirkond `ptr`-st
            // suurusega `size` kehtib kirjutamise korral.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Kahandage või suurendage mäluplokki antud `new_size`-ni.
    /// Plokki kirjeldavad antud `ptr`-osuti ja `layout`.
    ///
    /// Kui see tagastab nullist osuti, on `ptr` viidatud mäluploki omandiõigus sellele eraldajale üle antud.
    /// Mälu võib olla jaotatud või mitte, ja seda tuleks pidada kasutuskõlbmatuks (välja arvatud juhul, kui see on muidugi selle meetodi tagastusväärtuse kaudu helistajale uuesti tagasi viidud).
    /// Uus mäluplokk on eraldatud `layout`-ga, kuid `size` on uuendatud `new_size`-i.
    /// Seda uut paigutust tuleks kasutada uue mäluploki `dealloc`-ga jagamisel.
    /// Uue mäluploki vahemikul `0..min(layout.size(), new_size) `on garanteeritud samad väärtused nagu algsel plokil.
    ///
    /// Kui see meetod tagastab väärtuse null, pole mäluploki omandiõigust sellele eraldajale üle antud ja mäluploki sisu ei muutu.
    ///
    /// # Safety
    ///
    /// See funktsioon on ohtlik, kuna määratlemata käitumine võib tekkida juhul, kui helistaja ei taga kõiki järgmisi toiminguid:
    ///
    /// * `ptr` tuleb selle eraldaja kaudu praegu eraldada,
    ///
    /// * `layout` peab olema sama paigutus, mida kasutati mäluploki eraldamiseks,
    ///
    /// * `new_size` peab olema suurem kui null.
    ///
    /// * `new_size`, kui ümardatakse `layout.align()` lähima mitmekordseni, ei tohi see üle voolata (st ümardatud väärtus peab olema väiksem kui `usize::MAX`).
    ///
    /// (Laienduse alamkategooriad võivad anda käitumisele täpsemad piirid, näiteks tagavad null-suuruse jaotustaotluse korral valvuriaadressi või nullkursori.)
    ///
    /// # Errors
    ///
    /// Tagastab väärtuse null, kui uus paigutus ei vasta jaoturi suuruse ja joondamise piirangutele või kui ümberjaotamine muul viisil ebaõnnestub.
    ///
    /// Rakendusi soovitatakse mälu ammendumise asemel tühjaks teha, mitte paanitseda või katkestada, kuid see pole range nõue.
    /// (Täpsemalt: see on *seaduslik* rakendada see trait aluseks oleva natiivse eraldamise teegi kohal, mis katkestab mälu ammendumise.)
    ///
    /// Kliente, kes soovivad ümberjaotamisveale vastava arvutamise katkestada, soovitatakse kutsuda funktsiooni [`handle_alloc_error`], selle asemel, et otseselt kutsuda `panic!`-i või muud sarnast.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // OHUTUS: helistaja peab tagama, et `new_size` ei voola üle.
        // `layout.align()` pärineb `Layout`-st ja on seega garanteeritud, et see kehtib.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // OHUTUS: helistaja peab tagama, et `new_layout` on suurem kui null.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // SAFETY: varem eraldatud plokk ei saa äsja eraldatud plokiga kattuda.
            // `dealloc`-i ohutuslepingut peab helistaja järgima.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}