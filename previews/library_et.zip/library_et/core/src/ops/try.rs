/// trait `?`-operaatori käitumise kohandamiseks.
///
/// `Try`-i rakendav tüüp on selline, millel on kanooniline viis seda success/failure-dihhotoomia osas vaadata.
/// See trait võimaldab nii edukuse või ebaõnnestumise väärtuste eraldamist olemasolevast eksemplarist kui ka uue eksemplari loomist õnnestumise või ebaõnnestumise väärtusest.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Selle väärtuse tüüp, kui seda vaadatakse edukana.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Selle väärtuse tüüp nurjununa vaadatuna.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Rakendab operaatorit "?".`Ok(t)`-i tagastamine tähendab, et käivitamine peaks jätkuma tavapäraselt ja `?`-i tulemus on väärtus `t`.
    /// `Err(e)`-i tagastamine tähendab, et käivitamine peaks branch sisenema `catch`-i sisimasse või funktsioonist naasma.
    ///
    /// Kui `Err(e)` tulemus tagastatakse, on `e` väärtuseks "wrapped" ümbritseva sektori tagastustüübis (mis peab ise rakendama `Try`).
    ///
    /// Täpsemalt tagastatakse väärtus `X::from_error(From::from(e))`, kus `X` on ümbritseva funktsiooni tagastustüüp.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Kombineeritud tulemuse koostamiseks mähitage vea väärtus.
    /// Näiteks `Result::Err(x)` ja `Result::from_error(x)` on samaväärsed.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Komposiiditulemuse koostamiseks keerake väärtus OK.
    /// Näiteks `Result::Ok(x)` ja `Result::from_ok(x)` on samaväärsed.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}