/// Kasutatakse muutumatute alandamistoimingute jaoks, näiteks `*v`.
///
/// Lisaks `Deref`-i kasutamisele operaatoriga (unary) `*` muutumatutes kontekstides, kasutab kompilaator kaudselt ka `Deref` mitmel juhul.
/// Seda mehhanismi nimetatakse ['`Deref` coercion'][more].
/// Muutuvas kontekstis kasutatakse [`DerefMut`]-i.
///
/// `Deref`-i juurutamine nutikate osutite jaoks muudab nende taga olevatele andmetele juurdepääsu mugavaks, mistõttu nad rakendavad `Deref`-i.
/// Teisest küljest olid `Deref` ja [`DerefMut`]-i reeglid loodud spetsiaalselt nutikate osutite mahutamiseks.
/// Seetõttu tuleks segaduste vältimiseks rakendada **"Deref" ainult nutikate osutite jaoks**.
///
/// Sarnastel põhjustel **ei tohiks see trait kunagi ebaõnnestuda**.Ebaõnnestumine dereferencing ajal võib olla äärmiselt segane, kui `Deref`-i kaudselt kutsutakse.
///
/// # Lisateavet `Deref` sunni kohta
///
/// Kui `T` rakendab `Deref<Target = U>` ja `x` on tüübi `T` väärtus, siis:
///
/// * Muutumatutes kontekstides on `*x` (kus `T` ei ole võrdlus-ega toorosuti) samaväärne `* Deref::deref(&x)`-ga.
/// * `&T` tüüpi väärtused sunnitakse tüübi `&U` väärtustele
/// * `T` rakendab kaudselt kõiki `U` tüüpi (immutable)-meetodeid.
///
/// Lisateabe saamiseks külastage [the chapter in *The Rust Programming Language*][book] ning [the dereference operator][ref-deref-op], [method resolution] ja [type coercions] viitejagu.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Ühe väljaga struktuur, millele pääseb juurde, viidates struktuuri välja.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Saadud tüüp pärast lahkhelistamist.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Viitab väärtusele.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Kasutatakse muudetavate alandamistoimingute jaoks, nagu `*v = 1;`-is.
///
/// Lisaks `DerefMut`-i kasutamisele operaatoriga (unary) `*` muutuvas kontekstis kasutatakse kompilaatoril kaudselt ka `DerefMut`-i.
/// Seda mehhanismi nimetatakse ['`Deref` coercion'][more].
/// Muutumatutes kontekstides kasutatakse [`Deref`]-i.
///
/// `DerefMut`-i juurutamine nutikate osutite jaoks muudab nende taga olevate andmete muteerimise mugavaks, mistõttu nad rakendavad `DerefMut`-i.
/// Teisest küljest olid [`Deref`] ja `DerefMut`-i reeglid loodud spetsiaalselt nutikate osutite mahutamiseks.
/// Seetõttu tuleks segaduste vältimiseks **`DerefMut` rakendada ainult nutikate näpunäidete** jaoks.
///
/// Sarnastel põhjustel **ei tohiks see trait kunagi ebaõnnestuda**.Ebaõnnestumine dereferencing ajal võib olla äärmiselt segane, kui `DerefMut`-i kaudselt kutsutakse.
///
/// # Lisateavet `Deref` sunni kohta
///
/// Kui `T` rakendab `DerefMut<Target = U>` ja `x` on tüübi `T` väärtus, siis:
///
/// * Muutuvates kontekstides on `*x` (kus `T` ei ole võrdlus-ega toorosuti) samaväärne `* DerefMut::deref_mut(&mut x)`-ga.
/// * `&mut T` tüüpi väärtused sunnitakse tüübi `&mut U` väärtustele
/// * `T` rakendab kaudselt kõiki `U` tüüpi (mutable)-meetodeid.
///
/// Lisateabe saamiseks külastage [the chapter in *The Rust Programming Language*][book] ning [the dereference operator][ref-deref-op], [method resolution] ja [type coercions] viitejagu.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Ühe väljaga struktuur, mida on võimalik muuta, viidates struktuurile alla.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Jätab väärtuse muutumatult kõrvale.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Näitab, et struktuuri saab kasutada meetodi vastuvõtjana ilma funktsioonita `arbitrary_self_types`.
///
/// Seda rakendavad stdlib-osuti tüübid nagu `Box<T>`, `Rc<T>`, `&T` ja `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}