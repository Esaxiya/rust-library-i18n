/// Kohandatud kood hävitaja sees.
///
/// Kui väärtust pole enam vaja, käivitab Rust selle väärtuse "destructor".
/// Kõige tavalisem viis, kuidas väärtust enam ei vajata, on siis, kui see väärtusest välja läheb.Hävitajad võivad siiski töötada muudel asjaoludel, kuid keskendume siinsete näidete ulatusele.
/// Mõne muu juhtumi kohta lisateabe saamiseks vaadake jaotist [the reference] destruktorite kohta.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// See hävitaja koosneb kahest komponendist:
/// - Kõne `Drop::drop`-ile selle väärtuse jaoks, kui see eriline `Drop` trait on selle tüübi jaoks rakendatud.
/// - Automaatselt genereeritud "drop glue", mis rekursiivselt kutsub selle väärtuse kõigi väljade hävitajaid.
///
/// Kuna Rust kutsub automaatselt kõigi sisalduvate väljade hävitajaid, ei pea te enamikul juhtudel rakendama `Drop`.
/// Kuid mõnel juhul on see kasulik, näiteks tüüpide puhul, mis ressurssi otse haldavad.
/// See ressurss võib olla mälu, see võib olla faili kirjeldaja, see võib olla võrgupesa.
/// Kui seda tüüpi väärtust enam ei kasutata, peaks see "clean up" oma ressurssi vabastama mälu või sulgema faili või sokli.
/// See on hävitaja töö ja seega ka `Drop::drop` töö.
///
/// ## Examples
///
/// Destruktorite töös nägemiseks vaatame järgmist programmi:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust kutsub esmalt `Drop::drop`-i `_x`-ile ja seejärel nii `_x.one`-le kui ka `_x.two`-ile, mis tähendab, et selle käivitamine prindib
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Isegi kui eemaldame rakenduse `Drop` rakenduse `HasTwoDrop` jaoks, kutsutakse selle väljade hävitajaid ikkagi.
/// Selle tulemuseks oleks
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Te ei saa `Drop::drop`-ile ise helistada
///
/// Kuna väärtuse puhastamiseks kasutatakse `Drop::drop`-i, võib pärast meetodi kutsumist olla selle väärtuse kasutamine ohtlik.
/// Kuna `Drop::drop` ei võta oma sisendi omandisse, takistab Rust väärkasutust, lubamata teil otse `Drop::drop`-ile helistada.
///
/// Teisisõnu, kui proovisite ülaltoodud näites `Drop::drop`-i selgesõnaliselt helistada, näete kompilaatori viga.
///
/// Kui soovite sõnaselgelt helistada väärtuse hävitajale, saab selle asemel kasutada [`mem::drop`]-i.
///
/// [`mem::drop`]: drop
///
/// ## Drop order
///
/// Milline meie kahest `HasDrop`-st langeb siiski esimesena?Struktuuride puhul on see sama järjekord, nagu nad deklareeritakse: kõigepealt `one`, siis `two`.
/// Kui soovite seda ise proovida, saate ülaltoodud `HasDrop`-i muuta, et see sisaldaks mõnda teavet, näiteks täisarvu, ja seejärel kasutada seda `Drop`-i sees olevas `println!`-is.
/// Selle käitumise tagab keel.
///
/// Erinevalt struktuuridest kukutatakse lokaalsed muutujad vastupidises järjekorras:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// See prinditakse
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Täielike reeglite leiate [the reference]-ist.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` ja `Drop` on eksklusiivsed
///
/// Nii [`Copy`] kui ka `Drop` ei saa ühele tüübile rakendada.Tüübid, mis on `Copy`, dubleeritakse kompilaatori poolt kaudselt, mistõttu on väga raske ennustada, millal ja kui sageli destruktoreid käivitatakse.
///
/// Sellisel kujul ei saa nendel tüüpidel olla destruktoreid.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Käivitab selle tüübi hävitaja.
    ///
    /// Seda meetodit kutsutakse kaudselt, kui väärtus väljub ulatusest, ja seda ei saa selgesõnaliselt kutsuda (see on kompilaatori viga [E0040]).
    /// prelude funktsiooni [`mem::drop`] saab siiski kasutada argumendi `Drop` rakenduse kutsumiseks.
    ///
    /// Kui seda meetodit on kutsutud, pole `self`-i veel jagatud.
    /// See juhtub alles pärast meetodi lõppu.
    /// Kui see nii ei oleks, oleks `self` rippuv viide.
    ///
    /// # Panics
    ///
    /// Arvestades, et [`panic!`] helistab `drop`-ile, kui see lahti kerib, katkestatakse tõenäoliselt kõik [`panic!`]-d rakenduses `drop`.
    ///
    /// Pange tähele, et isegi kui see panics, loetakse väärtus langenuks;
    /// te ei tohi põhjustada `drop`-i uuesti helistamist.
    /// Kompilaator haldab seda tavaliselt automaatselt, kuid ebaturvalise koodi kasutamisel võib see mõnikord juhtuda tahtmatult, eriti [`ptr::drop_in_place`]-i kasutamisel.
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}