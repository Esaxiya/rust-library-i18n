/// Kõneoperaatori versioon, mis võtab muutumatu vastuvõtja.
///
/// `Fn` eksemplare saab korduvalt kutsuda ilma olekut muteerimata.
///
/// *Seda trait (`Fn`) ei tohi segi ajada [function pointers] (`fn`)-ga.*
///
/// `Fn` rakendatakse automaatselt nii sulgemiste abil, mis viitavad muutumatutele viidetele jäädvustatud muutujatele või ei hõivata üldse midagi, kui ka (safe) [function pointers] (mõningate hoiatustega vaadake nende üksikasjadest lähemalt).
///
/// Lisaks rakendab mis tahes tüüpi `F`, mis rakendab `Fn`, ka `&F`.
///
/// Kuna nii [`FnMut`] kui ka [`FnOnce`] on `Fn` supertraktid, võib parameetrina kasutada kõiki `Fn` eksemplare, kus eeldatakse [`FnMut`] või [`FnOnce`].
///
/// Kasutage sidet `Fn`, kui soovite aktsepteerida funktsiooni tüüpi parameetrit ja peate seda kutsuma korduvalt ja olekut muteerimata (nt samaaegse helistamise korral).
/// Kui te ei vaja nii rangeid nõudeid, kasutage piiridena [`FnMut`] või [`FnOnce`].
///
/// Selle teema kohta lisateabe saamiseks vaadake [chapter on closures in *The Rust Programming Language*][book]-i.
///
/// Märkimist väärib ka `Fn` traits spetsiaalne süntaks (nt
/// `Fn(usize, bool) -> kasutama`).Kes on huvitatud selle tehnilistest üksikasjadest, võib viidata [the relevant section in the *Rustonomicon*][nomicon]-ile.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Üleskutse kutsumine
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Parameetri `Fn` kasutamine
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // et regex saaks sellele `&str: !FnMut`-ile tugineda
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Teeb kõnetoimingu.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Kõneoperaatori versioon, mis võtab muudetava vastuvõtja.
///
/// `FnMut`-i eksemplare saab korduvalt kutsuda ja need võivad olekut muuta.
///
/// `FnMut` rakendatakse automaatselt sulgemiste abil, mis hõlmavad muutuvaid viiteid hõivatud muutujatele, samuti kõikidele tüüpidele, mis rakendavad [`Fn`]-i, nt (safe) [function pointers] (kuna `FnMut` on [`Fn`]-i ülitükk).
/// Lisaks rakendab mis tahes tüüpi `F`, mis rakendab `FnMut`, ka `&mut F`.
///
/// Kuna [`FnOnce`] on `FnMut` supertrait, saab kasutada kõiki `FnMut` eksemplare, kus eeldatakse [`FnOnce`]-i, ja kuna [`Fn`] on `FnMut` alamvorm, võib kasutada kõiki [`Fn`]-i eksemplare, kus eeldatavasti on `FnMut`.
///
/// Kasutage sidet `FnMut`, kui soovite aktsepteerida funktsiooni tüüpi parameetrit ja peate seda korduvalt kutsuma, võimaldades samal ajal olekut muteerida.
/// Kui te ei soovi, et parameeter muteeriks olekut, kasutage seotuna [`Fn`];kui te ei pea seda korduvalt helistama, kasutage [`FnOnce`]-i.
///
/// Selle teema kohta lisateabe saamiseks vaadake [chapter on closures in *The Rust Programming Language*][book]-i.
///
/// Märkimist väärib ka `Fn` traits spetsiaalne süntaks (nt
/// `Fn(usize, bool) -> kasutama`).Kes on huvitatud selle tehnilistest üksikasjadest, võib viidata [the relevant section in the *Rustonomicon*][nomicon]-ile.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Helistades vastastikku jäädvustatavaks sulgemiseks
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Parameetri `FnMut` kasutamine
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // et regex saaks sellele `&str: !FnMut`-ile tugineda
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Teeb kõnetoimingu.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Kõneoperaatori versioon, mis võtab vastu kõrvalväärtuse vastuvõtja.
///
/// `FnOnce`-i eksemplare saab kutsuda, kuid neid ei pruugi mitu korda helistada.Sellepärast, kui tüübi kohta on teada ainult see, et see rakendab `FnOnce`-i, saab seda helistada ainult üks kord.
///
/// `FnOnce` rakendatakse automaatselt nii sulgemistega, mis võivad tarbida hõivatud muutujaid, kui ka kõigi tüüpidega, mis rakendavad [`FnMut`]-i, nt (safe) [function pointers] (kuna `FnOnce` on [`FnMut`]-i ülitükk).
///
///
/// Kuna nii [`Fn`] kui ka [`FnMut`] on `FnOnce` alamtunnused, võib kasutada kõiki [`Fn`] või [`FnMut`] eksemplare, kus eeldatakse `FnOnce`-i.
///
/// Kasutage sidet `FnOnce`, kui soovite aktsepteerida funktsiooni tüüpi parameetrit ja peate seda vaid üks kord kutsuma.
/// Kui peate parameetrit korduvalt kutsuma, kasutage sidetena [`FnMut`];kui vajate seda ka muteerumata olekuks, kasutage [`Fn`]-i.
///
/// Selle teema kohta lisateabe saamiseks vaadake [chapter on closures in *The Rust Programming Language*][book]-i.
///
/// Märkimist väärib ka `Fn` traits spetsiaalne süntaks (nt
/// `Fn(usize, bool) -> kasutama`).Kes on huvitatud selle tehnilistest üksikasjadest, võib viidata [the relevant section in the *Rustonomicon*][nomicon]-ile.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Parameetri `FnOnce` kasutamine
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` kulutab oma hõivatud muutujaid, nii et seda ei saa käitada rohkem kui üks kord.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Kui proovite uuesti `func()`-i käivitada, visatakse `func`-i jaoks viga `use of moved value`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` siinkohal enam kasutada ei saa
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // et regex saaks sellele `&str: !FnMut`-ile tugineda
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Tagastatud tüüp pärast kõneoperaatori kasutamist.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Teeb kõnetoimingu.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}