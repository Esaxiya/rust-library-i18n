use crate::marker::Unpin;
use crate::pin::Pin;

/// Generaatori jätkamise tulemus.
///
/// See loend tagastatakse meetodilt `Generator::resume` ja see näitab generaatori võimalikke tagastusväärtusi.
/// Praegu vastab see kas riputuspunktile (`Yielded`) või lõpp-punktile (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Generaator on peatatud väärtusega.
    ///
    /// See olek näitab, et generaator on peatatud ja vastab tavaliselt `yield`-i lausele.
    /// Selles variandis pakutav väärtus vastab `yield`-le edastatud avaldisele ja võimaldab generaatoritel anda väärtuse iga kord, kui nad annavad.
    ///
    ///
    Yielded(Y),

    /// Generaator on komplekteeritud tagastatava väärtusega.
    ///
    /// See olek näitab, et generaator on lõpule viidud antud väärtusega.
    /// Kui generaator on `Complete` tagastanud, loetakse `resume` uuesti helistamiseks programmeerija viga.
    ///
    Complete(R),
}

/// trait, mida rakendavad sisseehitatud generaatoritüübid.
///
/// Generaatorid, mida tavaliselt nimetatakse ka korutiinideks, on Rust-s praegu eksperimentaalne keelefunktsioon.
/// [RFC 2033]-i lisatud generaatorid on praegu mõeldud peamiselt async/await-i süntaksi ehitusplokiks, kuid tõenäoliselt laienevad ka iteraatorite ja muude primitiivide ergonoomilise määratluse pakkumisele.
///
///
/// Generaatorite süntaks ja semantika on ebastabiilsed ning stabiliseerimiseks on vaja täiendavat RFC-d.Praegu on süntaks siiski sulgemisjärgne:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Generaatorite kohta lisateavet leiate ebastabiilsest raamatust.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Selle generaatori poolt saadava väärtuse tüüp.
    ///
    /// See seotud tüüp vastab avaldisele `yield` ja väärtustele, mida lubatakse tagastada iga kord, kui generaator annab.
    ///
    /// Näiteks iteraator-generaatorina oleks tõenäoliselt seda tüüpi `T`, tüüp on üle korratud.
    ///
    type Yield;

    /// Selle generaatori tagastatud väärtuse tüüp.
    ///
    /// See vastab tüübile, mis tagastati generaatorilt kas `return`-lausega või kaudselt generaatorliitli viimase avaldisena.
    /// Näiteks futures kasutaks seda kui `Result<T, E>`, kuna see tähistab lõpetatud future.
    ///
    ///
    type Return;

    /// Jätkab selle generaatori käivitamist.
    ///
    /// See funktsioon jätkab generaatori käivitamist või käivitab selle, kui see pole veel käivitatud.
    /// See kõne naaseb uuesti generaatori viimasesse peatuspunkti, jätkates käivitamist viimasest `yield`-ist.
    /// Generaator jätkab käivitamist seni, kuni see kas annab või naaseb, sel hetkel see funktsioon naaseb.
    ///
    /// # Tagastusväärtus
    ///
    /// Selle funktsiooni abil tagastatud `GeneratorState` loend näitab, millises olekus on generaator naasmisel.
    /// Kui `Yielded` variant tagastatakse, on generaator jõudnud riputuspunkti ja väärtus on välja antud.
    /// Selles olekus olevad generaatorid on hiljem jätkamiseks saadaval.
    ///
    /// Kui `Complete` tagastatakse, on generaator ettenähtud väärtusega täielikult valmis.Generaatori uuesti jätkamine on kehtetu.
    ///
    /// # Panics
    ///
    /// See funktsioon võib olla panic, kui seda kutsutakse pärast seda, kui `Complete` variant on varem tagastatud.
    /// Kui pärast `Complete`-i jätkamist on selles keeles loodud generaator-literaalid panic-le tagatud, pole see tagatud kõigi `Generator` trait-i rakenduste puhul.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}