use crate::marker::Unsize;

/// Trait, mis näitab, et see on kursor või selle ümbris, kus pointee jaoks saab suurust lahti võtta.
///
/// Lisateavet leiate mudelitest [DST coercion RFC][dst-coerce] ja [the nomicon entry on coercion][nomicon-coerce].
///
/// Sisseehitatud kursoritüüpide korral sunnib `T`-i osutajad osutama `U`-le, kui `T: Unsize<U>`, teisendades õhukest kursorit rasvaks.
///
/// Kohandatud tüüpide korral toimib siin sundimine `Foo<T>`-i `Foo<U>`-ile sundimisega tingimusel, et eksisteerib `CoerceUnsized<Foo<U>> for Foo<T>` implikaat.
/// Sellist implikaati saab kirjutada ainult siis, kui `Foo<T>`-l on ainult üks mittefantomandmete väli, mis hõlmab `T`-i.
/// Kui selle välja tüüp on `Bar<T>`, peab `CoerceUnsized<Bar<U>> for Bar<T>`-i rakendus olema olemas.
/// Sundimine sunnib `Bar<T>` välja `Bar<U>`-i sundima ja ülejäänud väljad `Foo<T>`-st täitma, et luua `Foo<U>`.
/// See aitab tõhusalt viia kursori välja ja sundida seda.
///
/// Üldiselt rakendate nutikate osutite jaoks `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`-i, valikulise `?Sized`-ga seotuna `T`-ile endale.
/// Otse `T`-i manustavate ümbristüüpide puhul, nagu `Cell<T>` ja `RefCell<T>`, saate `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`-i otse rakendada.
///
/// See võimaldab sellist tüüpi sunnil nagu `Cell<Box<T>>` töötada.
///
/// [`Unsize`][unsize] kasutatakse selliste tüüpide tähistamiseks, mida saab osutite taga sundida DST-dele.Koostaja rakendab seda automaatselt.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * konst U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Seda kasutatakse objekti turvalisuse tagamiseks, et kontrollida, kas meetodi vastuvõtja tüüpi saab edasi saata.
///
/// trait rakenduse näide:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}