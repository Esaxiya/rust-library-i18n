//! Ürgsed traits ja tüübid, mis esindavad tüüpide põhiomadusi.
//!
//! Rust tüüpe saab nende sisemiste omaduste järgi klassifitseerida mitmel viisil.
//! Neid klassifikatsioone tähistatakse kui traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Tüübid, mida saab üle lõime piiride viia.
///
/// See trait rakendatakse automaatselt, kui kompilaator määrab selle sobivaks.
///
/// Mitte-saatmise tüübi näiteks on viidete loendamise osuti [`rc::Rc`][`Rc`].
/// Kui kaks lõime üritavad kloonida [`Rc`-sid], mis osutavad samale viitega loendatud väärtusele, võivad nad proovida värskendada võrdlusloendit korraga, mis on [undefined behavior][ub], kuna [`Rc`] ei kasuta aatomioperatsioone.
///
/// Tema nõbu [`sync::Arc`][arc] kasutab aatomioperatsioone (tekitades teatud üldkulusid) ja on seega `Send`.
///
/// Lisateavet leiate jaotisest [the Nomicon](../../nomicon/send-and-sync.html).
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Koostamise ajal teadaolevad konstantse suurusega tüübid.
///
/// Kõigil tüübiparameetritel on kaudne seos `Sized`.Selle sideme eemaldamiseks saab kasutada spetsiaalset süntaksit `?Sized`, kui see pole sobiv.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//tõrge: [i32]-i jaoks pole suurust rakendatud
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Erandiks on trait kaudne `Self` tüüp.
/// trait-l ei ole kaudset `Sized`-sidet, kuna see ei ühildu objektiga [trait object], kus definitsiooni järgi peab trait töötama kõigi võimalike rakendajatega ja seega võib see olla mis tahes suurusega.
///
///
/// Kuigi Rust võimaldab teil `Sized`-i trait-ga siduda, ei saa te seda hiljem trait-objekti moodustamiseks kasutada:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // olgu y: &dyn Baar= &Impl;//viga: trait `Bar`-st ei saa objekti teha
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // näiteks Default jaoks, mis nõuab, et `[T]: !Default` oleks hinnatav
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Tüübid, mis võivad olla "unsized" kuni dünaamilise suurusega tüübid.
///
/// Näiteks suurusega massiivi tüüp `[i8; 2]` rakendab `Unsize<[i8]>` ja `Unsize<dyn fmt::Debug>`.
///
/// Kõik `Unsize`-i rakendused pakub kompilaator automaatselt.
///
/// `Unsize` rakendatakse:
///
/// - `[T; N]` on `Unsize<[T]>`
/// - `T` on `Unsize<dyn Trait>`, kui `T: Trait`
/// - `Foo<..., T, ...>` on `Unsize<Foo<..., U, ...>>`, kui:
///   - `T: Unsize<U>`
///   - Foo on struktuur
///   - Ainult `Foo`-i viimasel väljal on tüüp, mis hõlmab `T`-i
///   - `T` ei kuulu teiste väljade tüüpi
///   - `Bar<T>: Unsize<Bar<U>>`, kui `Foo`-i viimasel väljal on tüüp `Bar<T>`
///
/// `Unsize` kasutatakse koos [`ops::CoerceUnsized`]-ga, et "user-defined"-i konteinerid, näiteks [`Rc`], sisaldaksid dünaamilise suurusega tüüpe.
/// Lisateavet leiate mudelitest [DST coercion RFC][RFC982] ja [the nomicon entry on coercion][nomicon-coerce].
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Mustrivastetes kasutatavate konstantide jaoks on nõutav trait.
///
/// Mis tahes tüüp, mis tuletab `PartialEq`, rakendab selle trait automaatselt, olenemata sellest, kas selle tüübi parameetrid rakendavad `Eq`-i.
///
/// Kui üksus `const` sisaldab mõnda tüüpi, mis ei rakenda seda trait-i, siis see tüüp kas (1.) ei rakenda `PartialEq`-i (mis tähendab, et konstant ei paku seda võrdlusmeetodit, mis eeldab koodi genereerimist) või (2.), mida ta rakendab * `PartialEq` versioon (mis eeldame, et see ei vasta struktuurse võrdsuse võrdlusele).
///
///
/// Mõlemas ülaltoodud stsenaariumis lükkame sellise konstandi kasutamise mustrivastes tagasi.
///
/// Vaadake ka [structural match RFC][RFC1445] ja [issue 63438], mis motiveerisid atribuutipõhiselt kujunduselt sellele trait-le üle minema.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Mustrivastetes kasutatavate konstantide jaoks on nõutav trait.
///
/// Mis tahes tüüp, mis tuletab `Eq`, rakendab selle trait automaatselt, olenemata sellest, kas selle tüübi parameetrid rakendavad `Eq`-i.
///
/// See on häkk meie tüübisüsteemi piirangute ümber töötamiseks.
///
/// # Background
///
/// Tahame nõuda, et mustrivastetes kasutatavatel konstruktsioonitüüpidel oleks atribuut `#[derive(PartialEq, Eq)]`.
///
/// Ideaalsemas maailmas saaksime seda nõuet kontrollida, kontrollides lihtsalt, kas antud tüüp rakendab nii `StructuralPartialEq` trait *kui*`Eq` trait.
/// Kuid teil võib olla ADT-sid, mis *teevad*`derive(PartialEq, Eq)`, ja see võib olla juhtum, mille soovime, et kompilaator aktsepteeriks, kuid konstandi tüüp ei suuda `Eq`-i rakendada.
///
/// Nimelt selline juhtum:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Ülaltoodud koodi probleem on see, et `Wrap<fn(&())>` ei rakenda `PartialEq` ega `Eq`, kuna "for <" a> fn(&'a _)` does not implement those traits.)
///
/// Seetõttu ei saa me tugineda `StructuralPartialEq` ja `Eq` naiivsele kontrollimisele.
///
/// Selle lahendamise häkkimisel kasutame kahte eraldi traits-i, mis on süstitud mõlemast tuletisest (`#[derive(PartialEq)]` ja `#[derive(Eq)]`), ja kontrollime, kas mõlemad on struktuurse vaste kontrollimise osana olemas.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Tüübid, mille väärtusi saab dubleerida lihtsalt bittide kopeerimisega.
///
/// Vaikimisi on muutuvatel sidemetel 'liiguta semantikat'.Teisisõnu:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` on kolinud `y`-i ja seetõttu ei saa seda kasutada
///
/// // println! ("{: ?}", x);//tõrge: teisaldatud väärtuse kasutamine
/// ```
///
/// Kuid kui tüüp rakendab `Copy`-i, on sellel selle asemel "koopia semantika":
///
/// ```
/// // Saame tuletada `Copy`-i rakenduse.
/// // `Clone` on samuti vajalik, kuna see on `Copy` supertraat.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` on `x` koopia
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Oluline on märkida, et nendes kahes näites on ainus erinevus selles, kas teil on pärast ülesannet lubatud juurdepääs `x`-ile.
/// Kapoti all võivad nii koopia kui ka käik bitti mällu kopeerida, ehkki see on mõnikord optimeeritud.
///
/// ## Kuidas saan rakendust `Copy` rakendada?
///
/// `Copy`-i juurutamiseks teie tüübil on kaks võimalust.Lihtsaim on kasutada `derive`-i:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// `Copy` ja `Clone` saate rakendada ka käsitsi.
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Nende kahe vahel on väike erinevus: `derive` strateegia paigutab tüübiparameetritele ka `Copy`-i, mis pole alati soovitud.
///
/// ## Mis vahe on `Copy` ja `Clone` vahel?
///
/// Koopiad toimuvad kaudselt, näiteks osana ülesandest `y = x`.`Copy` käitumine pole ülekoormatav;see on alati lihtne natuke tark koopia.
///
/// Kloonimine on selgesõnaline tegevus, `x.clone()`.[`Clone`] juurutamine võib pakkuda mis tahes tüübispetsiifilist käitumist, mis on vajalik väärtuste ohutuks kopeerimiseks.
/// Näiteks [`Clone`]-i rakendamine [`String`]-i jaoks peab koputama hunnikusse suunatud stringi puhvri.
/// [`String`]-i väärtuste lihtne bitipõhine koopia kopeerib lihtsalt kursori, mis toob kaasa topeltvaba joone.
/// Sel põhjusel on [`String`] [`Clone`], kuid mitte `Copy`.
///
/// [`Clone`] on `Copy` supertrait, nii et kõik, mis on `Copy`, peab rakendama ka [`Clone`].
/// Kui tüüp on `Copy`, peab selle [`Clone`]-i juurutamine tagastama ainult `*self` (vt ülaltoodud näidet).
///
/// ## Millal saab minu tüüp olla `Copy`?
///
/// Tüüp võib rakendada `Copy`-i, kui kõik selle komponendid rakendavad `Copy`-i.Näiteks võib see struktuur olla `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Struktuur võib olla `Copy` ja [`i32`] on `Copy`, seetõttu sobib `Point` olla `Copy`.
/// Seevastu kaaluge
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Struktuuriga `PointList` ei saa rakendust `Copy` rakendada, kuna [`Vec<T>`] ei ole `Copy`.Kui proovime tuletada `Copy`-i rakendust, kuvatakse tõrge:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Jagatud viited (`&T`) on ka `Copy`, nii et tüüp võib olla `Copy`, isegi kui sellel on jagatud viited tüüpidele `T`, mis pole * `Copy`.
/// Mõelge järgmisele struktuurile, millega saab rakendada `Copy`-i, kuna sellel on ülalt ainult * jagatud viide meie mitte-koopia-tüüpi `PointList`-le:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Millal *kas* ei saa minu tüüp olla `Copy`?
///
/// Mõnda tüüpi ei saa ohutult kopeerida.Näiteks `&mut T` kopeerimisel luuakse varjunimega muudetav viide.
/// [`String`] kopeerimine dubleeriks vastutuse ["String"] puhvri haldamise eest, mis tooks kaasa topelt tasuta.
///
/// Viimast juhtumit üldistades ei saa ükski tüüp, mis rakendab [`Drop`], olla `Copy`, sest see haldab mõnda ressurssi lisaks oma [`size_of::<T>`] baitidele.
///
/// Kui proovite rakendada `Copy` struktuuris või loendis, mis sisaldab mitte-koopiaandmeid, kuvatakse tõrge [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Millal *peaks* minu tüüp olema `Copy`?
///
/// Üldiselt, kui teie tüüp _can_ rakendab `Copy`-i, peaks see ka toimima.
/// Pidage siiski meeles, et `Copy`-i juurutamine on osa teie tüüpi avalikust API-st.
/// Kui tüüp võib future-s muutuda mitte-Koopiaks, võib `Copy`-i juurutamine olla mõistlik kohe ära jätta, et vältida katkematut API-muudatust.
///
/// ## Täiendavad rakendajad
///
/// Lisaks [implementors listed below][impls] rakendavad `Copy` ka järgmised tüübid:
///
/// * Funktsioonide üksuste tüübid (st iga funktsiooni jaoks määratletud erinevad tüübid)
/// * Funktsioonikursori tüübid (nt `fn() -> i32`)
/// * Massiivitüübid kõigi suuruste jaoks, kui üksuse tüüp rakendab ka `Copy` (nt `[i32; 123456]`)
/// * Tuple tüübid, kui iga komponent rakendab ka `Copy` (nt `()`, `(i32, bool)`)
/// * Sulgemistüübid, kui need ei võta keskkonnast mingit väärtust või kui kõik sellised hõivatud väärtused rakendavad `Copy`-i ise.
///   Pange tähele, et jagatud viitega hõivatud muutujad rakendavad alati `Copy`-i (isegi kui referent seda ei tee), samas kui muutuva viite abil hõivatud muutujad ei kasuta kunagi `Copy`-i.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) See võimaldab kopeerida tüüpi, mis ei rakenda `Copy`-i rahulolematute eluaegsete piirangute tõttu (`A<'_>`-i kopeerimine, kui ainult `A<'static>: Copy` ja `A<'_>: Clone`).
// Meil on see atribuut siin praegu ainult seetõttu, et `Copy`-is on üsna palju olemasolevaid spetsialiseerumisi, mis on juba standardraamatukogus olemas, ja praegu pole sellist käitumist turvaliselt võimalik.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Tuletage makro, genereerides trait `Copy` implantaadi.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Tüübid, mille jaoks on ohutu viiteid lõimete vahel jagada.
///
/// See trait rakendatakse automaatselt, kui kompilaator määrab selle sobivaks.
///
/// Täpne määratlus on: tüüp `T` on [`Sync`] ja ainult siis, kui `&T` on [`Send`].
/// Teisisõnu, kui `&T`-i viidete edastamisel lõimede vahel pole [undefined behavior][ub]-i (sealhulgas andmesõiduvõimalusi) võimalust.
///
/// Nagu arvata võib, on primitiivsed tüübid, nagu [`u8`] ja [`f64`], kõik [`Sync`], samuti on neid sisaldavad lihtsad agregaattüübid, näiteks paarid, struktuurid ja loendid.
/// Põhiliste [`Sync`] tüüpide näidete hulka kuuluvad näiteks "immutable" tüübid, nagu `&T`, ja need, millel on lihtne pärilik muutlikkus, näiteks [`Box<T>`][box], [`Vec<T>`][vec] ja enamik teisi kollektsioonitüüpe.
///
/// (Üldised parameetrid peavad olema [`Sync`], et nende konteiner oleks [" Sync`].)
///
/// Definitsiooni mõnevõrra üllatav tagajärg on see, et `&mut T` on `Sync` (kui `T` on `Sync`), kuigi tundub, et see võib pakkuda sünkroniseerimata mutatsiooni.
/// Trikk seisneb selles, et jagatud viite (st `& &mut T`) taga olev muutuv viide muutub kirjutuskaitstuks, nagu oleks see `& &T`.
/// Seega ei ole andmesõidu ohtu.
///
/// Tüübid, mis ei ole `Sync`, on tüübid, millel on "interior mutability" mitte niiditurvalises vormis, näiteks [`Cell`][cell] ja [`RefCell`][refcell].
/// Need tüübid võimaldavad nende sisu mutatsiooni isegi muutumatu, jagatud viite kaudu.
/// Näiteks `set` meetod [`Cell<T>`][cell] võtab `&self`, nii et see nõuab ainult jagatud viide [`&Cell<T>`][cell].
/// Meetod ei teosta sünkroonimist, seega ei saa [`Cell`][cell] olla `Sync`.
///
/// Teine mittesünkrooniva tüübi näide on viidete loendamise osuti [`Rc`][rc].
/// Võttes arvesse mis tahes viiteid [`&Rc<T>`][rc], saate kloonida uue [`Rc<T>`][rc], muutes võrdlusarvusid mitte aatomilisel viisil.
///
/// Juhtudel, kui on vaja niidikindlat salongi muutlikkust, pakub Rust [atomic data types]-i, samuti selgesõnalist lukustamist [`sync::Mutex`][mutex] ja [`sync::RwLock`][rwlock] kaudu.
/// Need tüübid tagavad, et ükski mutatsioon ei saa põhjustada andmesõite, seega on tüübid `Sync`.
/// Samamoodi pakub [`sync::Arc`][arc] [`Rc`][rc]-i niidikindlat analoogi.
///
/// Igasugused sisemuutlikkusega tüübid peavad value(s)-i ümber kasutama ka [`cell::UnsafeCell`][unsafecell]-i ümbrist, mida saab ühise viite kaudu muteerida.
/// Selle tegemata jätmine on [undefined behavior][ub].
/// Näiteks [`transmute`][transmute]-ing vahemikus `&T` kuni `&mut T` on vale.
///
/// `Sync`-i kohta lisateavet leiate jaotisest [the Nomicon][nomicon-send-and-sync].
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): kui tugi `rustc_on_unimplemented`-i märkmete lisamiseks maandub beetaversioonis ja seda on laiendatud, et kontrollida, kas mõni sulgemisnõue on nõudeahelas, laiendage seda sellisena (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Nullsuuruse tüübiga tähistati asju, mis neile "act like" kuuluvad `T`.
///
/// `PhantomData<T>`-i välja lisamine tüübile ütleb kompilaatorile, et teie tüüp toimib nii, nagu salvestaks see `T`-tüüpi väärtuse, kuigi see tegelikult ei ole.
/// Seda teavet kasutatakse teatud ohutusomaduste arvutamisel.
///
/// `PhantomData<T>`-i kasutamise põhjalikuma selgituse saamiseks vaadake palun [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Õudne märkus 👻👻👻
///
/// Kuigi neil mõlemal on hirmutavad nimed, on `PhantomData` ja 'fantoomitüübid' omavahel seotud, kuid mitte identsed.Fantoomtüübi parameeter on lihtsalt tüübiparameeter, mida kunagi ei kasutata.
/// Rakenduses Rust põhjustab see kompilaatori sageli kaebusi ja lahendus on lisada "dummy"-i kasutamine `PhantomData`-i abil.
///
/// # Examples
///
/// ## Kasutamata eluea parameetrid
///
/// Võib-olla on `PhantomData`-i kõige tavalisem kasutusjuht struktuur, millel on kasutamata eluea parameeter, tavaliselt mõne ebaturvalise koodi osana.
/// Näiteks on siin struktuur `Slice`, millel on kaks `*const T` tüüpi osutit, mis osutavad arvatavasti kuskile massiivi:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Eesmärk on, et alusandmed kehtivad ainult eluea `'a` kohta, seega ei tohiks `Slice` `'a`-i üle elada.
/// Koodis seda kavatsust siiski ei väljendata, kuna eluajal `'a` pole mingeid kasutusviise ja seetõttu pole selge, millistele andmetele see kehtib.
/// Saame seda parandada, käskides kompilaatoril käituda * nii, nagu oleks `Slice`-struktuuris viide `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// See nõuab omakorda ka märkust `T: 'a`, mis näitab, et `T`-s olevad viited kehtivad kogu eluea `'a` jooksul.
///
/// `Slice` initsialiseerimisel sisestate välja `phantom` jaoks lihtsalt väärtuse `PhantomData`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Kasutamata tüübi parameetrid
///
/// Mõnikord juhtub, et teil on kasutamata tüübiparameetreid, mis näitavad, mis tüüpi andmetega struktuur "tied" on, kuigi neid andmeid tegelikult struktuuris endas pole.
/// Siin on näide, kus see tekib [FFI]-iga.
/// Võõras liides kasutab `*mut ()` tüüpi käepidemeid, et viidata erinevat tüüpi Rust väärtustele.
/// Jälgime Rust tüüpi, kasutades fantoomtüübi parameetrit struktuuris `ExternalResource`, mis ümbritseb käepidet.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Omandiline kuuluvus ja kukkumiskontroll
///
/// `PhantomData<T>`-tüüpi välja lisamine näitab, et teie tüüp omab `T`-tüüpi andmeid.See omakorda tähendab, et kui teie tüüp langeb, võib see langetada ühe või mitu `T` tüüpi eksemplari.
/// See mõjutab Rust kompilaatori [drop check] analüüsi.
///
/// Kui teie struktuuril tegelikult ei ole `T` tüüpi andmeid, siis on parem kasutada viitetüüpi, näiteks `PhantomData<&'a T>` (ideally) või `PhantomData<*const T>` (kui eluiga ei kehti), et mitte näidata omandiõigust.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Koostaja-sisemine trait, mida kasutatakse loendust eristavate liikide tüübi tähistamiseks.
///
/// See trait rakendatakse automaatselt igat tüüpi ja see ei lisa [`mem::Discriminant`]-le mingeid garantiisid.
/// `DiscriminantKind::Discriminant` ja `mem::Discriminant` vahel on **määratlemata käitumine**.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Diskriminandi tüüp, mis peab vastama `mem::Discriminant`-i nõutavale trait bounds-le.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Koostaja-sisemine trait kasutatakse selleks, et teha kindlaks, kas tüüp sisaldab `UnsafeCell`-i sisemiselt, kuid mitte suuna kaudu.
///
/// See mõjutab näiteks seda, kas seda tüüpi `static` paigutatakse kirjutuskaitstud staatilisse mällu või kirjutatavasse staatilisse mällu.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Tüübid, mida saab pärast kinnitamist turvaliselt liigutada.
///
/// Rust-l endal pole mõtet kinnisvaratüüpidest ja ta peab käike (nt loovutamise või [`mem::replace`] kaudu) alati ohutuks.
///
/// Tüüpi [`Pin`][Pin] kasutatakse selle asemel, et vältida liikumist tüübisüsteemis.[`Pin<P<T>>`][Pin] ümbrisesse mähitud kursoreid `P<T>` ei saa välja viia.
/// Kinnitamise kohta leiate lisateavet [`pin` module] dokumentatsioonist.
///
/// Rakenduse `Unpin` trait rakendamine rakenduse `T` jaoks tühistab tüübi eemaldamise piirangud, mis võimaldab seejärel `T`-i [`Pin<P<T>>`][Pin]-ist välja viia selliste funktsioonidega nagu [`mem::replace`].
///
///
/// `Unpin` kinnituseta andmetel pole mingit tagajärge.
/// Eelkõige liigutab [`mem::replace`] `!Unpin`-i andmeid õnnelikult (see töötab kõigi `&mut T`-de puhul, mitte ainult siis, kui `T: Unpin`).
/// Siiski ei saa te [`mem::replace`]-i kasutada [`Pin<P<T>>`][Pin]-i sisse mähitud andmetel, kuna te ei saa selleks vajalikku `&mut T`-i ja *see* paneb selle süsteemi tööle.
///
/// Nii saab seda näiteks teha ainult tüüpide `Unpin` juurutamisel:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // `mem::replace`-i helistamiseks vajame muudetavat viidet.
/// // Sellise viite saame (implicitly)-i abil, kasutades `Pin::deref_mut`-i, kuid see on võimalik ainult seetõttu, et `String` rakendab `Unpin`-i.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Seda trait rakendatakse automaatselt peaaegu igat tüüpi.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Markeri tüüp, mis ei rakenda `Unpin`-i.
///
/// Kui tüüp sisaldab `PhantomPinned`-i, ei rakenda see `Unpin`-i vaikimisi.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// `Copy` rakendused primitiivsete tüüpide jaoks.
///
/// Rakendused, mida ei saa kirjeldada rakenduses Rust, viiakse rakenduses `traits::SelectionContext::copy_clone_conditions()` sisse versioonis `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Jagatud viiteid saab kopeerida, kuid muudetavaid viiteid *ei saa*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}