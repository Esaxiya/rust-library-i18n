//! See on sisemoodul, mida ifmt!tööaeg.Need struktuurid eraldatakse staatilistesse massiividesse, et vormindusstringid enne tähtaega kompileerida.
//!
//! Need definitsioonid on sarnased nende `ct` ekvivalentidega, kuid erinevad selle poolest, et neid saab staatiliselt eraldada ja on käituse jaoks veidi optimeeritud
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Võimalikud joondused, mida saab vormindamisdirektiivi osana taotleda.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Märge selle kohta, et sisu peaks olema vasakule joondatud.
    Left,
    /// Märge selle kohta, et sisu peaks olema joondatud paremale.
    Right,
    /// Märge selle kohta, et sisu peaks olema joondatud keskele.
    Center,
    /// Ühtlustamist ei taotletud.
    Unknown,
}

/// Kasutatakse [width](https://doc.rust-lang.org/std/fmt/#width) ja [precision](https://doc.rust-lang.org/std/fmt/#precision) spetsifikaatorite poolt.
#[derive(Copy, Clone)]
pub enum Count {
    /// Määratud tähtnumbriga, salvestab väärtuse
    Is(usize),
    /// Määratletud `$` ja `*` süntaksite abil, salvestab indeks `args`-i
    Param(usize),
    /// Täpsustamata
    Implied,
}