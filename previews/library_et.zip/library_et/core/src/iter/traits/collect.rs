/// Teisendamine [`Iterator`]-st.
///
/// Rakendades tüübile `FromIterator`, saate määratleda, kuidas see iteraatorist luuakse.
/// See on tüüpiline tüüpide puhul, mis kirjeldavad mingisugust kogu.
///
/// [`FromIterator::from_iter()`] nimetatakse selgesõnaliselt harva ja seda kasutatakse hoopis [`Iterator::collect()`]-meetodi kaudu.
///
/// Veel näiteid leiate [`Iterator::collect()`]'s dokumentatsioonist.
///
/// Vaata ka: [`IntoIterator`].
///
/// # Examples
///
/// Põhikasutus:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// [`Iterator::collect()`]-i kasutamine kaudselt `FromIterator`-i kasutamiseks:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// `FromIterator` juurutamine teie tüübile:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Proovikogu, mis on lihtsalt Veci ümbris<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Anname talle mõned meetodid, et saaksime selle luua ja sinna asju lisada.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ja juurutame FromIteratori
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Nüüd saame teha uue iteraatori ...
/// let iter = (0..5).into_iter();
///
/// // ... ja tehke sellest MyCollection
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // koguge ka teoseid!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Loob iteraatorist väärtuse.
    ///
    /// Lisateavet leiate [module-level documentation]-st.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Teisendamine [`Iterator`]-ks.
///
/// Rakendades tüübile `IntoIterator`, määrate, kuidas see teisendatakse iteraatoriks.
/// See on tüüpiline tüüpide puhul, mis kirjeldavad mingisugust kogu.
///
/// `IntoIterator`-i rakendamise üks eelis on see, et teie tüüp on [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Vaata ka: [`FromIterator`].
///
/// # Examples
///
/// Põhikasutus:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// `IntoIterator` juurutamine teie tüübile:
///
/// ```
/// // Proovikogu, mis on lihtsalt Veci ümbris<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Anname talle mõned meetodid, et saaksime selle luua ja sinna asju lisada.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ja juurutame IntoIteratori
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Nüüd saame teha uue kollektsiooni ...
/// let mut c = MyCollection::new();
///
/// // ... lisage sellele natuke asju ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... ja seejärel muutke see iteraatoriks:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// On tavaline, et `IntoIterator` kasutatakse trait bound-na.See võimaldab sisendkogumi tüüpi muuta, kui see on endiselt iteraator.
/// Täiendavaid piire saab määrata piirates
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Kordatavate elementide tüüp.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Milliseks iteraatoriks me selle muudame?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Loob väärtusest iteraatori.
    ///
    /// Lisateavet leiate [module-level documentation]-st.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Laiendage kogu iteraatori sisuga.
///
/// Iteraatorid toodavad rida väärtusi ja kogusid võib mõelda ka kui väärtuste rida.
/// `Extend` trait ületab selle tühimiku, võimaldades teil kogu laiendada, lisades selle iteraatori sisu.
/// Kollektsiooni laiendamisel juba olemasoleva võtmega värskendatakse seda kirjet või lisatakse see kirje kollektsioonide puhul, mis võimaldavad mitut võrdse võtmega sisestust.
///
///
/// # Examples
///
/// Põhikasutus:
///
/// ```
/// // Stringi saate laiendada mõne tähemärgiga:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// `Extend` juurutamine:
///
/// ```
/// // Proovikogu, mis on lihtsalt Veci ümbris<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Anname talle mõned meetodid, et saaksime selle luua ja sinna asju lisada.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // kuna MyCollectionil on i32-de loend, juurutame i32-i jaoks rakenduse Extend
/// impl Extend<i32> for MyCollection {
///
///     // Betooni tüüpi allkirjaga on see natuke lihtsam: me võime helistada laiemale kõigele, mida saab muuta iteraatoriks, mis annab meile i32-d.
///     // Sest meil on vaja MyCollectioni sisestada i32-sid.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Rakendus on väga lihtne: tehke iteraator läbi ja add() iga element endale.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // laiendame oma kollektsiooni veel kolme numbriga
/// c.extend(vec![1, 2, 3]);
///
/// // oleme need elemendid lõpuni lisanud
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Laiendab kogu iteraatori sisuga.
    ///
    /// Kuna see on selle trait jaoks ainus nõutav meetod, sisaldavad [trait-level]-i dokumendid rohkem üksikasju.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// // Stringi saate laiendada mõne tähemärgiga:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Laiendab täpselt ühe elemendiga kollektsiooni.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Reserveerib kogumahu etteantud arvu täiendavate elementide jaoks.
    ///
    /// Vaikimisi rakendamine ei tee midagi.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}