/// Iteraator, mis teab selle täpset pikkust.
///
/// Paljud [itaatorid] ei tea, mitu korda nad kordavad, kuid mõned siiski.
/// Kui iteraator teab, mitu korda ta kordab, võib sellele teabele juurdepääsu võimaldamine olla kasulik.
/// Näiteks kui tahate tagurpidi korrata, on hea algus teada, kus lõpp on.
///
/// `ExactSizeIterator`-i juurutamisel peate rakendama ka [`Iterator`]-i.
/// Seda tehes peab [`Iterator::size_hint`]*rakendamine* tagastama iteraatori täpse suuruse.
///
/// [`len`]-meetodil on vaikimisi rakendus, nii et te ei peaks seda tavaliselt rakendama.
/// Kuid võite pakkuda vaikimisi toimivamat rakendust, nii et sel juhul on selle ületamine mõttekas.
///
///
/// Pange tähele, et see trait on turvaline trait ja sellisena *ei* ega * garanteeri, et tagastatav pikkus on õige.
/// See tähendab, et `unsafe`-kood **ei tohi** tugineda [`Iterator::size_hint`]-i õigsusele.
/// Ebastabiilne ja ohutu [`TrustedLen`](super::marker::TrustedLen) trait annab sellele lisagarantii.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Põhikasutus:
///
/// ```
/// // piiratud vahemik teab täpselt, mitu korda see kordub
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// [module-level docs]-is juurutasime [`Iterator`], `Counter`.
/// Rakendame selle jaoks ka `ExactSizeIterator`:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Saame hõlpsasti arvutada järelejäänud korduste arvu.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Ja nüüd saame seda kasutada!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Tagastab iteraatori täpse pikkuse.
    ///
    /// Rakendus tagab, et iteraator tagastab enne [`None`] tagastamist täpselt `len()` rohkem kui [`Some(T)`] väärtus.
    ///
    /// Sellel meetodil on vaikimisi rakendus, nii et te ei peaks seda tavaliselt otse rakendama.
    /// Kui suudate pakkuda tõhusamat rakendamist, saate seda siiski teha.
    /// Näite leiate dokumendist [trait-level].
    ///
    /// Sellel funktsioonil on samad ohutusgarantiid kui funktsioonil [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// // piiratud vahemik teab täpselt, mitu korda see kordub
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: See väide on liiga kaitsev, kuid kontrollib invarianti
        // tagab trait.
        // Kui see trait oleks rust-sisemine, saaksime kasutada debug_assert !;assert_eq!kontrollib ka kõiki kasutaja Rust rakendusi.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Tagastab `true`, kui iteraator on tühi.
    ///
    /// Sellel meetodil on vaikerakendus, kasutades [`ExactSizeIterator::len()`]-i, nii et te ei pea seda ise rakendama.
    ///
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}