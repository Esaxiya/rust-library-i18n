/// Iteraator, mis jätkab alati kurnatuna `None`-i tootmist.
///
/// Järgmisena helistamine sulatatud iteraatoril, mis on `None` korra tagasi andnud, tagab [`None`]-i uuesti.
/// Selle trait-i peaksid rakendama kõik nii käituvad iteraatorid, kuna see võimaldab [`Iterator::fuse()`]-i optimeerida.
///
///
/// Note: Üldiselt ei tohiks te `FusedIterator`-i kasutada üldistes piirides, kui vajate sulatatud iteraatorit.
/// Selle asemel peaksite lihtsalt iteraatoril helistama [`Iterator::fuse()`]-ile.
/// Kui iteraator on juba sulatatud, on täiendav [`Fuse`]-i ümbris keelatud, ilma et see oleks karistatud.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Iteraator, mis teatab täpse pikkuse, kasutades size_hint.
///
/// Kordaja teatab suuruse vihjest, kus see on kas täpne (alumine piir on võrdne ülemise piiriga) või ülemine piir on [`None`].
///
/// Ülemine piir peab olema [`None`] ainult juhul, kui iteraatori tegelik pikkus on suurem kui [`usize::MAX`].
/// Sellisel juhul peab alumine piir olema [`usize::MAX`], mille tulemuseks on `(usize::MAX, None)` [`Iterator::size_hint()`].
///
/// Iteraator peab enne lõppu jõudmist tootma täpselt nii palju elemente, nagu ta teatas, või lahknema.
///
/// # Safety
///
/// See trait tuleb rakendada ainult siis, kui leping on täidetud.
/// Selle trait tarbijad peavad kontrollima [`Iterator::size_hint()`]’s ülemist piiri.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Iteraator, mis on elemendi andmisel võtnud selle aluseks olevast [`SourceIter`]-ist vähemalt ühe elemendi.
///
/// Helistamine mis tahes meetodile, mis edendab iteraatorit, nt
/// [`next()`] või [`try_fold()`] tagab, et iga etapi jaoks on vähemalt üks iteraatori alusallika väärtus välja viidud ja iteraatorahela tulemus võib selle asemele lisada, eeldades, et allika struktuursed piirangud võimaldavad sellist sisestamist.
///
/// Teisisõnu näitab see trait, et iteraatori torujuhtme saab oma kohale koguda.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}