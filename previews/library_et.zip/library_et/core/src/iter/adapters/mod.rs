use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// See trait tagab interaktiivse juurdepääsu interaator-adapteri torujuhtme lähtekohtadele sellistel tingimustel
/// * iteraatori allikas `S` viib `SourceIter<Source = S>` ise ellu
/// * allika ja torujuhtme vahelise torujuhtme iga adapteri jaoks on selle trait delegeeritud rakendus.
///
/// Kui allikaks on iteraatori struktuur (mida tavaliselt nimetatakse `IntoIter`), võib see olla kasulik [`FromIterator`]-i rakenduste spetsialiseerimiseks või ülejäänud elementide taastamiseks pärast iteraatori osalist ammendumist.
///
///
/// Pange tähele, et rakendused ei pea tingimata pakkuma juurdepääsu torujuhtme sisemisele allikale.Olekuline vaheadapter võib torujuhtme osa innukalt hinnata ja paljastada selle sisemälu allikana.
///
/// trait on ohtlik, kuna rakendajad peavad kaitsma täiendavaid ohutusomadusi.
/// Vaadake üksikasju [`as_inner`]-st.
///
/// # Examples
///
/// Osaliselt tarbitud allika hankimine:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Allika etapp iteraatori torujuhtmes.
    type Source: Iterator;

    /// Too iteraatori torujuhtme allikas.
    ///
    /// # Safety
    ///
    /// Rakendused peavad tagastama sama muutuva viite kogu eluea jooksul, kui helistaja neid ei asenda.
    /// Helistajad võivad viite asendada alles siis, kui nad iteratsiooni peatasid ja iteraatori torujuhtme pärast allika väljavõtmist maha pillavad.
    ///
    /// See tähendab, et iteraatoriadapterid saavad loota sellele, et allikas iteratsiooni ajal ei muutu, kuid nad ei saa sellele Drop-rakendustes tugineda.
    ///
    /// Selle meetodi rakendamine tähendab, et adapterid loobuvad ainult eraviisilisest juurdepääsust oma allikale ja saavad tugineda ainult meetodi vastuvõtjate tüüpide põhjal tehtud garantiidele.
    /// Piiratud juurdepääsu puudumine eeldab ka seda, et adapterid peavad allika avalikku API-d toetama ka siis, kui neil on juurdepääs selle sisemustele.
    ///
    /// Helistajad peavad omakorda eeldama, et allikas oleks mis tahes olekus, mis on kooskõlas tema avaliku API-ga, kuna selle ja allika vahel istuvatel adapteritel on sama juurdepääs.
    /// Eelkõige võib adapter kulutada rohkem elemente kui hädavajalik.
    ///
    /// Nende nõuete üldeesmärk on lasta tarbijal torujuhet kasutada
    /// * mis jääb allikasse pärast iteratsiooni lõppemist
    /// * mälu, mis on tarbimata iteraatori edendamisel kasutamata jäänud
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Iteraatori adapter, mis toodab väljundit seni, kuni aluseks olev iteraator toodab `Result::Ok` väärtusi.
///
///
/// Vea ilmnemisel iteraator peatub ja viga salvestatakse.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Töötage antud iteraatorit nii, nagu annaks `Result<T, _>` asemel `T`.
/// Kõik vead peatavad sisemise iteraatori ja üldine tulemus on viga.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}