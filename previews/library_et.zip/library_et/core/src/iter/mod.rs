//! Komponeeritav väline iteratsioon.
//!
//! Kui olete leidnud mingisuguse kollektsiooni ja peate selle kollektsiooni elementidega toimingu tegema, satute kiiresti 'iterators'-i.
//! Iteraate kasutatakse idiomaatilises Rust-koodis palju, seega tasub nendega tuttavaks saada.
//!
//! Enne kui selgitada rohkem, räägime sellest, kuidas see moodul on üles ehitatud:
//!
//! # Organization
//!
//! See moodul on suures osas korraldatud tüübi järgi:
//!
//! * [Traits] on põhiosa: need traits määratlevad, millised iteraatorid eksisteerivad ja mida saate nendega teha.Nende traits meetodid on väärt lisauuringuaega.
//! * [Functions] pakuvad kasulikke viise mõnede põhiliste iteraatorite loomiseks.
//! * [Structs] on sageli selle mooduli traits erinevate meetodite tagastustüübid.Tavaliselt soovite vaadata meetodit, mis loob `struct`, mitte `struct`-i ennast.
//! Lisateavet selle kohta leiate jaotisest " [Iteratori juurutamine](#juurutaja)`.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! See selleks!Süveneme iteraatoritesse.
//!
//! # Iterator
//!
//! Selle mooduli süda ja hing on [`Iterator`] trait.[`Iterator`] tuum näeb välja selline:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Iteraatoril on meetod [`next`], mis helistamisel tagastab [`Option`]<Item>".
//! [`next`] tagastab [`Some(Item)`] seni, kuni elemente on, ja kui need kõik on ammendatud, tagastab `None`, mis näitab, et iteratsioon on lõppenud.
//! Üksikud iteraatorid võivad valida iteratsiooni jätkamise ja nii võib [`next`]-i uuesti kutsumine hakata mingil hetkel lõpuks uuesti [`Some(Item)`]-i tagastama (näiteks vt [`TryIter`]).
//!
//!
//! [`Iterator`] täielik määratlus sisaldab ka mitmeid muid meetodeid, kuid need on vaikemeetodid, mis on ehitatud [`next`]-i peale ja nii saate neid tasuta.
//!
//! Iteraatorid on ka komponeeritavad ja tavaline on nende aheldamine keerukamate töötlemisvormide tegemiseks.Lisateavet leiate allpool jaotisest [Adapters](#adapters).
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Kolm iteratsiooni vormi
//!
//! Kogust iteraatorite loomiseks on kolm tavalist meetodit:
//!
//! * `iter()`, mis kordub üle `&T`.
//! * `iter_mut()`, mis kordub üle `&mut T`.
//! * `into_iter()`, mis kordub üle `T`.
//!
//! Tavalises raamatukogus võib vajadusel rakendada ühte või mitut neist kolmest.
//!
//! # Iteratori rakendamine
//!
//! Iseenda iteraatori loomine hõlmab kahte etappi: `struct`-i loomine iteraatori oleku hoidmiseks ja seejärel [`Iterator`]-i juurutamine selle `struct`-i jaoks.
//! Sellepärast on selles moodulis nii palju `struct'e: iga iteraatori ja iteraatori adapteri jaoks on üks.
//!
//! Koostame iteraatori nimega `Counter`, mis loeb vahemikust `1` kuni `5`:
//!
//! ```
//! // Esiteks:
//!
//! /// Kordaja, mis loeb ühest viieni
//! struct Counter {
//!     count: usize,
//! }
//!
//! // me tahame, et meie arv algab ühest, nii et lisame abiks new()-meetodi.
//! // See pole tingimata vajalik, kuid on mugav.
//! // Pange tähele, et alustame `count`-i nullist, näeme, miks `next()`'s-i juurutamisel allpool.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Seejärel juurutame oma `Counter`-i jaoks `Iterator`:
//!
//! impl Iterator for Counter {
//!     // me loeme koos usize'iga
//!     type Item = usize;
//!
//!     // next() on ainus nõutav meetod
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Suurendage meie arvu.Seetõttu alustasime nullist.
//!         self.count += 1;
//!
//!         // Kontrollige, kas oleme loendamise lõpetanud või mitte.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Ja nüüd saame seda kasutada!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Sellisel viisil [`next`]-ile helistamine muutub korduvaks.Rust-l on konstruktsioon, mis võib teie iteraatoril helistada [`next`]-le, kuni see jõuab `None`-ni.Läheme sellest järgmisena üle.
//!
//! Pange tähele ka seda, et `Iterator` pakub vaikimisi selliste meetodite nagu `nth` ja `fold` rakendust, mis kutsuvad `next`-i sisemiselt.
//! Siiski on võimalik kirjutada ka meetodite `nth` ja `fold` kohandatud teostus, kui iteraator suudab neid `next`-i helistamata tõhusamalt arvutada.
//!
//! # `for` silmuseid ja `IntoIterator`
//!
//! Rust-i `for`-silmuse süntaks on iteraatorite jaoks tegelikult suhkur.Siin on `for` põhinäide:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! See prindib numbrid üks kuni viis, igaüks oma rida.Kuid märkate siin midagi: me ei ole kunagi oma vector-il iteratori loomiseks midagi helistanud.Mis annab?
//!
//! Midagi iteraatoriks teisendamiseks on tavaraamatukogus trait: [`IntoIterator`].
//! Sellel trait-l on üks meetod [`into_iter`], mis muudab [`IntoIterator`]-i rakendava asja iteraatoriks.
//! Vaatame uuesti seda `for`-i silmust ja seda, milliseks kompilaator selle teisendab:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-suhkrutab seda:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Kõigepealt kutsume väärtust `into_iter()`.Seejärel sobitame tagasi naasva iteraatori abil, kutsudes [`next`]-i ikka ja jälle, kuni näeme `None`-i.
//! Sel hetkel oleme `break` silmusest väljas ja oleme iteratsiooni teinud.
//!
//! Siin on veel üks peenike bitt: standardne teek sisaldab huvitavat rakendust [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Teisisõnu, kõik [`Iterator`i] rakendavad [`IntoIterator`]-i lihtsalt ise tagasi tulles.See tähendab kahte asja:
//!
//! 1. Kui kirjutate [`Iterator`]-i, saate seda kasutada `for`-silmusega.
//! 2. Kui loote kollektsiooni, võimaldab [`IntoIterator`]-i juurutamine sellele kollektsiooni kasutada `for`-silmusega.
//!
//! # Korduv viitega
//!
//! Kuna [`into_iter()`] võtab `self`-i väärtuse järgi, siis kogu kogu kordamiseks `for`-tsükli kasutamine kulutab selle kogu.Sageli võite soovida kollektsiooni kordada ilma seda tarbimata.
//! Paljud kollektsioonid pakuvad meetodeid, mis pakuvad iteraatoreid üle viidete, tavaliselt vastavalt `iter()` ja `iter_mut()`:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` kuulub endiselt sellele funktsioonile.
//! ```
//!
//! Kui kollektsiooni tüüp `C` pakub `iter()`-i, rakendab see tavaliselt ka `IntoIterator`-i `&C`-i jaoks koos rakendusega, mis lihtsalt kutsub `iter()`-i.
//! Samamoodi rakendab kogu `C`, mis annab `iter_mut()`, `IntoIterator` `&mut C` jaoks, delegeerides `iter_mut()`-le.See võimaldab mugavat stenogrammi:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // sama mis `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // sama mis `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Kuigi paljud kollektsioonid pakuvad `iter()`-i, ei paku kõik `iter_mut()`-i.
//! Näiteks võib [`HashSet<T>`] või [`HashMap<K, V>`] võtmete mutatsioon viia kollektsiooni ebaühtlasesse olekusse, kui võtme räsid muutuvad, nii et need kollektsioonid pakuvad ainult `iter()`-i.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Funktsioonid, mis võtavad [`Iterator`] ja tagastavad teise [`Iterator`], nimetatakse sageli iteraatori adapteriteks, kuna need on adapteri vormid
//! pattern'.
//!
//! Tavaliste iteraatoriadapterite hulka kuuluvad [`map`], [`take`] ja [`filter`].
//! Lisateavet leiate nende dokumentatsioonist.
//!
//! Kui iteraatoriadapter panics, on iteraator täpsustamata (kuid mälusäästlik) olekus.
//! Samuti ei garanteeri see olek Rust kõigi versioonide puhul samaks jäämist, seega peaksite vältima paanikasse sattunud iteraatori tagastatud täpseid väärtusi.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iteraatorid (ja iteraator [adapters](#adapters)) on *laisad*. See tähendab, et lihtsalt iteraatori loomine ei tähenda _do_-i palju. Midagi ei juhtu enne, kui helistate [`next`]-ile.
//! Iteraatori loomisel ainult selle kõrvaltoimete tõttu tekitab see mõnikord segadust.
//! Näiteks kutsub meetod [`map`] sulgema kõik elemendid, mida see kordab:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! See ei prindi ühtegi väärtust, kuna me lõime selle asemel ainult iteraatori.Koostaja hoiatab meid sellise käitumise eest:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Idioomaatne viis [`map`] selle kõrvaltoimete jaoks kirjutada on kasutada `for`-silmust või kutsuda meetodit [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Teine levinud viis iteraatori hindamiseks on uue kollektsiooni tootmiseks [`collect`]-meetodi kasutamine.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iteraatorid ei pea olema lõplikud.Näiteks on avatud vahemik lõpmatu kordaja:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Lõputu iteraatori lõplikuks muutmiseks on tavaline kasutada iteraatori adapterit [`take`]:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! See prindib numbrid `0` kuni `4`, igaüks oma reale.
//!
//! Pidage meeles, et lõpmatute iteraatorite meetodid, isegi need, mille tulemust saab lõpliku ajaga matemaatiliselt määrata, ei pruugi lõppeda.
//! Täpsemalt, sellised meetodid nagu [`min`], mis üldjuhul nõuavad iteraatori kõigi elementide läbimist, ei pruugi ühegi lõpmatu iteraatori korral edukalt naasta.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh ei!Lõputu silmus!
//! // `ones.min()` põhjustab lõpmatu tsükli, nii et me ei jõua sellesse punkti!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;