use crate::iter::{FusedIterator, TrustedLen};

/// Loob iteraatori, mis genereerib laiskalt väärtuse täpselt üks kord, viidates pakutavale sulgemisele.
///
/// Seda kasutatakse tavaliselt ühe väärtuse generaatori kohandamiseks muud tüüpi iteratsioonide [`chain()`]-ga.
/// Võib-olla on teil iteraator, mis hõlmab peaaegu kõike, kuid vajate täiendavat erijuhtumit.
/// Võib-olla on teil funktsioon, mis töötab iteraatoritel, kuid peate töötlema ainult ühe väärtuse.
///
/// Erinevalt [`once()`]-st genereerib see funktsioon nõudmisel väärtust laisalt.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Põhikasutus:
///
/// ```
/// use std::iter;
///
/// // üks on kõige üksildasem number
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // ainult üks, see on kõik, mis me saame
/// assert_eq!(None, one.next());
/// ```
///
/// Aheldamine koos teise iteraatoriga.
/// Oletame, et tahame kordada `.foo` kataloogi iga faili, aga ka konfiguratsioonifaili,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // peame teisendama DirEntry-s iteraatorist PathBufsi iteraatoriks, seega kasutame kaarti
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // nüüd on meie iteraator ainult meie konfiguratsioonifaili jaoks
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // aheldage kaks iteraatorit kokku üheks suureks iteraatoriks
/// let files = dirs.chain(config);
///
/// // see annab meile kõik failid failis .foo ja .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Iteraator, mis annab üksiku tüübi `A`, rakendades kaasasolevat sulgurit `F: FnOnce() -> A`.
///
///
/// Selle `struct` on loodud funktsiooniga [`once_with()`].
/// Lisateavet leiate selle dokumentatsioonist.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}