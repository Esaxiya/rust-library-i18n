use crate::{fmt, iter::FusedIterator};

/// Loob uue iteraatori, kus iga järgnev üksus arvutatakse eelneva põhjal.
///
/// Iteraator algab antud esimese elemendiga (kui see on olemas) ja kutsub iga üksuse järglase arvutamiseks antud `FnMut(&T) -> Option<T>`-i sulgema.
///
///
/// ```
/// use std::iter::successors;
///
/// let powers_of_10 = successors(Some(1_u16), |n| n.checked_mul(10));
/// assert_eq!(powers_of_10.collect::<Vec<_>>(), &[1, 10, 100, 1_000, 10_000]);
/// ```
#[stable(feature = "iter_successors", since = "1.34.0")]
pub fn successors<T, F>(first: Option<T>, succ: F) -> Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    // Kui see funktsioon tagastas `impl Iterator<Item=T>`, võib see põhineda `unfold`-il ja ei vaja spetsiaalset tüüpi.
    //
    // Kuid nimega `Successors<T, F>` tüüp võimaldab sellel olla `Clone`, kui `T` ja `F` on.
    Successors { next: first, succ }
}

/// Uus iteraator, kus iga järgnev üksus arvutatakse eelneva põhjal.
///
/// Selle `struct` on loodud funktsiooniga [`iter::successors()`].
/// Lisateavet leiate selle dokumentatsioonist.
///
/// [`iter::successors()`]: successors
#[derive(Clone)]
#[stable(feature = "iter_successors", since = "1.34.0")]
pub struct Successors<T, F> {
    next: Option<T>,
    succ: F,
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> Iterator for Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        let item = self.next.take()?;
        self.next = (self.succ)(&item);
        Some(item)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.next.is_some() { (1, None) } else { (0, Some(0)) }
    }
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> FusedIterator for Successors<T, F> where F: FnMut(&T) -> Option<T> {}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T: fmt::Debug, F> fmt::Debug for Successors<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Successors").field("next", &self.next).finish()
    }
}