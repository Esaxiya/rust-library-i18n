use crate::iter::{FusedIterator, TrustedLen};

/// Loob uue iteraatori, mis kordab lõputult tüüpi `A` elemente, rakendades selleks ettenähtud sulgurit, repiiterit, `F: FnMut() -> A`.
///
/// Funktsioon `repeat_with()` kutsub kordurit uuesti ja uuesti.
///
/// Lõpmatuid iteraatoreid, nagu `repeat_with()`, kasutatakse sageli koos adapteritega nagu [`Iterator::take()`], et muuta need lõplikuks.
///
/// Kui vajaliku iteraatori elemenditüüp rakendab [`Clone`]-i ja lähtekomponendi säilitamine mälus on OK, peaksite selle asemel kasutama funktsiooni [`repeat()`].
///
///
/// `repeat_with()` toodetud iteraator ei ole [`DoubleEndedIterator`].
/// Kui vajate [`DoubleEndedIterator`]-i tagastamiseks `repeat_with()`-i, avage palun GitHubi probleem, milles selgitatakse teie kasutust.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Põhikasutus:
///
/// ```
/// use std::iter;
///
/// // Oletame, et meil on mingi tüübi väärtus, mis ei ole `Clone` või mis ei soovi veel mällu jääda, kuna see on kallis:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // kindel väärtus igavesti:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Mutatsiooni kasutamine ja lõplikuks liikumine:
///
/// ```rust
/// use std::iter;
///
/// // Nullist kuni kahe kolmanda astmeni:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... ja nüüd oleme valmis
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Iteraator, mis kordab lõputult tüüpi `A` elemente, rakendades kaasasolevat sulgurit `F: FnMut() -> A`.
///
///
/// Selle `struct` on loodud funktsiooniga [`repeat_with()`].
/// Lisateavet leiate selle dokumentatsioonist.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}