use crate::iter::{FusedIterator, TrustedLen};

/// Loob uue iteraatori, mis kordab lõputult ühte elementi.
///
/// Funktsioon `repeat()` kordab ühte väärtust ikka ja jälle.
///
/// Lõpmatuid iteraatoreid, nagu `repeat()`, kasutatakse sageli koos adapteritega nagu [`Iterator::take()`], et muuta need lõplikuks.
///
/// Kui vajaliku iteraatori elemenditüüp ei rakenda `Clone` või kui te ei soovi korduvat elementi mälus hoida, võite selle asemel kasutada funktsiooni [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Põhikasutus:
///
/// ```
/// use std::iter;
///
/// // number neli 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // jah, ikka neli
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// [`Iterator::take()`]-iga lõplikuks muutumine:
///
/// ```
/// use std::iter;
///
/// // see viimane näide oli liiga palju nelja.Olgu meil ainult neli nelja.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... ja nüüd oleme valmis
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Iteraator, mis kordab elementi lõputult.
///
/// Selle `struct` on loodud funktsiooniga [`repeat()`].Lisateavet leiate selle dokumentatsioonist.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}