use crate::iter::{FusedIterator, TrustedLen};

/// Loob iteraatori, mis annab elemendi täpselt üks kord.
///
/// Seda kasutatakse tavaliselt ühe väärtuse kohandamiseks muud tüüpi iteratsioonide [`chain()`]-ga.
/// Võib-olla on teil iteraator, mis hõlmab peaaegu kõike, kuid vajate täiendavat erijuhtumit.
/// Võib-olla on teil funktsioon, mis töötab iteraatoritel, kuid peate töötlema ainult ühe väärtuse.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Põhikasutus:
///
/// ```
/// use std::iter;
///
/// // üks on kõige üksildasem number
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // ainult üks, see on kõik, mis me saame
/// assert_eq!(None, one.next());
/// ```
///
/// Aheldamine koos teise iteraatoriga.
/// Oletame, et tahame kordada `.foo` kataloogi iga faili, aga ka konfiguratsioonifaili,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // peame teisendama DirEntry-s iteraatorist PathBufsi iteraatoriks, seega kasutame kaarti
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // nüüd on meie iteraator ainult meie konfiguratsioonifaili jaoks
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // aheldage kaks iteraatorit kokku üheks suureks iteraatoriks
/// let files = dirs.chain(config);
///
/// // see annab meile kõik failid failis .foo ja .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Iteraator, mis annab elemendi täpselt üks kord.
///
/// Selle `struct` on loodud funktsiooniga [`once()`].Lisateavet leiate selle dokumentatsioonist.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}