//! Traits tüüpide vaheliste konversioonide jaoks.
//!
//! Selle mooduli traits pakub viisi ühest tüübist teiseks teisendamiseks.
//! Igal trait-l on erinev eesmärk:
//!
//! - Odavate viite-viite konversioonide jaoks rakendage [`AsRef`] trait
//! - Odavate muutuvate-muutuvate-teisenduste jaoks rakendage [`AsMut`] trait
//! - Väärtus-väärtus-konversioonide tarbimiseks juurutage [`From`] trait
//! - Rakendage [`Into`] trait väärtus-väärtus-konversioonide tarbimiseks tüüpidest väljaspool praegust crate
//! - [`TryFrom`] ja [`TryInto`] traits käituvad nagu [`From`] ja [`Into`], kuid need tuleks rakendada siis, kui teisendamine võib ebaõnnestuda.
//!
//! Selle mooduli traits-d kasutatakse üldiste funktsioonide jaoks sageli kui trait bounds, nii et mitut tüüpi argumentidele toetatakse.Näidete saamiseks vaadake iga trait dokumentatsiooni.
//!
//! Teegi autorina peaksite alati eelistama [`From<T>`][`From`] või [`TryFrom<T>`][`TryFrom`] rakendamist, mitte [`Into<U>`][`Into`] või [`TryInto<U>`][`TryInto`], kuna [`From`] ja [`TryFrom`] pakuvad suuremat paindlikkust ja pakuvad samaväärseid rakendusi [`Into`] või [`TryInto`] tänu standardraamatukogu üldisele rakendusele.
//! Rust 1.41-le varasema versiooni sihtimisel võib olla vajalik rakendada [`Into`] või [`TryInto`] otse, kui teisendatakse tüübist väljaspool praegust crate-i.
//!
//! # Üldised rakendused
//!
//! - [`AsRef`] ja [`AsMut`] automaatne dereferents, kui sisetüüp on viide
//! - [<U>T From '] tähendab [[Into]]</u><T><U>U jaoks</u>
//! - [`TryFrom`]`tähistab <U>T jaoks`[TryInto`] '</u><T><U>U jaoks</u>
//! - [`From`] ja [`Into`] on refleksiivsed, mis tähendab, et kõik tüübid saavad `into` ise ja `from` ise
//!
//! Kasutamisnäiteid leiate igast trait-st.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Identiteedifunktsioon.
///
/// Selle funktsiooni puhul on oluline märkida kahte asja:
///
/// - See ei ole alati samaväärne sulgemisega nagu `|x| x`, kuna sulgur võib sundida `x`-i teist tüüpi.
///
/// - See liigutab funktsioonile edastatud sisendi `x`.
///
/// Kuigi võib tunduda kummaline funktsioon, mis lihtsalt tagastab sisendi, on siiski mõned huvitavad kasutusalad.
///
///
/// # Examples
///
/// `identity`-i kasutamine muude huvitavate funktsioonide järjestuses mitte millegi tegemiseks:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Teeskleme, et ühe lisamine on huvitav funktsioon.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// `identity` kasutamine "do nothing" baasjuhtumina tingimusel:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Tehke veel huvitavat ...
///
/// let _results = do_stuff(42);
/// ```
///
/// `identity` kasutamine `Option<T>` iteraatori `Some` variantide säilitamiseks:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Kasutatakse odava võrdlus-viide teisenduse tegemiseks.
///
/// See trait on sarnane [`AsMut`]-ga, mida kasutatakse muutuvate viidete vahel teisendamiseks.
/// Kui peate tegema kuluka konversiooni, on parem rakendada [`From`] tüüpi `&T` või kirjutada kohandatud funktsioon.
///
/// `AsRef` on sama allkirjaga kui [`Borrow`], kuid [`Borrow`] on erinev mõnes aspektis:
///
/// - Erinevalt `AsRef`-st on [`Borrow`]-l kõigi `T`-de jaoks mõeldud implikatsioon ja seda saab kasutada kas viite või väärtuse aktsepteerimiseks.
/// - [`Borrow`] nõuab ka, et laenuväärtuse [`Hash`], [`Eq`] ja [`Ord`] väärtused oleksid samaväärsed omandiväärtusega.
/// Sel põhjusel, kui soovite laenata ainult ühte struktuuri välja, võite rakendada `AsRef`, kuid mitte [`Borrow`].
///
/// **Note: See trait ei tohi ebaõnnestuda **.Kui teisendamine võib ebaõnnestuda, kasutage spetsiaalset meetodit, mis tagastab [`Option<T>`] või [`Result<T, E>`].
///
/// # Üldised rakendused
///
/// - `AsRef` automaatsed viited, kui sisemine tüüp on viide või muudetav viide (nt: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Kasutades trait bounds, võime aktsepteerida erinevat tüüpi argumente, kui neid saab teisendada määratud tüübiks `T`.
///
/// Näiteks: luues üldise funktsiooni, mis võtab `AsRef<str>`, väljendame, et tahame argumendina aktsepteerida kõiki viiteid, mida saab [`&str`]-ks teisendada.
/// Kuna nii [`String`] kui ka [`&str`] rakendavad `AsRef<str>`-i, võime mõlemad nõustuda sisendargumendina.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Teostab teisenduse.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Kasutatakse odava muutuva-muutuva võrdluskonversiooni tegemiseks.
///
/// See trait on sarnane [`AsRef`]-ga, kuid seda kasutatakse muutuvate viidete vahel teisendamiseks.
/// Kui peate tegema kuluka konversiooni, on parem rakendada [`From`] tüüpi `&mut T` või kirjutada kohandatud funktsioon.
///
/// **Note: See trait ei tohi ebaõnnestuda **.Kui teisendamine võib ebaõnnestuda, kasutage spetsiaalset meetodit, mis tagastab [`Option<T>`] või [`Result<T, E>`].
///
/// # Üldised rakendused
///
/// - `AsMut` autodereferentsid, kui sisemine tüüp on muudetav viide (nt: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Kasutades `AsMut`-d kui üldist funktsiooni trait bound, võime aktsepteerida kõiki muudetavaid viiteid, mida saab teisendada tüübiks `&mut T`.
/// Kuna [`Box<T>`] rakendab `AsMut<T>`, saame kirjutada funktsiooni `add_one`, mis võtab kõik argumendid, mida saab teisendada `&mut u64`-iks.
/// Kuna [`Box<T>`] rakendab `AsMut<T>`-i, aktsepteerib `add_one` ka `&mut Box<u64>`-tüüpi argumente:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Teostab teisenduse.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Väärtusest väärtuseks teisendamine, mis kulutab sisendväärtust.[`From`] vastand.
///
/// Tuleks vältida [`Into`] juurutamist ja selle asemel rakendada [`From`].
/// Rakenduse [`From`] juurutamine annab ühele automaatselt rakenduse [`Into`] tänu üldisele rakendusele standardraamatukogus.
///
/// Eelistage trait bounds määramisel üldfunktsioonile [`Into`] asemel [`From`], et saaksite kasutada ka tüüpe, mis rakendavad ainult [`Into`].
///
/// **Note: See trait ei tohi ebaõnnestuda **.Kui teisendamine võib ebaõnnestuda, kasutage [`TryInto`]-i.
///
/// # Üldised rakendused
///
/// - ["Alates"]<T>U jaoks tähendab `Into<U> for T`
/// - [`Into`] on refleksiivne, mis tähendab, et `Into<T> for T` on rakendatud
///
/// # Rakenduse [`Into`] juurutamine välist tüüpi konversioonide jaoks Rust vanades versioonides
///
/// Kui enne Rust 1.41-i ei olnud sihtkoha tüüp praeguse crate-i osa, ei saanud te [`From`]-i otse rakendada.
/// Võtke näiteks see kood:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Seda ei saa keele vanemates versioonides kompileerida, sest Rust harvaesinemise reeglid olid varem veidi rangemad.
/// Selle möödarääkimiseks võite rakenduse [`Into`] otse rakendada:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Oluline on mõista, et [`Into`] ei paku [`From`]-i rakendust (nagu [`From`] teeb koos [`Into`]-iga).
/// Seetõttu peate alati proovima [`From`]-i juurutada ja seejärel [`Into`]-i tagasi minna, kui [`From`]-i ei saa rakendada.
///
/// # Examples
///
/// [`String`] rakendab ["Into"] "<" ["Vec"] <"[" u8 "] >> >>:
///
/// Selleks, et väljendada, et me tahame, et üldine funktsioon võtaks kõik argumendid, mida saab teisendada määratud tüüpi `T`, võime kasutada väärtust trait bound väärtusest [Into]]<T>".
///
/// Näiteks: funktsioon `is_hello` võtab kõik argumendid, mida saab teisendada tähte ["Vec"] <"[" u8 "]">.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Teostab teisenduse.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Kasutatakse väärtus-väärtus-konversioonide tegemiseks sisendväärtust tarbides.See on [`Into`] vastastikune väärtus.
///
/// Alati tuleks eelistada `From`-i rakendamist [`Into`]-i asemel, sest `From`-i juurutamine tagab tänu standardraamatukogu üldisele rakendusele [`Into`]-i rakendamise automaatselt.
///
///
/// Rakendage [`Into`] ainult siis, kui sihtite versiooni, mis on varasem kui Rust 1.41, ja teisendatakse tüübiks, mis jääb väljapoole praegust crate.
/// `From` ei suutnud seda tüüpi teisendusi varasemates versioonides Rust orvureeglite tõttu teha.
/// Lisateavet leiate jaotisest [`Into`].
///
/// Eelistage trait bounds määramisel üldfunktsioonil [`Into`] asemel `From`.
/// Nii saab argumentidena kasutada ka tüüpe, mis rakendavad otseselt [`Into`]-i.
///
/// `From` on väga kasulik ka vigade käsitlemisel.Ebaõnnestumisvõimelise funktsiooni ehitamisel on tagastuse tüüp tavaliselt vormis `Result<T, E>`.
/// `From` trait lihtsustab tõrkeotsingut, võimaldades funktsioonil tagastada üks veatüüp, mis kapseldab mitu veatüüpi.Lisateavet leiate jaotisest "Examples" ja [the book][book].
///
/// **Note: See trait ei tohi ebaõnnestuda **.Kui teisendamine võib ebaõnnestuda, kasutage [`TryFrom`]-i.
///
/// # Üldised rakendused
///
/// - `From<T> for U` tähendab <U>T jaoks</u> [[sisse]]
/// - `From` on refleksiivne, mis tähendab, et `From<T> for T` on rakendatud
///
/// # Examples
///
/// [`String`] rakendab `From<&str>`:
///
/// Selgesõnaline teisendamine `&str`-st stringiks toimub järgmiselt:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Veakäsitluse ajal on sageli kasulik rakendada `From` oma veatüübi jaoks.
/// Teisendades aluseks olevad veatüübid omaenda kohandatud veatüübiks, mis kapseldab aluseks oleva veatüübi, võime tagastada ühe veatüübi, kaotamata teavet selle põhjuse kohta.
/// Operaator '?' teisendab aluseks oleva veatüübi automaatselt meie kohandatud veatüübiks, helistades `Into<CliError>::into`-ile, mis antakse automaatselt `From`-i juurutamisel.
/// Seejärel järeldab kompilaator, millist `Into` rakendust tuleks kasutada.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Teostab teisenduse.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Teisenduskatse, mis tarbib `self`-i, mis võib olla kallis või mitte.
///
/// Raamatukogu autorid ei peaks seda trait tavaliselt otseselt rakendama, vaid peaksid eelistama [`TryFrom`] trait juurutamist, mis pakub suuremat paindlikkust ja pakub samaväärset `TryInto`-i rakendust tasuta tänu standardraamatukogu üldisele rakendusele.
/// Selle kohta lisateabe saamiseks vaadake [`Into`] dokumentatsiooni.
///
/// # Rakendamine `TryInto`
///
/// See kannab samu piiranguid ja põhjendusi kui [`Into`]-i rakendamine, vt üksikasju seal.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Konversioonivea korral tagastatud tüüp.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Teostab teisenduse.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Lihtsad ja ohutud tüüpi teisendused, mis võivad teatud tingimustel kontrollitult ebaõnnestuda.See on [`TryInto`] vastastikune väärtus.
///
/// See on kasulik, kui teete tüüpi teisendamist, mis võib ebaoluliselt õnnestuda, kuid võib vajada ka erikäsitlust.
/// Näiteks pole [`i64`]-i [`i64`]-ks teisendamist [`From`] trait-i abil, kuna [`i64`] võib sisaldada väärtust, mida [`i32`] ei saa kujutada, ja nii kaotaks teisendamine andmed.
///
/// Seda võidakse lahendada [`i64`] kärpimisega [`i32`]-ks (andes [i64 "] väärtuse mooduli [`i32::MAX`]) või lihtsalt tagastades [`i32::MAX`] või mõne muu meetodi abil.
/// [`From`] trait on mõeldud täiuslikuks teisendamiseks, nii et `TryFrom` trait teavitab programmeerijat, kui tüübi teisendamine võib halvaks minna, ja laseb neil otsustada, kuidas seda käsitseda.
///
/// # Üldised rakendused
///
/// - `TryFrom<T> for U` tähendab ["TryInto"] "<U>T</u>" <U>jaoks</u>
/// - [`try_from`] on refleksiivne, mis tähendab, et `TryFrom<T> for T` on rakendatud ja ei saa ebaõnnestuda-seotud `Error`-tüüp `T::try_from()`-i helistamiseks `T`-tüüpi väärtusel on [`Infallible`].
/// Kui tüüp [`!`] on stabiliseeritud, on [`Infallible`] ja [`!`] samaväärsed.
///
/// `TryFrom<T>` saab rakendada järgmiselt:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Nagu kirjeldatud, rakendab [`i32`] rakendust TryFrom <"[" i64`]">:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Kärbib vaikselt `big_number`-i, nõuab fakti tuvastamist ja käsitsemist pärast seda.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Tagastab vea, kuna `big_number` on `i32`-i mahtumiseks liiga suur.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Tagastab `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Konversioonivea korral tagastatud tüüp.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Teostab teisenduse.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// ÜLDISED MÕJUD
////////////////////////////////////////////////////////////////////////////////

// Kui tõstetakse üle&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Tõstetuna üle &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): asendage ülaltoodud implantaadid&/&mutiga järgmise üldisemaga:
// // Derefi kohal tõstetuna
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Suurus> AsRef <U>for D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut tõstab üle &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): asendage ülaltoodud implantaat &mut-i jaoks järgmise üldisemaga:
// // AsMut tõstab DerefMuti kohale
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Suurus> AsMut seadmele <U>D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Alates eeldab Into
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// From (ja seega Into) on refleksiivne
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Märkus stabiilsuse kohta:** Seda implikatsiooni pole veel olemas, kuid "reserving space" lisab selle future-i.
/// Vaadake üksikasju [rust-lang/rust#64715][#64715]-st.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): tee selle asemel põhimõtteline parandus.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom tähendab TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Eksimatud konversioonid on semantiliselt samaväärsed asustamata veatüübiga varjatud konversioonidega.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// BETOONID IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// VIGA VIGA TÜÜP
////////////////////////////////////////////////////////////////////////////////

/// Veatüüp vigadele, mida ei saa kunagi juhtuda.
///
/// Kuna sellel loendil pole ühtegi varianti, ei saa seda tüüpi väärtust kunagi tegelikult olemas olla.
/// See võib olla kasulik üldiste API-de jaoks, mis kasutavad [`Result`]-i ja parameetriseerivad veatüüpi, et näidata, et tulemus on alati [`Ok`].
///
/// Näiteks [`TryFrom`] trait-l (teisendusel, mis tagastab [`Result`]) on üldine rakendus kõigi tüüpide jaoks, kus on olemas vastupidine [`Into`]-i rakendus.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future ühilduvus
///
/// Sellel loendil on sama roll kui [the `!`“never”type][never]-il, mis on Rust selles versioonis ebastabiilne.
/// Kui `!` on stabiliseerunud, kavatseme `Infallible`-i sellele tüübinimega teha:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... ja lõpuks kaotab `Infallible`-i.
///
/// Siiski on üks juhtum, kus `!`-i süntaksit saab kasutada enne, kui `!` on täieõigusliku tüübina stabiliseeritud: funktsiooni tagasituleku tüübi asendis.
/// Täpsemalt on võimalik rakendada kahte erinevat funktsioonikursoritüüpi:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Kui `Infallible` on loend, on see kood kehtiv.
/// Kui aga `Infallible`-st saab never type varjunimi, hakkavad need kaks implikatsiooni kattuma ja keelatakse seetõttu keele trait sidususe reeglitega.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}