#![stable(feature = "core_hint", since = "1.27.0")]

//! Näpunäited kompilaatorile, mis mõjutab koodi väljastamise või optimeerimise viisi.
//! Vihjed võivad olla kompileerimise aeg või käitamisaeg.

use crate::intrinsics;

/// Teavitab koostajat, et see punkt koodis pole kättesaadav, võimaldades edasist optimeerimist.
///
/// # Safety
///
/// Selle funktsioonini jõudmine on täiesti *määratlemata käitumine*(UB).Eelkõige eeldab kompilaator, et kõiki UB-sid ei tohi kunagi juhtuda, ja seetõttu kõrvaldab kõik harud, mis jõuavad `unreachable_unchecked()`-i kõneni.
///
/// Nagu kõik UB eksemplarid, ka juhul, kui see oletus osutub valeks, st `unreachable_unchecked()`-i kõne on kõigi võimalike juhtimisvoogude seas tegelikult kättesaadav, rakendab kompilaator valet optimeerimisstrateegiat ja võib mõnikord isegi näiliselt mitteseotud koodi rikkuda, mis põhjustab silumiseks probleemid.
///
///
/// Kasutage seda funktsiooni ainult siis, kui suudate tõestada, et kood seda kunagi ei kutsu.
/// Vastasel juhul kaaluge makro [`unreachable!`] kasutamist, mis ei võimalda optimeerimist, kuid täidab panic.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` on alati positiivne (mitte null), seega ei tagasta `checked_div` kunagi `None`-i.
/////
///     // Seetõttu on teine branch kättesaamatu.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // OHUTUS: `intrinsics::unreachable`-i ohutusleping peab olema
    // helistaja peab kinnitama.
    unsafe { intrinsics::unreachable() }
}

/// Annab masinjuhise, et anda protsessorile märku, et see töötab hõivatud ootamise tsüklis ("spin lock").
///
/// Spinn-loop signaali vastuvõtmisel saab protsessor oma käitumist optimeerida näiteks energiat säästes või hyper-lõime vahetades.
///
/// See funktsioon erineb [`thread::yield_now`]-st, mis annab otse süsteemi ajastajale, samas kui `spin_loop` ei suhtle operatsioonisüsteemiga.
///
/// `spin_loop`-i tavaliseks kasutamiseks on piiratud optimistliku pöörlemise rakendamine sünkroonimisprimitiivides CAS-i silmus.
/// Selliste probleemide vältimiseks nagu prioriteedi inversioon, on tungivalt soovitatav lõpetada tsükkel pärast piiratud hulga kordusi ja teha sobiv blokeeriv syskõne.
///
///
/// **Märkus**. Platvormidel, mis ei toeta spin-loopi vihjeid, ei tee see funktsioon üldse midagi.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Jagatud aatomväärtus, mida lõimed koordineerimiseks kasutavad
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Taustahelas määrame lõpuks väärtuse
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Tehke natuke tööd, seejärel tehke väärtus elavaks
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Tagasi oma praeguse lõime juurde ootame väärtuse määramist
/// while !live.load(Ordering::Acquire) {
///     // Spinn loop on vihje protsessorile, mida me ootame, kuid tõenäoliselt mitte väga kaua
/////
///     hint::spin_loop();
/// }
///
/// // Nüüd on väärtus seatud
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // OHUTUS: `cfg` attr tagab, et me täidame seda ainult x86 sihtmärkidel.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // OHUTUS: `cfg` attr tagab, et me täidame seda ainult x86_64 sihtmärkidel.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // OHUTUS: `cfg` attr tagab, et me täidame seda ainult aarch64 sihtmärkidel.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // OHUTUS: `cfg` attr tagab, et me täidame seda ainult käe sihtmärkidel
            // v6 funktsiooni toega.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Identiteedifunktsioon, mis *__ vihjab __* kompilaatorile, et olla maksimaalselt pessimistlik selles osas, mida `black_box` saaks teha.
///
/// Erinevalt [`std::convert::identity`]-st soovitatakse Rust kompilaatoril eeldada, et `black_box` saab kasutada `dummy`-i mis tahes võimalikul viisil, mis on lubatud Rust-koodil, ilma et kutsekoodis oleks määratlemata käitumist.
///
/// See omadus muudab `black_box`-i kasulikuks koodi kirjutamisel, milles teatud optimeerimisi, näiteks võrdlusaluseid, pole vaja.
///
/// Pange tähele, et `black_box` on saadaval (ja seda saab pakkuda) ainult "best-effort" alusel.Optimeerimiste blokeerimise ulatus võib varieeruda sõltuvalt kasutatavast platvormist ja koodigeeni taustaprogrammist.
/// Programmid ei saa *õigsuse* osas mingil viisil tugineda `black_box`-ile.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Peame argumenti "use" mingil moel LLVM-i sisse vaatamata jätma ja seda toetavate sihtmärkide korral saame selle jaoks tavaliselt kasutada sisemist kokkupanekut.
    // LLVM tõlgendab sisemist montaaži nii, et see on hästi must kast.
    // See pole kõige parem rakendus, kuna see desoptimeerib arvatavasti rohkem kui soovime, kuid siiani on see piisavalt hea.
    //
    //

    #[cfg(not(miri))] // See on vaid vihje, nii et Miris on hea vahele jätta.
    // OHUTUS: sisseehitatud komplekt on keelatud.
    unsafe {
        // FIXME: `asm!`-i ei saa kasutada, kuna see ei toeta MIPS-i ega muid arhitektuure.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}