#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Sisaldab kompilaatori sisseehitatud tüüpide paigutuse struktuurseid definitsioone.
//!
//! Neid saab kasutada ebaturvalises koodis olevate muundurite sihtmärkideks, et otse toores esitustega manipuleerida.
//!
//!
//! Nende määratlus peaks alati vastama `rustc_middle::ty::layout`-s määratletud ABI-le.
//!

/// trait objekti nagu `&dyn SomeTrait` kujutamine.
///
/// Sellel struktuuril on sama paigutus nagu tüüpidel `&dyn SomeTrait` ja `Box<dyn AnotherTrait>`.
///
/// `TraitObject` on garanteeritud, et see sobib paigutustega, kuid see ei ole trait objektide tüüp (nt `&dyn SomeTrait`-il pole väljadele otseselt juurdepääsetavad) ega kontrolli seda paigutust (definitsiooni muutmine ei muuda `&dyn SomeTrait`-i paigutust).
///
/// See on mõeldud kasutamiseks ainult ebaturvalise koodi puhul, mis peab manipuleerima madalama taseme üksikasjadega.
///
/// Kõigile trait objektidele ei saa viidata üldsõnaliselt, nii et ainus viis seda tüüpi väärtuste loomiseks on funktsioonidega nagu [`std::mem::transmute`][transmute].
/// Samamoodi on `transmute`-ga ainus viis tõelise trait-objekti loomiseks `TraitObject`-väärtusest.
///
/// [transmute]: crate::intrinsics::transmute
///
/// trait-objekti sünteesimine sobimatute tüüpidega-selline, kus vtable ei vasta selle väärtuse tüübile, millele andmekursor osutab-viib suure tõenäosusega määratlemata käitumiseni.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // näide trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // las kompilaator valmistab objekti trait
/// let object: &dyn Foo = &value;
///
/// // vaata töötlemata kujutist
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // andmekursor on `value` aadress
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // ehitada uus objekt, osutades teisele `i32`-le, olles ettevaatlik X0 `object`-st kasutatava `i32`-i kasutamisel
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // see peaks töötama täpselt nii, nagu oleksime `other_value`-ist otse trait-objekti ehitanud
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}