//! Tüübid, mis kinnitavad andmed mälus asukohta.
//!
//! Mõnikord on kasulik omada esemeid, mille liikumine on tagatud selles mõttes, et nende paigutamine mällu ei muutu ja seega saab neile tugineda.
//! Sellise stsenaariumi parim näide oleks enesereferentsiaalsete struktuuride loomine, kuna objektidega iseenda poole viimine muudab need kehtetuks, mis võib põhjustada määratlemata käitumise.
//!
//! Kõrgel tasemel tagab [`Pin<P>`], et ükskõik millise osutitüübi `P` adressaadil on stabiilne asukoht mälus, see tähendab, et seda ei saa mujale teisaldada ja tema mälu ei saa enne ümberpaigutada.Me ütleme, et pointee on "pinned".Asjad muutuvad peenemaks, kui arutatakse tüüpe, mis ühendatakse kinnitatud ja kinnitamata andmetega;[see below](#projections-and-structural-pinning) lisateabe saamiseks.
//!
//! Vaikimisi on kõik tüübid Rust liikuvad.
//! Rust võimaldab edastada kõiki tüüpe väärtusväärtuste kaupa ja tavalised nutikate osuti tüübid, näiteks [`Box<T>`] ja `&mut T`, võimaldavad asendada ja teisaldada neis sisalduvaid väärtusi: saate liikuda [`Box<T>`]-ist välja või kasutada [`mem::swap`]-i.
//! [`Pin<P>`] murrab kursori tüübi `P`, nii et ["Pin"] "<" ["Box"] "<T>>`toimib sarnaselt tavalisele
//!
//! [`Box<T>`]: when a ["Pin"] "<" ["Box"] "<T>>`langeb ära, nii ka selle sisu ja mälu saab
//!
//! lahendatud.Samamoodi on [`Pin`]`<&mut T>`sarnane `&mut T`-ga.Kuid [`Pin<P>`] ei lase klientidel kinnitatud andmetele tegelikult hankida [`Box<T>`] või `&mut T`, mis tähendab, et te ei saa kasutada selliseid toiminguid nagu [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` vajab `&mut T`-i, kuid me ei saa seda kätte.
//!     // Oleme ummikus, me ei saa nende viidete sisu vahetada.
//!     // Võiksime kasutada `Pin::get_unchecked_mut`-i, kuid see on põhjusel ohtlik:
//!     // meil ei ole lubatud seda kasutada asjade `Pin`-st välja viimiseks.
//! }
//! ```
//!
//! Tasub korrata, et [`Pin<P>`]*ei* muuda fakti, et Rust kompilaator peab kõiki tüüpe liikuvaks.[`mem::swap`] jääb helistatavaks mis tahes `T` jaoks.Selle asemel takistab [`Pin<P>`] teatud *väärtuste*(millele osutavad [`Pin<P>`]-i mähitud osutid) liigutamist, muutes võimatuks kutsuda meetodid, mis vajavad `&mut T`-i (näiteks [`mem::swap`]).
//!
//! [`Pin<P>`] saab kasutada mis tahes `P`-tüüpi osuti mähkimiseks ja sellisena suhtleb see [`Deref`] ja [`DerefMut`]-ga.[`Pin<P>`], kus `P: Deref`-i tuleks pidada kinnitatud `P::Target`-i "`P`-style pointer"-ks-seega, ["Pin"] <"[" Box "]"<T>> `on kinnitatud `T`-i kuuluv osuti ja [` Pin '] `<` [`Rc`]`<T>>`on kinnitatud `T`-i viitega loendatud osuti.
//! Korrektsuse huvides tugineb [`Pin<P>`] [`Deref`] ja [`DerefMut`] rakendustele, et nad ei liiguks parameetritest `self` välja ja tagastaksid kursori kinnitatud andmetele ainult siis, kui neid kutsutakse kinnitatud osutil.
//!
//! # `Unpin`
//!
//! Paljud tüübid on alati vabalt teisaldatavad, isegi kui need on kinnitatud, sest nad ei looda stabiilse aadressi omamisele.See hõlmab kõiki põhitüüpe (nagu [`bool`], [`i32`] ja viited), samuti tüüpe, mis koosnevad ainult nendest tüüpidest.Tüübid, mis kinnitamisest ei hooli, rakendavad [`Unpin`] auto-trait, mis tühistab [`Pin<P>`] mõju.
//! `T: Unpin`-i puhul ["Pin"] <"[" Box "]"<T>> ja [`Box<T>`] toimivad identselt, nagu ka ["Pin"] "<&mut T>" ja `&mut T`.
//!
//! Pange tähele, et kinnitamine ja [`Unpin`] mõjutavad ainult teravatipulist tüüpi `P::Target`, mitte [`Pin<P>`]-i pakitud kursoritüüpi `P` ennast.Näiteks see, kas [`Box<T>`] on [`Unpin`] või mitte, ei mõjuta ["Pin"] "<" ["Box"] "käitumist<T>>"(siin on `T` teravatipuline).
//!
//! # Näide: eneseviidav struktuur
//!
//! Enne kui läheme üksikasjalikumalt `Pin<T>`-iga seotud garantiide ja valikute selgitamiseks, arutame mõningaid näiteid selle kasutamise kohta.
//! Võite vabalt kasutada [skip to where the theoretical discussion continues](#drop-guarantee)-i.
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // See on eneseviidav struktuur, kuna viilu väli osutab andmeväljale.
//! // Me ei saa sellest koostajat tavalise viitega teavitada, kuna seda mustrit ei saa tavaliste laenureeglitega kirjeldada.
//! //
//! // Selle asemel kasutame töötlemata kursorit, kuigi teadaolevalt pole see null, kuna teame, et see osutab stringile.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Veendumaks, et andmed funktsiooni naastes ei liigu, paigutame need kuhja, kuhu need jäävad objekti eluea jooksul, ja ainus viis neile juurde pääseda oleks neile suunatud osuti kaudu.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // loome kursori alles siis, kui andmed on paigas, vastasel juhul on see juba enne meie alustamist liikunud
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // me teame, et see on ohutu, sest välja muutmine ei liiguta kogu struktuuri
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Kursor peaks osutama õigele asukohale seni, kuni struktuur pole liikunud.
//! //
//! // Vahepeal võime vabalt kursorit liigutada.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Kuna meie tüüp ei rakenda Unpin'i, ei õnnestu seda kompileerida:
//! // olgu mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Näide: pealetükkiv topeltlingitud loend
//!
//! Pealetükkivas topeltlingitud loendis ei eralda kogu tegelikult elementide enda jaoks mälu.
//! Jaotust kontrollivad kliendid ja elemendid võivad elada korstna raami peal, mis elab lühem kui kogu.
//!
//! Selle toimimiseks on igal elemendil loendis viidad eelkäijale ja järeltulijale.Elemente saab lisada ainult siis, kui need on kinnitatud, kuna elementide ümberpaigutamine muudaks osutid kehtetuks.Pealegi lingitakse lingitud loendielemendi [`Drop`]-i rakendamine eelkäija ja järeltulija näpunäiteid, et ennast loendist eemaldada.
//!
//! Oluline on, et peame saama loota [`drop`]-i kutsumisele.Kui elemendi saaks ilma [`drop`]-i kutsumata jaotada või muul viisil kehtetuks muuta, muutuksid naaberelementidest sinna viitavad osutid kehtetuks, mis rikuks andmestruktuuri.
//!
//! Seetõttu kaasneb kinnitusega ka [drop] seotud garantii.
//!
//! # `Drop` guarantee
//!
//! Kinnitamise eesmärk on osata tugineda mõnede andmete paigutamisele mällu.
//! Selle toimimiseks on piiratud mitte ainult andmete teisaldamine;Samuti on piiratud andmete salvestamiseks kasutatava mälu jagamine, ümberpaigutamine või muul viisil kehtetuks muutmine.
//! Konkreetselt, kinnitatud andmete puhul peate säilitama muutumatu variandi, et *selle mälu ei muutuks kehtetuks ega muudetuks alates kinnitamise hetkest kuni [`drop`]-i kutsumiseni*.Ainult siis, kui [`drop`] naaseb või panics, võib mälu uuesti kasutada.
//!
//! Mälu võib olla "invalidated" tehingu abil, aga ka [`Some(v)`] asendamine [`None`]-ga või [`Vec::set_len`]-i "kill"-i kutsumine mõned elemendid vector-st välja.Selle saab uuesti kasutada, kasutades [`ptr::write`]-i, et see üle kirjutada, ilma et oleksite enne destruktorit kutsunud.Ükski neist pole kinnitatud andmete puhul lubatud ilma [`drop`]-i helistamata.
//!
//! See on täpselt selline garantii, et eelmise jaotise pealetükkiv lingitud loend peab õigesti toimima.
//!
//! Pange tähele, et see garantii ei tähenda, et mälu ei lekiks!See on ikka täiesti okei, et mitte kunagi ei saa [`drop`]-i helistada kinnitatud elemendile (nt [`mem::forget`]-ile saate ikkagi helistada ["Pin"] "<" ["Box"] "<T>>`).Topeltlingitud loendi näites jääks see element lihtsalt loendisse.Kuid te ei tohi salvestusruumi *vabastada ega taaskasutada ilma, et helistaksite [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Kui teie tüüp kasutab kinnitamist (näiteks kaks ülaltoodud näidet), peate [`Drop`]-i rakendamisel olema ettevaatlik.Funktsioon [`drop`] võtab `&mut self`, kuid seda nimetatakse *isegi siis, kui teie tüüp oli varem kinnitatud*!Tundub, nagu kutsuks kompilaator automaatselt [`Pin::get_unchecked_mut`]-i.
//!
//! See ei saa kunagi turvalises koodis probleeme tekitada, kuna kinnitamisele tugineva tüübi juurutamine nõuab ebaturvalist koodi, kuid pidage meeles, et otsustades oma tüüpi kinnitamist kasutada (näiteks rakendades mõnda toimingut nupul [`Pin`]`<&Self>`või [`Pin ']`<&mut Self>`) mõjutab ka teie [`Drop`]-i rakendamist: kui teie tüüpi elemendi oleks võinud kinnitada, peate [`Drop`]-i käsitlema nii, et see kaudselt võtab [`Pin']`<&mut Ise>`.
//!
//!
//! Näiteks võite `Drop`-i rakendada järgmiselt:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` on okei, sest me teame, et seda väärtust ei kasutata pärast langetamist enam kunagi.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Tegelik tilkakood läheb siia.
//!         }
//!     }
//! }
//! ```
//!
//! Funktsioonil `inner_drop` on tüüp, mis [`drop`]*peaks olema*, nii et see tagab, et te ei kasuta `self`/`this`-i kogemata viisil, mis on vastuolus kinnitusega.
//!
//! Veelgi enam, kui teie tüüp on `#[repr(packed)]`, liigutab kompilaator väljad automaatselt ümber, et oleks võimalik neid maha visata.See võib seda teha isegi juhtude piisavalt joondatud väljade jaoks.Seetõttu ei saa te kinnitada `#[repr(packed)]`-tüüpi kinnitusega.
//!
//! # Prognoosid ja struktuurne kinnitamine
//!
//! Kinnitatud struktuuridega töötades tekib küsimus, kuidas saab selle struktuuri väljadele juurde pääseda meetodis, mis võtab lihtsalt [`Pin`]` <&mut Struct> '.
//! Tavaline lähenemisviis on abimeetodite (nn *projektsioonide*) kirjutamine, mis muudavad ["Pin"] "<&mut Struct>" viiteks väljale, kuid mis tüüpi see viide peaks olema?Kas see on ""Pin"] <&mut Field> või `&mut Field`?
//! Sama küsimus kerkib välja `enum` väljade puhul ja ka container/wrapper tüüpide, näiteks [`Vec<T>`], [`Box<T>`] või [`RefCell<T>`] puhul.
//! (See küsimus kehtib nii muutuvate kui ka jagatud viidete kohta, illustreerimiseks kasutame lihtsalt siin tavalisemat muudetavate viidete juhtumit.)
//!
//! Selgub, et tegelikult on andmestruktuuri autori otsustada, kas konkreetse välja kinnitatud projektsioon muudab ["Pin"] "<&mut Struct>" [[Pin "]" <&mut Field> "või `&mut Field`.Siiski on mõned piirangud ja kõige olulisem piirang on *järjepidevus*:
//! igat välja saab *kas* projitseerida kinnitatud viite külge,*või* on projitseerimise osana eemaldatud kinnitus.
//! Kui mõlemad tehakse sama välja jaoks, on see tõenäoliselt ebatõenäoline!
//!
//! Andmestruktuuri autorina saate iga välja puhul otsustada, kas kinnitada "propagates" sellele väljale või mitte.
//! Levivat nööpimist nimetatakse ka "structural", kuna see järgib tüübi struktuuri.
//! Järgmistes alapeatükkides kirjeldame kaalutlusi, mis tuleb kummagi valiku puhul teha.
//!
//! ## Kinnitamine * ei ole `field` jaoks struktuurne
//!
//! Võib tunduda vastuoluline, et kinnitatud struktuuri väli ei pruugi olla kinnitatud, kuid see on tegelikult kõige lihtsam valik: kui ["Pin"] "<&mut Field>" kunagi ei looda, ei saa midagi valesti minna!Seega, kui otsustate, et mõnel väljal puudub struktuurne kinnitamine, peate tagama vaid selle, et te ei loo kunagi sellele väljale kinnitatud viidet.
//!
//! Struktuurse kinnitamiseta väljadel võib olla projektsioonimeetod, mis muudab ["Pin"] "<&mut Struct>" `&mut Field`-ks:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // See on okei, sest `field`-i ei peeta kunagi kinnitatud.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Võite ka `impl Unpin for Struct`*, isegi kui*`field` tüüp pole [`Unpin`].See, mida see tüüp kinnitusest arvab, pole asjakohane, kui kunagi pole loodud ["Pin"] "<&mut Field>".
//!
//! ## Kinnitamine * on `field` jaoks struktuurne
//!
//! Teine võimalus on otsustada, et kinnitamine on `field` `field` jaoks, mis tähendab, et kui struktuur on kinnitatud, siis on see ka väli.
//!
//! See võimaldab kirjutada projektsiooni, mis loob ["Pin"] "<&mut Field>", andes seega tunnistust, et väli on kinnitatud:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // See on okei, sest `field` on kinnitatud, kui `self` on.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Struktuurse kinnitusega kaasnevad siiski mõned lisanõuded:
//!
//! 1. Struktuur peab olema [`Unpin`] ainult siis, kui kõik struktuuriväljad on [`Unpin`].See on vaikimisi, kuid [`Unpin`] on turvaline trait, nii et struktuuri autorina on teie kohustus *mitte* lisada midagi sellist nagu `impl<T> Unpin for Struct<T>`.
//! (Pange tähele, et projektsioonitoimingu lisamine nõuab ebaturvalist koodi, nii et asjaolu, et [`Unpin`] on turvaline trait, ei riku põhimõtet, et selle pärast peate muretsema ainult siis, kui kasutate ohutut.)
//! 2. Struktuuri hävitaja ei tohi struktuurivälju oma argumendist välja viia.See on täpne punkt, mis [previous section][drop-impl]-is tõstatati: `drop` võtab `&mut self`-i, kuid struktuur (ja seega ka selle väljad) võib olla varem kinnitatud.
//!     Peate tagama, et te ei liiguta [`Drop`]-i juurutuses väli.
//!     Nagu eelnevalt selgitatud, tähendab see, et teie struktuur ei tohi * olla `#[repr(packed)]`.
//!     Vaadake selles jaotises, kuidas kirjutada [`drop`] nii, et kompilaator aitaks teil kogemata kinnitada.
//! 3. Peate veenduma, et toetate [`Drop` guarantee][drop-guarantee]-i:
//!     kui teie struktuur on kinnitatud, ei kirjutata sisu sisaldavat mälu üle ega jaotata ilma sisu hävitajateks kutsumata.
//!     See võib olla keeruline, nagu tõendab [`VecDeque<T>`]: [`VecDeque<T>`]-i hävitaja võib ebaõnnestuda kõigi elementide [`drop`]-i kutsumise, kui üks destruktoritest panics.See rikub garantiid [`Drop`], sest see võib viia elementide jaotamiseni ilma nende hävitajat kutsumata.([`VecDeque<T>`]-l pole kinnitusprojekte, seega ei põhjusta see ebamugavust.)
//! 4. Te ei tohi pakkuda muid toiminguid, mis võiksid viia teie tüübi kinnitamisel struktuuriväljadelt andmete teisaldamiseni.Näiteks kui struktuur sisaldab [`Option<T>`]-i ja `fn(Pin<&mut Struct<T>>) -> Option<T>`-tüüpi on `take'-laadne toiming, saab seda toimingut kasutada `T`-i teisaldamiseks kinnitatud `Struct<T>`-st-see tähendab, et kinnitamine ei saa olla seda välja hoidva välja jaoks struktuurne andmed.
//!
//!     Keerukama näite abil andmete teisaldamisest kinnitatud tüübist välja kujutage, kui [`RefCell<T>`]-l oleks meetod `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Siis saaksime teha järgmist:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     See on katastroofiline, see tähendab, et saame kõigepealt kinnitada [`RefCell<T>`]-i sisu (kasutades `RefCell::get_pin_mut`-i) ja seejärel selle sisu teisaldada, kasutades hiljem saadud muudetavat viidet.
//!
//! ## Examples
//!
//! Tüübi [`Vec<T>`] puhul on mõlemad võimalused (struktuurne kinnitamine või mitte) mõttekas.
//! Struktuurse kinnitusega [`Vec<T>`]-l võiksid olla kinnitatud viited elementidele `get_pin`/`get_pin_mut`-meetoditega.Kuid see ei saanud *mitte* lubada [`pop`][Vec::pop]-i helistamist kinnitatud [`Vec<T>`]-il, sest see liigutaks (struktuurselt kinnitatud) sisu!Samuti ei saanud see lubada [`push`][Vec::push]-i, mis võib ümber jaotada ja seega ka sisu liigutada.
//!
//! Struktuurse kinnitamiseta [`Vec<T>`] võiks olla `impl<T> Unpin for Vec<T>`, sest sisu pole kunagi kinnitatud ja ka [`Vec<T>`] ise on hästi liigutatav.
//! Sel hetkel ei ole kinnitamine lihtsalt vector-le mingit mõju.
//!
//! Tavaraamatukogus ei ole kursoritüüpidel tavaliselt struktuurset kinnitamist ja seega ei paku nad ka kinnitusprojekte.Seetõttu kehtib `Box<T>: Unpin` kõigi `T`-de jaoks.
//! Mõistlik on seda teha kursoritüüpide puhul, sest `Box<T>`-i liigutamine ei liiguta `T`-i tegelikult: [`Box<T>`] võib olla vabalt liikuv (teise nimega `Unpin`), isegi kui `T` seda pole.Tegelikult isegi [`Pin`]`<`[`Box ']`<T>> `ja [` Pin '] `<&mut T>` on alati [`Unpin`] ise, samal põhjusel: nende sisu (`T`) on kinnitatud, kuid kursoreid saab ise teisaldada ilma kinnitatud andmeid teisaldamata.
//! Nii [`Box<T>`] kui ka ["Pin"] jaoks <<[[Box]] "<T>>, kas sisu kinnitamine on täiesti sõltumatu sellest, kas kursor on kinnitatud, see tähendab, et kinnitamine pole *mitte* struktuurne.
//!
//! Kombinaatori [`Future`] juurutamisel vajate tavaliselt pesastatud futures jaoks struktuurilist kinnitamist, kuna peate [`poll`]-i helistamiseks hankima neile kinnitatud viited.
//! Kuid kui teie kombinaator sisaldab muid andmeid, mida pole vaja kinnitada, saate need väljad mitte struktureerida ja seega vabalt neile juurde pääseda, kasutades muudetavat viidet, isegi kui teil on lihtsalt ["Pin"] "<&mut Self>" (näiteks nagu teie enda [`poll`] juurutamisel).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Kinnitatud kursor.
///
/// See on ümbris mingi osuti ümber, mis muudab selle kursori "pin" oma kohale, takistades selle kursori viidatud väärtuse teisaldamist, kui see ei rakenda [`Unpin`].
///
///
/// *Kinnitamise selgituse leiate [`pin` module] dokumentatsioonist.*
///
/// [`pin` module]: self
///
// Note: allpool toodud `Clone` tuletis põhjustab ebamugavust, kuna seda on võimalik rakendada
// `Clone` muutuvate viidete jaoks.
// Lisateavet leiate jaotisest <https://internals.rust-lang.org/t/unsoundness-in-pin/11311>.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Järgmised rakendused pole tuletatud usaldusväärsuse probleemide vältimiseks.
// `&self.pointer` ei peaks olema kättesaadav ebausaldusväärsetele trait rakendustele.
//
// Lisateavet leiate jaotisest <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73>.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Ehitage uus `Pin<P>` osuti ümber osadele andmetüüpidest, mis rakendavad [`Unpin`]-i.
    ///
    /// Erinevalt `Pin::new_unchecked`-st on see meetod ohutu, kuna osuti `P` viitab [`Unpin`]-tüübile, mis tühistab kinnitamise garantiid.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // OHUTUS: osutatav väärtus on `Unpin` ja seega pole sellel mingeid nõudeid
        // kinnitamise ümber.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Tühistab selle `Pin<P>`-i, tagastades aluseks oleva kursori.
    ///
    /// See nõuab, et selle `Pin` sees olevad andmed oleksid [`Unpin`], et saaksime neid lahti pakkides ignoreerida kinnistavaid invariante.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Ehitage uus `Pin<P>` viite ümber teatud tüüpi andmetele, mis võivad `Unpin`-i rakendada või mitte.
    ///
    /// Kui `pointer` viitab `Unpin` tüübile, tuleks selle asemel kasutada `Pin::new`-i.
    ///
    /// # Safety
    ///
    /// See konstruktor on ebaturvaline, kuna me ei saa garanteerida, et andmed, millele `pointer` osutab, on kinnitatud, see tähendab, et andmeid ei teisaldata ega nende mälu kehtetuks muuta enne, kui need ära visatakse.
    /// Kui koostatud `Pin<P>` ei taga, et andmed, millele `P` osutab, on kinnitatud, on see API-lepingu rikkumine ja võib viia määratlemata käitumiseni hilisemates (safe)-toimingutes.
    ///
    /// Selle meetodi abil koostate rakenduste `P::Deref` ja `P::DerefMut` rakenduste kohta promise, kui need on olemas.
    /// Kõige tähtsam on see, et nad ei tohi oma `self`-argumentidest välja liikuda: `Pin::as_mut` ja `Pin::as_ref` kutsuvad kinnitatud osutil *`DerefMut::deref_mut` ja `Deref::deref`* ja eeldavad, et need meetodid toetavad kinnistavaid invariante.
    /// Veelgi enam, nimetades seda meetodit, saate promise, et viite `P` allahindlusi enam ei teisaldata;eriti ei tohi olla võimalik saada `&mut P::Target` ja seejärel sellest viitest välja liikuda (kasutades näiteks [`mem::swap`]).
    ///
    ///
    /// Näiteks pole X0 `Pin::new_unchecked`-il helistamine `&'a mut T`-il ohtlik, sest kuigi saate selle kinnitada antud eluea jooksul `'a`, ei saa te kontrollida, kas seda hoitakse kinnitatud, kui `'a` lõpeb:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // See peaks tähendama, et pointee `a` ei saa enam kunagi liikuda.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // `a`-i aadress muutus `b`-i virna pesaks, nii et `a` kolis ümber, kuigi oleme selle varem kinnitanud!Oleme rikkunud API kinnitamise lepingut.
    /////
    /// }
    /// ```
    ///
    /// Kui see on kinnitatud, peab see jäädavalt kinnitatud jääma (kui selle tüüp ei rakenda `Unpin`).
    ///
    /// Samamoodi on `Pin::new_unchecked`-il helistamine `Rc<T>`-il ohtlik, kuna samadele andmetele võivad olla varjunimed, mille kinnitamise piirangud ei kehti:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // See peaks tähendama, et pointee ei saa enam kunagi liikuda.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Kui nüüd oli ainus viide `x`, on meil muudetav viide ülaltoodud kinnitatud andmetele, mida saaksime nende teisaldamiseks kasutada, nagu nägime eelmises näites.
    ///     // Oleme rikkunud API kinnitamise lepingut.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Selle kinnitatud kursori abil saab kinnitatud jagatud viite.
    ///
    /// See on üldine meetod `&Pin<Pointer<T>>`-ist `Pin<&T>`-i liikumiseks.
    /// See on ohutu, kuna osana `Pin::new_unchecked` lepingust ei saa pointee liikuda pärast seda, kui `Pin<Pointer<T>>` on loodud.
    ///
    /// "Malicious" `Pin::new_unchecked` rakendused on samuti välistatud `Pin::new_unchecked` lepinguga.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // OHUTUS: vaadake selle funktsiooni dokumentatsiooni
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Tühistab selle `Pin<P>`-i, tagastades aluseks oleva kursori.
    ///
    /// # Safety
    ///
    /// See funktsioon on ohtlik.Peate tagama, et jätkate kursori `P` käsitlemist kinnitatud kujul pärast selle funktsiooni kutsumist, et `Pin`-tüüpi invariante saaks säilitada.
    /// Kui tulemuseks olevat `P`-i kasutav kood ei jätka kinnitavate invariantide hooldamist, on see API-lepingu rikkumine ja see võib (safe)-i hilisemates toimingutes kaasa tuua määratlemata käitumise.
    ///
    ///
    /// Kui aluseks olevad andmed on [`Unpin`], tuleks selle asemel kasutada [`Pin::into_inner`]-i.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Selle kinnitatud kursori abil saab kinnitatud muudetava viite.
    ///
    /// See on üldine meetod `&mut Pin<Pointer<T>>`-ist `Pin<&mut T>`-i liikumiseks.
    /// See on ohutu, kuna osana `Pin::new_unchecked` lepingust ei saa pointee liikuda pärast seda, kui `Pin<Pointer<T>>` on loodud.
    ///
    /// "Malicious" `Pin::new_unchecked` rakendused on samuti välistatud `Pin::new_unchecked` lepinguga.
    ///
    /// See meetod on kasulik, kui helistate mitu korda kinnitatud tüüpi tarbivatele funktsioonidele.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // tee midagi
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` tarbib `self`-i, seega laenake `Pin<&mut Self>` `as_mut`-i kaudu edasi.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // OHUTUS: vaadake selle funktsiooni dokumentatsiooni
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Määrab kinnitatud viite taga mälule uue väärtuse.
    ///
    /// See kirjutab kinnitatud andmed üle, kuid see on okei: selle hävitaja käivitatakse enne ülekirjutamist, seega ei rikuta kinnitamise garantiid.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Ehitab uue tihvti, kaardistades sisemise väärtuse.
    ///
    /// Näiteks kui soovite saada `Pin`-d millegi väljalt, võite seda kasutada, et saada juurdepääs sellele väljale ühel koodireal.
    /// Nende "pinning projections"-iga on aga mitu gotchat;
    /// selle teema kohta lisateavet leiate [`pin` module] dokumentatsioonist.
    ///
    /// # Safety
    ///
    /// See funktsioon on ohtlik.
    /// Peate tagama, et teie tagastatud andmed ei liiguks seni, kuni argumendi väärtus ei liigu (näiteks seetõttu, et see on selle väärtuse üks väljad), ja et te ei koli saadud argumendist välja salongi funktsioon.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // OHUTUS: `new_unchecked`-i ohutusleping peab olema
        // helistaja kinnitas.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Saab tihvtist välja jagatud viite.
    ///
    /// See on ohutu, kuna jagatud viidetest pole võimalik välja liikuda.
    /// Võib tunduda, et siin on probleem siseruumide muutlikkusega: tegelikult on * võimalik `T` `&RefCell<T>`-ist välja viia.
    /// Kuid see pole probleem seni, kuni pole olemas ka samadele andmetele osutavat `Pin<&T>`-i ja `RefCell<T>` ei luba teil kinnitatud viidet selle sisule luua.
    ///
    /// Lisateavet leiate ["pinning projections"]-i arutelust.
    ///
    /// Note: `Pin` rakendab sihtmärgile ka `Deref`, mida saab kasutada sisemisele väärtusele juurdepääsu saamiseks.
    /// Kuid `Deref` pakub ainult viidet, mis elab nii kaua kui `Pin`-i laen, mitte `Pin`-i enda eluiga.
    /// See meetod võimaldab muuta `Pin` algse `Pin`-iga sama elueaga referentsiks.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Teisendab selle `Pin<&mut T>` sama elueaga `Pin<&T>`-ks.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Saab muudetava viite selle `Pin` sees olevatele andmetele.
    ///
    /// See nõuab, et selles `Pin`-is olevad andmed oleksid `Unpin`.
    ///
    /// Note: `Pin` rakendab andmetele ka `DerefMut`, mida saab kasutada sisemisele väärtusele juurdepääsemiseks.
    /// Kuid `DerefMut` pakub ainult viidet, mis elab nii kaua kui `Pin`-i laen, mitte `Pin`-i enda eluiga.
    ///
    /// See meetod võimaldab muuta `Pin` algse `Pin`-iga sama elueaga referentsiks.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Saab muudetava viite selle `Pin` sees olevatele andmetele.
    ///
    /// # Safety
    ///
    /// See funktsioon on ohtlik.
    /// Peate garanteerima, et te ei teisalda kunagi andmeid selle funktsiooni kutsumisel saadud muudetavast viitest välja, nii et `Pin` tüüpi invariante saab säilitada.
    ///
    ///
    /// Kui aluseks olevad andmed on `Unpin`, tuleks selle asemel kasutada `Pin::get_mut`-i.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Ehitage uus tihvt, kaardistades interjööri väärtuse.
    ///
    /// Näiteks kui soovite saada `Pin`-d millegi väljalt, võite seda kasutada, et saada juurdepääs sellele väljale ühel koodireal.
    /// Nende "pinning projections"-iga on aga mitu gotchat;
    /// selle teema kohta lisateavet leiate [`pin` module] dokumentatsioonist.
    ///
    /// # Safety
    ///
    /// See funktsioon on ohtlik.
    /// Peate tagama, et teie tagastatud andmed ei liiguks seni, kuni argumendi väärtus ei liigu (näiteks seetõttu, et see on selle väärtuse üks väljad), ja et te ei koli saadud argumendist välja salongi funktsioon.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // OHUTUS: helistaja vastutab selle eest, et telefon ei liiguks
        // väärtus sellest viitest välja.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // OHUTUS: kuna `this` väärtus ei ole garanteeritud
        // on teisaldatud, on see kõne `new_unchecked`-ile turvaline.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Hankige kinnitatud viide staatilisest viitest.
    ///
    /// See on ohutu, sest `T` on laenatud `'static` eluajaks, mis ei lõpe kunagi.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // OHUTUS: staatiline laen tagab, et andmeid pole
        // moved/invalidated kuni see langeb (mida pole kunagi).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Hankige kinnitatud muutuv viide staatilisest muudetavast viitest.
    ///
    /// See on ohutu, sest `T` on laenatud `'static` eluajaks, mis ei lõpe kunagi.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // OHUTUS: staatiline laen tagab, et andmeid pole
        // moved/invalidated kuni see langeb (mida pole kunagi).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: see tähendab, et kõik `CoerceUnsized` implikatsioonid, mis võimaldavad alates
// tüüp, mis implitseerib `Deref<Target=impl !Unpin>` tüüpi, mis implitseerib `Deref<Target=Unpin>`-i, on ebatõenäoline.
// Selline implikatsioon oleks tõenäoliselt muudel põhjustel ebamõistlik, seega peame lihtsalt hoolitsema selle eest, et sellised implikatsioonid ei saaks std-s maanduda.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}