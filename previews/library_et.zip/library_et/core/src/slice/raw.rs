//! Tasuta funktsioonid `&[T]` ja `&mut [T]` loomiseks.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Moodustab kursorist ja pikkusest viilu.
///
/// `len` argument on **elementide** arv, mitte baitide arv.
///
/// # Safety
///
/// Käitumine on määratlemata, kui rikutakse mõnda järgmistest tingimustest:
///
/// * `data` peab paljude baitide `len * mem::size_of::<T>()` lugemise korral olema [valid] ja see peab olema korralikult joondatud.See tähendab eelkõige:
///
///     * Selle osa kogu mälu peab jääma ühte eraldatud objekti!
///       Lõigud ei saa kunagi ulatuda mitme eraldatud objekti vahel.Vt [below](#incorrect-usage) näide valesti seda arvesse võtmata.
///     * `data` ei tohi olla null ja joondatud ka nullpikkuste viilude puhul.
///     Selle üks põhjus on see, et loendi paigutuse optimeerimine võib tugineda viidete (sealhulgas mis tahes pikkusega viiludele) joondamisele ja mitte-nullile, et eristada neid muudest andmetest.
///     Nullpikkuste viilude jaoks saate [`NonNull::dangling()`]-i abil kasutada kursorit, mida saab kasutada kui `data`.
///
/// * `data` peab osutama `T`-i järjestikustele korralikult initsialiseeritud väärtustele.
///
/// * Tagastatud viilu viidatud mälu ei tohi kogu eluea jooksul `'a` muteerida, välja arvatud `UnsafeCell` sees.
///
/// * Viilu kogu suurus `len * mem::size_of::<T>()` ei tohi olla suurem kui `isize::MAX`.
///   Vaadake seadme [`pointer::offset`] ohutusdokumentatsiooni.
///
/// # Caveat
///
/// Tagastatud viilu eluiga tuletatakse selle kasutamisest.
/// Juhusliku väärkasutuse vältimiseks on soovitatav siduda eluiga kumbagi allika elueaga, mis on kontekstis ohutu, näiteks pakkudes abifunktsiooni, mis võtab viilu hosti väärtuse eluea, või selgesõnalise märkuse abil.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // avaldada viilu ühe elemendi jaoks
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Vale kasutamine
///
/// Järgmine funktsioon `join_slices` on **ebaheli** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Ülaltoodud väide tagab, et `fst` ja `snd` on külgnevad, kuid need võivad siiski sisalduda _different allocated objects_-s, mille puhul on selle viilu loomine määratlemata käitumine.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` ja `b` on erinevad eraldatud objektid ...
///     let a = 42;
///     let b = 27;
///     // ... mis sellegipoolest võidakse mälestuseks külgnevalt paigutada: a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // OHUTUS: helistaja peab järgima `from_raw_parts`-i ohutuslepingut.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Teeb sama funktsionaalsust nagu [`from_raw_parts`], välja arvatud see, et tagastatakse muudetav viil.
///
/// # Safety
///
/// Käitumine on määratlemata, kui rikutakse mõnda järgmistest tingimustest:
///
/// * `data` peab olema paljude baitide `len * mem::size_of::<T>()` lugemise ja kirjutamise puhul [valid] ning see peab olema korralikult joondatud.See tähendab eelkõige:
///
///     * Selle osa kogu mälu peab jääma ühte eraldatud objekti!
///       Lõigud ei saa kunagi ulatuda mitme eraldatud objekti vahel.
///     * `data` ei tohi olla null ja joondatud ka nullpikkuste viilude puhul.
///     Selle üks põhjus on see, et loendi paigutuse optimeerimine võib tugineda viidete (sealhulgas mis tahes pikkusega viiludele) joondamisele ja mitte-nullile, et eristada neid muudest andmetest.
///
///     Nullpikkuste viilude jaoks saate [`NonNull::dangling()`]-i abil kasutada kursorit, mida saab kasutada kui `data`.
///
/// * `data` peab osutama `T`-i järjestikustele korralikult initsialiseeritud väärtustele.
///
/// * Tagastatud viilu viidatud mällu ei tohi `'a` eluea jooksul juurde pääseda ühegi teise (mitte tagastusväärtusest tuletatud) osuti kaudu.
///   Nii lugemis-kui ka kirjutusjuurdepääs on keelatud.
///
/// * Viilu kogu suurus `len * mem::size_of::<T>()` ei tohi olla suurem kui `isize::MAX`.
///   Vaadake seadme [`pointer::offset`] ohutusdokumentatsiooni.
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // OHUTUS: helistaja peab järgima `from_raw_parts_mut`-i ohutuslepingut.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Teisendab viite T-le viiluks pikkusega 1 (kopeerimata).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Teisendab viite T-le viiluks pikkusega 1 (kopeerimata).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}