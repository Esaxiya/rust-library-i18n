// ignore-tidy-filelength

//! Viilude haldamine ja manipuleerimine.
//!
//! Lisateavet vt [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Puhas rust memchri juurutamine, võetud rust-memchrist
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// See funktsioon on avalik ainult seetõttu, et heapsordi testimiseks pole muud võimalust.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Tagastab viilu elementide arvu.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // OHUTUS: const heli, kuna me teisendame pikkusevälja kasutamisena välja (mis see peab olema)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // OHUTUS: see on ohutu, kuna `&[T]` ja `FatPtr<T>` on sama paigutusega.
            // Selle garantii saab anda ainult `std`.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Asendage `crate::ptr::metadata(self)`-iga, kui see on konstantselt stabiilne.
            // Selle kirjutamise ajal põhjustab see "Const-stable functions can only call other const-stable functions"-i tõrke.
            //

            // OHUTUS: Väärtusele pääsemine liidult `PtrRepr` on turvaline, kuna * const T
            // ja PtrComponents<T>on ühesugused mäluplaanid.
            // Selle garantii saab anda ainult std.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Tagastab `true`, kui viilu pikkus on 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Tagastab viilu esimese elemendi või `None`, kui see on tühi.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Tagastab muutuva kursori viilu esimesele elemendile või `None`, kui see on tühi.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Tagastab viilu esimese ja kõik ülejäänud elemendid või `None`, kui see on tühi.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Tagastab viilu esimese ja kõik ülejäänud elemendid või `None`, kui see on tühi.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Tagastab viilu viimase ja kõik ülejäänud elemendid või `None`, kui see on tühi.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Tagastab viilu viimase ja kõik ülejäänud elemendid või `None`, kui see on tühi.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Tagastab viilu viimase elemendi või `None`, kui see on tühi.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Tagastab muudetava kursori viilu viimasele üksusele.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Annab vastuseks indeksi tüübist viite elemendile või alamlõigule.
    ///
    /// - Kui antakse positsioon, tagastab viite elemendile selles asendis või `None`, kui see on väljaspool piire.
    ///
    /// - Kui antakse vahemik, tagastab sellele vahemikule vastava alamharu või `None`, kui see on väljaspool piire.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Tagastab muutuva viite elemendile või alamklassile sõltuvalt indeksi tüübist (vt [`get`]) või `None`, kui indeks on väljaspool piire.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Tagastab viite elemendile või alamlõigule, ilma piiride kontrollimiseta.
    ///
    /// Ohutu alternatiivi leidmiseks vaadake [`get`].
    ///
    /// # Safety
    ///
    /// Selle meetodi kutsumine piiriülese indeksiga on *[määratlemata käitumine]*, isegi kui saadud viidet ei kasutata.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // OHUTUS: helistaja peab järgima enamikku `get_unchecked`-i ohutusnõuetest;
        // viil on tuletatav, kuna `self` on ohutu viide.
        // Tagastatud kursor on ohutu, kuna `SliceIndex` i implikatsioonid peavad selle tagama.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Tagastab muutuva viite elemendile või alamlõigule, ilma piiride kontrollimiseta.
    ///
    /// Ohutu alternatiivi leidmiseks vaadake [`get_mut`].
    ///
    /// # Safety
    ///
    /// Selle meetodi kutsumine piiriülese indeksiga on *[määratlemata käitumine]*, isegi kui saadud viidet ei kasutata.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // OHUTUS: helistaja peab järgima seadme `get_unchecked_mut` ohutusnõudeid;
        // viil on tuletatav, kuna `self` on ohutu viide.
        // Tagastatud kursor on ohutu, kuna `SliceIndex` i implikatsioonid peavad selle tagama.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Tagastab toore osuti viilu puhvrisse.
    ///
    /// Helistaja peab tagama, et viil ületaks selle funktsiooni tagastatava kursori vanuse, vastasel juhul näitab see prügi.
    ///
    /// Helistaja peab ka tagama, et mälu, millele osuti (non-transitively) osutab, ei kirjutataks kunagi (välja arvatud `UnsafeCell` sees), kasutades seda kursorit või sellest tuletatud osuti.
    /// Kui peate viilu sisu muteerima, kasutage [`as_mut_ptr`]-i.
    ///
    /// Selle viilu viidatud konteineri muutmine võib põhjustada selle puhvri ümberjaotamise, mis muudaks ka selle viited kehtetuks.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Tagastab viilu puhvrisse ebaturvalise muudetava osuti.
    ///
    /// Helistaja peab tagama, et viil ületaks selle funktsiooni tagastatava kursori vanuse, vastasel juhul näitab see prügi.
    ///
    /// Selle viilu viidatud konteineri muutmine võib põhjustada selle puhvri ümberjaotamise, mis muudaks ka selle viited kehtetuks.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Tagastab viilu hõlmavad kaks töötlemata osutit.
    ///
    /// Tagastatud vahemik on poolavatud, mis tähendab, et lõppkursor osutab viilu viimase elemendi *üks minevik*.
    /// Nii tähistatakse tühja viilu kahe võrdse osutiga ja kahe osuti vahe tähistab viilu suurust.
    ///
    /// Nende näpunäidete kasutamise hoiatuste kohta vt [`as_ptr`].Lõpposuti nõuab erilist ettevaatlikkust, kuna see ei osuta viilus kehtivale elemendile.
    ///
    /// See funktsioon on kasulik suhtlemiseks võõrliidestega, mis kasutavad kahte osutit, et viidata mälus olevate elementide vahemikule, nagu on tavaline C++ puhul.
    ///
    ///
    /// Samuti võib olla kasulik kontrollida, kas osuti elemendile viitab selle viilu elemendile:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // OHUTUS: `add` on siin ohutu, kuna:
        //
        //   - Mõlemad osutid on osa samast objektist, kuna loeb ka otse objektist mööda suunamine.
        //
        //   - Lõigu suurus ei ole kunagi suurem kui isize::MAX baiti, nagu siin märgitud:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Asjaosalisi pole ümber mähitud, kuna viilud ei mähi aadressiruumi lõpust mööda.
        //
        // Vaadake pointer::add dokumentatsiooni.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Tagastab viilu hõlmavad kaks ebaturvalist muudetavat kursorit.
    ///
    /// Tagastatud vahemik on poolavatud, mis tähendab, et lõppkursor osutab viilu viimase elemendi *üks minevik*.
    /// Nii tähistatakse tühja viilu kahe võrdse osutiga ja kahe osuti vahe tähistab viilu suurust.
    ///
    /// Nende näpunäidete kasutamise hoiatuste kohta vt [`as_mut_ptr`].
    /// Lõpposuti nõuab erilist ettevaatlikkust, kuna see ei osuta viilus kehtivale elemendile.
    ///
    /// See funktsioon on kasulik suhtlemiseks võõrliidestega, mis kasutavad kahte osutit, et viidata mälus olevate elementide vahemikule, nagu on tavaline C++ puhul.
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // OHUTUS: vaadake ülaltoodud as_ptr_range()-i, miks `add` siin on ohutu.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Vahetab viilus kaks elementi.
    ///
    /// # Arguments
    ///
    /// * a, esimese elemendi indeks
    /// * b, teise elemendi indeks
    ///
    /// # Panics
    ///
    /// Panics, kui `a` või `b` on väljaspool piire.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Ühelt vector-lt ei saa võtta kahte muudetavat laenu, seega kasutage selle asemel tooreid näpunäiteid.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // OHUTUS: `pa` ja `pb` on loodud ohututest muutuvatest viidetest ja viidetest
        // viilu elementidele ning seetõttu on nende kehtivus ja joondamine tagatud.
        // Pange tähele, et `a` ja `b` taga olevate elementide juurde pääsemine on kontrollitud ja panic kui see on väljaspool piire.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Pöörab elementide järjekorra viilus paigas.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Väga väikeste tüüpide korral töötavad kõik tavalisel teel loetud isikud halvasti.
        // Efektiivse joondamata load/store-iga saame paremini hakkama, laadides suurema tüki ja tagurdades registri.
        //

        // Ideaalis teeks LLVM seda meie eest, kuna ta teab paremini kui meie, kas joondamata lugemised on tõhusad (kuna see muutub näiteks erinevate ARM-i versioonide vahel) ja milline oleks parim tükkide suurus.
        // Kahjuks rullib see LLVM 4.0 (2017-05)-st ainult silmus lahti, nii et peame seda ise tegema.
        // (Hüpotees: tagurpidi on tülikas, sest külgi saab joondada erinevalt-see on siis, kui pikkus on paaritu-nii et pole võimalik eel-ja järeltõkkeid väljastada, et kasutada täielikult joondatud SIMD-d keskel.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Kasutage X8X-i sisemist, et kasutada u8-sid kasutamisel
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // OHUTUS: siin on mitu asja, mida kontrollida:
                //
                // - Pange tähele, et `chunk` on kas 4 või 8 ülaltoodud CFG-kontrolli tõttu.Nii et `chunk - 1` on positiivne.
                // - Indekseerimine indeksiga `i` on hea, kuna tsükli kontroll tagab
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Indekseerimine indeksiga `ln - i - chunk = ln - (i + chunk)` on korras:
                //   - `i + chunk > 0` on triviaalselt tõsi.
                //   - Silmukontroll tagab:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, seega lahutamine ei alavoolu.
                // - `read_unaligned` ja `write_unaligned` kõned on korras:
                //   - `pa` osutab indeksile `i`, kus `i < ln / 2 - (chunk - 1)` (vt eespool) ja `pb` osutab indeksile `ln - i - chunk`, nii et mõlemad asuvad `self` lõpust vähemalt `chunk` palju baite.
                //
                //   - Iga initsialiseeritud mälu on kehtiv `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Kasutage X16X-is u16-de tagurdamiseks 16-ga pööramist
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // OHUTUS: Joondamata u32 saab lugeda `i`-ist, kui `i + 1 < ln`
                // (ja ilmselt `i < ln`), sest iga element on 2 baiti ja me loeme 4.
                //
                // `i + chunk - 1 < ln / 2` # samas tingimus
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Kuna see on väiksem kui pikkus jagatud 2-ga, peab see olema piiratud.
                //
                // See tähendab ka seda, et tingimust `0 < i + chunk <= ln` peetakse alati kinni, tagades `pb`-osuti ohutu kasutamise.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // OHUTUS: `i` jääb alla poole viilu pikkusest
            // `i` ja `ln - i - 1` juurdepääs on turvaline (`i` algab 0-st ega lähe kaugemale kui `ln / 2 - 1`).
            // Saadud osutid `pa` ja `pb` on seetõttu kehtivad ja joondatud ning neid saab lugeda ja sinna kirjutada.
            //
            //
            unsafe {
                // Ohutu vahetus piiride vältimiseks kontrollige turvalises vahetuses.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Tagastab viilu kohal iteraatori.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Tagastab iteraatori, mis võimaldab iga väärtust muuta.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Tagastab iteraatori kogu külgneva windows pikkusega `size`.
    /// windows kattub.
    /// Kui lõik on lühem kui `size`, ei tagasta iteraator väärtusi.
    ///
    /// # Panics
    ///
    /// Panics, kui `size` on 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Kui viil on lühem kui `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Tagastab viilu `chunk_size` elementide iteraatori korraga, alustades viilu algusest.
    ///
    /// Tükid on viilud ja ei kattu.Kui `chunk_size` ei jaga viilu pikkust, pole viimasel tükil `chunk_size` pikkust.
    ///
    /// Selle iteraatori variandi kohta, mis tagastab alati täpselt `chunk_size` elementide tükid, ja [`rchunks`] samale iteraatorile, kuid alustades viilu lõpust, vaadake [`chunks_exact`].
    ///
    ///
    /// # Panics
    ///
    /// Panics, kui `chunk_size` on 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Tagastab viilu `chunk_size` elementide iteraatori korraga, alustades viilu algusest.
    ///
    /// Tükid on muutuvad viilud ja ei kattu.Kui `chunk_size` ei jaga viilu pikkust, pole viimasel tükil `chunk_size` pikkust.
    ///
    /// Selle iteraatori variandi kohta, mis tagastab alati täpselt `chunk_size` elementide tükid, ja [`rchunks_mut`] samale iteraatorile, kuid alustades viilu lõpust, vaadake [`chunks_exact_mut`].
    ///
    ///
    /// # Panics
    ///
    /// Panics, kui `chunk_size` on 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Tagastab viilu `chunk_size` elementide iteraatori korraga, alustades viilu algusest.
    ///
    /// Tükid on viilud ja ei kattu.
    /// Kui `chunk_size` ei jaga viilu pikkust, jäetakse viimased kuni `chunk_size-1` elemendid välja ja neid saab leida iteraatori funktsioonist `remainder`.
    ///
    ///
    /// Kuna igal tükil on täpselt `chunk_size`-elemendid, saab kompilaator saadud koodi sageli paremini optimeerida kui [`chunks`]-i puhul.
    ///
    /// Selle iteraatori variandi kohta, mis tagastab ka ülejäänud osa väiksema tükina, vaadake [`chunks`] ja sama iteraatori puhul [`rchunks_exact`], kuid alustades viilu lõpust.
    ///
    /// # Panics
    ///
    /// Panics, kui `chunk_size` on 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Tagastab viilu `chunk_size` elementide iteraatori korraga, alustades viilu algusest.
    ///
    /// Tükid on muutuvad viilud ja ei kattu.
    /// Kui `chunk_size` ei jaga viilu pikkust, jäetakse viimased kuni `chunk_size-1` elemendid välja ja neid saab leida iteraatori funktsioonist `into_remainder`.
    ///
    ///
    /// Kuna igal tükil on täpselt `chunk_size`-elemendid, saab kompilaator saadud koodi sageli paremini optimeerida kui [`chunks_mut`]-i puhul.
    ///
    /// Selle iteraatori variandi kohta, mis tagastab ka ülejäänud osa väiksema tükina, vaadake [`chunks_mut`] ja sama iteraatori puhul [`rchunks_exact_mut`], kuid alustades viilu lõpust.
    ///
    /// # Panics
    ///
    /// Panics, kui `chunk_size` on 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Jagab viilu osaks `N`-elementide massiivid, eeldades, et ülejäänud osa pole.
    ///
    ///
    /// # Safety
    ///
    /// Seda võib nimetada ainult siis, kui
    /// - Lõik jaguneb täpselt N-elemenditükkideks (ehk `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // OHUTUS: 1-elemendilistel tükkidel pole kunagi ülejäänud osa
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // OHUTUS: viilu pikkus (6) on 3-kordne
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Need oleksid ebamõistlikud:
    /// // las tükid: &[[_;5]]= slice.as_chunks_unchecked()//Lõigu pikkus ei ole viie lubatud tükikese kordne:&[[_;0]]= slice.as_chunks_unchecked()//Nullpikkused tükid pole kunagi lubatud
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // OHUTUS: Meie eeltingimus on just see, mida selleks vaja on
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // OHUTUS: Valasime viilu `new_len * N` elemente
        // viil `new_len` paljudest `N` elementidest.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Jagab viilu osaks `N`-elementide massiivid, alustades viilu algusest, ja ülejäänud viil, mille pikkus on rangelt väiksem kui `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, kui `N` on 0. Enne selle meetodi stabiliseerumist muudetakse see kontroll tõenäoliselt kompileerimisaja veaks.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // OHUTUS: Oleme juba paanikas nulli ees ja selle tagab ehitus
        // et alamharu pikkus on N kordne.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Jagab viilu viiluks N-elemendi massiivid, alustades viilu lõpust, ja ülejäänud viil, mille pikkus on rangelt väiksem kui `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, kui `N` on 0. Enne selle meetodi stabiliseerumist muudetakse see kontroll tõenäoliselt kompileerimisaja veaks.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // OHUTUS: Oleme juba paanikas nulli ees ja selle tagab ehitus
        // et alamharu pikkus on N kordne.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Tagastab viilu `N` elementide iteraatori korraga, alustades viilu algusest.
    ///
    /// Tükid on massiiviited ja ei kattu.
    /// Kui `N` ei jaga viilu pikkust, jäetakse viimased kuni `N-1` elemendid välja ja neid saab leida iteraatori funktsioonist `remainder`.
    ///
    ///
    /// See meetod on [`chunks_exact`]-i üldine konstandiekvivalent.
    ///
    /// # Panics
    ///
    /// Panics, kui `N` on 0. Enne selle meetodi stabiliseerumist muudetakse see kontroll tõenäoliselt kompileerimisaja veaks.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Jagab viilu osaks `N`-elementide massiivid, eeldades, et ülejäänud osa pole.
    ///
    ///
    /// # Safety
    ///
    /// Seda võib nimetada ainult siis, kui
    /// - Lõik jaguneb täpselt N-elemenditükkideks (ehk `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // OHUTUS: 1-elemendilistel tükkidel pole kunagi ülejäänud osa
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // OHUTUS: viilu pikkus (6) on 3-kordne
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Need oleksid ebamõistlikud:
    /// // las tükid: &[[_;5]]= slice.as_chunks_unchecked_mut()//Lõigu pikkus ei ole viie lubatud tükikese kordne:&[[_;0]]= slice.as_chunks_unchecked_mut()//Nullpikkused tükid pole kunagi lubatud
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // OHUTUS: Meie eeltingimus on just see, mida selleks vaja on
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // OHUTUS: Valasime viilu `new_len * N` elemente
        // viil `new_len` paljudest `N` elementidest.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Jagab viilu osaks `N`-elementide massiivid, alustades viilu algusest, ja ülejäänud viil, mille pikkus on rangelt väiksem kui `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, kui `N` on 0. Enne selle meetodi stabiliseerumist muudetakse see kontroll tõenäoliselt kompileerimisaja veaks.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // OHUTUS: Oleme juba paanikas nulli ees ja selle tagab ehitus
        // et alamharu pikkus on N kordne.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Jagab viilu viiluks N-elemendi massiivid, alustades viilu lõpust, ja ülejäänud viil, mille pikkus on rangelt väiksem kui `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, kui `N` on 0. Enne selle meetodi stabiliseerumist muudetakse see kontroll tõenäoliselt kompileerimisaja veaks.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // OHUTUS: Oleme juba paanikas nulli ees ja selle tagab ehitus
        // et alamharu pikkus on N kordne.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Tagastab viilu `N` elementide iteraatori korraga, alustades viilu algusest.
    ///
    /// Tükid on muudetavad massiiviviited ja ei kattu.
    /// Kui `N` ei jaga viilu pikkust, jäetakse viimased kuni `N-1` elemendid välja ja neid saab leida iteraatori funktsioonist `into_remainder`.
    ///
    ///
    /// See meetod on [`chunks_exact_mut`]-i üldine konstandiekvivalent.
    ///
    /// # Panics
    ///
    /// Panics, kui `N` on 0. Enne selle meetodi stabiliseerumist muudetakse see kontroll tõenäoliselt kompileerimisaja veaks.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Tagastab iteraatori viilu `N` elementide kattuva windows-ga, alustades viilu algusest.
    ///
    ///
    /// See on [`windows`] konst generaalne ekvivalent.
    ///
    /// Kui `N` on suurem kui viilu suurus, ei tagasta windows.
    ///
    /// # Panics
    ///
    /// Panics, kui `N` on 0.
    /// Enne selle meetodi stabiliseerumist muudetakse see kontroll tõenäoliselt kompileerimisaja veaks.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Tagastab viilu `chunk_size` elementide iteraatori korraga, alustades viilu lõpust.
    ///
    /// Tükid on viilud ja ei kattu.Kui `chunk_size` ei jaga viilu pikkust, pole viimasel tükil `chunk_size` pikkust.
    ///
    /// Selle iteraatori variandi kohta, mis tagastab alati täpselt `chunk_size` elementide tükid, vaadake [`rchunks_exact`] ja sama iteraatori korral [`chunks`], kuid alustades viilu alguses.
    ///
    ///
    /// # Panics
    ///
    /// Panics, kui `chunk_size` on 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Tagastab viilu `chunk_size` elementide iteraatori korraga, alustades viilu lõpust.
    ///
    /// Tükid on muutuvad viilud ja ei kattu.Kui `chunk_size` ei jaga viilu pikkust, pole viimasel tükil `chunk_size` pikkust.
    ///
    /// Selle iteraatori variandi kohta, mis tagastab alati täpselt `chunk_size` elementide tükid, vaadake [`rchunks_exact_mut`] ja sama iteraatori korral [`chunks_mut`], kuid alustades viilu alguses.
    ///
    ///
    /// # Panics
    ///
    /// Panics, kui `chunk_size` on 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Tagastab viilu `chunk_size` elementide iteraatori korraga, alustades viilu lõpust.
    ///
    /// Tükid on viilud ja ei kattu.
    /// Kui `chunk_size` ei jaga viilu pikkust, jäetakse viimased kuni `chunk_size-1` elemendid välja ja neid saab leida iteraatori funktsioonist `remainder`.
    ///
    /// Kuna igal tükil on täpselt `chunk_size`-elemendid, saab kompilaator saadud koodi sageli paremini optimeerida kui [`chunks`]-i puhul.
    ///
    /// Selle iteraatori variandi kohta, mis tagastab ka ülejäänud osa väiksema tükina, vaadake [`rchunks`] ja sama iteraatori puhul [`chunks_exact`], kuid alustades viilu alguses.
    ///
    ///
    /// # Panics
    ///
    /// Panics, kui `chunk_size` on 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Tagastab viilu `chunk_size` elementide iteraatori korraga, alustades viilu lõpust.
    ///
    /// Tükid on muutuvad viilud ja ei kattu.
    /// Kui `chunk_size` ei jaga viilu pikkust, jäetakse viimased kuni `chunk_size-1` elemendid välja ja neid saab leida iteraatori funktsioonist `into_remainder`.
    ///
    /// Kuna igal tükil on täpselt `chunk_size`-elemendid, saab kompilaator saadud koodi sageli paremini optimeerida kui [`chunks_mut`]-i puhul.
    ///
    /// Selle iteraatori variandi kohta, mis tagastab ka ülejäänud osa väiksema tükina, vaadake [`rchunks_mut`] ja sama iteraatori puhul [`chunks_exact_mut`], kuid alustades viilu alguses.
    ///
    ///
    /// # Panics
    ///
    /// Panics, kui `chunk_size` on 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Tagastab viilu kohal iteraatori, mis toodab elementide kattuvaid jookse, kasutades predikaati nende eraldamiseks.
    ///
    /// Predikaat kutsutakse kahele enda järel järgnevale elemendile, see tähendab, et predikaati kutsutakse `slice[0]` ja `slice[1]`, seejärel `slice[1]` ja `slice[2]` jne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Seda meetodit saab kasutada sorteeritud alamrubriikide väljavõtmiseks:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Tagastab viilu kohal iteraatori, mis tekitab elementide kattuvaid muutuvaid jookse, kasutades predikaati nende eraldamiseks.
    ///
    /// Predikaat kutsutakse kahele enda järel järgnevale elemendile, see tähendab, et predikaati kutsutakse `slice[0]` ja `slice[1]`, seejärel `slice[1]` ja `slice[2]` jne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Seda meetodit saab kasutada sorteeritud alamrubriikide väljavõtmiseks:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Jagab ühe viilu indeksis kaheks.
    ///
    /// Esimene sisaldab kõiki indekse alates `[0, mid)`-st (välja arvatud indeks `mid` ise) ja teine sisaldab kõiki `[mid, len)`-i indekse (välja arvatud indeks `len` ise).
    ///
    ///
    /// # Panics
    ///
    /// Panics kui `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // OHUTUS: `[ptr; mid]` ja `[mid; len]` asuvad `self` sees, mis
        // vastab `from_raw_parts_mut` nõuetele.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Jagab ühe muutuva viilu indeksis kaheks.
    ///
    /// Esimene sisaldab kõiki indekse alates `[0, mid)`-st (välja arvatud indeks `mid` ise) ja teine sisaldab kõiki `[mid, len)`-i indekse (välja arvatud indeks `len` ise).
    ///
    ///
    /// # Panics
    ///
    /// Panics kui `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // OHUTUS: `[ptr; mid]` ja `[mid; len]` asuvad `self` sees, mis
        // vastab `from_raw_parts_mut` nõuetele.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Jagab ühe viilu indeksis kaheks, ilma piiride kontrollimiseta.
    ///
    /// Esimene sisaldab kõiki indekse alates `[0, mid)`-st (välja arvatud indeks `mid` ise) ja teine sisaldab kõiki `[mid, len)`-i indekse (välja arvatud indeks `len` ise).
    ///
    ///
    /// Ohutu alternatiivi leidmiseks vaadake [`split_at`].
    ///
    /// # Safety
    ///
    /// Selle meetodi kutsumine piiriülese indeksiga on *[määratlemata käitumine]*, isegi kui saadud viidet ei kasutata.Helistaja peab tagama, et `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // OHUTUS: Helistaja peab kontrollima, kas `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Jagab ühe muutuva viilu indeksis kaheks, ilma piiride kontrollimiseta.
    ///
    /// Esimene sisaldab kõiki indekse alates `[0, mid)`-st (välja arvatud indeks `mid` ise) ja teine sisaldab kõiki `[mid, len)`-i indekse (välja arvatud indeks `len` ise).
    ///
    ///
    /// Ohutu alternatiivi leidmiseks vaadake [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Selle meetodi kutsumine piiriülese indeksiga on *[määratlemata käitumine]*, isegi kui saadud viidet ei kasutata.Helistaja peab tagama, et `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // OHUTUS: Helistaja peab kontrollima, kas `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` ja `[mid; len]` ei kattu, seega on muudetava viite tagastamine hea.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Tagastab iteraatori alamrubriikidele, mis on eraldatud `pred`-ga vastavate elementidega.
    /// Sobitatud elementi ei sisalda alamlõiked.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Esimese elemendi sobitamisel on iteraatori tagastatud esimene element tühi viil.
    /// Samamoodi, kui viilu viimane element sobib, on tühi viil viimane kordaja tagastatud üksus:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Kui kaks sobitatud elementi asuvad otse kõrvuti, on nende vahel tühi viil:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Tagastab `pred`-iga sobivate elementidega eraldatud muudetavate alamrubriikide iteraatori.
    /// Sobitatud elementi ei sisalda alamlõiked.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Tagastab iteraatori alamrubriikidele, mis on eraldatud `pred`-ga vastavate elementidega.
    /// Sobitatud element sisaldub eelmise alamrühma lõpus terminatsioonina.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Kui viilu viimane element on sobitatud, loetakse seda elementi eelneva viilu lõpetajaks.
    ///
    /// See viil on viimane kordaja tagastatud üksus.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Tagastab `pred`-iga sobivate elementidega eraldatud muudetavate alamrubriikide iteraatori.
    /// Sobitatud element sisaldub eelmises alamterminis terminaatorina.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Tagastab iteraatori alamrubriikidele, mis on eraldatud `pred`-ga vastavate elementidega, alustades viilu lõpust ja töötades tagurpidi.
    /// Sobitatud elementi ei sisalda alamlõiked.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Nagu `split()` puhul, on esimese või viimase elemendi sobitamisel tühi viil esimene (või viimane) iteraatori tagastatud element.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Tagastab iteraatori muutuvate alamhulkade peale, mis on eraldatud `pred`-ga sobivate elementidega, alustades viilu lõpust ja töötades tagurpidi.
    /// Sobitatud elementi ei sisalda alamlõiked.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Tagastab iteraatori alamrubriikidele, mis on eraldatud `pred`-ga vastavate elementidega, piirdudes maksimaalselt `n`-üksuste tagastamisega.
    /// Sobitatud elementi ei sisalda alamlõiked.
    ///
    /// Viimane tagastatud element, kui see on olemas, sisaldab viilu ülejäänud osa.
    ///
    /// # Examples
    ///
    /// Prindige viil jagatud üks kord arvudega, mis jagunevad 3-ga (st `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Tagastab iteraatori alamrubriikidele, mis on eraldatud `pred`-ga vastavate elementidega, piirdudes maksimaalselt `n`-üksuste tagastamisega.
    /// Sobitatud elementi ei sisalda alamlõiked.
    ///
    /// Viimane tagastatud element, kui see on olemas, sisaldab viilu ülejäänud osa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Tagastab iteraatori alamrubriikidele, mis on eraldatud elementidega, mis vastavad `pred`-le, piirdudes maksimaalselt `n`-üksuste tagastamisega.
    /// See algab viilu lõpust ja töötab tagasi.
    /// Sobitatud elementi ei sisalda alamlõiked.
    ///
    /// Viimane tagastatud element, kui see on olemas, sisaldab viilu ülejäänud osa.
    ///
    /// # Examples
    ///
    /// Prindi viilujaotus üks kord, alustades lõpust, arvudega, mis jagunevad 3-ga (st `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Tagastab iteraatori alamrubriikidele, mis on eraldatud elementidega, mis vastavad `pred`-le, piirdudes maksimaalselt `n`-üksuste tagastamisega.
    /// See algab viilu lõpust ja töötab tagasi.
    /// Sobitatud elementi ei sisalda alamlõiked.
    ///
    /// Viimane tagastatud element, kui see on olemas, sisaldab viilu ülejäänud osa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Tagastab `true`, kui viil sisaldab antud väärtusega elementi.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Kui teil pole `&T`-i, vaid lihtsalt `&U`-i, nii et `T: Borrow<U>` (nt
    /// `String: laenake<str>`), saate kasutada `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // `String` viil
    /// assert!(v.iter().any(|e| e == "hello")); // otsige `&str`-iga
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Tagastab `true`, kui `needle` on viilu prefiks.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Tagastab alati `true`, kui `needle` on tühi viil:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Tagastab `true`, kui `needle` on viilu järelliide.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Tagastab alati `true`, kui `needle` on tühi viil:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Tagastab alajaotise, mille eesliide on eemaldatud.
    ///
    /// Kui viilu algab tähega `prefix`, tagastab `Some`-i mähituna eesliide järel alamharu.
    /// Kui `prefix` on tühi, tagastab lihtsalt algse viilu.
    ///
    /// Kui lõik ei alga tähega `prefix`, tagastab `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // See funktsioon vajab ümberkirjutamist, kui SlicePattern muutub keerukamaks.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Tagastab alaliigi, mille järelliide on eemaldatud.
    ///
    /// Kui viil lõpeb tähega `suffix`, tagastab alaliigi enne sufiksit `Some`-i mähituna.
    /// Kui `suffix` on tühi, tagastab lihtsalt algse viilu.
    ///
    /// Kui viil ei lõpe tähega `suffix`, tagastab `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // See funktsioon vajab ümberkirjutamist, kui SlicePattern muutub keerukamaks.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binaarne otsib antud elemendist seda sorteeritud viilu.
    ///
    /// Kui väärtus leitakse, tagastatakse [`Result::Ok`], mis sisaldab sobiva elemendi indeksit.
    /// Kui vasteid on mitu, siis võidakse ükskõik milline vaste tagastada.
    /// Kui väärtust ei leita, tagastatakse [`Result::Err`], mis sisaldab indeksit, kuhu sobiva elemendi saaks sisestada, säilitades järjestatud järjekorra.
    ///
    ///
    /// Vaadake ka [`binary_search_by`], [`binary_search_by_key`] ja [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Otsib nelja elemendi seeriat.
    /// Esimene on leitud, üheselt määratud positsiooniga;teist ja kolmandat ei leita;neljas võiks sobida mis tahes positsiooniga `[1, 4]`-is.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Kui soovite sisestada üksuse sorditud vector-sse, säilitades samas sortimisjärjestuse:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Binaarne otsib seda sorteeritud viilu võrdlusfunktsiooniga.
    ///
    /// Võrdlusfunktsioon peaks rakendama järjestuse, mis vastab aluseks oleva viilu sortimisjärjestusele, tagastades tellimiskoodi, mis näitab, kas selle argument on soovitud sihtmärk `Less`, `Equal` või `Greater`.
    ///
    ///
    /// Kui väärtus leitakse, tagastatakse [`Result::Ok`], mis sisaldab sobiva elemendi indeksit.Kui vasteid on mitu, siis võidakse ükskõik milline vaste tagastada.
    /// Kui väärtust ei leita, tagastatakse [`Result::Err`], mis sisaldab indeksit, kuhu sobiva elemendi saaks sisestada, säilitades järjestatud järjekorra.
    ///
    /// Vaadake ka [`binary_search`], [`binary_search_by_key`] ja [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Otsib nelja elemendi seeriat.Esimene on leitud, üheselt määratud positsiooniga;teist ja kolmandat ei leita;neljas võiks sobida mis tahes positsiooniga `[1, 4]`-is.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // OHUTUS: kõne teevad turvaliseks järgmised invariandid:
            // - `mid >= 0`
            // - `mid < size`: `mid` on piiratud `[left; right)`-ga seotud.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Põhjus, miks kasutame if/else-i juhtimisvoo asemel mängu, tuleneb sellest, et vaste järjestab võrdlustoimingud, mis on täiesti tundlik.
            //
            // See on u8-i jaoks x86 asm: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Binaarne otsib seda sorteeritud osa võtmeekstraktsiooniga.
    ///
    /// Eeldatakse, et lõik on sorteeritud võtme järgi, näiteks [`sort_by_key`]-iga, kasutades sama võtme väljavõtte funktsiooni.
    ///
    /// Kui väärtus leitakse, tagastatakse [`Result::Ok`], mis sisaldab sobiva elemendi indeksit.
    /// Kui vasteid on mitu, siis võidakse ükskõik milline vaste tagastada.
    /// Kui väärtust ei leita, tagastatakse [`Result::Err`], mis sisaldab indeksit, kuhu sobiva elemendi saaks sisestada, säilitades järjestatud järjekorra.
    ///
    ///
    /// Vaadake ka [`binary_search`], [`binary_search_by`] ja [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Otsib neljast elemendist koosnevat seeriat paaris, mis on järjestatud nende teiste elementide järgi.
    /// Esimene on leitud, üheselt määratud positsiooniga;teist ja kolmandat ei leita;neljas võiks sobida mis tahes positsiooniga `[1, 4]`-is.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links on lubatud, kuna `slice::sort_by_key` on rakenduses crate `alloc` ja `core`-i loomisel pole seda veel olemas.
    //
    // lingid allavoolu crate: #74481.Kuna primitiivid on dokumenteeritud ainult versioonis libstd (#73423), ei vii see praktikas kunagi katkiste linkideni.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Sorteerib viilu, kuid ei pruugi säilitada võrdsete elementide järjekorda.
    ///
    /// See sort on ebastabiilne (st võib järjestada võrdsed elemendid), paigas (st ei eralda) ja *O*(*n*\*log(* n*)) halvimal juhul.
    ///
    /// # Praegune rakendamine
    ///
    /// Praegune algoritm põhineb Orson Petersi [pattern-defeating quicksort][pdqsort]-il, mis ühendab randomiseeritud kiirkorduse keskmise keskmise juhtumi kiireima halvima hulga juhtumiga, saavutades samal ajal lineaarse aja teatud mustritega viiludel.
    /// Taandarengute vältimiseks kasutab see mõnda randomiseerimist, kuid fikseeritud seed abil tagab alati deterministliku käitumise.
    ///
    /// See on tavaliselt kiirem kui stabiilne sorteerimine, välja arvatud mõned erijuhud, nt kui viil koosneb mitmest liidetud järjestatud järjestusest.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Sorteerib viilu võrdlusfunktsiooniga, kuid ei pruugi säilitada võrdsete elementide järjekorda.
    ///
    /// See sort on ebastabiilne (st võib järjestada võrdsed elemendid), paigas (st ei eralda) ja *O*(*n*\*log(* n*)) halvimal juhul.
    ///
    /// Võrdlusfunktsioon peab määrama kogu viilu elementide järjestuse.Kui tellimine pole täielik, pole elementide järjestus täpsustatud.Tellimus on kogu tellimus, kui see on (kõigi `a`, `b` ja `c` puhul):
    ///
    /// * kokku ja antisümmeetriline: täpselt üks `a < b`, `a == b` või `a > b` on tõene ja
    /// * transitiivne, `a < b` ja `b < c` tähendab `a < c`.Sama kehtib nii `==` kui ka `>` puhul.
    ///
    /// Näiteks kui [`f64`] ei rakenda [`Ord`]-i, kuna `NaN != NaN`, võime `partial_cmp`-i kasutada oma sortimisfunktsioonina, kui teame, et lõik ei sisalda `NaN`-i.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Praegune rakendamine
    ///
    /// Praegune algoritm põhineb Orson Petersi [pattern-defeating quicksort][pdqsort]-il, mis ühendab randomiseeritud kiirkorduse keskmise keskmise juhtumi kiireima halvima hulga juhtumiga, saavutades samal ajal lineaarse aja teatud mustritega viiludel.
    /// Taandarengute vältimiseks kasutab see mõnda randomiseerimist, kuid fikseeritud seed abil tagab alati deterministliku käitumise.
    ///
    /// See on tavaliselt kiirem kui stabiilne sorteerimine, välja arvatud mõned erijuhud, nt kui viil koosneb mitmest liidetud järjestatud järjestusest.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // vastupidine sortimine
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Sorteerib viilu võtmeekstraktsiooniga, kuid ei pruugi säilitada võrdsete elementide järjekorda.
    ///
    /// See sort on ebastabiilne (st võib järjestada võrdsed elemendid), paigas (st ei eralda) ja *O*(m\* * n *\* log(*n*)) halvimal juhul, kui võtme funktsioon on *O*(*m*).
    ///
    /// # Praegune rakendamine
    ///
    /// Praegune algoritm põhineb Orson Petersi [pattern-defeating quicksort][pdqsort]-il, mis ühendab randomiseeritud kiirkorduse keskmise keskmise juhtumi kiireima halvima hulga juhtumiga, saavutades samal ajal lineaarse aja teatud mustritega viiludel.
    /// Taandarengute vältimiseks kasutab see mõnda randomiseerimist, kuid fikseeritud seed abil tagab alati deterministliku käitumise.
    ///
    /// Põhilise helistamisstrateegia tõttu on [`sort_unstable_by_key`](#method.sort_unstable_by_key) tõenäoliselt aeglasem kui [`sort_by_cached_key`](#method.sort_by_cached_key) juhtudel, kui võtmefunktsioon on kallis.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Järjestage viil ümber nii, et `index`-i element oleks sorditud viimases asendis.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Järjestage viil võrdlusfunktsiooniga ümber nii, et `index`-i element oleks lõplikus sorteeritud positsioonis.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Järjestage viil võtmeekstraktsiooniga ümber nii, et `index`-i element oleks sorditud viimases asendis.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Järjestage viil ümber nii, et `index`-i element oleks sorditud viimases asendis.
    ///
    /// Sellel ümberjärjestamisel on täiendav omadus, et mis tahes väärtus positsioonil `i < index` on väiksem või võrdne mis tahes väärtusega positsioonil `j > index`.
    /// Lisaks on see ümberjärjestamine ebastabiilne (st
    /// suvaline arv võrdseid elemente võib sattuda asendisse `index`), paigale (st
    /// ei eralda) ja *O*(*n*) halvimal juhul.
    /// See funktsioon on/tuntud ka kui "kth element" teistes raamatukogudes.
    /// See tagastab kolmikute järgmistest väärtustest: kõik elemendid, mis on väiksemad kui antud indeksil, väärtus antud indeksis ja kõik elemendid, mis on suuremad kui antud indeksis.
    ///
    ///
    /// # Praegune rakendamine
    ///
    /// Praegune algoritm põhineb sama quicksorti algoritmi [`sort_unstable`] jaoks kasutatud kiirvalikul.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics kui `index >= len()`, see tähendab, et tühjadel viiludel on see alati panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Leidke mediaan
    /// v.select_nth_unstable(2);
    ///
    /// // Meile tagatakse ainult see, et viil on üks järgmistest, lähtudes viisist, kuidas me määratud indeksit sorteerime.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Järjestage viil võrdlusfunktsiooniga ümber nii, et `index`-i element oleks lõplikus sorteeritud positsioonis.
    ///
    /// Sellel ümberjärjestamisel on täiendav omadus, et kõik väärtused positsioonil `i < index` on võrdlusfunktsiooni kasutades väiksemad või võrdsed mis tahes väärtustega positsioonil `j > index`.
    /// Lisaks on see ümberjärjestamine ebastabiilne (st suvaline arv võrdseid elemente võib sattuda positsiooni `index`), paigas (st ei eralda) ja halvimal juhul *O*(*n*).
    /// Seda funktsiooni tuntakse teistes raamatukogudes ka kui "kth element".
    /// See tagastab kolmikute järgmistest väärtustest: kõik elemendid, mis on väiksemad kui antud indeksil, väärtus antud indeksis ja kõik elemendid, mis on suuremad kui antud indeksis, kasutades selleks antud võrdlusfunktsiooni.
    ///
    ///
    /// # Praegune rakendamine
    ///
    /// Praegune algoritm põhineb sama quicksorti algoritmi [`sort_unstable`] jaoks kasutatud kiirvalikul.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics kui `index >= len()`, see tähendab, et tühjadel viiludel on see alati panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Leidke mediaan, nagu oleks viil sorteeritud kahanevas järjekorras.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Meile tagatakse ainult see, et viil on üks järgmistest, lähtudes viisist, kuidas me määratud indeksit sorteerime.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Järjestage viil võtmeekstraktsiooniga ümber nii, et `index`-i element oleks sorditud viimases asendis.
    ///
    /// Sellel ümberjärjestamisel on täiendav omadus, et kõik väärtused positsioonil `i < index` on väiksemad või võrdsed mis tahes väärtustega positsioonil `j > index`, kasutades võtmeekstraktsiooni.
    /// Lisaks on see ümberjärjestamine ebastabiilne (st suvaline arv võrdseid elemente võib sattuda positsiooni `index`), paigas (st ei eralda) ja halvimal juhul *O*(*n*).
    /// Seda funktsiooni tuntakse teistes raamatukogudes ka kui "kth element".
    /// See tagastab kolmikute järgmistest väärtustest: kõik elemendid, mis on väiksemad kui antud indeksis, väärtus antud indeksis ja kõik elemendid, mis on suuremad kui antud indeksis, kasutades selleks antud võtmeekstraktsiooni funktsiooni.
    ///
    ///
    /// # Praegune rakendamine
    ///
    /// Praegune algoritm põhineb sama quicksorti algoritmi [`sort_unstable`] jaoks kasutatud kiirvalikul.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics kui `index >= len()`, see tähendab, et tühjadel viiludel on see alati panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Tagastage mediaan nii, nagu oleks massiiv sorditud absoluutväärtuse järgi.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Meile tagatakse ainult see, et viil on üks järgmistest, lähtudes viisist, kuidas me määratud indeksit sorteerime.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Liigutab kõik järjestikused korduvad elemendid viilu lõppu vastavalt [`PartialEq`] trait teostusele.
    ///
    ///
    /// Tagastab kaks viilu.Esimene ei sisalda järjestikuseid korduvaid elemente.
    /// Teine sisaldab kõiki duplikaate kindlas järjekorras.
    ///
    /// Kui viil on sorteeritud, ei sisalda esimene tagastatud viil duplikaate.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Liigutab kõik järjestikuste elementide, välja arvatud esimese, viilu lõppu, mis vastab antud võrdsussuhtele.
    ///
    /// Tagastab kaks viilu.Esimene ei sisalda järjestikuseid korduvaid elemente.
    /// Teine sisaldab kõiki duplikaate kindlas järjekorras.
    ///
    /// Funktsioon `same_bucket` edastatakse viide kahele elemendile viimist ja see peab määrama, kas elemendid on võrdsed.
    /// Elemendid edastatakse viilu järjestuses vastupidises järjekorras, nii et kui `same_bucket(a, b)` tagastab `true`, liigutatakse `a` viilu lõpus.
    ///
    ///
    /// Kui viil on sorteeritud, ei sisalda esimene tagastatud viil duplikaate.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Kuigi meil on muutuv viide `self`-ile, ei saa me *suvalisi* muudatusi teha.`same_bucket` kõned võiksid olla panic, seega peame tagama, et viil oleks kogu aeg kehtivas olekus.
        //
        // Sellega tegeleme vahetustehingute abil;me kordame kõiki elemente, vahetades käigu pealt nii, et lõpuks jäävad elemendid, mida me soovime hoida, ees ja need, mida me tahame tagasi lükata.
        // Seejärel saame viilu jagada.
        // See toiming on endiselt `O(n)`.
        //
        // Näide: alustame sellest olekust, kus `r` tähistab "järgmine"
        // loe "ja `w` tähistab" järgmine_kirjutada ".
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Kui võrrelda self[r]-d iseendaga [w-1], pole see duplikaat, seega vahetame self[r] ja self[w] (pole efekti, kuna r==w) ja seejärel suurendame nii r kui w, jättes meile:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Võrreldes self[r]-i iseendaga [w-1], on see väärtus duplikaat, seega suurendame `r`-i, kuid kõik muu jätame muutmata:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Kui võrrelda self[r]-i enda [w-1]-ga, pole see duplikaat, seega vahetage self[r] ja self[w] ning liigutage r ja w edasi:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Pole duplikaat, korda:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Duplikaat, advance r. End viilu.Jagatud w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // OHUTUS: `while` tingimus tagab `next_read` ja `next_write`
        // on väiksemad kui `len`, seega jäävad `self` sisse.
        // `prev_ptr_write` osutab ühele elemendile enne `ptr_write`, kuid `next_write` algab 1-st, seega pole `prev_ptr_write` kunagi väiksem kui 0 ja asub viilu sees.
        // See vastab `ptr_read`, `prev_ptr_write` ja `ptr_write` alandamise ning `ptr.add(next_read)`, `ptr.add(next_write - 1)` ja `prev_ptr_write.offset(1)` kasutamise nõuetele.
        //
        //
        // `next_write` suureneb ka maksimaalselt üks kord tsükli kohta, see tähendab, et ühtegi elementi ei jäeta vahele, kui see võib vajada vahetamist.
        //
        // `ptr_read` ja `prev_ptr_write` ei osuta kunagi samale elemendile.See on vajalik, et `&mut *ptr_read`, `&mut* prev_ptr_write` oleksid ohutud.
        // Seletus on lihtsalt see, et `next_read >= next_write` on alati tõene, seega on ka `next_read > next_write - 1`.
        //
        //
        //
        //
        //
        unsafe {
            // Vältige piirikontrolli, kasutades tooreid näpunäiteid.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Viib kõik, välja arvatud järjestikused elemendid, viilu lõppu, mis lahendab sama võtme.
    ///
    ///
    /// Tagastab kaks viilu.Esimene ei sisalda järjestikuseid korduvaid elemente.
    /// Teine sisaldab kõiki duplikaate kindlas järjekorras.
    ///
    /// Kui viil on sorteeritud, ei sisalda esimene tagastatud viil duplikaate.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Pöörab viilu paigas nii, et viilu esimesed `mid` elemendid liiguvad lõpuni, viimased `self.len() - mid` elemendid aga edasi.
    /// Pärast `rotate_left`-ile helistamist muutub varem indeksis `mid` olev element viilu esimeseks elemendiks.
    ///
    /// # Panics
    ///
    /// See funktsioon on panic, kui `mid` on suurem kui viilu pikkus.Pange tähele, et `mid == self.len()` teeb _not_ panic ja on pöörlemiskiirus.
    ///
    /// # Complexity
    ///
    /// Võtab lineaarse (`self.len()`)-ajas.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Alalõike pööramine:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // OHUTUS: Vahemik `[p.add(mid) - mid, p.add(mid) + k)` on triviaalne
        // kehtib lugemiseks ja kirjutamiseks, nagu nõuab `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Pöörab viilu paigas nii, et viilu esimesed `self.len() - k` elemendid liiguvad lõpuni, viimased `k` elemendid aga edasi.
    /// Pärast `rotate_right`-ile helistamist muutub varem indeksis `self.len() - k` olev element viilu esimeseks elemendiks.
    ///
    /// # Panics
    ///
    /// See funktsioon on panic, kui `k` on suurem kui viilu pikkus.Pange tähele, et `k == self.len()` teeb _not_ panic ja on pöörlemiskiirus.
    ///
    /// # Complexity
    ///
    /// Võtab lineaarse (`self.len()`)-ajas.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Alamaluse pööramine:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // OHUTUS: Vahemik `[p.add(mid) - mid, p.add(mid) + k)` on triviaalne
        // kehtib lugemiseks ja kirjutamiseks, nagu nõuab `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Täidab `self` elementidega, kloonides `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Täidab `self` elementidega, mis tagastatakse korduvalt sulgemisele helistades.
    ///
    /// See meetod kasutab uute väärtuste loomiseks sulgemist.Kui soovite [`Clone`]-i antud väärtuse asemel kasutada [`fill`]-i.
    /// Kui soovite väärtuste loomiseks kasutada seadet [`Default`] trait, võite argumendina edastada [`Default::default`].
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Kopeerib elemendid `src`-ist `self`-i.
    ///
    /// `src` pikkus peab olema sama mis `self`.
    ///
    /// Kui `T` rakendab `Copy`-i, võib [`copy_from_slice`]-i kasutamine olla tulemuslikum.
    ///
    /// # Panics
    ///
    /// See funktsioon on panic, kui kahel lõigul on erinev pikkus.
    ///
    /// # Examples
    ///
    /// Kahe elemendi kloonimine viilust teise:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Kuna viilud peavad olema ühepikkused, viilutame lähteosa neljast elemendist kaheks.
    /// // Kui me seda ei tee, saab see panic.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust jõustab, et saab olla ainult üks muudetav viide, millel ei ole muutumatuid viiteid teatud ulatusega konkreetsele andmetele.
    /// Seetõttu põhjustab `clone_from_slice`-i kasutamise üksik viil kompileerimise tõrke:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Selle lahendamiseks saame [`split_at_mut`]-iga luua viilust kaks erinevat alamviilu:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Kopeerib kõik elemendid failist `src` mällu `self`, kasutades memcpy-d.
    ///
    /// `src` pikkus peab olema sama mis `self`.
    ///
    /// Kui `T` ei rakenda `Copy`-i, kasutage [`clone_from_slice`]-i.
    ///
    /// # Panics
    ///
    /// See funktsioon on panic, kui kahel lõigul on erinev pikkus.
    ///
    /// # Examples
    ///
    /// Kahe elemendi kopeerimine viilust teise:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Kuna viilud peavad olema ühepikkused, viilutame lähteosa neljast elemendist kaheks.
    /// // Kui me seda ei tee, saab see panic.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust jõustab, et saab olla ainult üks muudetav viide, millel ei ole muutumatuid viiteid teatud ulatusega konkreetsele andmetele.
    /// Seetõttu põhjustab `copy_from_slice`-i kasutamise üksik viil kompileerimise tõrke:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Selle lahendamiseks saame [`split_at_mut`]-iga luua viilust kaks erinevat alamviilu:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // panic kooditee viidi külma funktsiooni, et kõnesait ei paisuks.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // OHUTUS: `self` kehtib `self.len()` elementide jaoks definitsiooni järgi ja `src` oli
        // kontrolliti, kas neil on sama pikkus.
        // Lõigud ei saa kattuda, kuna muudetavad viited on välistavad.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Kopeerib elemendid viilu ühest osast enda teise ossa, kasutades memmove'i.
    ///
    /// `src` on vahemik `self` piires, kust kopeerida.
    /// `dest` on `self`-i vahemiku algindeks, kuhu kopeerida, mis on sama pikk kui `src`.
    /// Need kaks vahemikku võivad kattuda.
    /// Kahe vahemiku otsad peavad olema väiksemad kui `self.len()` või sellega võrdsed.
    ///
    /// # Panics
    ///
    /// See funktsioon on panic, kui kumbki vahemik ületab viilu lõppu või kui `src` lõpp on enne algust.
    ///
    ///
    /// # Examples
    ///
    /// Nelja baiti viilust kopeerimine:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // OHUTUS: kõik `ptr::copy`-i tingimused on eespool kontrollitud,
        // nagu ka `ptr::add` omad.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Vahetab kõik `self`-i elemendid `other`-i elementidega.
    ///
    /// `other` pikkus peab olema sama mis `self`.
    ///
    /// # Panics
    ///
    /// See funktsioon on panic, kui kahel lõigul on erinev pikkus.
    ///
    /// # Example
    ///
    /// Kahe elemendi vahetamine viilude vahel:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust jõustab, et kindlas ulatuses võib olla ainult üks muudetav viide konkreetsele andmetele.
    ///
    /// Seetõttu põhjustab `swap_with_slice`-i kasutamise üksik viil kompileerimise tõrke:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Selle vältimiseks saame [`split_at_mut`] abil luua viilust kaks erinevat muudetavat alamviilu:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // OHUTUS: `self` kehtib `self.len()` elementide jaoks definitsiooni järgi ja `src` oli
        // kontrolliti, kas neil on sama pikkus.
        // Lõigud ei saa kattuda, kuna muudetavad viited on välistavad.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Funktsioon `align_to{,_mut}` keskmise ja tagumise osa pikkuste arvutamiseks.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Mida me `rest`-i puhul ette võtame, on välja selgitada, millise hulga U-d saame panna väikseimasse arvu T-d.
        //
        // Ja kui palju `` T '' on meil vaja iga sellise "multiple" jaoks.
        //
        // Vaatleme näiteks T=u8 U=u16.Siis saame panna 1 U 2 Ts-i.Lihtne.
        // Vaatleme näiteks juhtumit, kus size_of: :<T>=16, suurus: <U>=24.</u>
        // Saame `rest` viilus iga 3 Ts asemel panna 2 Us.
        // Natuke keerulisem.
        //
        // Selle arvutamiseks on valem:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Laiendatud ja lihtsustatud:
        //
        // Meie=suurus: <T>/gcd(size_of::<T>, size_of::<U>) Ts=suurus: <U>//gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Õnneks, kuna seda kõike hinnatakse pidevalt ..., pole siin esinemine oluline!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // iteratiivse steini algoritm Peaksime ikkagi selle `const fn`-i tegema (ja pöörduma tagasi rekursiivsele algoritmile), sest selle kõige piiritlemisel on tuginemine llvm-le ... noh, see teeb mind ebamugavaks.
            //
            //

            // OHUTUS: kontrollitakse, et `a` ja `b` pole nullist erinevad.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // eemaldage b-st kõik tegurid 2
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // OHUTUS: `b` on kontrollitud nullist erinevaks.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Selle teadmisega relvastatud võime leida, kui palju U-sid mahub!
        let us_len = self.len() / ts * us;
        // Ja kui palju `T'-sid jääb lõppviilu!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Teisendage viil teist tüüpi viiluks, tagades tüüpide joondamise.
    ///
    /// See meetod jagab viilu kolmeks erinevaks viiluks: eesliide, õigesti joondatud uut tüüpi keskmine viil ja sufiksiviil.
    /// Meetod võib muuta keskmise viilu antud tüübi ja sisendviilu jaoks võimalikult suureks, kuid sellest peaks sõltuma ainult teie algoritmi jõudlus, mitte selle õigsus.
    ///
    /// On lubatud, et kõik sisendandmed tagastatakse eesliite või sufiksiviiluna.
    ///
    /// Sellel meetodil pole eesmärki, kui sisendelement `T` või väljundelement `U` on nullsuurused ja tagastavad algse viilu ilma midagi jagamata.
    ///
    /// # Safety
    ///
    /// See meetod on tagastatud keskmise viilu elementide suhtes sisuliselt `transmute`, seega kehtivad ka siin kõik tavalised `transmute::<T, U>`-ga seotud hoiatused.
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Pange tähele, et enamikku sellest funktsioonist hinnatakse pidevalt,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // käsitsege spetsiaalselt ZST-sid, mis on-ärge neid üldse käsitsege.
            return (self, &[], &[]);
        }

        // Esmalt leidke, millisel hetkel jagame esimese ja teise viilu.
        // ptr.align_offset-iga on lihtne.
        let ptr = self.as_ptr();
        // OHUTUS: üksikasjaliku ohutusjuhise saamiseks vaadake meetodit `align_to_mut`.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // OHUTUS: nüüd on `rest` kindlasti joondatud, nii et allpool olev `from_raw_parts` on korras,
            // kuna helistaja tagab, et saame `T`-i `U`-i ohutult teisendada.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Teisendage viil teist tüüpi viiluks, tagades tüüpide joondamise.
    ///
    /// See meetod jagab viilu kolmeks erinevaks viiluks: eesliide, õigesti joondatud uut tüüpi keskmine viil ja sufiksiviil.
    /// Meetod võib muuta keskmise viilu antud tüübi ja sisendviilu jaoks võimalikult suureks, kuid sellest peaks sõltuma ainult teie algoritmi jõudlus, mitte selle õigsus.
    ///
    /// On lubatud, et kõik sisendandmed tagastatakse eesliite või sufiksiviiluna.
    ///
    /// Sellel meetodil pole eesmärki, kui sisendelement `T` või väljundelement `U` on nullsuurused ja tagastavad algse viilu ilma midagi jagamata.
    ///
    /// # Safety
    ///
    /// See meetod on tagastatud keskmise viilu elementide suhtes sisuliselt `transmute`, seega kehtivad ka siin kõik tavalised `transmute::<T, U>`-ga seotud hoiatused.
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Pange tähele, et enamikku sellest funktsioonist hinnatakse pidevalt,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // käsitsege spetsiaalselt ZST-sid, mis on-ärge neid üldse käsitsege.
            return (self, &mut [], &mut []);
        }

        // Esmalt leidke, millisel hetkel jagame esimese ja teise viilu.
        // ptr.align_offset-iga on lihtne.
        let ptr = self.as_ptr();
        // OHUTUS: Siin tagame, et kasutame U jaoks joondatud viiteid
        // ülejäänud meetod.Seda tehes suunatakse kursor&[T]-le koos joondusega, mis on suunatud U-le.
        // `crate::ptr::align_offset` kutsutakse õigesti joondatud ja kehtiva osutiga `ptr` (see tuleneb viitest `self`) ja suurusega, mis on kahe võimsus (kuna see pärineb U joondusest), rahuldades selle ohutuspiiranguid.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Me ei saa pärast seda uuesti `rest`-i kasutada, see muudaks selle pseudonüümi `mut_ptr` kehtetuks!OHUTUS: vaadake `align_to` kommentaare.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Kontrollib, kas selle viilu elemendid on sorteeritud.
    ///
    /// See tähendab, et iga elemendi `a` ja sellele järgneva elemendi `b` puhul peab `a <= b` kehtima.Kui viil annab täpselt nulli või ühe elemendi, tagastatakse `true`.
    ///
    /// Pange tähele, et kui `Self::Item` on ainult `PartialOrd`, kuid mitte `Ord`, tähendab ülaltoodud määratlus, et see funktsioon tagastab `false`, kui kaks järjestikust üksust pole võrreldavad.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Kontrollib, kas selle viilu elemendid on antud võrdlusfunktsiooni abil sorteeritud.
    ///
    /// `PartialOrd::partial_cmp` kasutamise asemel kasutab see funktsioon antud funktsiooni `compare` kahe elemendi järjestuse määramiseks.
    /// Peale selle on see samaväärne [`is_sorted`]-iga;Lisateavet leiate selle dokumentatsioonist.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Kontrollib, kas antud viilu elemendid on antud võtmeekstraktsiooni abil sorteeritud.
    ///
    /// Selle asemel, et viilu elemente otse võrrelda, võrdleb see funktsioon elementide võtmeid, mille määrab `f`.
    /// Peale selle on see samaväärne [`is_sorted`]-iga;Lisateavet leiate selle dokumentatsioonist.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Tagastab jaotuspunkti indeksi vastavalt predikaadile (teise partitsiooni esimese elemendi indeks).
    ///
    /// Eeldatakse, et viil jaotatakse vastavalt antud predikaadile.
    /// See tähendab, et kõik elemendid, mille puhul predikaat vastab tõele, on viilu alguses ja kõik elemendid, mille predikaat tagastab vale, on lõpus.
    ///
    /// Näiteks [7, 15, 3, 5, 4, 12, 6] on jagatud predikaadi x% 2 all!=0 (kõik paaritu arvud on alguses, kõik isegi lõpus).
    ///
    /// Kui seda osa pole jaotatud, on tagastatav tulemus täpsustamata ja mõttetu, kuna see meetod teostab omamoodi kahendotsingu.
    ///
    /// Vaadake ka [`binary_search`], [`binary_search_by`] ja [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // OHUTUS: Kui `left < right`, `left <= mid < right`.
            // Seetõttu suureneb `left` alati ja `right` väheneb ning valitakse üks neist.Mõlemal juhul on `left <= right` täidetud.Seega, kui `left < right` on etapis, on `left <= right` järgmises etapis rahul.
            //
            // Seega seni, kuni `left != right`, on `0 <= left < right <= len` rahul ja kui ka see juhtum `0 <= mid < len` on rahul.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Peame need viilutama sõnaselgelt sama pikkusega
        // et optimeerijal oleks lihtsam piirikontrolli välja elada.
        // Kuid kuna sellele ei saa loota, on meil ka selgesõnaline spetsialiseerumine T: Copy'le.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Loob tühja viilu.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Loob muudetava tühja viilu.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Viilude mustreid kasutavad praegu ainult `strip_prefix` ja `strip_suffix`.
/// Loodame future punktis üldistada `core::str::Pattern` (mis kirjutamise ajal piirdub `str`-ga) viiludeks ja siis see trait asendatakse või kaotatakse.
///
pub trait SlicePattern {
    /// Sobiva viilu elemendi tüüp.
    type Item;

    /// Praegu vajavad `SlicePattern`-i tarbijad viilu.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}