// Algne teostus on võetud rust-memchrist.
// Autoriõigus 2015 Andrew Gallant, bluss ja Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Kasutage kärpimist.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Tagastab `true`, kui `x` sisaldab mis tahes nullbaiti.
///
/// Saates *Matters Computational*, J. Arndt:
///
/// "Idee on lahutada igast baidist üks ja seejärel otsida baite, kus laen levis kuni kõige olulisemani
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Tagastab esimese baidile `x` vastava indeksi `text`-is.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Kiire tee väikeste viilude jaoks
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Otsige ühe baidi väärtust, lugedes korraga kahte `usize` sõna.
    //
    // Jagage `text` kolmes osas
    // - algusosa joondamata, enne esimese sõna joondatud aadressi tekstis
    // - keha, skannige 2 sõna kaupa korraga
    // - viimane järelejäänud osa, <2 sõna

    // otsige joondatud piirini
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // otsige teksti põhiosa
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // OHUTUS: while predikaat tagab vähemalt 2 * usize_baiti vahemaa
        // viilu nihke ja lõpu vahel.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // katkesta, kui on vastav bait
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Leidke bait pärast seda, kui keha silmus peatus.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Tagastab viimase baidile `x` vastava indeksi `text`-is.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Otsige ühe baidi väärtust, lugedes korraga kahte `usize` sõna.
    //
    // Split `text` kolmes osas:
    // - joondamata saba pärast teksti viimase sõna joondatud aadressi,
    // - keha, skannitud 2 sõnaga korraga,
    // - esimesed ülejäänud baidid, <2 sõna.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Nimetame seda lihtsalt ees-ja järelliite pikkuse saamiseks.
        // Keskel töötleme alati kaks tükki korraga.
        // OHUTUS: `[u8]`-i muundamine `[usize]`-i on ohutu, välja arvatud `align_to` poolt hallatavad suuruste erinevused.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Otsige teksti põhiosas ja veenduge, et me ei ületaks min_aligned_offset.
    // nihe on alati joondatud, seega piisab vaid `>` testimisest ja välditakse võimalikku ülevoolu.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // OHUTUS: nihe algab väärtusest len, suffix.len(), kui see on suurem kui
        // min_aligned_offset (prefix.len()), ülejäänud vahemaa on vähemalt 2 * tükki_baiti.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Katkesta, kui on vastav bait.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Leidke bait enne seda, kui keha silmus peatus.
    text[..offset].iter().rposition(|elt| *elt == x)
}