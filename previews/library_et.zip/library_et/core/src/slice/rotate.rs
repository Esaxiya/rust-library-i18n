// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Pöörab vahemikku `[mid-left, mid+right)` nii, et `mid`-i elemendist saab esimene element.Samamoodi pöörab vahemikku `left` elemendid vasakule või `right` elemente paremale.
///
/// # Safety
///
/// Määratud vahemik peab kehtima lugemiseks ja kirjutamiseks.
///
/// # Algorithm
///
/// Algoritmi 1 kasutatakse `left + right` väikeste väärtuste või suurte `T` korral.
/// Elemendid viiakse oma lõppasenditesse ükshaaval, alustades punktist `mid - left` ja liikudes edasi `right` sammudega modulo `left + right`, nii et vaja läheb ainult ühte ajutist.
/// Lõpuks jõuame tagasi `mid - left`-i.
/// Kui aga `gcd(left + right, right)` ei ole 1, jäeti ülaltoodud toimingud elementidest üle.
/// Näiteks:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Õnneks on lõpetatud elementide vahel vahele jäetud elementide arv alati võrdne, nii et saame lihtsalt oma algpositsiooni kompenseerida ja teha rohkem voore (voorude koguarv on `gcd(left + right, right)` value).
///
/// Lõpptulemus on see, et kõik elemendid vormistatakse üks kord ja ainult üks kord.
///
/// Algoritmi 2 kasutatakse juhul, kui `left + right` on suur, kuid `min(left, right)` on piisavalt väike, et mahutada virna puhvrisse.
/// `min(left, right)` elemendid kopeeritakse puhvrisse, `memmove` rakendatakse teistele ja puhvris olevad elemendid viiakse tagasi auku, mis asub nende vastasküljel.
///
/// Algoritmid, mida saab vektoriseerida, ületavad ülaltoodut, kui `left + right` muutub piisavalt suureks.
/// Algoritmi 1 saab vektoriseerida tükeldades ja sooritades korraga mitu vooru, kuid keskmiselt on liiga vähe voore, kuni `left + right` on tohutu, ja ühe vooru halvim juhtum on alati olemas.
/// Selle asemel kasutab algoritm 3 `min(left, right)`-i elementide korduvat vahetamist, kuni jääb väiksem pööramisprobleem.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// kui `left < right` toimub vahetamine hoopis vasakult.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. allpool toodud algoritmid võivad ebaõnnestuda, kui neid juhtumeid ei kontrollita
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algoritm 1 mikromärgid näitavad, et juhuslike vahetuste keskmine jõudlus on kogu tee parem kuni umbes `left + right == 32`-ni, kuid halvimal juhul puruneb jõudlus isegi umbes 16-ni.
            // 24 valiti keskteeks.
            // Kui `T` suurus on suurem kui 4 kasutatavat, edestab see algoritm ka teisi algoritme.
            //
            //
            let x = unsafe { mid.sub(left) };
            // esimese ringi algus
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` `gcd(left + right, right)` arvutamise teel saab enne käsitsi leida, kuid on kiirem teha üks silmus, mis arvutab kõrvalmõjuna gcd, tehes siis ülejäänud osa
            //
            //
            let mut gcd = right;
            // Võrdlusuuringud näitavad, et kiirem on kogu aeg ajutine vahetada selle asemel, et üks ajutine üks kord läbi lugeda, tagurpidi kopeerida ja siis see ajutine lõpus kirjutada.
            // See võib olla tingitud asjaolust, et ajutiste andmete vahetamine või asendamine kasutab tsüklis ainult ühte mäluaadressi, selle asemel, et oleks vaja hallata kahte.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // selle asemel, et `i`-i suurendada ja seejärel kontrollida, kas see on väljaspool piire, kontrollime, kas `i` läheb järgmisel sammul väljaspool piire.
                // See hoiab ära osuti või `usize` mähkimise.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // esimese ringi lõpp
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // see tingimus peab olema siin, kui `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // viimistlege tükk veel mitme ringiga
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` ei ole nullsuurune tüüp, seega on okei jagada selle suurusega.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritm 2 `[T; 0]` peab siin tagama, et see oleks T jaoks sobivalt joondatud
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritm 3 Vahetamiseks on alternatiivne viis, mis hõlmab selle algoritmi viimase vahetuse leidmist ja selle viimase tüki kasutamist selle asemel, et vahetada külgnevaid tükke, nagu see algoritm teeb, kuid see viis on siiski kiirem.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // 3. algoritm, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}