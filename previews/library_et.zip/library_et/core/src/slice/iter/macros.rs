//! Viilude iteraatorite kasutatud makrod.

// Sisestades is_empty ja len, on tohutu jõudluse erinevus
macro_rules! is_empty {
    // See, kuidas kodeerime ZST iteraatori pikkust, töötab nii ZST kui ka mitte ZST puhul.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Mõnest piirikontrollist (vt `position`) vabanemiseks arvutame pikkuse mõnevõrra ootamatul viisil.
// (Testitud "codegen/slice-position-bounds-check" abil.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // meid kasutatakse mõnikord ebaturvalises plokis

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // See _cannot_ kasutab `unchecked_sub`-i, kuna sõltume pikkade ZST-viilu iteraatorite pikkuse pakkimisest.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Me teame, et `start <= end`, nii saab hakkama paremini kui `offset_from`, mis peab tegelema allkirjaga.
            // Siin sobivate lippude määramisega saame seda LLVM-ile öelda, mis aitab tal piirikontrollid eemaldada.
            // OHUTUS: muutumatu tüübi järgi `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Samuti öeldes LLVM-ile, et osutid on tüübi suuruse täpse mitmekordiga lahus, saab see `(end - start) < size`-i asemel optimeerida `len() == 0` kuni `start == end`.
            //
            // OHUTUS: tüübi invariandi järgi on osutid joondatud nii, et
            //         nende vaheline kaugus peab olema pointee suuruse mitmekordne
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Iteraatorite `Iter` ja `IterMut` jagatud määratlus
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Tagastab esimese elemendi ja liigutab iteraatori algust 1 võrra edasi.
        // Parandab jõudlust võrreldes sissejoonitud funktsiooniga.
        // Kordaja ei tohi olla tühi.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Tagastab viimase elemendi ja nihutab iteraatori otsa 1 võrra tahapoole.
        // Parandab jõudlust võrreldes sissejoonitud funktsiooniga.
        // Kordaja ei tohi olla tühi.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Kahandab iteraatorit, kui T on ZST, liigutades iteraatori otsa `n` võrra tahapoole.
        // `n` ei tohi ületada `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Abistaja funktsioon iteraatorist viilu loomiseks.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // OHUTUS: iteraator loodi kursoriga viilust
                // `self.ptr` ja pikkus `len!(self)`.
                // See tagab kõigi `from_raw_parts`-i eelduste täitmise.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Abistajafunktsioon iteraatori alguse `offset` elementide abil edasi liikumiseks, tagastades vana alguse.
            //
            // Ohtlik, kuna nihe ei tohi ületada `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // OHUTUS: helistaja tagab, et `offset` ei ületa `self.len()`,
                    // nii et see uus osuti on `self`-i sees ja seega garanteeritud, et see pole null.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Abistajafunktsioon iteraatori otsa `offset` elementide abil tahapoole liikumiseks, tagastades uue otsa.
            //
            // Ohtlik, kuna nihe ei tohi ületada `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // OHUTUS: helistaja tagab, et `offset` ei ületa `self.len()`,
                    // mis garanteerib, et see ei ületa `isize`-i.
                    // Samuti on saadud osuti `slice` piirides, mis vastab muudele `offset` nõuetele.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // võiks rakendada viiludega, kuid see väldib piirikontrolli

                // OHUTUS: `assume` kõned on turvalised, kuna viilu algusosuti
                // ei tohi olla nullist erinev ja ZST-de mittekuuluvatel viiludel peab olema ka nullist erinev lõppotsik.
                // Kõne `next_unchecked!`-ile on turvaline, kuna kontrollime, kas iteraator on kõigepealt tühi.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // See iteraator on nüüd tühi.
                    if mem::size_of::<T>() == 0 {
                        // Peame seda tegema nii, kuna `ptr` ei pruugi kunagi olla 0, kuid `end` võib olla (mähkimise tõttu).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // OHUTUS: lõpp ei saa olla 0, kui T pole ZST, kuna ptr pole 0 ja lõpp>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // OHUTUS: Oleme piirides.`post_inc_start` teeb õigesti isegi ZST-de jaoks.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Alistame vaikerakenduse, mis kasutab `try_fold`-i, kuna see lihtne juurutus genereerib vähem LLVM IR-i ja seda on kiirem kompileerida.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Alistame vaikerakenduse, mis kasutab `try_fold`-i, kuna see lihtne juurutus genereerib vähem LLVM IR-i ja seda on kiirem kompileerida.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Alistame vaikerakenduse, mis kasutab `try_fold`-i, kuna see lihtne juurutus genereerib vähem LLVM IR-i ja seda on kiirem kompileerida.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Alistame vaikerakenduse, mis kasutab `try_fold`-i, kuna see lihtne juurutus genereerib vähem LLVM IR-i ja seda on kiirem kompileerida.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Alistame vaikerakenduse, mis kasutab `try_fold`-i, kuna see lihtne juurutus genereerib vähem LLVM IR-i ja seda on kiirem kompileerida.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Alistame vaikerakenduse, mis kasutab `try_fold`-i, kuna see lihtne juurutus genereerib vähem LLVM IR-i ja seda on kiirem kompileerida.
            // Samuti väldib `assume` piirikontrolli.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // OHUTUS: silmuse invariant tagab meile piirid:
                        // kui `i >= n`, tagastab `self.next()` `None` ja silmus katkeb.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Alistame vaikerakenduse, mis kasutab `try_fold`-i, kuna see lihtne juurutus genereerib vähem LLVM IR-i ja seda on kiirem kompileerida.
            // Samuti väldib `assume` piirikontrolli.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // OHUTUS: `i` peab olema väiksem kui `n`, kuna see algab `n`-st
                        // ja ainult väheneb.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // OHUTUS: helistaja peab tagama, et `i` on piirides
                // aluseks olev viil, nii et `i` ei saa `isize`-i üle voolata ja tagastatud viited tagavad viilu elemendi olemasolu ja seega kehtivuse.
                //
                // Pange tähele ka seda, et helistaja garanteerib ka selle, et meile ei helistata enam kunagi sama indeksiga ja et ei kasutata muid meetodeid, mis sellele alamlõikele juurde pääsevad, seega on kehtiv, kui tagastatud viide on
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // võiks rakendada viiludega, kuid see väldib piirikontrolli

                // OHUTUS: `assume`-kõned on ohutud, kuna viilu algusosuti ei tohi olla null,
                // ja viiludel, mis ei ole ZST-d, peab olema ka null-null lõppkursor.
                // Kõne `next_back_unchecked!`-ile on turvaline, kuna kontrollime, kas iteraator on kõigepealt tühi.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // See iteraator on nüüd tühi.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // OHUTUS: Oleme piirides.`pre_dec_end` teeb õigesti isegi ZST-de jaoks.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}