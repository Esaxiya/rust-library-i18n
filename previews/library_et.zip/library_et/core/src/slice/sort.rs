//! Viilude sorteerimine
//!
//! See moodul sisaldab sorteerimisalgoritmi, mis põhineb Orson Petersi mustrit kaotaval kiirsortidel, mis on avaldatud aadressil: <https://github.com/orlp/pdqsort>
//!
//!
//! Ebastabiilne sorteerimine sobib libcore'iga, kuna see ei eralda mälu, erinevalt meie stabiilsest sorteerimisrakendusest.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Kui see kukutatakse, kopeeritakse `src`-ist `dest`-i.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // OHUTUS: See on abiklass.
        //          Palun lugege selle õigsust selle kasutamisest.
        //          Nimelt peab olema kindel, et `src` ja `dst` ei kattu, nagu `ptr::copy_nonoverlapping` nõuab.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Nihutab esimest elementi paremale, kuni see kohtub suurema või võrdse elemendiga.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // OHUTUS: Allpool toodud ohtlikud toimingud hõlmavad indekseerimist ilma kontrollimata (`get_unchecked` ja `get_unchecked_mut`)
    // ja mälu kopeerimine (`ptr::copy_nonoverlapping`).
    //
    // a.Indekseerimine:
    //  1. Kontrollisime massiivi suuruseks>=2.
    //  2. Kogu indekseerimine, mida me teeme, on alati maksimaalselt {0 <= index < len} vahel.
    //
    // b.Mälu kopeerimine
    //  1. Saame vihjeid viidetele, mille kehtivus on garanteeritud.
    //  2. Need ei saa kattuda, sest saame viite erinevuse indeksitele viiteid.
    //     Nimelt `i` ja `i-1`.
    //  3. Kui viil on õigesti joondatud, on elemendid õigesti joondatud.
    //     Helistaja kohustus on tagada viilu õige joondamine.
    //
    // Lisateabe saamiseks vaadake allpool toodud kommentaare.
    unsafe {
        // Kui kaks esimest elementi on korrast ära ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Lugege esimene element virnale eraldatud muutujaks.
            // Kui järgmine võrdlustoiming panics, langeb `hole` ja kirjutab elemendi automaatselt viilu sisse.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Liigutage i elementi üks koht vasakule, nihutades auku paremale.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` langeb ja kopeerib `tmp` `v`-i ülejäänud auku.
        }
    }
}

/// Nihutab viimast elementi vasakule, kuni see kohtub väiksema või võrdse elemendiga.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // OHUTUS: Allpool toodud ohtlikud toimingud hõlmavad indekseerimist ilma kontrollimata (`get_unchecked` ja `get_unchecked_mut`)
    // ja mälu kopeerimine (`ptr::copy_nonoverlapping`).
    //
    // a.Indekseerimine:
    //  1. Kontrollisime massiivi suuruseks>=2.
    //  2. Kogu indekseerimine, mida me teeme, on alati maksimaalselt `0 <= index < len-1` vahel.
    //
    // b.Mälu kopeerimine
    //  1. Saame vihjeid viidetele, mille kehtivus on garanteeritud.
    //  2. Need ei saa kattuda, sest saame viite erinevuse indeksitele viiteid.
    //     Nimelt `i` ja `i+1`.
    //  3. Kui viil on õigesti joondatud, on elemendid õigesti joondatud.
    //     Helistaja kohustus on tagada viilu õige joondamine.
    //
    // Lisateabe saamiseks vaadake allpool toodud kommentaare.
    unsafe {
        // Kui kaks viimast elementi on korrast ära ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Lugege viimane element virnale eraldatud muutujaks.
            // Kui järgmine võrdlustoiming panics, langeb `hole` ja kirjutab elemendi automaatselt viilu sisse.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Liigutage i elementi üks koht paremale, nihutades auku vasakule.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` langeb ja kopeerib `tmp` `v`-i ülejäänud auku.
        }
    }
}

/// Osaliselt sorteerib viilu, nihutades ümber mitu korrastamata elementi.
///
/// Tagastab `true`, kui viil on lõpus sorteeritud.See funktsioon on halvimal juhul *O*(*n*).
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Maksimaalne külgnevate järjestusväliste paaride arv, mis nihutatakse.
    const MAX_STEPS: usize = 5;
    // Kui viil on sellest lühem, ärge nihutage ühtegi elementi.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // OHUTUS: Me tegime juba `i < len`-iga seotud kontrolli.
        // Kogu meie järgnev indekseerimine on ainult vahemikus `0 <= index < len`
        unsafe {
            // Leidke järgmine paar kõrvuti asetsevaid korrastamata elemente.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Kas oleme valmis?
        if i == len {
            return true;
        }

        // Ärge nihutage elemente lühikeste massiivide korral, mis maksab jõudluskulusid.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Leitud elementide paari vahetamine.See paneb nad õigesse järjekorda.
        v.swap(i - 1, i);

        // Nihutage väiksem element vasakule.
        shift_tail(&mut v[..i], is_less);
        // Nihutage suurem element paremale.
        shift_head(&mut v[i..], is_less);
    }

    // Piiratud arvu sammudega ei õnnestunud viilu sortida.
    false
}

/// Sorteerib viilu sisestusjärjestuse abil, mis on halvimal juhul *O*(*n*^ 2).
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Sorteerib `v` heapsordi abil, mis tagab *O*(*n*\*log(* n*)) halvimal juhul.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // See binaarhunnik austab muutumatut `parent >= child`-i.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // `node` lapsed:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Valige suurem laps.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Peatage, kui muutumatu väärtus püsib `node` juures.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Vahetage `node` suurema lapsega, liikuge üks samm alla ja jätkake sõelumist.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Ehitage hunnik lineaarse ajaga.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop maksimaalsed elemendid kuhjast.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Jaotatakse `v` väiksemateks elementideks kui `pivot`, millele järgnevad elemendid, mis on suuremad või võrdsed `pivot`.
///
///
/// Tagastab elementide arvu, mis on väiksem kui `pivot`.
///
/// Jaotamine toimub plokkide kaupa, et minimeerida hargnemise toiminguid.
/// See idee on esitatud [BlockQuicksort][pdf] paberil.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Elementide arv tüüpilises plokis.
    const BLOCK: usize = 128;

    // Jaotuse algoritm kordab järgmisi samme kuni valmimiseni:
    //
    // 1. Jälgige plokki vasakult küljelt, et tuvastada liigendist suuremaid või sellega võrdseid elemente.
    // 2. Pöördest väiksemate elementide tuvastamiseks jälgige paremalt küljelt plokki.
    // 3. Vahetage tuvastatud elemendid vasaku ja parema külje vahel.
    //
    // Elementide ploki jaoks säilitame järgmised muutujad:
    //
    // 1. `block` - Elementide arv plokis.
    // 2. `start` - Alustage kursorit massiivi `offsets`.
    // 3. `end` - Lõpukursor massiivi `offsets` sisse.
    // 4. `nihked, ploki korrastamata elementide indeksid.

    // Praegune plokk vasakul küljel (alates `l` kuni `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Paremal küljel olev praegune plokk (`r.sub(block_r)` to `r`)-ist).
    // OHUTUS: .add() dokumentatsioonis mainitakse konkreetselt, et `vec.as_ptr().add(vec.len())` on alati ohutu
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Kui saame VLA-d, proovige pigem luua üks massiiv pikkusega `min(v.len(), 2 * BLOCK)
    // kui kaks fikseeritud suurusega massiivi pikkusega `BLOCK`.VLA-d võivad olla vahemälusäästlikumad.

    // Tagastab elementide arvu osuti `l` (inclusive) ja `r` (exclusive) vahel.
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Kui plokid `l` ja `r` saavad väga lähedale, oleme plokkide kaupa partitsiooni teinud.
        // Seejärel teeme mõned parandustööd, et jaotada ülejäänud elemendid nende vahel.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Ülejäänud elementide arv (pole ikka pöördega võrreldud).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Reguleerige ploki suurused nii, et vasak ja parem plokk ei kattuks, vaid oleksid kogu ülejäänud vahe katmiseks täiuslikult joondatud.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Jälgige `block_l` elemente vasakult küljelt.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // OHUTUS: Allpool toodud ohutustoimingud hõlmavad `offset` kasutamist.
                //         Vastavalt funktsiooni nõutavatele tingimustele rahuldame need, kuna:
                //         1. `offsets_l` on virnaga eraldatud ja seega käsitletakse seda eraldatud objektina.
                //         2. Funktsioon `is_less` tagastab `bool`.
                //            `bool`-i ülekandmine ei ületa kunagi `isize`-i.
                //         3. Oleme taganud, et `block_l` saab `<= BLOCK`.
                //            Lisaks määrati `end_l` algselt `offsets_` alguspunktiks, mis deklareeriti virnas.
                //            Seega teame, et isegi halvimal juhul (kõik `is_less`-i invokatsioonid tagastavad vale) on meil lõpp ainult 1 baiti.
                //        Teine ebaturvaline operatsioon on siin `elem`-i vähendamine.
                //        Algselt oli `elem` aga algviide viilule, mis kehtib alati.
                unsafe {
                    // Oksadeta võrdlus.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Jälgige `block_r` elemente paremalt küljelt.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // OHUTUS: Allpool toodud ohutustoimingud hõlmavad `offset` kasutamist.
                //         Vastavalt funktsiooni nõutavatele tingimustele rahuldame need, kuna:
                //         1. `offsets_r` on virnaga eraldatud ja seega käsitletakse seda eraldatud objektina.
                //         2. Funktsioon `is_less` tagastab `bool`.
                //            `bool`-i ülekandmine ei ületa kunagi `isize`-i.
                //         3. Oleme taganud, et `block_r` saab `<= BLOCK`.
                //            Lisaks määrati `end_r` algselt `offsets_` alguspunktiks, mis deklareeriti virnas.
                //            Seega teame, et isegi halvimal juhul (kõik `is_less`-i invokatsioonid vastavad tõele) ületame lõppu ainult ühe baidi.
                //        Teine ebaturvaline operatsioon on siin `elem`-i vähendamine.
                //        Kuid `elem` oli algselt `1 *sizeof(T)` lõpust möödas ja enne selle juurde pääsemist vähendasime seda `1* sizeof(T)` võrra.
                //        Lisaks väideti, et `block_r` on väiksem kui `BLOCK` ja `elem` osutab seega maksimaalselt viilu algusele.
                unsafe {
                    // Oksadeta võrdlus.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Vasakule ja paremale küljele vahetatavate korrastamata elementide arv.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Selle asemel, et vahetada korraga ühte paari, on efektiivsem teha tsükliline permutatsioon.
            // See ei ole täpselt samaväärne vahetusega, kuid annab sarnase tulemuse vähem mäluoperatsioone kasutades.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Kõik vasakpoolses plokis korrastamata elemendid teisaldati.Liigu järgmise ploki juurde.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Kõik parempoolses plokis korrastamata elemendid teisaldati.Liigu eelmisele plokile.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Praegu on jäänud ainult üks plokk (kas vasak või parem) koos korrastamata elementidega, mida tuleb teisaldada.
    // Selliseid ülejäänud elemente saab nende plokis lihtsalt nihutada lõpuni.
    //

    if start_l < end_l {
        // Vasak plokk jääb alles.
        // Viige selle ülejäänud korrast ära elemendid paremäärmusesse.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Õige plokk jääb alles.
        // Viige selle ülejäänud korrastamata elemendid vasakpoolsesse serva.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Midagi muud teha pole, oleme valmis.
        width(v.as_mut_ptr(), l)
    }
}

/// Jaotatakse `v` väiksemateks elementideks kui `v[pivot]`, millele järgnevad elemendid, mis on suuremad või võrdsed `v[pivot]`.
///
///
/// Tagastab hulga:
///
/// 1. Elementide arv väiksem kui `v[pivot]`.
/// 2. Tõsi, kui `v` oli juba jaotatud.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Asetage pöördosa viilu algusesse.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Tõhususe huvides lugege pöördet virnale eraldatud muutujaks.
        // Järgmise võrdlustoimingu panics korral kirjutatakse pöördetükk viilusse automaatselt tagasi.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Leidke esimene paar korrastamata elemente.
        let mut l = 0;
        let mut r = v.len();

        // OHUTUS: Allpool toodud ebaturvalisus hõlmab massiivi indekseerimist.
        // Esimese jaoks: siin kontrollime juba `l < r`-iga piire.
        // Teise jaoks: meil on algselt `l == 0` ja `r == v.len()` ning seda kontrollisime igal indekseerimisel.
        //                     Siit saame teada, et `r` peab olema vähemalt `r == l`, mis näitas, et see kehtib esimesest.
        unsafe {
            // Leidke esimene element, mis on pöördtappist suurem või sellega võrdne.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Leidke viimane element, mis on pöördetappist väiksem.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` läheb reguleerimisalast välja ja kirjutab pöördetapi (mis on virnale eraldatud muutuja) tagasi viilu sisse, kus see algselt oli.
        // See samm on ohutuse tagamisel kriitilise tähtsusega!
        //
    };

    // Asetage pöördosa kahe sektsiooni vahele.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Jaotage `v` elementideks, mis on võrdsed `v[pivot]`, millele järgnevad elemendid, mis on suuremad kui `v[pivot]`.
///
/// Tagastab liigendiga võrdse elementide arvu.
/// Eeldatakse, et `v` ei sisalda liigendist väiksemaid elemente.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Asetage pöördosa viilu algusesse.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Tõhususe huvides lugege pöördet virnale eraldatud muutujaks.
    // Järgmise võrdlustoimingu panics korral kirjutatakse pöördetükk viilusse automaatselt tagasi.
    // OHUTUS: Siin on kursor kehtiv, kuna see saadakse viite viilule.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Nüüd jaotage viil.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // OHUTUS: Allpool toodud ebaturvalisus hõlmab massiivi indekseerimist.
        // Esimese jaoks: siin kontrollime juba `l < r`-iga piire.
        // Teise jaoks: meil on algselt `l == 0` ja `r == v.len()` ning seda kontrollisime igal indekseerimisel.
        //                     Siit saame teada, et `r` peab olema vähemalt `r == l`, mis näitas, et see kehtib esimesest.
        unsafe {
            // Leidke esimene element, mis on pöördetappist suurem.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Leidke viimane pöördega võrdne element.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Kas oleme valmis?
            if l >= r {
                break;
            }

            // Leitud paari korrastamata elementide vahetamine.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Leidsime pöördega võrdsed `l` elemendid.Pivoti enda kontole lisamiseks lisage 1.
    l + 1

    // `_pivot_guard` läheb reguleerimisalast välja ja kirjutab pöördetapi (mis on virnale eraldatud muutuja) tagasi viilu sisse, kus see algselt oli.
    // See samm on ohutuse tagamisel kriitilise tähtsusega!
}

/// Hajutab mõningaid elemente, püüdes murda mustreid, mis võivad quicksortis põhjustada tasakaalustamata partitsioone.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // George Marsaglia poolt "Xorshift RNGs" paberist pärit pseudojuhuslike numbrite generaator.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Võtke juhuslikud arvud selle arvu järgi.
        // Number sobib `usize`-i, kuna `len` ei ole suurem kui `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Mõned pöördekandidaadid asuvad selle indeksi läheduses.Juhuslikult jaotame need.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Looge juhuslik arv modulo `len`.
            // Kuid kulukate toimingute vältimiseks võtame selle kõigepealt modulo võimsusega kaks ja seejärel vähendame `len` võrra, kuni see sobib vahemikku `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` on väiksem kui `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Valib `v`-is pöördetapi ja tagastab indeksi ja `true`, kui viil on tõenäoliselt juba sorditud.
///
/// `v`-i elemente võidakse selle käigus järjestada.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Mediaanide mediaani meetodi valimiseks on minimaalne pikkus.
    // Lühematel viiludel kasutatakse lihtsat mediaani kolmest meetodit.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Selles funktsioonis saab maksimaalselt vahetada.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Kolm indeksit, mille lähedal me valime pöördetapi.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Loendab indeksite sorteerimisel vahetatavate tehingute koguarvu.
    let mut swaps = 0;

    if len >= 8 {
        // Vahetab indeksid nii, et `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Vahetab indeksid nii, et `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Leiab `v[a - 1], v[a], v[a + 1]` mediaani ja salvestab indeksi `a`-i.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Leidke mediaanid `a`, `b` ja `c` naabruskondadest.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Leidke mediaan `a`, `b` ja `c` hulgast.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Tehti maksimaalne arv vahetustehinguid.
        // Võimalik, et viil väheneb või enamasti väheneb, nii et tagurdamine aitab tõenäoliselt kiiremini sorteerida.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Sorteerib `v` rekursiivselt.
///
/// Kui viilul oli algses massiivis eelkäija, on see määratletud kui `pred`.
///
/// `limit` on lubatud tasakaalustamata partitsioonide arv enne `heapsort`-ile üleminekut.
/// Nulli korral lülitub see funktsioon koheselt heapordile.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Kuni selle pikkusega viilud sorteeritakse sisestussorteerimise abil.
    const MAX_INSERTION: usize = 20;

    // Tõsi, kui viimane jaotamine oli mõistlikult tasakaalus.
    let mut was_balanced = true;
    // Tõsi, kui viimane jaotamine ei seganud elemente (viil oli juba jaotatud).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Väga lühikesed viilud sorteeritakse sisestussorteerimise abil.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Kui tehti liiga palju valesid pöördetõkkeid, pöörduge `O(n * log(n))` halvima juhtumi tagamiseks lihtsalt tagasi heapsordi.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Kui viimane jaotamine oli tasakaalust väljas, proovige jaotises mustreid murda, segades mõned elemendid ümber.
        // Loodetavasti valime seekord parema pöördetapi.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Valige pöördetapp ja proovige arvata, kas viil on juba sorteeritud.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Kui viimane jaotamine oli korralikult tasakaalustatud ega seganud elemente ja kui pivoti valik ennustas, on viil tõenäoliselt juba sorditud ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Proovige tuvastada mitu korrastamata elementi ja nihutada need õigesse asendisse.
            // Kui viil lõpuks sorteeritakse, oleme valmis.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Kui valitud pöördetapp on võrdne eelkäijaga, on see viilu väikseim element.
        // Jagage viil elementideks, mis on võrdsed ja suuremad kui pöördetapp.
        // Seda juhtumit tabatakse tavaliselt siis, kui viil sisaldab palju duplikaatelemente.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Jätkake liigendist suuremate elementide sorteerimist.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Jaota viil.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Jagage viil `left`, `pivot` ja `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Korrake lühemale küljele ainult selleks, et minimeerida rekursiivsete kõnede koguarvu ja kulutada vähem virnaruumi.
        // Seejärel jätkake lihtsalt pikema küljega (see sarnaneb saba rekursiooniga).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Sorteerib `v` mustrit kaotava kiirsordi abil, mis on *O*(*n*\*log(* n*)) halvimal juhul.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Sortimisel ei ole nullsuuruste tüüpide puhul sisukat käitumist.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Piirake tasakaalustamata partitsioonide arv väärtusega `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Kuni selle pikkusega viilude puhul on tõenäoliselt kiirem neid lihtsalt sorteerida.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Valige pöördetapp
        let (pivot, _) = choose_pivot(v, is_less);

        // Kui valitud pöördetapp on võrdne eelkäijaga, on see viilu väikseim element.
        // Jagage viil elementideks, mis on võrdsed ja suuremad kui pöördetapp.
        // Seda juhtumit tabatakse tavaliselt siis, kui viil sisaldab palju duplikaatelemente.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Kui oleme oma indeksi läbinud, siis oleme tublid.
                if mid > index {
                    return;
                }

                // Muul juhul jätkake liigendist suuremate elementide sorteerimist.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Jagage viil `left`, `pivot` ja `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Kui keskel==indeks, siis oleme valmis, kuna partition() garanteerib, et kõik elemendid pärast keskpaika on keskmisest suuremad või võrdsed.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Sortimisel ei ole nullsuuruste tüüpide puhul sisukat käitumist.Ära tee midagi.
    } else if index == v.len() - 1 {
        // Leidke max element ja asetage see massiivi viimasele positsioonile.
        // Meil on siin vaba kasutada `unwrap()`-i, kuna teame, et v ei tohi olla tühi.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Leidke min element ja asetage see massiivi esimesse positsiooni.
        // Meil on siin vaba kasutada `unwrap()`-i, kuna teame, et v ei tohi olla tühi.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}