//! Operatsioonid seadmega ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Kontrollib, kas kõik selle osa baidid jäävad ASCII vahemikku.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Kontrollib, kas kaks viilu on ASCII väiketähtedest sõltumatud.
    ///
    /// Sama mis `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, kuid ilma ajutisi eraldamata ja kopeerimata.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Teisendab selle osa oma ASCII suurtähtedega samaväärseks kohaks.
    ///
    /// ASCII tähed 'a' kuni 'z' vastendatakse tähtedega 'A' kuni 'Z', kuid mitte-ASCII tähed ei muutu.
    ///
    /// Uue suurte väärtuste tagastamiseks olemasolevat muutmata kasutage [`to_ascii_uppercase`]-i.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Teisendab selle osa oma ASCII väiketähtedega samaväärseks kohaks.
    ///
    /// ASCII tähed 'A' kuni 'Z' vastendatakse tähtedega 'a' kuni 'z', kuid mitte-ASCII tähed ei muutu.
    ///
    /// Uue väiketähelise väärtuse tagastamiseks olemasolevat muutmata kasutage [`to_ascii_lowercase`]-i.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Tagastab `true`, kui mõni bait sõnas `v` on nonascii (>=128).
/// Snarfed `../str/mod.rs`-ist, mis teeb utf8-i valideerimiseks midagi sarnast.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Optimeeritud ASCII test, mis kasutab bait-korraga-operatsioonide asemel korraga kasutatavate operatsioonide kasutamist (kui võimalik).
///
/// Siin kasutatav algoritm on üsna lihtne.Kui `s` on liiga lühike, kontrollime lihtsalt iga baidi ja oleme sellega valmis.Vastasel juhul:
///
/// - Lugege esimest sõna joondamata koormusega.
/// - Joondage kursor, lugege järgnevaid sõnu lõpuni joondatud koormustega.
/// - Lugege `s`-i viimast `usize`-i joondamata koormusega.
///
/// Kui mõni neist koormustest annab midagi, mille `contains_nonascii` (above) tagastab tõene, siis teame, et vastus on vale.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Kui me ei saa sõna-korraga rakendamisest midagi, siis pöörduge tagasi skalaarse ringi juurde.
    //
    // Teeme seda ka selliste arhitektuuride puhul, kus `size_of::<usize>()` ei ole `usize` jaoks piisav joondus, sest see on imelik edge juhtum.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Esimest sõna loeme alati joondamata, mis tähendab, et `align_offset` on
    // 0, loeksime joondatud lugemise jaoks sama väärtuse uuesti.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // OHUTUS: me kontrollime ülaltoodud seadet `len < USIZE_SIZE`.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Kontrollisime seda ülal, mõnevõrra kaudselt.
    // Pange tähele, et `offset_to_aligned` on kas `align_offset` või `USIZE_SIZE`, mõlemad on eespool selgesõnaliselt kontrollitud.
    //
    debug_assert!(offset_to_aligned <= len);

    // OHUTUS: sõna_ptr on (õigesti joondatud) kasutatav ptr, mida kasutame selle lugemiseks
    // viilu keskmine tükk.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` on `word_ptr` baitindeks, mida kasutatakse silmuse lõpu kontrollimiseks.
    let mut byte_pos = offset_to_aligned;

    // Paranoia kontrollib joondust, kuna hakkame tegema hulga joondamata koormusi.
    // Praktikas peaks see siiski olema võimatu, kuid vea tõkestamine `align_offset`-is.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Lugege järgnevaid sõnu kuni viimase joondatud sõnani, välja arvatud viimane joondatud sõna, mis tuleb hiljem teha sabakontrollis, tagamaks, et saba oleks alati üks `usize` kuni täiendava branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Tervislikkuse kontrollimine, kas lugemine on piiratud
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Ja et meie eeldused `byte_pos` kohta kehtivad.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // OHUTUS: Me teame, et `word_ptr` on õigesti joondatud (tänu
        // `align_offset`) ja me teame, et meil on `word_ptr` ja lõpu vahel piisavalt baite
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // OHUTUS: Me teame, et `byte_pos <= len - USIZE_SIZE`, mis tähendab seda
        // pärast seda `add` on `word_ptr` maksimaalselt üks-eelmine.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Tervisekontroll, et veenduda, et `usize`-i on tõesti alles.
    // Selle peaks tagama meie silmuse tingimus.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // OHUTUS: See tugineb `len >= USIZE_SIZE`-ile, mida kontrollime alguses.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}