//! `Clone` trait tüüpidele, mida ei saa kaudselt kopeerida.
//!
//! Rakenduses Rust on mõned lihtsad tüübid "implicitly copyable" ja kui määrate need või edastate need argumentidena, saab vastuvõtja koopia, jättes algse väärtuse paika.
//! Need tüübid ei nõua kopeerimiseks eraldamist ja neil pole lõplikke viimistlejaid (st need ei sisalda omatavaid kaste ega rakenda [`Drop`]), seega peab kompilaator neid kopeerimiseks odavaks ja ohutuks.
//!
//! Muude tüüpide puhul tuleb koopiad teha selgesõnaliselt, kokkuleppe [`Clone`] trait juurutamise ja meetodi [`clone`] abil.
//!
//! [`clone`]: Clone::clone
//!
//! Põhiline kasutusnäide:
//!
//! ```
//! let s = String::new(); // Stringi tüüpi rakendab klooni
//! let copy = s.clone(); // et saaksime selle kloonida
//! ```
//!
//! Clone trait hõlpsaks rakendamiseks võite kasutada ka `#[derive(Clone)]`-i.Näide:
//!
//! ```
//! #[derive(Clone)] // lisame Morpheuse struktuuri klooni trait
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // ja nüüd saame selle kloonida!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Tavaline trait võime selgesõnaliselt dubleerida objekti.
///
/// Erineb [`Copy`]-st selle poolest, et [`Copy`] on kaudne ja äärmiselt odav, samas kui `Clone` on alati selgesõnaline ja võib ka mitte olla kallis.
/// Nende omaduste jõustamiseks ei luba Rust teil [`Copy`] uuesti rakendada, kuid võite uuesti rakendada `Clone` ja käivitada suvalise koodi.
///
/// Kuna `Clone` on üldisem kui [`Copy`], saate automaatselt muuta kõik [`Copy`] ka `Clone`-iks.
///
/// ## Derivable
///
/// Seda trait saab kasutada koos `#[derive]`-iga, kui kõik väljad on `Clone`.[`Clone`]-i "tuletamise" juurutamine kutsub välja [`clone`].
///
/// [`clone`]: Clone::clone
///
/// Üldise struktuuri jaoks rakendab `#[derive]` `Clone`-i tingimuslikult, lisades seonduva `Clone`-i üldistele parameetritele.
///
/// ```
/// // `derive` rakendab klooni lugemiseks<T>kui T on kloon.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Kuidas saan rakendust `Clone` rakendada?
///
/// Tüüpidel, mis on [`Copy`], peaks olema `Clone` tühine rakendamine.Ametlikumalt:
/// kui `T: Copy`, `x: T` ja `y: &T`, siis `let x = y.clone();` on samaväärne `let x = *y;`-ga.
/// Käsitsi rakendamine peaks olema selle muutumatu hoidmiseks ettevaatlik;ebaturvaline kood ei tohi siiski mälu ohutuse tagamiseks sellele tugineda.
///
/// Näide on funktsioonikursorit hoidev üldine struktuur.Sel juhul ei saa `Clone`-i juurutamist tuletada, vaid seda saab rakendada järgmiselt:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Täiendavad rakendajad
///
/// Lisaks [implementors listed below][impls] rakendavad `Clone` ka järgmised tüübid:
///
/// * Funktsioonide üksuste tüübid (st iga funktsiooni jaoks määratletud erinevad tüübid)
/// * Funktsioonikursori tüübid (nt `fn() -> i32`)
/// * Massiivitüübid kõigi suuruste jaoks, kui üksuse tüüp rakendab ka `Clone` (nt `[i32; 123456]`)
/// * Tuple tüübid, kui iga komponent rakendab ka `Clone` (nt `()`, `(i32, bool)`)
/// * Sulgemistüübid, kui need ei võta keskkonnast mingit väärtust või kui kõik sellised hõivatud väärtused rakendavad `Clone`-i ise.
///   Pange tähele, et jagatud viitega hõivatud muutujad rakendavad alati `Clone`-i (isegi kui referent seda ei tee), samas kui muutuva viite abil hõivatud muutujad ei kasuta kunagi `Clone`-i.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Tagastab väärtuse koopia.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str rakendab Klooni
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Teostab `source`-ist koopia määramise.
    ///
    /// `a.clone_from(&b)` on funktsionaalsuses samaväärne `a = b.clone()`-iga, kuid selle võib asjatute jaotuste vältimiseks `a`-i ressursside taaskasutamiseks tühistada.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Tuletage makro, genereerides trait `Clone` implantaadi.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): neid struktuure kasutab ainult#[tuletis] väites, et iga tüübi komponent rakendab klooni või kopeerimist.
//
//
// Neid juhiseid ei tohiks kunagi kasutajakoodis ilmuda.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Clone` rakendused primitiivsete tüüpide jaoks.
///
/// Rakendused, mida ei saa kirjeldada rakenduses Rust, viiakse rakenduses `traits::SelectionContext::copy_clone_conditions()` sisse versioonis `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Jagatud viiteid saab kloonida, kuid muudetavaid viiteid *ei saa*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Jagatud viiteid saab kloonida, kuid muudetavaid viiteid *ei saa*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}