//! Märgi teisendamine.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Teisendab `u32` `char`-ks.
///
/// Pange tähele, et kõik ["char"-id on kehtivad ["u32"]-d ja neid saab ühega valada
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Kuid vastupidine ei ole tõsi: mitte kõik kehtivad [`u32`] s ei kehti [`char`] d.
/// `from_u32()` tagastab `None`, kui sisend ei ole [`char`] jaoks kehtiv väärtus.
///
/// Selle funktsiooni ebaturvalise versiooni kohta, mis neid kontrolle eirab, vaadake jaotist [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Põhikasutus:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Tagastatakse `None`, kui sisend ei ole kehtiv [`char`]:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Teisendab `u32`-i `char`-ks, eirates kehtivust.
///
/// Pange tähele, et kõik ["char"-id on kehtivad ["u32"]-d ja neid saab ühega valada
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Kuid vastupidine ei ole tõsi: mitte kõik kehtivad [`u32`] s ei kehti [`char`] d.
/// `from_u32_unchecked()` ignoreerib seda ja viskab pimesi [`char`]-i, luues võib-olla kehtetu.
///
///
/// # Safety
///
/// See funktsioon on ohtlik, kuna see võib konstrueerida kehtetud `char` väärtused.
///
/// Selle funktsiooni turvalise versiooni saamiseks vaadake funktsiooni [`from_u32`].
///
/// # Examples
///
/// Põhikasutus:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // OHUTUS: helistaja peab tagama, et `i` on kehtiv söeväärtus.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Teisendab [`char`] [`u32`]-ks.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Teisendab [`char`] [`u64`]-ks.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Täht valatakse koodipunkti väärtuseni, seejärel laiendatakse see nullini 64-bitise väärtuseni.
        // Vaadake [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Teisendab [`char`] [`u128`]-ks.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Täht valatakse koodipunkti väärtuseni ja laiendatakse seejärel nullini 128-bitise väärtuseni.
        // Vaadake [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Kaardistab 0x00 ..=0xFF baidi `char`-i, mille koodipunkt on sama väärtusega, U + 0000 ..=U + 00FF.
///
/// Unicode on loodud nii, et see dekodeerib baidid tegelase kodeeringuga, mida IANA kutsub ISO-8859-1-ks.
/// See kodeering ühildub ASCII-ga.
///
/// Pange tähele, et see erineb ISO/IEC 8859-1 aka-st
/// ISO 8859-1 (ühe sidekriipsuga vähem), mis jätab mõned "blanks"-baidised väärtused, mis pole määratud ühegi tähemärgiga.
/// ISO-8859-1 (IANA üks) määrab need juhtkoodidele C0 ja C1.
///
/// Pange tähele, et see erineb ka *Windows* 1252-st
/// koodileht 1252, mis on superset ISO/IEC 8859-1, mis määrab mõned (mitte kõik!) tühikud kirjavahemärkidele ja mitmesugustele ladina tähtedele.
///
/// Et asju veelgi segamini ajada, on [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` ja `windows-1252` kõik varjunimed Windowsi 1252 supersetile, mis täidab ülejäänud tühjad kohad C0 ja C1 juhtkoodidega.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Teisendab [`u8`] [`char`]-ks.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Viga, mille saab tagastada sõne parsimisel.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // OHUTUS: kontrollis, kas see on seaduslik unicode'i väärtus
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Veatüüp tagastati, kui u32-st sümboliks teisendamine ebaõnnestus.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Teisendab antud radiksis oleva numbri `char`-ks.
///
/// Siinset 'radix' nimetatakse mõnikord ka 'base'-ks.
/// Kahe raadiusega tähistatakse kahendarvu, kümnendkoha ja kümnendkoha täpsust ning kuueteistkümnendkoha täpsusega kuusteist, et anda mõned ühised väärtused.
///
/// Toetatakse meelevaldseid radikaale.
///
/// `from_digit()` tagastab `None`, kui sisend ei ole antud radiksis olev number.
///
/// # Panics
///
/// Panics, kui antud raadius on suurem kui 36.
///
/// # Examples
///
/// Põhikasutus:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Koma 11 on ühekohaline baas 16-s
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// `None` tagastamine, kui sisend pole number:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Suure radiksi läbimine, põhjustades panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}