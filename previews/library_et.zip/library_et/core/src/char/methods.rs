//! implantaadi täht {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Kõrgeim kehtiv koodipunkt, mis `char`-l olla võib.
    ///
    /// `char` on [Unicode Scalar Value], mis tähendab, et see on [Code Point], kuid ainult teatud vahemikus olevad.
    /// `MAX` on kõrgeim kehtiv koodipunkt, mis on kehtiv [Unicode Scalar Value].
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` ()-i kasutatakse Unicode'is dekodeerimisvea tähistamiseks.
    ///
    /// See võib ilmneda näiteks siis, kui anda [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy)-le halvasti vormitud UTF-8-baidid.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// [Unicode](http://www.unicode.org/) versioon, millel põhinevad meetodite `char` ja `str` osad Unicode.
    ///
    /// Regulaarselt antakse välja uusi Unicode'i versioone ja seejärel värskendatakse kõiki standardses teegis olevaid meetodeid, sõltuvalt Unicode'ist.
    /// Seetõttu muutuvad mõne `char` ja `str` meetodi käitumine ja selle konstandi väärtus ajas.
    /// Seda * ei peeta murranguliseks muutuseks.
    ///
    /// Versioonide nummerdamise skeemi on selgitatud [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4)-is.
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Loob `iter`-is kodeeritud UTF-16-i koodipunktide kohale iteraatori, tagastades paaristamata asendajad asendusena Err.
    ///
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Kadunud dekoodri saab `Err`-i tulemuste asendamise asemel asendusmärgiga:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Teisendab `u32` `char`-ks.
    ///
    /// Pange tähele, et kõik `char'id on kehtivad [` u32`] s ja neid saab ühega valada
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Kuid vastupidine ei ole tõsi: mitte kõik kehtivad [`u32`] s pole kehtivad`char`id.
    /// `from_u32()` tagastab `None`, kui sisend ei ole `char` jaoks kehtiv väärtus.
    ///
    /// Selle funktsiooni ebaturvalise versiooni kohta, mis neid kontrolle eirab, vaadake jaotist [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Tagastatakse `None`, kui sisend ei ole kehtiv `char`:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Teisendab `u32`-i `char`-ks, eirates kehtivust.
    ///
    /// Pange tähele, et kõik `char'id on kehtivad [` u32`] s ja neid saab ühega valada
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Kuid vastupidine ei ole tõsi: mitte kõik kehtivad [`u32`] s pole kehtivad`char`id.
    /// `from_u32_unchecked()` ignoreerib seda ja viskab pimesi `char`-i, luues võib-olla kehtetu.
    ///
    ///
    /// # Safety
    ///
    /// See funktsioon on ohtlik, kuna see võib konstrueerida kehtetud `char` väärtused.
    ///
    /// Selle funktsiooni turvalise versiooni saamiseks vaadake funktsiooni [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // OHUTUS: helistaja peab kinni pidama ohutuslepingust.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Teisendab antud radiksis oleva numbri `char`-ks.
    ///
    /// Siinset 'radix' nimetatakse mõnikord ka 'base'-ks.
    /// Kahe raadiusega tähistatakse kahendarvu, kümnendkoha ja kümnendkoha täpsust ning kuueteistkümnendkoha täpsusega kuusteist, et anda mõned ühised väärtused.
    ///
    /// Toetatakse meelevaldseid radikaale.
    ///
    /// `from_digit()` tagastab `None`, kui sisend ei ole antud radiksis olev number.
    ///
    /// # Panics
    ///
    /// Panics, kui antud raadius on suurem kui 36.
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Koma 11 on ühekohaline baas 16-s
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// `None` tagastamine, kui sisend pole number:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Suure radiksi läbimine, põhjustades panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Kontrollib, kas `char` on antud radiksis olev number.
    ///
    /// Siinset 'radix' nimetatakse mõnikord ka 'base'-ks.
    /// Kahe raadiusega tähistatakse kahendarvu, kümnendkoha ja kümnendkoha täpsust ning kuueteistkümnendkoha täpsusega kuusteist, et anda mõned ühised väärtused.
    ///
    /// Toetatakse meelevaldseid radikaale.
    ///
    /// Võrreldes [`is_numeric()`]-iga tunneb see funktsioon ära ainult tähemärgid `0-9`, `a-z` ja `A-Z`.
    ///
    /// 'Digit' on määratletud ainult järgmisteks tähemärkideks:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// 'digit'-i põhjalikumaks mõistmiseks vt [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics, kui antud raadius on suurem kui 36.
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Suure radiksi läbimine, põhjustades panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Teisendab `char` antud radiksis olevaks numbriks.
    ///
    /// Siinset 'radix' nimetatakse mõnikord ka 'base'-ks.
    /// Kahe raadiusega tähistatakse kahendarvu, kümnendkoha ja kümnendkoha täpsust ning kuueteistkümnendkoha täpsusega kuusteist, et anda mõned ühised väärtused.
    ///
    /// Toetatakse meelevaldseid radikaale.
    ///
    /// 'Digit' on määratletud ainult järgmisteks tähemärkideks:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Tagastab `None`, kui `char` ei viita antud radiksis olevale numbrile.
    ///
    /// # Panics
    ///
    /// Panics, kui antud raadius on suurem kui 36.
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Mittekohaline läbimine põhjustab ebaõnnestumist:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Suure radiksi läbimine, põhjustades panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // kood on siin jaotatud, et kiirendada juhtumeid, kus `radix` on konstantne ja 10 või väiksem
        //
        let val = if likely(radix <= 10) {
            // Kui see pole arv, luuakse radiksist suurem arv.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Tagastab iteraatori, mis annab märgi kui char-de kuueteistkümnendsüsteemis Unicode'i.
    ///
    /// See väldib tähemärki Rust süntaksiga kujul `\u{NNNNNN}`, kus `NNNNNN` on kuueteistkümnendsüsteem.
    ///
    ///
    /// # Examples
    ///
    /// Kordajana:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Otse `println!` kasutamine:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Mõlemad on samaväärsed:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// `to_string` kasutamine:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // või 1 tagab, et c==0 korral arvutab kood välja, et üks number tuleks printida, ja (mis on sama) väldib (31, 32) alamvoolu
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // kõige olulisema kuuekohalise numbri indeks
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// `escape_debug` laiendatud versioon, mis võimaldab valikuliselt pääseda laiendatud graafikakoodpunktidest välja.
    /// See võimaldab meil vormindada märke nagu tühimärke paremini, kui nad on stringi alguses.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Tagastab iteraatori, mis annab tegelase sõnasõnalise põgenemiskoodi kui "char".
    ///
    /// See väldib märke, mis sarnanevad `str` või `char` rakendustega `Debug`.
    ///
    ///
    /// # Examples
    ///
    /// Kordajana:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Otse `println!` kasutamine:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Mõlemad on samaväärsed:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// `to_string` kasutamine:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Tagastab iteraatori, mis annab tegelase sõnasõnalise põgenemiskoodi kui "char".
    ///
    /// Vaikimisi valitakse kallutatusega literaalide tootmine, mis on legaalsed erinevates keeltes, sealhulgas C++ 11 ja sarnased C-perekonna keeled.
    /// Täpsed reeglid on:
    ///
    /// * Vahekaart on põgenenud kui `\t`.
    /// * Vankri tagasipöördumine on `\r`.
    /// * Reasööt on `\n`.
    /// * Üksikpakkumine on `\'`.
    /// * Topeltpakkumine on `\"`.
    /// * Tagasi kaldkriips on `\\`.
    /// * Ükski " printable ASCII` vahemiku `0x20` .. `0x7e` (kaasa arvatud) tähemärki ei pääse.
    /// * Kõigile teistele tähemärkidele antakse kuueteistkümnendkohaga Unicode'i põgenemised;vaadake [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Kordajana:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Otse `println!` kasutamine:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Mõlemad on samaväärsed:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// `to_string` kasutamine:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Tagastab baitide arvu, mida see `char` vajaks, kui see oleks kodeeritud UTF-8-s.
    ///
    /// See baitide arv on alati vahemikus 1 kuni 4 (kaasa arvatud).
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Tüüp `&str` tagab, et selle sisu on UTF-8, ja seega saame võrrelda pikkust, mis kuluks, kui iga koodipunkt oleks `char` vs `&str`-is endas:
    ///
    ///
    /// ```
    /// // kui sõjad
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // mõlemat saab kujutada kolme baidina
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // &str-na on need kaks kodeeritud UTF-8-is
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // näeme, et nende koguarv on kuus baiti ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... täpselt nagu &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Tagastab 16-bitiste koodiüksuste arvu, mida `char` vajaks, kui see oleks kodeeritud UTF-16-s.
    ///
    ///
    /// Selle kontseptsiooni täpsema selgituse saamiseks vaadake [`len_utf8()`] dokumentatsiooni.
    /// See funktsioon on peegel, kuid UTF-8 asemel UTF-16.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Kodeerib selle märgi UTF-8-iga pakutavasse baidipuhvrisse ja tagastab seejärel kodeeritud märki sisaldava puhvri alamlõigu.
    ///
    ///
    /// # Panics
    ///
    /// Panics, kui puhver pole piisavalt suur.
    /// Neljapikkune puhver on piisavalt suur, et kodeerida mis tahes `char`-i.
    ///
    /// # Examples
    ///
    /// Mõlemas näites võtab 'ß' kodeerimiseks kaks baiti.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Liiga väike puhver:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // OHUTUS: `char` ei ole asendaja, seega kehtib see UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Kodeerib selle märgi UTF-16-iga pakutavasse `u16`-puhvrisse ja tagastab seejärel kodeeritud märki sisaldava puhvri alamlõigu.
    ///
    ///
    /// # Panics
    ///
    /// Panics, kui puhver pole piisavalt suur.
    /// Puhver pikkusega 2 on piisavalt suur, et kodeerida mis tahes `char`.
    ///
    /// # Examples
    ///
    /// Mõlemas näites võtab '𝕊' kodeerimiseks kaks u16.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Liiga väike puhver:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Tagastab väärtuse `true`, kui sellel `char`-il on omadus `Alphabetic`.
    ///
    /// `Alphabetic` kirjeldatakse [Unicode Standard]-i 4. peatükis (Märkide omadused) ja [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-s.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // armastus on palju asju, kuid see pole tähestikuline
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Tagastab väärtuse `true`, kui sellel `char`-il on omadus `Lowercase`.
    ///
    /// `Lowercase` kirjeldatakse [Unicode Standard]-i 4. peatükis (Märkide omadused) ja [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-s.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Hiina erinevatel skriptidel ja kirjavahemärkidel pole suurtähti ja nii:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Tagastab väärtuse `true`, kui sellel `char`-il on omadus `Uppercase`.
    ///
    /// `Uppercase` kirjeldatakse [Unicode Standard]-i 4. peatükis (Märkide omadused) ja [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-s.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Hiina erinevatel skriptidel ja kirjavahemärkidel pole suurtähti ja nii:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Tagastab väärtuse `true`, kui sellel `char`-il on omadus `White_Space`.
    ///
    /// `White_Space` on määratletud seadmes [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // murdumatu ruum
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Tagastab `true`, kui see `char` vastab kas [`is_alphabetic()`] või [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Tagastab `true`, kui sellel `char`-l on juhtkoodide üldkategooria.
    ///
    /// Juhtkoode (koodipunktid üldise kategooriaga `Cc`) kirjeldatakse [Unicode Standard]-i 4. peatükis (Märgiomadused) ja [Unicode Character Database][ucd]-s [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// // U + 009C, KEELLÕPPJA
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Tagastab väärtuse `true`, kui sellel `char`-il on omadus `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` on kirjeldatud dokumendis [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] ja täpsustatud dokumendis [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Tagastab `true`, kui sellel `char`-l on üks numbrite üldkategooriatest.
    ///
    /// Numbrite üldkategooriad (kümnendkohtade jaoks `Nd`, tähetaoliste numbrimärkide korral `Nl` ja muude numbrimärkide puhul `No`) on määratletud dokumendis [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Tagastab iteraatori, mis annab selle `char` väiketähtede kaardistuse ühe või enama kujul
    /// `char`s.
    ///
    /// Kui sellel `char`-l pole väiketähtede kaardistust, annab iteraator sama `char`.
    ///
    /// Kui sellel `char`-l on üks-ühele väiketähtede kaardistamine, mille annab [Unicode Character Database][ucd] [`UnicodeData.txt`], annab iteraator selle `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Kui see `char` nõuab erilisi kaalutlusi (nt mitu sümboli), annab iteraator [`SpecialCasing.txt`] antud sümboli (d).
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// See toiming teostab tingimusteta kaardistamise ilma rätsepata.See tähendab, et teisendamine on kontekstist ja keelest sõltumatu.
    ///
    /// [Unicode Standard]-is käsitletakse 4. peatükis (Märkide atribuudid) juhtumite kaardistamist üldiselt ja 3. peatükis (Conformance) juhtumite teisendamise vaikealgoritmi.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Kordajana:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Otse `println!` kasutamine:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Mõlemad on samaväärsed:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// `to_string` kasutamine:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Mõnikord on tulemuseks mitu tähemärki:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Märgid, millel pole nii suurt kui ka väikest, muudetakse iseendaks.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Tagastab iteraatori, mis annab selle `char` suurte tähtede kaardistamise ühe või enama kujul
    /// `char`s.
    ///
    /// Kui sellel `char`-l pole suurtähtede kaardistust, annab iteraator sama `char`.
    ///
    /// Kui sellel `char`-l on üks-ühele suurtähtede kaardistamine, mille annab [Unicode Character Database][ucd] [`UnicodeData.txt`], annab iteraator selle `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Kui see `char` nõuab erilisi kaalutlusi (nt mitu sümboli), annab iteraator [`SpecialCasing.txt`] antud sümboli (d).
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// See toiming teostab tingimusteta kaardistamise ilma rätsepata.See tähendab, et teisendamine on kontekstist ja keelest sõltumatu.
    ///
    /// [Unicode Standard]-is käsitletakse 4. peatükis (Märkide atribuudid) juhtumite kaardistamist üldiselt ja 3. peatükis (Conformance) juhtumite teisendamise vaikealgoritmi.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Kordajana:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Otse `println!` kasutamine:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Mõlemad on samaväärsed:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// `to_string` kasutamine:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Mõnikord on tulemuseks mitu tähemärki:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Märgid, millel pole nii suurt kui ka väikest, muudetakse iseendaks.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Märkus lokaadi kohta
    ///
    /// Türgi keeles on ladina keeles 'i' ekvivalendil kahe asemel viis vormi:
    ///
    /// * 'Dotless': I/ı, mõnikord kirjutatud ï
    /// * 'Dotted': İ/i
    ///
    /// Pange tähele, et väiketähtedega punktiir 'i' on sama mis ladina täht.Seetõttu:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// `upper_i` väärtus sõltub siin teksti keelest: kui me oleme `en-US`-is, peaks see olema `"I"`, kuid kui me oleme `tr_TR`, peaks see olema `"İ"`.
    /// `to_uppercase()` ei võta seda arvesse ja seega:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// omab kõiki keeli.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Kontrollib, kas väärtus jääb ASCII vahemikku.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Väärtuse koopia teeb selle ASCII suurtähe ekvivalendina.
    ///
    /// ASCII tähed 'a' kuni 'z' vastendatakse tähtedega 'A' kuni 'Z', kuid mitte-ASCII tähed ei muutu.
    ///
    /// Väärtuse suureks muutmiseks kasutage [`make_ascii_uppercase()`]-i.
    ///
    /// ASCII tähtede suurendamiseks lisaks muudele kui ASCII tähemärkidele kasutage [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Teeb väärtuse koopia ASCII väiketähega.
    ///
    /// ASCII tähed 'A' kuni 'Z' vastendatakse tähtedega 'a' kuni 'z', kuid mitte-ASCII tähed ei muutu.
    ///
    /// Väärtuse väikeste tähtede sisestamiseks kasutage [`make_ascii_lowercase()`].
    ///
    /// ASCII tähemärkide lisamiseks väikeste tähtedega lisaks muudele kui ASCII tähemärkidele kasutage [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Kontrollib, kas kaks väärtust vastavad ASCII väiketähtedele.
    ///
    /// Samaväärne `to_ascii_lowercase(a) == to_ascii_lowercase(b)`-ga.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Teisendab selle tüübi oma ASCII suurtähtedega ekvivalendiks.
    ///
    /// ASCII tähed 'a' kuni 'z' vastendatakse tähtedega 'A' kuni 'Z', kuid mitte-ASCII tähed ei muutu.
    ///
    /// Uue suurte väärtuste tagastamiseks olemasolevat muutmata kasutage [`to_ascii_uppercase()`]-i.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Teisendab selle tüübi oma ASCII väiketähtedega samaväärseks.
    ///
    /// ASCII tähed 'A' kuni 'Z' vastendatakse tähtedega 'a' kuni 'z', kuid mitte-ASCII tähed ei muutu.
    ///
    /// Uue väiketähelise väärtuse tagastamiseks olemasolevat muutmata kasutage [`to_ascii_lowercase()`]-i.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Kontrollib, kas väärtus on ASCII tähestikuline täht:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' või
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Kontrollib, kas väärtus on ASCII suurtäht:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Kontrollib, kas väärtus on ASCII väiketäht:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Kontrollib, kas väärtus on ASCII tähtnumbriline märk:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' või
    /// - U + 0061 'a' ..=U + 007A 'z' või
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Kontrollib, kas väärtus on ASCII kümnendkoht:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Kontrollib, kas väärtus on ASCII kuueteistkümnendkohaline arv:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9' või
    /// - U + 0041 'A' ..=U + 0046 'F' või
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Kontrollib, kas väärtus on ASCII kirjavahemärk:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /` või
    /// - U + 003A ..=U + 0040 `: ; < = > ? @` või
    /// - U + 005B ..=U + 0060 "[\] ^ _" `` või
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Kontrollib, kas väärtus on ASCII graafiline märk:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Kontrollib, kas väärtus on ASCII tühimärk:
    /// U + 0020 KOSMOS, U + 0009 HORISONTAALNE TABEL, U + 000A Liinisööt, U + 000C vormisööt või U + 000D VEOLU TAGASI.
    ///
    /// Rust kasutab WhatWG Infra Standardi [definition of ASCII whitespace][infra-aw]-i.Laialdaselt on kasutusel veel mitu definitsiooni.
    /// Näiteks sisaldab [the POSIX locale][pct] nii versiooni U + 000B VERTICAL TAB kui ka kõiki ülaltoodud märke, kuid-samast spetsifikatsioonist lähtudes-["field splitting"-i vaikereegel Bourne shell-is][bfs] arvestab *ainult* SPACE, HORIZONTAL TAB ja RIDASÖÖT tühimikuna.
    ///
    ///
    /// Kui kirjutate programmi, mis töötleb olemasolevat failivormingut, kontrollige enne selle funktsiooni kasutamist, milline on selle vormingu tühimõõt.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Kontrollib, kas väärtus on ASCII kontrollmärk:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR või U + 007F DELETE.
    /// Pange tähele, et enamik ASCII tühimärke on kontrollmärgid, kuid tühik pole.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Kodeerib tooraine u32 väärtusena UTF-8 etteantud baidipuhvrisse ja tagastab seejärel kodeeritud tähemärki sisaldava puhvri alamaluse.
///
///
/// Erinevalt `char::encode_utf8`-ist tegeleb see meetod ka koodipunktidega asendusvahemikus.
/// (`char`-i loomine asendusvahemikus on UB.) Tulemus on kehtiv [generalized UTF-8], kuid mitte kehtiv UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics, kui puhver pole piisavalt suur.
/// Neljapikkune puhver on piisavalt suur, et kodeerida mis tahes `char`-i.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Kodeerib töötlemata u32-väärtuse UTF-16-ks ettenähtud `u16`-puhvrisse ja tagastab seejärel kodeeritud märki sisaldava puhvri alamaluse.
///
///
/// Erinevalt `char::encode_utf16`-ist tegeleb see meetod ka koodipunktidega asendusvahemikus.
/// (`char`-i loomine asendusvahemikus on UB.)
///
/// # Panics
///
/// Panics, kui puhver pole piisavalt suur.
/// Puhver pikkusega 2 on piisavalt suur, et kodeerida mis tahes `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // OHUTUS: iga käsi kontrollib, kas kirjutamiseks on piisavalt bitte
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP kukub läbi
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Täiendavad lennukid lagunevad asendusaineteks.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}