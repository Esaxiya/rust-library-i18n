//! See moodul rakendab rakendust `Any` trait, mis võimaldab mis tahes `'static` tüüpi dünaamilist sisestamist käitusaja peegelduse kaudu.
//!
//! `Any` iseennast saab kasutada `TypeId` saamiseks ja sellel on rohkem funktsioone, kui seda kasutatakse trait objektina.
//! Selle `&dyn Any` (laenatud objekt trait) korral on sellel meetodid `is` ja `downcast_ref`, et testida, kas sisalduv väärtus on teatud tüüpi, ja saada viide sisemisele väärtusele kui tüübile.
//! Nagu `&mut dyn Any`, on olemas ka `downcast_mut` meetod, et saada sisemisele väärtusele muudetav viide.
//! `Box<dyn Any>` lisab meetodi `downcast`, mis üritab teisendada `Box<T>`-i.
//! Lisateavet leiate [`Box`] dokumentatsioonist.
//!
//! Pange tähele, et `&dyn Any` piirdub selle testimisega, kas väärtus on konkreetset tüüpi ja seda ei saa kasutada selle testimiseks, kas tüüp rakendab trait-d.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Nutikad osutid ja `dyn Any`
//!
//! Üks käitumisviis, mida tuleb meeles pidada, kui kasutate `Any`-d trait-objektina, eriti selliste tüüpide puhul nagu `Box<dyn Any>` või `Arc<dyn Any>`, on see, et lihtsalt väärtusele `.type_id()` helistades saadakse *konteineri*`TypeId`, mitte selle aluseks oleva objekti trait.
//!
//! Seda saab vältida, muutes nutika osuti hoopis `&dyn Any`-ks, mis tagastab objekti `TypeId`-i.
//! Näiteks:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Tõenäoliselt soovite seda:
//! let actual_id = (&*boxed).type_id();
//! // ... kui see:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Mõelgem olukorrale, kus me tahame funktsioonile edastatud väärtuse välja logida.
//! Me teame väärtust, millega töötame, Debugit juurutamas, kuid me ei tea selle konkreetset tüüpi.Teatud tüüpidele soovime anda erikäsitluse: antud juhul printida stringide väärtuste pikkus enne nende väärtust.
//! Me ei tea kompileerimise ajal oma väärtuse konkreetset tüüpi, seega peame selle asemel kasutama käitusaja kajastamist.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Loggeri funktsioon igat tüüpi silumiseks.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Proovige teisendada meie väärtus `String`-ks.
//!     // Edu korral tahame edastada nii stringi pikkuse kui ka selle väärtuse.
//!     // Kui ei, siis on see teist tüüpi: printige see lihtsalt ilustamata välja.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // See funktsioon soovib oma parameetri enne sellega töötamist välja logida.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... teha mõnda muud tööd
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Mis tahes trait
///////////////////////////////////////////////////////////////////////////////

/// trait dünaamilise kirjutamise jäljendamiseks.
///
/// Enamik tüüpe rakendab `Any`-i.Ükski tüüp, mis sisaldab mittestaatilist viidet, seda siiski ei tee.
/// Lisateavet leiate [module-level documentation][mod]-st.
///
/// [mod]: crate::any
// See trait pole ohtlik, kuigi tugineme selle ainsa implikaadi `type_id`-funktsiooni eripäradele ebaturvalises koodis (nt `downcast`).Tavaliselt oleks see probleem, kuid kuna `Any`-i ainus implikaat on üldine rakendamine, ei saa ükski teine kood `Any`-i rakendada.
//
// Võiksime selle trait-i usutavalt muuta ohtlikuks-see ei põhjustaks purunemist, kuna me kontrollime kõiki rakendusi-kuid me otsustame seda mitte teha, kuna see pole mõlemad tegelikult vajalik ja võib kasutajaid segi ajada ohtlike traits-de ja ohtlike meetodite (st. `type_id`-i oleks endiselt ohutu helistada, kuid tõenäoliselt sooviksime selle sellisena dokumentides ära märkida).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Saab `self` `self`-st.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Laiendusmeetodid mis tahes objektide trait jaoks.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Veenduge, et nt niidi ühendamise tulemust saab printida ja seega kasutada koos `unwrap`-iga.
// Võib-olla pole enam vajadust, kui lähetamine toimib ülestõusmisega.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Tagastab `true`, kui kasti tüüp on sama mis `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Hankige `TypeId` tüüpi funktsioon, millega see funktsioon on kohandatud.
        let t = TypeId::of::<T>();

        // Hangi `TypeId` tüüpi objekt trait (`self`).
        let concrete = self.type_id();

        // Võrrelge mõlemat võrdõiguslikkuse tüüpi.
        t == concrete
    }

    /// Tagastab mõningase viite kasti väärtusele, kui selle tüüp on `T`, või juhul, kui see pole `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // OHUTUS: lihtsalt kontrollisime, kas osutame õigele tüübile, ja saame loota
            // see kontrollib mälu turvalisust, kuna oleme rakendanud Any igat tüüpi;muid implikaate ei saa eksisteerida, kuna need oleksid meie implikatsiooniga vastuolus.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Tagastab mõnevõrra muudetava viite kasti väärtusele, kui see on tüüpi `T`, või `None`, kui see pole seda.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // OHUTUS: lihtsalt kontrollisime, kas osutame õigele tüübile, ja saame loota
            // see kontrollib mälu turvalisust, kuna oleme rakendanud Any igat tüüpi;muid implikaate ei saa eksisteerida, kuna need oleksid meie implikatsiooniga vastuolus.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Edasi meetodile, mis on määratletud tüübil `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Edasi meetodile, mis on määratletud tüübil `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Edasi meetodile, mis on määratletud tüübil `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Edasi meetodile, mis on määratletud tüübil `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Edasi meetodile, mis on määratletud tüübil `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Edasi meetodile, mis on määratletud tüübil `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID ja selle meetodid
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` tähistab tüübi globaalselt ainulaadset identifikaatorit.
///
/// Iga `TypeId` on läbipaistmatu objekt, mis ei võimalda kontrollida selle sisemust, kuid võimaldab põhitoiminguid, nagu kloonimine, võrdlemine, printimine ja näitamine.
///
///
/// `TypeId` on praegu saadaval ainult tüüpidele, mis omistavad `'static`-le, kuid future-is võib selle piirangu eemaldada.
///
/// Kuigi `TypeId` rakendab `Hash`, `PartialOrd` ja `Ord`, tasub märkida, et räsid ja järjestus varieeruvad Rust väljaannete vahel.
/// Hoiduge oma koodi sees neile lootmast!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Tagastab selle tüübi `TypeId`, millega see üldine funktsioon on liidetud.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Tagastab tüübi nime stringiviiluna.
///
/// # Note
///
/// See on ette nähtud diagnostiliseks kasutamiseks.
/// Tagastatava stringi täpset sisu ja vormingut ei täpsustata, välja arvatud see, et see on tüübi parim pingutus.
/// Näiteks stringide hulgas, mille `type_name::<Option<String>>()` võib tagastada, on `"Option<String>"` ja `"std::option::Option<std::string::String>"`.
///
///
/// Tagastatud stringi ei tohi pidada tüübi kordumatuks identifikaatoriks, kuna mitu tüüpi võivad kaardistada sama tüübi nime.
/// Samamoodi pole mingit garantiid, et kõik tüübi osad ilmuksid tagastatavasse stringi: näiteks pole kogu eluea täpsustajaid praegu lisatud.
/// Lisaks võib väljund kompilaatori versioonide vahel muutuda.
///
/// Praegune rakendus kasutab sama infrastruktuuri nagu kompilaatori diagnostika ja silumisinfo, kuid see pole tagatud.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Tagastab stringi viiluna viidatud väärtuse tüübi nime.
/// See on sama mis `type_name::<T>()`, kuid seda saab kasutada seal, kus muutuja tüüp pole lihtsalt saadaval.
///
/// # Note
///
/// See on ette nähtud diagnostiliseks kasutamiseks.Stringi täpset sisu ja vormingut ei täpsustata, välja arvatud see, et see on tüübi parim pingutus.
/// Näiteks võib `type_name_of_val::<Option<String>>(None)` tagastada `"Option<String>"` või `"std::option::Option<std::string::String>"`, kuid mitte `"foobar"`.
///
/// Lisaks võib väljund kompilaatori versioonide vahel muutuda.
///
/// See funktsioon ei lahenda trait objekte, mis tähendab, et `type_name_of_val(&7u32 as &dyn Debug)` võib tagastada `"dyn Debug"`, kuid mitte `"u32"`.
///
/// Tüübi nime ei tohiks pidada tüübi kordumatuks identifikaatoriks;
/// mitmel tüübil võib olla sama tüüpi nimi.
///
/// Praegune rakendus kasutab sama infrastruktuuri nagu kompilaatori diagnostika ja silumisinfo, kuid see pole tagatud.
///
/// # Examples
///
/// Prindib vaikimisi täis-ja ujukitüübid.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}