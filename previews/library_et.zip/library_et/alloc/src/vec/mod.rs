//! Külgnev kasvatav massiivitüüp kuhjaga eraldatud sisuga, kirjutatud `Vec<T>`.
//!
//! Vectors-l on `O(1)` indekseerimine, amortiseeritud `O(1)` push (lõpuni) ja `O(1)` pop (lõpust).
//!
//!
//! Vectors tagavad, et nad ei eralda kunagi rohkem kui `isize::MAX` baiti.
//!
//! # Examples
//!
//! [`Vec`] saate [`Vec::new`]-iga selgesõnaliselt luua:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... või kasutades makrot [`vec!`]:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // kümme nulli
//! ```
//!
//! [`push`]-väärtused saate sisestada vector otsa (mis vajadusel kasvatab vector-i):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Poppväärtused toimivad umbes samamoodi:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors toetab ka indekseerimist ([`Index`] ja [`IndexMut`] traits kaudu):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Külgnev kasvatav massiivitüüp, kirjutatud kui `Vec<T>` ja hääldatud 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// [`vec!`] makro on ette nähtud selleks, et muuta lähtestamine mugavamaks:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Samuti saab see initsialiseerida `Vec<T>` iga elemendi antud väärtusega.
/// See võib olla tõhusam kui eraldamise ja initsialiseerimise teostamine eraldi sammuna, eriti kui nullida vector:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Järgmine on samaväärne, kuid potentsiaalselt aeglasem:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Lisateavet leiate jaotisest [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Kasutage `Vec<T>`-i tõhusa virnana:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Prindib 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Tüüp `Vec` võimaldab väärtustele juurde pääseda indeksite kaupa, kuna see rakendab [`Index`] trait.Näide on selgem:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // see kuvab '2'
/// ```
///
/// Kuid olge ettevaatlik: kui proovite juurde pääseda indeksile, mida pole `Vec`-is, on teie tarkvara panic!Te ei saa seda teha:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Kasutage [`get`] ja [`get_mut`], kui soovite kontrollida, kas indeks on `Vec`-is.
///
/// # Slicing
///
/// `Vec` võib olla muudetav.Teiselt poolt on viilud kirjutuskaitstud objektid.
/// [slice][prim@slice]-i saamiseks kasutage [`&`]-i.Näide:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... ja see on kõik!
/// // saate seda teha ka nii:
/// let u: &[usize] = &v;
/// // või selline:
/// let u: &[_] = &v;
/// ```
///
/// Rakenduses Rust on levinum jagada viilud argumentidena, mitte vectors, kui soovite lihtsalt pakkuda lugemisõigust.Sama kehtib ka [`String`] ja [`&str`] kohta.
///
/// # Mahutavus ja ümberjaotamine
///
/// vector maht on ruumi suurus, mis on eraldatud mis tahes future elementide jaoks, mis lisatakse vector-le.Seda ei tohi segi ajada vector *pikkusega*, mis määrab vector-s olevate tegelike elementide arvu.
/// Kui vector pikkus ületab selle võimsust, suurendatakse selle võimsust automaatselt, kuid selle elemendid tuleb ümber jaotada.
///
/// Näiteks vector mahuga 10 ja pikkusega 0 oleks tühi vector, kus oleks ruumi veel 10 elemendile.10 või vähem elemendi surumine vector-le ei muuda selle mahtu ega põhjusta ümberjaotamist.
/// Kui aga vector pikkust suurendatakse 11-ni, tuleb see ümber jaotada, mis võib olla aeglane.Sel põhjusel on soovitatav kasutada [`Vec::with_capacity`]-i igal võimalusel, et täpsustada, kui suure vector-i eeldatavasti saab.
///
/// # Guarantees
///
/// Oma uskumatult põhimõttelise olemuse tõttu annab `Vec` oma disaini kohta palju garantiisid.See tagab, et see on üldjuhul võimalikult madal üldkulude arv ja ebaturvalise koodi abil saab seda primitiivsetel viisidel õigesti manipuleerida.Pange tähele, et need garantiid viitavad kvalifitseerimata `Vec<T>`-le.
/// Kui lisatakse täiendavaid tüübiparameetreid (nt kohandatud eraldajate toetamiseks), võib nende vaikeseadetest tühistamine käitumist muuta.
///
/// Põhimõtteliselt on ja jääb `Vec` alati (osuti, maht, pikkus) kolmikuks.Ei rohkem ega vähem.Nende väljade järjekord on täiesti määratlemata ja nende muutmiseks peaksite kasutama sobivaid meetodeid.
/// Kursor ei saa kunagi olla null, seega on see tüüp null-pointeri jaoks optimeeritud.
///
/// Kuid kursor ei pruugi tegelikult osutada eraldatud mälule.
/// Eelkõige, kui ehitate `Vec` võimsusega 0 kaudu [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`] või helistades tühjale Vecile [`shrink_to_fit`], ei eralda see mälu.Samamoodi, kui salvestate `Vec`-i sisse nullsuuruseid tüüpe, ei eralda see neile ruumi.
/// *Pange tähele, et sel juhul ei pruugi `Vec` teatada [`capacity`] väärtusest 0*.
/// `Vec` eraldab ainult siis, kui [`mem: : size_of::<T>"](() * capacity()> 0".
/// Üldiselt on `Veci jaotuse üksikasjad väga peened-kui kavatsete eraldada mälu `Vec`-iga ja kasutada seda millekski muuks (kas ohtlikule koodile edastamiseks või oma mäluga toetatud kogu loomiseks), siis veenduge selle mälu jaotamiseks `Vec` taastamiseks ja seejärel kukutamiseks `from_raw_parts`.
///
/// Kui `Vec`*-il on* eraldatud mälu, siis on mälu, millele ta osutab, kuhja (vastavalt jaotaja Rust määratlusele on vaikimisi konfigureeritud kasutamiseks) ja selle osuti osutab järjekorras [`len`] initsialiseeritud, külgnevatele elementidele (mida te vaadake, kas sundisite seda viiluks), millele järgnevad [`võime`],`[`` len`] loogiliselt initsialiseerimata, külgnevad elemendid.
///
///
/// vector, mis sisaldab elemente `'a'` ja `'b'`, mahtuvusega 4, saab visualiseerida järgmiselt.Ülemine osa on `Vec`-struktuur, see sisaldab kursorit jaotuse pea kohale kuhja, pikkuse ja mahuga.
/// Alumine osa on eraldus kuhjaga, külgnev mäluplokk.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** tähistab mälu, mida ei lähtestata, vt [`MaybeUninit`].
/// - Note: ABI ei ole stabiilne ja `Vec` ei garanteeri oma mälu paigutust (ka väljade järjekorda).
///
/// `Vec` ei soorita kunagi "small optimization"-i, kus elemendid on virnas tegelikult salvestatud, kahel põhjusel:
///
/// * See muudaks `Vec`-iga õigesti manipuleerimise ebaturvalise koodi jaoks keerulisemaks.`Vec`-i sisul ei oleks stabiilset aadressi, kui see ainult liigutataks, ja seda, kas `Vec` oleks tegelikult mälu eraldanud, oleks keerulisem kindlaks teha.
///
/// * See karistaks üldist juhtumit, tekitades igal juurdepääsul täiendava branch.
///
/// `Vec` ei kahane kunagi automaatselt, isegi kui see on täiesti tühi.See tagab, et asjatut jaotamist või jaotamist ei toimu.`Vec`-i tühjendamine ja seejärel sama [`len`]-i varundamine ei tohiks eraldajale helistada.Kasutamata mälu vabastamiseks kasutage [`shrink_to_fit`] või [`shrink_to`].
///
/// [`push`] ja [`insert`] ei eralda (ümber) kunagi, kui teatatud võimsus on piisav.[`push`] ja [`insert`]*eraldavad*(uuesti), kui ["len"] "==" ["maht"].See tähendab, et teatatud maht on täiesti täpne ja sellele saab tugineda.Soovi korral saab seda kasutada ka `Vec`-i eraldatud mälu käsitsi vabastamiseks.
/// Hulgisisestusmeetodid * võivad ümber jaotuda, isegi kui see pole vajalik.
///
/// `Vec` ei garanteeri mingit konkreetset kasvustrateegiat ei täieliku ümberjaotamise ega ka [`reserve`]-i kutsumise korral.Praegune strateegia on põhiline ja võib osutuda soovitavaks kasutada mittepüsivat kasvufaktorit.Ükskõik millist strateegiat kasutatakse, garanteerib muidugi *O*(1) amortiseeritud [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]` ja [`Vec::with_capacity(n)`][`Vec::with_capacity`] toodavad kõik täpselt nõutava võimsusega `Vec`-i.
/// Kui [`len`]`==`[` mahtuvus '](nagu makro [`vec!`] puhul), siis saab `Vec<T>` teisendada [`Box<[T]>`][owned slice]-ks ja sellest ilma elemente ümber jaotamata või teisaldamata.
///
/// `Vec` ei kirjuta spetsiaalselt üle ühtegi sellelt eemaldatud teavet, kuid ei ka neid spetsiaalselt säilitama.Selle initsialiseerimata mälu on tühimik, mida ta võib kasutada nii, nagu soovib.Üldiselt teeb ta lihtsalt kõike, mis on kõige tõhusam või muul viisil hõlpsasti rakendatav.Ärge usaldage eemaldatud andmete kustutamist turvalisuse huvides.
/// Isegi kui `Vec` maha viskate, võib teine `Vec` selle puhvrit lihtsalt uuesti kasutada.
/// Isegi kui nullite kõigepealt `Veci mälu, ei pruugi see tegelikult juhtuda, sest optimeerija ei pea seda kõrvalmõjuks, mida tuleb säilitada.
/// Siiski on üks juhtum, mida me ei murra: `unsafe`-koodi kasutamine üleliigse võimsuse kirjutamiseks ja seejärel pikkuse suurendamine sobitamiseks on alati kehtiv.
///
/// Praegu ei taga `Vec` elementide väljalangemise järjekorda.
/// Järjekord on varem muutunud ja võib uuesti muutuda.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Loomupärased meetodid
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Ehitab uue, tühja `Vec<T>`-i.
    ///
    /// vector ei eralda enne, kui elemendid on sellele surutud.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Ehitab uue, tühja `Vec<T>` määratud mahuga.
    ///
    /// vector suudab täpselt ümber paigutada `capacity` elemente.
    /// Kui `capacity` on 0, ei eralda vector.
    ///
    /// Oluline on märkida, et kuigi tagastatud vector on määratud *võimsusega*, on vector null *pikkusega*.
    ///
    /// Pikkuse ja läbilaskevõime erinevuse selgituse leiate artiklist *[Mahutavus ja ümberjaotamine]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector ei sisalda üksusi, kuigi see mahutab rohkem
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Need kõik tehakse ümber jaotamata ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... kuid see võib muuta vector ümberpaigutamise
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Loob `Vec<T>` otse teise vector toorainekomponentidest.
    ///
    /// # Safety
    ///
    /// Kontrollimata invariantide arvu tõttu on see väga ohtlik:
    ///
    /// * `ptr` peab olema eelnevalt eraldatud [`String`i]/`Vec<T>"(vähemalt on suure tõenäosusega vale, kui see nii ei olnud).
    /// * `T` peab olema sama suur ja joondatud kui millega `ptr` eraldati.
    ///   (Vähem range joondusega `T`-st ei piisa, joondamine peab tõesti olema võrdne, et täita [`dealloc`]-i nõue, et mälu tuleb eraldada ja paigutada sama paigutusega.)
    ///
    /// * `length` peab olema väiksem või võrdne `capacity`-ga.
    /// * `capacity` peab olema maht, millele osuti eraldati.
    ///
    /// Nende rikkumine võib tekitada probleeme, näiteks rikutakse eraldaja sisemisi andmestruktuure.Näiteks pole ** ohutu ehitada `Vec<u8>` kursorist C `char` massiivi pikkusega `size_t`.
    /// Samuti pole ohutu ehitada üks `Vec<u16>`-st ja selle pikkusest, sest eraldaja hoolib joondusest ja neil kahel tüübil on erinevad joondused.
    /// Puhver eraldati joondusega 2 (`u16` jaoks), kuid pärast selle muutmist `Vec<u8>`-ks paigutatakse see joondusega 1.
    ///
    /// `ptr` omandiõigus antakse üle `Vec<T>`-le, mis võib seejärel osuti soovi korral jaotada, ümber jaotada või muuta mälu sisu.
    /// Pärast selle funktsiooni kutsumist veenduge, et miski muu ei kasutaks kursorit.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Värskendage seda, kui vec_into_raw_parts on stabiliseerunud.
    ///     // Takistage `v` destruktori käivitamist, et saaksime jaotust täielikult kontrollida.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Tõmmake välja `v`-i kohta mitu olulist teavet
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Mälu kirjutamine 4, 5, 6 abil
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Pange kõik kokku Veciks
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Ehitab uue, tühja `Vec<T, A>`-i.
    ///
    /// vector ei eralda enne, kui elemendid on sellele surutud.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Ehitab määratud eraldajaga uue, tühja `Vec<T, A>`-i koos määratud mahutavusega.
    ///
    /// vector suudab täpselt ümber paigutada `capacity` elemente.
    /// Kui `capacity` on 0, ei eralda vector.
    ///
    /// Oluline on märkida, et kuigi tagastatud vector on määratud *võimsusega*, on vector null *pikkusega*.
    ///
    /// Pikkuse ja läbilaskevõime erinevuse selgituse leiate artiklist *[Mahutavus ja ümberjaotamine]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector ei sisalda üksusi, kuigi see mahutab rohkem
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Need kõik tehakse ümber jaotamata ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... kuid see võib muuta vector ümberpaigutamise
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Loob `Vec<T, A>` otse teise vector toorainekomponentidest.
    ///
    /// # Safety
    ///
    /// Kontrollimata invariantide arvu tõttu on see väga ohtlik:
    ///
    /// * `ptr` peab olema eelnevalt eraldatud [`String`i]/`Vec<T>"(vähemalt on suure tõenäosusega vale, kui see nii ei olnud).
    /// * `T` peab olema sama suur ja joondatud kui millega `ptr` eraldati.
    ///   (Vähem range joondusega `T`-st ei piisa, joondamine peab tõesti olema võrdne, et täita [`dealloc`]-i nõue, et mälu tuleb eraldada ja paigutada sama paigutusega.)
    ///
    /// * `length` peab olema väiksem või võrdne `capacity`-ga.
    /// * `capacity` peab olema maht, millele osuti eraldati.
    ///
    /// Nende rikkumine võib tekitada probleeme, näiteks rikutakse eraldaja sisemisi andmestruktuure.Näiteks pole ** ohutu ehitada `Vec<u8>` kursorist C `char` massiivi pikkusega `size_t`.
    /// Samuti pole ohutu ehitada üks `Vec<u16>`-st ja selle pikkusest, sest eraldaja hoolib joondusest ja neil kahel tüübil on erinevad joondused.
    /// Puhver eraldati joondusega 2 (`u16` jaoks), kuid pärast selle muutmist `Vec<u8>`-ks paigutatakse see joondusega 1.
    ///
    /// `ptr` omandiõigus antakse üle `Vec<T>`-le, mis võib seejärel osuti soovi korral jaotada, ümber jaotada või muuta mälu sisu.
    /// Pärast selle funktsiooni kutsumist veenduge, et miski muu ei kasutaks kursorit.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Värskendage seda, kui vec_into_raw_parts on stabiliseerunud.
    ///     // Takistage `v` destruktori käivitamist, et saaksime jaotust täielikult kontrollida.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Tõmmake välja `v`-i kohta mitu olulist teavet
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Mälu kirjutamine 4, 5, 6 abil
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Pange kõik kokku Veciks
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Lagundab `Vec<T>` toorkomponentideks.
    ///
    /// Tagastab lähteanduri aluseks olevatele andmetele, vector pikkusele (elementides) ja andmete eraldatud mahule (elementides).
    /// Need on samad argumendid samas järjekorras kui [`from_raw_parts`]-i argumendid.
    ///
    /// Pärast selle funktsiooni kutsumist vastutab helistaja `Vec` poolt varem hallatud mälu eest.
    /// Ainus viis selleks on teisendada toores osuti, pikkus ja maht tagasi `Vec`-ks funktsiooniga [`from_raw_parts`], mis võimaldab hävitajal puhastada.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Nüüd saame komponentides muudatusi teha, näiteks töötlemata kursori teisendamine ühilduvaks tüübiks.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Lagundab `Vec<T>` toorkomponentideks.
    ///
    /// Tagastab lähteanduri aluseks olevatele andmetele, vector pikkusele (elementides), andmete eraldatud võimsusele (elementides) ja eraldajale.
    /// Need on samad argumendid samas järjekorras kui [`from_raw_parts_in`]-i argumendid.
    ///
    /// Pärast selle funktsiooni kutsumist vastutab helistaja `Vec` poolt varem hallatud mälu eest.
    /// Ainus viis selleks on teisendada toores osuti, pikkus ja maht tagasi `Vec`-ks funktsiooniga [`from_raw_parts_in`], mis võimaldab hävitajal puhastada.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Nüüd saame komponentides muudatusi teha, näiteks töötlemata kursori teisendamine ühilduvaks tüübiks.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Tagastab elementide arvu, mida vector mahutab ilma ümberjaotamiseta.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Reserveerib ruumi vähemalt `additional` elemendi sisestamiseks antud `Vec<T>`-i.
    /// Kollektsioon võib reserveerida rohkem ruumi, et vältida sagedasi ümberjaotusi.
    /// Pärast `reserve`-i helistamist on maht suurem või võrdne `self.len() + additional`-ga.
    /// Ei tee midagi, kui võimsus on juba piisav.
    ///
    /// # Panics
    ///
    /// Panics, kui uus maht ületab `isize::MAX` baiti.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Reserveerib minimaalse võimsuse täpselt `additional` elemendi sisestamiseks antud `Vec<T>`-i.
    ///
    /// Pärast `reserve_exact`-i helistamist on maht suurem või võrdne `self.len() + additional`-ga.
    /// Ei tee midagi, kui mahutavus on juba piisav.
    ///
    /// Pange tähele, et eraldaja võib anda kollektsioonile rohkem ruumi, kui see nõuab.
    /// Seetõttu ei saa loota, et võimsus on täpselt minimaalne.
    /// Eelistage `reserve`-i, kui eeldatakse future sisestamist.
    ///
    /// # Panics
    ///
    /// Panics, kui uus maht ületab `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Püüab reserveerida võimsuse, et antud `Vec<T>`-i sisestada veel vähemalt `additional` elementi.
    /// Kollektsioon võib reserveerida rohkem ruumi, et vältida sagedasi ümberjaotusi.
    /// Pärast `try_reserve`-i helistamist on maht suurem või võrdne `self.len() + additional`-ga.
    /// Ei tee midagi, kui võimsus on juba piisav.
    ///
    /// # Errors
    ///
    /// Kui läbilaskevõime ületatakse või kui eraldaja teatab rikkest, tagastatakse tõrge.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Eelnevalt reserveerige mälu, sulgege, kui me ei saa
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Nüüd teame, et see ei saa meie keeruka töö keskel OOM-i teha
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // väga keeruline
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Püüab reserveerida minimaalse võimsuse täpselt `additional` elementide sisestamiseks antud `Vec<T>`-i.
    /// Pärast `try_reserve_exact`-i helistamist on võimsus suurem kui `self.len() + additional` või sellega võrdne, kui see tagastab `Ok(())`.
    ///
    /// Ei tee midagi, kui mahutavus on juba piisav.
    ///
    /// Pange tähele, et eraldaja võib anda kollektsioonile rohkem ruumi, kui see nõuab.
    /// Seetõttu ei saa loota, et võimsus on täpselt minimaalne.
    /// Eelistage `reserve`-i, kui eeldatakse future sisestamist.
    ///
    /// # Errors
    ///
    /// Kui läbilaskevõime ületatakse või kui eraldaja teatab rikkest, tagastatakse tõrge.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Eelnevalt reserveerige mälu, sulgege, kui me ei saa
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Nüüd teame, et see ei saa meie keeruka töö keskel OOM-i teha
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // väga keeruline
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Kahandab vector võimsust nii palju kui võimalik.
    ///
    /// See langeb pikkusele võimalikult lähedale, kuid eraldaja võib siiski vector-le teatada, et ruumi on veel paaril elemendil.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Mahutavus pole kunagi väiksem kui pikkus ja nende võrdsel tasemel pole midagi teha, seega saame `RawVec::shrink_to_fit`-is panic-juhtumit vältida, helistades sellele ainult suurema võimsusega.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Kahandab vector võimsust alumise piiriga.
    ///
    /// Mahutavus jääb vähemalt nii suureks kui pikkus ja tarnitud väärtus.
    ///
    ///
    /// Kui praegune võimsus on väiksem kui alumine piir, on see keelatud.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Teisendab vector [`Box<[T]>`][owned slice]-ks.
    ///
    /// Pange tähele, et see vähendab üleliigset võimsust.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Liigne võimsus eemaldatakse:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Lühendab vector, säilitades esimesed `len` elemendid ja kukutades ülejäänud.
    ///
    /// Kui `len` on suurem kui vector praegune pikkus, pole sellel mingit mõju.
    ///
    /// [`drain`]-meetod võib jäljendada `truncate`-i, kuid põhjustab liigsete elementide tagastamise, mitte langemise.
    ///
    ///
    /// Pange tähele, et see meetod ei mõjuta vector eraldatud võimsust.
    ///
    /// # Examples
    ///
    /// Viie elemendi vector kärpimine kaheks elemendiks:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Kärpimist ei toimu, kui `len` on suurem kui vector praegune pikkus:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Lühendamine, kui `len == 0` on samaväärne meetodi [`clear`] kutsumisega.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // See on ohutu, kuna:
        //
        // * `drop_in_place`-le edastatud viil on kehtiv;juhtum `len > self.len` väldib vale viilu loomist ja
        // * vector `len` on enne `drop_in_place`-ile helistamist kahanenud, nii et ükski väärtus ei lange kaks korda, kui `drop_in_place` oleks üks kord panic (kui see on kaks korda panics, katkestatakse programm).
        //
        //
        //
        unsafe {
            // Note: On tahtlik, et see on `>` ja mitte `>=`.
            //       `>=`-i muutmine mõjutab mõnel juhul negatiivseid tulemusi.
            //       Lisateavet leiate jaotisest #78884.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Ekstreerib kogu vector sisaldava viilu.
    ///
    /// Samaväärne `&s[..]`-ga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Ekstraktib kogu vector muutuva viilu.
    ///
    /// Samaväärne `&mut s[..]`-ga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Tagastab toore kursori vector puhvrisse.
    ///
    /// Helistaja peab tagama, et funktsioon vector elaks üle selle funktsiooni tagastatava kursori, vastasel juhul näitab see prügi.
    /// vector muutmine võib põhjustada selle puhvri ümberjaotamise, mis muudaks ka kõik sellele osutavad näited kehtetuks.
    ///
    /// Helistaja peab ka tagama, et mälu, millele osuti (non-transitively) osutab, ei kirjutataks kunagi (välja arvatud `UnsafeCell` sees), kasutades seda kursorit või sellest tuletatud osuti.
    /// Kui peate viilu sisu muteerima, kasutage [`as_mut_ptr`]-i.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Varjutame samanimelist viilumeetodit, et vältida `deref`-i läbimist, mis loob vahepealse viite.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Tagastab ebaturvalise muudetava osuti vector puhvrisse.
    ///
    /// Helistaja peab tagama, et funktsioon vector elaks üle selle funktsiooni tagastatava kursori, vastasel juhul näitab see prügi.
    ///
    /// vector muutmine võib põhjustada selle puhvri ümberjaotamise, mis muudaks ka kõik sellele osutavad näited kehtetuks.
    ///
    /// # Examples
    ///
    /// ```
    /// // Eraldage vector piisavalt suureks 4 elemendi jaoks.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Initsialiseerige elemendid toores kursori kirjutamise kaudu, seejärel määrake pikkus.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Varjutame samanimelist viilumeetodit, et vältida `deref_mut`-i läbimist, mis loob vahepealse viite.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Tagastab viite aluseks olevale eraldajale.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Sundib vector pikkust `new_len`-ni.
    ///
    /// See on madala taseme operatsioon, mis ei hoia ühtegi tüübi tavalist invarianti.
    /// Tavaliselt muudetakse vector pikkust ühe ohutu toimingu abil, näiteks [`truncate`], [`resize`], [`extend`] või [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` peab olema väiksem kui [`capacity()`] või sellega võrdne.
    /// - `old_len..new_len`-i elemendid tuleb lähtestada.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// See meetod võib olla kasulik olukordades, kus vector on puhver muu koodi jaoks, eriti FFI kaudu:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // See on doc-näite jaoks vaid minimaalne skelett;
    /// # // ära kasuta seda tõelise raamatukogu lähtepunktina.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // FFI meetodi dokumentide järgi "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // OHUTUS: Kui `deflateGetDictionary` tagastab `Z_OK`, leiab ta, et:
    ///     // 1. `dict_length` elemendid initsialiseeriti.
    ///     // 2.
    ///     // `dict_length` <=maht (32_768), mis muudab `set_len`-i helistamise ohutuks.
    ///     unsafe {
    ///         // Helistage FFI-sse ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... ja värskendage pikkus initsialiseeritud.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Kuigi järgmine näide on heli, on mäluleke, kuna sisemisi vektoreid ei vabastatud enne `set_len` kõnet:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` on tühi, seega pole elemente vaja lähtestada.
    /// // 2. `0 <= capacity` hoiab alati ükskõik, mis `capacity` on.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Tavaliselt kasutatakse siin sisu õigeks viskamiseks ja seega mälu lekkimiseks [`clear`]-i.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Eemaldab elemendi vector-st ja tagastab selle.
    ///
    /// Eemaldatud element asendatakse vector viimase elemendiga.
    ///
    /// See ei säilita tellimist, vaid on O(1).
    ///
    /// # Panics
    ///
    /// Panics, kui `index` on väljaspool piire.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Asendame ise [register] viimase elemendiga.
            // Pange tähele, et kui ülaltoodud piirikontroll õnnestub, peab olema viimane element (mis võib olla ka ise [register]).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Lisab elemendi vector sisse asendis `index`, nihutades kõik elemendid pärast seda paremale.
    ///
    ///
    /// # Panics
    ///
    /// Panics kui `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // ruumi uuele elemendile
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // eksimatu Uue väärtuse leidmise koht
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Ruumi saamiseks nihutage kõik üle.
                // (Indeksi "element" paljundamine kaheks järjestikuseks kohaks.)
                ptr::copy(p, p.offset(1), len - index);
                // Kirjutage see sisse, kirjutades üle elemendi `index 'esimese eksemplari.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Eemaldab ja tagastab elemendi vector sees positsioonis `index`, nihutades kõik elemendid pärast seda vasakule.
    ///
    ///
    /// # Panics
    ///
    /// Panics, kui `index` on väljaspool piire.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // koht, kust võtame.
                let ptr = self.as_mut_ptr().add(index);
                // kopeerige see välja, olles väärtuse koopia korraga nii virnas kui ka vector-s.
                //
                ret = ptr::read(ptr);

                // Selle koha täitmiseks nihutage kõike alla.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Säilitab ainult predikaadiga määratud elemendid.
    ///
    /// Teisisõnu eemaldage kõik elemendid `e` nii, et `f(&e)` tagastaks `false`.
    /// See meetod töötab paigas, külastades kõiki elemente täpselt üks kord algses järjekorras ja säilitades allesjäänud elementide järjekorra.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Kuna elemente külastatakse täpselt üks kord algses järjekorras, võib väliste olekute põhjal otsustada, milliseid elemente säilitada.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Vältige topeltkukkumist, kui kukkumiskaitset ei rakendata, kuna võime protsessi käigus teha mõningaid auke.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-töödeldud len-> |^-kontrollimiseks kõrval
        //                  | <-kustutatud cnt-> |
        //      | <-original_len-> |Hoidis: elemendid, mis predikaadina vastavad tõele.
        //
        // Auk: teisaldatud või langetatud elemendi pesa.
        // Märkimata: kontrollimata kehtivad elemendid.
        //
        // Sellele kukkumiskaitsele pöördutakse siis, kui elemendi predikaat või `drop` satub paanikasse.
        // See nihutab kontrollimata elemente aukude ja `set_len` katmiseks õige pikkusega.
        // Kui predikaat ja `drop` ei paanitse kunagi, optimeeritakse see välja.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // OHUTUS: Kontrollimata üksused peavad olema kehtivad, kuna me ei puuduta neid kunagi.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // OHUTUS: Pärast aukude täitmist on kõik üksused külgnevas mälus.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // OHUTUS: Kontrollimata element peab olema kehtiv.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Kui `drop_in_place` satub paanikasse, vältige varakult topeltkukkumist.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // OHUTUS: Me ei puutu seda elementi enam kunagi pärast mahakukkumist.
                unsafe { ptr::drop_in_place(cur) };
                // Juba viisime loenduri edasi.
                continue;
            }
            if g.deleted_cnt > 0 {
                // OHUTUS: `deleted_cnt`> 0, seega ei tohi auguauk praeguse elemendiga kattuda.
                // Me kasutame liikumiseks koopiat ega puuduta seda elementi enam kunagi.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Kõik üksused on töödeldud.Seda saab LLVM-i abil `set_len`-i optimeerida.
        drop(g);
    }

    /// Eemaldab kõik vector järjestikused elemendid, välja arvatud esimesed, mis lahendavad sama võtme.
    ///
    ///
    /// Kui vector on sorteeritud, eemaldab see kõik duplikaadid.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Eemaldab vector kõik järjestikused elemendid, välja arvatud esimene, mis vastavad antud võrdsussuhtele.
    ///
    /// Funktsioon `same_bucket` edastatakse viitega kahele elemendile vector-st ja see peab määrama, kas elemendid on võrdsed.
    /// Elemendid edastatakse viilu järjestuses vastupidises järjekorras, nii et kui `same_bucket(a, b)` tagastab `true`, eemaldatakse `a`.
    ///
    ///
    /// Kui vector on sorteeritud, eemaldab see kõik duplikaadid.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Lisab kollektsiooni tagaküljele elemendi.
    ///
    /// # Panics
    ///
    /// Panics, kui uus maht ületab `isize::MAX` baiti.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // See eraldab panic või katkestab, kui eraldaksime> isize::MAX baiti või kui pikkuse juurdekasv ületaks nullsuuruste tüüpide korral.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Eemaldab vector-st viimase elemendi ja tagastab selle või [`None`]-i, kui see on tühi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Teisaldab kõik `other` elemendid `Self`-i, jättes `other`-i tühjaks.
    ///
    /// # Panics
    ///
    /// Panics, kui elementide arv vector-s ületab `usize`-i.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Lisab elemendile `Self` muu puhvri elemendid.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Loob tühjendava iteraatori, mis eemaldab vector-s määratud vahemiku ja annab eemaldatud üksused.
    ///
    /// Kui iteraator **langeb**, eemaldatakse kõik vahemikus olevad elemendid vector-st isegi siis, kui iteraator ei olnud täielikult tarbitud.
    /// Kui iteraator **ei ole** langenud (näiteks [`mem::forget`]-iga), pole täpsustatud, mitu elementi eemaldatakse.
    ///
    /// # Panics
    ///
    /// Panics, kui alguspunkt on suurem kui lõpp-punkt või kui lõpp-punkt on suurem kui vector pikkus.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Kogu vahemik puhastab vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Mälu ohutus
        //
        // Kui Drain esimest korda luuakse, lühendab see allika vector pikkust veendumaks, et ükski initsialiseerimata või teisaldatud element ei ole üldse ligipääsetav, kui Drain hävitaja ei saa kunagi käima.
        //
        //
        // Drain eemaldab ptr::read eemaldatavad väärtused.
        // Kui see on lõpetatud, kopeeritakse aukude järelejäänud vanade saba tagasi ja vector pikkus taastatakse uuele pikkusele.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // seadke self.vec pikkused alguseks, et olla ohutu juhul, kui Drain lekib
            self.set_len(start);
            // Kasutage IterMutis olevat laenu, et näidata kogu Drain iteraatori laenukäitumist (nagu &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Kustutab vector, eemaldades kõik väärtused.
    ///
    /// Pange tähele, et see meetod ei mõjuta vector eraldatud võimsust.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Tagastab elementide arvu vector-s, mida nimetatakse ka selle 'length'-ks.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Tagastab `true`, kui vector ei sisalda elemente.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Jagab kogu antud indeksis kaheks.
    ///
    /// Tagastab äsja eraldatud vector, mis sisaldab elemente vahemikus `[at, len)`.
    /// Pärast kõnet jääb originaal vector, mis sisaldab elemente `[0, at)`, mille senine maht on muutmata.
    ///
    ///
    /// # Panics
    ///
    /// Panics kui `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // uus vector võib üle võtta originaalpuhvri ja vältida koopiat
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Ebaturvaliselt `set_len` ja kopeerige üksused `other`-i.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Muuda `Vec`-i suurust paigas nii, et `len` oleks võrdne `new_len`-ga.
    ///
    /// Kui `new_len` on suurem kui `len`, pikendatakse `Vec` erinevusega, kusjuures iga täiendav pesa täidetakse sulgemisega `f` helistamise tulemusega.
    ///
    /// `f`-i tagastusväärtused jõuavad `Vec`-i nende loodud järjekorras.
    ///
    /// Kui `new_len` on väiksem kui `len`, kärbitakse `Vec` lihtsalt.
    ///
    /// See meetod kasutab sulgemist, et igal tõukel luua uusi väärtusi.Kui soovite [`Clone`]-i antud väärtuse asemel kasutada [`Vec::resize`]-i.
    /// Kui soovite väärtuste loomiseks kasutada seadet [`Default`] trait, võite teise argumendina edastada [`Default::default`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Tarbib ja lekitab `Vec`-i, tagastades muutuva viite sisule, `&'a mut [T]`.
    /// Pange tähele, et tüüp `T` peab valitud eluea `'a` üle elama.
    /// Kui tüübil on ainult staatilised viited või neid pole üldse, siis võib selle valida `'static`.
    ///
    /// See funktsioon sarnaneb [`Box`]-i funktsiooniga [`leak`][Box::leak], välja arvatud see, et lekkinud mälu pole võimalik taastada.
    ///
    ///
    /// See funktsioon on peamiselt kasulik andmete jaoks, mis elavad programmi ülejäänud elu.
    /// Tagastatud viite langetamine põhjustab mälulekke.
    ///
    /// # Examples
    ///
    /// Lihtne kasutamine:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Tagastab vector järelejäänud vaba võimsuse `MaybeUninit<T>` viiluna.
    ///
    /// Tagastatud viilu saab kasutada vector täitmiseks andmetega (nt
    /// failist lugedes) enne andmete [`set_len`]-meetodil initsialiseerituks märkimist.
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Eraldage vector piisavalt suureks 10 elemendi jaoks.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Sisestage kolm esimest elementi.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Märkige vector esimesed 3 elementi initsialiseeritavaks.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Seda meetodit ei rakendata `split_at_spare_mut`-ga, et vältida puhvris olevate osutite kehtetuks muutmist.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Tagastab vector-sisu `T`-i viiluna koos vector-i ülejäänud vaba mahuga `MaybeUninit<T>`-i viiluna.
    ///
    /// Tagastatud vaba võimsuse viilu saab kasutada vector täitmiseks andmetega (nt failist lugedes) enne andmete [`set_len`]-meetodil initsialiseerituks märkimist.
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Pange tähele, et see on madala taseme API, mida tuleks optimeerimise eesmärgil hoolikalt kasutada.
    /// Kui peate `Vec`-ile andmed lisama, võite sõltuvalt oma täpsetest vajadustest kasutada seadmeid [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] või [`resize_with`].
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Broneerige piisavalt ruumi 10 elemendi jaoks.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Täitke järgmised 4 elementi.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Märkige vector 4 elementi initsialiseeritavaks.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - lenit ignoreeritakse ja nii ei muudeta kunagi
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Ohutus: tagastatud .2 (&mut usize) muutmist peetakse samaks kui `.set_len(_)`-i helistamist.
    ///
    /// Selle meetodi abil on ainulaadne juurdepääs kõigile vanadele osadele korraga `extend_from_within`-is.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` on garanteeritud, et see kehtib `len` elementide jaoks
        // - `spare_ptr` osutab ühe elemendi puhvrist mööda, nii et see ei kattuks `initialized`-iga
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Muuda `Vec`-i suurust paigas nii, et `len` oleks võrdne `new_len`-ga.
    ///
    /// Kui `new_len` on suurem kui `len`, pikendatakse `Vec` erinevusega, kusjuures iga täiendav pesa on täidetud `value`-ga.
    ///
    /// Kui `new_len` on väiksem kui `len`, kärbitakse `Vec` lihtsalt.
    ///
    /// Selle meetodi jaoks on [`Clone`]-i juurutamiseks vaja `T`-i, et oleks võimalik edastatud väärtust kloonida.
    /// Kui vajate suuremat paindlikkust (või soovite [`Clone`] asemel kasutada [`Default`]-i), kasutage [`Vec::resize_with`]-i.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Kloonib ja liidab kõik viilu elemendid `Vec`-i.
    ///
    /// Kordub viilu `other` kohal, kloonib iga elemendi ja liidab selle seejärel `Vec`-iga.
    /// `other` vector läbitakse järjekorras.
    ///
    /// Pange tähele, et see funktsioon on sama mis [`extend`], välja arvatud see, et see on spetsialiseerunud viiludega töötamiseks.
    ///
    /// Kui ja kui Rust saab spetsialiseerumise, on see funktsioon tõenäoliselt aegunud (kuid on endiselt saadaval).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Kopeerib elemendid vahemikust `src` kuni vector lõpuni.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` tagab, et antud vahemik kehtib enese indekseerimiseks
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// See kood üldistab `extend_with_{element,default}`-i.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Laiendage vector väärtusi `n` võrra, kasutades antud generaatorit.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Vea kõrvaldamiseks kasutage seadet SetLenOnDrop, kus kompilaator ei pruugi poodi `ptr` kaudu realiseerida-self.set_len() ei pseudonüümi.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Kirjutage kõik elemendid, välja arvatud viimane
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Juhul next() panics suurendage iga sammu pikkust
                local_len.increment_len(1);
            }

            if n > 0 {
                // Viimase elemendi võime kirjutada otse ilma asjatult kloonimata
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len poolt määratud ulatuse valvur
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Eemaldab vector järjestikused korduvad elemendid vastavalt rakendusele [`PartialEq`] trait.
    ///
    ///
    /// Kui vector on sorteeritud, eemaldab see kõik duplikaadid.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sisemised meetodid ja funktsioonid
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` peab olema kehtiv register
    /// - `self.capacity() - self.len()` peab olema `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len suurendatakse alles pärast elementide initsialiseerimist
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - helistaja garanteerib, et src on kehtiv register
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Element initsialiseeriti just `MaybeUninit::write`-iga, seega on ok suurendada len
            // - Lekete vältimiseks suurendatakse len iga elemendi järel (vt väljaanne #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - helistaja garanteerib, et `src` on kehtiv register
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Mõlemad näpunäited on loodud ainulaadsetest viiluviidetest (`&mut [_]`), nii et need kehtivad ega kattu.
            //
            // - Elemendid on järgmised: kopeerimine, nii et kopeerimine on OK, ilma et algsete väärtustega midagi ette tuleks
            // - `count` on võrdne `source` väärtusega len, seega kehtib allikas `count` lugemiste korral
            // - `.reserve(count)` garanteerib, et `spare.len() >= count` nii varu kehtib `count` kirjutamise korral
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - `copy_nonoverlapping` algatas just elemendid
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Veci tavalised trait-rakendused
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): cfg(test)-ga pole selle meetodi määratlemiseks vajalik `[T]::to_vec`-i loomupärane meetod saadaval.
    // Selle asemel kasutage funktsiooni `slice::to_vec`, mis on saadaval ainult koos cfg(test) NB-ga, lisateabe saamiseks vaadake slice.rs-i moodulit slice.rs
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // visake kõik, mida üle ei kirjutata
        self.truncate(other.len());

        // self.len <= other.len ülaltoodud kärpimise tõttu, seega on siin olevad viilud alati piirides.
        //
        let (init, tail) = other.split_at(self.len());

        // taaskasutada sisalduvaid väärtusi allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Loob tarbiva iteraatori, st sellise, mis liigutab kõik väärtused vector-st välja (algusest lõpuni).
    /// vector ei saa pärast selle helistamist kasutada.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s on tüüp String, mitte &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // leaf-meetod, mille erinevad SpecFrom/SpecExtend-i rakendused delegeerivad, kui neil pole enam rakendatavaid optimeerimisi
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // See kehtib üldise iteraatori puhul.
        //
        // See funktsioon peaks olema moraalne samaväärne järgmisega:
        //
        //      iteraatoris oleva üksuse jaoks {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB ei saa üle voolata, kuna oleksime pidanud aadressiruumi eraldama
                self.set_len(len + 1);
            }
        }
    }

    /// Loob splaissimise iteraatori, mis asendab vector määratud vahemiku antud `replace_with` iteraatoriga ja annab eemaldatud üksused.
    ///
    /// `replace_with` ei pea olema sama pikk kui `range`.
    ///
    /// `range` eemaldatakse isegi siis, kui iteraatorit ei tarbita lõpuni.
    ///
    /// Kui `Splice`-i väärtus lekib, pole täpsustatud, kui palju elemente eemaldatakse vector-st.
    ///
    /// Sisend iteraator `replace_with` kulub ainult siis, kui väärtus `Splice` langeb.
    ///
    /// See on optimaalne, kui:
    ///
    /// * Saba (elemendid vector-is pärast `range`-i) on tühi,
    /// * või `replace_with` annab vähem või võrdseid elemente kui vahemiku pikkus
    /// * või selle `size_hint()` alumine piir on täpne.
    ///
    /// Vastasel juhul eraldatakse ajutine vector ja saba liigutatakse kaks korda.
    ///
    /// # Panics
    ///
    /// Panics, kui alguspunkt on suurem kui lõpp-punkt või kui lõpp-punkt on suurem kui vector pikkus.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Loob iteraatori, mis kasutab sulgurit, et teha kindlaks, kas element tuleks eemaldada.
    ///
    /// Kui sulgur vastab tõele, siis element eemaldatakse ja saadakse.
    /// Kui sulgemine tagastab vale, jääb element vector-i ja iteraator ei anna seda.
    ///
    /// Selle meetodi kasutamine on samaväärne järgmise koodiga:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // oma kood siin
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Kuid `drain_filter` on lihtsam kasutada.
    /// `drain_filter` on ka tõhusam, sest see võib massiivi elemente hulgina tagasi nihutada.
    ///
    /// Pange tähele, et `drain_filter` võimaldab teil muteerida ka kõiki filtri sulguri elemente, olenemata sellest, kas otsustate selle säilitada või eemaldada.
    ///
    ///
    /// # Examples
    ///
    /// Massiivi jagamine võrdseteks ja koefitsientideks, algse jaotuse taaskasutamine:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Kaitske meid lekkimise eest (lekke võimendamine)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Laiendage rakendust, mis kopeerib elemendid viidetest välja, enne kui lükkate need Vecile.
///
/// See rakendus on spetsialiseerunud viilu kordajatele, kus see kasutab kogu viilu korraga lisamiseks [`copy_from_slice`]-i.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Rakendab vektorite võrdlust, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Rakendab vektorite tellimist, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // kasuta [T] jaoks dropi, kasuta toorviilu, et viidata vector elementidele kui nõrgimale vajalikule tüübile;
            //
            // võiks teatud juhtudel vältida kehtivuse küsimusi
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec tegeleb diilimisega
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Loob tühja `Vec<T>`-i.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: test tõmbab libstd-sse, mis põhjustab siin vigu
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: test tõmbab libstd-sse, mis põhjustab siin vigu
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Hangi kogu `Vec<T>` sisu massiivina, kui selle suurus vastab täpselt nõutava massiivi suurusele.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Kui pikkus ei ühti, tuleb sisend `Err`-is tagasi:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Kui teil on lihtsalt `Vec<T>`-i eesliite hankimine, võite kõigepealt helistada [`.truncate(N)`](Vec::truncate)-ile.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // OHUTUS: `.set_len(0)` on alati heli.
        unsafe { vec.set_len(0) };

        // OHUTUS: Veci kursor on alati õigesti joondatud ja
        // massiivi jaoks vajalik joondus on sama mis üksustel.
        // Kontrollisime varem, et meil on piisavalt esemeid.
        // Üksused ei kuku topelt, kuna `set_len` käsib `Vec`-il neid mitte ka maha visata.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}