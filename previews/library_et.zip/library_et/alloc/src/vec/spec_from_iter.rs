use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Vec::from_iter jaoks kasutatakse spetsialiseerumist trait
///
/// ## Delegatsiooni graafik:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Tavaline juhtum on vector edastamine funktsiooniks, mis kohe koguneb uuesti vector-ks.
        // Saame selle lühise tekitada, kui IntoIterit pole üldse edasi arendatud.
        // Kui see on edasi arenenud, võime ka mälu taaskasutada ja andmeid esiküljele viia.
        // Kuid me teeme seda ainult siis, kui tekkinud Vecil poleks rohkem kasutamata võimsust kui selle loomisel FromIteratori üldise rakenduse kaudu.
        //
        // See piirang ei ole tingimata vajalik, kuna Veci käitumine on tahtlikult määratlemata.
        // Kuid see on konservatiivne valik.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // peab delegeerima spec_extend()-ile, kuna extend() ise delegeerib tühjade Vecs-ide jaoks spec_from
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// See kasutab `iterator.as_slice().to_vec()`-i, kuna spec_extend peab lõpliku võimsuse + pikkuse üle otsustamiseks tegema rohkem samme ja seega rohkem tööd tegema.
// `to_vec()` eraldab otse õige summa ja täidab selle täpselt.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): cfg(test)-ga pole selle meetodi määratlemiseks vajalik `[T]::to_vec`-i loomupärane meetod saadaval.
    // Selle asemel kasutage funktsiooni `slice::to_vec`, mis on saadaval ainult koos cfg(test) NB-ga, lisateabe saamiseks vaadake slice.rs-i moodulit slice.rs
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}