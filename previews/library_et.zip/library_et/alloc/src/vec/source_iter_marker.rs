use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Spetsialiseerumismarker iteraatori torujuhtme kogumiseks Vec-i, kasutades samal ajal allika jaotust, st
/// torujuhtme paigale viimine.
///
/// SourceIteri vanem trait on vajalik spetsialiseerumisfunktsiooni jaoks, et pääseda juurde taaskasutatavale jaotusele.
/// Kuid spetsialiseerumise kehtivusest ei piisa.
/// Vaadake implantaadi täiendavaid piire.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-sisemist SourceIter/InPlaceIterable traits rakendab ainult Adapteri kett <Adapter<Adapter<IntoIter>>> (kõik kuuluvad core/std-le).
// Adapteri juurutamise lisapiirid (väljaspool `impl<I: Trait> Trait for Adapter<I>`) sõltuvad ainult teistest traits-st, mis on juba märgitud spetsialiseerumisena traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. marker ei sõltu kasutaja poolt pakutavate tüüpide elueast.Modulo the Copy hole, millest sõltuvad juba mitmed teised erialad.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Lisanõuded, mida ei saa väljendada trait bound kaudu.Toetame selle asemel const evalit:
        // a) ei kasutata ZST-sid, kuna taaskasutamiseks ei eraldataks ja kursori aritmeetika oleks panic b) suurus sobiks vastavalt Alloci lepingule c) joondamine sobiks vastavalt Alloci lepingule
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // varundamine üldisemate rakenduste juurde
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // kasutage try-foldi alates
        // - see vektoriseerib paremini mõne iteraatori adapteri jaoks
        // - erinevalt enamikust sisemistest itereerimismeetoditest võtab see ainult iseenda &mut
        // - see võimaldab meil kirjutusosuti oma sisemusest läbi keerata ja selle lõpuks tagasi saada
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // kordamine õnnestus, ära pea maha löö
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // kontrollige, kas SourceIteri leping järgiti hoiatust: kui neid ei oleks, ei pruugi me isegi selleni jõuda
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // kontrollige InPlaceIterable'i lepingut.See on võimalik ainult siis, kui iteraator lähtekursorit üldse edasi arendab.
        // Kui ta kasutab TrustedRandomAccess'i kaudu kontrollimata juurdepääsu, jääb lähtekursor oma esialgsesse asendisse ja me ei saa seda viitena kasutada
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // visake kõik allesjäänud väärtused allika saba juurde, kuid hoiduge jaotuse enda langemisest, kui IntoIter väljub ulatusest, kui tilk panics lekib ka kõik elemendid, mis on kogutud dst_buf-i
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // InPlaceIterable'i lepingut ei saa siin täpselt kontrollida, kuna try_foldil on ainuüksi viide allikakursorile, mida me saame teha, on kontrollida, kas see on ikka vahemikus
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}