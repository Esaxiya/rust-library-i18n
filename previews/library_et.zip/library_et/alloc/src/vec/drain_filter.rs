use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Iteraator, mis kasutab sulgurit, et teha kindlaks, kas element tuleks eemaldada.
///
/// Selle struktuuri on loonud [`Vec::drain_filter`].
/// Lisateavet leiate selle dokumentatsioonist.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// Selle üksuse register, mida kontrollitakse järgmise kõne korral telefonil `next`.
    pub(super) idx: usize,
    /// Siiani tühjendatud üksuste arv (removed).
    pub(super) del: usize,
    /// `vec` algne pikkus enne tühjendamist.
    pub(super) old_len: usize,
    /// Filtri testi predikaat.
    pub(super) pred: F,
    /// Filtritesti predikaadis on ilmunud lipp, mis tähistab panic.
    /// Seda kasutatakse tilkade juurutamisel vihjena, et vältida ülejäänud `DrainFilter`-i tarbimist.
    /// Töötlemata üksused nihutatakse `vec`-is tagurpidi, kuid filtri predikaat ei lase enam üksusi maha ega testi.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Tagastab viite aluseks olevale eraldajale.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Uuendage indeksit * pärast predikaadi kutsumist.
                // Kui indeksit värskendatakse enne ja predikaat panics, lekib selle indeksi element.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // See on üsna segane olek ja tegelikult pole ilmselt õiget asja teha.
                        // Me ei soovi jätkata `pred`-i käivitamist, nii et me lihtsalt nihutame kõiki töötlemata elemente ja ütleme vec-ile, et need on endiselt olemas.
                        //
                        // Tagasiliikumine on vajalik, et vältida predikaadis panic-le eelneva viimase edukalt tühjendatud üksuse topeltkukkumist.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Püüdke tarbida ülejäänud elemente, kui filtri predikaat pole veel paanikasse sattunud.
        // Nihutame kõik ülejäänud elemendid tagasi, olenemata sellest, kas oleme juba paanikasse sattunud või kui siinne tarbimine on panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}