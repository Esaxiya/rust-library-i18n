//! Dünaamiliselt suur vaade külgnevaks jadaks, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Viilud on vaade mäluplokiks, mida tähistatakse kursori ja pikkusena.
//!
//! ```
//! // viilutades Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // massiivi sundimine viilule
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Viilud on kas muudetavad või jagatud.
//! Jagatud viilu tüüp on `&[T]`, muudetava viilu tüüp on `&mut [T]`, kus `T` tähistab elemendi tüüpi.
//! Näiteks saate muteerida ploki, millele muudetav viide osutab:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Siin on mõned asjad, mida see moodul sisaldab:
//!
//! ## Structs
//!
//! Viilude jaoks on mitu struktuuri, näiteks [`Iter`], mis tähistab iteratsiooni viilu kohal.
//!
//! ## Trait rakendused
//!
//! Viilude jaoks on tavaline traits mitu rakendust.Mõned näited hõlmavad järgmist:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], viilude jaoks, mille elemenditüüp on [`Eq`] või [`Ord`].
//! * [`Hash`] - viilude jaoks, mille elemendi tüüp on [`Hash`].
//!
//! ## Iteration
//!
//! Viilud rakendavad `IntoIterator`.Iteraator annab viited viilu elementidele.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Muutuv lõik annab muutuvad viited elementidele:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! See iteraator annab muutuvaid viiteid viilu elementidele, nii et kui viilu elemendi tüüp on `i32`, on iteraatori elemendi tüüp `&mut i32`.
//!
//!
//! * [`.iter`] ja [`.iter_mut`] on selged meetodid vaikimisi iteraatorite tagastamiseks.
//! * Teised iteraatorite tagastamise meetodid on [`.split`], [`.splitn`], [`.chunks`], [`.windows`] ja muud.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Paljusid selle mooduli kasutusi kasutatakse ainult testi konfiguratsioonis.
// Puhtam on lihtsalt kasutamata_import hoiatus välja lülitada kui nende parandamine.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Viilu pikendamise põhimeetodid
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) vajalik `vec!`-i makro rakendamiseks NB testimise ajal, vaadake selle faili üksikasju `hack`-i moodulist.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) mis on vajalik `Vec::clone`-i rakendamiseks NB-i testimise ajal, vaadake selle faili kohta lisateavet `hack`-moodulist.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Kui cfg(test) pole `impl [T]` saadaval, on need kolm funktsiooni tegelikult meetodid, mis on `impl [T]`-is, kuid mitte `core::slice::SliceExt`-is, peame need funktsioonid pakkuma `test_permutations`-testi jaoks
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Me ei tohiks sellele lisada atribuuti sisemine, kuna seda kasutatakse peamiselt `vec!` makros ja see põhjustab täiusliku regressiooni.
    // Arutelu ja tulemuste saamiseks vaadake #71204-i.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // üksused märgiti initsialiseeritud allpool asuvas silmus
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) on vajalik LLVM-i jaoks piirikontrollide eemaldamiseks ja sellel on parem koodegen kui zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec määrati ja initsialiseeriti eespool vähemalt selle pikkusega.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // eraldatud ülal mahuga `s` ja initsialiseerige `s.len()`-le allpool ptr::copy_to_non_overlapping-is.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Sorteerib viilu.
    ///
    /// See sort on stabiilne (st ei järjesta võrdseid elemente ümber) ja *O*(*n*\*log(* n*)) halvimal juhul.
    ///
    /// Vajaduse korral eelistatakse ebastabiilset sorteerimist, kuna see on tavaliselt kiirem kui stabiilne sortimine ja see ei eralda abimälu.
    /// Vaadake [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Praegune rakendamine
    ///
    /// Praegune algoritm on [timsort](https://en.wikipedia.org/wiki/Timsort)-st inspireeritud adaptiivne, iteratiivne ühendussort.
    /// See on kavandatud väga kiireks juhtudel, kui viil on peaaegu sorteeritud või koosneb kahest või enamast järjestatud liitunud järjestusest.
    ///
    ///
    /// Samuti eraldab see ajutise salvestusruumi poole suurusest `self`, kuid lühikeste viilude jaoks kasutatakse selle asemel eraldamata sisestussorte.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Sorteerib viilu võrdlusfunktsiooniga.
    ///
    /// See sort on stabiilne (st ei järjesta võrdseid elemente ümber) ja *O*(*n*\*log(* n*)) halvimal juhul.
    ///
    /// Võrdlusfunktsioon peab määrama kogu viilu elementide järjestuse.Kui tellimine pole täielik, pole elementide järjestus täpsustatud.
    /// Tellimus on kogu tellimus, kui see on (kõigi `a`, `b` ja `c` puhul):
    ///
    /// * kokku ja antisümmeetriline: täpselt üks `a < b`, `a == b` või `a > b` on tõene ja
    /// * transitiivne, `a < b` ja `b < c` tähendab `a < c`.Sama kehtib nii `==` kui ka `>` puhul.
    ///
    /// Näiteks kui [`f64`] ei rakenda [`Ord`]-i, kuna `NaN != NaN`, võime `partial_cmp`-i kasutada oma sortimisfunktsioonina, kui teame, et lõik ei sisalda `NaN`-i.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Vajaduse korral eelistatakse ebastabiilset sorteerimist, kuna see on tavaliselt kiirem kui stabiilne sortimine ja see ei eralda abimälu.
    /// Vaadake [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Praegune rakendamine
    ///
    /// Praegune algoritm on [timsort](https://en.wikipedia.org/wiki/Timsort)-st inspireeritud adaptiivne, iteratiivne ühendussort.
    /// See on kavandatud väga kiireks juhtudel, kui viil on peaaegu sorteeritud või koosneb kahest või enamast järjestatud liitunud järjestusest.
    ///
    /// Samuti eraldab see ajutise salvestusruumi poole suurusest `self`, kuid lühikeste viilude jaoks kasutatakse selle asemel eraldamata sisestussorte.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // vastupidine sortimine
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Sorteerib viilu võtmeekstraktsiooniga.
    ///
    /// See sort on stabiilne (st ei järjesta võrdseid elemente ümber) ja *O*(*m*\* * n *\* log(*n*)) halvimal juhul, kus võtme funktsioon on *O*(*m*).
    ///
    /// Kallite võtmefunktsioonide jaoks (nt
    /// funktsioonid, mis pole lihtsad atribuutide juurdepääsud ega põhitoimingud), on [`sort_by_cached_key`](slice::sort_by_cached_key) tõenäoliselt oluliselt kiirem, kuna see ei arvuta elementide võtmeid ümber.
    ///
    ///
    /// Vajaduse korral eelistatakse ebastabiilset sorteerimist, kuna see on tavaliselt kiirem kui stabiilne sortimine ja see ei eralda abimälu.
    /// Vaadake [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Praegune rakendamine
    ///
    /// Praegune algoritm on [timsort](https://en.wikipedia.org/wiki/Timsort)-st inspireeritud adaptiivne, iteratiivne ühendussort.
    /// See on kavandatud väga kiireks juhtudel, kui viil on peaaegu sorteeritud või koosneb kahest või enamast järjestatud liitunud järjestusest.
    ///
    /// Samuti eraldab see ajutise salvestusruumi poole suurusest `self`, kuid lühikeste viilude jaoks kasutatakse selle asemel eraldamata sisestussorte.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Sorteerib viilu võtmeekstraktsiooniga.
    ///
    /// Sorteerimise ajal kutsutakse võtme funktsiooni elemendi kohta ainult üks kord.
    ///
    /// See sort on stabiilne (st ei järjesta võrdseid elemente ümber) ja *O*(*m*\* * n *+* n *\* log(*n*)) halvimal juhul, kui võtmefunktsioon on *O*(*m*) .
    ///
    /// Lihtsate võtmefunktsioonide (nt funktsioonid, mis on juurdepääs atribuutidele või põhitoimingud) jaoks on [`sort_by_key`](slice::sort_by_key) tõenäoliselt kiirem.
    ///
    /// # Praegune rakendamine
    ///
    /// Praegune algoritm põhineb Orson Petersi [pattern-defeating quicksort][pdqsort]-il, mis ühendab randomiseeritud kiirkorduse keskmise keskmise juhtumi kiireima halvima hulga juhtumiga, saavutades samal ajal lineaarse aja teatud mustritega viiludel.
    /// Taandarengute vältimiseks kasutab see mõnda randomiseerimist, kuid fikseeritud seed abil tagab alati deterministliku käitumise.
    ///
    /// Halvimal juhul eraldab algoritm ajutise salvestusruumi viilu pikkusega `Vec<(K, usize)>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Abimakro meie vector indekseerimiseks võimalikult väikse tüübi järgi, et eraldamist vähendada.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // `indices` elemendid on ainulaadsed, kuna need on indekseeritud, nii et kõik sortid on algse viilu suhtes stabiilsed.
                // Me kasutame siin `sort_unstable`-i, kuna see nõuab vähem mälu eraldamist.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Kopeerib `self` uude `Vec`-i.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Siin saab `s` ja `x` iseseisvalt muuta.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Kopeerib `self` koos eraldajaga uude `Vec`-i.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Siin saab `s` ja `x` iseseisvalt muuta.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, lisateabe saamiseks vaadake selle faili moodulit `hack`.
        hack::to_vec(self, alloc)
    }

    /// Teisendab `self` kloonide ja eralduseta vector-ks.
    ///
    /// Saadud vector saab `Vec<T>`into_boxed_slice` meetod.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` ei saa enam kasutada, kuna see on teisendatud `x`-ks.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, lisateabe saamiseks vaadake selle faili moodulit `hack`.
        hack::into_vec(self)
    }

    /// Loob vector, korrates viilu `n` korda.
    ///
    /// # Panics
    ///
    /// See funktsioon on panic, kui võimsus ületaks.
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// panic ülevoolu korral:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Kui `n` on suurem kui null, saab selle jagada kui `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` on number, mida tähistab `n` kõige vasakpoolsem '1'-bitt, ja `rem` on `n`-i ülejäänud osa.
        //
        //

        // Kasutage `set_len()`-i juurdepääsemiseks `Vec`-i.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` kordamine toimub kahekordistades `buf` `expn 'korda.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Kui `m > 0`, siis on vasakpoolse '1'-ni ülejäänud bitid.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` mahutab `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) kordus tehakse, kopeerides esimesed `rem` kordused `buf`-st endast.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Alates `2^expn > rem`-st pole see kattuv.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` võrdub `buf.capacity()` ("= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Lamendab `T` viilu üheks väärtuseks `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Lamendab `T` viilu ühtseks väärtuseks `Self::Output`, asetades nende vahele antud eraldaja.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Lamendab `T` viilu ühtseks väärtuseks `Self::Output`, asetades nende vahele antud eraldaja.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Tagastab vector, mis sisaldab selle viilu koopiat, kus iga bait vastendatakse selle ASCII suurtähe ekvivalendile.
    ///
    ///
    /// ASCII tähed 'a' kuni 'z' vastendatakse tähtedega 'A' kuni 'Z', kuid mitte-ASCII tähed ei muutu.
    ///
    /// Väärtuse suureks muutmiseks kasutage [`make_ascii_uppercase`]-i.
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Tagastab vector, mis sisaldab selle viilu koopiat, kus iga bait vastendatakse ASCII väiketähe ekvivalendile.
    ///
    ///
    /// ASCII tähed 'A' kuni 'Z' vastendatakse tähtedega 'a' kuni 'z', kuid mitte-ASCII tähed ei muutu.
    ///
    /// Väärtuse väikeste tähtede sisestamiseks kasutage [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Laiendus traits spetsiifiliste andmete viilude jaoks
////////////////////////////////////////////////////////////////////////////////

/// Abimees trait for [`[T]: : concat`](viil::konkat).
///
/// Note: `Item`-tüüpi parameetrit selles trait-s ei kasutata, kuid see võimaldab implantaatidel olla üldisemad.
/// Ilma selleta saame selle vea:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Seda seetõttu, et võib olla `V` tüüpe mitme `Borrow<[_]>` implikatsiooniga, nii et kehtiks mitu `T` tüüpi:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Saadud tüüp pärast liitmist
    type Output;

    /// Rakenduse [`[T]: : concat`](viil::konkat) rakendamine
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Abimees trait [[T]: : liitumiseks]](viil::liitu)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Saadud tüüp pärast liitmist
    type Output;

    /// Rakenduse [`[T]: : liitu`](viil::liitu) rakendamine
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Viilude trait standardsed rakendused
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // viska märklauale kõik, mida üle ei kirjutata
        target.truncate(self.len());

        // target.len <= self.len ülaltoodud kärpimise tõttu, seega on siin olevad viilud alati piirides.
        //
        let (init, tail) = self.split_at(target.len());

        // taaskasutada sisalduvaid väärtusi allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Lisab `v[0]` eelnevalt sorteeritud järjestusse `v[1..]`, nii et kogu `v[..]` muutub sorteerituks.
///
/// See on sisestamise sorteerimise lahutamatu alamprogramm.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Siin on sisestamise rakendamiseks kolm võimalust:
            //
            // 1. Vahetage külgnevaid elemente, kuni esimene jõuab lõppsihtkohta.
            //    Kuid nii kopeerime andmeid rohkem kui vaja.
            //    Kui elemendid on suured struktuurid (kopeerimine on kulukas), on see meetod aeglane.
            //
            // 2. Korduvad, kuni esimese elemendi jaoks on leitud õige koht.
            // Seejärel nihutage sellele järgnevad elemendid, et sellele ruumi teha, ja lõpuks asetage see ülejäänud auku.
            // See on hea meetod.
            //
            // 3. Kopeerige esimene element ajutiseks muutujaks.Korduvad, kuni selle jaoks õige koht on leitud.
            // Minnes kopeerige kõik läbitud elemendid sellele eelnevasse pilusse.
            // Lõpuks kopeerige andmed ajutisest muutujast ülejäänud auku.
            // See meetod on väga hea.
            // Võrdlusnäitajad näitasid veidi paremat jõudlust kui 2. meetodi puhul.
            //
            // Kõiki meetodeid võrreldi ja 3. tulemus oli parim.Nii et valisime selle ühe.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Sisestusprotsessi vaheolekut jälgib alati `hole`, millel on kaks eesmärki:
            // 1. Kaitseb `v` terviklikkust panics eest `is_less`-is.
            // 2. Lõpuks täidab `v`-is järelejäänud auk.
            //
            // Panic ohutus:
            //
            // Kui `is_less` panics on protsessi mis tahes punktis, kukub `hole` alla ja täidab `v`-i augu `tmp`-iga, tagades sellega, et `v` hoiab kõiki objekte, mida ta alguses hoidis, täpselt ühe korra.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` langeb ja kopeerib `tmp` `v`-i ülejäänud auku.
        }
    }

    // Kui see kukutatakse, kopeeritakse `src`-ist `dest`-i.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Ühendab mitte-vähenevad jooksud `v[..mid]` ja `v[mid..]`, kasutades ajutise salvestusruumina `buf`, ja salvestab tulemuse `v[..]`-i.
///
/// # Safety
///
/// Need kaks viilu ei tohi olla tühjad ja `mid` peab olema piiratud.
/// Puhver `buf` peab olema piisavalt pikk, et mahutada lühema viilu koopiat.
/// Samuti ei tohi `T` olla nullsuurune tüüp.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Ühendamisprotsess kopeerib kõigepealt lühema käigu `buf`-i.
    // Seejärel jälgib see äsja kopeeritud ja pikemat jooksu edasi (või tagasi), võrreldes nende järgmisi tarbimata elemente ja kopeerides väiksema (või suurema) `v`-i.
    //
    // Niipea, kui lühem jooks on täielikult ära kasutatud, on protsess tehtud.Kui pikem sõit kulub kõigepealt ära, peame kopeerima kõik, mis lühemast sõidust järele jääb, `v`-i järelejäänud auku.
    //
    // Protsessi vaheolekut jälgib alati `hole`, millel on kaks eesmärki:
    // 1. Kaitseb `v` terviklikkust panics eest `is_less`-is.
    // 2. Kui pikem sõit kulub kõigepealt ära, täidab see `v`-is allesjäänud augu.
    //
    // Panic ohutus:
    //
    // Kui `is_less` panics on protsessi mis tahes punktis, langeb `hole` alla ja täidab `v`-i augu `buf`-i tarbimata vahemikuga, tagades sellega, et `v` hoiab kõiki objekte, mida ta algselt hoidis, täpselt ühe korra.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Vasak sõit on lühem.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Esialgu osutavad need osutajad nende massiividele.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Tarbige väiksemat külge.
            // Kui see on võrdne, eelistage stabiilsuse säilitamiseks vasakut jooksu.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Õige jooks on lühem.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Esialgu osutavad need osutid nende massiividest mööda.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Tarbige suuremat külge.
            // Kui see on võrdne, eelistage stabiilsuse säilitamiseks õiget jooksu.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Lõpuks langeb `hole` ära.
    // Kui lühemat jooksu ei kasutatud täielikult, kopeeritakse kõik selle järelejäänud elemendid nüüd `v`-i auku.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Kui see langeb, kopeerib vahemiku `start..end` `dest..`-i.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` ei ole nullsuurune tüüp, seega on okei jagada selle suurusega.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// See ühendussort laenab TimSortilt mõned (kuid mitte kõik) ideed, mida on üksikasjalikult kirjeldatud [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Algoritm tuvastab rangelt kahanevad ja mitte laskuvad alamjärjestused, mida nimetatakse loomulikeks jooksudeks.Ühendamata on veel virna ootel olevaid jookse.
/// Iga äsja leitud sõit lükatakse virna ja seejärel ühendatakse mõned külgnevate jooksude paarid, kuni need kaks invarianti on täidetud:
///
/// 1. iga `i`-i jaoks `1..runs.len()`-is: `runs[i - 1].len > runs[i].len`
/// 2. iga `i`-i jaoks `2..runs.len()`-is: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Invariantid tagavad, et kogu tööaeg on *O*(*n*\*log(* n*)) halvimal juhul.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Kuni selle pikkusega viilud sorteeritakse sisestussorteerimise abil.
    const MAX_INSERTION: usize = 20;
    // Väga lühikesi jookse pikendatakse sisestussorteerimise abil, et hõlmata vähemalt nii palju elemente.
    const MIN_RUN: usize = 10;

    // Sortimisel ei ole nullsuuruste tüüpide puhul sisukat käitumist.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Lühikesed massiivid sorteeritakse eraldamise vältimiseks paigutamise teel.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Määrake puhver, mida kasutada nullmäluna.Hoiame pikkust 0, et saaksime selles hoida `v` sisu madalaid koopiaid, riskimata koopiatel töötavate arstidega, kui `is_less` panics.
    //
    // Kahe sorteeritud käigu ühendamisel sisaldab see puhver lühema sõidu koopiat, mille pikkus on alati kuni `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // `v`-is looduslike jooksude tuvastamiseks liigume selle tagurpidi.
    // See võib tunduda kummaline otsus, kuid võtke arvesse asjaolu, et ühinemised lähevad sagedamini (forwards)-i vastupidises suunas.
    // Eesmärkide kohaselt on ettepoole ühendamine veidi kiirem kui tahapoole ühendamine.
    // Kokkuvõtteks võib öelda, et jooksude tuvastamine tagurpidi liikudes parandab jõudlust.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Leidke järgmine loomulik jooks ja pöörake see tagasi, kui see on rangelt kahanev.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Lisage jooksu veel mõned elemendid, kui see on liiga lühike.
        // Lisamise sortimine on kiirem kui lühikeste järjestuste ühendamise sortimine, nii et see parandab oluliselt jõudlust.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Lükake see jooks virna külge.
        runs.push(Run { start, len: end - start });
        end = start;

        // Ühendage invariantide rahuldamiseks mõned külgnevate jooksude paarid.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Lõpuks peab virna jääma täpselt üks sõit.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Uurib jooksu virna ja tuvastab järgmise ühendatava jooksupaari.
    // Täpsemalt, kui tagastatakse `Some(r)`, tähendab see, et järgmisena tuleb ühendada `runs[r]` ja `runs[r + 1]`.
    // Kui algoritm peaks jätkama selle asemel uue jooksu loomist, tagastatakse `None`.
    //
    // TimSort on kurikuulus oma lollakate rakenduste poolest, nagu siin kirjeldatud:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Loo põhisisu on: peame panustama virna nelja parema sõidu invariante.
    // Nende rakendamine ainult esikolmikul ei ole piisav tagamaks, et invariandid hoiaksid veel virna *kõiki* jookse.
    //
    // See funktsioon kontrollib invariante õigesti nelja parema sõidu korral.
    // Lisaks, kui ülemine käivitus algab indeksist 0, nõuab see alati sortimise lõpuleviimiseks liitmisoperatsiooni, kuni virn on täielikult kokku varisenud.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}