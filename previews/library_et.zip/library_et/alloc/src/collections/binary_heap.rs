//! Binaarse kuhjaga rakendatud prioriteetne järjekord.
//!
//! Suurima elemendi sisestamine ja avamine on *O*(log(*n*))-aegse keerukusega.
//! Suurima elemendi kontrollimine on *O*(1).vector teisendamise binaarhunnikuks saab teha kohapeal ja selle keerukus on *O*(*n*).
//! Binaarhunniku saab ka kohapeal teisendada sorteeritud vector-ks, võimaldades seda kasutada kohapeal asuvas *O*(*n*\*log(* n*))-sordisadamas).
//!
//! # Examples
//!
//! See on suurem näide, mis rakendab [Dijkstra's algorithm][dijkstra] lahendamiseks [shortest path problem][sssp] [directed graph][dir_graph]-il.
//!
//! See näitab, kuidas [`BinaryHeap`]-i kasutada kohandatud tüüpidega.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Prioriteedijärjekord sõltub `Ord`-st.
//! // Rakendage trait selgesõnaliselt, nii et järjekorrast saab maksimaalse kuhja asemel min-kuhja.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Pange tähele, et me pöörame kulude tellimise ümber.
//!         // Võrdse tulemuse korral võrdleme positsioone, see samm on vajalik `PartialEq` ja `Ord` rakenduste järjepidevaks muutmiseks.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` tuleb ka rakendada.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Iga sõlm on lühema teostuse jaoks tähistatud kui `usize`.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Dijkstra lühima tee algoritm.
//!
//! // Alustage `start`-ist ja kasutage `dist`-i, et jälgida iga sõlme praegust lühimat vahemaad.See juurutamine ei ole mälusäästlik, kuna see võib jätta duplikaatsõlmed järjekorda.
//! //
//! // Samuti kasutab see lihtsama rakendamise jaoks valveväärtusena `usize::MAX`-i.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [sõlm]=praegune lühim kaugus punktidest `start` kuni `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Oleme `start`-l, nullkuludega
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Kõigepealt uurige piiri madalama hinnaga sõlmedega (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Teise võimalusena oleksime võinud jätkata kõigi lühimate teede leidmist
//!         if position == goal { return Some(cost); }
//!
//!         // See on oluline, kuna võime juba leida parema viisi
//!         if cost > dist[position] { continue; }
//!
//!         // Iga sõlme jaoks, kuhu me jõuame, vaadake, kas leiame selle sõlme läbimise võimaluse madalama hinnaga
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Kui jah, lisage see piirile ja jätkake
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Lõdvestus, oleme nüüd leidnud parema viisi
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Eesmärk pole saavutatav
//!     None
//! }
//!
//! fn main() {
//!     // See on suunatud graaf, mida me kasutame.
//!     // Sõlmede numbrid vastavad erinevatele olekutele ja edge kaalud sümboliseerivad ühest sõlmest teise liikumise kulusid.
//!     //
//!     // Pange tähele, et servad on ühesuunalised.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // Graafik on kujutatud külgnevusloendina, kus igal sõlme väärtusele vastaval indeksil on väljaminevate servade loend.
//!     // Valitud selle tõhususe tõttu.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Sõlm 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // 1. sõlm
//!         vec![Edge { node: 3, cost: 2 }],
//!         // 2. sõlm
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // 3. sõlm
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // 4. sõlm
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Binaarse kuhjaga rakendatud prioriteetne järjekord.
///
/// Sellest saab maksimaalselt palju.
///
/// See on loogikaviga, et üksust muudetakse nii, et üksuse järjestus mis tahes muu üksuse suhtes, mille määrab `Ord` trait, muutub kuhja oleku ajal.
///
/// Tavaliselt on see võimalik ainult `Cell`, `RefCell`, globaalse oleku, I/O või ebaturvalise koodi kaudu.
/// Sellisest loogikaveast tulenevat käitumist pole täpsustatud, kuid see ei too kaasa määratlemata käitumist.
/// See võib hõlmata panics-d, valesid tulemusi, katkestusi, mälulekkeid ja lõpetamist.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Tüübijäreldus lubab meil välja jätta selgesõnalise tüübiallkirja (mis oleks selles näites `BinaryHeap<i32>`).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Peek abil saame vaadata kuhja järgmist eset.
/// // Sel juhul pole seal veel ühtegi eset, nii et me ei saa ühtegi.
/// assert_eq!(heap.peek(), None);
///
/// // Lisame mõned hinded ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Nüüd näitab piilumine kuhja kõige olulisemat eset.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Saame kontrollida kuhja pikkust.
/// assert_eq!(heap.len(), 3);
///
/// // Me võime kuhjaga esemeid korrata, kuigi need tagastatakse juhuslikus järjekorras.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Kui me neid hindeid hoopis poputame, peaksid need järjekorras tagasi tulema.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Saame hunniku järelejäänud esemetest puhastada.
/// heap.clear();
///
/// // Hunnik peaks nüüd tühi olema.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// `BinaryHeap`-st min-hunnikuks saab kasutada kas `std::cmp::Reverse`-i või kohandatud `Ord`-i rakendust.
/// See paneb `heap.pop()` tagastama suurima väärtuse asemel väikseima väärtuse.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Pakkige väärtused `Reverse`-i
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Kui me neid hindeid nüüd poputame, peaksid need tulema vastupidises järjekorras.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Aja keerukus
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// `push` väärtus on eeldatav maksumus;meetodi dokumentatsioon annab üksikasjalikuma analüüsi.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Struktuur, mis ümbritseb `BinaryHeap` suurimat üksust muutuva viitega.
///
///
/// See `struct` on loodud [`peek_mut`]-meetodil [`BinaryHeap`]-is.
/// Lisateavet leiate selle dokumentatsioonist.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // OHUTUS: PeekMut kuvatakse ainult tühjade hunnikute korral.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // OHUTU: PeekMut on instantsitud ainult tühjade hunnikute korral
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // OHUTU: PeekMut on instantsitud ainult tühjade hunnikute korral
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Eemaldab hunnikust piilutud väärtuse ja tagastab selle.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Loob tühja `BinaryHeap<T>`-i.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Loob max-kuhjana tühja `BinaryHeap`-i.
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Loob kindla võimsusega tühja `BinaryHeap`-i.
    /// See eraldab `capacity` elementide jaoks piisavalt mälu, nii et `BinaryHeap`-i ei pea ümber jaotama enne, kui see sisaldab vähemalt nii palju väärtusi.
    ///
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Tagastab muutuva viite binaarhunniku suurimale üksusele või `None`, kui see on tühi.
    ///
    /// Note: Kui väärtus `PeekMut` lekib, võib hunnik olla vastuolus.
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Aja keerukus
    ///
    /// Kui üksust muudetakse, on halvimal juhul aja keerukus *O*(log(*n*)), vastasel juhul on see *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Eemaldab binaarkuhjast suurima üksuse ja tagastab selle või `None`, kui see on tühi.
    ///
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Aja keerukus
    ///
    /// `pop` halvim juhtum * * elemente sisaldava kuhja jaoks on *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // OHUTUS: !self.is_empty() tähendab, et self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Lükkab eseme binaarhunnikule.
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Aja keerukus
    ///
    /// `push` eeldatav maksumus, mis on keskmiselt arvutatud kõigi surutavate elementide järjestuse ja piisavalt suure hulga tõugete korral, on *O*(1).
    ///
    /// See on kõige tähendusrikkam mõõdik, kui lükatakse elemente, mis pole *juba* mis tahes sorteeritud mustris.
    ///
    /// Aja keerukus halveneb, kui elemendid surutakse valdavalt kasvavas järjekorras.
    /// Halvimal juhul lükatakse elemendid järjest kasvavas järjestuses ja amortiseeritud kulu ühe tõuke kohta on *O*(log(*n*)) kuhjaga, mis sisaldab *n* elementi.
    ///
    /// `push`-i *ühe* kõne halvim juhtum on *O*(*n*).Halvimal juhul juhtub olukord, kui maht on ammendatud ja vajab suuruse muutmist.
    /// Suuruse muutmise maksumus on varasematel joonistel amortiseeritud.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // OHUTUS: Kuna me lükkasime uue eseme, tähendab see seda
        //  vana_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Tarbib `BinaryHeap`-i ja tagastab vector järjestatud (ascending)-järjekorras.
    ///
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // OHUTUS: `end` läheb `self.len() - 1`-st 1-ni (mõlemad komplektis),
            //  nii et juurdepääsuks on see alati kehtiv register.
            //  Indeksile 0 (st `ptr`) on turvaline pääseda, kuna
            //  1 <=lõpp <self.len(), mis tähendab self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // OHUTUS: `end` läheb `self.len() - 1`-st 1-ni (mõlemad kaasa arvatud), nii et:
            //  0 <1 <=lõpp <= self.len(), 1 <self.len() Mis tähendab 0 <lõpp ja lõpp <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Rakenduste sift_up ja sift_down teostused kasutavad ebaturvalisi plokke, et element vector-st välja viia (jättes augu taha), nihkuda mööda teisi ja viia eemaldatud element tagasi augu lõpp-punkti vector-sse.
    //
    // Selle tähistamiseks kasutatakse tüüpi `Hole` ja veenduge, et auk oleks selle ulatuse lõpus tagasi täidetud, isegi panic-l.
    // Ava kasutamine vähendab konstantset tegurit võrreldes vahetustehingutega, mis hõlmab kaks korda rohkem käike.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Helistaja peab tagama, et `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Võtke väärtus `pos` juures välja ja tekitage auk.
        // OHUTUS: helistaja tagab, et pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // OHUTUS: hole.pos()> start>=0, mis tähendab hole.pos()> 0
            //  ja nii ei saa hole.pos(), 1 läbi voolata.
            //  See tagab, et vanem <hole.pos(), seega on see kehtiv indeks ja ka!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // OHUTUS: Sama mis ülal
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Võtke element `pos` juures ja liigutage seda kuhja alla, samal ajal kui selle lapsed on suuremad.
    ///
    ///
    /// # Safety
    ///
    /// Helistaja peab tagama, et `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // OHUTUS: helistaja tagab, et pos <lõpp <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loopvariant: laps==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // võrrelda suurema lapsega kahest lapsest. OHUTUS: laps <lõpp, 1 <self.len() ja laps + 1 <lõpp <= self.len(), seega on need kehtivad indeksid.
            //
            //  laps==2 *hole.pos() + 1!= hole.pos() ja laps + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 või 2* hole.pos() + 2 võivad üle voolata, kui T on ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // kui oleme juba korras, siis peatu.
            // OHUTUS: laps on nüüd kas vana laps või vana laps + 1
            //  Tõestasime juba, et mõlemad on <self.len() ja!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // OHUTUS: sama mis ülal.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // OHUTUS: &&lühis, mis tähendab, et
        //  teine tingimus on juba õige, et laps==lõpp, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // OHUTUS: laps on juba tõestatud kehtiva indeksina ja
            //  laps==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Helistaja peab tagama, et `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // OHUTUS: pos <len tagab helistaja ja
        //  ilmselt len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Võtke element `pos` juures ja liigutage see kuhjaga alla, seejärel sõeluge see üles oma asendisse.
    ///
    ///
    /// Note: See on kiirem, kui element on teadaolevalt suur/peaks olema põhjale lähemal.
    ///
    /// # Safety
    ///
    /// Helistaja peab tagama, et `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // OHUTUS: helistaja tagab, et pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loopvariant: laps==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // OHUTUS: laps <lõpp, 1 <self.len() ja
            //  laps + 1 <lõpp <= self.len(), seega on need kehtivad indeksid.
            //  laps==2 *hole.pos() + 1!= hole.pos() ja laps + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 või 2* hole.pos() + 2 võivad üle voolata, kui T on ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // OHUTUS: Sama mis ülal
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // OHUTUS: laps==lõpp, 1 <self.len(), seega on see kehtiv register
            //  ja laps==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // OHUTUS: pos on asend aukus ja see oli juba tõestatud
        //  olla kehtiv register.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // OHUTUS: n algab self.len()/2-st ja langeb 0-ni.
            //  Ainus juhtum, kui! (N <self.len()) on juhul, kui self.len() ==0, kuid selle välistab tsükli tingimus.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Teisaldab kõik `other` elemendid `self`-i, jättes `other`-i tühjaks.
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` võtab O(len1 + len2) toiminguid ja halvimal juhul umbes 2 *(len1 + len2) võrdlust, `extend` võtab O(len2* log(len1)) operatsioone ja halvimal juhul umbes 1 *len2* log_2(len1), eeldades, et len1>= len2.
        // Suuremate kuhjade puhul ei järgi ristumispunkt enam seda arutlust ja see määrati empiiriliselt.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Tagastab iteraatori, mis toob elemendid hunnikusse.
    /// Laetud elemendid eemaldatakse algsest hunnikust.
    /// Ülejäänud elemendid eemaldatakse hunnikusse langemisel.
    ///
    /// Note:
    /// * `.drain_sorted()` on *O*(*n*\*log(* n*)); palju aeglasem kui `.drain()`.
    ///   Enamikul juhtudel peaksite kasutama viimast.
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // eemaldab kõik elemendid hunnikus
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Säilitab ainult predikaadiga määratud elemendid.
    ///
    /// Teisisõnu eemaldage kõik elemendid `e` nii, et `f(&e)` tagastaks `false`.
    /// Elemente külastatakse sortimata (ja täpsustamata) järjekorras.
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // hoia ainult paarisarvusid
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Tagastab iteraatori, mis külastab suvalises järjekorras kõiki aluseks oleva vector väärtusi.
    ///
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Trükkige 1, 2, 3, 4 suvalises järjekorras
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Tagastab iteraatori, mis toob elemendid hunnikusse.
    /// See meetod kulutab algset kuhja.
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Tagastab binaarkuhja suurima üksuse või tühja `None`-i.
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Aja keerukus
    ///
    /// Maksumus on halvimal juhul *O*(1).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Tagastab elementide arvu, mida binaarhunnik mahutab ilma ümberjaotamiseta.
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Reserveerib minimaalse võimsuse täpselt `additional` elemendi sisestamiseks antud `BinaryHeap`-i.
    /// Ei tee midagi, kui mahutavus on juba piisav.
    ///
    /// Pange tähele, et eraldaja võib anda kollektsioonile rohkem ruumi, kui see nõuab.
    /// Seetõttu ei saa loota, et võimsus on täpselt minimaalne.
    /// Eelistage [`reserve`]-i, kui eeldatakse future sisestamist.
    ///
    /// # Panics
    ///
    /// Panics, kui uus maht ületab `usize`.
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Reserveerib võimsuse vähemalt `additional`-i elementide lisamiseks `BinaryHeap`-i.
    /// Kollektsioon võib reserveerida rohkem ruumi, et vältida sagedasi ümberjaotusi.
    ///
    /// # Panics
    ///
    /// Panics, kui uus maht ületab `usize`.
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Kõrvaldab nii palju lisavõimalusi kui võimalik.
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Viskab alumise piiriga võimsuse ära.
    ///
    /// Mahutavus jääb vähemalt nii suureks kui pikkus ja tarnitud väärtus.
    ///
    ///
    /// Kui praegune võimsus on väiksem kui alumine piir, on see keelatud.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Tarbib `BinaryHeap` ja tagastab selle aluseks oleva vector suvalises järjekorras.
    ///
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Trükib mõnes järjekorras
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Tagastab binaarhunniku pikkuse.
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Kontrollib, kas binaarhunnik on tühi.
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Kustutab binaarhunniku, tagastades eemaldatud elementide kohal iteraatori.
    ///
    /// Elemendid eemaldatakse suvalises järjekorras.
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Viskab kõik elemendid binaarkuhjast alla.
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Auk kujutab endast viilu ava, st kehtiva väärtuseta indeksit (kuna see teisaldati või kopeeriti).
///
/// Languses taastab `Hole` viilu, täites augu positsiooni algselt eemaldatud väärtusega.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Looge uus `Hole` indeksis `pos`.
    ///
    /// Ohtlik, kuna pos peab olema andmesektsioonis.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // OHUTU: pos peaks olema viilu sees
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Tagastab viite eemaldatud elemendile.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Tagastab elemendile `index` viite.
    ///
    /// Ohtlik, kuna indeks peab olema andmesektsioonis ja mitte võrdne pos.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Teisalda auk uude asukohta
    ///
    /// Ohtlik, kuna indeks peab olema andmesektsioonis ja mitte võrdne pos.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // täitke auk uuesti
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Kordus `BinaryHeap` elementide kohal.
///
/// Selle `struct` on loonud [`BinaryHeap::iter()`].
/// Lisateavet leiate selle dokumentatsioonist.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Eemaldage `#[derive(Clone)]` kasuks
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// `BinaryHeap` elementide iteraatori omamine.
///
/// Selle `struct` on loonud [`BinaryHeap::into_iter()`] (pakub `IntoIterator` trait).
/// Lisateavet leiate selle dokumentatsioonist.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Tühjendav iteraator `BinaryHeap` elementide kohal.
///
/// Selle `struct` on loonud [`BinaryHeap::drain()`].
/// Lisateavet leiate selle dokumentatsioonist.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Tühjendav iteraator `BinaryHeap` elementide kohal.
///
/// Selle `struct` on loonud [`BinaryHeap::drain_sorted()`].
/// Lisateavet leiate selle dokumentatsioonist.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Eemaldab kuhjaelemendid kuhjakorras.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Teisendab `Vec<T>` `BinaryHeap<T>`-ks.
    ///
    /// See teisendamine toimub kohapeal ja sellel on aja keerukus *O*(*n*).
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Teisendab `BinaryHeap<T>` `Vec<T>`-ks.
    ///
    /// See teisendamine ei vaja andmete liikumist ega eraldamist ning sellel on pidev keerukus.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Loob tarbiva iteraatori, st sellise, mis liigutab iga väärtuse suvalises järjekorras binaarhunnikust välja.
    /// Binaarhunnikut ei saa pärast selle kutsumist kasutada.
    ///
    /// # Examples
    ///
    /// Põhikasutus:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Trükkige 1, 2, 3, 4 suvalises järjekorras
    /// for x in heap.into_iter() {
    ///     // x-l on tüüp i32, mitte &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}