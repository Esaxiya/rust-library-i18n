use core::intrinsics;
use core::mem;
use core::ptr;

/// See asendab `v`-i unikaalse viite taga oleva väärtuse, kutsudes vastava funktsiooni.
///
///
/// Kui `change` sulgemisel tekib panic, katkestatakse kogu protsess.
#[allow(dead_code)] // säilitage illustratsioonina ja future kasutamiseks
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// See asendab `v`-i unikaalse viite taga oleva väärtuse, kutsudes vastava funktsiooni, ja tagastab teel saadud tulemuse.
///
///
/// Kui `change` sulgemisel tekib panic, katkestatakse kogu protsess.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}