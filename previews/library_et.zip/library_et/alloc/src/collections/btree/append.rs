use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Lisab kõik võtmeväärtuste paarid kahe tõusva iteraatori ühendusest, suurendades teel muutujat `length`.Viimane hõlbustab helistajal lekete vältimist, kui tilgakäitleja hakkab paanikasse sattuma.
    ///
    /// Kui mõlemad iteraatorid toodavad sama võtit, kukutab see meetod paari vasakult iteraatorilt ja lisab paari paremalt iteraatorilt.
    ///
    /// Kui soovite, et puu jõuaks rangelt kasvavas järjekorras, nagu `BTreeMap` puhul, peaksid mõlemad iteraatorid tootma võtmed rangelt kasvavas järjekorras, millest igaüks on suurem kui kõik puu võtmed, sealhulgas kõik võtmed, mis on puul juba sisenemise ajal.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Valmistume ühendama `left` ja `right` lineaarse aja järgi järjestatud järjestusse.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Vahepeal ehitame puu sorteeritud järjestusest sirgjooneliselt.
        self.bulk_push(iter, length)
    }

    /// Lükkab kõik võtmeväärtuste paarid puu otsa, suurendades `length` muutujat mööda teed.
    /// Viimane muudab iteraatori paanikas helistajal lekke vältimise lihtsamaks.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Korduvad kõik võtmeväärtuste paarid, lükates need õigel tasemel sõlmedesse.
        for (key, value) in iter {
            // Proovige sisestada võtme-väärtuste paar praegusesse lehesõlme.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Ruumi pole enam, minge üles ja suruge sinna.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Leiti sõlm, kus on ruumi, vajutage siia.
                                open_node = parent;
                                break;
                            } else {
                                // Minge uuesti üles.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Oleme tipus, loome uue juursõlme ja surume sinna.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Lükake võtmeväärtuste paar ja uus parem alampuu.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Minge uuesti alla kõige paremale lehele.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Suurendage iga iteratsiooni pikkust, veendumaks, et kaart viskab lisatud elemendid maha isegi siis, kui iteraatori edasiliikumine paanikasse jõuab.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Iteraator kahe sorteeritud järjestuse üheks ühendamiseks
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Kui kaks võtit on võrdsed, tagastab võtme-väärtuste paari õigest allikast.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}