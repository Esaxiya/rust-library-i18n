use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// Konkreetsete sündmuste jälgimiseks mõeldud kokkupõrketesti mannekeenide kavand.
/// Mõni eksemplar võib olla ühel hetkel konfigureeritud panic-le.
/// Sündmused on `clone`, `drop` või mõni anonüümne `query`.
///
/// Kokkupõrketesti mannekeenid identifitseeritakse ja järjestatakse ID järgi, nii et neid saab BTreeMapis võtmetena kasutada.
/// Tahtlikult kasutatav rakendus ei tugine millelegi crate-s määratletule, välja arvatud `Debug` trait.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Loob kokkupõrketesti näivdisaini.`id` määrab eksemplaride järjekorra ja võrdsuse.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Loob kokkupõrketesti mannekeeni eksemplari, mis salvestab kogetud sündmused ja valikuliselt panics.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Tagastab, mitu korda mannekeeni eksemplare on kloonitud.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Tagastab, mitu korda mannekeeni eksemplare on visatud.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// Tagastab, mitu korda on mannekeeni eksemplare nende `query`-liiget kutsutud.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Mingi anonüümne päring, mille tulemus on juba antud.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}