use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modelleerib mõne ainulaadse viite tagasilaenu, kui teate, et tagasivõtmist ja kõiki selle järglasi (st kõiki sellest saadud viiteid ja viiteid) ei kasutata mingil hetkel enam, pärast mida soovite algset kordumatut viidet uuesti kasutada .
///
///
/// Laenukontrollija tegeleb tavaliselt selle laenude virnastamisega teie eest, kuid mõned selle virnastamise juhtimisvood on kompilaatori jälgimiseks liiga keerulised.
/// `DormantMutRef` võimaldab teil kontrollida laenamist ise, väljendades samal ajal selle virnastatud olemust, ja kapseldada selleks vajalik toores osutikood ilma määratlemata käitumiseta.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Jäädvustage ainulaadne laen ja laenake see kohe tagasi.
    /// Koostaja jaoks on uue viite eluiga sama, mis algse viite eluiga, kuid lubate seda kasutada lühemaks ajaks.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // OHUTUS: hoiame laenu `_marker` kaudu kogu a jooksul ja paljastame
        // ainult see viide, nii et see on ainulaadne.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Pöörduge tagasi algselt püütud unikaalse laenu poole.
    ///
    /// # Safety
    ///
    /// Laen peab olema lõppenud, st `new`-i tagastatud viite ning kõiki sellest saadud viiteid ja viiteid ei tohi enam kasutada.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // OHUTUS: meie endi ohutustingimused tähendavad, et see viide on jällegi ainulaadne.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;