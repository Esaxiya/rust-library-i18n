// See on ideaali järgimise katse
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Kuna Rust-l pole tegelikult sõltuvaid tüüpe ja polümorfset rekursiooni, siis lepime paljude ohutustega.
//

// Selle mooduli peamine eesmärk on vältida keerukust, käsitledes puud üldise (kui veidra kujuga) konteinerina ja vältides enamiku B-puu invariantidega tegelemist.
//
// Sellisena ei hooli sellest moodulist, kas kirjed on sorteeritud, millised sõlmed võivad olla alatäielikud või isegi see, mida alatäied tähendavad.Siiski toetume mõnele invariandile:
//
// - Puudel peab olema ühtlane depth/height.See tähendab, et igal teel antud lehe suunas leheni on täpselt sama pikkus.
// - `n` pikkusel sõlmel on võtmed `n`, väärtused `n` ja servad `n + 1`.
//   See tähendab, et isegi tühjal sõlmel on vähemalt üks edge.
//   Lehesõlme puhul tähendab "having an edge" ainult seda, et suudame tuvastada sõlmes asuva positsiooni, kuna lehe servad on tühjad ega vaja andmete esitamist.
// Sisemises sõlmes identifitseerib edge nii positsiooni kui ka osutab alamsõlmele.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Lehtede sõlmede aluseks olev osa ja osa sisemiste sõlmede esitusest.
struct LeafNode<K, V> {
    /// Me tahame olla muutlikud `K` ja `V` puhul.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Selle sõlme indeks vanemasõlme massiivi `edges`.
    /// `*node.parent.edges[node.parent_idx]` peaks olema sama asi nagu `node`.
    /// Selle lähtestamine on tagatud ainult siis, kui `parent` pole null.
    parent_idx: MaybeUninit<u16>,

    /// Selle sõlme salvestatud võtmete ja väärtuste arv.
    len: u16,

    /// Massiivid, mis salvestavad sõlme tegelikke andmeid.
    /// Ainult iga massiivi esimesed `len` elemendid on initsialiseeritud ja kehtivad.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Initsialiseerib uue `LeafNode`-i.
    unsafe fn init(this: *mut Self) {
        // Üldise poliitikana jätame väljad initsialiseerimata, kui need on võimalikud, kuna see peaks olema Valgrindis nii veidi kiirem kui ka hõlpsam jälgitav.
        //
        unsafe {
            // parent_idx, võtmed ja vals on kõik võib-olla Unininit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Loob uue karbiga `LeafNode`.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Sisemiste sõlmede aluseks olev esitus.Nagu ka LeafNode'ide puhul, tuleks need peita kausta "BoxedNode" taha, et vältida initsialiseerimata võtmete ja väärtuste langemist.
/// Iga `InternalNode`-i osuti saab otse valada sõlme aluseks oleva `LeafNode`-i osuti juurde, võimaldades koodil lehe-ja sisesõlmedele üldist mõju avaldada, ilma et peaks isegi kontrollima, kumba neist osutab pointer.
///
/// Selle atribuudi lubab `repr(C)`-i kasutamine.
///
#[repr(C)]
// gdb_providers.py kasutab seda tüüpi nime sisevaatluseks.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Viited selle sõlme lastele.
    /// `len + 1` neist loetakse initsialiseeritud ja kehtivateks, välja arvatud see, et kui puu lõpus on laenutüüp `Dying`, siis mõned neist näpunäidetest rippuvad.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Loob uue karbiga `InternalNode`.
    ///
    /// # Safety
    /// Sisemiste sõlmede muutumatu variant on see, et neil on vähemalt üks initsialiseeritud ja kehtiv edge.
    /// See funktsioon ei seadista sellist edge-d.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Me peame ainult lähtestama andmed;servad on Võib-olla Uninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Hallatud, nullist erinev sõlme osuti.See on kas `LeafNode<K, V>`-i omandis olev tähis või `InternalNode<K, V>`-i omandis olev kursor.
///
/// Kuid `BoxedNode` ei sisalda teavet selle kohta, millist kahest tüüpi sõlmedest see tegelikult sisaldab, ja osaliselt selle teabe puudumise tõttu ei ole see eraldi tüüp ega hävitajat.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Kuuluva puu juursõlm.
///
/// Pange tähele, et sellel pole destruktorit ja see tuleb käsitsi puhastada.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Tagastab uue omandis oleva puu, millel on algselt tühi juuresõlm.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` ei tohi olla null.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Laenab vastutavalt omandis oleva juursõlme.
    /// Erinevalt `reborrow_mut`-ist on see ohutu, kuna tagastusväärtust ei saa juure hävitamiseks kasutada ja puule ei saa olla muid viiteid.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Laenab veidi vahetatavalt omandis oleva juursõlme.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Pöördumatult läheb üle viide, mis võimaldab läbimist ja pakub hävitavaid meetodeid ja vähe muud.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Lisab uue sisemise sõlme, millel on üks edge, mis osutab eelmisele juursõlmele, teeb selle uue sõlme juursõlmeks ja tagastab selle.
    /// See suurendab kõrgust 1 võrra ja on `pop_internal_level`-i vastand.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, välja arvatud see, et me lihtsalt unustasime, et oleme praegu sisemised:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Eemaldab sisemise juursõlme, kasutades uue juursõlmena selle esimest last.
    /// Kuna see on mõeldud helistamiseks ainult siis, kui juursõlmel on ainult üks laps, ei tehta ühtegi võtit, väärtust ega muud last puhastust.
    ///
    /// See vähendab kõrgust 1 võrra ja on `push_internal_level`-i vastand.
    ///
    /// Nõuab ainuõiget juurdepääsu objektile `Root`, kuid mitte juursõlmele;
    /// see ei muuda teisi käepidemeid ega viiteid juursõlmele.
    ///
    /// Panics, kui sisemist taset pole, st kui juursõlm on leht.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // OHUTUS: väitsime, et oleme sisemised.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // OHUTUS: me laenasime ainult `self` ja selle laenutüüp on eksklusiivne.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // OHUTUS: esimene edge lähtestatakse alati.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` on `K` ja `V` puhul alati muutuv, isegi kui `BorrowType` on `Mut`.
// See on tehniliselt vale, kuid ei saa `NodeRef`-i sisekasutuse tõttu põhjustada mingit ohutust, kuna oleme `K`-i ja `V`-i puhul täiesti üldised.
//
// Kui aga avalik tüüp mähib `NodeRef`-i, veenduge, et sellel oleks õige dispersioon.
//
/// Viide sõlmele.
///
/// Sellel tüübil on mitu parameetrit, mis kontrollivad selle toimimist.
/// - `BorrowType`: Nukutüüp, mis kirjeldab laenu ja kannab kogu elu.
///    - Kui see on `Immut<'a>`, toimib `NodeRef` umbes nagu `&'a Node`.
///    - Kui see on `ValMut<'a>`, toimib `NodeRef` võtmete ja puu struktuuri osas umbes nagu `&'a Node`, kuid võimaldab ka kõrvuti eksisteerida paljudel muudetavatel viidetel kogu puu väärtustele.
///    - Kui see on `Mut<'a>`, toimib `NodeRef` umbes nagu `&'a mut Node`, kuigi sisestusmeetodid võimaldavad muutuva kursori väärtusele koos eksisteerida.
///    - Kui see on `Owned`, toimib `NodeRef` umbes nagu `Box<Node>`, kuid sellel puudub hävitaja ja see tuleb käsitsi puhastada.
///    - Kui see on `Dying`, toimib `NodeRef` endiselt umbes nagu `Box<Node>`, kuid tal on meetodeid puu vähehaaval hävitamiseks ja tavalised meetodid, ehkki helistamiseks pole märgitud ohtlikuks, võivad valesti helistades kutsuda UB-d.
///
///   Kuna mis tahes `NodeRef` võimaldab navigeerida läbi puu, kehtib `BorrowType` tõhusalt kogu puu, mitte ainult sõlme enda kohta.
/// - `K` ja `V`: need on sõlmedesse salvestatud võtmete tüübid ja väärtused.
/// - `Type`: See võib olla `Leaf`, `Internal` või `LeafOrInternal`.
/// Kui see on `Leaf`, osutab `NodeRef` lehesõlmele, kui see on `Internal`, osutab `NodeRef` sisemisele sõlmele ja kui see on `LeafOrInternal`, võib `NodeRef` osutada mõlemale tüübile.
///   `Type` kannab nime `NodeType`, kui seda kasutatakse väljaspool `NodeRef`.
///
/// Nii `BorrowType` kui ka `NodeType` piiravad staatilise ohutuse ärakasutamiseks kasutatavaid meetodeid.Selliste piirangute rakendamisel on piiranguid:
/// - Iga tüübi parameetri jaoks saame meetodi määratleda ainult kas üldiselt või ühe konkreetse tüübi jaoks.
/// Näiteks ei saa me määratleda sellist meetodit nagu `into_kv` kogu `BorrowType` jaoks või üks kord kõigi tüüpide jaoks, millel on eluiga, sest me tahame, et see tagastaks `&'a` viited.
///   Seetõttu määratleme selle ainult kõige väiksema võimsusega tüübi `Immut<'a>` jaoks.
/// - Me ei saa kaudset sundi, näiteks `Mut<'a>`-st `Immut<'a>`-ni.
///   Seetõttu peame `reborrow`-ile sarnase meetodi saavutamiseks helistama `reborrow`-ile võimsamale `NodeRef`-ile.
///
/// Kõik `NodeRef`-i meetodid, mis tagastavad mingisuguse viite, on kas:
/// - Võtke `self` väärtuse järgi ja tagastage `BorrowType` eluiga.
///   Mõnikord peame sellise meetodi rakendamiseks helistama `reborrow_mut`-ile.
/// - Võtke `self` võrdlusena ja (implicitly) tagastab selle viite eluea, mitte `BorrowType` kandva eluea.
/// Nii tagab laenukontroll, et `NodeRef` jääb laenuks seni, kuni kasutatakse tagastatud viidet.
///   Sisestust toetavad meetodid painutavad seda reeglit, tagastades toore kursori, st viite, mille eluiga puudub.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Noodide arv, mida sõlme ja lehtede tase on üksteisest lahus, sõlme konstant, mida `Type` ei saa täielikult kirjeldada ja mida sõlm ise ei salvesta.
    /// Peame salvestama ainult juursõlme kõrguse ja tuletama sellest iga teise sõlme kõrguse.
    /// Peab olema null, kui `Type` on `Leaf`, ja nullist erinev, kui `Type` on `Internal`.
    ///
    ///
    height: usize,
    /// Lehe või sisemise sõlme osuti.
    /// `InternalNode` määratlus tagab, et osuti kehtib mõlemal juhul.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Pakkige välja sõlme viide, mis oli pakitud kui `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Paljastab sisemise sõlme andmed.
    ///
    /// Tagastab toore ptr, et vältida selle sõlme muude viidete kehtetuks muutmist.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // OHUTUS: staatilise sõlme tüüp on `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Laenab ainuõiguse sisemise sõlme andmetele.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Leiab sõlme pikkuse.See on võtmete või väärtuste arv.
    /// Servade arv on `len() + 1`.
    /// Pange tähele, et hoolimata sellest, et see funktsioon on turvaline, võib selle kõrvaltoimena kehtetuks muuta ohtliku koodi loodud muutuvad viited.
    ///
    pub fn len(&self) -> usize {
        // Oluline on, et pääseme siia `len` väljale juurde.
        // Kui BorrowType on marker::ValMut, võib väärtuste kohta olla väljapaistvaid muutuvaid viiteid, mida me ei tohi kehtetuks tunnistada.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Tagastab nende tasemete arvu, mille sõlme ja lehed lahutavad.
    /// Nullkõrgus tähendab, et sõlm on leht ise.
    /// Kui kujutate puid juurega üleval, ütleb number, millisel kõrgusel sõlm ilmub.
    /// Kui kujutate puid, mille lehed on peal, ütleb number, kui kõrgeks puu sõlme kohal ulatub.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Ajutiselt võtab samale sõlmele välja teise muutumatu viite.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Paljastab mis tahes lehe või sisemise sõlme leheosa.
    ///
    /// Tagastab toore ptr, et vältida selle sõlme muude viidete kehtetuks muutmist.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Sõlm peab kehtima vähemalt osa LeafNode jaoks.
        // See ei ole NodeRef-tüüpi viide, kuna me ei tea, kas see peaks olema kordumatu või jagatud.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Leiab praeguse sõlme vanema.
    /// Tagastab `Ok(handle)`, kui praegusel sõlmel on tegelikult vanem, kus `handle` osutab vanema edge-le, mis osutab praegusele sõlmele.
    ///
    /// Tagastab `Err(self)`, kui praegusel sõlmel pole vanemat, tagastades algse `NodeRef`.
    ///
    /// Meetodi nimi eeldab, et pildistate puid, mille juursõlm on peal.
    ///
    /// `edge.descend().ascend().unwrap()` ja `node.ascend().unwrap().descend()` ei tohiks edu korral mõlemad midagi teha.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Peame sõlmede jaoks kasutama tooreid näpunäiteid, sest kui BorrowType on marker::ValMut, võib väärtuste osas olla silmapaistvaid muutuvaid viiteid, mida me ei tohi kehtetuks tunnistada.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Pange tähele, et `self` peab olema tühi.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Pange tähele, et `self` peab olema tühi.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Paljastab muutumatu puu mis tahes lehe või sisemise sõlme leheosa.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // OHUTUS: `Immut`-iga laenatud puule ei saa olla muudetavaid viiteid.
        unsafe { &*ptr }
    }

    /// Laenab vaate sõlme salvestatud võtmetesse.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Sarnaselt `ascend`-ga saab viite sõlme vanemasõlmele, kuid jaotab protsessis ka praeguse sõlme.
    /// See on ohtlik, sest praegusele sõlmele on endiselt juurdepääs, hoolimata selle jaotamisest.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Kinnitab kompilaatorile ebaturvaliselt staatilist teavet, et see sõlm on `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Kinnitab kompilaatorile ebaturvaliselt staatilist teavet, et see sõlm on `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Võtab ajutiselt välja teise, muutuva viite samale sõlmele.Ettevaatust, kuna see meetod on väga ohtlik, kahekordselt, kuna see ei pruugi kohe ohtlikuna tunduda.
    ///
    /// Kuna muutlikud osutid võivad ringi liikuda kõikjal puu ümber, saab tagastatud kursorit virna laenureeglite alusel hõlpsasti muuta algse osuti riputatuks, piiridest väljapoole või kehtetuks.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) kaaluge `NodeRef`-ile veel ühe tüübiparameetri lisamist, mis piirab navigatsioonimeetodite kasutamist laenatud osutitel, hoides ära selle ebaturvalisuse.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Laenab eksklusiivse juurdepääsu mis tahes lehe või sisemise sõlme leheosale.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // OHUTUS: meil on eksklusiivne juurdepääs kogu sõlmele.
        unsafe { &mut *ptr }
    }

    /// Pakub eksklusiivset juurdepääsu mis tahes lehe või sisemise sõlme leheosale.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // OHUTUS: meil on eksklusiivne juurdepääs kogu sõlmele.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Laenab eksklusiivse juurdepääsu võtmesalvestusala elemendile.
    ///
    /// # Safety
    /// `index` on piirides 0..VÕIMSUS
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // OHUTUS: helistaja ei saa ise täiendavaid meetodeid helistada
        // seni, kuni võtme osa viide langeb, kuna meil on ainulaadne juurdepääs kogu laenu kehtivuse ajaks.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Laenab eksklusiivse juurdepääsu sõlme väärtuse salvestusala elemendile või viilule.
    ///
    /// # Safety
    /// `index` on piirides 0..VÕIMSUS
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // OHUTUS: helistaja ei saa ise täiendavaid meetodeid helistada
        // seni, kuni väärtusviilu viide langeb, kuna meil on ainulaadne juurdepääs kogu laenu eluaja jooksul.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Laenab edge sisu jaoks eksklusiivse juurdepääsu sõlme salvestusala elemendile või viilule.
    ///
    /// # Safety
    /// `index` on piirides 0..VÕIMSUS + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // OHUTUS: helistaja ei saa ise täiendavaid meetodeid helistada
        // kuni viilu edge viide tühistatakse, kuna meil on ainulaadne juurdepääs kogu laenu eluaja jooksul.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Sõlmel on rohkem kui `idx` initsialiseeritud elemente.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Loome viite ainult ühele huvipakkuvale elemendile, et vältida aliasimist silmapaistvate viidetega muudele elementidele, eriti neile, mis helistajale varasemates kordustes tagasi saadeti.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Rust väljaande #74679 tõttu peame sundima mõõtmeteta massiivinäitureid.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Laenab eksklusiivse juurdepääsu sõlme pikkusele.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Määrab sõlme lingi oma vanemale edge, muutmata solmile muid viiteid.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Kustutab juurte lingi oma vanemale edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Lisab sõlme lõppu võtme-väärtuste paari.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Iga üksus, mille `range` tagastas, on sõlme jaoks kehtiv edge indeks.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Lisab võtme-väärtuste paari ja edge, et minna sellest paarist paremale, sõlme otsa.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Kontrollib, kas sõlm on `Internal` või `Leaf` sõlm.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Viide konkreetsele võtme-väärtuste paarile või sõlmes olevale edge-le.
/// Parameeter `Node` peab olema `NodeRef`, samas kui `Type` võib olla kas `KV` (tähistab võtme-väärtuste paari käepidet) või `Edge` (tähistab edge käepidet).
///
/// Pange tähele, et isegi `Leaf`-sõlmedel võivad olla `Edge`-käepidemed.
/// Selle asemel, et osutada lapsele sõlme, tähistavad need tühikuid, kuhu lapsekursorid läheksid võtme-väärtuse paaride vahel.
/// Näiteks sõlmes, mille pikkus on 2, oleks 3 võimalikku edge asukohta, üks sõlmest vasakul, üks kahe paari vahel ja teine sõlme paremal.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Me ei vaja `#[derive(Clone)]` täielikku üldisust, kuna ainus kord, kui `Node` on kloonitav, on see, kui see on muutumatu viide ja seega `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Toob kätte sõlme, mis sisaldab edge või võtme-väärtuste paari, millele see käepide osutab.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Tagastab selle käepideme asukoha sõlmes.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Loob `node`-s võtme-väärtuste paarile uue käepideme.
    /// Ohtlik, kuna helistaja peab tagama, et `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// See võib olla PartialEqi avalik rakendus, kuid seda kasutatakse ainult selles moodulis.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Ajutiselt võtab samas asukohas välja teise muutumatu käepideme.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Me ei saa kasutada Handle::new_kv ega Handle::new_edge, sest me ei tea oma tüüpi
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Kinnitab kompilaatorile ebaturvaliselt staatilist teavet, et käepideme sõlm on `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Ajutiselt võtab samas asukohas välja teise muutuva käepideme.
    /// Ettevaatust, kuna see meetod on väga ohtlik, kahekordselt, kuna see ei pruugi kohe ohtlikuna tunduda.
    ///
    ///
    /// Üksikasju vt `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Me ei saa kasutada Handle::new_kv ega Handle::new_edge, sest me ei tea oma tüüpi
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Loob `node`-is uue käepideme edge-le.
    /// Ohtlik, kuna helistaja peab tagama, et `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Arvestades edge indeksit, kuhu soovime sisestada täisvõimsuseni täidetud sõlme, arvutab mõistlik jagunemispunkti KV indeks ja kuhu sisestamine läbi viia.
///
/// Jagumispunkti eesmärk on, et selle võti ja väärtus jõuaksid vanemsõlmesse;
/// jagamispunkti vasakul asuvatest klahvidest, väärtustest ja servadest saab vasak laps;
/// jagamispunkti paremal asuvatest klahvidest, väärtustest ja servadest saab õige laps.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust väljaanne #74834 proovib neid sümmeetrilisi reegleid selgitada.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Lisab uue võtme-väärtuste paari võtme-väärtuse paaride vahele sellest edge paremale ja vasakule.
    /// See meetod eeldab, et sõlmes on piisavalt ruumi uue paari mahutamiseks.
    ///
    /// Tagastatud kursor osutab sisestatud väärtusele.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Lisab uue võtme-väärtuste paari võtme-väärtuse paaride vahele sellest edge paremale ja vasakule.
    /// See meetod jagab sõlme, kui ruumi pole piisavalt.
    ///
    /// Tagastatud kursor osutab sisestatud väärtusele.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Parandab lapsesõlmes vanema kursori ja indeksi, millega see edge lingib.
    /// See on kasulik, kui servade järjestust on muudetud,
    fn correct_parent_link(self) {
        // Looge vastukäija, muutmata sõlme muid viiteid kehtetuks.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Lisab uue võtmeväärtuste paari ja edge, mis lähevad sellest uuest paarist paremale selle edge ja võtme-väärtuste paari vahele sellest edge paremale.
    /// See meetod eeldab, et sõlmes on piisavalt ruumi uue paari mahutamiseks.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Lisab uue võtmeväärtuste paari ja edge, mis lähevad sellest uuest paarist paremale selle edge ja võtme-väärtuste paari vahele sellest edge paremale.
    /// See meetod jagab sõlme, kui ruumi pole piisavalt.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Lisab uue võtme-väärtuste paari võtme-väärtuse paaride vahele sellest edge paremale ja vasakule.
    /// See meetod jagab sõlme, kui ruumi pole piisavalt, ja proovib jaotatud osa jaotada vanemsõlmesse rekursiivselt, kuni juur on saavutatud.
    ///
    ///
    /// Kui tagastatud tulemus on `Fit`, võib selle käepideme sõlm olla selle edge sõlm või esivanem.
    /// Kui tagastatud tulemus on `Split`, on juursõlmeks väli `left`.
    /// Tagastatud kursor osutab sisestatud väärtusele.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Leiab sõlme, millele see edge osutab.
    ///
    /// Meetodi nimi eeldab, et pildistate puid, mille juursõlm on peal.
    ///
    /// `edge.descend().ascend().unwrap()` ja `node.ascend().unwrap().descend()` ei tohiks edu korral mõlemad midagi teha.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Peame sõlmede jaoks kasutama tooreid näpunäiteid, sest kui BorrowType on marker::ValMut, võib väärtuste osas olla silmapaistvaid muutuvaid viiteid, mida me ei tohi kehtetuks tunnistada.
        // Kõrguse väljale pääsemisel pole muret, sest see väärtus on kopeeritud.
        // Pange tähele, et kui sõlme osuti on viidatud, pääseme servade massiivi juurde viitega (Rust probleem #73987) ja muudame massiivile või selle sees olevad viited kehtetuks, kui neid peaks olema.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Me ei saa kutsuda eraldi võtme-ja väärtusmeetodeid, kuna teise kutsumine muudab esimese tagastatud viite kehtetuks.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Asendage võti ja väärtus, millele KV käepide viitab.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Aitab `split` juurutamist konkreetse `NodeType` jaoks, hoolitsedes lehtede andmete eest.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Jagab aluseks oleva sõlme kolmeks osaks:
    ///
    /// - Sõlm on kärbitud ja sisaldab ainult võtme-väärtuse paare sellest käepidemest vasakul.
    /// - Eemaldatakse selle käepideme osundatud võti ja väärtus.
    /// - Kõik sellest käepidemest paremal asuvad võtme-väärtuste paarid pannakse äsja eraldatud sõlme.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Eemaldab selle käepideme abil osutatava võtmeväärtuste paari ja tagastab selle koos edge-ga, millesse võti-väärtuspaar kokku kukkus.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Jagab aluseks oleva sõlme kolmeks osaks:
    ///
    /// - Sõlm on kärbitud ja sisaldab ainult selle käepideme vasakul servi ja võtmeväärtuste paare.
    /// - Eemaldatakse selle käepideme osundatud võti ja väärtus.
    /// - Kõik sellest käepidemest paremal asuvad servad ja võtmeväärtuste paarid pannakse äsja eraldatud sõlme.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Esindab seanssi sisemise võtmeväärtuste paari ümber toimuva tasakaalustamisoperatsiooni hindamiseks ja teostamiseks.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Valib tasakaalustava konteksti, mis hõlmab sõlme lapsena, seega vanemasõlmes oleva KV vahel kohe vasakule või paremale.
    /// Tagastab `Err`, kui vanemat pole.
    /// Panics, kui vanem on tühi.
    ///
    /// Eelistab vasakut külge, et olla optimaalne, kui antud sõlm on kuidagi alatäidetud, see tähendab siin ainult seda, et sellel on vähem elemente kui vasakul vennal ja paremal õel, kui neid on.
    /// Sellisel juhul on vasaku õe-vennaga ühinemine kiirem, kuna meil on vaja liigutada ainult sõlme N elementi, selle asemel, et nihutada neid paremale ja liigutada rohkem kui N elementi ees.
    /// Vasakult õe-venna juurest varastamine on tavaliselt ka kiirem, kuna peame nihutama ainult sõlme N elementi paremale, selle asemel et nihutada vähemalt N õe või venna elemendist vasakule.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Tagastab, kas ühendamine on võimalik, st kas sõlmes on piisavalt ruumi keskse KV ühendamiseks mõlema külgneva alussõlmega.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Teostab ühendamise ja laseb sulgemisel otsustada, mida tagastada.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // OHUTUS: ühendatavate sõlmede kõrgus on üks kõrgusest allpool
                // selle edge sõlme, seega üle nulli, nii et nad on sisemised.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Ühendab vanema võtmeväärtuste paari ja mõlemad kõrvuti asetsevad alamsõlmed vasakpoolsesse alamsõlmesse ja tagastavad kahanenud vanemasõlme.
    ///
    ///
    /// Panics, kui me `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Ühendab vanema võtmeväärtuste paari ja mõlemad kõrvuti asetsevad alamsõlmed vasakusse lapse sõlme ja tagastavad selle alamsõlme.
    ///
    ///
    /// Panics, kui me `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Ühendab vanema võtmeväärtuste paari ja mõlemad kõrvuti asetsevad alamsõlmed vasakpoolsesse lapse sõlme ja tagastab käepideme edge selles lapsesõlmes, kuhu jälgitav laps edge sattus,
    ///
    ///
    /// Panics, kui me `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Eemaldab vasakult lapselt võtmeväärtuste paari ja paigutab selle vanema võtmeväärtuste hoiule, surudes samal ajal vana vanema võtmeväärtuste paari õigesse lapsesse.
    ///
    /// Tagastab parema lapse edge käepideme vastavalt sellele, kuhu `track_right_edge_idx` määratud algne edge jõudis.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Eemaldab parempoolsest lapsest võtme-väärtuste paari ja paigutab selle vanema võtmeväärtuste hoiule, surudes samal ajal vana vanema võtme-väärtuste paari vasakule lapsele.
    ///
    /// Tagastab `track_left_edge_idx` määratud vasakpoolse lapse edge käepideme, mis ei liikunud.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// See varastamine sarnaneb `steal_left`-iga, kuid varastab korraga mitu elementi.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Veenduge, et võime varastada ohutult.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Lehe andmete teisaldamine.
            {
                // Tehke õige lapse jaoks ruumi varastatud elementidele.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Liigutage elemendid vasakult lapselt paremale.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Viige kõige vasakpoolseim varastatud paar vanema juurde.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Teisaldage vanema võti-väärtus paar õigele lapsele.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Tehke ruumi varastatud servadele.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Varasta servi.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// `bulk_steal_left` sümmeetriline kloon.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Veenduge, et võime varastada ohutult.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Lehe andmete teisaldamine.
            {
                // Teisaldage kõige paremini varastatud paar vanema juurde.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Teisaldage vanema võtmeväärtuste paar vasakule lapsele.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Liigutage elemendid paremalt lapselt vasakule.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Täitke tühimik, kus vanasti olid varastatud elemendid.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Varasta servi.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Täitke tühimik seal, kus varem olid varastatud servad.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Eemaldab igasuguse staatilise teabe, väites, et see sõlm on `Leaf` sõlm.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Eemaldab igasuguse staatilise teabe, väites, et see sõlm on `Internal` sõlm.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Kontrollib, kas aluseks olev sõlm on `Internal` või `Leaf` sõlm.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Liigutage järelliide `self` järel ühest sõlmest teise.`right` peab olema tühi.
    /// `right`-i esimene edge jääb muutumatuks.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Sisestamise tulemus, kui sõlm pidi laienema oma võimekusest kaugemale.
pub struct SplitResult<'a, K, V, NodeType> {
    // Olemasoleva puu muudetud sõlm koos elementide ja servadega, mis kuuluvad `kv`-st vasakule.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Mõni võti ja väärtus jagunevad, lisatakse mujale.
    pub kv: (K, V),
    // Omanik, kinnitamata uus elementide ja servadega sõlm, mis kuuluvad `kv`-i paremale.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Kas seda laenutüüpi sõlme viited võimaldavad liikuda puu teistesse sõlmedesse.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Läbimist pole vaja, see juhtub `borrow_mut`-i tulemuse abil.
        // Keelates läbimise ja luues ainult uusi viiteid juurtele, teame, et kõik `Owned` tüüpi viited on juursõlmele.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Lisab väärtuse initsialiseeritud elementide viilu, millele järgneb üks initsialiseerimata element.
///
/// # Safety
/// Viilul on rohkem kui `idx` elemente.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Eemaldab ja tagastab kõigi initsialiseeritud elementide viilu väärtuse, jättes maha ühe initsialiseerimata elemendi.
///
///
/// # Safety
/// Viilul on rohkem kui `idx` elemente.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Nihutab `distance`-viiluasendis olevaid elemente vasakule.
///
/// # Safety
/// Viilul on vähemalt `distance` elemente.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Nihutab viilu `distance` positsioonis olevaid elemente paremale.
///
/// # Safety
/// Viilul on vähemalt `distance` elemente.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Teisaldab kõik väärtused initsialiseeritud elementide viimist initsialiseerimata elementide viiluni, jättes `src`-i kui kõik initsialiseerimata.
///
/// Töötab nagu `dst.copy_from_slice(src)`, kuid ei nõua, et `T` oleks `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;