#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Uue mälu sisu on initsialiseerimata.
    Uninitialized,
    /// Uue mälu nullimine on garanteeritud.
    Zeroed,
}

/// Madal taseme utiliit kuhjaga mälupuhvri ergonoomilisemaks jaotamiseks, ümberjaotamiseks ja jaotamiseks, ilma et peaksite muretsema kõigi kaasnevate juhtumite pärast.
///
/// See tüüp sobib suurepäraselt oma andmekonstruktsioonide loomiseks nagu Vec ja VecDeque.
/// Eriti:
///
/// * Toodab `Unique::dangling()` nullmõõdus tüüpidel.
/// * Toodab `Unique::dangling()` nullpikkusel jaotusel.
/// * Väldib `Unique::dangling()` vabastamist.
/// * Püüab kõik võimsuse arvutuste ülevoolud (tõstab need "capacity overflow" panics-i).
/// * Kaitse 32-bitiste süsteemide eest, mis eraldavad rohkem kui isize::MAX baiti.
/// * Kaitseb teie pikkuse ületäitumise eest.
/// * Nõuab `handle_alloc_error`-il ekslikke jaotusi.
/// * Sisaldab `ptr::Unique`-i ja annab seega kasutajale kõik sellega seotud eelised.
/// * Kasutab eraldajalt tagastatud ülejääki suurima võimaliku võimsuse kasutamiseks.
///
/// See tüüp ei kontrolli niikuinii tema hallatavat mälu.Kui see langeb, vabastab see * mälu, kuid ei püüa selle sisu ära visata.
/// `RawVec`-i sisemuses *salvestatud* tegelike asjadega tegelemine on `RawVec`-i kasutaja ülesanne.
///
/// Pange tähele, et nullsuuruste tüüpide liig on alati lõpmatu, nii et `capacity()` tagastab alati `usize::MAX`.
/// See tähendab, et peate selle tüübi `Box<[T]>`-ga ümardamisel olema ettevaatlik, kuna `capacity()` ei anna pikkust.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): See on olemas, kuna `#[unstable]` `const fn`-d ei pea vastama `min_const_fn`-le ja seega ei saa neid ka 'min_const_fn`-des kutsuda.
    ///
    /// Kui muudate `RawVec<T>::new`-i või sõltuvusi, palun ärge tutvustage midagi, mis `min_const_fn`-i tõeliselt rikuks.
    ///
    /// NOTE: Võiksime vältida seda häkkimist ja kontrollida vastavust mõnele `#[rustc_force_min_const_fn]` atribuudile, mis nõuab vastavust `min_const_fn`-le, kuid ei luba tingimata seda kutsuda `stable(...) const fn`-is/kasutajakood, mis ei luba `foo`-i, kui `#[rustc_const_unstable(feature = "foo", issue = "01234")]` on olemas.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Loob ilma eraldamiseta suurima võimaliku `RawVec`-i (süsteemihunnikus).
    /// Kui `T` on positiivse suurusega, siis teeb see `RawVec` võimsusega `0`.
    /// Kui `T` on nullsuur, siis teeb see `RawVec` võimsusega `usize::MAX`.
    /// Kasulik viivitatud jaotuse rakendamiseks.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Loob `[T; capacity]`-i (süsteemihunnikus), millel on täpselt `[T; capacity]`-i mahtuvus ja joondusnõuded.
    /// See on samaväärne `RawVec::new`-i helistamisega, kui `capacity` on `0` või `T` on nullsuur.
    /// Pange tähele, et kui `T` on nullsuur, tähendab see, et *ei* saada soovitud võimsusega `RawVec`-i.
    ///
    /// # Panics
    ///
    /// Panics, kui taotletud maht ületab `isize::MAX` baiti.
    ///
    /// # Aborts
    ///
    /// Katkestused OOM-is.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Nagu `with_capacity`, kuid tagab puhvri nullimise.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Lahendab `RawVec` kursori ja mahutavuse järgi.
    ///
    /// # Safety
    ///
    /// `ptr` tuleb eraldada (süsteemihunnikus) ja antud `capacity`-iga.
    /// `capacity` ei tohi suurusega tüüpide puhul ületada `isize::MAX`.(muret teeb vaid 32-bitiste süsteemide puhul).
    /// ZST vectors võimsus võib olla kuni `usize::MAX`.
    /// Kui `ptr` ja `capacity` pärinevad `RawVec`-ist, on see tagatud.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Pisikesed vecsid on tummad.Jäta vahele:
    // - 8, kui elemendi suurus on 1, sest kõik hunniku eraldajad ümardavad tõenäoliselt alla 8-baidise taotluse vähemalt 8-baidiseks.
    //
    // - 4, kui elemendid on mõõduka suurusega (<=1 KiB).
    // - 1 muul juhul, et vältida liiga lühikese Vecsi jaoks liiga palju ruumi raiskamist.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Nagu `new`, kuid parameetritakse üle tagastatava `RawVec` eraldaja valiku.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` tähendab "unallocated".nullsuuruseid tüüpe ignoreeritakse.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Nagu `with_capacity`, kuid parameetritakse üle tagastatava `RawVec` eraldaja valiku.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Nagu `with_capacity_zeroed`, kuid parameetritakse üle tagastatava `RawVec` eraldaja valiku.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Teisendab `Box<[T]>` `RawVec<T>`-ks.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Teisendab kogu puhvri `Box<[MaybeUninit<T>]>`-ks koos määratud `len`-iga.
    ///
    /// Pange tähele, et see taastab kõik tehtud `cap`-i muudatused õigesti.(Lisateavet leiate tüübi kirjeldusest.)
    ///
    /// # Safety
    ///
    /// * `len` - peab olema suurem või võrdne viimati taotletud võimsusega ja
    /// * `len` peab olema väiksem kui `self.capacity()` või sellega võrdne.
    ///
    /// Pange tähele, et taotletud maht ja `self.capacity()` võivad erineda, kuna eraldaja võib üldise asukoha ja tagastada suurema mäluploki kui taotletud.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Mõistlikkus-kontrollige üht ohutusnõuete poolest (me ei saa teist poolt kontrollida).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Väldime siin `unwrap_or_else`-i, kuna see paisutab tekitatud LLVM IR-i hulga.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Lahendab `RawVec` kursori, mahutavuse ja eraldaja järgi.
    ///
    /// # Safety
    ///
    /// `ptr` tuleb eraldada (antud eraldaja kaudu `alloc`) ja antud `capacity`-ga.
    /// `capacity` ei tohi suuremat tüüpi tüüpide puhul ületada väärtust `isize::MAX`.
    /// (muret teeb vaid 32-bitiste süsteemide puhul).
    /// ZST vectors võimsus võib olla kuni `usize::MAX`.
    /// Kui `ptr` ja `capacity` pärinevad `alloc` kaudu loodud `RawVec`-ist, on see tagatud.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Saab eraldise algusele toore näpunäite.
    /// Pange tähele, et see on `Unique::dangling()`, kui `capacity == 0` või `T` on nullsuurused.
    /// Esimesel juhul peate olema ettevaatlik.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Saab eraldise võimsuse.
    ///
    /// See on alati `usize::MAX`, kui `T` on nullsuur.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Tagastab jagatud viite eraldajale, kes toetab seda `RawVec`-i.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Meil on eraldatud mälumaht, nii et saame praeguse paigutuse saamiseks käitusaja kontrollidest mööda minna.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Tagab, et puhver sisaldab vähemalt piisavalt ruumi `len + additional`-elementide hoidmiseks.
    /// Kui sellel pole veel piisavalt ruumi, jaotab see amortiseerunud käitumise saamiseks piisavalt ruumi ja mugavat vaba ruumi.
    ///
    /// Piirab seda käitumist, kui see põhjustaks asjatult panic-i.
    ///
    /// Kui `len` ületab `self.capacity()`, ei pruugi see taotletud ruumi tegelikult eraldada.
    /// See pole tegelikult ohtlik, kuid selle funktsiooni käitumisele tuginev ohtlik kood *, mille te kirjutate, võib puruneda.
    ///
    /// See sobib ideaalselt hulgitõuke operatsiooni nagu `extend` rakendamiseks.
    ///
    /// # Panics
    ///
    /// Panics, kui uus maht ületab `isize::MAX` baiti.
    ///
    /// # Aborts
    ///
    /// Katkestused OOM-is.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // reserv oleks katkestanud või paanikasse sattunud, kui len ületaks `isize::MAX`, nii et seda on nüüd ohutu teha kontrollimata.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Sama mis `reserve`, kuid naaseb paanika või katkestamise asemel vigade korral.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Tagab, et puhver sisaldab vähemalt piisavalt ruumi `len + additional`-elementide hoidmiseks.
    /// Kui see pole veel nii, siis jaotab minimaalselt vajaliku mälumahu ümber.
    /// Üldiselt on see vajalik mälumaht täpselt, kuid põhimõtteliselt on eraldajal vabadus anda rohkem tagasi, kui me küsisime.
    ///
    ///
    /// Kui `len` ületab `self.capacity()`, ei pruugi see taotletud ruumi tegelikult eraldada.
    /// See pole tegelikult ohtlik, kuid selle funktsiooni käitumisele tuginev ohtlik kood *, mille te kirjutate, võib puruneda.
    ///
    /// # Panics
    ///
    /// Panics, kui uus maht ületab `isize::MAX` baiti.
    ///
    /// # Aborts
    ///
    /// Katkestused OOM-is.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Sama mis `reserve_exact`, kuid naaseb paanika või katkestamise asemel vigade korral.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Kahandab eraldise kindlaksmääratud summani.
    /// Kui antud summa on 0, siis tegelikult jagub täielikult.
    ///
    /// # Panics
    ///
    /// Panics, kui antud summa on praegusest võimsusest *suurem*.
    ///
    /// # Aborts
    ///
    /// Katkestused OOM-is.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Tagastab, kui vajaliku lisamahu täitmiseks peab puhver kasvama.
    /// Kasutatakse peamiselt reservkõnede lisamise võimaldamiseks ilma `grow`-i sisestamata.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Seda meetodit instantsitakse tavaliselt mitu korda.Nii et me tahame, et see oleks võimalikult väike, parandaks kompileerimise aegu.
    // Kuid soovime ka, et võimalikult suur osa selle sisust oleks staatiliselt arvutatav, et genereeritud kood töötaks kiiremini.
    // Seetõttu on see meetod hoolikalt kirjutatud nii, et kogu koodist, mis sõltub `T`-st, oleks selles, samas kui võimalikult palju koodist, mis ei sõltu `T`-st, on funktsioonides, mis pole `T`-i puhul üldised.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Selle tagavad kutsuvad kontekstid.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Kuna tagastame võimsuse `usize::MAX`, kui `elem_size` on
            // 0, tähendab siia jõudmine tingimata, et `RawVec` on ületäitunud.
            return Err(CapacityOverflow);
        }

        // Kahjuks ei saa me nende kontrollide vastu midagi teha.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // See tagab eksponentsiaalse kasvu.
        // Kahekordistamine ei saa üle voolata, kuna `cap <= isize::MAX` ja `cap` tüüp on `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` ei ole `T`-i puhul üldine.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Selle meetodi piirangud on palju samad, mis `grow_amortized`-il, kuid seda meetodit rakendatakse tavaliselt harvemini, nii et see on vähem kriitiline.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Kuna tagastame võimsuse `usize::MAX`, kui tüübi suurus on
            // 0, tähendab siia jõudmine tingimata, et `RawVec` on ületäitunud.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` ei ole `T`-i puhul üldine.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// See funktsioon on kompileerimisaja minimeerimiseks väljaspool `RawVec`-i.Vaadake üksikasju `RawVec::grow_amortized` kohal olevast kommentaarist.
// (Parameeter `A` ei ole oluline, sest praktikas nähtud erinevate `A` tüüpide arv on palju väiksem kui `T` tüüpide arv.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // `RawVec::grow_*`-i suuruse minimeerimiseks kontrollige siin viga.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Eraldaja kontrollib joonduse võrdsust
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Vabastab mälu, mille omanik on `RawVec`*, ilma et* prooviks selle sisu ära visata.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Keskne funktsioon reservivigade käsitlemiseks.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Peame tagama järgmise:
// * Me ei eralda kunagi `> isize::MAX` baidisuuruseid objekte.
// * Me ei ületa `usize::MAX`-i üle ja eraldame tegelikult liiga vähe.
//
// 64-bitise puhul peame lihtsalt kontrollima ülevoolu, kuna `> isize::MAX`-baitide eraldamine üritab kindlasti ebaõnnestuda.
// 32-bitises ja 16-bitises versioonis peame selle jaoks lisama täiendava kaitse juhul, kui töötame platvormil, mis saab kasutada kõiki 4 GB kasutajaruumis, nt PAE või x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Üks keskne funktsioon, mis vastutab võimete ületäitumise eest.
// See tagab, et nende panics-ga seotud koodide genereerimine on minimaalne, kuna kogu moodulis on panics-i asemel ainult üks asukoht.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}