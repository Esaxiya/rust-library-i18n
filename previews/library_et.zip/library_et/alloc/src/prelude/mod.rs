//! Jaotus Prelude
//!
//! Selle mooduli eesmärk on leevendada `alloc` crate tavaliselt kasutatavate üksuste importi, lisades moodulite ülaossa globaalse impordi:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;