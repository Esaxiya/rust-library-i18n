//! Stringide vormindamise ja printimise utiliidid.
//!
//! See moodul sisaldab [`format!`]-i süntaksilaiendi käitustuge.
//! See makro on kompilaatoris rakendatud selleks, et väljastada kõnesid sellele moodulile, et vormindada argumendid käitamise ajal stringideks.
//!
//! # Usage
//!
//! [`format!`] makro on mõeldud olema tuttav neile, kes tulevad C funktsioonidest `printf`/`fprintf` või funktsioonist Python `str.format`.
//!
//! Mõned näited laiendist [`format!`] on:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" juhtnullidega
//! ```
//!
//! Nende põhjal näete, et esimene argument on vormingu string.Kompilaator nõuab, et see oleks string literal;see ei saa olla muutuja, mis on sisestatud (kehtivuse kontrollimiseks).
//! Seejärel sõelub kompilaator vormingustringi ja teeb kindlaks, kas esitatud argumentide loend sobib sellele vormingustringile edastamiseks.
//!
//! Üksiku väärtuse stringiks teisendamiseks kasutage meetodit [`to_string`].See kasutab [`Display`]-vormingut trait.
//!
//! ## Asendiparameetrid
//!
//! Igal vorminguargumendil on lubatud määrata, millisele väärtusargumendile see viitab, ja kui see välja jätta, eeldatakse, et see on "the next argument".
//! Näiteks võtaks vormingustring `{} {} {}` kolm parameetrit ja need vormindataks samas järjekorras, nagu on antud.
//! Vormingustring `{2} {1} {0}` vormindaks argumendid aga vastupidises järjekorras.
//!
//! Asjad võivad veidi keeruliseks muutuda, kui hakkate kahte tüüpi positsioneerijat segama."next argument"-i täpsustajat võib pidada argumendi kordajaks.
//! Iga kord, kui kuvatakse "next argument" spetsifikaator, edeneb iteraator edasi.See viib sellise käitumiseni:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Esimese `{}`-i kuvamise ajaks pole argumendi sisemist iteraatorit edasi arendatud, seega prindib see esimese argumendi.Siis on teise `{}`-i jõudmisel iteraator edasi liikunud teise argumendini.
//! Põhimõtteliselt ei mõjuta parameetrid, mis oma argumendi sõnaselgelt nimetavad, parameetreid, mis positsiooni täpsustajate osas argumenti ei nimeta.
//!
//! Kõigi selle argumentide kasutamiseks on vajalik vormindusstring, vastasel juhul on tegemist kompileerimisaja veaga.Vormingu stringis võite samale argumendile viidata mitu korda.
//!
//! ## Nimetatud parameetrid
//!
//! Rust ise ei oma funktsioonile Python-taolist nimega parameetrite ekvivalenti, kuid [`format!`]-makro on süntaksilaiend, mis võimaldab tal kasutada nimetatud parameetreid.
//! Nimetatud parameetrid on loetletud argumentide loendi lõpus ja neil on süntaks:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Näiteks kõik järgmised [`format!`] avaldised kasutavad nimetatut argumenti:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Positsiooniparameetreid (nimeta) ei sobi panna argumentide järele, millel on nimed.Nagu positsioneerivate parameetrite puhul, ei ole ka vormindatud stringis kasutamata nimetatud parameetrite esitamine kehtetu.
//!
//! # Parameetrite vormindamine
//!
//! Iga vormindatavat argumenti saab teisendada mitme vormindamisparameetriga (vastab [the syntax](#syntax))-le [the syntax](#syntax))-is. Need parameetrid mõjutavad vormindatava stringi esitust.
//!
//! ## Width
//!
//! ```
//! // Kõik need prindivad "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! See on "minimum width" parameeter, mille vorming peaks kasutama.
//! Kui väärtuse string ei täida nii palju märke, kasutatakse fill/alignment-i määratud polsterdust vajaliku ruumi võtmiseks (vt allpool).
//!
//! Laiuse väärtuse saab parameetrite loendis esitada ka [`usize`]-na, lisades postfix `$`, mis näitab, et teine argument on laiust määrav [`usize`].
//!
//! Dollari süntaksiga argumendile viitamine ei mõjuta "next argument" loendurit, seega on mõistlik viidata argumentidele positsiooni järgi või kasutada nimega argumente.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Valikuline täitemärk ja joondamine antakse tavaliselt koos parameetriga [`width`](#width).See tuleb määratleda enne `width`, kohe pärast `:`.
//! See näitab, et kui vormindatav väärtus on väiksem kui `width`, prinditakse selle ümber mõned lisamärgid.
//! Erinevatel joondustel on täitmisel järgmised variandid:
//!
//! * `[fill]<` - argument on veergudes `width` vasakule joondatud
//! * `[fill]^` - argument on veergudes `width` keskel joondatud
//! * `[fill]>` - argument on veergudes `width` paremjoondatud
//!
//! [fill/alignment](#fillalignment) on vaikimisi tühik ja vasakule joondatud.Numbrivormindajate vaikimisi on ka tühik, kuid paremjoondusega.
//! Kui numbrite jaoks on määratud `0` lipp (vt allpool), siis on kaudne täitemärk `0`.
//!
//! Pange tähele, et mõnda tüüpi ei pruugi joondamist rakendada.Eelkõige pole seda üldiselt rakendatud `Debug` trait puhul.
//! Hea viis polsterduse rakendamise tagamiseks on sisendi vormindamine ja seejärel väljundi saamiseks selle stringi sisestamine:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Tere Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Need kõik on lipud, mis muudavad vormindaja käitumist.
//!
//! * `+` - See on mõeldud numbritüüpide jaoks ja näitab, et märk tuleks alati printida.Positiivseid märke ei trükita kunagi vaikimisi ja negatiivset märki trükitakse vaikimisi ainult `Signed` trait jaoks.
//! See lipp näitab, et alati tuleks printida õige märk (`+` või `-`).
//! * `-` - Praegu ei kasutata
//! * `#` - See lipp näitab, et tuleks kasutada "alternate"-vormingut.Alternatiivsed vormid on:
//!     * `#?` - printige [`Debug`]-vorming kenasti välja
//!     * `#x` - eelneb argumendile `0x`-ga
//!     * `#X` - eelneb argumendile `0x`-ga
//!     * `#b` - eelneb argumendile `0b`-ga
//!     * `#o` - eelneb argumendile `0o`-ga
//! * `0` - Seda kasutatakse täisarvuvormingute korral, et `width`-i täitmine peaks toimuma nii `0`-tähemärgiga kui ka tähemärgist.
//! Sellisel kujul nagu `{:08}` saadakse `00000001` täisarvule `1`, samas vormingus `-0000001` täisarvule `-1`.
//! Pange tähele, et negatiivsel versioonil on üks null vähem kui positiivsel versioonil.
//!         Pange tähele, et polsterdamisnullad asetatakse alati märgi järele (kui see on olemas) ja enne numbreid.Kasutamisel koos lipuga `#` kehtib sarnane reegel: polsterdamisnullad lisatakse eesliite järele, kuid enne numbreid.
//!         Eesliide sisaldub kogu laiuses.
//!
//! ## Precision
//!
//! Mittenumbriliste tüüpide puhul võib seda pidada "maximum width"-ks.
//! Kui saadud string on sellest laiusest pikem, kärbitakse see nii paljude tähemärkideni ja see parameetrite seadistamisel eraldatakse kärbitud väärtus õigete `fill`, `alignment` ja `width` korral.
//!
//! Integraalsete tüüpide puhul seda ignoreeritakse.
//!
//! Ujuvate punktide tüüpide puhul näitab see, mitu numbrit pärast koma tuleks printida.
//!
//! Soovitud `precision` määramiseks on kolm võimalust:
//!
//! 1. Täisarv `.N`:
//!
//!    täisarv `N` ise on täpsus.
//!
//! 2. Täisarv või nimi, millele järgneb dollarimärk `.N$`:
//!
//!    kasutage täpsusena vormingut *argument*`N` (mis peab olema `usize`).
//!
//! 3. Tärn `.*`:
//!
//!    `.*` tähendab, et see `{...}` on seotud *kahe* vormingus sisendiga, mitte ühe: esimene sisend hoiab `usize`-i täpsust ja teine-printimiseks vajalikku väärtust.
//!    Pange tähele, et kui sellisel juhul kasutatakse vormingu stringi `{<arg>:<spec>.*}`, viitab `<arg>` osa printimiseks* väärtusele * ja `precision` peab tulema `<arg>`-le eelnevas sisendis.
//!
//! Näiteks kõik järgmised kõned trükivad sama asja `Hello x is 0.01000`:
//!
//! ```
//! // Tere, {arg 0 ("x")} on {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Tere, {arg 1 ("x")} on {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Tere, {arg 0 ("x")} on {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Tere, {next arg ("x")} on {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Tere, {next arg ("x")} on {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Tere, {next arg ("x")} on {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Kuigi need:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! printige kolm oluliselt erinevat asja:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Mõnes programmeerimiskeeles sõltub stringi vormindamise funktsioonide käitumine opsüsteemi lokaadi sätetest.
//! Rust standardses teegis pakutavatel vormindamisfunktsioonidel puudub lokaadi mõiste ja need annavad kõigis süsteemides ühesugused tulemused, olenemata kasutaja konfiguratsioonist.
//!
//! Näiteks prindib järgmine kood alati `1.5`, isegi kui süsteemi lokaat kasutab muud kümnendkoha eraldajat kui punkt.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Sõnasõnalised tähemärgid `{` ja `}` võidakse lisada stringi, eelnedes neile sama tähemärgiga.Näiteks `{` tähemärki `{{` ja `}` `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Kokkuvõtteks võib öelda, et siit leiate vormingustringide täieliku grammatika.
//! Kasutatava vorminduskeele süntaks pärineb teistest keeltest, nii et see ei tohiks olla liiga võõras.Argumendid on vormindatud Python-laadse süntaksiga, mis tähendab, et argumente ümbritseb C-sarnase `%` asemel `{}`.
//! Vormindussüntaksi tegelik grammatika on:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Ülaltoodud grammatikas ei pruugi `text` sisaldada märke `'{'` või `'}'`.
//!
//! # traits vormindamine
//!
//! Kui taotlete argumendi vormindamist kindla tüübiga, siis tegelikult taotlete, et argument omistataks teatud trait-le.
//! See võimaldab `{:x}` kaudu vormindada mitut tegelikku tüüpi (näiteks [`i8`] ja [`isize`]).Praegune tüüpide vastavus traits-le on järgmine:
//!
//! * *mitte midagi* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] väikeste tähtedega kuueteistkümnendsüsteemi täisarvudega
//! * `X?` ⇒ [`Debug`] suurtähtedega kuueteistkümnendsüsteemi täisarvudega
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! See tähendab, et mis tahes tüüpi argumente, mis rakendavad [`fmt::Binary`][`Binary`] trait, saab seejärel vormindada `{:b}`-iga.Rakendused on nende traits jaoks ette nähtud paljude primitiivsete tüüpide jaoks ka tavalises raamatukogus.
//!
//! Kui ühtegi vormingut pole määratud (nagu `{}` või `{:6}`), on kasutatav vorming trait [`Display`] trait.
//!
//! Vormingu trait juurutamisel oma tüübi jaoks peate kasutama allkirja meetodit:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // meie kohandatud tüüp
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Teie tüüp edastatakse `self`-i viitena ja seejärel peaks funktsioon väljastama väljundi voogesse `f.buf`.Taotletud vormindamisparameetritest õigesti kinni pidamine sõltub iga trait-vormingu rakendusest.
//! Nende parameetrite väärtused loetletakse [`Formatter`]-i struktuuri väljadel.Selle aitamiseks pakub [`Formatter`] struct ka mõningaid abimeetodeid.
//!
//! Lisaks on selle funktsiooni tagastusväärtuseks [`fmt::Result`], mis on tüübi pseudonüümiks ["Tulemus"] "<()," ["std: : fmt::Viga"] ">".
//! Rakenduste vormindamine peaks tagama, et need levitavad vigu [`Formatter`]-ist (nt [`write!`]-i helistamisel).
//! Kuid nad ei tohiks kunagi vigu vääralt tagastada.
//! See tähendab, et vormindamise juurutamine peab tõrke tagastama ja tooma ainult siis, kui sisestatud [`Formatter`] tagastab tõrke.
//! Selle põhjuseks on asjaolu, et vastupidiselt funktsiooni signatuuri soovitusele on stringi vormindamine eksimatu toiming.
//! See funktsioon tagastab ainult tulemuse, kuna aluseks olevasse voosse kirjutamine võib ebaõnnestuda ja see peab pakkuma viisi, kuidas virna varundamisel ilmnes tõrge.
//!
//! Näide vormindamise traits juurutamisest näeks välja järgmine:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // `f` väärtus rakendab `Write` trait, mis on see, mida kirjutada!makro ootab.
//!         // Pange tähele, et see vormindamine eirab stringide vormistamiseks pakutavaid erinevaid lippe.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Erinevad traits võimaldavad tüübi väljundit erinevaid vorme.
//! // Selle vormingu tähendus on vector suuruse printimine.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Austage vormindamise lippe, kasutades vormindusobjektil abimeetodit `pad_integral`.
//!         // Lisateavet leiate meetodi dokumentatsioonist ja funktsiooni `pad` saab kasutada stringide polsterdamiseks.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Nendel kahel traits vormindamisel on erinevad eesmärgid:
//!
//! - [`fmt::Display`][`Display`] teostused kinnitavad, et tüüpi saab alati tõetruult kujutada UTF-8-stringina.**Ei ole** eeldatav, et kõik tüübid rakendavad [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] rakendused tuleks rakendada **kõigi** avalike tüüpide jaoks.
//!   Väljund esindab tavaliselt sisemist olekut võimalikult tõetruult.
//!   [`Debug`] trait eesmärk on hõlbustada Rust koodi silumist.Enamasti on `#[derive(Debug)]` kasutamine piisav ja soovitatav.
//!
//! Mõned näited mõlema traits väljundist:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Seotud makrod
//!
//! [`format!`] perekonnas on mitmeid seotud makrosid.Praegu rakendatakse järgmisi:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! See ja [`writeln!`] on kaks makrot, mida kasutatakse vormingus stringi emiteerimiseks määratud voos.Seda kasutatakse vormingustringide vahepealse eraldamise vältimiseks ja selle asemel kirjutatakse otse väljund.
//! Kapoti all kutsub see funktsioon tegelikult [`std::io::Write`] trait-s määratletud funktsiooni [`write_fmt`].
//! Kasutamise näide on:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! See ja [`println!`] väljastavad oma väljundi stdout-le.Sarnaselt makroga [`write!`] on ka nende makrode eesmärk vältida väljundite printimisel vaheeraldisi.Kasutamise näide on:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! [`eprint!`] ja [`eprintln!`] makrod on identsed vastavalt [`print!`] ja [`println!`], välja arvatud, et nad väljastavad oma väljundi stderr-le.
//!
//! ### `format_args!`
//!
//! See on uudishimulik makro, mida kasutatakse formaadistringi kirjeldava läbipaistmatu objekti ümber turvaliseks läbimiseks.Selle objekti loomiseks pole kuhjaga eraldisi vaja ja see viitab ainult virnas olevale teabele.
//! Kapoti all on kõik sellega seotud makrod rakendatud selles mõttes.
//! Esiteks on mõned kasutusnäited:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Makro [`format_args!`] tulemus on tüübi [`fmt::Arguments`] väärtus.
//! Selle struktuuri saab seejärel vormingus stringi töötlemiseks edastada selle mooduli sees olevatele funktsioonidele [`write`] ja [`format`].
//! Selle makro eesmärk on stringide vormindamisel tegeleda veelgi vahepealsete eraldiste vältimisega.
//!
//! Näiteks võiks logiraamatukogu kasutada standardset vormindamise süntaksit, kuid see läbiks selle struktuuri sisemiselt, kuni on kindlaks tehtud, kuhu väljund peaks minema.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Funktsioon `format` võtab [`Arguments`]-struktuuri ja tagastab saadud vormindatud stringi.
///
///
/// [`Arguments`]-eksemplari saab luua makroga [`format_args!`].
///
/// # Examples
///
/// Põhikasutus:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Pange tähele, et eelistada võib [`format!`]-i kasutamist.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}