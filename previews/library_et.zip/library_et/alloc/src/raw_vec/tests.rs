use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Kolmandate osapoolte eraldajate ja `RawVec` vahelise integratsiooni testi kirjutamine on veidi keeruline, kuna `RawVec` API ei avalda ekslikke jaotamismeetodeid, seega ei saa me kontrollida, mis juhtub, kui eraldaja on ammendatud (peale panic tuvastamise).
    //
    //
    // Selle asemel kontrollitakse lihtsalt, kas `RawVec`-meetodid läbivad salvestusruumi reserveerimisel vähemalt Allocatori API.
    //
    //
    //
    //
    //

    // Loll eraldaja, kes tarbib kindlas koguses kütust, enne kui jaotuskatsed hakkavad ebaõnnestuma.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (põhjustab ümberjaotuse, kasutades seega 50 + 150=200 ühikut kütust)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Esiteks eraldab `reserve` nagu `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 on rohkem kui 7-ga kahekordne, seega peaks `reserve` töötama nagu `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 on vähem kui pool 12-st, seega peab `reserve` kasvama eksponentsiaalselt.
        // Selle testi kirjutamise ajal on kasvutegur 2, seega on uus võimsus 24, kuid ka 1.5 kasvutegur on korras.
        //
        // Seega väidab `>= 18`.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}