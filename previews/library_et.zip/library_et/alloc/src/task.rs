#![stable(feature = "wake_trait", since = "1.51.0")]
//! Tüübid ja Traits asünkroonsete ülesannetega töötamiseks.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Täituri ülesande äratamise rakendamine.
///
/// Seda trait saab kasutada [`Waker`] loomiseks.
/// Testamenditäitja saab määratleda selle trait-i rakenduse ja kasutada seda Wakeri koostamiseks, et edastada sellele täiturile täidetavaid ülesandeid.
///
/// See trait on mälusäästlik ja ergonoomiline alternatiiv [`RawWaker`]-i konstrueerimisele.
/// See toetab tavalist täiturikujundust, milles ülesande äratamiseks kasutatud andmed on salvestatud [`Arc`]-i.
/// Mõned täitjad (eriti manustatud süsteemide jaoks) ei saa seda API-d kasutada, mistõttu [`RawWaker`] on nende süsteemide jaoks alternatiiv.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Põhifunktsioon `block_on`, mis võtab future ja käivitab selle praeguse lõime lõpuni.
///
/// **Note:** See näide müüb õiguse lihtsuse huvides.
/// Ummistuste vältimiseks peavad tootmistasemel rakendused käsitsema ka `thread::unpark`-i vahekõnesid ja pesastatud invokatsioone.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Ärataja, kes äratab praeguse lõime, kui teda kutsutakse.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Käivitage future praeguse lõime lõpuleviimiseks.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Kinnitage future, et seda saaks küsitleda.
///     let mut fut = Box::pin(fut);
///
///     // Looge uus kontekst, mis edastatakse future-le.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Käivitage future lõpuni.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Ärka see ülesanne üles.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Äratage see ülesanne ärkajat tarbimata.
    ///
    /// Kui testamenditäitja toetab odavamat ärkamisviisi ilma ärkajat tarbimata, peaks ta selle meetodi tühistama.
    /// Vaikimisi kloonib see [`Arc`] ja kutsub klooni [`wake`].
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // OHUTUS: See on ohutu, kuna raw_waker ehitab ohutult
        // RawWaker Arcilt<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Seda privaatset funktsiooni RawWakeri koostamiseks kasutatakse pigem
// lisades selle `From<Arc<W>> for RawWaker`-implantaadile, tagamaks, et `From<Arc<W>> for Waker`-i ohutus ei sõltu õigest trait-i saatmisest, kutsuvad mõlemad implitsiidid seda funktsiooni otse ja otsesõnu.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Suurendage selle kloonimiseks kaare võrdlusarvu.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Ärgake väärtuse järgi, liigutades kaare funktsiooni Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Ärka viitena, mässi ärkvel manuaalDropi, et vältida selle kukkumist
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Vähendage kaare võrdlusarvu langemisel
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}