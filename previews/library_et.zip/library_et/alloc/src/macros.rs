/// Loob argumente sisaldava [`Vec`].
///
/// `vec!` võimaldab `Vec`s määratleda sama süntaksiga nagu massiivi avaldised.
/// Selle makro vorme on kaks:
///
/// - Looge [`Vec`], mis sisaldab antud elementide loendit:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Looge [`Vec`] etteantud elemendist ja suurusest:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Pange tähele, et erinevalt massiivi avaldistest toetab see süntaks kõiki elemente, mis rakendavad [`Clone`]-i ja elementide arv ei pea olema konstant.
///
/// See kasutab avaldise paljundamiseks `clone`-i, seega peaksite olema ettevaatlik selle kasutamisel tüüpide puhul, millel on `Clone`-i mittestandardne rakendus.
/// Näiteks `vec![Rc::new(1);5] "loob vector viiest viitest samale kasti täisarvu väärtusele, mitte viiest viitega, mis osutavad iseseisvalt kasti täisarvudele.
///
///
/// Pange tähele, et `vec![expr; 0]` on lubatud ja toodab tühja vector.
/// See hindab siiski `expr`-i ja langetab saadud väärtuse kohe, nii et pidage meeles kõrvaltoimeid.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): cfg(test)-ga pole selle makrodefinitsiooni jaoks vajalik `[T]::into_vec`-meetod omane.
// Selle asemel kasutage funktsiooni `slice::into_vec`, mis on saadaval ainult koos cfg(test) NB-ga, lisateabe saamiseks vaadake slice.rs-i moodulit slice.rs
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Loob käitusaja avaldiste interpoleerimise abil `String`.
///
/// Esimene argument, mille `format!` saab, on vormingu string.See peab olema stringi literaal.Vormindusstringi võimsus on sisalduvates tekstides.
///
/// `format!`-le edastatud täiendavad parameetrid asendavad vormingus stringis olevad parameetrid antud järjekorras, välja arvatud juhul, kui kasutatakse nime-või asukohaparameetreid;lisateabe saamiseks vaadake [`std::fmt`].
///
///
/// `format!`-i tavaliseks kasutuseks on stringide liitmine ja interpoleerimine.
/// Sama kokkulepet kasutatakse [`print!`] ja [`write!`] makrode puhul, sõltuvalt stringi kavandatud sihtkohast.
///
/// Üksiku väärtuse stringiks teisendamiseks kasutage meetodit [`to_string`].See kasutab [`Display`]-vormingut trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics, kui vormindamise trait juurutamine tagastab vea.
/// See viitab valele juurutamisele, kuna `fmt::Write for String` ei anna kunagi ise viga.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Sundige AST-sõlme avaldisele, et parandada mustri asukoha diagnostikat.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}