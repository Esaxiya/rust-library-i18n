#![stable(feature = "rust1", since = "1.0.0")]

//! Niidikindlad viite loendamise näpunäited.
//!
//! Lisateavet leiate [`Arc<T>`][Arc] dokumentatsioonist.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Pehme piirang `Arc`-le tehtavate viidete arvule.
///
/// Selle piiri ületamine katkestab teie programmi (kuigi mitte tingimata) _exactly_ `MAX_REFCOUNT + 1` viitega.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer ei toeta mäluaeda.
// Arc/Weak rakenduses valepositiivsete aruannete vältimiseks kasutage sünkroonimiseks hoopis aatomkoormusi.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Keermeohutu viite loendamise osuti.'Arc' tähistab 'Atomically Reference Counted'.
///
/// Tüüp `Arc<T>` annab hunnikus eraldatud `T` tüüpi väärtuse jagatud omandiõiguse.[`clone`][clone]-i kutsumine `Arc`-il loob uue `Arc`-eksemplari, mis osutab samale jaotusele kuhjas kui allikas `Arc`, suurendades samal ajal võrdlusarvu.
/// Kui konkreetse eraldise viimane `Arc`-osuti hävitatakse, langeb ka sellesse jaotusse salvestatud väärtus (sageli nimetatud kui "inner value").
///
/// Rust-s jagatud viited keelavad mutatsiooni vaikimisi ja `Arc` pole erand: üldiselt ei saa muudetavat viidet `Arc`-i sisemusele.Kui peate muteeruma `Arc` kaudu, kasutage [`Mutex`][mutex], [`RwLock`][rwlock] või mõnda [`Atomic`][atomic] tüüpi.
///
/// ## Keerme ohutus
///
/// Erinevalt [`Rc<T>`]-ist kasutab `Arc<T>` võrdlusloendamiseks aatomioperatsioone.See tähendab, et see on niidikindel.Puuduseks on see, et aatomioperatsioonid on kallimad kui tavalised mälupääsud.Kui te ei jaga viidete vahel loendatud jaotusi lõimede vahel, kaaluge madalama üldkuluna [`Rc<T>`] kasutamist.
/// [`Rc<T>`] on turvaline vaikimisi, kuna kompilaator tabab kõik katsed [`Rc<T>`]-i saatmiseks lõimude vahel.
/// Raamatukogu tarbijatele paindlikkuse suurendamiseks võib raamatukogu siiski valida `Arc<T>`.
///
/// `Arc<T>` rakendab [`Send`] ja [`Sync`] seni, kuni `T` rakendab [`Send`] ja [`Sync`].
/// Miks ei saa te `Arc<T>`-i panna niiditult ohutut tüüpi `T`, et see oleks niidikindel?See võib esialgu olla natuke vastuoluline: kas pole ju `Arc<T>` niidiohutuse mõte?Peamine on see: `Arc<T>` muudab lõime ohutuks, kui teil on samadel andmetel mitu omandiõigust, kuid see ei lisa selle andmetele lõime ohutust.
///
/// Mõelge kaarele <Arc [`RefCell<T>"]">".
/// [`RefCell<T>`] ei ole [`Sync`] ja kui `Arc<T>` oli alati [`Send`], siis `Arc <` [`RefCell<T>"]"> oleks ka.
/// Aga siis oleks meil probleem:
/// [`RefCell<T>`] ei ole niidiga ohutu;see jälgib laenude arvu mitte-aatomoperatsioonide abil.
///
/// Lõppkokkuvõttes tähendab see, et peate võib-olla `Arc<T>` paaristama mingi [`std::sync`] tüübiga, tavaliselt [`Mutex<T>`][mutex].
///
/// ## Tsüklite katkestamine `Weak`-iga
///
/// [`downgrade`][downgrade]-meetodi abil saab luua mitteomava [`Weak`]-osuti.[`Weak`]-osuti võib olla [`upgrade`][upgrade] d `Arc`-iks, kuid see tagastab [`None`], kui jaotusse salvestatud väärtus on juba langenud.
/// Teisisõnu, `Weak`-i osutajad ei hoia jaotuses olevat väärtust elus;aga nad hoiavad eraldise (väärtuse tagavarapoe) elus.
///
/// `Arc`-osuti vahelist tsüklit ei jagata kunagi.
/// Sel põhjusel kasutatakse [`Weak`]-i tsüklite katkestamiseks.Näiteks võiks puul olla tugevad `Arc`-i näpunäited vanemate sõlmedest lastele ja [`Weak`]-i näpunäited lastelt nende vanemate juurde.
///
/// # Kloonimise viited
///
/// Uue viite loomine olemasolevast võrdlusloendusega kursorist toimub [`Arc<T>`][Arc] ja [`Weak<T>`][Weak] jaoks rakendatud `Clone` trait abil.
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Kaks allpool toodud süntaksit on samaväärsed.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b ja foo on kõik kaared, mis osutavad samale mälupunktile
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` automaatselt viited `T`-le ([`Deref`][deref] trait kaudu), nii et saate helistada `T` meetoditele väärtusele `Arc<T>`.Nimekonfliktide vältimiseks `T` meetoditega on `Arc<T>` meetodid ise seotud funktsioonid, mida nimetatakse [fully qualified syntax] abil:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// Kaar<T>traits-i rakendusi nagu `Clone` võib kutsuda ka täielikult kvalifitseeritud süntaksiga.
/// Mõned inimesed eelistavad kasutada täielikult kvalifitseeritud süntaksi, teised aga meetodi-kõne süntaksit.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Meetodi-kõne süntaks
/// let arc2 = arc.clone();
/// // Täielikult kvalifitseeritud süntaks
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] ei tee `T`-le automaatselt allahindlust, kuna sisemine väärtus võib olla juba langenud.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Mõnede muutumatute andmete jagamine lõimede vahel:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Pange tähele, et me ** ei käivita neid teste siin.
// windows-i ehitajad muutuvad ülimalt õnnetuks, kui lõim elab peamise lõime üle ja seejärel samal ajal väljub (midagi ummikus), nii et me lihtsalt väldime seda täielikult, kui neid teste ei käivitata.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Muutuva [`AtomicUsize`] jagamine:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Vaadake [`rc` documentation][rc_examples]-i, et saada rohkem näiteid võrdlusloendamise kohta üldiselt.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` on [`Arc`]-i versioon, millel on hallatavale jaotusele mitteomandav viide.
/// Jaotusele pääseb ligi, helistades `Weak`-i osuti [`upgrade`]-le, mis tagastab [`Option`]`<`[``Arc````<T>> ".
///
/// Kuna `Weak` viide ei loe omandilise kuuluvuse hulka, ei takista see jaotuses salvestatud väärtuse langemist ja `Weak` ise ei garanteeri, et väärtus on endiselt olemas.
///
/// Seega võib see [`None`]-i tagastada, kui ["uuendada"] d.
/// Pange tähele, et `Weak` viide * ei takista jaotuse enda (tugipoe) jaotamist.
///
/// `Weak`-osuti on kasulik ajutise viite säilitamiseks jaotusele, mida haldab [`Arc`], takistamata selle sisemise väärtuse langemist.
/// Seda kasutatakse ka [`Arc`]-osuti vaheliste ümmarguste viidete vältimiseks, kuna vastastikuse omamise viited ei võimaldaks kunagi kumbagi [`Arc`]-st loobuda.
/// Näiteks võiks puul olla tugevad [`Arc`]-i näpunäited vanemate sõlmedest lastele ja `Weak`-i näpunäited lastelt nende vanemate juurde.
///
/// Tüüpiline viis `Weak`-osuti saamiseks on helistada numbrile [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // See on `NonNull`, mis võimaldab selle tüübi suurust loendites optimeerida, kuid see pole tingimata kehtiv osut.
    //
    // `Weak::new` määrab selle väärtuseks `usize::MAX`, et see ei peaks hunnikule ruumi eraldama.
    // See pole väärtus, mida tõeline osuti kunagi saab, kuna RcBoxil on joondatud vähemalt 2.
    // See on võimalik ainult siis, kui `T: Sized`;suurusega `T` ei rippu kunagi.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// See on repr(C) kuni future kindel võimalike väljade ümberkorralduste vastu, mis häiriks muidu muudetavate sisetüüpide muidu ohutut [into|from]_raw()-i.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // väärtus usize::MAX toimib ajutise "locking"-i valvurina võime üle viia nõrku osuteid või alandada tugevaid;seda kasutatakse `make_mut` ja `get_mut` võistluste vältimiseks.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Ehitab uue `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Alustage nõrga kursori loendit 1, mis on nõrk kursor, mida hoiavad kõik tugevad osutid (kinda), lisateabe saamiseks vaadake std/rc.rs
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Ehitab uue `Arc<T>`, kasutades nõrka viidet iseendale.
    /// Nõrga viite värskendamise katse enne selle funktsiooni taastamist annab `None` väärtuse.
    /// Nõrgat lähteainet võib siiski vabalt kloonida ja säilitada kasutamiseks hiljem.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Ehitage sisemine olek "uninitialized" ühe nõrga referentsiga.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Tähtis on, et me ei loobuks nõrga osuti omamisest, muidu võib mälu vabaneda selleks ajaks, kui `data_fn` naaseb.
        // Kui me tõesti sooviksime omandiõiguse üle anda, võiksime luua endale täiendava nõrga kursori, kuid see tooks kaasa nõrkade võrdlusarvude täiendavaid värskendusi, mis muidu poleks võib-olla vajalikud.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Nüüd saame sisemise väärtuse korralikult lähtestada ja muuta oma nõrga võrdluse tugevaks võrdluseks.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Ülaltoodud andmeväljale kirjutamine peab olema nähtav kõigile lõimudele, mis jälgivad nullist erinevat tugevat arvu.
            // Seetõttu vajame `Weak::upgrade`-is sünkroonimiseks `compare_exchange_weak`-iga sünkroonimiseks vähemalt "Release"-i tellimist.
            //
            // "Acquire" tellimine pole vajalik.
            // `data_fn` võimaliku käitumise kaalumisel peame vaatama ainult seda, mida see võiks teha, viidates täiendamata `Weak`-le:
            //
            // - See võib *kloonida*`Weak`, suurendades nõrka võrdlusarvu.
            // - See võib need kloonid kukutada, vähendades nõrka võrdlusarvu (kuid mitte kunagi nulli).
            //
            // Need kõrvaltoimed ei mõjuta meid kuidagi ja ainult ohutu koodiga pole muud kõrvaltoimed võimalikud.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Tugevatele viidetele peaksid ühiselt kuuluma jagatud nõrk viide, nii et ärge käivitage meie vana nõrga viite hävitajat.
        //
        mem::forget(weak);
        strong
    }

    /// Ehitab uue initsialiseerimata sisuga `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Edasilükatud lähtestamine:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Ehitab uue initsialiseerimata sisuga `Arc`, kusjuures mälu on täidetud `0`-baitidega.
    ///
    ///
    /// Selle meetodi õige ja vale kasutamise näiteid leiate jaotisest [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Ehitab uue `Pin<Arc<T>>`.
    /// Kui `T` ei rakenda `Unpin`-i, kinnitatakse `data` mällu ja seda ei saa teisaldada.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Ehitab uue `Arc<T>`, tagastades tõrke, kui jaotamine ebaõnnestub.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Alustage nõrga kursori loendit 1, mis on nõrk kursor, mida hoiavad kõik tugevad osutid (kinda), lisateabe saamiseks vaadake std/rc.rs
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Ehitab uue initsialiseerimata sisuga `Arc`, tagastades tõrke, kui jaotamine ebaõnnestub.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Edasilükatud lähtestamine:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Ehitab uue initsialiseerimata sisuga `Arc`, kusjuures mälu on täidetud `0`-baitidega, tagastades tõrke, kui jaotamine ebaõnnestub.
    ///
    ///
    /// Selle meetodi õige ja vale kasutamise näiteid leiate jaotisest [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Tagastab sisemise väärtuse, kui `Arc`-l on täpselt üks tugev viide.
    ///
    /// Vastasel juhul tagastatakse [`Err`] sama `Arc`-iga, mis edastati.
    ///
    ///
    /// See õnnestub ka siis, kui on silmapaistvaid nõrku viiteid.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Tehke nõrk näpunäide kaudse tugeva-nõrga viite puhastamiseks
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Ehitab uue initsialiseerimata sisuga aatomite järgi loendatud viilu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Edasilükatud lähtestamine:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Ehitab uue initsialiseerimata sisuga aatomite järgi loendatud viilu, kusjuures mälu on täidetud `0`-baitidega.
    ///
    ///
    /// Selle meetodi õige ja vale kasutamise näiteid leiate jaotisest [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Teisendab `Arc<T>`-ks.
    ///
    /// # Safety
    ///
    /// Nagu [`MaybeUninit::assume_init`] puhul, on ka helistaja ülesanne garanteerida, et sisemine väärtus on tõesti lähtestatud olekus.
    ///
    /// Sellele helistamine, kui sisu pole veel täielikult vormistatud, põhjustab kohest määratlemata käitumist.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Edasilükatud lähtestamine:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Teisendab `Arc<[T]>`-ks.
    ///
    /// # Safety
    ///
    /// Nagu [`MaybeUninit::assume_init`] puhul, on ka helistaja ülesanne garanteerida, et sisemine väärtus on tõesti lähtestatud olekus.
    ///
    /// Sellele helistamine, kui sisu pole veel täielikult vormistatud, põhjustab kohest määratlemata käitumist.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Edasilükatud lähtestamine:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Tarbib `Arc`-i, tagastades pakitud osuti.
    ///
    /// Mälulekke vältimiseks tuleb osuti [`Arc::from_raw`] abil teisendada `Arc`-ks.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Annab andmetele toore kursori.
    ///
    /// Loendeid ei mõjuta see mingil viisil ja `Arc`-i ei tarbita.
    /// Kursor kehtib seni, kuni `Arc`-is on tugevaid loendusi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // OHUTUS: Seda ei saa läbi viia Deref::deref ega RcBoxPtr::inner, sest
        // see on vajalik raw/mut päritolu säilitamiseks nii, et nt
        // `get_mut` saab osuti kirjutada pärast Rc taastamist `from_raw` kaudu.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Ehitab `Arc<T>` töötlemata kursori järgi.
    ///
    /// Toores osuti peab olema varem tagasi saadetud kutsega [`Arc<U>::into_raw`][into_raw], kus `U` peab olema sama suur ja joondatud kui `T`.
    /// See on triviaalselt tõsi, kui `U` on `T`.
    /// Pange tähele, et kui `U` ei ole `T`, kuid sellel on sama suurus ja joondus, on see põhimõtteliselt nagu eri tüüpi viidete transmutamine.
    /// Lisateavet selle kohta kehtivate piirangute kohta leiate jaotisest [`mem::transmute`][transmute].
    ///
    /// `from_raw`-i kasutaja peab veenduma, et `T`-i konkreetne väärtus langetatakse ainult üks kord.
    ///
    /// See funktsioon on ohtlik, kuna ebaõige kasutamine võib põhjustada mälu ebaturvalisuse isegi siis, kui tagastatud `Arc<T>`-i kunagi juurde ei pääse.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Lekke vältimiseks teisendage tagasi `Arc`-ks.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Edasised kõned `Arc::from_raw(x_ptr)`-ile oleksid mäluohtlikud.
    /// }
    ///
    /// // Mälu vabastati, kui `x` ülaltoodud reguleerimisalast välja läks, nii et `x_ptr` ripub nüüd!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // ArcInneri leidmiseks pöörake nihe tagasi.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Loob sellele eraldisele uue [`Weak`]-i kursori.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // See lõdvestus on korras, kuna kontrollime allpool toodud CAS-i väärtust.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // kontrollige, kas nõrk loendur on praegu "locked";kui jah, siis keeruta.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: see kood eirab praegu ülevoolu võimalust
            // usize::MAX-i;üldiselt tuleb ülevooluga tegelemiseks reguleerida nii Rc kui ka Arc.
            //

            // Erinevalt Clone()-ist vajame seda, et see oleks omandamise lugemine, et sünkroonida `is_unique`-st pärineva kirjutisega, nii et sellele kirjutamisele eelnevad sündmused toimuksid enne seda lugemist.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Veenduge, et me ei loo rippuvat nõrka
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Sellele jaotusele saab [`Weak`]-i osutajate arvu.
    ///
    /// # Safety
    ///
    /// See meetod on iseenesest ohutu, kuid selle õige kasutamine nõuab täiendavat hoolt.
    /// Teine lõime võib nõrka arvu igal ajal muuta, sealhulgas potentsiaalselt selle meetodi kutsumise ja tulemusele reageerimise vahel.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // See väide on deterministlik, kuna me pole `Arc`-i ega `Weak`-i lõimede vahel jaganud.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Kui nõrk arv on praegu lukus, oli loenduse väärtus vahetult enne luku võtmist 0.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Hangi selle jaotuse jaoks tugevate (`Arc`)-osutite arv.
    ///
    /// # Safety
    ///
    /// See meetod on iseenesest ohutu, kuid selle õige kasutamine nõuab täiendavat hoolt.
    /// Teine niit võib igal ajal muuta tugevat arvu, sealhulgas potentsiaalselt selle meetodi kutsumise ja tulemuse järgi tegutsemise vahel.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // See väide on deterministlik, kuna me pole `Arc`-i lõimede vahel jaganud.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Suurendab pakutava kursoriga seotud `Arc<T>` tugevat võrdlusarvu ühe võrra.
    ///
    /// # Safety
    ///
    /// Kursor peab olema saadud `Arc::into_raw` kaudu ja sellega seotud `Arc` eksemplar peab olema kehtiv (st
    /// tugev arv peab selle meetodi kestel olema vähemalt 1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // See väide on deterministlik, kuna me pole `Arc`-i lõimede vahel jaganud.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Säilitage kaar, kuid ärge puudutage ümberarvutamist, pakkides ManuallyDropi
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Nüüd suurendage tagasiarvestust, kuid ärge langetage ka uut arvet
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Vähendab pakutava kursoriga seotud `Arc<T>` tugevat võrdlusarvu ühe võrra.
    ///
    /// # Safety
    ///
    /// Kursor peab olema saadud `Arc::into_raw` kaudu ja sellega seotud `Arc` eksemplar peab olema kehtiv (st
    /// selle meetodi kasutamisel peab tugev arv olema vähemalt 1).
    /// Seda meetodit saab kasutada lõpliku `Arc` ja tugimälu vabastamiseks, kuid **ei tohiks** kutsuda pärast lõpliku `Arc` vabastamist.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Need väited on deterministlikud, kuna me pole `Arc`-i lõimede vahel jaganud.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // See ebaturvalisus on ok, sest sel ajal, kui see kaar on elus, tagame sisemise osuti kehtivuse.
        // Lisaks teame, et `ArcInner` struktuur ise on `Sync`, kuna sisemised andmed on ka `Sync`, nii et me laename selle sisu jaoks muutumatu kursori.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // `drop` sisselõiketa osa.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Hävitage andmed praegu, kuigi me ei pruugi kasti eraldamist ise vabastada (seal võib siiski olla nõrku näpunäiteid).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Pange nõrk ref kokku, mida hoiavad kõik tugevad viited
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Tagastab `true`, kui kaks kaarti osutavad samale jaotusele ([`ptr::eq`]-ga sarnases veenis).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Määrab `ArcInner<T>`-i, kus on piisavalt ruumi võimaliku suuruse sisemise väärtuse jaoks, kui väärtusel on paigutus.
    ///
    /// Funktsioonile `mem_to_arcinner` kutsutakse andmekursoriga ja see peab `ArcInner<T>`-i jaoks tagastama (potentsiaalselt rasv) osutaja.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Arvutage paigutus, kasutades antud väärtuse paigutust.
        // Varem arvutati paigutus avaldisele `&*(ptr as* const ArcInner<T>)`, kuid see lõi valesti joondatud viite (vt #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Määrab `ArcInner<T>`-i, kus on piisavalt ruumi võimaliku suuruse sisemise väärtuse jaoks, kui väärtusel on paigutus, tagastades vea, kui jaotamine ebaõnnestub.
    ///
    ///
    /// Funktsioonile `mem_to_arcinner` kutsutakse andmekursoriga ja see peab `ArcInner<T>`-i jaoks tagastama (potentsiaalselt rasv) osutaja.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Arvutage paigutus, kasutades antud väärtuse paigutust.
        // Varem arvutati paigutus avaldisele `&*(ptr as* const ArcInner<T>)`, kuid see lõi valesti joondatud viite (vt #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Alustage ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Eraldab `ArcInner<T>`, millel on piisavalt ruumi suuruse sisemise väärtuse jaoks.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // `ArcInner<T>` jaoks eraldage antud väärtus.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopeeri väärtus baitidena
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Tasuta eraldamine selle sisu ära viskamata
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Määrab `ArcInner<[T]>` etteantud pikkusega.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Kopeerige elemendid viilust äsja eraldatud kaaresse <\[T\]>
    ///
    /// Ohtlik, kuna helistaja peab kas omandama `T: Copy`-i või siduma selle.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Ehitab `Arc<[T]>`-i iteraatorist, mis on teadaolevalt teatud suurusega.
    ///
    /// Käitumine on määratlemata, kui suurus oleks vale.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic valvur T-elementide kloonimise ajal.
        // panic korral langevad uude ArcInneri kirjutatud elemendid ja seejärel vabastatakse mälu.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Esimese elemendi kursor
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Kõik selge.Unustage valvur, nii et see ei vabastaks uut ArcInnerit.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` jaoks kasutatakse spetsialiseerumist trait.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Valmistab `Arc`-i osuti klooni.
    ///
    /// Nii luuakse teine osutus samale jaotusele, suurendades tugevat võrdlusarvu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Pingutatud järjestuse kasutamine on siin igati korras, kuna algse viite tundmine takistab teistel niitidel objekti ekslikult kustutamast.
        //
        // Nagu [Boost documentation][1]-s on selgitatud, saab võrdlusloenduri suurendamist alati teha mäluga_korraldus_relaksitud: uusi viiteid objektile saab moodustada ainult olemasolevast viitest ja olemasoleva viite edastamine ühest lõimest teise peab juba tagama vajaliku sünkroonimise.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Kuid peame hoiduma massiivsete tagasimaksete eest, kui keegi on kaari unustamas.
        // Kui me seda ei tee, võib arv ületada ja kasutajad kasutavad seda tasuta.
        // Küllalt küllastume `isize::MAX`-ni eeldusel, et pole ~2 miljardit lõime, mis suurendaksid viitenumbrit korraga.
        //
        // Seda branch ei kasutata kunagi üheski realistlikus programmis.
        //
        // Me katkestame, sest selline programm on uskumatult degenereerunud ja me ei hooli sellest.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Annab muudetava viite antud `Arc`-le.
    ///
    /// Kui samale jaotusele on muid `Arc` või [`Weak`] osutajaid, loob `make_mut` uue jaotuse ja kutsub ainulaadse omandilise kuuluvuse tagamiseks sisemisele väärtusele [`clone`][clone].
    /// Seda nimetatakse ka kloon-kirjutamiseks.
    ///
    /// Pange tähele, et see erineb [`Rc::make_mut`] käitumisest, mis eraldab kõik ülejäänud `Weak` osutid.
    ///
    /// Vaadake ka [`get_mut`][get_mut]-i, mis kloonimise asemel ebaõnnestub.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Ei klooni midagi
    /// let mut other_data = Arc::clone(&data); // Ei klooni sisemisi andmeid
    /// *Arc::make_mut(&mut data) += 1;         // Kloonib sisemised andmed
    /// *Arc::make_mut(&mut data) += 1;         // Ei klooni midagi
    /// *Arc::make_mut(&mut other_data) *= 2;   // Ei klooni midagi
    ///
    /// // Nüüd osutavad `data` ja `other_data` erinevatele jaotustele.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Pange tähele, et meil on nii tugev kui ka nõrk viide.
        // Seega ainult meie tugeva viite vabastamine ei põhjusta iseenesest mälu hajutamist.
        //
        // Kasutage Acquire'i, et veenduda, et näeme kõiki `weak`-i kirjutusi, mis toimuvad enne versiooni `strong`-i kirjutamist (st vähendamist).
        // Kuna meil on nõrk arv, pole võimalust, et ArcInner ise saaks jaotada.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // On veel üks tugev näpunäide, seega peame kloonima.
            // Eelnevalt eraldage mälu, et kloonitud väärtus oleks võimalik otse kirjutada.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Eeltoodust piisab lõdvestumisest, sest see on põhimõtteliselt optimeerimine: me võistleme alati nõrkade näpunäidete välja viskamisega.
            // Halvimal juhul eraldame lõpuks uue kaare asjatult.
            //

            // Eemaldasime viimase tugeva viite, kuid järele on jäänud veel nõrku viiteid.
            // Teisaldame sisu uude kaaresse ja muudame nõrgad viited kehtetuks.
            //

            // Pange tähele, et `weak`-i lugemine ei võimalda usize::MAX-i (st lukustada), kuna nõrga loenduri saab lukustada ainult tugeva viitega lõime.
            //
            //

            // Realiseerige meie kaudne nõrk osuti, et see saaks vajadusel ArcInneri puhastada.
            //
            let _weak = Weak { ptr: this.ptr };

            // Saab lihtsalt andmeid varastada, jääb vaid Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Olime mõlemat liiki ainus referents;tõsta tugeva ref-loenduri üles.
            //
            this.inner().strong.store(1, Release);
        }

        // Nagu ka `get_mut()` puhul, on ka ohutus korras, sest meie viide oli kas alguses ainulaadne või muutus selliseks sisu kloonimisel.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Tagastab muudetava viite antud `Arc`-i, kui samale jaotusele pole muid `Arc`-või [`Weak`]-osutiid.
    ///
    ///
    /// Tagastab muul juhul [`None`], kuna jagatud väärtuse mutatsioon pole turvaline.
    ///
    /// Vaadake ka [`make_mut`][make_mut], mis muudab [`clone`][clone] sisemise väärtuse, kui on muid näpunäiteid.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // See ebaturvalisus on ok, kuna oleme tagatud, et tagastatud kursor on *ainus* osutaja, mis T-le kunagi tagastatakse.
            // Meie võrdlusloend on selles punktis garanteeritud 1 ja me eeldasime, et kaar ise oleks `mut`, nii et tagastame ainsate võimalike viidete sisemistele andmetele.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Tagastab muudetava viite antud `Arc`-sse ilma igasuguse kontrollita.
    ///
    /// Vaadake ka [`get_mut`]-i, mis on ohutu ja teeb asjakohaseid kontrolle.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Kõiki muid sama jaotusega `Arc` või [`Weak`] osutajaid ei tohi tagastatud laenu kestuse ajal välistada.
    ///
    /// See on triviaalne olukord, kui selliseid näpunäiteid pole olemas, näiteks kohe pärast `Arc::new`-i.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Oleme ettevaatlikud, et *mitte* luua "count"-i väljad hõlmavat viidet, kuna see muutuks varjunimeks koos samaaegse juurdepääsuga viidete loenditele
        // poolt `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Tehke kindlaks, kas see on ainulaadne viide (sh nõrgad viited) alusandmetele.
    ///
    ///
    /// Pange tähele, et see nõuab nõrkade ref-arvude lukustamist.
    fn is_unique(&mut self) -> bool {
        // lukustage nõrga osuti loend, kui näime olevat ainus nõrga kursori hoidja.
        //
        // Siin tagab hankimismärgis enne juhtumisi `strong`-i (eriti `Weak::upgrade`-i) kirjutamise enne `weak`-i arvu vähendamist (`Weak::drop`-i kaudu, mis kasutab vabastamist).
        // Kui täiendatud nõrk viide ei langenud kunagi, siis siinne CAS ebaõnnestub, nii et me ei hooli sünkroonimisest.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // See peab olema `Acquire`, et sünkroonida `drop`-i loenduri `strong` vähenemisega-see on ainus juurdepääs, mis juhtub siis, kui mõni muu kui viimane viide kaotatakse.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Siinne väljalaske kirjutamine sünkroonitakse `downgrade`-is lugemisega, takistades tõhusalt ülaltoodud `strong`-i lugemist pärast kirjutamist.
            //
            //
            self.inner().weak.store(1, Release); // vabastage lukk
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Laseb `Arc` i alla.
    ///
    /// See vähendab tugevat võrdlusarvu.
    /// Kui tugev võrdlusarv jõuab nulli, on ainsad muud viited (kui neid on) [`Weak`], seega sisemise väärtuse `drop`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Ei prindi midagi
    /// drop(foo2);   // Prindib "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Kuna `fetch_sub` on juba aatomiline, ei pea me teiste lõimedega sünkroonima, kui me ei kavatse objekti kustutada.
        // Sama loogika kehtib allpool `fetch_sub` `weak` loenduse kohta.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // See piirdeaed on vajalik andmete kasutamise ümberkorraldamise ja andmete kustutamise vältimiseks.
        // Kuna see on tähistatud `Release`, sünkroniseeritakse võrdlusarvu vähenemine selle `Acquire` aiaga.
        // See tähendab, et andmete kasutamine toimub enne võrdlusarvu vähendamist, mis juhtub enne seda piire, mis toimub enne andmete kustutamist.
        //
        // Nagu [Boost documentation][1]-is selgitatud,
        //
        // > Oluline on tagada objektile igasugune võimalik juurdepääs ühes
        // > lõim (olemasoleva viite kaudu), mis *juhtub enne* kustutamist
        // > objekti teises lõimes.See saavutatakse "release" abil
        // > toiming pärast viite (mis tahes juurdepääsu objektile) langetamist
        // > selle viite kaudu peab ilmselt enne juhtuma) ja
        // > "acquire" enne objekti kustutamist.
        //
        // Täpsemalt, kuigi kaare sisu on tavaliselt muutumatu, on võimalik, et interjöör kirjutab midagi sellist nagu Mutex<T>.
        // Kuna Mutexi kustutamisel ei omandata, ei saa me tugineda selle sünkroonimisloogikale, et muuta kirjutamine lõimes A nähtavaks lõimes B töötavale hävitajale.
        //
        //
        // Pange tähele ka seda, et siinse aia hankimise võiks tõenäoliselt asendada koormaga Omanda, mis võib parandada jõudlust väga vaieldavates olukordades.Vaadake [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Proovige `Arc<dyn Any + Send + Sync>` allalaadida konkreetsele tüübile.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Ehitab uue `Weak<T>` ilma mälu eraldamata.
    /// Tagasiväärtuse [`upgrade`] helistamine annab alati [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Abistaja tüüp, et võimaldada juurdepääs viitele loenditesse andmevälja kohta mingeid väiteid tegemata.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Tagastab toore kursori objektile `T`, millele see `Weak<T>` osutab.
    ///
    /// Kursor kehtib ainult siis, kui on tugevaid viiteid.
    /// Kursor võib olla rippuv, joondamata või muul juhul [`null`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Mõlemad osutavad samale objektile
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Siinsed tugevad hoiavad seda elus, nii et saame objektile siiski juurde pääseda.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Aga enam mitte.
    /// // Saame teha weak.as_ptr()-i, kuid osuti juurde pääsemine tooks kaasa määratlemata käitumise.
    /// // assert_eq! ("tere", ohtlik {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Kui kursor ripub, tagastame valvuri otse.
            // See ei saa olla kehtiv kasuliku aadressi aadress, kuna see on vähemalt sama joondatud kui ArcInner (usize).
            ptr as *const T
        } else {
            // OHUTUS: kui is_dangling tagastab vale, siis osutab kursor sellele.
            // Kandevõime võib sel hetkel langeda ja me peame säilitama päritolu, seega kasutage toore osutiga manipuleerimist.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Tarbib `Weak<T>`-i ja muudab selle tooreks osutiks.
    ///
    /// See muudab nõrga osuti toorpointeriks, säilitades siiski ühe nõrga viite omandiõiguse (nõrk loend seda toimingut ei muuda).
    /// Selle saab [`from_raw`]-iga tagasi `Weak<T>`-ks muuta.
    ///
    /// Kursori sihtmärgile juurdepääsemiseks kehtivad samad piirangud nagu [`as_ptr`] puhul.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Teisendab [`into_raw`] i varem loodud toore kursori `Weak<T>`-iks.
    ///
    /// Seda saab kasutada tugeva viite ohutuks saamiseks (helistades hiljem [`upgrade`]-ile) või nõrga loenduri jaotamiseks `Weak<T>`-i viskamisega.
    ///
    /// See võtab ühe nõrga viite omandiõiguse (välja arvatud [`new`] loodud näpunäited, kuna need ei oma midagi; meetod töötab neil endiselt).
    ///
    /// # Safety
    ///
    /// Kursor peab olema pärit [`into_raw`]-st ja sellel peab endiselt olema potentsiaalne nõrk viide.
    ///
    /// Selle helistamise ajal on lubatud tugev arv olla 0.
    /// Sellele vaatamata omandab see ühe nõrga viite, mida praegu kuvatakse toornäiturina (nõrka arvu see toiming ei muuda) ja seetõttu tuleb see siduda [`into_raw`]-i eelmise kõnega.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Vähenda viimast nõrka arvu.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Konteksti kohta Weak::as_ptr vaadake, kuidas sisendkursor tuletatakse.

        let ptr = if is_dangling(ptr as *mut T) {
            // See on rippuv nõrk.
            ptr as *mut ArcInner<T>
        } else {
            // Vastasel juhul on meile garanteeritud, et kursor pärineb ebaselgest nõrgast.
            // OHUTUS: data_offset on turvaline helistada, kuna ptr viitab reaalsele (potentsiaalselt langenud) T.
            let offset = unsafe { data_offset(ptr) };
            // Seega pöörame nihke ümber, et saada kogu RcBox.
            // OHUTUS: osuti pärineb nõrgast, nii et see nihe on ohutu.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // OHUTUS: oleme nüüd taastanud algse nõrga osuti, nii et saate luua nõrga.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Proovib `Weak`-i kursorit uuendada versiooniks [`Arc`], edukuse korral viivitab sisemise väärtuse langemine.
    ///
    ///
    /// Tagastab [`None`], kui sisemine väärtus on sellest ajast peale langenud.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Hävitage kõik tugevad näpunäited.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Tugeva arvu suurendamiseks kasutame fetch_add asemel CAS-tsüklit, kuna see funktsioon ei tohiks kunagi viia võrdlusarvu nullist üheni.
        //
        //
        let inner = self.inner()?;

        // Lõdvestunud koormus, sest mis tahes 0 tähe kirjutamine, mida saame jälgida, lahkub väljal püsivalt nullseisundis (seega on 0-ga "stale"-i lugemine korras) ja mis tahes muu väärtus kinnitatakse allpool oleva CAS-i kaudu.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Miks me seda teeme (`mem::forget`-i jaoks), vaadake `Arc::clone`-i kommentaare.
            if n > MAX_REFCOUNT {
                abort();
            }

            // Lõdvestunud on ebaõnnestumise juhtumi korral hea, sest meil pole uue riigi suhtes mingeid ootusi.
            // Omandamine on vajalik edukuse juhtumi sünkroonimiseks `Arc::new_cyclic`-iga, kui sisemise väärtuse saab lähtestada pärast seda, kui `Weak`-i viited on juba loodud.
            // Sel juhul eeldame, et järgime täielikult initsialiseeritud väärtust.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null kontrollitud ülal
                Err(old) => n = old,
            }
        }
    }

    /// Saab sellele jaotusele viitavate tugevate (`Arc`)-osutite arvu.
    ///
    /// Kui `self` loodi [`Weak::new`]-i kasutades, tagastatakse see 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Hõlmab sellele jaotusele osutavate `Weak`-osutite arvu ligikaudse arvu.
    ///
    /// Kui `self` loodi [`Weak::new`]-i abil või kui pole veel tugevaid näpunäiteid, tagastab see 0.
    ///
    /// # Accuracy
    ///
    /// Rakenduse üksikasjade tõttu saab tagastatava väärtuse 1 võrra välja lülitada kummaski suunas, kui teised lõimed manipuleerivad mis tahes kaarega või nõrkadega, mis osutavad samale jaotusele.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Kuna pärast nõrkade arvude lugemist täheldasime, et vähemalt üks tugev näpunäide oli olemas, teame, et kaudne nõrk viide (olemas alati, kui mõni tugev viide on elus) oli nõrga loenduse vaatlemisel endiselt umbes ja võime selle seetõttu ohutult lahutada.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Tagastab `None`, kui osuti ripub ja eraldatud `ArcInner` pole määratud (st kui `Weak` loodi `Weak::new` poolt).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Oleme ettevaatlikud, et mitte luua "data"-i välja hõlmavat viidet, kuna väli võib olla samaaegselt muteeritud (näiteks kui viimane `Arc`-st loobutakse, langetatakse andmeväli oma kohale).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Tagastab `true`, kui kaks "nõrka" osutavad samale jaotusele (sarnane [`ptr::eq`]-le) või kui mõlemad ei osuta mingile jaotusele (kuna need on loodud `Weak::new()`)-iga.
    ///
    ///
    /// # Notes
    ///
    /// Kuna see võrdleb näpunäiteid, tähendab see, et `Weak::new()` võrdub üksteisega, kuigi need ei viita mingile jaotusele.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Võrreldes `Weak::new`-i.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Valmistab `Weak`-i osuti klooni, mis osutab samale jaotusele.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Vaadake Arc::clone()-i kommentaare, miks see on lõdvestunud.
        // See võib kasutada fetch_add (lukku ignoreerides), kuna nõrk arv on lukustatud ainult seal, kus pole *ühtegi teist* nõrka osutit.
        //
        // (Nii et me ei saa sel juhul seda koodi käitada).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Miks me seda teeme (mem::forget-i jaoks), vaadake Arc::clone()-i kommentaare.
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Ehitab uue `Weak<T>` ilma mälu eraldamata.
    /// Tagasiväärtuse [`upgrade`] helistamine annab alati [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Viskab kursori `Weak` alla.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Ei prindi midagi
    /// drop(foo);        // Prindib "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Kui saame teada, et olime viimane nõrk näitaja, siis on aeg andmed täielikult hajutada.Vaadake Arc::drop()-is arutelu mälu järjestuste kohta
        //
        // Siin ei ole vaja kontrollida lukustatud olekut, sest nõrga loenduri saab lukustada ainult siis, kui oli täpselt üks nõrk viide, see tähendab, et tilk sai alles siis järelejäänud nõrga viite käivitada, mis saab juhtuda alles pärast luku vabastamist.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Teeme seda spetsialiseerumist siin ja mitte `&T`-i üldisema optimeerimisena, sest vastasel juhul lisaks see kõikidele võrdluskontrollidele viiteid.
/// Eeldame, et `Arc'e kasutatakse suurte väärtuste salvestamiseks, mis on aeglaselt kloonitavad, kuid on ka rasked võrdsuse kontrollimiseks, mistõttu see kulu tasub end kergemini ära.
///
/// Samuti on tõenäolisem, et neil on kaks `Arc` klooni, mis osutavad samale väärtusele, kui kaks&T-d.
///
/// Saame seda teha ainult siis, kui `T: Eq` kui `PartialEq` võib olla tahtlikult refleksiivne.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Kahe kaare võrdsus.
    ///
    /// Kaks kaare on võrdsed, kui nende sisemised väärtused on võrdsed, isegi kui need on salvestatud erinevas jaotuses.
    ///
    /// Kui `T` rakendab ka `Eq` (mis viitab võrdsuse refleksiivsusele), on kaks samale jaotusele osutavat kaare alati võrdsed.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Kahe kaare ebavõrdsus.
    ///
    /// Kaks kaari on ebavõrdsed, kui nende sisemised väärtused on ebavõrdsed.
    ///
    /// Kui `T` rakendab ka `Eq` (mis viitab võrdsuse refleksiivsusele), pole kaks samale väärtusele viitavat kaare kunagi ebavõrdsed.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Osaline kahe kaare võrdlus.
    ///
    /// Neid kahte võrreldakse, nimetades `partial_cmp()` nende sisemisteks väärtusteks.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Vähem kui kahe kaare võrdlus.
    ///
    /// Neid kahte võrreldakse, nimetades `<` nende sisemisteks väärtusteks.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Kahe kaare võrdlus "vähem kui või võrdne".
    ///
    /// Neid kahte võrreldakse, nimetades `<=` nende sisemisteks väärtusteks.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Suurem kui kahe kaare võrdlus.
    ///
    /// Neid kahte võrreldakse, nimetades `>` nende sisemisteks väärtusteks.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Kahe kaare võrdlus "Suurem või võrdne".
    ///
    /// Neid kahte võrreldakse, nimetades `>=` nende sisemisteks väärtusteks.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Kahe kaare võrdlus.
    ///
    /// Neid kahte võrreldakse, nimetades `cmp()` nende sisemisteks väärtusteks.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Loob uue `Arc<T>` koos X0 `Default` väärtusega `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Määrake viitega loendatud viil ja täitke see kloonides `v`-i üksused.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Määrake viitega loendatud `str` ja kopeerige `v` sinna.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Määrake viitega loendatud `str` ja kopeerige `v` sinna.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Teisaldage kastiga objekt uuele, viidetega loendatud jaotusele.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Määrake viitega loendatud viil ja teisaldage `v`-i elemendid sinna.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Lubage Vecil mälu vabastada, kuid mitte selle sisu hävitada
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Võtab kõik elemendid `Iterator`-is ja koguvad need `Arc<[T]>`-i.
    ///
    /// # Jõudlusnäitajad
    ///
    /// ## Üldine juhtum
    ///
    /// Üldiselt toimub `Arc<[T]>`-i kogumine kõigepealt `Vec<T>`-i.See tähendab, et kirjutades järgmist:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// see käitub nii, nagu oleksime kirjutanud:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Esimene eraldiste kogum toimub siin.
    ///     .into(); // Siin toimub teine eraldamine `Arc<[T]>`-le.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// See eraldab `Vec<T>`-i konstrueerimiseks nii palju kordi kui vaja ja seejärel eraldatakse üks kord `Vec<T>`-i muutmiseks `Arc<[T]>`-iks.
    ///
    ///
    /// ## Tuntud pikkusega iteraatorid
    ///
    /// Kui teie `Iterator` rakendab `TrustedLen`-i ja on täpse suurusega, tehakse `Arc<[T]>`-ile üks eraldis.Näiteks:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Siin juhtub ainult üks eraldis.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Spetsialiseerumine trait, mida kasutatakse `Arc<[T]>`-i kogumiseks.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // See kehtib `TrustedLen` iteraatori puhul.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // OHUTUS: Peame tagama, et iteraatoril on täpne pikkus ja meil on.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Tagasi tavapärase rakendamise juurde.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Kursori taga oleva kasuliku koormuse jaoks saate nihke `ArcInner`-i piires.
///
/// # Safety
///
/// Kursor peab osutama T kehtivale eksemplarile (ja sellel peavad olema kehtivad metaandmed), kuid T on lubatud loobuda.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Joondage suuruse väärtus ArcInneri lõpuni.
    // Kuna RcBox on repr(C), on see alati viimane väli mälus.
    // OHUTUS: kuna ainsad võimalikud mõõtmeteta tüübid on viilud, objektid trait,
    // ja väliste tüüpide korral on sisendi ohutuse nõue praegu piisav align_of_val_raw nõuete täitmiseks;see on keele rakendusdetail, millele ei saa tugineda väljaspool std-i.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}