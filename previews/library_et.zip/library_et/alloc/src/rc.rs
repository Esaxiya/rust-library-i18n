//! Ühe keermega viite loendamise näpunäited.'Rc' tähistab viidet
//! Counted'.
//!
//! Tüüp [`Rc<T>`][`Rc`] tagab hunnikus eraldatud `T` tüüpi väärtuse jagatud omandiõiguse.
//! [`clone`][clone]-i kutsumine [`Rc`]-is loob kuhja samale jaotusele uue osuti.
//! Kui konkreetse eraldise viimane [`Rc`]-osuti hävitatakse, langeb ka sellesse jaotusse salvestatud väärtus (sageli nimetatud kui "inner value").
//!
//! Rust-i jagatud viited keelavad mutatsiooni vaikimisi ja [`Rc`] pole erand: üldiselt ei saa muudetavat viidet [`Rc`]-i sisemusele.
//! Kui vajate muutlikkust, pange [`Rc`] sisse [`Cell`] või [`RefCell`];vaadake [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] kasutab mitteaatomilist võrdlusloendust.
//! See tähendab, et üldkulud on väga madalad, kuid [`Rc`]-i ei saa lõimede vahel saata ja seetõttu ei rakenda [`Rc`] [`Send`][send]-i.
//! Selle tulemusena kontrollib Rust kompilaator *kompileerimise ajal*, et te ei saadaks lõimede vahel [`Rc`].
//! Kui vajate mitmekordset aatomi võrdlusloendust, kasutage [`sync::Arc`][arc]-i.
//!
//! [`downgrade`][downgrade]-meetodi abil saab luua mitteomava [`Weak`]-osuti.
//! [`Weak`]-i osuti võib olla [`upgrade '][upgrade] d kuni [`Rc`], kuid see tagastab [`None`], kui jaotusse salvestatud väärtus on juba langenud.
//! Teisisõnu, `Weak`-i osutajad ei hoia jaotuses olevat väärtust elus;aga nad hoiavad eraldamist (sisemise väärtuse tagavarahoidlat) elus.
//!
//! [`Rc`]-osuti vahelist tsüklit ei jagata kunagi.
//! Sel põhjusel kasutatakse [`Weak`]-i tsüklite katkestamiseks.
//! Näiteks võiks puul olla tugevad [`Rc`]-i näpunäited vanemate sõlmedest lastele ja [`Weak`]-i näpunäited lastelt nende vanemate juurde.
//!
//! `Rc<T>` automaatselt viited `T`-le ([`Deref`] trait kaudu), nii et saate helistada `T` meetoditele väärtusega [`Rc<T>`][`Rc`].
//! Nime kokkupõrgete vältimiseks `T` meetoditega on [`Rc<T>`][`Rc`] meetodid ise seotud funktsioonid, mida nimetatakse [fully qualified syntax] abil:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>traits-i rakendusi nagu `Clone` võib kutsuda ka täielikult kvalifitseeritud süntaksiga.
//! Mõned inimesed eelistavad kasutada täielikult kvalifitseeritud süntaksi, teised aga meetodi-kõne süntaksit.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Meetodi-kõne süntaks
//! let rc2 = rc.clone();
//! // Täielikult kvalifitseeritud süntaks
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] ei tee `T`-le automaatselt allahindlust, kuna sisemine väärtus võib olla juba langenud.
//!
//! # Kloonimise viited
//!
//! Uue viite loomine samale jaotusele kui olemasolev viite loendatud osuti, kasutatakse [`Rc<T>`][`Rc`] ja [`Weak<T>`][`Weak`] jaoks rakendatud `Clone` trait.
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Kaks allpool toodud süntaksit on samaväärsed.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a ja b osutavad mõlemad samale mälupunktile nagu foo.
//! ```
//!
//! `Rc::clone(&from)`-i süntaks on kõige idioomaatilisem, kuna see annab koodi täpsema tähenduse edasi.
//! Ülaltoodud näites on selle süntaksiga hõlpsam näha, et see kood loob uue viite, mitte kogu foo sisu kopeerimise.
//!
//! # Examples
//!
//! Mõelgem stsenaariumile, kus `Gadget`ide komplekt kuulub antud `Owner`-le.
//! Me tahame, et meie vidin näitaks nende `Owner`-i.Me ei saa seda teha ainulaadse omandilise kuuluvusega, sest samale `Owner`-ile võib kuuluda rohkem kui üks vidin.
//! [`Rc`] võimaldab meil jagada `Owner`-i mitme vidina vahel ja lasta `Owner`-i eraldada seni, kuni sellel on `Gadget`-punkte.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... muud väljad
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... muud väljad
//! }
//!
//! fn main() {
//!     // Looge viitega loendatud `Owner`.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Looge `gadget_owner`-i kuuluvad vidinad.
//!     // `Rc<Owner>` kloonimine annab meile uue osuti samale `Owner` jaotusele, suurendades protsessis viidete arvu.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Kõrvaldage meie kohalik muutuja `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Vaatamata `gadget_owner`-i langemisele suudame ikkagi välja printida `Vidina` `Owner`-i nime.
//!     // Selle põhjuseks on asjaolu, et oleme maha lasknud ainult ühe `Rc<Owner>`-i, mitte `Owner`-i, millele see osutab.
//!     // Niikaua kui samal `Owner` jaotusel on muid `Rc<Owner>`-i osutavaid punkte, jääb see aktiivseks.
//!     // Väliprojektsioon `gadget1.owner.name` töötab, kuna `Rc<Owner>` viitab automaatselt `Owner`-le.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Funktsiooni lõpus hävitatakse `gadget1` ja `gadget2` ning koos nendega loendatakse viimased viited meie `Owner`-ile.
//!     // Vidinamees hävitatakse nüüd ka.
//!     //
//! }
//! ```
//!
//! Kui meie nõuded muutuvad ja peame suutma ka `Owner`-lt `Gadget`-le liikuda, satume probleemidesse.
//! [`Rc`] kursor `Owner` kuni `Gadget` tutvustab tsüklit.
//! See tähendab, et nende võrdlusarvud ei saa kunagi jõuda 0-ni ja jaotust ei hävitata kunagi:
//! mäluleke.Sellest pääsemiseks saame kasutada [`Weak`]-i näpunäiteid.
//!
//! Rust muudab selle silmuse tootmise tegelikult mõnevõrra keeruliseks.Selleks, et saada kaks teineteisele suunatud väärtust, peab üks neist olema muudetav.
//! See on keeruline, sest [`Rc`] tagab mälu turvalisuse, jagades ainult jagatud viiteid ümbritsevale väärtusele ja need ei võimalda otsest mutatsiooni.
//! Me peame mähkima selle väärtuse osa [`RefCell`]-i, mis pakub *sisemuutuvust*: meetodi abil ühildatava viite abil muutlikkus.
//! [`RefCell`] jõustab Rust laenureegleid käitamise ajal.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... muud väljad
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... muud väljad
//! }
//!
//! fn main() {
//!     // Looge viitega loendatud `Owner`.
//!     // Pange tähele, et oleme paigutanud seadme "Vidin" omaniku vector `RefCell`-i sisse, et saaksime seda jagatud viite kaudu mutateerida.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Looge `gadget_owner`-i kuuluvad vidinad nagu ikka.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Lisage vidin nende `Owner`-i.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` dünaamiline laen lõpeb siin.
//!     }
//!
//!     // Kordage meie vidinaid, printides nende üksikasjad välja.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` on `Weak<Gadget>`.
//!         // Kuna `Weak`-osutid ei saa garanteerida, et jaotamine on endiselt olemas, peame helistama `upgrade`-le, mis tagastab `Option<Rc<Gadget>>`-i.
//!         //
//!         //
//!         // Sel juhul teame, et eraldamine on endiselt olemas, nii et me lihtsalt `unwrap` `Option`.
//!         // Keerulisemas programmis võib `None` tulemuse jaoks vajada graatsilist tõrkeotsingut.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Funktsiooni lõpus hävitatakse `gadget_owner`, `gadget1` ja `gadget2`.
//!     // Nüüd pole vidinate jaoks tugevaid (`Rc`)-i viiteid, nii et need hävitatakse.
//!     // See nullib vidinamehe võrdlusarvu, nii et ka tema hävitatakse.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// See on repr(C) kuni future kindel võimalike väljade ümberkorralduste vastu, mis häiriks muidu muudetavate sisetüüpide muidu ohutut [into|from]_raw()-i.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Ühe keermega viite loendamise osuti.'Rc' tähistab viidet
/// Counted'.
///
/// Lisateavet leiate [module-level documentation](./index.html)-st.
///
/// `Rc`-i omased meetodid on kõik seotud funktsioonid, mis tähendab, et peate neid kutsuma näiteks [`Rc::get_mut(&mut value)`][get_mut]-i, mitte `value.get_mut()`-i.
/// See väldib konflikte sisetüübi `T` meetoditega.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // See ebaturvalisus on ok, sest sel ajal, kui see Rc on elus, tagame sisemise osuti kehtivuse.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Ehitab uue `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Kõigile tugevatele näpunäidetele kuulub kaudne nõrk osuti, mis tagab, et nõrk hävitaja ei vabasta jaotust tugeva hävitaja töötamise ajal, isegi kui nõrk osuti on salvestatud tugeva sisemusse.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Ehitab uue `Rc<T>`, kasutades nõrka viidet iseendale.
    /// Nõrga viite värskendamise katse enne selle funktsiooni taastamist annab `None` väärtuse.
    ///
    /// Nõrgat lähteainet võib siiski vabalt kloonida ja säilitada kasutamiseks hiljem.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... veel väljad
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Ehitage sisemine olek "uninitialized" ühe nõrga referentsiga.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Tähtis on, et me ei loobuks nõrga osuti omamisest, muidu võib mälu vabaneda selleks ajaks, kui `data_fn` naaseb.
        // Kui me tõesti sooviksime omandiõiguse üle anda, võiksime luua endale täiendava nõrga kursori, kuid see tooks kaasa nõrkade võrdlusarvude täiendavaid värskendusi, mis muidu poleks võib-olla vajalikud.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Tugevatele viidetele peaksid ühiselt kuuluma jagatud nõrk viide, nii et ärge käivitage meie vana nõrga viite hävitajat.
        //
        mem::forget(weak);
        strong
    }

    /// Ehitab uue initsialiseerimata sisuga `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Edasilükatud lähtestamine:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Ehitab uue initsialiseerimata sisuga `Rc`, kusjuures mälu on täidetud `0`-baitidega.
    ///
    ///
    /// Selle meetodi õige ja vale kasutamise näiteid leiate jaotisest [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Ehitab uue `Rc<T>`, tagastades tõrke, kui jaotamine ebaõnnestub
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Kõigile tugevatele näpunäidetele kuulub kaudne nõrk osuti, mis tagab, et nõrk hävitaja ei vabasta jaotust tugeva hävitaja töötamise ajal, isegi kui nõrk osuti on salvestatud tugeva sisemusse.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Ehitab uue initsialiseerimata sisuga `Rc`, tagastades tõrke, kui jaotamine ebaõnnestub
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Edasilükatud lähtestamine:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Ehitab uue initsialiseerimata sisuga `Rc`, kusjuures mälu on täidetud `0`-baitidega, tagastades tõrke, kui jaotamine ebaõnnestub
    ///
    ///
    /// Selle meetodi õige ja vale kasutamise näiteid leiate jaotisest [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Ehitab uue `Pin<Rc<T>>`.
    /// Kui `T` ei rakenda `Unpin`-i, kinnitatakse `value` mällu ja seda ei saa teisaldada.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Tagastab sisemise väärtuse, kui `Rc`-l on täpselt üks tugev viide.
    ///
    /// Vastasel juhul tagastatakse [`Err`] sama `Rc`-iga, mis edastati.
    ///
    ///
    /// See õnnestub ka siis, kui on silmapaistvaid nõrku viiteid.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // kopeerige sisalduv objekt

                // Märkige Weaksile, et tugevat arvu vähendades ei saa neid reklaamida, ja seejärel eemaldage kaudne "strong weak"-osuti, käsitledes samal ajal ka tilkade loogikat, meisterdades lihtsalt võltsnõrga.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Ehitab uue initsialiseerimata sisuga viitega loendatud viilu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Edasilükatud lähtestamine:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Ehitab uue initsialiseerimata sisuga viitega loendatud viilu, kusjuures mälu on täidetud `0`-baitidega.
    ///
    ///
    /// Selle meetodi õige ja vale kasutamise näiteid leiate jaotisest [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Teisendab `Rc<T>`-ks.
    ///
    /// # Safety
    ///
    /// Nagu [`MaybeUninit::assume_init`] puhul, on ka helistaja ülesanne garanteerida, et sisemine väärtus on tõesti lähtestatud olekus.
    ///
    /// Sellele helistamine, kui sisu pole veel täielikult vormistatud, põhjustab kohest määratlemata käitumist.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Edasilükatud lähtestamine:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Teisendab `Rc<[T]>`-ks.
    ///
    /// # Safety
    ///
    /// Nagu [`MaybeUninit::assume_init`] puhul, on ka helistaja ülesanne garanteerida, et sisemine väärtus on tõesti lähtestatud olekus.
    ///
    /// Sellele helistamine, kui sisu pole veel täielikult vormistatud, põhjustab kohest määratlemata käitumist.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Edasilükatud lähtestamine:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Tarbib `Rc`-i, tagastades pakitud osuti.
    ///
    /// Mälulekke vältimiseks tuleb osuti [`Rc::from_raw`][from_raw] abil teisendada `Rc`-ks.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Annab andmetele toore kursori.
    ///
    /// Loendeid ei mõjuta see mingil viisil ja `Rc`-i ei tarbita.
    /// Kursor kehtib seni, kuni `Rc`-is on tugevad loendused.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // OHUTUS: Seda ei saa läbi viia Deref::deref ega Rc::inner, sest
        // see on vajalik raw/mut päritolu säilitamiseks nii, et nt
        // `get_mut` saab osuti kirjutada pärast Rc taastamist `from_raw` kaudu.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Ehitab `Rc<T>` töötlemata kursori järgi.
    ///
    /// Toores osuti peab olema varem tagasi saadetud kutsega [`Rc<U>::into_raw`][into_raw], kus `U` peab olema sama suur ja joondatud kui `T`.
    /// See on triviaalselt tõsi, kui `U` on `T`.
    /// Pange tähele, et kui `U` ei ole `T`, kuid sellel on sama suurus ja joondus, on see põhimõtteliselt nagu eri tüüpi viidete transmutamine.
    /// Lisateavet selle kohta kehtivate piirangute kohta leiate jaotisest [`mem::transmute`][transmute].
    ///
    /// `from_raw`-i kasutaja peab veenduma, et `T`-i konkreetne väärtus langetatakse ainult üks kord.
    ///
    /// See funktsioon on ohtlik, kuna ebaõige kasutamine võib põhjustada mälu ebaturvalisuse isegi siis, kui tagastatud `Rc<T>`-i kunagi juurde ei pääse.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Lekke vältimiseks teisendage tagasi `Rc`-ks.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Edasised kõned `Rc::from_raw(x_ptr)`-ile oleksid mäluohtlikud.
    /// }
    ///
    /// // Mälu vabastati, kui `x` ülaltoodud reguleerimisalast välja läks, nii et `x_ptr` ripub nüüd!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Algse RcBoxi leidmiseks pöörake nihe tagasi.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Loob sellele eraldisele uue [`Weak`]-i kursori.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Veenduge, et me ei loo rippuvat nõrka
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Sellele jaotusele saab [`Weak`]-i osutajate arvu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Hangi selle jaotuse jaoks tugevate (`Rc`)-osutite arv.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Tagastab `true`, kui sellele jaotusele pole muid `Rc` või [`Weak`] osutajaid.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Tagastab muudetava viite antud `Rc`-i, kui samale jaotusele pole muid `Rc`-või [`Weak`]-osutiid.
    ///
    ///
    /// Tagastab muul juhul [`None`], kuna jagatud väärtuse mutatsioon pole turvaline.
    ///
    /// Vaadake ka [`make_mut`][make_mut], mis muudab [`clone`][clone] sisemise väärtuse, kui on muid näpunäiteid.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Tagastab muudetava viite antud `Rc`-sse ilma igasuguse kontrollita.
    ///
    /// Vaadake ka [`get_mut`]-i, mis on ohutu ja teeb asjakohaseid kontrolle.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Kõiki muid sama jaotusega `Rc` või [`Weak`] osutajaid ei tohi tagastatud laenu kestuse ajal välistada.
    ///
    /// See on triviaalne olukord, kui selliseid näpunäiteid pole olemas, näiteks kohe pärast `Rc::new`-i.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Oleme ettevaatlikud, et mitte luua "count" väljad hõlmavat viidet, kuna see oleks vastuolus juurdepääsuga viitenumbritele (nt
        // poolt `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Tagastab `true`, kui kaks Rc osutavad samale jaotusele ([`ptr::eq`]-ga sarnases veenis).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Annab muudetava viite antud `Rc`-le.
    ///
    /// Kui samal jaotusel on muid `Rc`-i osutajaid, siis `make_mut` muudab [`clone`]-i uue eraldise sisemise väärtuse, et tagada ainulaadne omandiline kuuluvus.
    /// Seda nimetatakse ka kloon-kirjutamiseks.
    ///
    /// Kui selle jaotuse jaoks pole muid `Rc`-i osutajaid, siis eraldatakse selle jaotuse [`Weak`]-i osutajad.
    ///
    /// Vaadake ka [`get_mut`]-i, mis kloonimise asemel ebaõnnestub.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Ei klooni midagi
    /// let mut other_data = Rc::clone(&data);    // Ei klooni sisemisi andmeid
    /// *Rc::make_mut(&mut data) += 1;        // Kloonib sisemised andmed
    /// *Rc::make_mut(&mut data) += 1;        // Ei klooni midagi
    /// *Rc::make_mut(&mut other_data) *= 2;  // Ei klooni midagi
    ///
    /// // Nüüd osutavad `data` ja `other_data` erinevatele jaotustele.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] viited eraldatakse:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Pead andmed kloonima, on ka teisi Rcs-sid.
            // Eelnevalt eraldage mälu, et kloonitud väärtus oleks võimalik otse kirjutada.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Saab lihtsalt andmeid varastada, jääb vaid Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Eemaldage kaudne tugev-nõrk viide (siin pole vaja võltsitud nõrka meisterdada-me teame, et teised Weakid saavad meie jaoks puhastada)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // See ebaturvalisus on ok, kuna oleme tagatud, et tagastatud kursor on *ainus* osutaja, mis T-le kunagi tagastatakse.
        // Meie võrdlusarv on selles punktis garanteeritud 1 ja me nõudsime, et `Rc<T>` ise oleks `mut`, seega tagastame ainsa võimaliku viite jaotusele.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Proovige `Rc<dyn Any>` allalaadida konkreetsele tüübile.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Määrab `RcBox<T>`-i, kus on piisavalt ruumi võimaliku suuruse sisemise väärtuse jaoks, kui väärtusel on paigutus.
    ///
    /// Funktsioonile `mem_to_rcbox` kutsutakse andmekursoriga ja see peab `RcBox<T>`-i jaoks tagastama (potentsiaalselt rasv) osutaja.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Arvutage paigutus, kasutades antud väärtuse paigutust.
        // Varem arvutati paigutus avaldisele `&*(ptr as* const RcBox<T>)`, kuid see lõi valesti joondatud viite (vt #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Määrab `RcBox<T>`-i, kus on piisavalt ruumi võimaliku suuruse sisemise väärtuse jaoks, kui väärtusel on paigutus, tagastades vea, kui jaotamine ebaõnnestub.
    ///
    ///
    /// Funktsioonile `mem_to_rcbox` kutsutakse andmekursoriga ja see peab `RcBox<T>`-i jaoks tagastama (potentsiaalselt rasv) osutaja.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Arvutage paigutus, kasutades antud väärtuse paigutust.
        // Varem arvutati paigutus avaldisele `&*(ptr as* const RcBox<T>)`, kuid see lõi valesti joondatud viite (vt #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Eraldage paigutus.
        let ptr = allocate(layout)?;

        // Alustage RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Eraldab `RcBox<T>`, millel on piisavalt ruumi suuruse sisemise väärtuse jaoks
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // `RcBox<T>` jaoks eraldage antud väärtus.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopeeri väärtus baitidena
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Tasuta eraldamine selle sisu ära viskamata
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Määrab `RcBox<[T]>` etteantud pikkusega.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Kopeerige elemendid lõigust äsja eraldatud Rc-sse <\[T\]>
    ///
    /// Ohtlik, kuna helistaja peab kas omandama `T: Copy`-i või siduma selle
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Ehitab `Rc<[T]>`-i iteraatorist, mis on teadaolevalt teatud suurusega.
    ///
    /// Käitumine on määratlemata, kui suurus oleks vale.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic valvur T-elementide kloonimise ajal.
        // panic korral loobuvad uude RcBoxi kirjutatud elemendid ja seejärel vabastatakse mälu.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Esimese elemendi kursor
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Kõik selge.Unustage valvur, et see ei vabastaks uut RcBoxi.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` jaoks kasutatakse spetsialiseerumist trait.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Laseb `Rc` i alla.
    ///
    /// See vähendab tugevat võrdlusarvu.
    /// Kui tugev võrdlusarv jõuab nulli, on ainsad muud viited (kui neid on) [`Weak`], seega sisemise väärtuse `drop`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Ei prindi midagi
    /// drop(foo2);   // Prindib "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // hävitada suletud ese
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // eemaldage kaudne "strong weak"-osuti nüüd, kui oleme sisu hävitanud.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Valmistab `Rc`-i osuti klooni.
    ///
    /// Nii luuakse teine osutus samale jaotusele, suurendades tugevat võrdlusarvu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Loob uue `Rc<T>` koos X0 `Default` väärtusega `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Häkkige, et lubada `Eq`-ile spetsialiseerumist, kuigi `Eq`-l on meetod.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Teeme seda spetsialiseerumist siin ja mitte `&T`-i üldisema optimeerimisena, sest vastasel juhul lisaks see kõikidele võrdluskontrollidele viiteid.
/// Eeldame, et Rc-sid kasutatakse suurte väärtuste salvestamiseks, mis on aeglaselt kloonitavad, kuid on ka rasked võrdsuse kontrollimiseks, mistõttu see kulu tasub end kergemini.
///
/// Samuti on tõenäolisem, et neil on kaks `Rc` klooni, mis osutavad samale väärtusele, kui kaks&T-d.
///
/// Saame seda teha ainult siis, kui `T: Eq` kui `PartialEq` võib olla tahtlikult refleksiivne.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Kahe Rc võrdsus.
    ///
    /// Kaks Rc on võrdsed, kui nende sisemised väärtused on võrdsed, isegi kui neid hoitakse erinevas jaotuses.
    ///
    /// Kui `T` rakendab ka `Eq` (mis viitab võrdsuse refleksiivsusele), on kaks samale jaotusele osutavat "Rc" alati võrdsed.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Kahe "Rc" ebavõrdsus.
    ///
    /// Kaks Rc-d on ebavõrdsed, kui nende sisemised väärtused on ebavõrdsed.
    ///
    /// Kui `T` rakendab ka `Eq` (mis viitab võrdsuse refleksiivsusele), pole kaks samale jaotusele osutavat "Rc" kunagi ebavõrdsed.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Kahe "Rc" osaline võrdlus.
    ///
    /// Neid kahte võrreldakse, nimetades `partial_cmp()` nende sisemisteks väärtusteks.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Vähem kui kahe Rc võrdlus.
    ///
    /// Neid kahte võrreldakse, nimetades `<` nende sisemisteks väärtusteks.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// "Vähem või võrdne" kahe Rc võrdlusega.
    ///
    /// Neid kahte võrreldakse, nimetades `<=` nende sisemisteks väärtusteks.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Suurem kui kahe Rc võrdlus.
    ///
    /// Neid kahte võrreldakse, nimetades `>` nende sisemisteks väärtusteks.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// "Suurem või võrdne" võrdlus kahe "Rc" jaoks.
    ///
    /// Neid kahte võrreldakse, nimetades `>=` nende sisemisteks väärtusteks.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Kahe "Rc" võrdlus.
    ///
    /// Neid kahte võrreldakse, nimetades `cmp()` nende sisemisteks väärtusteks.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Määrake viitega loendatud viil ja täitke see kloonides `v`-i üksused.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Määrake viitega loendatud stringilõik ja kopeerige sinna `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Määrake viitega loendatud stringilõik ja kopeerige sinna `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Teisaldage kastiga objekt uuele, viidetega loendatud eraldisele.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Määrake viitega loendatud viil ja teisaldage `v`-i elemendid sinna.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Lubage Vecil mälu vabastada, kuid mitte selle sisu hävitada
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Võtab kõik elemendid `Iterator`-is ja koguvad need `Rc<[T]>`-i.
    ///
    /// # Jõudlusnäitajad
    ///
    /// ## Üldine juhtum
    ///
    /// Üldiselt toimub `Rc<[T]>`-i kogumine kõigepealt `Vec<T>`-i.See tähendab, et kirjutades järgmist:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// see käitub nii, nagu oleksime kirjutanud:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Esimene eraldiste kogum toimub siin.
    ///     .into(); // Siin toimub teine eraldamine `Rc<[T]>`-le.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// See eraldab `Vec<T>`-i konstrueerimiseks nii palju kordi kui vaja ja seejärel eraldatakse üks kord `Vec<T>`-i muutmiseks `Rc<[T]>`-iks.
    ///
    ///
    /// ## Tuntud pikkusega iteraatorid
    ///
    /// Kui teie `Iterator` rakendab `TrustedLen`-i ja on täpse suurusega, tehakse `Rc<[T]>`-ile üks eraldis.Näiteks:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Siin juhtub ainult üks eraldis.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Spetsialiseerumine trait, mida kasutatakse `Rc<[T]>`-i kogumiseks.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // See kehtib `TrustedLen` iteraatori puhul.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // OHUTUS: Peame tagama, et iteraatoril on täpne pikkus ja meil on.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Tagasi tavapärase rakendamise juurde.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` on [`Rc`]-i versioon, millel on hallatavale jaotusele mitteomandav viide.Jaotusele pääseb ligi, helistades `Weak`-i osuti [`upgrade`]-le, mis tagastab valiku ["Option"] <"[" Rc "]"<T>> ".
///
/// Kuna `Weak` viide ei loe omandilise kuuluvuse hulka, ei takista see jaotuses salvestatud väärtuse langemist ja `Weak` ise ei garanteeri, et väärtus on endiselt olemas.
/// Seega võib see [`None`]-i tagastada, kui ["uuendada"] d.
/// Pange tähele, et `Weak` viide * ei takista jaotuse enda (tugipoe) jaotamist.
///
/// `Weak`-osuti on kasulik ajutise viite säilitamiseks jaotusele, mida haldab [`Rc`], takistamata selle sisemise väärtuse langemist.
/// Seda kasutatakse ka [`Rc`]-osuti vaheliste ümmarguste viidete vältimiseks, kuna vastastikuse omamise viited ei võimaldaks kunagi kumbagi [`Rc`]-st loobuda.
/// Näiteks võiks puul olla tugevad [`Rc`]-i näpunäited vanemate sõlmedest lastele ja `Weak`-i näpunäited lastelt nende vanemate juurde.
///
/// Tüüpiline viis `Weak`-osuti saamiseks on helistada numbrile [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // See on `NonNull`, mis võimaldab selle tüübi suurust loendites optimeerida, kuid see pole tingimata kehtiv osut.
    //
    // `Weak::new` määrab selle väärtuseks `usize::MAX`, et see ei peaks hunnikule ruumi eraldama.
    // See pole väärtus, mida tõeline osuti kunagi saab, kuna RcBoxil on joondatud vähemalt 2.
    // See on võimalik ainult siis, kui `T: Sized`;suurusega `T` ei rippu kunagi.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Ehitab uue `Weak<T>` ilma mälu eraldamata.
    /// Tagasiväärtuse [`upgrade`] helistamine annab alati [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Abistaja tüüp, et võimaldada juurdepääs viitele loenditesse andmevälja kohta mingeid väiteid tegemata.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Tagastab toore kursori objektile `T`, millele see `Weak<T>` osutab.
    ///
    /// Kursor kehtib ainult siis, kui on tugevaid viiteid.
    /// Kursor võib olla rippuv, joondamata või muul juhul [`null`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Mõlemad osutavad samale objektile
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Siinsed tugevad hoiavad seda elus, nii et saame objektile siiski juurde pääseda.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Aga enam mitte.
    /// // Saame teha weak.as_ptr()-i, kuid osuti juurde pääsemine tooks kaasa määratlemata käitumise.
    /// // assert_eq! ("tere", ohtlik {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Kui kursor ripub, tagastame valvuri otse.
            // See ei saa olla kehtiv kasuliku aadressi aadress, kuna kasulik koormus on vähemalt sama joondatud kui RcBox (usize).
            ptr as *const T
        } else {
            // OHUTUS: kui is_dangling tagastab vale, siis osutab kursor sellele.
            // Kandevõime võib sel hetkel langeda ja me peame säilitama päritolu, seega kasutage toore osutiga manipuleerimist.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Tarbib `Weak<T>`-i ja muudab selle tooreks osutiks.
    ///
    /// See muudab nõrga osuti toorpointeriks, säilitades siiski ühe nõrga viite omandiõiguse (nõrk loend seda toimingut ei muuda).
    /// Selle saab [`from_raw`]-iga tagasi `Weak<T>`-ks muuta.
    ///
    /// Kursori sihtmärgile juurdepääsemiseks kehtivad samad piirangud nagu [`as_ptr`] puhul.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Teisendab [`into_raw`] i varem loodud toore kursori `Weak<T>`-iks.
    ///
    /// Seda saab kasutada tugeva viite ohutuks saamiseks (helistades hiljem [`upgrade`]-ile) või nõrga loenduri jaotamiseks `Weak<T>`-i viskamisega.
    ///
    /// See võtab ühe nõrga viite omandiõiguse (välja arvatud [`new`] loodud näpunäited, kuna need ei oma midagi; meetod töötab neil endiselt).
    ///
    /// # Safety
    ///
    /// Kursor peab olema pärit [`into_raw`]-st ja sellel peab endiselt olema potentsiaalne nõrk viide.
    ///
    /// Selle helistamise ajal on lubatud tugev arv olla 0.
    /// Sellele vaatamata omandab see ühe nõrga viite, mida praegu kuvatakse toornäiturina (nõrka arvu see toiming ei muuda) ja seetõttu tuleb see siduda [`into_raw`]-i eelmise kõnega.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Vähenda viimast nõrka arvu.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Konteksti kohta Weak::as_ptr vaadake, kuidas sisendkursor tuletatakse.

        let ptr = if is_dangling(ptr as *mut T) {
            // See on rippuv nõrk.
            ptr as *mut RcBox<T>
        } else {
            // Vastasel juhul on meile garanteeritud, et kursor pärineb ebaselgest nõrgast.
            // OHUTUS: data_offset on turvaline helistada, kuna ptr viitab reaalsele (potentsiaalselt langenud) T.
            let offset = unsafe { data_offset(ptr) };
            // Seega pöörame nihke ümber, et saada kogu RcBox.
            // OHUTUS: osuti pärineb nõrgast, nii et see nihe on ohutu.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // OHUTUS: oleme nüüd taastanud algse nõrga osuti, nii et saate luua nõrga.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Proovib `Weak`-i kursorit uuendada versiooniks [`Rc`], edukuse korral viivitab sisemise väärtuse langemine.
    ///
    ///
    /// Tagastab [`None`], kui sisemine väärtus on sellest ajast peale langenud.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Hävitage kõik tugevad näpunäited.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Saab sellele jaotusele viitavate tugevate (`Rc`)-osutite arvu.
    ///
    /// Kui `self` loodi [`Weak::new`]-i kasutades, tagastatakse see 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Võimaldab sellele jaotusele osutavate `Weak`-osutite arvu.
    ///
    /// Kui tugevaid näpunäiteid ei jää, tagastatakse see null.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // lahuta kaudne nõrk ptr
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Tagastab `None`, kui osuti ripub ja eraldatud `RcBox` pole määratud (st kui `Weak` loodi `Weak::new` poolt).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Oleme ettevaatlikud, et mitte luua "data"-i välja hõlmavat viidet, kuna väli võib olla samaaegselt muteeritud (näiteks kui viimane `Rc`-st loobutakse, langetatakse andmeväli oma kohale).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Tagastab `true`, kui kaks "nõrka" osutavad samale jaotusele (sarnane [`ptr::eq`]-le) või kui mõlemad ei osuta mingile jaotusele (kuna need on loodud `Weak::new()`)-iga.
    ///
    ///
    /// # Notes
    ///
    /// Kuna see võrdleb näpunäiteid, tähendab see, et `Weak::new()` võrdub üksteisega, kuigi need ei viita mingile jaotusele.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Võrreldes `Weak::new`-i.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Viskab kursori `Weak` alla.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Ei prindi midagi
    /// drop(foo);        // Prindib "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // nõrk loendus algab 1-st ja läheb nulli ainult siis, kui kõik tugevad näpunäited on kadunud.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Valmistab `Weak`-i osuti klooni, mis osutab samale jaotusele.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Ehitab uue `Weak<T>`, eraldades `T`-le mälu seda initsialiseerimata.
    /// Tagasiväärtuse [`upgrade`] helistamine annab alati [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Kontrollisime_add siia, et mem::forget-iga ohutult hakkama saada.Eriti
// kui kasutate mem::forget Rcs (või Weaks), võib ref-count üle voolata ja siis saate eraldamise vabastada, kuni täitmata Rcs (või Weaks) on olemas.
//
// Me katkestame, sest see on nii mandunud stsenaarium, et me ei hooli sellest, mis juhtub-ükski reaalne programm ei tohiks seda kunagi kogeda.
//
// Sellel peaks olema tühised üldkulud, kuna te ei pea Rust-s tänu omandilisusele ja liikumissemantikale neid nii palju kloonima.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Väärtuse langemise asemel soovime ülevoolu katkestada.
        // Kui seda kutsutakse, pole võrdlusarv kunagi null;
        // sellegipoolest lisame siia katkestuse, et vihjata LLVM-ile muidu vahelejäänud optimeerimisele.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Väärtuse langemise asemel soovime ülevoolu katkestada.
        // Kui seda kutsutakse, pole võrdlusarv kunagi null;
        // sellegipoolest lisame siia katkestuse, et vihjata LLVM-ile muidu vahelejäänud optimeerimisele.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Kursori taga oleva kasuliku koormuse jaoks saate nihke `RcBox`-i piires.
///
/// # Safety
///
/// Kursor peab osutama T kehtivale eksemplarile (ja sellel peavad olema kehtivad metaandmed), kuid T on lubatud loobuda.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Joondage suuruse väärtus RcBoxi lõpuni.
    // Kuna RcBox on repr(C), on see alati viimane väli mälus.
    // OHUTUS: kuna ainsad võimalikud mõõtmeteta tüübid on viilud, objektid trait,
    // ja väliste tüüpide korral on sisendi ohutuse nõue praegu piisav align_of_val_raw nõuete täitmiseks;see on keele rakendusdetail, millele ei saa tugineda väljaspool std-i.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}