use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Kasutatakse meie `#[assert_instr]`-i märkuste ütlemiseks, et nende koodegeeni testimiseks on olemas kõik sisemised sisemised funktsioonid, kuna mõned neist asuvad täiendava `-Ctarget-feature=+unimplemented-simd128`-i taga, millel pole praegu `#[target_feature]`-s ühtegi ekvivalenti.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}