`core::arch` - Rust põhiraamatukogu arhitektuurispetsiifilised olemused
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` moodul rakendab arhitektuurist sõltuvaid sisemisi omadusi (nt SIMD).

# Usage 

`core::arch` on saadaval osana `libcore`-st ja `libstd` reekspordib selle uuesti.Eelistage selle kasutamist `core::arch` või `std::arch` kaudu kui selle crate kaudu.
Ebastabiilsed funktsioonid on öösel Rust-s `feature(stdsimd)`-i kaudu sageli saadaval.

`core::arch`-i kasutamine selle crate kaudu nõuab öist Rust-i ja see võib sageli puruneda (ja teeb ka).Ainsad juhtumid, kus peaksite kaaluma selle kasutamist selle crate kaudu, on:

* kui peate ise `core::arch` uuesti kompileerima, nt lubades teatud sihtfunktsioonid, mis pole `libcore`/`libstd`-i jaoks lubatud.
Note: kui peate selle mittestandardse sihtmärgi jaoks uuesti kompileerima, eelistage selle crate asemel kasutada `xargo` ja `libcore`/`libstd` vastavalt kompileerida.
  
* kasutades mõnda funktsiooni, mis ei pruugi olla saadaval isegi ebastabiilsete Rust funktsioonide taga.Püüame neid võimalikult vähe hoida.
Kui peate mõnda neist funktsioonidest kasutama, avage probleem, et saaksime neid öösel Rust-s paljastada ja saaksite neid sealt kasutada.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` levitatakse peamiselt nii MIT-litsentsi kui ka Apache-litsentsi (versioon 2.0) tingimustel, kusjuures osad on kaetud erinevate BSD-laadsete litsentsidega.

Vaadake üksikasju LICENSE-APACHE ja LICENSE-MIT.

# Contribution

Kui te pole sõnaselgelt öelnud teisiti, on teie poolt `core_arch`-i lisamiseks tahtlikult esitatud kaastöö, nagu on määratletud Apache-2.0 litsentsis, topeltlitsentsitud, nagu ülal, ilma täiendavate tingimuste ja tingimusteta.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












