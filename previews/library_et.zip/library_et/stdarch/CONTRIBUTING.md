# Kaastöö stdarchile

`stdarch` crate on rohkem kui nõus kaastöid vastu võtma!Kõigepealt soovite tõenäoliselt tutvuda hoidlaga ja veenduda, et testid teie jaoks läbiksid:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Kus `<your-target-arch>` on sihtkolmik, mida kasutab `rustup`, nt `x86_x64-unknown-linux-gnu` (ilma eelneva `nightly-` vms).
Samuti pidage meeles, et see hoidla nõuab Rust öist kanalit!
Ülaltoodud testid nõuavad tegelikult, et teie süsteemiks oleks vaikimisi öine rust, et seadistada `rustup default nightly` (ja `rustup default stable` tagasipöördumiseks).

Kui mõni ülaltoodud toimingutest ei toimi, [please let us know][new]!

Järgmisena saate [find an issue][issues]-i aidata, valisime mõned [`help wanted`][help]-ja [`impl-period`][impl]-märgenditega, mis võiksid eriti abi kasutada. 
Võib-olla olete kõige rohkem huvitatud [#40][vendor]-ist, rakendades x86-is kõiki tarnija sisemisi omadusi.Selles väljaandes on mõned head vihjed selle kohta, kust alustada!

Kui teil on üldisi küsimusi, kasutage [join us on gitter][gitter]-i ja küsige lähemalt!Pingutage julgelt küsimustega kas@BurntSushi või@alexcrichton.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Kuidas kirjutada stdarchi sisemisi näiteid

Antud sisemise toimimise korral peavad olema lubatud mõned funktsioonid ja `cargo test --doc` peab näidet käitama ainult siis, kui seda funktsiooni toetab protsessor.

Selle tulemusel ei tööta `rustdoc` poolt loodud vaikimisi `fn main` (enamikul juhtudel).
Kaaluge järgmise näite kasutamist, et teie näide toimiks ootuspäraselt.

```rust
/// # // Vajame cfg_target_feature tagamaks, et näide on ainult
/// # // käivitab `cargo test --doc`, kui protsessor seda funktsiooni toetab
/// # #![feature(cfg_target_feature)]
/// # // Sisemise toimimiseks vajame target_feature
/// # #![feature(target_feature)]
/// #
/// # // Vaikimisi kasutab rustdoc `extern crate stdarch`-i, kuid meil on seda vaja
/// # // `#[macro_use]`
/// # # [makro_kasutus] extern crate stdarch;
/// #
/// # // Tõeline põhifunktsioon
/// # fn main() {
/// #     // Käivitage see ainult siis, kui `<target feature>` on toetatud
/// #     kui cfg_feature_enabled! ("<target feature>"){
/// #         // Looge funktsioon `worker`, mida käitatakse ainult sihtfunktsiooni korral
/// #         // on toetatud ja veenduge, et teie töötajal on `target_feature` lubatud
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         ebaturvaline fn worker() {
/// // Kirjutage oma näide siia.Siin toimivad funktsioonispetsiifilised olemused!Mine metsikuks!
///
/// #         }
///
/// #         ebaturvaline { worker(); }
/// #     }
/// # }
```

Kui mõni ülaltoodud süntaks ei tundu tuttav, kirjeldab [Rust Book]-i jaotis [Documentation as tests] süntaksit `rustdoc` üsna hästi.
Nagu alati, võtke [join us on gitter][gitter]-i julgelt ühendust ja küsige meilt, kas teil on mingeid tõrkeid, ja aitäh, et aitasite `stdarch`-i dokumentatsiooni täiustada!

# Alternatiivsed testimisjuhised

Testide käivitamiseks on üldiselt soovitatav kasutada `ci/run.sh`-i.
Kuid see ei pruugi teie jaoks töötada, nt kui kasutate Windows-i.

Sellisel juhul võite koodide genereerimise testimiseks tagasi töötada `cargo +nightly test` ja `cargo +nightly test --release -p core_arch`.
Pange tähele, et need nõuavad igaõhtuse tööriistaketi installimist ja et `rustc` teaks teie sihtkolmikust ja selle protsessorist.
Eelkõige peate määrama keskkonnamuutuja `TARGET` nagu `ci/run.sh` puhul.
Lisaks peate sihtfunktsioonide näitamiseks määrama `RUSTCFLAGS` (vajate `C`) `RUSTCFLAGS="-C -target-features=+avx2"`.
`-C -target-cpu=native` saate määrata ka siis, kui arendate "just"-d oma praeguse protsessori vastu.

Hoiatatakse, et nende alternatiivsete juhiste kasutamisel võib [things may go less smoothly than they would with `ci/run.sh`][ci-run-good] nt
käskude genereerimise testid võivad ebaõnnestuda, kuna lahtivõtja nimetas neid erinevalt, nt
see võib `aesenc`-i käskude asemel genereerida `vaesenc`-i, hoolimata sellest, et nad käituvad sama.
Ka nende juhistega sooritatakse vähem teste kui tavaliselt tehtaks, seega ärge imestage, et kui te lõpuks taotlete, võivad siin käsitlemata testides ilmneda mõned vead.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






