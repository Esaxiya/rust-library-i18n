use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr võtab tagasihelistamise, mis saab dl_phdr_info kursori iga protsessiga lingitud DSO kohta.
    // dl_iterate_phdr tagab ka dünaamilise linkeri lukustamise iteratsiooni algusest lõpuni.
    // Kui tagasihelistamine tagastab nullist erineva väärtuse, lõpetatakse iteratsioon varakult.
    // 'data' edastatakse iga kõne tagasihelistamise kolmanda argumendina.
    // 'size' annab dl_phdr_info suuruse.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Peame parsima välja ehitamise ID ja mõned põhiprogrammi päise andmed, mis tähendab, et vajame natuke asju ka ELF-i spetsifikatsioonidest.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Nüüd peame bitist bitiks korrama duktsiooni dl_phdr_info struktuuri, mida fuksia praegune dünaamiline linker kasutab.
// Kroomil on ka see ABI piir ja krahhi.
// Sellegipoolest tahaksime need juhtumid päkapikuotsingu kasutamiseks teisaldada, kuid peame selle SDK-s ette nägema ja seda pole veel tehtud.
//
// Seega oleme meie (ja nemad) kinni pidanud kasutama seda meetodit, mis põhjustab fuksia libc-ga tihedat sidumist.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Meil pole võimalust teada saada, kas e_phoff ja e_phnum kehtivad.
    // libc peaks selle meie jaoks tagama, nii et siin on ohutu viilu moodustada.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr tähistab 64-bitist ELF-i programmi päist sihtarhitektuuri lõpptulemuses.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr tähistab kehtivat ELF-i päist ja selle sisu.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Meil pole võimalust kontrollida, kas p_addr või p_memsz on kehtivad.
    // Fuksia libs sõelub kõigepealt märkmeid, kuid siin viibimise tõttu peavad need päised kehtima.
    //
    // NoteIter ei nõua alusandmete kehtivust, kuid piiride kehtivust.
    // Usume, et libc on taganud, et see on meie puhul siin nii.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Järgu ID-de märkuse tüüp.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr tähistab ELF-i märkme päist sihtmärgi endiaanluses.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Märkus tähistab ELF-i märget (päis + sisu).
// Nimi jäetakse u8-i viiluna, kuna see ei ole alati nulliga lõppenud ja rust abil on piisavalt lihtne kontrollida, kas baidid vastavad mõlemale.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter võimaldab teil märkmete segmendi kaudu ohutult itreerida.
// See lõpeb kohe, kui ilmneb tõrge või kui märkmeid pole enam.
// Kui kordate kehtetute andmete üle, toimib see justkui märkmeid ei leitud.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Funktsiooni muutumatu variant on see, et antud kursor ja suurus tähistavad kehtivat baitide vahemikku, mida kõiki saab lugeda.
    // Nende baitide sisu võib olla mis tahes, kuid vahemik peab olema kehtiv, et see oleks ohutu.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to joondab 'x' 'baidi' joondusega eeldades, et 'to' on 2.
// See järgib standardmustrit C/C ++ ELF-i parsimiskoodis, kus kasutatakse (x + kuni, 1) ja -to.
// Rust ei lase teil kasutust eitada, nii et ma kasutan
// 2-de täiendamise teisendamine selle loomiseks.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 kulutab lõigust baitide arvu (kui see on olemas) ja tagab lisaks, et viimane viil oleks õigesti joondatud.
// Kui taotletud baitide arv on liiga suur või kui lõiku ei ole võimalik pärast veel järelejäänud baitide olemasolu tõttu uuesti joondada, tagastatakse ükski ja viilu ei muudeta.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Sellel funktsioonil pole tõelisi invariante, mida helistaja peab toetama, välja arvatud see, et 'bytes' peaks jõudluse (ja mõnel arhitektuuril korrektsuse) järgi joonduma.
// Väljade Elf_Nhdr väärtused võivad olla jaburad, kuid see funktsioon ei taga sellist.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // See on ohutu, kuni ruumi on piisavalt ja me lihtsalt kinnitasime, et ülaltoodud if-avalduses ei tohiks see olla ohtlik.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Pange tähele, et sice_of: :<Elf_Nhdr>() on alati 4-baidine joondatud.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Kontrollige, kas oleme jõudnud lõpuni.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Teisendame nhdr välja, kuid kaalume saadud struktuuri hoolikalt.
        // Me ei usalda nameszi ega descsz-d ega tee tüübi põhjal ohtlikke otsuseid.
        //
        // Nii et isegi täielikust prügist välja tulles peaksime siiski olema ohutud.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Näitab, et segment on käivitatav.
const PERM_X: u32 = 0b00000001;
/// Näitab, et segment on kirjutatav.
const PERM_W: u32 = 0b00000010;
/// Näitab, et segment on loetav.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Esitab ELF-i segmenti käitamise ajal.
struct Segment {
    /// Annab selle segmendi sisu käitamise virtuaalse aadressi.
    addr: usize,
    /// Annab selle segmendi sisu mälumahu.
    size: usize,
    /// Annab selle segmendi mooduli virtuaalse aadressi koos ELF-failiga.
    mod_rel_addr: usize,
    /// Annab ELF-failist leitud õigused.
    /// Need load ei pruugi siiski olla käitamise ajal olevad õigused.
    flags: Perm,
}

/// Võimaldab ühelt korduselt jaotada DSO segmendid.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Esitab ELF DSO-d (dünaamiline jagatud objekt).
/// See tüüp viitab tegelikule jaotusvõrguettevõtjale salvestatud andmetele, selle asemel et teha oma koopia.
struct Dso<'a> {
    /// Dünaamiline linker annab meile alati nime, isegi kui nimi on tühi.
    /// Peamise käivitatava faili puhul jääb see nimi tühjaks.
    /// Jagatud objekti puhul on see soname (vt DT_SONAME).
    name: &'a str,
    /// Fuksias on peaaegu kõigil binaarkaartidel ehituskoodid, kuid see pole range nõue.
    /// Vajadusel ei saa DSO teavet reaalse ELF-failiga kokku sobitada, kui build_id puudub, seega nõuame, et igal DSO-l oleks siin üks.
    ///
    /// DS_id ilma build_id eiratakse.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Tagastab selle jaotusvõrguettevõtja segmentide iteraatori.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Need vead kodeerivad probleeme, mis tekivad iga DSO kohta käiva teabe sõelumisel.
///
enum Error {
    /// NameError tähendab, et C-stiili stringi rust teisendamisel tekkis viga.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError tähendab, et me ei leidnud järgu ID-d.
    /// Selle põhjuseks võib olla asjaolu, et DSO-l puudus järgu ID või et järgu ID-d sisaldav segment oli valesti vormistatud.
    ///
    BuildIDError,
}

/// Kõigi dünaamilise linkeri abil protsessi lingitud DSO-de jaoks kutsub kas 'dso' või 'error'.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter, millel on üks söömise meetoditest, mida nimetatakse foreach DSO-ks.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr tagab, et info.name osutab kehtivale asukohale.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// See funktsioon prindib kogu DSO-s sisalduva teabe jaoks Fuksia sümboliseerija märgistuse.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}