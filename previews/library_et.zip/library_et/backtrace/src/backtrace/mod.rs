use core::ffi::c_void;
use core::fmt;

/// Kontrollib praegust kõnepinu, viies kõik aktiivsed kaadrid virna jälje arvutamiseks ettenähtud sulgurisse.
///
/// See funktsioon on selle teegi tööhobune programmi virnajälgede arvutamisel.Antud sulgemisega `cb` saadakse `Frame` eksemplarid, mis esindavad teavet selle kõneraami kohta virnas.
/// Sulgemisel saadakse ülalt-alla raamid (viimati nimetatakse funktsioone esimesena).
///
/// Sulgemise tagasiväärtus näitab, kas tagasisuund peaks jätkuma.`false` tagastusväärtus lõpetab tagasituleku ja naaseb kohe.
///
/// Kui `Frame` on omandatud, soovite tõenäoliselt helistada numbril `backtrace::resolve`, et teisendada `ip` (käskude osuti) või sümboliaadress `Symbol`-ks, mille kaudu saab nime ja/või failinime/rea numbrit teada saada.
///
///
/// Pange tähele, et see on suhteliselt madala tasemega funktsioon ja kui soovite näiteks jäädvustada tagasijälje, mida hiljem kontrollida, võib `Backtrace` tüüp olla sobivam.
///
/// # Nõutavad funktsioonid
///
/// Selle funktsiooni jaoks peab olema lubatud funktsioon `backtrace` crate ja funktsioon `std` on vaikimisi lubatud.
///
/// # Panics
///
/// Selle funktsiooni eesmärk on mitte kunagi panic, kuid kui `cb` andis panics, sunnivad mõned platvormid topelt panic protsessi katkestama.
/// Mõned platvormid kasutavad C-teeki, mis kasutab sisemiselt tagasihelistamisi, mida ei saa tagasi kerida, nii et `cb`-ist paanika võib protsessi katkestada.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // jätkake tagasijälge
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Sama mis `trace`, ainult ebaturvaline, kuna see on sünkroonimata.
///
/// Sellel funktsioonil ei ole sünkroonimisgarantiisid, kuid see on saadaval siis, kui selle crate funktsiooni `std` pole kompileeritud.
/// Lisateavet ja näiteid leiate funktsioonist `trace`.
///
/// # Panics
///
/// Teavet `trace` kohta leiate `cb` paanika hoiatustest.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// trait, mis kujutab üht tagasijälje kaadrit, andis selle crate funktsioonile `trace`.
///
/// Jälgimisfunktsiooni sulgemine annab kaadrid ja raam saadetakse praktiliselt, kuna selle aluseks olev rakendus pole alati teada enne käitusaega.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Tagastab selle raami praeguse käsuosuti.
    ///
    /// Tavaliselt on see järgmine käsk, mida kaadris käivitada, kuid mitte kõik rakendused ei loetle seda 100% täpsusega (kuid üldiselt on see üsna lähedal).
    ///
    ///
    /// Soovitatav on see väärtus edastada `backtrace::resolve`-le, et muuta see sümbolinimeks.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Tagastab selle raami praeguse virnaosuti.
    ///
    /// Juhul kui taustaprogramm ei suuda selle kaadri virnaosutit taastada, tagastatakse nullkursor.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Tagastab selle funktsiooni raami algussümboli aadressi.
    ///
    /// See püüab `ip`-i poolt funktsiooni algusesse tagastatud käskude kursorit tagasi kerida, tagastades selle väärtuse.
    ///
    /// Mõnel juhul tagastavad taustaprogrammid `ip` sellest funktsioonist lihtsalt tagasi.
    ///
    /// Tagastatud väärtust saab mõnikord kasutada, kui `backtrace::resolve` ebaõnnestus ülal toodud `ip`-is.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Tagastab mooduli baasaadressi, kuhu raam kuulub.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // See peab olema esimene, tagamaks, et Miri on hostiplatvormi ees prioriteetne
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // ainult dbghelpis kasutatud sümboliseerivad
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}