#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Formaat tagajälgede jaoks.
///
/// Seda tüüpi saab kasutada tagasijälje printimiseks, olenemata sellest, kust see ise pärineb.
/// Kui teil on `Backtrace` tüüp, kasutab selle `Debug` rakendus juba seda printimisvormingut.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Printimisstiilid, mida saame printida
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Trükib tagasilöögi, mis ideaalis sisaldab ainult asjakohast teavet
    Short,
    /// Trükib kogu jälje, mis sisaldab kogu võimalikku teavet
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Looge uus `BacktraceFmt`, mis kirjutab väljundi antud `fmt`-i.
    ///
    /// `format`-argument juhib stiili, milles tagasijälg trükitakse, ja `print_path`-argumenti kasutatakse failinimede `BytesOrWideString`-eksemplaride printimiseks.
    /// See tüüp ise ei trüki failinimesid, kuid selleks on vaja seda tagasihelistamist.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Prindib prinditava tagantjälje preambuli.
    ///
    /// See on vajalik mõnel platvormil, et tagasijäljed hiljem täielikult sümboliseeritakse, ja muidu peaks see olema lihtsalt esimene meetod, millele helistate pärast `BacktraceFmt` loomist.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Lisab backtrace'i väljundisse raami.
    ///
    /// See kohustus tagastab `BacktraceFrameFmt`-i RAII-eksemplari, mida saab kasutada kaadri tegelikuks printimiseks ja hävitamisel suurendab see kaadriloendurit.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Lõpetab backtrace väljundi.
    ///
    /// See on praegu keelatud, kuid see lisatakse future ühilduvuse tagantjäljevormingutega.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Praegu pole lubatud-sealhulgas see hook, et võimaldada future lisandeid.
        Ok(())
    }
}

/// Vormindaja ainult ühe jälje kaadri jaoks.
///
/// Selle tüübi loob funktsioon `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Selle kaadri vormindajaga prindib `BacktraceFrame`.
    ///
    /// See prindib rekursiivselt kõik `BacktraceFrame`-i `BacktraceSymbol`-i eksemplarid.
    ///
    /// # Nõutavad funktsioonid
    ///
    /// Selle funktsiooni jaoks peab olema lubatud funktsioon `backtrace` crate ja funktsioon `std` on vaikimisi lubatud.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Prindib `BacktraceSymbol`-i `BacktraceFrame`-i piires.
    ///
    /// # Nõutavad funktsioonid
    ///
    /// Selle funktsiooni jaoks peab olema lubatud funktsioon `backtrace` crate ja funktsioon `std` on vaikimisi lubatud.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: see pole tore, et me ei lõpeta lõpuks midagi
            // mitte-utf8 failinimedega.
            // Õnneks on peaaegu kõik utf8, nii et see ei tohiks olla liiga halb.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Prindib töötlemata jälgitud `Frame` ja `Symbol`, tavaliselt selle crate töötlemata tagasihelistamise seest.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Lisab tagasijäljendi väljundisse toore raami.
    ///
    /// See meetod, erinevalt eelmisest, võtab toored argumendid juhul, kui nad on pärit erinevatest asukohtadest.
    /// Pange tähele, et seda võib ühe kaadri puhul mitu korda nimetada.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Lisab tagasijäljendi väljundisse tooraami, sealhulgas veeruteabe.
    ///
    /// See meetod, nagu ka eelmine, võtab toored argumendid juhul, kui nad on pärit erinevatest asukohtadest.
    /// Pange tähele, et seda võib ühe kaadri puhul mitu korda nimetada.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuksia ei suuda protsessis sümboliseerida, seega on tal spetsiaalne formaat, mida saab hiljem sümboliseerida.
        // Trükkige see meie enda vormingus aadresside printimise asemel siia.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // "null"-i kaadreid pole vaja printida, see tähendab põhimõtteliselt lihtsalt seda, et süsteemi tagasijälg oli natuke innukas superkaugele jälile.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // TCG suuruse vähendamiseks Sgx enklaavis ei soovi me rakendada sümbolite eraldamise funktsionaalsust.
        // Pigem saame siia printida aadressi nihke, mille võiks hiljem funktsiooni korrigeerimiseks kaardistada.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Trükkige nii kaadri register kui ka raami valikuline käsuosuti.
        // Kui me jääme selle kaadri esimesest sümbolist kaugemale, printime lihtsalt sobiva tühimärgi.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Järgmisena kirjutage välja sümboli nimi, kasutades lisateavet alternatiivse vormingu abil, kui oleme täielik tagasijälg.
        // Siin käsitleme ka sümboleid, millel pole nime,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Ja viimasena printige välja filename/line number, kui see on saadaval.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line on trükitud sümbolinime all olevatele joontele, nii et printige mõni sobiv tühik, et end kuidagi paremjoondada.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Failinime printimiseks ja seejärel reanumbri printimiseks delegeerige meie sisemisele tagasihelistamisele.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Lisage veeru number, kui see on saadaval.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Meid huvitab ainult kaadri esimene sümbol
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}