//! Moodul, mis on abiks dbghelp sidumiste haldamisel Windows-is
//!
//! Windows-i tagasijäljed (vähemalt MSVC puhul) on peamiselt varustatud `dbghelp.dll`-i ja selle erinevate funktsioonidega.
//! Need funktsioonid on praegu laaditud *dünaamiliselt*, mitte lingitakse `dbghelp.dll`-iga staatiliselt.
//! Seda teeb praegu standardraamatukogu (ja see on seal teoreetiliselt nõutav), kuid see on püüd aidata vähendada teegi staatilisi dll-sõltuvusi, kuna tagasijäljed on tavaliselt üsna valikulised.
//!
//! Nagu öeldud, laadib `dbghelp.dll` peaaegu alati edukalt Windows-i.
//!
//! Pange tähele, et kuna me laadime kogu selle toe dünaamiliselt, ei saa me `winapi`-is tooreid määratlusi kasutada, vaid peame ise määrama funktsioonikursori tüübid ja seda kasutama.
//! Me ei taha tegelikult tegeleda winapi dubleerimisega, nii et meil on Cargo funktsioon `verify-winapi`, mis kinnitab, et kõik sidemed vastavad Winapi omadele ja see funktsioon on CI-s lubatud.
//!
//! Lõpuks märkite siin, et `dbghelp.dll`-i dll-i ei laadita kunagi maha ja see on praegu tahtlik.
//! Mõeldakse, et saame selle globaalselt vahemällu salvestada ja seda API-le helistamise vahel kasutada, vältides kallist loads/unloads-i.
//! Kui see on lekkeandurite vms probleem, võime sinna jõudes üle silla minna.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Töö `SymGetOptions` ja `SymSetOptions` ümber pole Winapi endas olemas.
// Vastasel juhul kasutatakse seda ainult siis, kui kontrollime tüüpe winapi suhtes uuesti.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Winapis pole veel määratletud
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // See on defineeritud WinAPis, kuid see on vale (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Winapis pole veel määratletud
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Seda makrot kasutatakse `Dbghelp`-i struktuuri määratlemiseks, mis sisaldab sisemiselt kõiki funktsiooninäitajaid, mida võime laadida.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// `dbghelp.dll`-i jaoks laaditud DLL
            dll: HMODULE,

            // Iga funktsioonikursor iga funktsiooni kohta, mida võime kasutada
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Esialgu pole me DLL-i laadinud
            dll: 0 as *mut _,
            // Kõigi funktsioonide algväärtuseks seatakse null, et öelda, et neid tuleb dünaamiliselt laadida.
            //
            $($name: 0,)*
        };

        // Mugavus typedef iga funktsiooni tüübi jaoks.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// `dbghelp.dll` avamise katsed.
            /// Tagastab edukuse, kui see töötab, või vea, kui `LoadLibraryW` ebaõnnestub.
            ///
            /// Panics, kui kogu on juba laaditud.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Funktsioon iga meetodi jaoks, mida soovime kasutada.
            // Kui seda kutsutakse, loeb see vahemällu salvestatud funktsioonikursorit või laadib selle ja tagastab laaditud väärtuse.
            // Õnnestumiseks kinnitatakse koormusi.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Mugavus puhverserveri abil saab lukustada dbghelp-funktsioone.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Alustage kogu tugi, mis on vajalik `dbghelp` API funktsioonide kasutamiseks sellest crate-st.
///
///
/// Pange tähele, et see funktsioon on **ohutu**, sellel on oma sünkroonimine.
/// Pange tähele ka seda, et seda funktsiooni on turvaline mitu korda rekursiivselt kutsuda.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Esimene asi, mida peame tegema, on selle funktsiooni sünkroonimine.Seda võib nimetada samaaegselt teistest lõimedest või rekursiivselt ühe lõime sees.
        // Pange tähele, et see on siiski keerukam, sest siin kasutatav `dbghelp`,*ka* tuleb selles protsessis kõigi teiste `dbghelp`-i helistajatega sünkroonida.
        //
        // Tavaliselt pole `dbghelp`-i jaoks sama protsessi jooksul nii palju kõnesid ja võime arvata, et ainult meie pääseme sellele juurde.
        // Siiski on veel üks peamine kasutaja, kelle pärast peame muretsema, irooniliselt meie ise, kuid tavalises raamatukogus.
        // Rust standardraamatukogu sõltub sellest crate-st tagasiteede toetamiseks ja see crate on olemas ka crates.io-is.
        // See tähendab, et kui standardraamatukogu prindib panic tagasijälge, võib see võistelda selle crates.io-ist pärineva crate-ga, mis põhjustab segfigu.
        //
        // Selle sünkroonimisprobleemi lahendamiseks kasutame siin Windowsi spetsiifilist trikki (see on ju Windowsi spetsiifiline piirang sünkroonimise osas).
        // Selle kõne kaitsmiseks loome *session-local* nimega mutex.
        // Eesmärk on see, et standardraamatukogu ja see crate ei pea siin sünkroonimiseks jagama Rust-tasemel API-sid, vaid võivad selle asemel töötada kulisside taga, et tagada nende sünkroonimine.
        //
        // Nii, kui seda funktsiooni kutsutakse läbi tavalise teegi või crates.io-i kaudu, võime olla kindlad, et sama mutex on hankimisel.
        //
        // Nii et see tähendab, et esimene asi, mida me siin teeme, on aatomi abil `HANDLE`, mis on Windows-is nimega mutex.
        // Sünkroonime natuke teiste seda funktsiooni jagavate lõimedega ja tagame, et selle funktsiooni eksemplari jaoks luuakse ainult üks käepide.
        // Pange tähele, et käepide pole kunagi suletud, kui see on globaalsesse kohta salvestatud.
        //
        // Pärast seda, kui oleme lukustuse tegelikult käima saanud, omandame selle lihtsalt ja meie välja antud `Init`-käepide vastutab selle lõpuks langemise eest.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, phew!Nüüd, kui me kõik oleme turvaliselt sünkroonitud, alustame tegelikult kõike töödelda.
        // Kõigepealt peame tagama, et `dbghelp.dll` on selles protsessis tegelikult laaditud.
        // Teeme seda dünaamiliselt, et vältida staatilist sõltuvust.
        // Seda on ajalooliselt tehtud imelike linkimisprobleemide lahendamiseks ja see on mõeldud binaarkaartide natuke kaasaskantavamaks muutmiseks, kuna see on suuresti vaid silumisutiliit.
        //
        //
        // Kui oleme `dbghelp.dll` avanud, peame selles kutsuma mõned initsialiseerimisfunktsioonid ja seda on üksikasjalikumalt kirjeldatud allpool.
        // Kuid me teeme seda ainult üks kord, nii et meil on globaalne tõeväärtus, mis näitab, kas oleme veel valmis või mitte.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Veenduge, et `SYMOPT_DEFERRED_LOADS`-lipp oleks seatud, sest vastavalt MSVC enda dokumentidele selle kohta: "This is the fastest, most efficient way to use the symbol handler.", nii et tehkem seda!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Initsialiseerige sümbolid tegelikult MSVC abil.Pange tähele, et see võib ebaõnnestuda, kuid me ignoreerime seda.
        // Selle jaoks pole iseenesest palju varasemat kunsti, kuid tundub, et LLVM ignoreerib siinset tagastusväärtust ja üks LLVM-i desinfitseerimisraamatukogudest trükib hirmutava hoiatuse, kui see ebaõnnestub, kuid ignoreerib seda pikas perspektiivis.
        //
        //
        // Ühel juhul tuleb see Rust jaoks palju välja, et nii standardraamatukogu kui ka see crate crates.io-il tahavad mõlemad võistelda `SymInitializeW`-i nimel.
        // Tavapärane raamatukogu tahtis ajalooliselt suurema osa ajast siis initsialiseerida, kuid nüüd, kui ta kasutab seda crate, tähendab see, et keegi jõuab esmalt initsialiseerimiseni ja teine jätkab seda initsialiseerimist.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}