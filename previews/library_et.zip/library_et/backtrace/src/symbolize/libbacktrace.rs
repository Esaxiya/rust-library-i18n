//! Sümboliseerimisstrateegia, mis kasutab libbacktrace'is DWARF-i sõelumiskoodi.
//!
//! Libbacktrace C teek, mida levitatakse tavaliselt koos gcc-ga, toetab mitte ainult tagasijälje genereerimist (mida me tegelikult ei kasuta), vaid sümboliseerib ka tagasisuunda ja käsitleb kääbuse silumisandmeid selliste asjade kohta nagu sissejoonitud raamid ja muu.
//!
//!
//! See on siin suhteliselt erinevate probleemide tõttu suhteliselt keeruline, kuid põhiidee on:
//!
//! * Kõigepealt helistame `backtrace_syminfo`-ile.See saab sümboliteabe dünaamiliste sümbolite tabelist, kui suudame.
//! * Järgmisena helistame `backtrace_pcinfo`-ile.See sõelub silumisinfotabeleid, kui need on saadaval, ja võimaldab meil taastada teavet tekstisiseste raamide, failinimede, reanumbrite jms kohta.
//!
//! Päkapikulaudade libbacktrace'i viimisel on palju trikke, kuid loodetavasti pole see veel maailma lõpp ja see on allpool lugedes piisavalt selge.
//!
//! See on MSVC-ja OSX-väliste platvormide vaikesümboliseerimisstrateegia.Libstd-s on see OSX-i vaikestrateegia.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Võimaluse korral eelistage silumisinfost pärinevat nime `function`, mis võib tavaliselt olla täpsem näiteks kaadrisisestele kaadritele.
                // Kui seda pole, pöörduge tagasi `symname`-is määratud sümbolitabeli nime juurde.
                //
                // Pange tähele, et mõnikord võib `function` tunduda mõnevõrra vähem täpne, näiteks on see `try<i32,closure>`-i asemel `std::panicking::try::do_call`-i nimekirjas.
                //
                // Pole päris selge, miks, kuid üldiselt näib `function` nimi täpsem.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // ära tee praegu midagi
}

/// `syminfo_cb`-i edastatud `data`-osuti tüüp
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Kui see tagasihelistamine on rakendatud `backtrace_syminfo`-ilt, kui me lahendamist alustame, läheme edasi `backtrace_pcinfo`-ile.
    // Funktsioon `backtrace_pcinfo` otsib silumisteavet ja lubab teha asju, näiteks file/line-i teabe ja kaadrisse lisatud kaadreid.
    // Pange tähele, et kui silumisteavet pole, võib `backtrace_pcinfo` ebaõnnestuda või palju ära teha, nii et kui see juhtub, helistame kindlasti tagasihelistamiseks vähemalt ühe sümboliga `syminfo_cb`-ist.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// `pcinfo_cb`-i edastatud `data`-osuti tüüp
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Libbacktrace API toetab oleku loomist, kuid see ei toeta riigi hävitamist.
// Ma isiklikult pean seda tähendama, et riik on mõeldud loomiseks ja siis igavesti elamiseks.
//
// Mulle meeldiks registreerida at_exit()-käitleja, mis selle seisundi puhastaks, kuid libbacktrace ei võimalda seda teha.
//
// Nende piirangute korral on sellel funktsioonil staatiliselt vahemällu salvestatud olek, mis arvutatakse esimesel nõudmisel.
//
// Pidage meeles, et kõik jälitamine toimub järjestikku (üks globaalne lukk).
//
// Pange tähele, et sünkroonimise puudumine on siin tingitud nõudest, et `resolve` on väliselt sünkroniseeritud.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Ärge kasutage libbacktrace'i ohutuid võimalusi, kuna me kutsume seda alati sünkroniseeritud viisil.
        //
        0,
        error_cb,
        ptr::null_mut(), // pole täiendavaid andmeid
    );

    return STATE;

    // Pange tähele, et libbacktrace'i toimimiseks peab see praeguse käivitatava faili jaoks leidma DWARF-i silumisinfo.Tavaliselt teeb ta seda paljude mehhanismide kaudu, sealhulgas, kuid mitte ainult:
    //
    // * /proc/self/exe toetatud platvormidel
    // * Faili nimi edastati oleku loomisel sõnaselgelt
    //
    // Libbacktrace'i teek on suur hulk C-koodi.See tähendab loomulikult, et sellel on mäluohutuse nõrkused, eriti valesti vormindatud silumisinfo käitlemisel.
    // Libstd on ajalooliselt paljude nendega kokku puutunud.
    //
    // Kui kasutatakse /proc/self/exe-i, võime neid tavaliselt ignoreerida, kuna eeldame, et libbacktrace on "mostly correct" ja muidu ei tee "attempted to be correct" kääbuse silumisinfoga imelikke asju.
    //
    //
    // Kui edastame siiski failinime, on see mõnel platvormil (näiteks BSD-d) võimalik, kus pahatahtlik tegija võib põhjustada suvalise faili paigutamise sellesse kohta.
    // See tähendab, et kui me ütleme libbacktrace'ile failinime kohta, võib see kasutada suvalist faili, mis võib põhjustada rikkeid.
    // Kui me ei ütle libbacktrace'ile midagi, siis ei tee see midagi platvormidel, mis ei toeta radasid nagu /proc/self/exe!
    //
    // Arvestades kõike seda, mida me üritame nii palju kui võimalik failinimes *mitte* edastada, kuid peame platvormidel, mis ei toeta üldse /proc/self/exe-i.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Pange tähele, et ideaalis kasutaksime `std::env::current_exe`-i, kuid me ei saa siin `std`-i nõuda.
            //
            // Kasutage `_NSGetExecutablePath`-i, et laadida praegune käivitatav tee staatilisse alasse (millest kui see on liiga väike, siis lihtsalt loobuge).
            //
            //
            // Pange tähele, et me usaldame siin tõsiselt, et libbacktrace ei sure korrumpeeruvate käivitatavate failide tõttu, kuid see kindlasti ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows on failide avamise režiim, kus pärast avamist ei saa seda kustutada.
            // Seda me üldiselt siin tahamegi, sest tahame tagada, et meie käivitatav fail ei muutuks meie alt pärast seda, kui anname selle libbacktrace'ile, loodetavasti leevendades võimalust edastada meelevaldseid andmeid libbacktrace'i (mida võidakse valesti käsitseda).
            //
            //
            // Arvestades, et me teeme siin natuke tantsu, et oma pildile omamoodi lukku saada:
            //
            // * Hankige käimasolev protsess, laadige selle failinimi.
            // * Avage selle failinimega fail õigete lippudega.
            // * Laadige praeguse protsessi failinimi uuesti ja veenduge, et see oleks sama
            //
            // Kui see kõik möödub, oleme teoreetiliselt tõepoolest oma protsessi faili avanud ja oleme garanteeritud, et see ei muutu.FWIW kopeerib selle libstdist ajalooliselt, nii et see on minu parim tõlgendus toimuvast.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // See elab staatilises mälus, et saaksime selle tagasi anda.
                static mut BUF: [i8; N] = [0; N];
                // ... ja see elab virnas, kuna see on ajutine
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // lekitage sihilikult `handle`, sest selle avamine peaks meie failinime lukustama.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Soovime tagastada viilu, mille lõpp on null, nii et kui kõik on täidetud ja see võrdub kogupikkusega, siis võrdsusta see ebaõnnestumisega.
                //
                //
                // Vastasel juhul veenduge, et edu tagastamisel oleks nul-bait viil.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // backtrace'i vead on praegu vaiba alla pühitud
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Helistage `backtrace_syminfo`-i API-le, mis (koodi lugemisest) peaks `syminfo_cb`-i helistama täpselt ühe korra (või ebaõnnestuma arvatavasti veaga).
    // Seejärel tegeleme `syminfo_cb`-is rohkem.
    //
    // Pange tähele, et me teeme seda, kuna `syminfo` uurib sümbolitabelit, leides sümbolite nimed ka siis, kui binaarses silumisinfot pole.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}