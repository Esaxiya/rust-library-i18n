use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Lahendage aadress sümbolile, edastades sümbol määratud sulgurile.
///
/// See funktsioon otsib antud aadressi sellistes piirkondades nagu kohalik sümbolitabel, dünaamiline sümbolitabel või DWARF-i silumisteave (sõltuvalt aktiveeritud rakendusest), et leida saadavaid sümboleid.
///
///
/// Sulgemist ei saa kutsuda, kui eraldusvõimet ei õnnestunud teostada, ja sisselülitatud funktsioonide korral võib seda ka mitu korda helistada.
///
/// Saadud sümbolid tähistavad täitmist määratud `addr`-l, tagastades selle aadressi file/line paarid (kui need on saadaval).
///
/// Pange tähele, et kui teil on `Frame`, on soovitatav selle asemel kasutada funktsiooni `resolve_frame`.
///
/// # Nõutavad funktsioonid
///
/// Selle funktsiooni jaoks peab olema lubatud funktsioon `backtrace` crate ja funktsioon `std` on vaikimisi lubatud.
///
/// # Panics
///
/// Selle funktsiooni eesmärk on mitte kunagi panic, kuid kui `cb` andis panics, sunnivad mõned platvormid topelt panic protsessi katkestama.
/// Mõned platvormid kasutavad C-teeki, mis kasutab sisemiselt tagasihelistamisi, mida ei saa tagasi kerida, nii et `cb`-ist paanika võib protsessi katkestada.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // vaata ainult ülemist raami
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Lahendage varem jäädvustatud kaader sümboliks, viies sümbol määratud sulgurini.
///
/// Funktsioon täidab sama funktsiooni nagu `resolve`, välja arvatud see, et ta võtab aadressi asemel argumendina `Frame`.
/// See võib lubada mõnel platvormi tagantjälgimise rakendusel pakkuda täpsemat sümboliteavet või teavet näiteks siseste raamide kohta.
///
/// Soovitatav on seda kasutada, kui saate.
///
/// # Nõutavad funktsioonid
///
/// Selle funktsiooni jaoks peab olema lubatud funktsioon `backtrace` crate ja funktsioon `std` on vaikimisi lubatud.
///
/// # Panics
///
/// Selle funktsiooni eesmärk on mitte kunagi panic, kuid kui `cb` andis panics, sunnivad mõned platvormid topelt panic protsessi katkestama.
/// Mõned platvormid kasutavad C-teeki, mis kasutab sisemiselt tagasihelistamisi, mida ei saa tagasi kerida, nii et `cb`-ist paanika võib protsessi katkestada.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // vaata ainult ülemist raami
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Virnaraamide IP-väärtused on tavaliselt (always?) käsk *pärast* kõnet, mis on virna tegelik jälg.
// Selle sümboliseerimine põhjustab filename/line-i numbri üks ees ja võib-olla tühjus, kui see on funktsiooni lõpu lähedal.
//
// Põhimõtteliselt näib see nii olevat kõigil platvormidel, nii et lahutatud lahenduse ip-st lahutame selle alati eelmise kõnekäskluse asemel selle asemel, et käsk tagastada.
//
//
// Ideaalis me seda ei teeks.
// Ideaalis nõuaksime, et siin `resolve`-i API-de helistajad teeksid -1-i käsitsi ja arvestaksid, et nad sooviksid asukohateavet *eelmise* juhise jaoks, mitte praegust.
// Ideaalis eksponeeriksime ka `Frame`-i, kui oleme tõepoolest järgmise juhise või praeguse aadressi aadress.
//
// Praegu on see üsna nišimure, nii et lahutame selle sisemiselt alati.
// Tarbijad peaksid jätkama tööd ja saama päris häid tulemusi, seega peaksime olema piisavalt head.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Sama mis `resolve`, ainult ebaturvaline, kuna see on sünkroonimata.
///
/// Sellel funktsioonil ei ole sünkroonimisgarantiisid, kuid see on saadaval siis, kui selle crate funktsiooni `std` pole kompileeritud.
/// Lisateavet ja näiteid leiate funktsioonist `resolve`.
///
/// # Panics
///
/// Teavet `resolve` kohta leiate `cb` paanika hoiatustest.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Sama mis `resolve_frame`, ainult ebaturvaline, kuna see on sünkroonimata.
///
/// Sellel funktsioonil ei ole sünkroonimisgarantiisid, kuid see on saadaval siis, kui selle crate funktsiooni `std` pole kompileeritud.
/// Lisateavet ja näiteid leiate funktsioonist `resolve_frame`.
///
/// # Panics
///
/// Teavet `resolve_frame` kohta leiate `cb` paanika hoiatustest.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait, mis tähistab failis oleva sümboli eraldusvõimet.
///
/// See trait antakse trait-objektina funktsioonile `backtrace::resolve` antud sulgemisele ja see saadetakse praktiliselt, kuna pole teada, milline rakendus selle taga on.
///
///
/// Sümbol võib anda funktsiooni kohta kontekstuaalset teavet, näiteks nime, failinime, rea numbrit, täpset aadressi jne.
/// Kogu teave pole alati sümbolis saadaval, seega tagastavad kõik meetodid `Option`-i.
///
///
pub struct Symbol {
    // TODO: see eluaegne seos peab jääma lõpuks ka `Symbol`-i,
    // kuid see on praegu murettekitav muutus.
    // Praegu on see ohutu, kuna `Symbol` on kunagi kätte antud ainult viitena ja seda ei saa kloonida.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Tagastab selle funktsiooni nime.
    ///
    /// Tagastatud struktuuri saab kasutada erinevate omaduste pärimiseks sümbolinime kohta:
    ///
    ///
    /// * Rakendus `Display` prindib lahti segatud sümboli.
    /// * Juurdepääsu saab sümboli töötlemata väärtusele `str` (kui see kehtib utf-8).
    /// * Juurdepääsu saab sümbolinime töötlemata baitidele.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Tagastab selle funktsiooni algusaadressi.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Tagastab toore failinime viiluna.
    /// See on peamiselt kasulik `no_std` keskkondades.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Tagastab selle veeru numbri, kus see sümbol praegu töötab.
    ///
    /// Ainult gimli annab praegu väärtuse siin ja isegi siis, kui `filename` tagastab `Some`, ja seega kehtivad sellele järelikult sarnased hoiatused.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Tagastab rea numbri, kus see sümbol praegu töötab.
    ///
    /// See tagastusväärtus on tavaliselt `Some`, kui `filename` tagastab `Some`, ja seetõttu kehtivad sellele sarnased hoiatused.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Tagastab faili nime, kus see funktsioon oli määratletud.
    ///
    /// See on praegu saadaval ainult siis, kui kasutatakse libbacktrace'i või gimli (nt
    /// unix platvormid muud) ja kui kahendkood koostatakse silumisinfoga.
    /// Kui kumbki neist tingimustest pole täidetud, tagastab see tõenäoliselt `None`.
    ///
    /// # Nõutavad funktsioonid
    ///
    /// Selle funktsiooni jaoks peab olema lubatud funktsioon `backtrace` crate ja funktsioon `std` on vaikimisi lubatud.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Võib-olla sõelutud C++ sümbol, kui segamini viidud sümbol parsimisel Rust ebaõnnestus.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Hoidke see nullisuurus kindlasti nii, et `cpp_demangle` funktsioon ei peaks keelamisel olema tasuta.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Sümbolinime ümber olev ümbris, mis pakub ergonoomilisi ligipääsu moondatud nimele, töötlemata baitidele, toorele stringile jne.
///
// Luba surnud kood, kui funktsioon `cpp_demangle` pole lubatud.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Loob töötlemata baitidest uue sümbolinime.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Tagastab toore (mangled) sümboli nime kui `str`, kui sümbol on kehtiv utf-8.
    ///
    /// Kasutage `Display`-i juurutamist, kui soovite lahti löödud versiooni.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Tagastab toore sümboli nime baitide loendina
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // See võib printida, kui lahti segatud sümbol tegelikult ei kehti, nii et käsitsege viga siin graatsiliselt, mitte seda väljapoole levitades.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Proovige tagasi võtta see vahemällu salvestatud mälu, mida kasutatakse aadresside sümboliseerimiseks.
///
/// Selle meetodi abil üritatakse vabastada kõik globaalsed andmestruktuurid, mis on muidu globaalselt või lõimes vahemällu salvestatud, mis tavaliselt esindavad parsitud DWARF-teavet või muud sarnast.
///
///
/// # Caveats
///
/// Kuigi see funktsioon on alati saadaval, ei tee see enamikus rakendustes tegelikult midagi.
/// Raamatukogud, nagu dbghelp või libbacktrace, ei paku oleku jaotamise ja eraldatud mälu haldamise võimalusi.
/// Praegu on selle crate funktsioon `gimli-symbolize` ainus funktsioon, millel sellel funktsioonil on mingit mõju.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}