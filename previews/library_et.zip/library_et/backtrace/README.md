# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Raamatukogu Rust-i jaoks tagasijälgede hankimiseks käitusajal.
Selle teegi eesmärk on suurendada tavapärase teegi tuge, pakkudes töötamiseks programmilist liidest, kuid see toetab ka lihtsalt praeguse tagantjälje printimist nagu libstd's panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Tagantjälje lihtsalt jäädvustamiseks ja sellega tegelemise edasilükkamiseks võite kasutada tipptasemel `Backtrace`-tüüpi.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Kui soovite siiski rohkem töötlemata juurdepääsu tegelikule jälgimisfunktsioonile, saate kasutada funktsioone `trace` ja `resolve` otse.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Lahendage see juhendi sümbol nimega
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // jätkake järgmise kaadriga
    });
}
```

# License

See projekt on litsentsitud ühe või teise all

 * Apache litsents, versioon 2.0, ([LICENSE-APACHE](LICENSE-APACHE) või http://www.apache.org/licenses/LICENSE-2.0)
 * MIT-i litsents ([LICENSE-MIT](LICENSE-MIT) või http://opensource.org/licenses/MIT)

omal valikul.

### Contribution

Kui te pole sõnaselgelt öelnud teisiti, on teie poolt tahtlikult backtrace-r-de lisamiseks esitatud kaastöö, nagu on määratletud Apache-2.0 litsentsis, topeltlitsentsitud, nagu ülal, ilma täiendavate tingimuste ja tingimusteta.







