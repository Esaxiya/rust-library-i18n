use backtrace::Backtrace;

// 50-täheline mooduli nimi
mod _234567890_234567890_234567890_234567890_234567890 {
    // 50-täheline struktuurinimi
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// Pikkade funktsioonide nimed tuleb kärbida (MAX_SYM_NAME, 1) tähemärki.
// Käivitage see test ainult msvc jaoks, kuna gnu prindib kõigi kaadrite jaoks "<no info>".
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // 10 kordust struktuuri nimes, seega on täielikult kvalifitseeritud funktsiooni nimi vähemalt 10 *(50 + 50)* 2=2000 tähemärki.
    //
    // See on tegelikult pikem, kuna see sisaldab ka `::`, `<>` ja praeguse mooduli nime
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}