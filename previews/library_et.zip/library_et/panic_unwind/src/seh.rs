//! Windows SEH
//!
//! Windows-is (praegu ainult MSVC-s) on vaikimisi erandite käsitlemise mehhanism Struktureeritud erandite käitlemine (SEH).
//! See on kompilaatori sisemiste külgede poolest üsna erinev Kääbuspõhisest erandite käsitlemisest (nt mida muud unix-i platvormid kasutavad), nii et LLVM-il peab olema SEH-i jaoks palju lisatoetust.
//!
//! Lühidalt öeldes toimub siin:
//!
//! 1. Funktsioon `panic` kutsub standardfunktsiooni Windows `_CxxThrowException`, et visata C++ sarnane erand, mis käivitab kerimisprotsessi.
//! 2.
//! Kõik kompilaatori genereeritud maandumisplokid kasutavad isiklike funktsioonide `__CxxFrameHandler3` funktsioone CRT-s ja Windows-i kerimiskood kasutab seda isiksuse funktsiooni kogu korstnas oleva puhastuskoodi käivitamiseks.
//!
//! 3. Kõigil kompilaatori loodud kõnetel `invoke` on maandumisplokk seatud `cleanuppad` LLVM-i käsuks, mis näitab puhastustoimingu algust.
//! Isiksus (CRT-s määratletud 2. etapis) vastutab puhastustoimingute käitamise eest.
//! 4. Lõpuks käivitatakse `try`-i sisemine `try`-kood (kompilaatori loodud) ja see näitab, et juhtimine peaks tagasi tulema Rust-le.
//! Seda tehakse `catchswitch` pluss `catchpad` käsu kaudu LLVM IR tingimustes, tagastades lõpuks `catchret` käsklusega programmi normaalse juhtimise.
//!
//! Mõned konkreetsed erinevused gcc-põhisel erandite käsitlemisel on järgmised:
//!
//! * Rust-l pole kohandatud isiksusfunktsiooni, see on selle asemel *alati*`__CxxFrameHandler3`.Lisaks ei teostata täiendavat filtreerimist, nii et jõuame lõpuks C++ eranditeni, mis näivad olevat sellised, nagu me viskame.
//! Pange tähele, et erandi viskamine Rust-sse on nagunii määratlemata käitumine, nii et see peaks korras olema.
//! * Meil on mõned andmed, mida saate üle lahtikeeruva piiri edastada, täpsemalt `Box<dyn Any + Send>`.Nagu Kääbuse erandite puhul, salvestatakse need kaks osutit kasuliku koormana erandisse endasse.
//! MSVC-s pole aga vaja täiendavat kuhja jaotust, kuna kõnefunktsioon säilib filtrifunktsioonide täitmise ajal.
//! See tähendab, et osutid edastatakse otse seadmele `_CxxThrowException`, mis seejärel taastatakse filtrifunktsioonis, et kirjutada sisemise `try` korstna raami.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // See peab olema Option, sest me püüame erandi viitena ja selle destruktori täidab käitusaeg C++ .
    // Kui võtame kasti erandist välja, peame jätma erandi kehtivasse olekusse, et selle hävitaja töötaks ilma kasti topelt viskamata.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Kõigepealt terve hunnik tüübimääratlusi.Siin on mõned platvormispetsiifilised veidrused ja palju on LLVM-ist lihtsalt räigelt kopeeritud.Selle kõige eesmärk on rakendada allpool olevat funktsiooni `panic` kõne kaudu `_CxxThrowException`-ile.
//
// Sellel funktsioonil on kaks argumenti.Esimene on nende andmete osuti, mida me edastame, mis on antud juhul meie objekt trait.Päris lihtne leida!Järgmine on aga keerulisem.
// See on osuti `_ThrowInfo` struktuurile ja üldiselt on see mõeldud lihtsalt visatava erandi kirjeldamiseks.
//
// Praegu on seda tüüpi [1] määratlus veidi karvane ja peamine kummalisus (ja erinevus veebiartiklist) on see, et 32-bitistel on osutid osutid, kuid 64-bitistel on kursorid väljendatud 32-bitiste nihetena `__ImageBase` sümbol.
//
// Selle väljendamiseks kasutatakse allpool olevate moodulite makroid `ptr_t` ja `ptr!`.
//
// Tüübimääratluste rägastik jälgib tähelepanelikult ka seda, mida LLVM sedalaadi toimingute jaoks väljastab.Näiteks kui koostate selle C++ koodi MSVC-s ja väljastate LLVM IR:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      kehtetu foo() { rust_panic a = {0, 1};
//          viska a;}
//
// See on sisuliselt see, mida me üritame jäljendada.Enamik allpool toodud püsiväärtustest kopeeriti lihtsalt LLVM-ist,
//
// Igal juhul on need struktuurid kõik üles ehitatud sarnasel viisil ja see on meie jaoks lihtsalt mõnevõrra verbose.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Pange tähele, et me ignoreerime sihilikult nimede segamise reegleid: me ei soovi, et C++ saaks Rust panics kätte saada, lihtsalt deklareerides `struct rust_panic`.
//
//
// Muutmisel veenduge, et tüübinime string vastab täpselt `compiler/rustc_codegen_llvm/src/intrinsic.rs`-is kasutatule.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Siinne juhtiv `\x01`-bait on tegelikult maagiline signaal LLVM-ile, et *mitte* rakendada muud segadust nagu `_`-märgiga eesliide.
    //
    //
    // See sümbol on vt +, mida C++ `std::type_info` kasutab.
    // `std::type_info` tüüpi objektidel, tüübikirjeldajatel, on selle tabeli kursor.
    // Tüüpikirjeldustele viitavad eespool määratletud C++ EH struktuurid ja need, mida me konstrueerime allpool.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Seda tüüpi kirjeldajat kasutatakse ainult erandi viskamisel.
// Püüdmisosaga tegeleb try intrinsic, mis loob oma TypeDescriptori.
//
// See on hea, kuna MSVC käitustöö kasutab tüübinimes stringide võrdlust, et sobitada TypeDescriptors, mitte osuti võrdsust.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destruktorit kasutatakse juhul, kui C++ kood otsustab erandi jäädvustada ja selle ilma levitamata visata.
// Sisemise try-i püüdmisosa seab erandiobjekti esimese sõna väärtuseks 0, nii et hävitaja jätab selle vahele.
//
// Pange tähele, et x86 Windows kasutab X + X-liikmete funktsioonide jaoks "thiscall"-i kõneskonventsiooni "C"-i vaikekonventsiooni asemel.
//
// Funktsioon erandkopeerimine on siin natuke eriline: seda kutsub esile MSVC käitusaeg try/catch ploki all ja siin genereeritavat panic kasutatakse erandkoopia tulemusena.
//
// Seda kasutab käituse C++ abil erandite hõivamine std::exception_ptr-iga, mida me ei saa toetada, kuna Box<dyn Any>pole kloonitav.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException käivitatakse täielikult selles virnaraamis, nii et pole vaja muul viisil `data`-i kuhja kanda.
    // Sellele funktsioonile edastame lihtsalt virnaosuti.
    //
    // ManuaalDropi on siin vaja, kuna me ei taha, et kerimine lahti lastaks.
    // Selle asemel visatakse see välja kivétel_puhastusega, mille käivitab C++ käitusaeg.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // See ... võib tunduda üllatav ja õigustatult.32-bitises MSVC-s on nende struktuuri vahelised osutid just sellised, osutid.
    // 64-bitises MSVC-s on struktuuride vahelised osutajad siiski `__ImageBase`-i 32-bitiste nihetena väljendatud.
    //
    // Järelikult võime 32-bitises MSVC-s kõik need näpunäited ülaltoodud staatilistes deklareerida.
    // 64-bitises MSVC-s peaksime staatikas väljendama kursorite lahutamist, mida Rust praegu ei võimalda, nii et me ei saa seda tegelikult teha.
    //
    // Parim järgmine asi on siis nende struktuuride täitmine käitamise ajal (paanika on niikuinii juba "slow path").
    // Nii et siin tõlgendame kõik need kursori väljad 32-bitiste täisarvudena ja salvestame seejärel asjakohase väärtuse (aatomiliselt, kuna samaaegne panics võib juhtuda).
    //
    // Tehniliselt teeb käitamisaeg tõenäoliselt nende väljade mitteatoomilise lugemise, kuid teoreetiliselt ei loe nad kunagi *vale* väärtust, nii et see ei tohiks olla liiga halb ...
    //
    // Igal juhul peame põhimõtteliselt midagi sellist tegema, kuni saame staatikas rohkem operatsioone väljendada (ja me ei pruugi seda kunagi teha).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // NULL kasulik koormus tähendab seda, et me jõudsime siia __rust_try püügist (...).
    // See juhtub siis, kui tabatakse muu kui Rust-i erand.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Selle olemasolu eeldab kompilaator (nt see on üks lang-element), kuid kompilaator pole seda tegelikult kunagi kutsunud, kuna __C_specific_handler või_except_handler3 on alati kasutatav isiksusfunktsioon.
//
// Seega on see lihtsalt katkestav nõme.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}