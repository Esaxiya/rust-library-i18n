//! *Emscripten* sihtmärgi lõdvestumine.
//!
//! Kui Rust tavaline Unix-i platvormide jaoks lahtiühendatav rakendus kutsub otse libunwind API-sid, siis Emscriptenis kutsume selle asemel C++ -i lahti keeravaid API-sid.
//! See on lihtsalt otstarbekus, kuna Emscripteni käitusaeg rakendab alati neid API-sid ja ei rakenda libunwind.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// See sobib std::type_info paigutusega C++ -s
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // Siinne juhtiv `\x01`-bait on tegelikult maagiline signaal LLVM-ile, et *mitte* rakendada muud segadust nagu `_`-märgiga eesliide.
    //
    //
    // See sümbol on vt +, mida C++ `std::type_info` kasutab.
    // `std::type_info` tüüpi objektidel, tüübikirjeldajatel, on selle tabeli kursor.
    // Tüüpikirjeldustele viitavad eespool määratletud C++ EH struktuurid ja need, mida me konstrueerime allpool.
    //
    // Pange tähele, et tegelik suurus on suurem kui 3 kasutatavat, kuid meil on vaja vaid vtable-d, et osutada kolmandale elemendile.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info rust_panic klassi jaoks
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // Tavaliselt kasutaksime .as_ptr().add(2)-i, kuid see ei toimi const-kontekstis.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // See ei kasuta tahtlikult tavalist nime segamise skeemi, sest me ei soovi, et C++ saaks toota või püüda Rust panics.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // See on vajalik, kuna C++ kood suudab meie täitmise std::exception_ptr-iga hõivata ja mitu korda uuesti visata, võib-olla isegi teises lõimes.
    //
    //
    caught: AtomicBool,

    // See peab olema Option, kuna objekti eluiga järgib C++ semantikat: kui catch_unwind viib kasti erandist välja, peab ta ikkagi jätma erandi objekti kehtivasse olekusse, kuna selle hävitajat kutsub ikkagi __cxa_end_catch.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try tegelikult annab meile selle struktuuri kohta näpunäite.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // Kuna cleanup() ei ole panic-le lubatud, siis me lihtsalt katkestame.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}