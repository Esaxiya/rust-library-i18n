//! Tugiteek makroautoritele uute makrode määratlemisel.
//!
//! See teek, mille pakub standardjaotus, pakub protseduuriliselt määratletud makrodefinitsioonide liideseid tarbitavaid tüüpe, näiteks funktsioonilaadsed makrod `#[proc_macro]`, makroatribuudid `#[proc_macro_attribute]` ja kohandatud tuletised atribuudid "#[proc_macro_derive]".
//!
//!
//! Lisateavet leiate jaotisest [the book].
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Määrab, kas proc_macro on praegu käimasolevale programmile juurdepääsetavaks tehtud.
///
/// Proc_macro crate on ette nähtud kasutamiseks ainult protseduuriliste makrode rakendamisel.Kõik selle crate funktsioonid panic, kui neid kutsutakse protseduurimakro väljastpoolt, näiteks koostamisskripti või üksustesti või tavalise binaarse Rust abil.
///
/// Arvestades Rust teeke, mis on mõeldud nii makro-kui ka mittekasutamisjuhtumite toetamiseks, pakub `proc_macro::is_available()` paanikavaba viisi tuvastada, kas proc_macro API kasutamiseks vajalik infrastruktuur on praegu saadaval.
/// Tagastab tõese, kui seda kutsutakse protseduurimakro seest, vale, kui seda kutsutakse mõnest muust binaararvust.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Selle crate pakutav põhitüüp, mis tähistab tokens abstraktset voogu või täpsemalt token puude järjestust.
/// Tüüp pakub liideseid nende token puude kordamiseks ja vastupidi hulga token puude kogumiseks ühte voogu.
///
///
/// See on nii `#[proc_macro]`, `#[proc_macro_attribute]` kui ka `#[proc_macro_derive]` definitsioonide sisend ja väljund.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// `TokenStream::from_str`-ist tagastati viga.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Tagastab tühja `TokenStream`, mis ei sisalda token puid.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Kontrollib, kas see `TokenStream` on tühi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Katsed katkestada string tokens-ks ja need tokens-i sõelumiseks token-vooks.
/// Võib ebaõnnestuda mitmel põhjusel, näiteks kui string sisaldab tasakaalustamata eraldajaid või tähemärke, mida keeles pole.
///
/// Kõik parsitud voos olevad tokens saavad `Span::call_site()`-i laiused.
///
/// NOTE: mõned vead võivad `LexError`-i tagastamise asemel põhjustada panics.Me jätame endale õiguse need vead hiljem LexErroriks muuta.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, sild pakub ainult `to_string`-i, selle põhjal rakendab `fmt::Display`-i (nende kahe tavapärase suhte tagurpidi).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Prindib voo token stringina, mis peaks olema kadudeta konverteeritav tagasi samaks token vooguks (moodulid ulatuvad), välja arvatud võimalused `TokenTree: : Group`s, millel on `Delimiter::None` eraldajad ja negatiivsed numbriliitrid.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Prindib token silumiseks mugavas vormis.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Loob token voo, mis sisaldab ühte token puud.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Kogub hulga token puid ühte voogu.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// "flattening" operatsioon token voogude abil kogub token puud mitmest token voost ühte voogu.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Kasutage optimeeritud rakendust if/when võimalik.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// `TokenStream` tüüpi avaliku rakendamise üksikasjad, näiteks iteraatorid.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// TokerStreami TokenTree'i kordaja.
    /// Iteratsioon on "shallow", nt kordaja ei kordu eraldatud rühmadeks ja tagastab terved rühmad token puudena.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` aktsepteerib suvalist tokens ja laieneb sisendit kirjeldavaks `TokenStream`-ks.
/// Näiteks toodab `quote!(a + b)` avaldise, mis hindamisel konstrueerib `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Pakkumine toimub `$`-iga ja toimib nii, et noteerimata terminiks võetakse üks järgmine identiteet.
/// `$` enda tsiteerimiseks kasutage `$$`-i.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Lähtekoodi piirkond koos makro laiendamise teabega.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Loob uue `Diagnostic` antud `message`-ga vahemikus `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Vahemik, mis laheneb makrodefinitsioonisaidil.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Praeguse protseduurimakro esilekutsumise ulatus.
    /// Selle vahemikuga loodud identifikaatorid lahendatakse nii, nagu oleksid need kirjutatud otse makrokõne asukohas (kõne saidi hügieen) ja ka teised makrokõne saidi koodid saaksid neile viidata.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Vahemik, mis esindab `macro_rules`-hügieeni ja mis mõnikord laheneb makrode määratlemise saidil (kohalikud muutujad, sildid, `$crate`) ja mõnikord makrokõne saidil (kõik muu).
    ///
    /// Vahemiku asukoht võetakse kõnesaidilt.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Algne lähtefail, kuhu see vahemik osutab.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` tokens jaoks eelmises makro laienduses, millest `self` loodi, kui see on olemas.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Allika lähtekoodi vahemik, millest `self` loodi.
    /// Kui seda `Span` ei genereeritud muudest makro laiendustest, on tagastusväärtus sama mis `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Hangi selle vahemiku algfailis algava line/column.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Hangi selle vahemiku lähtefaili lõppu line/column.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Loob uue vahemiku `self` ja `other`.
    ///
    /// Tagastab `None`, kui `self` ja `other` pärinevad erinevatest failidest.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Loob uue vahemiku sama line/column-teabega kui `self`, kuid see lahendab sümbolid nii, nagu oleks see `other`-is.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Loob uue vahemiku, millel on sama nime eraldusvõimega käitumine kui `self`-l, kuid `other`-i line/column-teabega.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Võrreldes laiustega, et näha, kas nad on võrdsed.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Tagastab lähteteksti vahemiku taha.
    /// See säilitab algse lähtekoodi, sealhulgas tühikud ja kommentaarid.
    /// See tagastab tulemuse ainult siis, kui ulatus vastab tegelikule lähtekoodile.
    ///
    /// Note: Makro vaadeldav tulemus peaks tuginema ainult tokens-le, mitte sellele lähtetekstile.
    ///
    /// Selle funktsiooni tulemus on parim, mida saab kasutada ainult diagnostikas.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Prindib vahemiku silumiseks mugavas vormis.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Rida-veerupaar, mis tähistab `Span` algust või lõppu.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// 1-indekseeritud rida lähtefailis, millel vahemik algab või lõpeb (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// 0-indekseeritud veerg (UTF-8 tähemärgis) lähtefailis, millel vahemik algab või lõpeb (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Antud `Span` lähtefail.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Saab selle lähtefaili tee.
    ///
    /// ### Note
    /// Kui selle `SourceFile`-ga seotud koodivahemiku on loonud väline makro, ei pruugi see makro olla tegelik tee failisüsteemis.
    /// Kontrollimiseks kasutage nuppu [`is_real`].
    ///
    /// Pange tähele ka seda, et isegi kui `is_real` tagastab `true`, kui `--remap-path-prefix` edastati käsureal, ei pruugi antud tee tegelikult kehtida.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Tagastab `true`, kui see lähtefail on tõeline lähtefail ja seda ei genereeri väline makro laiendamine.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // See on häkkimine, kuni interrate-vahemikud on rakendatud ja meil võib olla väliste makrode abil loodud reaalseid lähtefaile spanide jaoks.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Üksik token või eraldatud token puude jada (nt `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Sulgude eraldajatega ümbritsetud voog token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Identifikaator.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Üks kirjavahemärk ("+", `,`, `$` jne).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Sõnasõnaline tähemärk (`'a'`), string (`"hello"`), number (`2.3`) jne.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Tagastab selle puu siru, delegeerides sisalduva token või eraldatud voo meetodile `span`.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Konfigureerib vahemiku *ainult selle token* jaoks.
    ///
    /// Pange tähele, et kui see token on `Group`, siis see meetod ei konfigureeri iga sisemise tokens vahemikku, see delegeeritakse lihtsalt iga variandi `set_span` meetodile.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Prindib puu token silumiseks mugavas vormis.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Kõigil neist on tuletatud silumisel nimi struktuuritüübis, nii et ärge vaevake täiendava suunamiskihiga
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, sild pakub ainult `to_string`-i, selle põhjal rakendab `fmt::Display`-i (nende kahe tavapärase suhte tagurpidi).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Prindib puu token stringina, mis peaks olema kadudeta konverteeritav tagasi samaks token puuks (moodulid ulatuvad), välja arvatud võimalused `TokenTree: : Group`s, millel on `Delimiter::None` eraldajad ja negatiivsed numbriliitrid.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Piiratud token voog.
///
/// `Group` sisaldab sisemiselt `TokenStream`-i, mis on ümbritsetud piirajatega.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Kirjeldab, kuidas eraldatakse token puude jada.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Kaudne eraldaja, mis võib näiteks ilmuda "macro variable" `$var`-st pärineva tokens ümber.
    /// Oluline on säilitada operaatori prioriteedid sellistel juhtudel nagu `$var * 3`, kus `$var` on `1 + 2`.
    /// Kaudsed eraldajad ei pruugi token voo edasi-tagasi stringi kaudu ellu jääda.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Loob uue eraldusvõime ja voo token abil uue `Group`.
    ///
    /// See konstruktor määrab selle rühma vahemikuks `Span::call_site()`.
    /// Vahemiku muutmiseks võite kasutada allpool toodud meetodit `set_span`.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Tagastab selle `Group` eraldaja
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Tagastab selles `Group`-is eraldatud tokens-i `TokenStream`.
    ///
    /// Pange tähele, et tagastatav voog token ei sisalda ülaltoodud eraldajat.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Tagastab selle token voo eraldajate vahemiku, mis hõlmab kogu `Group`-i.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Tagastab selle grupi algusjoonele osutava vahemiku.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Tagastab vahemiku, mis osutab selle rühma lõpp-eraldajale.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Konfigureerib selle grupi eraldajate vahemiku, kuid mitte selle sisemise tokens.
    ///
    /// See meetod **ei määra** kõigi selle rühma hõlmatud sisemiste tokens vahemikku, vaid seab eraldaja tokens vahemiku ainult `Group` tasemele.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, sild pakub ainult `to_string`-i, selle põhjal rakendab `fmt::Display`-i (nende kahe tavapärase suhte tagurpidi).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Prindib rühma stringina, mis peaks olema kadudeta konverteeritav tagasi samasse gruppi (moodulivahemikud), välja arvatud võimalused `TokenTree: : Group'id `Delimiter::None` eraldajatega.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` on üksik kirjavahemärk nagu `+`, `-` või `#`.
///
/// Mitme tähemärgiga operaatorid, nagu `+=`, on kujutatud kui kaks `Punct`-i eksemplari, mille `Spacing`-i erinevad vormid on tagastatud.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Kas `Punct`-le järgneb kohe teine `Punct` või järgneb teine token või tühimik.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// nt `+` on `Alone` `+ =`, `+ident` või `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// nt `+` on `Joint` `+=` või `'#`.
    /// Lisaks saab üksikpakkumine `'` liituda identifikaatoritega, et moodustada `'ident` eluaeg.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Loob antud tähemärgist ja tühikutest uue `Punct`.
    /// `ch` argument peab olema keele poolt lubatud kehtiv kirjavahemärk, vastasel juhul funktsioon panic.
    ///
    /// Tagastatava `Punct`-i vaikeväärtus on `Span::call_site()`, mida saab täiendavalt konfigureerida allpool toodud meetodiga `set_span`.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Tagastab selle kirjavahemärgi väärtuse `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Tagastab selle kirjavahemärgi tühiku, näidates, kas sellele järgneb kohe voos token teine `Punct`, nii et neid saab potentsiaalselt kombineerida mitme tähemärgi operaatoriks (`Joint`) või sellele järgneb mõni muu token või tühimik (`Alone`), nii et operaator on kindlasti lõppenud.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Tagastab selle kirjavahemärgi vahemiku.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigureerige selle kirjavahemärgi vahemik.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, sild pakub ainult `to_string`-i, selle põhjal rakendab `fmt::Display`-i (nende kahe tavapärase suhte tagurpidi).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Prindib kirjavahemärgi stringina, mis peaks olema kadudeta teisendatav samaks tähemärgiks.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Identifikaator (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Loob uue `Ident` koos antud `string` ja määratud `span`-iga.
    /// `string` argument peab olema keele poolt lubatud kehtiv identifikaator (sealhulgas märksõnad, nt `self` või `fn`).Vastasel juhul on funktsioon panic.
    ///
    /// Pange tähele, et `span`, praegu rustc, konfigureerib selle identifikaatori hügieeniteabe.
    ///
    /// Sellest hetkest alates valib `Span::call_site()` sõnaselgelt "call-site"-i hügieeni, mis tähendab, et selle vahemikuga loodud identifikaatorid lahendatakse nii, nagu oleksid need kirjutatud otse makrokõne asukohas, ja muud makrokõne saidi koodid saavad viidata ka neid.
    ///
    ///
    /// Hilisemad ajavahemikud nagu `Span::def_site()` võimaldavad lubada "definition-site"-i hügieeni, mis tähendab, et selle vahemikuga loodud identifikaatorid lahendatakse makrode definitsiooni asukohas ja muud makrokõne saidi koodid ei saa neile viidata.
    ///
    /// Hügieeni praeguse tähtsuse tõttu nõuab see konstruktor, erinevalt teistest tokens-st, ehitamisel `Span`-i määramist.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Sama mis `Ident::new`, kuid loob toore identifikaatori (`r#ident`).
    /// `string` argument on keele poolt lubatud kehtiv identifikaator (sealhulgas märksõnad, nt `fn`).
    /// Märksõnad, mis on kasutatavad teesegmentides (nt
    /// `self`, "super") ei toetata ja see põhjustab panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Tagastab selle `Ident` vahemiku, hõlmates kogu [`to_string`](Self::to_string) tagastatud stringi.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigureerib selle `Ident` vahemiku, muutes selle hügieenikonteksti.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, sild pakub ainult `to_string`-i, selle põhjal rakendab `fmt::Display`-i (nende kahe tavapärase suhte tagurpidi).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Prindib identifikaatori stringina, mis peaks olema kadudeta teisendatav samaks identifikaatoriks.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Sõnasõnaline string (`"hello"`), baitide string (`b"hello"`), märk (`'a'`), baitmärk (`b'a'`), täis-või ujukomaarv koos sufiksiga või ilma ("1", `1u8`, `2.3`, `2.3f32`).
///
/// Loogilised literaalid nagu `true` ja `false` ei kuulu siia, nad on `Ident`id.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Loob uue sufiksiga täisarvulise literaali, millel on määratud väärtus.
        ///
        /// See funktsioon loob sellise täisarvu nagu `1u32`, kus määratud täisarv on token esimene osa ja lõpus on ka integraal.
        /// Negatiivsetest arvudest loodud literaalid ei pruugi edasi liikuda edasi-tagasi `TokenStream`-i või stringide kaudu ning need võib jagada kaheks tokens-ks (`-` ja positiivne literaal).
        ///
        ///
        /// Selle meetodi abil loodud literaalidel on vaikimisi vahemik `Span::call_site()`, mida saab konfigureerida allpool toodud meetodiga `set_span`.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Loob uue, lisamata väärtusega täisarvulise literaali.
        ///
        /// See funktsioon loob täisarvu nagu `1`, kus määratud täisarv on token esimene osa.
        /// Sellel token-l pole järelliidet määratud, mis tähendab, et sellised invokatsioonid nagu `Literal::i8_unsuffixed(1)` on samaväärsed `Literal::u32_unsuffixed(1)`-ga.
        /// Negatiivsetest numbritest loodud sõnasõnalised ei pruugi `TokenStream`-i või stringide kaudu toimuvaid rrippe üle elada ning need võib jagada kaheks tokens-ks (`-` ja positiivne literaal).
        ///
        ///
        /// Selle meetodi abil loodud literaalidel on vaikimisi vahemik `Span::call_site()`, mida saab konfigureerida allpool toodud meetodiga `set_span`.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Loob uue kinnistamata ujukoma literaali.
    ///
    /// See konstruktor sarnaneb sarnastega nagu `Literal::i8_unsuffixed`, kus ujuki väärtus emiteeritakse otse token-i, kuid ei kasutata järelliidet, nii et hiljem võib kompilaatoris järeldada, et see on `f64`.
    ///
    /// Negatiivsetest numbritest loodud sõnasõnalised ei pruugi `TokenStream`-i või stringide kaudu toimuvaid rrippe üle elada ning need võib jagada kaheks tokens-ks (`-` ja positiivne literaal).
    ///
    /// # Panics
    ///
    /// See funktsioon nõuab, et määratud ujuk oleks piiratud, näiteks kui see on lõpmatus või NaN, siis see funktsioon on panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Loob uue sufiksiga ujukoma literaali.
    ///
    /// See konstruktor loob sellise litraali nagu `1.0f32`, kus määratud väärtus on token eelnev osa ja `f32` on token järelliide.
    /// Selle token järeldus on kompilaatoris alati `f32`.
    /// Negatiivsetest numbritest loodud sõnasõnalised ei pruugi `TokenStream`-i või stringide kaudu toimuvaid rrippe üle elada ning need võib jagada kaheks tokens-ks (`-` ja positiivne literaal).
    ///
    ///
    /// # Panics
    ///
    /// See funktsioon nõuab, et määratud ujuk oleks piiratud, näiteks kui see on lõpmatus või NaN, siis see funktsioon on panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Loob uue kinnistamata ujukoma literaali.
    ///
    /// See konstruktor sarnaneb sarnastega nagu `Literal::i8_unsuffixed`, kus ujuki väärtus emiteeritakse otse token-i, kuid ei kasutata järelliidet, nii et hiljem võib kompilaatoris järeldada, et see on `f64`.
    ///
    /// Negatiivsetest numbritest loodud sõnasõnalised ei pruugi `TokenStream`-i või stringide kaudu toimuvaid rrippe üle elada ning need võib jagada kaheks tokens-ks (`-` ja positiivne literaal).
    ///
    /// # Panics
    ///
    /// See funktsioon nõuab, et määratud ujuk oleks piiratud, näiteks kui see on lõpmatus või NaN, siis see funktsioon on panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Loob uue sufiksiga ujukoma literaali.
    ///
    /// See konstruktor loob sellise litraali nagu `1.0f64`, kus määratud väärtus on token eelnev osa ja `f64` on token järelliide.
    /// Selle token järeldus on kompilaatoris alati `f64`.
    /// Negatiivsetest numbritest loodud sõnasõnalised ei pruugi `TokenStream`-i või stringide kaudu toimuvaid rrippe üle elada ning need võib jagada kaheks tokens-ks (`-` ja positiivne literaal).
    ///
    ///
    /// # Panics
    ///
    /// See funktsioon nõuab, et määratud ujuk oleks piiratud, näiteks kui see on lõpmatus või NaN, siis see funktsioon on panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// String sõna otseses mõttes.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Tähemärkide otsene.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Baidistringi sõnasõnaline.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Tagastab selle literaali hõlmava vahemiku.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigureerib selle literaali seotud vahemiku.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Tagastab `Span`, mis on `self.span()` alamhulk, mis sisaldab ainult vahemikus `range` olevaid lähtekäibeid.
    /// Tagastab `None`, kui võimalik kärbitud vahemik jääb väljapoole `self` piire.
    ///
    // FIXME(SergioBenitez): kontrollige, kas baitide vahemik algab ja lõpeb allika UTF-8 piiril.
    // vastasel juhul on tõenäoline, et lähteteksti printimisel tekib panic mujal.
    // FIXME(SergioBenitez): kasutaja ei saa kuidagi teada, millega `self.span()` tegelikult kaardistab, nii et seda meetodit saab praegu kutsuda ainult pimesi.
    // Näiteks `to_string()` tähemärgi 'c' korral tagastab "'\u{63}'";kasutaja ei saa kuidagi teada, kas lähtetekst oli 'c' või oli see '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) midagi sarnast `Option::cloned`-ga, kuid `Bound<&T>`-i jaoks.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, sild pakub ainult `to_string`-i, selle põhjal rakendab `fmt::Display`-i (nende kahe tavapärase suhte tagurpidi).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Prindib literaali stringina, mis peaks olema kadudeta konverteeritav tagasi samasse literaali (välja arvatud võimalik ümardamine ujukoma literaalide puhul).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Jälgitud juurdepääs keskkonnamuutujatele.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Too keskkonnamuutuja ja lisage see sõltuvusteabe loomiseks.
    /// Kompilaatorit käivitav järk-järgusüsteem teab, et muutujale oli kompileerimise ajal juurde pääsenud, ja saab muutmise väärtuse muutumisel järku uuesti käivitada.
    ///
    /// Lisaks sõltuvuse jälgimisele peaks see funktsioon olema samaväärne standardkogu `env::var`-ga, välja arvatud see, et argument peab olema UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}