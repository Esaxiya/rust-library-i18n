use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // हाम्रो `#[assert_instr]` एनोटेसनहरू बताउन प्रयोग गरियो कि सबै सिम्ड ईन्टरिक्सहरू उनीहरूको कोडजेन परीक्षण गर्नका लागि उपलब्ध छन्, किनकि केहि थप `-Ctarget-feature=+unimplemented-simd128` पछाडि gated छन् जसको अहिले `#[target_feature]` मा कुनै समान छैन।
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}