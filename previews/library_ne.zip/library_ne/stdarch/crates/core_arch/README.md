`core::arch` - Rust को कोर लाइब्रेरी आर्किटेक्चर-विशिष्ट इंटिरिक्स
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` मोड्युलले आर्किटेक्चर-निर्भर ईन्ट्रिन्सिक्स (उदाहरण सिमडी) लागू गर्दछ।

# Usage 

`core::arch` `libcore` को भागको रूपमा उपलब्ध छ र यो `libstd` द्वारा पुन: निर्यात गरिएको छ।यो crate मार्फत भन्दा `core::arch` वा `std::arch` को माध्यम बाट प्रयोग गर्न मन पर्छ।
अस्थिर सुविधाहरू प्राय: राति Rust मा `feature(stdsimd)` मार्फत उपलब्ध हुन्छन्।

यो crate मार्फत `core::arch` प्रयोग गर्न रातको Rust आवश्यक पर्दछ, र यसले प्राय: विच्छेद गर्न सक्दछ (र गर्छ)।केवल केसहरू जसमा तपाईले यसलाई crate मार्फत प्रयोग गर्न विचार गर्नुपर्छ।

* यदि तपाईंले `core::arch` आफैलाई पुन: कम्पाइल गर्नु आवश्यक छ, उदाहरणका लागि, विशेष लक्षित-सुविधाहरू सक्षम पारिएका जुन `libcore`/`libstd` का लागि सक्षम छैनन्।
Note: यदि तपाईं यसलाई एक गैर-मानक लक्ष्यका लागि पुन: कम्पाइल गर्न आवश्यक छ भने, कृपया `xargo` प्रयोग गरेर `libcore`/`libstd` लाई पुन: कम्पाईल गर्नुहोस् यो crate प्रयोग गर्नुको सट्टा।
  
* केही सुविधाहरू प्रयोग गर्दै जुन अस्थिर Rust सुविधाहरूको पछाडि पनि उपलब्ध नहुन सक्छ।हामी यसलाई न्यूनतम राख्न प्रयास गर्दछौं।
यदि तपाईंलाई यी सुविधाहरू मध्ये केही प्रयोग गर्न आवश्यक छ भने, कृपया एउटा मुद्दा खोल्नुहोस् ताकि हामी तिनीहरूलाई रातको Rust मा पर्दाफाश गर्न सक्दछौं र तपाईं तिनीहरूलाई त्यहाँबाट प्रयोग गर्न सक्नुहुनेछ।

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` मुख्य रूपमा दुबै एमआईटी इजाजतपत्र र Apache लाइसेन्स (संस्करण 2.0) को शर्त अन्तर्गत वितरित छ, विभिन्न BSD-जस्तो इजाजतपत्र द्वारा कभर अंशहरूको साथ।

विवरणको लागि LICENSE-APachE, र LICENSE-MIT हेर्नुहोस्।

# Contribution

जब सम्म तपाईं स्पष्ट रूपमा बताउनुहुन्न, तपाईं द्वारा `core_arch` मा समावेशका लागि जानाजानी पेश गरिएको कुनै योगदान, Apache-2.0 लाईसेन्समा परिभाषित गरे अनुसार, कुनै अतिरिक्त नियम वा सर्तहरू बिना, माथिको रूपमा दोहोरो इजाजतपत्र हुनेछ।


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












