#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// [`prefetch`](fn._prefetch.html) हेर्नुहोस्।
pub const _PREFETCH_READ: i32 = 0;

/// [`prefetch`](fn._prefetch.html) हेर्नुहोस्।
pub const _PREFETCH_WRITE: i32 = 1;

/// [`prefetch`](fn._prefetch.html) हेर्नुहोस्।
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// [`prefetch`](fn._prefetch.html) हेर्नुहोस्।
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// [`prefetch`](fn._prefetch.html) हेर्नुहोस्।
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// [`prefetch`](fn._prefetch.html) हेर्नुहोस्।
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// क्यास लाईन फेच गर्नुहोस् जुन दिइएको `p` र `locality` प्रयोग गरी ठेगाना `p` समावेश गर्दछ।
///
/// `rw` मध्ये एक हुनुपर्दछ:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): प्रिफेच पढ्नको लागि तयारी गर्दैछ।
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): प्रिफेच लेख्नको लागि तयारी गर्दैछ।
///
/// `locality` मध्ये एक हुनुपर्दछ:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): स्ट्रिमि or वा गैर-टेम्पोरल प्रिफेच, डाटाको लागि जुन एक पटक मात्र प्रयोग गरिन्छ।
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): स्तर c क्यासमा ल्याउनुहोस्।
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): स्तर २ क्यासमा ल्याउनुहोस्।
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): स्तर १ क्याचमा ल्याउनुहोस्।
///
/// प्रिफेच मेमोरी निर्देशनहरूले मेमोरी प्रणालीमा संकेत गर्दछ जुन निर्दिष्ट ठेगानाबाट मेमोरी पहुँच गर्दछ future नजिकै हुने सम्भावना छ।
/// मेमोरी प्रणालीले त्यस्तो कार्यहरू गरेर प्रतिक्रिया दिन सक्छ जुन मेमोरी पहुँचको गतिमा अपेक्षित हुन्छ जब ती घटनाहरू हुन्छन्, जस्तै एक वा धेरै क्यासहरूमा निर्दिष्ट ठेगाना प्रीलोड गर्ने जस्ता।
///
/// किनकि यी संकेतहरू केवल सints्केत मात्र हुन्, यो विशिष्ट CPU को लागि कुनै वा सबै प्रिफेच निर्देशनहरू NOP को रूपमा व्यवहार गर्न मान्य हुन्छ।
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // हामी `cache type` =1 (डाटा क्याच) को साथ `llvm.prefetch` इन्स्ट्रिन्सिक प्रयोग गर्दछौं।
    // `rw` र `strategy` प्रकार्य प्यारामिटरमा आधारित छन्।
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}