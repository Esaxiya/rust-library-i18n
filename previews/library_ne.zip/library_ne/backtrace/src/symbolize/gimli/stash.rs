// मात्र अहिले Linux मा प्रयोग गरीएको छ, त्यसैले अन्यत्र डेड कोड अनुमति दिनुहोस्
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// बाइट बफरहरूको लागि एक साधारण क्षेत्र आवंटक।
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// निर्दिष्ट आकार को एक बफर आवंटित गर्दछ र यसलाई एक म्यूटेबल सन्दर्भ फिर्ता।
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // सुरक्षा: यो एकमात्र प्रकार्य हो कि कहिल्यै एक म्यूटेबल निर्माण गर्दछ
        // `self.buffers` मा सन्दर्भ।
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // सुरक्षा: हामी कहिले पनि तत्वहरू `self.buffers` बाट हटाउँदैनौं, त्यसैले एउटा सन्दर्भ
        // कुनै पनि बफर भित्र डाटा मा `self` गर्दछ सम्म बाँच्नेछ।
        &mut buffers[i]
    }
}