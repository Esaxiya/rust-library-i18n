use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// ठेगानालाई प्रतीकमा समाधान गर्नुहोस्, निर्दिष्ट बन्द गर्न प्रतीकलाई पास गर्दै।
///
/// यस प्रकार्यले दिइएका ठेगानाहरूमा ती स्थानहरूमा स्थानीय प्रतीक तालिका, गतिशील प्रतीक तालिका, वा DWARF डिबग जानकारी (सक्रिय कार्यान्वयनमा निर्भर गर्दै) उत्पन्न गर्न प्रतीकहरू पत्ता लगाउँदछ।
///
///
/// रिजोलुसन गर्न सकिएन भने बन्द गर्न सकिदैन, र यो ईन्लाइन कार्यहरूको अवस्थामा एक भन्दा बढि पनि कल गर्न सकिन्छ।
///
/// प्राप्त प्रतीकहरूले निर्दिष्ट `addr` मा कार्यान्वयन प्रतिनिधित्व गर्दछ, त्यो ठेगानाको लागि file/line जोडी फिर्ता (यदि उपलब्ध छ भने)।
///
/// नोट गर्नुहोस् कि यदि तपाईंसँग `Frame` छ भने यसलाई `resolve_frame` प्रकार्यको सट्टा प्रयोग गर्न सिफारिस गरिन्छ।
///
/// # आवश्यक सुविधाहरू
///
/// यस प्रकार्यलाई सक्षम पार्न `backtrace` crate को `std` सुविधा चाहिन्छ, र `std` सुविधा पूर्वनिर्धारितद्वारा सक्षम पारिएको छ।
///
/// # Panics
///
/// यो प्रकार्य panic कहिले पनि गर्न कोसिस गर्दछ, तर यदि `cb` panics प्रदान गर्दछ भने केहि प्लेटफर्मले एक डबल panic प्रक्रिया रद्द गर्न बाध्य पार्दछ।
/// केही प्लेटफर्मले सी लाइब्रेरी प्रयोग गर्दछ जुन आन्तरिक रूपमा कलब्याकहरू प्रयोग गर्दछ जुन अवाउन्ड हुन सक्दैन, त्यसैले `cb` बाट आतंकित गर्दा प्रक्रिया परित्याग ट्रिगर गर्न सक्दछ।
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // केवल शीर्ष फ्रेममा हेर्नुहोस्
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// पहिलेको क्याप्चर फ्रेमलाई प्रतीकमा समाधान गर्नुहोस्, निर्दिष्ट क्लोजरमा प्रतीकलाई पार गर्दै।
///
/// यो फ्याक्टिनले `resolve` को रूपमा कार्य गर्दछ जुन बाहेक यसले `Frame` लिन्छ ठेगानाको सट्टा तर्कको रूपमा।
/// यसले backtracing को केहि प्लेटफर्म कार्यान्वयन गर्न को लागी अधिक सही प्रतीक जानकारी या उदाहरण को लागी इनलाइन फ्रेम को बारे मा जानकारी प्रदान गर्न को लागी अनुमति दिन सक्छ।
///
/// यदि तपाईं सक्नुहुन्छ भने यो प्रयोग गर्न सिफारिस गरिन्छ।
///
/// # आवश्यक सुविधाहरू
///
/// यस प्रकार्यलाई सक्षम पार्न `backtrace` crate को `std` सुविधा चाहिन्छ, र `std` सुविधा पूर्वनिर्धारितद्वारा सक्षम पारिएको छ।
///
/// # Panics
///
/// यो प्रकार्य panic कहिले पनि गर्न कोसिस गर्दछ, तर यदि `cb` panics प्रदान गर्दछ भने केहि प्लेटफर्मले एक डबल panic प्रक्रिया रद्द गर्न बाध्य पार्दछ।
/// केही प्लेटफर्मले सी लाइब्रेरी प्रयोग गर्दछ जुन आन्तरिक रूपमा कलब्याकहरू प्रयोग गर्दछ जुन अवाउन्ड हुन सक्दैन, त्यसैले `cb` बाट आतंकित गर्दा प्रक्रिया परित्याग ट्रिगर गर्न सक्दछ।
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // केवल शीर्ष फ्रेममा हेर्नुहोस्
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// स्ट्याक फ्रेमबाट आईपी मानहरू सामान्यतया निर्देशन १0000 पछि * कल पछि हुन्छ जुन वास्तविक स्ट्याक ट्रेस हो।
// यसको प्रतीकको कारणले filename/line नम्बर अगाडि हुन र शून्यमा यदि यो प्रकार्यको अन्त्य नजिक छ भने।
//
// यो मूल रूपमा सँधै सबै प्लेटफर्महरूमा देखा पर्दछ, त्यसैले हामी यसलाई सँधै आईपीबाट घटाउँछौं यसलाई सुल्झाउनुको सट्टा अघिल्लो कल निर्देशनमा समाधान गर्नको लागि।
//
//
// आदर्श रूपमा हामी यो गर्दैनौं।
// आदर्श रूपमा हामी यहाँ `resolve` एपीआई को कलरहरू मैन्युअली -1 गर्न को लागी आवश्यक छ र खाता कि तिनीहरू *अघिल्लो* निर्देशन को लागी स्थान जानकारी चाहान्छन्, वर्तमान होइन।
// यदि हामी वास्तवमै अर्को निर्देशन वा हालको ठेगाना हो भने वास्तवमा हामी `Frame` मा खुलासा गर्छौं।
//
// अहिलेको लागि यो एक धेरै महत्वपूर्ण चिन्ता हो त्यसैले हामी केवल आन्तरिक रूपमा सँधै एउटा घटाउँछौं।
// उपभोक्ताहरूले काम गरिरहनुपर्दछ र राम्रो राम्रो परिणामहरू प्राप्त गर्दै हुनुपर्दछ, त्यसैले हामी प्रशस्त हुनुपर्दछ।
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// `resolve` को रूपमा उही, असुरक्षितको रूपमा यो अनइन्क्रोनाइज गरिएको छ।
///
/// यो प्रकार्यको समक्रमण ग्यारेन्टीहरू छैन तर यो crate को `std` सुविधा कम्पाइल नहुँदा उपलब्ध हुन्छ।
/// अधिक कागजात र उदाहरणका लागि `resolve` प्रकार्य हेर्नुहोस्।
///
/// # Panics
///
/// `cb` Panicking मा सावधानहरूको लागि `resolve` मा जानकारी हेर्नुहोस्।
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// `resolve_frame` को रूपमा उही, असुरक्षितको रूपमा यो अनइन्क्रोनाइज गरिएको छ।
///
/// यो प्रकार्यको समक्रमण ग्यारेन्टीहरू छैन तर यो crate को `std` सुविधा कम्पाइल नहुँदा उपलब्ध हुन्छ।
/// अधिक कागजात र उदाहरणका लागि `resolve_frame` प्रकार्य हेर्नुहोस्।
///
/// # Panics
///
/// `cb` Panicking मा सावधानहरूको लागि `resolve_frame` मा जानकारी हेर्नुहोस्।
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// एक trait एक फाईलमा प्रतीकको रिजोलुसन प्रतिनिधित्व गर्दै।
///
/// यो trait `backtrace::resolve` प्रकार्यलाई बन्द गर्न trait वस्तुको रूपमा उत्पन्न भयो, र यो वस्तुतः पठाइएको छ किनकि यो अज्ञात छ जुन कार्यान्वयन यसको पछाडि छ।
///
///
/// प्रतीकले प्रकार्यको बारेमा प्रासंगिक जानकारी दिन सक्दछ, उदाहरणका लागि नाम, फाइलनाम, लाइन नम्बर, सटीक ठेगाना, आदि।
/// सबै जानकारीहरू सँधै प्रतीकमा उपलब्ध हुँदैन, यद्यपि सबै विधिहरू `Option` फर्काउँछन्।
///
///
pub struct Symbol {
    // TODO: यो जीवनकाल बाध्य गर्न अन्तमा `Symbol` मा जारी गर्न आवश्यक छ,
    // तर त्यो हाल एक ब्रेकिंग परिवर्तन हो।
    // अहिलेको लागि यो सुरक्षित छ किनकि `Symbol` मात्र सन्दर्भ द्वारा कहिले बाहिर पठाइन्छ र क्लोन गर्न सकिदैन।
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// यस प्रकार्यको नाम फर्काउँछ।
    ///
    /// फिर्ता गरिएको संरचना प्रतीक नामको बारेमा बिभिन्न गुणहरू प्रश्न गर्न प्रयोग गर्न सकिन्छ।
    ///
    ///
    /// * `Display` कार्यान्वयनले demangled प्रतीक प्रिन्ट गर्दछ।
    /// * प्रतीकको कच्चा `str` मान पहुँच गर्न सकिन्छ (यदि यो मान्य utf-8 हो)।
    /// * प्रतीक नामको लागि कच्चा बाइटहरू पहुँच गर्न सकिन्छ।
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// यस प्रकार्यको सुरू ठेगाना फर्काउँछ।
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// स्लाइसको रूपमा कच्चा फाइलनाम फर्काउँछ।
    /// यो मुख्यतया `no_std` वातावरण को लागी उपयोगी छ।
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// यस प्रतीक हाल कार्यान्वयन भइरहेको ठाउँमा स्तम्भ संख्या फर्काउँछ।
    ///
    /// केवल जिमिलले हाल यहाँ एक मान प्रदान गर्दछ र तब पनि यदि `filename` ले `Some` फर्काउँछ, र त्यसैले यो परिणाम स्वरूप उस्तै समान चेतावनीहरूको अधीनमा हुन्छ।
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// यस स symbol्केत हाल कार्यान्वयन भइरहेको ठाउँमा लाइन नम्बर फर्काउँछ।
    ///
    /// यो फिर्ती मान सामान्यतया `Some` हो यदि `filename` `Some` फर्काउँछ, र फलस्वरूप उस्तै समान चेतावनीहरूको अधीनमा छ।
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// फाइलको नाम फर्काउँदछ जहाँ यो प्रकार्य परिभाषित गरिएको थियो।
    ///
    /// यो हालै मात्र उपलब्ध हुन्छ जब libbacktrace वा gimli प्रयोग भइरहेको छ (उदाहरण:
    /// unix प्लेटफर्महरू अन्य) र जब बाइनरी डिबगिनफोसँग कम्पाइल हुन्छ।
    /// यदि यी मध्ये कुनै पनि एक सर्त पूरा गरिएको छैन भने सम्भवतः `None` फिर्ता हुन्छ।
    ///
    /// # आवश्यक सुविधाहरू
    ///
    /// यस प्रकार्यलाई सक्षम पार्न `backtrace` crate को `std` सुविधा चाहिन्छ, र `std` सुविधा पूर्वनिर्धारितद्वारा सक्षम पारिएको छ।
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // सायद पार्स गरिएको C++ प्रतीक, यदि Rust को रूपमा मंगलबार प्रतीक पार्सिंग असफल भयो भने।
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // निश्चित गर्नुहोस् कि यो शून्य आकारको राख्नुहोस्, ताकि `cpp_demangle` सुविधा असक्षम हुँदा कुनै लागत हुँदैन।
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// डिमng्गल गरिएको नाम, कच्चा बाइट्स, कच्चा स्ट्रिंग, इत्यादिलाई एर्गोनोमिक एक्सेसरहरू प्रदान गर्न प्रतीकको नामको वरिपरि एउटा आवरण।
///
// `cpp_demangle` सुविधा सक्षम नहुँदाको लागि मृत कोडलाई अनुमति दिनुहोस्।
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// कच्चा अन्तर्निहित बाइट्सबाट नयाँ प्रतीकको नाम सिर्जना गर्दछ।
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// `str` को रूपमा कच्चा (mangled) प्रतीक नाम फिर्ता गर्दछ यदि प्रतीक मान्य utf-8 हो।
    ///
    /// `Display` कार्यान्वयन प्रयोग गर्नुहोस् यदि तपाईं demangled संस्करण चाहनुहुन्छ भने।
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// बाइट्सको सूचीको रूपमा कच्चा प्रतीकको नाम फर्काउँछ
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // यो प्रिन्ट गर्न सक्दछ यदि डिमेन्ग्ल्ड प्रतीक वास्तवमा मान्य छैन, त्यसैले त्रुटिलाई यहाँ बाहिरी रूपमा प्रचार नगरी होन्डल गर्नुहोस्।
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// पुन: दावी गर्न कोशिस गर्नुहोस् कि क्याच मेमोरी ठेगानाहरू प्रतीकहरूको रूपमा प्रयोग गर्‍यो।
///
/// यस विधिले कुनै पनि वैश्विक डेटा संरचनाहरू जारी गर्ने प्रयास गर्दछ जुन अन्यथा विश्वव्यापी वा थ्रेडमा क्यास गरिएको छ जुन सामान्यतया पार्स गरिएको DWARF जानकारी वा समान प्रतिनिधित्व गर्दछ।
///
///
/// # Caveats
///
/// जबकि यो समारोह सँधै उपलब्ध छ यो वास्तवमा सबै कार्यान्वयन मा केहि पनि गर्दैन।
/// Dbghelp वा libbacktrace जस्तै लाइब्रेरीहरु राज्य deallocon र आवंटित मेमोरी को प्रबन्धन को लागी सुविधा प्रदान गर्दैन।
/// अहिलेको crate को `gimli-symbolize` सुविधा मात्र फिचर हो जहाँ यस प्रकार्यको कुनै प्रभाव छ।
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}