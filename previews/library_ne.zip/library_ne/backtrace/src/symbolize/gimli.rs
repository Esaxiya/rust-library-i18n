//! `gimli` crate crates.io मा प्रतीकको लागि समर्थन
//!
//! यो Rust को लागी डिफल्ट प्रतीक कार्यान्वयन हो।

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'स्थिर जीवनकाल स्वयं-रेफरेन्टल स्ट्रिक्टको लागि समर्थनको अभावको वरिपरि ह्याक गर्न झूट हो।
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // 'स्थिर जीवनकालमा रूपान्तरण गर्नुहोस् किनकि प्रतीकहरूले केवल `map` र `stash` लाई orrowण लिनुपर्दछ र हामी त्यसलाई तल संरक्षित गर्दैछौं।
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Windows मा नेटिभ पुस्तकालयहरू लोड गर्नका लागि, यहाँ विभिन्न रणनीतिहरूको लागि rust-lang/rust#71060 मा केहि छलफल हेर्नुहोस्।
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW पुस्तकालयहरू हाल ASLR (rust-lang/rust#16514) समर्थन गर्दैन, तर DLL अझै पनी स्थानमा वरिपरि स्थान परिवर्तन गर्न सकिन्छ।
            // यस्तो देखिन्छ कि डिबग जानकारीमा ठेगानाहरू सबै यस रूपमा हुन्-यदि यो लाइब्रेरी यसको "image base" मा लोड गरिएको थियो, जुन यसको COFF फाईल हेडरको क्षेत्र हो।
            // किनकि डिबगइनफोले लिस्टिंगमा यस्तो देखिन्छ कि हामी प्रतीक तालिका पार्स गर्दछौं र ठेगानाहरू भण्डार गर्दछौं मानौं पुस्तकालय "image base" मा पनि लोड भयो।
            //
            // यद्यपि "image base" मा पुस्तकालय लोड हुन सक्दैन।
            // (सम्भवतः त्यहाँ केहि अरू लोड हुन सक्छ?) यो जहाँ `bias` क्षेत्र खेल मा आउँछ, र हामीले यहाँ `bias` को मान निकाल्नु पर्छ।दुर्भाग्यवस यद्यपि यो लोड मोड्युलबाट कसरी प्राप्त गर्ने भन्ने बारे स्पष्ट छैन।
            // हामीसँग के छ, तथापि, वास्तविक लोड ठेगाना (`modBaseAddr`) हो।
            //
            // अहिलेको लागि एक कप-आउटको रूपमा हामीले फाईललाई म्याम्याप गर्दछौं, हेडर जानकारी पढ्दछौं, त्यसपछि एमएमएप ड्रप गर्दछौं।यो बेकार छ किनकि हामी सम्भवत mmap पछि खोल्न सक्छौं, तर यसले अहिलेको लागि राम्ररी काम गर्नुपर्छ।
            //
            // एकचोटि हामीसँग `image_base` (इच्छित लोड स्थान) र `base_addr` (वास्तविक लोड स्थान) हामी `bias` (वास्तविक र इच्छित बीचको भिन्नता) भर्न सक्दछौं र तब प्रत्येक खण्डको ब्यबहारित ठेगाना `image_base` हुन्छ किनकि फाइलले भनेको छ।
            //
            //
            // अहिलेको लागि यस्तो देखिन्छ कि ELF/MachO भन्दा फरक हामी प्रत्येक लाइब्रेरीको एक खण्डसँग गर्न सक्दछौं, X०1X सम्पूर्ण आकारको रूपमा प्रयोग गरेर।
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS माच-O फाइल ढाँचा प्रयोग गर्दछ र DYLD-विशिष्ट एपीआईहरू प्रयोग गर्दछ देशी पुस्तकालयहरूको सूची लोड गर्न जुन अनुप्रयोगको हिस्सा हुन्।
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // यस पुस्तकालयको नाम ल्याउनुहोस् जुन योसँग लोड गर्ने मार्गसँग मिल्दो छ।
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // यस पुस्तकालयको छवि हेडर लोड गर्नुहोस् र `object` लाई सबै लोड आदेशहरू पार्स गर्न प्रतिनिधि दिनुहोस् ताकि हामी यहाँ रहेका सबै खण्डहरू पत्ता लगाउन सक्दछौं।
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // खण्डहरूमा इटरेरेट गर्नुहोस् र हामी फेला परेका क्षेत्रहरूका लागि ज्ञात क्षेत्रहरू दर्ता गर्नुहोस्।
            // पछि प्रोसेसिंगका लागि जानकारी खण्ड पाठ क्षेत्रहरू रेकर्ड गर्नुहोस्, तल टिप्पणीहरू हेर्नुहोस्।
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // यस पुस्तकालयको लागि "slide" निर्धारण गर्नुहोस् जुन मेमोरी वस्तुहरू कहाँ लोड गरिएको छ भनेर पत्ता लगाउन पूर्वाग्रहको रूपमा समाप्त हुन्छ।
            // यद्यपि यो अनौंठो गणनाको एक बिट हो र ज is्गलमा केहि चीजहरू खोज्दै गरेको र के छडी हेर्दा परिणाम हो।
            //
            // सामान्य विचार यो हो कि `bias` प्लस सेगमेन्टको `stated_virtual_memory_address` हुन गइरहेको छ जहाँ वास्तविक ठेगाना स्पेसमा सेगमेन्ट बस्छ।
            // अर्को चीज जसमाथि हामी भरोसा गर्छौं त्यो भनेको वास्तविक ठेगाना शून्य `bias` प्रतीक तालिका र डिबगिनफोमा हेर्न सूचकांक हो।
            //
            // यो बाहिर छ, प्रणाली लोड लाइब्रेरीहरूको लागि यी गणनाहरू गलत छन्।नेटिभ एक्जिक्युटेबलका लागि, यद्यपि यो सहि देखिन्छ।
            // LLDB को स्रोतबाट केहि तर्क उठाउँदै यसमा पहिलो `__TEXT` सेक्सनको लागि केही विशेष केसिंग छ जुन नानजेरो आकारको साथ फाइल अफसेट ० बाट लोड भयो।
            // कुनै पनि कारणको लागि जब यो उपस्थित हुन्छ यो प्रतीक तालिका लाइब्रेरीको लागि केवल vmaddr स्लाइडसँग सम्बन्धित छ जस्तो देखिन्छ।
            // यदि यो *उपस्थित छैन* भने प्रतीक तालिका vmaddr स्लाइड प्लस खण्डको बताइएको ठेगानासँग सम्बन्धित छ।
            //
            // यस स्थितिलाई ह्यान्डल गर्न यदि हामी * फाइल अफसेट शून्यमा पाठ सेक्शन फेला पार्दैनौं भने हामी पहिलो पाठ सेक्सनको तोकिएको ठेगानाबाट पूर्वाग्रह बढाउँदछौं र त्यस रकमले सबै बताइएको ठेगानाहरू पनि घटाउँछौं।
            //
            // त्यस प्रकारले प्रतीक तालिका सँधै पुस्तकालयको पूर्वाग्रह राशिसँग सम्बन्धित हुन्छ।
            // प्रतीक तालिका मार्फत प्रतीकको रूपमा यो सही परिणामहरू देखिन्छ।
            //
            // इमानदारीपूर्वक मलाई पूर्ण रूपमा यकिन छैन कि यो सहि छ वा यदि त्यहाँ अरू पनि छन् जुन यसले यो कसरी गर्ने भन्ने संकेत गर्दछ।
            // अहिलेका लागि यसले पर्याप्त (?) लाई राम्ररी काम गरेको जस्तो देखिन्छ र हामी आवश्यक छ भने समयको साथ यो चिम्ट गर्न हामी सक्षम हुनुपर्दछ।
            //
            // केहि थप जानकारीको लागि #318 हेर्नुहोस्
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // अन्य Unix (उदाहरण:
        // लिनक्स) प्लेटफर्मले वस्तु फाईल ढाँचाको रूपमा ELF प्रयोग गर्दछ र सामान्यतया नेटिभ पुस्तकालयहरू लोड गर्न `dl_iterate_phdr` भनिने एक एपीआई लागू गर्दछ।
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` एक मान्य सूचक हुनु पर्छ।
        // `vec` `std::Vec` को लागी मान्य सूचक हुनु पर्छ।
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 नेटिभ डिबग जानकारीलाई समर्थन गर्दैन, तर निर्माण प्रणालीले मार्ग `romfs:/debug_info.elf` मा डिबग जानकारी राख्दछ।
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // अरू सबैले ELF प्रयोग गर्नुपर्दछ, तर नेटिभ पुस्तकालयहरू लोड गर्ने तरिका जान्दैनन्।
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// सबै ज्ञात साझा लाइब्रेरीहरू लोड गरिएको छ कि।
    libraries: Vec<Library>,

    /// म्याप्सिंग क्यास जहाँ हामी पार्स गरिएको बौना जानकारी राख्छौं।
    ///
    /// यस सूचीमा यसको सम्पूर्ण लाइफटाइमको लागि निश्चित क्षमता छ जुन कहिल्यै बढ्दैन।
    /// प्रत्येक जोडीको `usize` तत्व `libraries` माथिको अनुक्रमणिका हो जहाँ `usize::max_value()` हालको कार्यान्वयनको प्रतिनिधित्व गर्दछ।
    ///
    /// `Mapping` पार्स गरिएको बौना जानकारीसँग सम्बन्धित छ।
    ///
    /// नोट गर्नुहोस् कि यो मूलतया एक LRU क्यास हो र हामी ठेगानाहरू प्रतीकको रूपमा हामी यहाँ चीजहरू बदल्दै छौं।
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// यस पुस्तकालयको अंशहरू स्मृतिमा लोड गरियो, र जहाँ तिनीहरू लोड भइरहेका छन्।
    segments: Vec<LibrarySegment>,
    /// यस पुस्तकालयको "bias", सामान्यतया जहाँ यो मेमोरीमा लोड हुन्छ।
    /// यो मान प्रत्येक खण्डको बताइएको ठेगानामा थपियो वास्तविक भर्चुअल मेमोरी ठेगाना प्राप्त गर्न जुन खण्डमा लोड गरिएको छ।
    /// थप रूपमा यो पूर्वाग्रह वास्तविक आभासी मेमोरी ठेगानाहरूबाट डिबगइन्फो र प्रतीक तालिकामा अनुक्रमणिकामा घटाइएको छ।
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// वस्तु फाईलमा यस खण्डको तोकिएको ठेगाना।
    /// यो वास्तवमा त्यस्तो छैन जहाँ सेगमेन्ट लोड गरिएको छ, बरु यो ठेगाना प्लस सहितको पुस्तकालयको `bias` कहाँ छ जहाँ यो भेट्टाउने हो।
    ///
    stated_virtual_memory_address: usize,
    /// मेमोरीमा ths खण्डको आकार।
    len: usize,
}

// असुरक्षित किनकि बाह्य समक्रमण गर्न यो आवश्यक छ
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // असुरक्षित किनकि बाह्य समक्रमण गर्न यो आवश्यक छ
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // डिबग जानकारी म्यापिingsको लागि एकदम सानो, एकदम सरल LRU क्यास।
        //
        // हिट रेट एकदम उच्च हुनुपर्दछ, किनभने ठ्याक्क स्ट्याक धेरै साझा लाइब्रेरीहरूको बिच पार हुँदैन।
        //
        // `addr2line::Context` संरचनाहरू निर्माण गर्न धेरै महँगो छन्।
        // यसको लागत अनुवर्ती `locate` क्वेरीहरू द्वारा परिशोधित हुने आशा गरिएको छ, जुन राम्रो स्पीडअपहरू प्राप्त गर्न `addr2line: : Context`s निर्माण गर्दा बनाइएको संरचनाहरूको लाभ उठाउँदछ।
        //
        // यदि हामीसँग यो क्यास छैन भने, त्यो परिशोधन कहिल्यै हुने छैन, र ब्याकट्रेसहरू प्रतीकात्मक रूपमा ssssllllooooowwww हुनेछ।
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // पहिले यस परीक्षण गर्नुहोस् यदि यो `lib` सँग `addr` (ह्यान्डलिंग रिलोकेसन) को कुनै सेगमेन्ट छ भने।यदि यो चेक पास भयो भने हामी तल जारी राख्न सक्दछौं र वास्तवमा ठेगाना अनुवाद गर्दछौं।
                //
                // नोट गर्नुहोस् कि हामी यहाँ `wrapping_add` प्रयोग गर्दैछौं ओवरफ्लो जाँचहरू जोगिनका लागि।यो जंगलीमा देखियो कि SVMA + पूर्वाग्रह गणना ओभरफ्लो।
                // यो केहि अनौंठो जस्तो देखिन्छ कि हुन्छ तर त्यहाँ त्यस्तो ठूलो रकम छैन जुन हामी यसको बारेमा गर्न सक्दछौं केवल ती क्षेत्रहरूलाई वेवास्ता गर्नुहोस् किनभने तिनीहरू सम्भवतः अन्तरिक्षमा देखाउँदै छन्।
                //
                // यो मूल रूपमा rust-lang/backtrace-rs#329 मा आयो।
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // अब जब हामी जान्दछौं कि `lib` ले `addr` समावेश गर्दछ, हामी पूर्वाग्रहको साथ अफसेट गर्न सक्छौं भनिएको वायरल मेमोरी ठेगाना पाउन।
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // इन्भेरियन्ट: यो सर्त पछि चाँडो फर्केर नै पूरा हुन्छ
        // त्रुटिबाट, यस मार्गको लागि क्यास प्रविष्टि अनुक्रमणिका ० मा छ।

        if let Some(idx) = idx {
            // जब म्यापि। पहिले नै क्याचमा छ, अगाडि सार्नुहोस्।
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // जब म्यापि। क्यासमा छैन, नयाँ नक्साpping्कन सिर्जना गर्नुहोस्, यसलाई क्यासको अगाडि घुसाउनुहोस्, र यदि आवश्यक भएमा सबैभन्दा पुरानो क्यास प्रविष्टि खाली गर्नुहोस्।
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // `'static` आजीवन लीक नगर्नुहोस्, निश्चित गर्नुहोस् कि यो केवल आफैंमा स्कोप गरिएको छ
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // `sym` लाई `'static` को जीवनकाल विस्तार गर्नुहोस् किनकि हामीलाई दुर्भाग्यवश यहाँ चाहिन्छ, तर यो ओन्नी हो एक सन्दर्भको रूपमा बाहिर जाँदा कुनै पनि सन्दर्भमा यो फ्रेम बाहिर पनी जारी रहनु हुँदैन।
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // अन्तमा, क्यास म्यापि। प्राप्त गर्नुहोस् वा यस फाईलको लागि नयाँ म्यापि। सिर्जना गर्नुहोस्, र DWARF जानकारीको मूल्यांकन गर्नुहोस् यस ठेगानाको लागि file/line/name फेला पार्न।
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// हामी यो प्रतीकको लागी फ्रेम जानकारी खोज्न सक्षम भयौं, र r addr2line` को फ्रेम भित्र आन्तरिक सबै nitty gritty विवरण छ।
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// डिबग जानकारी फेला पार्न सकेनौं, तर हामीले यसलाई एल्फ एक्जिक्युटेबलको प्रतीक तालिकामा भेट्यौं।
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}