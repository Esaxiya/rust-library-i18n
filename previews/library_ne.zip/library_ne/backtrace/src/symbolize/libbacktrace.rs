//! प्रतीक रणनीति libbacktrace मा DWARF पार्सिंग कोड प्रयोग गरेर।
//!
//! सामान्यतया gcc को साथ वितरित libbacktrace सी लाइब्रेरी, एक backtrace उत्पादन मात्र समर्थन गर्छ (जुन हामी वास्तवमा प्रयोग गर्दैनौं) तर intrames फ्रेम र व्हाट नट जस्ता चीजहरूको बारेमा ब्याकट्रेस र ह्यान्डल ड्वार्ब डिबग जानकारी पनि।
//!
//!
//! यो यहाँ धेरै धेरै चिन्ताको कारण अपेक्षाकृत जटिल छ, तर आधारभूत विचार हो:
//!
//! * पहिले हामी `backtrace_syminfo` कल गर्छौं।यो गतिशील प्रतीक तालिकाबाट प्रतीक जानकारी प्राप्त गर्दछ यदि हामी सक्दछौं।
//! * अर्को हामी `backtrace_pcinfo` कल गर्छौं।यसले डिबगइनफो टेबलहरू पार्स गर्दछ यदि तिनीहरू उपलब्ध छन् र हामीलाई इनलाइन फ्रेमहरू, फाइलनामहरू, लाइन नम्बरहरू, इत्यादि बारे जानकारी पुनः प्राप्त गर्न अनुमति दिनेछ।
//!
//! त्यहाँ बौने टेबल्सलाई लिबब्रेट्रेसमा ल्याउने थुप्रै चालहरू छन्, तर आशा छ यो संसारको अन्त्य होईन र तल पढ्दा स्पष्ट हुन्छ।
//!
//! यो गैर-MSVC र गैर-OSX प्लेटफर्महरूको लागि पूर्वनिर्धारित प्रतीक रणनीति हो।लिबस्टेडमा यद्यपि यो OSX का लागि पूर्वनिर्धारित रणनीति हो।
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // यदि सम्भव छ भने `function` नाम प्राथमिकता दिनुहोस् जुन डिबगइनफोबाट आउँदछ र सामान्यतया उदाहरणका लागि इनलाइन फ्रेमहरूका लागि अधिक सटीक हुन सक्छ।
                // यदि त्यो उपस्थित छैन भने `symname` मा तोकिएको प्रतीक तालिकाको नाममा फिर्ता जानुहोस्।
                //
                // नोट गर्नुहोस् कि कहिलेकाँही `function` ले थोरै कम सही महसुस गर्न सक्छ, उदाहरण को लागी `try<i32,closure>` `std::panicking::try::do_call` isntead को रूपमा सूचीबद्ध गरीएको छ।
                //
                // यो वास्तवमै किन स्पष्ट छैन किन, तर समग्रमा `function` नाम अधिक सटीक देखिन्छ।
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // अहिलेको लागि केहि नगर्नुहोस्
}

/// `data` सूचकको प्रकार `syminfo_cb` मा पारियो
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // यो कलब्याक एक पटक `backtrace_syminfo` बाट बोलाइएको छ जब हामी समाधान गर्न थाल्छौं हामी `backtrace_pcinfo` कल गर्न अगाडि जान्छौं।
    // `backtrace_pcinfo` प्रकार्य डिबग जानकारी परामर्श गर्दछ र गर्न को लागी चीज गर्न को लागी file/line जानकारी को रूप मा प्राप्त गरीएको फ्रेमहरु।
    // जहाँसम्म ध्यान दिनुहोस् कि `backtrace_pcinfo` असफल हुन सक्छ वा केहि गर्न सक्दैन यदि त्यहाँ डिबग जानकारी छैन भने, त्यसो भए यदि हामी Xbox X बाट कम्तिमा एउटा प्रतीकको साथ कलब्याक कल गर्न निश्चित छौं।
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// `data` सूचकको प्रकार `pcinfo_cb` मा पारियो
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Libbacktrace एपीआई एक राज्य को निर्माण गर्न समर्थन गर्दछ, तर यसले एक राज्य नष्ट गर्न समर्थन गर्दैन।
// म व्यक्तिगत रूपमा यसको अर्थ यो लिन्छु कि एक राज्य सिर्जना गर्नु हो र त्यसपछि सँधै बाँच्नको लागि हो।
//
// म एक at_exit() ह्यान्डलर दर्ता गर्न मन पराउँछु जसले यो राज्य खाली गर्छ, तर लिबब्रेट्रेसले त्यसो गर्न कुनै तरिका प्रदान गर्दैन।
//
// यी अवरोधहरूको साथ, यस प्रकार्यको एक स्ट्याटसिकली क्यास्ड स्टेट छ जुन यो अनुरोध गरिएको पहिलो पटक गणना गरिन्छ।
//
// याद गर्नुहोस् कि ब्याट्रैसिंग सबै क्रमशः हुन्छ (एक ग्लोबल लक)।
//
// नोट गर्नुहोस् कि यहाँ सिnch्क्रोनाइजेशनको अभाव `resolve` X बाह्य सि sy्क्रोनाइज गरिएको आवश्यकताको कारणले हो।
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Libbacktrace को थ्रेडसेफ क्षमताहरूको व्यायाम नगर्नुहोस् किनकि हामी सँधै यसलाई सि sy्क्रोनाइज्ड फेसनमा कल गर्दछौं।
        //
        0,
        error_cb,
        ptr::null_mut(), // कुनै थप डाटा छैन
    );

    return STATE;

    // नोट गर्नुहोस् कि libbacktrace को लागि सबै सञ्चालन गर्न यो वर्तमान कार्यान्वयनको लागि DWARF डिबग जानकारी फेला पार्न आवश्यक छ।यसले सामान्यतया: समावेश सहित धेरै संयन्त्रहरूको माध्यमबाट गर्छ, तर सीमित छैन:
    //
    // * /proc/self/exe समर्थित प्लेटफार्महरूमा
    // * फाइलनाम राज्य बनाउँदा स्पष्ट रूपमा पार गरियो
    //
    // Libbacktrace लाइब्रेरी सी कोड को एक ठूलो wad हो।यसको स्वाभाविक अर्थ यो मेमोरी सुरक्षा भेद्यताहरू हो, विशेष गरी जब विकृत डीबगिनफो ह्यान्डल गर्दा।
    // लिब्स्टडी यी ऐतिहासिक रूपमा धेरै मा चलाइएको छ।
    //
    // यदि /proc/self/exe प्रयोग गरिएको छ भने हामी यीलाई सामान्यतया बेवास्ता गर्न सक्दछौं किनकि हामी यो मान्छौं कि libbacktrace "mostly correct" हो र अन्यथा "attempted to be correct" बौने डिबग जानकारीको साथ अनौंठो कुरा गर्दैन।
    //
    //
    // यदि हामी फाईलनाममा पास गर्दछौं भने, त्यसो भए यो केहि प्लेटफर्महरूमा सम्भव छ (जस्तै BSDs) जहाँ एक द्वेषपूर्ण अभिनेताले त्यस स्थानमा एक मनमानी फाइल राख्न को कारण हुन सक्छ।
    // यसको मतलब यो हो कि यदि हामीले फाईलनामको बारेमा लिबब्रेट्रेसलाई बतायौं भने यसले एक मनमानी फाइल प्रयोग गरिरहेको हुन सक्छ, सम्भवत सेगफाल्टको कारण।
    // यदि हामी libbacktrace केहि पनि बताउँदैनौं भने यसले प्लेटफर्ममा केहि पनि गर्दैन जसले /proc/self/exe जस्ता मार्गहरूलाई समर्थन गर्दैन!
    //
    // हामी फाईलनाममा *पास गर्न* सकेसम्म सक्दो प्रयास गर्ने सबैलाई दिएका छौं, तर हामीले प्लेटफर्महरूमा /proc/self/exe लाई समर्थन गर्दैनौं।
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // नोट गर्नुहोस् कि आदर्श रूपमा हामीले `std::env::current_exe` प्रयोग गर्‍यौं, तर हामीलाई यहाँ `std` आवश्यक पर्दैन।
            //
            // हालको कार्यान्वयनयोग्य पथलाई स्थिर क्षेत्रमा लोड गर्न `_NSGetExecutablePath` प्रयोग गर्नुहोस् (जुन यदि यो अत्यन्त सानो छ भने मात्र छोड्नुहोस्)।
            //
            //
            // नोट गर्नुहोस् कि हामी यहाँ भ्रष्ट कार्यान्वयनकर्ताहरुमा न मर्नको लागि लिबब्रेट्रेसलाई गम्भीर रूपमा विश्वास गरिरहेका छौं, तर यसले पक्कै गर्छ ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows फाइल खोल्ने मोड छ जहाँ खोले पछि यसलाई मेटाउन सकिदैन।
            // यो सामान्य रूपमा हामी यहाँ के चाहान्छौं किनकि हामी यो सुनिश्चित गर्न चाहन्छौं कि लिबब्रेट्रेसमा हस्तान्तरण गरिसकेपछि हाम्रो कार्यान्वयन योग्य हाम्रो अन्तर्गतबाट बाहिर परिवर्तन हुँदैन, आशा छ कि लिबब्रेट्रेसमा मनमानी डेटामा पास गर्ने क्षमतालाई कम गर्ने (जुन गलत अर्थ लगाउन सकिन्छ)।
            //
            //
            // हाम्रो आफ्नै छविमा एक प्रकारको लक प्राप्त गर्न को लागी प्रयास गर्न हामी यहाँ नाचको केहि गर्छौं।
            //
            // * हालको प्रक्रियामा ह्यान्डल प्राप्त गर्नुहोस्, यसको फाइलनाम लोड गर्नुहोस्।
            // * सहि झण्डाको साथ त्यो फाइलनाममा फाईल खोल्नुहोस्।
            // * हालको प्रक्रियाको फाईलनाम पुन: लोड गर्नुहोस्, निश्चित गर्नुहोस् कि यो उस्तै हो
            //
            // यदि ती सबै पासहरू सिद्धान्तमा हामीले वास्तवमै हाम्रो प्रक्रियाको फाइल खोलेका छौं र हामीलाई ग्यारेन्टी गरियो कि यो परिवर्तन हुँदैन।FWIW यसको एक समूहलाई ऐतिहासिक रूपमा लिबस्ट्डबाट प्रतिलिपि गरिएको छ, त्यसैले यो के भइरहेको थियो भन्ने मेरो सबै भन्दा राम्रो व्याख्या हो।
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // यो स्थिर मेमोरीमा बाँचन्छ त्यसैले हामी यसलाई फर्काउन सक्दछौं।
                static mut BUF: [i8; N] = [0; N];
                // ... र यो स्ट्याकमा रहन्छ किनकि यो अस्थायी हो
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // जानाजानी यहाँ `handle` लीक गर्नुहोस् किनकि त्यो खुलासँग यस फाईल नाममा हाम्रो लक सुरक्षित गर्नुपर्दछ।
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // हामी एउटा स्लाइस फर्काउन चाहन्छौं जुन नल-टर्मिनेटेड हो, त्यसैले यदि सबै चीज भरियो र यो कुल लम्बाई बराबर भयो भने असफलतामा समान हुन्छ।
                //
                //
                // अन्यथा सफलता फिर्ताको बेला निश्चित गर्नुहोस् कि नुल बाइट स्लाइसमा समावेश छ।
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // ब्याकट्रेस त्रुटिहरू हालै गला कालो मुनि रहेका छन्
    let state = init_state();
    if state.is_null() {
        return;
    }

    // `backtrace_syminfo` एपीआई कल गर्नुहोस् जुन (कोड पढेर) `syminfo_cb` लाई ठीक एक पटक कल गर्नुपर्दछ (वा सम्भवतः त्रुटिको साथ विफल)।
    // हामी त्यसपछि `syminfo_cb` भित्र अधिक ह्यान्डल गर्दछौं।
    //
    // नोट गर्नुहोस् कि हामी यो गर्छौं किनकि `syminfo` ले प्रतीक तालिकामा परामर्श लिनेछ, बाइनरीमा डिबग जानकारी नभए पनि प्रतीक नामहरू फेला पार्नेछ।
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}