//! libunwind/gcc_s/etc एपीआईहरू प्रयोग गरेर ब्याकट्रेस समर्थन।
//!
//! यस मोड्युलले libunwind-शैली एपीआईहरू प्रयोग गरेर स्ट्याकलाई अनुहार हटाउने क्षमता समावेश गर्दछ।
//! नोट गर्नुहोस् कि लाइबुनविन्ड-जस्तो एपीआईको कार्यान्वयनको सम्पूर्ण गुच्छा त्यहाँ छ, र यसले केवल सबैलाई एकै पटकमा पिकि beingको सट्टा एकरूपमा संगत गर्न खोजिरहेको छ।
//!
//!
//! Libunwind एपीआई `_Unwind_Backtrace` द्वारा संचालित हो र अभ्यासमा एक ब्याकट्रेस उत्पन्न गर्न धेरै विश्वसनीय छ।
//! यो पूर्ण रूपमा स्पष्ट छैन कि यसले कसरी गर्छ (फ्रेम पोइन्टर्स? ए_फ्रेम जानकारी? दुबै?) तर यसले कार्य गर्दछ जस्तो देखिन्छ!
//!
//! यस मोड्युलको अधिकतर जटिलता लाइबनिविन्ड कार्यान्वयनको बिभिन्न विभिन्न प्लेटफर्म फरकहरू ह्यान्डल गर्दैछ।
//! अन्यथा यो एक धेरै साधारण Rust लाइबुनविन्ड एपीआईको लागि बाँधेको छ।
//!
//! यो हाल सबै गैर-विन्डोज प्लेटफर्महरूको लागि पूर्वनिर्धारित अनावश्यक एपीआई हो।
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// एक कच्चा लिबुनविन्ड पोइन्टरको साथ यो केवल पठन मात्र थ्रेडसेफ फेसनमा पहुँच हुनुपर्दछ, त्यसैले यो `Sync` हो।
// जब `Clone` को माध्यम बाट अन्य थ्रेडहरूमा पठाउँदा हामी सँधै एक संस्करणमा स्विच गर्छौं जसले आन्तरिक पोइन्टर्स समेट्दैन, त्यसैले हामी `Send` पनि हुनुपर्दछ।
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // यस्तो लाग्छ कि OSX U_Uwwind_FindEnclosingFunction` मा एक सूचक फिर्ता गर्दछ ... केहि अस्पष्ट हो।
        // यो पनी निश्चित रूपमा जहिले पनि कुनै पनि कारणको लागि संलग्न कार्य होईन।
        // यहाँ के भइरहेको छ भन्ने कुरा मलाई पूर्णरूपले स्पष्ट छैन, त्यसैले यसलाई अहिले नै निराश पार्नुहोस् र सँधै आईपी फिर्ता गर्नुहोस्।
        //
        // नोट गर्नुहोस् `skip_inner_frames.rs` X परीक्षण OSX मा यस खण्डका कारण छोडियो, र यदि यो तय गरियो भने सिद्धान्तमा परीक्षण ओएसएक्समा चलाउन सकिन्छ!
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// Backtraces को लागी पुस्तकालय ईन्टरफेस प्रयोग गरीयो
///
/// नोट गर्नुहोस् कि डेड कोडलाई अनुमति छ किनकि यहाँ केवल बाइन्डि areहरू छन् आईओएसले ती सबै प्रयोग गर्दैन तर थप प्लेटफर्म-विशेष कन्फिगरेसनहरू थप गर्नाले कोड धेरै नै दूषित हुन्छ।
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // एआरएम EABI द्वारा मात्र प्रयोग गरिएको
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // IOS मा कुनै नेटिभ _Uwwind_Backtrace छैन
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // GCC 4.2.0 देखि उपलब्ध, हाम्रो उद्देश्यका लागि ठीक हुनुपर्छ
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // यो प्रकार्य गलतफहमी हो: यस फ्रेमको क्यानोनिकल फ्रेम ठेगाना प्राप्त गर्नु भन्दा (उर्फ कलर फ्रेमको एसपी) यसले यो फ्रेमको एसपी फर्काउँछ।
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x एक पक्षपाती सीएफए मान प्रयोग गर्दछ, त्यसकारण हामीले _Uwwind_GetCFA मा भर पर्नुको सट्टा स्ट्याक पोइन्टर रेजिस्टर (%r15) प्राप्त गर्न _Uwwind_GetGR को आवश्यकता पर्छ।
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // android र आर्ममा, प्रकार्य `_Unwind_GetIP` र अन्यको गुच्छा म्याक्रो हो, त्यसैले हामी म्याक्रोहरूको विस्तार समावेश गर्ने कार्यहरू परिभाषित गर्छौं।
    //
    //
    // TODO: हेडर फाइलमा लिंक गर्नुहोस् जसले यी म्याक्रोहरूलाई परिभाषित गर्दछ, यदि तपाईं फेला पार्न सक्नुहुनेछ।
    // (म, फिटजेन, हेडर फाइल फेला पार्न सक्दिन कि यी केहि म्याक्रो विस्तारहरू मूल रूपमा लिइएको हो।)
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 हात मा स्ट्याक सूचक हो।
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // यो प्रकार्य Android वा ARM/Linux मा पनि अवस्थित छैन, त्यसैले यसलाई नो-अप बनाउनुहोस्।
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}