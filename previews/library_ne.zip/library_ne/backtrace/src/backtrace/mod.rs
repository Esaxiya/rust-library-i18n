use core::ffi::c_void;
use core::fmt;

/// हालको कल-स्ट्याक निरीक्षण गर्दछ, स्ट्याक ट्रेस गणना गर्नको लागि प्रदान गरिएको बन्दमा सबै सक्रिय फ्रेमहरू पार गर्दै।
///
/// यो प्रकार्य यस पुस्तकालयको वर्कहर्स हो एक प्रोग्रामका लागि स्ट्याक ट्रेसहरूको गणना गर्न।दिईएको क्लोजर `cb` `Frame` का उदाहरणहरू प्राप्त हुन्छ जुन स्ट्याकमा त्यो कल फ्रेमको बारेमा जानकारी प्रस्तुत गर्दछ।
/// बन्द एक शीर्ष-तल फैशन (हालसालै फंक्शनहरू पहिले भनिन्छ) मा फ्रेमहरू उत्पादन गरिन्छ।
///
/// बन्दको फिर्ती मूल्य ब्याकट्रेस जारी रहनु पर्छ कि पर्दैन भन्ने संकेत हो।`false` को एक फिर्ती मान backtrace समाप्त र तुरुन्तै फिर्ता हुनेछ।
///
/// एक पटक `Frame` प्राप्त भएपछि तपाई सम्भवत `backtrace::resolve` कल गर्न चाहानुहुन्छ `ip` (निर्देशन पोइन्टर) रूपान्तरण गर्न वा प्रतीक ठेगानालाई `Symbol` मा परिवर्तन गर्नुहोस् जुन नाम र/वा फाइलनाम/लाइन नम्बर सिक्न सकिन्छ।
///
///
/// नोट गर्नुहोस् कि यो एक अपेक्षाकृत कम-स्तरको प्रकार्य हो र यदि तपाईं चाहनुहुन्छ, उदाहरणका लागि, पछि निरीक्षण गर्न ब्याकट्रेस क्याप्चर गर्नुहोस्, त्यसपछि `Backtrace` प्रकार अधिक उपयुक्त हुन सक्छ।
///
/// # आवश्यक सुविधाहरू
///
/// यस प्रकार्यलाई सक्षम पार्न `backtrace` crate को `std` सुविधा चाहिन्छ, र `std` सुविधा पूर्वनिर्धारितद्वारा सक्षम पारिएको छ।
///
/// # Panics
///
/// यो प्रकार्य panic कहिले पनि गर्न कोसिस गर्दछ, तर यदि `cb` panics प्रदान गर्दछ भने केहि प्लेटफर्मले एक डबल panic प्रक्रिया रद्द गर्न बाध्य पार्दछ।
/// केही प्लेटफर्मले सी लाइब्रेरी प्रयोग गर्दछ जुन आन्तरिक रूपमा कलब्याकहरू प्रयोग गर्दछ जुन अवाउन्ड हुन सक्दैन, त्यसैले `cb` बाट आतंकित गर्दा प्रक्रिया परित्याग ट्रिगर गर्न सक्दछ।
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // ब्याकट्रेस जारी राख्नुहोस्
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// `trace` को रूपमा उही, असुरक्षितको रूपमा यो अनइन्क्रोनाइज गरिएको छ।
///
/// यो प्रकार्यको समक्रमण ग्यारेन्टीहरू छैन तर यो crate को `std` सुविधा कम्पाइल नहुँदा उपलब्ध हुन्छ।
/// अधिक कागजात र उदाहरणका लागि `trace` प्रकार्य हेर्नुहोस्।
///
/// # Panics
///
/// `cb` Panicking मा सावधानहरूको लागि `trace` मा जानकारी हेर्नुहोस्।
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// एक trait ब्याकट्रेसको एक फ्रेम प्रतिनिधित्व गर्दै, यो crate को `trace` प्रकार्यमा प्राप्त भयो।
///
/// ट्रेसि function समारोहको बन्द फ्रेम उत्पन्न हुनेछ, र फ्रेम वस्तुतः पठाइन्छ किनभने अन्तर्निहित कार्यान्वयन सधैँ रनटाइम सम्म ज्ञात हुँदैन।
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// यस फ्रेमको हालको निर्देशन सूचक फर्काउँछ।
    ///
    /// यो फ्रेममा कार्यान्वयन गर्न सामान्यतया अर्को निर्देशन हो, तर सबै कार्यान्वयनहरूले यसलाई १००% शुद्धताका साथ सूचीकृत गर्दैन (तर यो सामान्यतया निकै नजिक छ)।
    ///
    ///
    /// यो मानलाई `backtrace::resolve` मा पास गर्न सिफारिश गरिएको छ यसलाई प्रतीक नाममा बदल्न।
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// यस फ्रेमको हालको स्ट्याक सूचक फर्काउँछ।
    ///
    /// यस्तो अवस्थामा कि ब्याकएन्डले यस फ्रेमको लागि स्ट्याक पोइन्टर पुन: प्राप्त गर्न सक्दैन, शून्य सूचक फिर्ता हुन्छ।
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// यस प्रकार्यको फ्रेमको सुरूवात प्रतीक ठेगाना फर्काउँछ।
    ///
    /// यसले `ip` द्वारा फिर्ता सुरू गर्न निर्देशन सूचकलाई फर्काउने प्रयास गर्दछ, त्यो मान फर्काउँदै।
    ///
    /// केहि केसहरूमा, तथापि, ब्याकएन्डहरूले केवल यो प्रकार्यबाट `ip` फर्काउँछ।
    ///
    /// फर्काइएको मान कहिलेकाँही प्रयोग गर्न सकिन्छ यदि `backtrace::resolve` माथि दिइएको `ip` मा असफल भयो।
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// मोड्युलको आधार ठेगाना फर्काउँछ जुन फ्रेम सम्बन्धित छ।
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // यो पहिले आउन आवश्यक छ, यो सुनिश्चित गर्न मिरीले होस्ट प्लेटफर्ममा प्राथमिकता लिन्छ
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // केवल dbghelp प्रतीकमा प्रयोग गरिएको
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}