use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr ले एक कलब्याक लिन्छ जुन प्रक्रियामा लि been्क गरिएको प्रत्येक DSO को लागी dl_phdr_info सूचक प्राप्त गर्दछ।
    // dl_iterate_phdr ले सुनिश्चित गर्दछ कि डायनामिक लिer्करलाई लक गर्न शुरूबाट अन्तर्करणको अन्त्य सम्ममा बन्द छ।
    // यदि कलब्याकले गैर-शून्य मान फिर्ता गर्छ भने पुनरावृत्ति चाँडै समाप्त हुन्छ।
    // 'data' प्रत्येक कलमा कलब्याकमा तेर्सो तर्कको रूपमा पारित हुनेछ।
    // 'size' dl_phdr_info को आकार दिन्छ।
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// हामीले बिल्ड आईडी र केहि आधारभूत प्रोग्राम हेडर डाटा पार्स गर्न आवश्यक पर्दछ जसको अर्थ हामीलाई ELF स्प्याकबाट पनि केही चीज चाहिन्छ।
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// अब हामी dl_phdr_info प्रकारको fuchsia को वर्तमान गतिशील लिंकर द्वारा प्रयोग गरिएको संरचना को लागी बिट को लागी प्रतिलिपि बनाउनु पर्छ।
// क्रोमियमसँग यो एबीआई सीमा साथै क्र्यासप्याड पनि छ।
// आखिरमा हामी यी केसहरू एल्फ-खोजी प्रयोग गर्न सार्न चाहान्छौं तर हामीले त्यो एसडीकेमा प्रदान गर्नु आवश्यक छ र त्यो अहिलेसम्म गरिएको छैन।
//
// यसैले हामी (र तिनीहरू) यो विधि प्रयोग गर्न अडी रह्यौं जुन fuchsia libc संग एक कडा जोडी हुन्छ।
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // E_phoff र e_phnum मान्य छ कि छैन जाँच्न हामीसँग कुनै तरिका छैन।
    // libc ले यो हाम्रो लागि सुनिश्चित गर्नुपर्दछ त्यसैले यहाँ स्लाइस बनाउनका लागि सुरक्षित छ।
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr ले architect 64-बिट ELF प्रोग्राम हेडरको प्रतिनिधित्व गर्छ लक्ष्य आर्किटेक्चरको endianness मा।
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr एक मान्य ELF कार्यक्रम हेडर र यसको सामग्री प्रतिनिधित्व गर्दछ।
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // हामीसँग p_addr वा p_memsz मान्य छ कि छैन भनेर जाँच गर्ने कुनै तरिका छैन।
    // Fuchsia को libc नोटहरू पहिलो पार्स गर्दछ यद्यपि यहाँ हुनुको कारणले यी हेडरहरू मान्य हुनुपर्दछ।
    //
    // नोटिटरले अन्तर्निहित डेटा मान्य हुन आवश्यक पर्दैन तर यसले सीमालाई मान्य हुन आवश्यक पर्दैन।
    // हामी विश्वास गर्छौं कि libc ले सुनिश्चित गर्‍यो कि यो हाम्रो लागि केस हो।
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// आईडी निर्माणको लागि नोट प्रकार।
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr लक्ष्यको endianness मा एक ELF नोट हेडर प्रतिनिधित्व गर्दछ।
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// नोटले ELF नोट (हेडर + सामग्रीहरू) प्रतिनिधित्व गर्दछ।
// नाम u8 टुक्राको रूपमा छोडियो किनभने यो सँधै शून्य हुँदैन र rust ले सजीलो बनाउँदछ कि जाँच गर्न बाइट जे भए पनि मिलाउँछ।
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// नोटिटरले तपाईंलाई नोट क्षेत्रमा सुरक्षित रूपमा पुनरावृत्ति गर्न दिन्छ।
// यो त्रुटि हुने बित्तिकै समाप्त हुन्छ वा त्यहाँ थप नोटहरू छैनन्।
// यदि तपाईं अवैध डाटामा पुनरावृत्ति गर्नुहुन्छ भने यसले कार्य गर्दछ किनकि कुनै नोटहरू फेला परेन।
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // यो प्रकार्यको इन्भेरियन्ट हो कि सूचक र आकारले दिएको बाइट्सको वैध दायरालाई जनाउँछ जुन सबै पढ्न सकिन्छ।
    // यी बाइट्सका सामग्रीहरू केहि पनि हुन सक्दछन् तर दायरा वैध हुनै पर्छ सुरक्षित रहनका लागि।
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to 'x' लाई 'to'-byte पign्क्तिबद्ध माने 'to' लाई २ को एक शक्ति हो।
// यसले C/C ++ ELF पार्सि code कोडमा (x + to, १) र -to प्रयोग हुने मानक ढाँचा अनुसरण गर्दछ।
// Rust ले तपाईंलाई उपयोगी अस्वीकार गर्न दिदैन त्यसैले म प्रयोग गर्छु
// 2 को पूरक रूपान्तरण कि पुनः सिर्जना गर्न को लागी।
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 ले स्लाइसबाट नम्बर बाइट खपत गर्दछ (यदि अवस्थित छ) र साथै थप निश्चित गर्दछ कि अन्तिम स्लाइस उचित तरिकाले पigned्क्तिबद्ध गरिएको छ।
// यदि या त अनुरोध गरिएको बाइट्सको संख्या धेरै ठूलो छ वा पर्याप्त बाँकी बाइट्स नभएको कारण स्लाइस पछाडि पुन: प्रमाणित गर्न सकिदैन, कुनै पनि फिर्ता हुँदैन र टुक्रा परिमार्जन गरिएको छैन।
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// यस प्रकार्यसँग कुनै वास्तविक इन्वाइन्टहरू छैन कलरले प्रदर्शनको लागि (र केहि वास्तुकलामा शुद्धतामा) प X्क्तिित हुनुपर्दछ कि 'bytes' लाई पछाडि अन्य समर्थन गर्नुपर्दछ।
// Elf_Nhdr फिल्डका मानहरू बकवास हुन सक्छ तर यस प्रकार्यले त्यस्तो कुनै कुराको सुनिश्चित गर्दैन।
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // यो सुरक्षित छ जबसम्म त्यहाँ पर्याप्त ठाउँ छ र हामीले भर्खरै पुष्टि गर्यौं कि यदि माथिको स्टेटमेन्टमा यो असुरक्षित हुनु हुँदैन।
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // नोट गर्नुहोस् कि sice_of: :<Elf_Nhdr>() सँधै-बाइट प al्क्तिबद्ध हुन्छ।
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // जाँच गर्नुहोस् कि हामी अन्तमा पुगेका छौं।
        if self.base.len() == 0 || self.error {
            return None;
        }
        // हामी nhdr लाई ट्रान्समिट गर्दछौं तर हामी ध्यानपूर्वक नतिजा प्राप्त संरचनालाई विचार गर्दछौं।
        // हामी नामहरू वा डेसेक्सलाई विश्वास गर्दैनौं र हामी कुनै प्रकारको आधारमा असुरक्षित निर्णय लिदैनौं।
        //
        // त्यसो भए पनि यदि हामी पूर्ण फोहोर उठाउँदछौं भने हामी अझै सुरक्षित हुनुपर्छ।
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// खण्ड कार्यान्वयन योग्य छ भनेर इates्गित गर्दछ।
const PERM_X: u32 = 0b00000001;
/// खण्ड लेख्न योग्य छ भनेर संकेत गर्दछ।
const PERM_W: u32 = 0b00000010;
/// खण्ड पठनीय छ भनेर इic्गित गर्दछ।
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// रनटाइममा ELF खण्ड प्रतिनिधित्व गर्दछ।
struct Segment {
    /// यस खण्डको सामग्रीको रनटाइम भर्चुअल ठेगाना दिन्छ।
    addr: usize,
    /// यस खण्डको सामग्रीको मेमोरी आकार दिन्छ।
    size: usize,
    /// ELF फाईलको साथ यस खण्डको मोड्युल भर्चुअल ठेगाना दिन्छ।
    mod_rel_addr: usize,
    /// ELF फाईलमा फेला परेको अनुमति दिन्छ।
    /// यी अनुमतिहरू आवश्यक रूपमा रनटाइममा उपस्थित अनुमतिहरू छैनन्।
    flags: Perm,
}

/// DSO बाट सेगमेन्टहरूमा एक पुनरावृत्ति गर्न दिन्छ।
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// ELF DSO (गतिशील साझा वस्तु) लाई प्रतिनिधित्व गर्दछ।
/// यस प्रकारले वास्तविक प्रतिलिपि बनाउनुको सट्टा वास्तविक DSO मा डाटा भण्डारण गर्दछ।
struct Dso<'a> {
    /// गतिशील लिंकरले जहिले पनि हामीलाई नाम दिन्छ, नाम खाली भए पनि।
    /// मुख्य कार्यान्वयन योग्यको मामलामा यो नाम खाली हुनेछ।
    /// एक साझा वस्तु को मामला मा यो Soname हुनेछ (DT_SONAME हेर्नुहोस्)।
    name: &'a str,
    /// फुचियामा वस्तुतः सबै बाइनरीसँग निर्माण आईडी हुन्छ तर यो सख्त आवश्यक छैन।
    /// त्यहाँ वास्तविक ELF फाईलसँग DSO जानकारी मिलाउन कुनै तरिका छैन यदि त्यहाँ build_id छैन भने हामी प्रत्येक DSO सँग यहाँ हुनु आवश्यक छ।
    ///
    /// DSO को build_id बिना बेवास्ता गरिन्छ।
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// यस DSO मा खण्डहरूमा इटरेटर फिर्ता गर्दछ।
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// यी त्रुटिहरूले ती समस्याहरूको स issues्केत गर्छ जुन प्रत्येक DSO को बारेमा जानकारी पार्सि while गर्दा उत्पन्न हुन्छ।
///
enum Error {
    /// नेम ईररको मतलब एक सी शैली स्ट्रि aलाई rust स्ट्रि intoमा रूपान्तरण गर्दा त्रुटि भयो।
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError यसको मतलब हो कि हामीले बिल्ड आईडी भेट्टाएनौं।
    /// यो कि किनभने DSO सँग कुनै बिल्ड आईडी थिएन वा किनभने निर्माण आईडी समावेश गरिएको खण्ड खराब भएको कारणले यो हुन सक्छ।
    ///
    BuildIDError,
}

/// या त 'dso' वा 'error' प्रत्येक DSO को लागि डाइनमिक लिंकर द्वारा प्रक्रियामा लिंक गरियो।
///
///
/// # Arguments
///
/// * `visitor` - एक DsoPrinter कि एक खाने विधिहरू मध्ये एक हुनेछ foreach DSO भनिन्छ।
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr ले info.name एक वैध स्थान औंल्याउँछ भनेर सुनिश्चित गर्दछ।
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// यस प्रकार्यले DSO मा समावेश सबै जानकारीको लागि Fuchsia प्रतीक मार्कअप प्रिन्ट गर्दछ।
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}