#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// ब्याकट्रेसहरूको लागि ढाँचा।
///
/// यस प्रकारको ब्याकट्रेस प्रिन्ट गर्नको लागि प्रयोग गर्न सकिन्छ जहाँ ब्याकट्रेस आफैंबाट आउँदछ।
/// यदि तपाईंसँग `Backtrace` प्रकार छ भने यसको `Debug` कार्यान्वयन पहिले नै यो प्रिन्टिंग ढाँचा प्रयोग गर्दछ।
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// मुद्रणका शैलीहरू जुन हामी छाप्न सक्छौं
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// एक टेर्सर ब्याकट्रेस प्रिन्ट गर्दछ जसमा आदर्श मात्र प्रासंगिक जानकारी हुन्छ
    Short,
    /// ब्याकट्रेस प्रिन्ट गर्दछ जसमा सबै सम्भावित जानकारी हुन्छ
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// नयाँ `BacktraceFmt` सिर्जना गर्नुहोस् जुन प्रदान गरिएको `fmt` मा आउटपुट लेख्दछ।
    ///
    /// `format` आर्गुमेन्टले शैलीलाई नियन्त्रण गर्दछ जसमा ब्याकट्रेस छपाई गरिएको छ, र `print_path` आर्गुमेन्ट फाइलनामको `BytesOrWideString` ईन्स्टान्स प्रिन्ट गर्न प्रयोग हुनेछ।
    /// यस प्रकारले आफै फाइलनामहरूको कुनै पनि मुद्रण गर्दैन, तर यो कलब्याक त्यसो गर्न आवश्यक छ।
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// प्रिन्ट हुनको लागि ब्याकट्रेसको लागि एक प्रिमेबल प्रिन्ट गर्दछ।
    ///
    /// यो केहि प्लेटफर्महरूमा आवश्यक हुन्छ ब्याकट्रेसहरू पछि पूर्ण प्रतीकको रूपमा देखा पर्न, र अन्यथा यो केवल पहिलो विधि हुनुपर्छ जुन तपाईंले कल गर्नुभयो `BacktraceFmt` सिर्जना गरेपछि।
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// ब्याकट्रेस आउटपुटमा फ्रेम थप गर्दछ।
    ///
    /// यो प्रतिबद्धले `BacktraceFrameFmt` को एक RAII उदाहरण फर्काउँछ जुन वास्तवमै फ्रेम प्रिन्ट गर्न प्रयोग गर्न सकिन्छ, र विनाशमा यसले फ्रेम काउन्टरलाई बढाउनेछ।
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// ब्याकट्रेस आउटपुट पूरा गर्दछ।
    ///
    /// यो हाल कुनै अप्ट छैन तर ब्याकट्रेस ढाँचाहरूको साथ future अनुकूलताको लागि जोडिएको छ।
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // वर्तमानमा कुनै अपोइ---future थपको लागि अनुमति दिन यो hook सहित।
        Ok(())
    }
}

/// ब्याकट्रेसको केवल एक फ्रेमका लागि एक ढाँचा।
///
/// यो प्रकार `BacktraceFmt::frame` प्रकार्य द्वारा बनाईएको हो।
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// यो फ्रेम ढाँचाको साथ `BacktraceFrame` प्रिन्ट गर्दछ।
    ///
    /// यो पुनरावृत्तिकै `BacktraceFrame` भित्र सबै `BacktraceSymbol` उदाहरणहरु प्रिन्ट हुनेछ।
    ///
    /// # आवश्यक सुविधाहरू
    ///
    /// यस प्रकार्यलाई सक्षम पार्न `backtrace` crate को `std` सुविधा चाहिन्छ, र `std` सुविधा पूर्वनिर्धारितद्वारा सक्षम पारिएको छ।
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// `BacktraceFrame` भित्र `BacktraceSymbol` प्रिन्ट गर्दछ।
    ///
    /// # आवश्यक सुविधाहरू
    ///
    /// यस प्रकार्यलाई सक्षम पार्न `backtrace` crate को `std` सुविधा चाहिन्छ, र `std` सुविधा पूर्वनिर्धारितद्वारा सक्षम पारिएको छ।
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: यो ठूलो कुरा होइन कि हामी केहि पनि प्रिन्ट गर्न समाप्त गर्दैनौं
            // गैर-utf8 फाइलनामहरूको साथ।
            // धन्यबाद, लगभग सबै कुरा utf8 छ त्यसैले यो धेरै नराम्रो हुनु हुँदैन।
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// एक कच्चा ट्रेस गरिएको `Frame` र `Symbol` प्रिन्ट गर्दछ, सामान्यतया यो crate को कच्चा कलब्याक भित्रबाट।
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// ब्याकट्रेस आउटपुटमा एक कच्चा फ्रेम थप गर्दछ।
    ///
    /// यो विधि, अघिल्लो जस्तो छैन, कच्चा तर्कहरू लिन्छन् यदि तिनीहरू बिभिन्न स्थानहरूबाट स्रोत हुन सक्छन्।
    /// नोट गर्नुहोस् कि यसलाई एक फ्रेमका लागि धेरै पटक भन्न सकिन्छ।
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// स्तम्भ जानकारी सहित ब्याकट्रेस आउटपुटमा एक कच्चा फ्रेम थप गर्दछ।
    ///
    /// यो विधि, अघिल्लो जस्तै, कच्चा तर्कहरू लिन्छन् यदि तिनीहरू बिभिन्न स्थानहरूबाट स्रोत भईरहेछन्।
    /// नोट गर्नुहोस् कि यसलाई एक फ्रेमका लागि धेरै पटक भन्न सकिन्छ।
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia एक प्रक्रिया भित्र प्रतीक गर्न असमर्थ छ त्यसैले यसको एक विशेष ढाँचा छ जुन पछि प्रतीकको रूपमा प्रयोग गर्न सकिन्छ।
        // प्रिन्ट गर्नुहोस् बरु हाम्रो आफ्नै ढाँचामा ठेगाना मुद्रणको सट्टा।
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // "null" फ्रेमहरू प्रिन्ट गर्न आवश्यक पर्दैन, यसको मूल रूपमा भनेको यो छ कि प्रणाली ब्याकट्रेस एकदम पछाडि सुपर ट्रेस गर्न उत्सुक थियो।
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Sgx enclave मा TCB आकार कम गर्न, हामी प्रतीक संकल्प कार्यक्षमता कार्यान्वयन गर्न चाहँदैनौं।
        // बरु, हामी यहाँ ठेगानाको अफसेट प्रिन्ट गर्न सक्छौं, जुन पछि म्याप गर्न सकिन्छ समारोह ठीक गर्न।
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // फ्रेमको अनुक्रमणिका साथै फ्रेमको वैकल्पिक निर्देशन पोइन्टर प्रिन्ट गर्नुहोस्।
        // यदि हामी यस फ्रेमको पहिलो प्रतीक भन्दा बाहिर छौं यद्यपि हामी उचित उचित खाली स्थान प्रिन्ट गर्छौं।
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // अर्कोमा प्रतीकको नाम लेख्नुहोस्, थप जानकारीको लागि वैकल्पिक ढाँचा प्रयोग गरेर यदि हामी पूरा ब्याट्र्रेस छौं।
        // यहाँ हामी पनि प्रतीकहरु ह्याण्डल गर्छौं जसको नाम छैन,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // र अन्तिममा, filename/line नम्बर प्रिन्ट गर्नुहोस् यदि तिनीहरू उपलब्ध छन् भने।
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line प्रतीक नाम मुनि लाइनहरु मा मुद्रित छन्, त्यसैले दायाँ प al्क्तिबद्ध को क्रमबद्ध गर्न को लागी केहि उचित सफेद क्षेत्र प्रिन्ट गर्नुहोस्।
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // फाइलनाम प्रिन्ट गर्नका लागि हाम्रो आन्तरिक कलब्याकलाई बुझाउनुहोस् र त्यसपछि लाइन नम्बर प्रिन्ट गर्नुहोस्।
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // उपलब्ध भएमा स्तम्भ नम्बर थप्नुहोस्।
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // हामी केवल फ्रेमको पहिलो प्रतीकको बारेमा ख्याल राख्छौं
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}