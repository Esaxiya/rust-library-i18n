use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// एक स्वामित्व र स्व-निहित ब्याकट्रेसको प्रतिनिधित्व।
///
/// यो संरचना प्रोग्राममा बिभिन्न बिन्दुहरूमा ब्याकट्रेस क्याप्चर गर्न प्रयोग गर्न सकिन्छ र पछि त्यस समयमा ब्याकट्रेस के थियो निरीक्षण गर्न प्रयोग गर्न सकिन्छ।
///
///
/// `Backtrace` यसको `Debug` कार्यान्वयन मार्फत ब्याकट्रेसको प्रिन्टि। प्रिन्टि supports समर्थन गर्दछ।
///
/// # आवश्यक सुविधाहरू
///
/// यस प्रकार्यलाई सक्षम पार्न `backtrace` crate को `std` सुविधा चाहिन्छ, र `std` सुविधा पूर्वनिर्धारितद्वारा सक्षम पारिएको छ।
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // यहाँ फ्रेमहरू स्ट्याकको शीर्ष-देखि-तल सूचीबद्ध छन्
    frames: Vec<BacktraceFrame>,
    // हामीले विश्वास गर्ने अनुक्रमणिका ब्याकट्रेसको वास्तविक सुरुवात हो, `Backtrace::new` र `backtrace::trace` जस्ता फ्रेमहरू छोडिदै।
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// ब्याकट्रेसमा फ्रेमको क्याप्चर संस्करण।
///
/// यो प्रकार `Backtrace::frames` बाट सूचीको रूपमा फर्काइन्छ र क्याप्चर गरिएको ब्याट्र्रेसमा एउटा स्ट्याक फ्रेम प्रतिनिधित्व गर्दछ।
///
/// # आवश्यक सुविधाहरू
///
/// यस प्रकार्यलाई सक्षम पार्न `backtrace` crate को `std` सुविधा चाहिन्छ, र `std` सुविधा पूर्वनिर्धारितद्वारा सक्षम पारिएको छ।
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// ब्याकट्रेसमा प्रतीकको क्याप्चर संस्करण।
///
/// यो प्रकार `BacktraceFrame::symbols` बाट सूचीको रूपमा फर्काइएको छ र ब्याट्र्रेसमा प्रतीकको लागि मेटाडेटा प्रतिनिधित्व गर्दछ।
///
/// # आवश्यक सुविधाहरू
///
/// यस प्रकार्यलाई सक्षम पार्न `backtrace` crate को `std` सुविधा चाहिन्छ, र `std` सुविधा पूर्वनिर्धारितद्वारा सक्षम पारिएको छ।
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// यस प्रकार्यको कलसाइटमा एक ब्याट्र्यास् कब्जा, एक स्वामित्व प्रतिनिधित्व फिर्ता।
    ///
    /// यो प्रकार्य Rust मा एक वस्तुको रूपमा एक backtrace प्रतिनिधित्व को लागी उपयोगी छ।यो फिर्ता मानलाई थ्रेडहरूमा पठाउन सकिन्छ र कहिँ प्रिन्ट गर्न सकिन्छ, र यो मानको उद्देश्य पूर्ण रूपमा स्वयं समावेश हुनु हो।
    ///
    /// नोट गर्नुहोस् कि केहि प्लेटफर्महरूमा पूर्ण ब्याकट्रेस प्राप्त गर्दै यसलाई समाधान गर्न अति महँगो हुन सक्छ।
    /// यदि लागत तपाइँको अनुप्रयोगको लागि धेरै नै छ भने यसको सट्टा `Backtrace::new_unresolved()` प्रयोग गर्न सिफारिश गरिन्छ जसले प्रतीक रिजोलुसन चरणलाई बेवास्ता गर्दछ (जुन सामान्यतया सबैभन्दा लामो समय लाग्दछ) र पछाडि मितिमा डिफ्रिनिंग अनुमति दिन्छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # आवश्यक सुविधाहरू
    ///
    /// यस प्रकार्यलाई सक्षम पार्न `backtrace` crate को `std` सुविधा चाहिन्छ, र `std` सुविधा पूर्वनिर्धारितद्वारा सक्षम पारिएको छ।
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // यहाँ सुनिश्चित गर्न चाहानुहुन्छ कि त्यहाँ एक फ्रेम हटाउन को लागी छ
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// `new` को समान जस्तै यसले कुनै पनि प्रतीकहरू समाधान गर्दैन, यसले केवल ठेगानाहरूको सूचीको रूपमा ब्याकट्रेस कब्जा गर्दछ।
    ///
    /// पछि पछि `resolve` प्रकार्य पढ्न योग्य नामहरूमा यो ब्याकट्रेसको प्रतीकहरू समाधान गर्न कल गर्न सकिन्छ।
    /// यो प्रकार्य अवस्थित छ किनकि रिजोलुसन प्रक्रियाले कहिलेकाँही महत्वपूर्ण समय लिन सक्दछ जबकि कुनै एक ब्याट्र्रेस मात्र सायद कम मुद्रित हुन सक्छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // कुनै प्रतीक नामहरू छैनन्
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // प्रतीक नामहरू अहिले अवस्थित छन्
    /// ```
    ///
    /// # आवश्यक सुविधाहरू
    ///
    /// यस प्रकार्यलाई सक्षम पार्न `backtrace` crate को `std` सुविधा चाहिन्छ, र `std` सुविधा पूर्वनिर्धारितद्वारा सक्षम पारिएको छ।
    ///
    ///
    ///
    #[inline(never)] // यहाँ सुनिश्चित गर्न चाहानुहुन्छ कि त्यहाँ एक फ्रेम हटाउन को लागी छ
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// जब यो ब्याकट्रेस क्याप्चर गरियो फ्रेमबाट फर्काउँछ।
    ///
    /// यस स्लाइसको पहिलो प्रविष्टि सम्भवतः `Backtrace::new` प्रकार्य हो, र अन्तिम फ्रेम सम्भावित केहि यस थ्रेड वा मुख्य प्रकार्य कसरी सुरू भयो भन्ने बारे हुन सक्छ।
    ///
    ///
    /// # आवश्यक सुविधाहरू
    ///
    /// यस प्रकार्यलाई सक्षम पार्न `backtrace` crate को `std` सुविधा चाहिन्छ, र `std` सुविधा पूर्वनिर्धारितद्वारा सक्षम पारिएको छ।
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// यदि यो ब्याकट्रेस `new_unresolved` बाट सिर्जना गरिएको हो भने यस प्रकार्यले बैकट्रेसमा सबै ठेगानाहरूलाई तिनीहरूको प्रतीकात्मक नामहरूमा समाधान गर्दछ।
    ///
    ///
    /// यदि यो ब्याकट्रेस पहिले सुल्झाइएको छ वा `new` मार्फत सिर्जना गरिएको हो भने, यो प्रकार्यले केहि गर्दैन।
    ///
    /// # आवश्यक सुविधाहरू
    ///
    /// यस प्रकार्यलाई सक्षम पार्न `backtrace` crate को `std` सुविधा चाहिन्छ, र `std` सुविधा पूर्वनिर्धारितद्वारा सक्षम पारिएको छ।
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// `Frame::ip` को जस्तै
    ///
    /// # आवश्यक सुविधाहरू
    ///
    /// यस प्रकार्यलाई सक्षम पार्न `backtrace` crate को `std` सुविधा चाहिन्छ, र `std` सुविधा पूर्वनिर्धारितद्वारा सक्षम पारिएको छ।
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// `Frame::symbol_address` को जस्तै
    ///
    /// # आवश्यक सुविधाहरू
    ///
    /// यस प्रकार्यलाई सक्षम पार्न `backtrace` crate को `std` सुविधा चाहिन्छ, र `std` सुविधा पूर्वनिर्धारितद्वारा सक्षम पारिएको छ।
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// `Frame::module_base_address` को जस्तै
    ///
    /// # आवश्यक सुविधाहरू
    ///
    /// यस प्रकार्यलाई सक्षम पार्न `backtrace` crate को `std` सुविधा चाहिन्छ, र `std` सुविधा पूर्वनिर्धारितद्वारा सक्षम पारिएको छ।
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// प्रतीकहरूको सूची फर्काउँछ जुन यो फ्रेमसँग सम्बन्धित छ।
    ///
    /// सामान्यतया त्यहाँ प्रति फ्रेम मात्र एक प्रतीक हुन्छ, तर कहिलेकाँही यदि धेरै प्रकार्यहरू एक फ्रेममा सम्मिलित हुन्छन् भने बहु चिन्हहरू फिर्ता हुनेछन्।
    /// पहिलो प्रतीक सूचीबद्ध "innermost function" हो, जबकि अन्तिम प्रतीक बाहिरीतम (अन्तिम कलर) हो।
    ///
    /// नोट गर्नुहोस् कि यदि यो फ्रेम एक समाधान नगरिएको ब्याकट्रेसबाट आएको छ भने यसले खाली सूची फर्काउँछ।
    ///
    /// # आवश्यक सुविधाहरू
    ///
    /// यस प्रकार्यलाई सक्षम पार्न `backtrace` crate को `std` सुविधा चाहिन्छ, र `std` सुविधा पूर्वनिर्धारितद्वारा सक्षम पारिएको छ।
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// `Symbol::name` को जस्तै
    ///
    /// # आवश्यक सुविधाहरू
    ///
    /// यस प्रकार्यलाई सक्षम पार्न `backtrace` crate को `std` सुविधा चाहिन्छ, र `std` सुविधा पूर्वनिर्धारितद्वारा सक्षम पारिएको छ।
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// `Symbol::addr` को जस्तै
    ///
    /// # आवश्यक सुविधाहरू
    ///
    /// यस प्रकार्यलाई सक्षम पार्न `backtrace` crate को `std` सुविधा चाहिन्छ, र `std` सुविधा पूर्वनिर्धारितद्वारा सक्षम पारिएको छ।
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// `Symbol::filename` को जस्तै
    ///
    /// # आवश्यक सुविधाहरू
    ///
    /// यस प्रकार्यलाई सक्षम पार्न `backtrace` crate को `std` सुविधा चाहिन्छ, र `std` सुविधा पूर्वनिर्धारितद्वारा सक्षम पारिएको छ।
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// `Symbol::lineno` को जस्तै
    ///
    /// # आवश्यक सुविधाहरू
    ///
    /// यस प्रकार्यलाई सक्षम पार्न `backtrace` crate को `std` सुविधा चाहिन्छ, र `std` सुविधा पूर्वनिर्धारितद्वारा सक्षम पारिएको छ।
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// `Symbol::colno` को जस्तै
    ///
    /// # आवश्यक सुविधाहरू
    ///
    /// यस प्रकार्यलाई सक्षम पार्न `backtrace` crate को `std` सुविधा चाहिन्छ, र `std` सुविधा पूर्वनिर्धारितद्वारा सक्षम पारिएको छ।
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // पथ छाप्ने क्रममा हामी cwd लाई हटाउन कोशिस गर्छौं यदि यो अवस्थित छ, अन्यथा हामी केवल जसरी मार्गलाई प्रिन्ट गर्छौं।
        // नोट गर्नुहोस् कि हामी केवल छोटो ढाँचाका लागि यो पनि गर्छौं, किनकि यदि यो पूर्ण छ भने हामी सम्भवतः सबै कुरा छाप्न चाहन्छौं।
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}