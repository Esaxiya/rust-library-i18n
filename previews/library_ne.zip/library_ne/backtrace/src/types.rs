//! प्लेटफर्म निर्भर प्रकारहरू।

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// एक प्लेटफर्मको स्ट्रि ofको स्वतन्त्र प्रतिनिधित्व।
/// `std` सक्षमसँग कार्य गर्दा `std` प्रकारहरूमा रूपान्तरण प्रदान गर्नका लागि सुविधा विधिहरूमा सिफारिस गरिन्छ।
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// एक टुक्रा, सामान्यतया Unix प्लेटफार्महरूमा प्रदान गरिएको।
    Bytes(&'a [u8]),
    /// Windows बाट सामान्यतया चौडा स्ट्रिंगहरू।
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// हानि `Cow<str>` मा रूपान्तरण गर्दछ, यदि `Bytes` मान्य UTF-8 मान्य छैन वा `BytesOrWideString` `Wide` हो भने आवंटित हुनेछ।
    ///
    /// # आवश्यक सुविधाहरू
    ///
    /// यस प्रकार्यलाई सक्षम पार्न `backtrace` crate को `std` सुविधा चाहिन्छ, र `std` सुविधा पूर्वनिर्धारितद्वारा सक्षम पारिएको छ।
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// `BytesOrWideString` को `Path` प्रतिनिधित्व प्रदान गर्दछ।
    ///
    /// # आवश्यक सुविधाहरू
    ///
    /// यस प्रकार्यलाई सक्षम पार्न `backtrace` crate को `std` सुविधा चाहिन्छ, र `std` सुविधा पूर्वनिर्धारितद्वारा सक्षम पारिएको छ।
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}