//! Windows मा dbghelp बाइन्डि manहरू प्रबन्ध गर्न मद्दत गर्न
//!
//! Windows मा backtraces (कम्तिमा MSVC को लागी) `dbghelp.dll` र यसले समावेश गर्ने विभिन्न प्रकार्यहरू मार्फत ठूलो मात्रामा संचालित हुन्छ।
//! यी प्रकार्यहरू हालै लोड गरिन्छन् *गतिशील*`dbghelp.dll` लाई स्थिर रूपमा लि than्क गर्नु भन्दा।
//! यो हाल मानक पुस्तकालय द्वारा गरिएको हो (र त्यहाँ सिद्धान्तमा आवश्यक छ), तर पुस्तकालयको स्थिर dll निर्भरता कम गर्न मद्दत गर्ने प्रयास हो किनकि ब्याकट्रेस सामान्यतया राम्रो वैकल्पिक हुन्छ।
//!
//! त्यो भनिएको छ, `dbghelp.dll` लगभग सधैं सफलतापूर्वक Windows मा लोड गर्दछ।
//!
//! यद्यपि नोट गर्नुहोस् कि हामी यी सबै समर्थनलाई गतिशील रूपमा लोड गर्दैछौं हामी वास्तवमै `winapi` मा कच्चा परिभाषा प्रयोग गर्न सक्दैनौं, बरु हामी आफैं कार्य सूचक प्रकारहरू परिभाषित गर्न आवश्यक छ र त्यो प्रयोग गर्नुहोस्।
//! हामी वास्तवमा डुप्लिकेट विनोपीको व्यवसायमा हुन चाहँदैनौं, त्यसैले हामीसँग Cargo सुविधा `verify-winapi` छ जसले जोड दिन्छ कि सबै बाइन्डि winहरू winapi मा मिल्दछन् र यो सुविधा CI मा सक्षम गरिएको छ।
//!
//! अन्तमा, तपाइँले यहाँ नोट गर्नुहुनेछ कि `dbghelp.dll` को लागी dll कहिले पनि अनलोड हुने छैन, र त्यो हाल जानबूझकर छ।
//! सोच यो हो कि हामी विश्वव्यापी यसलाई क्यास गर्न सक्छौं र यसलाई एपीआईमा कलहरू बीच प्रयोग गर्न सक्दछौं, महँगो loads/unloads लाई बेवास्ता गर्दै।
//! यदि यो चुहावट डिटेक्टरहरूको लागि समस्या हो वा जस्तो कि हामी त्यहाँ पुलमा पुल पार गर्न सक्छौं।
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// `SymGetOptions` र `SymSetOptions` वरिपरि काम गर्नुहोस् winapi मा उपस्थित छैन।
// अन्यथा यो केवल तब प्रयोग हुन्छ जब हामी winapi बिरूद्ध डबल जाँच गर्दैछौं।
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // अझै winapi मा परिभाषित गरिएको छैन
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // यो winapi मा परिभाषित छ, तर यो गलत छ (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // अझै winapi मा परिभाषित गरिएको छैन
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// यो म्याक्रो `Dbghelp` संरचना परिभाषित गर्न प्रयोग गरिएको छ जुन आन्तरिक रूपमा सबै प्रकार्य सूचकहरू समावेश गर्दछ जुन हामी लोड गर्न सक्दछौं।
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// `dbghelp.dll` का लागि लोड DLL
            dll: HMODULE,

            // हामीले प्रयोग गर्न सक्ने प्रत्येक प्रकार्यका लागि प्रत्येक कार्य सूचक
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // सुरुमा हामीले DLL लोड गरेका छैनौं
            dll: 0 as *mut _,
            // इनिनेसनल सबै प्रकार्यहरू शून्यमा सेट छन् भनिन्छ तिनीहरू गतिशील रूपमा लोड हुन आवश्यक छ।
            //
            $($name: 0,)*
        };

        // प्रत्येक प्रकार्य प्रकारका लागि सुविधा टाइपफेफ।
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// `dbghelp.dll` खोल्न प्रयासहरू।
            /// यदि यसले कार्य गर्दछ वा `LoadLibraryW` असफल भयो भने त्रुटि फिर्ता गर्छ।
            ///
            /// Panics यदि पुस्तकालय पहिले नै लोड छ।
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // हामी प्रयोग गर्न चाहन्छौं प्रत्येक विधिका लागि प्रकार्य।
            // जब कल गरिन्छ या त क्यास्ड प्रकार्य सूचक पढ्छ वा लोड गर्दछ र लोड गरिएको मान फिर्ता गर्दछ।
            // लोडहरू सफल हुन जोड दिइन्छ।
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Dbghelp प्रकार्यहरू सन्दर्भमा क्लीनअप लकहरू प्रयोग गर्नको लागि सुविधा प्रोक्सी।
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// यस crate बाट `dbghelp` एपीआई प्रकार्यहरू पहुँच गर्न आवश्यक सबै समर्थन सुरू गर्नुहोस्।
///
///
/// नोट गर्नुहोस् कि यो प्रकार्य **सुरक्षित** हो, आन्तरिक रूपमा यसको आफ्नै सि own्क्रोनाइजेसन छ।
/// यो पनि नोट गर्नुहोस् कि यस प्रकार्यलाई धेरै चोटि पुनरावृत्ति रूपमा कल गर्नु सुरक्षित छ।
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // हामीले गर्नुपर्ने सबैभन्दा पहिले यस प्रकार्यलाई सिंक्रोनाइज गर्नु हो।यसलाई एक साथ अर्को थ्रेडबाट समवर्ती भनिन्छ वा एक थ्रेड भित्र रिकर्सिभली भनिन्छ।
        // नोट गर्नुहोस् कि यो त्यस भन्दा पनि मुश्किल छ किनकि हामी यहाँ के प्रयोग गरिरहेका छौं, `dbghelp`,*पनि* यस प्रक्रियामा `dbghelp` मा सबै अन्य कलरहरूसँग सि sy्क्रोनाइज गर्न आवश्यक छ।
        //
        // सामान्यतया त्यहि प्रक्रिया भित्र `dbghelp` मा धेरै कलहरू भएनन् र हामी सुरक्षित रूपमा यो अनुमान गर्न सक्दछौं कि हामी मात्र यसमा पहुँच गरिरहेका छौं।
        // त्यहाँ एउटा प्राथमिक अन्य प्रयोगकर्ता छ जुन हामीले चिन्ता लिनु पर्छ जुन विडम्बनाका आफैं हो, तर मानक पुस्तकालयमा।
        // Rust मानक पुस्तकालय ब्याकट्रेस समर्थनको लागि यो crate मा निर्भर गर्दछ, र यो crate crates.io मा पनि अवस्थित छ।
        // यसको मतलब यो हो कि यदि मानक लाइब्रेरीले panic ब्याकट्रेस प्रिन्ट गर्दैछ भने यो crate crates.io बाट आउँदा दौडन सक्छ, सेगफाल्टको कारण।
        //
        // यो सिnch्क्रोनाइजेसन समस्या समाधान गर्न मद्दतको लागि हामी यहाँ विन्डोज-विशिष्ट ट्रिक रोजगार गर्दछौं (यो सबैमा सि sy्क्रोनाइजेसनको बारेमा विन्डोज-विशिष्ट प्रतिबन्ध हो)।
        // हामी यस कललाई सुरक्षा दिन म्युटेक्स नामको एक सेशन-स्थानीय * बनाउँदछौं।
        // यहाँ अभिप्राय यो हो कि मानक लाइब्रेरी र यो crate ले यहाँ सि sy्ख्रोनाइज गर्नको लागि Rust-स्तर एपीआईहरू साझेदारी गर्नु पर्दैन तर पछाडि पछाडि काम गर्न सक्दछ कि तिनीहरू एक अर्कासँग सिन्क्रोनाइज गर्दैछन्।
        //
        // त्यस तरीकाले जब यो प्रकार्य लाईन्डर लाइब्रेरी मार्फत वा crates.io मार्फत कल गरिन्छ हामी निश्चित हुन सक्छौं कि उही म्युटेक्स अधिग्रहण गरिएको छ।
        //
        // त्यसो भए सबै भन्नको लागि हामी यहाँ के गर्छौं भने हामीले आणविक हिसाबले `HANDLE` सिर्जना गर्छौं जुन Windows मा नामित म्युटेक्स हो।
        // हामी अन्य थ्रेडहरूसँग यो प्रकार्य विशेष रूपमा साझेदारी गर्नका लागि अलि सिnch्क्रोनाइज गर्दछौं र यो सुनिश्चित गर्दछौं कि यस प्रकार्यको प्रत्येक उदाहरणका लागि केवल एक ह्यान्डल सिर्जना गरिएको छ।
        // नोट गर्नुहोस् कि ह्यान्डल कहिले पनि बन्द हुँदैन जब यो ग्लोबलमा भण्डार हुन्छ।
        //
        // हामीले वास्तवमै लक गरेपछि हामी यसलाई प्राप्त गर्छौं, र हामीले हाम्रा `Init` ह्यान्डललाई बाहिर निकाल्छौं जुन अन्ततः यसलाई ड्रप गर्न जिम्मेवार हुनेछ।
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // ठीक छ, pho!अब हामी सबै सुरक्षित रूपमा सिnch्क्रोनाइज भएका छौं, वास्तवमा सबै कुरा प्रशोधन गर्न सुरु गरौं।
        // पहिले हामीले यो सुनिश्चित गर्नु पर्छ कि `dbghelp.dll` वास्तवमै यस प्रक्रियामा लोड गरिएको छ।
        // हामी स्थिर गतिशील निर्भरताबाट बच्नको लागि यसलाई गतिशील रूपमा गर्छौं।
        // यो ऐतिहासिक रूपमा अनौंठो लिंक गर्ने मुद्दाहरूको वरिपरि कार्य गर्न गरिएको हो र बाइनरीहरूलाई अलि बढी पोर्टेबल बनाउने उद्देश्यले गरिएको छ किनकि यो मुख्यतया एक डिबगिंग उपयोगिता हो।
        //
        //
        // एकचोटि हामीले `dbghelp.dll` खोल्‍यौं हामीले यसमा केही इनिसियलाइजेसनहरू कल गर्न आवश्यक पर्दछ, र त्यो तल विस्तृत छ।
        // हामी यो मात्र एक पटक गर्छौं, यद्यपि हामीले ग्लोबल बुलियन पाएका छौं जुन हामीले अझसम्म सम्पन्न गरेका छौं वा छैन भनेर स .्केत गर्दछ।
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // `SYMOPT_DEFERRED_LOADS` झण्डा सेट गरिएको छ भनि निश्चित गर्नुहोस्, किनकि यस बारे MSVC आफ्नै कागजात अनुसार: "This is the fastest, most efficient way to use the symbol handler.", त्यसोभए त्यो गरौं!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // वास्तवमा MSVC को साथ प्रतीकहरू सुरूवात गर्नुहोस्।नोट गर्नुहोस् कि यो असफल हुन सक्छ, तर हामी यसलाई बेवास्ता गर्दछौं।
        // यस प्रति सेपको लागि त्यहाँ एक टन कला छैन, तर एलएलभीएम आन्तरिक रूपमा यहाँ फिर्ती मूल्यलाई बेवास्ता गर्दछ जस्तो देखिन्छ र एलएलभीएममा रहेको एक सेनेटिसेयर पुस्तकालयले एक डरलाग्दो चेतावनी प्रिन्ट गर्दछ यदि असफल भयो तर मूल रूपमा लामो समयसम्म यसलाई बेवास्ता गर्दछ।
        //
        //
        // एक केस यो Rust को लागी धेरै आउँछ जुन मानक लाइब्रेरी र crates.io मा यो crate दुबै `SymInitializeW` को लागि प्रतिस्पर्धा गर्न चाहन्छ।
        // ऐतिहासिक पुस्तकालय ऐतिहासिक रुपमा धेरै जसो समय सफा गर्न थालनी चाहन्थ्यो, तर अब यो crate प्रयोग गरिरहेको छ यसको मतलब यो हो कि कोही पहिले आरम्भमा जान्छ र अर्कोले त्यो आरम्भ छान्छ।
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}