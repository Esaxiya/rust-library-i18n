use backtrace::Backtrace;

// - ०-चरित्र मोड्युल नाम
mod _234567890_234567890_234567890_234567890_234567890 {
    // - ०-चरित्र संरचना नाम
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// लामो समारोह नामहरू (MAX_SYM_NAME, १) वर्णहरूमा काटिनु पर्छ।
// केवल msvc का लागि यो परीक्षण चलाउनुहोस्, किनकि gnu सबै फ्रेमहरूको लागि "<no info>" प्रिन्ट गर्दछ।
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // संरचना नामको १० पुनरावृत्तिहरू, त्यसैले पूर्ण रूपमा योग्य प्रकार्य नाम कम्तिमा पनि कमसेकम १० *(+० +)०)* २=२००० वर्ण लामो छ।
    //
    // यो वास्तवमै लामो छ किनकि यसले `::`, `<>` र हालको मोड्युलको नाम पनि समावेश गर्दछ
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}