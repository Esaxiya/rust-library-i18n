use backtrace::Backtrace;

// यो परीक्षणले प्लेटफर्महरूमा मात्र काम गर्दछ जुन फ्रेमको लागि कार्य गर्ने `symbol_address` प्रकार्य छ जुन प्रतीकको सुरूवात ठेगाना रिपोर्ट गर्दछ।
// नतिजाको रूपमा यो केवल केहि प्लेटफर्महरूमा सक्षम छ।
//
const ENABLED: bool = cfg!(all(
    // Windows वास्तवमै परीक्षण गरिएको छैन, र OSX वास्तवमा एक संलग्न फ्रेम खोज्न समर्थन गर्दैन, त्यसैले यसलाई अक्षम गर्नुहोस्
    //
    target_os = "linux",
    // एआरएममा एन्क्लोजिंग प्रकार्य फेला पार्दै आईपीमा मात्र फर्कन्छ।
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}