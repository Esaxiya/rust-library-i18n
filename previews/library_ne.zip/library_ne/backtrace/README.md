# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Rust का लागि रनटाइममा ब्याकट्रेसहरू प्राप्त गर्नका लागि पुस्तकालय।
यस पुस्तकालयको उद्देश्य काम गर्नको लागि प्रोग्रामेटिक ईन्टरफेस प्रदान गरेर मानक लाइब्रेरीको समर्थन बढाउनु हो, तर यसले लिबस्टेडको panics जस्तो हालको ब्याकट्रेसलाई सजीलै मुद्रण गर्न पनि समर्थन गर्दछ।

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

केवल एक ब्याट्रैस कब्जा गर्न र एक पछि समय सम्म यसको साथ कामकाजी डिफरर, तपाईं शीर्ष-स्तर `Backtrace` प्रकार प्रयोग गर्न सक्नुहुनेछ।

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

यदि, तथापि, तपाईं वास्तविक ट्रेसिंग कार्यक्षमतामा बढी कच्चा पहुँच चाहनुहुन्छ भने, तपाईं `trace` र `resolve` प्रकार्यहरू सिधा उपयोग गर्न सक्नुहुनेछ।

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // प्रतीक नाममा यस निर्देश पोइन्टरलाई समाधान गर्नुहोस्
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // अर्को फ्रेममा जान जारी राख्नुहोस्
    });
}
```

# License

यो परियोजना मध्ये कुनै एक अन्तर्गत इजाजतपत्र छ

 * Apache लाइसेन्स, संस्करण 2.0, ([LICENSE-APACHE](LICENSE-APACHE) वा http://www.apache.org/licenses/LICENSE-2.0)
 * MIT लाईसेन्स ([LICENSE-MIT](LICENSE-MIT) वा http://opensource.org/licenses/MIT)

तपाईंको विकल्पमा।

### Contribution

जबसम्म तपाईं स्पष्ट रूपमा बताउनुहुन्न, Apache-2.0 लाईसेन्समा परिभाषित गरे अनुसार तपाईले ब्याकट्रेस-आरएसमा समावेश गर्नको लागि जानाजानी बुझाउनु भएको कुनै योगदान, कुनै पनि अतिरिक्त सर्तहरू वा सर्तहरू बिना माथिको रूपमा दोहोरो इजाजतपत्र हुनेछ।







