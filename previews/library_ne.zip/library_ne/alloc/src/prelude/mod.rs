//! Preolve को विनियोजन
//!
//! यस मोड्युलको उद्देश्य `alloc` crate को सामान्य रूपमा प्रयोग हुने वस्तुहरूको आयात हटाउन मोड्युलहरूको शीर्षमा एक ग्लोब आयात थपेर:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;