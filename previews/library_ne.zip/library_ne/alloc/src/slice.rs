//! संक्रमित अनुक्रममा गतिशील-आकारको दृश्य, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! स्लाइसहरू मेमोरीको ब्लकमा एक पोइन्टर र लम्बाइको रूपमा प्रतिनिधित्व गरिन्छ।
//!
//! ```
//! // एक Vec काट्ने
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // एक स्लाइस गर्न एर्रे जबरजस्ती
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! स्लाइसहरू या त म्यूटेबल वा साझा छन्।
//! साझा स्लाइस प्रकार `&[T]` हो, जबकि परिवर्तनीय स्लाइस प्रकार `&mut [T]` हो, जहाँ `T` तत्व प्रकार प्रतिनिधित्व गर्दछ।
//! उदाहरण को लागी, तपाईले मेमोरीको ब्लक परिवर्तन गर्न सक्नुहुन्छ जुन एक परिवर्तनीय स्लाइसले संकेत गर्दछ:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! यहाँ केहि चीजहरू यस मोड्युलले समावेश गर्दछ:
//!
//! ## Structs
//!
//! त्यहाँ धेरै स्ट्रिकहरू छन् जुन स्लाइसहरूका लागि उपयोगी छ, जस्तै [`Iter`], जसले स्लाइसमा पुनरावृत्ति प्रतिनिधित्व गर्दछ।
//!
//! ## Trait कार्यान्वयन
//!
//! स्लासहरूका लागि सामान्य traits को धेरै कार्यान्वयनहरू छन्।केहि उदाहरणहरूमा समावेश छ:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], स्लाइसहरूको लागि जसको एलिमेन्ट प्रकार [`Eq`] वा [`Ord`] हुन्।
//! * [`Hash`] - स्लाइसहरूको लागि जसको एलिमेन्ट प्रकार [`Hash`] हो।
//!
//! ## Iteration
//!
//! स्लाइसहरू `IntoIterator` कार्यान्वयन गर्दछ।इटरेटरले स्लाइस एलिमेन्टहरूको सन्दर्भ दिन्छ।
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! म्यूटेबल स्लाइसले तत्वहरूमा म्यूटेबल सन्दर्भ दिन्छ।
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! यस इटरेटरले स्लाइसको एलिमेन्टहरूमा म्यूटेबल रेफरेंस दिन्छ, त्यसैले स्लाइसको एलिमेन्ट प्रकार एक्स ०१ एक्स हुन्छ भने इट्रेटरको एलिमेन्ट प्रकार एक्स १००० हुन्छ।
//!
//!
//! * [`.iter`] र [`.iter_mut`] स्पष्ट विधिहरू पूर्वनिर्धारित पुनरावर्तकहरू फर्काउनका लागि हो।
//! * थप विधिहरू जुन इटरेटर्स फिर्ता हुन्छन् [`.split`], [`.splitn`], [`.chunks`], [`.windows`] र अधिक।
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// यस मोड्युलमा धेरै प्रयोगहरू केवल परीक्षण कन्फिगरेसनमा प्रयोग हुन्छन्।
// यसलाई सफा गर्नुहोस् केवल अप्रयुक्त_इम्पोर्ट चेतावनी बन्द गर्नलाई तिनीहरूलाई सच्याउनु भन्दा।
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// आधारभूत स्लाइस विस्तार विधाहरू
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) NB परीक्षणको समयमा `vec!` म्याक्रोको कार्यान्वयनको लागि आवश्यक छ, अधिक जानकारीको लागि यस फाईलमा `hack` मोड्युल हेर्नुहोस्।
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) NB परीक्षणको समयमा `Vec::clone` कार्यान्वयनको लागि आवश्यक छ, अधिक जानकारीका लागि यस फाईलमा `hack` मोड्युल हेर्नुहोस्।
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): cfg(test) `impl [T]` उपलब्ध छैन, यी तीन प्रकार्यहरू वास्तवमा विधिहरू हुन् जुन `impl [T]` मा छन् तर `core::slice::SliceExt` मा छैनन्, हामीले यी कार्यहरू `test_permutations` परीक्षणको लागि आपूर्ति गर्न आवश्यक छ।
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // हामीले यसमा इनलाइन एट्रिब्यूट थप्न हुँदैन किनकि यो अधिकतर `vec!` म्याक्रोमा प्रयोग गरीन्छ र उत्तम रिग्रेसनको कारण दिन्छ।
    // छलफल र उत्तम परिणामहरूको लागि #71204 हेर्नुहोस्।
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // आईटमहरू तल लूपमा आरम्भ गरिएको चिन्ह लगाईयो
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) LLVM को लागी सीमा जाँच हटाउन आवश्यक छ र zip भन्दा राम्रो कोडजेन छ।
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // कम से कम यस लम्बाइको लागि vec आवंटित र आरम्भ गरिएको थियो।
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // `s` को क्षमताको साथ माथि विनियोजित, र `s.len()` मा ptr::copy_to_non_overlapping मा इनिसियलाइज गर्नुहोस्।
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// स्लाइस क्रमबद्ध गर्दछ।
    ///
    /// यो क्रमबद्ध स्थिर छ (जस्तै, समान तत्वहरूलाई पुनःक्रम गराउँदैन) र *O*(*n*\*log(* n*)) खराब अवस्था)।
    ///
    /// जब लागू हुन्छ, अस्थिर क्रमबद्ध गर्न रुचाईन्छ किनकि यो सामान्य छिटो छिटो भन्दा छिटो हुन्छ र यसले सहायक मेमोरी वाटप गर्दैन।
    /// [`sort_unstable`](slice::sort_unstable) हेर्नुहोस्।
    ///
    /// # वर्तमान कार्यान्वयन
    ///
    /// हालको एल्गोरिथ्म एक अनुकूलन, पुनरावृत्ति मर्ज क्रम [timsort](https://en.wikipedia.org/wiki/Timsort) बाट प्रेरित हो।
    /// यो स्लाइस लगभग क्रमबद्ध गरिएको अवस्थामा धेरै छिटोको लागि डिजाइन गरिएको हो, वा दुई वा बढी क्रमबद्ध श्रृences्खलाहरू एक पछि अर्को एकत्रित गरिएको हुन्छ।
    ///
    ///
    /// साथै, यसले अस्थायी भण्डारण `self` को आधा आकार बाँडफाँड गर्दछ, तर छोटो स्लाइसहरूको लागि एक गैर-विनियोजन सम्मिलित क्रम यसको सट्टा प्रयोग गरिन्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// एक तुलनाकर्ता प्रकार्यको साथ स्लाइसलाई क्रमबद्ध गर्दछ।
    ///
    /// यो क्रमबद्ध स्थिर छ (जस्तै, समान तत्वहरूलाई पुनःक्रम गराउँदैन) र *O*(*n*\*log(* n*)) खराब अवस्था)।
    ///
    /// कम्पारेटर कार्यले स्लाइसमा एलिमेन्टहरूको लागि कुल अर्डरिंग परिभाषित गर्नुपर्दछ।यदि अर्डरिंग कुल छैन भने, तत्वहरूको क्रम अनिर्दिष्ट छ।
    /// एउटा अर्डर कुल आदेश हो जुन यो हो (सबै `a`, `b` र `c` को लागी):
    ///
    /// * कुल र एन्टिस्मिमेट्रिक: `a < b`, `a == b` वा `a > b` मध्ये एक सही हो, र
    /// * ट्रान्जिटिभ, `a < b` र `b < c` `a < c` लागू गर्दछ।समान दुबै `==` र `>` को लागी समात्नु पर्छ।
    ///
    /// उदाहरणको लागि, जबकि [`f64`] ले [`Ord`] कार्यान्वयन गर्दैन किनकि `NaN != NaN`, हामी `partial_cmp` लाई हाम्रो क्रमबद्ध प्रकार्यको रूपमा प्रयोग गर्न सक्दछौं जब हामीलाई थाहा हुन्छ स्लाइसमा एक `NaN` समावेश छैन।
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// जब लागू हुन्छ, अस्थिर क्रमबद्ध गर्न रुचाईन्छ किनकि यो सामान्य छिटो छिटो भन्दा छिटो हुन्छ र यसले सहायक मेमोरी वाटप गर्दैन।
    /// [`sort_unstable_by`](slice::sort_unstable_by) हेर्नुहोस्।
    ///
    /// # वर्तमान कार्यान्वयन
    ///
    /// हालको एल्गोरिथ्म एक अनुकूलन, पुनरावृत्ति मर्ज क्रम [timsort](https://en.wikipedia.org/wiki/Timsort) बाट प्रेरित हो।
    /// यो स्लाइस लगभग क्रमबद्ध गरिएको अवस्थामा धेरै छिटोको लागि डिजाइन गरिएको हो, वा दुई वा बढी क्रमबद्ध श्रृences्खलाहरू एक पछि अर्को एकत्रित गरिएको हुन्छ।
    ///
    /// साथै, यसले अस्थायी भण्डारण `self` को आधा आकार बाँडफाँड गर्दछ, तर छोटो स्लाइसहरूको लागि एक गैर-विनियोजन सम्मिलित क्रम यसको सट्टा प्रयोग गरिन्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // उल्टो क्रमबद्ध
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// कुञ्जी निकासी प्रकार्यका साथ स्लाइसलाई क्रमबद्ध गर्दछ।
    ///
    /// यो क्रमबद्ध स्थिर छ (जस्तै, समान तत्वहरूलाई पुनःक्रम गराउँदैन) र *O*(*m*\* * n *\* log(*n*)) खराब अवस्था, जहाँ प्रमुख प्रकार्य *O*(*m*) हो।
    ///
    /// महँगो कुञ्जी कार्यहरूको लागि (उदाहरण:
    /// प्रकार्यहरू जुन साधारण सम्पत्ती पहुँच वा आधारभूत अपरेशनहरू छैनन्), [`sort_by_cached_key`](slice::sort_by_cached_key) चाँडै नै चाँडो हुने सम्भावना छ, किनकि यसले तत्व कुञ्जीहरू पुन: कम्प्युट गर्दैन।
    ///
    ///
    /// जब लागू हुन्छ, अस्थिर क्रमबद्ध गर्न रुचाईन्छ किनकि यो सामान्य छिटो छिटो भन्दा छिटो हुन्छ र यसले सहायक मेमोरी वाटप गर्दैन।
    /// [`sort_unstable_by_key`](slice::sort_unstable_by_key) हेर्नुहोस्।
    ///
    /// # वर्तमान कार्यान्वयन
    ///
    /// हालको एल्गोरिथ्म एक अनुकूलन, पुनरावृत्ति मर्ज क्रम [timsort](https://en.wikipedia.org/wiki/Timsort) बाट प्रेरित हो।
    /// यो स्लाइस लगभग क्रमबद्ध गरिएको अवस्थामा धेरै छिटोको लागि डिजाइन गरिएको हो, वा दुई वा बढी क्रमबद्ध श्रृences्खलाहरू एक पछि अर्को एकत्रित गरिएको हुन्छ।
    ///
    /// साथै, यसले अस्थायी भण्डारण `self` को आधा आकार बाँडफाँड गर्दछ, तर छोटो स्लाइसहरूको लागि एक गैर-विनियोजन सम्मिलित क्रम यसको सट्टा प्रयोग गरिन्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// कुञ्जी निकासी प्रकार्यका साथ स्लाइसलाई क्रमबद्ध गर्दछ।
    ///
    /// क्रमबद्ध गर्दा, कुञ्जी प्रकार्य एक पटक प्रति तत्व मात्र भनिन्छ।
    ///
    /// यो क्रमबद्ध स्थिर छ (जस्तै, समान तत्वहरूलाई पुनःक्रम गराउँदैन) र *O*(*m*\* * n *+ n*\*log(* n *)) खराब अवस्था, जहाँ प्रमुख प्रकार्य* O *(* m *) हो ।
    ///
    /// साधारण कुञ्जी प्रकार्यका लागि (उदाहरणका लागि सम्पत्ती पहुँच वा आधारभूत अपरेशनहरू हुन्), [`sort_by_key`](slice::sort_by_key) चाँडो हुने सम्भावना छ।
    ///
    /// # वर्तमान कार्यान्वयन
    ///
    /// हालको एल्गोरिथ्म ओरसन पीटर्स द्वारा [pattern-defeating quicksort][pdqsort] मा आधारित छ, जुन र्यान्डमाइज क्विकोर्टको द्रुत औसत केसलाई हिप्सोर्टको द्रुत खराब स्थितिसँग मिल्दछ, जबकि निश्चित ढाँचाको साथ स्लाइसहरूमा रेखीय समय प्राप्त गर्दै।
    /// यसले केहि डण्डमाइजेशनको प्रयोग गर्दछ डिजेनेरेट केसहरू जोगिनको लागि, तर स्थिर seed को साथ सँधै डिस्ट्रिमन्टिक व्यवहार प्रदान गर्न।
    ///
    /// सबैभन्दा नराम्रो अवस्थामा, एल्गोरिथ्मले `Vec<(K, usize)>` मा स्लाइसको लम्बाइमा अस्थायी भण्डारण वितरण गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // सहयोगी म्याक्रो हाम्रो vector साना सम्भावित प्रकारबाट अनुक्रमणिका लागि, विनियोजन घटाउनको लागि।
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // `indices` को एलिमेन्टहरू अद्वितीय हुन्छन्, किनकि उनीहरूलाई अनुक्रमित गरिन्छ, त्यसैले कुनै पनि क्रमबद्ध मौलिक स्लाइसको सम्बन्धमा स्थिर हुनेछ।
                // हामी यहाँ `sort_unstable` प्रयोग गर्छौं किनकि यसको लागि मेमोरी विनियोजन कम आवश्यक छ।
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// `self` लाई नयाँ `Vec` मा प्रतिलिपि गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // यहाँ, `s` र `x` स्वतन्त्र रूप मा परिमार्जन गर्न सकिन्छ।
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// एक एक्सलोटरको साथ `self` नयाँ `Vec` मा प्रतिलिपि गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // यहाँ, `s` र `x` स्वतन्त्र रूप मा परिमार्जन गर्न सकिन्छ।
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // एनबी, अधिक जानकारीको लागि यस फाईलमा `hack` मोड्युल हेर्नुहोस्।
        hack::to_vec(self, alloc)
    }

    /// `self` लाई vector मा क्लोन वा विनियोजन बिना रूपान्तरण गर्दछ।
    ///
    /// परिणामस्वरूप vector `Vec मार्फत फिर्ता बक्समा रूपान्तरण गर्न सकिन्छ<T>X को `into_boxed_slice` विधि।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` अब प्रयोग गर्न सकिदैन किनकि यो `x` मा रूपान्तरण गरिएको छ।
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // एनबी, अधिक जानकारीको लागि यस फाईलमा `hack` मोड्युल हेर्नुहोस्।
        hack::into_vec(self)
    }

    /// vector सिर्जना गर्दछ एक टुक्रा `n` पटक दोहोर्याएर।
    ///
    /// # Panics
    ///
    /// यो समारोह panic हुनेछ यदि क्षमता ओभरफ्लो हुनेछ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// ओभरफ्लोमा एक panic:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // यदि `n` शून्य भन्दा ठूलो छ भने, यो `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` को रूपमा विभाजित गर्न सकिन्छ।
        // `2^expn` `n` को बायाँ '1' बिट द्वारा प्रतिनिधित्व गरिएको संख्या हो, र `rem` `n` को बाँकी भाग हो।
        //
        //

        // `set_len()` पहुँच गर्न `Vec` प्रयोग गर्दै।
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` दोहोर्यादै `buf` `Expn`-पटक दोहोर्याएर गरिन्छ।
        buf.extend(self);
        {
            let mut m = n >> 1;
            // यदि `m > 0`, बाँकी बिट्सहरू बाँकी '1' सम्म बाँकी छन्।
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` `self.len() * n` को क्षमता छ।
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, २ ^ Expn`) पुनरावृत्ति `buf` बाटै `rem` X पुनरुक्तिहरूको प्रतिलिपि गरेर गरिन्छ।
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // यो `2^expn > rem` पछि गैर ओभरल्यापि is हो।
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` `buf.capacity()` (`= self.len() * n`)) बराबर।
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// `T` को एक टुक्रालाई एकल मान `Self::Output` चाप्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// `T` को एक एकल मान `Self::Output` मा टुक्रा फ्ल्याट गर्दछ, प्रत्येक बीचमा दिइएको विभाजक राख्छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// `T` को एक एकल मान `Self::Output` मा टुक्रा फ्ल्याट गर्दछ, प्रत्येक बीचमा दिइएको विभाजक राख्छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// एक vector फर्काउँछ जहाँ यस स्लाइसको प्रतिलिपि हुन्छ जहाँ प्रत्येक बाइटलाई यसको ASCII अपर केस बराबरमा म्याप गरिएको हुन्छ।
    ///
    ///
    /// 'z' लाई 'a' लाई ASCII अक्षरहरू 'A' लाई 'Z' मा म्याप गरिएको छ, तर गैर-ASCII अक्षर परिवर्तन गरिएको छैन।
    ///
    /// ठाउँमा ठूलो मानको लागि, [`make_ascii_uppercase`] प्रयोग गर्नुहोस्।
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// यस स्लाइसको प्रतिलिपि भएको vector फर्काउँछ जहाँ प्रत्येक बाइट यसको ASCII लोअर केस बराबरमा म्याप गरिएको हुन्छ।
    ///
    ///
    /// 'Z' लाई 'A' लाई ASCII अक्षरहरू 'a' लाई 'z' मा म्याप गरिएको छ, तर गैर-ASCII अक्षर परिवर्तन गरिएको छैन।
    ///
    /// ठाँउमा मूल्य सानो ठाउँमा राख्न, [`make_ascii_lowercase`] प्रयोग गर्नुहोस्।
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// विशेष प्रकारको डेटामा स्लाइसहरूको लागि traits विस्तार
////////////////////////////////////////////////////////////////////////////////

/// [`[T]: : concat`](टुक्रा::कन्कट) को लागी सहयोगी trait।
///
/// Note: `Item` प्रकार प्यारामिटर यो trait मा प्रयोग गरीएको छैन, तर यसले इम्प्ल्सलाई बढी सामान्य हुने अनुमति दिन्छ।
/// यो बिना, हामी यो त्रुटि पाउँछौं:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// यो किनभने त्यहाँ `V` प्रकारहरू बहु `Borrow<[_]>` impl साथ हुन सक्छ, जस्तै कि बहु `T` प्रकारहरू लागू हुनेछ:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// सम्मिलित पछि नतिजा प्रकार
    type Output;

    /// [`[T]: : concat`](स्लाइस::कन्कट) को कार्यान्वयन
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// [`[T]: : join`] का लागि सहयोगी trait (टुक्रा::सामेल)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// सम्मिलित पछि नतिजा प्रकार
    type Output;

    /// [`[T]: : join`] को कार्यान्वयन (टुक्रा::सामेल)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// स्लाइसहरूको लागि मानक trait कार्यान्वयन
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // लक्ष्यमा केहि पनि छोड्नुहोस् जुन अधिलेखन हुँदैन
        target.truncate(self.len());

        // target.len <= self.len माथिको काटिएको कारण, त्यसैले यहाँ स्लाइसहरू जहिले पनि सीमामा हुन्छन्।
        //
        let (init, tail) = self.split_at(target.len());

        // समावेश भएको मान allocations/resources पुन: प्रयोग गर्नुहोस्।
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// `v[0]` पूर्व क्रमबद्ध क्रम `v[1..]` मा सम्मिलित गर्दछ ताकि सम्पूर्ण `v[..]` क्रमबद्ध हुन्छ।
///
/// यो सम्मिलित क्रम को अभिन्न subroutine छ।
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // यहाँ सम्मिलित लागू गर्न तीन तरिकाहरू छन्:
            //
            // 1. पहिलो एकको अन्तिम गन्तव्यमा पुग्न नसके सम्म आसन्न तत्त्वहरूलाई स्वैप गर्नुहोस्।
            //    यद्यपि यस तरिकाले हामी डाटाको प्रतिलिपि गर्छौं आवश्यक भन्दा बढी।
            //    यदि तत्वहरू ठूला संरचनाहरू हुन् (प्रतिलिपि गर्न महँगो), यो विधि ढिलो हुनेछ।
            //
            // 2. पहिलो तत्वको लागि सहि ठाउँ नभएसम्म इटेरेट गर्नुहोस्।
            // त्यसपछि यसको लागि ठाउँ बनाउन सफल एलिमेन्टहरू सिफ्ट गर्नुहोस् र अन्तमा बाँकी प्वालमा राख्नुहोस्।
            // यो राम्रो तरीका हो।
            //
            // 3. पहिलो तत्वलाई अस्थायी भ्यारीएबलमा प्रतिलिपि गर्नुहोस्।यसको लागि सही ठाँउ नभएसम्म इटेरेट गर्नुहोस्।
            // हामी सँगसँगै जाने क्रममा, प्रत्येक ट्र्यार्स्ड एलिमेन्टको प्रतिलिपि गर्नुहोस् यस अघि रहेका स्लटमा।
            // अन्तमा, अस्थायी चरबाट बाँकी प्वालमा डाटा प्रतिलिपि गर्नुहोस्।
            // यो विधि धेरै राम्रो छ।
            // बेन्चमार्कले दोस्रो मेथडको तुलनामा थोरै राम्रो प्रदर्शन देखायो।
            //
            // सबै विधिहरू बेन्चमार्क गरिएको थियो, र तेस्रोले राम्रो परिणामहरू देखायो।त्यसैले हामीले त्यो छनौट गर्यौं।
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // सम्मिलन प्रक्रियाको मध्यवर्ती अवस्था सँधै `hole` द्वारा ट्र्याक हुन्छ, जसले दुई उद्देश्यहरू गर्दछ:
            // 1. X0 `v` को `is_less` मा panics बाट अखण्डतालाई सुरक्षित गर्दछ।
            // 2. `v` मा अन्तमा बाँकी प्वाल भरिन्छ।
            //
            // Panic सुरक्षा:
            //
            // यदि `is_less` panics प्रक्रियाको बखत कुनै पनि बिन्दुमा, `hole` ड्रप हुन्छ र `v` मा प्वाल `tmp` को साथ भरिन्छ, त्यसैले `v` ले अझै पनि प्रत्येक वस्तु राख्दछ भन्ने कुराको सुनिश्चित गर्दछ यो सुरुमा ठीक एक पटक राखिएको थियो।
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` झर्छ र यसैले `tmp` लाई `v` मा बाँकी प्वालमा प्रतिलिपि गर्दछ।
        }
    }

    // जब छोडियो, `src` बाट `dest` मा प्रतिलिपिहरू।
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// X-01X र `v[mid..]` अस्थायी भण्डारणको रूपमा `v[..mid]` प्रयोग गरेर न्यून-घट्ने रनहरू मर्ज गर्दछ, र परिणामलाई `v[..]` मा भण्डारण गर्दछ।
///
/// # Safety
///
/// दुई स्लाइसहरू खाली नभएको हुनुपर्दछ र `mid` सीमाहरूमा हुनुपर्दछ।
/// छोटो स्लाइसको प्रतिलिपि राख्न बफर `buf` पर्याप्त लामो हुनुपर्छ।
/// साथै, `T` शून्य आकारको प्रकार हुनु हुँदैन।
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // मर्ज प्रक्रिया पहिले `buf` मा छोटो रनको प्रतिलिपि गर्दछ।
    // त्यसोभए यसले भर्खरको प्रतिलिपि गरिएको रन र लामो रन अगाडि (वा पछाडि) पत्ता लगाउँदछ, आफ्ना अर्को असन्जित तत्वहरूको तुलना गरेर र `v` मा कम (वा अधिक) एक प्रतिलिपि गर्दै।
    //
    // चाँडै छोटो रन पूर्ण रूपमा खपत भएपछि, प्रक्रिया सकियो।यदि लामो रन पहिले खपत हुन्छ भने, तब हामीले छोटो रनको बाँकी रहेको जे पनि `v` मा रहेको बाँकी प्वालमा प्रतिलिपि गर्नै पर्छ।
    //
    // प्रक्रियाको मध्यवर्ती अवस्था सँधै `hole` द्वारा ट्र्याक हुन्छ, जसले दुई उद्देश्यहरू गर्दछ:
    // 1. X0 `v` को `is_less` मा panics बाट अखण्डतालाई सुरक्षित गर्दछ।
    // 2. बाँकी प्वाल `v` मा भर्दछ यदि लामो रनको पहिले खपत भयो भने।
    //
    // Panic सुरक्षा:
    //
    // यदि `is_less` panics प्रक्रियाको बखत कुनै पनि बिन्दुमा, `hole` ड्रप हुन्छ र `v` मा प्वालहरू `buf` मा अनसन्मेन्ट दायराले भरिन्छ, त्यसैले `v` ले अझै पनि प्रत्येक वस्तु राख्दछ भन्ने कुराको सुनिश्चित गर्दछ यो सुरुमा ठीक एक पटक राखिएको थियो।
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // बाँया रन छोटो छ।
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // प्रारम्भमा, यी पोइन्टरहरूले तिनीहरूको एर्रेको सुरूवात गर्दछ।
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // कम पक्ष उपभोग गर्नुहोस्।
            // यदि बराबर छ भने, स्थिरता कायम राख्नको लागि बाँया रनलाई प्राथमिकता दिनुहोस्।
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // दायाँ रन छोटो छ।
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // प्रारम्भमा, यी पोइन्टरहरूले तिनीहरूको एर्रेको अन्तिम बिन्दु दर्साउँछन्।
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // ठूलो पक्ष उपभोग गर्नुहोस्।
            // यदि बराबर छ भने, स्थिरता कायम गर्न दायाँ रनको प्राथमिकता दिनुहोस्।
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // अन्तमा, `hole` खसालिन्छ।
    // यदि छोटो रन पूर्ण रूपमा खपत भएन भने, त्यसका बाँकी रहेका चीजहरू अब `v` मा प्वालमा प्रतिलिपि गरिनेछ।

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // जब छोडिन्छ, दायरा `start..end` लाई `dest..` मा प्रतिलिपि गर्दछ।
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` शून्य आकारको प्रकार होईन, त्यसैले यसको साइजले भाग गर्न ठीक छ।
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// यस मर्ज क्रमबद्धले टिम्सोर्टबाट केहि (तर सबै होईन) विचारहरू लिन्छ, जुन विस्तार [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) मा वर्णन गरिएको छ।
///
///
/// एल्गोरिथ्मले कडाइका साथ अवरोही र गैर-अवरोन्डिंग उप-परिच्छेदहरू पहिचान गर्दछ, जसलाई प्राकृतिक रनहरू भनिन्छ।मर्ज गर्न बाँकी रहेका रनहरूको स्ट्याक अझै छ।
/// प्रत्येक भर्खरै फेला परेको रनलाई स्ट्याकमा धक्का दिइन्छ, र त्यसपछि आसन्न रनहरूका केही जोडीहरू मर्ज गरिन्छ जब सम्म यी दुई आक्रमणकारीहरू सन्तुष्ट हुँदैनन्:
///
/// 1. `1..runs.len()` मा प्रत्येक `i` को लागी: `runs[i - 1].len > runs[i].len`
/// 2. `2..runs.len()` मा प्रत्येक `i` को लागी: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// आक्रमणकारीहरूले सुनिश्चित गर्दछ कि कुल चलिरहेको समय *O*(*n*\*log(* n*)) खराब अवस्था) हो।
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // यस लम्बाइ सम्मका स्लाइसहरू सम्मिलित क्रममा प्रयोग गरेर क्रमबद्ध हुन्छ।
    const MAX_INSERTION: usize = 20;
    // कम छोटो रनहरू सम्मिलित क्रम को उपयोग गरेर बढाइएको छ कम्तिमा यस धेरै तत्वहरू स्प्यान गर्न।
    const MIN_RUN: usize = 10;

    // क्रमबद्ध गर्न शून्य आकारका प्रकारहरूमा कुनै अर्थपूर्ण व्यवहार हुँदैन।
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // छोटो एर्रे स्थानमा क्रमबद्ध गर्नुहोस् सम्मिलन क्रम मार्फत विनियोजनबाट जोगिनको लागि।
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // स्क्र्याच मेमोरीको रूपमा प्रयोग गर्न बफरलाई आबंटित गर्नुहोस्।हामी ०० लम्बाइ राख्छौं त्यसैले हामी यसमा `v` को सामग्रीहरूको उथली प्रतिलिपिहरू राख्न सक्दछौं यदि `is_less` panics यदि प्रतिलिपिहरूमा चलिरहेको डक्टरहरू जोखिममा नपारिकनै।
    //
    // दुई क्रमबद्ध रनहरू मर्ज गर्दा, यो बफरले छोटो रनको प्रतिलिपि राख्छ, जुन सँधै अधिकतम `len / 2` मा लम्बाई हुन्छ।
    //
    let mut buf = Vec::with_capacity(len / 2);

    // `v` मा प्राकृतिक रनहरू पहिचान गर्नका लागि, हामी यसलाई पछाडि पार गर्छौं।
    // त्यो एक अनौंठो निर्णय जस्तो लाग्न सक्छ, तर यो तथ्यलाई विचार गर्नुहोस् जुन मर्ज हुन्छ प्राय: विपरित दिशा (forwards) मा।
    // बेन्चमार्कका अनुसार अगाडि मर्ज गर्नु पछाडि मर्ज गर्नु भन्दा केही छिटो हुन्छ।
    // निष्कर्षमा, पछिल्तिर पछाडि टर्काएर रनको पहिचानले प्रदर्शनमा सुधार ल्याउँछ।
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // अर्को प्राकृतिक रन फेला पार्नुहोस्, र यदि यो कडा रूपमा तल झर्दै छ भने रिभर्स गर्नुहोस्।
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // रनमा धेरै थप तत्वहरू घुसाउनुहोस् यदि यो धेरै छोटो छ भने।
        // सम्मिलित क्रम छोटो अनुक्रमहरुमा मर्ज क्रम भन्दा छिटो छ, त्यसैले यसले प्रदर्शनलाई महत्वपूर्ण बनाउँछ।
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // स्ट्याकमा यस रनलाई पुश गर्नुहोस्।
        runs.push(Run { start, len: end - start });
        end = start;

        // आक्रमणकारीहरूलाई सन्तुष्ट पार्न केही जोडी आसन्न रनहरू मर्ज गर्नुहोस्।
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // अन्त्यमा, ठीक एक रन स्ट्याकमा रहनु पर्छ।
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // रनको स्ट्याक जाँच गर्दछ र मर्ज गर्न रनको अर्को जोडी पहिचान गर्दछ।
    // अधिक विशेष रूपमा, यदि `Some(r)` फर्काइयो भने यसको मतलब `runs[r]` र `runs[r + 1]` अर्को मर्ज हुनु पर्छ।
    // यदि एल्गोरिथ्म यसको सट्टामा नयाँ रन निर्माण गर्न जारी राख्नुपर्दछ, `None` फिर्ता हुन्छ।
    //
    // टिमसोर्ट यसको बग्गी कार्यान्वयनको लागि कुख्यात छ, यहाँ वर्णन गरिए अनुसार:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // कथाको सार यो हो: हामीले आक्रमणकारीहरू स्ट्याकमा शीर्ष चार रनमा लागू गर्न पर्छ।
    // केवल तीन तीनमा उनीहरूको लागि बल पुर्‍याउनु पर्याप्त छैन यो सुनिश्चित गर्नका लागि कि आक्रमणकारीहरू अझै पनि स्टकमा *सबै* रनको लागि होल्ड गर्दछन्।
    //
    // यस प्रकार्यले शीर्ष चार रनको लागि सही रूपमा अन्वेषकहरूलाई जाँच गर्दछ।
    // थप रूपमा, यदि शीर्ष रन सूचकांक ० मा शुरू हुन्छ भने, यो सँधै मर्ज अपरेसनको माग गर्दछ स्ट्याक पूर्ण ढsed्ग नभएसम्म क्रमबद्ध पूरा गर्न।
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}