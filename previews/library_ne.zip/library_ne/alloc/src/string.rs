//! एक UTF-8 - एन्कोड गरिएको, उत्पादन योग्य स्ट्रिंग।
//!
//! यस मोड्युलमा [`String`] प्रकार, [`ToString`] trait तारमा रूपान्तरणका लागि, र धेरै त्रुटि प्रकारहरू छन् जुन [`String`] s का साथ काम गर्दा परिणाम हुन सक्छ।
//!
//!
//! # Examples
//!
//! स्ट्रिंग लिटरलबाट नयाँ [`String`] सिर्जना गर्न धेरै तरिकाहरू छन्:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! तपाईं एक संग मिसाएर एक अवस्थित एक नयाँ [`String`] सिर्जना गर्न सक्नुहुन्छ
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! यदि तपाईंसँग vector वैध UTF-8 बाइट्स छ भने, तपाईं यसको [`String`] 1X बनाउन सक्नुहुन्छ।तपाईं उल्टो पनि गर्न सक्नुहुन्छ।
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // हामीलाई थाहा छ कि यी बाइट्स मान्य छन्, त्यसैले हामी `unwrap()` प्रयोग गर्नेछौं।
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// एक UTF-8 - एन्कोड गरिएको, उत्पादन योग्य स्ट्रिंग।
///
/// `String` प्रकार सबै भन्दा सामान्य स्ट्रिंग प्रकार हो कि स्ट्रि of को सामग्रीहरु मा स्वामित्व छ।योको यसको उधारो लिइएको समकक्ष, आदिम [`str`] सँग घनिष्ट सम्बन्ध छ।
///
/// # Examples
///
/// तपाईं [a literal string][`str`] बाट [`String::from`] को साथ `String` सिर्जना गर्न सक्नुहुन्छ:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// तपाईं [`push`] विधिसँग `String` मा [`char`] थप्न सक्नुहुन्छ, र [`push_str`] विधिसँग [`&str`] थप्न सक्नुहुन्छ:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// यदि तपाईंसँग UTF-8 बाइट्सको vector छ भने तपाईं [`from_utf8`] विधिबाट `String` सिर्जना गर्न सक्नुहुनेछ।
///
/// ```
/// // केहि बाइट्स, vector मा
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // हामीलाई थाहा छ कि यी बाइट्स मान्य छन्, त्यसैले हामी `unwrap()` प्रयोग गर्नेछौं।
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `String`s सँधै मान्य UTF-8 हुन्छ।यसमा केही प्रभावहरू छन्, पहिलो मध्ये यो यदि तपाईंलाई एक गैर-UTF-8 स्ट्रि need चाहिन्छ भने, [`OsString`] लाई विचार गर्नुहोस्।यो समान छ, तर UTF-8 प्रतिबन्ध बिना।दोस्रो प्रभाव यो हो कि तपाईं `String` मा सूचकांक गर्न सक्नुहुन्न:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// अनुक्रमणिका एक स्थिर समय अपरेशन को उद्देश्य हो, तर UTF-8 स enc्केतनले हामीलाई यो गर्न अनुमति दिदैन।यसबाहेक, यो स्पष्ट छैन कि कुन प्रकारको कुरा सूचकांकले फर्काउँछ: एक बाइट, एक कोडप्वाइन्ट, वा ग्राफीम क्लस्टर।
/// [`bytes`] र [`chars`] विधिहरू क्रमशः पहिले दुईमा पुनरावृत्तकर्ताहरू फर्काउँछन्।
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String`s लागू [`डेरेफ]`<Target=str>`, र त्यसैले सबै [` str`] का विधिहरू अधिकार पाउनुहोस्।थपको रूपमा, यसको मतलब यो हुन्छ कि तपाईंले `String` लाई प्रकार्यमा पठाउन सक्नुहुनेछ जुन एम्परस्यान्ड (`&`) प्रयोग गरेर [`&str`] लिन्छ:
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// यसले `String` बाट [`&str`] सिर्जना गर्दछ र यसलाई पास गर्दछ। यो रूपान्तरण एकदम सस्तो छ, र त्यसैले सामान्यतया, कार्यहरूले [`&str`] s लाई आर्गुमेन्टको रूपमा स्वीकार गर्दछ जबसम्म उनीहरूलाई कुनै खास कारणका लागि `String` चाहिन्छ।
///
/// केहि केसहरूमा Rust सँग यो रूपान्तरण गर्न पर्याप्त जानकारी छैन, [`Deref`] जबरजस्ती भनेर चिनिन्छ।निम्न उदाहरणमा स्ट्रि sl स्लाइस [`&'a str`][`&str`] ले trait `TraitExample` कार्यान्वयन गर्दछ, र प्रकार्य `example_func` जे ले trait कार्यान्वयन गर्दछ केहि पनि लिन्छ।
/// यस अवस्थामा Rust ले दुई निहित रूपान्तरणहरू गर्नु पर्छ, जुन Rust सँग गर्न मतलब छैन।
/// त्यस कारणका लागि, निम्न उदाहरण कम्पाइल हुनेछैन।
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// त्यहाँ दुई विकल्पहरू छन् जुन सट्टामा काम गर्दछ।पहिलो रेखा `example_func(&example_string);` लाई `example_func(example_string.as_str());` मा परिवर्तन गर्नु, विधि [`as_str()`] प्रयोग गरेर स्पष्ट रूपमा स्ट्रि containing सहित स्ट्रिंग स्लाइस निकाल्नु हो।
/// दोस्रो तरीकाले `example_func(&example_string);` लाई `example_func(&*example_string);` मा परिवर्तन गर्दछ।
/// यस अवस्थामा हामी `String` लाई [`str`][`&str`] लाई डेरेन्फर गर्दैछौं, तब [`str`][`&str`] लाई [`&str`] मा सन्दर्भ गर्दै।
/// दोस्रो तरिका अधिक मुहावरेपन हो, तथापि दुबैले रूपान्तरणमा स्पष्ट रूपले काम गर्दछ बाह्य रूपान्तरणमा निर्भरता भन्दा।
///
/// # Representation
///
/// एक `String` तीन कम्पोनेन्टबाट बनेको छ: केहि बाइट्स, एक लम्बाई, र क्षमताको सूचक।सूचकले आन्तरिक बफर `String` मा दर्साउँछ यसको डाटा भण्डारण गर्न प्रयोग गर्दछ।लम्बाई हाल बफरमा भण्डार गरिएको बाइट्सको संख्या हो, र क्षमता बाइट्समा बफरको आकार हो।
///
/// त्यस्तै, लम्बाइ सधैं क्षमता भन्दा कम वा बराबर हुनेछ।
///
/// यो बफर सधैं हिपमा भण्डारण हुन्छ।
///
/// तपाईं यी [`as_ptr`], [`len`], र [`capacity`] विधिहरूको साथ हेर्न सक्नुहुनेछ:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME यसलाई अपडेट गर्नुहोस् जब vec_into_raw_parts स्थिर हुन्छ।
/// // स्ट्रिंगको डाटा स्वतः ड्रप गर्न रोक्नुहोस्
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // कथा १ nine बाइट्स छ
/// assert_eq!(19, len);
///
/// // हामी ptr, लेन, र क्षमता बाहिर स्ट्रिंग पुन: निर्माण गर्न सक्दछौं।
/// // यो सबै असुरक्षित छ किनभने हामी कम्पोनेन्टहरू मान्य रहेको निश्चित गर्नका लागि जिम्मेवार छौं:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// यदि `String` सँग पर्याप्त क्षमता छ भने यसमा एलिमेन्ट्स थप गर्दै पुन: आवंटन हुँदैन।उदाहरण को लागी, यो कार्यक्रम विचार:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// यसले निम्नलिखित उत्पादन गर्दछ:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// सुरुमा, हामीसँग कुनै मेमोरी विनियोजित छैन, तर हामी स्ट्रिंगमा थप्ने क्रममा यसले यसको क्षमता उचित रूपमा बढाउँदछ।यदि हामी यसको सट्टा [`with_capacity`] विधि प्रयोग गर्‍यौं भने सुरुमा सही क्षमताको आवंटन गर्नका लागि।
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// हामी बिभिन्न आउटपुटको साथ समाप्त हुन्छौं:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// यहाँ, लूप भित्र बढी मेमोरी बाँडफाँड गर्नु पर्दैन।
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// UTF-8 बाइट vector बाट `String` रूपान्तरण गर्दा सम्भावित त्रुटि मान।
///
/// यो प्रकार [`String`] मा [`from_utf8`] विधिको लागि त्रुटि प्रकार हो।
/// यो सावधानीपूर्वक reallocations लाई रोक्नको लागि यस्तो तरीकाले डिजाइन गरिएको छ: [`into_bytes`] विधिले बाइट vector फिर्ता प्रदान गर्दछ जुन रूपान्तरण प्रयासमा प्रयोग भएको थियो।
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// [`std::str`] द्वारा प्रदान गरिएको [`Utf8Error`] प्रकारले एक त्रुटि प्रतिनिधित्व गर्दछ जुन [`u8`] s को स्लाइस [`&str`] मा रूपान्तरण गर्दा हुन सक्दछ।
/// यस अर्थमा यो `FromUtf8Error` को एनालग हो, र तपाई `FromUtf8Error` बाट [`utf8_error`] विधि मार्फत प्राप्त गर्न सक्नुहुनेछ।
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// आधारभूत उपयोग:
///
/// ```
/// // केहि अवैध बाइट्स, vector मा
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// UTF-16 बाइट स्लाइसबाट `String` रूपान्तरण गर्दा सम्भावित त्रुटि मान।
///
/// यो प्रकार [`String`] मा [`from_utf16`] विधिको लागि त्रुटि प्रकार हो।
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// आधारभूत उपयोग:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// नयाँ खाली `String` सिर्जना गर्दछ।
    ///
    /// `String` खाली छ दिईएको खण्डमा, यसले कुनै बृद्धि बफर बाँडफाँड गर्दैन।जबकि यसको मतलब यो छ कि यो प्रारम्भिक अपरेशन धेरै सस्तो छ, यसले पछि अत्यधिक विनियोजन गर्न सक्दछ जब तपाईं डाटा थप्नुहुन्छ।
    ///
    /// यदि तपाइँसँग `String` लाई कती डाटाले समातिन्छ भनेर एक विचार छ भने अत्यधिक पुन: आवंटन रोक्न [`with_capacity`] विधिलाई विचार गर्नुहोस्।
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// विशेष क्षमताको साथ नयाँ खाली `String` सिर्जना गर्दछ।
    ///
    /// `String`s सँग आन्तरिक बफर हुन्छ तिनीहरूको डाटा समाउन।
    /// क्षमता त्यो बफरको लम्बाई हो, र [`capacity`] विधिसँग क्वेरी गर्न सकिन्छ।
    /// यो विधिले खाली `String` सिर्जना गर्दछ, तर एक शुरुवाती बफरको साथ जुन `capacity` बाइट्स समात्छ।
    /// यो उपयोगी छ जब तपाईं `String` मा डाटाको गुच्छा थप्दै हुनहुन्छ, यसलाई गर्नु पर्ने रिकलोकेशन संख्या घटाएर।
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// यदि दिइएको क्षमता `0` हो भने, कुनै विनियोजन हुनेछैन, र यो विधि [`new`] विधिसँग समान छ।
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // स्ट्रिले कुनै क्यारेसहरू समावेश गर्दैन, यद्यपि यससँग अधिक क्षमता छ
    /// assert_eq!(s.len(), 0);
    ///
    /// // यी सबै पुन: निर्धारण बिना नै गरिएका छन् ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... तर यसले स्ट्रि re रिलोक्याट गर्न सक्दछ
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): cfg(test) सँग अन्तर्निहित `[T]::to_vec` विधि, जुन यो विधि परिभाषाको लागि आवश्यक छ, उपलब्ध छैन।
    // हामीलाई परीक्षण विधिको लागि यस विधिको आवश्यक पर्दैन, त्यसैले म यसलाई अub्ग्रोपार गर्दै छु NB slice.rs मा slice::hack मोड्युल अधिक जानकारीको लागि देख्दछु।
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// vector बाइट्सलाई `String` मा बदल्छ।
    ///
    /// एक स्ट्रि X ([`String`]) बाइट्स ([`u8`]) बाट बनेको छ, र vector बाइट्स ([`Vec<u8>`]) बाइट्स बाट बनेको छ, त्यसैले यो प्रकार्य दुई बीच रूपान्तरण।
    /// सबै बाइट स्लाइसहरू मान्य छैन `स्ट्रिंग`हरू, जे भए पनि: `String` लाई यो मान्य UTF-8 हुन आवश्यक पर्दछ।
    /// `from_utf8()` बाइट्स मान्य UTF-8 छन् भनेर निश्चित गर्न जाँच गर्दछ, र त्यसपछि रूपान्तरण गर्दछ।
    ///
    /// यदि तपाइँ निश्चित हुनुहुन्छ कि बाइट स्लाइस वैध UTF-8 हो, र तपाइँ वैधता जाँचको ओभरहेड लगाउन चाहनुहुन्न भने, त्यहाँ यो प्रकार्यको असुरक्षित संस्करण छ, [`from_utf8_unchecked`], समान व्यवहार छ तर चेक छोड्छ।
    ///
    ///
    /// यस विधिले vector नक्कल गर्न सावधानी राख्नेछ, दक्षताको लागि।
    ///
    /// यदि तपाईंलाई `String` को सट्टामा [`&str`] चाहिएको छ भने, [`str::from_utf8`] विचार गर्नुहोस्।
    ///
    /// यस विधिको व्युत्क्रम [`into_bytes`] हो।
    ///
    /// # Errors
    ///
    /// [`Err`] फर्काउँछ यदि स्लाइस UTF-8 होईन किन वर्णनको कारण किन प्रदान गरिएको बाइट्स UTF-8 छैनन्।तपाईंले सार्नुभएको vector पनि समावेश छ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// // केहि बाइट्स, vector मा
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // हामीलाई थाहा छ कि यी बाइट्स मान्य छन्, त्यसैले हामी `unwrap()` प्रयोग गर्नेछौं।
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// गलत बाइट्स:
    ///
    /// ```
    /// // केहि अवैध बाइट्स, vector मा
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// [`FromUtf8Error`] का लागि कागजातहरू हेर्नुहोस् यस त्रुटिसँग तपाईं के गर्न सक्नुहुन्छ भन्नेमा थप विवरणहरूको लागि।
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// बाइट्सको स्लाइसलाई स्ट्रिंगमा रूपान्तरण गर्दछ, अवैध वर्ण सहित।
    ///
    /// स्ट्रि by बाइट्स ([`u8`]) बाट बनेको छ, र ([`&[u8]`][byteslice]) बाइट्सको स्लाइस बाइट्स बाट बनेको छ, त्यसैले यो प्रकार्य दुई बीच बदल्छ।सबै बाइट स्लाइसहरू मान्य स्ट्रिंगहरू छैनन्, यद्यपि: स्ट्रि validहरू मान्य UTF-8 हुन आवश्यक छ।
    /// यस रूपान्तरणको क्रममा, `from_utf8_lossy()` ले कुनै अवैध UTF-8 दृश्यहरूलाई [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] सँग प्रतिस्थापन गर्नेछ, जुन यस्तो देखिन्छ:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// यदि तपाईं निश्चित हुनुहुन्छ कि बाइट स्लाइस वैध UTF-8 मान्य छ, र तपाईं रूपान्तरणको ओभरहेड लगाउन चाहनुहुन्न भने, त्यहाँ यस प्रकार्यको असुरक्षित संस्करण, [`from_utf8_unchecked`] छ, जुन समान व्यवहार गर्दछ तर चेकहरूलाई छोड्छ।
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// यो प्रकार्यले [`Cow<'a, str>`] फिर्ता गर्दछ।यदि हाम्रो बाइट स्लाइस अवैध UTF-8 अमान्य छ, तब हामीले प्रतिस्थापन वर्णहरू सम्मिलित गर्न आवश्यक छ, जसले स्ट्रिंगको आकार परिवर्तन गर्दछ, र यसैले, `String` चाहिन्छ।
    /// तर यदि यो पहिले नै मान्य UTF-8 हो, हामीलाई नयाँ विनियोजनको आवश्यकता पर्दैन।
    /// यो फिर्ती प्रकारले हामीलाई दुबै केसहरू ह्यान्डल गर्न अनुमति दिन्छ।
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// // केहि बाइट्स, vector मा
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// गलत बाइट्स:
    ///
    /// ```
    /// // केहि अवैध बाइट्स
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// एक UTF-16 ode एन्कोड गरिएको vector `v` एक `String` मा डिकोड गर्नुहोस्, [`Err`] फिर्ता अगर `v` कुनै अवैध डेटा शामिल।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // यो स: :्कलन::मार्फत गरिएको छैन <Result<_, _>> () प्रदर्शन कारणका लागि।
        // FIXME: #48994 बन्द हुँदा कार्य फेरि सरलीकृत गर्न सकिन्छ।
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// एक UTF-16 Dec एन्कोड गरिएको टुक्रा `v` लाई `String` मा डिकोड गर्नुहोस्, अवैध डाटालाई [the replacement character (`U+FFFD`)][U+FFFD] प्रतिस्थापन गरेर।
    ///
    /// [`from_utf8_lossy`] भन्दा फरक जसले [`Cow<'a, str>`] फर्काउँदछ, `from_utf16_lossy` लाई `String` फिर्ता गर्दछ UTF-16 लाई UTF-8 रूपान्तरणको लागि मेमोरी विनियोजनको आवश्यकता पर्दछ।
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// XsX यसको कच्चा घटकहरूमा विघटित गर्दछ।
    ///
    /// अन्तर्निहित डेटा, स्ट्रिंगको लम्बाई (बाइट्स), र डाटाको बाँडफाँड क्षमता (बाइट्स) मा कच्चा सूचक फर्काउँछ।
    /// [`from_raw_parts`] मा आर्गुमेन्टहरू समान क्रममा यी समान तर्कहरू हुन्।
    ///
    /// यस प्रकार्य कल गरिसकेपछि कलर `String` द्वारा प्रबन्धित मेमोरीको लागि जिम्मेवार छ।
    /// यसको लागि एक मात्र तरीका भनेको कच्चा स poin्केतक, लम्बाई, र क्षमतालाई `String` X मा फिर्ता [`from_raw_parts`] प्रकार्यमा रूपान्तरण गर्नु हो, विध्वंसकलाई सफाई प्रदर्शन गर्न अनुमति दिदै।
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// लम्बाई, क्षमता, र सूचकबाट नयाँ `String` सिर्जना गर्दछ।
    ///
    /// # Safety
    ///
    /// यो अत्यधिक असुरक्षित छ, परीक्षकहरूको संख्याको कारण जाँच गरिएन:
    ///
    /// * `buf` मा मेमोरी पहिले समान आबक्ताले मानक लाइब्रेरी प्रयोग गर्दछ, ठीक १ को आवश्यक पign्क्तिबद्धको साथ आबश्यक हुनुपर्दछ।
    /// * `length` `capacity` भन्दा कम वा बराबरको हुनु आवश्यक छ।
    /// * `capacity` सहि मान हुनु आवश्यक छ।
    /// * `buf` मा पहिलो `length` बाइट्स मान्य UTF-8 हुनु पर्छ।
    ///
    /// यीलाई उल्ल .्घन गर्नाले समस्याहरू उत्पन्न गर्दछ आवाबको आन्तरिक डेटा संरचनाहरू भ्रष्ट पार्ने जस्ता।
    ///
    /// `buf` को स्वामित्व `String` लाई प्रभावी रूपमा स्थानान्तरण गरियो जुन त्यसपछि इच्छाशक्तिले सूचकको आधारमा देखाइएको मेमोरीको सामग्रीहरू Deallocon गर्न, पुन: सम्बोधन गर्न वा परिवर्तन गर्न सक्दछ।
    /// निश्चित गर्नुहोस् कि अरू कुनै कुराले यो प्रकार्य कल गरेपछि सूचक प्रयोग गर्दैन।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME यसलाई अपडेट गर्नुहोस् जब vec_into_raw_parts स्थिर हुन्छ।
    ///     // स्ट्रिंगको डाटा स्वतः ड्रप गर्न रोक्नुहोस्
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// बाइट्सको vector लाई `String` मा रूपान्तरण गर्दछ कि स्ट्रि theमा मान्य UTF-8 समावेश छ।
    ///
    /// अधिक जानकारीका लागि सुरक्षित संस्करण, [`from_utf8`] हेर्नुहोस्।
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// यो प्रकार्य असुरक्षित छ किनकि यसले जाँच गरिरहेको छैन कि यसलाई पारित बाइट्स मान्य UTF-8 हुन्।
    /// यदि यो अवरोध उल्ल .्घन गरियो भने, यसले `String` का future प्रयोगकर्ताहरूको साथ मेमोरी असुरक्षित मुद्दाहरू निम्त्याउन सक्छ, किनकि बाँकी मानक पुस्तकालयले मान्दछ कि `String`s मान्य UTF-8 हो।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// // केहि बाइट्स, vector मा
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// `String` लाई बाइट vector मा बदल्छ।
    ///
    /// यसले `String` खान्छ, त्यसैले हामीले यसको सामग्रीहरू प्रतिलिपि गर्न आवश्यक पर्दैन।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// सम्पूर्ण `String` युक्त स्ट्रि sl स्लाइस निकाल्छ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// `String` लाई म्यूटेबल स्ट्रि sl स्लाइसमा रूपान्तरण गर्दछ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// यो `String` को अन्त्यमा दिइएको स्ट्रिंग स्लाइस थप्दछ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// यस `String` को क्षमता, बाइट्समा फर्काउँछ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// सुनिश्चित गर्दछ कि यस `स्ट्रिंगको क्षमता कम्तिमा `additional` बाइट यसको लम्बाई भन्दा ठूलो छ।
    ///
    /// क्षमता पुन: रिकोलोकेशनहरू रोक्नको लागि, यदि यो छनौट गर्दछ भने `additional` बाइट्स बढी बढाउन सक्दछ।
    ///
    ///
    /// यदि तपाईं यो "at least" व्यवहार चाहनुहुन्न भने, [`reserve_exact`] विधि हेर्नुहोस्।
    ///
    /// # Panics
    ///
    /// Panics यदि नयाँ क्षमता [`usize`] ओभरफ्लो भयो।
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// यसले वास्तवमा क्षमता बढाउन सक्दैन:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s अब २ को लम्बाई र १० को क्षमता छ
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // हामीसँग पहिलेदेखि नै अतिरिक्त capacity क्षमता छ, यसलाई कल गर्दै ...
    /// s.reserve(8);
    ///
    /// // ... वास्तवमा बढ्दैन।
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// यो `String` को क्षमता `additional` बाइट यसको लम्बाई भन्दा ठूलो छ भनेर सुनिश्चित गर्दछ।
    ///
    /// [`reserve`] विधि प्रयोग गर्ने बारे विचार गर्नुहोस् जबसम्म तपाईं राम्ररी राम्रा राम्रा कुरा बुझ्नुहुन्छ अझ राम्ररी।
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics यदि नयाँ क्षमता `usize` ओभरफ्लो भयो।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// यसले वास्तवमा क्षमता बढाउन सक्दैन:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s अब २ को लम्बाई र १० को क्षमता छ
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // हामीसँग पहिलेदेखि नै अतिरिक्त capacity क्षमता छ, यसलाई कल गर्दै ...
    /// s.reserve_exact(8);
    ///
    /// // ... वास्तवमा बढ्दैन।
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// कम्तिमा `additional` थप तत्वहरू सम्मिलित `String` सम्मिलित गर्न क्षमता रिजर्भ गर्न प्रयास गर्दछ।
    /// संग्रहले लगातार रिकलोकेशन्सबाट बच्न अधिक ठाउँ आरक्षित गर्न सक्दछ।
    /// `reserve` कल गरेपछि, क्षमता `self.len() + additional` भन्दा बढि वा बराबर हुनेछ।
    /// केहि गर्दैन यदि क्षमता पहिले नै पर्याप्त छ।
    ///
    /// # Errors
    ///
    /// यदि क्षमता ओभरफ्लो भयो, वा विनियोजकले एक विफलता रिपोर्ट गरे, तब एउटा त्रुटि फर्किन्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // मेमोरी प्रि-रिजर्भ गर्नुहोस्, यदि हामी सक्दैनौं भने बाहिर निस्कँदै
    ///     output.try_reserve(data.len())?;
    ///
    ///     // अब हामी जान्दछौं कि यो OOM हाम्रो जटिल कामको बिचमा गर्न सक्दैन
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// `additional` 1X अधिक तत्वहरू ठीक `String` सम्मिलित गर्न न्यूनतम क्षमता आरक्षित गर्न कोसिस गर्दछ।
    ///
    /// `reserve_exact` कल गरेपछि, क्षमता `self.len() + additional` भन्दा बढि वा बराबर हुनेछ।
    /// केहि गर्दैन यदि क्षमता पहिले नै पर्याप्त छ।
    ///
    /// नोट गर्नुहोस् कि विनियोजकले संग्रहले अनुरोध भन्दा बढी ठाउँ दिन सक्छ।
    /// तसर्थ, क्षमता एकदम न्यूनतम हुन भर पर्न सक्दैन।
    /// `reserve` प्राथमिकता दिनुहोस् यदि future सम्मिलनहरू अपेक्षित छन्।
    ///
    /// # Errors
    ///
    /// यदि क्षमता ओभरफ्लो भयो, वा विनियोजकले एक विफलता रिपोर्ट गरे, तब एउटा त्रुटि फर्किन्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // मेमोरी प्रि-रिजर्भ गर्नुहोस्, यदि हामी सक्दैनौं भने बाहिर निस्कँदै
    ///     output.try_reserve(data.len())?;
    ///
    ///     // अब हामी जान्दछौं कि यो OOM हाम्रो जटिल कामको बिचमा गर्न सक्दैन
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// यसको `String` को क्षमतालाई संकुचन गर्दछ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// तल्लो बाउन्डको साथ यो `String` को क्षमता संकुचन गर्दछ।
    ///
    /// क्षमता कम्तिमा दुबै लम्बाई र आपूर्ति गरिएको मानको रूपमा ठूलो रहनेछ।
    ///
    ///
    /// यदि हालको क्षमता तल्लो सीमा भन्दा कम छ भने, यो एक अप-अप हो।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// दिइएको [`char`] लाई यो `String` को अन्त्यमा थप्दछ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// यस `String` को सामग्रीको बाइट स्लाइस फर्काउँछ।
    ///
    /// यस विधिको व्युत्क्रम [`from_utf8`] हो।
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// निर्दिष्ट गरिएको लम्बाइमा यस `String` लाई छोटो पार्दछ।
    ///
    /// यदि `new_len` स्ट्रिंगको वर्तमान लम्बाई भन्दा ठूलो छ भने, यसले कुनै प्रभाव पार्दैन।
    ///
    ///
    /// नोट गर्नुहोस् कि यस विधिले स्ट्रि ofको विनियोजित क्षमतामा कुनै प्रभाव पार्दैन
    ///
    /// # Panics
    ///
    /// Panics यदि `new_len` [`char`] सीमा मा छैन।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// अन्तिम वर्णलाई स्ट्रिंग बफरबाट हटाउँछ र फिर्ता गर्छ।
    ///
    /// [`None`] फर्काउँछ यदि यो `String` खाली छ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// यस `String` बाट [`char`] लाई बाइट स्थितिमा हटाउँछ र फिर्ता गर्छ।
    ///
    /// यो एक *O*(*n*) अपरेशन हो, किनकि यसलाई बफरमा प्रत्येक तत्वको प्रतिलिपि गर्न आवश्यक पर्दछ।
    ///
    /// # Panics
    ///
    /// Panics यदि `idx` `String` को लम्बाई भन्दा ठूलो वा बराबर छ, वा यदि यो [`char`] सीमामा पर्दैन भने।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// X001 X मा प्याटर्नको सबै मिलान हटाउनुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// खेलहरू पत्ता लगाइनेछ र पुनरावृत्तिक रूपमा हटाइनेछ, त्यसैले जहाँ मामिलाहरूमा ढाँचा ओभरल्याप हुन्छ, मात्र पहिलो ढाँचा हटाइनेछ:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // सुरक्षा: सुरु र अन्त utf8 बाइट सीमा मा प्रति हुनेछ
        // खोजीकर्ता कागजातहरू
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// पूर्वानुमान द्वारा निर्दिष्ट वर्ण मात्र राख्छ।
    ///
    /// अर्को शब्दमा, सबै अक्षरहरू `c` हटाउनुहोस् कि `f(c)` `false` फर्काउँछ।
    /// यो विधि स्थानमा सञ्चालन गर्दछ, प्रत्येक क्यारेक्टर मूल क्रममा ठीक एक पटक भ्रमण गर्दछ, र राखिएको क्यारेक्टरहरूको क्रम सुरक्षित गर्दछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// सहि अर्डर बाह्य अवस्था ट्र्याक गर्नको लागि उपयोगी हुन सक्छ, जस्तै एक सूचकांक जस्तो।
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // अर्को चार्टमा पोइन्ट idx
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// यस `String` मा एउटा बाइट स्थितिमा क्यारेक्टर सम्मिलित गर्दछ।
    ///
    /// यो एक *O*(*n*) अपरेशन हो किनकि यसलाई बफरमा प्रत्येक तत्वको प्रतिलिपि गर्न आवश्यक पर्दछ।
    ///
    /// # Panics
    ///
    /// Panics यदि `idx` `String` को लम्बाई भन्दा ठूलो छ, वा यदि यो [`char`] सीमामा छैन भने।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// यस `String` मा बाइट स्थितिमा स्ट्रिंग स्लाइस घुसाउँदछ।
    ///
    /// यो एक *O*(*n*) अपरेशन हो किनकि यसलाई बफरमा प्रत्येक तत्वको प्रतिलिपि गर्न आवश्यक पर्दछ।
    ///
    /// # Panics
    ///
    /// Panics यदि `idx` `String` को लम्बाई भन्दा ठूलो छ, वा यदि यो [`char`] सीमामा छैन भने।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// यो `String` को सामग्रीहरूमा एक परिवर्तनीय सन्दर्भ फर्काउँछ।
    ///
    /// # Safety
    ///
    /// यो प्रकार्य असुरक्षित छ किनकि यसले जाँच गरिरहेको छैन कि यसलाई पारित बाइट्स मान्य UTF-8 हुन्।
    /// यदि यो अवरोध उल्ल .्घन गरियो भने, यसले `String` का future प्रयोगकर्ताहरूको साथ मेमोरी असुरक्षित मुद्दाहरू निम्त्याउन सक्छ, किनकि बाँकी मानक पुस्तकालयले मान्दछ कि `String`s मान्य UTF-8 हो।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// यस `String` को लम्बाइ फर्काउँछ, बाइट्समा, [`Char`] s वा ग्राफिमहरू होईन।
    /// अर्को शब्दमा, यो स्ट्रिंगको लम्बाइलाई मान्ने मानिस हुन सक्दैन।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// `true` फर्काउँछ यदि यो `String` को शून्य को लम्बाई छ, र अन्यथा `false`।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// दिईएको बाइट सूचकांकमा स्ट्रि two दुईमा विभाजन गर्दछ।
    ///
    /// नयाँ बाँडिएको `String` फर्काउँछ।
    /// `self` बाइट्स `[0, at)`, र फिर्ता `String` बाइट `[at, len)` समावेश गर्दछ।
    /// `at` UTF-8 कोड पोइन्टको सीमामा हुनुपर्दछ।
    ///
    /// नोट गर्नुहोस् कि `self` को क्षमता परिवर्तन हुँदैन।
    ///
    /// # Panics
    ///
    /// Panics यदि `at` `UTF-8` कोड पोइन्ट सीमामा छैन, वा यदि यो स्ट्रिंगको अन्तिम कोड पोइन्ट बाहिर छ भने।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// सबै सामग्री हटाएर यो `String` छाँट्छ।
    ///
    /// जबकि यसको मतलब यो `String` शून्य को एक लम्बाई हुनेछ, यो यसको क्षमता छुन छैन।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// XP1X मा निर्दिष्ट दायरा हटाउँछ र हटाइएको `chars` उपज एक नाली इटररेटर सिर्जना गर्दछ।
    ///
    ///
    /// Note: एलिमेटर दायरा हटाइन्छ यदि इट्रेटर अन्त्यसम्म उपभोग हुँदैन।
    ///
    /// # Panics
    ///
    /// Panics यदि सुरूवात पोइन्ट वा अन्तिम पोइन्ट [`char`] सीमामा हुँदैन, वा यदि ती सीमा बाहिर छ भने।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // दायरा माथि Remove सम्म स्ट्रिंगबाट हटाउनुहोस्
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // पूर्ण दायराले स्ट्रिंग खाली गर्दछ
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // मेमोरी सुरक्षा
        //
        // Drain को स्ट्रिंग संस्करण vector संस्करण को स्मृति सुरक्षा मुद्दाहरु छैन।
        // डाटा मात्र सादा बाइट्स छ।
        // किनभने दायरा हटाउने ड्रपमा हुन्छ, यदि Drain ईटरटर लीक भयो भने, हटाउने कार्य हुने छैन।
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // दुई एक साथ bण लिनुहोस्।
        // &mut स्ट्रि ite ड्रपमा, पुनरावृत्ति समाप्त नभएसम्म पहुँच गर्न सकिदैन।
        let self_ptr = self as *mut _;
        // सुरक्षा: `slice::range` र `is_char_boundary` उचित सीमा जाँच गर्दछ।
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// स्ट्रिंगमा निर्दिष्ट दायरा हटाउँछ, र दिईएको स्ट्रि withको साथ बदल्छ।
    /// दिईएको स्ट्रिको दायरा बराबर लम्बाइ हुनु आवश्यक छैन।
    ///
    /// # Panics
    ///
    /// Panics यदि सुरूवात पोइन्ट वा अन्तिम पोइन्ट [`char`] सीमामा हुँदैन, वा यदि ती सीमा बाहिर छ भने।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // दायरा माथि lace स्ट्रिंगबाट बदल्नुहोस्
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // मेमोरी सुरक्षा
        //
        // Replace_range सँग vector Splice को मेमोरी सुरक्षा मुद्दाहरू छैन।
        // vector संस्करण को।डाटा मात्र सादा बाइट्स छ।

        // चेतावनी: यस भ्यारीएबललाई इनलाइन गर्नु अनउउन्ड (#81138) हुनेछ
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // चेतावनी: यस भ्यारीएबललाई इनलाइन गर्नु अनउउन्ड (#81138) हुनेछ
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // `range` फेरि प्रयोग अनौंउन्ड (#81138) हुनेछ हामी `range` द्वारा रिपोर्ट गरिएको सीमा एकै रहन सक्छौ, तर एक adversarial कार्यान्वयन कल बीच बदल्न सक्छ।
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// यस `String` लाई [`Box`]`<`[`str`] `>` मा रूपान्तरण गर्दछ।
    ///
    /// यसले कुनै पनि अधिक क्षमता छोड्नेछ।
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// [`U8`] बाइट्सको एउटा टुक्रा फर्काउँछ जुन `String` मा रूपान्तरण गर्न प्रयास गरिएको थियो।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// // केहि अवैध बाइट्स, vector मा
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// `String` मा रूपान्तरण गर्न प्रयास गरिएका बाइटहरू फर्काउँछ।
    ///
    /// यो विधि सावधानीपूर्वक विनियोजनबाट जोगिनको लागि हो
    /// यसले त्रुटि खपत गर्दछ, बाइट्सलाई बाहिर सार्दै, ताकि बाइट्सको प्रतिलिपि बनाउन आवश्यक पर्दैन।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// // केहि अवैध बाइट्स, vector मा
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// रूपान्तरण विफलताको बारेमा थप विवरण प्राप्त गर्न `Utf8Error` ल्याउनुहोस्।
    ///
    /// [`std::str`] द्वारा प्रदान गरिएको [`Utf8Error`] प्रकारले एक त्रुटि प्रतिनिधित्व गर्दछ जुन [`u8`] s को स्लाइस [`&str`] मा रूपान्तरण गर्दा हुन सक्दछ।
    /// यस अर्थमा यो `FromUtf8Error` लाई एनालग हो।
    /// यसको प्रयोगका बारे अधिक विवरणका लागि यसको कागजात हेर्नुहोस्।
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// // केहि अवैध बाइट्स, vector मा
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // पहिलो बाइट यहाँ अवैध छ
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // किनकि हामी `String`s मा पुनरावृत्ति गर्दैछौं, हामी कम्तिमा एउटा आवंटनबाट बच्न सक्छौं इट्रेटरबाट पहिलो स्ट्रि getting प्राप्त गरेर र यसमा पछिल्लो सबै स्ट्रि appहरू थपेर।
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // किनकि हामी CoWs मा पुनरावृत्ति गर्दैछौं, हामी (potentially) लाई कम्तिमा एउटा बाँडफाँड गर्नबाट रोक्न सक्छौं पहिलो वस्तु प्राप्त गरेर र त्यस पछि सबै आइटमहरू थप गरेर।
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// `&str` को लागी impl लाई प्रतिनिधि बनाउने सुविधा सुविधा।
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// खाली `String` सिर्जना गर्दछ।
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// `+` X अपरेटरलाई दुई स्ट्रिंगहरू संयोजन गर्न लागू गर्दछ।
///
/// यसले `String` बायाँपट्टि खान्छ र यसको बफर पुनः प्रयोग गर्दछ (आवश्यक भएमा यसलाई बढाउँदै)।
/// यो एक नयाँ `String` बाँडफाँड गर्न र प्रत्येक अपरेशनमा सम्पूर्ण सामग्री प्रतिलिपि गर्नबाट बच्नको लागि गरिन्छ, जुन *O*(*n* running 2) चालु समयमा दोहोरिने कन्टिनेटेसन द्वारा एक *n*-बाइट स्ट्रि building निर्माण गर्दा।
///
///
/// दायाँ-पट्टीमा स्ट्रि string मात्र उधारो लिएको छ;यसको सामग्रीहरू फर्काइएको `String` मा प्रतिलिपि गरिएको छ।
///
/// # Examples
///
/// दुई `String`s लाई संयोजनमा पहिलो मानले लिन्छ र दोस्रो उधारो लिन्छ:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` सारिएको छ र अब यहाँ प्रयोग गर्न सकिँदैन।
/// ```
///
/// यदि तपाईं पहिलो `String` को उपयोग जारी राख्न चाहानुहुन्छ, तपाईं क्लोन गर्न सक्नुहुनेछ र क्लोनमा थप्न सक्नुहुन्छ:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` यहाँ अझै मान्य छ।
/// ```
///
/// `&str` स्लाइसहरू संयोजन गर्नु पहिलो `String` मा रूपान्तरण गरेर गर्न सकिन्छ:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// `String` लाई जोड्नको लागि `+=` अपरेटरलाई लागू गर्दछ।
///
/// यो [`push_str`][String::push_str] विधि जस्तै व्यवहार छ।
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// [`Infallible`] को लागी एक उपनाम।
///
/// यो उपनाम पछाडि संगतताको लागि अवस्थित छ, र अन्ततः अस्वीकार हुन सक्छ।
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// एक trait एक `String` मा मान रूपान्तरणको लागि।
///
/// यो trait स्वचालित रूपमा [`Display`] trait कार्यान्वयन गर्ने कुनै पनि प्रकारको लागि लागू गरिएको छ।
/// त्यस्तै, `ToString` सीधा कार्यान्वयन गर्नु हुँदैन:
/// [`Display`] यसको साटोमा कार्यान्वयन हुनुपर्दछ, र तपाई `ToString` कार्यान्वयन सित्तैमा पाउनुहुन्छ।
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// दिइएको मानलाई `String` मा बदल्छ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// यस कार्यान्वयनमा, `to_string` विधि panics यदि `Display` कार्यान्वयनले त्रुटि देखायो।
/// यो गलत `Display` कार्यान्वयन इंगित गर्दछ किनकि `fmt::Write for String` कहिल्यै आफै त्रुटि फिर्ता गर्दैन।
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // एउटा साधारण दिशानिर्देश भनेको जेनेरिक फंक्शनहरू इनलाइन नगर्नु हो।
    // यद्यपि यस विधिबाट `#[inline]` हटाउनाले गैर उपेक्षित रेग्रेसनहरू निम्त्याउँदछ।
    // <https://github.com/rust-lang/rust/pull/74852> हेर्नुहोस्, यसलाई हटाउन प्रयास गर्ने अन्तिम प्रयास।
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// `&mut str` लाई `String` मा बदल्छ।
    ///
    /// परिणाम ढेरमा छुट्याइएको छ।
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: परीक्षण libstd मा तान्छ, जसले यहाँ त्रुटिहरूको कारण गर्दछ
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// दिइएको बक्स गरिएको `str` स्लाइसलाई `String` मा बदल्छ।
    /// यो उल्लेखनीय छ कि `str` स्लाइस स्वामित्वमा छ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// दिइएको `String` लाई बक्स गरिएको `str` स्लाइसमा बदल्छ जुन स्वामित्वमा रहेको छ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// स्ट्रि sl स्लाइसलाई उधारो भेरिएन्टमा रूपान्तरण गर्दछ।
    /// कुनै हिप एलोकसन गरिएको छैन, र स्ट्रिंग प्रतिलिपि गरिएको छैन।
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// एक स्ट्रि anलाई स्वामित्व संस्करणमा रूपान्तरण गर्दछ।
    /// कुनै हिप एलोकसन गरिएको छैन, र स्ट्रिंग प्रतिलिपि गरिएको छैन।
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// एक स्ट्रिंग सन्दर्भलाई एक उधारो संस्करणमा रूपान्तरण गर्दछ।
    /// कुनै हिप एलोकसन गरिएको छैन, र स्ट्रिंग प्रतिलिपि गरिएको छैन।
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// `String` लाई vector `Vec` मा रूपान्तरण गर्दछ जुन `u8` प्रकारको मान राख्छ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// `String` को लागी एक जलिरहेको पुनरावृत्ति।
///
/// यो संरचना [`drain`] विधि द्वारा [`String`] मा सिर्जना गरिएको हो।
/// अधिकको लागि यसको कागजात हेर्नुहोस्।
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// &'कन्स्ट्रक्टरमा म्युट स्ट्रिंगको रूपमा प्रयोग हुनेछ
    string: *mut String,
    /// हटाउनको लागि भागको सुरू गर्नुहोस्
    start: usize,
    /// भाग को अन्त हटाउन को लागी
    end: usize,
    /// हटाउनको लागि हालको बाँकी दायरा
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Vec::drain प्रयोग गर्नुहोस्।
            // "Reaffirm" panic कोड फेरि सम्मिलित हुनबाट जोगिन सीमाहरूले जाँच गर्दछ।
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// यस पुनरावृत्तिको बाँकी (उप) स्ट्रि aलाई स्लाइसको रूपमा फर्काउँछ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: असक्षमता AsRef स्थिर जब तल झल्काउँछ।
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// `string_drain_as_str` स्थिर गर्दा अनकम्मेन्ट।
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>Drain <'a> {fn as_ref(&self)-> &str for को लागि
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> Drain <' a> n fn as_ref(&self)->&[u8] for को लागि
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}