#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// नयाँ मेमोरीको सामग्रीहरू अनइन्टीटाइजेशन गरिएको छ।
    Uninitialized,
    /// नयाँ मेमोरी शून्य हुने ग्यारेन्टी गरिएको छ।
    Zeroed,
}

/// अधिक एर्गोनोमिकली विनियोजनको लागि एक कम-स्तर युटिलिटी, पुन: स्थानियकरण, र हिपमा मेमोरीको बफरलाई डेअलोकेकेट गर्ने सबै कुनामा घटनाहरूमा चिन्ता नगरिकन।
///
/// यो प्रकार Vec र VecDeque जस्तै तपाईंको आफ्नै डाटा संरचनाहरू निर्माण गर्नका लागि उत्कृष्ट छ।
/// विशेषत:
///
/// * शून्य आकारका प्रकारहरूमा `Unique::dangling()` उत्पादन गर्दछ।
/// * शून्य-लम्बाई विनियोजनमा `Unique::dangling()` उत्पादन गर्दछ।
/// * `Unique::dangling()` फ्रि गर्ने बेवास्ता गर्दछ।
/// * क्षमता गणनामा सबै ओभरफ्लोहरू क्याच गर्दछ (तिनीहरूलाई "capacity overflow" panics मा बढुवा गर्दछ)।
/// * 00२-बिट प्रणालीहरू विरुद्ध गार्डहरू isize::MAX बाइट्स भन्दा बढि विनियोजन गर्छन्।
/// * तपाईंको लम्बाइ ओभरफ्लो गर्ने विरूद्ध गार्डहरू।
/// * कलयोग्य `handle_alloc_error` फेलिबल विनियोजनहरूको लागि।
/// * एक `ptr::Unique` समावेश गर्दछ र यसैले सबै सम्बन्धित लाभहरूको साथ प्रयोगकर्तालाई प्रदान गर्दछ।
/// * सबैभन्दा ठूलो उपलब्ध क्षमता प्रयोग गर्न विनियोजकबाट फर्काइएको अधिकको प्रयोग गर्दछ।
///
/// यस प्रकारले जे भए पनि यसले प्रबन्ध गर्ने मेमोरीको निरीक्षण गर्दैन।जब यो छोडियो *यसले यसको मेमोरी खाली गर्दछ, तर यसले* यसका सामग्रीहरू छोड्ने कोशिश गर्दैन।
/// यो `RawVec` को प्रयोगकर्ता माथि छ `RawVec` X भित्रको वास्तविक चीजहरू *भण्डारण* ह्यान्डल गर्नका लागि।
///
/// नोट गर्नुहोस् कि एक शून्य आकारका प्रकारहरू सधैं असीम हुन्छन्, त्यसैले `capacity()` सँधै `usize::MAX` फर्काउँछ।
/// यसको मतलव तपाईले होशियार हुनु आवश्यक छ कि `Box<[T]>` को साथ यस प्रकारको राउन्ड-ट्रिपिंग गर्दा, किनभने `capacity()` ले लम्बाई प्रदान गर्दैन।
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): यो अवस्थित छ किनभने `#[unstable]` `const fn`s लाई `min_const_fn` अनुरूपको आवश्यक पर्दैन र त्यसैले तिनीहरूलाई`min_const_fn`s मा बोलाउन सकिदैन।
    ///
    /// यदि तपाइँ `RawVec<T>::new` वा निर्भरताहरू परिवर्तन गर्नुहुन्छ भने, कृपया `min_const_fn` X लाई वास्तव मा उल्ल .्घन गर्ने केहि परिचय नलगाउन सावधान हुनुहोस्।
    ///
    /// NOTE: हामी यस ह्याकलाई बेवास्ता गर्न सक्दछौं र केहि `#[rustc_force_min_const_fn]` एट्रिब्युटको साथ कन्फरमेसन जाँच गर्न सक्दछौं जसलाई `min_const_fn` का साथ कन्फरेन्स आवश्यक छ तर `stable(...) const fn`/प्रयोगकर्ता कोडमा कल गर्न अनुमति दिदैन `foo` सक्षम नहुँदा `#[rustc_const_unstable(feature = "foo", issue = "01234")]` अवस्थित हुन्छ।
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// विनियोजन नगरी सबैभन्दा ठूलो सम्भव `RawVec` (प्रणाली हीपमा) सिर्जना गर्दछ।
    /// यदि `T` को सकारात्मक आकार छ, तब यसले `0` क्षमताको साथ `RawVec` बनाउँछ।
    /// यदि `T` शून्य आकारको छ, तब यसले `usize::MAX` क्षमताको साथ `RawVec` बनाउँछ।
    /// ढिलाइ विनियोजन कार्यान्वयनको लागि उपयोगी।
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// `[T; capacity]` को लागी क्षमता र पign्क्तिबद्धता आवश्यकताको साथ `RawVec` (प्रणाली हिपमा) सिर्जना गर्दछ।
    /// यो कल गर्न `RawVec::new` बराबर हो जब `capacity` `0` वा `T` शून्य आकारको हुन्छ।
    /// नोट गर्नुहोस् कि यदि `T` शून्य आकारको छ यसको मतलब तपाईले अनुरोध गरिएको क्षमताको साथ `RawVec` प्राप्त गर्नुहुने छैन।
    ///
    /// # Panics
    ///
    /// Panics यदि अनुरोध गरिएको क्षमता `isize::MAX` बाइट भन्दा बढि छ।
    ///
    /// # Aborts
    ///
    /// ओओएममा एबर्ट्स।
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// जस्तै `with_capacity`, तर ग्यारेन्टी गर्दछ बफर शून्य छ।
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// सूचक र क्षमताबाट `RawVec` पुनर्गठन गर्दछ।
    ///
    /// # Safety
    ///
    /// `ptr` (सिस्टम हिपमा) विनियोजित हुनुपर्दछ, र दिइएको `capacity` सँग।
    /// `capacity` आकारका प्रकारहरूको लागि `isize::MAX` भन्दा बढी हुन सक्दैन।(32२-बिट प्रणालीहरूमा मात्र एउटा चिन्ता)।
    /// ZST vectors को क्षमता `usize::MAX` सम्म हुन सक्छ।
    /// यदि `ptr` र `capacity` एक `RawVec` बाट आयो, तब यो ग्यारेन्टी गरिएको छ।
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // सानो Vecs लाटो हुन्छन्।छोड्नुहोस्:
    // - If यदि एलिमेन्ट साइज १ हो, किनकि कुनै पनि हिप एलोकटरले कम 8 बाइट्स भन्दा कम by बाइट्सको अनुरोधलाई गोल गर्न सक्छ।
    //
    // - If यदि तत्व मध्यम-आकारका छन् (<=१ KiB)।
    // - १ अन्यथा, धेरै छोटो Vecs को लागी धेरै ठाउँ खेर फाल्नबाट जोगिन।
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// `new` लाई मन पर्यो, तर फिर्ता `RawVec` को लागी आवाश्यककर्ताको छनौटमा प्यारामेराइज गरिएको छ।
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` यसको मतलब "unallocated"।शून्य आकारका प्रकारहरू वेवास्ता गरियो।
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// `with_capacity` लाई मन पर्यो, तर फिर्ता `RawVec` को लागी आवाश्यककर्ताको छनौटमा प्यारामेराइज गरिएको छ।
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// `with_capacity_zeroed` लाई मन पर्यो, तर फिर्ता `RawVec` को लागी आवाश्यककर्ताको छनौटमा प्यारामेराइज्ड
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// `Box<[T]>` लाई `RawVec<T>` मा बदल्छ।
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// सम्पूर्ण बफरलाई निर्दिष्ट `len` को साथ `Box<[MaybeUninit<T>]>` मा रूपान्तरण गर्दछ।
    ///
    /// नोट गर्नुहोस् कि यसले कुनै पनि `cap` परिवर्तनहरू ठीकसँग पुनर्गठन गर्दछ जुन प्रदर्शन गरिएको हुन सक्छ।(विवरणका लागि प्रकारको विवरण हेर्नुहोस्।)
    ///
    /// # Safety
    ///
    /// * `len` सब भन्दा भर्खरको अनुरोध गरिएको क्षमता भन्दा ठूलो वा बराबर हुनै पर्छ, र
    /// * `len` `self.capacity()` भन्दा कम वा बराबर हुनुपर्छ।
    ///
    /// नोट गर्नुहोस्, कि अनुरोध गरिएको क्षमता र `self.capacity()` फरक हुन सक्छ, एक आवंटक समग्र गर्न र अनुरोध भन्दा ठूलो मेमोरी ब्लक फिर्ता गर्न सक्छ।
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // सुरक्षा आवाश्यकताको आधा भाग जाँच गर्नुहोस् (हामी अन्य आधा जाँच गर्न सक्दैनौं)।
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // हामी यहाँ `unwrap_or_else` लाई बेवास्ता गर्छौं किनकि यसले उत्पन्न गरिएको LLVM IR को मात्रा फुलाउँछ।
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// सूचक, क्षमता, र वितरकबाट `RawVec` पुनर्गठन गर्दछ।
    ///
    /// # Safety
    ///
    /// `ptr` विनियोजित गर्नु पर्छ (दिइएका विनियोजक `alloc` मार्फत), र दिइएको `capacity` सँग।
    /// `capacity` आकारका प्रकारहरूको लागि `isize::MAX` भन्दा बढी हुन सक्दैन।
    /// (32२-बिट प्रणालीहरूमा मात्र एउटा चिन्ता)।
    /// ZST vectors को क्षमता `usize::MAX` सम्म हुन सक्छ।
    /// यदि `ptr` र `capacity` `alloc` मार्फत बनाईएको `RawVec` बाट आयो भने, यो ग्यारेन्टी हुन्छ।
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// विनियोजनको सुरूवात गर्न कच्चा सूचक प्राप्त गर्दछ।
    /// नोट गर्नुहोस् कि यो `Unique::dangling()` यदि `capacity == 0` वा `T` शून्य आकारको छ।
    /// पहिलेको केसमा तपाई होशियार हुनुपर्छ।
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// विनियोजनको क्षमता हुन्छ।
    ///
    /// यो सँधै `usize::MAX` हुन्छ यदि `T` शून्य आकारको छ।
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// यस `RawVec` लाई समर्थन गर्दै आबद्धकर्तालाई साझेदारी गरिएको सन्दर्भ फर्काउँछ।
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // हामीसँग स्मृतिको आबंटित हिस्सा छ, त्यसैले हामी हाम्रो हालको लेआउट प्राप्त गर्न रनटाइम जाँचहरूलाई बाइपास गर्न सक्छौं।
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// सुनिश्चित गर्दछ कि बफरले कम्तिमा पर्याप्त मात्रामा `len + additional` एलिमेन्टहरू समात्दछ।
    /// यदि यो पहिले नै पर्याप्त क्षमता छैन भने, पर्याप्त ठाउँ र आरामदायक ढिलो ठाउँ पुन: संगठित गर्नेछ Amorised *O*(१) व्यवहार प्राप्त गर्न।
    ///
    /// यो व्यवहार सीमित गर्दछ यदि यसले अनावश्यक रूपमा आफैलाई panic मा निम्त्याउँदछ।
    ///
    /// यदि `len` `self.capacity()` भन्दा बढी, यो वास्तव मा अनुरोध गरिएको ठाउँ आबित गर्न असफल हुन सक्छ।
    /// यो वास्तवमै असुरक्षित छैन, तर असुरक्षित कोड *तपाईं* लेख्नुहोस् जुन यस प्रकार्यको व्यवहारमा निर्भर गर्दछ विच्छेद हुन सक्छ।
    ///
    /// `extend` जस्तै बल्क-पुश अपरेशन लागू गर्न यो आदर्श हो।
    ///
    /// # Panics
    ///
    /// Panics यदि नयाँ क्षमता `isize::MAX` बाइट भन्दा अधिक छ।
    ///
    /// # Aborts
    ///
    /// ओओएममा एबर्ट्स।
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // रिजर्व परित्याग वा डरलाग्दो हुन सक्छ यदि लेन `isize::MAX` भन्दा बढी भयो भने अब यो अनचेक गर्न सुरक्षित छ।
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// `reserve` को जस्तै, तर पनीकिking वा परित्यागको सट्टामा त्रुटिहरूमा फर्काउँछ।
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// सुनिश्चित गर्दछ कि बफरले कम्तिमा पर्याप्त मात्रामा `len + additional` एलिमेन्टहरू समात्दछ।
    /// यदि यो पहिले नै छैन भने, आवश्यक मेमोरीको न्यूनतम सम्भावित रकम पुनः गणना गर्दछ।
    /// सामान्यतया यो ठीकसँग आवश्यक मेमोरीको मात्रा हुनेछ, तर सिद्धान्तमा आवंटककर्ताले हामीले मागेको भन्दा बढी फिर्ता दिन स्वतन्त्र हुन्छ।
    ///
    ///
    /// यदि `len` `self.capacity()` भन्दा बढी, यो वास्तव मा अनुरोध गरिएको ठाउँ आबित गर्न असफल हुन सक्छ।
    /// यो वास्तवमै असुरक्षित छैन, तर असुरक्षित कोड *तपाईं* लेख्नुहोस् जुन यस प्रकार्यको व्यवहारमा निर्भर गर्दछ विच्छेद हुन सक्छ।
    ///
    /// # Panics
    ///
    /// Panics यदि नयाँ क्षमता `isize::MAX` बाइट भन्दा अधिक छ।
    ///
    /// # Aborts
    ///
    /// ओओएममा एबर्ट्स।
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// `reserve_exact` को जस्तै, तर पनीकिking वा परित्यागको सट्टामा त्रुटिहरूमा फर्काउँछ।
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// निर्दिष्ट राशिमा तल छुट संकुचन गर्दछ।
    /// यदि दिइएको रकम ० छ भने वास्तवमा पूर्ण रूपमा डेलोकेट्स।
    ///
    /// # Panics
    ///
    /// Panics यदि दिइएको रकम हालको क्षमता भन्दा *ठूलो* छ।
    ///
    /// # Aborts
    ///
    /// ओओएममा एबर्ट्स।
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// फिर्ता हुन्छ यदि बफरलाई आवश्यक थप क्षमता पूरा गर्नको लागि विकसित गर्न आवश्यक छ।
    /// मुख्य रूपमा `grow` इनलाइन नगरी सम्भव इनलाइनिंग रिजर्भ कलहरू गर्न प्रयोग गरियो।
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // यो विधि प्राय जसो पटक इन्स्ट्यान्ट हुन्छ।कम्पाइल समय सुधार गर्न हामी यो सकेसम्म सानो भएको चाहान्छौं।
    // तर हामी चाहान्छौं कि यसको धेरै भन्दा धेरै सामग्रीहरू पनि यथासक्दो स्ट्याटिबल कम्प्युटेबल भएको छ, जेनरेट गरिएको कोड रन छिटो बनाउनको लागि।
    // तसर्थ, यो विधि ध्यानपूर्वक लेखिएको छ ताकि `T` मा निर्भर सबै कोड यस भित्र छन्, जबकि जति धेरै `T` मा निर्भर गर्दैन कोडको अधिकतम `T` मा गैर-जेनेरिक हो।
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // यो कलिंग प्रसंगहरु द्वारा सुनिश्चित गरीएको छ।
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // किनकि हामी `usize::MAX` को क्षमता फिर्ता गर्छौं जब `elem_size` हुन्छ
            // ०, यहाँ पुग्नु आवश्यक `RawVec` X overfull छ।
            return Err(CapacityOverflow);
        }

        // दु: खको कुरा, हामी यी जाँचहरूको बारेमा साँच्चिकै गर्न सक्दैनौं।
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // यसले घातांकीय विकासको ग्यारेन्टी गर्दछ।
        // दोहोरो ओभरफ्लो हुन सक्दैन किनकि `cap <= isize::MAX` र `cap` को प्रकार `usize` हो।
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` मा गैर-सामान्य हो।
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // यस विधिमा अवरोधहरू `grow_amortized` मा जस्तै धेरै छन्, तर यो विधि सामान्यतया कम पटक इन्स्ट्यान्ट गरिन्छ त्यसैले यो कम महत्वपूर्ण छ।
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // किनकि हामी `usize::MAX` को क्षमता फिर्ता गर्छौं जब प्रकारको आकार हुन्छ
            // ०, यहाँ पुग्नु आवश्यक `RawVec` X overfull छ।
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` मा गैर-सामान्य हो।
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// यो प्रकार्य `RawVec` बाहिर कम्पाइल समय न्यूनतम गर्न को लागी हो।विवरणहरूको लागि `RawVec::grow_amortized` माथिको टिप्पणी हेर्नुहोस्।
// (`A` प्यारामिटर महत्त्वपूर्ण छैन, किनकि अभ्यासमा देखिने विभिन्न `A` प्रकारहरूको संख्या `T` प्रकारहरूको संख्या भन्दा धेरै सानो छ।)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // `RawVec::grow_*` को आकार न्यूनतम गर्न यहाँ त्रुटि जाँच गर्नुहोस्।
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // आवंटकले पign्क्तिबद्धता समानताको लागि जाँच गर्दछ
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// `RawVec`*द्वारा स्वामित्व प्राप्त मेमोरी फ्रि गर्दछ** यसको सामग्रीहरू छोड्ने प्रयास बिना।
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// आरक्षित त्रुटि ह्यान्डलिंगको लागि केन्द्रीय प्रकार्य।
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// हामीले निम्न कुराको ग्यारेन्टी गर्नु पर्छ:
// * हामी कहिले पनि `> isize::MAX` बाइट-साइज वस्तुहरू बाँडफाँड गर्दैनौं।
// * हामी `usize::MAX` ओभरफ्लो गर्दैनौं र वास्तवमै थोरै विनियोजित गर्दछौं।
//
// -64-बिटमा हामीले केवल ओभरफ्लो जाँच गर्न आवश्यक छ किनकि `> isize::MAX` बाइट्स बाँच्न प्रयास गर्दा असफल हुनेछ।
// - २-बिट र १--बिटमा हामीले यसका लागि अतिरिक्त गार्ड थप्न आवश्यक छ यदि हामी प्लेटफर्ममा चल्दैछौं जुन प्रयोगकर्ता-स्पेसमा सबै GB जीबी प्रयोग गर्न सक्छ, उदाहरणका लागि, PAE वा x32।
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// क्षमता ओभरफ्लो रिपोर्ट गर्नका लागि जिम्मेवार एउटा केन्द्रीय कार्य।
// यसले सुनिश्चित गर्दछ कि यी panics मा सम्बन्धित कोड जेनेरेसन न्यूनतम छ किनकि त्यहाँ केवल एक स्थान मात्र छ जुन panics भन्दा मोड्युल भर गुच्छा भन्दा।
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}