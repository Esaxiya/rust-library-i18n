//! एकल-थ्रेड भएको सन्दर्भ-गणना गणना पोइन्टर्स।'Rc' 'सन्दर्भ हो
//! Counted'.
//!
//! प्रकार [`Rc<T>`][`Rc`] प्रकार `T` को मूल्यको स्वामित्व प्रदान गर्दछ, हिपमा आवंटित गरियो।
//! [`Rc`] मा [`clone`][clone] आमन्त्रित गरी हिपमा समान आबंटनको लागि एक नयाँ सूचक उत्पादन गर्दछ।
//! जब कुनै XOX दिइएको सूचकलाई अन्तिम सूचक नष्ट गरिन्छ, त्यस आवंटनमा भण्डारित मान (प्राय: "inner value" भनिन्छ) पनि छोडिन्छ।
//!
//! Rust मा साझा संदर्भले पूर्वनिर्धारितद्वारा उत्परिवर्तन अस्वीकार गर्दछ, र [`Rc`] यसको अपवाद छैन: तपाईं सामान्यतया [`Rc`] भित्र कुनै चीजको लागि म्यूटेबल सन्दर्भ प्राप्त गर्न सक्नुहुन्न।
//! यदि तपाईंलाई म्युटेबिलिटी चाहिएको छ भने, [`Cell`] वा [`RefCell`] [`Rc`] भित्र राख्नुहोस्;[an example of mutability inside an `Rc`][mutability] हेर्नुहोस्।
//!
//! [`Rc`] गैर परमाणु सन्दर्भ मतगणना प्रयोग गर्दछ।
//! यसको मतलब यो छ कि ओभरहेड एकदम कम छ, तर [`Rc`] थ्रेडहरू बीच पठाउन सकिँदैन, र परिणाम स्वरूप [`Rc`] [`Send`][send] कार्यान्वयन गर्दैन।
//! नतिजाको रूपमा, Rust कम्पाइलरले *कम्पाइल समयमा* जाँच गर्नेछ कि तपाईंले थ्रेडहरू बीच [`Rc`] s पठाउँदै हुनुहुन्न।
//! यदि तपाईंलाई बहु-थ्रेडेड, आणविक संदर्भ गणना आवश्यक छ भने, [`sync::Arc`][arc] प्रयोग गर्नुहोस्।
//!
//! [`downgrade`][downgrade] विधि गैर-स्वामित्व वाला [`Weak`] सूचक सिर्जना गर्न प्रयोग गर्न सकिन्छ।
//! एक [`Weak`] सूचक [`अपग्रेड`][अपग्रेड] d एक [`Rc`] मा हुन सक्छ, तर यो [`None`] फर्काउँछ यदि विनियोजनमा भण्डार गरिएको मान पहिले नै छोडियो भने।
//! अर्को शब्दमा, `Weak` पोइन्टर्सले विनियोजन भित्र रहेको मानलाई जीवित राख्दैन;जे होस्, तिनीहरूले * बाँडफाँड (भित्री मूल्य को लागी ब्याकिंग स्टोर) राख्छन्।
//!
//! [`Rc`] पोइन्टर्स बीचको चक्र कहिले पनि डिलोकेट हुँदैन।
//! यस कारणले, [`Weak`] चक्र तोड्न प्रयोग गरिन्छ।
//! उदाहरण को लागी, एउटा रूखले कडा [`Rc`] सूचकहरू बच्चाहरूमा अभिभावक नोड्सबाट, र [`Weak`] सूचक बच्चाहरूबाट आफ्ना आमा बुबामा फर्काउन सक्छ।
//!
//! `Rc<T>` स्वचालित रूपमा `T` का सन्दर्भहरू ([`Deref`] trait मार्फत), त्यसैले तपाईं [`Rc<T>`][`Rc`] प्रकारको मानमा `T` विधिहरू कल गर्न सक्नुहुनेछ।
//! `T` का विधिहरूसँग नाम द्वन्द्वबाट बच्न, [`Rc<T>`][`Rc`] का विधिहरू सम्बन्धित कार्यहरू हुन्, जुन [fully qualified syntax] प्रयोग गरेर भनिन्छ:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>`Clone` जस्तो traits को implement का कार्यान्वयनहरू पूर्ण रूपमा योग्य सिन्ट्याक्स प्रयोग गरेर पनि बोलाउन सकिन्छ।
//! केही व्यक्ति पूर्ण रूपले योग्य सिन्ट्याक्स प्रयोग गर्न रुचाउँछन्, जबकि अरूले विधि-कल सिन्ट्याक्स प्रयोग गर्न रुचाउँछन्।
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // विधि-कल सिन्ट्याक्स
//! let rc2 = rc.clone();
//! // पूर्ण योग्य सिन्ट्याक्स
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] `T` मा स्वत: डेरेन्सन गर्दैन, किनकि भित्री मान पहिले नै छोडियो।
//!
//! # क्लोनिंग सन्दर्भ
//!
//! `Clone` trait [`Rc<T>`][`Rc`] र [`Weak<T>`][`Weak`] को लागी लागू गरिएको `Clone` trait को प्रयोग गरी अवस्थित सन्दर्भ गणना गरिएको सूचकको रूपमा समान विनियोजनको लागि नयाँ सन्दर्भ सिर्जना गर्न।
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // तल दुई वाक्य रचनाहरू बराबर छन्।
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a र b दुबै foo को समान स्मृति स्थानमा।
//! ```
//!
//! `Rc::clone(&from)` सिन्ट्याक्स सब भन्दा मुहावरे हो किनकि यसले कोडको अर्थ अधिक स्पष्ट रूपमा प्रस्तुत गर्दछ।
//! माथिको उदाहरणमा, यो सिन्ट्याक्सले यो बुझ्न सजिलो बनाउँदछ कि यो कोड foo को सम्पूर्ण सामग्री प्रतिलिपि गर्नुको सट्टा नयाँ सन्दर्भ सिर्जना गर्दैछ।
//!
//! # Examples
//!
//! एउटा परिदृश्य विचार गर्नुहोस् जहाँ `Gadget`s को एक सेट `Owner` द्वारा स्वामित्व प्राप्त छ।
//! हामी हाम्रो `ग्याजेट बिन्दुलाई उनीहरूको `Owner` गर्न चाहन्छौं।हामी यो अद्वितीय स्वामित्वको साथ गर्न सक्दैनौं, किनकि एक भन्दा बढी ग्याजेट समान `Owner` को हुन सक्छ।
//! [`Rc`] हामीलाई बहु `ग्याजेटहरूका बीच `Owner` साझेदारी गर्न अनुमति दिन्छ, र `Owner` यसमा कुनै `Gadget` पोइन्टसम्म लामो समयसम्म बाँडफाँड गरिरहन्छ।
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... अन्य क्षेत्रहरू
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... अन्य क्षेत्रहरू
//! }
//!
//! fn main() {
//!     // एक संदर्भ गणना `Owner` सिर्जना गर्नुहोस्।
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // `gadget_owner` मा सम्बन्धित `ग्याजेट सिर्जना गर्नुहोस्।
//!     // `Rc<Owner>` क्लोनिंगले हामीलाई उही `Owner` विनियोजनमा नयाँ सूचक दिन्छ, प्रक्रियामा सन्दर्भ गणना बढाउँदै।
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // हाम्रो स्थानीय चर `gadget_owner` डिस्पोज।
//!     drop(gadget_owner);
//!
//!     // `gadget_owner` छोड्ने बावजुद, हामी अझै पनि `ग्याजेटको `Owner` को नाम छाप्न सक्षम छौं।
//!     // यो किनभने हामीले मात्र एकल `Rc<Owner>` खसाल्यौं, `Owner` यसलाई औंल्याउँदैन।
//!     // जबसम्म त्यहाँ अन्य `Rc<Owner>` समान `Owner` विनियोजनमा स poin्केत गर्दछ, यो प्रत्यक्ष रहनेछ।
//!     // फिल्ड प्रोजेक्शन `gadget1.owner.name` ले कार्य गर्दछ किनभने `Rc<Owner>` स्वचालित रूपमा `Owner` लाई डेरेरेन्ट गर्दछ।
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // प्रकार्यको अन्त्यमा, `gadget1` र `gadget2` नष्ट गरियो, र तिनीहरूसँग हाम्रो `Owner` मा अन्तिम गणना गरिएको संदर्भहरू छन्।
//!     // ग्याजेट म्यान अब साथै नष्ट हुन्छ।
//!     //
//! }
//! ```
//!
//! यदि हाम्रो आवश्यकताहरू परिवर्तन भयो, र हामी पनि `Owner` बाट `Gadget` मा ट्रान्सभर्स गर्न सक्षम हुनु आवश्यक छ, हामी समस्याहरूमा जान्छौं।
//! `Owner` बाट `Gadget` सम्म [`Rc`] सूचकले एक चक्र परिचय गर्दछ।
//! यसको मतलव तिनीहरूको सन्दर्भ संख्या ० मा कहिले पनि पुग्न सक्दैन, र यो आवंटन कहिले पनि नष्ट हुँदैन:
//! एक मेमोरी चुहावटयसको वरिपरि जानको लागि, हामी [`Weak`] पोइन्टर्स प्रयोग गर्न सक्दछौं।
//!
//! Rust वास्तवमा यसलाई यो स्थानमा पहिलो स्थानमा उत्पादन गर्न केही गाह्रो हुन्छ।दुई मानहरूको अन्त्य गर्न एक अर्कोमा औंल्याउने, ती मध्ये एक परिवर्तित हुनु पर्छ।
//! यो गाह्रो छ किनकि [`Rc`] ले मेमोरी सुरक्षा प्रवर्तन गर्दछ केवल यसलाई रैप गरिएको मानको लागि साझेदारी सन्दर्भहरू दिएर, र यसले प्रत्यक्ष उत्परिवर्तनलाई अनुमति दिदैन।
//! हामीले [`RefCell`] मा रूपान्तरण गर्न चाहेको मूल्यको अंश लपेट्नु पर्छ, जसले *आन्तरिक उत्परिवर्तन* प्रदान गर्दछ: साझा संदर्भको माध्यमबाट उत्परिवर्तन प्राप्त गर्ने विधि।
//! [`RefCell`] रनटाइममा Rust को उधारो नियमहरू लागू गर्दछ।
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... अन्य क्षेत्रहरू
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... अन्य क्षेत्रहरू
//! }
//!
//! fn main() {
//!     // एक संदर्भ गणना `Owner` सिर्जना गर्नुहोस्।
//!     // नोट गर्नुहोस् कि हामीले X मालिकको vector `Gadget`s को `RefCell` भित्र राख्यौं जसले गर्दा हामी यसलाई एक साझा सन्दर्भ मार्फत परिवर्तन गर्न सक्दछौं।
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // `gadget_owner` सम्बन्धित `ग्याजेटहरू सिर्जना गर्नुहोस्, पहिले जस्तो।
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // X Gadget`s लाई तिनीहरूको `Owner` मा थप्नुहोस्।
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` गतिशील orrowण यहाँ समाप्त हुन्छ।
//!     }
//!
//!     // हाम्रो `ग्याजेटमा उनीहरूको विवरणहरू प्रिन्ट गर्नुहोस्।
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` एक `Weak<Gadget>` हो।
//!         // किनकि `Weak` पोइन्टर्स अझै पनी वितरणको ग्यारेन्टी गर्न सक्दैन, हामीले `upgrade` कल गर्नु पर्छ, जसले `Option<Rc<Gadget>>` फिर्ता गर्छ।
//!         //
//!         //
//!         // यस केसमा हामीलाई थाहा छ यो विनियोजन अझै अवस्थित छ, त्यसैले हामी केवल `unwrap` `Option`।
//!         // अधिक जटिल प्रोग्राममा, तपाईलाई `None` परिणामको लागी सुंदर त्रुटि ह्यान्डलिंग आवश्यक पर्दछ।
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // प्रकार्यको अन्त्यमा, `gadget_owner`, `gadget1`, र `gadget2` नष्ट गरियो।
//!     // ग्याजेटहरूमा अब कुनै शक्तिशाली (`Rc`) सूचकहरू छैनन्, त्यसैले तिनीहरू नष्ट भए।
//!     // यसले ग्याजेट म्यानमा सन्दर्भ गणनालाई शून्य गर्दछ, त्यसैले ऊ पनि नष्ट हुन्छ।
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// यो सम्भावित फिल्ड-रिअर्डरिंगको बिरूद्ध repr(C) बाट future-प्रूफ हो, जसले ट्रान्समिटेबल भित्री प्रकारका सुरक्षित [into|from]_raw() सँग हस्तक्षेप गर्दछ।
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// एकल-थ्रेड भएको सन्दर्भ-गणना गणना सूचक।'Rc' 'सन्दर्भ हो
/// Counted'.
///
/// अधिक जानकारीको लागि [module-level documentation](./index.html) हेर्नुहोस्।
///
/// `Rc` को अन्तर्निहित विधिहरू सबै सम्बन्धित कार्यहरू हुन्, जसको मतलब तपाईंले तीनिहरूलाई `value.get_mut()` को सट्टामा [`Rc::get_mut(&mut value)`][get_mut] भन्नु पर्ने हुन्छ।
/// यसले भित्री प्रकारको `T` को विधिहरूसँग द्वन्द्वहरूलाई बेवास्ता गर्दछ।
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // यो असुरक्षित छ किनकि यो आरसी जीवित छ जबकि हामी ग्यारेन्टी छौं कि भित्री सूचक मान्य छ।
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// नयाँ `Rc<T>` निर्माण गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // त्यहाँ एक मजबूत कमजोर सूचक सबै मजबूत पोइन्टर्सको स्वामित्वमा छ, जसले यो सुनिश्चित गर्दछ कि कमजोर विनाशकर्ताले कहिले पनि बाँडफाँड गर्दैन कडा विनाशक चलिरहेको छ, जबकि कमजोर सूचक कडा भित्र रहेको छ।
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// नयाँ `Rc<T>` निर्माण गर्दछ आफैमा कमजोर सन्दर्भ प्रयोग गरेर।
    /// यस प्रकार्यले फर्काउनु भन्दा पहिले कमजोर सन्दर्भ अपग्रेड गर्न प्रयास गर्दा `None` मानमा परिणाम हुनेछ।
    ///
    /// यद्यपि कमजोर सन्दर्भलाई स्वतन्त्र रूपमा क्लोन गर्न सकिन्छ र पछि प्रयोगको लागि भण्डारण गर्न सकिन्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... अधिक क्षेत्रहरू
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // "uninitialized" राज्य भित्र भित्री एकल कमजोर सन्दर्भको साथ बनाउनुहोस्।
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // यो महत्त्वपूर्ण छ कि हामी कमजोर सूचकको स्वामित्व त्याग्दैनौं, वा अन्यथा `data_fn` रिटर्न द्वारा मेमोरी खाली हुन सक्छ।
        // यदि हामी वास्तवमै स्वामित्व पास गर्न चाहान्छौं भने, हामी आफैंको लागि अतिरिक्त कमजोर सूचक सिर्जना गर्न सक्थ्यौं, तर यसले कमजोर सन्दर्भ गणनालाई थप अपडेटहरू दिनेछ जुन अन्यथा आवश्यक नहुन सक्छ।
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // कडा सन्दर्भले सामूहिक रूपमा एक साझा कमजोर संदर्भको स्वामित्व लिनुपर्दछ, त्यसैले हाम्रो पुरानो कमजोर सन्दर्भको लागि विनाशकारी चलाउनुहोस्।
        //
        mem::forget(weak);
        strong
    }

    /// अनावश्यक सामग्रीको साथमा नयाँ `Rc` निर्माण गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // स्थगित आरम्भ:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// `0` बाइट्सको साथ मेमोरी भरिएको साथ, ईनिटिटलाइज गरिएको सामग्रीको साथ नयाँ `Rc` निर्माण गर्दछ।
    ///
    ///
    /// यस विधिको सही र गलत प्रयोगको उदाहरणका लागि [`MaybeUninit::zeroed`][zeroed] हेर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// नयाँ `Rc<T>` निर्माण गर्दछ, त्रुटि फिर्ता भयो यदि बाँडफाँड असफल भयो भने
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // त्यहाँ एक मजबूत कमजोर सूचक सबै मजबूत पोइन्टर्सको स्वामित्वमा छ, जसले यो सुनिश्चित गर्दछ कि कमजोर विनाशकर्ताले कहिले पनि बाँडफाँड गर्दैन कडा विनाशक चलिरहेको छ, जबकि कमजोर सूचक कडा भित्र रहेको छ।
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// एक नया `Rc` निर्मित ईन्टिटिनाइजेसन सामग्री सहित निर्माण गर्दछ, त्रुटि फिर्ता भयो भने यदि विनियोजन असफल भयो
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // स्थगित आरम्भ:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// `0` बाइट्सका साथ मेमोरी भरिएको, अनावश्यक सामग्रीको साथ नयाँ `Rc` निर्माण गर्दछ, यदि त्रुटि असफल भएमा त्रुटि फिर्ता गर्छ
    ///
    ///
    /// यस विधिको सही र गलत प्रयोगको उदाहरणका लागि [`MaybeUninit::zeroed`][zeroed] हेर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// नयाँ `Pin<Rc<T>>` निर्माण गर्दछ।
    /// यदि `T` `Unpin` कार्यान्वयन गर्दैन, तब `value` मेमोरीमा पिन हुनेछ र सर्न असक्षम भयो।
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// भित्री मान फिर्ता गर्दछ, यदि `Rc` सँग ठीक एक मजबूत संदर्भ छ भने।
    ///
    /// अन्यथा,[`Err`] X फिर्ता गरिएको समान `Rc` सँग फिर्ता भयो।
    ///
    ///
    /// यो सफल हुनेछ यदि त्यहाँ उल्लेखनीय कमजोर सन्दर्भहरू छन्।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // निहित वस्तुको प्रतिलिपि गर्नुहोस्

                // कमजोरहरूलाई संकेत गर्नुहोस् कि ती सबल गन्ती घटाएर पदोन्नति हुन सक्दैन, र त्यसपछि अंतर्निहीत "strong weak" पोइन्टर हटाउनुहोस् जबकि ड्रप तर्कलाई ह्यान्डल गर्दा केवल नक्कली कमजोर शिल्प गरेर।
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// इन्टिनिटाइज गरिएको सामग्रीका साथ नयाँ सन्दर्भ-गणना स्लाइस निर्माण गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // स्थगित आरम्भ:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// `0` बाइट्सको साथ मेमोरी भरीएकोले, ईन्निटिटलाइज्ड सामग्रीको साथ नयाँ सन्दर्भ-गणना स्लाइस निर्माण गर्दछ।
    ///
    ///
    /// यस विधिको सही र गलत प्रयोगको उदाहरणका लागि [`MaybeUninit::zeroed`][zeroed] हेर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// `Rc<T>` मा रूपान्तरण गर्दछ।
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] को रूपमा, यो कलरमा निर्भर हुन्छ कि ग्यारेन्टी गर्न कि भित्री मान वास्तवमा आरम्भिक अवस्थामा छ।
    ///
    /// यो कलिंग गर्दा जब सामग्री अझै पूर्ण रूपमै आरम्भ गरिएको छैन तत्काल अपरिभाषित व्यवहारको कारण गर्दछ।
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // स्थगित आरम्भ:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// `Rc<[T]>` मा रूपान्तरण गर्दछ।
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] को रूपमा, यो कलरमा निर्भर हुन्छ कि ग्यारेन्टी गर्न कि भित्री मान वास्तवमा आरम्भिक अवस्थामा छ।
    ///
    /// यो कलिंग गर्दा जब सामग्री अझै पूर्ण रूपमै आरम्भ गरिएको छैन तत्काल अपरिभाषित व्यवहारको कारण गर्दछ।
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // स्थगित आरम्भ:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// `Rc` खान्छ, र्याप गरिएको सूचक फिर्ता गर्दै।
    ///
    /// मेमोरी चुहावटबाट बच्न सूचकलाई [`Rc::from_raw`][from_raw] प्रयोग गरेर `Rc` मा परिवर्तन गर्नुपर्दछ।
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// डाटालाई कच्चा सूचक प्रदान गर्दछ।
    ///
    /// गन्तीहरू कुनै पनि तरिकाले प्रभावित हुँदैनन् र `Rc` उपभोग हुँदैन।
    /// `Rc` मा बलियो गणनाहरू छन् जबसम्म सूचक मान्य छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // सुरक्षा: यो Deref::deref वा Rc::inner मार्फत जान सक्दैन किनभने किनभने
        // यसको लागि raw/mut प्रोभेन्सन्स राख्न आवश्यक पर्दछ
        // `get_mut` `from_raw` मार्फत Rc पुन: प्राप्त भएपछि सूचकको माध्यमबाट लेख्न सक्छ।
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// एक कच्चा सूचक बाट एक `Rc<T>` बनाउँछ।
    ///
    /// कच्चा सूचक पहिले [`Rc<U>::into_raw`][into_raw] लाई फिर्ता फिर्ता गरिएको हुनुपर्छ जहाँ `U` सँग समान आकार र `T` को रूपमा पment्क्तिबद्धता हुनुपर्दछ।
    /// यदि यो `U` `T` हो भने यो तुच्छ हो।
    /// नोट गर्नुहोस् कि यदि `U` `T` हैन, तर उही आकार र पign्क्तिबद्धता छ भने, यो मूल रूपमा फरक प्रकारको सन्दर्भ ट्रान्समिटि। जस्तै हो।
    /// यस केसमा के प्रतिबन्धहरू लागू हुन्छन् भन्ने बारे थप जानकारीको लागि [`mem::transmute`][transmute] हेर्नुहोस्।
    ///
    /// `from_raw` को प्रयोगकर्ताले `T` को एक खास मूल्य एक पटक मात्र छोडियो भनेर निश्चित गर्नुपर्दछ।
    ///
    /// यो प्रकार्य असुरक्षित हो किनभने अनुचित प्रयोगले मेमोरी असुरक्षित गर्न सक्दछ, फिर्ता `Rc<T>` कहिल्यै पहुँच नहुने भए पनि।
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // चुहावट रोक्नको लागि फेरि `Rc` मा रूपान्तरण गर्नुहोस्।
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Rc::from_raw(x_ptr)` लाई थप कलहरू मेमोरी-असुरक्षित हुनेछन्।
    /// }
    ///
    /// // `x` माथिको दायरा बाहिर गयो जब यो मेमोरी खाली भयो, त्यसैले `x_ptr` अब झुम्झिरहेको छ!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // सक्कली RcBox फेला पार्न अफसेटलाई उल्टाउनुहोस्।
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// यो विनियोजन गर्न नयाँ [`Weak`] सूचक सिर्जना गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // निश्चित गर्नुहोस् कि हामी व्याकुल कमजोरी सिर्जना गर्दैनौं
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// यो विनियोजनमा [`Weak`] पोइन्टर्सको संख्या प्राप्त गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// यस विनियोजनको लागि सशक्त (`Rc`) सूचकहरूको संख्या प्राप्त गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// XOX फिर्ता गर्दछ यदि त्यहाँ कुनै `Rc` वा [`Weak`] पोइन्टर्स यो आबंटनको लागि छैन भने।
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// दिईएको `Rc` मा एक परिवर्तनीय सन्दर्भ फर्काउँछ, यदि त्यहाँ समान XO1X वा [`Weak`] सूचकहरू छैन भने।
    ///
    ///
    /// अन्यथा [`None`] फर्काउँछ, किनकि यो सेयर गरिएको मान परिवर्तन गर्न सुरक्षित छैन।
    ///
    /// [`make_mut`][make_mut] पनि हेर्नुहोस्, जुन भित्री मान [`clone`][clone] हुनेछ जब त्यहाँ अन्य सूचकहरू छन्।
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// कुनै चेक बिना, दिइएको `Rc` मा एक परिवर्तनीय सन्दर्भ फर्काउँछ।
    ///
    /// [`get_mut`] पनि हेर्नुहोस्, जुन सुरक्षित छ र उपयुक्त जाँच गर्दछ।
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// कुनै पनि अन्य `Rc` वा [`Weak`] सूचक उही आव्हानमा फर्काइएको orrowणको अवधिको लागि डेरेफरेसन हुनु हुँदैन।
    ///
    /// यो तुच्छ घटना हो यदि कुनै सूचकहरू अवस्थित छैनन्, उदाहरणको लागि तुरून्त `Rc::new` पछि।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // हामी "count" फिल्डहरू कभर गर्ने * ** सन्दर्भ सिर्जना गर्न सावधान छौं, किनकि यसले संदर्भ गणनामा पहुँचका साथ विरोधाभासपूर्ण हुन्छ (जस्तै:
        // `Weak` द्वारा)।
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// `true` फर्काउँछ यदि दुई same Rc`s समान आबंटनको लागि पोइन्ट गर्दछ ([`ptr::eq`] समान शिरामा)।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// दिइएको `Rc` मा म्यूटेबल सन्दर्भ बनाउँदछ।
    ///
    /// यदि त्यहाँ अन्य `Rc` सूचकहरू समान आबंटनमा छन् भने, त्यसोभए `make_mut` आन्तरिक मान [`clone`] नयाँ आबंटनको लागि अद्वितीय स्वामित्व सुनिश्चित गर्न हुनेछ।
    /// यसलाई क्लोन-अन-राइटको रूपमा पनि चिनिन्छ।
    ///
    /// यदि त्यहाँ यस विनियोजनको लागि कुनै अन्य `Rc` पोइन्टर्स छैन भने, यस XO1X पोइन्टर्स यस अलगमा अलग गरिनेछ।
    ///
    /// [`get_mut`] पनि हेर्नुहोस्, जो क्लोनिंगको सट्टा असफल हुनेछ।
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // केहि क्लोन छैन
    /// let mut other_data = Rc::clone(&data);    // भित्री डेटा क्लोन गर्दैन
    /// *Rc::make_mut(&mut data) += 1;        // क्लोनहरू भित्री डेटा
    /// *Rc::make_mut(&mut data) += 1;        // केहि क्लोन छैन
    /// *Rc::make_mut(&mut other_data) *= 2;  // केहि क्लोन छैन
    ///
    /// // अब `data` र `other_data` विभिन्न आबंटनहरु लाई जनाउँछ।
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] पोइन्टर्स अलग गरिनेछ:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // डाटा क्लोन भयो, त्यहाँ अरू आरसीएस छन्।
            // क्लोन गरिएको मान सीधा लेख्न अनुमति दिन पूर्व-बाँडफाड मेमोरी।
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // केवल डाटा चोर्न सक्दछ, खाली सबै Weakks मा छ
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // निहित कडा-कमजोर रेफ हटाउनुहोस् (यहाँ नक्कली कमजोर शिल्प गर्न आवश्यक पर्दैन-हामीलाई थाहा छ अन्य कमजोरहरूले हाम्रो लागि सफा गर्न सक्दछन्)।
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // यो असुरक्षित छ ठीक छ किनभने हामीले ग्यारेन्टी गर्यौं कि सूचक फिर्ता *केवल* पोइन्टर हो जुन कहिले पनि T मा फिर्ता आउनेछ।
        // हाम्रो सन्दर्भ गणना यस बिन्दुमा १ हुने ग्यारेन्टी गरिएको छ, र हामीले `Rc<T>` आफै `mut` हुनु आवश्यक छ, त्यसैले हामी यस सम्झौताको लागि मात्र सम्भावित सन्दर्भ फर्काइरहेका छौं।
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// एक कंक्रीट प्रकारमा `Rc<dyn Any>` डाउनकास्ट गर्न प्रयास गर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// एक `RcBox<T>` सम्भावित असक्षम आकार भित्री मानको लागि पर्याप्त स्थानको साथ आवंटित गर्दछ जहाँ मानको लेआउट प्रदान गरिएको छ।
    ///
    /// प्रकार्य `mem_to_rcbox` डाटा पोइन्टरको साथ कल गरिएको छ र `RcBox<T>` को लागी एक (सम्भावित फ्याट)-पोइन्टर फिर्ता गर्नु पर्छ।
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // दिइएको मान लेआउट प्रयोग गरेर लेआउट गणना गर्नुहोस्।
        // पहिले, लेआउट `&*(ptr as* const RcBox<T>)` अभिव्यक्ति मा गणना गरिएको थियो, तर यो एक गलत हस्ताक्षर संदर्भ सिर्जना (#54908 हेर्नुहोस्)।
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// एक `RcBox<T>` सम्भावित असक्षम आकार भित्री मानको लागि पर्याप्त ठाउँको साथ बाँडफाँट गर्दछ जहाँ मानले रूपरेखा प्रदान गरेको छ, यदि त्रुटि असफल भएमा त्रुटि फिर्ता गर्ने।
    ///
    ///
    /// प्रकार्य `mem_to_rcbox` डाटा पोइन्टरको साथ कल गरिएको छ र `RcBox<T>` को लागी एक (सम्भावित फ्याट)-पोइन्टर फिर्ता गर्नु पर्छ।
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // दिइएको मान लेआउट प्रयोग गरेर लेआउट गणना गर्नुहोस्।
        // पहिले, लेआउट `&*(ptr as* const RcBox<T>)` अभिव्यक्ति मा गणना गरिएको थियो, तर यो एक गलत हस्ताक्षर संदर्भ सिर्जना (#54908 हेर्नुहोस्)।
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // लेआउट को लागी आवंटित
        let ptr = allocate(layout)?;

        // RcBox सुरू गर्नुहोस्
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// एक असक्षम भित्री मानको लागि पर्याप्त ठाउँको साथ एक `RcBox<T>` आवंटित गर्दछ
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // दिइएको मान प्रयोग गरेर `RcBox<T>` को लागी विनियोजन गर्नुहोस्।
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // बाइट्सको रूपमा मूल्य प्रतिलिपि गर्नुहोस्
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // यसको सामग्रीहरू खसाल बिना नै वितरण छुट गर्नुहोस्
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// दिईएको लम्बाईको साथ `RcBox<[T]>` बाँडफाँड गर्दछ।
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// स्लाइसबाट एलिमेन्टहरू प्रतिलिपि गर्नुहोस् भर्खरै विनियोजित आरसी <\[T\]> मा
    ///
    /// असुरक्षित किनकि कलरले या त स्वामित्व लिनुपर्दछ वा `T: Copy` लाई पक्का गर्नु पर्छ
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// एक निश्चित आकार को रूपमा परिचित इटरेटरबाट `Rc<[T]>` निर्माण गर्दछ।
    ///
    /// व्यवहार अपरिभाषित छ साइज गलत हुनुपर्दछ।
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // T0 क्लोनिंग गर्दै Panic गार्ड।
        // panic को घटनामा, नयाँ RcBox मा लेखिएका एलिमेन्टहरू छोडिनेछ, त्यसपछि मेमोरी खाली हुन्छ।
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // पहिलो तत्वमा पोइन्टर
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // सबै खाली।गार्ड बिर्सनुहोस् ताकि यसले नयाँ आरसीबक्सलाई स्वतन्त्र पार्दैन।
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` को लागी प्रयोग गरिएको विशेषज्ञता trait।
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// `Rc` ड्रप गर्दछ।
    ///
    /// यो मजबूत संदर्भ गणना घटाउनेछ।
    /// यदि कडा सन्दर्भ गणना शून्यमा पुग्छ भने मात्र अन्य सन्दर्भहरू (यदि कुनै छन्) [`Weak`] हुन्, त्यसैले हामी भित्री मान `drop`।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // केहि पनि प्रिन्ट गर्दैन
    /// drop(foo2);   // "dropped!" प्रिन्ट गर्दछ
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // समावेश वस्तुलाई नष्ट गर्नुहोस्
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // अब सम्मिलित "strong weak" सूचक हटाउनुहोस् कि हामीले सामग्रीहरू नष्ट गरेका छौं।
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// `Rc` सूचकको क्लोन बनाउँछ।
    ///
    /// यसले समान आवंटनमा अर्को सूचक सिर्जना गर्दछ, कडा सन्दर्भ गणनालाई बढाउँदै।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// `T` का लागि `Default` मानको साथ, नयाँ `Rc<T>` सिर्जना गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// ह्याकसँग `Eq` मा विशेषज्ञता अनुमति दिन पनि `Eq` सँग एक विधि छ।
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// हामी यहाँ यो विशेषज्ञता गरिरहेका छौं, र `&T` मा अधिक सामान्य अनुकूलनको रूपमा होइन, किनभने यसले अन्यथा सबै रेफ्रेसमा सबै समानता जाँचमा लागत थप्न सक्छ।
/// हामी मान्दछौं कि values Rc`s ठूला मानहरू भण्डारण गर्न प्रयोग गरिन्छ, जुन क्लोन गर्न ढिलो हुन्छ, तर समानताको लागि जाँच्न पनि गाह्रो हुन्छ, जसले गर्दा यो लागत अधिक सजीलो भुक्तान हुन्छ।
///
/// योसँग दुई `Rc` क्लोन हुने सम्भावना पनि छ, समान मानमा दुई `&T`s भन्दा बढि।
///
/// हामी केवल तब गर्न सक्दछौं जब `T: Eq` `PartialEq` को रूपमा जानाजानी अपूरणीय हुन सक्छ।
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// दुई `Rc`s को लागि समानता।
    ///
    /// दुई `Rc`s बराबर छन् यदि उनीहरूको भित्री मानहरू बराबर छन् भने पनि तिनीहरू फरक आवंटनमा भण्डार गरिएको छ।
    ///
    /// यदि `T` ले `Eq` (समानताको अपवर्तन) लाई लागू गर्दछ भने, दुई `Rc`s जुन समान आबंटनमा पोइन्ट गर्दछ सधैं समान हुन्छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// दुई `Rc`s को लागि असमानता।
    ///
    /// दुई `Rc`s असमान छन् यदि उनीहरूको भित्री मानहरू असमान छन्।
    ///
    /// यदि `T` ले `Eq` (समानताको अपवर्तनशीलता) लागू गर्दछ भने, दुई `Rc`s जुन समान आबंटनलाई देखाउँदछ कहिले पनि असमान हुँदैन।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// दुई `Rc`s का लागि आंशिक तुलना।
    ///
    /// दुईको आन्तरिक मानहरूमा `partial_cmp()` कल गरेर तुलना गरिएको छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// दुई `Rc`s को लागि तुलना भन्दा कम।
    ///
    /// दुईको आन्तरिक मानहरूमा `<` कल गरेर तुलना गरिएको छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 'भन्दा कम वा बराबर' दुई `Rc`s का लागि तुलना।
    ///
    /// दुईको आन्तरिक मानहरूमा `<=` कल गरेर तुलना गरिएको छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// ग्रेटर-तुलना दुई `Rc` को लागि।
    ///
    /// दुईको आन्तरिक मानहरूमा `>` कल गरेर तुलना गरिएको छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// दुई भन्दा `Rc`s को तुलना तुलनामा 'भन्दा ठूलो वा बराबर'।
    ///
    /// दुईको आन्तरिक मानहरूमा `>=` कल गरेर तुलना गरिएको छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// दुई `Rc`s का लागि तुलना।
    ///
    /// दुईको आन्तरिक मानहरूमा `cmp()` कल गरेर तुलना गरिएको छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// सन्दर्भ-गणना स्लाइस आवंटित गर्नुहोस् र cl v` को आईटमहरू क्लोनिंग गरेर भर्नुहोस्।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// सन्दर्भ-गणना स्ट्रि sl स्लाइस आवाश्यक गर्नुहोस् र यसमा `v` प्रतिलिपि गर्नुहोस्।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// सन्दर्भ-गणना स्ट्रि sl स्लाइस आवाश्यक गर्नुहोस् र यसमा `v` प्रतिलिपि गर्नुहोस्।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// एक बाकस गरिएको वस्तुलाई नयाँ, सन्दर्भ गणना, वाटपमा सार्नुहोस्।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// सन्दर्भ-गणना स्लाइस आवंटित गर्नुहोस् र यसमा `v` वस्तुहरू सार्नुहोस्।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Vec लाई यसको मेमोरी खाली गर्न अनुमति दिनुहोस्, तर यसको सामग्रीहरू नष्ट नगर्नुहोस्
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// प्रत्येक तत्व `Iterator` मा लिन्छ र यसलाई `Rc<[T]>` मा संकलन गर्दछ।
    ///
    /// # प्रदर्शन विशेषताहरु
    ///
    /// ## सामान्य मामला
    ///
    /// सामान्य अवस्थामा, `Rc<[T]>` मा संकलन `Vec<T>` X मा पहिले स first्कलन गरेर गरिन्छ।त्यो हो, जब निम्नलिखित लेखन:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// यो यस्तो लेख्छ कि हामीले लेखेका छौं:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // विनियोजनको पहिलो सेट यहाँ हुन्छ।
    ///     .into(); // `Rc<[T]>` को लागी दोस्रो आव्हान यहाँ हुन्छ।
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// यो `Vec<T>` निर्माण गर्न को लागी धेरै पटक आबोलित गर्दछ र त्यसपछि यो `Vec<T>` लाई `Rc<[T]>` मा बदल्नको लागि एक पटक आवंटित हुनेछ।
    ///
    ///
    /// ## ज्ञात लम्बाइका आईटेटरहरू
    ///
    /// जब तपाईंको `Iterator` ले `TrustedLen` लागू गर्दछ र सही आकारको छ, एक एकल विनियोजन `Rc<[T]>` को लागि गरिन्छ।उदाहरण को लागी:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // यहाँ एकल विनियोजन हुन्छ।
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// विशेषज्ञता trait `Rc<[T]>` मा संकलनको लागि प्रयोग।
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // यो एक `TrustedLen` पुनरावृत्तिको लागि केस हो।
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // सुरक्षा: हामीले यो सुनिश्चित गर्नु पर्छ कि पुनरावृत्तिको ठीक लम्बाई छ र हामीसँग छ।
                Rc::from_iter_exact(self, low)
            }
        } else {
            // सामान्य कार्यान्वयनमा फर्कनुहोस्।
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` [`Rc`] को संस्करण हो जुन प्रबन्धित विनियोजनको गैर-स्वामित्व सन्दर्भ राख्दछ।`Weak` सूचकमा [`upgrade`] कल गरेर विनियोजन पहुँच गरिएको छ, जसले [`विकल्प`] returns <`[`Rc`] returns फिर्ता गर्छ<T>>`।
///
/// एक `Weak` सन्दर्भ स्वामित्व तिर गणना छैन, यो बाँडफाँड मा भण्डार गरिएको मान छोड्दा रोक्ने छैन, र `Weak` आफैं अझै पनी मूल्य रहेको बारे कुनै ग्यारेन्टी बनाउँदैन।
/// यसैले यसले [`None`] फिर्ता गर्न सक्दछ जब [`अपग्रेड`] d।
/// तथापि नोट गर्नुहोस् कि एक `Weak` सन्दर्भ *गर्दछ* बाँडफाँड आफैं (समर्थन स्टोर) deallocated हुनबाट रोक्छ।
///
/// एक `Weak` सूचक [`Rc`] द्वारा व्यवस्थित विनियोजनको एक अस्थायी संदर्भ राख्नको लागि यसको आन्तरिक मान ड्रप हुनबाट रोक्नको लागि उपयोगी छ।
/// यो [`Rc`] पोइन्टर्स बीच गोलाकार सन्दर्भ रोक्न पनि प्रयोग गरिन्छ, किनकि आपसी स्वामित्व सन्दर्भले कहिले पनि [`Rc`] छोड्ने अनुमति दिँदैन।
/// उदाहरण को लागी, एउटा रूखले कडा [`Rc`] सूचकहरू बच्चाहरूमा अभिभावक नोड्सबाट, र `Weak` सूचक बच्चाहरूबाट आफ्ना आमा बुबामा फर्काउन सक्छ।
///
/// `Weak` पोइन्टर प्राप्त गर्न विशिष्ट तरिका भनेको [`Rc::downgrade`] कल गर्नु हो।
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // यो `NonNull` हो enums मा यस प्रकारको आकार अनुकूलन अनुमति दिन को लागी, तर यो एक मान्य सूचक आवश्यक छैन।
    //
    // `Weak::new` यसलाई `usize::MAX` मा सेट गर्दछ ताकि यसलाई हिपमा खाली स्थान विनियोजन गर्न आवश्यक पर्दैन।
    // त्यो वास्तविक पोइन्टरले कहिले पनी मान गर्दैन किनभने आरसीबक्समा कम्तिमा २ पign्क्तिबद्ध गरिएको छ।
    // यो मात्र सम्भव छ जब `T: Sized`;असमर्थित `T` कहिल्यै झर्ने छैन।
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// कुनै नयाँ मेमोरी विनियोजन नगरी नयाँ `Weak<T>` निर्माण गर्दछ।
    /// फिर्ता मानमा [`upgrade`] कल गर्दा [`None`] X सँधै दिन्छ।
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// सहयोगी प्रकार डेटा क्षेत्र को बारे मा कुनै assertions बनाएको बिना संदर्भ गणना पहुँच गर्न अनुमति दिन।
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// यस `Weak<T>` द्वारा औंल्याइएको वस्तु `T` मा एक कच्चा सूचक फर्काउँछ।
    ///
    /// सूचक मात्र मान्य हुन्छ यदि त्यहाँ केहि कडा संदर्भहरू छन्।
    /// सूचक dangling, unalign वा [`null`] अन्यथा हुन सक्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // दुबै समान वस्तुलाई औंल्याउँछन्
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // यहाँ बलियोले यसलाई जीवित राख्छ, त्यसैले हामी अझै पनि वस्तु पहुँच गर्न सक्दछौं।
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // तर कुनै होईन।
    /// // हामी weak.as_ptr() गर्न सक्छौं, तर पोइन्टर पहुँच गर्दा अपरिभाषित व्यवहार हुन सक्छ।
    /// // assert_eq! ("हेलो", असुरक्षित {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // यदि सूचक झुकाव छ भने, हामी सीधा पत्र पठाउनेछौं।
            // यो वैध पेलोड ठेगाना हुन सक्दैन, किनकि पेलोड कम्तिमा RcBox (usize) को रूपमा पigned्क्तिबद्ध गरिएको छ।
            ptr as *const T
        } else {
            // सुरक्षा: यदि is_dangling गलत फिर्ता, यदि सूचक dereferencable छ।
            // पेलोड यस बिन्दुमा खसालिन्छ, र हामीले प्रोभेन्सन्स राख्नु पर्छ, त्यसैले कच्चा सूचक हेरफेर प्रयोग गर्नुहोस्।
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// `Weak<T>` खान्छ र यसलाई एक कच्चा सूचकमा बदल्छ।
    ///
    /// यसले कमजोर पोइन्टरलाई एक कच्चा सूचकमा रूपान्तरण गर्दछ, जबकि अझै पनि एक कमजोर सन्दर्भको स्वामित्वको संरक्षण गर्दै (कमजोर गणना यस अपरेशनले परिमार्जन गरिएको छैन)।
    /// यो `Weak<T>` मा [`from_raw`] को साथ फिर्ता बदल्न सकिन्छ।
    ///
    /// [`as_ptr`] को रूपमा सूचकको लक्ष्य पहुँचको समान प्रतिबन्धहरू लागू हुन्छन्।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// [`into_raw`] द्वारा पहिले सिर्जना गरिएको एक कच्चा सूचक `Weak<T>` मा बदल्छ।
    ///
    /// यो सुरक्षित संदर्भ प्राप्त गर्न को लागी प्रयोग गर्न सकिन्छ (पछि [`upgrade`] कल गरेर) वा `Weak<T>` ड्रप गरेर कमजोर गणना Deallocon गर्न।
    ///
    /// यसले एक कमजोर सन्दर्भको स्वामित्व लिन्छ ([`new`] द्वारा सिर्जना गरिएको पोइन्टर्सको अपवाद बाहेक, यीसँग स्वामित्वको केही हुँदैन; विधि अझै पनि तिनीहरूमा काम गर्दछ)।
    ///
    /// # Safety
    ///
    /// सूचक [`into_raw`] बाट उत्पन्न भएको हुनुपर्दछ र अझै पनि यसको सम्भावित कमजोर सन्दर्भको स्वामित्व हुनुपर्दछ।
    ///
    /// यो कल गर्न को लागी कडा गणना गर्न ० लाई अनुमति छ।
    /// जे होस्, यसले हालको कच्चा सूचकको रूपमा प्रतिनिधित्व गरिएको एक कमजोर सन्दर्भको स्वामित्व लिन्छ (कमजोर गणना यस अपरेशनले परिमार्जन गरेको छैन) र त्यसैले यो [`into_raw`] मा अघिल्लो कलको साथ जोडा बनाउनुपर्दछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // अन्तिम कमजोर गणना घटाउनुहोस्।
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // कसरी इनपुट पोइन्टर व्युत्पन्न गरिएको सन्दर्भमा Weak::as_ptr हेर्नुहोस्।

        let ptr = if is_dangling(ptr as *mut T) {
            // यो एक dangling कमजोर छ।
            ptr as *mut RcBox<T>
        } else {
            // अन्यथा, हामी ग्यारेन्टी भयौं सूचक एक nondangling कमजोर बाट आयो।
            // SAFETY: डाटा_अफसेट कल गर्न सुरक्षित छ, किनकि ptr सन्दर्भको रूपमा एक वास्तविक (सम्भावित छोडियो) T।
            let offset = unsafe { data_offset(ptr) };
            // यसैले हामी सम्पूर्ण RcBox प्राप्त गर्न अफसेटलाई उल्टाउछौं।
            // सुरक्षा: सूचक कमजोर बाट उत्पन्न भयो, त्यसैले यो अफसेट सुरक्षित छ।
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // सुरक्षा: हामीले अब मूल कमजोर सूचक पुन: प्राप्त गरेका छौं, त्यसैले कमजोर सिर्जना गर्न सक्दछौं।
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// `Weak` सूचकलाई एक [`Rc`] मा अपग्रेड गर्न प्रयास, यदि सफल भयो भने भित्री मान छोड्दै ढिलाइ हुन्छ।
    ///
    ///
    /// [`None`] फर्काउँछ यदि भित्री मान पछिदेखि छोडियो।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // सबै बलियो सूचकहरू नष्ट गर्नुहोस्।
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// यस विनियोजनमा स poin्केत गर्ने सशक्त (`Rc`) सूचकहरूको संख्या प्राप्त गर्दछ।
    ///
    /// यदि `self` [`Weak::new`] प्रयोग गरी सिर्जना गरिएको हो भने, यसले ० फर्काउँछ।
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// यो आबंटनमा देखाउँदै `Weak` पोइन्टर्सको संख्या पाउछ।
    ///
    /// यदि कुनै मजबूत सूचकहरू बाँकी छैन भने, यो शून्य फिर्ता हुनेछ।
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // निहित कमजोर ptr घटाउनुहोस्
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// `None` फर्काउँछ जब सूचक झुम्झिरहेको हुन्छ र त्यहाँ कुनै विनियोजित `RcBox` छैन, (जस्तै जब यो `Weak` `Weak::new` द्वारा सिर्जना गरिएको हो)।
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // हामी एक्सरेक्सन "data" क्षेत्रलाई कभर गर्ने * * सिर्जना गर्न सावधान छौं, किनकि क्षेत्र सँगसँगै उत्परिवर्तन हुन सक्छ (उदाहरणका लागि, यदि अन्तिम `Rc` खसालियो भने डाटा फिल्डलाई ठाउँमा छोडिनेछ)।
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// `true` फर्काउँछ यदि दुई `Weak`s समान आबंटन ([`ptr::eq`] समान) लाई देखाउँदछ, वा यदि दुबै कुनै पनि आवंटनमा इशारा गर्दैन भने (किनभने तिनीहरू `Weak::new()`) को साथ सिर्जना गरिएको हो।
    ///
    ///
    /// # Notes
    ///
    /// किनकि यसले पोइन्टर्स तुलना गर्दछ यसको मतलब यो हो कि `Weak::new()` एक अर्काको बराबरी हुनेछ, यद्यपि उनीहरूले कुनै पनि विनियोजनमा इशारा गर्दैन।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` तुलना गर्दै।
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` सूचक ड्रप गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // केहि पनि प्रिन्ट गर्दैन
    /// drop(foo);        // "dropped!" प्रिन्ट गर्दछ
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // कमजोर गणना १ बाट सुरु हुन्छ, र शून्यमा मात्र जान्छ यदि सबै शक्तिशाली सूचकहरू हराइसकेका छन्।
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// `Weak` सूचकको क्लोन बनाउँदछ जुन समान आबंटनमा पोइन्ट गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// नयाँ `Weak<T>` निर्माण गर्दछ, `T` का लागि सुरूवात नगरी मेमोरी बाँडफाँड गर्दछ।
    /// फिर्ता मानमा [`upgrade`] कल गर्दा [`None`] X सँधै दिन्छ।
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: हामीले यहाँ mem::forget सुरक्षित रूपमा कारोबार गर्नका लागि जाँच गर्यौं।विशेषत
// यदि तपाईं mem::forget आरसीएस (वा कमजोर), रेफ-काउन्ट ओभरफ्लो हुन सक्छ, र त्यसपछि तपाईं बाँकी आरसीएस (वा कमजोर) अवस्थित हुँदा तपाईं छुट छुट दिन सक्नुहुन्छ।
//
// हामी परित्याग गर्छौं किनकि यो यस्तो पतित परिदृश्य हो कि हामीलाई के हुन्छ भनेर वास्ता हुँदैन-कुनै वास्तविक कार्यक्रमले यो अनुभव गर्नुपर्दैन।
//
// यसको नगण्य ओभरहेड हुनुपर्दछ किनकी तपाईले Rust मा यथार्थ रूपमा क्लोन गर्न आवश्यक पर्दैन स्वामित्व र चाल-अर्थको लागि धन्यवाद।
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // हामी मान छोड्नुको सट्टा ओभरफ्लोमा परित्याग गर्न चाहन्छौं।
        // सन्दर्भ गणना कहिले पनि शून्य हुँदैन जब यो भनिन्छ;
        // जे होस्, हामी यहाँ छुट्ट्याई घुसाउँदछौं LLVM संकेत गर्न अन्यथा छुटेको अनुकूलनमा।
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // हामी मान छोड्नुको सट्टा ओभरफ्लोमा परित्याग गर्न चाहन्छौं।
        // सन्दर्भ गणना कहिले पनि शून्य हुँदैन जब यो भनिन्छ;
        // जे होस्, हामी यहाँ छुट्ट्याई घुसाउँदछौं LLVM संकेत गर्न अन्यथा छुटेको अनुकूलनमा।
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// सूचकको पछिल्लो पेलोडको लागि `RcBox` भित्र अफसेट पाउनुहोस्।
///
/// # Safety
///
/// सूचकले (र वैध मेटाडेटाको लागि) T को पहिलेको वैध उदाहरणलाई सूचित गर्नुपर्दछ, तर T लाई छोड्न अनुमति दिइन्छ।
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // RcBox को अन्त्यमा असुरक्षित मान पign्क्तिबद्ध गर्नुहोस्।
    // किनभने RcBox repr(C) हो, यो मेमोरीमा सधैं अन्तिम फिल्ड हुनेछ।
    // सुरक्षा: किनभने केवल असमर्थित प्रकारहरू स्लाइसहरू, trait वस्तुहरू हुन्,
    // र बाह्य प्रकारहरू, इनपुट सुरक्षा आवश्यकता हाल align_of_val_raw को आवश्यकताहरू पूरा गर्न पर्याप्त छ;यो भाषाको कार्यान्वयन विवरण हो जुन std बाहिरमा भर पर्न सक्दैन।
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}