//! हिप वाटपको लागि एक सूचक प्रकार।
//!
//! [`Box<T>`], आकस्मिक रूपमा एक 'box' को रूपमा संदर्भित, Rust मा हिप वाटपको सरल रूप प्रदान गर्दछ।बक्सहरूले यस बाँडफाँडको लागि स्वामित्व प्रदान गर्दछ, र उनीहरूको सामग्री ड्रप गर्दछ जब उनीहरू कार्यक्षेत्रबाट बाहिर जान्छन्।बक्सहरूले पनि सुनिश्चित गर्दछ कि उनीहरूले कहिल्यै `isize::MAX` बाइट्स भन्दा बढि विनियोजन गरेनन्।
//!
//! # Examples
//!
//! [`Box`] सिर्जना गरेर ढेरबाट ढेरमा मान सार्नुहोस्:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! [dereferencing] बाट स्ट्याकमा [`Box`] बाट मान सार्नुहोस्:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! एक रिकर्सिव डाटा संरचना सिर्जना गर्दै:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! यसले `Cons (१, Cons(2, Nil))`.
//!
//! रिकर्सिभ संरचनाहरू बक्स हुनुपर्दछ, किनकि यदि `Cons` को परिभाषा यस्तो देखिन्थ्यो भने:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! यसले काम गर्दैन।यो किनभने `List` को आकार सूचीमा कति तत्वहरू छन् मा निर्भर गर्दछ, र त्यसैले हामी जान्दैनौं `Cons` को लागी कति मेमोरी छुट्याउने।एक [`Box<T>`] पेश गर्दै, जुन परिभाषित आकार छ, हामी जान्दछौं कति ठूलो `Cons` हुनु पर्छ।
//!
//! # मेमोरी लेआउट
//!
//! गैर-शून्य-आकार मानहरूको लागि, एक [`Box`] यसको [`Global`] आबोधकको उपयोगको लागि यसको प्रयोग गर्दछ।[`Box`] र [`Global`] विनियोजकको साथ छुट्याइएको एक कच्चा सूचक बीच दुबै तरिकाहरू रूपान्तरण गर्न वैध छ, यस प्रकारले कि XT4X प्रकारको लागि सही छ।
//!
//! अधिक स्पष्ट रूपमा, [`Global`] संग [`Global`] आबोलकर्तासँग विनियोजित गरिएको `value: *mut T` [`Box::<T>::from_raw(value)`] प्रयोग गरेर बक्समा रूपान्तरण गर्न सकिन्छ।
//! यसको विपरित, [`Box::<T>::into_raw`] बाट प्राप्त `value:*mut T` लाई समर्थन गर्ने मेमोरीलाई [`Layout::for_value(&* value)`] X सँग [`Global`] आवाश्यककर्ताको प्रयोग गरेर Deallocated गर्न सकिन्छ।
//!
//! शून्य आकारका मानहरूका लागि `Box` सूचक अझै पठन र लेखनका लागि [valid] हुनुपर्दछ र पर्याप्त रूपमा पigned्क्तिबद्ध गरिएको छ।
//! विशेष रूपमा, कच्चा सूचकमा कुनै पigned्क्तिबद्ध गैर-शून्य पूर्णांक कास्टिंगले वैध पोइन्टर उत्पादन गर्दछ, तर एक सूचक अघिल्लो आवंटित मेमोरीमा औंल्याउँछ जुन पछि स्वतन्त्र भयो वैध छैन।
//! एक ZST मा बक्स निर्माण गर्न सिफारिश गरिएको तरिका यदि `Box::new` प्रयोग गर्न सकिएन भने [`ptr::NonNull::dangling`] प्रयोग गर्नु हो।
//!
//! `T: Sized` सम्म यति लामो समय सम्म, `Box<T>` एकल सूचकको रूपमा प्रतिनिधित्व हुन ग्यारेन्टी गरिएको छ र C पॉइन्टरहरू (जस्तै C प्रकार `T*`) सँग ABI-अनुकूल छ।
//! यसको मतलब यो छ कि यदि तपाईंसँग Extern "C" Rust प्रकार्यहरू छन् जुन C बाट कल गरिन्छ, तपाईं ती Rust प्रकार्यहरू `Box<T>` प्रकारहरू प्रयोग गरेर परिभाषित गर्न सक्नुहुनेछ, र `T*` सी पक्षमा सम्बन्धित प्रकारको रूपमा प्रयोग गर्नुहोस्।
//! उदाहरणको रूपमा, यस C हेडरलाई विचार गर्नुहोस् जसले कार्यहरू घोषणा गर्दछ जसले केही प्रकारको `Foo` मान सिर्जना गर्दछ र नष्ट गर्दछ:
//!
//! ```c
//! /* C हेडर */
//!
//! /* कलरमा स्वामित्व फर्काउँछ */
//! struct Foo* foo_new(void);
//!
//! /* कलरबाट स्वामित्व लिन्छ;कुनै अप्ट छैन जब NULL साथ बोलाइयो */
//! void foo_delete(struct Foo*);
//! ```
//!
//! यी दुई प्रकार्यहरू Rust मा निम्नानुसार लागू हुन सक्छ।यहाँ, X बाट `Box<Foo>` प्रकार `Box<Foo>` मा अनुवाद गरिएको छ, जसले स्वामित्व बाधा समेट्छ।
//! यो पनि नोट गर्नुहोस् कि `foo_delete` को nullable आर्गुमेन्ट Rust मा `Option<Box<Foo>>` को रूपमा प्रतिनिधित्व गरीन्छ, किनकि `Box<Foo>` खाली हुन सक्दैन।
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! यद्यपि `Box<T>` को समान प्रतिनिधित्व र C ABI ले एक C सूचकको रूपमा, यसको मतलब यो होइन कि तपाईले अनियन्त्रित `T*` लाई `Box<T>` मा रूपान्तरण गर्न सक्नुहुनेछ र चीजहरूले काम गर्न अपेक्षा गर्नुहुनेछ।
//! `Box<T>` मानहरू सँधै पूर्ण रूपमा प al्क्तिबद्ध हुनेछ, नन-नल पोइन्टर्स।यसबाहेक, `Box<T>` को लागि डिस्ट्रक्टरले विश्वव्यापी आवाश्यककर्तासँग मान खाली गर्न प्रयास गर्नेछ।सामान्यतया, सबै भन्दा राम्रो अभ्यास भनेको केवल `Box<T>` केवल पोइन्टर्स को लागी प्रयोग गर्नु हो जुन वैश्विक आवाश्यककर्ताबाट उत्पन्न भएको हो।
//!
//! **महत्त्वपूर्ण।** कम्तिमा वर्तमानमा तपाईले `Box<T>` प्रकारहरू प्रकारका लागि प्रयोग गर्नु हुँदैन जुन C मा परिभाषित हो तर Rust बाट बोलाइएको छ।ती अवस्थाहरूमा तपाईले सी प्रकारको सीधा मिरर गर्नुहोस् जतिसक्दो चाँडो।
//! `Box<T>` जस्ता प्रकारहरू प्रयोग गरेर जहाँ C परिभाषा मात्र `T*` प्रयोग गरिरहेको छ अपरिभाषित व्यवहारमा डोर्‍याउन सक्छ, [rust-lang/unsafe-code-guidelines#198][ucg#198] मा वर्णन गरिए अनुसार।
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// हिप वाटपको लागि एक सूचक प्रकार।
///
/// अधिकको लागि [module-level documentation](../../std/boxed/index.html) हेर्नुहोस्।
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// हिपमा मेमोरी आवंटित गर्दछ र त्यसपछि यसमा `x` राख्छ।
    ///
    /// यो वास्तवमा छुट्याउँदैन यदि `T` शून्य आकारको छ।
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// इनिटिटलाइज्ड सामग्रीको साथ नयाँ बक्स निर्माण गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // स्थगित आरम्भ:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// `0` बाइट्सको साथ मेमोरी भरिएको साथ, ईनिटिटलाइज गरिएको सामग्रीको साथ नयाँ `Box` निर्माण गर्दछ।
    ///
    ///
    /// यस विधिको सही र गलत प्रयोगको उदाहरणका लागि [`MaybeUninit::zeroed`][zeroed] हेर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// नयाँ `Pin<Box<T>>` निर्माण गर्दछ।
    /// यदि `T` `Unpin` कार्यान्वयन गर्दैन, तब `x` मेमोरीमा पिन हुनेछ र सर्न असक्षम भयो।
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// हिपमा मेमोरी आवंटित गर्दछ त्यसपछि `x` लाई यसमा राख्दछ, यदि त्रुटि विनियोजन असफल भयो भने एक त्रुटि फिर्ता गर्दै
    ///
    ///
    /// यो वास्तवमा छुट्याउँदैन यदि `T` शून्य आकारको छ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// हिपमा अनावश्यक सामग्रीको साथ नयाँ बक्स निर्माण गर्दछ, यदि त्रुटि विनियोजन असफल भयो भने एक त्रुटि फिर्ता गर्दै
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // स्थगित आरम्भ:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// एक्निटाइलाइज गरिएको सामग्रीका साथ नयाँ `Box` निर्माण गर्दछ, स्मृतिको साथ हीपमा `0` बाइट्स भरिएको
    ///
    ///
    /// यस विधिको सही र गलत प्रयोगको उदाहरणका लागि [`MaybeUninit::zeroed`][zeroed] हेर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// दिईएको आब्रोटरमा मेमोरी आवंटित गर्दछ र त्यसपछि `x` राख्छ।
    ///
    /// यो वास्तवमा छुट्याउँदैन यदि `T` शून्य आकारको छ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// दिईएको आब्रोटरमा मेमोरी आवंटित गर्दछ त्यसपछि `x` लाई यसमा राख्दछ, यदि त्रुटि असफल भएमा त्रुटि फिर्ता गर्दै
    ///
    ///
    /// यो वास्तवमा छुट्याउँदैन यदि `T` शून्य आकारको छ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// प्रदान वितरकमा ईन्निटिटलाइज्ड सामग्रीको साथ नयाँ बक्स निर्माण गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // स्थगित आरम्भ:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Unwrap_or_else मा मिलान मन पर्छ जब कहिलेकाँही इनलाइन योग्य हुँदैन।
        // त्यो कोड आकार ठूलो बनाउँछ।
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// प्रदान गरिएको विनियोजकमा अनावश्यक सामग्रीको साथ नयाँ बक्स निर्माण गर्दछ, यदि त्रुटि विनियोजन असफल भयो भने त्रुटि फिर्ता गर्दै
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // स्थगित आरम्भ:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// एक नया `Box` निर्विवाद सामग्रीको साथ निर्माण गर्दछ, मेमोरी प्रदान गरिएको आलोकमा `0` बाइट्सले भरिएको छ।
    ///
    ///
    /// यस विधिको सही र गलत प्रयोगको उदाहरणका लागि [`MaybeUninit::zeroed`][zeroed] हेर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Unwrap_or_else मा मिलान मन पर्छ जब कहिलेकाँही इनलाइन योग्य हुँदैन।
        // त्यो कोड आकार ठूलो बनाउँछ।
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// प्रदान नगरवस्तुकर्तामा `0` बाइट्स भरिएको मेमोरीको साथ, XT1X बाइट्सले भरिएको भइरहेको स्मृतिको साथमा नयाँ `Box` निर्माण गर्दछ, यदि त्रुटि असफल भएमा त्रुटि फिर्ता गर्दै,
    ///
    ///
    /// यस विधिको सही र गलत प्रयोगको उदाहरणका लागि [`MaybeUninit::zeroed`][zeroed] हेर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// नयाँ `Pin<Box<T, A>>` निर्माण गर्दछ।
    /// यदि `T` `Unpin` कार्यान्वयन गर्दैन, तब `x` मेमोरीमा पिन हुनेछ र सर्न असक्षम भयो।
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// `Box<T>` लाई `Box<[T]>` मा बदल्छ
    ///
    /// यो रूपान्तरण को थुप्रो मा आवंटित छैन र ठाउँमा हुन्छ।
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// `Box` खपत, आवरण मान फिर्ता।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// एक नया बक्सा स्लाइस निर्बोधात्मक सामग्रीको साथ निर्माण गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // स्थगित आरम्भ:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// `0` बाइट्सको साथ मेमोरी भरिएकोले, ईन्निटिटलाइज्ड सामग्रीको साथ नयाँ बाकस स्लाइस निर्माण गर्दछ।
    ///
    ///
    /// यस विधिको सही र गलत प्रयोगको उदाहरणका लागि [`MaybeUninit::zeroed`][zeroed] हेर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// प्रदान गरिएको विनियोजकमा अनावश्यक सामग्रीको साथ नयाँ बाकस स्लाइस निर्माण गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // स्थगित आरम्भ:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// `0` बाइट्सको साथ मेमोरी भरीएकोले, प्रदान गरिएको आबیلوकर्तामा अनावश्यक सामग्रीको साथ नयाँ बक्सि sl स्लाइस निर्माण गर्दछ।
    ///
    ///
    /// यस विधिको सही र गलत प्रयोगको उदाहरणका लागि [`MaybeUninit::zeroed`][zeroed] हेर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// `Box<T, A>` मा रूपान्तरण गर्दछ।
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] को रूपमा, यो कलरमा निर्भर हुन्छ कि ग्यारेन्टी गर्न कि मान वास्तवमा सुरुमा रहेको अवस्थामा छ।
    ///
    /// यो कलिंग गर्दा जब सामग्री अझै पूर्ण रूपमै आरम्भ गरिएको छैन तत्काल अपरिभाषित व्यवहारको कारण गर्दछ।
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // स्थगित आरम्भ:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// `Box<[T], A>` मा रूपान्तरण गर्दछ।
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] को रूपमा, यो कलरमा निर्भर छ कि ग्यारेन्टी गर्न को लागि मानहरू वास्तवमै एक सुरूवात अवस्थामा छन्।
    ///
    /// यो कलिंग गर्दा जब सामग्री अझै पूर्ण रूपमै आरम्भ गरिएको छैन तत्काल अपरिभाषित व्यवहारको कारण गर्दछ।
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // स्थगित आरम्भ:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// एउटा कच्चा सूचकबाट बक्स बनाउँछ।
    ///
    /// यो प्रकार्य कल गरेपछि, कच्चा सूचक परिणाम `Box` X को स्वामित्वमा छ।
    /// विशेष रूपमा, `Box` विध्वंसकले `T` को विनाशक कल गर्दछ र आवंटित मेमोरी खाली गर्दछ।
    /// यो सुरक्षित हुनको लागि, मेमोरी `Box` द्वारा प्रयोग गरिएको [memory layout] अनुसार अनुरूप वितरण गरिएको हुनुपर्दछ।
    ///
    ///
    /// # Safety
    ///
    /// यो प्रकार्य असुरक्षित हो किनभने अनुचित प्रयोगले मेमोरी समस्या निम्त्याउन सक्छ।
    /// उदाहरण को लागी, यदि एक ही कच्चा सूचक मा समारोह दुई पटक बोलाइएको छ भने एक डबल फ्री हुन सक्छ।
    ///
    /// सुरक्षा सर्तहरू [memory layout] सेक्सनमा वर्णन गरिएको छ।
    ///
    /// # Examples
    ///
    /// एक `Box` पुन: निर्माण गर्नुहोस् जुन पहिले कच्चा सूचकमा [`Box::into_raw`] प्रयोग गरेर रूपान्तरण गरिएको थियो:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// म्यानुअल रूपमा एक `Box` सिर्जना गर्नुहोस् स्क्र्याचबाट ग्लोबल आवाश्यककर्ताको प्रयोग गरेर:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // सामान्यतया .write लाई `ptr` को (uninitialized) अघिल्लो सामग्री बिगार्न प्रयास गर्नबाट जोगिन आवश्यक छ, यद्यपि यस साधारण उदाहरणको लागि `*ptr = 5` ले पनि काम गरेको हुन्थ्यो।
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// दिईएको वितरकमा एक कच्चा सूचकबाट बक्स बनाउँछ।
    ///
    /// यो प्रकार्य कल गरेपछि, कच्चा सूचक परिणाम `Box` X को स्वामित्वमा छ।
    /// विशेष रूपमा, `Box` विध्वंसकले `T` को विनाशक कल गर्दछ र आवंटित मेमोरी खाली गर्दछ।
    /// यो सुरक्षित हुनको लागि, मेमोरी `Box` द्वारा प्रयोग गरिएको [memory layout] अनुसार अनुरूप वितरण गरिएको हुनुपर्दछ।
    ///
    ///
    /// # Safety
    ///
    /// यो प्रकार्य असुरक्षित हो किनभने अनुचित प्रयोगले मेमोरी समस्या निम्त्याउन सक्छ।
    /// उदाहरण को लागी, यदि एक ही कच्चा सूचक मा समारोह दुई पटक बोलाइएको छ भने एक डबल फ्री हुन सक्छ।
    ///
    /// # Examples
    ///
    /// एक `Box` पुन: निर्माण गर्नुहोस् जुन पहिले कच्चा सूचकमा [`Box::into_raw_with_allocator`] प्रयोग गरेर रूपान्तरण गरिएको थियो:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// म्यानुअल रूपमा प्रणाली आबेलकर्ताको प्रयोग गरेर स्क्र्याचबाट `Box` सिर्जना गर्नुहोस्:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // सामान्यतया .write लाई `ptr` को (uninitialized) अघिल्लो सामग्री बिगार्न प्रयास गर्नबाट जोगिन आवश्यक छ, यद्यपि यस साधारण उदाहरणको लागि `*ptr = 5` ले पनि काम गरेको हुन्थ्यो।
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// `Box` खान्छ, एक आवरण कच्चा सूचक फिर्ता।
    ///
    /// सूचक ठीक रूपमा पigned्क्तिबद्ध हुनेछ र नल।
    ///
    /// यस प्रकार्य कल गरिसकेपछि कलर `Box` द्वारा प्रबन्धित मेमोरीको लागि जिम्मेवार छ।
    /// विशेष रूपमा कलरले `T` लाई ठीकसँग नष्ट गर्नुपर्दछ र `Box` द्वारा प्रयोग गरिएको [memory layout] लाई ध्यानमा राख्दै मेमोरी रिलीज गर्नुपर्छ।
    /// यसको गर्न सजिलो तरीका भनेको कच्चा स poin्केतकलाई `Box` X मा फिर्ता [`Box::from_raw`] प्रकार्यमा रूपान्तरण गर्नु हो, `Box` विध्वंसकलाई सफाई प्रदर्शन गर्न अनुमति दिदै।
    ///
    ///
    /// Note: यो एक सम्बन्धित समारोह हो, जसको मतलब यो हुन्छ कि तपाईंले X001 को सट्टा `Box::into_raw(b)` भन्नु पर्छ।
    /// यो यस्तो छ कि भित्री प्रकारमा विधिको कुनै विवाद छैन।
    ///
    /// # Examples
    /// स्वचालित सफा अपको लागि [`Box::from_raw`] को साथ कच्चा सूचक फेरि `Box` मा रूपान्तरण गर्दै:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// म्यानुअल सफाई स्पष्ट रूपमा डिस्ट्रक्टर चलाएर र मेमोरीलाई डेलोकेट गरेर:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// `Box` खान्छ, एक र्याप गरिएको कच्चा सूचक र आबद्धकर्ता फिर्ता गर्दछ।
    ///
    /// सूचक ठीक रूपमा पigned्क्तिबद्ध हुनेछ र नल।
    ///
    /// यस प्रकार्य कल गरिसकेपछि कलर `Box` द्वारा प्रबन्धित मेमोरीको लागि जिम्मेवार छ।
    /// विशेष रूपमा कलरले `T` लाई ठीकसँग नष्ट गर्नुपर्दछ र `Box` द्वारा प्रयोग गरिएको [memory layout] लाई ध्यानमा राख्दै मेमोरी रिलीज गर्नुपर्छ।
    /// यसको गर्न सजिलो तरीका भनेको कच्चा स poin्केतकलाई `Box` X मा फिर्ता [`Box::from_raw_in`] प्रकार्यमा रूपान्तरण गर्नु हो, `Box` विध्वंसकलाई सफाई प्रदर्शन गर्न अनुमति दिदै।
    ///
    ///
    /// Note: यो एक सम्बन्धित समारोह हो, जसको मतलब यो हुन्छ कि तपाईंले X001 को सट्टा `Box::into_raw_with_allocator(b)` भन्नु पर्छ।
    /// यो यस्तो छ कि भित्री प्रकारमा विधिको कुनै विवाद छैन।
    ///
    /// # Examples
    /// स्वचालित सफा अपको लागि [`Box::from_raw_in`] को साथ कच्चा सूचक फेरि `Box` मा रूपान्तरण गर्दै:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// म्यानुअल सफाई स्पष्ट रूपमा डिस्ट्रक्टर चलाएर र मेमोरीलाई डेलोकेट गरेर:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // बाकस "unique pointer" को रूपमा स्ट्याक्ड बोर्न्स द्वारा मान्यता प्राप्त छ, तर आन्तरिक रूपमा यो प्रकार प्रणालीको लागि कच्चा सूचक हो।
        // यसलाई सिधा एक कच्चा सूचकमा परिणत गर्ने "releasing" को रूपमा मान्यता प्राप्त हुँदैन अलाइज्ड कच्चा पहुँचहरूको अनुमति दिन अद्वितीय सूचक, त्यसैले सबै कच्चा सूचक विधिहरू `Box::leak` मार्फत जानु पर्छ।
        //
        // टर्न गर्दै *कि* एक कच्चा सूचक सही व्यवहार गर्दछ।
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// अन्तर्निहित आबद्धकर्तालाई सन्दर्भ फर्काउँछ।
    ///
    /// Note: यो एक सम्बन्धित समारोह हो, जसको मतलब यो हुन्छ कि तपाईंले X001 को सट्टा `Box::allocator(&b)` भन्नु पर्छ।
    /// यो यस्तो छ कि भित्री प्रकारमा विधिको कुनै विवाद छैन।
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// `Box` उपभोग र लीक, एक परिवर्तनीय सन्दर्भ फिर्ता, `&'a mut T`.
    /// नोट गर्नुहोस् कि `T` प्रकारले चुनिएको जीवनकाल `'a` लाई बहिष्कृत गर्नु पर्छ।
    /// यदि प्रकारसँग केवल स्थिर सन्दर्भहरू छन्, वा कुनै पनि त्यस्तो छैन, भने यो `'static` हुन रोज्न सकिन्छ।
    ///
    /// यो प्रकार्य डाटाको लागि उपयोगी छ जुन प्रोग्रामको बाँकी जीवनको लागि जिउँछ।
    /// फर्काइएको सन्दर्भ छोड्दा मेमोरी चुहावट हुन्छ।
    /// यदि यो स्वीकार्य छैन भने, सन्दर्भ पहिलो [`Box::from_raw`] प्रकार्य `Box` उत्पादनको साथ लपेट्नु पर्छ।
    ///
    /// यस `Box` लाई पछि झार्न सकिन्छ जुन `T` लाई ठीक नष्ट गर्दछ र बाँडिएको मेमोरी जारी गर्दछ।
    ///
    /// Note: यो एक सम्बन्धित समारोह हो, जसको मतलब यो हुन्छ कि तपाईंले X001 को सट्टा `Box::leak(b)` भन्नु पर्छ।
    /// यो यस्तो छ कि भित्री प्रकारमा विधिको कुनै विवाद छैन।
    ///
    /// # Examples
    ///
    /// साधारण प्रयोग:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// आकार नगरिएको डाटा:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// `Box<T>` लाई `Pin<Box<T>>` मा बदल्छ
    ///
    /// यो रूपान्तरण को थुप्रो मा आवंटित छैन र ठाउँमा हुन्छ।
    ///
    /// यो [`From`] मार्फत पनि उपलब्ध छ।
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // `Pin<Box<T>>` को भित्रपट्टि सार्न वा प्रतिस्थापन गर्न सम्भव छैन जब `T: !Unpin`, त्यसैले यसलाई कुनै अतिरिक्त आवश्यकता बिना सीधा पिन गर्न सुरक्षित हुन्छ।
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: केहि नगर्नुहोस्, ड्रप हाल कम्पाइलर द्वारा प्रदर्शन गरिएको छ।
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// T को लागी `Default` मानको साथ `Box<T>` सिर्जना गर्दछ।
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// यस बक्सको सामग्रीको `clone()` को साथ नयाँ बक्स फर्काउँछ।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // मान उस्तै छ
    /// assert_eq!(x, y);
    ///
    /// // तर ती अद्वितीय वस्तुहरू हुन्
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // क्लोन गरिएको मान सीधा लेख्न अनुमति दिन पूर्व-बाँडफाड मेमोरी।
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// प्रतिलिपि `स्रोत` को सामग्रीहरू `self` मा नयाँ विनियोजन सिर्जना नगरी।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // मान उस्तै छ
    /// assert_eq!(x, y);
    ///
    /// // र कुनै विनियोजन भएको छैन
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // यसले डाटाको प्रतिलिपि बनाउँदछ
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// जेनेरिक प्रकार `T` लाई `Box<T>` मा बदल्छ
    ///
    /// रूपान्तरण हिपमा आवंटित हुन्छ र यसमा स्ट्याकबाट `t` सार्दछ।
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// `Box<T>` लाई `Pin<Box<T>>` मा बदल्छ
    ///
    /// यो रूपान्तरण को थुप्रो मा आवंटित छैन र ठाउँमा हुन्छ।
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// `&[T]` लाई `Box<[T]>` मा बदल्छ
    ///
    /// यो रूपान्तरण हिपमा आबंटित गर्दछ र `slice` को प्रतिलिपि गर्दछ।
    ///
    /// # Examples
    ///
    /// ```rust
    /// // एउटा&[u8] सिर्जना गर्नुहोस् जुन बक्स <[u8]> सिर्जना गर्न प्रयोग हुनेछ
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// `&str` लाई `Box<str>` मा बदल्छ
    ///
    /// यो रूपान्तरण हिपमा आबंटित गर्दछ र `s` को प्रतिलिपि गर्दछ।
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// `Box<str>` लाई `Box<[u8]>` मा बदल्छ
    /// यो रूपान्तरण को थुप्रो मा आवंटित छैन र ठाउँमा हुन्छ।
    ///
    /// # Examples
    ///
    /// ```rust
    /// // एउटा बाकस सिर्जना गर्नुहोस्<str>जुन बक्स <[u8]> सिर्जना गर्न प्रयोग गरिने छ
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // एउटा&[u8] सिर्जना गर्नुहोस् जुन बक्स <[u8]> सिर्जना गर्न प्रयोग हुनेछ
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// `[T; N]` लाई `Box<[T]>` मा बदल्छ
    /// यस रूपान्तरणले एर्रेलाई नयाँ हेप-आवंटित मेमोरीमा सार्छ।
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// कंक्रीट प्रकारमा बक्स डाउनकास्ट गर्न प्रयास गर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// कंक्रीट प्रकारमा बक्स डाउनकास्ट गर्न प्रयास गर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// कंक्रीट प्रकारमा बक्स डाउनकास्ट गर्न प्रयास गर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // भित्री युनिकलाई सिधा बाकसबाट निकाल्न सम्भव छैन, बरु हामी यसलाई * कन्स्टमा राख्छौं जुन अद्वितीय उपनाम दिन्छ।
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// आकार `I`s का लागि विशेषज्ञता जसले `last()` को कार्यान्वयन प्रयोग गर्दछ पूर्वनिर्धारितको सट्टा।
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}