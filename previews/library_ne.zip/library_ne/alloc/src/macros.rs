/// [`Vec`] X आर्गुमेन्टहरू समावेश गर्दछ।
///
/// `vec!` `Vec`s लाई समान सिन्ट्याक्सको साथ एरे अभिव्यक्तिको रूपमा परिभाषित गर्न अनुमति दिन्छ।
/// यस म्याक्रोको दुई प्रकारहरू छन्:
///
/// - तत्वहरूको सूची दिइएको [`Vec`] सिर्जना गर्नुहोस्:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - दिइएको तत्व र आकारबाट [`Vec`] सिर्जना गर्नुहोस्:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// नोट गर्नुहोस् कि एरे अभिव्यक्तिहरूको विपरीत यो वाक्यविन्यासले सबै तत्वहरूलाई समर्थन गर्दछ जसले [`Clone`] कार्यान्वयन गर्दछ र तत्वहरूको संख्या स्थिर हुँदैन।
///
/// यसले `clone` लाई अभिव्यक्ति नक्कल गर्न प्रयोग गर्दछ, त्यसैले एक यसको एक सावधानी अपनाउनु पर्दछ नानस्ट्यान्डर्ड `Clone` कार्यान्वयनको प्रकारको साथ।
/// उदाहरण को लागी, `vec![Rc::new(1);]] `एक समान बक्साइएको पूर्णांक मानमा पाँच सन्दर्भहरूको vector सिर्जना गर्दछ, स्वतन्त्र रूपमा बाकस पूर्णांकलाई दर्साउने पाँच सन्दर्भ होईन।
///
///
/// साथै, नोट गर्नुहोस् कि `vec![expr; 0]` लाई अनुमति छ, र खाली vector उत्पादन गर्दछ।
/// यसले अझै पनि `expr` को मूल्या will्कन गर्दछ, र तुरून्त परिणाम परिणाम ड्रप गर्दछ, त्यसैले साइड इफेक्ट को बारे मा सावधान रहनुहोस्।
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): cfg(test) सँग अन्तर्निहित `[T]::into_vec` विधि, जुन यो म्याक्रो परिभाषाको लागि आवश्यक छ, उपलब्ध छैन।
// यसको सट्टा `slice::into_vec` प्रकार्य प्रयोग गर्नुहोस् जुन cfg(test) NB को साथ मात्र उपलब्ध छ अधिक जानकारीको लागि slice.rs मा slice::hack मोड्युल हेर्नुहोस्।
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// रनटाइम अभिव्यक्तिहरूको इन्टरपोलेसन प्रयोग गरी `String` सिर्जना गर्दछ।
///
/// पहिलो आर्गुमेन्ट `format!` एक ढाँचा स्ट्रि is हो।यो स्ट्रि lite शाब्दिक हुनुपर्दछ।ढाँचा स्ट्रि ofको पावर contained {} `s सम्मिलित छ।
///
/// `format!` मा पारित अतिरिक्त प्यारामिटरहरू नाम वा स्थितिगत प्यारामिटरहरू प्रयोग नगरेसम्म दिइएको क्रममा ढाँचा स्ट्रि within भित्र `{}` s प्रतिस्थापन गर्दछ;अधिक जानकारीको लागि [`std::fmt`] हेर्नुहोस्।
///
///
/// `format!` को लागी एक साधारण प्रयोग कaten्कटेन्टेसन र स्ट्रि interको रोकिनु हो।
/// उही कन्भेन्सन [`print!`] र [`write!`] म्याक्रोको साथ प्रयोग गरिएको छ, स्ट्रि theको अभिप्रेत गन्तव्यमा निर्भर गर्दै।
///
/// एकल मानलाई स्ट्रि toमा रूपान्तरण गर्न, [`to_string`] विधि प्रयोग गर्नुहोस्।यसले [`Display`] ढाँचा trait प्रयोग गर्दछ।
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics यदि ढाँचा trait कार्यान्वयनमा त्रुटि फर्काउँछ।
/// यो गलत कार्यान्वयन स indicates्केत गर्दछ किनकि `fmt::Write for String` ले कहिले त्रुटि त्रुटि फिर्ता गर्दैन।
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// ढाँचा स्थितिमा डायग्नोस्टिक्स सुधार गर्न अभिव्यक्तिको लागि AST नोडलाई बल गर्नुहोस्।
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}