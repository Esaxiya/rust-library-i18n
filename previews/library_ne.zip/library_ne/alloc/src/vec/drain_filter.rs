use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// एक पुनरावृत्तिकर्ताले कुनै तत्व हटाउनु पर्छ कि निर्धारित गर्न क्लोजर प्रयोग गर्दछ।
///
/// यो संरचना [`Vec::drain_filter`] द्वारा बनाईएको हो।
/// अधिकको लागि यसको कागजात हेर्नुहोस्।
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// `next` मा अर्को कल द्वारा निरीक्षण गरिने वस्तुको अनुक्रमणिका।
    pub(super) idx: usize,
    /// (removed) निकास गरिएको आईटमहरूको संख्या अहिलेसम्म।
    pub(super) del: usize,
    /// `vec` को मूल लम्बाई पानी निकासी अघि।
    pub(super) old_len: usize,
    /// फिल्टर परीक्षण पूर्वानुमान।
    pub(super) pred: F,
    /// panic संकेत गर्ने झण्डा फिल्टर परीक्षण पूर्वानुमानमा देखा पर्‍यो।
    /// यो `DrainFilter` को शेष को खपत रोक्न ड्रप कार्यान्वयन मा एक संकेत को रूप मा प्रयोग गरीन्छ।
    /// कुनै पनि असीमित वस्तुहरू `vec` मा बैकशिफ्ट हुनेछ, तर कुनै अन्य वस्तुहरू ड्रप वा फिल्टर प्रेिकेट द्वारा परीक्षण गरिने छैन।
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// अन्तर्निहित आबद्धकर्तालाई सन्दर्भ फर्काउँछ।
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // अनुक्रमणिका *अद्यावधिक गर्नुहोस्* पछि प्रेडिक्ट भनिन्छ।
                // यदि अनुक्रमणिका पहिले अपडेट गरिएको छ र पूर्वानुमान panics, यो सूचकांकमा तत्व चुहावट हुनेछ।
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // यो एक राम्रो गडबड राज्य हो, र त्यहाँ वास्तव मा स्पष्ट गर्न सही कुरा छैन।
                        // हामी `pred` कार्यान्वयन गर्न को लागी जारी राख्न चाहँदैनौं, त्यसैले हामी केवल सबै असुरक्षित तत्वहरूको समर्थन गर्छौं र भेक्टरलाई भन्छौं कि तिनीहरू अझै अवस्थित छन्।
                        //
                        // ब्याकशिफ्ट प्रेडिकेटमा panic भन्दा पहिले अन्तिम सफलतापूर्वक निस्केको वस्तुको डबल ड्रप रोक्नको लागि आवश्यक छ।
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // कुनै पनि बाँकी तत्त्वहरू खपत गर्ने प्रयास गर्नुहोस् यदि फिल्टर प्रेडिकेट अझै प्यानक भएको छैन।
        // हामी कुनै पनि बाँकी रहेका तत्वहरूलाई ब्याकशिफ्ट गर्नेछौं कि हामी पहिले नै आतंकित छौं वा खपत यहाँ panics।
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}