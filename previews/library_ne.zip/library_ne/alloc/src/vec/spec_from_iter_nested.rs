use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// Vec::from_iter को लागी अर्को विशेषज्ञता trait म्यानुअल रूपमा ओभरल्यापि special विशेषज्ञता प्राथमिकता आवश्यक [`SpecFromIter`](super::SpecFromIter) विवरणका लागि।
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // पहिलो पुनरावृत्ति अनरोल गर्नुहोस्, किनकि vector हरेक पुनरावृत्तिमा यस पुनरावृत्तिमा विस्तार हुने छ जब पुनरावृत्तिक खाली छैन, तर extend_desugared() मा लुप vector केही पछिल्लो लूप पुनरावृत्तिका भरि भइरहेको देख्दैन।
        //
        // त्यसैले हामी अझ राम्रो branch भविष्यवाणी प्राप्त।
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // spec_extend() लाई प्रतिनिधित्व गर्नुपर्दछ extend() आफैले खाली Vecs को लागि spec_from लाई प्रतिनिधि गर्नुहोस्
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // spec_extend() लाई प्रतिनिधित्व गर्नुपर्दछ extend() आफैले खाली Vecs को लागि spec_from लाई प्रतिनिधि गर्नुहोस्
        //
        vector.spec_extend(iterator);
        vector
    }
}