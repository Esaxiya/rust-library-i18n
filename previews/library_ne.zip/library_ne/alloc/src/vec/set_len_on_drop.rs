// `SetLenOnDrop` मान दायरा बाहिर गयो जब भेसको लम्बाई सेट गर्नुहोस्।
//
// विचार यो हो: सेटलेनओनड्रपमा लम्बाइ फिल्ड एक स्थानीय चल हो जुन अप्टिमाइजरले देख्नेछ भेकको डाटा पोइन्टर मार्फत कुनै पनि स्टोरहरूसँग उपनाम हुँदैन।
// यो उपनाम विश्लेषण मुद्दा #32155 को लागी एक कार्य हो
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}