use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// स्रोत एलोकसनको पुन: प्रयोग गर्दा एक Vec मा एक इट्रेटर पाइपलाइन संकलनको लागि विशेषज्ञता मार्कर
/// ठाउँमा पाइपलाइन कार्यान्वयन गर्दै।
///
/// SourceIter अभिभावक trait विशेष उपयोग समारोह को लागी विनियोजन को उपयोग गर्न को लागी आवश्यक छ जुन पुन: प्रयोग गर्नु पर्छ।
/// तर यो मान्यताको लागि मान्य छैन।
/// इम्प्लीमा अतिरिक्त सीमा हेर्नुहोस्।
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-आन्तरिक SourceIter/InPlaceIterable traits केवल एडाप्टरको चेन द्वारा कार्यान्वयन गरिएको छ <Adapter<Adapter<IntoIter>>> (सबै core/std द्वारा स्वामित्व गरिएको)।
// एडेप्टर कार्यान्वयनमा अतिरिक्त सीमाहरू (`impl<I: Trait> Trait for Adapter<I>` बाहिर) केवल अन्य traits मा निर्भर गर्दछ जुन पहिले नै विशेषज्ञता traits (प्रतिलिपि, ट्रस्टर्डरन्डोम एक्सेस, FusedIterator) को रूपमा चिन्ह लगाइएको छ।
//
// I.e. मार्कर प्रयोगकर्ता द्वारा आपूर्ति को प्रकार को जीवनकाल मा निर्भर गर्दैन।Modulo प्रतिलिपि प्वाल, जुन अन्य धेरै विशेषज्ञताहरू पहिले नै निर्भर छन्।
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // अतिरिक्त आवश्यकताहरू जुन trait bounds मार्फत व्यक्त गर्न सकिदैन।हामी यसको सट्टा कन्स्टल ईभालमा निर्भर छौं:
        // क) कुनै जेडएसटी छैन किनकि त्यहाँ पुन: प्रयोगको लागि कुनै बाँडफाँड हुँदैन र सूचक अंकगणित panic ख) आकार मिलान एलोक सम्झौताको आधारमा आवश्यक हुनेछ सी) पign्क्तिबद्ध मेल एलोक सम्झौताको आवश्यकता अनुसार
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // अधिक सामान्य कार्यान्वयन गर्न फलब्याक
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // देखि प्रयास गुना प्रयोग गर्नुहोस्
        // - केहि ईट्रेटर एडेप्टरको लागि यसले राम्रोसँग भेक्टरोर्इज गर्दछ
        // - अधिकांश आन्तरिक पुनरावृत्ति विधिहरूको विपरीत, यसले मात्र &mut स्व लिन्छ
        // - यसले हामीलाई यसको इन्डोरको माध्यमबाट लेख सूचक थ्रेड गर्न दिन्छ र अन्त्यमा यसलाई फिर्ता लिन दिन्छ
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // पुनरावृत्ति सफल भयो, टाउको छोड्नुहोस्
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // SourceIter अनुबंध यदि चेतावनी राखिएको हो कि भनेर जाँच गर्नुहोस्: यदि तिनीहरू नभई हामी यसलाई यो बिन्दुमा पुग्न पनि सक्दैनौं
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // InPlaceIteable अनुबंध जाँच गर्नुहोस्।यो मात्र सम्भव छ यदि इटरेटरले स्रोत सूचक बिल्कुल उन्नत गरे।
        // यदि यो ट्रस्टेड रान्डमएक्सेस मार्फत जाँच नगरिएको पहुँच प्रयोग गर्दछ भने स्रोत सूचक यसको प्रारम्भिक स्थितिमा रहनेछ र हामी यसलाई सन्दर्भको रूपमा प्रयोग गर्न सक्दैनौं।
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // स्रोतको पुच्छरमा कुनै पनि बाँकी मानहरू छोड्नुहोस् तर एकपटक आन्ट्रोइटर दायराबाट बाहिर जान्छ भने यसको बाँडफाँडको ड्रप रोक्दछ यदि panics ड्रप गर्छ भने हामी पनि dst_buf मा संकलित कुनै पनि तत्व चुहावट गर्छौं।
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // InPlaceIteable अनुबंध यहाँ ठ्याक्कै रुजू गर्न सकिदैन किनकि try_fold को स्रोत पोईन्टरमा एक विशेष सन्दर्भ छ हामीले गर्न सक्ने सबै यकिन छ कि यो अझै दायरामा छ कि छैन भनेर जाँच गर्न सक्दछौं।
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}