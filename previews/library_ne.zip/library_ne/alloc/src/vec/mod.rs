//! हेप-विनियोजित सामग्रीको साथ लिखित `Vec<T>` सँग मिल्दो बढ्न योग्य एरे प्रकार।
//!
//! Vectors सँग `O(1)` अनुक्रमणिका, Amorised `O(1)` पुश (अन्तमा) र `O(1)` पप (अन्तबाट) छ।
//!
//!
//! Vectors ले `isize::MAX` X बाइट भन्दा बढि कहिले पनि बाँडफाँड गर्दैनन्।
//!
//! # Examples
//!
//! तपाइँ स्पष्ट रूपमा [`Vec::new`] को साथ [`Vec`] सिर्जना गर्न सक्नुहुन्छ:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... वा [`vec!`] म्याक्रो प्रयोग गरेर:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // दस शून्य
//! ```
//!
//! तपाईं [`push`] मानहरू vector को अन्तमा गर्न सक्नुहुनेछ (जुन vector आवश्यकता अनुसार बढ्नेछ):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! पपिंग मानहरूले धेरै त्यहि रूपमा काम गर्दछ:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors ले अनुक्रमणिकालाई समर्थन गर्दछ ([`Index`] र [`IndexMut`] traits मार्फत):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// एक मिल्दो बढ्न योग्य एरे प्रकार, `Vec<T>` का रूपमा लेखिएको र 'vector'।
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// [`vec!`] म्याक्रो इनिसियलाइसनलाई अधिक सुविधाजनक बनाउन प्रदान गरिएको छ:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// यो पनि एक `Vec<T>` को प्रत्येक तत्व दिए गए मानको साथ आरम्भ गर्न सक्दछ।
/// यो अलग चरणहरूमा आवंटन र आरम्भिकरण प्रदर्शन भन्दा अझ बढी सक्षम हुन सक्छ, विशेष गरी जब Zeros को vector आरम्भमा:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // तल बराबर हो, तर सम्भावित ढिलो:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// अधिक जानकारीको लागि, [Capacity and Reallocation](#capacity-and-reallocation) हेर्नुहोस्।
///
/// एक कुशल स्ट्याकको रूपमा `Vec<T>` प्रयोग गर्नुहोस्:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // प्रिन्ट 3, 2, १
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// `Vec` प्रकारले अनुक्रमणिकाद्वारा मानहरू पहुँच गर्न अनुमति दिन्छ, किनकि यसले [`Index`] trait लागू गर्दछ।एक उदाहरण अधिक स्पष्ट हुनेछ:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // यसले '2' प्रदर्शन गर्दछ
/// ```
///
/// यद्यपि सावधान रहनुहोस्: यदि तपाईं एक सूचकांक पहुँच गर्न प्रयास गर्नुहोस् जुन `Vec` मा छैन भने, तपाईंको सफ्टवेयर panic हुनेछ!तपाईं यो गर्न सक्नुहुन्न:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// [`get`] र [`get_mut`] प्रयोग गर्नुहोस् यदि तपाईं सूचकांक `Vec` मा छ कि छैन जाँच गर्न चाहानुहुन्छ।
///
/// # Slicing
///
/// एक `Vec` बदलाव गर्न सकिन्छ।अर्कोतर्फ, स्लाइसहरू केवल पढ्ने वस्तुहरू हुन्।
/// एक [slice][prim@slice] प्राप्त गर्न, [`&`] प्रयोग गर्नुहोस्।उदाहरण:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... र त्यो मात्र हो!
/// // तपाईं यसलाई यो पनि गर्न सक्नुहुन्छ:
/// let u: &[usize] = &v;
/// // वा यो जस्तै:
/// let u: &[_] = &v;
/// ```
///
/// Rust मा, vectors को सट्टा तर्कहरूको रूपमा स्लाइसहरू पार गर्न सामान्य छ जब तपाईं केवल पढ्ने पहुँच प्रदान गर्न चाहानुहुन्छ।[`String`] र [`&str`] को लागि पनि त्यस्तै हुन्छ।
///
/// # क्षमता र पुन: स्थान
///
/// एक vector को क्षमता vector मा थपिने छ कि कुनै future तत्वहरु को लागी छुट्याइएको ठाउँ को राशि हो।यो vector को *लम्बाई* संग भ्रमित गर्नु हुँदैन, जसले vector भित्र वास्तविक तत्वहरूको संख्या निर्दिष्ट गर्दछ।
/// यदि vector को लम्बाईले यसको क्षमता भन्दा बढि छ भने, यसको क्षमता स्वत: बढाइनेछ, तर यसको तत्त्वहरू पुनः गणना गर्नुपर्नेछ।
///
/// उदाहरणका लागि, क्षमता १० र लम्बाई ० भएको vector १० थप तत्वहरूको लागि खाली vector हुनेछ।१० वा कम तत्त्वहरूलाई vector मा पुश गर्नाले यसको क्षमता परिवर्तन गर्दैन वा पुन: स्थान परिवर्तनको कारण हुँदैन।
/// जहाँसम्म, यदि vector को लम्बाई ११ मा बढाइयो भने, यो पुनः केन्द्रित गर्नु पर्छ, जुन ढिलो हुन सक्छ।यस कारणका लागि, यो [`Vec::with_capacity`] प्रयोग गर्न सिफारिस गरिन्छ जब संभव हुन्छ vector प्राप्त हुने अपेक्षा गरिएको ठूलो निर्दिष्ट गर्न।
///
/// # Guarantees
///
/// यसको अविश्वसनीय मौलिक प्रकृतिको कारण, `Vec` ले यसको डिजाइनको बारेमा धेरै ग्यारेन्टीहरू बनाउँछ।यसले सुनिश्चित गर्दछ कि यो सामान्य केसमा सकेसम्म कम ओभरहेड हो, र असुरक्षित कोडद्वारा ठीक तरिकाले आदिम तरिकामा हेरफेर गर्न सकिन्छ।नोट गर्नुहोस् कि यी ग्यारेन्टीहरूले एक अयोग्य `Vec<T>` लाई जनाउँछ।
/// यदि अतिरिक्त प्रकारका प्यारामिटरहरू थपिएका छन् (उदाहरणका लागि, अनुकूलन सहयोगीहरूलाई समर्थन गर्न), तिनीहरूका पूर्वनिर्धारितहरूलाई ओभरराइड गर्दा व्यवहार परिवर्तन गर्न सक्दछ।
///
/// धेरै मौलिक, `Vec` हो र सँधै (सूचक, क्षमता, लम्बाई) ट्रिपलेट हुनेछ।कुनै अधिक, कम छैन।यी क्षेत्रहरूको क्रम पूर्ण रूपमा अनिर्दिष्ट छ, र तपाईं तिनीहरूलाई परिमार्जन गर्न उचित विधिहरूको प्रयोग गर्नुपर्दछ।
/// सूचक कहिल्यै नल हुँदैन, त्यसैले यो प्रकार शून्य-सूचक-अनुकूलित छ।
///
/// यद्यपि सूचकले वास्तवमा विनियोजित मेमोरीमा स not्केत गर्दैन।
/// विशेष रूपमा, यदि तपाइँ [`Vec::new`] लाई [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], वा खाली Vec मा [`shrink_to_fit`] कल गरेर `Vec` निर्माण गर्नुहुन्छ भने, यसले मेमोरी बाँडफाँड गर्दैन।त्यस्तै, यदि तपाइँ `Vec` भित्र शून्य आकारका प्रकारहरू भण्डार गर्नुहुन्छ, यसले तिनीहरूका लागि ठाउँ बाँडफाँड गर्दैन।
/// *नोट गर्नुहोस् कि यस अवस्थामा `Vec` ले ०* को [`capacity`] रिपोर्ट गर्न सक्दैन।
/// `Vec` यदि र मात्र `[` mem: : आकार_of::<T>`]` () * capacity()> ०`।
/// सामान्यतया, `भेकाको आबंटन विवरण एकदम सूक्ष्म हुन्छ-यदि तपाईं `Vec` को प्रयोग गरेर मेमोरी बाँडफाँड गर्ने इच्छा गर्नुहुन्छ र यसलाई अरू केहि प्रयोगको लागि (या त असुरक्षित कोडमा पास गर्न, वा तपाईंको आफ्नै मेमोरी-ब्याक्ड संग्रह निर्माण गर्न) निश्चित हुनुहोस्। `from_raw_parts` पुन: प्राप्ति गर्न `from_raw_parts` प्रयोग गरेर र यसलाई छोड्दा यस मेमोरीलाई असमर्थ बनाउँनुहोस्।
///
/// यदि `Vec`*लाई* आबंटित मेमोरी छ भने, त्यसपछि यसले दर्शाएको मेमोरी हिपमा छ (आवंटक Rust द्वारा परिभाषित रूपमा पूर्वनिर्धारित रूपमा प्रयोग गर्नको लागि कन्फिगर गरिएको छ), र यसको सूचक [`len`] इनिसियलाइज्ड, कन्फिगुलुअल एलिमेन्ट्स क्रममा पोइन्ट गर्दछ (तपाईं के गर्नुहुन्छ हेर्नुहोस् यदि तपाईंले यसलाई स्लाइसमा जोड गर्नुभयो), [`क्षमता`]`,`[`len`] तार्किक रूपमा निर्विवाद, मिल्दो तत्त्वहरूको पछि लाग्नुहोस्।
///
///
/// एक vector तत्वहरू `'a'` र `'b'` क्षमता 4 को साथ तल देख्न सकिन्छ।शीर्ष भाग `Vec` संरचना हो, यसले हिप, लम्बाई र क्षमतामा बाँडफाँडको टाउकोमा सूचक समावेश गर्दछ।
/// तलको अंश हिपमा विनियोजन हो, एक मिल्दो मेमोरी ब्लक।
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **अननिट** मेमोरी प्रतिनिधित्व गर्दछ जुन आरम्भ गरिएको छैन, [`MaybeUninit`] हेर्नुहोस्।
/// - Note: ABI स्थिर छैन र `Vec` यसको मेमोरी लेआउटको बारेमा कुनै ग्यारेन्टी गर्दैन (फिल्डको अर्डर सहित)।
///
/// `Vec` कहिले पनि "small optimization" प्रदर्शन गर्दैन जहाँ तत्वहरू स्ट्याकमा दुई कारणका लागि वास्तवमा भण्डारण गरिन्छ:
///
/// * असुरक्षित कोडको लागि `Vec` लाई ठीकसँग प्रयोग गर्न यसले अझ गाह्रो बनाउँदछ।`Vec` को सामग्रीहरूको एक स्थिर ठेगाना हुँदैन यदि यसलाई मात्र सारियो भने, र यो पत्ता लगाउन अझ गाह्रो हुन्छ कि यदि `Vec` वास्तवमै मेमोरी विनियोजित गरेको थियो भने।
///
/// * यसले सामान्य केसलाई दण्ड दिइनेछ, प्रत्येक पहुँचमा अतिरिक्त branch सहित।
///
/// `Vec` पूर्ण रूपले खाली भए पनि स्वत: सँधै कहिले पनि सink्क्रमित हुँदैन।यो सुनिश्चित गर्दछ कि कुनै अनावश्यक विनियोजन वा deallocations देखा पर्दैन।एक `Vec` खाली गरेर र फेरि उही [`len`] भर्न भरिएलाइ कल गरिएको छैन।यदि तपाईं प्रयोग नभएको मेमोरी खाली गर्न चाहनुहुन्छ भने, [`shrink_to_fit`] वा [`shrink_to`] प्रयोग गर्नुहोस्।
///
/// [`push`] र [`insert`] कहिले पनि पुन: वितरण हुँदैन यदि रिपोर्ट गरिएको क्षमता पर्याप्त छ।[`push`] र [`insert`]* *(पुनः) आवंटित हुनेछ यदि [`len`]`==`[`क्षमता`]।त्यो हो, रिपोर्ट गरिएको क्षमता पूर्ण रूपमा सहि छ, र भर पर्न सकिन्छ।यो म्यानुअली म्यानुअली `Vec` द्वारा विनियोजित मेमोरी खाली गर्न प्रयोग गर्न सकिन्छ यदि चाहियो भने।
/// थोक सम्मिलन विधि *आवश्यक* नभए पनि पुन: सम्बोधन गर्न सक्दछ।
///
/// `Vec` पूर्ण भएको बेलामा पुन: निर्धारण गर्दा कुनै विशेष वृद्धि रणनीतिको ग्यारेन्टी गर्दैन, न त जब [`reserve`] कल गरिन्छ।हालको रणनीति आधारभूत छ र यो एक स्थिर र लगातार विकास कारक प्रयोग गर्न योग्य साबित हुन सक्छ।जे पनि रणनीति प्रयोग गरीन्छ निश्चित रूपमा ग्यारेन्टी *O*(१) परिमार्जित [`push`]।
///
/// `vec![x; n]`, `vec![a, b, c, d]`, र [`Vec::with_capacity(n)`][`Vec::with_capacity`], सबै ठीक अनुरोध गरिएको क्षमता संग एक `Vec` उत्पादन गर्दछ।
/// यदि [`len`]`==`[`क्षमता`], ([`vec!`] म्याक्रोको लागि जस्तो हो), तब एक `Vec<T>` लाई रूपान्तरण गर्न सकिन्छ र [`Box<[T]>`][owned slice] बाट तत्व पुन: निर्धारण वा सार्न बिना।
///
/// `Vec` यसबाट हटाइएको कुनै पनि डाटालाई विशेष रूपमा अधिलेखन गर्दैन, तर विशेष रूपमा यसलाई सुरक्षित गर्दैन।यसको इनिटिटलाइज गरिएको मेमोरी स्क्र्याच स्पेस हो जुन यसले चाहिन सक्छ प्रयोग गर्न सक्दछ।यो सामान्यतया मात्र जे सबै भन्दा कुशल वा कार्यान्वयन गर्न सजिलो गर्न को लागी गर्छ।सुरक्षा उद्देश्यको लागि मेटाउनका लागि हटाइएको डाटामा भरोसा नगर्नुहोस्।
/// यदि तपाईंले `Vec` ड्रप गर्नुभयो भने, यसको बफरलाई अर्को `Vec` द्वारा पुन: प्रयोग गर्न सकिन्छ।
/// यदि तपाईं पहिले `Vec` को मेमोरी शून्य गर्नुहुन्छ भने, त्यो वास्तवमै हुन सक्दैन किनकि अप्टिमाइजरले यसलाई एक साइड-प्रभावको रूपमा लिदैन जुन सुरक्षित गर्नुपर्दछ।
/// त्यहाँ एक केस छ जुन हामी भाँच्ने छैनौं, यद्यपि: अधिक क्षमतामा लेख्न `unsafe` कोड प्रयोग गरेर, र त्यसपछि लम्बाइ बढाउँदा, सधैं वैध हुन्छ।
///
/// हाल `Vec` X ले आदेशहरू ग्यारेन्टी गर्दैन जसमा तत्वहरू खसालिन्छन्।
/// अर्डर विगतमा परिवर्तन भएको छ र फेरि परिवर्तन हुन सक्छ।
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// स्वाभाविक विधिहरू
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// नयाँ, खाली `Vec<T>` निर्माण गर्दछ।
    ///
    /// vector ले विनियोजन गर्दैन जब सम्म त्यसमा तत्वहरू धकेला हुँदैन।
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// निर्दिष्ट क्षमताको साथ नयाँ, खाली `Vec<T>` निर्माण गर्दछ।
    ///
    /// vector reallocating बिना ठीक `capacity` तत्व समाउन सक्षम हुनेछ।
    /// यदि `capacity` 0 हो, vector आवंटित हुँदैन।
    ///
    /// यो याद गर्नु महत्त्वपूर्ण छ कि फिर्ता vector को *क्षमता* निर्दिष्ट गरिएको छ, vector को एक शून्य *लम्बाई* हुनेछ।
    ///
    /// लम्बाई र क्षमता बीचको भिन्नताको विवरणको लागि, हेर्नुहोस् [क्षमता र पुन: स्थान] *।
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector ले कुनै आईटमहरू समावेश गर्दैन, यद्यपि यससँग अधिक क्षमता छ
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // यी सबै पुन: निर्धारण बिना नै गरिएका छन् ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... तर यसले vector पुन: सम्बोधन गर्न सक्दछ
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// अर्को vector को कच्चा कम्पोनेन्टबाट सिधा `Vec<T>` सिर्जना गर्दछ।
    ///
    /// # Safety
    ///
    /// यो अत्यधिक असुरक्षित छ, परीक्षकहरूको संख्याको कारण जाँच गरिएन:
    ///
    /// * `ptr` पहिले [`String`]/`Vec मार्फत विनियोजन गर्नु पर्छ<T>`(कम्तिमा पनि, यो गलत हुन सक्दछ यदि यो गलत थिएन भने)।
    /// * `T` `ptr` सँग आवंटित गरिएको जस्तै समान साइज र प .्क्तिबद्धता हुनु पर्छ।
    ///   (`T` कम कडा प al्क्तिबद्धता पर्याप्त छैन, पign्क्तिबद्धता [`dealloc`] आवश्यकता पूरा गर्न बराबर हुनु आवश्यक छ जुन मेमोरी आवाश्यक हुनुपर्दछ र उही लेआउटको साथ deallocated हुनु पर्छ।)
    ///
    /// * `length` `capacity` भन्दा कम वा बराबरको हुनु आवश्यक छ।
    /// * `capacity` पोइन्टर विनियोजन गरिएको क्षमता हुनु आवश्यक छ।
    ///
    /// यीलाई उल्ल .्घन गर्नाले समस्याहरू उत्पन्न गर्दछ आवाबको आन्तरिक डेटा संरचनाहरू भ्रष्ट पार्ने जस्ताउदाहरण को लागी यो **होईन** एक `Vec<u8>` निर्माण गर्न सुरक्षित छ सूचकबाट C `char` एरेमा लम्बाई `size_t` को साथ।
    /// यो एक `Vec<u16>` र यसको लम्बाई बाट एक निर्माण गर्न पनि सुरक्षित छैन, किनभने आवंटकले पign्क्तिबद्धको बारे ख्याल राख्दछ, र यी दुई प्रकारका बिभिन्न पign्क्तिबद्धताहरू छन्।
    /// बफर पign्क्तिबद्धता २ (`u16` को लागी) को साथ विनियोजित गरिएको थियो, तर यसलाई `Vec<u8>` मा परिणत गरे पछि यो पign्क्तिबद्धता १ सँग विलम्बित हुनेछ।
    ///
    /// `ptr` को स्वामित्व `Vec<T>` लाई प्रभावी रूपमा स्थानान्तरण गरियो जुन त्यसपछि इच्छाशक्तिले सूचकको आधारमा देखाइएको मेमोरीको सामग्रीहरू Deallocon गर्न, पुन: सम्बोधन गर्न वा परिवर्तन गर्न सक्दछ।
    /// निश्चित गर्नुहोस् कि अरू कुनै कुराले यो प्रकार्य कल गरेपछि सूचक प्रयोग गर्दैन।
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME यसलाई अपडेट गर्नुहोस् जब vec_into_raw_parts स्थिर हुन्छ।
    ///     // Running v` डिस्ट्र्याक्टर चलाउन रोक्नुहोस् त्यसैले हामी विनियोजनको पूर्ण नियन्त्रणमा हुन्छौं।
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // `v` को बारेमा जानकारीको विभिन्न महत्त्वपूर्ण टुक्राहरू तान्नुहोस्
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // ,,,, With को साथ मेमोरी ओभरराइट गर्नुहोस्
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // फेरि सबै एक Vec मा एक साथ राख्नुहोस्
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// नयाँ, खाली `Vec<T, A>` निर्माण गर्दछ।
    ///
    /// vector ले विनियोजन गर्दैन जब सम्म त्यसमा तत्वहरू धकेला हुँदैन।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// प्रदान गरिएको विनियोजकको साथ निर्दिष्ट क्षमताको साथ नयाँ, खाली `Vec<T, A>` निर्माण गर्दछ।
    ///
    /// vector reallocating बिना ठीक `capacity` तत्व समाउन सक्षम हुनेछ।
    /// यदि `capacity` 0 हो, vector आवंटित हुँदैन।
    ///
    /// यो याद गर्नु महत्त्वपूर्ण छ कि फिर्ता vector को *क्षमता* निर्दिष्ट गरिएको छ, vector को एक शून्य *लम्बाई* हुनेछ।
    ///
    /// लम्बाई र क्षमता बीचको भिन्नताको विवरणको लागि, हेर्नुहोस् [क्षमता र पुन: स्थान] *।
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector ले कुनै आईटमहरू समावेश गर्दैन, यद्यपि यससँग अधिक क्षमता छ
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // यी सबै पुन: निर्धारण बिना नै गरिएका छन् ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... तर यसले vector पुन: सम्बोधन गर्न सक्दछ
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// अर्को vector को कच्चा कम्पोनेन्टबाट सिधा `Vec<T, A>` सिर्जना गर्दछ।
    ///
    /// # Safety
    ///
    /// यो अत्यधिक असुरक्षित छ, परीक्षकहरूको संख्याको कारण जाँच गरिएन:
    ///
    /// * `ptr` पहिले [`String`]/`Vec मार्फत विनियोजन गर्नु पर्छ<T>`(कम्तिमा पनि, यो गलत हुन सक्दछ यदि यो गलत थिएन भने)।
    /// * `T` `ptr` सँग आवंटित गरिएको जस्तै समान साइज र प .्क्तिबद्धता हुनु पर्छ।
    ///   (`T` कम कडा प al्क्तिबद्धता पर्याप्त छैन, पign्क्तिबद्धता [`dealloc`] आवश्यकता पूरा गर्न बराबर हुनु आवश्यक छ जुन मेमोरी आवाश्यक हुनुपर्दछ र उही लेआउटको साथ deallocated हुनु पर्छ।)
    ///
    /// * `length` `capacity` भन्दा कम वा बराबरको हुनु आवश्यक छ।
    /// * `capacity` पोइन्टर विनियोजन गरिएको क्षमता हुनु आवश्यक छ।
    ///
    /// यीलाई उल्ल .्घन गर्नाले समस्याहरू उत्पन्न गर्दछ आवाबको आन्तरिक डेटा संरचनाहरू भ्रष्ट पार्ने जस्ताउदाहरण को लागी यो **होईन** एक `Vec<u8>` निर्माण गर्न सुरक्षित छ सूचकबाट C `char` एरेमा लम्बाई `size_t` को साथ।
    /// यो एक `Vec<u16>` र यसको लम्बाई बाट एक निर्माण गर्न पनि सुरक्षित छैन, किनभने आवंटकले पign्क्तिबद्धको बारे ख्याल राख्दछ, र यी दुई प्रकारका बिभिन्न पign्क्तिबद्धताहरू छन्।
    /// बफर पign्क्तिबद्धता २ (`u16` को लागी) को साथ विनियोजित गरिएको थियो, तर यसलाई `Vec<u8>` मा परिणत गरे पछि यो पign्क्तिबद्धता १ सँग विलम्बित हुनेछ।
    ///
    /// `ptr` को स्वामित्व `Vec<T>` लाई प्रभावी रूपमा स्थानान्तरण गरियो जुन त्यसपछि इच्छाशक्तिले सूचकको आधारमा देखाइएको मेमोरीको सामग्रीहरू Deallocon गर्न, पुन: सम्बोधन गर्न वा परिवर्तन गर्न सक्दछ।
    /// निश्चित गर्नुहोस् कि अरू कुनै कुराले यो प्रकार्य कल गरेपछि सूचक प्रयोग गर्दैन।
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME यसलाई अपडेट गर्नुहोस् जब vec_into_raw_parts स्थिर हुन्छ।
    ///     // Running v` डिस्ट्र्याक्टर चलाउन रोक्नुहोस् त्यसैले हामी विनियोजनको पूर्ण नियन्त्रणमा हुन्छौं।
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // `v` को बारेमा जानकारीको विभिन्न महत्त्वपूर्ण टुक्राहरू तान्नुहोस्
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // ,,,, With को साथ मेमोरी ओभरराइट गर्नुहोस्
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // फेरि सबै एक Vec मा एक साथ राख्नुहोस्
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// XsX यसको कच्चा घटकहरूमा विघटित गर्दछ।
    ///
    /// अन्तर्निहित डेटा, vector को लम्बाई (तत्वहरूमा), र डाटाको विनियोजित क्षमता (तत्वहरूमा) फर्काउँछ।
    /// [`from_raw_parts`] मा आर्गुमेन्टहरू समान क्रममा यी समान तर्कहरू हुन्।
    ///
    /// यस प्रकार्य कल गरिसकेपछि कलर `Vec` द्वारा प्रबन्धित मेमोरीको लागि जिम्मेवार छ।
    /// यसको लागि एक मात्र तरीका भनेको कच्चा स poin्केतक, लम्बाई, र क्षमतालाई `Vec` X मा फिर्ता [`from_raw_parts`] प्रकार्यमा रूपान्तरण गर्नु हो, विध्वंसकलाई सफाई प्रदर्शन गर्न अनुमति दिदै।
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // अब हामी कम्पोनेन्टहरूमा परिवर्तन गर्न सक्दछौं, जस्तै कच्चा सूचकलाई मिल्दो प्रकारमा ट्रान्समिट गर्न।
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// XsX यसको कच्चा घटकहरूमा विघटित गर्दछ।
    ///
    /// अन्तर्निहित डेटा, vector को लम्बाई (तत्वहरूमा), डाटाको विनियोजित क्षमता (तत्वहरूमा), र वितरकमा कच्चा सूचक फर्काउँछ।
    /// [`from_raw_parts_in`] मा आर्गुमेन्टहरू समान क्रममा यी समान तर्कहरू हुन्।
    ///
    /// यस प्रकार्य कल गरिसकेपछि कलर `Vec` द्वारा प्रबन्धित मेमोरीको लागि जिम्मेवार छ।
    /// यसको लागि एक मात्र तरीका भनेको कच्चा स poin्केतक, लम्बाई, र क्षमतालाई `Vec` X मा फिर्ता [`from_raw_parts_in`] प्रकार्यमा रूपान्तरण गर्नु हो, विध्वंसकलाई सफाई प्रदर्शन गर्न अनुमति दिदै।
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // अब हामी कम्पोनेन्टहरूमा परिवर्तन गर्न सक्दछौं, जस्तै कच्चा सूचकलाई मिल्दो प्रकारमा ट्रान्समिट गर्न।
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// vector पुन: प्रदर्शन नगरी समाउन सक्ने तत्वहरूको संख्या फर्काउँछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// कम्तिमा `additional` अधिक तत्वहरू सम्मिलित `Vec<T>` सम्मिलित गर्न क्षमता सुरक्षित गर्दछ।
    /// संग्रहले लगातार रिकलोकेशन्सबाट बच्न अधिक ठाउँ आरक्षित गर्न सक्दछ।
    /// `reserve` कल गरेपछि, क्षमता `self.len() + additional` भन्दा बढि वा बराबर हुनेछ।
    /// केहि गर्दैन यदि क्षमता पहिले नै पर्याप्त छ।
    ///
    /// # Panics
    ///
    /// Panics यदि नयाँ क्षमता `isize::MAX` बाइट भन्दा अधिक छ।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// ठीक `additional` अधिक तत्वहरूको लागि दिइएको `Vec<T>` सम्मिलित गर्न न्यूनतम क्षमता आरक्षित गर्दछ।
    ///
    /// `reserve_exact` कल गरेपछि, क्षमता `self.len() + additional` भन्दा बढि वा बराबर हुनेछ।
    /// केहि गर्दैन यदि क्षमता पहिले नै पर्याप्त छ।
    ///
    /// नोट गर्नुहोस् कि विनियोजकले संग्रहले अनुरोध भन्दा बढी ठाउँ दिन सक्छ।
    /// तसर्थ, क्षमता एकदम न्यूनतम हुन भर पर्न सक्दैन।
    /// `reserve` प्राथमिकता दिनुहोस् यदि future सम्मिलनहरू अपेक्षित छन्।
    ///
    /// # Panics
    ///
    /// Panics यदि नयाँ क्षमता `usize` ओभरफ्लो भयो।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// कम्तिमा `additional` थप तत्वहरू सम्मिलित `Vec<T>` सम्मिलित गर्न क्षमता रिजर्भ गर्न प्रयास गर्दछ।
    /// संग्रहले लगातार रिकलोकेशन्सबाट बच्न अधिक ठाउँ आरक्षित गर्न सक्दछ।
    /// `try_reserve` कल गरेपछि, क्षमता `self.len() + additional` भन्दा बढि वा बराबर हुनेछ।
    /// केहि गर्दैन यदि क्षमता पहिले नै पर्याप्त छ।
    ///
    /// # Errors
    ///
    /// यदि क्षमता ओभरफ्लो भयो, वा विनियोजकले एक विफलता रिपोर्ट गरे, तब एउटा त्रुटि फर्किन्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // मेमोरी प्रि-रिजर्भ गर्नुहोस्, यदि हामी सक्दैनौं भने बाहिर निस्कँदै
    ///     output.try_reserve(data.len())?;
    ///
    ///     // अब हामी जान्दछौं कि यो OOM हाम्रो जटिल कामको बिचमा गर्न सक्दैन
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // धेरै जटिल
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// ठीक `additional` एलिमेन्टहरूलाई `Vec<T>` सम्मिलित गर्नका लागि न्यूनतम क्षमता आरक्षित गर्न कोसिस गर्दछ।
    /// `try_reserve_exact` कल गरेपछि क्षमता `self.len() + additional` भन्दा बढि वा बराबर हुनेछ यदि यसले `Ok(())` फर्काउँछ।
    ///
    /// केहि गर्दैन यदि क्षमता पहिले नै पर्याप्त छ।
    ///
    /// नोट गर्नुहोस् कि विनियोजकले संग्रहले अनुरोध भन्दा बढी ठाउँ दिन सक्छ।
    /// तसर्थ, क्षमता एकदम न्यूनतम हुन भर पर्न सक्दैन।
    /// `reserve` प्राथमिकता दिनुहोस् यदि future सम्मिलनहरू अपेक्षित छन्।
    ///
    /// # Errors
    ///
    /// यदि क्षमता ओभरफ्लो भयो, वा विनियोजकले एक विफलता रिपोर्ट गरे, तब एउटा त्रुटि फर्किन्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // मेमोरी प्रि-रिजर्भ गर्नुहोस्, यदि हामी सक्दैनौं भने बाहिर निस्कँदै
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // अब हामी जान्दछौं कि यो OOM हाम्रो जटिल कामको बिचमा गर्न सक्दैन
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // धेरै जटिल
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// सकेसम्म vector को क्षमता संकुचन गर्दछ।
    ///
    /// यो सकेसम्म लम्बाइमा झर्नेछ तर विस्तारकर्ताले अझै vector लाई सूचित गर्न सक्दछ कि केहि थप तत्वहरूको लागि खाली ठाउँ छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // क्षमता कहिले पनि लम्बाई भन्दा कम हुँदैन, र त्यहाँ केहि छैन जब गर्न को लागी केहि हुँदैन, त्यसैले हामी `RawVec::shrink_to_fit` मा panic केस त्याग्न सक्दछौं मात्र यसलाई अधिक क्षमताको साथ कल गरेर।
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// तल्लो सीमाको साथ vector को क्षमता संकुचन गर्दछ।
    ///
    /// क्षमता कम्तिमा दुबै लम्बाई र आपूर्ति गरिएको मानको रूपमा ठूलो रहनेछ।
    ///
    ///
    /// यदि हालको क्षमता तल्लो सीमा भन्दा कम छ भने, यो एक अप-अप हो।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// vector लाई [`Box<[T]>`][owned slice] मा रूपान्तरण गर्दछ।
    ///
    /// नोट गर्नुहोस् कि यसले कुनै पनि अधिक क्षमता छोड्नेछ।
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// कुनै अधिक क्षमता हटाईयो:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// vector लाई छोटो पार्छ, पहिलो `len` एलिमेन्टहरू राख्दै र बाँकी छोड्दै।
    ///
    /// यदि `len` vector को वर्तमान लम्बाई भन्दा ठूलो छ भने, यसले कुनै प्रभाव पार्दैन।
    ///
    /// [`drain`] विधिले `truncate` अनुकरण गर्न सक्दछ, तर थप तत्त्वहरू छोड्नुको सट्टा फिर्ताको कारण गर्दछ।
    ///
    ///
    /// नोट गर्नुहोस् कि यस विधिले vector को आवंटित क्षमतामा कुनै प्रभाव पार्दैन।
    ///
    /// # Examples
    ///
    /// पाँच तत्व vector दुई तत्वहरूमा छाँटदै:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// जब कुनै `len` vector को वर्तमान लम्बाई भन्दा ठूलो छ कुनै काटिएको हुँदैन:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// ट्रन्केटिंग जब `len == 0` [`clear`] विधि कल गर्न बराबर छ।
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // यो सुरक्षित छ किनकि:
        //
        // * `drop_in_place` मा पारित स्लाइस मान्य छ;`len > self.len` केसले अवैध स्लाइस सिर्जना गर्नबाट बचाउँछ, र
        // * vector को `len` `drop_in_place` कल गर्नु अघि संकुचन गरिएको छ, कि `drop_in_place` एक पटक panic मा गएमा कुनै पनि मान दुई पटक झारिनेछैन (यदि यो panics दुई पटक भयो भने, कार्यक्रम अवरूद्ध हुन्छ)।
        //
        //
        //
        unsafe {
            // Note: यो जानाजानी हो कि यो `>` हो `>=` होईन।
            //       यसलाई `>=` मा परिवर्तन गर्दा केहि केसहरूमा नकारात्मक प्रदर्शन प्रभाव पर्छ।
            //       अधिकको लागि #78884 हेर्नुहोस्।
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// सम्पूर्ण vector समावेश भएको एउटा टुक्रा निकाल्छ।
    ///
    /// `&s[..]` को बराबरी।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// सम्पूर्ण vector को म्यूटेबल स्लाइस निकाल्छ।
    ///
    /// `&mut s[..]` को बराबरी।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// vector को बफरमा एक कच्चा सूचक फर्काउँछ।
    ///
    /// कलरले सुनिश्चित गर्नु पर्छ कि vector पोइन्टरलाई outlives यो प्रकार्य फर्काउँछ, वा अन्यथा यो फोहोरमा देखाउँदै समाप्त हुन्छ।
    /// vector परिमार्जन गर्नाले यसको बफरलाई पुन: स्थानबद्ध गर्न सक्दछ, जसले यसले कुनै पनि पोइन्टर्सलाई अमान्य बनाउँदछ।
    ///
    /// कलरले यो पनि सुनिश्चित गर्नुपर्दछ कि पोइन्टर (non-transitively) पोइन्टमा जुन मेमोरी कहिल्यै लेखिएको छैन (`UnsafeCell` भित्र बाहेक) यो पोइन्टर वा यसबाट व्युत्पन्न कुनै सूचक प्रयोग गरेर।
    /// यदि तपाईंलाई स्लाइसको सामग्रीहरू परिवर्तन गर्न आवश्यक छ भने, [`as_mut_ptr`] प्रयोग गर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // हामी `deref` मार्फत जानबाट रोक्नको लागि उही नामको स्लाइस विधिलाई छायाँ दिन्छौं, जसले एक मध्यवर्ती संदर्भ सिर्जना गर्दछ।
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// vector को बफरमा एक असुरक्षित म्यूटेबल पोइन्टर फर्काउँछ।
    ///
    /// कलरले सुनिश्चित गर्नु पर्छ कि vector पोइन्टरलाई outlives यो प्रकार्य फर्काउँछ, वा अन्यथा यो फोहोरमा देखाउँदै समाप्त हुन्छ।
    ///
    /// vector परिमार्जन गर्नाले यसको बफरलाई पुन: स्थानबद्ध गर्न सक्दछ, जसले यसले कुनै पनि पोइन्टर्सलाई अमान्य बनाउँदछ।
    ///
    /// # Examples
    ///
    /// ```
    /// // 4 तत्वहरूको लागि पर्याप्त vector आवंटित गर्नुहोस्।
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // कच्चा सूचक लेखेर मार्फत तत्त्वहरू सुरूवात गर्नुहोस्, त्यसपछि लम्बाई सेट गर्नुहोस्।
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // हामी `deref_mut` मार्फत जानबाट रोक्नको लागि उही नामको स्लाइस विधिलाई छायाँ दिन्छौं, जसले एक मध्यवर्ती संदर्भ सिर्जना गर्दछ।
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// अन्तर्निहित आबद्धकर्तालाई सन्दर्भ फर्काउँछ।
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// vector को लम्बाईलाई `new_len` मा जोड दिन्छ।
    ///
    /// यो एक तल्लो स्तरको अपरेशन हो जुन प्रकारको सामान्य आक्रमणकर्ताहरू मध्ये कुनै एकलाई कायम राख्दैन।
    /// सामान्यतया vector को लम्बाइ बदल्नुको सट्टा सुरक्षित अपरेशन्सको प्रयोग गरेर गरिन्छ, जस्तै [`truncate`], [`resize`], [`extend`], वा [`clear`]।
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` [`capacity()`] भन्दा कम वा बराबर हुनुपर्छ।
    /// - `old_len..new_len` मा एलिमेन्ट शुरुवात हुनुपर्दछ।
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// यो विधि परिस्थितिहरूको लागि उपयोगी हुन सक्दछ जहाँ vector अन्य कोडका लागि बफरको रूपमा सेवा गर्दछ, विशेष गरी FFI माथि:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // यो कागजात उदाहरण को लागी एक न्यूनतम कंकाल हो;
    /// # // यो वास्तविक लाइब्रेरीको लागि सुरूवात बिन्दुको रूपमा प्रयोग नगर्नुहोस्।
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // FFI विधिको कागजातहरूमा, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // सुरक्षा: जब `deflateGetDictionary` `Z_OK` फिर्ता, यो पकड:
    ///     // 1. `dict_length` तत्वहरू आरम्भ गरिएको थियो।
    ///     // 2.
    ///     // `dict_length` <=क्षमता (32_768) जसले `set_len` कल गर्न सुरक्षित गर्दछ।
    ///     unsafe {
    ///         // FFI कल गर्नुहोस् ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... र शुरूआत गरिएकोमा लम्बाइ अपडेट गर्नुहोस्।
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// जबकि निम्न उदाहरण ध्वनि छ, त्यहाँ एक मेमोरी लीक छ किनकि भित्री vectors `set_len` कल भन्दा पहिले स्वतन्त्र गरिएको थिएन:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` खाली छ त्यसैले कुनै पनि तत्वहरू सुरूवात गर्न आवश्यक पर्दैन।
    /// // 2. `0 <= capacity` जहिले पनि `capacity` हो जोड्छ।
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// सामान्यतया, यहाँ एक [`clear`] को सट्टा सामग्री को ड्रप गर्न को लागी प्रयोग गर्नेछ र यसरी मेमोरी लीक हुँदैन।
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// vector बाट एक तत्व हटाउँछ र फर्काउँछ।
    ///
    /// हटाइएको तत्त्व vector को अन्तिम तत्व द्वारा प्रतिस्थापन गरिएको छ।
    ///
    /// यसले अर्डरिंगलाई सुरक्षित गर्दैन, तर O(1) हो।
    ///
    /// # Panics
    ///
    /// Panics यदि `index` सीमा बाहिर छ।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // हामी अन्तिम तत्व संग आत्म [अनुक्रमणिका] प्रतिस्थापन गर्दछौं।
            // नोट गर्नुहोस् कि यदि माथिको सीमा जाँच सफल भयो भने अन्तिम तत्व हुनुपर्दछ (जुन आफैलाई [सूचकांकमा आफैं हुन सक्छ)।
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// `index` स्थितिमा एलिमेन्ट vector भित्र सम्मिलित गर्दछ, सबै तत्वहरूलाई पछि यसलाई दायाँ सार्दै।
    ///
    ///
    /// # Panics
    ///
    /// Panics यदि `index > len`।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // नयाँ तत्वका लागि ठाउँ
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // अचूक स्थान नयाँ मान राख्नको लागि
            //
            {
                let p = self.as_mut_ptr().add(index);
                // ठाउँ बनाउनको लागि सबै चीज शिफ्ट गर्नुहोस्।
                // (लगातार `सूचकांक तत्वलाई लगातार दुई स्थानहरूमा नक्कल बनाउँदै।)
                ptr::copy(p, p.offset(1), len - index);
                // यसमा लेख्नुहोस्, `अनुक्रमणिका तत्वको पहिलो प्रतिलिपि अधिलेखन गर्नुहोस्।
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// तत्वलाई vector भित्र `index` मा हटाउँछ र फर्काउँछ, सबै तत्त्वहरू पछि यसलाई बायाँ सार्दै।
    ///
    ///
    /// # Panics
    ///
    /// Panics यदि `index` सीमा बाहिर छ।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // हामीले लिइरहेका ठाँउ।
                let ptr = self.as_mut_ptr().add(index);
                // यसलाई प्रतिलिपि गर्नुहोस्, असुरक्षित रूपमा स्ट्याकमा र vector मा एकै समयमा मूल्यको प्रतिलिपि राख्दै।
                //
                ret = ptr::read(ptr);

                // सबै ठाउँमा सिफ्ट गर्नुहोस् तल भरनुहोस्।
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// पूर्वानुमान द्वारा निर्दिष्ट तत्वहरू मात्र राख्छ।
    ///
    /// अर्को शब्दमा, सबै तत्वहरू `e` हटाउनुहोस् कि `f(&e)` `false` फर्काउँछ।
    /// यो विधि स्थानमा सञ्चालन गर्दछ, प्रत्येक तत्व एक पटक मूल क्रममा एक पटक भ्रमण गर्‍यो, र राखिएको तत्त्वहरूको क्रम सुरक्षित गर्दछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// किनभने तत्वहरू क्रममा एक पटक मूल क्रममा भ्रमण गरियो, बाह्य अवस्था कुन एलिमेन्टहरू राख्नुपर्दछ भनेर निर्णय गर्न प्रयोग गर्न सकिन्छ।
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // यदि ड्रप गार्ड कार्यान्वयन गरिएको छैन भने डबल ड्रपबाट बच्नुहोस्, किनकि हामीले प्रक्रियाको बेला केहि प्वालहरू बनाउँदछौं।
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-संसाधित लेन-> |^-जाँच गर्न अर्को
        //                  | <-मेटिएको सीएनटी-> |
        //      | <-original_len-> |राखिएको: एलिमेन्टहरू जुन पूर्वानुमान दिन्छ सहीमा।
        //
        // होल: सारिएको वा स्लप एलिमेन्ट स्लट।
        // जाँच नगरिएको: जाँच नगरिएका मान्य तत्वहरू।
        //
        // पूर्वानुमान वा तत्वको `drop` आतंकित हुँदा यो ड्रप गार्ड सुरू हुनेछ।
        // यसले जाँच नगरिएका तत्वहरूलाई प्वाल पार्छ प्वालमा प्वालहरू र `set_len` लाई सही लम्बाइमा।
        // केसहरूमा जब प्रेडिकेट र `drop` कहिले प्यानक हुँदैन, यो अप्टिमाइज हुनेछ।
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // सुरक्षा: अनचेक नगरिएका वस्तुहरूको ट्रेलि be मान्य हुनुपर्दछ किनकि हामीले तिनीहरूलाई कहिल्यै छोएनौं।
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // सुरक्षा: प्वालहरू भरे पछि, सबै आईटमहरू स्मृतिको स्मृतिमा छन्।
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // सुरक्षा: जाँच नगरिएको तत्व मान्य हुनुपर्दछ।
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // `drop_in_place` डरायो भने डबल ड्रपबाट बच्न प्रारम्भिक अग्रिम।
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // सुरक्षा: हामी यस तत्वलाई छोड्दा पछाडि कहिले पनि छुदैनौं।
                unsafe { ptr::drop_in_place(cur) };
                // हामी पहिले नै काउन्टर उन्नत।
                continue;
            }
            if g.deleted_cnt > 0 {
                // सुरक्षा: `deleted_cnt`> ०, त्यसैले प्वाल स्लट हालको तत्वसँग मिल्दैन।
                // हामी चालको लागि प्रतिलिपि प्रयोग गर्छौं, र यो तत्त्वलाई फेरि कहिल्यै छुदैनौं।
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // सबै वस्तुहरू प्रक्रियामा छन्।यो LLVM द्वारा `set_len` मा अनुकूलित गर्न सकिन्छ।
        drop(g);
    }

    /// vector मा लगातार कुञ्जीहरू पहिले समाप्त गर्दछ जुन समान कुञ्जीमा समाधान हुन्छ।
    ///
    ///
    /// यदि vector क्रमबद्ध गरिएको छ, यसले सबै डुप्लिकेटहरू हटाउँछ।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// vector मा लगातार समान तत्वहरूको पहिलो तर सबै हटाई दिईएको समानता सम्बन्धमा सन्तोषजनक।
    ///
    /// `same_bucket` प्रकार्य vector बाट दुई तत्वहरूमा सन्दर्भ पारित गरियो र तत्वहरू बराबर तुलना गर्दा निर्धारित गर्नु पर्छ।
    /// तत्वहरू तिनीहरूको अर्डरबाट स्लाइसमा विपरीत क्रममा पारित हुन्छन्, त्यसैले यदि `same_bucket(a, b)` `true` फर्काउँछ भने, `a` हटाइन्छ।
    ///
    ///
    /// यदि vector क्रमबद्ध गरिएको छ, यसले सबै डुप्लिकेटहरू हटाउँछ।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// स of्ग्रहको पछाडि तत्व थप गर्दछ।
    ///
    /// # Panics
    ///
    /// Panics यदि नयाँ क्षमता `isize::MAX` बाइट भन्दा अधिक छ।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // यो panic वा परित्याग गर्छ यदि हामी> isize::MAX बाइट्स आवंटित गर्छौं वा यदि लम्बाइ वृद्धि शून्य आकारका प्रकारहरूका लागि ओभरफ्लो हुनेछ।
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// vector बाट अन्तिम तत्व हटाउँछ र यसलाई फर्काउँछ, वा [`None`] यदि खाली छ भने।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// `other` का सबै तत्वहरूलाई `Self` मा सार्दछ, `other` खाली छोड्छ।
    ///
    /// # Panics
    ///
    /// Panics यदि vector मा तत्वहरूको संख्या एक `usize` ओभरफ्लो गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// अन्य बफरबाट तत्वहरू `Self` मा जोड्दछ।
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// एक जल निकाल्ने इटरेटर बनाउँदछ जुन vector मा निर्दिष्ट दायरा हटाउँदछ र हटाइएको वस्तुहरू दिन्छ।
    ///
    /// जब इट्रेटर ** ** छोडियो, दायरामा सबै तत्वहरू vector बाट हटाइन्छ, यदि ईटर्रेटर पूर्ण रूपमा खपत भएको थिएन भने पनि।
    /// यदि इटरेटर ** ** खसाइएको छैन भने (उदाहरणका लागि [`mem::forget`] का साथ), कति वटा तत्वहरू हटाईएको छ भने यो तोकिएको छैन।
    ///
    /// # Panics
    ///
    /// Panics यदि सुरूवात बिन्दु अन्तिम पोइन्ट भन्दा ठूलो छ वा यदि अन्तिम पोइन्ट vector को लम्बाई भन्दा ठूलो छ भने।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // पूर्ण दायराले vector खाली गर्दछ
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // मेमोरी सुरक्षा
        //
        // जब Drain पहिलो सिर्जना गरिएको हो, यसले स्रोत vector लाई छोटो बनाउँदछ सुनिश्चित गर्न को लागी कुनै निर्विवाद वा सारिएको-तत्वहरू कुनै पनि ठाउँमा पहुँच योग्य छैन यदि Drain को विनाशकारी कहिल्यै चल्दैन।
        //
        //
        // Drain ले ptr::read हटाउनेछ मानहरू।
        // जब समाप्त हुन्छ, भेसको बाँकी पुच्छर प्वाल गरेर प्रतिलिपि हुन्छ प्वाल प्वालमा, र vector लम्बाई नयाँ लम्बाइमा पुनःभण्डारण हुन्छ।
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // सेट गर्न self.vec लम्बाइ सेट गर्नुहोस्, Drain चुहावट भएमा सुरक्षित हुन
            self.set_len(start);
            // IterMut मा orrowण प्रयोग गर्नुहोस् सम्पूर्ण Drain पुनरावृत्ति (जस्तै &mut T) का उधारो व्यवहारको संकेत गर्न।
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// vector खाली गर्दछ, सबै मानहरू हटाउँदै।
    ///
    /// नोट गर्नुहोस् कि यस विधिले vector को आवंटित क्षमतामा कुनै प्रभाव पार्दैन।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// vector मा तत्वहरूको संख्या फर्काउँछ, यसलाई यसको 'length' पनि भनिन्छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// यदि vector ले कुनै तत्व समावेश गर्दैन भने `true` फर्काउँछ।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// दिइएको सूचकांकमा संग्रह दुईमा विभाजन गर्दछ।
    ///
    /// `[at, len)` दायरामा एलिमेन्टहरू सहित एक नयाँ आव्हान गरिएको vector फर्काउँछ।
    /// कल पछि, मूल vector ले `[0, at)` एलिमेन्टहरू सहित छोडिनेछ जुन यसको अघिल्लो क्षमता अपरिवर्तित छ।
    ///
    ///
    /// # Panics
    ///
    /// Panics यदि `at > len`।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // नयाँ vector सक्कली बफर लिन र प्रतिलिपि बेवास्ता गर्न सक्दछ
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // असुरक्षित `set_len` र `other` मा आईटमहरूको प्रतिलिपि गर्नुहोस्।
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// `Vec` लाई ठाउँमा पुन: आकार दिन्छ ताकि `len` `new_len` बराबर हो।
    ///
    /// यदि `new_len` `len` भन्दा ठूलो छ, `Vec` भिन्नता द्वारा विस्तार गरियो, प्रत्येक अतिरिक्त स्लट क्लोजर `f` कल गर्ने परिणामले भरियो।
    ///
    /// `f` बाट फर्काउने मानहरू `Vec` मा समाप्त हुने क्रममा समाप्त हुन्छन्।
    ///
    /// यदि `new_len` `len` भन्दा कम छ भने, `Vec` सजिलै काटिन्छ।
    ///
    /// यस विधिले प्रत्येक पुशमा नयाँ मानहरू सिर्जना गर्न क्लोजर प्रयोग गर्दछ।यदि तपाई [`Clone`] दिईएको मानको सट्टामा [`Vec::resize`] प्रयोग गर्नुहोस्।
    /// यदि तपाईं मानहरू उत्पन्न गर्न [`Default`] trait प्रयोग गर्न चाहानुहुन्छ भने, तपाईं दोस्रो तर्कको रूपमा [`Default::default`] पास गर्न सक्नुहुनेछ।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// `Vec` उपभोग र लीक गर्छ, सामग्रीको लागि म्यूटेबल सन्दर्भ फिर्ता गर्दै, `&'a mut [T]`.
    /// नोट गर्नुहोस् कि `T` प्रकारले चुनिएको जीवनकाल `'a` लाई बहिष्कृत गर्नु पर्छ।
    /// यदि प्रकारसँग केवल स्थिर सन्दर्भहरू छन्, वा कुनै पनि त्यस्तो छैन, भने यो `'static` हुन रोज्न सकिन्छ।
    ///
    /// यो प्रकार्य [`leak`][Box::leak] X मा X0X प्रकार्यसँग मिल्दो छ बाहेक बाहेक चुहाएको मेमोरीलाई पुनःप्राप्त गर्ने कुनै उपाय छैन।
    ///
    ///
    /// यो प्रकार्य डाटाको लागि उपयोगी छ जुन प्रोग्रामको बाँकी जीवनको लागि जिउँछ।
    /// फर्काइएको सन्दर्भ छोड्दा मेमोरी चुहावट हुन्छ।
    ///
    /// # Examples
    ///
    /// साधारण प्रयोग:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// vector को बाँकी खाली क्षमता `MaybeUninit<T>` को एक टुक्राको रूपमा फर्काउँछ।
    ///
    /// फर्काइएको स्लाइस vector डाटा (उदाहरणका लागि) भर्न प्रयोग गर्न सकिन्छ
    /// [`set_len`] विधि प्रयोग गरेर आरम्भ गरिएको रूपमा डेटा मार्क गर्नु अघि) एउटा फाइलबाट पढेर।
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // 10 तत्वहरूको लागि पर्याप्त vector आवंटित गर्नुहोस्।
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // पहिलो elements तत्वहरू भर्नुहोस्।
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // vector को पहिलो elements तत्वहरू आरम्भ गरिएको रूपमा चिन्ह लगाउनुहोस्।
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // यो विधि `split_at_spare_mut` को सर्तमा लागू गरीएको छैन, बफरमा पोइन्टर्सको अमान्यकरण रोक्नको लागि।
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// vector सामग्रीलाई `T` को स्लाइसको रूपमा फर्काउँछ, vector को बाँकी खाली क्षमताको साथ `MaybeUninit<T>` को स्लाइसको रूपमा।
    ///
    /// फर्केका स्पेयर क्षमता स्लाइस vector भर्न डाटा प्रयोग गर्न सकिन्छ (उदाहरणका लागि फाइलबाट पढेर) डाटालाई [`set_len`] विधि प्रयोग गरेर आरम्भको रूपमा मार्क गर्नु अघि।
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// नोट गर्नुहोस् कि यो तल्लो स्तरको एपीआई हो, जुन अप्टिमाइजेसन उद्देश्यका लागि सावधानीका साथ प्रयोग गर्नुपर्दछ।
    /// यदि तपाईंलाई `Vec` मा डाटा थप्न आवश्यक छ भने तपाईं [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] वा [`resize_with`] प्रयोग गर्न सक्नुहुनेछ, तपाईंको वास्तविक आवश्यकताहरूमा निर्भर गर्दै।
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // १० तत्वहरूको लागि पर्याप्त ठूलो ठाउँ आरक्षित गर्नुहोस्।
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // अर्को elements तत्वहरू भर्नुहोस्।
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // vector को 4 तत्वहरू आरम्भ गरिएको रूपमा चिन्ह लगाउनुहोस्।
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - लेनलाई बेवास्ता गरियो र कहिल्यै परिवर्तन हुँदैन
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// सुरक्षा: .2 लाई परिवर्तन गर्दै (&mut usize) `.set_len(_)` लाई कल गरीरहेको छ।
    ///
    /// यो विधि `extend_from_within` मा एकै चोटि सबै vec पुर्जाहरुमा अद्वितीय पहुँच गर्न प्रयोग गरीन्छ।
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` `len` तत्वहरूको लागि मान्य हुन ग्यारेन्टी गरिएको छ
        // - `spare_ptr` बफरको अघिल्लो तत्वलाई सूचित गर्दैछ, त्यसैले यो `initialized` सँग ओभरल्याप हुँदैन
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// `Vec` लाई ठाउँमा पुन: आकार दिन्छ ताकि `len` `new_len` बराबर हो।
    ///
    /// यदि `new_len` `len` भन्दा ठूलो छ, `Vec` फरकले विस्तारित गरियो, प्रत्येक अतिरिक्त स्लट `value` भरिएको साथ।
    ///
    /// यदि `new_len` `len` भन्दा कम छ भने, `Vec` सजिलै काटिन्छ।
    ///
    /// यस विधिलाई [`Clone`] कार्यान्वयन गर्न `T` आवश्यक छ, पारित मान क्लोन गर्न सक्षम हुनको लागि।
    /// यदि तपाईंलाई अधिक लचिलोपन चाहिन्छ (वा [`Clone`] को सट्टा [`Default`] मा निर्भर हुन चाहनुहुन्छ भने), [`Vec::resize_with`] प्रयोग गर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// क्लोनहरू र `Vec` मा स्लाइसमा सबै एलिमेन्टहरू जोडिन्छ।
    ///
    /// टुक्रा `other` मा Iterates, प्रत्येक तत्व क्लोन, र त्यसपछि यो `Vec` मा जोड।
    /// `other` vector क्रमबद्ध पार गरिएको छ।
    ///
    /// नोट गर्नुहोस् कि यो प्रकार्य [`extend`] को जस्तै छ बाहेक स्लाइसहरूसँग काम गर्न विशेषज्ञता बाहेक।
    ///
    /// यदि र Rust विशेषज्ञता प्राप्त भयो भने यो प्रकार्य अमान्य हुनेछ (तर अझै उपलब्ध)।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// `src` दायरा को vector को अन्त सम्म प्रतिलिपि गर्दछ।
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` ग्यारेन्टी दिन्छ कि दिईएको दायरा स्वयं अनुक्रमणिकाको लागि मान्य छ
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// यो कोड `extend_with_{element,default}` लाई सामान्यीकृत गर्दछ।
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// `n` मान द्वारा vector विस्तार गर्नुहोस्, दिएका जेनेरेटरको प्रयोग गरेर।
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // बग वरिपरि काम गर्नको लागि सेटलेनऑनड्रप प्रयोग गर्नुहोस् जहाँ कम्पाइलरले `ptr` मार्फत self.set_len() उपनाम नभएको मार्फत स्टोर महसुस गर्न सक्दैन।
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // अन्तिम एक बाहेक सबै तत्वहरू लेख्नुहोस्
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // next() panics मा प्रत्येक चरणमा लम्बाई वृद्धि गर्नुहोस्
                local_len.increment_len(1);
            }

            if n > 0 {
                // हामी अन्तिम तत्व सिधा लेख्न सक्छौं अनावश्यक क्लोनिंग बिना
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // स्कोप गार्ड द्वारा सेट लेन
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// [`PartialEq`] trait कार्यान्वयनको अनुसार vector मा लगातार दोहोरिएका तत्वहरू हटाउँछ।
    ///
    ///
    /// यदि vector क्रमबद्ध गरिएको छ, यसले सबै डुप्लिकेटहरू हटाउँछ।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// आन्तरिक विधिहरू र कार्यहरू
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` मान्य अनुक्रमणिका हुनु आवश्यक छ
    /// - `self.capacity() - self.len()` `>= src.len()` हुनु पर्छ
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - लेन तत्व सुरू गरे पछि मात्र बढाइन्छ
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - कलर ग्यारेटीहरू कि src एक मान्य सूचकांक हो
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - एलिमेन्ट भर्खरै `MaybeUninit::write` को साथ आरम्भ गरिएको थियो, त्यसैले लेन वृद्धि गर्न ठीक छ
            // - लीन रोक्न प्रत्येक तत्व पछि बढाइन्छ (मुद्दा #82533 हेर्नुहोस्)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - कलर ग्यारेटीहरू कि `src` एक मान्य सूचकांक हो
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - दुबै पोइन्टरहरू अद्वितीय स्लाइस सन्दर्भ (`&mut [_]`) बाट सिर्जना गरिएको हो त्यसैले तिनीहरू मान्य छन् र ओभरल्याप हुँदैन।
            //
            // - तत्वहरू: प्रतिलिपि गर्नुहोस् त्यसैले तिनीहरूलाई प्रतिलिपि गर्न ठीक छ, मूल मानको साथ केही नगरी
            // - `count` `source` को लेन बराबर छ, त्यसैले स्रोत `count` पढ्नको लागि मान्य छ
            // - `.reserve(count)` `spare.len() >= count` यति स्पेयर `count` लेख्नका लागि मान्य छ भनेर ग्यारेन्टी गर्दछ
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - तत्वहरू भर्खर `copy_nonoverlapping` द्वारा आरम्भ गरिएको थियो
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Vec को लागी साझा trait कार्यान्वयन
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): cfg(test) सँग अन्तर्निहित `[T]::to_vec` विधि, जुन यो विधि परिभाषाको लागि आवश्यक छ, उपलब्ध छैन।
    // यसको सट्टा `slice::to_vec` प्रकार्य प्रयोग गर्नुहोस् जुन cfg(test) NB को साथ मात्र उपलब्ध छ अधिक जानकारीको लागि slice.rs मा slice::hack मोड्युल हेर्नुहोस्।
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // अधिलेखन हुने छैन जुन केहि छोड्नुहोस्
        self.truncate(other.len());

        // self.len <= other.len माथिको काटिएको कारण, त्यसैले यहाँ स्लाइसहरू जहिले पनि सीमामा हुन्छन्।
        //
        let (init, tail) = other.split_at(self.len());

        // समावेश भएको मान allocations/resources पुन: प्रयोग गर्नुहोस्।
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// उपभोग गर्ने इटरेटर बनाउँदछ, त्यो हो कि प्रत्येक मूल्यलाई vector (सुरुबाट अन्तसम्म) सार्दछ।
    /// vector यसलाई कल गरेपछि प्रयोग गर्न सकिदैन।
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s को प्रकार स्ट्रि has छ, &String हैन
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // पात विधि जसमा विभिन्न SpecFrom/SpecExtend कार्यान्वयन प्रतिनिधि हुन्छन् जब उनीहरूसँग लागू गर्न थप कुनै अनुकूलन छैन
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // यो सामान्य इट्रेटरको लागि केस हो।
        //
        // यो प्रकार्यको नैतिक बराबर हुनुपर्दछ:
        //
        //      आईटरमा आईटमका लागि {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB ओभरफ्लो हुन सक्दैन किनकि हामीले ठेगाना स्पेस बाँडफाँड गर्नुपर्ने थियो
                self.set_len(len + 1);
            }
        }
    }

    /// एक स्प्लिगिंग इटरेटर बनाउँदछ जुन vector मा निर्दिष्ट दायरालाई दिईएको `replace_with` इटरेटरसँग प्रतिस्थापन गर्दछ र हटाइएको वस्तुहरू दिन्छ।
    ///
    /// `replace_with` `range` को समान लम्बाई हुनु आवश्यक छैन।
    ///
    /// `range` हटाईन्छ यदि पुनरावृतकर्ता अन्त्यसम्म उपभोग हुँदैन।
    ///
    /// यो XPXx मान लीक भएमा कति तत्वहरू vector बाट हटाईन्छ भन्ने बारे तोँकी छैन।
    ///
    /// इनपुट इट्रेटर `replace_with` मात्र खपत हुन्छ जब `Splice` मान छोडियो।
    ///
    /// यो इष्टतम हो यदि:
    ///
    /// * पुच्छर (`range` पछि vector मा तत्वहरू) खाली छ,
    /// * वा `replace_with` ले `दायरा'को लम्बाइ भन्दा कम वा बराबर तत्वहरू दिन्छ
    /// * वा यसको `size_hint()` को तल्लो सीमा सही छ।
    ///
    /// अन्यथा, एक अस्थायी vector आवंटित गरियो र पुच्छर दुई पटक सारियो।
    ///
    /// # Panics
    ///
    /// Panics यदि सुरूवात बिन्दु अन्तिम पोइन्ट भन्दा ठूलो छ वा यदि अन्तिम पोइन्ट vector को लम्बाई भन्दा ठूलो छ भने।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// एक पुनरावृत्तिकर्ता सिर्जना गर्दछ जसले एक तत्व हटाइनु पर्छ कि निर्धारित गर्न क्लोजर प्रयोग गर्दछ।
    ///
    /// यदि क्लोजर सहि फिर्ता हुन्छ, तब तत्त्व हटाईन्छ र पैदा हुन्छ।
    /// यदि क्लोजर गलत फिर्ता हुन्छ भने, तत्व vector मा रहनेछ र ईट्रेटर द्वारा उत्पन्न हुने छैन।
    ///
    /// यो विधि प्रयोग गरेर निम्न कोडको बराबर हो।
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // तपाईको कोड यहाँ छ
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// तर `drain_filter` प्रयोग गर्न सजिलो छ।
    /// `drain_filter` यो अधिक कुशल छ, किनकि यसले थोरैमा एर्रेको एलिमेन्ट्सको बैकसिफ्ट गर्न सक्दछ।
    ///
    /// नोट गर्नुहोस् कि `drain_filter` ले तपाईंलाई फिल्टर क्लोजरमा प्रत्येक तत्वलाई परिवर्तन गर्न दिन्छ, तपाईं यसलाई राख्ने वा हटाउने छनौट नगरी।
    ///
    ///
    /// # Examples
    ///
    /// एरियनलाई शाम र विचित्रमा विभाजन गर्दै, मूल विनियोजन पुन: प्रयोग गर्दै:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // लीक भइरहेको हाम्रो विरुद्धमा सावधान गर्नुहोस् (चुहावट प्रवर्धन)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// कार्यान्वयन विस्तार गर्नुहोस् जुन Vec मा उनीहरूलाई धकेल्नु अघि सन्दर्भहरूको बाहिर प्रतिलिपि गर्दछ।
///
/// यो कार्यान्वयन स्लाईस पुनरावृत्तिको लागि विशेष छ, जहाँ यसले [`copy_from_slice`] एकै पटकमा सम्पूर्ण स्लाइस थप्न प्रयोग गर्दछ।
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// vectors को तुलना लागू गर्दछ, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// vectors को क्रमबद्धता कार्यान्वयन, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // [T] को लागी ड्रप प्रयोग गर्नुहोस् vector को तत्वहरूलाई कमजोर आवश्यक प्रकारको रूपमा सन्दर्भ गर्न एक कच्चा स्लाइस प्रयोग गर्नुहोस्;
            //
            // केहि केसहरूमा वैधताको प्रश्नबाट बच्न सक्छ
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec deallocation ह्यान्डल गर्दछ
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// खाली `Vec<T>` सिर्जना गर्दछ।
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: परीक्षण libstd मा तान्छ, जसले यहाँ त्रुटिहरूको कारण गर्दछ
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: परीक्षण libstd मा तान्छ, जसले यहाँ त्रुटिहरूको कारण गर्दछ
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// `Vec<T>` को सम्पूर्ण सामग्रीहरू एर्रेको रूपमा प्राप्त गर्दछ, यदि यसको आकार ठीक अनुरोध गरिएको एर्रेसँग मिल्दछ भने।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// यदि लम्बाइ मिलेन भने, इनपुट `Err` मा फिर्ता आउँदछ:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// यदि तपाईं ठीक `Vec<T>` को उपसर्ग प्राप्त गर्न को लागी ठीक हुनुहुन्छ भने, तपाईं पहिले [`.truncate(N)`](Vec::truncate) कल गर्न सक्नुहुन्छ।
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // सुरक्षा: `.set_len(0)` सधैं ध्वनि हुन्छ।
        unsafe { vec.set_len(0) };

        // सुरक्षा: A `Vec` सूचक सधैं सही रूपमा प al्क्तिबद्ध गरिएको छ, र
        // एर्रेमेन्ट एरमेन्टको समान चीजहरू समान छन्।
        // हामीले पहिले जाँच गर्‍यौं कि हामीसँग पर्याप्त आईटमहरू छन्।
        // वस्तुहरू डबल-ड्रप हुने छैनन् किनकि `set_len` `Vec` लाई तिनीहरूलाई ड्रप नगर्न भन्छ।
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}