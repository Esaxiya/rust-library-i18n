use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Vec::from_iter को लागि विशेषज्ञता trait प्रयोग गरियो
///
/// ## प्रतिनिधिमण्डल ग्राफ:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // एउटा साधारण केसले vector लाई कुनै प्रकार्यमा पार गरिरहेको छ जुन तुरून्त vector मा पुनः संकलन गर्दछ।
        // यदि हामी ईन्टोइटरमा उन्नत छैन भने हामी यो सर्ट सर्किट गर्न सक्छौं।
        // जब यो उन्नत भएको छ हामी पनि मेमोरी पुनः प्रयोग गर्न सक्दछौं र डाटालाई अगाडि सार्न सक्छौं।
        // तर हामी केवल त्यसो गर्छौं जब परिणामस्वरूप भेकसँग जेनेरिक फोरइसेटर कार्यान्वयनको माध्यमबाट यसलाई सिर्जना गर्ने भन्दा बढी प्रयोग नभएको क्षमता हुँदैन।
        //
        // त्यो सीमितता कडा रूपमा आवश्यक छैन किनकि Vec को विनियोजन व्यवहार जानाजानी अनिर्दिष्ट छ।
        // तर यो एक रूढिवादी छनौट हो।
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // spec_extend() लाई प्रतिनिधित्व गर्नुपर्दछ extend() आफैले खाली Vecs को लागि spec_from लाई प्रतिनिधि गर्नुहोस्
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// यसले `iterator.as_slice().to_vec()` प्रयोग गर्दछ किनभने spec_extend ले अन्तिम क्षमता + लम्बाइका बारेमा तर्क गर्न थप कदमहरू चाल्नुपर्दछ र यसैले अधिक काम गर्दछ।
// `to_vec()` सिधा सहि रकम बाँडफाँड गर्दछ र ठ्याक्कै भर्दछ।
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): cfg(test) सँग अन्तर्निहित `[T]::to_vec` विधि, जुन यो विधि परिभाषाको लागि आवश्यक छ, उपलब्ध छैन।
    // यसको सट्टा `slice::to_vec` प्रकार्य प्रयोग गर्नुहोस् जुन cfg(test) NB को साथ मात्र उपलब्ध छ अधिक जानकारीको लागि slice.rs मा slice::hack मोड्युल हेर्नुहोस्।
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}