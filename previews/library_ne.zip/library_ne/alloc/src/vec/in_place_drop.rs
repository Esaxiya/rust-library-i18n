use core::ptr::{self};
use core::slice::{self};

// स्थान पुनरावर्तनका लागि सहयोगी संरचना जसले पुनरावृत्तिको गन्तव्य स्लाइस ड्रप गर्दछ, अर्थात् हेड।
// स्रोत स्लाइस (पुच्छर) IntoIter द्वारा खसालिएको छ।
pub(super) struct InPlaceDrop<T> {
    pub(super) inner: *mut T,
    pub(super) dst: *mut T,
}

impl<T> InPlaceDrop<T> {
    fn len(&self) -> usize {
        unsafe { self.dst.offset_from(self.inner) as usize }
    }
}

impl<T> Drop for InPlaceDrop<T> {
    #[inline]
    fn drop(&mut self) {
        unsafe {
            ptr::drop_in_place(slice::from_raw_parts_mut(self.inner, self.len()));
        }
    }
}