//! # Rust कोर विनियोजन र संग्रह लाइब्रेरी
//!
//! यस पुस्तकालयले स्मार्ट पोइन्टर्स र सap्कलन प्रदान गर्दछ हेप-विनियोजित मानहरू प्रबन्ध गर्नका लागि।
//!
//! यो लाइब्रेरी, लाइबकोर जस्ता, सामान्य रूपमा सीधा प्रयोग गर्न आवश्यक पर्दैन किनकि यसको सामग्रीहरू [`std` crate](../std/index.html) मा पुनः निर्यात हुन्छ।
//! Crates जसले `#![no_std]` एट्रिब्युट प्रयोग गर्दछ तथापि सामान्यतया `std` मा निर्भर हुँदैन, त्यसैले उनीहरूले यसको सट्टामा यो crate प्रयोग गर्थे।
//!
//! ## बक्से मान
//!
//! [`Box`] प्रकार एक स्मार्ट सूचक प्रकार हो।त्यहाँ एक [`Box`] को केवल एक मालिक हुन सक्छ, र मालिकले सामग्रीमा परिवर्तन गर्न निर्णय गर्न सक्दछ, जो हिपमा बस्दछन्।
//!
//! यस प्रकारको थ्रेडहरू बीच कुशलतापूर्वक पठाउन सकिन्छ किनकि `Box` मानको साइज सूचकको जस्तो हो।
//! रूख-जस्तो डाटा संरचनाहरू प्राय: बक्सहरूसहित निर्माण हुन्छन् किनकि प्रत्येक नोडमा प्रायः एक मालिक हुन्छ, अभिभावक।
//!
//! ## सन्दर्भ गन्ती सूचकहरू
//!
//! [`Rc`] प्रकार एक थ्रेडअसेफरेन्स संदर्भ-गणना गरीने सूचक प्रकार हो जुन एक थ्रेड भित्र मेमोरी साझाको लागि उद्देश्य हो।
//! एक [`Rc`] सूचक एक प्रकार, `T` लपेट्छ, र केवल `&T`, एक साझा संदर्भ को उपयोग गर्न अनुमति दिन्छ।
//!
//! यो प्रकारको उपयोगी छ जब यो विरासतगत म्युटेबिलिटी (जस्तै [`Box`] को प्रयोग गरीरहेको छ) एक अनुप्रयोगको लागि धेरै बाधा पुर्‍याइरहेको छ, र प्राय: [`Cell`] वा [`RefCell`] प्रकारहरूको जोडा बनाइएको छ उत्परिवर्तनलाई अनुमति दिनका लागि।
//!
//!
//! ## परमाणु सन्दर्भ गणना सूचकहरू
//!
//! [`Arc`] प्रकार [`Rc`] प्रकारको थ्रेडसेफ बराबर हो।यसले [`Rc`] को सबै समान कार्यक्षमता प्रदान गर्दछ, बाहेक यसले समावेश गरिएको प्रकार `T` साझेदारी योग्य हो भनेर बाहेक।
//! थप रूपमा, [`Arc<T>`][`Arc`] आफै पठाउन योग्य छ जबकि [`Rc<T>`][`Rc`] छैन।
//!
//! यस प्रकारले समाहित डाटामा साझा पहुँचको लागि अनुमति दिन्छ, र प्राय: सिnch्क्रोनाइजेसन प्रिमिटिभहरू जस्तै जोडीयो को साझा गरिएको स्रोतको उत्परिवर्तन अनुमति दिन mutexes संग जोडी।
//!
//! ## Collections
//!
//! सबैभन्दा सामान्य सामान्य उद्देश्य डाटा संरचनाहरूको कार्यान्वयन यस पुस्तकालयमा परिभाषित छन्।ती [standard collections library](../std/collections/index.html) मार्फत पुन: निर्यात हुन्छन्।
//!
//! ## हिप इन्टरफेस
//!
//! [`alloc`](alloc/index.html) मोड्युलले कम-स्तर ईन्टरफेसलाई पूर्वनिर्धारित ग्लोबल आक्लोरेटरमा परिभाषित गर्दछ।यो libc एलोरेटर एपीआईको साथ उपयुक्त छैन।
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// प्राविधिक रूपमा, यो रस्टडोकमा बग हो: रस्टडोकले `#[lang = slice_alloc]` ब्लकहरूमा कागजातहरू `&[T]` का लागि देख्दछ, जुनसँग `core` मा यो सुविधा प्रयोग गरेर कागजात पनि छ, र पागल हुन्छ कि सुविधा-गेट सक्षम छैन।
// आदर्श रूपमा, यसले अन्य crates बाट कागजातहरूको लागि फिचर गेटको लागि जाँच गर्दैन, तर किनकि यो केवल ल्यांग वस्तुहरूको लागि मात्र देखा पर्न सक्छ, फिक्सिंग लायक देखिदैन।
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// यस पुस्तकालयको परीक्षणको लागि अनुमति दिनुहोस्

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// अन्य मोड्युलहरू द्वारा प्रयोग गरिएको आन्तरिक म्याक्रोहरूको साथ मोड्युल (अन्य मोड्युलहरू अघि समावेश गर्नु आवश्यक छ)।
#[macro_use]
mod macros;

// थोरै स्तरको विनियोजन रणनीतिहरूको लागि हिपहरू प्रदान गरियो

pub mod alloc;

// आदिम प्रकारहरू माथि हिपहरू प्रयोग गरेर

// सर्त रूपमा `boxed.rs` बाट मोड परिभाषित गर्न आवश्यक छ जब cfg निर्माण गर्दा ल्याट-आइटमहरूको नक्कल गर्नबाट जोगिन;तर पनि `use boxed::Box;` घोषणा गर्न कोडलाई अनुमति दिन आवश्यक छ।
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}