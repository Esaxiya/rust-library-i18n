#![stable(feature = "rust1", since = "1.0.0")]

//! थ्रेड-सुरक्षित सन्दर्भ मतगणना सूचकहरू।
//!
//! अधिक जानकारीको लागि [`Arc<T>`][Arc] कागजात हेर्नुहोस्।

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// `Arc` मा गर्न सकिने सन्दर्भहरूको मात्रामा एक नरम सीमा।
///
/// यस सीमा भन्दा माथि जाँदा _exactly_ `MAX_REFCOUNT + 1` सन्दर्भहरूमा तपाईंको कार्यक्रम (तथापि आवश्यक छैन) परित्याग गर्दछ।
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// थ्रेडसेनिटाइजरले मेमोरी फेंस समर्थन गर्दैन।
// आर्क/कमजोर कार्यान्वयनमा गलत सकारात्मक रिपोर्टहरू बेवास्ता गर्न समिकरणको सट्टामा आणविक भार प्रयोग गर्नुहोस्।
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// एक थ्रेड-सुरक्षित सन्दर्भ-मतगणना सूचक।'Arc' को मतलब 'परमाणु सन्दर्भ काउन्टेड'।
///
/// प्रकार `Arc<T>` प्रकारको `T` को मूल्यको स्वामित्व प्रदान गर्दछ, हिपमा आवंटित गरियो।`Arc` मा [`clone`][clone] आमन्त्रित एक नयाँ `Arc` उदाहरण उत्पादन गर्दछ, जो स्रोत `Arc` को रूपमा हीपमा समान आवंटनलाई इंगित गर्दछ, जबकि सन्दर्भ गणनालाई बढाउँदै।
/// जब कुनै XOX दिइएको सूचकलाई अन्तिम सूचक नष्ट गरिन्छ, त्यस आवंटनमा भण्डारित मान (प्राय: "inner value" भनिन्छ) पनि छोडिन्छ।
///
/// Rust मा साझा संदर्भले पूर्वनिर्धारितद्वारा उत्परिवर्तन अस्वीकार गर्दछ, र `Arc` यसको अपवाद छैन: तपाईं सामान्यतया `Arc` भित्र कुनै चीजको लागि म्यूटेबल सन्दर्भ प्राप्त गर्न सक्नुहुन्न।यदि तपाइँले `Arc` मार्फत परिवर्तन गर्न आवश्यक छ भने, [`Mutex`][mutex], [`RwLock`][rwlock], वा [`Atomic`][atomic] प्रकार मध्ये एउटा प्रयोग गर्नुहोस्।
///
/// ## थ्रेड सुरक्षा
///
/// [`Rc<T>`] विपरीत, `Arc<T>` यसको संदर्भ मतगणनाको लागि आणविक अपरेसनहरू प्रयोग गर्दछ।यसको मतलब यो थ्रेड-सेफ हो।नोक्सान यो हो कि साधारण मेमोरी एक्सेसहरू भन्दा आणविक अपरेसनहरू महँगो हुन्छन्।यदि तपाईं थ्रेडहरू बीच सन्दर्भ-गणना गणनामा साझेदारी गर्दै हुनुहुन्न भने, तल्लो ओभरहेडको लागि [`Rc<T>`] प्रयोग गर्ने विचार गर्नुहोस्।
/// [`Rc<T>`] एक सुरक्षित पूर्वनिर्धारित हो, किनकि कम्पाइलरले थ्रेडहरू बीच [`Rc<T>`] पठाउन कुनै प्रयास समात्छ।
/// यद्यपि लाइब्रेरीले `Arc<T>` लाई छनौट गर्न सक्दछ पुस्तकालयको उपभोक्ताहरूलाई बढी लचिलो बनाउन।
///
/// `Arc<T>` [`Send`] र [`Sync`] लाई `T` कार्यान्वयन गर्ने [`Send`] र [`Sync`] लाई लागू गर्दछ।
/// तपाईं किन एक थ्रेड-सुरक्षित प्रकार `T` `Arc<T>` मा यो थ्रेड-सुरक्षित बनाउन सक्नुहुन्न?यो सुरुमा थोरै काउन्टर-सहज हुन सक्छ: आखिर, यो `Arc<T>` थ्रेड सुरक्षाको बिन्दु होइन?कुञ्जी यो हो: `Arc<T>` समान थ्रेडको बहु स्वामित्व राख्न यो थ्रेड सुरक्षित गर्दछ, तर यसले डाटामा थ्रेड सुरक्षा थप गर्दैन।
///
/// विचार गर्नुहोस् `आर्क <` [`RefCell<T>`]`>`।
/// [`RefCell<T>`] [`Sync`] हैन, र यदि `Arc<T>` सँधै [`Send`], `चाप <` [`RefCell थियो<T>`]`>`साथै हुनेछ।
/// तर त्यसो भए हामीसँग समस्या छ:
/// [`RefCell<T>`] धागा सुरक्षित छैन;यसले गैर-परमाणु अपरेशन्सको प्रयोग गरेर ingण लिने गणनालाई ट्र्याक राख्दछ।
///
/// अन्त्यमा, यसको मतलब यो हो कि तपाई `Arc<T>` लाई [`std::sync`] प्रकारको प्रकार जोड्नु पर्दछ, सामान्यतया [`Mutex<T>`][mutex]।
///
/// ## `Weak` को साथ ब्रेक चक्र
///
/// [`downgrade`][downgrade] विधि गैर स्वामित्वको [`Weak`] सूचक सिर्जना गर्न प्रयोग गर्न सकिन्छ।एक [`Weak`] सूचक [`अपग्रेड`][अपग्रेड] d एक `Arc` मा हुन सक्छ, तर यो [`None`] फिर्ता हुनेछ यदि विनियोजनमा भण्डार गरिएको मान पहिले नै छोडियो भने।
/// अर्को शब्दमा, `Weak` पोइन्टर्सले विनियोजन भित्र रहेको मानलाई जीवित राख्दैन;जे होस्, तिनीहरूले * बाँडफाँड (मूल्य को लागी ब्याकिंग स्टोर) लाई जीवित राख्छन्।
///
/// `Arc` पोइन्टर्स बीचको चक्र कहिले पनि डिलोकेट हुँदैन।
/// यस कारणले, [`Weak`] चक्र तोड्न प्रयोग गरिन्छ।उदाहरण को लागी, एउटा रूखले कडा `Arc` सूचकहरू बच्चालाई अभिभावक नोड्सबाट, र [`Weak`] सूचक बच्चाहरूबाट आफ्ना आमा बुबामा गर्न सक्दछ।
///
/// # क्लोनिंग सन्दर्भ
///
/// अवस्थित सन्दर्भ-गणना सूचकबाट नयाँ सन्दर्भ सिर्जना गर्ने `Clone` trait [`Arc<T>`][Arc] र [`Weak<T>`][Weak] को लागी लागू गरीएको हो।
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // तल दुई वाक्य रचनाहरू बराबर छन्।
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, र foo सबै आर्क्स हुन् जुन समान मेमोरी स्थानमा औंल्याउँछ
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` स्वचालित रूपमा `T` का सन्दर्भ ([`Deref`][deref] trait मार्फत), त्यसैले तपाईं `Arc<T>` प्रकारको मानमा `T` विधिहरू कल गर्न सक्नुहुनेछ।`T` का विधिहरूसँग नाम द्वन्द्वबाट बच्न, `Arc<T>` का विधिहरू सम्बन्धित कार्यहरू हुन्, जुन [fully qualified syntax] प्रयोग गरेर भनिन्छ:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `चाप<T>`Clone` जस्तो traits को implement का कार्यान्वयनहरू पूर्ण रूपमा योग्य सिन्ट्याक्स प्रयोग गरेर पनि बोलाउन सकिन्छ।
/// केही व्यक्ति पूर्ण रूपले योग्य सिन्ट्याक्स प्रयोग गर्न रुचाउँछन्, जबकि अरूले विधि-कल सिन्ट्याक्स प्रयोग गर्न रुचाउँछन्।
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // विधि-कल सिन्ट्याक्स
/// let arc2 = arc.clone();
/// // पूर्ण योग्य सिन्ट्याक्स
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] `T` मा स्वत: डेरेन्सन गर्दैन, किनकि भित्री मान पहिले नै छोडियो।
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// थ्रेडहरू बीच केही अपरिवर्तनीय डेटा साझा गर्दै:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// नोट गर्नुहोस् कि हामी यहाँ **यी परीक्षणहरू** चलाउँदैनौं।
// windows निर्माणकर्ताहरू अति दुखी हुन्छन् यदि एउटा थ्रेडले मुख्य थ्रेडलाई आउटलाइभ गर्दछ र त्यहि समयमा बाहिर निस्किन्छ (केहि डेडलक्स) त्यसैले हामी केवल यी परीक्षणहरू चलाएर यसलाई पूर्ण रूपमा बेवास्ता गर्छौं।
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// एक परिवर्तनीय [`AtomicUsize`] साझा गर्दै:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// सामान्य गणना सन्दर्भको अधिक उदाहरणका लागि [`rc` documentation][rc_examples] हेर्नुहोस्।
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` [`Arc`] को संस्करण हो जुन प्रबन्धित विनियोजनको गैर-स्वामित्व सन्दर्भ राख्दछ।
/// `Weak` सूचकमा [`upgrade`] कल गरेर विनियोजन पहुँच गरिएको छ, जसले [`विकल्प`] returns <`[`आर्के]`फिर्ता गर्छ<T>>`।
///
/// एक `Weak` सन्दर्भ स्वामित्व तिर गणना छैन, यो बाँडफाँड मा भण्डार गरिएको मान छोड्दा रोक्ने छैन, र `Weak` आफैं अझै पनी मूल्य रहेको बारे कुनै ग्यारेन्टी बनाउँदैन।
///
/// यसैले यसले [`None`] फिर्ता गर्न सक्दछ जब [`अपग्रेड`] d।
/// तथापि नोट गर्नुहोस् कि एक `Weak` सन्दर्भ *गर्दछ* बाँडफाँड आफैं (समर्थन स्टोर) deallocated हुनबाट रोक्छ।
///
/// एक `Weak` सूचक [`Arc`] द्वारा व्यवस्थित विनियोजनको एक अस्थायी संदर्भ राख्नको लागि यसको आन्तरिक मान ड्रप हुनबाट रोक्नको लागि उपयोगी छ।
/// यो [`Arc`] पोइन्टर्स बीच गोलाकार सन्दर्भ रोक्न पनि प्रयोग गरिन्छ, किनकि आपसी स्वामित्व सन्दर्भले कहिले पनि [`Arc`] छोड्ने अनुमति दिँदैन।
/// उदाहरण को लागी, एउटा रूखले कडा [`Arc`] सूचकहरू बच्चामा अभिभावक नोड्सबाट, र `Weak` सूचक बच्चाहरूबाट आफ्ना आमा बुबामा गर्न सक्छ।
///
/// `Weak` पोइन्टर प्राप्त गर्न विशिष्ट तरिका भनेको [`Arc::downgrade`] कल गर्नु हो।
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // यो `NonNull` हो enums मा यस प्रकारको आकार अनुकूलन अनुमति दिन को लागी, तर यो एक मान्य सूचक आवश्यक छैन।
    //
    // `Weak::new` यसलाई `usize::MAX` मा सेट गर्दछ ताकि यसलाई हिपमा खाली स्थान विनियोजन गर्न आवश्यक पर्दैन।
    // त्यो वास्तविक पोइन्टरले कहिले पनी मान गर्दैन किनभने आरसीबक्समा कम्तिमा २ पign्क्तिबद्ध गरिएको छ।
    // यो मात्र सम्भव छ जब `T: Sized`;असमर्थित `T` कहिल्यै झर्ने छैन।
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// यो सम्भावित फिल्ड-रिअर्डरिंगको बिरूद्ध repr(C) बाट future-प्रूफ हो, जसले ट्रान्समिटेबल भित्री प्रकारका सुरक्षित [into|from]_raw() सँग हस्तक्षेप गर्दछ।
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // usize::MAX मानले अस्थायी रूपमा "locking" को लागि कमजोर पोइन्टर्स अपग्रेड गर्ने वा बलियो व्यक्तिहरू डाउनग्रेड गर्ने क्षमताको लागि एक प्रेषकको रूपमा कार्य गर्दछ;`make_mut` र `get_mut` मा रेसहरू जोगिनका लागि यो प्रयोग गरिन्छ।
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// नयाँ `Arc<T>` निर्माण गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // कमजोर पोइन्टर गणना १ को रूपमा शुरू गर्नुहोस् जुन कमजोर सूचक हो जुन सबै शक्तिशाली पोइन्टरहरू (kinda) द्वारा समेटिएको छ, अधिक जानकारीको लागि std/rc.rs हेर्नुहोस्।
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// नयाँ `Arc<T>` निर्माण गर्दछ आफैमा कमजोर सन्दर्भ प्रयोग गरेर।
    /// यस प्रकार्यले फर्काउनु भन्दा पहिले कमजोर सन्दर्भ अपग्रेड गर्न प्रयास गर्दा `None` मानमा परिणाम हुनेछ।
    /// यद्यपि कमजोर सन्दर्भलाई स्वतन्त्र रूपमा क्लोन गर्न सकिन्छ र पछि प्रयोगको लागि भण्डारण गर्न सकिन्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // "uninitialized" राज्य भित्र भित्री एकल कमजोर सन्दर्भको साथ बनाउनुहोस्।
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // यो महत्त्वपूर्ण छ कि हामी कमजोर सूचकको स्वामित्व त्याग्दैनौं, वा अन्यथा `data_fn` रिटर्न द्वारा मेमोरी खाली हुन सक्छ।
        // यदि हामी वास्तवमै स्वामित्व पास गर्न चाहान्छौं भने, हामी आफैंको लागि अतिरिक्त कमजोर सूचक सिर्जना गर्न सक्थ्यौं, तर यसले कमजोर सन्दर्भ गणनालाई थप अपडेटहरू दिनेछ जुन अन्यथा आवश्यक नहुन सक्छ।
        //
        //
        //
        //
        let data = data_fn(&weak);

        // अब हामी भित्री मानको राम्रोसँग इनिसियलास गर्न सक्दछौं र हाम्रो कमजोर सन्दर्भलाई कडा सन्दर्भमा बदल्न सक्छौं।
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // माथिको डेटा फिल्डमा लेख्नको लागि कुनै थ्रेडमा दृश्यात्मक हुनुपर्दछ जुन गैर-शून्य बलियो गणना गर्दछ।
            // त्यसैले हामीलाई कम्तिमा "Release" क्रमबद्ध गर्न आवश्यक छ `Weak::upgrade` मा `compare_exchange_weak` साथ सि sy्ख्रोनाइज गर्न।
            //
            // "Acquire" आदेश आवश्यक छैन।
            // जब `data_fn` को सम्भावित ब्यवहारहरू विचार गर्दा हामीले केवल अपग्रेड गर्न योग्य `Weak` को सन्दर्भमा के गर्न सक्दछ भनेर हेर्नु आवश्यक छ:
            //
            // - यसले *क्लोन*`Weak` गर्न सक्दछ, कमजोर सन्दर्भ गणना बढाउँदै।
            // - यसले ती क्लोनहरूलाई ड्रप गर्न सक्छ, कमजोर सन्दर्भ गणना घटाउँदै (तर कहिले शून्यमा)।
            //
            // यी साइड इफेक्टले कुनै पनि हिसाबले हामीलाई असर गर्दैन, र कुनै अन्य साइड इफेक्टहरू सुरक्षित कोडको साथ सम्भव छैन।
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // कडा सन्दर्भले सामूहिक रूपमा एक साझा कमजोर संदर्भको स्वामित्व लिनुपर्दछ, त्यसैले हाम्रो पुरानो कमजोर सन्दर्भको लागि विनाशकारी चलाउनुहोस्।
        //
        mem::forget(weak);
        strong
    }

    /// अनावश्यक सामग्रीको साथमा नयाँ `Arc` निर्माण गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // स्थगित आरम्भ:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// `0` बाइट्सको साथ मेमोरी भरिएको साथ, ईनिटिटलाइज गरिएको सामग्रीको साथ नयाँ `Arc` निर्माण गर्दछ।
    ///
    ///
    /// यस विधिको सही र गलत प्रयोगको उदाहरणका लागि [`MaybeUninit::zeroed`][zeroed] हेर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// नयाँ `Pin<Arc<T>>` निर्माण गर्दछ।
    /// यदि `T` `Unpin` कार्यान्वयन गर्दैन, तब `data` मेमोरीमा पिन हुनेछ र सर्न असक्षम भयो।
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// नयाँ `Arc<T>` निर्माण गर्दछ, यदि त्रुटि विनियोजन असफल भयो भने त्रुटि फिर्ता गर्दै।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // कमजोर पोइन्टर गणना १ को रूपमा शुरू गर्नुहोस् जुन कमजोर सूचक हो जुन सबै शक्तिशाली पोइन्टरहरू (kinda) द्वारा समेटिएको छ, अधिक जानकारीको लागि std/rc.rs हेर्नुहोस्।
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// एकनिमेसनयुक्त सामग्रीको साथ नयाँ `Arc` निर्माण गर्दछ, यदि त्रुटि विनियोजन असफल भयो भने त्रुटि फिर्ता गर्दै।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // स्थगित आरम्भ:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// `0` बाइट्सको साथ मेमोरी भरिएकोमा, एक्निटिसलाइज्ड सामग्रीको साथ नयाँ `Arc` निर्माण गर्दछ, यदि त्रुटि असफल भएमा त्रुटि फिर्ता गर्छ।
    ///
    ///
    /// यस विधिको सही र गलत प्रयोगको उदाहरणका लागि [`MaybeUninit::zeroed`][zeroed] हेर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// भित्री मान फिर्ता गर्दछ, यदि `Arc` सँग ठीक एक मजबूत संदर्भ छ भने।
    ///
    /// अन्यथा,[`Err`] X फिर्ता गरिएको समान `Arc` सँग फिर्ता भयो।
    ///
    ///
    /// यो सफल हुनेछ यदि त्यहाँ उल्लेखनीय कमजोर सन्दर्भहरू छन्।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // निहित संकेत-कमजोर सन्दर्भ खाली गर्नका लागि कमजोर सूचक बनाउनुहोस्
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// इनिटिटलाइज गरिएको सामग्रीको साथ नयाँ परमाणु सन्दर्भ-गणना स्लाइस निर्माण गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // स्थगित आरम्भ:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// `0` बाइट्सको साथ मेमोरी भरिएको साथ, ईनिटिटलाइज गरिएको सामग्रीको साथ नयाँ परमाणु सन्दर्भ-गणना स्लाइस निर्माण गर्दछ।
    ///
    ///
    /// यस विधिको सही र गलत प्रयोगको उदाहरणका लागि [`MaybeUninit::zeroed`][zeroed] हेर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// `Arc<T>` मा रूपान्तरण गर्दछ।
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] को रूपमा, यो कलरमा निर्भर हुन्छ कि ग्यारेन्टी गर्न कि भित्री मान वास्तवमा आरम्भिक अवस्थामा छ।
    ///
    /// यो कलिंग गर्दा जब सामग्री अझै पूर्ण रूपमै आरम्भ गरिएको छैन तत्काल अपरिभाषित व्यवहारको कारण गर्दछ।
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // स्थगित आरम्भ:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// `Arc<[T]>` मा रूपान्तरण गर्दछ।
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] को रूपमा, यो कलरमा निर्भर हुन्छ कि ग्यारेन्टी गर्न कि भित्री मान वास्तवमा आरम्भिक अवस्थामा छ।
    ///
    /// यो कलिंग गर्दा जब सामग्री अझै पूर्ण रूपमै आरम्भ गरिएको छैन तत्काल अपरिभाषित व्यवहारको कारण गर्दछ।
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // स्थगित आरम्भ:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// `Arc` खान्छ, र्याप गरिएको सूचक फिर्ता गर्दै।
    ///
    /// मेमोरी चुहावटबाट बच्न सूचकलाई [`Arc::from_raw`] प्रयोग गरेर `Arc` मा परिवर्तन गर्नुपर्दछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// डाटालाई कच्चा सूचक प्रदान गर्दछ।
    ///
    /// गन्तीहरू कुनै पनि तरिकाले प्रभावित हुँदैनन् र `Arc` उपभोग हुँदैन।
    /// `Arc` मा बलियो गणनाहरू छन् जबसम्म सूचक मान्य छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // सुरक्षा: यो Deref::deref वा RcBoxPtr::inner मार्फत जान सक्दैन किनभने किनभने
        // यसको लागि raw/mut प्रोभेन्सन्स राख्न आवश्यक पर्दछ
        // `get_mut` `from_raw` मार्फत Rc पुन: प्राप्त भएपछि सूचकको माध्यमबाट लेख्न सक्छ।
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// एक कच्चा सूचक बाट एक `Arc<T>` बनाउँछ।
    ///
    /// कच्चा सूचक पहिले [`Arc<U>::into_raw`][into_raw] लाई फिर्ता फिर्ता गरिएको हुनुपर्छ जहाँ `U` सँग समान आकार र `T` को रूपमा पment्क्तिबद्धता हुनुपर्दछ।
    /// यदि यो `U` `T` हो भने यो तुच्छ हो।
    /// नोट गर्नुहोस् कि यदि `U` `T` हैन, तर उही आकार र पign्क्तिबद्धता छ भने, यो मूल रूपमा फरक प्रकारको सन्दर्भ ट्रान्समिटि। जस्तै हो।
    /// यस केसमा के प्रतिबन्धहरू लागू हुन्छन् भन्ने बारे थप जानकारीको लागि [`mem::transmute`][transmute] हेर्नुहोस्।
    ///
    /// `from_raw` को प्रयोगकर्ताले `T` को एक खास मूल्य एक पटक मात्र छोडियो भनेर निश्चित गर्नुपर्दछ।
    ///
    /// यो प्रकार्य असुरक्षित हो किनभने अनुचित प्रयोगले मेमोरी असुरक्षित गर्न सक्दछ, फिर्ता `Arc<T>` कहिल्यै पहुँच नहुने भए पनि।
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // चुहावट रोक्नको लागि फेरि `Arc` मा रूपान्तरण गर्नुहोस्।
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Arc::from_raw(x_ptr)` लाई थप कलहरू मेमोरी-असुरक्षित हुनेछन्।
    /// }
    ///
    /// // `x` माथिको दायरा बाहिर गयो जब यो मेमोरी खाली भयो, त्यसैले `x_ptr` अब झुम्झिरहेको छ!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // मूल ArcInner फेला पार्नको लागि अफसेटलाई उल्टाउनुहोस्।
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// यो विनियोजन गर्न नयाँ [`Weak`] सूचक सिर्जना गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // यो आराम गरीयो किनकि हामी तलको CAS मा मान जाँच गर्दैछौं।
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // कमजोर काउन्टर हाल "locked" छ कि छैन जाँच गर्नुहोस्;यदि हो भने, स्पिन।
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: यस कोडले हाल अतिप्रवाहको सम्भावनालाई बेवास्ता गर्दछ
            // usize::MAX मा;सामान्य रूपमा आरसी र आर्क दुबैलाई ओभरफ्लोसँग सम्झौताको समायोजन गर्न आवश्यक छ।
            //

            // Clone() सँग विपरित, हामी यो `is_unique` बाट आएको लेखको साथ सिize्क्रोनाइज गर्न को लागी एक्वाइर पठन हुनु आवश्यक छ, ताकि त्यो लेख्नु भन्दा पहिलेका घटनाहरू यस पढ्नु अघि नै हुनेछ।
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // निश्चित गर्नुहोस् कि हामी व्याकुल कमजोरी सिर्जना गर्दैनौं
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// यो विनियोजनमा [`Weak`] पोइन्टर्सको संख्या प्राप्त गर्दछ।
    ///
    /// # Safety
    ///
    /// यो विधि आफै सुरक्षित छ, तर यसलाई सही रूपमा प्रयोग गर्न थप हेरचाह आवश्यक छ।
    /// अर्को थ्रेडले कुनै पनि समयमा कमजोर गणनालाई परिवर्तन गर्न सक्दछ, सम्भवतः यस विधिलाई कल गर्ने र परिणाममा कार्य गर्ने बीचमा।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // यो दृढ निरोधात्मक हो किनकि हामीले थ्रेडहरू बीच `Arc` वा `Weak` साझा गरेका छैनौं।
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // यदि कमजोर गणना हाल लक गरिएको छ भने, लक लिनु अघि गणनाको मान ० थियो।
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// यस विनियोजनको लागि सशक्त (`Arc`) सूचकहरूको संख्या प्राप्त गर्दछ।
    ///
    /// # Safety
    ///
    /// यो विधि आफै सुरक्षित छ, तर यसलाई सही रूपमा प्रयोग गर्न थप हेरचाह आवश्यक छ।
    /// अर्को थ्रेडले कुनै पनि समयमा बलियो गणनालाई परिवर्तन गर्न सक्दछ, सम्भवतः यस विधिलाई कल गर्ने र परिणाममा कार्य गर्ने बीचमा।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // यो दृढ निरोधात्मक हो किनकि हामीले थ्रेडहरू बीच `Arc` साझा गरेको छैन।
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// `Arc<T>` मा एक द्वारा प्रदान गरिएको सूचकको साथ सम्बन्धित सन्दर्भ सन्दर्भलाई वृद्धि गर्दछ।
    ///
    /// # Safety
    ///
    /// सूचक `Arc::into_raw` को माध्यमबाट प्राप्त गरेको हुनुपर्दछ, र सम्बन्धित `Arc` उदाहरण मान्य हुनुपर्दछ (जस्तै
    /// यस विधिको अवधिको लागि बलियो गणना कम्तिमा १ हुनुपर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // यो दृढ निरोधात्मक हो किनकि हामीले थ्रेडहरू बीच `Arc` साझा गरेको छैन।
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // आर्क पुन: राख्नुहोस्, तर म्यानुअल ड्रपमा बेर्ने द्वारा रिफ्याउन्ट छुनुहोस्
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // अब पुन: गणना बढाउनुहोस्, तर नयाँ रिसाउन्टलाई पनि नहेर्नुहोस्
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// `Arc<T>` मा एक द्वारा प्रदान गरिएको सूचकको साथ सम्बन्धित सन्दर्भ सन्दर्भलाई कम गर्छ।
    ///
    /// # Safety
    ///
    /// सूचक `Arc::into_raw` को माध्यमबाट प्राप्त गरेको हुनुपर्दछ, र सम्बन्धित `Arc` उदाहरण मान्य हुनुपर्दछ (जस्तै
    /// यस विधिलाई प्रयोग गर्दा कडा गणना कम्तिमा १ हुनुपर्दछ।
    /// यो विधि अन्तिम `Arc` र ब्याकिंग भण्डारण जारी गर्न प्रयोग गर्न सकिन्छ, तर ** ** भनिनु हुँदैन अन्तिम `Arc` जारी गरिए पछि।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // ती दावीहरू डिस्टेनिमेन्टिक हुन् किनकि हामीले थ्रेडहरू बीच `Arc` साझा गरेका छैनौं।
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // यो असुरक्षित छ किनकि यो चाप जीवित रहेको बेला हामी ग्यारेन्टी छौं कि भित्री पोइन्टर मान्य छ।
        // यसबाहेक, हामीलाई थाहा छ कि `ArcInner` संरचना आफै `Sync` हो किनभने भित्री डाटा साथै `Sync` पनि हो, त्यसैले हामी यी सामग्रीहरूमा अपरिवर्तनीय सूचक बाहिर loanण दिइरहेका छौं।
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // `drop` को गैर-ईनलाइन भाग।
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // यस समयमा डाटा नष्ट गर्नुहोस्, यद्यपि हामीले बाकस बाँडफाँड आफैँ स्वतन्त्र नगर्न सक्दछौं (त्यहाँ अझै पनी कमजोर सूचकहरू छन्)।
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // कमजोर रेफ ड्रप गर्नुहोस् सामूहिक रूपमा सबै मजबूत संदर्भ द्वारा आयोजित
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// `true` फर्काउँछ यदि दुई `Arc`s एक समान आबंटनमा देखाउँदछ ([`ptr::eq`] समान शिरामा)।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// एक `ArcInner<T>` सम्भावित असक्षम आकार भित्री मानको लागि पर्याप्त स्थानको साथ आवंटित गर्दछ जहाँ मानको लेआउट प्रदान गरिएको छ।
    ///
    /// प्रकार्य `mem_to_arcinner` डाटा पोइन्टरको साथ कल गरिएको छ र `ArcInner<T>` को लागी एक (सम्भावित फ्याट)-पोइन्टर फिर्ता गर्नु पर्छ।
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // दिइएको मान लेआउट प्रयोग गरेर लेआउट गणना गर्नुहोस्।
        // पहिले, लेआउट `&*(ptr as* const ArcInner<T>)` अभिव्यक्ति मा गणना गरिएको थियो, तर यो एक गलत हस्ताक्षर संदर्भ सिर्जना (#54908 हेर्नुहोस्)।
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// एक `ArcInner<T>` सम्भावित असक्षम आकार भित्री मानको लागि पर्याप्त ठाउँको साथ बाँडफाँट गर्दछ जहाँ मानले रूपरेखा प्रदान गरेको छ, यदि त्रुटि असफल भएमा त्रुटि फिर्ता गर्ने।
    ///
    ///
    /// प्रकार्य `mem_to_arcinner` डाटा पोइन्टरको साथ कल गरिएको छ र `ArcInner<T>` को लागी एक (सम्भावित फ्याट)-पोइन्टर फिर्ता गर्नु पर्छ।
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // दिइएको मान लेआउट प्रयोग गरेर लेआउट गणना गर्नुहोस्।
        // पहिले, लेआउट `&*(ptr as* const ArcInner<T>)` अभिव्यक्ति मा गणना गरिएको थियो, तर यो एक गलत हस्ताक्षर संदर्भ सिर्जना (#54908 हेर्नुहोस्)।
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // आर्कइन्नर सुरु गर्नुहोस्
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// एक असक्षम भित्री मानको लागि पर्याप्त ठाउँको साथ एक `ArcInner<T>` आवंटित गर्दछ।
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // दिइएको मान प्रयोग गरेर `ArcInner<T>` को लागी विनियोजन गर्नुहोस्।
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // बाइट्सको रूपमा मूल्य प्रतिलिपि गर्नुहोस्
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // यसको सामग्रीहरू खसाल बिना नै वितरण छुट गर्नुहोस्
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// दिईएको लम्बाईको साथ `ArcInner<[T]>` बाँडफाँड गर्दछ।
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// स्लाइसबाट एलिमेन्टहरू प्रतिलिपि गर्नुहोस् भर्खरै विनियोजित आर्क <\[T\]> मा
    ///
    /// असुरक्षित किनकि कलरले या त स्वामित्व लिनुपर्दछ वा `T: Copy` लाई पक्का गर्नु पर्छ।
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// एक निश्चित आकार को रूपमा परिचित इटरेटरबाट `Arc<[T]>` निर्माण गर्दछ।
    ///
    /// व्यवहार अपरिभाषित छ साइज गलत हुनुपर्दछ।
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // T0 क्लोनिंग गर्दै Panic गार्ड।
        // panic को घटनामा, नयाँ आर्कइन्नरमा लेखिएका एलिमेन्टहरू छोडिनेछ, त्यसपछि मेमोरी फ्रि हुनेछ।
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // पहिलो तत्वमा पोइन्टर
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // सबै खाली।गार्ड बिर्सनुहोस् ताकि यसले नयाँ आर्कइन्नरलाई मुक्त गर्दैन।
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` को लागी प्रयोग गरिएको विशेषज्ञता trait।
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// `Arc` सूचकको क्लोन बनाउँछ।
    ///
    /// यसले समान आवंटनमा अर्को सूचक सिर्जना गर्दछ, कडा सन्दर्भ गणनालाई बढाउँदै।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // रिलक्सर्ड अर्डरिंग प्रयोग गर्नु ठीकै छ, किनकि मूल सन्दर्भको ज्ञानले अरू थ्रेडहरूलाई गल्तीले मेटाउन रोक्दछ।
        //
        // [Boost documentation][1] मा वर्णन गरिए अनुसार, सन्दर्भ काउन्टर बढाउने सँधै मेमोरी_अर्डररेक्स्डका साथ गर्न सकिन्छ: कुनै वस्तुमा नयाँ सन्दर्भ केवल विद्यमान सन्दर्भबाट गठन गर्न सकिन्छ, र एउटा थ्रेडबाट अर्कोमा विद्यमान सन्दर्भलाई पास गर्नु अघि नै कुनै आवश्यक समक्रमणलाई प्रदान गर्नुपर्नेछ।
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // यद्यपि हामीले ठूलो रिफ्याक्ट्सबाट सावधानी अपनाउनु पर्छ यदि कोही `मेम: : बिर्सिने आर्क्स छ भने।
        // यदि हामीले यसो गरेनौं भने गणनाले अतिप्रवाह गर्न सक्दछ र प्रयोगकर्ताहरू नि: शुल्क प्रयोगका हुनेछन्।
        // XCX X लाई एक पटक मा संदर्भ गणना बढाउने त्यहाँ ~2 अरब थ्रेड छैन भन्ने धारणामा हामी racily संतृप्त।
        //
        // यो branch कुनै पनि वास्तविक कार्यक्रम मा लिने छैन।
        //
        // हामी रद्द गर्दछौं किनकि त्यस्ता कार्यक्रम अविश्वसनीय रूपमा पतित छ, र हामी यसलाई समर्थन गर्दैनौं।
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// दिइएको `Arc` मा म्यूटेबल सन्दर्भ बनाउँदछ।
    ///
    /// यदि त्यहाँ अन्य `Arc` वा [`Weak`] पोइन्टर्स समान आबंटनमा छन् भने, तब `make_mut` नयाँ आबंटन सिर्जना गर्दछ र अद्वितीय स्वामित्व सुनिश्चित गर्न भित्री मानमा [`clone`][clone] आह्वान गर्दछ।
    /// यसलाई क्लोन-अन-राइटको रूपमा पनि चिनिन्छ।
    ///
    /// नोट गर्नुहोस् कि यो [`Rc::make_mut`] को व्यवहारबाट भिन्न छ जसले कुनै पनि बाँकी `Weak` पोइटरहरूलाई अलग गर्दछ।
    ///
    /// [`get_mut`][get_mut] पनि हेर्नुहोस्, जो क्लोनिंगको सट्टा असफल हुनेछ।
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // केहि क्लोन छैन
    /// let mut other_data = Arc::clone(&data); // भित्री डेटा क्लोन गर्दैन
    /// *Arc::make_mut(&mut data) += 1;         // क्लोनहरू भित्री डेटा
    /// *Arc::make_mut(&mut data) += 1;         // केहि क्लोन छैन
    /// *Arc::make_mut(&mut other_data) *= 2;   // केहि क्लोन छैन
    ///
    /// // अब `data` र `other_data` विभिन्न आबंटनहरु लाई जनाउँछ।
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // नोट गर्नुहोस् कि हामी दुबै एक कडा सन्दर्भ र कमजोर सन्दर्भ राख्छौं।
        // तसर्थ, हाम्रो कडा सन्दर्भ जारी मात्र, मात्र, मेमोरी विलम्ब गर्न को कारण हुनेछ।
        //
        // यो सुनिश्चित गर्नुहोस् कि हामी `weak` मा कुनै पनि लेखहरू देख्दछौं जुन `strong` मा रिलिज हुनुभन्दा अघि (अर्थात् घट्दो) देखिन्छ।
        // किनकि हामीसँग कमजोर गणना छ, त्यसैले आर्कइनेर आफैँ Dealocated हुन सम्भव छैन।
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // अर्को कडा सूचक अवस्थित छ, त्यसैले हामीले क्लोन गर्नु पर्छ।
            // क्लोन गरिएको मान सीधा लेख्न अनुमति दिन पूर्व-बाँडफाड मेमोरी।
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // माथी मा रिलक्स्ड पेसेन्स किनकि यो मौलिक आधारभूत रुपमा एक अनुकूलन हो: हामी सँधै कमजोर पोइन्टर्स छोड्दै दौडिरहेका छौं।
            // सबैभन्दा नराम्रो मामला, हामी अन्त्यमा अनावश्यक रूपमा नयाँ आर्क बाँड्यौं।
            //

            // हामीले अन्तिम कडा रेफ हटायौं, तर त्यहाँ अतिरिक्त कमजोर रेफहरू बाँकी छन्।
            // हामी सामग्रीहरू नयाँ आर्कमा सार्नेछौं, र अन्य कमजोर रेफ्रेसहरूलाई अवैध बनाउँदछौं।
            //

            // नोट गर्नुहोस् कि `weak` को पढाई usize::MAX (जस्तै, लक गरिएको) उत्पादन गर्न सम्भव छैन, किनकि कमजोर गणना मात्र एक मजबूत संदर्भको साथ एउटा थ्रेड द्वारा लक गर्न सकिन्छ।
            //
            //

            // हाम्रो आफ्नै निहित कमजोर सूचकलाई भौतिकीकृत गर्नुहोस्, ताकि यसले आर्कइन्नरलाई आवश्यकता अनुसार सफा गर्न सक्दछ।
            //
            let _weak = Weak { ptr: this.ptr };

            // केवल डाटा चोर्न सक्दछ, खाली सबै Weakks मा छ
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // हामी कुनै पनि प्रकारको एक मात्र सन्दर्भ थिए;बलियो रेफ काउन्ट ब्याक अप बम्प गर्नुहोस्।
            //
            this.inner().strong.store(1, Release);
        }

        // `get_mut()` को रूपमा, असुरक्षित ठीक छ किनभने हाम्रो सन्दर्भ कि त शुरू गर्न अद्वितीय थियो, वा सामग्री क्लोनिंगमा एक भयो।
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// दिईएको `Arc` मा एक परिवर्तनीय सन्दर्भ फर्काउँछ, यदि त्यहाँ समान XO1X वा [`Weak`] सूचकहरू छैन भने।
    ///
    ///
    /// अन्यथा [`None`] फर्काउँछ, किनकि यो सेयर गरिएको मान परिवर्तन गर्न सुरक्षित छैन।
    ///
    /// [`make_mut`][make_mut] पनि हेर्नुहोस्, जुन भित्री मान [`clone`][clone] हुनेछ जब त्यहाँ अन्य सूचकहरू छन्।
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // यो असुरक्षित छ ठीक छ किनभने हामीले ग्यारेन्टी गर्यौं कि सूचक फिर्ता *केवल* पोइन्टर हो जुन कहिले पनि T मा फिर्ता आउनेछ।
            // हाम्रो सन्दर्भ गणना यस बिन्दुमा १ हुने ग्यारेन्टी गरिएको छ, र हामीले आर्क आफैं `mut` हुनु आवश्यक छ, त्यसैले हामी भित्री डाटाको लागि मात्र सम्भव सन्दर्भ फर्काइरहेका छौं।
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// कुनै चेक बिना, दिइएको `Arc` मा एक परिवर्तनीय सन्दर्भ फर्काउँछ।
    ///
    /// [`get_mut`] पनि हेर्नुहोस्, जुन सुरक्षित छ र उपयुक्त जाँच गर्दछ।
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// कुनै पनि अन्य `Arc` वा [`Weak`] पोइन्टर्स समान आबंटनको लागि फिर्ती orrowणको अवधिको लागि सम्मानजनक हुनु हुँदैन।
    ///
    /// यो तुच्छ घटना हो यदि कुनै सूचकहरू अवस्थित छैन, उदाहरणका लागि तुरून्त `Arc::new` पछि।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // हामी "count" फिल्डहरू कभर गर्ने सन्दर्भ सिर्जना गर्न * होन्न भन्ने कुरामा सावधान छौं, किनकि यसले सन्दर्भ गणनामा समवर्ती पहुँचको साथ उपनाम दिन्छ (जस्तै।
        // `Weak` द्वारा)।
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// अन्तर्निहित डेटाको लागि यो अद्वितीय सन्दर्भ हो कि निर्धारण गर्नुहोस् (कमजोर रेफ सहित)।
    ///
    ///
    /// नोट गर्नुहोस् कि यसको लागि कमजोर रेफ गणनालाई लक गर्न आवश्यक छ।
    fn is_unique(&mut self) -> bool {
        // कमजोर पोइन्टर गणनालाई लक गर्नुहोस् यदि हामी एक मात्र कमजोर सूचक होल्डरमा देखा पर्दछौं।
        //
        // यहाँ अधिग्रहण लेबल `strong` (`Weak::upgrade` मा विशेष गरी) `weak` गणना (`Weak::drop` मार्फत, जुन विमोचन प्रयोग गर्दछ) घटाउनु भन्दा पहिले कुनै लेख्नको साथ पहिलेको सम्बन्ध सुनिश्चित गर्दछ।
        // यदि अपग्रेड गरिएको कमजोर रेफ कहिल्यै छोडियो भने, यहाँ सीएएस असफल हुनेछ त्यसैले हामी सिnch्ख्रोनाइजमा परवाह गर्दैनौं।
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // `drop` मा `strong` काउन्टर घटाउनको साथ समिकरण गर्न यो `Acquire` हुनु पर्छ-केवल पहुँच मात्र हुन्छ जब कुनै पनि पछिल्लो सन्दर्भ छोडियो।
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // यहाँ रिलिज लेखन `downgrade` मा एक पठन संग सिंक्रनाइज़ गर्दछ, `strong` को माथिको पठनलाई लेखन पछि हुनबाट रोक्छ।
            //
            //
            self.inner().weak.store(1, Release); // लक जारी गर्नुहोस्
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// `Arc` ड्रप गर्दछ।
    ///
    /// यो मजबूत संदर्भ गणना घटाउनेछ।
    /// यदि कडा सन्दर्भ गणना शून्यमा पुग्छ भने मात्र अन्य सन्दर्भहरू (यदि कुनै छन्) [`Weak`] हुन्, त्यसैले हामी भित्री मान `drop`।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // केहि पनि प्रिन्ट गर्दैन
    /// drop(foo2);   // "dropped!" प्रिन्ट गर्दछ
    /// ```
    #[inline]
    fn drop(&mut self) {
        // किनकि `fetch_sub` पहिले नै परमाणु हो, हामीले अन्य थ्रेडहरूसँग समक्रमण गर्न आवश्यक पर्दैन जबसम्म हामी वस्तु मेटाउँदैनौं।
        // यो समान तर्क `fetch_sub` X गणनामा तल `fetch_sub` मा लागू हुन्छ।
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // यो बारको प्रयोगलाई डाटाको पुन: क्रमबद्ध गर्न र डाटालाई हटाउन रोक्न आवश्यक छ।
        // किनभने यो `Release` चिन्ह लगाइएको छ, सन्दर्भ गणनाको घट्दै यस `Acquire` बाड़सँग सिंक्रनाइज गर्दछ।
        // यसको मतलब डेटाको उपयोग संदर्भ गन्ती घटाउनु अघि घटित हुन्छ, जुन यस फेंस भन्दा पहिले हुन्छ, जुन डेटा मेटाउनु अघि हुन्छ।
        //
        // [Boost documentation][1] मा वर्णन गरिए अनुसार,
        //
        // > यो महत्त्वपूर्ण छ कि कुनै एक वस्तुमा कुनै पनि सम्भावित पहुँचलाई लागू गर्नका लागि
        // > थ्रेड (अवस्थित सन्दर्भ मार्फत)*मेट्नु अघि* हुन
        // > भिन्न थ्रेडमा वस्तु।यो एक "release" द्वारा हासिल गरीएको हो
        // > एक प drop्क्ति ड्रप गरे पछि अपरेसन (वस्तुमा कुनै पहुँच
        // > यस सन्दर्भ मार्फत स्पष्ट रूपमा पहिले हुनुपर्दछ), र एक
        // > "acquire" वस्तु मेटाउनु अघि अपरेसन।
        //
        // विशेष रूपमा, जब आर्कको सामग्रीहरू सामान्यतया अपरिवर्तनीय हुन्छन्, यो शून्य कुरो जस्तो ईन्टेरियर लेख्न सम्भव छ<T>।
        // यो मेटिएको बेलामा म्युटेक्स प्राप्त नभएकोले हामी थ्रेड बीमा थोरैमा लेख्ने बनाउनको लागि यसको सिnch्क्रोनाइजेसन तर्कमा भर पर्न सक्दैनौं।
        //
        //
        // र यो नोट गर्नुहोस् कि यहाँ एक्क्वायर फेंस सम्भवतः एक्क्वायर लोडसँग प्रतिस्थापन गर्न सकिन्छ, जसले अत्यधिक विवादित अवस्थाहरूमा प्रदर्शन सुधार गर्न सक्छ।[2] हेर्नुहोस्।
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// एक कंक्रीट प्रकारमा `Arc<dyn Any + Send + Sync>` डाउनकास्ट गर्न प्रयास गर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// कुनै नयाँ मेमोरी विनियोजन नगरी नयाँ `Weak<T>` निर्माण गर्दछ।
    /// फिर्ता मानमा [`upgrade`] कल गर्दा [`None`] X सँधै दिन्छ।
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// सहयोगी प्रकार डेटा क्षेत्र को बारे मा कुनै assertions बनाएको बिना संदर्भ गणना पहुँच गर्न अनुमति दिन।
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// यस `Weak<T>` द्वारा औंल्याइएको वस्तु `T` मा एक कच्चा सूचक फर्काउँछ।
    ///
    /// सूचक मात्र मान्य हुन्छ यदि त्यहाँ केहि कडा संदर्भहरू छन्।
    /// सूचक dangling, unalign वा [`null`] अन्यथा हुन सक्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // दुबै समान वस्तुलाई औंल्याउँछन्
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // यहाँ बलियोले यसलाई जीवित राख्छ, त्यसैले हामी अझै पनि वस्तु पहुँच गर्न सक्दछौं।
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // तर कुनै होईन।
    /// // हामी weak.as_ptr() गर्न सक्छौं, तर पोइन्टर पहुँच गर्दा अपरिभाषित व्यवहार हुन सक्छ।
    /// // assert_eq! ("हेलो", असुरक्षित {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // यदि सूचक झुकाव छ भने, हामी सीधा पत्र पठाउनेछौं।
            // यो वैध पेलोड ठेगाना हुन सक्दैन, किनकि पेडलोड कम्तिमा आर्कइन्टर (usize) को रूपमा पigned्क्तिबद्ध गरिएको छ।
            ptr as *const T
        } else {
            // सुरक्षा: यदि is_dangling गलत फिर्ता, यदि सूचक dereferencable छ।
            // पेलोड यस बिन्दुमा खसालिन्छ, र हामीले प्रोभेन्सन्स राख्नु पर्छ, त्यसैले कच्चा सूचक हेरफेर प्रयोग गर्नुहोस्।
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// `Weak<T>` खान्छ र यसलाई एक कच्चा सूचकमा बदल्छ।
    ///
    /// यसले कमजोर पोइन्टरलाई एक कच्चा सूचकमा रूपान्तरण गर्दछ, जबकि अझै पनि एक कमजोर सन्दर्भको स्वामित्वको संरक्षण गर्दै (कमजोर गणना यस अपरेशनले परिमार्जन गरिएको छैन)।
    /// यो `Weak<T>` मा [`from_raw`] को साथ फिर्ता बदल्न सकिन्छ।
    ///
    /// [`as_ptr`] को रूपमा सूचकको लक्ष्य पहुँचको समान प्रतिबन्धहरू लागू हुन्छन्।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// [`into_raw`] द्वारा पहिले सिर्जना गरिएको एक कच्चा सूचक `Weak<T>` मा बदल्छ।
    ///
    /// यो सुरक्षित संदर्भ प्राप्त गर्न को लागी प्रयोग गर्न सकिन्छ (पछि [`upgrade`] कल गरेर) वा `Weak<T>` ड्रप गरेर कमजोर गणना Deallocon गर्न।
    ///
    /// यसले एक कमजोर सन्दर्भको स्वामित्व लिन्छ ([`new`] द्वारा सिर्जना गरिएको पोइन्टर्सको अपवाद बाहेक, यीसँग स्वामित्वको केही हुँदैन; विधि अझै पनि तिनीहरूमा काम गर्दछ)।
    ///
    /// # Safety
    ///
    /// सूचक [`into_raw`] बाट उत्पन्न भएको हुनुपर्दछ र अझै पनि यसको सम्भावित कमजोर सन्दर्भको स्वामित्व हुनुपर्दछ।
    ///
    /// यो कल गर्न को लागी कडा गणना गर्न ० लाई अनुमति छ।
    /// जे होस्, यसले हालको कच्चा सूचकको रूपमा प्रतिनिधित्व गरिएको एक कमजोर सन्दर्भको स्वामित्व लिन्छ (कमजोर गणना यस अपरेशनले परिमार्जन गरेको छैन) र त्यसैले यो [`into_raw`] मा अघिल्लो कलको साथ जोडा बनाउनुपर्दछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // अन्तिम कमजोर गणना घटाउनुहोस्।
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // कसरी इनपुट पोइन्टर व्युत्पन्न गरिएको सन्दर्भमा Weak::as_ptr हेर्नुहोस्।

        let ptr = if is_dangling(ptr as *mut T) {
            // यो एक dangling कमजोर छ।
            ptr as *mut ArcInner<T>
        } else {
            // अन्यथा, हामी ग्यारेन्टी भयौं सूचक एक nondangling कमजोर बाट आयो।
            // SAFETY: डाटा_अफसेट कल गर्न सुरक्षित छ, किनकि ptr सन्दर्भको रूपमा एक वास्तविक (सम्भावित छोडियो) T।
            let offset = unsafe { data_offset(ptr) };
            // यसैले हामी सम्पूर्ण RcBox प्राप्त गर्न अफसेटलाई उल्टाउछौं।
            // सुरक्षा: सूचक कमजोर बाट उत्पन्न भयो, त्यसैले यो अफसेट सुरक्षित छ।
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // सुरक्षा: हामीले अब मूल कमजोर सूचक पुन: प्राप्त गरेका छौं, त्यसैले कमजोर सिर्जना गर्न सक्दछौं।
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// `Weak` सूचकलाई एक [`Arc`] मा अपग्रेड गर्न प्रयास, यदि सफल भयो भने भित्री मान छोड्दै ढिलाइ हुन्छ।
    ///
    ///
    /// [`None`] फर्काउँछ यदि भित्री मान पछिदेखि छोडियो।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // सबै बलियो सूचकहरू नष्ट गर्नुहोस्।
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // हामी एक fetch_add को सट्टा मजबूत गणना बढाउन CAS लूप प्रयोग गर्छौं किनकि यस प्रकार्यले सन्दर्भ गणनालाई शून्यबाट कहिल्यै लिन सक्दैन।
        //
        //
        let inner = self.inner()?;

        // आरामदायी लोड किनभने ० को कुनै लेख जुन हामी अवलोकन गर्न सक्दछौं स्थायी रूपमा शून्य अवस्थामा फिल्ड छोड्छ (त्यसैले ० को एक "stale" पढ्नु ठीक छ), र कुनै अन्य मान CAS मार्फत निश्चय गरिन्छ।
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // `Arc::clone` मा टिप्पणीहरू हेर्नुहोस् किन हामी यो गर्छौं (`mem::forget` का लागि)।
            if n > MAX_REFCOUNT {
                abort();
            }

            // आराम विफलताको केसका लागि राम्रो छ किनकि हामीसँग नयाँ राज्यको बारेमा कुनै आशा छैन।
            // सफलताको केस `Arc::new_cyclic` का साथ समिकरण गर्न एक्क्वायर आवश्यक छ, जब भित्री मान `Weak` सन्दर्भहरू पहिले नै सिर्जना गरिसके पछि आरम्भ गर्न सकिन्छ।
            // त्यो अवस्थामा, हामी पूर्ण सुरुवाती मान अवलोकन गर्न अपेक्षा गर्दछौं।
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // शून्य माथि जाँच गरियो
                Err(old) => n = old,
            }
        }
    }

    /// यस विनियोजनमा स poin्केत गर्ने सशक्त (`Arc`) सूचकहरूको संख्या प्राप्त गर्दछ।
    ///
    /// यदि `self` [`Weak::new`] प्रयोग गरी सिर्जना गरिएको हो भने, यसले ० फर्काउँछ।
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// यो आबंटनमा देखाउँदै `Weak` पोइन्टर्सको संख्याको एक अनुमानित हुन्छ।
    ///
    /// यदि `self` [`Weak::new`] प्रयोग गरेर सिर्जना गरिएको हो, वा यदि त्यहाँ बाँकी बलियो सूचकहरू छैनन् भने, यसले ० फर्काउँछ।
    ///
    /// # Accuracy
    ///
    /// कार्यान्वयन विवरणका कारण, फर्काइएको मान १ मा दुबै दिशामा बन्द गर्न सकिन्छ जब अन्य थ्रेडहरूले कुनै पनि `आर्केस वा` कमजोरलाई समान आबंटनमा देखाउँदै हेरफेर गरिरहेका हुन्छन्।
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // जहाँबाट हामीले देख्यौं कि त्यहाँ कम्तिमा एउटा बलियो सूचक थियो कमजोर गणना पढेपछि, हामी जान्दछौं कि अव्यक्त कमजोर संदर्भ (जब कुनै पनि सशक्त सन्दर्भ जीवित छ) अझै कमजोर थियो, हामीले कमजोर गणना अवलोकन गर्‍यौं, र त्यसैले यसलाई सुरक्षित घटाउन सक्छौं।
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// `None` फर्काउँछ जब सूचक झुम्झिरहेको हुन्छ र त्यहाँ कुनै विनियोजित `ArcInner` छैन, (जस्तै जब यो `Weak` `Weak::new` द्वारा सिर्जना गरिएको हो)।
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // हामी एक्सरेक्सन "data" क्षेत्रलाई कभर गर्ने * * सिर्जना गर्न सावधान छौं, किनकि क्षेत्र सँगसँगै उत्परिवर्तन हुन सक्छ (उदाहरणका लागि, यदि अन्तिम `Arc` खसालियो भने डाटा फिल्डलाई ठाउँमा छोडिनेछ)।
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// `true` फर्काउँछ यदि दुई `Weak`s समान आबंटन ([`ptr::eq`] समान) लाई देखाउँदछ, वा यदि दुबै कुनै पनि आवंटनमा इशारा गर्दैन भने (किनभने तिनीहरू `Weak::new()`) को साथ सिर्जना गरिएको हो।
    ///
    ///
    /// # Notes
    ///
    /// किनकि यसले पोइन्टर्स तुलना गर्दछ यसको मतलब यो हो कि `Weak::new()` एक अर्काको बराबरी हुनेछ, यद्यपि उनीहरूले कुनै पनि विनियोजनमा इशारा गर्दैन।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` तुलना गर्दै।
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// `Weak` सूचकको क्लोन बनाउँदछ जुन समान आबंटनमा पोइन्ट गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Arc::clone() मा टिप्पणीहरू हेर्नुहोस् किन यो सुस्त छ।
        // यसले फेच_अड्ड (लकलाई वेवास्ता गर्दै) प्रयोग गर्न सक्दछ किनकि कमजोर गणना मात्र लक गरिएको छ जहाँ *कुनै अन्य* कमजोर सूचकहरू अस्तित्वमा छैनन्।
        //
        // (त्यसोभए हामी त्यस अवस्थामा यो कोड चलाउन सक्दैनौं)।
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Arc::clone() मा टिप्पणीहरू हेर्नुहोस् किन हामी यो गर्छौं (mem::forget का लागि)।
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// मेमोरी विनियोजन नगरी नयाँ `Weak<T>` निर्माण गर्दछ।
    /// फिर्ता मानमा [`upgrade`] कल गर्दा [`None`] X सँधै दिन्छ।
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` सूचक ड्रप गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // केहि पनि प्रिन्ट गर्दैन
    /// drop(foo);        // "dropped!" प्रिन्ट गर्दछ
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // यदि हामीले पत्ता लगायौं कि हामी अन्तिम कमजोर सूचकहरू थियौं, तब डाटा पूर्ण रूपमा डिलोकेट गर्ने समय हो।Arc::drop() मा मेमोरी अर्डरिंगको बारेमा छलफल हेर्नुहोस्
        //
        // यहाँ ताल्चा लगाइएको अवस्था जाँच गर्नु आवश्यक छैन किनकि कमजोर गणना मात्र लक गर्न सकिन्छ यदि त्यहाँ एक मात्र कमजोर रेफ छ भने, जसको अर्थ ड्रप मात्र बाँकी रहेको कमजोर रेफमा चल्न सक्छ, जुन केवल लकको विमोचन पछि मात्र हुन सक्छ।
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// हामी यहाँ यो विशेषज्ञता गरिरहेका छौं, र `&T` मा अधिक सामान्य अनुकूलनको रूपमा होइन, किनभने यसले अन्यथा सबै रेफ्रेसमा सबै समानता जाँचमा लागत थप्न सक्छ।
/// हामी मान्दछौं कि `Arc`s ठूला मानहरू भण्डारण गर्न प्रयोग गरिन्छ, जुन क्लोन गर्न ढिलो हुन्छ, तर समानताको लागि जाँच्न पनि गाह्रो हुन्छ, जसले गर्दा यो लागत अधिक सजीलो भुक्तान हुन्छ।
///
/// योसँग दुई `Arc` क्लोन हुने सम्भावना पनि छ, समान मानमा दुई `&T`s भन्दा बढि।
///
/// हामी केवल तब गर्न सक्दछौं जब `T: Eq` `PartialEq` को रूपमा जानाजानी अपूरणीय हुन सक्छ।
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// दुई `Arc`s को लागि समानता।
    ///
    /// दुई `Arc`s बराबर छन् यदि उनीहरूको भित्री मानहरू बराबर छन् भने पनि तिनीहरू फरक आवंटनमा भण्डार गरिएको छ।
    ///
    /// यदि `T` ले `Eq` (समानताको अपवर्तनशीलता) लाई पनि लागू गर्दछ भने, दुई आर्कहरू जुन समान आबोलनमा विन्दु हुन्छ सधैं समान हुन्छन्।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// दुई `Arc`s को लागि असमानता।
    ///
    /// दुई `आर्क असमान छन् यदि उनीहरूको भित्री मानहरू असमान छन्।
    ///
    /// यदि `T` ले `Eq` (समानताको अपवर्तनशीलता) लागू गर्दछ भने, दुई `आर्क` जुन समान मानमा पोइन्ट गर्दछ कहिले पनि असमान हुँदैन।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// दुई `Arc`s का लागि आंशिक तुलना।
    ///
    /// दुईको आन्तरिक मानहरूमा `partial_cmp()` कल गरेर तुलना गरिएको छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// दुई `आर्कको लागि तुलना भन्दा कम।
    ///
    /// दुईको आन्तरिक मानहरूमा `<` कल गरेर तुलना गरिएको छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'भन्दा कम वा बराबर' दुई `अर्कको लागि तुलना।
    ///
    /// दुईको आन्तरिक मानहरूमा `<=` कल गरेर तुलना गरिएको छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// दुई `आर्कसको लागि भन्दा ठूलो।
    ///
    /// दुईको आन्तरिक मानहरूमा `>` कल गरेर तुलना गरिएको छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// '`भन्दा ठूलो वा बराबर' दुई` आर्कको लागि तुलना।
    ///
    /// दुईको आन्तरिक मानहरूमा `>=` कल गरेर तुलना गरिएको छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// दुई `Arc`s का लागि तुलना।
    ///
    /// दुईको आन्तरिक मानहरूमा `cmp()` कल गरेर तुलना गरिएको छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// `T` का लागि `Default` मानको साथ, नयाँ `Arc<T>` सिर्जना गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// सन्दर्भ-गणना स्लाइस आवंटित गर्नुहोस् र cl v` को आईटमहरू क्लोनिंग गरेर भर्नुहोस्।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// सन्दर्भ-गणना `str` आवंटित गर्नुहोस् र यसमा `v` प्रतिलिपि गर्नुहोस्।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// सन्दर्भ-गणना `str` आवंटित गर्नुहोस् र यसमा `v` प्रतिलिपि गर्नुहोस्।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// एक बाकस गरिएको वस्तुलाई नयाँ, सन्दर्भ-गणना गणनामा सार्नुहोस्।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// सन्दर्भ-गणना स्लाइस आवंटित गर्नुहोस् र यसमा `v` वस्तुहरू सार्नुहोस्।
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Vec लाई यसको मेमोरी खाली गर्न अनुमति दिनुहोस्, तर यसको सामग्रीहरू नष्ट नगर्नुहोस्
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// प्रत्येक तत्व `Iterator` मा लिन्छ र यसलाई `Arc<[T]>` मा संकलन गर्दछ।
    ///
    /// # प्रदर्शन विशेषताहरु
    ///
    /// ## सामान्य मामला
    ///
    /// सामान्य अवस्थामा, `Arc<[T]>` मा संकलन `Vec<T>` X मा पहिले स first्कलन गरेर गरिन्छ।त्यो हो, जब निम्नलिखित लेखन:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// यो यस्तो लेख्छ कि हामीले लेखेका छौं:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // विनियोजनको पहिलो सेट यहाँ हुन्छ।
    ///     .into(); // `Arc<[T]>` को लागी दोस्रो आव्हान यहाँ हुन्छ।
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// यो `Vec<T>` निर्माण गर्न को लागी धेरै पटक आबोलित गर्दछ र त्यसपछि यो `Vec<T>` लाई `Arc<[T]>` मा बदल्नको लागि एक पटक आवंटित हुनेछ।
    ///
    ///
    /// ## ज्ञात लम्बाइका आईटेटरहरू
    ///
    /// जब तपाईंको `Iterator` ले `TrustedLen` लागू गर्दछ र सही आकारको छ, एक एकल विनियोजन `Arc<[T]>` को लागि गरिन्छ।उदाहरण को लागी:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // यहाँ एकल विनियोजन हुन्छ।
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// विशेषज्ञता trait `Arc<[T]>` मा संकलनको लागि प्रयोग।
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // यो एक `TrustedLen` पुनरावृत्तिको लागि केस हो।
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // सुरक्षा: हामीले यो सुनिश्चित गर्नु पर्छ कि पुनरावृत्तिको ठीक लम्बाई छ र हामीसँग छ।
                Arc::from_iter_exact(self, low)
            }
        } else {
            // सामान्य कार्यान्वयनमा फर्कनुहोस्।
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// सूचकको पछिल्लो पेलोडको लागि `ArcInner` भित्र अफसेट पाउनुहोस्।
///
/// # Safety
///
/// सूचकले (र वैध मेटाडेटाको लागि) T को पहिलेको वैध उदाहरणलाई सूचित गर्नुपर्दछ, तर T लाई छोड्न अनुमति दिइन्छ।
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // अर्कइन्नरको अन्त्यमा असुरक्षित मान प Al्क्तिबद्ध गर्नुहोस्।
    // किनभने RcBox repr(C) हो, यो मेमोरीमा सधैं अन्तिम फिल्ड हुनेछ।
    // सुरक्षा: किनभने केवल असमर्थित प्रकारहरू स्लाइसहरू, trait वस्तुहरू हुन्,
    // र बाह्य प्रकारहरू, इनपुट सुरक्षा आवश्यकता हाल align_of_val_raw को आवश्यकताहरू पूरा गर्न पर्याप्त छ;यो भाषाको कार्यान्वयन विवरण हो जुन std बाहिरमा भर पर्न सक्दैन।
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}