#![stable(feature = "wake_trait", since = "1.51.0")]
//! प्रकार र Traits एसिन्क्रोनस कार्यहरूको साथ कामका लागि।
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// एक कार्यकारीकर्तामा कार्य उठाउने कार्यको कार्यान्वयन।
///
/// यो trait [`Waker`] सिर्जना गर्न प्रयोग गर्न सकिन्छ।
/// एक कार्यवाहकले यस trait को कार्यान्वयन परिभाषित गर्न सक्दछ, र त्यो प्रयोगकर्तामा कार्यान्वयन हुने कार्यहरूमा पास गर्न एक बेकर निर्माण गर्न प्रयोग गर्दछ।
///
/// यो trait एक [`RawWaker`] निर्माण गर्न मेमोरी सेफ र एर्गोनोमिक विकल्प हो।
/// यसले सामान्य कार्यवाहक डिजाइनलाई समर्थन गर्दछ जहाँ कार्य जगाउन प्रयोग गरिएको डाटा [`Arc`] मा भण्डारण हुन्छ।
/// केहि एक्जिक्युटर्स (विशेष गरी एम्बेडेड प्रणालीहरूको लागि) ले यो एपीआई प्रयोग गर्न सक्दैन, किनकी [`RawWaker`] ती प्रणालीहरूको विकल्पको रूपमा अवस्थित छ।
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// आधारभूत `block_on` प्रकार्य जसले future लिन्छ र यसलाई हालको थ्रेडमा पूरा हुनका लागि चलाउँदछ।
///
/// **Note:** यस उदाहरणले सरलताको लागि सहि ट्रेड गर्दछ।
/// डेडलक्सलाई रोक्नको लागि, उत्पादन-ग्रेड कार्यान्वयनले `thread::unpark` मा नेमीटेड आमन्त्रनको लागि मध्यवर्ती कलहरू पनि ह्यान्डल गर्न आवश्यक पर्दछ।
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// कल गरिएको जब हालको थ्रेड उठ्ने एक बेकर।
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// हालको थ्रेडमा पूरा गर्न future चलाउनुहोस्।
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // future पिन गर्नुहोस् ताकि यसलाई पोल गर्न सकिन्छ।
///     let mut fut = Box::pin(fut);
///
///     // future मा पारित गर्नका लागि नयाँ सन्दर्भ सिर्जना गर्नुहोस्।
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // पूरा गर्न future चलाउनुहोस्।
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// यस कार्यलाई उठाउनुहोस्।
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// बेकर उपभोग नगरी यस कार्यलाई उठाउनुहोस्।
    ///
    /// यदि एक कार्यवाहकले बेकरको उपभोग नगरी उठ्ने सस्तो तरीका समर्थन गर्दछ भने, यो विधिलाई ओभरराइड गर्नुपर्दछ।
    /// पूर्वनिर्धारितद्वारा, यसले [`Arc`] क्लोन गर्दछ र क्लोनमा [`wake`] कल गर्दछ।
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // सुरक्षा: यो सुरक्षित छ किनभने Raw_waker सुरक्षित रूपमा निर्माण गर्दछ
        // आर्क बाट एक RawWaker<W>।
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: RawWaker निर्माणको लागि यो निजी प्रकार्यको सट्टा प्रयोग गरिन्छ
// `From<Arc<W>> for RawWaker` impl मा इनलाइनिंग गर्दै, `From<Arc<W>> for Waker` को सुरक्षा सही trait प्रेषणमा निर्भर गर्दैन भनेर निश्चित गर्न, सट्टामा दुबै ईम्प्लेक्सले यस प्रकार्यलाई सिधा र स्पष्ट कल गर्दछ।
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // आर्कको क्लोन गर्न सन्दर्भ गणना बढाउनुहोस्।
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // मान द्वारा उठ्नुहोस्, आर्कलाई Wake::wake प्रकार्यमा सार्दै
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // सन्दर्भ द्वारा उठ्नुहोस्, Waker लाई म्यानुअल ड्रपमा बेर्नुहोस् यसलाई छोड्ने होईन
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // ड्रपमा आर्कको संदर्भ गणना घटाउनुहोस्
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}