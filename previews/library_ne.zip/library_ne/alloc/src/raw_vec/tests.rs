use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // तेस्रो-पक्ष आबंटकहरू र `RawVec` को बीचको एकीकरणको परीक्षण लेख्नु एक सानो कुरा हो किनभने `RawVec` एपीआई ले फोलिबल आबंटन विधिहरूलाई पर्दाफास गर्दैन, त्यसैले हामी कहिले जाँच्न सक्दैनौं कि कहिले आवंटक समाप्त हुन्छ (panic पत्ता लगाउनु भन्दा पर)।
    //
    //
    // यसको सट्टामा, यसले `RawVec` विधिहरू कम से कम Allocator एपीआई मार्फत जान्छ जब यो भण्डारण भण्डार गर्दछ भनेर जाँच गर्दछ।
    //
    //
    //
    //
    //

    // एक गूंगा आवंटक जसले विनियोजन प्रयासहरू असफल हुनु अघि एक निश्चित मात्रामा ईन्धन खपत गर्दछ।
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (एक realloc कारण, यसैले fuel० + १=०=२०० ईन्धनको ईन्धनको प्रयोग गरेर)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // पहिले, `reserve` `reserve_exact` जस्तै आवंटित।
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 7 को भन्दा दोब्बर हो, त्यसैले `reserve` `reserve_exact` जस्तै काम गर्नु पर्छ।
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 12 १२ को आधा भन्दा कम हो, त्यसैले `reserve` द्रुत रूपमा बढ्नु पर्छ।
        // यस परीक्षण लेख्नको समयमा कारक २ बढ्दो छ, त्यसैले नयाँ क्षमता २ is हो, तथापि, 1.5 को वृद्धि कारक पनि ठीक छ।
        //
        // त्यसैले सम्मिलितमा `>= 18`।
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}