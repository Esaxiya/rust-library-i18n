use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// सम्भावित अन्डरफुल नोड स्टक गर्दछ एक भाईको साथ मर्ज गरेर वा चोरी गरेर।
    /// यदि सफल भए पनि प्यारेन्ट नोडलाई संकुचन गर्ने लागतमा, त्यो प्यारेन्ट नोडलाई सunk्कलन गर्दछ।
    /// यदि नोड खाली रूट हो भने `Err` फर्काउँछ।
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// एक सम्भावित अन्डरफुल नोड स्टक गर्दछ, र यदि त्यसले यसको अभिभावक नोड सिक्दछ भने, अभिभावकलाई पुनरावर्तन गर्दछ।
    /// `true` फर्काउँदछ यदि यसले रूखलाई मिलायो भने, `false` यदि यो सकेन किनकि रूट नोड खाली भयो।
    ///
    /// यस विधिले पूर्वजहरूलाई प्रवेश र panics मा पहिले नै अन्डरफुल भएको आशा गर्दैन यदि यदि यो खाली पूर्वजसँग भेट भयो भने।
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// शीर्षमा खाली स्तरहरू हटाउँछ, तर खाली पात राख्छ यदि सम्पूर्ण रूख खाली छ।
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// स्टक अप वा रूखको दायाँ सीमानामा कुनै पनि अन्डरफुल नोडहरू मर्ज गर्नुहोस्।
    /// अन्य नोडहरू, ती जो मूल वा सही edge छैनन्, पहिले नै कम्तिमा MIN_LEN तत्त्वहरू हुनुपर्दछ।
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// `fix_right_border` को सममित क्लोन।
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// रूखको दायाँ सीमानामा कुनै पनि अन्डरफुल नोडहरू स्टक गर्नुहोस्।
    /// अन्य नोडहरू, ती जो मूल र सही edge छैनन्, मा MIN_LEN तत्त्वहरू चोरी गर्न तयार हुनुपर्दछ।
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // दाँया-सबैभन्दा बच्चाहरू अन्डरफुल छ कि छैन जाँच गर्नुहोस्।
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // हामीले चोर्नु पर्छ।
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // अगाडि तल जानुहोस्।
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// बायाँ बच्चालाई स्टक गर्दछ, दाँया बच्चा अनगर्ती नभएको मानेर, र यसले आफ्नो बच्चाहरूलाई अन्डरफुल नहुँदा मर्ज गर्न अनुमति दिन थप तत्व प्रदान गर्दछ।
    ///
    /// बाँया बच्चा फर्काउँछ।
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` यदि समायोजन पछिल्लो स्तरमा भयो भने समायोजनबाट बच्न।
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// दायाँ बच्चाहरुको स्टक गर्छ, मानेर बायाँ बच्चा अन्डरफुल छैन, र थप तत्वको प्रावधान गर्दछ यसको बच्चाहरूलाई अन्डरफुल नहुँदा बदली गर्न अनुमति दिन।
    ///
    /// जहाँ सही बच्चाको अन्त्य भयो जहाँ फिर्ता हुन्छ।
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` यदि समायोजन पछिल्लो स्तरमा भयो भने समायोजनबाट बच्न।
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}