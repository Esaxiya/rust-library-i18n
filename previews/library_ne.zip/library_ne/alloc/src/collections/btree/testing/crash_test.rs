use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// क्र्यास टेस्ट डमी ईन्स्ट्यान्सका लागि ब्लूप्रिन्ट जसले विशेष घटनाहरूको अनुगमन गर्छ।
/// केही उदाहरणहरू केहि बिन्दुमा panic मा कन्फिगर गर्न सकिन्छ।
/// घटनाहरू `clone`, `drop` वा केही अज्ञात `query` हुन्।
///
/// क्र्यास टेस्ट डमीहरू पहिचान गरीन्छन् र एक आईडी मार्फत अर्डर गरिन्छ, त्यसैले उनीहरूलाई BTreeMap मा कुञ्जीको रूपमा प्रयोग गर्न सकिन्छ।
/// XMLX trait को अलावा, कार्यान्वयनले जानाजानी प्रयोग गर्ने crate मा परिभाषित केहिमा निर्भर हुँदैन।
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// क्र्यास परीक्षण डमी डिजाइन सिर्जना गर्दछ।`id` आदेश र उदाहरणहरूको समानता निर्धारित गर्दछ।
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// क्र्यास टेस्ट डमीको एक घटना सिर्जना गर्दछ जसले यसले अनुभव गर्दछ घटनाहरूको र वैकल्पिक panics रेकर्ड गर्दछ।
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// फर्कन्छ कति पटक डमीका उदाहरणहरू क्लोन गरियो।
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// फर्कन्छ कति पटक डमीका घटनाहरू छोडियो।
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// फर्कन्छ कति पटक डमीका उदाहरणहरूमा `query` X सदस्य बोलाइएको छ।
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// केहि बेनामी क्वेरी, जसको नतीजा पहिले नै दिइएको छ।
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}