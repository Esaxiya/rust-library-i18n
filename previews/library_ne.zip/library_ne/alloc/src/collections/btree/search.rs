use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// `Bound::Included(T)` जस्तै, हेर्नको लागि समावेशी बाध्य।
    Included(T),
    /// `Bound::Excluded(T)` जस्तै, हेर्नका लागि एक विशेष बाउन्ड।
    Excluded(T),
    /// एक बिना शर्त समावेशी बाउन्ड, `Bound::Unbounded` जस्तै।
    AllIncluded,
    /// एक शर्त बिनाको सीमा।
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// नोडको नेतृत्वमा (उप) रूखमा दिइएको कुञ्जी माथि देखिन्छ, रिकर्सिभली।
    /// मिल्दो KV को ह्यान्डलको साथ `Found` फर्काउँछ, यदि कुनै छ भने।
    /// अन्यथा, कुञ्जी सम्बन्धित पाना edge को ह्यान्डलको साथ एक `GoDown` फर्काउँछ।
    ///
    /// परिणाम मात्र अर्थपूर्ण हुन्छ यदि रूख कुञ्जी द्वारा अर्डर गरिएको छ, जस्तै `BTreeMap` मा रूख हो।
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// नजिकको नोडमा तल झर्छ जहाँ edge दायराको तल्लो सीमासँग मेल खान्छ edge अपर बाउन्डसँग मिल्दोजुल्दो छ, अर्थात नजिकको नोड जुन दायरामा कम से कम एउटा कुञ्जी समावेश गर्दछ।
    ///
    ///
    /// यदि फेला पर्‍यो भने त्यो X नोडको साथ `Ok` फर्काउँछ, यसमा edge सूचकांकको जोडी, दायरा को सीमा बनाउँछ, र बच्चा नोडमा खोजी जारी राख्नका लागि सीमाको अनुरूप जोडी, यदि नोड आन्तरिक हो भने।
    ///
    /// यदि फेला परेन भने,`Err` फिर्ता edge सम्पूर्ण दायरासँग मिल्छ।
    ///
    /// परिणाम केवल तब अर्थपूर्ण हुन्छ यदि रूख कुञ्जी द्वारा अर्डर गरिएको छ।
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // यी भ्यारीएबलहरू इनलाइन गर्नबाट बच्नुपर्दछ।
        // हामी मानौं `range` द्वारा रिपोर्ट गरिएको सीमा एक समान रहन्छ, तर एक adversarial कार्यान्वयन (#81138) कल बीच बदल्न सक्छ।
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// एक दायरा को तल्लो सीमा सीमांकित नोड मा एक edge फेला पार्छ।
    /// मिल्दो चाइल्ड नोडमा खोजी जारी राख्नका लागि प्रयोग गरिने तल्लो बाउन्डलाई पनि फर्काउँछ, यदि `self` आन्तरिक नोड हो भने।
    ///
    ///
    /// परिणाम केवल तब अर्थपूर्ण हुन्छ यदि रूख कुञ्जी द्वारा अर्डर गरिएको छ।
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// माथिल्लो बाउन्डको लागि `find_lower_bound_edge` को क्लोन।
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// नोडमा दिइएको कुञ्जीलाई पुनरावृत्ति बिना नै देख्दछ।
    /// मिल्दो KV को ह्यान्डलको साथ `Found` फर्काउँछ, यदि कुनै छ भने।
    /// अन्यथा, edge को ह्यान्डलको साथ `GoDown` फर्काउँदछ जहाँ कुञ्जी फेला पर्न सक्दछ (यदि नोड आन्तरिक हो भने) वा जहाँ कुञ्जी घुसाउन सकिन्छ।
    ///
    ///
    /// परिणाम मात्र अर्थपूर्ण हुन्छ यदि रूख कुञ्जी द्वारा अर्डर गरिएको छ, जस्तै `BTreeMap` मा रूख हो।
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// या त नोडमा KV अनुक्रमणिका फर्काउँछ जुन कुञ्जी (वा समतुल्य) अवस्थित हुन्छ, वा edge अनुक्रमणिका जहाँ कुञ्जी सम्बन्धित छ।
    ///
    ///
    /// परिणाम मात्र अर्थपूर्ण हुन्छ यदि रूख कुञ्जी द्वारा अर्डर गरिएको छ, जस्तै `BTreeMap` मा रूख हो।
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// दायराको तल्लो सीमाको सीमा नोडमा edge अनुक्रमणिका फेला पार्दछ।
    /// मिल्दो चाइल्ड नोडमा खोजी जारी राख्नका लागि प्रयोग गरिने तल्लो बाउन्डलाई पनि फर्काउँछ, यदि `self` आन्तरिक नोड हो भने।
    ///
    ///
    /// परिणाम केवल तब अर्थपूर्ण हुन्छ यदि रूख कुञ्जी द्वारा अर्डर गरिएको छ।
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// माथिल्लो बाउन्डको लागि `find_lower_bound_index` को क्लोन।
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}