// यो आदर्श पछिको कार्यान्वयनको प्रयास हो
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Rust वास्तवमै निर्भर प्रकारहरू र बहुरूपिक पुनरावृत्तिहरू नभएकोले हामी असुरक्षाको साथ धेरै काम गर्छौं।
//

// यस मोड्युलको प्रमुख लक्ष्य रूखलाई जेनेरिक (यदि अजीब आकारको छ भने) कन्टेनरको रूपमा व्यवहार गरेर र अधिकतर बी-रूख इन्भिएन्टहरूसँग व्यवहार नगर्न जटिलताबाट बच्न हो।
//
// त्यस्तै, यस मोड्युलले मतलब गर्दैन कि प्रविष्टिहरू क्रमबद्ध गरिएको छ, कुन नोडहरू अण्डरफुल हुन सक्छन्, वा अण्डरफुलको अर्थ के हो।यद्यपि हामी केहि आक्रमणकारीहरूमा भर पर्दछौं:
//
// - रूखहरूसँग एकसमान depth/height हुनुपर्दछ।यसको मतलब यो हो कि दिइएको नोडबाट पातमा तल प्रत्येक बाटोको उहि लम्बाई छ।
// - `n` लम्बाइको नोडमा `n` कुञ्जीहरू, `n` मानहरू, र `n + 1` किनारहरू छन्।
//   यसले स that्केत गर्दछ कि खाली नोडमा पनि कम्तिमा एउटा edge छ।
//   पात नोडका लागि, "having an edge" को मतलब केवल हामी नोडमा स्थिति पहिचान गर्न सक्दछौं, किनकि पातको किनाराहरू खाली छन् र डाटा प्रतिनिधित्वको आवश्यकता पर्दैन।
// एक आन्तरिक नोडमा, edge दुबै स्थिति पहिचान गर्दछ र बच्चा नोडमा सूचक समावेश गर्दछ।
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// पात नोडहरूको अन्तर्निहित प्रतिनिधित्व र आन्तरिक नोड्सको प्रतिनिधित्वको अंश।
struct LeafNode<K, V> {
    /// हामी `K` र `V` मा कोभेरियन्ट हुन चाहन्छौं।
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// यस नोडको अनुक्रमणिका प्यारेन्ट नोडको `edges` एर्रेमा।
    /// `*node.parent.edges[node.parent_idx]` `node` को समान चीज हुनु पर्छ।
    /// यो केवल आरम्भ गर्न ग्यारेन्टी गरिएको छ जब `parent` गैर-शून्य हो।
    parent_idx: MaybeUninit<u16>,

    /// यस नोड स्टोरहरूले कुञ्जी र मानहरूको संख्या।
    len: u16,

    /// एर्रे नोडको वास्तविक डाटा भण्डारण गर्दछ।
    /// प्रत्येक एर्रेको केवल पहिलो `len` एलिमेन्ट आरम्भ र मान्य हुन्छन्।
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// ठाउँमा नयाँ `LeafNode` सुरू गर्दछ।
    unsafe fn init(this: *mut Self) {
        // सामान्य नीतिको रूपमा, हामी फिल्डहरूलाई अनावश्यक रूपमा छोड्छौं यदि तिनीहरू हुन सक्छन् भने, किनकि यो दुबै छिटो र सजिलो हुनुपर्दछ Valgrind मा ट्र्याक गर्न।
        //
        unsafe {
            // प्यारेन्ट_आईडीएक्स, कुञ्जीहरू, र वालहरू सबै मेयोयूनिट हुन्
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// नयाँ बाकस गरिएको `LeafNode` सिर्जना गर्दछ।
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// आन्तरिक नोडहरूको अन्तर्निहित प्रतिनिधित्व।`LeafNode`s को रूपमा जस्तै, यी it BoxedNode`s पछाडि लुकाउनुपर्दछ निर्बाध कुञ्जी र मान छोड्ने रोक्नको लागि।
/// `InternalNode` मा कुनै पनि पोइन्टर सिधा सूचकमा नोडको अन्तर्निहित `LeafNode` भागमा कास्ट गर्न सकिन्छ, कोडलाई पात र आन्तरिक नोडहरूमा कार्य गर्न अनुमति दिईन्छ जसमा दुई मध्ये कुन सूचक देखाउदै छ।
///
/// यो गुण `repr(C)` को उपयोग द्वारा सक्षम गरिएको छ।
///
#[repr(C)]
// gdb_providers.py आत्मपरीक्षणको लागि यस प्रकारको नाम प्रयोग गर्दछ।
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// यस नोडका बच्चाहरूलाई पोइन्टर्स।
    /// `len + 1` यी मध्येको शुरुको र मान्य मानिन्छ, अन्तको नजिकको बाहेक, जब रूख orrowण प्रकारको `Dying` मार्फत समातिन्छ, यी सूचकहरू केहि झुकाउँदै छन्।
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// नयाँ बाकस गरिएको `InternalNode` सिर्जना गर्दछ।
    ///
    /// # Safety
    /// आन्तरिक नोड्सको एक इन्भिएन्ट यो छ कि उनीहरूसँग कम्तिमा एक आरम्भिक र मान्य edge छ।
    /// यो प्रकार्य यस्तो edge सेट अप गर्दैन।
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // हामीले केवल डाटा आरम्भ गर्न आवश्यक छ;किनारहरु सम्भव हुन।
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// नोडमा एक व्यवस्थित, नन-नल पोइन्टर।यो या त `LeafNode<K, V>` को स्वामित्व प्राप्त सूचक वा `InternalNode<K, V>` मा स्वामित्व प्राप्त सूचक हो।
///
/// यद्यपि `BoxedNode` ले कुन जानकारीका दुई प्रकारका नोडहरू वास्तवमा समावेश गर्दछ भनेर समावेश गर्दैन, र आंशिक रूपमा जानकारीको अभावका कारण यो छुट्टै प्रकारको छैन र यसमा कुनै विध्वंसक छैन।
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// स्वामित्वको रूखको जड नोड।
///
/// नोट गर्नुहोस् कि यससँग डिस्ट्रक्टर छैन, र म्यानुअल रूपमा सफा हुनै पर्छ।
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// नयाँ स्वामित्वको रूख फर्काउँछ, यसको आफ्नै रूट नोडको साथ जुन सुरुमा खाली छ।
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` शून्य हुनु हुँदैन।
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Mutally स्वामित्वको जड़ नोड उधारो लिन्छ।
    /// `reborrow_mut` विपरीत, यो सुरक्षित छ किनभने फिर्ती मानले रूटलाई नष्ट गर्न सक्दैन, र रूखमा अन्य सन्दर्भहरू हुन सक्दैन।
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// थोरै म्युटेलीली स्वामित्वको जड नोड उधारो लिन्छ।
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// सान्दर्भिक रूपमा सन्दर्भमा ट्रान्जिसन जुन ट्रभर्सललाई अनुमति दिन्छ र विनाशकारी विधिहरू प्रदान गर्दछ र अन्य थोरै।
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// एकल edge को साथ अघिल्लो मूल नोडमा देखाउँदै नयाँ आन्तरिक नोड थप्दछ, त्यो नयाँ नोडलाई रूट नोड बनाउनुहोस्, र यसलाई फिर्ता गर्नुहोस्।
    /// यसले उचाई १ ले बढाउँदछ र `pop_internal_level` को विपरित हो।
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, बाहेक हामीले भर्खरै बिर्सेका छौं हामी अब आन्तरिक हो:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// आन्तरिक मूल नोड हटाउँदछ, नयाँ मूल नोडको रूपमा पहिलो बच्चा प्रयोग गरेर।
    /// यो केवल कल गर्न भनिन्छ जब मूल नोडको मात्र एक बच्चा हुन्छ, कुनै पनि कुञ्जी, मानहरू र अन्य बालबालिकाहरूमा कुनै सफाई हुँदैन।
    ///
    /// यो उचाई १ ले घट्छ र `push_internal_level` को विपरित हो।
    ///
    /// `Root` वस्तुमा विशेष पहुँच आवश्यक छ तर मूल नोडमा होइन;
    /// यसले अन्य ह्यान्डलहरू वा मूल नोडको सन्दर्भलाई अवैध गर्दैन।
    ///
    /// Panics यदि कुनै आन्तरिक स्तर छैन, उदाहरणका लागि, यदि मूल नोड एक पात हो भने।
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // सुरक्षा: हामी आन्तरिक हुन जोड दिए।
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // सुरक्षा: हामीले `self` विशेष रूपमा लिएको छ र यसको itsण प्रकार विशेष छ।
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // सुरक्षा: पहिलो edge सधैं सुरूवात हुन्छ।
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` `K` र `V` मा जहिले पनि कोभेरियन्ट हुन्छ, `BorrowType` `Mut` हुँदा पनि।
// यो प्राविधिक रूपमा गलत छ, तर `NodeRef` को आन्तरिक प्रयोगको कारण कुनै असुरक्षितमा परिणाम दिन सक्दैन किनकि हामी `K` र `V` मा पूर्ण रूपमा सामान्य रहन्छौं।
//
// जे होस्, जब पनि सार्वजनिक प्रकारले `NodeRef` लपेट्छ, निश्चित गर्नुहोस् कि यससँग सही भिन्नता छ।
//
/// नोडको सन्दर्भ।
///
/// यस प्रकारको धेरै प्यारामिटरहरू छन् जुन यसले कसरी कार्य गर्दछ नियन्त्रण गर्दछ:
/// - `BorrowType`: एक डमी प्रकारले orrowणको प्रकार वर्णन गर्दछ र जीवनभर बोक्छ।
///    - जब यो `Immut<'a>` हो, `NodeRef` लगभग `&'a Node` जस्तै कार्य गर्दछ।
///    - जब यो `ValMut<'a>` हो, `NodeRef` लगभग `&'a Node` जस्तै कुञ्जीहरू र रूखहरूको संरचनाको सन्दर्भमा कार्य गर्दछ, तर रूख भरि मानहरूको लागि धेरै परिवर्तनशील सन्दर्भहरू सँगसँगै रहन अनुमति दिन्छ।
///    - जब यो `Mut<'a>` हो, `NodeRef` लगभग `&'a mut Node` जस्तो कार्य गर्दछ, जबकि घुसाउने विधिहरूले एक म्युटेबल पोइन्टरलाई सहि अस्तित्वमा रहन अनुमति दिन्छ।
///    - जब यो `Owned` हो, `NodeRef` लगभग `Box<Node>` जस्तो कार्य गर्दछ, तर यसको डिस्ट्रक्टर छैन, र म्यानुअल रूपमा सफा गर्नुपर्दछ।
///    - जब यो `Dying` हो, `NodeRef` ले अझै `Box<Node>` जस्तो करीव कार्य गर्दछ, तर बिट बिट बिस्तार गर्ने विधिहरू छन्, र साधारण विधिहरू, कल गर्न असुरक्षितको रूपमा चिन्ह लगाइएको छैन भने, UB लाई बोलाउन सक्छ यदि गलत भनिन्छ।
///
///   कुनै पनि `NodeRef` रूखको माध्यमबाट नेभिगेट गर्न अनुमति दिन्छ, `BorrowType` प्रभावी ढंगले नोडमा मात्र होइन सम्पूर्ण रूखमा लागू हुन्छ।
/// - `K` र `V`: यी कुञ्जीहरू र मानहरूको नोडहरूमा भण्डार गरिएका हुन्।
/// - `Type`: यो `Leaf`, `Internal`, वा `LeafOrInternal` हुन सक्छ।
/// जब यो `Leaf` हुन्छ, `NodeRef` एक पात नोडमा देखाउँदछ, जब यो `Internal` हुन्छ `NodeRef` आन्तरिक नोडमा पोइन्ट गर्दछ, र जब यो `LeafOrInternal` हुन्छ `NodeRef` या त नोडको प्रकारलाई सूचित गर्दछ।
///   `Type` `NodeType` नाम गरिएको छ जब `NodeRef` बाहिर प्रयोग गरियो।
///
/// दुबै `BorrowType` र `NodeType` स्थिर लागू सुरक्षा को शोषण गर्न, हामी लागू गर्ने केहि विधाहरु प्रतिबन्धित गर्दछ।त्यहाँ त्यस्तो सीमितताहरू छन् जुन हामी त्यस्ता प्रतिबन्धहरूलाई लागू गर्न सक्छौं:
/// - प्रत्येक प्रकारको प्यारामिटरको लागि, हामी केवल एक तरीका परिभाषित गर्न सक्छौं या त सामान्य रूपमा वा एक विशेष प्रकारको लागि।
/// उदाहरणका लागि, हामी `into_kv` जस्ता विधिलाई सबै `BorrowType` का लागि परिभाषित गर्न सक्दैनौं, वा जीवनकालमा बोक्ने सबै प्रकारका लागि एक पटक, किनकि हामी यसलाई `&'a` सन्दर्भ फर्काउन चाहन्छौं।
///   तसर्थ, हामी यसलाई कम से कम शक्तिशाली प्रकार `Immut<'a>` को लागी परिभाषित गर्दछौं।
/// - हामी `Mut<'a>` बाट `Immut<'a>` मा निहित जबरजस्ती प्राप्त गर्न सक्दैनौं।
///   त्यसकारण, हामीले स्पष्ट रूपमा `reborrow` लाई अधिक पावरफुल `NodeRef` कल गर्नुपर्दछ `into_kv` जस्तो विधिमा पुग्नको लागि।
///
/// `NodeRef` मा सबै विधिहरू जुन प्रकारको सन्दर्भ फर्काउँदछ: कि त
/// - `self` मान द्वारा लिनुहोस्, र `BorrowType` द्वारा गरिएको जीवनकाल फिर्ता गर्नुहोस्।
///   कहिलेकाँही, त्यस्ता विधि प्रयोग गर्न, हामीले `reborrow_mut` कल गर्नु पर्छ।
/// - `self` सन्दर्भ द्वारा लिनुहोस्, र (implicitly) ले त्यो संदर्भको जीवनकाल फिर्ता गर्दछ, `BorrowType` द्वारा गरिएको जीवनकालको सट्टा।
/// त्यस तर्फ, orrowण जाँचकर्ताले ग्यारेन्टी दिन्छ कि `NodeRef` orrowण लिइएको रहन्छ जबसम्म फर्काइएको सन्दर्भ प्रयोग गरिन्छ।
///   विधिहरू घुसाउँन समर्थन कच्चा पोइन्टर, अर्थात, कुनै जीवनकाल बिना नै एक सन्दर्भ फिर्ता द्वारा यस नियम बेंड।
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// स्तरहरूको संख्या जुन नोड र पातहरूको स्तर भिन्न छन्, नोडको स्थिरता जुन पूर्ण रूपमा `Type` द्वारा वर्णन गर्न सकिदैन, र त्यो नोड आफैंले भण्डार गर्दैन।
    /// हामीले केवल रुट नोडको उचाई भण्डार गर्न आवश्यक छ, र यसबाट प्रत्येक अन्य नोडको उचाई प्राप्त गर्न सक्छौं।
    /// शून्य हुनु पर्छ यदि `Type` `Leaf` हो र गैर शून्य यदि `Type` `Internal` हो भने।
    ///
    ///
    height: usize,
    /// पात वा आन्तरिक नोडमा सूचक।
    /// `InternalNode` को परिभाषाले सुनिश्चित गर्दछ कि पोइन्टर कुनै पनि तरीकाले मान्य छ।
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// `NodeRef::parent` को रूपमा प्याक गरिएको नोड सन्दर्भ अनप्याक गर्नुहोस्।
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// एक आन्तरिक नोडको डाटा उजागर गर्दछ।
    ///
    /// यस नोडको अन्य अमान्य सन्दर्भहरू बेवास्ता गर्न कच्चा ptr फर्काउँछ।
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // सुरक्षा: स्थिर नोड प्रकार `Internal` हो।
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// आन्तरिक नोडको डाटामा विशेष पहुँच उधारो लिन्छ।
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// नोडको लम्बाइ फेला पार्दछ।यो कुञ्जी वा मानहरूको संख्या हो।
    /// किनारहरूको संख्या `len() + 1` हो।
    /// नोट गर्नुहोस्, सुरक्षित भएता पनि, यस प्रकार्यलाई कल गर्दा असुरक्षित कोडले सिर्जना गरेको अवैध अवैध परिवर्तनको साइड इफेक्ट हुन सक्छ।
    ///
    pub fn len(&self) -> usize {
        // महत्वपूर्ण रूपमा, हामी केवल `len` फिल्ड यहाँ पहुँच गर्दछौं।
        // यदि BorrowType marker::ValMut हो भने, त्यहाँ मानहरूमा उल्लेखनीय उत्परिवर्ती संदर्भ हुन सक्छ जुन हामीले अवैध गर्नु हुँदैन।
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// नोड र पातहरू छुट्याइएको स्तरहरूको संख्या फर्काउँछ।
    /// शून्य उचाईको मतलब नोड एक पत्ती नै हो।
    /// यदि तपाईं रूख माथिको रूटको साथ चित्रण गर्नुहुन्छ भने, संख्याले बताउँछ कुन उचाईमा नोड देखा पर्छ।
    /// यदि तपाईं माथि पातहरू सहित रूखहरू चित्रण गर्नुहुन्छ भने संख्याले बताउँछ कि रूख नोडको माथि कति विस्तार हुन्छ।
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// अस्थायी रूपमा अर्को नोड निकाल्छ, उही नोडको सन्दर्भ।
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// कुनै पत्ती वा आन्तरिक नोडको पातलो भाग उजागर गर्दछ।
    ///
    /// यस नोडको अन्य अमान्य सन्दर्भहरू बेवास्ता गर्न कच्चा ptr फर्काउँछ।
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // नोड कम्तिमा LeafNode भाग को लागी मान्य हुनु पर्छ।
        // यो NodeRef प्रकार मा सन्दर्भ होईन किनकि हामीलाई थाहा छैन कि यो अनौंठो वा साझा गरिएको हुनुपर्दछ।
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// हालको नोडको अभिभावक फेला पार्छ।
    /// यदि हालको नोडको वास्तविक अभिभावक छ भने `Ok(handle)` फर्काउँछ, जहाँ `handle` हालको नोडमा पोइन्ट गर्ने अभिभावकको edge मा पोइन्ट गर्दछ।
    ///
    /// `Err(self)` फर्काउँछ यदि हालको नोडको कुनै अभिभावक छैन भने, मूल `NodeRef` फिर्ता प्रदान गर्दै।
    ///
    /// विधि नामले माथिको रूट नोडको साथ तपाईलाई रूखको चित्र दिन्छ।
    ///
    /// `edge.descend().ascend().unwrap()` र `node.ascend().unwrap().descend()` दुबै, सफलता मा, केहि गर्न हुँदैन।
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // हामीले नोडहरूमा कच्चा पोइन्टरहरू प्रयोग गर्नु पर्छ किनकि यदि BorrowType marker::ValMut छ भने, त्यहाँ मानहरूमा उल्लेखनीय उत्परिवर्ती संदर्भ हुन सक्छ जुन हामीले अमान्य गर्नु हुँदैन।
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// नोट गर्नुहोस् कि `self` नोम्प्टी हुनुपर्दछ।
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// नोट गर्नुहोस् कि `self` नोम्प्टी हुनुपर्दछ।
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// कुनै पत्तीको पातलो भाग वा अस्थिर रूखमा आन्तरिक नोडको पर्दाफाश गर्दछ।
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // सुरक्षा: यस रूखमा कुनै परिवर्तनकारी सन्दर्भहरू हुन सक्दैन `Immut` को रूपमा लिएको।
        unsafe { &*ptr }
    }

    /// नोडमा भण्डार गरिएको कुञ्जीमा दृश्य लिन्छ।
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// `ascend` को समान, नोडको अभिभावक नोडको सन्दर्भ प्राप्त हुन्छ, तर प्रकृयामा वर्तमान नोडलाई पनि deallocates गर्दछ।
    /// यो असुरक्षित छ किनकि हालको नोड अझै पनी पहुँचयोग्य हुने छ पनि डेकोलकेटेड भए पनि।
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// असुरक्षित रूपमा कम्पाइलरमा स्थिर जानकारीको जोड दिन्छ कि यो नोड एक `Leaf` हो।
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// असुरक्षित रूपमा कम्पाइलरमा स्थिर जानकारीको जोड दिन्छ कि यो नोड एक `Internal` हो।
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// अस्थायी रूपमा अर्को नोड निकाल्छ, उही नोडको सन्दर्भ।सावधान रहनुहोस्, किनकि यो विधि धेरै खतरनाक छ, दुगुरु त यो तुरून्त खतरनाक नदेखिन सक्छ।
    ///
    /// किनकि परिवर्तनीय पोइन्टरहरू रूखको वरिपरि जताततै घुम्न सकिन्छ, फर्केका पोइन्टर सजीलो मूल पोइन्टर ड्याlingलग गर्न प्रयोग गर्न सकिन्छ, सीमा बाहिर, वा स्ट्याक्ड orrowण नियम अन्तर्गत अवैध।
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) `NodeRef` मा अझै अर्को प्रकारको प्यारामिटर थप्ने विचार गर्नुहोस् जुन पुन: उत्पन्न बिन्दुहरूमा नेभिगेसन विधिहरूको प्रयोग प्रतिबन्धित गर्दछ, यस असुरक्षितलाई रोक्दै।
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// कुनै पाना वा आन्तरिक नोडको पातको अंशमा विशेष पहुँच उधारो लिन्छ।
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // सुरक्षा: हामीसँग सम्पूर्ण नोडमा विशेष पहुँच छ।
        unsafe { &mut *ptr }
    }

    /// कुनै पाना वा आन्तरिक नोडको पातको अंशमा विशेष पहुँच प्रदान गर्दछ।
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // सुरक्षा: हामीसँग सम्पूर्ण नोडमा विशेष पहुँच छ।
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// कुञ्जी भण्डारण क्षेत्रको एक तत्वमा विशेष पहुँच उधारो लिन्छ।
    ///
    /// # Safety
    /// `index` ०..CAPACITY को सीमामा छ
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // सुरक्षा: कलरले आफैंमा थप विधिहरू कल गर्न सक्षम हुँदैन
        // कुञ्जी टुक्रा सन्दर्भ ड्रप नगरे सम्म, हामी संग theण को जीवनकाल को लागी अद्वितीय पहुँच छ।
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// नोडको मूल्य भण्डारण क्षेत्रको एक तत्व वा स्लाइसमा विशेष पहुँच उधारो लिन्छ।
    ///
    /// # Safety
    /// `index` ०..CAPACITY को सीमामा छ
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // सुरक्षा: कलरले आफैंमा थप विधिहरू कल गर्न सक्षम हुँदैन
        // जब सम्म मूल्य टुक्रा सन्दर्भ छोडिन्छ, हामी संग theण को जीवनकाल को लागी अद्वितीय पहुँच छ।
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// edge सामग्रीहरूको लागि नोडको भण्डारण क्षेत्रको एलिमेन्ट वा स्लाइसको लागि एक्सेसमा एक्सेस लिन्छ।
    ///
    /// # Safety
    /// `index` ०..CAPACITY + १ को सीमामा छ
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // सुरक्षा: कलरले आफैंमा थप विधिहरू कल गर्न सक्षम हुँदैन
        // edge स्लाइस संदर्भ छोडे सम्म, हामी asण को जीवनकाल को लागी अद्वितीय पहुँच छ।
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - नोडमा `idx` भन्दा बढि इलिनिमेसन एलिमेन्टहरू छन्।
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // हामी केवल एउटा तत्त्वलाई मात्र संदर्भ दिन्छौं जुन हामी इच्छुक छौं अन्य तत्वहरूमा उल्लेखनीय सन्दर्भको साथ एलियासिंगबाट बच्न, विशेष गरी अघिल्लो पुनरावृत्तिमा कलरमा फर्केका ती व्यक्तिहरू।
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // हामीले Rust मुद्दा #74679 को कारण असुरक्षित एरे पोइन्टर्समा बाध्य पार्नु पर्छ।
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// नोडको लम्बाइमा विशिष्ट पहुँच उधारो लिन्छ।
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// नोडको लिंक यसको अभिभावक edge मा सेट गर्दछ, नोडमा अन्य सन्दर्भहरू अवैध नगरी।
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// यसको मूल edge मा मूलको लिंक खाली गर्दछ।
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// नोडको अन्त्यमा कुञ्जी-मान जोडी थप गर्दछ।
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// प्रत्येक वस्तु `range` द्वारा फर्काइएको नोडको लागि मान्य edge अनुक्रमणिका हो।
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// कुञ्जी-मान जोडी जोड्दछ, र edge कि जोडीको दायाँ जानका लागि नोडको अन्तमा।
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// नोड एक `Internal` नोड हो वा `Leaf` नोड हो कि होइन भनेर जाँच गर्दछ।
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// एउटा विशेष कुञ्जी-मान जोडी वा edge एक नोड भित्र सन्दर्भ।
/// `Node` प्यारामिटर `NodeRef` हुनुपर्दछ, जबकि `Type` या त `KV` (कुञ्जी-मान जोडीमा ह्यान्डललाई स sign्केत गर्ने) वा `Edge` (edge मा ह्यान्डललाई स sign्केत गर्ने) हुन सक्दछ।
///
/// नोट गर्नुहोस् कि `Leaf` नोडहरूमा पनि `Edge` ह्यान्डलहरू हुन सक्छन्।
/// बच्चा नोडमा सूचक प्रतिनिधित्व गर्नुको सट्टा, ती खाली ठाउँहरू प्रतिनिधित्व गर्दछ जहाँ बच्चा पोइन्टरहरू कुञ्जी-मान जोडीहरू बीच जान्छन्।
/// उदाहरणको लागि, लम्बाई २ भएको नोडमा, possible सम्भावित edge स्थानहरू हुन्छन्, एउटा नोडको बाँयादेखि, दुई जोडाहरू बीचको, र एउटा नोडको दायाँमा।
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// हामीलाई `#[derive(Clone)]` को पूर्ण सामान्यताको आवश्यकता छैन, मात्र समय `Node` हुनेछ `क्लोनेबल जब यो एक अपरिवर्तनीय सन्दर्भ हो र त्यसैले `Copy`।
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// edge वा कुञ्जी-मान जोडी समावेश गर्ने नोड पुनःप्राप्त गर्दछ यस ह्यान्डलले पोइन्ट गर्दछ।
    pub fn into_node(self) -> Node {
        self.node
    }

    /// नोडमा यस ह्याण्डलको स्थिति फर्काउँछ।
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// `node` मा कुञ्जी-मान जोडीमा नयाँ ह्याण्डल सिर्जना गर्दछ।
    /// असुरक्षित किनकि कलरले त्यो `idx < node.len()` सुनिश्चित गर्नुपर्दछ।
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// PartialEq को सार्वजनिक कार्यान्वयन हुनसक्दछ, तर केवल यो मोड्युलमा प्रयोग गरियो।
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// अस्थायी रूपमा उही स्थानमा अर्को, अपरिवर्तनीय ह्यान्डल लिन्छ।
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // हामी Handle::new_kv वा Handle::new_edge प्रयोग गर्न सक्दैनौं किनकि हामीलाई हाम्रो प्रकार थाहा छैन
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// असुरक्षित रूपमा स्थिर जानकारी कम्पाइलरमा जोड दिन्छ कि ह्यान्डलको नोड एक `Leaf` हो।
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// अस्थायी रूपमा उही स्थानमा अर्को, परिवर्तन योग्य ह्यान्डल लिन्छ।
    /// सावधान रहनुहोस्, किनकि यो विधि धेरै खतरनाक छ, दुगुरु त यो तुरून्त खतरनाक नदेखिन सक्छ।
    ///
    ///
    /// विवरणका लागि, `NodeRef::reborrow_mut` हेर्नुहोस्।
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // हामी Handle::new_kv वा Handle::new_edge प्रयोग गर्न सक्दैनौं किनकि हामीलाई हाम्रो प्रकार थाहा छैन
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// `node` मा edge मा नयाँ ह्यान्डल सिर्जना गर्दछ।
    /// असुरक्षित किनकि कलरले त्यो `idx <= node.len()` सुनिश्चित गर्नुपर्दछ।
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// edge अनुक्रमणिका दिईयो जहाँ हामी क्षमताले भरिएको नोडमा घुसाउन चाहन्छौं, स्प्लिट पोइन्टको संवेदनशील KV अनुक्रमणिका गणना गर्छ र कहाँ सम्मिलित गर्ने कार्य गर्ने।
///
/// विभाजन बिन्दुको लक्ष्य यसको कुञ्जी र मानको लागि अभिभावक नोडमा अन्त हुन्छ;
/// कुञ्जीहरू, मानहरू र विभाजन बिन्दुको बाँया कुञ्जीहरू बायाँ बच्चा हुन्छन्;
/// कुञ्जीहरू, मानहरू र विभाजन बिन्दुको दायाँ कुनाहरू सही बच्चा हुन्छन्।
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust मुद्दा #74834 यी सममित नियमहरू व्याख्या गर्न कोशिस गर्दछ।
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// यस edge को दाँया र बाँया कुञ्जी-मान जोडीहरू बीच नयाँ कुञ्जी-मान जोडी घुसाउँदछ।
    /// यो विधि मान्दछ कि नयाँ जोडी फिट को लागी नोड मा पर्याप्त ठाउँ छ।
    ///
    /// फर्काइएको पोइन्टर घुसाइएको मानमा पोइन्ट गर्दछ।
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// यस edge को दाँया र बाँया कुञ्जी-मान जोडीहरू बीच नयाँ कुञ्जी-मान जोडी घुसाउँदछ।
    /// यो विधि नोड विभाजित गर्दछ यदि पर्याप्त कोठा छैन।
    ///
    /// फर्काइएको पोइन्टर घुसाइएको मानमा पोइन्ट गर्दछ।
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// बच्चा नोडमा अविभावक सूचक र अनुक्रमणिका फिक्स गर्दछ जुन यस edge मा लिंक छ।
    /// यो उपयोगी छ जब किनाराको क्रम परिवर्तन गरिएको छ,
    fn correct_parent_link(self) {
        // नोडमा अन्य सन्दर्भहरू अवैध नगरी ब्याकपोइन्टर सिर्जना गर्नुहोस्।
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// एक नयाँ कुञ्जी-मान जोडी र edge सम्मिलित गर्दछ जुन यो edge र साँचो Z-edge0Z को दाँया कुञ्जी-मान जोडी बीचको नयाँ जोडीको दायाँ जान्छ।
    /// यो विधि मान्दछ कि नयाँ जोडी फिट को लागी नोड मा पर्याप्त ठाउँ छ।
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// एक नयाँ कुञ्जी-मान जोडी र edge सम्मिलित गर्दछ जुन यो edge र साँचो Z-edge0Z को दाँया कुञ्जी-मान जोडी बीचको नयाँ जोडीको दायाँ जान्छ।
    /// यो विधि नोड विभाजित गर्दछ यदि पर्याप्त कोठा छैन।
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// यस edge को दाँया र बाँया कुञ्जी-मान जोडीहरू बीच नयाँ कुञ्जी-मान जोडी घुसाउँदछ।
    /// यस विधिले नोड विभाजित गर्दछ यदि पर्याप्त कोठा छैन, र प्यारेन्ट नोडमा स्पर्ट अफ भाग सम्मिलित गर्न प्रयास गर्दछ रर्स्ट नभएसम्म,
    ///
    ///
    /// यदि फिर्ता गरिएको परिणाम `Fit` हो भने, यसको ह्यान्डलको नोड यो edge को नोड वा पूर्वज हुन सक्छ।
    /// यदि फिर्ता गरिएको परिणाम एक `Split` हो भने, `left` क्षेत्र मूल नोड हुनेछ।
    /// फर्काइएको पोइन्टर घुसाइएको मानमा पोइन्ट गर्दछ।
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// यस edge द्वारा देखाएको नोड फेला पार्दछ।
    ///
    /// विधि नामले माथिको रूट नोडको साथ तपाईलाई रूखको चित्र दिन्छ।
    ///
    /// `edge.descend().ascend().unwrap()` र `node.ascend().unwrap().descend()` दुबै, सफलता मा, केहि गर्न हुँदैन।
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // हामीले नोडहरूमा कच्चा पोइन्टरहरू प्रयोग गर्नु पर्छ किनकि यदि BorrowType marker::ValMut छ भने, त्यहाँ मानहरूमा उल्लेखनीय उत्परिवर्ती संदर्भ हुन सक्छ जुन हामीले अमान्य गर्नु हुँदैन।
        // उचाई फिल्डमा पहुँच गर्न त्यहाँ कुनै चिन्ता छैन किनकि त्यो मानको प्रतिलिपि गरिएको छ।
        // सावधान रहनुहोस्, एक पटक नोड पोइन्टरलाई आदर गरेपछि, हामी किनाराहरू एर्रेमा सन्दर्भ (Rust मुद्दा #73987) को साथ पहुँच गर्छौं र एर्रे भित्र वा कुनै अन्य सन्दर्भहरूलाई अमान्य गर्दछौं, जुन कुनै पनि वरपर हुनुपर्दछ।
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // हामी छुट्टै कुञ्जी र मान विधिहरू कल गर्न सक्दैनौं, किनकि दोस्रोलाई कल गर्दा पहिलो फर्काइएको सन्दर्भलाई अवैध बनाउँछ।
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// कुञ्जी र मान बदल्नुहोस् जुन KV ह्यान्डलले सन्दर्भ गर्दछ।
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// `split` को विशेष डेटा `NodeType` का लागि कार्यान्वयनमा सहयोग गर्दछ, पात डाटाको ख्याल गरेर।
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// अन्तर्निहित नोडलाई तीन भागमा विभाजन गर्दछ:
    ///
    /// - नोडलाई केवल यस ह्याण्डलको बाँया कुञ्जी-मान जोडीहरू सम्मिलित गरिएको छ।
    /// - यस ह्यान्डलले औंल्याइएको कुञ्जी र मान निकालिन्छ।
    /// - सबै यस कुञ्जी-मान जोडीहरू यस ह्याण्डलको दायाँपट्टि नयाँ आवंटित नोडमा राखिन्छ।
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// यस ह्याण्डलले दर्साइएको कुञ्जी-मान जोडी हटाउँदछ र edge साथ कुञ्जी-मान जोडीमा झर्छ।
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// अन्तर्निहित नोडलाई तीन भागमा विभाजन गर्दछ:
    ///
    /// - नोड केवल ह्यान्डलको बाँयामा किनाराहरू र कुञ्जी-मान जोडीहरू समावेश गर्न काटिन्छ।
    /// - यस ह्यान्डलले औंल्याइएको कुञ्जी र मान निकालिन्छ।
    /// - सबै किनाराहरू र कुञ्जी-मान जोडीहरू यस ह्याण्डलको दायाँपट्टि एक नयाँ आवंटित नोडमा राखिन्छ।
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// आन्तरिक कुञ्जी-मान जोडीको वरिपरि सन्तुलन अपरेशन मूल्यांकन गर्न र प्रदर्शनको लागि सत्र प्रतिनिधित्व गर्दछ।
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// बच्चाको रूपमा नोडसँग सम्बन्धित एक सन्तुलित प्रसoo्ग छनौट गर्दछ, यसरी KV को बीच तुरून्त बाँया वा दायाँ पेरन्ट नोडमा।
    /// यदि कुनै अभिभावक छैन भने `Err` फर्काउँछ।
    /// Panics यदि अभिभावक खाली छ।
    ///
    /// बाँया पट्टि प्राथमिकता दिईन्छ, यदि उपयुक्त नोड यदि कुनै तरिकाले अन्डरफुल छ भने इष्टतम हुनको लागि, यहाँ मात्र यसको अर्थ यो छ कि यसको बायाँ भाईबहिनी भन्दा कम तत्वहरू छन् र यसको दायाँ भाईबहिनी भन्दा तिनीहरू अवस्थित छन् भने।
    /// त्यो अवस्थामा, बाँया भाईको साथ मर्ज गर्न छिटो हुन्छ, किनकि हामीले केवल नोडको एन तत्वहरू सार्नु पर्छ, तिनीहरूलाई दायाँ सार्नुको सट्टा र एन तत्वहरू भन्दा अगाडि सर्नको लागि।
    /// बाँया भाईबाट चोर्न पनि सामान्यतया छिटो हुन्छ, किनकि हामीले दाँया नोडको एन तत्वहरू दायाँ सार्नु पर्छ, बरु भाइबहिनीको कम्तीमा एन बायाँ सार्नुको सट्टा।
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// मर्ज गर्न सम्भव छ कि छैन भनेर फर्काउँछ, अर्थात, त्यहाँ नोडमा पर्याप्त कोठा छ कि छैन केन्द्रीय केभी दुबै छेउछाउका नोडहरू सँग जोड्नका लागि।
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// मर्ज गर्दछ र क्लोजरले के फिर्ता गर्ने निर्णय गर्न दिन्छ।
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // सुरक्षा: मर्ज हुने नोडहरूको उचाइ उचाइभन्दा तल हो
                // यस edge को नोडको, त्यसैले शून्य माथि, त्यसैले तिनीहरू आन्तरिक छन्।
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// अभिभावकको कुञ्जी-मान जोडी र दुबै आसन्न बच्चा नोडहरूलाई बाँया बच्चा नोडमा मर्ज गर्दछ र स्कित प्यारेन्ट नोड फर्काउँछ।
    ///
    ///
    /// Panics जबसम्म हामी `.can_merge()` गर्दैनौं।
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// अभिभावकको कुञ्जी-मान जोडी र दुबै आसन्न बच्चा नोडहरूलाई बाँया बच्चा नोडमा मर्ज गर्दछ र त्यो बच्चा नोड फिर्ता गर्दछ।
    ///
    ///
    /// Panics जबसम्म हामी `.can_merge()` गर्दैनौं।
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// अभिभावकको कुञ्जी-मान जोडी र दुबै आसन्न बच्चा नोडहरूलाई बाँया बच्चा नोडमा मर्ज गर्दछ र edge ह्यान्डललाई त्यो बच्चा नोडमा फर्काउँदछ जहाँ ट्र्याक गरिएको बच्चा edge समाप्त भयो,
    ///
    ///
    /// Panics जबसम्म हामी `.can_merge()` गर्दैनौं।
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// बायाँ बच्चाबाट कुञ्जी-मान जोडी हटाउँदछ र पुरानो अभिभावक कुञ्जी-मान जोडी दायाँ बच्चामा धकेल्दै बाबुको कुञ्जी-मूल्य भण्डारणमा राख्दछ।
    ///
    /// सही बच्चाको edge मा एक ह्यान्डल फर्काउँछ जहाँ `track_right_edge_idx` द्वारा निर्दिष्ट मूल edge समाप्त भयो।
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// दाँया बच्चाबाट कुञ्जी-मान जोडी हटाउँदछ र पुरानो अभिभावक कुञ्जी-मान जोडीलाई बायाँ बच्चामा धकेल्दा यसलाई आमाबुवाको कुञ्जी-मूल्य भण्डारणमा राख्दछ।
    ///
    /// `track_left_edge_idx` द्वारा निर्दिष्ट बायाँ बच्चामा edge मा एक ह्यान्डल फिर्ता गर्दछ, जुन सार्दैन।
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// यसले `steal_left` सँग समान चोरी गर्दछ तर एकै पटकमा धेरै तत्वहरू चोरी गर्दछ।
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // निश्चित गर्नुहोस् कि हामी सुरक्षित रूपमा चोरी गर्न सक्छौं।
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // पात डाटा सार्नुहोस्।
            {
                // सही बच्चामा चोरी भएका तत्वहरूको लागि ठाउँ बनाउनुहोस्।
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // बायाँ बच्चाबाट दायाँ एकमा तत्वहरू सार्नुहोस्।
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // बाँया सबैभन्दा चोरिएको जोडीलाई अभिभावकमा सार्नुहोस्।
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // सही बच्चामा अभिभावकको कुञ्जी-मान जोडी सार्नुहोस्।
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // चोरी भएको किनारहरूको लागि ठाउँ बनाउनुहोस्।
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // किनारहरू चोरी गर्नुहोस्।
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// `bulk_steal_left` को सममित क्लोन।
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // निश्चित गर्नुहोस् कि हामी सुरक्षित रूपमा चोरी गर्न सक्छौं।
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // पात डाटा सार्नुहोस्।
            {
                // दाँया-सबै चोरिएको जोडीलाई अभिभावकमा सार्नुहोस्।
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // बायाँ बच्चामा अभिभावकको कुञ्जी-मान जोडी सार्नुहोस्।
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // दाँया बच्चाबाट बाँया एकमा तत्वहरू सार्नुहोस्।
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // खाली ठाउँ भर्नुहोस् जहाँ चोरी गरिएका तत्वहरू प्रयोग गर्दथे।
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // किनारहरू चोरी गर्नुहोस्।
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // खाली ठाउँ भर्नुहोस् जहाँ चोरीको किनारहरू हुन्थ्यो।
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// कुनै स्थिर जानकारी हटाउँदछ कि यो नोड एक `Leaf` नोड हो भनेर
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// कुनै स्थिर जानकारी हटाउँदछ कि यो नोड एक `Internal` नोड हो भनेर
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// अन्तर्निहित नोड एक `Internal` नोड हो वा `Leaf` नोड हो कि होइन भनेर जाँच गर्दछ।
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// `self` पछि प्रत्यय एउटा नोडबाट अर्कोमा सार्नुहोस्।`right` खाली हुनुपर्दछ।
    /// `right` को पहिलो edge अपरिवर्तित रहन्छ।
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// सम्मिलनको नतीजा, जब एक नोड यसको क्षमता बाहिर विस्तार गर्न आवश्यक छ।
pub struct SplitResult<'a, K, V, NodeType> {
    // `kv` को बाँयासँग सम्बन्धित तत्व र किनारहरू सहित अवस्थित रूखमा नोड परिवर्तन गरियो।
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // केही कुञ्जी र मान विभाजन बन्द, कहीं अन्तर्गत सम्मिलित गर्न।
    pub kv: (K, V),
    // `kv` को दायाँमा सम्बन्धित तत्वहरू र किनारहरूसहितको स्वामित्व, अपठित, नयाँ नोड।
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // यस orrowण प्रकारको नोड सन्दर्भले रूखमा अन्य नोडहरूमा यात्रा गर्न अनुमति दिन्छ।
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // ट्र्याभर्सललाई आवाश्यक छैन, यो `borrow_mut` को नतीजा प्रयोग गरेर हुन्छ।
        // Traversal असक्षम गरेर, र केवल जरामा नयाँ सन्दर्भ सिर्जना गरेर, हामी जान्दछौं कि `Owned` प्रकारको प्रत्येक संदर्भ रूट नोडमा हुन्छ।
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// इनिसिटलाइज्ड तत्त्वको एक टुक्रामा मान सम्मिलित गर्दछ त्यसपछि एक अनावश्यक तत्त्व।
///
/// # Safety
/// स्लाइसमा `idx` भन्दा बढी तत्वहरू छन्।
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// हटाउँछ र सबै आरम्भिक तत्त्वहरूको स्लाइसबाट मान फर्काउँछ, एक ट्रेलिंग अननिटलाइज गरिएको तत्त्वको पछाडि।
///
///
/// # Safety
/// स्लाइसमा `idx` भन्दा बढी तत्वहरू छन्।
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// एक स्लाइस `distance` स्थितिमा एलिमेन्टहरू बाँयामा बदल्नुहोस्।
///
/// # Safety
/// टुक्रामा कम्तिमा `distance` तत्वहरू छन्।
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// स्लाइस `distance` स्थितिमा एलिमेन्टहरू दायाँ सिफ्ट गर्नुहोस्।
///
/// # Safety
/// टुक्रामा कम्तिमा `distance` तत्वहरू छन्।
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// XIX को पछाडि सबै ईन्निटिटलाइजको रूपमा छोड्दै, इनिशियलाइज्ड एलिमेन्टहरूको स्लाइसबाट सबै मानहरू अननिटिटलाइज्ड एलिमेन्टहरूको टुक्रामा सार्दछ।
///
/// `dst.copy_from_slice(src)` जस्तै कार्य गर्दछ तर `T` `Copy` हुन आवश्यक छैन।
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;