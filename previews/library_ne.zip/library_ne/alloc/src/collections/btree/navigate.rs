use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// अस्थायी रूपमा अर्को समान, समान दायराको अपरिवर्तनीय बराबर लिन्छ।
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// रूखमा निर्दिष्ट दायरा सीमांकन गर्न छुट्टै पात किनारहरू फेला पार्दछ।
    /// या त एउटै रूखमा बिभिन्न ह्यान्डलहरूको जोडी वा खाली विकल्पहरूको जोडी फर्काउँछ।
    ///
    /// # Safety
    ///
    /// `BorrowType` `Immut` नभएसम्म दोहोरै KV भ्रमण गर्न नक्कल ह्याण्डलहरू प्रयोग नगर्नुहोस्।
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// `(root1.first_leaf_edge(), root2.last_leaf_edge())` को बराबर तर अधिक कुशल।
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// रूखमा विशिष्ट दायरा सीमांकन गर्दै पातको किनारहरूको जोडी फेला पार्दछ।
    ///
    /// परिणाम मात्र अर्थपूर्ण हुन्छ यदि रूख कुञ्जी द्वारा अर्डर गरिएको छ, जस्तै `BTreeMap` मा रूख हो।
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // सुरक्षा: हाम्रो orrowण प्रकार अपरिवर्तनीय छ।
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// पूरै रूख को सीमा निर्धारण गर्ने पातको किनारहरूको जोडी फेला पार्छ।
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// एक निर्दिष्ट दायरा सीमान्तीकरण गर्दै पात किनाराहरूको जोडीमा एक अद्वितीय सन्दर्भ विभाजित गर्दछ।
    /// परिणाम गैर-अद्वितीय सन्दर्भहरू छन् (some) उत्परिवर्तन, जो सावधानीपूर्वक प्रयोग गर्नुपर्दछ।
    ///
    /// परिणाम मात्र अर्थपूर्ण हुन्छ यदि रूख कुञ्जी द्वारा अर्डर गरिएको छ, जस्तै `BTreeMap` मा रूख हो।
    ///
    ///
    /// # Safety
    /// नक्कल ह्यान्डलहरू एकै KV दुई पटक भ्रमण गर्न प्रयोग नगर्नुहोस्।
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// रूखको पूर्ण दायरा सीमांकन गर्दै पातको किनाराहरूको जोडीमा एक अद्वितीय सन्दर्भ विभाजित गर्दछ।
    /// परिणाम गैर-अद्वितीय सन्दर्भ हो म्युटेसन (केवल मानको) लाई अनुमति दिँदै, त्यसैले सावधानीको साथ प्रयोग गर्नुपर्दछ।
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // हामी यहाँ रुट नोडराफको नक्कल गर्छौं-हामी कहिले पनि उही केभीलाई दुई पटक भेट्ने छैनौं, र कहिले पनि ओभरल्यापिंग मान सन्दर्भसँग अन्त्य हुँदैनौं।
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// रूखको पूर्ण दायरा सीमांकन गर्दै पातको किनाराहरूको जोडीमा एक अद्वितीय सन्दर्भ विभाजित गर्दछ।
    /// परिणामहरू गैर-विशिष्ट सन्दर्भहरू हुन् जुन विशाल विनाशकारी उत्परिवर्तनलाई अनुमति दिन्छ, त्यसैले अत्यन्त सावधानीका साथ प्रयोग गर्नुपर्दछ।
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // हामी यहाँ रुट नोडराफको नक्कल गर्छौं-हामी कहिले पनि यसलाई पहुँच गर्ने छैनौं कि जराबाट प्राप्त भएका ओभरल्याप हुने तरीकाले।
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// एउटा पात edge ह्यान्डल दिइयो, [`Result::Ok`] दायाँको छेउछाउको KV लाई ह्यान्डलको साथ फर्काउँछ, जुन कि त उही पात नोडमा वा पूर्वज नोडमा हुन्छ।
    ///
    /// यदि पात edge रूखमा अन्तिम अन्तिम हो भने, रूट नोडको साथ [`Result::Err`] फर्काउँछ।
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// एक पात edge ह्यान्डल दिइयो, [`Result::Ok`] फर्काइयो ह्यान्डलको साथ बाँकी छेउछाउको KV लाई, जुन कि उही पात नोडमा वा पूर्वज नोडमा छ।
    ///
    /// यदि पात edge रूखमा पहिलो हो भने, रूट नोडको साथ [`Result::Err`] फर्काउँछ।
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// एक आन्तरिक edge ह्यान्डल दिईएको छ, [`Result::Ok`] दायाँको छेउछाउको KV लाई ह्यान्डलको साथ फर्काउँछ, जुन कि त समान आन्तरिक नोड वा पूर्वज नोडमा छ।
    ///
    /// यदि आन्तरिक edge रूखमा अन्तिम अन्तिम हो भने, रूट नोडको साथ [`Result::Err`] फर्काउँछ।
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// एक पात edge ह्यान्डललाई मर्ने रूखमा दिइयो, अर्को पाना edge दायाँ पछाडि फर्काउँछ, र बीचमा कुञ्जी-मान जोडी, जुन कि त उही पत्ती नोडमा, पूर्वज नोडमा, वा अवस्थित छैन।
    ///
    ///
    /// यस विधिले कुनै पनि node(s) लाई डेकोलोकेट गर्दछ जुन यसको अन्तमा पुग्छ।
    /// यसले संकेत गर्दछ कि यदि कुनै अधिक कुञ्जी-मान जोडी अवस्थित भएमा, रूखको सम्पूर्ण बाँकी हिस्सा हटाइएको छ र फर्कनको लागि केहि पनि बाँकी छैन।
    ///
    /// # Safety
    /// दिइएको edge पहिले काउन्टरपार्ट `deallocating_next_back` द्वारा फिर्ता गरिएको हुनु हुँदैन।
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// एक पात edge ह्यान्डललाई मर्ने रूखमा दिइयो, अर्को पाना edge बायाँ पट्टि फर्काउँछ, र बीचमा कुञ्जी-मान जोडी, जुन कि त उही पत्ती नोडमा, पूर्वज नोडमा, वा अवस्थित छैन।
    ///
    ///
    /// यस विधिले कुनै पनि node(s) लाई डेकोलोकेट गर्दछ जुन यसको अन्तमा पुग्छ।
    /// यसले संकेत गर्दछ कि यदि कुनै अधिक कुञ्जी-मान जोडी अवस्थित भएमा, रूखको सम्पूर्ण बाँकी हिस्सा हटाइएको छ र फर्कनको लागि केहि पनि बाँकी छैन।
    ///
    /// # Safety
    /// दिइएको edge पहिले काउन्टरपार्ट `deallocating_next` द्वारा फिर्ता गरिएको हुनु हुँदैन।
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// पातबाट माथिसम्म जरामा नोडहरूको थुप्रो।
    /// `deallocating_next` र `deallocating_next_back` रूखको दुबै छेउमा निबिल भईरहेको छ, र उही edge मा ठुलो पछाडि यो रूखको बाँकी हिस्सा अपमान गर्नका लागि यो मात्र तरिका हो।
    /// यो केवल कल गर्न भनिन्छ जब सबै कुञ्जीहरू र मानहरू फिर्ता गरियो, कुनै पनि कुञ्जी वा मानहरूमा कुनै सफाई कार्य हुँदैन।
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// पात edge ह्याण्डललाई अर्को पाना edge मा सार्दछ र कुञ्जी र बीचमा मानमा सन्दर्भ फर्काउँछ।
    ///
    ///
    /// # Safety
    /// त्यहाँ यात्राको दिशामा अर्को KV हुनुपर्दछ।
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// पात edge ह्याण्डललाई अघिल्लो पाना edge मा सार्छ र बीचमा कुञ्जी र मानमा सन्दर्भ फर्काउँछ।
    ///
    ///
    /// # Safety
    /// त्यहाँ यात्राको दिशामा अर्को KV हुनुपर्दछ।
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// पात edge ह्याण्डललाई अर्को पाना edge मा सार्दछ र कुञ्जी र बीचमा मानमा सन्दर्भ फर्काउँछ।
    ///
    ///
    /// # Safety
    /// त्यहाँ यात्राको दिशामा अर्को KV हुनुपर्दछ।
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // यो अन्तिम गर्नु द्रुत छ, बेन्चमार्कका अनुसार।
        kv.into_kv_valmut()
    }

    /// पात edge ह्यान्डललाई अघिल्लो पानामा सार्छ र कुञ्जी र मानको बीचमा सन्दर्भ फर्काउँछ।
    ///
    ///
    /// # Safety
    /// त्यहाँ यात्राको दिशामा अर्को KV हुनुपर्दछ।
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // यो अन्तिम गर्नु द्रुत छ, बेन्चमार्कका अनुसार।
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// पात edge ह्याण्डललाई अर्को पाना edge मा सार्दछ र कुञ्जी र मान बीचमा फर्काउँछ, कुनै पनि नोडलाई पछाडि पछाडि पछाडि पार गर्दछ जब पनी सम्बन्धित नोड ड्याling्लिंगमा सम्बन्धित edge छोडेर।
    ///
    /// # Safety
    /// - त्यहाँ यात्राको दिशामा अर्को KV हुनुपर्दछ।
    /// - त्यो केभी पहिले रूखको यात्रा गर्न ह्यान्डलहरूको कुनै पनि प्रतिलिपिमा काउन्टरपार्ट `next_back_unchecked` द्वारा फिर्ता गरिएको थिएन।
    ///
    /// अपडेट गरिएको ह्याण्डलको साथ अगाडि बढ्ने एक मात्र सुरक्षित तरीका भनेको यसलाई तुलना गर्नु, यसलाई खसाल्नु, यस विधिलाई यसका सुरक्षा शर्तहरूको बिषयमा कल गर्नुहोस्, वा काउंटरपार्ट `next_back_unchecked` लाई यसको सुरक्षा सर्तहरूको अधीनमा कल गर्नुहोस्।
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// पात edge ह्याण्डललाई अघिल्लो पाना edge मा सार्दछ र कुञ्जी र मान बीचमा फर्काउँछ, कुनै पनि नोडलाई पछाडि पछाडि पछाडि पछाडि कुनै पनि नोड छोड्दा सम्बन्धित edge लाई यसको प्यारेन्ट नोड ड्याlingलि in्गमा पछाडि छोडिन्छ।
    ///
    /// # Safety
    /// - त्यहाँ यात्राको दिशामा अर्को KV हुनुपर्दछ।
    /// - त्यो पाना edge पहिले काउन्टरपार्ट `next_unchecked` द्वारा रूखमा पार गर्न प्रयोग गरिने ह्यान्डलहरूको कुनै प्रतिलिपिमा फिर्ता गरिएको थिएन।
    ///
    /// अपडेट गरिएको ह्याण्डलको साथ अगाडि बढ्ने एक मात्र सुरक्षित तरीका भनेको यसलाई तुलना गर्नु, यसलाई खसाल्नु, यस विधिलाई यसका सुरक्षा शर्तहरूको अधीनमा कल गर्नुहोस्, वा काउंटरपार्ट `next_unchecked` लाई यसको सुरक्षा सर्तहरूको विषयमा कल गर्नु हो।
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// बायाँपट्टि पात edge फर्काउँछ नोडको मुनि वा मुनि, अर्को शब्दहरूमा, edge तपाईलाई अगाडि नेभिगेट गर्दा पहिले चाहिन्छ (वा पछिल्लो पछाडि नेभिगेट गर्दा)।
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// दायाँको पातलो edge फर्काउँछ नोडको मुनि वा मुनि, अर्को शब्दहरूमा, edge तपाईंलाई अन्तिम चाहिन्छ अगाडि नेभिगेट गर्दा (वा पहिले पछाडि नेभिगेट गर्दा)।
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// आरोहित कुञ्जीहरूको क्रममा पात नोडहरू र आन्तरिक KVs भ्रमण गर्दछ, र साथै सम्पूर्ण गहिराइ पहिलो क्रममा आन्तरिक नोडहरू पनि भ्रमण गर्दछ, जसको मतलब हो कि आन्तरिक नोडहरू उनीहरूको व्यक्तिगत KVs र उनीहरूको बच्चा नोडहरू भन्दा पहिले।
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// (उप) रूखमा तत्त्वहरूको संख्या गणना गर्दछ।
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// फर्वार्ड नेभिगेसनका लागि पात edge KV को नजिकै फर्काउँछ।
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// पछाडि edge फर्काउँछ नेविगेशन नेविगेशनको लागि KV नजिकै।
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}