use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// दुई बढ्दो पुनरावृत्तकर्ताहरूको मिलनबाट सबै कुञ्जी-मान जोडीहरू जोड्दछ, बाटोमा एक `length` भ्यारीएबल बढाउँदै।पछिल्लोले कलरको लागि चुहावटबाट बच्न सजिलो बनाउँदछ जब ड्रप ह्यान्डलरले प्यानक गर्छ।
    ///
    /// यदि दुबै इटरेटरहरूले समान कुञ्जी उत्पादन गर्दछ भने, यो विधिले बाँया पुनरावृत्तिकर्ताबाट जोडी खसाल्छ र दाया इट्रेटरबाट जोडी जोड्दछ।
    ///
    /// यदि तपाईं रूख कडाई रूपमा चढ्दो क्रममा अन्त्य गर्न चाहनुहुन्छ, एक `BTreeMap` को लागि जस्तै, दुबै पुनरावृत्तकर्ताहरूले कडाइका साथ क्रमिक चढाइ क्रममा कुञ्जीहरू उत्पादन गर्नुपर्दछ, रूखमा सबै कुञ्जीहरू भन्दा ठूलो, प्रत्येकमा प्रविष्टमा रूखमा पहिले नै कुनै कुञ्जीहरू सहित।
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // हामी `left` र `right` लाई लाइनर क्रमबद्ध क्रममा मर्ज गर्न तयार गर्दछौं।
        let iter = MergeIter(MergeIterInner::new(left, right));

        // यस बीच, हामी लाईख समय मा क्रमबद्ध क्रम बाट एक रूख निर्माण।
        self.bulk_push(iter, length)
    }

    /// सबै कुञ्जी-मान जोडीहरूलाई रूखको अन्त्यमा धक्का दिन्छ, बाटोमा `length` भ्यारीएबल बढाउँदै।
    /// पछिल्लोले कलरका लागि लीटरलाई रोक्न सजिलो बनाउँदछ जब ईटररेटरले पञ्ज गर्दछ।
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // सबै कुञ्जी-मान जोडीहरू मार्फत Iterate गर्नुहोस्, तिनीहरूलाई दायाँ स्तरमा नोडहरूमा धकेल्दै।
        for (key, value) in iter {
            // कुञ्जी-मान जोडीलाई हालको पात नोडमा धकेल्ने प्रयास गर्नुहोस्।
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // कुनै ठाउँ बाँकी छैन, माथि जानुहोस् र त्यहाँ धकेल्नुहोस्।
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // खाली ठाउँ सहितको नोड भेटियो, यहाँ थिच्नुहोस्।
                                open_node = parent;
                                break;
                            } else {
                                // फेरि माथि जानुहोस्।
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // हामी शीर्षमा छौं, नयाँ मूल नोड सिर्जना गर्नुहोस् र त्यहाँ धकेल्नुहोस्।
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // कुञ्जी-मान जोडी र नयाँ दायाँ उपशीटिका पुश गर्नुहोस्।
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // तल दायाँ-सबैभन्दा पातमा जानुहोस्।
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // लम्बाइ प्रत्येक पुनरावृत्ति, निश्चित गर्न नक्शाले एट्रेन्ट एलिमेन्ट्स ड्रप गर्दछ भने यदी एटररेटर पicks्क्सलाई अगाडि बढाउँदै।
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// एकमा दुई क्रमबद्ध क्रमहरू मर्ज गर्नका लागि एक पुनरावृत्तिकर्ता
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// यदि दुई कुञ्जीहरू बराबर भए, सही स्रोतबाट कुञ्जी-मान जोडी फर्काउँछ।
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}