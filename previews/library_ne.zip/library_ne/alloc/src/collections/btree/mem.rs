use core::intrinsics;
use core::mem;
use core::ptr;

/// यो `v` अद्वितीय सन्दर्भ पछाडि मान सम्बन्धित ठाउँमा सम्बन्धित ठाउँमा।
///
///
/// यदि panic `change` बन्दमा देखा पर्छ, सम्पूर्ण प्रक्रिया परित्याग गरिनेछ।
#[allow(dead_code)] // उदाहरणको रूपमा र future प्रयोगको लागि राख्नुहोस्
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// यसले `v` अद्वितीय सन्दर्भ पछाडिको मानलाई प्रासंगिक प्रकार्य कल गरी प्रतिस्थापन गर्दछ, र बाटोमा प्राप्त परिणाम फिर्ता गर्छ।
///
///
/// यदि panic `change` बन्दमा देखा पर्छ, सम्पूर्ण प्रक्रिया परित्याग गरिनेछ।
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}