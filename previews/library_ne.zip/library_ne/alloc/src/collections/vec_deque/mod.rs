//! एक डबल एन्डेड पue्क्ति बढ्न मिल्ने रिंग बफरको साथ लागू गरियो।
//!
//! यो लाममा *O*(१) परिमार्जित ईन्सर्ट र कन्टेनरको दुबै छेउबाट हटाइएको छ।
//! यसमा *O*(१) vector जस्तो अनुक्रमणिका पनि छ।
//! समावेश तत्वहरू प्रतिलिपि योग्य हुन आवश्यक छैन, र प que्क्ति पठाउन योग्य छ यदि समावेश गरिएको प्रकार पठाउन योग्य छ भने।
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // २ ^,, १
const MINIMUM_CAPACITY: usize = 1; // २, १

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // दुई मध्ये सब भन्दा ठूलो सम्भव शक्ति

/// एक डबल एन्डेड पue्क्ति बढ्न मिल्ने रिंग बफरको साथ लागू गरियो।
///
/// यस प्रकारको "default" लाई प a्क्तिको रूपमा प्रयोग [`push_back`] लाई पue्क्तिमा थप्नको लागि, र [`pop_front`] लाई पue्क्तिबाट हटाउनको लागि हो।
///
/// [`extend`] र [`append`] यस तरीकाले पछाडि धकेल्छ, र `VecDeque` मा पुनरावर्तन अगाडि पछाडि जान्छ।
///
/// किनकि `VecDeque` एक रिंग बफर हो, यसका तत्वहरू मेमोरीमा सान्दर्भिक हुँदैनन्।
/// यदि तपाईं एकल स्लाइसको रूपमा तत्त्वहरूलाई पहुँच गर्न चाहनुहुन्छ, जस्तै कुशल क्रमबद्धको लागि, तपाईं [`make_contiguous`] प्रयोग गर्न सक्नुहुनेछ।
/// यसले `VecDeque` घुमाउँदछ ताकि यसको तत्त्वहरू लपेट्न सक्दैन, र अब मिल्दो तत्त्व अनुक्रममा म्यूटेबल स्लाइस दिन्छ।
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // पुच्छर र टाउको बफरमा पोइन्टर्स हुन्।
    // टेलले सधैं पहिलो तत्त्वलाई औंल्याउँछ जुन पढ्न सकिन्छ, हेडले सँधै संकेत गर्दछ जहाँ डाटा लेख्नुपर्दछ।
    //
    // यदि पूंछ==हेड बफर खाली छ।रिंगबफर को लम्बाई दुई बीचको दूरी को रूप मा परिभाषित छ।
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// स्लासमा सबै वस्तुहरूको लागि विनाशकारी चलाउँछ जब यो झर्दछ (सामान्य रूपमा वा अनइन्डि duringको समयमा)।
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // [T] को लागी ड्रप प्रयोग गर्नुहोस्
            ptr::drop_in_place(front);
        }
        // RawVec deallocation ह्यान्डल गर्दछ
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// खाली `VecDeque<T>` सिर्जना गर्दछ।
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// सीमान्त रूपमा अधिक सुविधाजनक
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// सीमान्त रूपमा अधिक सुविधाजनक
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // शून्य आकारका प्रकारहरूका लागि हामी सँधै अधिकतम क्षमतामा हुन्छौं
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Ptr लाई एक टुक्रामा बदल्नुहोस्
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Ptr परिवर्तन गर्नुहोस् म्युट स्लाइसमा
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// एलिमेन्ट बफरबाट बाहिर सारियो
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// बफरमा एलिमेन्ट लेख्दछ, यसलाई सार्दै।
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// `true` फर्काउँछ यदि बफर पूर्ण क्षमतामा छ।
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// दिइएको तार्किक तत्व अनुक्रमणिकाको लागि अन्तर्निहित बफरमा सूचका Return्क फर्काउँछ।
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// दिइएको तार्किक तत्व अनुक्रमणिका + थपको लागि अन्तर्निहित बफरमा अनुक्रमणिका फर्काउँछ।
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// दिइएको तार्किक तत्व अनुक्रमणिका, subtrahend को लागि अन्तर्निहित बफरमा अनुक्रमणिका फर्काउँछ।
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// src बाट dst सम्म लामो मेमोरी लेनको मिल्दो ब्लक प्रतिलिपि गर्दछ
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// src बाट dst सम्म लामो मेमोरी लेनको मिल्दो ब्लक प्रतिलिपि गर्दछ
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// src बाट गन्तव्यको लागि लामो मेमोरी लेनको एक सम्भावित रैपिंग ब्लक प्रतिलिपि गर्दछ।
    /// (abs(dst - src) + लेन) cap() भन्दा ठूलो हुनु हुँदैन (त्यहाँ src र डेस्ट बीचमा एक भन्दा बढि लगातार ओभरल्यापि region क्षेत्र हुनुपर्दछ)।
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src ले र्याप गर्दैन, dst रैप गर्दैन
                //
                //        S।।
                // १ [_ _ A A B B C C _]
                // २ [_ _ A A A A B B _] D
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // zstsrc0Z भन्दा पहिले dst, src लपेट्दैन, dst रैप
                //
                //
                //    S।।
                // १ [A A B B _ _ _ C C]
                // २ [A A B B _ _ _ A A]
                // X [B B B B _ _ _ A A] .. D
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src dst भन्दा पहिले, src लपेट्दैन, dst रैप
                //
                //
                //              S।।
                // १ [C C _ _ _ A A B B]
                // २ [B B _ _ _ A A B B]
                // X [B B _ _ _ A A A A] .. D
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // zstsrc0Z भन्दा पहिले dst, src लपेट्छ, dst रैप गर्दैन
                //
                //
                //    .. S
                // १ [C C _ _ _ A A B B]
                // २ [C C _ _ _ B B B B]
                // X [C C _ _ _ B B C C] D।।
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src dst भन्दा पहिले, src लपेट्छ, dst रैप गर्दैन
                //
                //
                //    .. S
                // १ [A A B B _ _ _ C C]
                // २ [A A A A _ _ _ C C]
                // X [C C A A _ _ _ C C] D।।
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // Dst src भन्दा पहिले, src लपेट्छ, dst रैप
                //
                //
                //    ।.. S
                // १ [A B C D _ E F G H]
                // २ [A B C D _ E G H H]
                // X [A B C D _ E G H A]
                // X [B C C D _ E G H A] .. D।
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src dst भन्दा पहिले, src आवरण, dst रैप
                //
                //
                //    .. S।
                // १ [A B C D _ E F G H]
                // २ [A A B D _ E F G H]
                // X [H A B D _ E F G H]
                // X [H A B D _ E F F G]।.. D
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// टाउको र टेल टुक्राहरूको वरिपरि Frobs तथ्यलाई ह्यान्डल गर्नका लागि कि हामीले भर्खर पुन: स्थानान्तरण गरेका छौं।
    /// असुरक्षित किनकि यसले पुरानो क्षमताको भरोसा राख्दछ।
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // रि ring बफर TH को सब भन्दा छोटो मिल्दो भाग सार्नुहोस्
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [।।।ooooooo।।।।।।
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // होईन
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// खाली `VecDeque` सिर्जना गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// कम्तिमा `capacity` तत्वहरूको लागि खाली `VecDeque` सिर्जना गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +१ किनकि रिंगबफरले जहिले पनि एक खाली ठाउँ छोड्दछ
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// दिइएको अनुक्रमणिकामा एलिमेन्टलाई सन्दर्भ प्रदान गर्दछ।
    ///
    /// अनुक्रमणिका ० मा एलिमेन्ट लामको अगाडि हो।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// दिइएको अनुक्रमणिकामा तत्त्वलाई म्युटेबल सन्दर्भ प्रदान गर्दछ।
    ///
    /// अनुक्रमणिका ० मा एलिमेन्ट लामको अगाडि हो।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// सूचकांक `i` र `j` मा तत्व स्वैप गर्दछ।
    ///
    /// `i` र `j` बराबर हुन सक्छ।
    ///
    /// अनुक्रमणिका ० मा एलिमेन्ट लामको अगाडि हो।
    ///
    /// # Panics
    ///
    /// Panics यदि कुनै सूचकांक सीमा बाहिर छ भने।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// `VecDeque` पुन: प्रदर्शन नगरी समाउन सक्ने तत्वहरूको संख्या फर्काउँछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// ठीक `additional` अधिक तत्वहरूको लागि दिइएको `VecDeque` सम्मिलित गर्न न्यूनतम क्षमता आरक्षित गर्दछ।
    /// केहि गर्दैन यदि क्षमता पहिले नै पर्याप्त छ।
    ///
    /// नोट गर्नुहोस् कि विनियोजकले संग्रहले अनुरोध भन्दा बढी ठाउँ दिन सक्छ।
    /// त्यसैले क्षमता ठीक न्यूनतम हुन भर पर्न सक्दैन।
    /// [`reserve`] प्राथमिकता दिनुहोस् यदि future सम्मिलनहरू अपेक्षित छन्।
    ///
    /// # Panics
    ///
    /// Panics यदि नयाँ क्षमता `usize` ओभरफ्लो भयो।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// कम्तिमा `additional` अधिक तत्वहरू सम्मिलित `VecDeque` सम्मिलित गर्न क्षमता सुरक्षित गर्दछ।
    /// संग्रहले लगातार रिकलोकेशन्सबाट बच्न अधिक ठाउँ आरक्षित गर्न सक्दछ।
    ///
    /// # Panics
    ///
    /// Panics यदि नयाँ क्षमता `usize` ओभरफ्लो भयो।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// `additional` 1X अधिक तत्वहरू ठीक `VecDeque<T>` सम्मिलित गर्न न्यूनतम क्षमता आरक्षित गर्न कोसिस गर्दछ।
    ///
    /// `try_reserve_exact` कल गरेपछि, क्षमता `self.len() + additional` भन्दा बढि वा बराबर हुनेछ।
    /// केहि गर्दैन यदि क्षमता पहिले नै पर्याप्त छ।
    ///
    /// नोट गर्नुहोस् कि विनियोजकले संग्रहले अनुरोध भन्दा बढी ठाउँ दिन सक्छ।
    /// तसर्थ, क्षमता एकदम न्यूनतम हुन भर पर्न सक्दैन।
    /// `reserve` प्राथमिकता दिनुहोस् यदि future सम्मिलनहरू अपेक्षित छन्।
    ///
    /// # Errors
    ///
    /// यदि क्षमता ओभरफ्लो `usize`, वा विनियोजक एक विफलता रिपोर्ट, तब एक त्रुटि फर्काइन्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // मेमोरी प्रि-रिजर्भ गर्नुहोस्, यदि हामी सक्दैनौं भने बाहिर निस्कँदै
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // अब हामी जान्दछौं कि यो हाम्रो जटिल कामको बीचमा OOM(Out-Of-Memory) सक्दैन
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // धेरै जटिल
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// कम्तिमा `additional` थप तत्वहरू सम्मिलित `VecDeque<T>` सम्मिलित गर्न क्षमता रिजर्भ गर्न प्रयास गर्दछ।
    /// संग्रहले लगातार रिकलोकेशन्सबाट बच्न अधिक ठाउँ आरक्षित गर्न सक्दछ।
    /// `try_reserve` कल गरेपछि, क्षमता `self.len() + additional` भन्दा बढि वा बराबर हुनेछ।
    /// केहि गर्दैन यदि क्षमता पहिले नै पर्याप्त छ।
    ///
    /// # Errors
    ///
    /// यदि क्षमता ओभरफ्लो `usize`, वा विनियोजक एक विफलता रिपोर्ट, तब एक त्रुटि फर्काइन्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // मेमोरी प्रि-रिजर्भ गर्नुहोस्, यदि हामी सक्दैनौं भने बाहिर निस्कँदै
    ///     output.try_reserve(data.len())?;
    ///
    ///     // अब हामी जान्दछौं कि यो OOM हाम्रो जटिल कामको बिचमा गर्न सक्दैन
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // धेरै जटिल
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// सकेसम्म `VecDeque` को क्षमता संकुचन गर्दछ।
    ///
    /// यो लम्बाइमा जति सक्दो नजिक झर्नेछ तर वितरकले अझै `VecDeque` लाई सूचित गर्न सक्दछ कि केहि थप तत्वहरूको लागि खाली ठाउँ छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// तल्लो बाउन्डको साथ `VecDeque` को क्षमता संकुचन गर्दछ।
    ///
    /// क्षमता कम्तिमा दुबै लम्बाई र आपूर्ति गरिएको मानको रूपमा ठूलो रहनेछ।
    ///
    ///
    /// यदि हालको क्षमता तल्लो सीमा भन्दा कम छ भने, यो एक अप-अप हो।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // हामीले ओभरफ्लोको बारेमा चिन्ता लिनु पर्दैन किनकि न त `self.len()` न `self.capacity()` कहिल्यै `usize::MAX` हुन सक्छ।
        // रिंगबफरको रूपमा +१ ले जहिले पनि एक खाली ठाउँ छोड्दछ।
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // त्यहाँ चासोका तीनवटा केसहरू छन्:
            //   सबै तत्वहरू चाहेको सीमाहरू बाहिर छन् तत्वहरू मिल्दोजुल्दो छ, र टाउको चाहेको सीमाहरू भन्दा बाहिर तत्वहरू विसंगत छन्, र पुच्छर चाहेको सीमाना बाहिर छ।
            //
            //
            // सबै अन्य समयमा, तत्व स्थितिहरू अप्रभावित हुन्छन्।
            //
            // इशारा गर्दछ कि टाउकोमा एलिमेन्टहरू सारियो।
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // इच्छित सीमाबाट तत्वहरू सार्नुहोस् (लक्ष्य_क्याप पछाडि स्थिति)
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// `VecDeque` छोटो पार्छ, पहिलो `len` एलिमेन्ट राख्दै र बाँकी छोड्दै।
    ///
    ///
    /// यदि `len` `VecDeque` को वर्तमान लम्बाइ भन्दा ठूलो छ भने, यसले कुनै प्रभाव पार्दैन।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// स्लासमा सबै वस्तुहरूको लागि विनाशकारी चलाउँछ जब यो झर्दछ (सामान्य रूपमा वा अनइन्डि duringको समयमा)।
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // सुरक्षित किनभने:
        //
        // * `drop_in_place` मा पारित कुनै स्लाइस मान्य छ;दोस्रो केस `len <= front.len()` छ र `len > self.len()` मा फर्कदै `begin <= back.len()` पहिलो मामला मा सुनिश्चित गर्दछ
        //
        // * VecDeque को टाउको `drop_in_place` कल गर्नु अघि सारिएको छ, त्यसैले कुनै मान दुई पटक झारियो यदि `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // निश्चित गर्नुहोस् कि दोस्रो आधा ड्रप पनि भयो जब पहिलो एक panics मा एक विध्वंसक।
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// अगाडि-देखि-पछाडि इट्रेटर फर्काउँछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// अगाडि-देखि-पछाडि इटरेटर फर्काउँछ जुन म्यूटेबल सन्दर्भहरू फर्काउँछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // सुरक्षा: आन्तरिक `IterMut` सुरक्षा इन्वायरनेट स्थापना भएको छ किनभने
        // `ring` हामी सिर्जना गर्दछौं जीवनभरको लागि एक डेरेफ्रेन्सेबल स्लाइस '_।
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// `VecDeque` को सामग्रीहरूको क्रममा समावेश भएको स्लाइसहरूको जोडी फर्काउँछ।
    ///
    /// यदि [`make_contiguous`] पहिले कल गरिएको थियो, `VecDeque` का सबै तत्वहरू पहिलो स्लाइसमा हुनेछ र दोस्रो स्लाइस खाली हुनेछ।
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// `VecDeque` को सामग्रीहरूको क्रममा समावेश भएको स्लाइसहरूको जोडी फर्काउँछ।
    ///
    /// यदि [`make_contiguous`] पहिले कल गरिएको थियो, `VecDeque` का सबै तत्वहरू पहिलो स्लाइसमा हुनेछ र दोस्रो स्लाइस खाली हुनेछ।
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// `VecDeque` मा तत्वहरूको संख्या फर्काउँछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// `true` फर्काउँदछ यदि `VecDeque` खाली छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// एक इटरेटर बनाउँदछ जुन `VecDeque` मा निर्दिष्ट दायरा कभर गर्दछ।
    ///
    /// # Panics
    ///
    /// Panics यदि सुरूवात बिन्दु अन्तिम पोइन्ट भन्दा ठूलो छ वा यदि अन्तिम पोइन्ट vector को लम्बाई भन्दा ठूलो छ भने।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // पूर्ण दायराले सबै सामग्रीहरू समेट्छ
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // हामीसंग &self मा साझा संदर्भ Iter को '_ _ मा कायम छ।
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// एक इटरेटर बनाउँदछ जुन `VecDeque` मा निर्दिष्ट परिवर्तनीय दायरा कभर गर्दछ।
    ///
    /// # Panics
    ///
    /// Panics यदि सुरूवात बिन्दु अन्तिम पोइन्ट भन्दा ठूलो छ वा यदि अन्तिम पोइन्ट vector को लम्बाई भन्दा ठूलो छ भने।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // पूर्ण दायराले सबै सामग्रीहरू समेट्छ
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // सुरक्षा: आन्तरिक `IterMut` सुरक्षा इन्वायरनेट स्थापना भएको छ किनभने
        // `ring` हामी सिर्जना गर्दछौं जीवनभरको लागि एक डेरेफ्रेन्सेबल स्लाइस '_।
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// XinX मा निर्दिष्ट दायरा हटाउँछ र हटाईएका वस्तुहरू दिन्छ कि एक जलद ईटरेटर सिर्जना गर्दछ।
    ///
    /// नोट १: एलिमेन्ट दायरा हटाइनेछ यदि पुनरावृत्तिकर्ता अन्त्यसम्म उपभोग गरिएको छैन।
    ///
    /// नोट २: यो तोकिएको छैन कि कति तत्वहरू डेकबाट हटाइन्छ, यदि `Drain` मान खसालिएको छैन, तर holdsण यो समात्छ (उदाहरणको लागि, `mem::forget` को कारण)।
    ///
    ///
    /// # Panics
    ///
    /// Panics यदि सुरूवात बिन्दु अन्तिम पोइन्ट भन्दा ठूलो छ वा यदि अन्तिम पोइन्ट vector को लम्बाई भन्दा ठूलो छ भने।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // पूर्ण दायराले सबै सामग्री खाली गर्दछ
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // मेमोरी सुरक्षा
        //
        // जब Drain पहिलो सिर्जना गरिएको हो, स्रोत डेक छोटो बनाइएको छ सुनिश्चित गर्न को लागी कुनै चिन्ता नगरिकन वा सारिएको तत्वबाट कुनै पनि पहुँच योग्य छैन यदि Drain को विनाशकारी कहिल्यै चल्दैन।
        //
        //
        // Drain ले ptr::read हटाउनेछ मानहरू।
        // समाप्त भएपछि, बाँकी डाटा पछाडि प्रतिलिपि गरिनेछ प्वालमा प्वाल गर्न, र head/tail मानहरू ठीकसँग पुनर्स्थापना हुनेछ।
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // Deque को तत्वहरु लाई तीन खण्डहरु मा विभाजित गरीन्छ:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;H= self.head;t=drain_tail;h=drain_head
        //
        // हामी drain_tail self.head को रूपमा, र drain_head र self.head after_tail को रूपमा र पछि_हेड क्रमशः Drain मा स्टोर गर्दछौं।
        // यसले प्रभावी एर्रेलाई पनि छोट्याउँदछ कि यदि Drain लीक भयो भने, हामी drain को सुरूवात पछि सम्भावित मानहरू बिर्स्यौं।
        //
        //
        //        T th H
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" drain सुरु भएपछि drain पूरा नभएसम्म र Drain विध्वंसक चालु नभएसम्म मानहरूको बारेमा।
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // महत्वपूर्ण रूपमा, हामी केवल यहाँ `self` बाट साझा सन्दर्भ सिर्जना र बाट पढ्न।
                // हामी `self` मा लेख्दैनौं न एक म्यूटेबल सन्दर्भलाई पुनः देखाउन।
                // यसैले कच्चा सूचक हामीले माथि सिर्जना गरेका छौं, `deque` का लागि, मान्य रहन्छ।
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// `VecDeque` खाली गर्दछ, सबै मानहरू हटाउँदै।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// `true` फर्काउँछ यदि `VecDeque` ले दिइएको मानको बराबर तत्व समावेश गर्दछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// फ्रन्ट एलिमेन्ट, वा `None` को सन्दर्भ प्रदान गर्दछ यदि `VecDeque` खाली छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// फ्रन्ट एलिमेन्ट, वा `None` को लागि एक परिवर्तित सन्दर्भ प्रदान गर्दछ यदि `VecDeque` खाली छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// पछाडि तत्त्वलाई सन्दर्भ प्रदान गर्दछ, वा `None` यदि `VecDeque` खाली छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// `VecDeque` खाली छ भने पछाडि तत्त्व, वा `None` मा एक परिवर्तित सन्दर्भ प्रदान गर्दछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// पहिलो तत्वलाई हटाउछ र फर्काउँछ, वा `None` यदि `VecDeque` खाली छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// `VecDeque` बाट अन्तिम तत्व हटाउँछ र यसलाई फर्काउँछ, वा `None` यदि खाली छ भने।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// `VecDeque` मा एक तत्व तयार गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// `VecDeque` को पछाडि एक तत्व जोड्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: के हामीले `head == 0` भन्न खोज्नु पर्छ?
        // त्यो `self` मिल्छ कि?
        self.tail <= self.head
    }

    /// `VecDeque` मा जहाँसुकैबाट कुनै तत्व हटाउँदछ र फर्काउँछ, पहिलो तत्वको साथ प्रतिस्थापन गरेर।
    ///
    ///
    /// यसले अर्डरिंगलाई सुरक्षित गर्दैन, तर *O*(१) हो।
    ///
    /// `None` फर्काउँदछ यदि `index` सीमा भन्दा बाहिर छ।
    ///
    /// अनुक्रमणिका ० मा एलिमेन्ट लामको अगाडि हो।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// `VecDeque` मा कहिँबाट पनि एलिमेन्ट हटाउँदछ र अन्तिम तत्वको साथ प्रतिस्थापन गरेर फर्काउँछ।
    ///
    ///
    /// यसले अर्डरिंगलाई सुरक्षित गर्दैन, तर *O*(१) हो।
    ///
    /// `None` फर्काउँदछ यदि `index` सीमा भन्दा बाहिर छ।
    ///
    /// अनुक्रमणिका ० मा एलिमेन्ट लामको अगाडि हो।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// `index` मा `VecDeque` भित्र एलिमेन्ट घुसाउँदछ, सूचकका साथ सबै तत्वहरू बदल्छ `index` भन्दा पछाडि तर्फ।
    ///
    ///
    /// अनुक्रमणिका ० मा एलिमेन्ट लामको अगाडि हो।
    ///
    /// # Panics
    ///
    /// Panics यदि `index` `VecDeque` को लम्बाई भन्दा ठूलो छ
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // रिंग बफरमा तत्वहरूको कम्तिमा स Move्ख्या सार्नुहोस् र दिइएको वस्तु घुसाउनुहोस्
        //
        // अधिकतम len/2 मा, १ तत्वहरू सारिनेछन्। O(min(n, n-i))
        //
        // त्यहाँ तीन मुख्य केसहरू छन्:
        //  तत्वहरू मिल्दोजुल्दो छन्
        //      - विशेष केस जब पूंछ ० तत्त्वहरू विवादास्पद हुन्छन् र घुसाउँदो पूंछ सेक्सनमा हुन्छ एलिमेन्टहरू विवादास्पद हुन्छन् र घुसाउँदा शिर खण्डमा हुन्छ।
        //
        //
        // ती प्रत्येकको लागि त्यहाँ दुईवटा थप केसहरू छन्:
        //  घुसाउँदो पुच्छर नजिक छ सम्मिलित टाउको नजिक छ
        //
        // कुञ्जी: H, self.head
        //      T, self.tail o, मान्य عنصر I, सम्मिलन तत्व A, तत्व जुन सम्मिलित बिन्दु M पछि हुनु पर्दछ, इंगित गर्दछ तत्व सारियो।
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [Aoooooo।।।।।।
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // मिल्दो, पुच्छरको नजिक घुसाउनुहोस्:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // मिल्दो, पुच्छर र पुच्छरको नजिक घुसाउनुहोस् ०:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       MM

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // पहिले नै पुच्छर सारियो, त्यसैले हामी केवल `index - 1` तत्वहरू प्रतिलिपि गर्दछौं।
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // मिल्दो, शिरको नजिक घुसाउनुहोस्:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       Mmm

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // असन्तुष्ट, पुच्छरको नजिक सम्मिलित गर्नुहोस्, पुच्छर सेक्सन:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // असन्तुष्ट, टाउको नजिक पुग्नुहोस्, पुच्छर सेक्सन:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // नयाँ टाउको सम्म तत्वहरूको प्रतिलिपि गर्नुहोस्
                    self.copy(1, 0, self.head);

                    // बफरको तल खाली ठाउँमा अन्तिम तत्व प्रतिलिपि गर्नुहोस्
                    self.copy(0, self.cap() - 1, 1);

                    // एडीएमएक्सबाट एलिमेन्टहरू सार्नुहोस् अगाडि अन्तमा to तत्व समावेश गर्दैन
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // विसंगत, घुसाउनुहोस् पुच्छर, हेड सेक्सनको नजिक छ, र आन्तरिक बफरमा सूचकांक शून्यमा छ:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               Mmm

                    // नयाँ पुच्छर सम्म तत्वहरूको प्रतिलिपि गर्नुहोस्
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // बफरको तल खाली ठाउँमा अन्तिम तत्व प्रतिलिपि गर्नुहोस्
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // असंगत, पुच्छरको नजिक घुसाउनुहोस्, हेड सेक्सन:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // नयाँ पुच्छर सम्म तत्वहरूको प्रतिलिपि गर्नुहोस्
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // बफरको तल खाली ठाउँमा अन्तिम तत्व प्रतिलिपि गर्नुहोस्
                    self.copy(self.cap() - 1, 0, 1);

                    // तत्वहरू idx-1 बाट अगाडि अन्तमा सार्नुहोस् ^ एलिमेन्ट समावेश गर्दैन
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // असन्तुष्ट, टाउकोको नजिक घुसाउनुहोस्, हेड सेक्सन:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 Mmm

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // पुच्छ्न परिवर्तन भएको हुन सक्छ त्यसैले हामीलाई पुन: गणना गर्न आवश्यक पर्दछ
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// `VecDeque` बाट `index` मा तत्व हटाउँछ र फर्काउँछ।
    /// जुनसुकै अन्त पनि हटाउने बिन्दुको नजीकमा कोठामा सारिनेछ, र सबै प्रभावित तत्वहरू नयाँ स्थानहरूमा सारिनेछ।
    ///
    /// `None` फर्काउँदछ यदि `index` सीमा भन्दा बाहिर छ।
    ///
    /// अनुक्रमणिका ० मा एलिमेन्ट लामको अगाडि हो।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // त्यहाँ तीन मुख्य केसहरू छन्:
        //  एलिमेन्ट्स मिल्दोजुल्दो हुन्छन् एलिमेन्ट बिच्छेद हुन्छन् र हटाउने पूंछ सेक्सनमा हुन्छ एलिमेन्ट विचलित हुन्छ र र हटान टाउको सेक्सनमा छ।
        //
        //      - विशेष केस जब तत्वहरू प्राविधिक रूपमा संमिश्र छन्, तर self.head =0
        //
        // ती प्रत्येकको लागि त्यहाँ दुईवटा थप केसहरू छन्:
        //  घुसाउँदो पुच्छर नजिक छ सम्मिलित टाउको नजिक छ
        //
        // कुञ्जी: H, self.head
        //      T, self.tail o, मान्य عنصر x, तत्व हटाउनका लागि चिनो लगाइएको छ R, तत्व दर्शाउँछ जुन हटाइदैछ M, इंगित गर्दछ तत्व सारियो
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // मिल्दो, पुच्छरको नजिक हटाउनुहोस्:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // मिल्दो, टाउकोको नजिक हटाउनुहोस्:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // असन्तुष्ट, पुच्छरको नजिकै हटाउनुहोस्, पुच्छर सेक्सन:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // असन्तुष्ट, टाउको, टाउको सेक्सनको नजिक हटाउनुहोस्:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // असन्तुष्ट, टाउको नजिक पुग्नुहोस्, पुच्छर सेक्सन:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // वा अर्ध-असन्तुष्ट, टाउको पछाडि हटाउनुहोस्, पुच्छर सेक्सन:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // पुच्छर सेक्सनमा तत्वहरू कोर्नुहोस्
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // अण्डफ्लो रोक्दछ।
                    if self.head != 0 {
                        // खाली स्थानमा पहिलो तत्व प्रतिलिपि गर्नुहोस्
                        self.copy(self.cap() - 1, 0, 1);

                        // हेड सेक्सनमा एलिमेन्टहरू पछाडि सर्नुहोस्
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // असन्तुष्ट, पुच्छरको नजिक, शिर खण्ड हटाउनुहोस्:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // आईडीएक्स सम्म तत्वहरूमा ड्र गर्नुहोस्
                    self.copy(1, 0, idx);

                    // खाली स्थानमा अन्तिम तत्व प्रतिलिपि गर्नुहोस्
                    self.copy(0, self.cap() - 1, 1);

                    // अन्तिमलाई बाहेक, पुच्छरबाट तत्त्वहरू अन्तमा अगाडि सर्नुहोस्
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// दिइएको सूचकांकमा `VecDeque` लाई दुईमा विभाजन गर्दछ।
    ///
    /// नयाँ बाँडिएको `VecDeque` फर्काउँछ।
    /// `self` एलिमेन्ट्स `[0, at)`, र फिर्ता `VecDeque` समावेश गर्दछ `[at, len)`।
    ///
    /// नोट गर्नुहोस् कि `self` को क्षमता परिवर्तन हुँदैन।
    ///
    /// अनुक्रमणिका ० मा एलिमेन्ट लामको अगाडि हो।
    ///
    /// # Panics
    ///
    /// Panics यदि `at > len`।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` पहिलो आधा मा छ।
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // केवल दोस्रो आधा को सबै ले।
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` दोस्रो आधामा रहेको छ, तत्त्वहरूमा फ्याक्टर आवश्यक छ हामीले पहिलो हाफमा छोडेका छौं।
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // सफा गर्नुहोस् जहाँ बफरहरूको अन्त हुन्छ
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// `other` का सबै तत्वहरूलाई `self` मा सार्दछ, `other` खाली छोड्छ।
    ///
    /// # Panics
    ///
    /// Panics यदि आफैंमा एलिमेन्ट्सको नयाँ संख्याले `usize` ओभरफ्लो गर्दछ भने।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // भोली impl
        self.extend(other.drain(..));
    }

    /// पूर्वानुमान द्वारा निर्दिष्ट तत्वहरू मात्र राख्छ।
    ///
    /// अर्को शब्दहरूमा, सबै तत्वहरू `e` हटाउनुहोस् कि `f(&e)` गलत फर्काउँछ।
    /// यो विधि स्थानमा सञ्चालन गर्दछ, प्रत्येक तत्व एक पटक मूल क्रममा एक पटक भ्रमण गर्‍यो, र राखिएको तत्त्वहरूको क्रम सुरक्षित गर्दछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// सहि अर्डर बाह्य अवस्था ट्र्याक गर्नको लागि उपयोगी हुन सक्छ, जस्तै एक सूचकांक जस्तो।
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // यो panic वा परित्याग गर्न सक्दछ
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // बफर आकार डबल।
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// `VecDeque` in-place मा परिमार्जन गर्दछ ताकि `len()` `new_len` बराबर हो, या त पछाडिबाट अतिरिक्त तत्वहरू हटाएर वा `generator` लाई पछाडि कल गरेर उत्पन्न गरिएको एलिमेन्टहरू थप गरेर।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// यस डिकको आन्तरिक भण्डारणको पुन: व्यवस्था गर्दछ त्यसैले यो एक मिल्दो स्लाइस हो, जुन पछि फिर्ता हुन्छ।
    ///
    /// यस विधिले विनियोजित गर्दैन र सम्मिलित तत्त्वहरूको क्रम परिवर्तन गर्दैन।जब यसले म्युटेबल स्लाइस फिर्ता गर्छ, यो एक डेक्व क्रमबद्ध गर्न प्रयोग गर्न सकिन्छ।
    ///
    /// एक पटक आन्तरिक भण्डारण संगठित भएपछि, [`as_slices`] र [`as_mut_slices`] विधिहरू `VecDeque` को सम्पूर्ण सामग्रीहरू एक टुक्रामा फर्काउँदछ।
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Deque को सामग्री क्रमबद्ध गर्दै।
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // Deque क्रमबद्ध
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // उल्टो क्रममा क्रमबद्ध गर्दै
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// मिल्दो स्लाइसमा अपरिवर्तनीय पहुँच प्राप्त गर्दै।
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // हामी अब यो सुनिश्चित गर्न सक्छौं कि `slice` मा डेक्‍यूको सबै तत्वहरू छन्, अझै `buf` X मा अपरिवर्तनीय पहुँच हुँदा।
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // एकै चोटिमा पुच्छिको प्रतिलिपि गर्न पर्याप्त खाली ठाउँ छ, यसको मतलब यो हो कि हामीले पहिले हेडलाई पछाडि सर्छौं, र त्यसपछि पूँछलाई सही स्थानमा प्रतिलिपि गर्दछौं।
            //
            //
            // बाट: DEFGH .... ABC
            // लाई: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: हामी हाल विचार गर्दैनौं .... ABCDEFGH
            // संगत हुनको लागि किनकि यस अवस्थामा `head` `0` हुनेछ।
            // जबकि हामी सायद यसलाई परिवर्तन गर्न चाहान्छौं तर यो तुच्छ छैन किनकि केहि स्थानहरूले `is_contiguous` को अर्थ अपेक्षा गर्छ कि हामी केवल `buf[tail..head]` प्रयोग गरेर टुक्रा गर्न सक्छौं।
            //
            //

            // एकै चोटि टाउको प्रतिलिपि गर्न पर्याप्त खाली ठाउँ छ, यसको मतलब यो हो कि हामी पहिले पुच्छर अगाडि सर्छौं, र त्यसपछि टाउको सहि स्थितिमा प्रतिलिपि गर्छौं।
            //
            //
            // बाट: FGH .... ABCDE
            // लाई: ... ABCDEFGH।
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // फ्री दुबै टाउको र पुच्छर भन्दा सानो छ, यसको मतलब हामीले बिस्तारै पुच्छर र टाउको "swap" गर्नु पर्छ।
            //
            //
            // बाट: EFGHI ... ABCD वा HIJK.ABCDEFG
            // to: ABCDEFGHI ... वा ABCDEFGHIJK।
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // सामान्य समस्या यो GHIJKLM जस्तो देखिन्छ ... ABCDEF, कुनै पनि बदलाव अगाडि ABCDEFM ... GHIJKL, १ बदलाव पछि ABCDEFGHIJM ... KL, बायाँ edge टेम्प स्टोरमा पुग्न नसक्दासम्म स्वाप
                //                  - त्यसो भए नयाँ (smaller) स्टोरको साथ एल्गोरिथ्म पुनःस्टार्ट गर्नुहोस् कहिलेकाँही टेम्प स्टोर हुन्छ जब दायाँ edge बफरको अन्त्यमा हुन्छ, यसको मतलब हामीले थोरै स्वपको साथ सहि क्रममा हिर्कायौं!
                //
                // E.g
                // EF..ABCD ABCDEF .., चार मात्र स्वॅप पछि हामीले समाप्त गर्यौं
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// बायाँमा डबल समाप्त भएको लाम `mid` ठाउँहरू घुमाउँदछ।
    ///
    /// Equivalently,
    /// - वस्तु `mid` लाई पहिलो स्थितिमा घुमाउँदछ।
    /// - पहिलो `mid` आईटमहरू पप गर्दछ र तिनीहरूलाई अन्तमा धक्का दिन्छ।
    /// - दाँयामा `len() - mid` ठाउँहरू घुमाउँदछ।
    ///
    /// # Panics
    ///
    /// यदि `mid` `len()` भन्दा ठूलो छ।
    /// नोट गर्नुहोस् कि `mid == len()` _not_ panic गर्दछ र कुनै अप्ट रोटेशन हो।
    ///
    /// # Complexity
    ///
    /// `*O*(min(mid, len() - mid))` समय लिन्छ र अतिरिक्त ठाउँ छैन।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// दायाँ तिर डबल समाप्त भएको लाम `k` स्थानहरू घुमाउँदछ।
    ///
    /// Equivalently,
    /// - पहिलो वस्तुलाई `k` मा घुमाउँदछ।
    /// - अन्तिम `k` आईटमहरू पोप गर्दछ र तिनीहरूलाई अगाडि धक्का दिन्छ।
    /// - बाँया `len() - k` X स्थानहरू घुमाउँछ।
    ///
    /// # Panics
    ///
    /// यदि `k` `len()` भन्दा ठूलो छ।
    /// नोट गर्नुहोस् कि `k == len()` _not_ panic गर्दछ र कुनै अप्ट रोटेशन हो।
    ///
    /// # Complexity
    ///
    /// `*O*(min(k, len() - k))` समय लिन्छ र अतिरिक्त ठाउँ छैन।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // सुरक्षा: निम्न दुई विधिहरूलाई रोटेसन रकमको आवश्यक पर्दछ
    // Deque को आधा भन्दा कम लम्बाई हुनुहोस्।
    //
    // `wrap_copy` यसको लागि `min(x, cap() - x) + copy_len <= cap()` आवश्यक छ, तर `min` भन्दा कहिले पनि x को आधा क्षमता भन्दा बढी हुँदैन, त्यसैले यहाँ कल गर्नु राम्रो हुन्छ किनकि हामी आधा लम्बाई भन्दा कमको साथ कल गर्दैछौं जुन आधा क्षमता भन्दा माथि कहिल्यै हुँदैन।
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// बाइनरी खोजिएको एलिमेन्टको लागि क्रमबद्ध गरिएको `VecDeque`।
    ///
    /// यदि मान फेला पारियो भने [`Result::Ok`] फिर्ता हुन्छ, मिल्दो तत्वको अनुक्रमणिका समावेश गर्दै।
    /// यदि त्यहाँ धेरै खेलहरू छन् भने कुनै पनि खेलहरू फिर्ता हुन सक्छ।
    /// यदि मान फेला परेन भने [`Result::Err`] फिर्ता हुन्छ, अनुक्रमणिका समावेश गर्दै जहाँ मिलान तत्त्व घुसाउन सकिन्छ क्रमबद्ध क्रम कायम गर्न।
    ///
    ///
    /// # Examples
    ///
    /// चार तत्वहरूको श्रृंखला देखिन्छ।
    /// पहिलो फेला परेको छ, अद्वितीय रूपमा निर्धारित स्थितिको साथ;दोस्रो र तेस्रो फेला परेन;चौथो `[1, 4]` मा कुनै पनि स्थिति मेल गर्न सक्छ।
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// यदि तपाईं क्रमबद्ध गरिएको क्रमबद्ध गर्दै, क्रमबद्ध गरिएको `VecDeque` मा आईटम घुसाउन चाहनुहुन्छ भने:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// बाइनरी खोज गर्दछ यो क्रमबद्ध `VecDeque` एक कम्पेरेटर प्रकार्यको साथ।
    ///
    /// कम्प्याटर गर्ने प्रकार्यले क्रमबद्ध `VecDeque` को क्रमबद्ध अर्डरसँग मिल्दो अर्डर कार्यान्वयन गर्नुपर्दछ, अर्डर कोड फिर्ता गर्दछ जुन त्यसको आर्गुमेन्ट अपेक्षित लक्षित भन्दा `Less`, `Equal` वा `Greater` हो कि होइन भनेर संकेत गर्दछ।
    ///
    ///
    /// यदि मान फेला पारियो भने [`Result::Ok`] फिर्ता हुन्छ, मिल्दो तत्वको अनुक्रमणिका समावेश गर्दै।यदि त्यहाँ धेरै खेलहरू छन् भने कुनै पनि खेलहरू फिर्ता हुन सक्छ।
    /// यदि मान फेला परेन भने [`Result::Err`] फिर्ता हुन्छ, अनुक्रमणिका समावेश गर्दै जहाँ मिलान तत्त्व घुसाउन सकिन्छ क्रमबद्ध क्रम कायम गर्न।
    ///
    /// # Examples
    ///
    /// चार तत्वहरूको श्रृंखला देखिन्छ।पहिलो फेला परेको छ, अद्वितीय रूपमा निर्धारित स्थितिको साथ;दोस्रो र तेस्रो फेला परेन;चौथो `[1, 4]` मा कुनै पनि स्थिति मेल गर्न सक्छ।
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// बाइनरी खोज यो कुञ्जी निकासी प्रकार्य संग `VecDeque` क्रमबद्ध।
    ///
    /// मानिन्छ कि `VecDeque` कुञ्जी द्वारा क्रमबद्ध गरिएको छ, उदाहरणको लागि [`make_contiguous().sort_by_key()`](#method.make_contiguous) समान कुञ्जी निष्कर्षण प्रकार्य प्रयोग गरेर।
    ///
    ///
    /// यदि मान फेला पारियो भने [`Result::Ok`] फिर्ता हुन्छ, मिल्दो तत्वको अनुक्रमणिका समावेश गर्दै।
    /// यदि त्यहाँ धेरै खेलहरू छन् भने कुनै पनि खेलहरू फिर्ता हुन सक्छ।
    /// यदि मान फेला परेन भने [`Result::Err`] फिर्ता हुन्छ, अनुक्रमणिका समावेश गर्दै जहाँ मिलान तत्त्व घुसाउन सकिन्छ क्रमबद्ध क्रम कायम गर्न।
    ///
    /// # Examples
    ///
    /// दुई तत्वहरूको क्रमबद्ध जोडीको स्लाइसमा चार तत्वहरूको श्रृंखला देखिन्छ।
    /// पहिलो फेला परेको छ, अद्वितीय रूपमा निर्धारित स्थितिको साथ;दोस्रो र तेस्रो फेला परेन;चौथो `[1, 4]` मा कुनै पनि स्थिति मेल गर्न सक्छ।
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// `VecDeque` लाई ठाउँमा बदल्नुहोस् ताकि `len()` new_len बराबर हो, या त पछाडिबाट अतिरिक्त तत्वहरू हटाएर वा `value` को क्लोनहरू पछाडि थप्दै।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// दिइएको तार्किक तत्व अनुक्रमणिकाको लागि अन्तर्निहित बफरमा सूचका Return्क फर्काउँछ।
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // आकार सँधै २ को एक शक्ति हो
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// बफरमा पढ्नको लागि बाँकी रहेका तत्वहरूको संख्या गणना गर्नुहोस्
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // आकार सँधै २ को एक शक्ति हो
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // सँधै तीन खण्डमा विभाजन गर्न मिल्छ, उदाहरणका लागि: स्वयं: [a b c|d e f] अन्य: [0 1 2 3|4 5] फ्रन्ट=,, मध्य=१, [a b c] == [0 1 2] र&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // As_slices विधि द्वारा फर्केका स्लाइसहरूमा Hash::hash_slice प्रयोग गर्न सम्भव छैन किनकि तिनीहरूको लम्बाइ अन्यथा उस्तै डेक्सामा फरक पर्न सक्दछ।
        //
        //
        // ह्याशरले केवल यसको विधिहरूमा कलहरूको ठीक समान सेटको लागि समानताको ग्यारेन्टी गर्दछ।
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// `VecDeque` लाई अगाडि-देखि-पछाडि पुनरावृत्तकर्तामा मान उपज तत्वहरू उपभोग गर्दछ।
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // यो प्रकार्यको नैतिक बराबर हुनुपर्दछ:
        //
        //      iter.into_iter() item मा आईटमको लागि
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// [`Vec<T>`] लाई [`VecDeque<T>`] मा बदल्नुहोस्।
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// यो जहाँ सम्भव सम्भव reallocating लाई बेवास्ता गर्दछ, तर त्यसका सर्तहरू कडा छन्, र परिवर्तनको अधीनमा छन्, र त्यसैले `Vec<T>` `From<VecDeque<T>>` बाट आएको नभएसम्म भरोसा गर्नु हुँदैन र पुन: केन्द्रित नगरिनु पर्छ।
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // क्षमताको बारेमा चिन्ताको लागि ZST को लागि कुनै वास्तविक विनियोजन छैन, तर `VecDeque` `Vec` भन्दा बढी लम्बाई ह्यान्डल गर्न सक्दैन।
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // हामीले पुनःआकार गर्नु पर्छ यदि क्षमता दुईको पावर होईन, धेरै सानो छ वा कम्तिमा एउटा खाली ठाउँ छैन।
            // हामी यो गर्छौं जबकि यो अझै `Vec` X मा छ त्यसैले वस्तुहरू panic मा ड्रप हुनेछ।
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// [`VecDeque<T>`] लाई [`Vec<T>`] मा बदल्नुहोस्।
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// यसलाई कहिले पनि पुन: बाँडफाँड गर्नु आवश्यक पर्दैन, तर *O*(*n*) डाटा आन्दोलन गर्नु आवश्यक छ यदि सर्कुलर बफर विनियोजनको सुरूमा भएन भने।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // यो एक *O*(१) हो।
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // यो एक लाई डाटा पुनर्व्यवस्थित गर्न आवश्यक छ।
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}