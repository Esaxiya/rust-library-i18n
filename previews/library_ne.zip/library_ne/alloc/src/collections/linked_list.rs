//! स्वामित्वयुक्त नोडहरूको साथ दुबै-लि linked्क गरिएको सूची।
//!
//! `LinkedList` ले धकेल्छ र पपिंग एलिमेन्टहरूलाई स्थिर समयमा कि त अन्तमा अनुमति दिन्छ।
//!
//! NOTE: [`Vec`] वा [`VecDeque`] प्रयोग गर्नको लागि यो सधैं उत्तम हुन्छ किनकि एर्रे-आधारित कन्टेनरहरू सामान्य रूपमा छिटो हुन्छन्, अधिक मेमोरी दक्ष छन्, र CPU क्यासको राम्रो प्रयोग गर्दछन्।
//!
//!
//! [`Vec`]: crate::vec::Vec
//! [`VecDeque`]: super::vec_deque::VecDeque
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::Ordering;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem;
use core::ptr::NonNull;

use super::SpecExtend;
use crate::boxed::Box;

#[cfg(test)]
mod tests;

/// स्वामित्वयुक्त नोडहरूको साथ दुबै-लि linked्क गरिएको सूची।
///
/// `LinkedList` ले धकेल्छ र पपिंग एलिमेन्टहरूलाई स्थिर समयमा कि त अन्तमा अनुमति दिन्छ।
///
/// NOTE: `Vec` वा `VecDeque` प्रयोग गर्नको लागि यो सधैं उत्तम हुन्छ किनकि एर्रे-आधारित कन्टेनरहरू सामान्य रूपमा छिटो हुन्छन्, अधिक मेमोरी दक्ष छन्, र CPU क्यासको राम्रो प्रयोग गर्दछन्।
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "LinkedList")]
pub struct LinkedList<T> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<Box<Node<T>>>,
}

struct Node<T> {
    next: Option<NonNull<Node<T>>>,
    prev: Option<NonNull<Node<T>>>,
    element: T,
}

/// `LinkedList` को तत्वहरूमा एक पुनरावृत्ति।
///
/// यो `struct` [`LinkedList::iter()`] द्वारा बनाईएको हो।
/// अधिकको लागि यसको कागजात हेर्नुहोस्।
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<&'a Node<T>>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.len).finish()
    }
}

// FIXME(#26925) `#[derive(Clone)]` को पक्षमा हटाउनुहोस्
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ..*self }
    }
}

/// `LinkedList` को तत्वहरूमा एक परिवर्तनीय पुनरावृत्ति।
///
/// यो `struct` [`LinkedList::iter_mut()`] द्वारा बनाईएको हो।
/// अधिकको लागि यसको कागजात हेर्नुहोस्।
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    // हामी यहाँ *पूर्ण रूपमा सम्पूर्ण सूचीको स्वामित्व* गर्दैनौं, नोडको `element` को सन्दर्भ इट्रेटरले हस्तान्तरण गरेको छ!त्यसैले यो प्रयोग गर्दा सावधान रहनुहोस्;भनिएका विधिहरू सतर्क हुनुपर्दछ कि त्यहाँ `element` मा एलियासिंग पोइन्टरहरू हुन सक्छन्।
    //
    //
    list: &'a mut LinkedList<T>,
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IterMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IterMut").field(&self.list).field(&self.len).finish()
    }
}

/// `LinkedList` को एलिमेन्टहरूमा मालिकको मालिक।
///
/// यो `struct` [`into_iter`] विधि द्वारा बनाइएको [`LinkedList`] (`IntoIterator` trait द्वारा प्रदान गरिएको)।
/// अधिकको लागि यसको कागजात हेर्नुहोस्।
///
/// [`into_iter`]: LinkedList::into_iter
#[derive(Clone)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    list: LinkedList<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.list).finish()
    }
}

impl<T> Node<T> {
    fn new(element: T) -> Self {
        Node { next: None, prev: None, element }
    }

    fn into_element(self: Box<Self>) -> T {
        self.element
    }
}

// निजी विधिहरू
impl<T> LinkedList<T> {
    /// दिईएको नोडलाई सूचीको अगाडि थप्दछ।
    #[inline]
    fn push_front_node(&mut self, mut node: Box<Node<T>>) {
        // यो विधिले `element` मा aliasing पोइन्टर्सको वैधता कायम गर्न, सम्पूर्ण नोडहरूमा परिवर्तनीय सन्दर्भ सिर्जना नगर्न सावधानी लिन्छ।
        //
        unsafe {
            node.next = self.head;
            node.prev = None;
            let node = Some(Box::leak(node).into());

            match self.head {
                None => self.tail = node,
                // नयाँ परिवर्तनीय (unique!) सन्दर्भहरू ओभरल्यापि X `element` सिर्जना गर्दै।
                Some(head) => (*head.as_ptr()).prev = node,
            }

            self.head = node;
            self.len += 1;
        }
    }

    /// सूचीको अगाडि नोड हटाउँछ र फर्काउँछ।
    #[inline]
    fn pop_front_node(&mut self) -> Option<Box<Node<T>>> {
        // यो विधिले `element` मा aliasing पोइन्टर्सको वैधता कायम गर्न, सम्पूर्ण नोडहरूमा परिवर्तनीय सन्दर्भ सिर्जना नगर्न सावधानी लिन्छ।
        //
        self.head.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.head = node.next;

            match self.head {
                None => self.tail = None,
                // नयाँ परिवर्तनीय (unique!) सन्दर्भहरू ओभरल्यापि X `element` सिर्जना गर्दै।
                Some(head) => (*head.as_ptr()).prev = None,
            }

            self.len -= 1;
            node
        })
    }

    /// दिईएको नोडलाई सूचीको पछाडि थप्दछ।
    #[inline]
    fn push_back_node(&mut self, mut node: Box<Node<T>>) {
        // यो विधिले `element` मा aliasing पोइन्टर्सको वैधता कायम गर्न, सम्पूर्ण नोडहरूमा परिवर्तनीय सन्दर्भ सिर्जना नगर्न सावधानी लिन्छ।
        //
        unsafe {
            node.next = None;
            node.prev = self.tail;
            let node = Some(Box::leak(node).into());

            match self.tail {
                None => self.head = node,
                // नयाँ परिवर्तनीय (unique!) सन्दर्भहरू ओभरल्यापि X `element` सिर्जना गर्दै।
                Some(tail) => (*tail.as_ptr()).next = node,
            }

            self.tail = node;
            self.len += 1;
        }
    }

    /// सूचीको पछाडि नोड हटाउँछ र फर्काउँछ।
    #[inline]
    fn pop_back_node(&mut self) -> Option<Box<Node<T>>> {
        // यो विधिले `element` मा aliasing पोइन्टर्सको वैधता कायम गर्न, सम्पूर्ण नोडहरूमा परिवर्तनीय सन्दर्भ सिर्जना नगर्न सावधानी लिन्छ।
        //
        self.tail.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.tail = node.prev;

            match self.tail {
                None => self.head = None,
                // नयाँ परिवर्तनीय (unique!) सन्दर्भहरू ओभरल्यापि X `element` सिर्जना गर्दै।
                Some(tail) => (*tail.as_ptr()).next = None,
            }

            self.len -= 1;
            node
        })
    }

    /// हालको सूचीबाट निर्दिष्ट नोडलाई अनलिंक गर्दछ।
    ///
    /// चेतावनी: यसले जाँच गर्दैन कि प्रदान गरिएको नोड वर्तमान सूचीमा सम्बन्धित छ।
    ///
    /// यो विधिले `element` मा परिवर्तनीय सन्दर्भहरू सिर्जना नगर्न सावधानी लिन्छ, Aliasing pointrs को वैधता कायम गर्न।
    ///
    #[inline]
    unsafe fn unlink_node(&mut self, mut node: NonNull<Node<T>>) {
        let node = unsafe { node.as_mut() }; // यो अब हाम्रो हो, हामी &mut सिर्जना गर्न सक्छौं।

        // नयाँ परिवर्तनीय (unique!) सन्दर्भहरू ओभरल्यापि X `element` सिर्जना गर्दै।
        match node.prev {
            Some(prev) => unsafe { (*prev.as_ptr()).next = node.next },
            // यो नोड हेड नोड हो
            None => self.head = node.next,
        };

        match node.next {
            Some(next) => unsafe { (*next.as_ptr()).prev = node.prev },
            // यो नोड पूंछ नोड हो
            None => self.tail = node.prev,
        };

        self.len -= 1;
    }

    /// दुई अवस्थित नोडहरू बीच नोडहरूको श्रृंखला विभाजन गर्दछ।
    ///
    /// चेतावनी: यसले जाँच गर्दैन कि प्रदान गरिएको नोड दुई अवस्थित सूचीमा सम्बन्धित छ।
    #[inline]
    unsafe fn splice_nodes(
        &mut self,
        existing_prev: Option<NonNull<Node<T>>>,
        existing_next: Option<NonNull<Node<T>>>,
        mut splice_start: NonNull<Node<T>>,
        mut splice_end: NonNull<Node<T>>,
        splice_length: usize,
    ) {
        // यो विधि `element` मा aliasing पोइन्टर्सको वैधता कायम गर्न एकै समयमा सम्पूर्ण नोडहरूमा बहु परिवर्तनीय सन्दर्भहरू सिर्जना नगर्न सावधान रहन्छ।
        //
        if let Some(mut existing_prev) = existing_prev {
            unsafe {
                existing_prev.as_mut().next = Some(splice_start);
            }
        } else {
            self.head = Some(splice_start);
        }
        if let Some(mut existing_next) = existing_next {
            unsafe {
                existing_next.as_mut().prev = Some(splice_end);
            }
        } else {
            self.tail = Some(splice_end);
        }
        unsafe {
            splice_start.as_mut().prev = existing_prev;
            splice_end.as_mut().next = existing_next;
        }

        self.len += splice_length;
    }

    /// नोडहरूको श्रृंखलाको रूपमा लि list्क गरिएको सूचीबाट सबै नोडहरू अलग गर्दछ।
    #[inline]
    fn detach_all_nodes(mut self) -> Option<(NonNull<Node<T>>, NonNull<Node<T>>, usize)> {
        let head = self.head.take();
        let tail = self.tail.take();
        let len = mem::replace(&mut self.len, 0);
        if let Some(head) = head {
            let tail = tail.unwrap_or_else(|| unsafe { core::hint::unreachable_unchecked() });
            Some((head, tail, len))
        } else {
            None
        }
    }

    #[inline]
    unsafe fn split_off_before_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // स्प्लिट नोड दोस्रो भागको नयाँ हेड नोड हो
        if let Some(mut split_node) = split_node {
            let first_part_head;
            let first_part_tail;
            unsafe {
                first_part_tail = split_node.as_mut().prev.take();
            }
            if let Some(mut tail) = first_part_tail {
                unsafe {
                    tail.as_mut().next = None;
                }
                first_part_head = self.head;
            } else {
                first_part_head = None;
            }

            let first_part = LinkedList {
                head: first_part_head,
                tail: first_part_tail,
                len: at,
                marker: PhantomData,
            };

            // दोस्रो भागको हेड ptr फिक्स गर्नुहोस्
            self.head = Some(split_node);
            self.len = self.len - at;

            first_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }

    #[inline]
    unsafe fn split_off_after_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // विभाजित नोड पहिलो भागको नयाँ पुच्छर नोड हो र दोस्रो भागको टाउकोको स्वामित्व राख्छ।
        //
        if let Some(mut split_node) = split_node {
            let second_part_head;
            let second_part_tail;
            unsafe {
                second_part_head = split_node.as_mut().next.take();
            }
            if let Some(mut head) = second_part_head {
                unsafe {
                    head.as_mut().prev = None;
                }
                second_part_tail = self.tail;
            } else {
                second_part_tail = None;
            }

            let second_part = LinkedList {
                head: second_part_head,
                tail: second_part_tail,
                len: self.len - at,
                marker: PhantomData,
            };

            // पहिलो भागको पूंछ ptr ठीक गर्नुहोस्
            self.tail = Some(split_node);
            self.len = at;

            second_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for LinkedList<T> {
    /// खाली `LinkedList<T>` सिर्जना गर्दछ।
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

impl<T> LinkedList<T> {
    /// खाली `LinkedList` सिर्जना गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let list: LinkedList<u32> = LinkedList::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_linked_list_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        LinkedList { head: None, tail: None, len: 0, marker: PhantomData }
    }

    /// `other` बाट सूचीको अन्तमा सबै तत्वहरू सार्दछ।
    ///
    /// यसले `other` बाट सबै नोडहरू पुन: प्रयोग गर्दछ र तिनीहरूलाई `self` मा सार्दछ।
    /// यस अपरेशन पछि, `other` खाली हुन्छ।
    ///
    /// यस अपरेशनले *O*(१) समय र *O*(१) मेमोरीमा गणना गर्नुपर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list1 = LinkedList::new();
    /// list1.push_back('a');
    ///
    /// let mut list2 = LinkedList::new();
    /// list2.push_back('b');
    /// list2.push_back('c');
    ///
    /// list1.append(&mut list2);
    ///
    /// let mut iter = list1.iter();
    /// assert_eq!(iter.next(), Some(&'a'));
    /// assert_eq!(iter.next(), Some(&'b'));
    /// assert_eq!(iter.next(), Some(&'c'));
    /// assert!(iter.next().is_none());
    ///
    /// assert!(list2.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn append(&mut self, other: &mut Self) {
        match self.tail {
            None => mem::swap(self, other),
            Some(mut tail) => {
                // `as_mut` यहाँ ठिक छ किनकि हामी दुबै सूचिहरुमा सम्पूर्ण पहुँचका लागि विशेष पहुँच छ।
                //
                if let Some(mut other_head) = other.head.take() {
                    unsafe {
                        tail.as_mut().next = Some(other_head);
                        other_head.as_mut().prev = Some(tail);
                    }

                    self.tail = other.tail.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// `other` बाट सूचीको सुरूमा सबै तत्वहरू सार्दछ।
    #[unstable(feature = "linked_list_prepend", issue = "none")]
    pub fn prepend(&mut self, other: &mut Self) {
        match self.head {
            None => mem::swap(self, other),
            Some(mut head) => {
                // `as_mut` यहाँ ठिक छ किनकि हामी दुबै सूचिहरुमा सम्पूर्ण पहुँचका लागि विशेष पहुँच छ।
                //
                if let Some(mut other_tail) = other.tail.take() {
                    unsafe {
                        head.as_mut().prev = Some(other_tail);
                        other_tail.as_mut().next = Some(head);
                    }

                    self.head = other.head.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// एक अगाडि पुनरावृत्ति प्रदान गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { head: self.head, tail: self.tail, len: self.len, marker: PhantomData }
    }

    /// परिवर्तनीय सन्दर्भहरूको साथ एक अगाडि पुनरावृत्ति प्रदान गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// for element in list.iter_mut() {
    ///     *element += 10;
    /// }
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&10));
    /// assert_eq!(iter.next(), Some(&11));
    /// assert_eq!(iter.next(), Some(&12));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { head: self.head, tail: self.tail, len: self.len, list: self }
    }

    /// फ्रन्ट एलिमेन्टमा कर्सर प्रदान गर्दछ।
    ///
    /// यदि सूची खाली छ भने कर्सरले "ghost" गैर-तत्वलाई औंल्याइरहेको छ।
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front(&self) -> Cursor<'_, T> {
        Cursor { index: 0, current: self.head, list: self }
    }

    /// फ्रन्ट एलिमेन्टमा सम्पादन अपरेशनको साथ कर्सर प्रदान गर्दछ।
    ///
    /// यदि सूची खाली छ भने कर्सरले "ghost" गैर-तत्वलाई औंल्याइरहेको छ।
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: 0, current: self.head, list: self }
    }

    /// पछाडि तत्त्वमा कर्सर प्रदान गर्दछ।
    ///
    /// यदि सूची खाली छ भने कर्सरले "ghost" गैर-तत्वलाई औंल्याइरहेको छ।
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back(&self) -> Cursor<'_, T> {
        Cursor { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// पछाडि तत्त्वमा सम्पादन सञ्चालनको साथ कर्सर प्रदान गर्दछ।
    ///
    /// यदि सूची खाली छ भने कर्सरले "ghost" गैर-तत्वलाई औंल्याइरहेको छ।
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// `true` फर्काउँदछ यदि `LinkedList` खाली छ।
    ///
    /// यो अपरेशन *O*(१) समयमा गणना गर्नु पर्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert!(dl.is_empty());
    ///
    /// dl.push_front("foo");
    /// assert!(!dl.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.head.is_none()
    }

    /// `LinkedList` को लम्बाई फर्काउँछ।
    ///
    /// यो अपरेशन *O*(१) समयमा गणना गर्नु पर्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.len(), 1);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    ///
    /// dl.push_back(3);
    /// assert_eq!(dl.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// `LinkedList` बाट सबै तत्व हटाउँछ।
    ///
    /// यस अपरेशनले *O*(*n*) समयमा गणना गर्नुपर्नेछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// dl.clear();
    /// assert_eq!(dl.len(), 0);
    /// assert_eq!(dl.front(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = Self::new();
    }

    /// `true` फर्काउँछ यदि `LinkedList` ले दिइएको मानको बराबर तत्व समावेश गर्दछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// assert_eq!(list.contains(&0), true);
    /// assert_eq!(list.contains(&10), false);
    /// ```
    #[stable(feature = "linked_list_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        self.iter().any(|e| e == x)
    }

    /// अगाडि तत्व, वा `None` को सन्दर्भ प्रदान गर्दछ यदि सूची खाली छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        unsafe { self.head.as_ref().map(|node| &node.as_ref().element) }
    }

    /// फ्रन्ट एलिमेन्ट, वा `None` मा म्यूटेबल सन्दर्भ प्रदान गर्दछ यदि सूची खाली छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// match dl.front_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.front(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        unsafe { self.head.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// पछाडि तत्त्वलाई सन्दर्भ प्रदान गर्दछ, वा `None` यदि सूची खाली छ भने।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        unsafe { self.tail.as_ref().map(|node| &node.as_ref().element) }
    }

    /// पछाडि तत्त्व, वा `None` मा एक परिवर्तनीय सन्दर्भ प्रदान गर्दछ यदि सूची खाली छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    ///
    /// match dl.back_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.back(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        unsafe { self.tail.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// सूचीमा पहिले तत्व थप्दछ।
    ///
    /// यो अपरेशन *O*(१) समयमा गणना गर्नु पर्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.front().unwrap(), &2);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front().unwrap(), &1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, elt: T) {
        self.push_front_node(box Node::new(elt));
    }

    /// पहिलो तत्वलाई हटाउछ र फर्काउँछ, वा `None` यदि सूची खाली छ भने।
    ///
    ///
    /// यो अपरेशन *O*(१) समयमा गणना गर्नु पर्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_front(), None);
    ///
    /// d.push_front(1);
    /// d.push_front(3);
    /// assert_eq!(d.pop_front(), Some(3));
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        self.pop_front_node().map(Node::into_element)
    }

    /// सूचीको पछाडि एलिमेन्ट थप गर्दछ।
    ///
    /// यो अपरेशन *O*(१) समयमा गणना गर्नु पर्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(3, *d.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, elt: T) {
        self.push_back_node(box Node::new(elt));
    }

    /// सूचीबाट अन्तिम तत्त्वलाई हटाउछ र फर्काउँछ, वा `None` यदि खाली छ भने।
    ///
    ///
    /// यो अपरेशन *O*(१) समयमा गणना गर्नु पर्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_back(), None);
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(d.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        self.pop_back_node().map(Node::into_element)
    }

    /// दिईएको अनुक्रमणिकामा सूची दुईमा विभाजन गर्दछ।
    /// दिइएको अनुक्रमणिका पछि सूचकांक सहित सबै फर्काउँछ।
    ///
    /// यस अपरेशनले *O*(*n*) समयमा गणना गर्नुपर्नेछ।
    ///
    /// # Panics
    ///
    /// Panics यदि `at > len`।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// let mut split = d.split_off(2);
    ///
    /// assert_eq!(split.pop_front(), Some(1));
    /// assert_eq!(split.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn split_off(&mut self, at: usize) -> LinkedList<T> {
        let len = self.len();
        assert!(at <= len, "Cannot split off at a nonexistent index");
        if at == 0 {
            return mem::take(self);
        } else if at == len {
            return Self::new();
        }

        // तल, हामी rate i-1`th नोडतर्फ पुनरावृत्ति गर्छौं या त सुरुदेखि वा अन्तबाट, जुन निर्भर छिटो हुन्छ।
        //
        let split_node = if at - 1 <= len - 1 - (at - 1) {
            let mut iter = self.iter_mut();
            // .skip() (जसले नयाँ स्ट्रक्स सिर्जना गर्दछ) को प्रयोग छोड्नको सट्टा, हामी म्यानुअली छोड्यौं हामी स्किपको कार्यान्वयन विवरणमा निर्भर बिना हेड फिल्ड पहुँच गर्न सक्दछौं।
            //
            //
            for _ in 0..at - 1 {
                iter.next();
            }
            iter.head
        } else {
            // अन्तबाट सुरू गरेर राम्रो
            let mut iter = self.iter_mut();
            for _ in 0..len - 1 - (at - 1) {
                iter.next_back();
            }
            iter.tail
        };
        unsafe { self.split_off_after_node(split_node, at) }
    }

    /// दिइएको अनुक्रमणिकामा तत्व हटाउँछ र फिर्ता गर्छ।
    ///
    /// यस अपरेशनले *O*(*n*) समयमा गणना गर्नुपर्नेछ।
    ///
    /// # Panics
    /// Panics यदि>=लेनमा
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(linked_list_remove)]
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// assert_eq!(d.remove(1), 2);
    /// assert_eq!(d.remove(0), 3);
    /// assert_eq!(d.remove(0), 1);
    /// ```
    #[unstable(feature = "linked_list_remove", issue = "69210")]
    pub fn remove(&mut self, at: usize) -> T {
        let len = self.len();
        assert!(at < len, "Cannot remove at an index outside of the list bounds");

        // तल, हामी दिईएको अनुक्रमणिकामा नोडतिर पुनरावृत गर्छौं या त सुरुबाट वा अन्त्यबाट, जुन निर्भर छिटो हुन्छ।
        //
        let offset_from_end = len - at - 1;
        if at <= offset_from_end {
            let mut cursor = self.cursor_front_mut();
            for _ in 0..at {
                cursor.move_next();
            }
            cursor.remove_current().unwrap()
        } else {
            let mut cursor = self.cursor_back_mut();
            for _ in 0..offset_from_end {
                cursor.move_prev();
            }
            cursor.remove_current().unwrap()
        }
    }

    /// एक पुनरावृत्तिकर्ता सिर्जना गर्दछ जसले एक तत्व हटाइनु पर्छ कि निर्धारित गर्न क्लोजर प्रयोग गर्दछ।
    ///
    /// यदि क्लोजर सहि फिर्ता हुन्छ, तब तत्त्व हटाईन्छ र पैदा हुन्छ।
    /// यदि क्लोजर गलत फर्काउँछ भने, तत्व सूचीमा रहनेछ र ईट्रेटर द्वारा उत्पन्न हुने छैन।
    ///
    /// नोट गर्नुहोस् कि `drain_filter` ले तपाईलाई फिल्टर क्लोजरमा प्रत्येक तत्व परिवर्तन गर्न दिन्छ, तपाई यसलाई राख्न वा हटाउने छनौट नगरी।
    ///
    ///
    /// # Examples
    ///
    /// सूची सूचीमा शाम र बाधामा पार्दै, मूल सूची पुन: प्रयोग गर्दै:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// use std::collections::LinkedList;
    ///
    /// let mut numbers: LinkedList<u32> = LinkedList::new();
    /// numbers.extend(&[1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15]);
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<LinkedList<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens.into_iter().collect::<Vec<_>>(), vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds.into_iter().collect::<Vec<_>>(), vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F>
    where
        F: FnMut(&mut T) -> bool,
    {
        // orrowण मुद्दाहरू बेवास्ता गर्नुहोस्।
        let it = self.head;
        let old_len = self.len;

        DrainFilter { list: self, it, pred: filter, idx: 0, old_len }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        struct DropGuard<'a, T>(&'a mut LinkedList<T>);

        impl<'a, T> Drop for DropGuard<'a, T> {
            fn drop(&mut self) {
                // हामीले तल गरेको लूपलाई जारी राख्नुहोस्।यो केवल तब चल्दछ जब एक विनाशकारी भयभीत छ।
                // यदि अर्को एक panics भने यसले परित्याग गर्दछ।
                while self.0.pop_front_node().is_some() {}
            }
        }

        while let Some(node) = self.pop_front_node() {
            let guard = DropGuard(self);
            drop(node);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // एक प्राप्त गर्न अनबाउन्ड आजीवन चाहिन्छ
                let node = &*node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // एक प्राप्त गर्न अनबाउन्ड आजीवन चाहिन्छ
                let node = &*node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // एक प्राप्त गर्न अनबाउन्ड आजीवन चाहिन्छ
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &mut node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a mut T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // एक प्राप्त गर्न अनबाउन्ड आजीवन चाहिन्छ
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &mut node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

/// `LinkedList` मा कर्सर।
///
/// एक `Cursor` एक पुनरावृत्तिकै जस्तो छ, बाहेक यसले स्वतन्त्र रूपमा पछाडि र अगाडि खोजी गर्न सक्दछ।
///
/// कर्सरहरू सँधै सूचीमा दुई तत्वहरू बीच विश्राम गर्दछ, र तार्किक रूपमा गोलाकार तरिकाले अनुक्रमणिका।
/// यसलाई समायोजन गर्न, एक "ghost" गैर-तत्व छ जुन सूचीको टाउको र पुच्छरको बीच `None` दिन्छ।
///
///
/// जब सिर्जना हुन्छ, कर्सरहरू सूचीको अगाडि सुरू हुन्छ, वा "ghost" गैर-तत्व यदि सूची खाली छ भने।
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct Cursor<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T> Clone for Cursor<'_, T> {
    fn clone(&self) -> Self {
        let Cursor { index, current, list } = *self;
        Cursor { index, current, list }
    }
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for Cursor<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Cursor").field(&self.list).field(&self.index()).finish()
    }
}

/// `LinkedList` मा सम्पादन कार्यहरूको साथमा एक कर्सर।
///
/// एक `Cursor` एक पुनरावृत्तिकै जस्तो हो, बाहेक यसले स्वतन्त्र रूपमा पछाडि र अगाडि खोजी गर्न सक्छ, र सुरक्षित रूपमा पुनरावृत्तिको समयमा सूची परिवर्तन गर्न सक्दछ।
/// यो किनभने यसको उपज सन्दर्भहरूको जीवनकाल केवल अन्तर्निहित सूचीको सट्टामा आफ्नै जीवनकालमा बाँधिएको छ।
/// यसको मतलब कर्सरले एकै पटकमा धेरै तत्वहरू उत्पादन गर्न सक्दैन।
///
/// कर्सरहरू सँधै सूचीमा दुई तत्वहरू बीच विश्राम गर्दछ, र तार्किक रूपमा गोलाकार तरिकाले अनुक्रमणिका।
/// यसलाई समायोजन गर्न, एक "ghost" गैर-तत्व छ जुन सूचीको टाउको र पुच्छरको बीच `None` दिन्छ।
///
///
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct CursorMut<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a mut LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for CursorMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("CursorMut").field(&self.list).field(&self.index()).finish()
    }
}

impl<'a, T> Cursor<'a, T> {
    /// `LinkedList` भित्र कर्सर स्थिति अनुक्रमणिका फर्काउँछ।
    ///
    /// यसले `None` फर्काउँछ यदि कर्सरले हाल "ghost" गैर-तत्वलाई जनाईरहेको छ।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// `LinkedList` को अर्को तत्वमा कर्सर सारियो।
    ///
    /// यदि कर्सरले "ghost" गैर-तत्वलाई औंल्याइरहेको छ भने यसले यसलाई `LinkedList` को पहिलो तत्वमा सार्नेछ।
    /// यदि यो `LinkedList` को अन्तिम तत्वतिर इशारा गर्दै छ भने यसले यसलाई "ghost" गैर-तत्वमा सार्नेछ।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // हामीसँग कुनै वर्तमान तत्त्व थिएन;कर्सर सुरुवात स्थितिमा बसेको थियो अर्को तत्व सूचीको प्रमुख हुनु पर्छ
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // हामीसँग अघिल्लो तत्त्व थियो, त्यसैले यसको अर्कोमा जानौं
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// `LinkedList` को अघिल्लो तत्वमा कर्सर सारियो।
    ///
    /// यदि कर्सरले "ghost" गैर-तत्वलाई औंल्याइरहेको छ भने यसले यो `LinkedList` को अन्तिम तत्वमा सार्नेछ।
    /// यदि यो `LinkedList` को पहिलो तत्व को इशारा गर्दै छ भने यसले यसलाई "ghost" गैर-तत्वमा सार्छ।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // हालको छैन।हामी सूचीको सुरूमा छौं।कुनै उपज छैन र अन्तमा हाम फाल्नुहोस्।
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // एक अधिमान छयो उपज गर्नुहोस् र अघिल्लो तत्वमा जानुहोस्।
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// तत्त्वलाई सन्दर्भ फर्काउँछ जुन कर्सरले हालमा औंल्याइरहेको छ।
    ///
    /// यसले `None` फर्काउँछ यदि कर्सरले हाल "ghost" गैर-तत्वलाई जनाईरहेको छ।
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&self) -> Option<&'a T> {
        unsafe { self.current.map(|current| &(*current.as_ptr()).element) }
    }

    /// अर्को तत्वमा सन्दर्भ फर्काउँछ।
    ///
    /// यदि कर्सरले "ghost" गैर-तत्वलाई औंल्याइरहेको छ भने यसले `LinkedList` को पहिलो एलिमेन्ट फिर्ता गर्दछ।
    /// यदि यो `LinkedList` को अन्तिम तत्वतिर इशारा गर्दै छ भने यसले `None` फर्काउँछ।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&self) -> Option<&'a T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &(*next.as_ptr()).element)
        }
    }

    /// अघिल्लो तत्वको सन्दर्भ फर्काउँछ।
    ///
    /// यदि कर्सरले "ghost" गैर-तत्वलाई औंल्याइरहेको छ भने यसले `LinkedList` को अन्तिम तत्व फिर्ता गर्दछ।
    /// यदि यसले `LinkedList` को पहिलो तत्त्वलाई देखाउँदै छ भने यसले `None` फर्काउँछ।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&self) -> Option<&'a T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &(*prev.as_ptr()).element)
        }
    }
}

impl<'a, T> CursorMut<'a, T> {
    /// `LinkedList` भित्र कर्सर स्थिति अनुक्रमणिका फर्काउँछ।
    ///
    /// यसले `None` फर्काउँछ यदि कर्सरले हाल "ghost" गैर-तत्वलाई जनाईरहेको छ।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// `LinkedList` को अर्को तत्वमा कर्सर सारियो।
    ///
    /// यदि कर्सरले "ghost" गैर-तत्वलाई औंल्याइरहेको छ भने यसले यसलाई `LinkedList` को पहिलो तत्वमा सार्नेछ।
    /// यदि यो `LinkedList` को अन्तिम तत्वतिर इशारा गर्दै छ भने यसले यसलाई "ghost" गैर-तत्वमा सार्नेछ।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // हामीसँग कुनै वर्तमान तत्त्व थिएन;कर्सर सुरुवात स्थितिमा बसेको थियो अर्को तत्व सूचीको प्रमुख हुनु पर्छ
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // हामीसँग अघिल्लो तत्त्व थियो, त्यसैले यसको अर्कोमा जानौं
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// `LinkedList` को अघिल्लो तत्वमा कर्सर सारियो।
    ///
    /// यदि कर्सरले "ghost" गैर-तत्वलाई औंल्याइरहेको छ भने यसले यो `LinkedList` को अन्तिम तत्वमा सार्नेछ।
    /// यदि यो `LinkedList` को पहिलो तत्व को इशारा गर्दै छ भने यसले यसलाई "ghost" गैर-तत्वमा सार्छ।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // हालको छैन।हामी सूचीको सुरूमा छौं।कुनै उपज छैन र अन्तमा हाम फाल्नुहोस्।
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // एक अधिमान छयो उपज गर्नुहोस् र अघिल्लो तत्वमा जानुहोस्।
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// तत्त्वलाई सन्दर्भ फर्काउँछ जुन कर्सरले हालमा औंल्याइरहेको छ।
    ///
    /// यसले `None` फर्काउँछ यदि कर्सरले हाल "ghost" गैर-तत्वलाई जनाईरहेको छ।
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&mut self) -> Option<&mut T> {
        unsafe { self.current.map(|current| &mut (*current.as_ptr()).element) }
    }

    /// अर्को तत्वमा सन्दर्भ फर्काउँछ।
    ///
    /// यदि कर्सरले "ghost" गैर-तत्वलाई औंल्याइरहेको छ भने यसले `LinkedList` को पहिलो एलिमेन्ट फिर्ता गर्दछ।
    /// यदि यो `LinkedList` को अन्तिम तत्वतिर इशारा गर्दै छ भने यसले `None` फर्काउँछ।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&mut self) -> Option<&mut T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &mut (*next.as_ptr()).element)
        }
    }

    /// अघिल्लो तत्वको सन्दर्भ फर्काउँछ।
    ///
    /// यदि कर्सरले "ghost" गैर-तत्वलाई औंल्याइरहेको छ भने यसले `LinkedList` को अन्तिम तत्व फिर्ता गर्दछ।
    /// यदि यसले `LinkedList` को पहिलो तत्त्वलाई देखाउँदै छ भने यसले `None` फर्काउँछ।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&mut self) -> Option<&mut T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &mut (*prev.as_ptr()).element)
        }
    }

    /// हालको एलिमेन्टलाई देखाउँदै पढ्ने-मात्र कर्सर फर्काउँछ।
    ///
    /// फिर्ता `Cursor` को जीवनकाल `CursorMut` को साथ बाध्य छ, जसको अर्थ यो `CursorMut` लाई आउटलिभ गर्न सक्दैन र `Cursor` X `CursorMut` X को जीवनकालको लागि स्थिर छ।
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn as_cursor(&self) -> Cursor<'_, T> {
        Cursor { list: self.list, current: self.current, index: self.index }
    }
}

// अब सूची सम्पादन कार्यहरू

impl<'a, T> CursorMut<'a, T> {
    /// `LinkedList` मा हालको पछि नयाँ तत्व सम्मिलित गर्दछ।
    ///
    /// यदि कर्सर "ghost" गैर-तत्वमा इशारा गर्दै छ भने नयाँ तत्व `LinkedList` को अगाडि सम्मिलित हुन्छ।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_after(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, spliced_node, spliced_node, 1);
            if self.current.is_none() {
                // "ghost" गैर-तत्व सूचकांक परिवर्तन भएको छ।
                self.index = self.list.len;
            }
        }
    }

    /// `LinkedList` मा हालको भन्दा पहिले नयाँ तत्व सम्मिलित गर्दछ।
    ///
    /// यदि कर्सरले "ghost" गैर-तत्वमा स .्केत गरिरहेको छ भने नयाँ तत्व `LinkedList` को अन्त्यमा सम्मिलित हुन्छ।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_before(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, spliced_node, spliced_node, 1);
            self.index += 1;
        }
    }

    /// `LinkedList` बाट वर्तमान तत्व हटाउँछ।
    ///
    /// हटाइएको एलिमेन्ट फिर्ता भयो, र कर्सरलाई `LinkedList` मा अर्को तत्वमा सूचित गर्न सारियो।
    ///
    ///
    /// यदि कर्सरले हाल "ghost" गैर-तत्वलाई औंल्याइरहेको छ भने कुनै पनि तत्त्व हटाइनेछ र `None` फर्काइनेछ।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current(&mut self) -> Option<T> {
        let unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);
            let unlinked_node = Box::from_raw(unlinked_node.as_ptr());
            Some(unlinked_node.element)
        }
    }

    /// हालको एलिमेन्ट `LinkedList` बाट हटाउनुहोस् सूची नोडलाई डेलोकेट नगरीकन।
    ///
    /// हटाइएको नोड नयाँ `LinkedList` को रूपमा यो नोड मात्र समावेश गरीन्छ।
    /// कर्सरलाई हालको `LinkedList` मा अर्को तत्वमा सूचित गर्न सारिएको छ।
    ///
    /// यदि कर्सरले हाल "ghost" गैर-तत्वलाई औंल्याइरहेको छ भने कुनै पनि तत्त्व हटाइनेछ र `None` फर्काइनेछ।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current_as_list(&mut self) -> Option<LinkedList<T>> {
        let mut unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);

            unlinked_node.as_mut().prev = None;
            unlinked_node.as_mut().next = None;
            Some(LinkedList {
                head: Some(unlinked_node),
                tail: Some(unlinked_node),
                len: 1,
                marker: PhantomData,
            })
        }
    }

    /// हालको X पछि X दिईएको `LinkedList` बाट एलिमेन्टहरू सम्मिलित गर्दछ।
    ///
    /// यदि कर्सरले "ghost" गैर-तत्वमा स .्केत गरिरहेको छ भने नयाँ तत्त्वहरू `LinkedList` को सुरूमा सम्मिलित हुन्छन्।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_after(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, splice_head, splice_tail, splice_len);
            if self.current.is_none() {
                // "ghost" गैर-तत्व सूचकांक परिवर्तन भएको छ।
                self.index = self.list.len;
            }
        }
    }

    /// हालको `LinkedList` बाट तत्त्वहरू सम्मिलित गर्दछ।
    ///
    /// यदि कर्सरले "ghost" गैर-तत्वमा स .्केत गरिरहेको छ भने नयाँ तत्त्वहरू `LinkedList` को अन्त्यमा सम्मिलित हुन्छन्।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_before(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, splice_head, splice_tail, splice_len);
            self.index += splice_len;
        }
    }

    /// हालको एलिमेन्ट पछि सूची दुईमा विभाजन गर्दछ।
    /// यसले कर्सर पछाडि सबै चीज समावेश गरेर नयाँ सूची फर्काउनेछ, मूल सूचीको अगाडि सबै चीज राखेर।
    ///
    ///
    /// यदि कर्सरले "ghost" गैर-तत्वमा स .्केत गरिरहेको छ भने `LinkedList` का सम्पूर्ण सामग्री सारियो।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_after(&mut self) -> LinkedList<T> {
        let split_off_idx = if self.index == self.list.len { 0 } else { self.index + 1 };
        if self.index == self.list.len {
            // "ghost" गैर-तत्व सूचकांक ० मा परिवर्तन भयो।
            self.index = 0;
        }
        unsafe { self.list.split_off_after_node(self.current, split_off_idx) }
    }

    /// हालको तत्त्व भन्दा पहिले सूची दुईमा विभाजन गर्दछ।
    /// यसले कर्सर भन्दा पहिले सबै चीज समावेश गरीएको नयाँ सूची फर्काउनेछ, मूल सूची पछि सबै चीज राखेर।
    ///
    ///
    /// यदि कर्सरले "ghost" गैर-तत्वमा स .्केत गरिरहेको छ भने `LinkedList` का सम्पूर्ण सामग्री सारियो।
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_before(&mut self) -> LinkedList<T> {
        let split_off_idx = self.index;
        self.index = 0;
        unsafe { self.list.split_off_before_node(self.current, split_off_idx) }
    }
}

/// लिटरलिस्टमा `drain_filter` कल गरेर उत्पन्न गरिएको एक इट्रेटर।
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub struct DrainFilter<'a, T: 'a, F: 'a>
where
    F: FnMut(&mut T) -> bool,
{
    list: &'a mut LinkedList<T>,
    it: Option<NonNull<Node<T>>>,
    pred: F,
    idx: usize,
    old_len: usize,
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Iterator for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        while let Some(mut node) = self.it {
            unsafe {
                self.it = node.as_ref().next;
                self.idx += 1;

                if (self.pred)(&mut node.as_mut().element) {
                    // `unlink_node` Aliasing `element` सन्दर्भको साथ ठीक छ।
                    self.list.unlink_node(node);
                    return Some(Box::from_raw(node.as_ptr()).element);
                }
            }
        }

        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Drop for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T, F>(&'r mut DrainFilter<'a, T, F>)
        where
            F: FnMut(&mut T) -> bool;

        impl<'r, 'a, T, F> Drop for DropGuard<'r, 'a, T, F>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                self.0.for_each(drop);
            }
        }

        while let Some(item) = self.next() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T: fmt::Debug, F> fmt::Debug for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.list).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.list.pop_front()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.list.len, Some(self.list.len))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.list.pop_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for LinkedList<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        let mut list = Self::new();
        list.extend(iter);
        list
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for LinkedList<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// मानलाई आधार मान्ने एलिटर उपज तत्वहरूमा सूची लिन्छ।
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { list: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a LinkedList<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut LinkedList<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Extend<T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.push_back(elem);
    }
}

impl<I: IntoIterator> SpecExtend<I> for LinkedList<I::Item> {
    default fn spec_extend(&mut self, iter: I) {
        iter.into_iter().for_each(move |elt| self.push_back(elt));
    }
}

impl<T> SpecExtend<LinkedList<T>> for LinkedList<T> {
    fn spec_extend(&mut self, ref mut other: LinkedList<T>) {
        self.append(other);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &'a T) {
        self.push_back(elem);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq> PartialEq for LinkedList<T> {
    fn eq(&self, other: &Self) -> bool {
        self.len() == other.len() && self.iter().eq(other)
    }

    fn ne(&self, other: &Self) -> bool {
        self.len() != other.len() || self.iter().ne(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for LinkedList<T> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.iter().partial_cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for LinkedList<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.iter().cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for LinkedList<T> {
    fn clone(&self) -> Self {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        let mut iter_other = other.iter();
        if self.len() > other.len() {
            self.split_off(other.len());
        }
        for (elem, elem_other) in self.iter_mut().zip(&mut iter_other) {
            elem.clone_from(elem_other);
        }
        if !iter_other.is_empty() {
            self.extend(iter_other.cloned());
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for LinkedList<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash> Hash for LinkedList<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        for elt in self {
            elt.hash(state);
        }
    }
}

// निश्चित गर्नुहोस् कि `LinkedList` र यसको पढ्ने मात्र पुनरावृत्तिहरू तिनीहरूको प्रकारका मानदण्डहरूमा covariant छन्।
#[allow(dead_code)]
fn assert_covariance() {
    fn a<'a>(x: LinkedList<&'static str>) -> LinkedList<&'a str> {
        x
    }
    fn b<'i, 'a>(x: Iter<'i, &'static str>) -> Iter<'i, &'a str> {
        x
    }
    fn c<'a>(x: IntoIter<&'static str>) -> IntoIter<&'a str> {
        x
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Send for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for IterMut<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for IterMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Send for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Send> Send for CursorMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for CursorMut<'_, T> {}