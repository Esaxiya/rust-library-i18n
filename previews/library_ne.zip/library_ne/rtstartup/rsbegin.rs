// rsbegin.o र rsend.o तथाकथित "compiler runtime startup objects" हो।
// तिनीहरूसँग कम्पाइलर रनटाइम सहि सुरू गर्न आवश्यक कोड हुन्छ।
//
// जब एक कार्यान्वयन योग्य वा dylib छवि लि is्क हुन्छ, सबै प्रयोगकर्ता कोड र पुस्तकालयहरू यी दुई वस्तु फाईलहरूको बीच "sandwiched" हुन्छन्, त्यसैले rsbegin.o बाट कोड वा डेटा छविको सम्बन्धित भागहरूमा पहिलो हुन्छन्, जबकि rsend.o बाट कोड र डाटा अन्तिम हुन्छन्।
// यो प्रभाव सुरूमा वा सेक्सनको अन्तमा प्रतीकहरू राख्नको लागि प्रयोग गर्न सकिन्छ, साथै कुनै आवश्यक हेडरहरू वा फुटरहरू सम्मिलित गर्नका लागि प्रयोग गर्न सकिन्छ।
//
// नोट गर्नुहोस् कि वास्तविक मोड्युल प्रविष्टि पोइन्ट सी रनटाइम स्टार्टअप वस्तु (सामान्यतया `crtX.o` भनिन्छ) मा अवस्थित छ, जुन त्यसपछि अन्य रनटाइम कम्पोनेन्टहरूको सुरूवात कलब्याकलाई आह्वान गर्दछ (अझै अर्को विशेष छवि सेक्सन मार्फत दर्ता गरिएको)।
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // स्ट्याक फ्रेम अन्वाइन्ड जानकारी सेक्सनको सुरूलाई चिन्ह लगाउँछ
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // अनविंदरको आन्तरिक पुस्तक-राख्नेका लागि स्क्र्याच ठाउँ।
    // यसलाई `struct object` को रूपमा $ GCC/unwind-dw2-fde.h मा परिभाषित गरिएको छ।
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // जानकारी खोल्नुहोस् registration/deregistration दिनचर्या।
    // Libpanic_unwind को कागजातहरू हेर्नुहोस्।
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // मोड्युल सुरुआतमा अनावश्यक जानकारी रेजिस्टर गर्नुहोस्
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // शटडाउनमा दर्ता रद्द गर्नुहोस्
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-विशिष्ट init/uninit नियमित पंजीकरण
    pub mod mingw_init {
        // MinGW को स्टार्टअप वस्तुहरू (crt0.o/dllcrt0.o) ले .ctors र .dtors खण्डहरूमा स्टार्टअप र बाहिर निस्किने ग्लोबल कन्स्ट्रक्टरलाई बोलाउँदछ।
        // DLL को मामलामा, यो गरियो जब DLL लोड र अनलोड हुन्छ।
        //
        // लिer्ककर्ताले सेक्सनहरू क्रमबद्ध गर्दछ, जसले सुनिश्चित गर्दछ कि हाम्रो कलब्याक सूचीको अन्तमा अवस्थित छ।
        // कन्स्ट्रक्टरहरू रिभर्स अर्डरमा चल्दछन्, यसले हाम्रो कलब्याकहरू कार्यान्वयन भएको पहिलो र अन्तिममा सुनिश्चित गर्दछ।
        //
        //

        #[link_section = ".ctors.65535"] // .ctors। *: C इनिसियलासन कलब्याक
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors। *: C समाप्ति कलब्याक
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}