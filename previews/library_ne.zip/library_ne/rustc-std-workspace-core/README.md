# `rustc-std-workspace-core` crate

यो crate शिम र खाली crate हो जुन केवल `libcore` मा निर्भर गर्दछ र यसका सबै सामग्रीहरू पुन: निर्यात गर्दछ।
crate crates.io बाट crates मा निर्भर मानक लाइब्रेरी सशक्तीकरणको छ।

crates.io मा Crates कि मानक पुस्तकालय crates.io बाट `rustc-std-workspace-core` crate मा निर्भर हुनु पर्ने आवश्यकतामा निर्भर गर्दछ, जो खाली छ।

हामी `[patch]` लाई यो रिपोजिटरीमा crate मा ओभरराइड गर्न प्रयोग गर्दछौं।
नतिजाको रूपमा, crates.io मा crates ले `libcore` मा निर्भरता edge लिनेछ, यो भण्डारमा परिभाषित संस्करण।
Cargo सफलतापूर्वक crates बनाउँछ भनेर सुनिश्चित गर्न सबै निर्भरता किनारहरू कोर्न सक्दछ!

नोट गर्नुहोस् कि crates.io मा crates ले जेड `core` नाममा `core` नाममा निर्भर हुनु पर्छ सबै काम सही तरीकाले गर्नका लागि।त्यसो गर्न तिनीहरूले प्रयोग गर्न सक्दछन्:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

`package` कुञ्जी को उपयोग मार्फत crate `core` मा पुनःनामाकरण गरिएको छ, यसको अर्थ यो देखिनेछ

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

जब Cargo कम्पाईलर आमन्त्रित गर्दछ, कम्पाइलरले ईन्जेक्टेड निहित `extern crate core` निर्देशलाई सन्तुष्ट गर्दै।




