# `rustc-std-workspace-std` crate

`rustc-std-workspace-core` crate का लागि कागजात हेर्नुहोस्।