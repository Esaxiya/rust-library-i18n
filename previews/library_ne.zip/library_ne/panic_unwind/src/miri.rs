//! मिन्ड्रीको लागि panics अनइन्डि। गर्दै।
use alloc::boxed::Box;
use core::any::Any;

// पेलोडको प्रकार जुन मिनी इञ्जिनले हाम्रो लागि अनवाइन्डिंग मार्फत प्रचार गर्छ।
// सूचक आकारको हुनु पर्छ।
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// मिनी-प्रदान बाह्य प्रकार्य अनावश्यक सुरू गर्न।
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // हामीले `miri_start_panic` मा पास पेडलोड बिल्कुल आर्गुमेन्ट हुनेछ जुन हामीले तल `cleanup` मा पाउछौं।
    // त्यसैले हामी केवल यो एक पटक बाकस, केहि सूचक आकार प्राप्त गर्न।
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // अन्तर्निहित `Box` पुन: प्राप्ति गर्नुहोस्।
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}