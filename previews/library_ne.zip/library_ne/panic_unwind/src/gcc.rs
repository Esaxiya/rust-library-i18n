//! libgcc/libunwind द्वारा समर्थित panics को कार्यान्वयन (केही फारममा)।
//!
//! अपवाद ह्यान्डलिंग र स्ट्याक अनवाइन्डिंगमा पृष्ठभूमिका लागि कृपया "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) र यसबाट लिंक गरिएका कागजातहरू हेर्नुहोस्।
//! यी पनि राम्रो पढ्न छन्:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## एक संक्षिप्त सारांश
//!
//! अपवाद ह्यान्डलिंग दुई चरणहरूमा हुन्छ: खोजी चरण र सफा चरण।
//!
//! दुबै चरणहरूमा अनन्विन्डरले स्ट्याक फ्रेमबाट हालको प्रक्रियाको मोडुलहरूको सेक्शन अनवाइन्ड सेक्सनको जानकारीको प्रयोग गरेर स्ट्याक फ्रेमहरू टुक्र्याउँदछ ("module" यहाँ एक ओएस मोड्युललाई जनाउँछ, जस्तै, कार्यान्वयन योग्य वा गतिशील पुस्तकालय)।
//!
//!
//! प्रत्येक स्ट्याक फ्रेमको लागि, यसले सम्बन्धित "personality routine" लाई आह्वान गर्दछ, जसको ठेगाना पनि खोलिएको जानकारी अनुभागमा भण्डारण गरिएको छ।
//!
//! खोजी चरणमा, व्यक्तित्व दिनचर्याको काम भनेको फालिएको अपवाद वस्तुको परिक्षण गर्नु हो, र यसलाई स्ट्याक फ्रेममा समातिनु पर्छ कि पर्दैन भनेर निर्णय गर्नु।एकचोटि ह्यान्डलर फ्रेम पहिचान भएपछि सफाई चरण सुरु हुन्छ।
//!
//! सफाई चरणमा, अनइन्भन्डरले प्रत्येक व्यक्तित्वको तालिकालाई फेरि बोलाउँदछ।
//! यस पटक यसले निर्णय गर्दछ कुन (यदि कुनै छ भने) क्लीनअप कोड हालको स्ट्याक फ्रेमको लागि चलाउनु पर्छ।यदि त्यसो हो भने, कन्ट्रोल विशेष branch मा प्रकार्य शरीरमा हस्तान्तरण गरिएको छ, "landing pad", जसले डिस्ट्रक्टर्सलाई आमन्त्रित गर्दछ, मेमोरी खाली गर्दछ, आदि।
//! ल्यान्डि pad प्याडको अन्त्यमा, नियन्त्रण अनविन्डर र अनवाइन्डिंग रिजुमेहरूमा फिर्ता सारिन्छ।
//!
//! एक पटक स्ट्याकलाई ह्यान्डलर फ्रेम स्तरमा अवाउन्ड गरिएको छ, अनावश्यक स्टपहरू र अन्तिम व्यक्तित्व दिनचर्या क्याच ब्लकमा नियन्त्रण स्थानान्तरण गर्दछ।
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Rust अपवाद वर्ग परिचयकर्ता।
// यो व्यक्तित्व दिनचर्या द्वारा प्रयोग गरिन्छ यदि अपवाद तिनीहरूको आफ्नै रनटाइम द्वारा फालिएको थियो कि भनेर निर्धारण गर्न।
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-विक्रेता, भाषा
    0x4d4f5a_00_52555354
}

// रेजिस्टर आईडीहरू प्रत्येक वास्तुकलाको लागि LLVM को TargetLowering::getExceptionPointerRegister() र TargetLowering::getExceptionSelectorRegister() बाट हटाईयो, त्यसपछि दर्ताको परिभाषा तालिकाहरू मार्फत DWARF रेजिस्टर नम्बरहरूमा म्याप गरियो (सामान्यतया<arch>RegisterInfo.td, "DwarfRegNum" को लागी खोजी गर्नुहोस्)।
//
// http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register पनि हेर्नुहोस्।
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// निम्न कोड GCC को C र C++ व्यक्तित्व दिनचर्यामा आधारित छ।सन्दर्भको लागि, हेर्नुहोस्:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI व्यक्तित्व दिनचर्या।
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS डिफल्ट रूटीनको सट्टामा SjLj अनवाइन्डिंग प्रयोग गर्दछ।
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // एआरएममा ब्याकट्रेसहरूले राज्यको व्यक्तित्व दिनचर्या कल गर्दछ==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND।
                // ती अवस्थाहरूमा हामी स्ट्याकलाई अनइवाइन्ड जारी राख्न चाहन्छौं, अन्यथा हाम्रो सबै ब्याकट्रेसहरू __rust_try मा समाप्त हुन्छन्।
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // DWARF अविनविंदरले मान्दछ कि _Uwwind_Context ले समारोह र LSDA पोइन्टर्स जस्ता चीजहरू राख्दछ, जबकि एआरएम EHABI ले तिनीहरूलाई अपवाद वस्तुमा राख्छ।
            // _Unwind_GetLanguageSpecificData() जस्ता प्रकार्यहरूको हस्ताक्षरहरू जोगाउन, जसले केवल प्रस poin्ग पोइन्टर लिन्छ, GCC व्यक्तित्व दिनचर्या एक पॉइन्टरलाई प्रसंगमा अपवाद_बाब्जेक्टमा स्ट्याम गर्दछ, स्थानको प्रयोग गरेर एआरएमको "scratch register" (r12) का लागि आरक्षित।
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... एक अधिक सिद्धान्त दृष्टिकोण हाम्रो लिबुनविन्ड बाइन्डि ARमा एआरएमको _उन्विन्ड_ कन्टेक्स्टको पूर्ण परिभाषा प्रदान गर्ने र त्यहाँबाट D डाटा को अनुकूलता प्रकार्यहरू बाइपास गरेर सीधै आवश्यक डाटा ल्याउने हो।
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI अपवाद वस्तु को बाधा क्यास मा एसपी मूल्य अपडेट गर्न व्यक्तित्व दिनचर्या आवश्यक छ।
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // एआरएम EHABI मा व्यक्तित्व दिनचर्या वास्तवमा फर्कनु अघि एकल स्ट्याक फ्रेम अनइन्डि forका लागि जिम्मेवार हुन्छ (एआरएम EHABI से।
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // libgcc मा परिभाषित
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // पूर्वनिर्धारित व्यक्तित्व दिनचर्या, जुन प्राय लक्षितमा र अप्रत्यक्ष रूपमा एसईएच मार्फत Windows x86_64 मा प्रयोग हुन्छ।
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // x86_64 MinGW लक्ष्यहरूमा, अनावश्यक मेकानिजम SEH हो तर अनविन्ड ह्यान्डलर डाटा (उर्फ LSDA) GCC-अनुकूल ईन्कोडि। प्रयोग गर्दछ।
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // हाम्रो अधिकांश लक्ष्यहरूको लागि व्यक्तित्व दिनचर्या।
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // फर्काउने ठेगाना पोइन्टहरू १ बाइट कल कल अनुदेश, जो LSDA दायरा तालिकामा अर्को आईपी दायरामा हुन सक्छ।
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// फ्रेम अज्ञात जानकारी पञ्जीकरण
//
// प्रत्येक मोड्युलको छविमा एक फ्रेम अनावश्यक जानकारी सेक्सन (सामान्यतया ".eh_frame") हुन्छ।जब मोड्युल प्रक्रियाहरूमा loaded/unloaded हुन्छ, अनविंदरलाई मेमोरीमा यस सेक्सनको स्थानको बारेमा जानकारी दिनुपर्दछ।प्लेटफर्म द्वारा फरक छ कि प्राप्त गर्ने विधिहरू।
// केहि (उदाहरणका लागि, Linux), अनविंदरले आफैंमा अज्ञात सूचना खण्डहरू पत्ता लगाउन सक्दछ (dl_iterate_phdr() API and finding their ".eh_frame" sections) मार्फत हालै लोड गरिएको मोड्युलहरूको गतिशील रूपमा गणना गरेर; Windows जस्तै, अण्डविंदर एपीआई मार्फत सक्रिय रूपमा उनीहरूको अज्ञात जानकारी खण्डहरू दर्ता गर्न मोड्युलहरू आवश्यक पर्दछ।
//
//
// यस मोड्युलले दुई प्रतीकहरू परिभाषित गर्दछ जुन 0GCC रनटाइमको साथ हाम्रो जानकारी दर्ता गर्न rsbegin.rs बाट संदर्भ र कल गरिएको हो।
// स्ट्याक अनवाइन्डि implementationको कार्यान्वयन (अहिलेको लागि) libgcc_eh लाई स्थगित गरियो, तथापि Rust crates यी Rust-विशिष्ट प्रविष्टि पोइन्टहरू प्रयोग गर्दछ जुन कुनै GCC रनटाइमको साथ सम्भावित झगडाबाट बच्न सक्छ।
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}