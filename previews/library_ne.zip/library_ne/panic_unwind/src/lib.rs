//! panics को कार्यान्वयन स्ट्याक अनवाइन्डिंग मार्फत
//!
//! यो crate Rust मा panics को कार्यान्वयन हो "most native" स्ट्याक अनावश्यक संयन्त्र प्रयोग गरेर यो कम्पाइल भइरहेको छ।
//! यो अनिवार्य रूपमा हाल तीन बाल्टिनहरूमा वर्गीकृत हुन्छ:
//!
//! 1. MSVC लक्ष्यहरूले `seh.rs` फाईलमा SEH प्रयोग गर्दछ।
//! 2. इम्स्क्रिप्टेडले `emcc.rs` फाईलमा C++ अपवादहरू प्रयोग गर्दछ।
//! 3. अन्य सबै लक्ष्यहरूले libunwind/libgcc X फाइलमा libunwind/libgcc प्रयोग गर्दछ।
//!
//! प्रत्येक कार्यान्वयनको बारेमा अधिक कागजात सम्बन्धित मोड्युलमा फेला पार्न सकिन्छ।
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` मिरी संग अप्रयुक्त छ, त्यसैले शान्त चेतावनी।
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Rust रनटाइमको स्टार्टअप वस्तुहरू यी प्रतीकहरूमा निर्भर छन्, त्यसैले तिनीहरूलाई सार्वजनिक गर्नुहोस्।
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // लक्ष्यहरू जसले अनावश्यक समर्थन गर्दैन।
        // - arch=wasm32
        // - OS=कुनै पनि होइन ("bare metal" लक्ष्यहरू)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // मिरी रनटाइम प्रयोग गर्नुहोस्।
        // हामीले अझै पनि माथिल्लो रनटाइम लोड गर्न आवश्यक पर्दछ, किनकि rustc त्यहाँबाट केहि ल्यांग आईटमहरू परिभाषित हुने आशा गर्दछ।
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // वास्तविक रनटाइम प्रयोग गर्नुहोस्।
        use real_imp as imp;
    }
}

extern "C" {
    /// जब panic वस्तु `catch_unwind` भन्दा बाहिर ड्रप गरियो लिबस्टडिमा ह्यान्डलर भनिन्छ।
    ///
    fn __rust_drop_panic() -> !;

    /// एक विदेशी अपवाद समातिएमा libstd मा ह्यान्डलर भनिन्छ।
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// अपवाद जुटाउनको लागि प्रविष्टि बिन्दु, केवल प्लेटफर्म-विशेष कार्यान्वयनमा प्रतिनिधिहरू।
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}