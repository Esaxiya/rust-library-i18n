//! *Emscriptten* लक्ष्य को लागी अनावश्यक।
//!
//! जबकि Rust को Unix प्लेटफार्मको लागि सामान्य अनावश्यक कार्यान्वयन प्रत्यक्ष लिबुनविन्ड एपीआईमा कल गर्दछ, एम्स्क्रिप्टमा हामी यसको सट्टामा C++ अनवाइन्डिंग APIs मा कल गर्छौं।
//! यो केवल एक एक्स्पेन्डियन्स हो किनकि इमस्क्रिप्टनको रनटाइमले सधैं ती एपीआईहरू लागू गर्दछ र लाइबनिविन्ड लागू गर्दैन।
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// यो C++ मा std::type_info को सजावटसँग मेल खान्छ
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // यहाँको प्रमुख `\x01` बाइट वास्तवमा LLVM लाई एक जादुई संकेत हो * ** लागू गर्न हुँदैन XL1X वर्णको साथ उपसर्ग जस्तै कुनै पनि अन्य मंगलिंग लागू गर्न।
    //
    //
    // यो प्रतीक सी ++ को `std::type_info` द्वारा प्रयोग गरिएको भ्याटेबल हो।
    // प्रकार `std::type_info` का वस्तुहरू, वर्णन वर्णकहरू, यस तालिकामा सूचक छ।
    // प्रकार वर्णनकर्ताहरू माथि परिभाषित C++ EH संरचनाहरू द्वारा सन्दर्भ र हामी तल निर्माण गर्दछन्।
    //
    // नोट गर्नुहोस् कि वास्तविक आकार us usize भन्दा ठूलो छ, तर हामी तेस्रो तत्त्वलाई देखाउन मात्र हाम्रो vtable चाहिन्छ।
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info एक rust_panic कक्षा को लागी
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // सामान्यतया हामी .as_ptr().add(2) प्रयोग गर्ने छौं तर यसले कन्स्ट सन्दर्भमा काम गर्दैन।
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // यो जानाजानी सामान्य नाम मैling्लिंग योजना प्रयोग गर्दैन किनकि हामी C++ Rust panics उत्पादन गर्न वा समात्न सक्षम बनाउन चाहँदैनौं।
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // यो आवश्यक छ किनकि C++ कोडले std::exception_ptr को साथ हाम्रो कार्यान्वयन क्याप्चर गर्न सक्दछ र यसलाई धेरै पटक पुनःथ्रो गर्न सक्दछ, सम्भवतः अर्को थ्रेडमा पनि।
    //
    //
    caught: AtomicBool,

    // यो विकल्प हुनु पर्छ किनकि वस्तुको जीवनकालले C++ शब्दार्थलाई पछ्याउँदछ: जब कैच_उन्डविन्डले अपवादबाट बाकसलाई सार्दछ यो अझै पनि अपवाद वस्तुलाई वैध राज्यमा छोड्नुपर्दछ किनकि यसको विध्वंसक अझै __cxa_end_catch द्वारा कल हुन गइरहेको छ।
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try वास्तवमा हामीलाई यो संरचना गर्न एक सूचक दिन्छ।
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // cleanup() panic को लागी अनुमति छैन, हामी यसको सट्टामा त्यागौं।
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}