//! DWARF-encoded डाटा स्ट्रिमहरू पार्सि forको लागि उपयोगिताहरू।
//! <http://www.dwarfstd.org>, DWARF-4 मानक, सेक्सन 7, "Data Representation" हेर्नुहोस्
//!

// यो मोड्युल केवल x86_64-pc-Windows-gnu द्वारा अहिलेको लागि प्रयोग गरिएको छ, तर हामी यसलाई जताततै संकलन गर्दै छौं प्रतिबन्धहरूबाट बच्न।
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // DWARF स्ट्रिमहरू प्याक गरिएका छन्, उदाहरणका लागि, एक u32 आवश्यक रूपमा-बाइट बाउन्ड्रीमा पigned्क्तिबद्ध हुँदैन।
    // यसले सख्त पign्क्तिबद्ध आवश्यकताको साथ प्लेटफर्महरूमा समस्या उत्पन्न गर्न सक्दछ।
    // "packed" संरचनामा डेटा र्‍याप गरेर, हामी ब्याकइन्डलाई "misalignment-safe" कोड उत्पन्न गर्न भन्दैछौं।
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // ULEB128 र SLEB128 एन्कोडिंगहरू सेक्सन 7.6, "Variable Length Data" मा परिभाषित छन्।
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}