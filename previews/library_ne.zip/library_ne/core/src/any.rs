//! यो मोड्युल `Any` trait कार्यान्वयन, जो रनटाइम परावर्तन को माध्यम बाट कुनै `'static` प्रकारको गतिशील टाइपिंग सक्षम गर्दछ।
//!
//! `Any` आफैमा `TypeId` प्राप्त गर्न प्रयोग गर्न सकिन्छ, र अधिक सुविधाहरू छन् जब trait वस्तुको रूपमा प्रयोग गरिन्छ।
//! `&dyn Any` को रूपमा (एक उधारोिएको trait वस्तु), यसमा `is` र `downcast_ref` विधिहरू छन्, यदि समावेश गरिएको मान दिएको प्रकारको हो भने परिक्षण गर्न, र एक प्रकारको रूपमा भित्री मानको सन्दर्भ प्राप्त गर्न।
//! `&mut dyn Any` को रूपमा, भित्री मानमा एक परिवर्तनीय सन्दर्भ प्राप्त गर्नका लागि `downcast_mut` विधि पनि छ।
//! `Box<dyn Any>` `downcast` विधि जोड्दछ, जसले `Box<T>` मा रूपान्तरण गर्न प्रयास गर्दछ।
//! पूर्ण विवरणहरूको लागि [`Box`] कागजात हेर्नुहोस्।
//!
//! नोट गर्नुहोस् कि `&dyn Any` एक मान तोकिएको क concrete्क्रीट प्रकारको हो कि भनेर परीक्षण गर्न सीमित छ, र एक प्रकारले trait लागू गर्दछ कि भनेर परीक्षण गर्न प्रयोग गर्न सकिँदैन।
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # स्मार्ट सूचक र `dyn Any`
//!
//! `Any` लाई trait वस्तुको रूपमा प्रयोग गर्दा ध्यानमा राख्नु पर्ने व्यवहारको एउटा अंश, विशेष गरी `Box<dyn Any>` वा `Arc<dyn Any>` जस्तो प्रकारको साथ, केवल मानमा `.type_id()` कलिंगले *कन्टेनर* को `TypeId` उत्पादन गर्दछ, अन्तर्निहित trait वस्तु होइन।
//!
//! यसको सट्टामा स्मार्ट पोइन्टरलाई `&dyn Any` मा रूपान्तरण गरेर बचाउन सकिन्छ, जुन वस्तुको `TypeId` फर्काउँछ।
//! उदाहरण को लागी:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // तपाई यो चाहानुहुन्छ अधिक संभावना:
//! let actual_id = (&*boxed).type_id();
//! // ... यो भन्दा:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! एउटा स्थितिलाई विचार गर्नुहोस् जहाँ हामी एउटा समारोहमा पारित मान लग आउट गर्न चाहन्छौं।
//! हामीलाई थाहा छ हामी कार्यान्वयन डिबगमा काम गरिरहेका छौं, तर हामीलाई यसको ठोस प्रकार थाहा छैन।हामी केहि प्रकारहरुमा विशेष उपचार दिन चाहान्छौं: यस अवस्थामा स्ट्रिंग मानहरुको लम्बाई प्रिन्ट गर्दै।
//! हामीलाई कम्पाईल समयमा हाम्रो मूल्यको ठोस प्रकार थाहा छैन, त्यसैले हामीले यसको सट्टामा रनटाइम प्रतिबिम्ब प्रयोग गर्नु पर्छ।
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // कुनै पनि प्रकारको लागि लगगर प्रकार्य जुन डिबग लागू गर्दछ।
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // हाम्रो मानलाई `String` मा रूपान्तरण गर्ने प्रयास गर्नुहोस्।
//!     // यदि सफल भएमा, हामी स्ट्रिंग lengthको लम्बाईका साथै यसको मान पनि आउटपुट गर्न चाहन्छौं।
//!     // यदि होईन भने यो एक फरक प्रकार हो: यसलाई अननाउन्डर प्रिन्ट गर्नुहोस्।
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // यस प्रकार्यले यससँग काम गर्नु अघि यसको प्यारामिटर लग आउट गर्न चाहन्छ।
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... अरू केहि काम गर्नुहोस्
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// कुनै trait
///////////////////////////////////////////////////////////////////////////////

/// एक trait गतिशील टाइप अनुकरण गर्न।
///
/// धेरै प्रकारका `Any` लागू गर्दछ।यद्यपि, कुनै पनि प्रकारले गैर-st'static` सन्दर्भ समावेश गर्दैन।
/// अधिक जानकारीको लागि [module-level documentation][mod] हेर्नुहोस्।
///
/// [mod]: crate::any
// यो trait असुरक्षित छैन, यद्यपि हामी यसका एक्स्पेलको `type_id` प्रकार्य असुरक्षित कोडमा कार्य गर्दछौं (उदाहरणका लागि `downcast`)।सामान्यतया, यो समस्या हुनेछ, तर किनकि `Any` को मात्र इम्प्लीन कम्बल कार्यान्वयन हो, अरू कुनै कोडले `Any` कार्यान्वयन गर्न सक्दैन।
//
// हामी यो trait असुरक्षित बनाउन सक्दछौं-यसले बिग्रेको कारण हुने छैन किनभने हामी सबै कार्यान्वयनहरू नियन्त्रण गर्छौं-तर हामी यो छनौट गर्दैनौं जुन वास्तवमै दुबै आवश्यक छैन र प्रयोगकर्ताहरूलाई असुरक्षित traits र असुरक्षित विधिहरूको भिन्नता बारे भ्रमित गर्न सक्छ (जस्तै, `type_id` अझै कल गर्न सुरक्षित हुनेछ, तर हामी सम्भवतः कागजातमा जस्तै स to्केत गर्न चाहान्छौं)।
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// `self` को `TypeId` हुन्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// कुनै पनि trait वस्तुहरूको लागि विस्तार विधिहरू।
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// निश्चित गर्नुहोस् कि उदाहरणको लागि, एउटा थ्रेडमा सामेल हुन प्रिन्ट गर्न सकिन्छ र त्यसैले `unwrap` का साथ प्रयोग गरियो।
// अन्ततः अब आवश्यक छैन यदि प्रेषणले अपकास्टिंगसँग काम गर्दछ भने।
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// `true` फिर्ता गर्छ यदि बक्सिंग प्रकार `T` जस्तै हो।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // यस प्रकार्यको साथ इन्स्ट्यान्ट गरिएको प्रकारको `TypeId` प्राप्त गर्नुहोस्।
        let t = TypeId::of::<T>();

        // प्रकारको `TypeId` trait वस्तु (`self`) मा प्राप्त गर्नुहोस्।
        let concrete = self.type_id();

        // समानतामा दुबै `TypeId`s तुलना गर्नुहोस्।
        t == concrete
    }

    /// बक्स गरिएको मानमा केहि सन्दर्भ फर्काउँछ यदि यो प्रकार `T` का हो, वा `None` यदि होईन भने।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // सुरक्षा: भर्खरै जाँच गरियो कि हामी सहि प्रकारलाई दर्साउँदै छौं, र हामी भर पर्न सक्छौं
            // त्यो मेमोरी सुरक्षाको लागि जाँच गर्दछ किनकि हामीले सबै प्रकारका लागि लागू गरेका छौं;कुनै अन्य ईम्प्लसहरू अवस्थित हुन सक्दैन किनकि ती हाम्रो ईम्प्लिमासँग विरोधाभास हुन्छ।
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// बक्स गरिएको मानको लागि केही परिवर्तनीय सन्दर्भ फर्काउँछ यदि यो प्रकार `T` का हो, वा `None` यदि यो होईन भने।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // सुरक्षा: भर्खरै जाँच गरियो कि हामी सहि प्रकारलाई दर्साउँदै छौं, र हामी भर पर्न सक्छौं
            // त्यो मेमोरी सुरक्षाको लागि जाँच गर्दछ किनकि हामीले सबै प्रकारका लागि लागू गरेका छौं;कुनै अन्य ईम्प्लसहरू अवस्थित हुन सक्दैन किनकि ती हाम्रो ईम्प्लिमासँग विरोधाभास हुन्छ।
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// अगाडि `Any` प्रकारमा परिभाषित विधिमा।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// अगाडि `Any` प्रकारमा परिभाषित विधिमा।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// अगाडि `Any` प्रकारमा परिभाषित विधिमा।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// अगाडि `Any` प्रकारमा परिभाषित विधिमा।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// अगाडि `Any` प्रकारमा परिभाषित विधिमा।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// अगाडि `Any` प्रकारमा परिभाषित विधिमा।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// टाइपआईडी र यसको विधिहरू
///////////////////////////////////////////////////////////////////////////////

/// एक `TypeId` एक प्रकार को लागी एक विश्वव्यापी अद्वितीय परिचयकर्ता प्रतिनिधित्व गर्दछ।
///
/// प्रत्येक `TypeId` एक अपारदर्शी वस्तु हो जुन भित्र के निरीक्षणको लागि अनुमति दिदैन तर क्लोनिंग, तुलना, प्रिन्टि,, र देखाउने जस्ता आधारभूत कार्यहरूलाई अनुमति दिन्छ।
///
///
/// एक `TypeId` हाल मात्र प्रकारका लागि मात्र उपलब्ध छ जुन `'static` लाई सदस्यता दिन्छ, तर यो सीमा future मा हटाउन सकिन्छ।
///
/// `TypeId` ले `Hash`, `PartialOrd`, र `Ord` कार्यान्वयन गर्दा, यो याद गर्नु उपयुक्त छ कि ह्यास र अर्डरिंग Rust रिलिजहरू बीच भिन्न हुनेछ।
/// तपाईंको कोड भित्र तिनीहरूमा निर्भर रहनुहोस्!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// यस जेनेरिक प्रकार्यको साथ स्थापित गरिएको प्रकारको `TypeId` फर्काउँछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// एक प्रकारको नामलाई स्ट्रि sl स्लाइसको रूपमा फर्काउँछ।
///
/// # Note
///
/// यो निदानात्मक प्रयोगको लागि हो।
/// फर्काइएको स्ट्रि ofको वास्तविक सामग्री र ढाँचा निर्दिष्ट गरिएको छैन, यस प्रकारको एक उत्तम-प्रयास वर्णनको बाहेक।
/// उदाहरणका लागि, `type_name::<Option<String>>()` ले फर्कन सक्ने तार बीच `"Option<String>"` र `"std::option::Option<std::string::String>"` हुन्।
///
///
/// फिर्ती स्ट्रि a एक प्रकारको अद्वितीय पहिचानकर्ता मान्नु हुँदैन किनकि बहु प्रकारले समान प्रकारको नाममा नक्सा गर्न सक्दछ।
/// त्यस्तै, कुनै प्रकारको ग्यारेन्टी छैन कि प्रकारका सबै भागहरू फर्काइएको स्ट्रिंगमा देखा पर्नेछ: उदाहरणका लागि, जीवनकाल निर्दिष्टकर्ताहरू हाल समावेश गरिएको छैन।
/// थपको रूपमा, आउटपुट कम्पाइलरको संस्करणहरूमा परिवर्तन हुन सक्दछ।
///
/// हालको कार्यान्वयनले कम्पाइलर डायग्नोस्टिक्स र डिबगिन्फो जस्ता पूर्वाधार प्रयोग गर्दछ, तर यसको ग्यारेन्टी छैन।
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// स्ट्रिंग स्लाइसको रूपमा पोइन्ट-टु मानको प्रकारको नाम फर्काउँछ।
/// यो `type_name::<T>()` जस्तै हो, तर जहाँ चरको प्रकार सजिलैसँग उपलब्ध हुँदैन जहाँ प्रयोग गर्न सकिन्छ।
///
/// # Note
///
/// यो निदानात्मक प्रयोगको लागि हो।सहीको सामग्री र ढाँचा निर्दिष्ट गरिएको छैन, प्रकारको एक उत्तम-प्रयास वर्णनको बाहेक।
/// उदाहरण को लागी, `type_name_of_val::<Option<String>>(None)` `"Option<String>"` वा `"std::option::Option<std::string::String>"`, तर `"foobar"` फिर्ता गर्न सकेन।
///
/// थपको रूपमा, आउटपुट कम्पाइलरको संस्करणहरूमा परिवर्तन हुन सक्दछ।
///
/// यो प्रकार्यले trait वस्तुहरू समाधान गर्दैन, `type_name_of_val(&7u32 as &dyn Debug)` `"dyn Debug"` फिर्ता हुन सक्छ, तर `"u32"` होइन।
///
/// प्रकारको नामलाई कुनै प्रकारको अद्वितीय पहिचानकर्ता मान्नु हुँदैन;
/// बहु प्रकारले उही प्रकारको नाम साझा गर्न सक्दछ।
///
/// हालको कार्यान्वयनले कम्पाइलर डायग्नोस्टिक्स र डिबगिन्फो जस्ता पूर्वाधार प्रयोग गर्दछ, तर यसको ग्यारेन्टी छैन।
///
/// # Examples
///
/// पूर्वनिर्धारित पूर्णाger्क र फ्लोट प्रकारहरू प्रिन्ट गर्दछ।
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}