//! `Default` trait प्रकारहरूको लागि जुन अर्थपूर्ण पूर्वनिर्धारित मानहरू हुन सक्दछ।

#![stable(feature = "rust1", since = "1.0.0")]

/// एक trait एक प्रकारको उपयोगी डिफल्ट मानको लागि।
///
/// कहिलेकाँही तपाई कुनै प्रकारको पूर्वनिर्धारित मानमा लाग्न चाहानुहुन्छ, र खास गरी के हो त्यसको ख्याल राख्नुहुन्न।
/// यो प्राय: संरचनाको साथ आउँदछ जुन विकल्पहरूको सेट परिभाषित गर्दछ:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// हामी केहि पूर्वनिर्धारित मानहरू कसरी परिभाषित गर्न सक्छौं?तपाईं `Default` प्रयोग गर्न सक्नुहुनेछ:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// अब तपाई सबै डिफल्ट मानहरु पाउनुहुन्छ।Rust विभिन्न आदिम प्रकारहरूको लागि `Default` कार्यान्वयन गर्दछ।
///
/// यदि तपाईं एक विशेष विकल्प लाई ओभरराइड गर्न चाहानुहुन्छ, तर अझै अन्य पूर्वनिर्धारितहरू राख्नुहोस्।
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// यो trait `#[derive]` का साथ प्रयोग गर्न सकिन्छ यदि सबै प्रकारको फाँटहरू `Default` लागू गर्दछ।
/// जब `derive`d हुन्छ, यसले प्रत्येक फाँटको प्रकारको लागि पूर्वनिर्धारित मान प्रयोग गर्दछ।
///
/// ## म कसरी `Default` कार्यान्वयन गर्न सक्छु?
///
/// `default()` विधिको लागि कार्यान्वयन प्रदान गर्नुहोस् जुन तपाईंको प्रकारको मान फर्काउँछ जुन पूर्वनिर्धारित हुनुपर्छ।
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// एक प्रकारको लागि "default value" फर्काउँछ।
    ///
    /// पूर्वनिर्धारित मानहरू प्राय: केही प्रकारको प्रारम्भिक मान, पहिचान मान, वा अरू केहि हुन् जुन डिफल्टको रूपमा बुझिन सक्छ।
    ///
    ///
    /// # Examples
    ///
    /// पूर्वनिर्मित पूर्वनिर्धारित मानहरू प्रयोग गर्दै:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// तपाईंको आफ्नै बनाउने:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// `Default` trait अनुसार प्रकारको पूर्वनिर्धारित मान फर्काउनुहोस्।
///
/// फिर्ती को प्रकार संदर्भ बाट inferred छ;यो `Default::default()` बराबर छ तर टाइप गर्न छोटो छ।
///
/// उदाहरण को लागी:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// trait `Default` को एक इम्प्ली उत्पन्न डेरिभ म्याक्रो।
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }