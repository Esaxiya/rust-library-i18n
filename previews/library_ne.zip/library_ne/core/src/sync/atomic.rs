//! आणविक प्रकार
//!
//! आणविक प्रकारले थ्रेडहरू बीच आदिम साझा-मेमोरी संचार प्रदान गर्दछ, र अन्य समवर्ती प्रकारहरूको निर्माण ब्लक हुन्।
//!
//! यो मोड्युलले [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], आदि सहित आदिम प्रकारहरूको चयन संख्याको आणविक संस्करण परिभाषित गर्दछ।
//! आणविक प्रकारले प्रस्तुत अपरेसनहरू, जब सही रूपमा प्रयोग हुँदा थ्रेडहरू बीच अपडेट सि updates्ख्रोनाइज गर्दछ।
//!
//! प्रत्येक विधिले [`Ordering`] लिन्छ जुन त्यो अपरेशनको लागि मेमोरी बाधाको शक्ति प्रतिनिधित्व गर्दछ।यी आदेशहरू [C++20 atomic orderings][1] जस्तै छन्।अधिक जानकारीको लागि [nomicon][2] हेर्नुहोस्।
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! आणविक चरहरू थ्रेडहरू बीच साझेदारी गर्न सुरक्षित छन् (ती [`Sync`] कार्यान्वयन गर्छन्) तर तिनीहरू आफैंले Rust को [threading model](../../../std/thread/index.html#the-threading-model) लाई साझा र अनुसरणको लागि संयन्त्र प्रदान गर्दैनन्।
//!
//! परमाणु भेरिएबल साझा गर्ने सब भन्दा साधारण तरीका भनेको यसलाई [`Arc`][arc] मा राख्नु (एक परमाणु-संदर्भ-गणना गणना साझा सूचक)।
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! आणविक प्रकारहरू स्थिर चरमा भण्डार गर्न सकिन्छ, [`AtomicBool::new`] जस्तै स्थिर आरम्भकर्ताहरू प्रयोग गरेर आरम्भ गरिएको।आणविक तथ्याics्क प्रायः आलसी ग्लोबल इनिशिएलाइसनको लागि प्रयोग गरिन्छ।
//!
//! # Portability
//!
//! यस मोड्युलमा सबै आणविक प्रकारहरू [lock-free] हुन ग्यारेन्टी छन् यदि तिनीहरू उपलब्ध छन् भने।यसको मतलब तिनीहरू आन्तरिक रूपमा एक ग्लोबल म्युटेक्स प्राप्त गर्दैनन्।आणविक प्रकार र अपरेशनहरू प्रतीक्षा-रहित ग्यारेन्टी छैन।
//! यसको मतलव `fetch_or` जस्तो अपरेसनहरू तुलना र स्वैप लूपसँग कार्यान्वयन हुन सक्छ।
//!
//! परमाणु अपरेशनहरू ठूलो आकारको परमाणुको साथ निर्देशन तहमा लागू गर्न सकिन्छ।उदाहरणका लागि केहि प्लेटफर्मले `AtomicI8` कार्यान्वयन गर्न--बाइट एटम निर्देशनहरू प्रयोग गर्छन्।
//! नोट गर्नुहोस् कि यस इमुलेसनले कोडको शुद्धतामा प्रभाव पार्नुहुन्न, यो मात्र होसियार हुनु हो।
//!
//! यस मोड्युलमा आणविक प्रकारहरू सबै प्लेटफार्महरूमा उपलब्ध नहुन सक्छ।यहाँ आणविक प्रकारहरू सबै व्यापक रूपमा उपलब्ध छन्, यद्यपि, र सामान्यतया अवस्थितमा भर पर्न सकिन्छ।केहि उल्लेखनीय अपवादहरू हुन्:
//!
//! * PowerPC र 00२-बिट पोइन्टरहरू सहित MIPS प्लेटफार्महरू `AtomicU64` वा `AtomicI64` प्रकारहरू छैनन्।
//! * ARM `armv5te` जस्ता प्लेटफर्महरू जुन Linux का लागि होईन मात्र `load` र `store` अपरेशनहरू प्रदान गर्दछ, र तुलना र स्व्याप (CAS) अपरेसनहरू समर्थन गर्दैन, जस्तै `swap`, `fetch_add`, आदि।
//! थप रूपमा Linux मा, यी CAS अपरेशनहरू [operating system support] मार्फत कार्यान्वयन भएका छन्, जुन प्रदर्शन दण्डको साथ आउन सक्छ।
//! * ARM `thumbv6m` को साथ लक्ष्यहरूले मात्र `load` र `store` अपरेशनहरू प्रदान गर्दछ, र तुलना र स्व्याप (CAS) कार्यहरू, जस्तै `swap`, `fetch_add`, आदि समर्थन गर्दैन।
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! नोट गर्नुहोस् कि future प्लेटफार्महरू थप्न सकिन्छ कि केहि परमाणु अपरेशनहरूको लागि समर्थन छैन।अधिकतम पोर्टेबल कोड कुन परमाणु प्रकारको प्रयोग भइरहेको बारे सतर्क हुन चाहन्छ।
//! `AtomicUsize` र `AtomicIsize` सामान्यतया सबै भन्दा पोर्टेबल हो, तर पनि ती सबै ठाउँमा उपलब्ध हुँदैनन्।
//! सन्दर्भको लागि, `std` लाइब्रेरीलाई सूचक आकारको परमाणु आवश्यक पर्दछ, जे होस् `core` ले गर्दैन।
//!
//! हाल तपाईले `#[cfg(target_arch)]` प्रयोग गर्नु पर्छ मुख्य रूपमा एटमिक्सको साथ कोडमा सर्तमा कम्पाइल गर्न।त्यहाँ एक अस्थिर `#[cfg(target_has_atomic)]` छ जुन future मा स्थिर हुन सक्छ।
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! एक साधारण स्पिनलॉक:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // अन्य थ्रेडको लागि प्रतीक्षा गर्नुहोस् लक लक गर्न
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! प्रत्यक्ष थ्रेडहरूको ग्लोबल गणना राख्नुहोस्:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// बुलियन प्रकार जुन सुरक्षित रूपमा थ्रेडहरू बीच साझेदारी गर्न सकिन्छ।
///
/// यस प्रकारको X-X X जस्तै समान इन-मेमोरी प्रतिनिधित्व छ।
///
/// **नोट**: यो प्रकार केवल प्लेटफर्महरूमा उपलब्ध छ कि आणविक लोड र `u8` को स्टोरहरूलाई समर्थन गर्दछ।
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// `false` मा इनिसिस गरिएको `AtomicBool` सिर्जना गर्दछ।
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// पठाउनुहोस् स्पष्ट रूपमा आणविकबुलको लागि लागू गरिएको छ।
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// एक कच्चा सूचक प्रकार जुन सुरक्षित रूपमा थ्रेडहरू बीच साझेदारी गर्न सकिन्छ।
///
/// यस प्रकारको X-X X को रूपमा समान-इन-मेमोरी प्रतिनिधित्व छ।
///
/// **नोट**: यो प्रकार केवल प्लेटफर्महरूमा उपलब्ध छ कि आणविक लोड र पोइन्टरहरूको स्टोर समर्थन गर्दछ।
/// यसको आकार लक्ष्य सूचकको आकारमा निर्भर गर्दछ।
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// एक शून्य `AtomicPtr<T>` सिर्जना गर्दछ।
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// आणविक मेमोरी अर्डरिंगहरू
///
/// मेमोरी अर्डरिंगले आणविक अपरेसन मेमोरीको सिंक्रोनाइज गर्ने तरिका निर्दिष्ट गर्दछ।
/// यसको कमजोर [`Ordering::Relaxed`] मा, अपरेसनले प्रत्यक्ष रूपमा छुने मेमोरी मात्र सिंक्रोनाइज हुन्छ।
/// अर्कोतर्फ, [`Ordering::SeqCst`] अपरेसनहरूको भण्डार-लोड जोडीले अन्य मेमोरीलाई समक्रमण गर्दछ जबकि अतिरिक्त रूपमा सबै थ्रेडहरूमा यस प्रकारका कार्यहरूको कुल आदेश सुरक्षित गर्दछ।
///
///
/// Rust को मेमोरी अर्डरिंग [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order) हो।
///
/// अधिक जानकारीको लागि [nomicon] हेर्नुहोस्।
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// कुनै अर्डरिंग बाधा छैन, केवल आणविक अपरेसनहरू।
    ///
    /// C ++ 20 मा [`memory_order_relaxed`] लाई सम्बन्धित छ।
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// जब स्टोरसँग जोडिएको हुन्छ, सबै पछिल्लो अपरेशनहरू [`Acquire`] (वा अधिक सुदृढ) अर्डरिंगको साथ यो मानको कुनै लोड अघि अर्डर हुन्छ।
    ///
    /// विशेष रूपमा, सबै अघिल्लो लेखहरू सबै थ्रेडहरूमा दृश्यात्मक हुन्छन् जुन यो मानको [`Acquire`] (वा अधिक शक्तिशाली) प्रदर्शन गर्दछ।
    ///
    /// याद गर्नुहोस् कि यो अर्डरिंग एक अपरेशनको लागि जुन लोड र भण्डारहरू संयोजन गर्दछ यसले [`Relaxed`] लोड अपरेशनमा डोर्‍याउँछ!
    ///
    /// यो अर्डरिंग केवल अपरेशनहरूको लागि लागू हुन्छ जुन स्टोर प्रदर्शन गर्न सक्दछ।
    ///
    /// C ++ 20 मा [`memory_order_release`] लाई सम्बन्धित छ।
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// जब लोडको साथ जोडीएको खण्डमा, यदि लोड गरिएको मान [`Release`] (वा अधिक सुदृढ) अर्डरको साथ स्टोर अपरेशन द्वारा लेखिएको थियो भने, सबै पछिल्ला अपरेशनहरू त्यो स्टोर पछि अर्डर हुनेछन्।
    /// विशेष रूपमा, सबै पछिल्लो भारहरू स्टोर अघि लेखिएको डाटा देख्नेछन्।
    ///
    /// याद गर्नुहोस् कि यो अर्डरिंग अपरेशनको लागि प्रयोग जसले लोड र भण्डारहरू संयोजन गर्दछ [`Relaxed`] स्टोर अपरेशनमा जान्छ!
    ///
    /// यो अर्डरिंग अपरेशनहरूको लागि मात्र लागू हुन्छ जुन लोड प्रदर्शन गर्न सक्दछ।
    ///
    /// C ++ 20 मा [`memory_order_acquire`] लाई सम्बन्धित छ।
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// दुबै [`Acquire`] र [`Release`] को प्रभाव छ:
    /// लोडका लागि यसले [`Acquire`] आदेश प्रयोग गर्दछ।स्टोरहरूको लागि यसले [`Release`] अर्डरिंग प्रयोग गर्दछ।
    ///
    /// नोट गर्नुहोस् कि `compare_and_swap` को मामलामा, यो सम्भव छ कि अपरेशनले कुनै स्टोर प्रदर्शन नगरेको खण्डमा यसको [`Acquire`] 1X अर्डर मात्र छ।
    ///
    /// जे होस्, `AcqRel` ले [`Relaxed`] एक्सेसहरू कहिले प्रदर्शन गर्दैन।
    ///
    /// यो अर्डरिंग अपरेशनहरूको लागि मात्रै लागू हुन्छ जुन दुबै लोड र भण्डारहरू संयोजन गर्दछ।
    ///
    /// C ++ 20 मा [`memory_order_acq_rel`] लाई सम्बन्धित छ।
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// जस्तै [qu Acquire`]/[`रिलीज]]/[`AcqRel`](क्रमशः लोड, स्टोर, र लोड-भण्डार अपरेशनहरूको लागि) अतिरिक्त ग्यारेन्टीको साथ कि सबै थ्रेडहरूले क्रमबद्ध रूपमा सबै क्रमबद्ध अपरेशनहरू समान क्रममा देख्दछन्। ।
    ///
    ///
    /// C ++ 20 मा [`memory_order_seq_cst`] लाई सम्बन्धित छ।
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// एक [`AtomicBool`] `false` मा आरम्भ।
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// नयाँ `AtomicBool` सिर्जना गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// अन्तर्निहित [`bool`] मा एक परिवर्तनीय सन्दर्भ फर्काउँछ।
    ///
    /// यो सुरक्षित छ किनकि म्यूटेबल सन्दर्भले ग्यारेन्टी गर्दछ कि कुनै अन्य थ्रेड समरूपमा आणविक डेटा पहुँच गरिरहेका छैनन्।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // सुरक्षा: म्युटेबल सन्दर्भले अद्वितीय स्वामित्वको ग्यारेन्टी गर्दछ।
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// `&mut bool` मा आणविक पहुँच प्राप्त गर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // सुरक्षा: रूपान्तरण सन्दर्भ अद्वितीय स्वामित्व ग्यारेन्टी, र
        // दुबै `bool` र `Self` को पign्क्तिबद्धता १ हो।
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// आणविक उपभोग गर्दछ र समावेश गरिएको मान फिर्ता गर्दछ।
    ///
    /// यो सुरक्षित छ किनकि मान द्वारा `self` पारित गर्दा ग्यारेन्टी हुन्छ कि कुनै अन्य थ्रेड समरूपमा आणविक डेटा पहुँच गरिरहेका छैनन्।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// bool बाट मान लोड गर्दछ।
    ///
    /// `load` एक [`Ordering`] आर्गुमेन्ट लिन्छ जुन यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्दछ।
    /// सम्भावित मानहरू [`SeqCst`], [`Acquire`] र [`Relaxed`] हुन्।
    ///
    /// # Panics
    ///
    /// Panics यदि `order` [`Release`] वा [`AcqRel`] हो।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // सुरक्षा: कुनै पनि डेटा दौडहरू आणविक ईन्ट्रिन्सिक्स र कच्चा द्वारा रोकिन्छ
        // पोइन्टरमा पारित वैध छ किनकि हामीले यसलाई सन्दर्भबाट पाएका छौं।
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// bool मा मान स्टोर गर्दछ।
    ///
    /// `store` एक [`Ordering`] आर्गुमेन्ट लिन्छ जुन यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्दछ।
    /// सम्भावित मानहरू [`SeqCst`], [`Release`] र [`Relaxed`] हुन्।
    ///
    /// # Panics
    ///
    /// Panics यदि `order` [`Acquire`] वा [`AcqRel`] हो।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // सुरक्षा: कुनै पनि डेटा दौडहरू आणविक ईन्ट्रिन्सिक्स र कच्चा द्वारा रोकिन्छ
        // पोइन्टरमा पारित वैध छ किनकि हामीले यसलाई सन्दर्भबाट पाएका छौं।
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// bool मा मान स्टोर गर्दछ, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// `swap` एक [`Ordering`] आर्गुमेन्ट लिन्छ जुन यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्दछ।सबै अर्डरिंग मोडहरू सम्भव छन्।
    /// नोट गर्नुहोस् कि [`Acquire`] प्रयोग गर्नाले स्टोरले यो अपरेशन [`Relaxed`] को हिस्सा बनाउँछ, र [`Release`] प्रयोग गर्दा लोड भाग [`Relaxed`] बनाउँछ।
    ///
    ///
    /// **Note:** यो विधि केवल प्लेटफर्महरूमा उपलब्ध छ जुन `u8` मा परमाणु अपरेशनहरू समर्थन गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // सुरक्षा: डाटा रेसहरू आणविक ईन्ट्रिन्सिक्स द्वारा रोकिएका छन।
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// [`bool`] मा मान भण्डार गर्दछ यदि हालको मान `current` मान जस्तै हो।
    ///
    /// फिर्ती मान सँधै अघिल्लो मान हुन्छ।यदि यो `current` बराबर छ, तब मान अपडेट गरियो।
    ///
    /// `compare_and_swap` एक [`Ordering`] आर्गुमेन्ट पनि लिन्छ जुन यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्दछ।
    /// ध्यान दिनुहोस् कि [`AcqRel`] प्रयोग गर्दा पनि, अपरेशन असफल हुन सक्छ र त्यसैले मात्र एक `Acquire` लोड प्रदर्शन गर्दछ, तर `Release` शब्दार्थ छैन।
    /// [`Acquire`] प्रयोग गर्नाले स्टोरले यो अपरेशन [`Relaxed`] को हिस्सा बनाउँदछ यदि यो हुन्छ भने, र [`Release`] प्रयोग गर्नाले लोड भाग [`Relaxed`] बनाउँछ।
    ///
    /// **Note:** यो विधि केवल प्लेटफर्महरूमा उपलब्ध छ जुन `u8` मा परमाणु अपरेशनहरू समर्थन गर्दछ।
    ///
    /// # `compare_exchange` र `compare_exchange_weak` मा सर्दै
    ///
    /// `compare_and_swap` मेमोरी अर्डरिंगका लागि निम्न म्यापिppingको साथ `compare_exchange` बराबर हो।
    ///
    /// मूल |सफलता |असफलता
    /// -------- | ------- | -------
    /// रिलक्सड |रिलक्सड |आराम प्राप्तअधिग्रहण |जारी गर्नुहोस् |रिलीज |आरामदायक AcqRel |AcqRel |SeqCst प्राप्त गर्नुहोस्SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` तुलना सफल हुँदा पनि उत्तेजित रूपमा असफल हुन अनुमति दिईन्छ, जसले कम्पाइलरलाई राम्रो संयोजन कोड उत्पन्न गर्न मद्दत गर्दछ जब तुलना र स्व्याप लूपमा प्रयोग गरिन्छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// [`bool`] मा मान भण्डार गर्दछ यदि हालको मान `current` मान जस्तै हो।
    ///
    /// रिटर्न मान एक परिणाम हो जुन नयाँ मान लेखिएको थियो र अघिल्लो मान समावेश गर्दछ।
    /// सफलतामा यो मान `current` बराबर हुने ग्यारेन्टी गरिएको छ।
    ///
    /// `compare_exchange` यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्न दुई [`Ordering`] आर्गुमेन्ट लिन्छ।
    /// `success` पढ्ने-परिमार्जन-लेखन अपरेशनको लागि आवश्यक अर्डरिंग वर्णन गर्दछ जुन लिन्छ यदि `current` सँग तुलना सफल भयो भने।
    /// `failure` लोड अपरेशनका लागि आवश्यक अर्डरिंग वर्णन गर्दछ जुन तुलना विफल भएपछि हुने गर्दछ।
    /// [`Acquire`] लाई सफलताको क्रमको रूपमा प्रयोग गर्नाले स्टोरले यो अपरेशन [`Relaxed`] बनाउँदछ, र [`Release`] प्रयोग गर्नाले सफल लोड [`Relaxed`] बनाउँदछ।
    ///
    /// असफलता अर्डरिंग मात्र [`SeqCst`], [`Acquire`] वा [`Relaxed`] हुन सक्छ र सफलता अर्डरिंग भन्दा बराबर वा कमजोर हुनुपर्दछ।
    ///
    /// **Note:** यो विधि केवल प्लेटफर्महरूमा उपलब्ध छ जुन `u8` मा परमाणु अपरेशनहरू समर्थन गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // सुरक्षा: डाटा रेसहरू आणविक ईन्ट्रिन्सिक्स द्वारा रोकिएका छन।
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// [`bool`] मा मान भण्डार गर्दछ यदि हालको मान `current` मान जस्तै हो।
    ///
    /// [`AtomicBool::compare_exchange`] विपरीत, यो प्रकार्य तुलनात्मक रूपमा सफल हुँदा पनि उत्तेजित रूपमा असफल हुने अनुमति दिईन्छ, जसले केहि प्लेटफर्महरूमा बढी कुशल कोडको परिणाम दिन्छ।
    ///
    /// रिटर्न मान एक परिणाम हो जुन नयाँ मान लेखिएको थियो र अघिल्लो मान समावेश गर्दछ।
    ///
    /// `compare_exchange_weak` यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्न दुई [`Ordering`] आर्गुमेन्ट लिन्छ।
    /// `success` पढ्ने-परिमार्जन-लेखन अपरेशनको लागि आवश्यक अर्डरिंग वर्णन गर्दछ जुन लिन्छ यदि `current` सँग तुलना सफल भयो भने।
    /// `failure` लोड अपरेशनका लागि आवश्यक अर्डरिंग वर्णन गर्दछ जुन तुलना विफल भएपछि हुने गर्दछ।
    /// [`Acquire`] लाई सफलताको क्रमको रूपमा प्रयोग गर्नाले स्टोरले यो अपरेशन [`Relaxed`] बनाउँदछ, र [`Release`] प्रयोग गर्नाले सफल लोड [`Relaxed`] बनाउँदछ।
    /// असफलता अर्डरिंग मात्र [`SeqCst`], [`Acquire`] वा [`Relaxed`] हुन सक्छ र सफलता अर्डरिंग भन्दा बराबर वा कमजोर हुनुपर्दछ।
    ///
    /// **Note:** यो विधि केवल प्लेटफर्महरूमा उपलब्ध छ जुन `u8` मा परमाणु अपरेशनहरू समर्थन गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // सुरक्षा: डाटा रेसहरू आणविक ईन्ट्रिन्सिक्स द्वारा रोकिएका छन।
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// बुलियन मानको साथ तार्किक "and"।
    ///
    /// हालको मान र आर्गुमेन्ट `val` मा तार्किक "and" कार्य गर्दछ, र परिणाममा नयाँ मान सेट गर्दछ।
    ///
    /// अघिल्लो मान फर्काउँछ।
    ///
    /// `fetch_and` एक [`Ordering`] आर्गुमेन्ट लिन्छ जुन यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्दछ।सबै अर्डरिंग मोडहरू सम्भव छन्।
    /// नोट गर्नुहोस् कि [`Acquire`] प्रयोग गर्नाले स्टोरले यो अपरेशन [`Relaxed`] को हिस्सा बनाउँछ, र [`Release`] प्रयोग गर्दा लोड भाग [`Relaxed`] बनाउँछ।
    ///
    ///
    /// **Note:** यो विधि केवल प्लेटफर्महरूमा उपलब्ध छ जुन `u8` मा परमाणु अपरेशनहरू समर्थन गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // सुरक्षा: डाटा रेसहरू आणविक ईन्ट्रिन्सिक्स द्वारा रोकिएका छन।
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// बुलियन मानको साथ तार्किक "nand"।
    ///
    /// हालको मान र आर्गुमेन्ट `val` मा तार्किक "nand" कार्य गर्दछ, र परिणाममा नयाँ मान सेट गर्दछ।
    ///
    /// अघिल्लो मान फर्काउँछ।
    ///
    /// `fetch_nand` एक [`Ordering`] आर्गुमेन्ट लिन्छ जुन यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्दछ।सबै अर्डरिंग मोडहरू सम्भव छन्।
    /// नोट गर्नुहोस् कि [`Acquire`] प्रयोग गर्नाले स्टोरले यो अपरेशन [`Relaxed`] को हिस्सा बनाउँछ, र [`Release`] प्रयोग गर्दा लोड भाग [`Relaxed`] बनाउँछ।
    ///
    ///
    /// **Note:** यो विधि केवल प्लेटफर्महरूमा उपलब्ध छ जुन `u8` मा परमाणु अपरेशनहरू समर्थन गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // हामी यहाँ परमाणु_ nand प्रयोग गर्न सक्दैनौं किनकि यसले bool अमान्य मानको साथ परिणाम दिन सक्छ।
        // यो हुन्छ किनकि आणविक अपरेशन--बिट पूर्णांकको साथ आन्तरिक रूपमा गरिन्छ, जसले माथिल्लो b बिटहरू सेट गर्दछ।
        //
        // त्यसोभए हामी केवल fetch_xor वा यसको सट्टामा बदल्छौं।
        if val {
            // (x&true)== !x हामीले bool उल्ट्याउनु पर्छ।
            //
            self.fetch_xor(true, order)
        } else {
            // (x&गलत)==सत्य हामीले bool लाई सेट गर्नु पर्छ।
            //
            self.swap(true, order)
        }
    }

    /// बुलियन मानको साथ तार्किक "or"।
    ///
    /// हालको मान र आर्गुमेन्ट `val` मा तार्किक "or" कार्य गर्दछ, र परिणाममा नयाँ मान सेट गर्दछ।
    ///
    /// अघिल्लो मान फर्काउँछ।
    ///
    /// `fetch_or` एक [`Ordering`] आर्गुमेन्ट लिन्छ जुन यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्दछ।सबै अर्डरिंग मोडहरू सम्भव छन्।
    /// नोट गर्नुहोस् कि [`Acquire`] प्रयोग गर्नाले स्टोरले यो अपरेशन [`Relaxed`] को हिस्सा बनाउँछ, र [`Release`] प्रयोग गर्दा लोड भाग [`Relaxed`] बनाउँछ।
    ///
    ///
    /// **Note:** यो विधि केवल प्लेटफर्महरूमा उपलब्ध छ जुन `u8` मा परमाणु अपरेशनहरू समर्थन गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // सुरक्षा: डाटा रेसहरू आणविक ईन्ट्रिन्सिक्स द्वारा रोकिएका छन।
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// बुलियन मानको साथ तार्किक "xor"।
    ///
    /// हालको मान र आर्गुमेन्ट `val` मा तार्किक "xor" कार्य गर्दछ, र परिणाममा नयाँ मान सेट गर्दछ।
    ///
    /// अघिल्लो मान फर्काउँछ।
    ///
    /// `fetch_xor` एक [`Ordering`] आर्गुमेन्ट लिन्छ जुन यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्दछ।सबै अर्डरिंग मोडहरू सम्भव छन्।
    /// नोट गर्नुहोस् कि [`Acquire`] प्रयोग गर्नाले स्टोरले यो अपरेशन [`Relaxed`] को हिस्सा बनाउँछ, र [`Release`] प्रयोग गर्दा लोड भाग [`Relaxed`] बनाउँछ।
    ///
    ///
    /// **Note:** यो विधि केवल प्लेटफर्महरूमा उपलब्ध छ जुन `u8` मा परमाणु अपरेशनहरू समर्थन गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // सुरक्षा: डाटा रेसहरू आणविक ईन्ट्रिन्सिक्स द्वारा रोकिएका छन।
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// अन्तर्निहित [`bool`] मा एक परिवर्तनीय सूचक फर्काउँछ।
    ///
    /// नॉन-परमाणु पढ्ने र नतिजा हुने पूर्णांकमा लेख्ने डेटा दौड हुन सक्छ।
    /// यो विधि अधिकतर एफएफआईको लागि उपयोगी छ, जहाँ प्रकार्य हस्ताक्षरले `&AtomicBool` को सट्टा `*mut bool` प्रयोग गर्न सक्दछ।
    ///
    /// एक `*mut` सूचक लाई यो आणविक को एक साझा संदर्भ बाट फर्काउने सुरक्षित छ किनकि आणविक प्रकारले आन्तरिक उत्परिवर्तनको साथ काम गर्दछ।
    /// एक आणविक सबै परिमार्जन एक साझा संदर्भ को माध्यम बाट मान परिवर्तन, र तिनीहरूले परमाणु अपरेशन्स को उपयोग सम्म लामो सुरक्षित गर्न सक्छन्।
    /// फिर्ता गरिएको कच्चा सूचकको कुनै पनि प्रयोगको लागि `unsafe` ब्लक आवश्यक पर्दछ र अझै पनि उही समान प्रतिबन्धलाई समर्थन गर्नुपर्दछ: यसमा सञ्चालनहरू आणविक हुनै पर्छ।
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// मान लिन्छ, र यसमा प्रकार्य लागू गर्दछ जुन वैकल्पिक नयाँ मान फिर्ता गर्दछ।`Ok(previous_value)` को `Result` फिर्ता गर्दछ यदि प्रकार्य `Some(_)`, अन्य `Err(previous_value)` फर्कायो भने।
    ///
    /// Note: यसले कार्य धेरै पटक कल गर्न सक्दछ यदि यस बीचमा अन्य थ्रेडबाट मान परिवर्तन गरिएको छ, जबसम्म प्रकार्य `Some(_)` फर्काउँदछ, तर प्रकार्य एक पटक मात्र भण्डारण गरिएको मानमा लागू गरिएको हुनेछ।
    ///
    ///
    /// `fetch_update` यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्न दुई [`Ordering`] आर्गुमेन्ट लिन्छ।
    /// पहिलो अपरेशन अन्ततः सफल हुँदा यसको लागि आवश्यक अर्डरिंग वर्णन गर्दछ जबकि दोस्रोले लोडहरूको लागि आवश्यक क्रमको वर्णन गर्दछ।
    /// यी क्रमश: [`AtomicBool::compare_exchange`] को सफलता र असफलता अर्डरिंगको अनुरूप छन्।
    ///
    /// सफलताको क्रमको रूपमा [`Acquire`] प्रयोग गर्नाले स्टोरले यो अपरेशन [`Relaxed`] को हिस्सा बनाउँछ, र [`Release`] प्रयोग गर्नाले अन्तिम सफल लोड [`Relaxed`] बनाउँदछ।
    /// (failed) लोड अर्डरिंग केवल [`SeqCst`], [`Acquire`] वा [`Relaxed`] हुन सक्छ र सफलता अर्डरिंग भन्दा बराबर वा कमजोर हुनुपर्दछ।
    ///
    /// **Note:** यो विधि केवल प्लेटफर्महरूमा उपलब्ध छ जुन `u8` मा परमाणु अपरेशनहरू समर्थन गर्दछ।
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// नयाँ `AtomicPtr` सिर्जना गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// अन्तर्निहित पोइन्टरमा म्यूटेबल सन्दर्भ फर्काउँछ।
    ///
    /// यो सुरक्षित छ किनकि म्यूटेबल सन्दर्भले ग्यारेन्टी गर्दछ कि कुनै अन्य थ्रेड समरूपमा आणविक डेटा पहुँच गरिरहेका छैनन्।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// एक सूचकमा आणविक पहुँच प्राप्त गर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - परिवर्तनीय सन्दर्भ अद्वितीय स्वामित्वको ग्यारेन्टी गर्दछ।
        //  - `*mut T` र `Self` को पign्क्तिबद्ध सबै प्लेटफर्महरूमा समान छ rust द्वारा समर्थित, माथिको प्रमाणितको रूपमा।
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// आणविक उपभोग गर्दछ र समावेश गरिएको मान फिर्ता गर्दछ।
    ///
    /// यो सुरक्षित छ किनकि मान द्वारा `self` पारित गर्दा ग्यारेन्टी हुन्छ कि कुनै अन्य थ्रेड समरूपमा आणविक डेटा पहुँच गरिरहेका छैनन्।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// सूचकबाट मान लोड गर्दछ।
    ///
    /// `load` एक [`Ordering`] आर्गुमेन्ट लिन्छ जुन यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्दछ।
    /// सम्भावित मानहरू [`SeqCst`], [`Acquire`] र [`Relaxed`] हुन्।
    ///
    /// # Panics
    ///
    /// Panics यदि `order` [`Release`] वा [`AcqRel`] हो।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // सुरक्षा: डाटा रेसहरू आणविक ईन्ट्रिन्सिक्स द्वारा रोकिएका छन।
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// सूचकमा मान भण्डार गर्दछ।
    ///
    /// `store` एक [`Ordering`] आर्गुमेन्ट लिन्छ जुन यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्दछ।
    /// सम्भावित मानहरू [`SeqCst`], [`Release`] र [`Relaxed`] हुन्।
    ///
    /// # Panics
    ///
    /// Panics यदि `order` [`Acquire`] वा [`AcqRel`] हो।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // सुरक्षा: डाटा रेसहरू आणविक ईन्ट्रिन्सिक्स द्वारा रोकिएका छन।
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// अघिल्लो मान फिर्ता गर्दै, सूचकमा मान भण्डार गर्दछ।
    ///
    /// `swap` एक [`Ordering`] आर्गुमेन्ट लिन्छ जुन यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्दछ।सबै अर्डरिंग मोडहरू सम्भव छन्।
    /// नोट गर्नुहोस् कि [`Acquire`] प्रयोग गर्नाले स्टोरले यो अपरेशन [`Relaxed`] को हिस्सा बनाउँछ, र [`Release`] प्रयोग गर्दा लोड भाग [`Relaxed`] बनाउँछ।
    ///
    ///
    /// **Note:** यो विधि केवल प्लेटफर्महरूमा उपलब्ध छ जसले सूचकहरूमा परमाणु अपरेशन समर्थन गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // सुरक्षा: डाटा रेसहरू आणविक ईन्ट्रिन्सिक्स द्वारा रोकिएका छन।
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// सूचकमा मान भण्डार गर्दछ यदि हालको मान `current` मान जस्तै हो।
    ///
    /// फिर्ती मान सँधै अघिल्लो मान हुन्छ।यदि यो `current` बराबर छ, तब मान अपडेट गरियो।
    ///
    /// `compare_and_swap` एक [`Ordering`] आर्गुमेन्ट पनि लिन्छ जुन यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्दछ।
    /// ध्यान दिनुहोस् कि [`AcqRel`] प्रयोग गर्दा पनि, अपरेशन असफल हुन सक्छ र त्यसैले मात्र एक `Acquire` लोड प्रदर्शन गर्दछ, तर `Release` शब्दार्थ छैन।
    /// [`Acquire`] प्रयोग गर्नाले स्टोरले यो अपरेशन [`Relaxed`] को हिस्सा बनाउँदछ यदि यो हुन्छ भने, र [`Release`] प्रयोग गर्नाले लोड भाग [`Relaxed`] बनाउँछ।
    ///
    /// **Note:** यो विधि केवल प्लेटफर्महरूमा उपलब्ध छ जसले सूचकहरूमा परमाणु अपरेशन समर्थन गर्दछ।
    ///
    /// # `compare_exchange` र `compare_exchange_weak` मा सर्दै
    ///
    /// `compare_and_swap` मेमोरी अर्डरिंगका लागि निम्न म्यापिppingको साथ `compare_exchange` बराबर हो।
    ///
    /// मूल |सफलता |असफलता
    /// -------- | ------- | -------
    /// रिलक्सड |रिलक्सड |आराम प्राप्तअधिग्रहण |जारी गर्नुहोस् |रिलीज |आरामदायक AcqRel |AcqRel |SeqCst प्राप्त गर्नुहोस्SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` तुलना सफल हुँदा पनि उत्तेजित रूपमा असफल हुन अनुमति दिईन्छ, जसले कम्पाइलरलाई राम्रो संयोजन कोड उत्पन्न गर्न मद्दत गर्दछ जब तुलना र स्व्याप लूपमा प्रयोग गरिन्छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// सूचकमा मान भण्डार गर्दछ यदि हालको मान `current` मान जस्तै हो।
    ///
    /// रिटर्न मान एक परिणाम हो जुन नयाँ मान लेखिएको थियो र अघिल्लो मान समावेश गर्दछ।
    /// सफलतामा यो मान `current` बराबर हुने ग्यारेन्टी गरिएको छ।
    ///
    /// `compare_exchange` यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्न दुई [`Ordering`] आर्गुमेन्ट लिन्छ।
    /// `success` पढ्ने-परिमार्जन-लेखन अपरेशनको लागि आवश्यक अर्डरिंग वर्णन गर्दछ जुन लिन्छ यदि `current` सँग तुलना सफल भयो भने।
    /// `failure` लोड अपरेशनका लागि आवश्यक अर्डरिंग वर्णन गर्दछ जुन तुलना विफल भएपछि हुने गर्दछ।
    /// [`Acquire`] लाई सफलताको क्रमको रूपमा प्रयोग गर्नाले स्टोरले यो अपरेशन [`Relaxed`] बनाउँदछ, र [`Release`] प्रयोग गर्नाले सफल लोड [`Relaxed`] बनाउँदछ।
    ///
    /// असफलता अर्डरिंग मात्र [`SeqCst`], [`Acquire`] वा [`Relaxed`] हुन सक्छ र सफलता अर्डरिंग भन्दा बराबर वा कमजोर हुनुपर्दछ।
    ///
    /// **Note:** यो विधि केवल प्लेटफर्महरूमा उपलब्ध छ जसले सूचकहरूमा परमाणु अपरेशन समर्थन गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // सुरक्षा: डाटा रेसहरू आणविक ईन्ट्रिन्सिक्स द्वारा रोकिएका छन।
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// सूचकमा मान भण्डार गर्दछ यदि हालको मान `current` मान जस्तै हो।
    ///
    /// [`AtomicPtr::compare_exchange`] विपरीत, यो प्रकार्य तुलनात्मक रूपमा सफल हुँदा पनि उत्तेजित रूपमा असफल हुने अनुमति दिईन्छ, जसले केहि प्लेटफर्महरूमा बढी कुशल कोडको परिणाम दिन्छ।
    ///
    /// रिटर्न मान एक परिणाम हो जुन नयाँ मान लेखिएको थियो र अघिल्लो मान समावेश गर्दछ।
    ///
    /// `compare_exchange_weak` यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्न दुई [`Ordering`] आर्गुमेन्ट लिन्छ।
    /// `success` पढ्ने-परिमार्जन-लेखन अपरेशनको लागि आवश्यक अर्डरिंग वर्णन गर्दछ जुन लिन्छ यदि `current` सँग तुलना सफल भयो भने।
    /// `failure` लोड अपरेशनका लागि आवश्यक अर्डरिंग वर्णन गर्दछ जुन तुलना विफल भएपछि हुने गर्दछ।
    /// [`Acquire`] लाई सफलताको क्रमको रूपमा प्रयोग गर्नाले स्टोरले यो अपरेशन [`Relaxed`] बनाउँदछ, र [`Release`] प्रयोग गर्नाले सफल लोड [`Relaxed`] बनाउँदछ।
    /// असफलता अर्डरिंग मात्र [`SeqCst`], [`Acquire`] वा [`Relaxed`] हुन सक्छ र सफलता अर्डरिंग भन्दा बराबर वा कमजोर हुनुपर्दछ।
    ///
    /// **Note:** यो विधि केवल प्लेटफर्महरूमा उपलब्ध छ जसले सूचकहरूमा परमाणु अपरेशन समर्थन गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // सुरक्षा: यो भित्री असुरक्षित छ किनकि यसले कच्चा सूचकमा काम गर्दछ
        // तर हामी यो कुरा निश्चितको लागि जान्दछौं कि सूचक मान्य छ (हामीले भर्खर यो हामीले `UnsafeCell` X बाट पाएका छौं जुन सन्दर्भमा छ) र आणविक अपरेसनले नै हामीलाई `UnsafeCell` सामग्रीहरू सुरक्षित रूपमा परिवर्तन गर्न अनुमति दिन्छ।
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// मान लिन्छ, र यसमा प्रकार्य लागू गर्दछ जुन वैकल्पिक नयाँ मान फिर्ता गर्दछ।`Ok(previous_value)` को `Result` फिर्ता गर्दछ यदि प्रकार्य `Some(_)`, अन्य `Err(previous_value)` फर्कायो भने।
    ///
    /// Note: यसले कार्य धेरै पटक कल गर्न सक्दछ यदि यस बीचमा अन्य थ्रेडबाट मान परिवर्तन गरिएको छ, जबसम्म प्रकार्य `Some(_)` फर्काउँदछ, तर प्रकार्य एक पटक मात्र भण्डारण गरिएको मानमा लागू गरिएको हुनेछ।
    ///
    ///
    /// `fetch_update` यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्न दुई [`Ordering`] आर्गुमेन्ट लिन्छ।
    /// पहिलो अपरेशन अन्ततः सफल हुँदा यसको लागि आवश्यक अर्डरिंग वर्णन गर्दछ जबकि दोस्रोले लोडहरूको लागि आवश्यक क्रमको वर्णन गर्दछ।
    /// यी क्रमश: [`AtomicPtr::compare_exchange`] को सफलता र असफलता अर्डरिंगको अनुरूप छन्।
    ///
    /// सफलताको क्रमको रूपमा [`Acquire`] प्रयोग गर्नाले स्टोरले यो अपरेशन [`Relaxed`] को हिस्सा बनाउँछ, र [`Release`] प्रयोग गर्नाले अन्तिम सफल लोड [`Relaxed`] बनाउँदछ।
    /// (failed) लोड अर्डरिंग केवल [`SeqCst`], [`Acquire`] वा [`Relaxed`] हुन सक्छ र सफलता अर्डरिंग भन्दा बराबर वा कमजोर हुनुपर्दछ।
    ///
    /// **Note:** यो विधि केवल प्लेटफर्महरूमा उपलब्ध छ जसले सूचकहरूमा परमाणु अपरेशन समर्थन गर्दछ।
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// `bool` लाई `AtomicBool` मा बदल्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // यो म्याक्रो केही वास्तुकलामा अप्रयुक्त हुन समाप्त हुन्छ।
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// एक पूर्णांक प्रकार जुन थ्रेडहरू बीचमा सुरक्षित रूपमा साझेदारी गर्न सकिन्छ।
        ///
        /// यस प्रकारको अन्तर्निहित पूर्णांक प्रकार, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// आणविक प्रकार र गैर-आणविक प्रकार बीच भिन्नताका साथै यस प्रकारको पोर्टेबिलिटीको बारेमा जानकारीको लागि, कृपया [module-level documentation] हेर्नुहोस्।
        ///
        ///
        /// **Note:** यो प्रकार केवल प्लेटफर्महरूमा उपलब्ध छ जुन आणविक लोड र [of को स्टोरहरूलाई समर्थन गर्दछ
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// एक आणविक पूर्णांक `0` मा आरम्भ भयो।
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // पठाउनुहोस् स्पष्ट रूपमा लागू गरिएको छ।
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// नयाँ आणविक पूर्णांक सिर्जना गर्दछ।
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// अन्तर्निहित पूर्णांकमा म्यूटेबल सन्दर्भ फर्काउँछ।
            ///
            /// यो सुरक्षित छ किनकि म्यूटेबल सन्दर्भले ग्यारेन्टी गर्दछ कि कुनै अन्य थ्रेड समरूपमा आणविक डेटा पहुँच गरिरहेका छैनन्।
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// म्युट को केहि_सिन्ट=१२3;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, १००);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - परिवर्तनीय सन्दर्भ अद्वितीय स्वामित्वको ग्यारेन्टी गर्दछ।
                //  - `$int_type` र `Self` को पign्क्तिबद्धता समान हो, $cfg_align द्वारा वचन दिएका र माथिको प्रमाणित।
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// आणविक उपभोग गर्दछ र समावेश गरिएको मान फिर्ता गर्दछ।
            ///
            /// यो सुरक्षित छ किनकि मान द्वारा `self` पारित गर्दा ग्यारेन्टी हुन्छ कि कुनै अन्य थ्रेड समरूपमा आणविक डेटा पहुँच गरिरहेका छैनन्।
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// आणविक पूर्णांकको मान लोड गर्दछ।
            ///
            /// `load` एक [`Ordering`] आर्गुमेन्ट लिन्छ जुन यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्दछ।
            /// सम्भावित मानहरू [`SeqCst`], [`Acquire`] र [`Relaxed`] हुन्।
            ///
            /// # Panics
            ///
            /// Panics यदि `order` [`Release`] वा [`AcqRel`] हो।
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // सुरक्षा: डाटा रेसहरू आणविक ईन्ट्रिन्सिक्स द्वारा रोकिएका छन।
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// आणविक पूर्णांकमा मान भण्डार गर्दछ।
            ///
            /// `store` एक [`Ordering`] आर्गुमेन्ट लिन्छ जुन यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्दछ।
            ///  सम्भावित मानहरू [`SeqCst`], [`Release`] र [`Relaxed`] हुन्।
            ///
            /// # Panics
            ///
            /// Panics यदि `order` [`Acquire`] वा [`AcqRel`] हो।
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // सुरक्षा: डाटा रेसहरू आणविक ईन्ट्रिन्सिक्स द्वारा रोकिएका छन।
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// परमाणु पूर्णा into्कमा मान भण्डार गर्दछ, अघिल्लो मान फिर्ता गर्दै।
            ///
            /// `swap` एक [`Ordering`] आर्गुमेन्ट लिन्छ जुन यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्दछ।सबै अर्डरिंग मोडहरू सम्भव छन्।
            /// नोट गर्नुहोस् कि [`Acquire`] प्रयोग गर्नाले स्टोरले यो अपरेशन [`Relaxed`] को हिस्सा बनाउँछ, र [`Release`] प्रयोग गर्दा लोड भाग [`Relaxed`] बनाउँछ।
            ///
            ///
            /// **नोट**: यो विधि केवल प्लेटफर्महरूमा उपलब्ध छ जुन आणविक अपरेसनहरू समर्थन गर्दछ
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // सुरक्षा: डाटा रेसहरू आणविक ईन्ट्रिन्सिक्स द्वारा रोकिएका छन।
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// आणविक पूर्णांकमा मान भण्डार गर्दछ यदि हालको मान `current` मान जस्तै हो।
            ///
            /// फिर्ती मान सँधै अघिल्लो मान हुन्छ।यदि यो `current` बराबर छ, तब मान अपडेट गरियो।
            ///
            /// `compare_and_swap` एक [`Ordering`] आर्गुमेन्ट पनि लिन्छ जुन यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्दछ।
            /// ध्यान दिनुहोस् कि [`AcqRel`] प्रयोग गर्दा पनि, अपरेशन असफल हुन सक्छ र त्यसैले मात्र एक `Acquire` लोड प्रदर्शन गर्दछ, तर `Release` शब्दार्थ छैन।
            ///
            /// [`Acquire`] प्रयोग गर्नाले स्टोरले यो अपरेशन [`Relaxed`] को हिस्सा बनाउँदछ यदि यो हुन्छ भने, र [`Release`] प्रयोग गर्नाले लोड भाग [`Relaxed`] बनाउँछ।
            ///
            /// **नोट**: यो विधि केवल प्लेटफर्महरूमा उपलब्ध छ जुन आणविक अपरेसनहरू समर्थन गर्दछ
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # `compare_exchange` र `compare_exchange_weak` मा सर्दै
            ///
            /// `compare_and_swap` मेमोरी अर्डरिंगका लागि निम्न म्यापिppingको साथ `compare_exchange` बराबर हो।
            ///
            /// मूल |सफलता |असफलता
            /// -------- | ------- | -------
            /// रिलक्सड |रिलक्सड |आराम प्राप्तअधिग्रहण |जारी गर्नुहोस् |रिलीज |आरामदायक AcqRel |AcqRel |SeqCst प्राप्त गर्नुहोस्SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` तुलना सफल हुँदा पनि उत्तेजित रूपमा असफल हुन अनुमति दिईन्छ, जसले कम्पाइलरलाई राम्रो संयोजन कोड उत्पन्न गर्न मद्दत गर्दछ जब तुलना र स्व्याप लूपमा प्रयोग गरिन्छ।
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// आणविक पूर्णांकमा मान भण्डार गर्दछ यदि हालको मान `current` मान जस्तै हो।
            ///
            /// रिटर्न मान एक परिणाम हो जुन नयाँ मान लेखिएको थियो र अघिल्लो मान समावेश गर्दछ।
            /// सफलतामा यो मान `current` बराबर हुने ग्यारेन्टी गरिएको छ।
            ///
            /// `compare_exchange` यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्न दुई [`Ordering`] आर्गुमेन्ट लिन्छ।
            /// `success` पढ्ने-परिमार्जन-लेखन अपरेशनको लागि आवश्यक अर्डरिंग वर्णन गर्दछ जुन लिन्छ यदि `current` सँग तुलना सफल भयो भने।
            /// `failure` लोड अपरेशनका लागि आवश्यक अर्डरिंग वर्णन गर्दछ जुन तुलना विफल भएपछि हुने गर्दछ।
            /// [`Acquire`] लाई सफलताको क्रमको रूपमा प्रयोग गर्नाले स्टोरले यो अपरेशन [`Relaxed`] बनाउँदछ, र [`Release`] प्रयोग गर्नाले सफल लोड [`Relaxed`] बनाउँदछ।
            ///
            /// असफलता अर्डरिंग मात्र [`SeqCst`], [`Acquire`] वा [`Relaxed`] हुन सक्छ र सफलता अर्डरिंग भन्दा बराबर वा कमजोर हुनुपर्दछ।
            ///
            /// **नोट**: यो विधि केवल प्लेटफर्महरूमा उपलब्ध छ जुन आणविक अपरेसनहरू समर्थन गर्दछ
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // सुरक्षा: डाटा रेसहरू आणविक ईन्ट्रिन्सिक्स द्वारा रोकिएका छन।
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// आणविक पूर्णांकमा मान भण्डार गर्दछ यदि हालको मान `current` मान जस्तै हो।
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// यस प्रकार्यलाई उत्तेजित रूपमा असफल हुन अनुमति दिईन्छ पनि जब तुलना सफल हुन्छ, जुन केहि प्लेटफर्महरूमा बढी कुशल कोडको परिणाम हुन सक्छ।
            /// रिटर्न मान एक परिणाम हो जुन नयाँ मान लेखिएको थियो र अघिल्लो मान समावेश गर्दछ।
            ///
            /// `compare_exchange_weak` यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्न दुई [`Ordering`] आर्गुमेन्ट लिन्छ।
            /// `success` पढ्ने-परिमार्जन-लेखन अपरेशनको लागि आवश्यक अर्डरिंग वर्णन गर्दछ जुन लिन्छ यदि `current` सँग तुलना सफल भयो भने।
            /// `failure` लोड अपरेशनका लागि आवश्यक अर्डरिंग वर्णन गर्दछ जुन तुलना विफल भएपछि हुने गर्दछ।
            /// [`Acquire`] लाई सफलताको क्रमको रूपमा प्रयोग गर्नाले स्टोरले यो अपरेशन [`Relaxed`] बनाउँदछ, र [`Release`] प्रयोग गर्नाले सफल लोड [`Relaxed`] बनाउँदछ।
            ///
            /// असफलता अर्डरिंग मात्र [`SeqCst`], [`Acquire`] वा [`Relaxed`] हुन सक्छ र सफलता अर्डरिंग भन्दा बराबर वा कमजोर हुनुपर्दछ।
            ///
            /// **नोट**: यो विधि केवल प्लेटफर्महरूमा उपलब्ध छ जुन आणविक अपरेसनहरू समर्थन गर्दछ
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// म्युट पुरानो= val.load(Ordering::Relaxed);
            /// लूप {नयाँ=पुरानो * २ लाई दिनुहोस्;
            ///     val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, } match म्याच गर्नुहोस्
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // सुरक्षा: डाटा रेसहरू आणविक ईन्ट्रिन्सिक्स द्वारा रोकिएका छन।
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// हालको मानमा थप गर्दछ, अघिल्लो मान फिर्ता गर्दै।
            ///
            /// यो अपरेसन ओभरफ्लोमा वरिपरि लपेटिन्छ।
            ///
            /// `fetch_add` एक [`Ordering`] आर्गुमेन्ट लिन्छ जुन यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्दछ।सबै अर्डरिंग मोडहरू सम्भव छन्।
            /// नोट गर्नुहोस् कि [`Acquire`] प्रयोग गर्नाले स्टोरले यो अपरेशन [`Relaxed`] को हिस्सा बनाउँछ, र [`Release`] प्रयोग गर्दा लोड भाग [`Relaxed`] बनाउँछ।
            ///
            ///
            /// **नोट**: यो विधि केवल प्लेटफर्महरूमा उपलब्ध छ जुन आणविक अपरेसनहरू समर्थन गर्दछ
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // सुरक्षा: डाटा रेसहरू आणविक ईन्ट्रिन्सिक्स द्वारा रोकिएका छन।
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// हालको मानबाट घटाउछ, अघिल्लो मान फिर्ता गर्दै।
            ///
            /// यो अपरेसन ओभरफ्लोमा वरिपरि लपेटिन्छ।
            ///
            /// `fetch_sub` एक [`Ordering`] आर्गुमेन्ट लिन्छ जुन यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्दछ।सबै अर्डरिंग मोडहरू सम्भव छन्।
            /// नोट गर्नुहोस् कि [`Acquire`] प्रयोग गर्नाले स्टोरले यो अपरेशन [`Relaxed`] को हिस्सा बनाउँछ, र [`Release`] प्रयोग गर्दा लोड भाग [`Relaxed`] बनाउँछ।
            ///
            ///
            /// **नोट**: यो विधि केवल प्लेटफर्महरूमा उपलब्ध छ जुन आणविक अपरेसनहरू समर्थन गर्दछ
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // सुरक्षा: डाटा रेसहरू आणविक ईन्ट्रिन्सिक्स द्वारा रोकिएका छन।
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// हालको मानको साथ Bitwise "and"।
            ///
            /// हालको मान र आर्गुमेन्ट `val` मा एक बिटवाइज "and" अपरेसन गर्दछ, र परिणाममा नयाँ मान सेट गर्दछ।
            ///
            /// अघिल्लो मान फर्काउँछ।
            ///
            /// `fetch_and` एक [`Ordering`] आर्गुमेन्ट लिन्छ जुन यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्दछ।सबै अर्डरिंग मोडहरू सम्भव छन्।
            /// नोट गर्नुहोस् कि [`Acquire`] प्रयोग गर्नाले स्टोरले यो अपरेशन [`Relaxed`] को हिस्सा बनाउँछ, र [`Release`] प्रयोग गर्दा लोड भाग [`Relaxed`] बनाउँछ।
            ///
            ///
            /// **नोट**: यो विधि केवल प्लेटफर्महरूमा उपलब्ध छ जुन आणविक अपरेसनहरू समर्थन गर्दछ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // सुरक्षा: डाटा रेसहरू आणविक ईन्ट्रिन्सिक्स द्वारा रोकिएका छन।
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// हालको मानको साथ Bitwise "nand"।
            ///
            /// हालको मान र आर्गुमेन्ट `val` मा एक बिटवाइज "nand" अपरेसन गर्दछ, र परिणाममा नयाँ मान सेट गर्दछ।
            ///
            /// अघिल्लो मान फर्काउँछ।
            ///
            /// `fetch_nand` एक [`Ordering`] आर्गुमेन्ट लिन्छ जुन यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्दछ।सबै अर्डरिंग मोडहरू सम्भव छन्।
            /// नोट गर्नुहोस् कि [`Acquire`] प्रयोग गर्नाले स्टोरले यो अपरेशन [`Relaxed`] को हिस्सा बनाउँछ, र [`Release`] प्रयोग गर्दा लोड भाग [`Relaxed`] बनाउँछ।
            ///
            ///
            /// **नोट**: यो विधि केवल प्लेटफर्महरूमा उपलब्ध छ जुन आणविक अपरेसनहरू समर्थन गर्दछ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // सुरक्षा: डाटा रेसहरू आणविक ईन्ट्रिन्सिक्स द्वारा रोकिएका छन।
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// हालको मानको साथ Bitwise "or"।
            ///
            /// हालको मान र आर्गुमेन्ट `val` मा एक बिटवाइज "or" अपरेसन गर्दछ, र परिणाममा नयाँ मान सेट गर्दछ।
            ///
            /// अघिल्लो मान फर्काउँछ।
            ///
            /// `fetch_or` एक [`Ordering`] आर्गुमेन्ट लिन्छ जुन यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्दछ।सबै अर्डरिंग मोडहरू सम्भव छन्।
            /// नोट गर्नुहोस् कि [`Acquire`] प्रयोग गर्नाले स्टोरले यो अपरेशन [`Relaxed`] को हिस्सा बनाउँछ, र [`Release`] प्रयोग गर्दा लोड भाग [`Relaxed`] बनाउँछ।
            ///
            ///
            /// **नोट**: यो विधि केवल प्लेटफर्महरूमा उपलब्ध छ जुन आणविक अपरेसनहरू समर्थन गर्दछ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // सुरक्षा: डाटा रेसहरू आणविक ईन्ट्रिन्सिक्स द्वारा रोकिएका छन।
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// हालको मानको साथ Bitwise "xor"।
            ///
            /// हालको मान र आर्गुमेन्ट `val` मा एक बिटवाइज "xor" अपरेसन गर्दछ, र परिणाममा नयाँ मान सेट गर्दछ।
            ///
            /// अघिल्लो मान फर्काउँछ।
            ///
            /// `fetch_xor` एक [`Ordering`] आर्गुमेन्ट लिन्छ जुन यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्दछ।सबै अर्डरिंग मोडहरू सम्भव छन्।
            /// नोट गर्नुहोस् कि [`Acquire`] प्रयोग गर्नाले स्टोरले यो अपरेशन [`Relaxed`] को हिस्सा बनाउँछ, र [`Release`] प्रयोग गर्दा लोड भाग [`Relaxed`] बनाउँछ।
            ///
            ///
            /// **नोट**: यो विधि केवल प्लेटफर्महरूमा उपलब्ध छ जुन आणविक अपरेसनहरू समर्थन गर्दछ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // सुरक्षा: डाटा रेसहरू आणविक ईन्ट्रिन्सिक्स द्वारा रोकिएका छन।
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// मान लिन्छ, र यसमा प्रकार्य लागू गर्दछ जुन वैकल्पिक नयाँ मान फिर्ता गर्दछ।`Ok(previous_value)` को `Result` फिर्ता गर्दछ यदि प्रकार्य `Some(_)`, अन्य `Err(previous_value)` फर्कायो भने।
            ///
            /// Note: यसले कार्य धेरै पटक कल गर्न सक्दछ यदि यस बीचमा अन्य थ्रेडबाट मान परिवर्तन गरिएको छ, जबसम्म प्रकार्य `Some(_)` फर्काउँदछ, तर प्रकार्य एक पटक मात्र भण्डारण गरिएको मानमा लागू गरिएको हुनेछ।
            ///
            ///
            /// `fetch_update` यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्न दुई [`Ordering`] आर्गुमेन्ट लिन्छ।
            /// पहिलो अपरेशन अन्ततः सफल हुँदा यसको लागि आवश्यक अर्डरिंग वर्णन गर्दछ जबकि दोस्रोले लोडहरूको लागि आवश्यक क्रमको वर्णन गर्दछ।यो सफलता र असफलता अर्डरिंगको अनुरूप छ
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// सफलताको क्रमको रूपमा [`Acquire`] प्रयोग गर्नाले स्टोरले यो अपरेशन [`Relaxed`] को हिस्सा बनाउँछ, र [`Release`] प्रयोग गर्नाले अन्तिम सफल लोड [`Relaxed`] बनाउँदछ।
            /// (failed) लोड अर्डरिंग केवल [`SeqCst`], [`Acquire`] वा [`Relaxed`] हुन सक्छ र सफलता अर्डरिंग भन्दा बराबर वा कमजोर हुनुपर्दछ।
            ///
            /// **नोट**: यो विधि केवल प्लेटफर्महरूमा उपलब्ध छ जुन आणविक अपरेसनहरू समर्थन गर्दछ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (अर्डरिंग: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (अर्डरिंग: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// हालको मानको साथ अधिकतम।
            ///
            /// हालको मान र आर्गुमेन्ट `val` को अधिकतम फेला पार्छ, र परिणाममा नयाँ मान सेट गर्दछ।
            ///
            /// अघिल्लो मान फर्काउँछ।
            ///
            /// `fetch_max` एक [`Ordering`] आर्गुमेन्ट लिन्छ जुन यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्दछ।सबै अर्डरिंग मोडहरू सम्भव छन्।
            /// नोट गर्नुहोस् कि [`Acquire`] प्रयोग गर्नाले स्टोरले यो अपरेशन [`Relaxed`] को हिस्सा बनाउँछ, र [`Release`] प्रयोग गर्दा लोड भाग [`Relaxed`] बनाउँछ।
            ///
            ///
            /// **नोट**: यो विधि केवल प्लेटफर्महरूमा उपलब्ध छ जुन आणविक अपरेसनहरू समर्थन गर्दछ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// गरौं बार=;२;
            /// अधिकतम_फू=foo.fetch_max (बार, Ordering::SeqCst).max(bar);
            /// assert! (max_foo==)२);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // सुरक्षा: डाटा रेसहरू आणविक ईन्ट्रिन्सिक्स द्वारा रोकिएका छन।
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// हालको मानको साथ न्यूनतम।
            ///
            /// हालको मान र आर्गुमेन्ट `val` को न्यूनतम फेला पार्छ, र परिणाममा नयाँ मान सेट गर्दछ।
            ///
            /// अघिल्लो मान फर्काउँछ।
            ///
            /// `fetch_min` एक [`Ordering`] आर्गुमेन्ट लिन्छ जुन यस अपरेशनको मेमोरी अर्डरिंग वर्णन गर्दछ।सबै अर्डरिंग मोडहरू सम्भव छन्।
            /// नोट गर्नुहोस् कि [`Acquire`] प्रयोग गर्नाले स्टोरले यो अपरेशन [`Relaxed`] को हिस्सा बनाउँछ, र [`Release`] प्रयोग गर्दा लोड भाग [`Relaxed`] बनाउँछ।
            ///
            ///
            /// **नोट**: यो विधि केवल प्लेटफर्महरूमा उपलब्ध छ जुन आणविक अपरेसनहरू समर्थन गर्दछ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// गरौं बार=१२;
            /// min_foo=foo.fetch_min (बार, Ordering::SeqCst).min(bar);
            /// assert_eq! (मिनेट_फू, १२);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // सुरक्षा: डाटा रेसहरू आणविक ईन्ट्रिन्सिक्स द्वारा रोकिएका छन।
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// अन्तर्निहित पूर्णांकमा म्यूटेबल पोइन्टर फर्काउँछ।
            ///
            /// नॉन-परमाणु पढ्ने र नतिजा हुने पूर्णांकमा लेख्ने डेटा दौड हुन सक्छ।
            /// यो विधि अधिकतर एफएफआईको लागि उपयोगी छ, जहाँ प्रकार्य हस्ताक्षर प्रयोग गर्न सक्दछ
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// एक `*mut` सूचक लाई यो आणविक को एक साझा संदर्भ बाट फर्काउने सुरक्षित छ किनकि आणविक प्रकारले आन्तरिक उत्परिवर्तनको साथ काम गर्दछ।
            /// एक आणविक सबै परिमार्जन एक साझा संदर्भ को माध्यम बाट मान परिवर्तन, र तिनीहरूले परमाणु अपरेशन्स को उपयोग सम्म लामो सुरक्षित गर्न सक्छन्।
            /// फिर्ता गरिएको कच्चा सूचकको कुनै पनि प्रयोगको लागि `unsafe` ब्लक आवश्यक पर्दछ र अझै पनि उही समान प्रतिबन्धलाई समर्थन गर्नुपर्दछ: यसमा सञ्चालनहरू आणविक हुनै पर्छ।
            ///
            ///
            /// # Examples
            ///
            /// 00 `X (extern-declaration) बेवास्ता गर्नुहोस्
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// बाह्य "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // सुरक्षा: `my_atomic_op` आणविक हो जबसम्म सुरक्षित।
            /// असुरक्षित {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // सुरक्षा: कलरले `atomic_store` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ।
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // सुरक्षा: कलरले `atomic_load` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ।
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षा: कलरले `atomic_swap` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ।
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// अघिल्लो मान (जस्तै __ sync_fetch_and_add) फर्काउँछ।
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षा: कलरले `atomic_add` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ।
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// अघिल्लो मान फर्काउँछ (जस्तै __sync_fetch_and_sub)।
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षा: कलरले `atomic_sub` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ।
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // सुरक्षा: कलरले `atomic_compare_exchange` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ।
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // सुरक्षा: कलरले `atomic_compare_exchange_weak` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ।
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षा: कलरले `atomic_and` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षा: कलरले `atomic_nand` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षा: कलरले `atomic_or` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षा: कलरले `atomic_xor` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// अधिकतम मान फिर्ता गर्छ (हस्ताक्षर गरिएको तुलना)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षा: कलरले `atomic_max` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// न्यूनतम मान फिर्ता गर्दछ (हस्ताक्षर गरिएको तुलना)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षा: कलरले `atomic_min` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// अधिकतम मान फिर्ता गर्छ (हस्ताक्षर नगरिएको तुलना)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षा: कलरले `atomic_umax` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// न्यूनतम मान फिर्ता गर्दछ (हस्ताक्षर नगरिएको तुलना)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // सुरक्षा: कलरले `atomic_umin` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// एक आणविक बार
///
/// निर्दिष्ट अर्डरमा निर्भर गर्दै, फेंसले कम्पाइलर र सीपीयूलाई यसको वरिपरि केहि प्रकारका मेमोरी अपरेसनहरू क्रमबद्ध गर्नबाट रोक्दछ।
/// यो सिन्क्रोनाइजेसन सिर्जना गर्दछ-यो र अन्य थ्रेडहरूमा परमाणु अपरेशन वा फेंस बीचको सम्बन्धहरू।
///
/// एउटा फेंस 'A' जसमा (कम्तिमा) [`Release`] अर्डरिंग शब्दार्थ छ, एक बार 'B' का साथ सिंक्रनाइज़ गर्दछ X कम्तिमा [`Acquire`] शब्दार्थ, यदि र यदि मात्र त्यहाँ अपरेशन X र Y, दुबै केहि आणविक वस्तु 'M' मा अपरेटिंग हुन्छ जुन A लाई क्रमबद्ध गरिएको छ X, Y B भन्दा पहिले सिंक्रनाइज हुन्छ र Y ले M लाई परिवर्तन अवलोकन गर्दछ।
/// यसले A र B बीचमा निर्भरता हुनु अघि प्रदान गर्दछ।
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// [`Release`] वा [`Acquire`] अर्थविज्ञानको साथ परमाणु अपरेशनहरू पनि फेन्सको साथ समक्रमण गर्न सक्दछन्।
///
/// एक बार जुन [`SeqCst`] अर्डरिंग गर्दछ, दुबै [`Acquire`] र [`Release`] सिमेन्टिक्स बाहेक, अन्य [`SeqCst`] कार्यहरू र/वा बाड़हरूको ग्लोबल प्रोग्राम अर्डरमा भाग लिन्छ।
///
/// [`Acquire`], [`Release`], [`AcqRel`] र [`SeqCst`] आदेशहरू स्वीकार गर्दछ।
///
/// # Panics
///
/// Panics यदि `order` [`Relaxed`] छ।
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // स्पिनलॉकमा आधारित म्युचुअल बहिष्कार आदिम।
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // पुरानो मान `false` नभएसम्म कुर्नुहोस्।
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // यो फेंस `unlock` मा स्टोर संग सिंक्रनाइज़।
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // सुरक्षा: आणविक बार प्रयोग गरेर सुरक्षित छ।
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// एक कम्पाइलर मेमोरी फेंस
///
/// `compiler_fence` कुनै पनि मेशिन कोड उत्सर्जन गर्दैन, तर कम्पाइलरलाई गर्न अनुमति दिईएको मेमोरी रि-अर्डर गर्ने प्रकारहरूमा प्रतिबन्ध लगाउँदछ।विशेष रूपमा, दिइएको [`Ordering`] अर्थको आधारमा, कम्पाइलर `compiler_fence` मा कलको पछाडि वा पछाडि कल वा पछाडिबाट पढ्ने वा लेख्ने सार्न अस्वीकृत हुन सक्छ।नोट गर्नुहोस् कि यसले **गर्दैन***हार्डवेयर* लाई यस्तो रि-अर्डरिंग गर्नबाट रोक्दछ।
///
/// यो एकल थ्रेड भएको, कार्यान्वयन प्रसंगमा समस्या होइन, तर जब अन्य थ्रेडहरूले एकै समयमा मेमोरीलाई परिमार्जन गर्न सक्दछन्, बलियो सि stronger्क्रोनाइजेसन आदिमहरू जस्तै [`fence`] आवश्यक छ।
///
/// पुन: अर्डरिंग बिभिन्न अर्डरिंग सेमान्टिक्स द्वारा रोकिएको हो:
///
///  - [`SeqCst`] को साथ, यस बिन्दुमा पठन र लेखनको कुनै पुनः क्रमबद्ध गर्न अनुमति छैन।
///  - [`Release`] को साथ, अघिल्लो पढ्ने र लेख्ने पछिल्लो लेखहरू सार्न सकिदैन।
///  - [`Acquire`] को साथ, पछिल्लो पठन र लेखहरू अघिल्लो पठनको अगाडि सर्न सकिदैन।
///  - [`AcqRel`] को साथ, माथिका दुबै नियमहरू लागू गरियो।
///
/// `compiler_fence` सामान्यतया थ्रेडलाई आफैंमा रेसिंग * रोक्नको लागि मात्र उपयोगी छ।त्यो हो, यदि दिइएको थ्रेडले कोडको एक टुक्रा कार्यान्वयन गरिरहेको छ, र त्यसपछि अवरोध भयो र अन्य ठाउँमा कोड कार्यान्वयन गर्न सुरू गर्दछ (जबकि अझै समान थ्रेडमा, र अवधारणा अनुसार अझै समान कोरमा)।परम्परागत कार्यक्रमहरूमा, यो तब मात्र हुन सक्दछ जब सिग्नल ह्यान्डलर दर्ता हुन्छ।
/// अधिक कम-स्तर कोडमा, त्यस्ता परिस्थितिहरू अवरोधहरू ह्यान्डल गर्ने बेला, पूर्व-इम्पेशनको साथ हरियो थ्रेडहरू कार्यान्वयन गर्ने क्रममा पनि उत्पन्न हुन सक्छ।
/// जिज्ञासु पाठकहरूलाई Linux कर्नेलको [memory barriers] को चर्चा पढ्न प्रोत्साहित गरियो।
///
/// # Panics
///
/// Panics यदि `order` [`Relaxed`] छ।
///
/// # Examples
///
/// `compiler_fence` बिना, निम्न कोडमा `assert_eq!` * एकल थ्रेडमा केहि भए पनि, सफल हुने ग्यारेन्टी छैन।
/// किन हेर्नको लागि, सम्झनुहोस् कि कम्पाइलर `IMPORTANT_VARIABLE` र `IS_READ` मा दुबै स्टोर बदल्न स्वतन्त्र छ किनकि ती दुबै `Ordering::Relaxed` हुन्।यदि यो गर्छ, र `IS_READY` अपडेट भएको ठीक पछि सिग्नल ह्यान्डलर आमन्त्रित गरिएको छ, तब संकेत ह्यान्डलरले `IS_READY=1` देख्नेछ, तर `IMPORTANT_VARIABLE=0`।
/// एक `compiler_fence` उपचारहरू प्रयोग गरेर यो अवस्था।
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // अघिल्लो लेखहरुलाई यस बिन्दु भन्दा पर सार्न रोक्नुहोस्
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // सुरक्षा: आणविक बार प्रयोग गरेर सुरक्षित छ।
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// प्रोसेसरले संकेत गर्दछ कि यो व्यस्त-प्रतिक्षा स्पिन-लूप ("स्पिन लक") भित्र छ।
///
/// यो प्रकार्य [`hint::spin_loop`] को पक्षमा अस्वीकृत छ।
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}