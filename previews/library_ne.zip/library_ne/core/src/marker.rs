//! प्राइमेटिभ traits र प्रकारहरूको आधारभूत गुण प्रतिनिधित्व गर्ने प्रकारहरू।
//!
//! Rust प्रकारहरू उनीहरूको आन्तरिक गुणहरू अनुसार विभिन्न उपयोगी तरीकाहरूमा वर्गीकृत गर्न सकिन्छ।
//! यी वर्गीकरण traits को रूप मा प्रतिनिधित्व गरीन्छ।
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// प्रकारहरू जुन थ्रेड सीमामा पार गर्न सकिन्छ।
///
/// यो trait स्वचालित रूपमा कार्यान्वयन हुन्छ जब कम्पाइलरले यो उपयुक्त छ भनेर निर्धारण गर्दछ।
///
/// गैर-`Send` प्रकारको उदाहरण सन्दर्भ-मतगणना सूचक [`rc::Rc`][`Rc`] हो।
/// यदि दुई थ्रेडहरूले क्लोन गर्न प्रयास गरे भने [`Rc`] s को उही सन्दर्भ-गणना मानमा, तिनीहरू एकै समयमा सन्दर्भ गणना अपडेट गर्न को लागी प्रयास गर्न सक्दछ, जुन [undefined behavior][ub] छ किनकि [`Rc`] आणविक अपरेशन प्रयोग गर्दैन।
///
/// यसको चचेरो भाई [`sync::Arc`][arc] आणविक अपरेसनहरू प्रयोग गर्दछ (केहि ओभरहेड समावेश गर्दछ) र त्यसैले यो `Send` हो।
///
/// अधिक जानकारीको लागि [the Nomicon](../../nomicon/send-and-sync.html) हेर्नुहोस्।
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// स्थिर आकारको साथ प्रकारहरू कम्पाईल समयमा ज्ञात हुन्छ।
///
/// सबै प्रकारका मानदण्डहरूको `Sized` को एक निहित सीमा छ।विशेष सिन्ट्याक्स `?Sized` यो बाउन्ड हटाउन प्रयोग गर्न सकिन्छ यदि यो उपयुक्त छैन।
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // संरचना FooUse(Foo<[i32]>);//त्रुटि: आकार [i32] को लागी लागू गरिएको छैन
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// एउटा अपवाद trait को निहित `Self` प्रकार हो।
/// एक trait एक निहित `Sized` बाध्य छैन किनकि यो [trait वस्तु] को साथ नमिल्दो हो जहाँ परिभाषाबाट trait सबै सम्भावित कार्यान्वयनकर्ताहरूसँग काम गर्न आवश्यक छ, र यसरी कुनै पनि आकार हुन सक्छ।
///
///
/// जे होस् Rust ले तपाईंलाई `Sized` लाई trait मा बाँध्न दिनेछ, तपाईं पछि यसलाई trait वस्तु बनाउनका लागि सक्षम हुनुहुने छैन:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // y दिनुहोस्: &dyn बार= &Impl;//त्रुटि: trait `Bar` वस्तुमा बनाउन सकिदैन
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // पूर्वनिर्धारितको लागि, उदाहरणका लागि, जो `[T]: !Default` मूल्यांकन गर्न आवश्यक छ
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// प्रकार जुन गतिशील आकारको प्रकारमा "unsized" हुन सक्छ।
///
/// उदाहरण को लागी, आकार को एरे प्रकार `[i8; 2]` `Unsize<[i8]>` र `Unsize<dyn fmt::Debug>` लागू गर्दछ।
///
/// `Unsize` का सबै कार्यान्वयन कम्पाइलर द्वारा स्वचालित रूपमा प्रदान गरिन्छ।
///
/// `Unsize` निम्नको लागि कार्यान्वयन गरिएको छ:
///
/// - `[T; N]` `Unsize<[T]>` हो
/// - `T` `Unsize<dyn Trait>` हुन्छ जब `T: Trait`
/// - `Foo<..., T, ...>` `Unsize<Foo<..., U, ...>>` हो यदि:
///   - `T: Unsize<U>`
///   - Foo एक संरचना हो
///   - `Foo` को अन्तिम फिल्डमा `T` समावेश भएको एक प्रकार छ
///   - `T` कुनै पनि अन्य क्षेत्रको प्रकारको होईन
///   - `Bar<T>: Unsize<Bar<U>>`, यदि `Foo` को अन्तिम फिल्डमा `Bar<T>` प्रकार छ
///
/// `Unsize` [`ops::CoerceUnsized`] का साथै "user-defined" कन्टेनरहरू [`Rc`] लाई गतिशील आकारका प्रकारहरू राख्न अनुमति दिन [`ops::CoerceUnsized`] सँग प्रयोग गरीन्छ।
/// अधिक जानकारीको लागि [DST coercion RFC][RFC982] र [the nomicon entry on coercion][nomicon-coerce] हेर्नुहोस्।
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// आवश्यक ढाँचा मिलानमा प्रयोग गरिएको trait।
///
/// कुनै पनि प्रकारको `PartialEq` स्वचालित रूपमा यो trait कार्यान्वयन गर्दछ,*यसको परवाह नगरे* यसको प्रकार-प्यारामिटरहरूले `Eq` कार्यान्वयन गर्छ कि गर्दैन।
///
/// यदि एक `const` आईटममा केहि प्रकार समावेश छ जुन यो trait कार्यान्वयन गर्दैन, त्यसो भए त्यो प्रकार (1.) `PartialEq` कार्यान्वयन गर्दैन (जसको अर्थ स्थिरले प्रदान गर्ने तुलना प्रणाली प्रदान गर्दैन, जुन कोड जनरेशन उपलब्ध छ भनेर मानिन्छ), वा (2.) ले यो लागू गर्दछ *यसको आफ्नै*`PartialEq` को संस्करण (जुन हामीले मान्यौं संरचनात्मक-समानता तुलनाको अनुरूप छैन)।
///
///
/// माथिका दुईवटा परिदृश्यहरू मध्ये कुनै एक ढाँचामा हामी कुनै प्रकारको मिलानमा यस्तो स्थिरको प्रयोगलाई अस्वीकार गर्दछौं।
///
/// [structural match RFC][RFC1445], र [issue 63438] पनि हेर्नुहोस् जुन गुणमा आधारित डिजाइनबाट यस trait मा सर्ने प्रेरणा दिन्छ।
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// आवश्यक ढाँचा मिलानमा प्रयोग गरिएको trait।
///
/// कुनै पनि प्रकारको `Eq` स्वचालित रूपमा यो trait कार्यान्वयन गर्दछ,*यसको परवाह नगरे* यसको प्रकारका प्यारामिटरहरूले `Eq` कार्यान्वयन गर्छन् कि गर्दैन।
///
/// यो हाम्रो प्रकारको प्रणालीमा सीमितताको वरिपरि काम गर्न एक ह्याक हो।
///
/// # Background
///
/// हामी चाहान्छौं कि बान्कीका प्रकारहरूसँग ढाँचा मिलानमा प्रयुक्त `#[derive(PartialEq, Eq)]` बिशेषता छ।
///
/// एक अधिक आदर्श संसारमा, हामी यो आवश्यकतालाई मात्र जाँच गरेर जाँच गर्न सक्दछौं कि प्रकारले `StructuralPartialEq` trait *र*`Eq` trait दुबै लागू गर्दछ।
/// जहाँसम्म, तपाईंसँग ADT हरू हुन सक्छन् * *`derive(PartialEq, Eq)` गर्छन, र यो केस हुन जुन हामी कम्पाइलरले स्वीकार्न चाहान्छौं, र अझै पनि स्थिरताको प्रकार `Eq` कार्यान्वयन गर्न असफल हुन्छ।
///
/// अर्थात्, यो जस्तो एक मामला:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (माथिको कोडमा समस्या यो छ कि `Wrap<fn(&())>` `PartialEq` कार्यान्वयन गर्दैन, न `Eq`, किनकि '<' a> fn(&'a _)` does not implement those traits.) को लागि
///
/// त्यसकारण, हामी `StructuralPartialEq` र केवल `Eq` को लागि भोले चेकमा भर पर्न सक्दैनौं।
///
/// यसको वरिपरि काम गर्नका लागि ह्याकको रूपमा, हामी दुई छुट्टै (`#[derive(PartialEq)]` र `#[derive(Eq)]`) प्रत्येकले ईन्जेक्टेड दुई छुट्टै traits प्रयोग गर्छौं र ती दुबै स्ट्रक्चरल-खेल जाँचको भागको रूपमा उपस्थित छन् भनेर जाँच गर्नुहोस्।
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// प्रकारहरू जसको मानहरू बिट्स प्रतिलिपि गरेर मात्र नक्कल गर्न सकिन्छ।
///
/// पूर्वनिर्धारितद्वारा, भ्यारीएबल बाइन्डिसँग 'मूव सेमेन्टिक्स' हुन्छ।अर्को शब्दमा:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` `y` मा सारियो, र त्यसैले प्रयोग गर्न सकिदैन
///
/// // println! ("{: ?}", x);//त्रुटि: सारिएको मान को उपयोग
/// ```
///
/// जहाँसम्म, यदि प्रकारले `Copy` कार्यान्वयन गर्‍यो, यसको सट्टामा 'प्रतिलिपि शब्दार्थ' छ:
///
/// ```
/// // हामी `Copy` कार्यान्वयन गर्न सक्दछौं।
/// // `Clone` यो पनि आवश्यक छ, किनकि यो `Copy` को एक सुपरट्राइट हो।
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` `x` को प्रतिलिपि हो
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// यो नोट गर्न महत्त्वपूर्ण छ कि यी दुई उदाहरणहरूमा, भिन्नता केवल यो हो कि तपाईंलाई कार्यपश्चात् `x` पहुँच गर्न अनुमति दिइएको छ कि छैन।
/// हुड मुनि, दुबै प्रतिलिपि र चालले बिट्सलाई मेमोरीमा नक्कल गर्न सक्छ, यद्यपि यो कहिलेकाँही अनुकूलित पनि हुन्छ।
///
/// ## म कसरी `Copy` कार्यान्वयन गर्न सक्छु?
///
/// तपाइँको प्रकारमा `Copy` कार्यान्वयन गर्न दुई तरिकाहरू छन्।`derive` प्रयोग गर्नका लागि सब भन्दा सरल हो:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// तपाईं `Copy` र `Clone` म्यानुअल रूपमा कार्यान्वयन गर्न सक्नुहुनेछ:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// त्यहाँ दुबै बीच सानो भिन्नता छ: `derive` रणनीतिले पनि X11X प्रकारका मानदण्डहरूमा बाध्य पार्दछ, जुन सधैं आवाश्यक हुँदैन।
///
/// ## `Copy` र `Clone` बीच के भिन्नता छ?
///
/// प्रतिलिपिहरू स्पष्ट रूपमा हुन्छन्, उदाहरणका लागि एक असाइनमेन्ट `y = x` को भागको रूपमा।`Copy` को व्यवहार अधिभार योग्य छैन;यो सँधै साधारण बिट वार प्रतिलिपि हुन्छ।
///
/// क्लोनिंग एक स्पष्ट कार्य हो, `x.clone()`।[`Clone`] को कार्यान्वयनले कुनै पनि प्रकार-विशिष्ट व्यवहार प्रदान गर्न सक्दछ मानहरू सुरक्षित रूपमा नक्कल गर्नका लागि।
/// उदाहरण को लागी [`Clone`] का लागी [`Clone`] को कार्यान्वयनले हिपमा पोइन्ट-टु स्ट्रिंग बफर प्रतिलिपि गर्नु पर्छ।
/// [`String`] मानको एक साधारण बिटवाइज प्रतिलिपि मात्र पोइन्टरको प्रतिलिपि गर्दछ, लाईन तल डबल फ्रि गर्न।
/// यस कारणका लागि, [`String`] [`Clone`] हो तर `Copy` होईन।
///
/// [`Clone`] `Copy` को एक सुपरट्राईट हो, त्यसैले जे जुन `Copy` हुन्छ उसले [`Clone`] पनि कार्यान्वयन गर्नुपर्दछ।
/// यदि प्रकार `Copy` हो भने यसको [`Clone`] कार्यान्वयनले मात्र `*self` फर्काउन आवश्यक छ (माथिको उदाहरण हेर्नुहोस्)।
///
/// ## कहिले मेरो प्रकारको `Copy` हुन सक्छ?
///
/// एक प्रकारले `Copy` लागू गर्न सक्दछ यदि यसको सबै कम्पोनेन्टहरूले `Copy` लागू गर्दछ।उदाहरण को लागी, यो संरचना `Copy` हुन सक्छ:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// एक संरचना `Copy` हुन सक्छ, र [`i32`] `Copy` हो, त्यसैले `Point` `Copy` हुन योग्य छ।
/// यसको विपरीत, विचार गर्नुहोस्
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// संरचना `PointList` `Copy` कार्यान्वयन गर्न सक्दैन, किनभने [`Vec<T>`] `Copy` हैन।यदि हामीले `Copy` कार्यान्वयन गर्न प्रयास गर्‍यौं भने, हामी त्रुटि प्राप्त गर्नेछौं:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// साझा सन्दर्भ (`&T`) पनि `Copy` हो, त्यसैले एक प्रकार `Copy` हुन सक्छ, यसले `T` प्रकारहरूको साझा सन्दर्भ राख्दछ कि * *`Copy` होईन।
/// निम्न संरचना विचार गर्नुहोस्, जसले `Copy` कार्यान्वयन गर्न सक्दछ, किनकि यसले केवल एक साझा गरिएको सन्दर्भलाई * हाम्रो गैर-`Copy` प्रकार `PointList` माथिको हो।
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## जब * मेरो प्रकारको `Copy` हुन सक्दैन?
///
/// केहि प्रकारहरू सुरक्षित रूपमा प्रतिलिपि गर्न सकिदैन।उदाहरण को लागी, `&mut T` को प्रतिलिपि बनाउँदा एक aliised म्यूटेबल सन्दर्भ पैदा हुनेछ।
/// [`String`] प्रतिलिपि गर्नाले [`String`] को बफर प्रबन्धनको लागि डुप्लिकेट जिम्मेदारी हुन्छ, जुन डबल फ्रीमा अग्रसर हुन्छ।
///
/// पछिल्लो केसलाई सामान्यीकरण गर्दै, [`Drop`] कार्यान्वयन गर्ने कुनै पनि प्रकारको `Copy` हुन सक्दैन, किनकि यसले आफ्नै [`size_of::<T>`] बाइटहरू बाहेक केही स्रोतहरू प्रबन्ध गरिरहेको छ।
///
/// यदि तपाइँ संरचना वा en-opCopy` डाटा समावेश enum मा `Copy` लागू गर्न कोशिस गर्नुभयो भने, तपाइँ त्रुटि [E0204] प्राप्त गर्नुहुनेछ।
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## कहिले * मेरो प्रकारको `Copy` हुनु पर्छ?
///
/// सामान्यतया बोल्दै, यदि तपाइँको प्रकार _can_ `Copy` लागू गर्दछ, यो हुनु पर्छ।
/// याद गर्नुहोस्, यद्यपि, `Copy` कार्यान्वयन गर्नु तपाईंको प्रकारको सार्वजनिक एपीआईको अंश हो।
/// यदि प्रकार future मा गैर-प्रतिलिपि बन्न सक्छ, यो ब्रेक एपीआई परिवर्तन बाट बच्न, `Copy` कार्यान्वयन अब छोड्नु बुद्धिमानी हुन सक्छ।
///
/// ## थप कार्यान्वयनकर्ताहरू
///
/// [implementors listed below][impls] को साथसाथै, निम्न प्रकारहरूले `Copy` लागू गर्दछ:
///
/// * प्रकार्य वस्तु प्रकारहरू (उदाहरणका लागि, प्रत्येक प्रकार्यका लागि फरक प्रकार परिभाषित)
/// * प्रकार्य सूचक प्रकारहरू (जस्तै, `fn() -> i32`)
/// * एर्रे प्रकारहरू, सबै आकारका लागि, यदि वस्तु प्रकारले `Copy` (जस्तै, `[i32; 123456]`) लागू गर्दछ।
/// * Tuple प्रकारहरू, यदि प्रत्येक घटकले `Copy` (उदाहरण, `()`, `(i32, bool)`) लागू गर्दछ।
/// * बन्द गर्ने प्रकारहरू, यदि तिनीहरूले वातावरणबाट कुनै मान लिदैन वा यदि ती सबै क्याप्चर मानहरू आफैं `Copy` कार्यान्वयन गर्छन्।
///   नोट गर्नुहोस् कि साझा सन्दर्भ द्वारा क्याप्चर भेरिएबलले सँधै `Copy` कार्यान्वयन गर्दछ (चाहे रेफर गरेन पनि), जबकि परिवर्तनीय सन्दर्भले क्याप्चर भ्यारीएबलले कहिले पनि `Copy` लागू गर्दैन।
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) यसले एक प्रकारको प्रतिलिपि गर्न अनुमति दिँदछ जसले असन्तुष्ट जीवनकाल सीमाहरूको कारण `Copy` कार्यान्वयन गर्दैन (`A<'_>` मात्र `A<'static>: Copy` र `A<'_>: Clone` मात्र प्रतिलिपि बनाउँदै)।
// हामीसँग यहाँ यो विशेषता अहिलेको लागि मात्र हो किनकि त्यहाँ `Copy` मा केही विद्यमान विशेषज्ञताहरू छन् जुन मानक लाइब्रेरीमा पहिले नै अवस्थित छ, र अहिले सुरक्षित व्यवहार गर्ने कुनै तरिका छैन।
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// trait `Copy` को एक इम्प्ली उत्पन्न डेरिभ म्याक्रो।
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// प्रकारहरू जसका लागि यो थ्रेडहरू बीच सन्दर्भ साझेदारी गर्न सुरक्षित छ।
///
/// यो trait स्वचालित रूपमा कार्यान्वयन हुन्छ जब कम्पाइलरले यो उपयुक्त छ भनेर निर्धारण गर्दछ।
///
/// सटीक परिभाषा हो: एक प्रकार `T` [`Sync`] हो यदि `&T` [`Send`] हो भने मात्र।
/// अर्को शब्दहरूमा, यदि त्यहाँ थ्रेडहरू बीच `&T` सन्दर्भ पास गर्दा [undefined behavior][ub] (डेटा रेस सहित) को कुनै सम्भावना छैन।
///
/// एकले अपेक्षा गरे अनुसार, आदिम प्रकारहरू जस्तै [`u8`] र [`f64`] सबै [`Sync`] हुन्, र त्यसैले साधारण समग्र प्रकारहरू तिनीहरूलाई समावेश गर्दछ, जस्तै ट्यूपल्स, स्टर्क्टहरू र एम्स।
/// आधारभूत [`Sync`] प्रकारका अधिक उदाहरणहरूमा "immutable" प्रकारहरू `&T`, र साधारण पैतृक सम्बन्धी उत्परिवर्तन, जस्तै [`Box<T>`][box], [`Vec<T>`][vec] र अधिक अन्य संग्रह प्रकारहरू समावेश गर्दछ।
///
/// (जेनेरिक प्यारामिटरहरू तिनीहरूको कन्टेनर हुनको लागि [00 Sync`] [`Sync`] हुनु पर्छ।)
///
/// परिभाषाको केहि आश्चर्यजनक परिणाम यो हो कि `&mut T` `Sync` (यदि `T` `Sync` हो) जे भए जस्तो देखिन्छ कि यसले अनइन्क्रनाइज गरिएको उत्परिवर्तन प्रदान गर्दछ।
/// चाल यो हो कि एक साझा सन्दर्भ पछाडि एक परिवर्तनीय सन्दर्भ (कि, `& &mut T`) केवल पढ्न मात्र सकिन्छ, यदि यो एक `& &T` हो।
/// त्यसकारण त्यहाँ डेटा दौडको कुनै जोखिम छैन।
///
/// `Sync` नभएका प्रकारहरू ती हुन् जुन "interior mutability" गैर थ्रेड-सुरक्षित फारममा छन्, जस्तै [`Cell`][cell] र [`RefCell`][refcell]।
/// यी प्रकारहरूले एक अपरिवर्तनीय, साझा संदर्भको माध्यमबाट उनीहरूको सामग्रीको उत्परिवर्तनको लागि अनुमति दिन्छ।
/// उदाहरण को लागी [`Cell<T>`][cell] मा `set` विधि `&self` लिन्छ, त्यसैले यो केवल एक साझा संदर्भ [`&Cell<T>`][cell] मात्र आवश्यक छ।
/// विधिले कुनै सिnch्क्रोनाइजेसन प्रदर्शन गर्दैन, त्यसैले [`Cell`][cell] `Sync` हुन सक्दैन।
///
/// गैर `Sync` प्रकारको अर्को उदाहरण सन्दर्भ-गणना गणना सूचक [`Rc`][rc] हो।
/// कुनै सन्दर्भ [`&Rc<T>`][rc] दिईयो, तपाईले नयाँ [`Rc<T>`][rc] क्लोन गर्न सक्नुहुनेछ, गैर-आणविक तरिकाले सन्दर्भ गणना परिमार्जन गर्नुहोस्।
///
/// केसहरूको लागि जब कसैलाई थ्रेड-सुरक्षित ईन्टिरि। म्युबिलिटी आवश्यक पर्दछ, Rust [atomic data types], साथै [`sync::Mutex`][mutex] र [`sync::RwLock`][rwlock] मार्फत स्पष्ट लक गर्ने प्रदान गर्दछ।
/// यी प्रकारहरूले सुनिश्चित गर्दछ कि कुनै पनी उत्परिवर्तनले डाटा रेसहरू निम्त्याउँदैन, त्यसैले प्रकारहरू `Sync` हुन्।
/// त्यस्तै, [`sync::Arc`][arc] [`Rc`][rc] को थ्रेड-सुरक्षित एनालग प्रदान गर्दछ।
///
/// कुनै पनि प्रकारका आन्तरिक उत्परिवर्तनले [`cell::UnsafeCell`][unsafecell] र्यापर पनि value(s) वरपर प्रयोग गर्नुपर्दछ जुन साझा संदर्भको माध्यमबाट परिवर्तित गर्न सकिन्छ।
/// यो गर्न असफल [undefined behavior][ub] हो।
/// उदाहरण को लागी, [`transmute`][transmute]-ing `&T` बाट `&mut T` मा अवैध छ।
///
/// `Sync` को बारेमा अधिक विवरणहरूको लागि [the Nomicon][nomicon-send-and-sync] हेर्नुहोस्।
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): एक पटक बिटामा `rustc_on_unimplemented` जमिनमा नोटहरू थप्न समर्थन गर्दछ, र यो आवश्यक श्रृंखलामा कतै पनि बन्द छ कि छैन भनेर जाँच गर्न विस्तार गरिएको छ, यस्तो (#48534) को रूपमा विस्तार गर्नुहोस्:
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// शून्य आकारका प्रकारहरू मार्क्स गर्न प्रयोग जुन "act like" तिनीहरूको स्वामित्वमा एक `T`।
///
/// तपाइँको प्रकारमा `PhantomData<T>` क्षेत्र थप्नाले कम्पाइलरलाई बताउँदछ कि तपाइँको प्रकारले कार्य गर्दछ किनकि यसले प्रकारको `T` को मान भण्डार गर्दछ, यद्यपि यो वास्तवमै छैन।
/// केही सुरक्षा गुणहरू गणना गर्दा यो जानकारी प्रयोग गरिन्छ।
///
/// `PhantomData<T>` कसरी प्रयोग गर्ने भन्ने बारे अझ गहन विवरणको लागि, कृपया [the Nomicon](../../nomicon/phantom-data.html) हेर्नुहोस्।
///
/// # भयानक नोट note
///
/// यद्यपि ती दुबै डराउने नामहरू छन्, `PhantomData` र 'प्रेत प्रकारहरू' सम्बन्धित छन्, तर समान छैन।एक प्रेत प्रकार प्यारामिटर मात्र एक प्रकार प्यारामिटर हो जुन कहिले प्रयोग हुँदैन।
/// Rust मा, यसले प्राय: कम्पाइलरलाई गुनासो गर्दछ, र समाधान भनेको `PhantomData` मार्फत "dummy" प्रयोग थप्नु हो।
///
/// # Examples
///
/// ## प्रयोग नभएको आजीवन प्यारामिटरहरू
///
/// सायद `PhantomData` को लागी सबैभन्दा सामान्य प्रयोग केस एक संरचना हो जुन एक प्रयोग नगरिएको जीवनकाल प्यारामिटर छ, सामान्यतया केहि असुरक्षित कोडको अंशको रूपमा।
/// उदाहरण को लागी, यहाँ एक संरचना `Slice` छ कि `*const T` प्रकारको दुई पोइन्टर्स, सम्भवतः एर्रे मा कहीं इशारा गर्दै:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// अभिप्राय यो छ कि अंतर्निहित डाटा मात्र जीवनकाल `'a` को लागी मान्य छ, त्यसैले `Slice` `'a` लाई आउटलाइभ गर्नुहुन्न।
/// जे होस्, यो अभिप्राय कोड मा अभिव्यक्त गरिएको छैन, किनकि त्यहाँ आजीवन `'a` को कुनै उपयोग छैन र त्यसैले यो कुन डाटा लाई लागु हुन्छ भन्ने कुरा स्पष्ट छैन।
/// हामीले यो ठीक गर्न सक्दछ कम्पाइलरलाई *कार्य गर्न भनि* यदि * `Slice` संरचनामा एक संदर्भ `&'a T` समावेश छ:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// यसको बदलामा एनोटेसन `T: 'a` पनि चाहिन्छ, `T` मा कुनै पनि सन्दर्भहरू आजीवन `'a` मा मान्य हुन्छ भनेर संकेत गर्दै।
///
/// जब एक `Slice` इनिसियलाइज गर्दा तपाई केवल `PhantomData` फिल्ड `phantom` को लागी मान प्रदान गर्नुहुन्छ।
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## अप्रयुक्त प्रकार प्यारामिटरहरू
///
/// यो कहिलेकाँही यस्तो हुन्छ कि तपाईंसँग अप्रयुक्त प्रकारका प्यारामिटरहरू छन् जसले कुन प्रकारको डेटा स्ट्र indicateट "tied" मा सूचित गर्दछ, जबकि त्यो डाटा वास्तवमै संरचनामा फेला पर्दैन।
/// यहाँ एक उदाहरण छ जहाँ यो [FFI] को साथ उठ्छ।
/// विदेशी ईन्टरफेसले `*mut ()` प्रकारका ह्यान्डलहरू प्रयोग गर्दछ विभिन्न प्रकारका Rust मानहरू सन्दर्भित गर्न।
/// हामी Rust प्रकार ट्र्याक गर्दछ `ExternalResource` स्ट्रैक्ट XXX मा प्रेतम प्रकार प्यारामिटर प्रयोग गरेर जुन ह्यान्डललाई लपेट्छ।
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## स्वामित्व र ड्रप चेक
///
/// `PhantomData<T>` प्रकारको क्षेत्र थप्नाले संकेत गर्दछ कि तपाईंको प्रकारले `T` प्रकारको डाटाको स्वामित्व राख्दछ।यसले बदल्नमा यो संकेत गर्दछ कि जब तपाइँको प्रकार खसाईन्छ, यो प्रकार `T` को एक वा बढी उदाहरणहरु ड्रप गर्न सक्छ।
/// यो Rust कम्पाइलरको [drop check] विश्लेषणमा लिईएको छ।
///
/// यदि तपाइँको संरचना वास्तवमा *प्रकार*`T` को डेटा को स्वामित्व छैन भने, यो सन्दर्भ प्रकार जस्तै `PhantomData<&'a T>` (ideally) वा `PhantomData<*const T>` (यदि कुनै आजीवन लागू हुँदैन भने) प्रयोग गर्नु राम्रो हुन्छ, त्यसैले स्वामित्व दर्साउँदैन।
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// कम्पाइलर-आन्तरिक trait एनम भेदभावको प्रकारलाई संकेत गर्न प्रयोग गरियो।
///
/// यो trait स्वचालित रूपमा प्रत्येक प्रकारको लागि लागू गरिएको छ र [`mem::Discriminant`] मा कुनै ग्यारेन्टीहरू थप गर्दैन।
/// यो **अपरिभाषित व्यवहार**`DiscriminantKind::Discriminant` र `mem::Discriminant` बीच ट्रान्समिट गर्न को लागी हो।
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// भेदभावकर्ताको प्रकार, जसले `mem::Discriminant` लाई चाहिएको trait bounds पूरा गर्नु पर्छ।
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// कम्पाइलर-आन्तरिक trait निर्धारित गर्न प्रयोग गरियो कि प्रकारले कुनै `UnsafeCell` आन्तरिक रूपमा समावेश गर्दछ, तर एक दिशाको माध्यमबाट होईन।
///
/// यसले असर पार्छ, उदाहरणका लागि, त्यस प्रकारको `static` पठाइएको मात्र स्ट्याटिक मेमोरीमा वा लेख्न योग्य स्थिर मेमोरीमा राखिएको छ।
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// प्रकारहरू जुन पिन पछि सुरक्षित रूपमा सारिन सकिन्छ।
///
/// Rust आफैंमा अचल जीवहरूको कुनै धारणा छैन, र चालहरू (उदाहरणका लागि, असाइनमेन्ट वा [`mem::replace`] को माध्यमबाट) लाई सधैं सुरक्षित रहनको लागि विचार गर्दछ।
///
/// [`Pin`][Pin] प्रकार यसको प्रकार प्रणाली मार्फत चालहरू रोक्नको लागि प्रयोग गरिन्छ।[`Pin<P<T>>`][Pin] र्यापरमा बेर्काएको पोइन्टरहरू `P<T>` बाहिर बाहिर सार्न सकिदैन।
/// पिन गर्नेमा थप जानकारीको लागि [`pin` module] कागजात हेर्नुहोस्।
///
/// `T` का लागि `Unpin` trait कार्यान्वयन गर्नाले प्रकार बन्द गर्ने बन्देज हटाउँदछ, जसले [`Pin<P<T>>`][Pin] बाहिर [`mem::replace`] लाई [`mem::replace`] जस्ता प्रकार्यहरूको साथ सार्न अनुमति दिन्छ।
///
///
/// `Unpin` गैर-पिन डाटाको लागि कुनै परिणाम छैन।
/// विशेष रूपमा, [`mem::replace`] खुशीसाथ `!Unpin` डाटा सार्दछ (यो कुनै पनि `&mut T` को लागी काम गर्दछ, `T: Unpin` मात्र होइन)।
/// जहाँसम्म, तपाई [`Pin<P<T>>`][Pin] भित्र बेरिएको डाटामा [`mem::replace`] प्रयोग गर्न सक्नुहुन्न किनकि तपाईले यसको लागि आवश्यक पर्ने `&mut T` प्राप्त गर्न सक्नुहुन्न, र *त्यो* हो जुन यस प्रणालीले काम गर्दछ।
///
/// त्यसो भए यो उदाहरणको लागि मात्र `Unpin` कार्यान्वयन गर्ने प्रकारहरूमा मात्र गर्न सकिन्छ:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // हामीलाई `mem::replace` कल गर्न म्यूटेबल सन्दर्भ चाहिन्छ।
/// // हामीले (implicitly) लाई `Pin::deref_mut` बोलाउँदै पनि त्यस्तै सन्दर्भ प्राप्त गर्न सक्छौं, तर त्यो मात्र सम्भव छ किनकि `String` ले `Unpin` लागू गर्दछ।
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// यो trait स्वचालित रूपमा लगभग सबै प्रकारको लागी लागू हुन्छ।
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// मार्कर प्रकार जुन `Unpin` कार्यान्वयन गर्दैन।
///
/// यदि प्रकारले `PhantomPinned` समावेश गर्दछ भने, यसले पूर्वनिर्धारितद्वारा `Unpin` कार्यान्वयन गर्दैन।
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// आदिम प्रकारका लागि `Copy` को कार्यान्वयन।
///
/// Rust मा वर्णन गर्न सकिदैन कार्यान्वयनहरू `rustc_trait_selection` मा `traits::SelectionContext::copy_clone_conditions()` मा लागू गरियो।
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// साझेदारी सन्दर्भहरू प्रतिलिपि गर्न सकिन्छ, तर परिवर्तनीय सन्दर्भहरू *सक्दैन*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}