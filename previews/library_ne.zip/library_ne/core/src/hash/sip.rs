//! SipHash को कार्यान्वयन।

#![allow(deprecated)] // यस मोड्युलमा प्रकारहरू घटाईयो

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// SipHash १-1-3 को कार्यान्वयन।
///
/// यो हाल मानक पुस्तकालय द्वारा प्रयोग गरीएको पूर्वनिर्धारित हैशिंग प्रकार्य हो (उदाहरणका लागि `collections::HashMap` यसलाई पूर्वनिर्धारितद्वारा प्रयोग गर्दछ)।
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// SipHash २-An को कार्यान्वयन।
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// SipHash २-An को कार्यान्वयन।
///
/// See: <https://131002.net/siphash/>
///
/// SipHash एक सामान्य प्रयोजन को लागी हैशिंग समारोह हो: यो एक राम्रो गति (स्पूकी र शहर संग प्रतिस्पर्धी) मा चलाउँछ र मजबूत _keyed_ हैशिंग अनुमति।
///
/// यसले तपाइँलाई तपाइँको ह्यास तालिकालाई मजबूत RNG बाट कुञ्जी बनाउँदछ, जस्तै [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html)।
///
/// जे होस् सिपहस एल्गोरिथ्मलाई सामान्य रूपमा बलियो मानिन्छ, यो क्रिप्टोग्राफिक उद्देश्यको लागि होइन।
/// त्यस्तै, यस क्रियान्वयनको सबै क्रिप्टोग्राफिक प्रयोगहरू _strongly discouraged_ हुन्।
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // कतिवटा बाइटहरू हामीले प्रसोधन गरेका छौं
    state: State,  // ह्यास राज्य
    tail: u64,     // असीमित बाइट्स ले
    ntail: usize,  // पुच्छरमा कति बाइट्स मान्य छन्
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2 र v1, v3 एल्गोरिथ्ममा जोडीमा देखा पर्दछ, र SipHash को सिमड कार्यान्वयनले v02 र v13 को vectors प्रयोग गर्दछ।
    //
    // संरचना मा यो क्रम मा राखेर, कम्पाइलर आफैले केही सिम अनुकूलन गर्न सक्दछ।
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// बाइट स्ट्रीमबाट LE क्रममा, इच्छित प्रकारको एक पूर्णांक लोड गर्दछ।
/// `copy_nonoverlapping` को प्रयोग गर्दछ कम्पाइलरले सम्भावित अस्ताईन नगरिएको ठेगानाबाट लोड गर्नका लागि सबैभन्दा प्रभावकारी तरीका उत्पन्न गर्न।
///
///
/// असुरक्षित किनकि: i..i+size_of(int_ty) मा अनचेक अनुक्रमणिका
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// एक u64 लोड गर्दछ बाइट स्लाइसको by बाइट सम्म।
/// यो अनौंठो देखिन्छ तर `copy_nonoverlapping` कलहरू देखा पर्दछ (`load_int_le!` मार्फत) सबै निश्चित आकारहरू छन् र `memcpy` कल गर्नबाट रोक्छ जुन गतिको लागि राम्रो हो।
///
///
/// असुरक्षित किनकि: अनचेक अनुक्रमणिका शुरू..स्टार्ट + लेनमा
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // वर्तमान बाइट सूचकांक (LSB बाट) आउटपुट u64 मा
    let mut out = 0;
    if i + 3 < len {
        // सुरक्षा: `i` `len` भन्दा ठूलो हुन सक्दैन, र कलरले ग्यारेन्टी गर्न अनिवार्य छ
        // त्यो सूचकांक सुरु..स्टार्ट + लेन सीमामा छ।
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // सुरक्षा: माथिको जस्तै।
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // सुरक्षा: माथिको जस्तै।
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// दुई सुरुवाती कुञ्जीहरू ० मा सेट गरिएको नयाँ `SipHasher` सिर्जना गर्दछ।
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// एक `SipHasher` सिर्जना गर्दछ जुन प्रदान गरिएको कुञ्जीमा keyed छ।
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// दुई सुरुवाती कुञ्जीहरू ० मा सेट गरिएको नयाँ `SipHasher13` सिर्जना गर्दछ।
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// एक `SipHasher13` सिर्जना गर्दछ जुन प्रदान गरिएको कुञ्जीमा keyed छ।
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: कुनै पूर्णांक ह्याशिंग विधिहरू (`Writ_u *`, `write_i*`) परिभाषित छैनन्
    // यस प्रकारको लागि।
    // हामी तिनीहरूलाई थप्न सक्दछौं, `short_write` कार्यान्वयनलाई librustc_data_structures/sip128.rs मा प्रतिलिपि गर्न सक्छौं, र `write_u *`/`write_i*` विधिहरू `SipHasher`, `SipHasher13`, र `DefaultHasher` मा थप्न सक्नुहुन्छ।
    //
    // यसले ती ह्यासहरूद्वारा पूर्ण रूपमा पूर्णा has्कीय ह्यासि speedको गति बढाउँदछ, केही बेन्चमार्कमा कम्पाइल गति थोरै ढिलो बनाउनको लागतमा।
    // विवरणका लागि #69152 हेर्नुहोस्।
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // सुरक्षा: `cmp::min(length, needed)` `length` मा नहुनु ग्यारेन्टी छ
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // बफर टेल अब फ्ल्यास छ, नयाँ इनपुट प्रक्रिया गर्नुहोस्।
        let len = length - needed;
        let left = len & 0x7; // लेन% 8

        let mut i = needed;
        while i < len - left {
            // सुरक्षा: किनकि `len - left` under मुनिको सबैभन्दा ठूलो गुणक हो
            // `len`, र किनभने `i` `needed` मा शुरू हुन्छ जहाँ `len` `length - needed` हो, `i + 8` `length` भन्दा कम वा बराबरको ग्यारेन्टी गरिएको छ।
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // सुरक्षा: `i` अब `needed + len.div_euclid(8) * 8`,
        // त्यसोभए `i + left` = `needed + len` = `length`, जुन `msg.len()` बराबर परिभाषा द्वारा छ।
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// दुई सुरुवाती कुञ्जीहरू ० मा सेट गरिएको `Hasher<S>` सिर्जना गर्दछ।
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}