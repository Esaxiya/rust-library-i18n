//! जेनेरिक हैशिंग समर्थन।
//!
//! यो मोड्युलले मानको [hash] गणना गर्न सामान्य तरीका प्रदान गर्दछ।
//! ह्यासहरू प्राय: [`HashMap`] र [`HashSet`] को साथ प्रयोग गरिन्छ।
//!
//! [hash]: https://en.wikipedia.org/wiki/Hash_function
//! [`HashMap`]: ../../std/collections/struct.HashMap.html
//! [`HashSet`]: ../../std/collections/struct.HashSet.html
//!
//! एक प्रकारको हैशेबल बनाउनको लागि सजिलो तरीका भनेको `#[derive(Hash)]` प्रयोग गर्नु हो:
//!
//! # Examples
//!
//! ```rust
//! use std::collections::hash_map::DefaultHasher;
//! use std::hash::{Hash, Hasher};
//!
//! #[derive(Hash)]
//! struct Person {
//!     id: u32,
//!     name: String,
//!     phone: u64,
//! }
//!
//! let person1 = Person {
//!     id: 5,
//!     name: "Janet".to_string(),
//!     phone: 555_666_7777,
//! };
//! let person2 = Person {
//!     id: 5,
//!     name: "Bob".to_string(),
//!     phone: 555_666_7777,
//! };
//!
//! assert!(calculate_hash(&person1) != calculate_hash(&person2));
//!
//! fn calculate_hash<T: Hash>(t: &T) -> u64 {
//!     let mut s = DefaultHasher::new();
//!     t.hash(&mut s);
//!     s.finish()
//! }
//! ```
//!
//! यदि तपाईंलाई कसरी एक मूल्य ह्याश गरिएकोमा अधिक नियन्त्रणको आवश्यकता छ भने, तपाईंले [`Hash`] trait कार्यान्वयन गर्न आवश्यक छ:
//!
//!
//! ```rust
//! use std::collections::hash_map::DefaultHasher;
//! use std::hash::{Hash, Hasher};
//!
//! struct Person {
//!     id: u32,
//!     # #[allow(dead_code)]
//!     name: String,
//!     phone: u64,
//! }
//!
//! impl Hash for Person {
//!     fn hash<H: Hasher>(&self, state: &mut H) {
//!         self.id.hash(state);
//!         self.phone.hash(state);
//!     }
//! }
//!
//! let person1 = Person {
//!     id: 5,
//!     name: "Janet".to_string(),
//!     phone: 555_666_7777,
//! };
//! let person2 = Person {
//!     id: 5,
//!     name: "Bob".to_string(),
//!     phone: 555_666_7777,
//! };
//!
//! assert_eq!(calculate_hash(&person1), calculate_hash(&person2));
//!
//! fn calculate_hash<T: Hash>(t: &T) -> u64 {
//!     let mut s = DefaultHasher::new();
//!     t.hash(&mut s);
//!     s.finish()
//! }
//! ```

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::marker;

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use self::sip::SipHasher;

#[unstable(feature = "hashmap_internals", issue = "none")]
#[allow(deprecated)]
#[doc(hidden)]
pub use self::sip::SipHasher13;

mod sip;

/// एक hashable प्रकार।
///
/// `Hash` लागू गर्ने प्रकारहरू [[hash`] [`Hasher`] को एक उदाहरणका साथ सम्पादन गर्न सक्षम छन्।
///
/// ## `Hash` कार्यान्वयन गर्दै
///
/// `#[derive(Hash)]` को साथ `Hash` निकाल्न सक्दछ यदि सबै फिल्डहरू `Hash` लागू गर्दछ।
/// परिणामस्वरूप ह्यास प्रत्येक क्षेत्रमा [`hash`] कल गर्न मानहरूको संयोजन हुनेछ।
///
/// ```
/// #[derive(Hash)]
/// struct Rustacean {
///     name: String,
///     country: String,
/// }
/// ```
///
/// यदि तपाईंलाई कसरी मूल्य ह्याश गर्ने बारेमा थप नियन्त्रण आवश्यक छ भने, तपाईं आफैंले `Hash` trait आफैंमा लागू गर्न सक्नुहुन्छ:
///
/// ```
/// use std::hash::{Hash, Hasher};
///
/// struct Person {
///     id: u32,
///     name: String,
///     phone: u64,
/// }
///
/// impl Hash for Person {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         self.id.hash(state);
///         self.phone.hash(state);
///     }
/// }
/// ```
///
/// ## `Hash` र `Eq`
///
/// दुबै `Hash` र [`Eq`] कार्यान्वयन गर्दा, यो महत्वपूर्ण छ कि निम्न सम्पत्तिले समाहित गर्यो:
///
/// ```text
/// k1 == k2 -> hash(k1) == hash(k2)
/// ```
///
/// अर्को शब्दमा, यदि दुई कुञ्जीहरू बराबर छन्, तिनीहरूको ह्यासहरू पनि बराबर हुनुपर्दछ।
/// [`HashMap`] र [`HashSet`] दुबै यो व्यवहारमा निर्भर गर्दछ।
///
/// धन्यबाद, जब तपाईले [`Eq`] र `Hash` दुबै `#[derive(PartialEq, Eq, Hash)]` लाई निकाल्दा यो सम्पत्तीलाई समाहित गर्ने बारे चिन्ता लिने आवश्यकता पर्दैन।
///
///
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
/// [`HashSet`]: ../../std/collections/struct.HashSet.html
/// [`hash`]: Hash::hash
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Hash {
    /// दिईएको [`Hasher`] मा यो मान फीड गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::{Hash, Hasher};
    ///
    /// let mut hasher = DefaultHasher::new();
    /// 7920.hash(&mut hasher);
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn hash<H: Hasher>(&self, state: &mut H);

    /// दिइएको [`Hasher`] मा यस प्रकारको स्लाइस फिड गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::{Hash, Hasher};
    ///
    /// let mut hasher = DefaultHasher::new();
    /// let numbers = [6, 28, 496, 8128];
    /// Hash::hash_slice(&numbers, &mut hasher);
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "hash_slice", since = "1.3.0")]
    fn hash_slice<H: Hasher>(data: &[Self], state: &mut H)
    where
        Self: Sized,
    {
        for piece in data {
            piece.hash(state);
        }
    }
}

// trait `Hash` बिना preolve बाट म्याक्रो `Hash` पुन: निर्यात गर्न मोड्युल अलग गर्नुहोस्।
pub(crate) mod macros {
    /// trait `Hash` को एक इम्प्ली उत्पन्न डेरिभ म्याक्रो।
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Hash($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Hash;

/// एक trait बाइट्स को एक मनमानी धारा hashes को लागी।
///
/// `Hasher` का उदाहरणहरू प्राय: राज्यलाई प्रतिनिधित्व गर्दछ जुन डाटाको ह्याचिhing गर्दा परिवर्तन हुन्छ।
///
/// `Hasher` उत्पन्न गरिएको ह्यास ([`finish`] सँग) पुनःप्राप्त गर्न, र इन्टेजरहरू लेख्ने साथसाथै बाइट्सको स्लाइसहरू उदाहरणमा ([`write`] र [`write_u8`] आदि सहित) प्रदान गर्नका लागि पर्याप्त आधारभूत इन्टरफेस प्रदान गर्दछ।
/// धेरै जसो समय, `Hasher` उदाहरणहरू [`Hash`] trait को साथ संयोजनको रूपमा प्रयोग गरीन्छ।
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::Hasher;
///
/// let mut hasher = DefaultHasher::new();
///
/// hasher.write_u32(1989);
/// hasher.write_u8(11);
/// hasher.write_u8(9);
/// hasher.write(b"Huh?");
///
/// println!("Hash is {:x}!", hasher.finish());
/// ```
///
/// [`finish`]: Hasher::finish
/// [`write`]: Hasher::write
/// [`write_u8`]: Hasher::write_u8
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Hasher {
    /// अहिले सम्म लेखिएको मानहरूको लागि ह्यास मान फर्काउँछ।
    ///
    /// यसको नामको बावजुद, विधिले ह्यासको आन्तरिक स्थिति रिसेट गर्दैन।
    /// अतिरिक्त [`Writ`] s वर्तमान मानबाट जारी रहनेछ।
    /// यदि तपाईं एक नयाँ ह्यास मान सुरू गर्न आवश्यक छ, तपाईं एक नयाँ हॅशर सिर्जना गर्नुपर्नेछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::Hasher;
    ///
    /// let mut hasher = DefaultHasher::new();
    /// hasher.write(b"Cool!");
    ///
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    ///
    /// [`write`]: Hasher::write
    #[stable(feature = "rust1", since = "1.0.0")]
    fn finish(&self) -> u64;

    /// यस `Hasher` मा केहि डाटा लेख्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::Hasher;
    ///
    /// let mut hasher = DefaultHasher::new();
    /// let data = [0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef];
    ///
    /// hasher.write(&data);
    ///
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write(&mut self, bytes: &[u8]);

    /// यस ह्यासरमा एकल `u8` लेख्छ।
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u8(&mut self, i: u8) {
        self.write(&[i])
    }
    /// यस ह्यासरमा एकल `u16` लेख्छ।
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u16(&mut self, i: u16) {
        self.write(&i.to_ne_bytes())
    }
    /// यस ह्यासरमा एकल `u32` लेख्छ।
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u32(&mut self, i: u32) {
        self.write(&i.to_ne_bytes())
    }
    /// यस ह्यासरमा एकल `u64` लेख्छ।
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u64(&mut self, i: u64) {
        self.write(&i.to_ne_bytes())
    }
    /// यस ह्यासरमा एकल `u128` लेख्छ।
    #[inline]
    #[stable(feature = "i128", since = "1.26.0")]
    fn write_u128(&mut self, i: u128) {
        self.write(&i.to_ne_bytes())
    }
    /// यस ह्यासरमा एकल `usize` लेख्छ।
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_usize(&mut self, i: usize) {
        self.write(&i.to_ne_bytes())
    }

    /// यस ह्यासरमा एकल `i8` लेख्छ।
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i8(&mut self, i: i8) {
        self.write_u8(i as u8)
    }
    /// यस ह्याशरमा एकल `i16` लेख्छ।
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i16(&mut self, i: i16) {
        self.write_u16(i as u16)
    }
    /// यस ह्यासरमा एकल `i32` लेख्छ।
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i32(&mut self, i: i32) {
        self.write_u32(i as u32)
    }
    /// यस ह्यासरमा एकल `i64` लेख्छ।
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i64(&mut self, i: i64) {
        self.write_u64(i as u64)
    }
    /// यस ह्यासरमा एकल `i128` लेख्छ।
    #[inline]
    #[stable(feature = "i128", since = "1.26.0")]
    fn write_i128(&mut self, i: i128) {
        self.write_u128(i as u128)
    }
    /// यस ह्यासरमा एकल `isize` लेख्छ।
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_isize(&mut self, i: isize) {
        self.write_usize(i as usize)
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<H: Hasher + ?Sized> Hasher for &mut H {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

/// एक trait [`Hasher`] का ईन्स्टान्सहरू सिर्जना गर्नका लागि।
///
/// एक `BuildHasher` सामान्यतया प्रयोग गरिन्छ (उदाहरणको लागि, [`HashMap`] द्वारा) प्रत्येक कुञ्जीको लागि [`Hasher`] s सिर्जना गर्नको लागि कि तिनीहरू एक अर्काको स्वतन्त्र रूपमा ह्याश हुन्छन्, किनकि [`Hasher`] को राज्य समावेश गर्दछ।
///
///
/// `BuildHasher` को प्रत्येक उदाहरणको लागि, [0 Hasher`] s [`build_hasher`] द्वारा बनाईएको समान हुनुपर्छ।
/// त्यो हो, यदि बाइट्सको समान स्ट्रिम प्रत्येक ह्यासरमा फेस गरियो भने, उही आउटपुट पनि उत्पन्न हुनेछ।
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::RandomState;
/// use std::hash::{BuildHasher, Hasher};
///
/// let s = RandomState::new();
/// let mut hasher_1 = s.build_hasher();
/// let mut hasher_2 = s.build_hasher();
///
/// hasher_1.write_u32(8128);
/// hasher_2.write_u32(8128);
///
/// assert_eq!(hasher_1.finish(), hasher_2.finish());
/// ```
///
/// [`build_hasher`]: BuildHasher::build_hasher
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
///
#[stable(since = "1.7.0", feature = "build_hasher")]
pub trait BuildHasher {
    /// ह्यासरको प्रकार जुन सिर्जना हुन्छ।
    #[stable(since = "1.7.0", feature = "build_hasher")]
    type Hasher: Hasher;

    /// नयाँ ह्याशर सिर्जना गर्दछ।
    ///
    /// प्रत्येक कल `build_hasher` मा समान उदाहरणमा समान [`Hasher`] s उत्पादन गर्नुपर्दछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::RandomState;
    /// use std::hash::BuildHasher;
    ///
    /// let s = RandomState::new();
    /// let new_s = s.build_hasher();
    /// ```
    #[stable(since = "1.7.0", feature = "build_hasher")]
    fn build_hasher(&self) -> Self::Hasher;
}

/// [`Hasher`] र [`Default`] लागू गर्ने प्रकारहरूको लागि पूर्वनिर्धारित [`BuildHasher`] ईन्स्टान्स सिर्जना गर्न प्रयोग गरियो।
///
/// `BuildHasherDefault<H>` एक प्रकार `H` [`Hasher`] र [`Default`] कार्यान्वयन गर्दा प्रयोग गर्न सकिन्छ, र तपाईंलाई सम्बन्धित [`BuildHasher`] उदाहरण चाहिन्छ, तर कुनै परिभाषित गरिएको छैन।
///
///
/// कुनै `BuildHasherDefault` [zero-sized] हो।यो [`default`][method.default] को साथ सिर्जना गर्न सकिन्छ।
/// [`HashMap`] वा [`HashSet`] को साथ `BuildHasherDefault` प्रयोग गर्दा, यो गर्नु आवश्यक पर्दैन, किनकि उनीहरूले उचित [`Default`] उदाहरणहरू आफैंमा लागू गर्छन्।
///
/// # Examples
///
/// `BuildHasherDefault` प्रयोग गर्दै अनुकूलन [`BuildHasher`] को लागी निर्दिष्ट गर्न
/// [`HashMap`]:
///
/// ```
/// use std::collections::HashMap;
/// use std::hash::{BuildHasherDefault, Hasher};
///
/// #[derive(Default)]
/// struct MyHasher;
///
/// impl Hasher for MyHasher {
///     fn write(&mut self, bytes: &[u8]) {
///         // तपाईंको ह्यासिंग एल्गोरिथ्म यहाँ जान्छ!
///        unimplemented!()
///     }
///
///     fn finish(&self) -> u64 {
///         // तपाईंको ह्यासिंग एल्गोरिथ्म यहाँ जान्छ!
///         unimplemented!()
///     }
/// }
///
/// type MyBuildHasher = BuildHasherDefault<MyHasher>;
///
/// let hash_map = HashMap::<u32, u32, MyBuildHasher>::default();
/// ```
///
/// [method.default]: BuildHasherDefault::default
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
/// [`HashSet`]: ../../std/collections/struct.HashSet.html
/// [zero-sized]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#zero-sized-types-zsts
///
///
///
///
#[stable(since = "1.7.0", feature = "build_hasher")]
pub struct BuildHasherDefault<H>(marker::PhantomData<H>);

#[stable(since = "1.9.0", feature = "core_impl_debug")]
impl<H> fmt::Debug for BuildHasherDefault<H> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("BuildHasherDefault")
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H: Default + Hasher> BuildHasher for BuildHasherDefault<H> {
    type Hasher = H;

    fn build_hasher(&self) -> H {
        H::default()
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H> Clone for BuildHasherDefault<H> {
    fn clone(&self) -> BuildHasherDefault<H> {
        BuildHasherDefault(marker::PhantomData)
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H> Default for BuildHasherDefault<H> {
    fn default() -> BuildHasherDefault<H> {
        BuildHasherDefault(marker::PhantomData)
    }
}

#[stable(since = "1.29.0", feature = "build_hasher_eq")]
impl<H> PartialEq for BuildHasherDefault<H> {
    fn eq(&self, _other: &BuildHasherDefault<H>) -> bool {
        true
    }
}

#[stable(since = "1.29.0", feature = "build_hasher_eq")]
impl<H> Eq for BuildHasherDefault<H> {}

mod impls {
    use crate::mem;
    use crate::slice;

    use super::*;

    macro_rules! impl_write {
        ($(($ty:ident, $meth:ident),)*) => {$(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Hash for $ty {
                #[inline]
                fn hash<H: Hasher>(&self, state: &mut H) {
                    state.$meth(*self)
                }

                #[inline]
                fn hash_slice<H: Hasher>(data: &[$ty], state: &mut H) {
                    let newlen = data.len() * mem::size_of::<$ty>();
                    let ptr = data.as_ptr() as *const u8;
                    // सुरक्षा: `ptr` मान्य र पigned्क्तिबद्ध गरिएको छ, किनकि यो म्याक्रो मात्र प्रयोग गरीन्छ
                    // संख्यात्मक आदिमहरूको लागि जुनसँग प्याडि। छैन।
                    // नयाँ स्लाइस `data` मा मात्र फ्याँकिएको छ र कहिल्यै बदलिएको छैन, र यसको कुल आकार मूल `data` जस्तै छ त्यसैले यो `isize::MAX` भन्दा माथि हुन सक्दैन।
                    //
                    state.write(unsafe { slice::from_raw_parts(ptr, newlen) })
                }
            }
        )*}
    }

    impl_write! {
        (u8, write_u8),
        (u16, write_u16),
        (u32, write_u32),
        (u64, write_u64),
        (usize, write_usize),
        (i8, write_i8),
        (i16, write_i16),
        (i32, write_i32),
        (i64, write_i64),
        (isize, write_isize),
        (u128, write_u128),
        (i128, write_i128),
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for bool {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write_u8(*self as u8)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for char {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write_u32(*self as u32)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for str {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write(self.as_bytes());
            state.write_u8(0xff)
        }
    }

    #[stable(feature = "never_hash", since = "1.29.0")]
    impl Hash for ! {
        #[inline]
        fn hash<H: Hasher>(&self, _: &mut H) {
            *self
        }
    }

    macro_rules! impl_hash_tuple {
        () => (
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Hash for () {
                #[inline]
                fn hash<H: Hasher>(&self, _state: &mut H) {}
            }
        );

        ( $($name:ident)+) => (
            #[stable(feature = "rust1", since = "1.0.0")]
            impl<$($name: Hash),+> Hash for ($($name,)+) where last_type!($($name,)+): ?Sized {
                #[allow(non_snake_case)]
                #[inline]
                fn hash<S: Hasher>(&self, state: &mut S) {
                    let ($(ref $name,)+) = *self;
                    $($name.hash(state);)+
                }
            }
        );
    }

    macro_rules! last_type {
        ($a:ident,) => { $a };
        ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
    }

    impl_hash_tuple! {}
    impl_hash_tuple! { A }
    impl_hash_tuple! { A B }
    impl_hash_tuple! { A B C }
    impl_hash_tuple! { A B C D }
    impl_hash_tuple! { A B C D E }
    impl_hash_tuple! { A B C D E F }
    impl_hash_tuple! { A B C D E F G }
    impl_hash_tuple! { A B C D E F G H }
    impl_hash_tuple! { A B C D E F G H I }
    impl_hash_tuple! { A B C D E F G H I J }
    impl_hash_tuple! { A B C D E F G H I J K }
    impl_hash_tuple! { A B C D E F G H I J K L }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: Hash> Hash for [T] {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            self.len().hash(state);
            Hash::hash_slice(self, state)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized + Hash> Hash for &T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            (**self).hash(state);
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized + Hash> Hash for &mut T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            (**self).hash(state);
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Hash for *const T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            #[cfg(not(bootstrap))]
            {
                let (address, metadata) = self.to_raw_parts();
                state.write_usize(address as usize);
                metadata.hash(state);
            }
            #[cfg(bootstrap)]
            {
                if mem::size_of::<Self>() == mem::size_of::<usize>() {
                    // पातलो सूचक
                    state.write_usize(*self as *const () as usize);
                } else {
                    // फ्याट पोइन्टर सुरक्षा: हामी `self` मा कब्जा गरिएको मेमोरीमा पहुँच गर्दैछौं जुन मान्य हुन ग्यारेन्टी गरिएको छ।
                    // यो मानिन्छ एक फ्याट सूचक एक `(usize, usize)`, जो `std` मा सुरक्षित गर्न को लागी प्रतिनिधित्व गर्न सकिन्छ किनभने यो पठाइयो र `rustc` मा फ्याट सूचक को कार्यान्वयनको साथ सिंक मा राखिएको छ।
                    //
                    //
                    //
                    //
                    let (a, b) = unsafe { *(self as *const Self as *const (usize, usize)) };
                    state.write_usize(a);
                    state.write_usize(b);
                }
            }
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Hash for *mut T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            #[cfg(not(bootstrap))]
            {
                let (address, metadata) = self.to_raw_parts();
                state.write_usize(address as usize);
                metadata.hash(state);
            }
            #[cfg(bootstrap)]
            {
                if mem::size_of::<Self>() == mem::size_of::<usize>() {
                    // पातलो सूचक
                    state.write_usize(*self as *const () as usize);
                } else {
                    // फ्याट पोइन्टर सुरक्षा: हामी `self` मा कब्जा गरिएको मेमोरीमा पहुँच गर्दैछौं जुन मान्य हुन ग्यारेन्टी गरिएको छ।
                    // यो मानिन्छ एक फ्याट सूचक एक `(usize, usize)`, जो `std` मा सुरक्षित गर्न को लागी प्रतिनिधित्व गर्न सकिन्छ किनभने यो पठाइयो र `rustc` मा फ्याट सूचक को कार्यान्वयनको साथ सिंक मा राखिएको छ।
                    //
                    //
                    //
                    //
                    let (a, b) = unsafe { *(self as *const Self as *const (usize, usize)) };
                    state.write_usize(a);
                    state.write_usize(b);
                }
            }
        }
    }
}