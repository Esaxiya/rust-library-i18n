#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! उपयोगिताहरू विदेशी प्रकार्य ईन्टरफेस (FFI) बाइन्डि toसँग सम्बन्धित।

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// X को `void` प्रकारको बराबरी जब [pointer] को रूपमा प्रयोग गरियो।
///
/// संक्षेपमा, `*const c_void` C को `const void*` बराबर हो र `*mut c_void` C को `void*` बराबर हो।
/// त्योले भन्यो, यो * सीको `void` रिटर्न प्रकार जस्तै होईन, जुन Rust को `()` प्रकार हो।
///
/// FFI मा अपारदर्शी प्रकारहरूमा सूचकहरू मोडेल गर्न, `extern type` स्थिर नभएसम्म, यसलाई खाली बाइट एर्रे वरिपरि newtype रैपर प्रयोग गर्न सिफारिस गरिन्छ।
///
/// विवरणका लागि [Nomicon] हेर्नुहोस्।
///
/// एकले `std::os::raw::c_void` प्रयोग गर्न सक्दछ यदि तिनीहरू 1.1.0 सम्म तल पुरानो Rust कम्पाइलर समर्थन गर्न चाहन्छन्।
/// Rust 1.30.0 पछि, यो परिभाषा द्वारा यसलाई पुन: निर्यात गरिएको थियो।
/// अधिक जानकारीको लागि, कृपया [RFC 2521] पढ्नुहोस्।
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, LLVM लाई शून्य सूचक प्रकार पहिचान गर्न र malloc() जस्ता विस्तार प्रकार्यहरू द्वारा, हामीले यसलाई LLVM बिटकोडमा i8 * को रूपमा प्रतिनिधित्व गर्नु पर्छ।
// यहाँ प्रयोग भएको एनमले यो सुनिश्चित गर्दछ र निजी भेरियन्टहरू मात्र भएको "raw" प्रकारको दुरुपयोग रोक्दछ।
// हामीलाई दुई वेरिएन्टहरू चाहिन्छ किनभने कम्पाइलरले repr एट्रिब्युटको बारेमा गुनासो गरेको छ र हामीलाई कम्तिमा एउटा संस्करण चाहिन्छ अन्यथा एनम निर्जन हुनेछ र कम्तिमा यस्ता पोइन्टर्सलाई डिरेफरिंग युबी हुनेछ।
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// `va_list` को आधारभुत कार्यान्वयन।
// नाम WIP हो, अहिलेको लागि `VaListImpl` प्रयोग गर्दै।
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // `'f` मा इन्भेरिएन्ट, त्यसैले प्रत्येक `VaListImpl<'f>` वस्तु यो परिभाषित गरिएको प्रकारको क्षेत्रमा बाधिएको छ
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 ABI `va_list` को कार्यान्वयन।
/// अधिक जानकारीको लागि [AArch64 Procedure Call Standard] हेर्नुहोस्।
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC ABI `va_list` को कार्यान्वयन।
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 ABI `va_list` को कार्यान्वयन।
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// `va_list` का लागि आवरण
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// `VaListImpl` लाई `VaList` मा रूपान्तरण गर्नुहोस् जुन बाइनरी-अनुकूल सीको `va_list` सँग छ।
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// `VaListImpl` लाई `VaList` मा रूपान्तरण गर्नुहोस् जुन बाइनरी-अनुकूल सीको `va_list` सँग छ।
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait लाई सार्वजनिक इन्टरफेसमा प्रयोग गर्न आवश्यक पर्दछ, जेडट्राइट ० Z आफैंलाई यो मोड्युल बाहिर प्रयोग गर्न मिल्दैन।
// प्रयोगकर्ताहरूलाई नयाँ प्रकारको लागि trait लागू गर्न अनुमति दिदै (यसले va_arg ईन्टर्न्सिकलाई नयाँ प्रकारमा प्रयोग गर्न अनुमति दिदै) अपरिभाषित व्यवहार हुन सक्ने सम्भावना छ।
//
// FIXME(dlrobertson): एक सार्वजनिक इन्टरफेसमा VaArgSafe trait को उपयोग गर्न को लागी तर यसलाई अन्यत्र प्रयोग गर्न सकिदैन भनेर निश्चित गर्न, trait निजी मोड्युल भित्र सार्वजनिक हुनु आवश्यक छ।
// एक पटक आरएफसी २१4545 लागू गरिसकेपछि यसलाई सुधार गर्ने दृष्टिकोण राख्नुहोस्।
//
//
//
//
mod sealed_trait {
    /// Trait जसले अनुमति दिएका प्रकारहरूलाई [super::VaListImpl::arg] को साथ प्रयोग गर्न अनुमति दिन्छ।
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// अर्को आर्गमा अग्रिम।
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // सुरक्षा: कलरले `va_arg` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ।
        unsafe { va_arg(self) }
    }

    /// हालको स्थानमा `va_list` प्रतिलिपि गर्दछ।
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // सुरक्षा: कलरले `va_end` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ।
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // सुरक्षा: हामी `MaybeUninit` मा लेख्छौं, यसैले यो आरम्भ भयो र `assume_init` कानूनी हो
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: यसले `va_end` लाई कल गर्नुपर्दछ, तर त्यहाँ कुनै सफा तरीका छैन
        // ग्यारेन्टी गर्नुहोस् कि `drop` सँधै यसको कलरमा इनलिन्ड हुन्छ, त्यसैले `va_end` सीधा सम्बन्धित `va_copy` को समान कार्यबाट बोलाइन्छ।
        // `man va_end` भन्छन कि C लाई यसको आवश्यक पर्दछ, र LLVM मूलत: C शब्दार्थ पछ्याउँदछ, त्यसैले हामीले `va_end` जहिले पनि `va_copy` को समान कार्यबाट बोलाइएको पक्का गर्नु पर्छ।
        //
        // अधिक जानकारी को लागी, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // यो अहिलेका लागि काम गर्दछ, किनकि `va_end` सबै वर्तमान LLVM लक्ष्यहरूमा एक अप-ऑप हो।
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// `va_start` वा `va_copy` को साथ आरम्भ पछि arglist `ap` नष्ट गर्नुहोस्।
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Arglist `src` को वर्तमान स्थानको प्रतिलिपि बनाउँदछ `dst`।
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// `va_list` `ap` बाट `T` प्रकारको आर्गुमेन्ट लोड गर्दछ र तर्क `ap` पोइन्टमा वृद्धि गर्दछ।
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}