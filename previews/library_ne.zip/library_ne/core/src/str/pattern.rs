//! स्ट्रिंग पैटर्न API।
//!
//! पैटर्न एपीआई एक स्ट्रिंग के माध्यम से खोज करते समय अलग ढाँचा प्रकारहरु को लागी जेनेरिक संयन्त्र प्रदान गर्दछ।
//!
//! थप विवरणहरूको लागि, traits [`Pattern`], [`Searcher`], [`ReverseSearcher`], र [`DoubleEndedSearcher`] हेर्नुहोस्।
//!
//! यद्यपि यो एपीआई अस्थिर छ, यो [`str`] प्रकारमा स्थिर एपीआई मार्फत खुलासा गरिएको छ।
//!
//! # Examples
//!
//! [`Pattern`] [`&str`][`str`], [`char`], [`char`] को स्लाइस, र `FnMut(char) -> bool` कार्यान्वयन गर्ने प्रकार्य र क्लोजरको लागि स्थिर एपीआईमा [implemented][pattern-impls] हो।
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // चार बान्की
//! assert_eq!(s.find('n'), Some(2));
//! // चारस बान्कीको स्लाइस
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // बन्द गर्ने बान्की
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// एक स्ट्रिंग ढाँचा।
///
/// एक `Pattern<'a>` अभिव्यक्त गर्दछ कि कार्यान्वयन प्रकार [`&'a str`][str] मा खोजको लागि एक स्ट्रिंग ढाँचाको रूपमा प्रयोग गर्न सकिन्छ।
///
/// उदाहरण को लागी, दुबै `'a'` र `"aa"` स्ट्रिंग `"baaaab"` मा अनुक्रमणिका `1` मा मिल्छ कि पैटर्न हो।
///
/// trait आफैंमा सम्बन्धित [`Searcher`] प्रकारको लागि बिल्डरको रूपमा कार्य गर्दछ, जसले स्ट्रि inमा बान्कीका घटनाहरू फेला पार्न वास्तविक कार्य गर्दछ।
///
///
/// ढाँचाको प्रकारमा निर्भर गर्दै, [`str::find`] र [`str::contains`] जस्ता विधिहरूको व्यवहार परिवर्तन गर्न सक्दछ।
/// तलको तालिकाले ती व्यवहारहरूको वर्णन गर्दछ।
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// यस बान्कीका लागि सम्बद्ध खोजकर्ता
    type Searcher: Searcher<'a>;

    /// खोजी गर्न `self` र `haystack` बाट सम्बन्धित खोजीलाई निर्माण गर्दछ।
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// घाँसपट्टीको कुनै पनि ठाउँमा प्याटर्न मिल्छ कि गर्दैन भनेर जाँच गर्दछ
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// घाँस ह्याकको अगाडि प्याटर्न मेल खाँदछ कि भनेर जाँच गर्दछ
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// घाँस ह्याकको पछाडि प्याटर्न मेल खान्छ कि भनेर जाँच गर्दछ
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// घाँसपट्टीको अगाडिबाट प्याटर्न हटाउँदछ, यदि यो मिल्दछ भने।
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // सुरक्षा: `Searcher` वैध सूचकांक फिर्ता गर्न जानिन्छ।
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// घाँसपट्टीको पछाडिबाट ढाँचा हटाउँदछ, यदि यो मेल खायो भने।
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // सुरक्षा: `Searcher` वैध सूचकांक फिर्ता गर्न जानिन्छ।
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// [`Searcher::next()`] वा [`ReverseSearcher::next_back()`] कल गर्ने नतिजा।
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// व्यक्त गर्दछ कि बान्कीको एक खेल `haystack[a..b]` मा फेला परेको छ।
    ///
    Match(usize, usize),
    /// व्यक्त गर्दछ कि `haystack[a..b]` प्याटर्नको सम्भावित मिलानको रूपमा अस्वीकार गरिएको छ।
    ///
    /// नोट गर्नुहोस् कि दुई `Match`es को बीचमा एक `Reject` भन्दा बढि हुन सक्छ, तिनीहरूलाई एकमा मिलाउन आवश्यक छैन।
    ///
    ///
    Reject(usize, usize),
    /// अभिव्यक्त गर्दछ कि घासको प्रत्येक बाइट भ्रमण गरिएको छ, पुनरावृत्ति समाप्त गरेर।
    ///
    Done,
}

/// स्ट्रि pattern बान्कीका लागि खोजीकर्ता।
///
/// यस trait ले स्ट्रिंगको अगाडि (left) बाट सुरू गरेर ढाँचाको गैर-ओभरल्यापिpping खेलहरूका लागि खोजी गर्न विधिहरू प्रदान गर्दछ।
///
/// यो [`Pattern`] trait को सम्बन्धित `Searcher` प्रकारहरू द्वारा कार्यान्वयन हुनेछ।
///
/// trait असुरक्षितको रूपमा चिनो लगाइएको छ किनकी [`next()`][Searcher::next] विधिहरू द्वारा फर्काइएका सूचकाँहरू हाईस्टेकमा मान्य utf8 सीमाहरूमा झूठो हुनु आवश्यक छ।
/// यसले यस trait का उपभोक्ताहरूलाई अतिरिक्त रनटाइम जाँच बिना नै घासको टुक्रा काट्न सक्षम गर्दछ।
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// अन्तर्निहित स्ट्रिंगको लागि खोजी गर्न Getter
    ///
    /// सँधै समान [`&str`][str] फर्काउँछ।
    fn haystack(&self) -> &'a str;

    /// अगाडिबाट सुरू गरेर अर्को खोज चरण कार्य गर्दछ।
    ///
    /// - [`Match(a, b)`][SearchStep::Match] फर्काउँछ यदि `haystack[a..b]` बान्कीसँग मेल खान्छ।
    /// - [`Reject(a, b)`][SearchStep::Reject] फिर्ता गर्दछ यदि `haystack[a..b]` ढाँचासँग मेल गर्न सक्दैन, आंशिक रूपमा।
    /// - XyX फिर्ता गर्दछ यदि घासको प्रत्येक बाइट भ्रमण गरिएको छ।
    ///
    /// [`Match`][SearchStep::Match] र [`Reject`][SearchStep::Reject] मानको [`Done`][SearchStep::Done] सम्मको स्ट्रिममा सूचकांक दायरा पर्दछ जुन नजिकै, गैर-ओभरल्यापि,, पूरै घासको कभरलाई कभर गरेर, र utf8 सीमानाहरूमा बिछ्याउने छ।
    ///
    ///
    /// एक [`Match`][SearchStep::Match] परिणाममा सम्पूर्ण मिलान बान्की समावेश गर्न आवश्यक छ, जबकि [`Reject`][SearchStep::Reject] नतीजा मनमानी धेरै आसन्नको टुक्राहरूमा विभाजित हुन सक्छ।दुबै दायराहरूको शून्य लम्बाइ हुन सक्छ।
    ///
    /// एक उदाहरणको रूपमा, ढाँचा `"aaa"` र haystack `"cbaaaaab"` स्ट्रिम उत्पादन गर्न सक्दछ
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// अर्को [`Match`][SearchStep::Match] परिणाम फेला पार्दछ।[`next()`][Searcher::next] हेर्नुहोस्।
    ///
    /// [`next()`][Searcher::next] विपरीत, त्यहाँ कुनै ग्यारेन्टी छैन कि यस र [`next_reject`][Searcher::next_reject] को फिर्ता दायरा अधिव्यापन हुनेछ।
    /// यो `(start_match, end_match)` फर्कने छ, जहाँ start_match अनुक्रमणिका हो जहाँ खेल सुरु हुन्छ, र end_match अनुक्रमणिका हो मैचको अन्त्य पछि।
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// अर्को [`Reject`][SearchStep::Reject] परिणाम फेला पार्दछ।[`next()`][Searcher::next] र [`next_match()`][Searcher::next_match] हेर्नुहोस्।
    ///
    /// [`next()`][Searcher::next] विपरीत, त्यहाँ कुनै ग्यारेन्टी छैन कि यस र [`next_match`][Searcher::next_match] को फिर्ता दायरा अधिव्यापन हुनेछ।
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// एक स्ट्रिंग ढाँचा को लागी एक रिभर्स खोजकर्ता।
///
/// यस trait ले स्ट्रिंगको पछाडि (right) बाट सुरू गरीएको ढाँचाको गैर-ओभरल्यापि matches खेलहरूका लागि खोजी गर्न विधिहरू प्रदान गर्दछ।
///
/// यो [`Pattern`] trait सम्बन्धित [`Searcher`] प्रकारहरू द्वारा लागू गरिएको हो यदि ढाँचा पछाडिबाट यसलाई खोजी समर्थन गर्दछ।
///
///
/// यस trait द्वारा फर्काइएको अनुक्रमणिका दायरा उल्टो फर्वार्ड खोजको ठीकसँग मेल गर्न आवश्यक पर्दैन।
///
/// यो trait असुरक्षित चिन्ह लगाइएको कारणका लागि, तिनीहरूलाई अभिभावक trait [`Searcher`] हेर्नुहोस्।
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// पछिल्लो खोज चरण पछाडिबाट सुरू गर्दछ।
    ///
    /// - [`Match(a, b)`][SearchStep::Match] फिर्ता गर्दछ यदि `haystack[a..b]` बान्कीसँग मेल खान्छ।
    /// - [`Reject(a, b)`][SearchStep::Reject] फिर्ता गर्दछ यदि `haystack[a..b]` ढाँचासँग मेल गर्न सक्दैन, आंशिक रूपमा।
    /// - XyX फिर्ता गर्दछ यदि घासको प्रत्येक बाइट भ्रमण गरिएको छ
    ///
    /// [`Match`][SearchStep::Match] र [`Reject`][SearchStep::Reject] मानको [`Done`][SearchStep::Done] सम्मको स्ट्रिममा सूचकांक दायरा पर्दछ जुन नजिकै, गैर-ओभरल्यापि,, पूरै घासको कभरलाई कभर गरेर, र utf8 सीमानाहरूमा बिछ्याउने छ।
    ///
    ///
    /// एक [`Match`][SearchStep::Match] परिणाममा सम्पूर्ण मिलान बान्की समावेश गर्न आवश्यक छ, जबकि [`Reject`][SearchStep::Reject] नतीजा मनमानी धेरै आसन्नको टुक्राहरूमा विभाजित हुन सक्छ।दुबै दायराहरूको शून्य लम्बाइ हुन सक्छ।
    ///
    /// एक उदाहरणको रूपमा, ढाँचा `"aaa"` र हेयस्टेक `"cbaaaaab"` ले स्ट्रिम `[Reject(7, 8), Match(4, 7), Reject(1, 4), उत्पादन गर्न सक्दछ। Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// अर्को [`Match`][SearchStep::Match] परिणाम फेला पार्दछ।
    /// [`next_back()`][ReverseSearcher::next_back] हेर्नुहोस्।
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// अर्को [`Reject`][SearchStep::Reject] परिणाम फेला पार्दछ।
    /// [`next_back()`][ReverseSearcher::next_back] हेर्नुहोस्।
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// मार्कर trait व्यक्त गर्न कि [`ReverseSearcher`] [`DoubleEndedIterator`] कार्यान्वयनको लागि प्रयोग गर्न सकिन्छ।
///
/// यसको लागि, [`Searcher`] र [`ReverseSearcher`] को इम्प्लीले यी सर्तहरू पालना गर्नु पर्छ:
///
/// - `next()` का सबै परिणामहरू उल्टो क्रममा `next_back()` का नतीजाहरूको समान हुन आवश्यक छ।
/// - `next()` र `next_back()` लाई मानको दायराको दुई छेउको रूपमा व्यवहार गर्न आवश्यक छ, त्यो हो कि तिनीहरू "walk past each other" सक्दैनन्।
///
/// # Examples
///
/// `char::Searcher` एक `DoubleEndedSearcher` हो किनकि [`char`] को लागी खोजी गर्न एक पटकमा एक मात्र चाहिन्छ, जुन दुबै छेउबाट समान व्यवहार गर्दछ।
///
/// `(&str)::Searcher` एक `DoubleEndedSearcher` हैन किनकि घाँसपट्टी `"aa"` मा ढाँचा `"aaa"` या त `"[aa]a"` वा `"a[aa]"` को रूप मा मेल खान्छ, कुन पक्ष बाट खोजिएको छ निर्भर गर्दै।
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// चारको लागि इम्प्ली
/////////////////////////////////////////////////////////////////////////////

/// `<char as Pattern<'a>>::Searcher` को लागि सम्बन्धित प्रकार।
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // सुरक्षा इन्वेरियन्ट: `finger`/`finger_back` `haystack` को मान्य utf8 बाइट सूचकांक हुनुपर्दछ। यो इन्भेर्नेट तोड्न सकिन्छ * * Next_match र Next_match_back भित्र, यद्यपि तिनीहरू मान्य कोड पोउन्ट सीमाहरूमा औंलाहरूसँग बाहिर निस्कनु पर्छ।
    //
    //
    /// `finger` अगाडि खोज को वर्तमान बाइट सूचकांक हो।
    /// कल्पना गर्नुहोस् कि यो बाइट भन्दा पहिले यसको अनुक्रमणिकामा अवस्थित छ
    /// `haystack[finger]` अगाडी खोजीको क्रममा हामीले निरीक्षण गर्नु पर्ने स्लाइसको पहिलो बाइट हो
    ///
    finger: usize,
    /// `finger_back` उल्टो खोजको वर्तमान बाइट अनुक्रमणिका हो।
    /// कल्पना गर्नुहोस् कि यो बाइट पछि यसको अनुक्रमणिकामा अवस्थित छ, जस्तै
    /// हाईस्टेक [फिंगरब्याक, १] स्लाइसको अन्तिम बाइट हो जुन हामीले अगाडि खोजीको क्रममा निरीक्षण गर्नुपर्दछ (र यसरी एक्स बाई एक्स एक्स ० एक्स कल गर्दा निरीक्षण गर्न सकिन्छ।
    ///
    finger_back: usize,
    /// चरित्र खोजी भइरहेको छ
    needle: char,

    // सुरक्षा इन्वेरियन्ट: `utf8_size` 5 भन्दा कम हुनुपर्दछ
    /// utf8 X मा ईन्कोड गरिएको बेला `needle` बाइट्सको संख्या लिन्छ।
    utf8_size: usize,
    /// एक utf8 `needle` को एन्कोड गरिएको प्रतिलिपि
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // सुरक्षा: १--4 `get_unchecked` को ग्यारेन्टी सुरक्षा
        // 1. `self.finger` र `self.finger_back` युनिकोड सीमामा राखिएको छ (यो इन्भेरियन्ट हो)
        // 2. `self.finger >= 0` किनकि यो ० मा सुरू हुन्छ र मात्र बढ्छ
        // 3. `self.finger < self.finger_back` किनभने अन्यथा चार्ट `iter` `SearchStep::Done` फिर्ता हुनेछ
        // 4.
        // `self.finger` परागकणको अन्त्य हुन अघि आउँदछ किनभने `self.finger_back` अन्त्यमा सुरू हुन्छ र मात्र घट्छ
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // utf-8 को रूपमा पुन: ईन्कोडिंग बिना वर्तमान चरित्रको बाइट अफसेट थप्नुहोस्
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // अन्तिम चरित्र फेला परे पछि हाईस्टेक पाउनुहोस्
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // utf8 एन्कोड गरिएको सुई सुरक्षाको अन्तिम बाइट: हामीसँग एक इन्भेर्नेट छ कि `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // नयाँ औंलाले हामीले फेला पारेको बाइटको अनुक्रमणिका हो, प्लस वन, किनकि हामी क्यारेक्टरको अन्तिम बाइटको लागि मेम्चर थियौं।
                //
                // नोट गर्नुहोस् कि यसले सँधै UTF8 सीमामा हामीलाई औँला दिदैन।
                // यदि हामीले *हाम्रो चरित्र* फेला पारेनौं भने हामीले--बाइट वा-बाइट क्यारेक्टरको गैर-अन्तिम बाइटमा अनुक्रमणिका गर्न सक्दछौं।
                // हामी केवल अर्को वैध सुरूवात बाइटमा छोड्न सक्दैनौं किनकि character (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` जस्तो एक चरित्रले हामीलाई सँधै दोस्रो बाइट फेला पार्छ जब तेस्रोको लागि खोजी गर्दछ।
                //
                //
                // यद्यपि यो पूर्ण रूपमा ठीक छ।
                // जबकि हामीसँग एक्सरियन्ट छ कि self.finger UTF8 सीमा मा छ, यो इन्गरिएन्ट यस विधि भित्र भर पर्दैन (यो CharSearcher::next()) मा निर्भर छ।
                //
                // हामी केवल यो विधि बाहिर जान्छौं जब हामी स्ट्रिंगको अन्त्यमा पुग्छौं, वा यदि हामी केहि फेला पार्दछौं।जब हामी केहि खोज्छौं `finger` UTF8 सीमा मा सेट हुनेछ।
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // केहि भेटिएन, बाहिर निस्कनुहोस्
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // अर्को_रेजेक्टरले खोजकर्ता trait बाट पूर्वनिर्धारित कार्यान्वयनको उपयोग गरौं
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // सुरक्षा: माथिको next() को लागी टिप्पणी हेर्नुहोस्
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // utf-8 को रूपमा पुन: ईन्कोडिंग बिना वर्तमान चरित्रको बाइट अफसेट घटाउनुहोस्
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // परागकण सम्म पाउनुहोस् तर खोजी गरिएको अन्तिम क्यारेक्टर समावेश गरीएको छैन
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // utf8 एन्कोड गरिएको सुई सुरक्षाको अन्तिम बाइट: हामीसँग एक इन्भेर्नेट छ कि `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // हामीले एउटा स्लाइस खोज्यौं जुन self.finger द्वारा अफसेट गरिएको थियो, self.finger थप्नुहोस् मूल सूचकांक पुनः प्राप्त गर्न
                //
                let index = self.finger + index;
                // मेम्चररले हामी खोज्न चाहेको बाइटको अनुक्रमणिका फर्काउँछ।
                // एक ASCII चरित्र को मामला मा, यो वास्तव मा हामी हाम्रो नयाँ औंला हुन चाहाथ्यो ("after" उल्टो पुनरावृत्ति को प्रतिमान मा फेला परेको चार्ट)।
                //
                // मल्टीबाइट चरहरूको लागि हामीले ASCII भन्दा बढि बाइट्सको संख्याबाट तल जानुपर्दछ
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // क्यारेक्टर फेला पर्नु भन्दा पहिले औंला सार्नुहोस् (उदाहरणको लागि, यसको सुरू अनुक्रमणिकामा)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // हामी फिंगरब्याक=अनुक्रमणिका, आकार + १ यहाँ प्रयोग गर्न सक्दैनौं।
                // यदि हामीले बिभिन्न आकारको क्यारेक्टरको अन्तिम चार्ट भेट्टायौं (वा बिभिन्न क्यारेक्टरको बीच बाइट) हामीले फिंगरब्याकलाई `index` तल बम्प गर्नु पर्छ।
                // यसले समान रूपमा बनाउँछ `finger_back` अब सीमामा रहनको क्षमता छैन, तर यो ठीक छ किनकि हामी मात्र यो प्रकार्य बाउन्ड्रीमा बाहिर निस्कन्छौं वा जब घासदाँट पूर्ण रूपमा खोजी गरिएको थियो।
                //
                //
                // Next_match भन्दा फरक यो utf-8 मा दोहोरिएको बाइट्स को समस्या छैन किनकि हामी अन्तिम बाइट खोज्दै छौं, र हामी मात्र पछिल्लो बाइट फेला पार्न सक्छौं उल्टो खोजी गर्दा।
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // केहि भेटिएन, बाहिर निस्कनुहोस्
                return None;
            }
        }
    }

    // अर्को_रेजेक्ट_ब्याकलाई खोजकर्ता trait बाट पूर्वनिर्धारित कार्यान्वयनको उपयोग गरौं
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// वर्णहरूको लागि खोजी जुन दिइएको [`char`] सँग बराबर छ।
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// मल्टिचार्इक र्यापरको लागि इम्प्ली गर्नुहोस्
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // हालको चारको लम्बाइ पत्ता लगाउन आन्तरिक बाइट स्लाइस इटरेटरको लम्बाइ तुलना गर्नुहोस्
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // हालको चारको लम्बाइ पत्ता लगाउन आन्तरिक बाइट स्लाइस इटरेटरको लम्बाइ तुलना गर्नुहोस्
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// &[चार] को लागी लागू गर्नुहोस्
/////////////////////////////////////////////////////////////////////////////

// Todo: अर्थमा अस्पष्टताका कारण परिवर्तन गर्नुहोस्/हटाउनुहोस्।

/// `<&[char] as Pattern<'a>>::Searcher` को लागि सम्बन्धित प्रकार।
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// चरहरूका लागि खोजी गर्दछ जुन स्लाईसमा [`char`] s को बराबर छ।
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// एफ: FnMut(char)-> bool को लागी लागू गर्नुहोस्
/////////////////////////////////////////////////////////////////////////////

/// `<F as Pattern<'a>>::Searcher` को लागि सम्बन्धित प्रकार।
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// [`Char`] को लागि खोजीहरू जुन दिइएको पूर्वानुमानसँग मेल खान्छ।
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// &&str को लागी लागू गर्नुहोस्
/////////////////////////////////////////////////////////////////////////////

/// `&str` impl का प्रतिनिधिहरू।
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// &str को लागी लुगा लगाउनुहोस्
/////////////////////////////////////////////////////////////////////////////

/// गैर-विनियोजन सब्स्ट्रिंग खोज।
///
/// `""` ढाँचा ह्यान्डल गर्दछ प्रत्येक अक्षर सीमानामा खाली मिलानहरू फर्काउँदा।
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// घाँस ह्याकको अगाडि प्याटर्न मेल खाँदछ कि भनेर जाँच गर्दछ।
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// घाँसपट्टीको अगाडिबाट प्याटर्न हटाउँदछ, यदि यो मिल्दछ भने।
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // सुरक्षा: उपसर्ग भर्खरै अवस्थित रहेको प्रमाणित गरिएको थियो।
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// घाँस ह्याकको पछाडि ढाँचा मिल्दछ कि भनेर जाँच गर्दछ।
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// घाँसपट्टीको पछाडिबाट ढाँचा हटाउँदछ, यदि यो मेल खायो भने।
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // सुरक्षा: प्रत्यय अवस्थित रहेको मात्र प्रमाणित गरिएको थियो।
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// दुई मार्ग सब्स्ट्रिंग खोजी
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// `<&str as Pattern<'a>>::Searcher` को लागि सम्बन्धित प्रकार।
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // खाली सुईले प्रत्येक चार्ट अस्वीकार गर्दछ र उनीहरू बीचको हरेक खाली स्ट्रि matchesसँग मेल खान्छ
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher वैध *मिलान* सूचकहरू उत्पादन गर्दछ जुन चार सीमानाहरूमा विभाजित हुन्छ जबसम्म यो सही मिलान गर्दछ र कि हेस्याटेक र सुई मान्य UTF-8 *अस्वीकार* एल्गोरिथ्मबाट कुनै पनि सूचकहरूमा पर्न सक्छ, तर हामी त्यसलाई म्यानुअल रूपमा अर्को चरित्र सीमामा जान्छौं।, त्यसोभए तिनीहरू utf-8 सुरक्षित छन्।
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // अर्को चार सीमानामा स्किप गर्नुहोस्
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // `true` र `false` केसहरू लेख्नुहोस् र कम्पाइलरलाई दुई केसहरू अलग छुट्याउन प्रोत्साहित गर्न।
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // अर्को चार सीमानामा स्किप गर्नुहोस्
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // `true` र `false`, `next_match` जस्तै लेख्नुहोस्
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// दुई-मार्ग सबस्ट्रिंग खोज एल्गोरिथ्मको आन्तरिक अवस्था।
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// महत्वपूर्ण कारक अनुक्रमणिका
    crit_pos: usize,
    /// उल्टो सुईको लागि महत्वपूर्ण कारक अनुक्रमणिका
    crit_pos_back: usize,
    period: usize,
    /// `byteset` एक विस्तार हो (दुई तर्फ एल्गोरिथ्मको भाग होईन);
    /// यो-64-बिट "fingerprint" हो जहाँ प्रत्येक सेट बिट `j` सुईमा उपस्थित एक (बाइट र 63 63)==j सँग मेल खान्छ।
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// सुईमा अनुक्रमणिका जसको अघि हामीले पहिले नै मेल खाइसकेका छौं
    memory: usize,
    /// सुईमा अनुक्रमणिका पछि हामीसँग पहिले नै मेल खायो
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // यहाँ के भइरहेको छ भनेर विशेष रूपमा पढ्नयोग्य विवरण क्रोशेमोर र राइटरको पुस्तक "Text Algorithms", सीएच १ be मा पाउन सकिन्छ।
        // विशेष रूपमा p मा "Algorithm CP" को लागी कोड हेर्नुहोस्।
        // 323.
        //
        // के भइरहेको छ कि हामीसँग सुईको केही आलोचनात्मक कारक (u, v) छ, र हामी यो निर्धारित गर्न चाहन्छौं कि तपाईं U&v [.. अवधि] को प्रत्यय हो कि होइन।
        // यदि यो हो भने हामी "Algorithm CP1" प्रयोग गर्छौं।
        // अन्यथा हामी "Algorithm CP2" प्रयोग गर्छौं, जुन सुईको अवधि ठूलो हुँदाको लागि अनुकूलित हुन्छ।
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // छोटो अवधि केस-अवधि ठीक उल्टो सुई x=u 'v' जहाँ | v '| को लागी एक अलग आलोचनात्मक कारक गणना छ।<period(x)।
            //
            // यो पहिले नै ज्ञात भइरहेको अवधि द्वारा बढाइन्छ।
            // नोट गर्नुहोस् कि x= "acba" जस्ता केस ठीक अगाडि फैक्टर हुन सक्दछ (crit_pos=1, अवधि=3) जबकि क्रमशः समयावधि उल्टो क्रममा दर्साइएको छ (crit_pos=२, अवधि=२)।
            // हामी दिईएको रिभर्स कारकीकरण प्रयोग गर्दछौं तर सहि अवधि राख्छौं।
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // लामो अवधि केस-हामीसंग वास्तविक अवधिमा एक अनुमानित छ, र सम्झन प्रयोग गर्दैनौं।
            //
            //
            // तल्लो सीमा max(|u|, |v|) + १ द्वारा समयावधि अवधि।
            // अगाडि र उल्टो खोजी दुबैको लागि प्रयोग गर्नका लागि महत्वपूर्ण कारक सक्षम छ।
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // डम्मी मान यो अवधि लामो छ
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // टू-वे को एक मुख्य विचार यो हो कि हामी सुईलाई दुई भागमा विभाजित गर्दछौं, (u, v), र बायाँबाट दायाँ स्क्यान गरेर घासको छालामा v खोज्न थाल्छौं।
    // यदि v मिल्दछ भने, हामी तपाईलाई दायाँ देखि बाँया स्क्यान गरेर मिलाउन प्रयास गर्दछौं।
    // हामी बेमेल हुँदा हामी कति टाढासम्म हाम फाल्न सक्दछौं भन्ने तथ्य तथ्यमा आधारित छ (यू, वी) सुईको लागि महत्वपूर्ण कारक हो।
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` `self.position` लाई यसको कर्सरको रूपमा प्रयोग गर्दछ
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // जाँच गर्नुहोस् कि हामीसँग पोजीशनमा सुई कोठा छ। सुई_लास्ट ओभरफ्लो हुन सक्दैन यदि मानौं स्लाइसहरू ईसाइजको दायरा द्वारा बाध्य छन्।
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // हाम्रो स्ट्रिंगमा असम्बन्धित ठूला भागहरू द्रुत रूपमा स्किप गर्नुहोस्
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // हेर्नुहोस् कि सुईको दायाँ भाग मेल खान्छ
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // हेर्नुहोस् कि सुईको बाँया भाग मेल खान्छ
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // हामीले एउटा खेल भेट्टायौं!
            let match_pos = self.position;

            // Note: ओभरल्यापि matches खेलहरू गर्न needle.len() को सट्टा self.period थप्नुहोस्
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // ओभरल्यापि matches खेलहरूका लागि needle.len(), self.period मा सेट गर्नुहोस्
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // `next()` मा विचारहरू अनुसरण गर्दछ।
    //
    // परिभाषाहरू सममित छन्, period(x) = period(reverse(x)) र local_period(u, v) = local_period(reverse(v), reverse(u)) का साथ, त्यसैले यदि (u, v) एक महत्वपूर्ण कारक हो, त्यसैले (reverse(v) हो, reverse(u)).
    //
    //
    // रिभर्स केसका लागि हामीले एउटा महत्त्वपूर्ण कारक x=u 'v' (क्षेत्र `crit_pos_back`) गणना गरेका छौं।हामीलाई | u | आवश्यक छ<period(x) अगाडि केसको लागि र यसैले | v '|<एक्स ०१ एक्स रिभर्सका लागि।
    //
    // घास कोटिको माध्यमबाट रिभर्समा खोजी गर्न, हामी एक उल्टो सुईको साथ उल्टो घाँसकोटको अगाडि खोज्दछौं, पहिले u 'र v' मिलान गर्दै।
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` `self.end` लाई यसको कर्सरको रूपमा प्रयोग गर्दछ-ताकि `next()` र `next_back()` स्वतन्त्र छन्।
        //
        let old_end = self.end;
        'search: loop {
            // जाँच गर्नुहोस् कि हामीसँग अन्त्यमा खोजी गर्न कोठा छ, needle.len() चारैतिर लपेट्नेछ जब त्यहाँ थप ठाउँ छैन, तर स्लाइस लम्बाई सीमाहरूको कारणले यो कहिलेसम्म पछाडि लम्बाउन सकिदैन पछाडि लम्बाईमा।
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // हाम्रो स्ट्रिंगमा असम्बन्धित ठूला भागहरू द्रुत रूपमा स्किप गर्नुहोस्
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // हेर्नुहोस् कि सुईको बाँया भाग मेल खान्छ
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // हेर्नुहोस् कि सुईको दायाँ भाग मेल खान्छ
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // हामीले एउटा खेल भेट्टायौं!
            let match_pos = self.end - needle.len();
            // Note: उप self.period needle.len() को सट्टामा ओभरल्यापि matches खेलहरू छन्
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // `arr` को अधिकतम प्रत्यय गणना गर्नुहोस्।
    //
    // अधिकतम प्रत्यय `arr` को एक सम्भावित गंभीर कारक (u, v) हो।
    //
    // रिटर्न (`i`, `p`) जहाँ `i` v को सुरूवात सूचक हो र `p` v को समयावधि हो।
    //
    // `order_greater` लेक्जिकल अर्डर `<` वा `>` छ कि छैन निर्धारण गर्दछ।
    // दुबै आदेशहरू गणना गर्नुपर्दछ-क्रमबद्ध रूपमा सबैभन्दा ठूलो `i` एक महत्वपूर्ण कारक दिन्छ।
    //
    //
    // लामो अवधिको मामिलाहरूको लागि, परिणाम अवधि सहि हुँदैन (यो अत्यन्त छोटो छ)।
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // कागजमा I को पत्राचार गर्दछ
        let mut right = 1; // कागजमा j सँग सम्बन्धित छ
        let mut offset = 0; // कागजमा k लाई पत्राचार गर्दछ, तर ० बाट सुरू हुन्छ
        // ०-आधारित अनुक्रमणिका मिलान गर्न।
        let mut period = 1; // कागजमा p लाई पत्राचार गर्दछ

        while let Some(&a) = arr.get(right + offset) {
            // `left` `right` हुन्छ जब इनबाउन्ड हुनेछ।
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // प्रत्यय सानो छ, अवधि अहिले सम्म पूर्ण उपसर्ग हो।
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // वर्तमान अवधि को पुनरावृत्ति को माध्यम बाट अग्रिम।
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // प्रत्यय ठूलो छ, हालको स्थानबाट सुरू गर्नुहोस्।
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // `arr` को उल्टो अधिकतम प्रत्यय गणना गर्नुहोस्।
    //
    // अधिकतम प्रत्यय `arr` को एक सम्भावित गंभीर कारक (u ', v') हो।
    //
    // `i` फर्काउँदछ जहाँ `i` 'v' को शुरुवात सूचक हो, पछाडिबाट;
    // `known_period` को अवधिमा पुगेपछि तुरून्त फिर्ता हुन्छ।
    //
    // `order_greater` लेक्जिकल अर्डर `<` वा `>` छ कि छैन निर्धारण गर्दछ।
    // दुबै आदेशहरू गणना गर्नुपर्दछ-क्रमबद्ध रूपमा सबैभन्दा ठूलो `i` एक महत्वपूर्ण कारक दिन्छ।
    //
    //
    // लामो अवधिको मामिलाहरूको लागि, परिणाम अवधि सहि हुँदैन (यो अत्यन्त छोटो छ)।
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // कागजमा I को पत्राचार गर्दछ
        let mut right = 1; // कागजमा j सँग सम्बन्धित छ
        let mut offset = 0; // कागजमा k लाई पत्राचार गर्दछ, तर ० बाट सुरू हुन्छ
        // ०-आधारित अनुक्रमणिका मिलान गर्न।
        let mut period = 1; // कागजमा p लाई पत्राचार गर्दछ
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // प्रत्यय सानो छ, अवधि अहिले सम्म पूर्ण उपसर्ग हो।
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // वर्तमान अवधि को पुनरावृत्ति को माध्यम बाट अग्रिम।
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // प्रत्यय ठूलो छ, हालको स्थानबाट सुरू गर्नुहोस्।
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy ले एल्गोरिथ्मलाई कि त सकेसम्म छिटो गैर-मैचहरू स्किप गर्न अनुमति दिन्छ, वा यस्तो मोडमा कार्य गर्न जहाँ यसले अस्वीकार गर्दछ अपेक्षाकृत चाँडो।
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// सकेसम्म छिटो अन्तरालहरू मिलाउन स्किप गर्नुहोस्
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// नियमित रूपमा अस्वीकार गर्नुहोस्
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}