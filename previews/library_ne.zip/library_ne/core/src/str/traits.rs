//! `str` को लागी Trait कार्यान्वयन।

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// स्ट्रिंगको अर्डरिंग लागू गर्दछ।
///
/// स्ट्रि Xहरू [lexicographically](Ord#lexicographical-comparison) तिनीहरूका बाइट मान द्वारा अर्डर गरियो।
/// यो आदेश चार्ट युनिकोड कोड पोइन्टहरू तिनीहरूको चार्टहरूमा कोड चार्टमा।
/// यो आवश्यक छैन कि "alphabetical" अर्डर जस्तै हो, जुन भाषा र स्थानीय अनुसार फरक हुन्छ।
/// सांस्कृतिक रूपले स्वीकृत मानक अनुसार स्ट्रिंग क्रमबद्ध गर्नलाई स्थानीय-विशेष डेटा आवश्यक पर्दछ जुन `str` प्रकारको दायरा बाहिर छ।
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// स्ट्रिंगहरूमा तुलना कार्यहरू लागू गर्दछ।
///
/// स्ट्रिंगहरू [lexicographically](Ord#lexicographical-comparison) लाई तिनीहरूका बाइट मानसँग तुलना गरिन्छ।
/// यसले युनिकोड कोड पोइन्टहरू कोड चार्टमा तिनीहरूको स्थितिको आधारमा तुलना गर्दछ।
/// यो आवश्यक छैन कि "alphabetical" अर्डर जस्तै हो, जुन भाषा र स्थानीय अनुसार फरक हुन्छ।
/// सांस्कृतिक रूपमा स्वीकार्य मानकहरू अनुसार स्ट्रिंगहरूको तुलना गर्न स्थानीय-विशेष डेटा आवश्यक पर्दछ जुन `str` प्रकारको दायरा बाहिर छ।
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// सिन्ट्याक्स `&self[..]` वा `&mut self[..]` को साथ स्ट्रिंग स्लाइसिंग लागू गर्दछ।
///
/// पूरै स्ट्रि aको स्लाइस फर्काउँछ, जस्तै, `&self` वा `&mut self` फर्काउँछ।`र स्वयं [० .. लाई बराबर
/// लेन] `वा`&म्युट स्वतः [० ..
/// len]`.
/// अन्य अनुक्रमणिका अपरेशनहरूको विपरीत, यसले कहिले पनि panic गर्न सक्दैन।
///
/// यो अपरेशन *O*(१) हो।
///
/// 1.20.0 अघि, यी अनुक्रमणिका अपरेसनहरू अझै पनी `Index` र `IndexMut` को प्रत्यक्ष कार्यान्वयन द्वारा समर्थित थियो।
///
/// `&self[0 .. len]` वा `&mut self[0 .. len]` को बराबरी।
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// सिन्ट्याक्स `&self[begin .. end]` वा `&mut self[begin .. end]` को साथ स्ट्रिंग स्लाइसिंग लागू गर्दछ।
///
/// बाइट दायरा [`शुरुआत`, `end`) बाट दिइएको स्ट्रि stringको स्लाइस फर्काउँछ।
///
/// यो अपरेशन *O*(१) हो।
///
/// 1.20.0 अघि, यी अनुक्रमणिका अपरेसनहरू अझै पनी `Index` र `IndexMut` को प्रत्यक्ष कार्यान्वयन द्वारा समर्थित थियो।
///
/// # Panics
///
/// Panics यदि `begin` वा `end` क्यारेक्टरको शुरुवात बाइट अफसेटलाई जनाउँदैन (`is_char_boundary` द्वारा परिभाषित गरिएको छ), यदि `begin > end`, वा यदि `end > len`।
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // यी panic हुनेछ:
/// // बाइट २ `ö` भित्र छ:
/// // &s [२ ..]];
///
/// // बाइट 8 `老`&s [1 .. भित्र
/// // 8];
///
/// // बाइट १०० स्ट्रिंग&को [.. .. बाहिर बाहिर छ।
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // सुरक्षा: भर्खरै जाँच गरियो कि `start` र `end` चार सीमानामा छन्,
            // र हामी एक सुरक्षित सन्दर्भ मा पार गर्दै छौं, त्यसैले फिर्ती मान पनि एक हुनेछ।
            // हामीले चार सीमानाहरू पनि जाँच्यौं, त्यसैले यो मान्य UTF-8 हो।
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // सुरक्षा: भर्खरै जाँच गरियो कि `start` र `end` चार सीमानामा छन्।
            // हामीलाई थाहा छ सूचक अद्वितीय छ किनकि हामीले यो `slice` बाट पायौं।
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // सुरक्षा: कलरले `self` `slice` को दायरामा छ कि ग्यारेन्टी गर्दछ
        // जसले `add` का लागि सबै सर्तहरूको सन्तुष्टि दिन्छ।
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // सुरक्षा: `get_unchecked` का लागि टिप्पणीहरू हेर्नुहोस्।
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary चेक गर्दछ कि सूचकांक [०, .len()] मा `get` पुन: प्रयोग गर्न सक्दैन NLL समस्याको कारण।
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // सुरक्षा: भर्खरै जाँच गरियो कि `start` र `end` चार सीमानामा छन्,
            // र हामी एक सुरक्षित सन्दर्भ मा पार गर्दै छौं, त्यसैले फिर्ती मान पनि एक हुनेछ।
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// सिन्ट्याक्स `&self[.. end]` वा `&mut self[.. end]` को साथ स्ट्रिंग स्लाइसिंग लागू गर्दछ।
///
/// बाइट दायरा [`०`, `end`) बाट दिइएको स्ट्रि ofको स्लाइस फर्काउँछ।
/// `&self[0 .. end]` वा `&mut self[0 .. end]` को बराबरी।
///
/// यो अपरेशन *O*(१) हो।
///
/// 1.20.0 अघि, यी अनुक्रमणिका अपरेसनहरू अझै पनी `Index` र `IndexMut` को प्रत्यक्ष कार्यान्वयन द्वारा समर्थित थियो।
///
/// # Panics
///
/// Panics यदि `end` एक क्यारेक्टर (`is_char_boundary` द्वारा परिभाषित रूपमा) को शुरुवात बाइट अफसेटलाई जनाउँदैन भने, वा यदि `end > len`।
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // सुरक्षा: भर्खरै जाँच गरियो कि `end` चार सीमानामा छ,
            // र हामी एक सुरक्षित सन्दर्भ मा पार गर्दै छौं, त्यसैले फिर्ती मान पनि एक हुनेछ।
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // सुरक्षा: भर्खरै जाँच गरियो कि `end` चार सीमानामा छ,
            // र हामी एक सुरक्षित सन्दर्भ मा पार गर्दै छौं, त्यसैले फिर्ती मान पनि एक हुनेछ।
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // सुरक्षा: भर्खरै जाँच गरियो कि `end` चार सीमानामा छ,
            // र हामी एक सुरक्षित सन्दर्भ मा पार गर्दै छौं, त्यसैले फिर्ती मान पनि एक हुनेछ।
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// सिन्ट्याक्स `&self[begin ..]` वा `&mut self[begin ..]` को साथ स्ट्रिंग स्लाइसिंग लागू गर्दछ।
///
/// बाइट दायरा [`शुरुआत`, `len`) बाट दिइएको स्ट्रि stringको स्लाइस फर्काउँछ।Iv र आत्म [बराबर .. को बराबरी
/// लेन] `वा`&म्युट सेल्फ [सुरु ..
/// len]`.
///
/// यो अपरेशन *O*(१) हो।
///
/// 1.20.0 अघि, यी अनुक्रमणिका अपरेसनहरू अझै पनी `Index` र `IndexMut` को प्रत्यक्ष कार्यान्वयन द्वारा समर्थित थियो।
///
/// # Panics
///
/// Panics यदि `begin` एक क्यारेक्टर (`is_char_boundary` द्वारा परिभाषित रूपमा) को शुरुवात बाइट अफसेटलाई जनाउँदैन भने, वा यदि `begin > len`।
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // सुरक्षा: भर्खरै जाँच गरियो कि `start` चार सीमानामा छ,
            // र हामी एक सुरक्षित सन्दर्भ मा पार गर्दै छौं, त्यसैले फिर्ती मान पनि एक हुनेछ।
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // सुरक्षा: भर्खरै जाँच गरियो कि `start` चार सीमानामा छ,
            // र हामी एक सुरक्षित सन्दर्भ मा पार गर्दै छौं, त्यसैले फिर्ती मान पनि एक हुनेछ।
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // सुरक्षा: कलरले `self` `slice` को दायरामा छ कि ग्यारेन्टी गर्दछ
        // जसले `add` का लागि सबै सर्तहरूको सन्तुष्टि दिन्छ।
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // सुरक्षा: `get_unchecked` को समान।
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // सुरक्षा: भर्खरै जाँच गरियो कि `start` चार सीमानामा छ,
            // र हामी एक सुरक्षित सन्दर्भ मा पार गर्दै छौं, त्यसैले फिर्ती मान पनि एक हुनेछ।
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// सिन्ट्याक्स `&self[begin ..= end]` वा `&mut self[begin ..= end]` को साथ स्ट्रिंग स्लाइसिंग लागू गर्दछ।
///
/// [`begin`, `end`] बाइट दायरा बाट दिईएको स्ट्रि ofको स्लाइस फर्काउँछ।`&self [begin .. end + 1]` वा `&mut self[begin .. end + 1]` सँग बराबर, यदि `end` को `usize` का अधिकतम मान छ भने बाहेक।
///
/// यो अपरेशन *O*(१) हो।
///
/// # Panics
///
/// Panics यदि `begin` क्यारेक्टरको शुरुवात बाइट अफसेटलाई जनाउँदैन (`is_char_boundary` द्वारा परिभाषित गरे अनुसार), यदि `end` एक वर्णको अन्तिम बाइट अफसेटलाई जनाउँदैन भने (`end + 1` या त एक शुरुवात बाइट अफसेट हो वा `len` बराबर हो), यदि `begin > end`, वा यदि `end >= len`।
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // सुरक्षा: कलरले `get_unchecked` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ।
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // सुरक्षा: कलरले `get_unchecked_mut` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ।
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// सिन्ट्याक्स `&self[..= end]` वा `&mut self[..= end]` को साथ स्ट्रिंग स्लाइसिंग लागू गर्दछ।
///
/// [0, `end`] बाइट दायरा बाट दिईएको स्ट्रि ofको स्लाइस फर्काउँछ।
/// `&self [0 .. end + 1]` सँग बराबर, `end` सँग `usize` का अधिकतम मान छ भने बाहेक।
///
/// यो अपरेशन *O*(१) हो।
///
/// # Panics
///
/// Panics यदि `end` एक चरित्रको अन्त्य बाइट अफसेटलाई औंल्याउँदैन (`end + 1` या त `is_char_boundary` द्वारा परिभाषित रूपमा शुरुवात बाइट अफसेट हो, वा `len` सँग बराबर), वा यदि `end >= len`।
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // सुरक्षा: कलरले `get_unchecked` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ।
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // सुरक्षा: कलरले `get_unchecked_mut` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ।
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// स्ट्रि fromबाट मान पार्स गर्नुहोस्
///
/// `FromStr` को [`from_str`] विधि प्राय: स्पष्ट रूपमा प्रयोग गरिन्छ, [`str`] को [`parse`] विधि मार्फत।
/// उदाहरणका लागि [ars parse`] को कागजात हेर्नुहोस्।
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` एक आजीवन प्यारामिटर छैन, र त्यसैले तपाईं केवल पार्स गर्न सक्नुहुन्छ कि जीवनकाल प्यारामिटर आफैं समावेश गर्दैन।
///
/// अर्को शब्दहरुमा, तपाइँले `FromStr` लाई `FromStr` पार्स गर्न सक्नुहुन्छ, तर `&i32` होइन।
/// तपाईले एउटा संरचना पार्स गर्न सक्नुहुनेछ जुन `i32` समावेश गर्दछ, तर एउटा `&i32` समावेश गर्दैन।
///
/// # Examples
///
/// `FromStr` X उदाहरणमा `FromStr` को आधारभुत कार्यान्वयन:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// सम्बन्धित त्रुटि जुन पार्सि fromबाट फर्काउन सकिन्छ।
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// यस प्रकारको मान फर्काउन स्ट्रि X `s` पार्स गर्दछ।
    ///
    /// यदि पार्सि suc सफल भयो भने [`Ok`] भित्रको मान फिर्ता गर्नुहोस्, अन्यथा स्ट्रि ill बिरामी ढाँचा भएको खण्डमा भित्री [`Err`] को लागी त्रुटि देखा पर्छ।
    /// त्रुटि प्रकार trait को कार्यान्वयनको लागि विशिष्ट छ।
    ///
    /// # Examples
    ///
    /// [`i32`] का साथ आधारभूत उपयोग, `FromStr` कार्यान्वयन गर्ने प्रकार:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// स्ट्रि fromबाट `bool` पार्स गर्नुहोस्।
    ///
    /// `Result<bool, ParseBoolError>` उत्पादन गर्दछ, किनकि `s` वास्तवमा पार्सेबल हुन सक्छ वा हुन सक्दैन।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// नोट, धेरै केसहरूमा, `str` मा `.parse()` विधि अधिक उचित छ।
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}