//! स्ट्रिंग हेरफेर।
//!
//! थप विवरणहरूको लागि, [`std::str`] मोड्युल हेर्नुहोस्।
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. सीमा बाहिर
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. सुरु <=अन्त्य
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. चरित्र सीमा
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // चरित्र खोज्नुहोस्
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` लेन र चार सीमाना भन्दा कम हुनुपर्छ
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// `self` को लम्बाई फर्काउँछ।
    ///
    /// यो लम्बाइ बाइट्समा हो, [`Char`] s वा graphemes मा होईन।
    /// अर्को शब्दमा, यो स्ट्रिंगको लम्बाइलाई मान्ने मानिस हुन सक्दैन।
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // fancy f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// `true` फर्काउँछ यदि `self` को शून्य बाइटको लम्बाई छ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// जाँच गर्दछ कि `index`-th बाइट UTF-8 कोड पोइन्ट अनुक्रम वा स्ट्रि ofको अन्त्यमा पहिलो बाइट हो।
    ///
    ///
    /// स्ट्रिंगको सुरू र अन्त (जब `अनुक्रमणिका== self.len()`) सीमाहरू मानिन्छ।
    ///
    /// यदि `index` `self.len()` भन्दा ठूलो छ भने `false` फर्काउँछ।
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // `老` को सुरूवात
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // `ö` को दोस्रो बाइट
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // `老` को तेस्रो बाइट
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // ० र लेन सधैं ठीक हुन्छ।
        // स्पष्ट रूपमा ० को लागि परीक्षण गर्नुहोस् ताकि यसले सजिलैसँग चेक अप्टिमेट गर्न सक्दछ र त्यस केसको लागि प string्क्ति स्ट्रि data डाटा पढ्न स्किप गर्न सकिन्छ।
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // यो बिट जादू बराबर हो: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// स्ट्रिंग स्लाइसलाई बाइट स्लाइसमा रूपान्तरण गर्दछ।
    /// बाइट स्लाईसलाई फेरि स्ट्रि sl स्लाइसमा रूपान्तरण गर्न, [`from_utf8`] प्रकार्य प्रयोग गर्नुहोस्।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // सुरक्षा: कन्स्ट आवाज किनकि हामी एकै रूपरेखाको साथ दुई प्रकारका ट्रान्समिट गर्दछौं
        unsafe { mem::transmute(self) }
    }

    /// म्यूटेबल स्ट्रि sl स्लाइसलाई म्यूटेबल बाइट स्लाइसमा रूपान्तरण गर्दछ।
    ///
    /// # Safety
    ///
    /// कलरले सुनिश्चित गर्नु पर्छ कि स्लाइसको सामग्री Xण समाप्त हुनु अघि र अन्तर्निहित `str` प्रयोग गर्नु अघि UTF-8 मान्य छ।
    ///
    ///
    /// एक `str` को उपयोग जसको सामग्री मान्य UTF-8 अपरिभाषित व्यवहार हो।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // सुरक्षा: `&str` बाट `&[u8]` मा कास्ट `str` सुरक्षित छ
        // `&[u8]` को समान लेआउट छ (केवल libstd ले यो ग्यारेन्टी गर्न सक्दछ)।
        // पोइन्टर डिरेफरेसन सुरक्षित छ किनकि यो म्यूटेबल सन्दर्भबाट आएको हो जुन लेख्नको लागि मान्य हुने ग्यारेन्टी गरिएको छ।
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// स्ट्रि sl स्लाइसलाई कच्चा सूचकमा रूपान्तरण गर्दछ।
    ///
    /// स्ट्रिंग स्लाइसहरू बाइट्सको स्लाइस हो, कच्चा सूचकले [`u8`] मा औंल्याउँछ।
    /// यो सूचक स्ट्रिंग स्लाइस को पहिलो बाइट मा इंगित हुनेछ।
    ///
    /// कलरले यो सुनिश्चित गर्नु पर्छ कि फिर्ता पोइन्टर कहिले लेखिएको छैन।
    /// यदि तपाइँले स्ट्रि sl स्लाइसको सामग्री परिवर्तन गर्न आवश्यक छ भने, [`as_mut_ptr`] प्रयोग गर्नुहोस्।
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// म्यूटेबल स्ट्रि sl स्लाइसलाई एउटा कच्चा सूचकमा रूपान्तरण गर्दछ।
    ///
    /// स्ट्रिंग स्लाइसहरू बाइट्सको स्लाइस हो, कच्चा सूचकले [`u8`] मा औंल्याउँछ।
    /// यो सूचक स्ट्रिंग स्लाइस को पहिलो बाइट मा इंगित हुनेछ।
    ///
    /// यो सुनिश्चित गर्नु तपाईंको उत्तरदायित्व हो कि स्ट्रि sl स्लाइस मात्र परिमार्जन हुन्छ कि यो वैध UTF-8 रहन्छ।
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// `str` को एक सब्सलिस फर्काउँछ।
    ///
    /// `str` लाई अनुक्रमणिका गर्नको लागि यो गैर-पिकनिक विकल्प हो।
    /// [`None`] फर्काउँछ जब समतुल्य अनुक्रमणिका अपरेसन panic हुन्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // सूचकांक UTF-8 अनुक्रम सीमामा छैन
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // सीमा बाहिर
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// `str` को एक परिवर्तनीय सब्सलिस फर्काउँछ।
    ///
    /// `str` लाई अनुक्रमणिका गर्नको लागि यो गैर-पिकनिक विकल्प हो।
    /// [`None`] फर्काउँछ जब समतुल्य अनुक्रमणिका अपरेसन panic हुन्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // सही लम्बाई
    /// assert!(v.get_mut(0..5).is_some());
    /// // सीमा बाहिर
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// `str` को एक जाँच नगरिएको सब्सलिसलाई फर्काउँछ।
    ///
    /// यो `str` लाई अनुक्रमणिका गर्ने जाँच नगरिएको विकल्प हो।
    ///
    /// # Safety
    ///
    /// यस प्रकार्यका कलरहरू जिम्मेवार छन् कि यी पूर्व शर्तहरू सन्तुष्ट छन्:
    ///
    /// * सुरूवात सूचकांक अन्त्य सूचकांक भन्दा बढी हुनु हुँदैन;
    /// * अनुक्रमणिका मूल टुक्रा को सीमा भित्र हुनु पर्छ;
    /// * अनुक्रमणिका UTF-8 अनुक्रम सीमामा हुनु पर्छ।
    ///
    /// असफल भएमा, फिर्ता स्ट्रि sl स्लाइसले अवैध मेमोरीलाई सन्दर्भित गर्न सक्दछ वा `str` प्रकारद्वारा सूचित गरिएको आक्रमणकर्ताहरूलाई उल्ल .्घन गर्न सक्दछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // सुरक्षा: कलरले `get_unchecked` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ;
        // टुक्रा डेरेन्फेन्सेबल छ किनकि `self` एक सुरक्षित सन्दर्भ हो।
        // फिर्ता पोइन्टर सुरक्षित छ किनकि `SliceIndex` को ईम्प्सले ग्यारेन्टी गर्नु पर्छ यो छ।
        unsafe { &*i.get_unchecked(self) }
    }

    /// `str` को एक परिवर्तनीय, अनचेक सब्सलिस फर्काउँछ।
    ///
    /// यो `str` लाई अनुक्रमणिका गर्ने जाँच नगरिएको विकल्प हो।
    ///
    /// # Safety
    ///
    /// यस प्रकार्यका कलरहरू जिम्मेवार छन् कि यी पूर्व शर्तहरू सन्तुष्ट छन्:
    ///
    /// * सुरूवात सूचकांक अन्त्य सूचकांक भन्दा बढी हुनु हुँदैन;
    /// * अनुक्रमणिका मूल टुक्रा को सीमा भित्र हुनु पर्छ;
    /// * अनुक्रमणिका UTF-8 अनुक्रम सीमामा हुनु पर्छ।
    ///
    /// असफल भएमा, फिर्ता स्ट्रि sl स्लाइसले अवैध मेमोरीलाई सन्दर्भित गर्न सक्दछ वा `str` प्रकारद्वारा सूचित गरिएको आक्रमणकर्ताहरूलाई उल्ल .्घन गर्न सक्दछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // सुरक्षा: कलरले `get_unchecked_mut` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ;
        // टुक्रा डेरेन्फेन्सेबल छ किनकि `self` एक सुरक्षित सन्दर्भ हो।
        // फिर्ता पोइन्टर सुरक्षित छ किनकि `SliceIndex` को ईम्प्सले ग्यारेन्टी गर्नु पर्छ यो छ।
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// सुरक्षा जाँचहरूलाई बाइपास गरेर अर्को स्ट्रि sl स्लाइसबाट स्ट्रि sl स्लाइस सिर्जना गर्दछ।
    ///
    /// यो सामान्य रूपमा सिफारिस गरिएको छैन, सावधानीका साथ प्रयोग गर्नुहोस्!सुरक्षित विकल्पको लागि [`str`] र [`Index`] हेर्नुहोस्।
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// यो नयाँ स्लाइस `begin` बाट `end` मा जान्छ, `begin` सहित तर `end` बाहेक।
    ///
    /// यसको सट्टा एक म्यूटेबल स्ट्रि sl स्लाइस प्राप्त गर्नका लागि, [`slice_mut_unchecked`] विधि हेर्नुहोस्।
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// यस प्रकार्यका कलरहरू जिम्मेवार छन् कि तीन पूर्व शर्तहरू सन्तुष्ट छन्:
    ///
    /// * `begin` `end` भन्दा बढि हुनु हुँदैन।
    /// * `begin` र `end` बाइट स्थिति स्ट्रिंग स्लाइस भित्र हुनुपर्छ।
    /// * `begin` र `end` UTF-8 अनुक्रम सीमामा हुनु पर्छ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // सुरक्षा: कलरले `get_unchecked` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ;
        // टुक्रा डेरेन्फेन्सेबल छ किनकि `self` एक सुरक्षित सन्दर्भ हो।
        // फिर्ता पोइन्टर सुरक्षित छ किनकि `SliceIndex` को ईम्प्सले ग्यारेन्टी गर्नु पर्छ यो छ।
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// सुरक्षा जाँचहरूलाई बाइपास गरेर अर्को स्ट्रि sl स्लाइसबाट स्ट्रि sl स्लाइस सिर्जना गर्दछ।
    /// यो सामान्य रूपमा सिफारिस गरिएको छैन, सावधानीका साथ प्रयोग गर्नुहोस्!सुरक्षित विकल्पको लागि [`str`] र [`IndexMut`] हेर्नुहोस्।
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// यो नयाँ स्लाइस `begin` बाट `end` मा जान्छ, `begin` सहित तर `end` बाहेक।
    ///
    /// यसको सट्टा एक अपरिवर्तनीय स्ट्रिंग स्लाइस प्राप्त गर्नका लागि, [`slice_unchecked`] विधि हेर्नुहोस्।
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// यस प्रकार्यका कलरहरू जिम्मेवार छन् कि तीन पूर्व शर्तहरू सन्तुष्ट छन्:
    ///
    /// * `begin` `end` भन्दा बढि हुनु हुँदैन।
    /// * `begin` र `end` बाइट स्थिति स्ट्रिंग स्लाइस भित्र हुनुपर्छ।
    /// * `begin` र `end` UTF-8 अनुक्रम सीमामा हुनु पर्छ।
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // सुरक्षा: कलरले `get_unchecked_mut` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ;
        // टुक्रा डेरेन्फेन्सेबल छ किनकि `self` एक सुरक्षित सन्दर्भ हो।
        // फिर्ता पोइन्टर सुरक्षित छ किनकि `SliceIndex` को ईम्प्सले ग्यारेन्टी गर्नु पर्छ यो छ।
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// एउटा स्ट्रि sl स्लाइस दुईमा अनुक्रमणिकामा विभाजन गर्नुहोस्।
    ///
    /// आर्गुमेन्ट, `mid`, स्ट्रिंगको शुरूआतबाट बाइट अफसेट हुनुपर्दछ।
    /// यो UTF-8 कोड पोइन्टको सीमामा हुनुपर्दछ।
    ///
    /// दुई स्लाइसहरू `mid` मा स्ट्रिंग स्लाइसको सुरूबाट, र `mid` बाट स्ट्रिंग स्लाइसको अन्त्यसम्म फर्कियो।
    ///
    /// यसको सट्टा परिवर्तनीय स्ट्रि s स्लाइसहरू प्राप्त गर्न, [`split_at_mut`] विधि हेर्नुहोस्।
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics यदि `mid` UTF-8 कोड पोइन्ट सीमामा छैन भने, वा यदि यो स्ट्रिंग स्लाइसको अन्तिम कोड पोइन्टको अन्त्यमा छ।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary जाँच गर्दछ कि सूचकांक [०, .len()]
        if self.is_char_boundary(mid) {
            // सुरक्षा: भर्खरै जाँच गरियो कि `mid` चार सीमानामा छ।
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// एउटा परिवर्तनीय स्ट्रि sl स्लाइसलाई दुईमा सूचकांकमा विभाजन गर्नुहोस्।
    ///
    /// आर्गुमेन्ट, `mid`, स्ट्रिंगको शुरूआतबाट बाइट अफसेट हुनुपर्दछ।
    /// यो UTF-8 कोड पोइन्टको सीमामा हुनुपर्दछ।
    ///
    /// दुई स्लाइसहरू `mid` मा स्ट्रिंग स्लाइसको सुरूबाट, र `mid` बाट स्ट्रिंग स्लाइसको अन्त्यसम्म फर्कियो।
    ///
    /// यसको सट्टा अपरिवर्तनीय स्ट्रिंग स्लाइसहरू प्राप्त गर्न, [`split_at`] विधि हेर्नुहोस्।
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics यदि `mid` UTF-8 कोड पोइन्ट सीमामा छैन भने, वा यदि यो स्ट्रिंग स्लाइसको अन्तिम कोड पोइन्टको अन्त्यमा छ।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary जाँच गर्दछ कि सूचकांक [०, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // सुरक्षा: भर्खरै जाँच गरियो कि `mid` चार सीमानामा छ।
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// [`Char`] s को स्ट्रि sl स्लाइसको इटररेटर फर्काउँछ।
    ///
    /// स्ट्रिंग स्लाइसमा मान्य UTF-8 समावेश भएकोले, हामी [`char`] द्वारा स्ट्रिंग स्लाइस मार्फत पुनरावृत्ति गर्न सक्छौं।
    /// यस विधिले यस्तो पुनरावृत्तिकर्ता फिर्ता गर्छ।
    ///
    /// यो याद राख्नु महत्वपूर्ण छ कि [`char`] ले युनिकोड स्केलर मान प्रतिनिधित्व गर्दछ, र 'character' के हो भन्ने तपाईंको विचारसँग मेल खाँदैन।
    ///
    /// ग्राफीम क्लस्टरमा इन्टरेसन तपाईले चाहानु भएको जस्तो हुन सक्छ।
    /// यो कार्यक्षमता Rust को मानक लाइब्रेरी द्वारा प्रदान गरिएको छैन, सट्टा crates.io जाँच गर्नुहोस्।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// याद राख्नुहोस्, [`char`] s ले तपाईंको चरित्रको बारेमा अन्तर्ज्ञानसँग मेल खाँदैन:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // 'y̆' होईन
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// [`Char`] s को स्ट्रि sl स्लाइस, र तिनीहरूको स्थिति माथि ईटररेटर फर्काउँछ।
    ///
    /// स्ट्रिंग स्लाइसमा मान्य UTF-8 समावेश भएकोले, हामी [`char`] द्वारा स्ट्रिंग स्लाइस मार्फत पुनरावृत्ति गर्न सक्छौं।
    /// यस विधिले यी दुबै [`char s] s को पुनरावृत्तिकर्ता प्रदान गर्दछ, साथै तिनीहरूको बाइट स्थानहरू।
    ///
    /// इटरेटरले ट्युपल्स उत्पादन गर्दछ।स्थिति पहिलो छ, [`char`] दोस्रो छ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// याद राख्नुहोस्, [`char`] s ले तपाईंको चरित्रको बारेमा अन्तर्ज्ञानसँग मेल खाँदैन:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // होईन (०, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // यहाँ नोट गर्नुहोस् the, अन्तिम चरित्रले दुई बाइट्स लिएको छ
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// स्ट्रिंग स्लाइसको बाइट्समा इटरेटर।
    ///
    /// स्ट्रिंग स्लाइसमा बाइट्सको अनुक्रम हुन्छ, हामी बाइट द्वारा स्ट्रिंग स्लाइस मार्फत पुनरावृत्ति गर्न सक्छौं।
    /// यस विधिले यस्तो पुनरावृत्तिकर्ता फिर्ता गर्छ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// व्हाइटस्पेस द्वारा स्ट्रि sl स्लाइस विभाजित गर्दछ।
    ///
    /// इट्रेटर फर्कायो स्ट्रिंग स्लाइसहरू फर्काउँछ जुन मौलिक स्ट्रिंगका उप-स्लाइसहरू हुन्छन, कुनै पनि स्पेसको स्पेसबाट अलग गरिएको।
    ///
    ///
    /// 'Whitespace' युनिकोड व्युत्पन्न कोर गुण `White_Space` को सर्तहरू अनुसार परिभाषित गरिएको छ।
    /// यदि तपाईं यसको सट्टामा ASCII व्हाइटस्पेसमा विभाजित गर्न चाहनुहुन्छ भने, [`split_ascii_whitespace`] प्रयोग गर्नुहोस्।
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// सबै प्रकारको ह्वाइटस्पेसलाई मानिन्छ:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// ASCII ह्वाइटस्पेस द्वारा स्ट्रिंग स्लाइस विभाजित गर्दछ।
    ///
    /// फिर्ता गरिएको इटररेटरले स्ट्रिंग स्लाइसहरू फर्काउँछ जुन मौलिक स्ट्रि sl स्लाइसका उप-स्लाइसहरू हुन्, कुनै पनि ASCII सेता खाली ठाउँबाट अलग।
    ///
    ///
    /// यसको सट्टामा युनिकोड `Whitespace` द्वारा विभाजित गर्न, [`split_whitespace`] प्रयोग गर्नुहोस्।
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// सबै प्रकारको ASCII ह्वाइटस्पेस मानिन्छ:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// स्ट्रि of स्लाइसहरू जस्तै स्ट्रि ofको लाइनहरूमा ईटररेटर।
    ///
    /// लाइनहरू या त नयाँ लाइन (`\n`) वा एक लाइन फिड (`\r\n`) को साथ एक क्यारिज फिर्ताको साथ समाप्त भयो।
    ///
    /// अन्तिम रेखा अन्त्य वैकल्पिक हो।
    /// अन्तिम रेखा अन्त्य हुने स्ट्रिले अन्तिम रेखा अन्त्य नगरी उस्तै लाइनहरूलाई अन्यथा समान स्ट्रिंगको रूपमा फर्काउँछ।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// अन्तिम रेखा अन्त्य आवश्यक छैन:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// एक स्ट्रिंग को लाइन मा एक iterator।
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// UTF-16 को रूपमा ईन्कोडिंग स्ट्रि overमा `u16` को एक इटरेटर फर्काउँछ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// `true` फर्काउँछ यदि दिइएको ढाँचाले यो स्ट्रि sl स्लाइसको उप-स्लाइससँग मेल खान्छ।
    ///
    /// यदि छैन भने `false` फर्काउँछ।
    ///
    /// [pattern] `&str`, [`char`], [`Char`] s को एक टुक्रा, वा प्रकार्य वा बन्द हुन सक्दछ कि क्यारेक्टर मेल खायो भने निर्धारण गर्दछ।
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// `true` फर्काउँछ यदि दिइएको ढाँचा यो स्ट्रि string स्लाइसको उपसर्गसँग मेल खान्छ।
    ///
    /// यदि छैन भने `false` फर्काउँछ।
    ///
    /// [pattern] `&str`, [`char`], [`Char`] s को एक टुक्रा, वा प्रकार्य वा बन्द हुन सक्दछ कि क्यारेक्टर मेल खायो भने निर्धारण गर्दछ।
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// यदि दिइएको ढाँचाले यो स्ट्रि sl स्लाइसको प्रत्ययसँग मेल खान्छ भने `true` फर्काउँछ।
    ///
    /// यदि छैन भने `false` फर्काउँछ।
    ///
    /// [pattern] `&str`, [`char`], [`Char`] s को एक टुक्रा, वा प्रकार्य वा बन्द हुन सक्दछ कि क्यारेक्टर मेल खायो भने निर्धारण गर्दछ।
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// ढाँचासँग मेल खाने यो स्ट्रिंग स्लाइसको पहिलो वर्णको बाइट अनुक्रमणिका फर्काउँछ।
    ///
    /// यदि ढाँचा मेल खाँदैन भने [`None`] फर्काउँछ।
    ///
    /// [pattern] `&str`, [`char`], [`Char`] s को एक टुक्रा, वा प्रकार्य वा बन्द हुन सक्दछ कि क्यारेक्टर मेल खायो भने निर्धारण गर्दछ।
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// साधारण ढाँचा:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// पोइन्ट-फ्री शैली र क्लोजरहरू प्रयोग गरेर अधिक जटिल बान्कीहरू:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// ढाँचा फेला परेन:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// यस स्ट्रि sl स्लाइसमा प्याटर्नको दाँयाको मेलको पहिलो वर्णको लागि बाइट सूचकांक फर्काउँछ।
    ///
    /// यदि ढाँचा मेल खाँदैन भने [`None`] फर्काउँछ।
    ///
    /// [pattern] `&str`, [`char`], [`Char`] s को एक टुक्रा, वा प्रकार्य वा बन्द हुन सक्दछ कि क्यारेक्टर मेल खायो भने निर्धारण गर्दछ।
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// साधारण ढाँचा:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// बन्दको साथ अधिक जटिल बान्कीहरू:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// ढाँचा फेला परेन:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// यस स्ट्रि sl स्लाइसको सबस्ट्रि over्हरूमा एक इटरेटर, प्याटर्नसँग मिलेको क्यारेक्टरहरूद्वारा विभाजित।
    ///
    /// [pattern] `&str`, [`char`], [`Char`] s को एक टुक्रा, वा प्रकार्य वा बन्द हुन सक्दछ कि क्यारेक्टर मेल खायो भने निर्धारण गर्दछ।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator को व्यवहार
    ///
    /// फिर्ता ईटरेटर एक [`DoubleEndedIterator`] हुनेछ यदि प्याटर्नले रिभर्स खोजीलाई अनुमति दिन्छ र forward/reverse खोजले समान तत्वहरू उत्पादन गर्दछ।
    /// यो उदाहरणको लागि, [`char`] का लागि सही हो, तर `&str` का लागि होईन।
    ///
    /// यदि बान्कीले रिभर्स खोजीलाई अनुमति दिन्छ तर यसको नतिजाहरू अगाडि खोजमा फरक हुन सक्दछ, [`rsplit`] विधि प्रयोग गर्न सकिन्छ।
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// साधारण ढाँचा:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// यदि ढाँचा वर्णहरूको टुक्रा हो भने, कुनै पनि वर्णहरूको प्रत्येक घटनामा विभाजन गर्नुहोस्:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// एक अधिक जटिल बान्की, क्लोजर प्रयोग गरी:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// यदि स्ट्रिमा बहुसंगत विभाजक समावेश छ भने तपाई आउटपुटमा खाली स्ट्रि withको साथ अन्त्य हुनेछ।
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// कन्टिभियस विभाजक खाली स्ट्रि byद्वारा विभाजित गरिन्छ।
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// स्ट्रिंगको सुरू वा अन्तमा विभाजक खाली स्ट्रि byहरू द्वारा छिमेकी हुन्छन्।
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// जब खाली स्ट्रि a विभाजकको रूपमा प्रयोग गरिन्छ, यसले स्ट्रिंगको प्रत्येक अक्षरलाई अलग गर्दछ, स्ट्रिंगको सुरूवात र अन्तको साथ।
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// मिल्ने विभाजकहरूले सम्भवतः अचम्मको व्यवहार गर्न सक्दछ जब सेतो स्पेस विभाजकको रूपमा प्रयोग गरिन्छ।यो कोड सहि छ:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// यसले _not_ तपाईंलाई दिन्छ:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// यो व्यवहारको लागि [`split_whitespace`] प्रयोग गर्नुहोस्।
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// यस स्ट्रि sl स्लाइसको सबस्ट्रि over्हरूमा एक इटरेटर, प्याटर्नसँग मिलेको क्यारेक्टरहरूद्वारा विभाजित।
    /// `split` X द्वारा उत्पादित इट्रेटरभन्दा फरक जुन `split_inclusive` मा मिल्दो भागलाई स्ट्रिring्गको टर्मिनेटरको रूपमा छोडिन्छ।
    ///
    ///
    /// [pattern] `&str`, [`char`], [`Char`] s को एक टुक्रा, वा प्रकार्य वा बन्द हुन सक्दछ कि क्यारेक्टर मेल खायो भने निर्धारण गर्दछ।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// यदि स्ट्रि ofको अन्तिम तत्व मेल खाएमा, त्यो तत्व पूर्ववर्ती सबस्ट्रिंगको टर्मिनेटर मानिनेछ।
    /// त्यो स्ट्र्रिring्ग अन्तिम कार्यकर्ताद्वारा फिर्ता गरिएको अन्तिम वस्तु हुनेछ।
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// दिइएको स्ट्रि sl स्लाइसको सबस्ट्रिंगमा एक इटररेटर, एक ढाँचामा मिलेको क्यारेक्टरहरू द्वारा छुट्याइएको र उल्टो क्रममा उत्पन्न।
    ///
    /// [pattern] `&str`, [`char`], [`Char`] s को एक टुक्रा, वा प्रकार्य वा बन्द हुन सक्दछ कि क्यारेक्टर मेल खायो भने निर्धारण गर्दछ।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator को व्यवहार
    ///
    /// फिर्ता इटरेटर्सको आवाश्यक हुन्छ कि प्याटर्नले रिभर्स खोजीलाई समर्थन गर्दछ, र यो [`DoubleEndedIterator`] हुनेछ यदि forward/reverse खोजले समान तत्वहरू उत्पादन गर्दछ।
    ///
    ///
    /// अगाडिबाट पुनरावृत्तिको लागि, [`split`] विधि प्रयोग गर्न सकिन्छ।
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// साधारण ढाँचा:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// एक अधिक जटिल बान्की, क्लोजर प्रयोग गरी:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// दिइएको स्ट्रि sl स्लाइसको सबस्ट्रिंगमा एक पुनरावृत्ति, ढाँचाले मिलेको क्यारेक्टरहरूद्वारा विभाजित।
    ///
    /// [pattern] `&str`, [`char`], [`Char`] s को एक टुक्रा, वा प्रकार्य वा बन्द हुन सक्दछ कि क्यारेक्टर मेल खायो भने निर्धारण गर्दछ।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] को बराबर, बाहेक खाली पछाडि खाली छोडिन्छ भने।
    ///
    /// [`split`]: str::split
    ///
    /// यो विधि _terminated_ भन्दा स्ट्रिंग डेटाको लागि प्रयोग गर्न सकिन्छ, एक पैटर्न द्वारा _separated_ भन्दा।
    ///
    /// # Iterator को व्यवहार
    ///
    /// फिर्ता ईटरेटर एक [`DoubleEndedIterator`] हुनेछ यदि प्याटर्नले रिभर्स खोजीलाई अनुमति दिन्छ र forward/reverse खोजले समान तत्वहरू उत्पादन गर्दछ।
    /// यो उदाहरणको लागि, [`char`] का लागि सही हो, तर `&str` का लागि होईन।
    ///
    /// यदि बान्कीले रिभर्स खोजीलाई अनुमति दिन्छ तर यसको नतिजाहरू अगाडि खोजमा फरक हुन सक्दछ, [`rsplit_terminator`] विधि प्रयोग गर्न सकिन्छ।
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// `self` को सबस्ट्रि over्हरूमा एक इटरेटर, एक ढाँचामा मिलेको क्यारेक्टरहरू द्वारा छुट्याइएको र उल्टो क्रममा उत्पन्न भयो।
    ///
    /// [pattern] `&str`, [`char`], [`Char`] s को एक टुक्रा, वा प्रकार्य वा बन्द हुन सक्दछ कि क्यारेक्टर मेल खायो भने निर्धारण गर्दछ।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] को बराबर, बाहेक खाली पछाडि खाली छोडिन्छ भने।
    ///
    /// [`split`]: str::split
    ///
    /// यो विधि _terminated_ भन्दा स्ट्रिंग डेटाको लागि प्रयोग गर्न सकिन्छ, एक पैटर्न द्वारा _separated_ भन्दा।
    ///
    /// # Iterator को व्यवहार
    ///
    /// फिर्ता इटरेटरको आवाश्यकता पर्दछ र ढाँचाले रिभर्स खोजीलाई समर्थन गर्दछ, र यो डबल समाप्त हुन्छ यदि forward/reverse खोजले समान तत्वहरू उत्पादन गर्दछ।
    ///
    ///
    /// अगाडिबाट पुनरावृत्तिको लागि, [`split_terminator`] विधि प्रयोग गर्न सकिन्छ।
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// अधिकतम `n` आईटमहरूमा फर्कने प्रतिबन्धित ढाँचामा विभाजित स्ट्रिंग स्लाइसको सबस्ट्रिंगमा एक पुनरावृत्ति
    ///
    /// यदि `n` सबस्ट्रिings्स फर्काइयो भने, अन्तिम सबस्ट्रिंग (`n`th सबस्ट्रिंग) मा स्ट्रि ofको शेष हुनेछ।
    ///
    /// [pattern] `&str`, [`char`], [`Char`] s को एक टुक्रा, वा प्रकार्य वा बन्द हुन सक्दछ कि क्यारेक्टर मेल खायो भने निर्धारण गर्दछ।
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator को व्यवहार
    ///
    /// फिर्ता ईटरेटर दोहोरो अन्त्य हुने छैन, किनकि यो समर्थन गर्न कुशल छैन।
    ///
    /// यदि ढाँचाले उल्टो खोजीलाई अनुमति दिन्छ भने [`rsplitn`] विधि प्रयोग गर्न सकिन्छ।
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// साधारण ढाँचा:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// एक अधिक जटिल बान्की, क्लोजर प्रयोग गरी:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// यस स्ट्रि sl स्लाइसको सबस्ट्रि over्हरूमा एक इटरेटर, एक ढाँचाद्वारा विभाजित गरियो, स्ट्रि ofको अन्त्यबाट सुरू गरेर, अधिकतम `n` आईटमहरूमा फर्कने प्रतिबन्धित।
    ///
    ///
    /// यदि `n` सबस्ट्रिings्स फर्काइयो भने, अन्तिम सबस्ट्रिंग (`n`th सबस्ट्रिंग) मा स्ट्रि ofको शेष हुनेछ।
    ///
    /// [pattern] `&str`, [`char`], [`Char`] s को एक टुक्रा, वा प्रकार्य वा बन्द हुन सक्दछ कि क्यारेक्टर मेल खायो भने निर्धारण गर्दछ।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator को व्यवहार
    ///
    /// फिर्ता ईटरेटर दोहोरो अन्त्य हुने छैन, किनकि यो समर्थन गर्न कुशल छैन।
    ///
    /// अगाडिबाट विभाजनको लागि, [`splitn`] विधि प्रयोग गर्न सकिन्छ।
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// साधारण ढाँचा:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// एक अधिक जटिल बान्की, क्लोजर प्रयोग गरी:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// निर्दिष्ट डेलिमिटरको पहिलो घटनामा स्ट्रिl विभाजित गर्दछ र डेलिमिटर भन्दा पहिले उपसर्ग र डेलिमिटर पछि प्रत्यय फर्काउँछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// निर्दिष्ट डेलिमिटरको अन्तिम घटनामा स्ट्रि Sp विभाजित गर्दछ र डेलिमिटर भन्दा पहिले उपसर्ग र डेलिमिटर पछि प्रत्यय फर्काउँछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// दिईएको स्ट्रि sl स्लाइस भित्र कुनै ढाँचाको डिजॉइन्ट मिल्दो माथि इट्रेटर।
    ///
    /// [pattern] `&str`, [`char`], [`Char`] s को एक टुक्रा, वा प्रकार्य वा बन्द हुन सक्दछ कि क्यारेक्टर मेल खायो भने निर्धारण गर्दछ।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator को व्यवहार
    ///
    /// फिर्ता ईटरेटर एक [`DoubleEndedIterator`] हुनेछ यदि प्याटर्नले रिभर्स खोजीलाई अनुमति दिन्छ र forward/reverse खोजले समान तत्वहरू उत्पादन गर्दछ।
    /// यो उदाहरणको लागि, [`char`] का लागि सही हो, तर `&str` का लागि होईन।
    ///
    /// यदि बान्कीले रिभर्स खोजीलाई अनुमति दिन्छ तर यसको नतिजाहरू अगाडि खोजमा फरक हुन सक्दछ, [`rmatches`] विधि प्रयोग गर्न सकिन्छ।
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// उल्टो क्रममा उत्पन्न यो स्ट्रि sl स्लाइस भित्र कुनै ढाँचाको डिजॉइन्ट मिल्दो माथि इटरेटर।
    ///
    /// [pattern] `&str`, [`char`], [`Char`] s को एक टुक्रा, वा प्रकार्य वा बन्द हुन सक्दछ कि क्यारेक्टर मेल खायो भने निर्धारण गर्दछ।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator को व्यवहार
    ///
    /// फिर्ता इटरेटर्सको आवाश्यक हुन्छ कि प्याटर्नले रिभर्स खोजीलाई समर्थन गर्दछ, र यो [`DoubleEndedIterator`] हुनेछ यदि forward/reverse खोजले समान तत्वहरू उत्पादन गर्दछ।
    ///
    ///
    /// अगाडिबाट पुनरावृत्तिको लागि, [`matches`] विधि प्रयोग गर्न सकिन्छ।
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// यस स्ट्रिंग स्लाइस भित्र पैटर्नको असमान मेलहरू माथि एक इटरेटर साथ साथै सूचकांक जुन म्याच शुरू हुन्छ।
    ///
    /// `self` बीचको `pat` को मिलानहरू जुन ओभरल्याप हुन्छ, केवल पहिलो खेलसँग सम्बन्धित सूचका .्कहरू फिर्ता हुन्छन्।
    ///
    /// [pattern] `&str`, [`char`], [`Char`] s को एक टुक्रा, वा प्रकार्य वा बन्द हुन सक्दछ कि क्यारेक्टर मेल खायो भने निर्धारण गर्दछ।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator को व्यवहार
    ///
    /// फिर्ता ईटरेटर एक [`DoubleEndedIterator`] हुनेछ यदि प्याटर्नले रिभर्स खोजीलाई अनुमति दिन्छ र forward/reverse खोजले समान तत्वहरू उत्पादन गर्दछ।
    /// यो उदाहरणको लागि, [`char`] का लागि सही हो, तर `&str` का लागि होईन।
    ///
    /// यदि बान्कीले रिभर्स खोजीलाई अनुमति दिन्छ तर यसको नतिजाहरू अगाडि खोजमा फरक हुन सक्दछ, [`rmatch_indices`] विधि प्रयोग गर्न सकिन्छ।
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // केवल पहिलो `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// `self` भित्र कुनै ढाँचाको डिजॉइन्ट मेलहरू माथि एक पुनरावृत्तिक, खेलको अनुक्रमणिकाको साथसाथ रिभर्स अर्डरमा प्राप्त भयो।
    ///
    /// `self` बीचको `pat` को मिलानहरू जुन ओभरल्याप हुन्छ, अन्तिम म्याचसँग मिल्दो सूचकांक मात्र फिर्ता हुन्छ।
    ///
    /// [pattern] `&str`, [`char`], [`Char`] s को एक टुक्रा, वा प्रकार्य वा बन्द हुन सक्दछ कि क्यारेक्टर मेल खायो भने निर्धारण गर्दछ।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator को व्यवहार
    ///
    /// फिर्ता इटरेटर्सको आवाश्यक हुन्छ कि प्याटर्नले रिभर्स खोजीलाई समर्थन गर्दछ, र यो [`DoubleEndedIterator`] हुनेछ यदि forward/reverse खोजले समान तत्वहरू उत्पादन गर्दछ।
    ///
    ///
    /// अगाडिबाट पुनरावृत्तिको लागि, [`match_indices`] विधि प्रयोग गर्न सकिन्छ।
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // केवल अन्तिम `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// अग्रणी र ट्रेलि wh ह्वाइटस्पेस हटाइएको साथ स्ट्रिंग स्लाइस फर्काउँछ।
    ///
    /// 'Whitespace' युनिकोड व्युत्पन्न कोर गुण `White_Space` को सर्तहरू अनुसार परिभाषित गरिएको छ।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// अग्रणी ह्वाइटस्पेस हटाइएको एक स्ट्रिंग स्लाइस फर्काउँछ।
    ///
    /// 'Whitespace' युनिकोड व्युत्पन्न कोर गुण `White_Space` को सर्तहरू अनुसार परिभाषित गरिएको छ।
    ///
    /// # पाठ दिशात्मकता
    ///
    /// स्ट्रि बाइट्सको अनुक्रम हो।
    /// `start` यस सन्दर्भमा भनेको बाइट स्ट्रि ofको पहिलो स्थिति हो;अंग्रेजी वा रूसी जस्तो बायाँ-देखि-दायाँ भाषाको लागि, यो बाँया पट्टि हुनेछ, र दायाँ-देखि-बाँया भाषाहरू जस्तै अरबी वा हिब्रूको लागि, यो दायाँ पट्टि हुनेछ।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// ट्रेलिंग ह्वाइटस्पेस हटाईएको साथ स्ट्रिंग स्लाइस फर्काउँछ।
    ///
    /// 'Whitespace' युनिकोड व्युत्पन्न कोर गुण `White_Space` को सर्तहरू अनुसार परिभाषित गरिएको छ।
    ///
    /// # पाठ दिशात्मकता
    ///
    /// स्ट्रि बाइट्सको अनुक्रम हो।
    /// `end` यस सन्दर्भमा यसको अर्थ बाइट स्ट्रि ofको अन्तिम स्थिति;अंग्रेजी वा रूसी जस्तो देब्रे-देखि-दाँया भाषाको लागि, यो दायाँ पट्टि हुनेछ, र अरबी वा हिब्रू जस्ता दायाँ-देखि-बाँया भाषाहरूको लागि, यो बायाँ तर्फ हुनेछ।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// अग्रणी ह्वाइटस्पेस हटाइएको एक स्ट्रिंग स्लाइस फर्काउँछ।
    ///
    /// 'Whitespace' युनिकोड व्युत्पन्न कोर गुण `White_Space` को सर्तहरू अनुसार परिभाषित गरिएको छ।
    ///
    /// # पाठ दिशात्मकता
    ///
    /// स्ट्रि बाइट्सको अनुक्रम हो।
    /// 'Left' यस सन्दर्भमा भनेको बाइट स्ट्रि ofको पहिलो स्थिति हो;अरबी वा हिब्रू जस्तो भाषाको लागि जुन 'दायाँ देखि बाँया' बरु 'बायाँ देखि दायाँ' को लागी, यो _right_ तर्फ, बायाँ होइन।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// ट्रेलिंग ह्वाइटस्पेस हटाईएको साथ स्ट्रिंग स्लाइस फर्काउँछ।
    ///
    /// 'Whitespace' युनिकोड व्युत्पन्न कोर गुण `White_Space` को सर्तहरू अनुसार परिभाषित गरिएको छ।
    ///
    /// # पाठ दिशात्मकता
    ///
    /// स्ट्रि बाइट्सको अनुक्रम हो।
    /// 'Right' यस सन्दर्भमा यसको अर्थ बाइट स्ट्रि ofको अन्तिम स्थिति;अरबी वा हिब्रू जस्तो भाषाको लागि जुन 'बायाँ देखि दायाँ' भन्दा 'दायाँ देखि बायाँ' हुन्छन्, यो _left_ पक्ष हो, दायाँ होईन।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// बारम्बार हटाइएको बान्कीसँग मेल खाने सबै उपसर्ग र प्रत्ययहरूको साथ स्ट्रिंग स्लाइस दिन्छ।
    ///
    /// [pattern] एक [`char`], [`char`] को एक टुक्रा, वा प्रकार्य वा बन्द हुन सक्दछ कि क्यारेक्टर मेल खाएमा निर्धारण गर्दछ।
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// साधारण ढाँचा:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// एक अधिक जटिल बान्की, क्लोजर प्रयोग गरी:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // प्रारम्भिक ज्ञात म्याच याद गर्नुहोस्, तल यसलाई सुधार गर्नुहोस् यदि
            // अन्तिम खेल फरक छ
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // सुरक्षा: `Searcher` वैध सूचकांक फिर्ता गर्न जानिन्छ।
        unsafe { self.get_unchecked(i..j) }
    }

    /// बारम्बार हटाइएको बान्कीसँग मेल खाने सबै उपसर्गहरूको साथ स्ट्रिंग स्लाइस दिन्छ।
    ///
    /// [pattern] `&str`, [`char`], [`Char`] s को एक टुक्रा, वा प्रकार्य वा बन्द हुन सक्दछ कि क्यारेक्टर मेल खायो भने निर्धारण गर्दछ।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # पाठ दिशात्मकता
    ///
    /// स्ट्रि बाइट्सको अनुक्रम हो।
    /// `start` यस सन्दर्भमा भनेको बाइट स्ट्रि ofको पहिलो स्थिति हो;अंग्रेजी वा रूसी जस्तो बायाँ-देखि-दायाँ भाषाको लागि, यो बाँया पट्टि हुनेछ, र दायाँ-देखि-बाँया भाषाहरू जस्तै अरबी वा हिब्रूको लागि, यो दायाँ पट्टि हुनेछ।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // सुरक्षा: `Searcher` वैध सूचकांक फिर्ता गर्न जानिन्छ।
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// उपसर्ग हटाइएको एक स्ट्रिंग स्लाइस फर्काउँछ।
    ///
    /// यदि स्ट्रि `prefix` ढाँचासँग शुरू भयो भने, `Some` मा लपेटेर उपसर्ग पछि स्ट्रिंग फर्किन्छ।
    /// `trim_start_matches` विपरीत, यस विधिले उपसर्गलाई ठीक एकचोटि हटाउँदछ।
    ///
    /// यदि स्ट्रिंग `prefix` को साथ शुरू भएन भने, `None` फर्काउँछ।
    ///
    /// [pattern] `&str`, [`char`], [`Char`] s को एक टुक्रा, वा प्रकार्य वा बन्द हुन सक्दछ कि क्यारेक्टर मेल खायो भने निर्धारण गर्दछ।
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// प्रत्यय हटाईएको साथ स्ट्रिंग स्लाइस फर्काउँछ।
    ///
    /// यदि स्ट्रि `suffix` ढाँचाको साथ समाप्त हुन्छ भने, `Some` मा बेर्नु को लागी प्रत्यय पहिले सब स्ट्रिंग, फर्काउँछ।
    /// `trim_end_matches` विपरीत, यस विधिले प्रत्यय ठीक एक पटक हटाउँछ।
    ///
    /// यदि स्ट्रि X `suffix` को साथ समाप्त हुँदैन भने, `None` फर्काउँछ।
    ///
    /// [pattern] `&str`, [`char`], [`Char`] s को एक टुक्रा, वा प्रकार्य वा बन्द हुन सक्दछ कि क्यारेक्टर मेल खायो भने निर्धारण गर्दछ।
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// बारम्बार हटाइएको बान्कीसँग मेल खाने सबै प्रत्ययको साथ स्ट्रिंग स्लाइस दिन्छ।
    ///
    /// [pattern] `&str`, [`char`], [`Char`] s को एक टुक्रा, वा प्रकार्य वा बन्द हुन सक्दछ कि क्यारेक्टर मेल खायो भने निर्धारण गर्दछ।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # पाठ दिशात्मकता
    ///
    /// स्ट्रि बाइट्सको अनुक्रम हो।
    /// `end` यस सन्दर्भमा यसको अर्थ बाइट स्ट्रि ofको अन्तिम स्थिति;अंग्रेजी वा रूसी जस्तो देब्रे-देखि-दाँया भाषाको लागि, यो दायाँ पट्टि हुनेछ, र अरबी वा हिब्रू जस्ता दायाँ-देखि-बाँया भाषाहरूको लागि, यो बायाँ तर्फ हुनेछ।
    ///
    ///
    /// # Examples
    ///
    /// साधारण ढाँचा:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// एक अधिक जटिल बान्की, क्लोजर प्रयोग गरी:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // सुरक्षा: `Searcher` वैध सूचकांक फिर्ता गर्न जानिन्छ।
        unsafe { self.get_unchecked(0..j) }
    }

    /// बारम्बार हटाइएको बान्कीसँग मेल खाने सबै उपसर्गहरूको साथ स्ट्रिंग स्लाइस दिन्छ।
    ///
    /// [pattern] `&str`, [`char`], [`Char`] s को एक टुक्रा, वा प्रकार्य वा बन्द हुन सक्दछ कि क्यारेक्टर मेल खायो भने निर्धारण गर्दछ।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # पाठ दिशात्मकता
    ///
    /// स्ट्रि बाइट्सको अनुक्रम हो।
    /// 'Left' यस सन्दर्भमा भनेको बाइट स्ट्रि ofको पहिलो स्थिति हो;अरबी वा हिब्रू जस्तो भाषाको लागि जुन 'दायाँ देखि बाँया' बरु 'बायाँ देखि दायाँ' को लागी, यो _right_ तर्फ, बायाँ होइन।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// बारम्बार हटाइएको बान्कीसँग मेल खाने सबै प्रत्ययको साथ स्ट्रिंग स्लाइस दिन्छ।
    ///
    /// [pattern] `&str`, [`char`], [`Char`] s को एक टुक्रा, वा प्रकार्य वा बन्द हुन सक्दछ कि क्यारेक्टर मेल खायो भने निर्धारण गर्दछ।
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # पाठ दिशात्मकता
    ///
    /// स्ट्रि बाइट्सको अनुक्रम हो।
    /// 'Right' यस सन्दर्भमा यसको अर्थ बाइट स्ट्रि ofको अन्तिम स्थिति;अरबी वा हिब्रू जस्तो भाषाको लागि जुन 'बायाँ देखि दायाँ' भन्दा 'दायाँ देखि बायाँ' हुन्छन्, यो _left_ पक्ष हो, दायाँ होईन।
    ///
    ///
    /// # Examples
    ///
    /// साधारण ढाँचा:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// एक अधिक जटिल बान्की, क्लोजर प्रयोग गरी:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// यस प्रकारको स्लाइसलाई अर्को प्रकारमा पार्स गर्दछ।
    ///
    /// किनभने `parse` यति सामान्य छ, यसले प्रकारको अनुमानको साथ समस्या उत्पन्न गर्न सक्छ।
    /// त्यस्तै, `parse` केहि पटक हो तपाईंले सिन्ट्याक्सलाई मायालु तरिकाले 'turbofish' भनेर चिनिनुहुनेछ: `::<>`.
    ///
    /// यसले अनुमान एल्गोरिथ्मलाई विशेष रूपमा बुझ्न कुन प्रकारको तपाइँ पार्स गर्न खोज्नु भएको छ भनेर मद्दत गर्दछ।
    ///
    /// `parse` [`FromStr`] trait कार्यान्वयन गर्ने कुनै पनि प्रकारमा पार्स गर्न सक्दछ।
    ///

    /// # Errors
    ///
    /// [`Err`] फर्काउँछ यदि यो स्ट्रिंग स्लाइसलाई इच्छित प्रकारमा पार्स गर्न सम्भव छैन।
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// `four` लाई एनोटेट गर्नुको सट्टा 'turbofish' प्रयोग गर्दै:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// पार्स गर्न असफल:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// जाँच गर्दछ कि यदि यो स्ट्रि inमा सबै अक्षरहरू ASCII दायरा भित्रै छन्।
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // हामी प्रत्येक बाइटलाई यहाँ चरित्रको रूपमा व्यवहार गर्न सक्छौं: सबै मल्टबाइट अक्षरहरू बाइटसँग सुरु हुन्छन् जुन एस्की दायरामा हुँदैन, त्यसैले हामी पहिले नै त्यहाँ रोक्नेछौं।
        //
        //
        self.as_bytes().is_ascii()
    }

    /// दुई स्ट्रिंगहरू ASCII केस-असंवेदनशील खेल हो भनेर जाँच गर्दछ।
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` को रूपमा उस्तै, तर अस्थायी वाटप र प्रतिलिपि बिना।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// यस स्ट्रि itsलाई यसको ASCII अपर केसमा बराबर स्थानमा रूपान्तरण गर्दछ।
    ///
    /// 'z' लाई 'a' लाई ASCII अक्षरहरू 'A' लाई 'Z' मा म्याप गरिएको छ, तर गैर-ASCII अक्षर परिवर्तन गरिएको छैन।
    ///
    /// अवस्थित एकलाई परिमार्जन नगरी नयाँ ठूलो ठूलो मान फर्काउन [`to_ascii_uppercase()`] प्रयोग गर्नुहोस्।
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // सुरक्षा: सुरक्षित किनकि हामी एकै रूपरेखाको साथ दुई प्रकारका ट्रान्समिट गर्दछौं।
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// यस स्ट्रि its लाई यसको ASCII लोअर केस सम स्थानमा बदल्छ।
    ///
    /// 'Z' लाई 'A' लाई ASCII अक्षरहरू 'a' लाई 'z' मा म्याप गरिएको छ, तर गैर-ASCII अक्षर परिवर्तन गरिएको छैन।
    ///
    /// अवस्थित एकलाई परिमार्जन नगरी नयाँ लोअरकेस मान फिर्ता गर्न [`to_ascii_lowercase()`] प्रयोग गर्नुहोस्।
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // सुरक्षा: सुरक्षित किनकि हामी एकै रूपरेखाको साथ दुई प्रकारका ट्रान्समिट गर्दछौं।
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// एक पुनरावृत्तकर्ता फिर्ता गर्नुहोस् जुन `self` मा [`char::escape_debug`] को साथमा प्रत्येक चारमा जान्छ।
    ///
    ///
    /// Note: केवल विस्तारित ग्राफीम कोडेपोइन्टहरू स्ट्रि begin सुरु हुन्छ भने सुरक्षित हुन्छ।
    ///
    /// # Examples
    ///
    /// एक पुनरावृतकर्ताको रूपमा:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` सीधा प्रयोग गर्दै:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// दुबै बराबर हुन्:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// `to_string` प्रयोग गर्दै:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// एक पुनरावृत्तकर्ता फिर्ता गर्नुहोस् जुन `self` मा [`char::escape_default`] को साथमा प्रत्येक चारमा जान्छ।
    ///
    ///
    /// # Examples
    ///
    /// एक पुनरावृतकर्ताको रूपमा:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` सीधा प्रयोग गर्दै:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// दुबै बराबर हुन्:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// `to_string` प्रयोग गर्दै:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// एक पुनरावृत्तकर्ता फिर्ता गर्नुहोस् जुन `self` मा [`char::escape_unicode`] को साथमा प्रत्येक चारमा जान्छ।
    ///
    ///
    /// # Examples
    ///
    /// एक पुनरावृतकर्ताको रूपमा:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` सीधा प्रयोग गर्दै:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// दुबै बराबर हुन्:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// `to_string` प्रयोग गर्दै:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// खाली str बनाउँछ
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// खाली म्युटेबल स्ट्रि सिर्जना गर्दछ
    #[inline]
    fn default() -> Self {
        // सुरक्षा: खाली स्ट्रिंग UTF-8 मान्य छ।
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// एक नाम, क्लोनेबल fn प्रकार
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // सुरक्षा: सुरक्षित छैन
        unsafe { from_utf8_unchecked(bytes) }
    };
}