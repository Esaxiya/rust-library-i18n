//! बाइट स्लाइसबाट `str` सिर्जना गर्ने तरिकाहरू।

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// बाइटको टुक्रालाई स्ट्रि sl स्लाइसमा रूपान्तरण गर्दछ।
///
/// स्ट्रि sl स्लाइस ([`&str`]) बाइट्स ([`u8`]) बाट बनेको छ, र बाइट स्लाइस ([`&[u8]`][byteslice]) बाइट्स बाट बनेको छ, त्यसैले यो प्रकार्य दुई बीच बदल्छ।
/// सबै बाइट स्लाइसहरू मान्य स्ट्रिंग स्लाइसहरू छैनन्, तथापि: [`&str`] लाई यो मान्य UTF-8 हुन आवश्यक छ।
/// `from_utf8()` बाइट्स मान्य UTF-8 छन् भनेर निश्चित गर्न जाँच गर्दछ, र त्यसपछि रूपान्तरण गर्दछ।
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// यदि तपाइँ निश्चित हुनुहुन्छ कि बाइट स्लाइस वैध UTF-8 हो, र तपाइँ वैधता जाँचको ओभरहेड लगाउन चाहनुहुन्न भने, त्यहाँ यो प्रकार्यको असुरक्षित संस्करण छ, [`from_utf8_unchecked`], समान व्यवहार छ तर चेक छोड्छ।
///
///
/// यदि तपाईंलाई `&str` को सट्टामा `String` चाहिएको छ भने, [`String::from_utf8`][string] विचार गर्नुहोस्।
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// किनभने तपाईं स्ट्याक-आवंटन गर्न सक्नुहुनेछ `[u8; N]`, र तपाईं यसको एक [`&[u8]`][byteslice] लिन सक्नुहुनेछ, यो प्रकार्य स्ट्याक-आवंटित स्ट्रि haveको एक तरीका हो।तल उदाहरण अनुभागमा यसको एक उदाहरण छ।
///
/// [byteslice]: slice
///
/// # Errors
///
/// यदि स्लाइस UTF-8 छैन भने किन प्रदान गरिएको स्लाइस UTF-8 छैन भनेर वर्णनको साथ `Err` फर्काउँछ।
///
/// # Examples
///
/// आधारभूत उपयोग:
///
/// ```
/// use std::str;
///
/// // केहि बाइट्स, vector मा
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // हामीलाई थाहा छ कि यी बाइट्स मान्य छन्, त्यसैले मात्र `unwrap()` प्रयोग गर्नुहोस्।
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// गलत बाइट्स:
///
/// ```
/// use std::str;
///
/// // केहि अवैध बाइट्स, vector मा
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// कागजातहरू [`Utf8Error`] का लागि हेर्नुहोस् त्रुटिहरूको प्रकारहरूमा फर्केर हेर्न सकिन्छ।
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // केहि बाइट्स, स्ट्याक-विनियोजित एर्रेमा
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // हामीलाई थाहा छ कि यी बाइट्स मान्य छन्, त्यसैले मात्र `unwrap()` प्रयोग गर्नुहोस्।
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // सुरक्षा: भर्खरै चलेको प्रमाणीकरण।
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// बाइट्सको म्यूटेबल स्लाइसलाई म्यूटेबल स्ट्रि sl स्लाइसमा रूपान्तरण गर्दछ।
///
/// # Examples
///
/// आधारभूत उपयोग:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" एक परिवर्तनीय vector को रूपमा
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // जस्तो कि हामीलाई थाहा छ यी बाइट्स मान्य छन्, हामी `unwrap()` प्रयोग गर्न सक्दछौं
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// गलत बाइट्स:
///
/// ```
/// use std::str;
///
/// // एक अवैध vector मा केहि अमान्य बाइट्स
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// कागजातहरू [`Utf8Error`] का लागि हेर्नुहोस् त्रुटिहरूको प्रकारहरूमा फर्केर हेर्न सकिन्छ।
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // सुरक्षा: भर्खरै चलेको प्रमाणीकरण।
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// बाइट्सको स्लाइसलाई स्ट्रिंग स्लाइसमा रूपान्तरण गर्दछ कि स्ट्रि validमा मान्य UTF-8 समावेश छ।
///
/// अधिक जानकारीको लागि सुरक्षित संस्करण, [`from_utf8`] हेर्नुहोस्।
///
/// # Safety
///
/// यो प्रकार्य असुरक्षित छ किनकि यसले जाँच गरिरहेको छैन कि यसलाई पारित बाइट्स मान्य UTF-8 हुन्।
/// यदि यो अवरोध उल्ल .्घन गरियो भने, अपरिभाषित व्यवहार परिणामहरू, बाँकी Rust ले मान्दछ कि [`&str`] s मान्य UTF-8 हो।
///
///
/// [`&str`]: str
///
/// # Examples
///
/// आधारभूत उपयोग:
///
/// ```
/// use std::str;
///
/// // केहि बाइट्स, vector मा
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // सुरक्षा: कलरले ग्यारेन्टी गर्नु पर्छ कि बाइट्स `v` मान्य UTF-8 छन्।
    // `&str` र `&[u8]` समान लेआउटमा निर्भर गर्दछ।
    unsafe { mem::transmute(v) }
}

/// बाइट्सको स्लाइसलाई स्ट्रिंग स्लाइसमा रूपान्तरण नगरीकन स्ट्रिंगमा मान्य UTF-8 समावेश गर्दछ;परिवर्तनीय संस्करण।
///
///
/// अधिक जानकारीको लागि अपरिवर्तनीय संस्करण, [`from_utf8_unchecked()`] हेर्नुहोस्।
///
/// # Examples
///
/// आधारभूत उपयोग:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // सुरक्षा: कलरले ग्यारेन्टी गर्नै पर्छ कि बाइट्स `v`
    // मान्य UTF-8 हुन्, त्यसैले `*mut str` मा कास्ट सुरक्षित छ।
    // साथै, पोइन्टर डिरेफरेसन सुरक्षित छ किनकि त्यो पोइन्टर सन्दर्भबाट आउँछ जुन लेख्नको लागि मान्य हुने ग्यारेन्टी हो।
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}