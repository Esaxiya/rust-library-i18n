//! UTF-8 मान्यीकरणसँग सम्बन्धित अपरेसनहरू।

use crate::mem;

use super::Utf8Error;

/// पहिलो बाइटको लागि प्रारम्भिक कोडेपोइन्ट संचयीक फर्काउँछ।
/// पहिलो बाइट विशेष हो, केवल चौडाई २ को लागि bottom बिटहरू, चौडाई for को लागि b बिट, र चौडाइ 4 को लागि b बिटहरू मात्र चाहान्छन्।
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// `ch` को मान निरन्तरता बाइट `byte` को साथ अपडेट भएको मान फर्काउँछ।
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// बाइट एक UTF-8 निरन्तरता बाइट हो कि होइन जाँच गर्दछ (जस्तै, बिट्स `10` बाट सुरू हुन्छ)।
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// अर्को कोड पोइन्टलाई बाइट इट्रेटरको बाहिर पढ्दछ (एक यूटीएफ-ing-जस्तो एन्कोडि ass स्वीकार गर्दै)।
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // डिकोड UTF-8
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // मल्टबाइटे केसले बाइट संयोजनबाट डिकोड निम्न अनुसरण गर्दछ: [[[x y] z] w]
    //
    // NOTE: प्रदर्शन यहाँ सटीक निर्माण को लागी संवेदनशील छ
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] w] केस
        // 0xE0 मा पाँचौं बिट .. 0xEF सँधै स्पष्ट हुन्छ, त्यसैले `init` अझै मान्य छ
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] केस मात्र `init` को कम 3 बिट्स को उपयोग गर्नुहोस्
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// बाइट इटरेटरको अन्तिम कोड पोइन्ट पढ्दछ (एक यूटीएफ-8-जस्तो एन्कोडि ass स्वीकार गर्दै)।
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // डिकोड UTF-8
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // मल्टबाइटे केसले बाइट संयोजनबाट डिकोड निम्न पछाडि: [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// u64 फिट गर्न काटि प्रयोग गर्नुहोस्
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// `true` फर्काउँदछ यदि `x` शब्दमा कुनै बाइट भने nonascii (>=128) हो।
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// `v` जाँचको माध्यमबाट हिड्छ कि यो एक मान्य UTF-8 अनुक्रम हो, `Ok(())` फिर्ता त्यो अवस्थामा, वा, यदि यो अवैध छ भने, `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // हामीलाई डाटा चाहिएको थियो, तर त्यहाँ कुनै पनि थिएन: त्रुटि!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // २-बाइट ईन्कोडिंग कोडेपोइन्ट्स\u {०{०}} बाट\u {07ff} पहिलो C2 80० अन्तिम अन्तिम DF BF को लागि हो
            // - बाइट ईन्कोडिंग कोडेपोइन्ट्स\u {०00०} बाट\u {ffff for को लागि हो E0 X A0 last० अन्तिम EF BF BF surrogates codipPoint\u {d800} बाट D u {dfff} ED A0 80 देखि ED BF BF को लागि बाहेक
            // - बाइट ईन्कोडिंग कोडेपोइन्टको लागि हो\u {१०००} ० देखि {u {१०ff} ff पहिलो F0 80० 80० last० अन्तिम F4 8F BF BF
            //
            // आरएफसीबाट UTF-8 सिन्ट्याक्स प्रयोग गर्नुहोस्
            //
            // https://tools.ietf.org/html/rfc3629
            // UTF8-1=% x00-7F UTF8-2=% xC2-DF UTF8-TEE UTF8-3= %xE0% xA0-BF UTF8-ਪੂਛ/% xE1-EC 2( UTF8-tail )/%xED% x80-9F UTF8-टेल/% xEE-EF 2( UTF8-tail ) UTF8-4= %xF0% x90-BF 2( UTF8-tail )/% xF1-F3 3( UTF8-tail )/%xF4% x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // Ascii केस, छिटो अगाडि बढ्ने प्रयास गर्नुहोस्।
            // जब सूचक पigned्क्तिबद्ध हुन्छ, प्रति पुनरावृत्तिमा डेटाका २ शब्दहरू पढ्नुहोस् जबसम्म हामीले गैर-एस्कि बाइट समावेश भएको शब्द फेला पार्दैनौं।
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // सुरक्षा: किनकि `align - index` र `ascii_block_size` हो
                    // `usize_bytes`, `block = ptr.add(index)` को गुणनहरू सँधै `usize` संग प .्क्तिबद्ध हुन्छ त्यसैले यो दुबै `block` र `block.offset(1)` लाई डेरेफर गर्न सुरक्षित छ।
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // यदि त्यहाँ एक nonascii बाइट छ तोड्न
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // बिन्दुबाट चरणमा जहाँ वर्डवाइज लूप रोकिन्छ
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// पहिलो बाइट दिईयो, यो UTF-8 क्यारेक्टरमा कति बाइटहरू छन् भन्ने निर्धारण गर्दछ।
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// एक निरंतरता बाइटको मान बिट्सको मास्क।
const CONT_MASK: u8 = 0b0011_1111;
/// एक निरन्तरता बाइटको ट्याग बिट्सको मान (ट्याग मास्क !CONT_MASK हो)।
const TAG_CONT_U8: u8 = 0b1000_0000;

// अधिकतम `max` फिर्ता `true` बराबर लम्बाइमा `&str` काट्नुहोस् यदि यसलाई काटिएको थियो भने, र नयाँ str।
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}