//! utf8 त्रुटि प्रकार परिभाषित गर्दछ।

use crate::fmt;

/// [`u8`] को अनुक्रमलाई स्ट्रि asको रूपमा व्याख्या गर्ने प्रयास गर्दा त्रुटि देखा पर्न सक्दछ।
///
/// त्यस्तै रूपमा, दुबै [`String`] s र [`&str`] s को लागि कार्य र विधिहरूको `from_utf8` परिवारले यो त्रुटि प्रयोग गर्दछ, उदाहरणका लागि।
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// यस त्रुटि प्रकारका विधिहरू हेप मेमोरी विनियोजन नगरी `String::from_utf8_lossy` सँग समान कार्यक्षमता सिर्जना गर्न प्रयोग गर्न सकिन्छ:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// दिइएको स्ट्रिंगमा अनुक्रमणिका फर्काउँछ जुन मान्य UTF-8 प्रमाणित गरिएको थियो।
    ///
    /// यो अधिकतम अनुक्रमणिका हो कि `from_utf8(&input[..index])` `Ok(_)` फर्काउँछ।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// use std::str;
    ///
    /// // केहि अवैध बाइट्स, vector मा
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 एक Utf8Error फर्काउँछ
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // दोस्रो बाइट यहाँ अवैध छ
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// असफलताको बारेमा अधिक जानकारी प्रदान गर्दछ:
    ///
    /// * `None`: इनपुटको अन्त्य अप्रत्याशित रूपमा पुगेको थियो।
    ///   `self.valid_up_to()` इनपुटको अन्त्यबाट १ देखि by बाइट्स छ।
    ///   यदि एक बाइट स्ट्रिम (जस्तै एक फाईल वा नेटवर्क सकेट) बढि डिकोड भइरहेको छ भने, यो एक मान्य `char` हुन सक्छ जसको UTF-8 बाइट अनुक्रम बहुविध भाग फ्याँकदै छ।
    ///
    ///
    /// * `Some(len)`: एक अप्रत्याशित बाइट सामना भयो।
    ///   प्रदान गरिएको लम्बाइ अवैध बाइट अनुक्रमको हो जुन `valid_up_to()` द्वारा दिइएको सूचकांकमा सुरु हुन्छ।
    ///   हानिकारक डिकोडिंगको अवस्थामा त्यो अनुक्रम पछि [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] X सम्मिलित गरेपछि डिकोडिंग फेरि सुरु हुन सक्दछ।
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// [`from_str`] विफल हुँदा `bool` पार्स गर्दा त्रुटि भयो
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}