//! ASCII तार र वर्णहरूमा अपरेशनहरू।
//!
//! Rust मा अधिक स्ट्रिंग अपरेशनहरू UTF-8 तारहरूमा कार्य गर्दछ।
//! जे होस्, कहिलेकाँही यसले खास अपरेशनको लागि ASCII क्यारेक्टर सेटलाई मात्र विचार गर्न अधिक समझदारी गर्दछ।
//!
//! [`escape_default`] प्रकार्य दिइएको वर्णको एक एस्केप संस्करणको बाइट्समा इटरेटर प्रदान गर्दछ।
//!
//!

#![stable(feature = "core_ascii", since = "1.26.0")]

use crate::fmt;
use crate::iter::FusedIterator;
use crate::ops::Range;
use crate::str::from_utf8_unchecked;

/// एक बाइटको भागिएको संस्करणमा एक पुनरावृत्तिकर्ता।
///
/// यो `struct` [`escape_default`] प्रकार्य द्वारा बनाईएको हो।
/// अधिकको लागि यसको कागजात हेर्नुहोस्।
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct EscapeDefault {
    range: Range<usize>,
    data: [u8; 4],
}

/// एक पुनरावर्तन फर्काउँछ जुन `u8` को एक एस्केड संस्करण उत्पादन गर्दछ।
///
/// पूर्वनिर्धारित शाब्दिक उत्पादनको प्रति पूर्वाग्रहको साथ छनौट गरियो जुन C++ 11 र समान C-पारिवारिक भाषाहरू सहित विभिन्न भाषाहरूमा कानूनी हुन्छ।
/// सहि नियमहरू:
///
/// * ट्याब `\t` को रूपमा भाग्यो।
/// * क्यारिज रिटर्न `\r` को रूपमा भाग्यो।
/// * लाइन फिड `\n` को रूपमा भाग्यो।
/// * एकल उद्धरण `\'` को रूपमा भाग्यो।
/// * डबल उद्धरण `\"` को रूपमा भाग्यो।
/// * ब्याकस्लेश `\\` को रूपमा भाग्यो।
/// * 'मुद्रण योग्य ASCII' दायरा `0x20` मा कुनै पनि वर्ण .. `0x7e` समावेशी उम्कन छैन।
/// * कुनै पनि अन्य वर्णहरूलाई हेक्स एस्केप फारम '\xNN' दिइन्छ।
/// * युनिकोड एस्केपहरू कहिले पनि यो प्रकार्यले उत्पन्न गर्दैन।
///
/// # Examples
///
/// ```
/// use std::ascii;
///
/// let escaped = ascii::escape_default(b'0').next().unwrap();
/// assert_eq!(b'0', escaped);
///
/// let mut escaped = ascii::escape_default(b'\t');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b't', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\r');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'r', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\n');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'n', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\'');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'\'', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'"');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'"', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\\');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'\\', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\x9d');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'x', escaped.next().unwrap());
/// assert_eq!(b'9', escaped.next().unwrap());
/// assert_eq!(b'd', escaped.next().unwrap());
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn escape_default(c: u8) -> EscapeDefault {
    let (data, len) = match c {
        b'\t' => ([b'\\', b't', 0, 0], 2),
        b'\r' => ([b'\\', b'r', 0, 0], 2),
        b'\n' => ([b'\\', b'n', 0, 0], 2),
        b'\\' => ([b'\\', b'\\', 0, 0], 2),
        b'\'' => ([b'\\', b'\'', 0, 0], 2),
        b'"' => ([b'\\', b'"', 0, 0], 2),
        b'\x20'..=b'\x7e' => ([c, 0, 0, 0], 1),
        _ => ([b'\\', b'x', hexify(c >> 4), hexify(c & 0xf)], 4),
    };

    return EscapeDefault { range: 0..len, data };

    fn hexify(b: u8) -> u8 {
        match b {
            0..=9 => b'0' + b,
            _ => b'a' + b - 10,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Iterator for EscapeDefault {
    type Item = u8;
    fn next(&mut self) -> Option<u8> {
        self.range.next().map(|i| self.data[i])
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.range.size_hint()
    }
    fn last(mut self) -> Option<u8> {
        self.next_back()
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl DoubleEndedIterator for EscapeDefault {
    fn next_back(&mut self) -> Option<u8> {
        self.range.next_back().map(|i| self.data[i])
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ExactSizeIterator for EscapeDefault {}
#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for EscapeDefault {}

#[stable(feature = "ascii_escape_display", since = "1.39.0")]
impl fmt::Display for EscapeDefault {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // सुरक्षा: ठीक छ किनभने `escape_default` ले वैध utf-8 डाटा मात्र सिर्जना गर्दछ
        f.write_str(unsafe { from_utf8_unchecked(&self.data[self.range.clone()]) })
    }
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for EscapeDefault {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("EscapeDefault { .. }")
    }
}