use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// *उत्तराधिकारी* र *पूर्ववर्ती* अपरेशनहरूको धारणा रहेको वस्तुहरू।
///
/// *उत्तराधिकारी* अपरेशन मानहरूतर्फ बढ्छ जुन अधिक तुलना गर्दछ।
/// *पूर्ववर्ती* अपरेशन मानहरू तर्फ बढ्छ जुन कम तुलना गर्दछ।
///
/// # Safety
///
/// यो trait `unsafe` हो किनभने यसको कार्यान्वयन `unsafe trait TrustedLen` कार्यान्वयनको सुरक्षाको लागि सही हुनुपर्दछ, र यो trait प्रयोग गर्ने नतिजा अन्यथा `unsafe` कोड द्वारा विश्वास गर्न सकिन्छ सही हुन र सूचीबद्ध दायित्वहरू पूरा गर्न।
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// `start` बाट `end` सम्म प्राप्त गर्न *उत्तराधिकारी* चरणहरूको संख्या फर्काउँछ।
    ///
    /// `None` फर्काउँछ यदि चरणहरूको संख्या `usize` ओभरफ्लो हुन्छ (वा असीम छ, वा यदि `end` कहिले सम्म पुग्न सकेन)।
    ///
    ///
    /// # Invariants
    ///
    /// कुनै पनि `a`, `b`, र `n` को लागी:
    ///
    /// * `steps_between(&a, &b) == Some(n)` यदि र मात्र यदि `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` यदि र मात्र यदि `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` मात्र यदि `a <= b`
    ///   * Corollary: `steps_between(&a, &b) == Some(0)` यदि `a == b` X मात्र हो भने
    ///   * नोट गर्नुहोस् कि `a <= b` ले _not_ लाई `steps_between(&a, &b) != None` जनाउँदछ;
    ///     यो केस हो जब यो `b` मा जान `usize::MAX` भन्दा बढी चरणहरू चाहिन्छ
    /// * `steps_between(&a, &b) == None` यदि `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// `self` `count` पटकको *उत्तराधिकारी* लिएर प्राप्त हुने मान फर्काउँछ।
    ///
    /// यदि यसले `Self` द्वारा समर्थित मानहरूको दायरा ओभरफ्लो गर्दछ भने, `None` फर्काउँछ।
    ///
    /// # Invariants
    ///
    /// कुनै पनि `a`, `n`, र `m` को लागी:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// कुनै पनि `a`, `n`, र `m` का लागि जहाँ `n + m` ओभरफ्लो छैन:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// कुनै पनि `a` र `n` को लागी:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// `self` `count` पटकको *उत्तराधिकारी* लिएर प्राप्त हुने मान फर्काउँछ।
    ///
    /// यदि यसले `Self` द्वारा समर्थित मानहरूको दायरा ओभरफ्लो गर्दछ भने, यो प्रकार्यलाई panic, र्‍याप, वा संतृप्त गर्न अनुमति दिइन्छ।
    ///
    /// सुझाव गरिएको व्यवहार panic मा हुन्छ जब डिबग एसेर्सन सक्षम हुन्छ, र र्याप वा अन्यथा संतृप्त गर्न।
    ///
    /// असुरक्षित कोड ओवरफ्लो पछि व्यवहारको शुद्धतामा भर पर्दैन।
    ///
    /// # Invariants
    ///
    /// कुनै पनि `a`, `n`, र `m` का लागि, जहाँ कुनै ओभरफ्लो देखा पर्दैन:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// कुनै पनि `a` र `n` का लागि, जहाँ कुनै ओभरफ्लो देखा पर्दैन:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// `self` `count` पटकको *उत्तराधिकारी* लिएर प्राप्त हुने मान फर्काउँछ।
    ///
    /// # Safety
    ///
    /// `Self` द्वारा समर्थित मानहरूको दायरा ओभरफ्लो गर्न यो अपरेशनको लागि यो अपरिभाषित व्यवहार हो।
    /// यदि तपाईं यो ग्यारेन्टी गर्न सक्नुहुन्न कि यो ओभरफ्लो हुनेछैन, यसको सट्टामा `forward` वा `forward_checked` प्रयोग गर्नुहोस्।
    ///
    /// # Invariants
    ///
    /// कुनै पनि `a` को लागी:
    ///
    /// * यदि त्यहाँ `b` त्यस्तो `b > a` अवस्थित छ भने, यो `Step::forward_unchecked(a, 1)` कल गर्न सुरक्षित छ
    /// * यदि त्यहाँ `b`, `n` त्यस्तो `steps_between(&a, &b) == Some(n)` अवस्थित छ भने, कुनै `m <= n` का लागि `Step::forward_unchecked(a, m)` कल गर्न सुरक्षित छ।
    ///
    ///
    /// कुनै पनि `a` र `n` का लागि, जहाँ कुनै ओभरफ्लो देखा पर्दैन:
    ///
    /// * `Step::forward_unchecked(a, n)` `Step::forward(a, n)` बराबर छ
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// `self` `count` पटकको *पूर्ववर्ती* लिएर प्राप्त हुने मान फर्काउँछ।
    ///
    /// यदि यसले `Self` द्वारा समर्थित मानहरूको दायरा ओभरफ्लो गर्दछ भने, `None` फर्काउँछ।
    ///
    /// # Invariants
    ///
    /// कुनै पनि `a`, `n`, र `m` को लागी:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// कुनै पनि `a` र `n` को लागी:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// `self` `count` पटकको *पूर्ववर्ती* लिएर प्राप्त हुने मान फर्काउँछ।
    ///
    /// यदि यसले `Self` द्वारा समर्थित मानहरूको दायरा ओभरफ्लो गर्दछ भने, यो प्रकार्यलाई panic, र्‍याप, वा संतृप्त गर्न अनुमति दिइन्छ।
    ///
    /// सुझाव गरिएको व्यवहार panic मा हुन्छ जब डिबग एसेर्सन सक्षम हुन्छ, र र्याप वा अन्यथा संतृप्त गर्न।
    ///
    /// असुरक्षित कोड ओवरफ्लो पछि व्यवहारको शुद्धतामा भर पर्दैन।
    ///
    /// # Invariants
    ///
    /// कुनै पनि `a`, `n`, र `m` का लागि, जहाँ कुनै ओभरफ्लो देखा पर्दैन:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// कुनै पनि `a` र `n` का लागि, जहाँ कुनै ओभरफ्लो देखा पर्दैन:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// `self` `count` पटकको *पूर्ववर्ती* लिएर प्राप्त हुने मान फर्काउँछ।
    ///
    /// # Safety
    ///
    /// `Self` द्वारा समर्थित मानहरूको दायरा ओभरफ्लो गर्न यो अपरेशनको लागि यो अपरिभाषित व्यवहार हो।
    /// यदि तपाईं यो ग्यारेन्टी गर्न सक्नुहुन्न कि यो ओभरफ्लो हुनेछैन, यसको सट्टामा `backward` वा `backward_checked` प्रयोग गर्नुहोस्।
    ///
    /// # Invariants
    ///
    /// कुनै पनि `a` को लागी:
    ///
    /// * यदि त्यहाँ `b` त्यस्तो `b < a` अवस्थित छ भने, यो `Step::backward_unchecked(a, 1)` कल गर्न सुरक्षित छ
    /// * यदि त्यहाँ `b`, `n` त्यस्तो `steps_between(&b, &a) == Some(n)` अवस्थित छ भने, कुनै `m <= n` का लागि `Step::backward_unchecked(a, m)` कल गर्न सुरक्षित छ।
    ///
    ///
    /// कुनै पनि `a` र `n` का लागि, जहाँ कुनै ओभरफ्लो देखा पर्दैन:
    ///
    /// * `Step::backward_unchecked(a, n)` `Step::backward(a, n)` बराबर छ
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// यी अझै पनि म्याक्रो-उत्पन्न भएका छन् किनकि पूर्णांक अक्षरशः फरक प्रकारहरूमा समाधान गर्दछ।
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // सुरक्षा: कलरले `start + n` ओभरफ्लो नभएको ग्यारेन्टी गर्नु पर्छ।
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // सुरक्षा: कलरले `start - n` ओभरफ्लो नभएको ग्यारेन्टी गर्नु पर्छ।
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // डिबग निर्माणमा, panic ओभरफ्लोमा ट्रिगर गर्नुहोस्।
            // यो रिलीज निर्माणहरूमा पूर्ण रूपले अप्टिमाइज हुनुपर्दछ।
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // उदाहरणका लागि अनुमति दिन गणित र्‍याप गर्नुहोस् `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // डिबग निर्माणमा, panic ओभरफ्लोमा ट्रिगर गर्नुहोस्।
            // यो रिलीज निर्माणहरूमा पूर्ण रूपले अप्टिमाइज हुनुपर्दछ।
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // उदाहरणका लागि अनुमति दिन गणित र्‍याप गर्नुहोस् `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // यो $u_narrower <=usize मा निर्भर गर्दछ
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // यदि एन सीमा भन्दा बाहिर छ, `unsigned_start + n` पनि छ
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // यदि एन सीमा भन्दा बाहिर छ, `unsigned_start - n` पनि छ
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // यो $i_narrower <=usize मा निर्भर गर्दछ
                        //
                        // आईसाइज गर्न कास्टिंगले चौडाई विस्तार गर्दछ तर चिन्ह सुरक्षित गर्दछ।
                        // इसाइज स्पेसमा र्यापि__सब प्रयोग गर्नुहोस् र ईसाइजको दायरा भित्र नहुन सक्ने फरक गणना गर्न युजलाई कास्ट गर्नुहोस्।
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // र्‍यापिंगले `Step::forward(-120_i8, 200) == Some(80_i8)` जस्ता केसहरूलाई ह्यान्डल गर्दछ, जबकि २०० i8 को दायरा भन्दा पर छ।
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // थप ओभरफ्लो भयो
                            }
                        }
                        // यदि एन, उदाहरणको दायरा भन्दा बाहिर छ
                        // u8, त्यसो भए यो i8 को लागी सम्पूर्ण दायरा भन्दा ठूलो छ त्यसैले `any_i8 + n` आवश्यक रूपमा i8 ओभरफ्लो गर्दछ।
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // र्‍यापिंगले `Step::forward(-120_i8, 200) == Some(80_i8)` जस्ता केसहरूलाई ह्यान्डल गर्दछ, जबकि २०० i8 को दायरा भन्दा पर छ।
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // घटाउ ओभरफ्लो भयो
                            }
                        }
                        // यदि एन, उदाहरणको दायरा भन्दा बाहिर छ
                        // u8, त्यसो भए यो i8 को लागी सम्पूर्ण दायरा भन्दा ठूलो छ त्यसैले `any_i8 - n` आवश्यक रूपमा i8 ओभरफ्लो गर्दछ।
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // यदि भिन्नता उदाहरण को लागी धेरै ठूलो छ भने
                            // i128, यो कम बिट्सको साथ प्रयोगको लागि पनि ठूलो हुनेछ।
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // सुरक्षा: res एक मान्य यूनिकोड स्केलर हो
            // (0x110000 मुनि र ०xD800..0xE000 मा होईन)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // सुरक्षा: res एक मान्य यूनिकोड स्केलर हो
        // (0x110000 मुनि र ०xD800..0xE000 मा होईन)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // सुरक्षा: कलरले ग्यारेन्टी गर्नै पर्दछ कि यो ओभरफ्लो हुँदैन
        // चारको लागि मानहरूको दायरा।
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // सुरक्षा: कलरले ग्यारेन्टी गर्नै पर्दछ कि यो ओभरफ्लो हुँदैन
            // चारको लागि मानहरूको दायरा।
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // सुरक्षा: अघिल्लो सम्झौताको कारण, यो ग्यारेन्टी गरिएको छ
        // कलर द्वारा एक मान्य चार हुन।
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // सुरक्षा: कलरले ग्यारेन्टी गर्नै पर्दछ कि यो ओभरफ्लो हुँदैन
        // चारको लागि मानहरूको दायरा।
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // सुरक्षा: कलरले ग्यारेन्टी गर्नै पर्दछ कि यो ओभरफ्लो हुँदैन
            // चारको लागि मानहरूको दायरा।
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // सुरक्षा: अघिल्लो सम्झौताको कारण, यो ग्यारेन्टी गरिएको छ
        // कलर द्वारा एक मान्य चार हुन।
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // सुरक्षा: भर्खरको शर्त जाँच गरियो
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // सुरक्षा: भर्खरको शर्त जाँच गरियो
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// यी म्याक्रोहरूले विभिन्न दायरा प्रकारहरूका लागि `ExactSizeIterator` इम्प्लेसहरू उत्पन्न गर्दछ।
//
// * `ExactSizeIterator::len` सँधै सटीक `usize` फर्काउन आवश्यक छ, त्यसैले कुनै दायरा `usize::MAX` भन्दा लामो हुन सक्दैन।
//
// * `Range<_>` मा पूर्णांक प्रकारका लागि यो `usize` भन्दा सानो वा सानोको प्रकारका मामला हो।
//   `RangeInclusive<_>` मा पूर्णांक प्रकारका लागि यो प्रकारको हो *कडाईले संकुचित*`usize` भन्दा उदाहरणको लागि
//   `(0..=u64::MAX).len()` `u64::MAX + 1` हुनेछ।
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // यी माथिको तर्कको आधारमा इन्कोरक्ट छन्, तर तिनीहरूलाई हटाउँदा ब्रेकि change परिवर्तन हुनेछ किनकि उनीहरू Rust 1.0.0 मा स्थिर थिए।
    // उदाहरणका लागि
    // `(0..66_000_u32).len()` उदाहरणको लागि १--बिट प्लेटफर्महरूमा त्रुटि वा चेतावनी बिना कम्पाइल गर्दछ, तर गलत परिणाम दिन जारी राख्दछ।
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // यी माथिको तर्कको आधारमा इन्कोरक्ट छन्, तर तिनीहरूलाई हटाउँदा ब्रेकि change परिवर्तन हुनेछ किनकि उनीहरू Rust 1.26.0 मा स्थिर थिए।
    // उदाहरणका लागि
    // `(0..=u16::MAX).len()` उदाहरणको लागि १--बिट प्लेटफर्महरूमा त्रुटि वा चेतावनी बिना कम्पाइल गर्दछ, तर गलत परिणाम दिन जारी राख्दछ।
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // सुरक्षा: भर्खरको शर्त जाँच गरियो
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // सुरक्षा: भर्खरको शर्त जाँच गरियो
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // सुरक्षा: भर्खरको शर्त जाँच गरियो
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // सुरक्षा: भर्खरको शर्त जाँच गरियो
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // सुरक्षा: भर्खरको शर्त जाँच गरियो
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // सुरक्षा: भर्खरको शर्त जाँच गरियो
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}