use crate::ops::{ControlFlow, Try};

/// दुबै छेउबाट एलिटर उत्पन्न गर्न सक्षम ईटररेटर।
///
/// `DoubleEndedIterator` कार्यान्वयन गर्ने केहिमा [`Iterator`] लागू गर्ने केहिमा एक अतिरिक्त क्षमता छ: पछाडिबाट `वस्तुहरू पनि लिने क्षमता, साथसाथै अगाडि।
///
///
/// यो याद गर्नु महत्त्वपूर्ण छ कि दुवै र पछाडि दुवै समान दायरामा काम गर्छन्, र क्रस गर्दैनन्: पुनरावृत्ति समाप्त हुन्छ जब उनीहरू बीचमा भेट्छन्।
///
/// [`Iterator`] प्रोटोकोलको समान फेसनमा, एक पटक `DoubleEndedIterator` ले [`next_back()`] X बाट X0X फिर्ता गर्दछ, यसलाई फेरि कल गर्दा वा कहिले पनि [`Some`] फिर्ता हुन सक्दैन।
/// [`next()`] र [`next_back()`] यस उद्देश्यको लागि आदानप्रदान हुन्छ।
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// आधारभूत उपयोग:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// इटरेटरको अन्त्यबाट एलिमेन्ट हटाउँछ र फर्काउँछ।
    ///
    /// `None` फर्काउँछ जब त्यहाँ अधिक तत्वहरू हुँदैनन्।
    ///
    /// [trait-level] कागजातमा अधिक विवरणहरू छन्।
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// एलिमेन्ट्स te DoubleEidedIterator by का विधि द्वारा उत्पन्न तत्वहरू [te Iterator`] का विधिहरू द्वारा उत्पन्न गरिएको भन्दा भिन्न हुन सक्छ:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// `n` एलिमेन्टहरू द्वारा पछाडिबाट इट्रेटर अग्रिम गर्दछ।
    ///
    /// `advance_back_by` [`advance_by`] को उल्टो संस्करण हो।यस विधिले [`next_back`] सम्म [`next_back`] सम्म [`next_back`] सम्म कल गरेर `n` एलिमेन्टहरू [`None`] सामना नगरेसम्म `n` एलिमेन्टहरू उत्सुकतापूर्वक छोड्नेछ।
    ///
    /// `advance_back_by(n)` यदि इट्रेटरले सफलतापूर्वक `n` एलिमेन्ट्सले अगाडि बढ्यो भने [`Ok(())`] फर्काउँदछ, वा [`Err(k)`] यदि [`None`] भेटिएको छ भने, जहाँ `k` एलिमेन्ट्सको स is्ख्या हो जब इन्ट्रेटरहरू एलिमेन्ट्सको अगाडि दौडनु भन्दा पहिले उन्नत हुन्छ (उदाहरणका लागि।
    /// पुनरावृत्ति को लम्बाई)।
    /// नोट गर्नुहोस् कि `k` जहिले पनि `n` भन्दा कम हुन्छ।
    ///
    /// `advance_back_by(0)` कल गर्दा कुनै पनि तत्व खपत गर्दैन र सँधै [`Ok(())`] फर्काउँछ।
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // मात्र `&3` छोडियो
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// पुनरावृत्तीकर्ताको अन्त्यबाट `n`th एलिमेन्ट फर्काउँछ।
    ///
    /// यो अनिवार्य रूपमा [`Iterator::nth()`] को उलट संस्करण हो।
    /// जे होस् प्राय जसो अनुक्रमणिका अपरेसनहरू जस्तै, गणना शून्यबाट सुरू हुन्छ, त्यसैले `nth_back(0)` अन्त्यबाट पहिलो मान फर्काउँछ, दोस्रो `nth_back(1)` दोस्रो, र त्यस्तै।
    ///
    ///
    /// नोट गर्नुहोस् कि रिटर्न एलिमेन्ट सहित अन्त र रिटर्न एलिमेन्ट बीचको सबै तत्वहरू खपत हुनेछन्।
    /// यसको मतलब यो छ कि `nth_back(0)` एकै पटकमा एउटै इटरेटरमा कल गर्दा बिभिन्न तत्वहरू फर्काउँछ।
    ///
    /// `nth_back()` [`None`] फिर्ता गर्नेछ यदि `n` पुनरावृत्तिको लम्बाई भन्दा ठूलो वा बराबर छ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// `nth_back()` बहु पटक कल गर्दा ईटररेटर रिवाइन्ड हुँदैन:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// `None` फिर्ता गर्दै यदि `n + 1` भन्दा कम तत्वहरू छन् भने:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// यो [`Iterator::try_fold()`] को रिभर्स संस्करण हो: यसले एट्रेटरको पछाडिबाट सुरु हुने तत्वहरू लिन्छ।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // किनकि यो छोटो सर्किट गरिएको छ, बाँकी तत्त्वहरू अझै पनी ईरेटरको माध्यमबाट उपलब्ध छन्।
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// एक पुनरावृत्ति विधि जसले पछाडिबाट शुरू गर्दै, एकल, अन्तिम मानमा इट्रेटरको तत्त्वहरूलाई कम गर्दछ।
    ///
    /// यो [`Iterator::fold()`] को रिभर्स संस्करण हो: यसले एट्रेटरको पछाडिबाट सुरु हुने तत्वहरू लिन्छ।
    ///
    /// `rfold()` दुई आर्गुमेन्टहरू लिन्छ: एक प्रारंभिक मान, र दुई आर्गुमेन्टहरूको साथ बन्द: एक 'accumulator', र एक एलिमेन्ट।
    /// क्लोजरले मानलाई फर्काउँछ जुन इक्युमेटरले अर्को पुनरावृत्तिको लागि हुनुपर्दछ।
    ///
    /// प्रारम्भिक मान पहिलो मानमा स accum्ग्रहणकर्ताको मान हुन्छ।
    ///
    /// यो क्लोजर एट्रेटरको प्रत्येक तत्वमा लागू गरिसकेपछि, `rfold()` संचयकर्तालाई फर्काउँछ।
    ///
    /// यस अपरेशनलाई कहिलेकाँही 'reduce' वा 'inject' पनि भनिन्छ।
    ///
    /// फोल्डि useful उपयोगी छ जब तपाईंसँग केहि चीजको स it्ग्रह हुन्छ, र यसबाट एकल मान सिर्जना गर्न चाहनुहुन्छ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // को तत्वको सबैको योगफल
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// यस उदाहरणले एक स्ट्रि build बनाउँदछ, प्रारम्भिक मानको साथ सुरू गरेर र प्रत्येक तत्वको साथ पछाडि अगाडि सम्म अगाडि बढ्दै:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// पछाडिबाट एक इटररेटरको तत्वको लागि खोजी गर्दछ जुन पूर्वानुमानलाई सन्तुष्टि दिन्छ।
    ///
    /// `rfind()` `true` वा `false` फर्काउने क्लोजर लिन्छ।
    /// यसले यो बन्दकर्ताको प्रत्येक तत्वमा लागू गर्दछ, अन्तबाट सुरू गरेर, र यदि तिनीहरू मध्ये `true` फर्काउँछ, तब `rfind()` ले [`Some(element)`] फर्काउँछ।
    /// यदि तिनीहरू सबै `false` फर्काउँछन्, यसले [`None`] फर्काउँछ।
    ///
    /// `rfind()` छोटो सर्किटिंग हो;अर्को शब्दहरुमा, यसले `true` फर्कने बित्तिकै प्रशोधन गर्न रोकिनेछ।
    ///
    /// किनभने `rfind()` ले सन्दर्भ लिन्छ, र धेरै पुनरावृत्तिहरू सन्दर्भहरूमा पुनरावृत्ति गर्दछ, यसले सम्भावित भ्रमित स्थितितर्फ डो .्याउँछ जहाँ तर्क दोहोरो सन्दर्भ हो।
    ///
    /// तपाईं XTX को साथ तलका उदाहरणहरूमा यो प्रभाव देख्न सक्नुहुनेछ।
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// पहिलो `true` मा रोकिदै:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // हामी अझै पनि `iter` प्रयोग गर्न सक्छौं, किनकि त्यहाँ अधिक तत्वहरू छन्।
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}