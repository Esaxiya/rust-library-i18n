/// एक [`Iterator`] बाट रूपान्तरण।
///
/// एक प्रकारको लागि `FromIterator` कार्यान्वयन गरेर, तपाइँ परिभाषित गर्नुहुन्छ कि यो कसरी एक इट्रेटरबाट सिर्जना गरिने छ।
/// यो प्रकारको लागि सामान्य हो जुन कुनै प्रकारको संग्रह वर्णन गर्दछ।
///
/// [`FromIterator::from_iter()`] विरलै स्पष्ट रूपमा कल गरिन्छ, र यसको सट्टा [`Iterator::collect()`] विधि मार्फत प्रयोग गरिन्छ।
///
/// अधिक उदाहरणका लागि [`Iterator::collect()`]'s कागजात हेर्नुहोस्।
///
/// यो पनि हेर्नुहोस्: [`IntoIterator`].
///
/// # Examples
///
/// आधारभूत उपयोग:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// स्पष्ट रूपमा `FromIterator` प्रयोग गर्न [`Iterator::collect()`] प्रयोग गर्दै:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// तपाइँको प्रकारको लागि `FromIterator` कार्यान्वयन गर्दै:
///
/// ```
/// use std::iter::FromIterator;
///
/// // एउटा नमूना स that's्ग्रह, त्यो Vec मा मात्र एउटा आवरण हो<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // यसलाई केहि तरिकाहरू दिनुहोस् ताकि हामी एउटा सिर्जना गर्न सक्दछौं र यसमा चीजहरू थप्न सक्छौं।
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // र हामी FromIterator लागू गर्नेछौं
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // अब हामी नयाँ ईरेटर गर्न सक्छौं ...
/// let iter = (0..5).into_iter();
///
/// // ... र यसबाट मेरो कलेक्सन बनाउनुहोस्
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // कामहरू पनि संकलन गर्नुहोस्!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// एक इटरेटरबाट मान सिर्जना गर्दछ।
    ///
    /// अधिकको लागि [module-level documentation] हेर्नुहोस्।
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// एक [`Iterator`] मा रूपान्तरण।
///
/// एक प्रकारको लागि `IntoIterator` कार्यान्वयन गरेर, तपाइँ परिभाषित गर्नुहुन्छ कि यसलाई कसरी एक इट्रेटरमा रूपान्तरण गरिनेछ।
/// यो प्रकारको लागि सामान्य हो जुन कुनै प्रकारको संग्रह वर्णन गर्दछ।
///
/// `IntoIterator` कार्यान्वयनको एक लाभ यो हो कि तपाइँको प्रकार [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) हुन्छ।
///
///
/// यो पनि हेर्नुहोस्: [`FromIterator`].
///
/// # Examples
///
/// आधारभूत उपयोग:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// तपाइँको प्रकारको लागि `IntoIterator` कार्यान्वयन गर्दै:
///
/// ```
/// // एउटा नमूना स that's्ग्रह, त्यो Vec मा मात्र एउटा आवरण हो<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // यसलाई केहि तरिकाहरू दिनुहोस् ताकि हामी एउटा सिर्जना गर्न सक्दछौं र यसमा चीजहरू थप्न सक्छौं।
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // र हामी IntoIterator लागू गर्नेछौं
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // अब हामी नयाँ संग्रह गर्न सक्छौं ...
/// let mut c = MyCollection::new();
///
/// // ... यसमा केहि सामान थप्नुहोस् ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... र त्यसपछि यसलाई एक Iterator मा बदल्नुहोस्:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// यो `IntoIterator` trait bound को रूप मा प्रयोग गर्न सामान्य छ।यसले इनपुट स type्ग्रह प्रकारलाई परिवर्तन गर्न अनुमति दिँदछ, यति लामो समय सम्म यो पुनरावृत्तिकर्ता हो।
/// अतिरिक्त सीमानाहरू प्रतिबन्धित गरेर निर्दिष्ट गर्न सकिन्छ
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// पुन: पुनरावृत भइरहेको तत्वहरूको प्रकार।
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// कस्तो प्रकारको इटरेटर हामी यसलाई परिवर्तन गर्दैछौं?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// मानबाट इट्रेटर सिर्जना गर्दछ।
    ///
    /// अधिकको लागि [module-level documentation] हेर्नुहोस्।
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// एक पुनरावृत्तकर्ताको सामग्रीको साथ संग्रह विस्तार गर्नुहोस्।
///
/// Iterators मानहरूको एक श्रृंखला उत्पादन, र संग्रह पनि मानहरूको श्रृंखला को रूप मा सोच्न सकिन्छ।
/// `Extend` trait ले यो खाली पार्दछ, तपाइँलाई पुनरावृत्तिका सामग्रीहरू समावेश गरेर संग्रह विस्तार गर्न अनुमति दिनुहुन्छ।
/// पहिले नै अवस्थित कुञ्जीको साथ स extend्ग्रह विस्तार गर्दा, त्यो प्रविष्टि अद्यावधिक हुन्छ वा, समान कुञ्जीहरूको साथ बहु प्रविष्टिहरूलाई अनुमति दिने स of्ग्रहको मामलामा, त्यो प्रविष्टि घुसाइन्छ।
///
///
/// # Examples
///
/// आधारभूत उपयोग:
///
/// ```
/// // तपाईं केहि अक्षरहरूको साथ एक स्ट्रिंग विस्तार गर्न सक्नुहुन्छ:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// `Extend` कार्यान्वयन गर्दै:
///
/// ```
/// // एउटा नमूना स that's्ग्रह, त्यो Vec मा मात्र एउटा आवरण हो<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // यसलाई केहि तरिकाहरू दिनुहोस् ताकि हामी एउटा सिर्जना गर्न सक्दछौं र यसमा चीजहरू थप्न सक्छौं।
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // किनकि माई कलेक्सनसँग आई 32 को सूची छ, हामी i32 को लागी एक्सटेन्ड लागू गर्दछौं
/// impl Extend<i32> for MyCollection {
///
///     // यो ठोस प्रकारको हस्ताक्षरको साथ अलि सरल छ: हामी कुनै पनि चीजमा विस्तार कल गर्न सक्दछौं जुन एक Iterator मा परिणत हुन सक्छ जसले हामीलाई i32s दिन्छ।
///     // किनकि हामीलाई मेरो संग्रहमा राख्न i32s चाहिन्छ।
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // कार्यान्वयन एकदम सीधा छ: इट्रेटरको माध्यमबाट लुप, र प्रत्येक तत्व आफैमा add()।
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // हाम्रो संग्रहलाई थप तीन नम्बरको साथ विस्तार गरौं
/// c.extend(vec![1, 2, 3]);
///
/// // हामीले अन्तमा यी तत्वहरू थपेका छौं
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// एक iterator को सामग्रीको साथ संग्रह विस्तार गर्दछ।
    ///
    /// किनकि यो trait को लागि मात्र आवश्यक विधि हो, [trait-level] कागजातहरूमा थप विवरणहरू छन्।
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// // तपाईं केहि अक्षरहरूको साथ एक स्ट्रिंग विस्तार गर्न सक्नुहुन्छ:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// ठ्याक्कै एक तत्वको साथ संग्रह विस्तार गर्दछ।
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// थप तत्वहरूको दिइएको संख्याको लागि स in्ग्रहमा क्षमता सुरक्षित गर्दछ।
    ///
    /// पूर्वनिर्धारित कार्यान्वयनले केहि गर्दैन।
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}