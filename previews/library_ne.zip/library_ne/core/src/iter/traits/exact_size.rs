/// एक पुनरावृत्तिकर्ता जसले यसको सही लम्बाइ जान्दछ।
///
/// धेरै [te Iterator`] s थाहा छैन कति पटक तिनीहरू पुनरावृत्ति हुन्छन्, तर केहि गर्छन्।
/// यदि एक पुनरावृत्तिकर्तालाई थाहा हुन्छ कति पटक यो पुनरावृत्ति हुन सक्छ, त्यो जानकारीको पहुँच प्रदान गर्न उपयोगी हुन सक्छ।
/// उदाहरण को लागी, यदि तपाईं पछाडि पुनरावृत्ति गर्न चाहानुहुन्छ, एक राम्रो सुरुवात भनेको अन्त कहाँ हो भनेर थाहा पाउनु हो।
///
/// जब `ExactSizeIterator` कार्यान्वयन हुन्छ, तपाईंले [`Iterator`] पनि लागू गर्नु पर्छ।
/// त्यसो गर्दा, [`Iterator::size_hint`]*को कार्यान्वयनले* पुनरावृत्तिको सहि आकार फिर्ता गर्नै पर्छ।
///
/// [`len`] विधिको पूर्वनिर्धारित कार्यान्वयन छ, त्यसैले तपाईंले प्राय: यसलाई लागू गर्नु हुँदैन।
/// जहाँसम्म, तपाईं पूर्वनिर्धारित भन्दा बढी प्रदर्शन कार्यान्वयन प्रदान गर्न सक्षम हुन सक्नुहुन्छ, त्यसैले यस मामलामा यसलाई ओभरराइडिंगले अर्थ गर्दछ।
///
///
/// नोट गर्नुहोस् कि यो trait एक सुरक्षित trait हो र यस्तो *छैन* र * फिर्ता लम्बाई सहि ग्यारेन्टी दिन सक्दैन।
/// यसको मतलब यो छ कि `unsafe` कोड ** **[`Iterator::size_hint`] को सहि निर्भरता हुँदैन।
/// अस्थिर र असुरक्षित [`TrustedLen`](super::marker::TrustedLen) trait ले यो अतिरिक्त ग्यारेन्टी दिन्छ।
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// आधारभूत उपयोग:
///
/// ```
/// // एक सीमित सीमा कति पटक यो पुनरावृत्ति हुन्छ थाहा छ
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// [module-level docs] मा, हामीले [`Iterator`] लागू गर्‍यौं, `Counter`.
/// यसको लागि `ExactSizeIterator` कार्यान्वयन पनि गरौं:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // हामी सजीलो पुनरावृत्ति को बाँकी संख्या गणना गर्न सक्छौं।
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // र अब हामी यसलाई प्रयोग गर्न सक्छौं!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// पुनरावृत्तिको सही लम्बाई फर्काउँछ।
    ///
    /// कार्यान्वयनले सुनिश्चित गर्दछ कि इट्रेटरले [`None`] फिर्ता पहिले `len()` अधिक पटक `len()` मान फिर्ता गर्दछ।
    ///
    /// यस विधिको एक पूर्वनिर्धारित कार्यान्वयन छ, त्यसैले तपाईं सामान्यतया यसलाई सीधा कार्यान्वयन गर्नु हुँदैन।
    /// जे होस्, यदि तपाईं अधिक कुशल कार्यान्वयन प्रदान गर्न सक्नुहुन्छ, तपाईं त्यसो गर्न सक्नुहुनेछ।
    /// उदाहरणको लागि [trait-level] कागजातहरू हेर्नुहोस्।
    ///
    /// यो प्रकार्यको [`Iterator::size_hint`] प्रकार्यको जस्तै सुरक्षा ग्यारेन्टीहरू छन्।
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// // एक सीमित सीमा कति पटक यो पुनरावृत्ति हुन्छ थाहा छ
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: यो दाबी अत्यधिक रक्षात्मक हो, तर यसले आक्रमणकर्तालाई जाँच गर्दछ
        // trait द्वारा ग्यारेन्टी गरिएको।
        // यदि यो trait rust आन्तरिक हो भने, हामी डिबग_सम्राट प्रयोग गर्न सक्दछौं;assert_eq!सबै Rust प्रयोगकर्ता कार्यान्वयन पनि जाँच गर्दछ।
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// यदि इटरेटर खाली छ भने `true` फर्काउँछ।
    ///
    /// यो विधिको [`ExactSizeIterator::len()`] को प्रयोग गरी पूर्वनिर्धारित कार्यान्वयन हुन्छ, त्यसैले तपाई आफैले यसलाई कार्यान्वयन गर्नु आवश्यक पर्दैन।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}