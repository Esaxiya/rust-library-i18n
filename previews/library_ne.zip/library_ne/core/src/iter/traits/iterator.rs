// बेवास्ता गर्नुहोस्-फाइल-लम्बाई यो फाईल लगभग एक्सक्लेक्स एक्स परिभाषाको समावेश गर्दछ।
// हामी त्यसलाई बहु फाईलहरूमा विभाजन गर्न सक्दैनौं।
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// पुनरावृत्तकर्ताहरूसँग व्यवहार गर्ने इन्टरफेस।
///
/// यो मुख्य पुनरावृत्ति trait हो।
/// सामान्यतया पुनरावृत्तिको अवधारणाको बारेमा, कृपया [module-level documentation] हेर्नुहोस्।
/// विशेष रूपमा, तपाइँ [implement `Iterator`][impl] लाई कसरी जान्न सक्नुहुन्छ।
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// पुन: पुनरावृत भइरहेको तत्वहरूको प्रकार।
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// पुनरावृत्तिको अग्रिम र अर्को मान फर्काउँछ।
    ///
    /// एक्सटरेसन समाप्त भएपछि [`None`] फर्काउँछ।
    /// व्यक्तिगत पुनरावर्तन कार्यान्वयनले पुनरावृत्ति पुनःसुरु गर्न छनौट गर्न सक्छ, र त्यसैले `next()` कल गरेर फेरि अन्ततः [`Some(Item)`] फिर्ता केहि बिन्दुमा शुरू गर्न सक्दछ।
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // next() मा कल पछिल्लो मान फर्काउँछ ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... र त्यसपछि कुनै पनि होइन यो समाप्त भयो।
    /// assert_eq!(None, iter.next());
    ///
    /// // अधिक कलहरूले `None` फिर्ता गर्न सक्छ वा सक्दैन।यहाँ, तिनीहरू सँधै हुनेछन्।
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// पुनरावृत्तिको बाँकी लम्बाइमा सीमा फर्काउँछ।
    ///
    /// विशेष रूपमा, `size_hint()` एक tuple फर्काउँछ जहाँ पहिलो तत्व तल्लो बाउन्ड हो, र दोस्रो तत्व अपर बाउन्ड हो।
    ///
    /// ट्युपलको दोस्रो भाग आयो जुन फिर्ता भयो [`विकल्प`]`<`[`usize`] `>`।
    /// यहाँ एक [`None`] मतलब कि या त ज्ञात अपर बाउन्ड छैन, वा माथिको बाउन्ड [`usize`] भन्दा ठूलो छ।
    ///
    /// # कार्यान्वयन नोटहरू
    ///
    /// यो लागू गरिएको छैन कि एक पुनरावृत्ति कार्यान्वयनले तत्वहरूको घोषित संख्याको उपज दिन्छ।एउटा बग्गी इट्रेटरले तल्लो बाउन्ड भन्दा कम वा तत्वहरूको माथिल्लो सीमा भन्दा कम उत्पादन गर्न सक्दछ।
    ///
    /// `size_hint()` मुख्य रूपले अप्टिमाइजेसनको लागि प्रयोगको उद्देश्यले हो जस्तै इट्रेटरको एलिमेन्टहरूको लागि ठाउँ सुरक्षित गर्ने, तर विश्वास गर्नु हुँदैन उदाहरणको लागि, असुरक्षित कोडमा बाउन्ड सीमा चेक बेच्न।
    /// `size_hint()` को गलत कार्यान्वयनले मेमोरी सुरक्षा उल्लंघन गर्न सक्दैन।
    ///
    /// त्यो भनियो, कार्यान्वयनले एक सही अनुमान प्रदान गर्नुपर्दछ, किनभने अन्यथा यो trait को प्रोटोकलको उल्लंघन हुनेछ।
    ///
    /// पूर्वनिर्धारित कार्यान्वयन returns (०, `[` No``]`)` फर्काउँछ जुन कुनै पनि इट्रेटरको लागि सहि हो।
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// अझ जटिल उदाहरण:
    ///
    /// ```
    /// // शून्य देखि दश सम्मको संख्याहरू।
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // हामी शून्य देखि दश पटक सम्म दोहोर्याउन सक्छौं।
    /// // थाहा छ कि यो वास्तवमै पाँच हो filter() कार्यान्वयन नगरी सम्भव छैन।
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // chain() का साथ पाँच थप संख्याहरू जोडौं
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // अब दुबै सिमा पाँचले बढाएको छ
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// माथिल्लो बाउन्डको लागि `None` फिर्ता गर्दै:
    ///
    /// ```
    /// // एक असीम पुनरावृत्तिसँग माथिल्लो बाउन्ड छैन र अधिकतम सम्भव तल्लो सीमा छ
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// पुनरावृत्तिको खण्ड, पुनरावृत्तिको संख्या गणना गरी फर्काउँछ।
    ///
    /// यस विधिले [`next`] लाई बारम्बार कल गर्नेछ जब सम्म [`None`] देखा पर्दैन, [`Some`] पटक देखेको संख्या फिर्ता गर्दै।
    /// नोट गर्नुहोस् कि [`next`] कम्तिमा एक पटक कल गर्नुपर्नेछ यदि पुनरावृत्तिको कुनै एलिमेन्ट छैन भने पनि।
    ///
    /// [`next`]: Iterator::next
    ///
    /// # ओभरफ्लो व्यवहार
    ///
    /// विधिले ओभरफ्लोहरू विरूद्ध कुनै सुरक्षा गर्दैन, त्यसैले [`usize::MAX`] भन्दा बढी तत्त्वहरूसहित एक इटरेटरको तत्वहरूको गणना गर्दा गलत नतिजा वा panics उत्पन्न गर्दछ।
    ///
    /// यदि डिबग assertions सक्षम छन्, एक panic ग्यारेन्टी छ।
    ///
    /// # Panics
    ///
    /// यो प्रकार्य panic हुन सक्छ यदि ईटरटरमा [`usize::MAX`] भन्दा बढि तत्वहरू छन्।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// पुनरावृत्ति खान्छ, अन्तिम तत्व फिर्ता गर्दै।
    ///
    /// यस विधिले पुनरावृत्तिको मूल्या will्कन गर्दछ जबसम्म यसले [`None`] फर्काउँदैन।
    /// त्यसो गर्दा, यसले हालको तत्त्व ट्र्याक राख्छ।
    /// [`None`] फिर्ता भएपछि, `last()` त्यसपछि अन्तिम पटक देखेको फर्काउँछ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// `n` एलिमेन्ट्स द्वारा इट्रेटरको अग्रिम
    ///
    /// यो विधि [`next`] सम्म [`next`] सम्म [`next`] सम्म कल गरेर `n` एलिमेन्टहरू एक्स्प्रेस छोड्नेछ XX3X सामना नगरेसम्म।
    ///
    /// `advance_by(n)` यदि इट्रेटरले सफलतापूर्वक `n` एलिमेन्ट्सले अगाडि बढ्यो भने [`Ok(())`][Ok] फर्काउँदछ, वा [`Err(k)`][Err] यदि [`None`] भेटिएको छ भने, जहाँ `k` एलिमेन्ट्सको स is्ख्या हो जब इन्ट्रेटर एलिमेन्ट्सको अगाडि दौडनु भन्दा पहिले उन्नत हुन्छ (जस्तै:
    /// पुनरावृत्ति को लम्बाई)।
    /// नोट गर्नुहोस् कि `k` जहिले पनि `n` भन्दा कम हुन्छ।
    ///
    /// `advance_by(0)` कल गर्दा कुनै पनि तत्व खपत गर्दैन र सँधै [`Ok(())`][Ok] फर्काउँछ।
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // मात्र `&4` छोडियो
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Rator n` पुनरावृत्तिक तत्वको फर्काउँछ।
    ///
    /// धेरै अनुक्रमणिका अपरेसनहरू जस्तै, गणना शून्यबाट सुरू हुन्छ, त्यसैले `nth(0)` पहिलो मान फर्काउँछ, `nth(1)` दोस्रो, र त्यस्तै।
    ///
    /// नोट गर्नुहोस् कि सबै अघिल्लो तत्त्वहरू, साथै फर्काइएका तत्त्वहरू, इटरेटरबाट खपत हुनेछ।
    /// यसको मतलब यो छ कि अघिल्लो एलिमेन्टहरू त्याग्ने छ, र यो पनि भनिन्छ कि एक्सटोर एक्स बहु पटक समान पुनरावृत्तिमा बिभिन्न तत्वहरू फर्काउँछ।
    ///
    ///
    /// `nth()` [`None`] फिर्ता गर्नेछ यदि `n` पुनरावृत्तिको लम्बाई भन्दा ठूलो वा बराबर छ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// `nth()` बहु पटक कल गर्दा ईटररेटर रिवाइन्ड हुँदैन:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// `None` फिर्ता गर्दै यदि `n + 1` भन्दा कम तत्वहरू छन् भने:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// उही बिन्दुमा सुरू हुने इट्रेटर सिर्जना गर्दछ, तर प्रत्येक पुनरावृत्तिमा दिइएको रकमबाट चरणबद्ध गर्दै।
    ///
    /// नोट १: ईट्रेटरको पहिलो तत्त्व सँधै फिर्ता हुन्छ, कुनै चरण दिए पनि।
    ///
    /// नोट २: उपेक्षित तत्त्वहरूलाई तान्ने समय तय गरिएको छैन।
    /// `StepBy` अनुक्रम `next(), nth(step-1), nth(step-1),…` जस्तो व्यवहार गर्दछ, तर यो क्रम जस्तै व्यवहार गर्न स्वतन्त्र पनि छ
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// कुन कारणले प्रयोग गरेको छ केही प्रदर्शनको कारणले गर्दा केही पुनरावृत्तिको लागि परिवर्तन हुन सक्छ।
    /// दोस्रो तरीकाले पहिले एट्रेटर अग्रिम गर्नेछ र अधिक चीजहरू खपत गर्न सक्दछ।
    ///
    /// `advance_n_and_return_first` को बराबर हो:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// विधि panic हुनेछ यदि दिइएको चरण `0` छ भने।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// दुई पुनरावृत्तिको लिन्छ र अनुक्रममा दुबै माथि नयाँ इटररेट सिर्जना गर्दछ।
    ///
    /// `chain()` एउटा नयाँ इट्रेटर फर्काउँछ जुन पहिलो इट्रेटरबाट मानहरू माथि दोहोर्याउँदछ र दोस्रो इट्रेटरबाट मानहरू माथि।
    ///
    /// अर्को शब्दहरुमा, यसले एक श्रृंखलामा दुई पुनरावृत्तिको सँगै जोड्दछ।🔗
    ///
    /// [`once`] सामान्यतया एकल मानलाई अन्य प्रकारको पुनरावृत्तिको श्रृंखलामा अनुकूलन गर्न प्रयोग गरिन्छ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `chain()` को आर्गुमेन्टले [`IntoIterator`] प्रयोग गर्दछ, हामी केहि पनि पास गर्न सक्छौं जुन [`Iterator`] मा रूपान्तरण गर्न सकिन्छ, केवल [`Iterator`] मात्र होईन।
    /// उदाहरण को लागी, टुक्रा (`&[T]`) [`IntoIterator`] लागू, र त्यसैले सीधा `chain()` गर्न सकिन्छ:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// यदि तपाईं Windows API का साथ काम गर्नुहुन्छ भने, तपाईं [`OsStr`] लाई `Vec<u16>` मा रूपान्तरण गर्न सक्नुहुन्छ:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// जोपहरूको एकल पुनरावृत्तिमा दुई पुनरावृत्तिहरू 'zip up'।
    ///
    /// `zip()` नयाँ इट्रेटर फर्काउँछ जुन दुई अन्य पुनरावृत्तिको माथि पुनरावृत्ति हुन्छ, ट्युपल फर्काउँदै जहाँ पहिलो एलिटर पहिलो इटरेटरबाट आउँदछ, र दोस्रो एलिमेन्ट दोस्रो इट्रेटरबाट आउँदछ।
    ///
    ///
    /// अर्को शब्दहरुमा, यसले एकलमा दुई पुनरावृत्तिको सँगै zip गर्दछ।
    ///
    /// यदि या त पुनरावृत्तिकर्ताले [`None`] फर्काउँछ भने, z0 ईट्रेटरबाट [`next`] [`None`] फर्काउँछ।
    /// यदि पहिलो इटर्रेटरले [`None`] फर्काउँछ भने, `zip` सर्ट-सर्किट हुन्छ र `next` दोस्रो इट्रेटरमा कल गरिने छैन।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` को आर्गुमेन्टले [`IntoIterator`] प्रयोग गर्दछ, हामी केहि पनि पास गर्न सक्छौं जुन [`Iterator`] मा रूपान्तरण गर्न सकिन्छ, केवल [`Iterator`] मात्र होईन।
    /// उदाहरण को लागी, टुक्रा (`&[T]`) [`IntoIterator`] लागू, र त्यसैले सीधा `zip()` गर्न सकिन्छ:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` अक्सर एक सीमितमा एक असीमित पुनरावृत्पादक zip गर्न प्रयोग गरिन्छ।
    /// यसले काम गर्दछ किनकि परिमित पुनरावृत्तिकर्ताले अन्ततः [`None`] फर्कनेछ, जिपरको अन्त्य गर्दै।`(0..)` को साथ zip धेरै [`enumerate`] जस्तै हेर्न सक्छ:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// एक नयाँ इट्रेटर सिर्जना गर्दछ जसले मूल इट्रेटरको आसन्न वस्तुहरूका बीचमा `separator` को प्रतिलिपि राख्छ।
    ///
    /// यदि `separator` [`Clone`] कार्यान्वयन गर्दैन वा प्रत्येक पटक गणना गर्नु आवश्यक छ भने, [`intersperse_with`] प्रयोग गर्नुहोस्।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // `a` बाट पहिलो तत्व।
    /// assert_eq!(a.next(), Some(&100)); // विभाजक।
    /// assert_eq!(a.next(), Some(&1));   // `a` बाट अर्को तत्व।
    /// assert_eq!(a.next(), Some(&100)); // विभाजक।
    /// assert_eq!(a.next(), Some(&2));   // `a` बाट अन्तिम तत्व।
    /// assert_eq!(a.next(), None);       // इटरेटर समाप्त भयो।
    /// ```
    ///
    /// `intersperse` एक सामान्य तत्व प्रयोग गरी एक पुनरावृत्तिको वस्तुहरूमा सामेल हुन धेरै उपयोगी हुन सक्छ:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// एक नयाँ इटरेटर बनाउँदछ जुन `separator` द्वारा उत्पन्न गरिएको आइटमलाई मूल इट्रेटरको छेउछाउका वस्तुहरू बीच राख्दछ।
    ///
    /// क्लोजर बिल्कुल एक पटक भनिन्छ प्रत्येक पटक अन्तर्निहित इट्रेटरबाट दुई आसन्न वस्तुहरूका बीचमा कुनै वस्तु राखिन्छ;
    /// विशेष रूपमा, क्लोजर भनिदैन यदि अन्तर्निहित ईट्रेटरले दुई भन्दा कम वस्तुहरू उत्पादन गर्दछ र अन्तिम आईटम अर्जित भएपछि।
    ///
    ///
    /// यदि इटरेटरको वस्तुले [`Clone`] लागू गर्दछ भने, यो [`intersperse`] प्रयोग गर्न सजिलो हुन सक्छ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // `v` बाट पहिलो तत्व।
    /// assert_eq!(it.next(), Some(NotClone(99))); // विभाजक।
    /// assert_eq!(it.next(), Some(NotClone(1)));  // `v` बाट अर्को तत्व।
    /// assert_eq!(it.next(), Some(NotClone(99))); // विभाजक।
    /// assert_eq!(it.next(), Some(NotClone(2)));  // `v` बाट अन्तिम तत्व।
    /// assert_eq!(it.next(), None);               // इटरेटर समाप्त भयो।
    /// ```
    ///
    /// `intersperse_with` विभाजक गणना गर्न आवश्यक पर्दा यस्तो अवस्थामा प्रयोग गर्न सकिन्छ:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // बन्दले पारस्परिक रूपमा एक वस्तु उत्पन्न गर्न यसको सन्दर्भ उधारो लिन्छ।
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// एउटा क्लोजर लिन्छ र एक इट्रेटर सिर्जना गर्दछ जसले प्रत्येक तत्वमा त्यो क्लोजर भन्छ।
    ///
    /// `map()` एक इरेटरलाई अर्कोमा बदल्छ यसको तर्कको माध्यमबाट:
    /// [`FnMut`] लागू गर्ने केहि चीज।यसले एक नयाँ इट्रेटर उत्पादन गर्दछ जसले यस क्लोजरलाई मूल इट्रेटरको प्रत्येक तत्वमा कल गर्दछ।
    ///
    /// यदि तपाईं प्रकारहरूमा सोच्न राम्रो हुनुहुन्छ भने, तपाईं यो जस्तो `map()` को लागी सोच्न सक्नुहुन्छ:
    /// यदि तपाईंसँग इट्रेटर छ जसले तपाईंलाई केहि प्रकार `A` को तत्त्व दिन्छ, र तपाईं कुनै अन्य प्रकारको `B` को पुनरावृत्ति चाहानुहुन्छ, तपाईं `map()` प्रयोग गर्न सक्नुहुनेछ, `A` लिने क्लोजर पार गरेर `B` फर्काउँछ।
    ///
    ///
    /// `map()` [`for`] लूपसँग अवधारणा जस्तै छ।जहाँसम्म, `map()` आलसी हो, यो उत्तम प्रयोग गरिन्छ जब तपाईं पहिले नै अन्य इट्रेटरहरूसँग काम गरिरहनु भएको छ।
    /// यदि तपाईं साइड इफेक्टको लागि कुनै प्रकारका लुपिंग गर्दै हुनुहुन्छ भने, यो `map()` भन्दा [`for`] प्रयोग गर्न बढी मुर्ख मानिन्छ।
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// यदि तपाइँ कुनै प्रकारको साइड इफेक्ट गरिरहनु भएको छ भने [`for`] लाई `map()` मा प्राथमिकता दिनुहोस्:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // यो नगर्नुहोस्:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // यो कार्यान्वयन पनि हुँदैन, किनकि यो अल्छी छ।Rust ले तपाईंलाई यसको बारेमा चेतावनी दिन्छ।
    ///
    /// // यसको सट्टामा, यसको लागि प्रयोग गर्नुहोस्:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// एक iterator को प्रत्येक तत्व मा एक बन्द कल।
    ///
    /// यो पुनरावृत्तिकर्तामा [`for`] लूप प्रयोग गर्न बराबर हो, यद्यपि `break` र `continue` बन्दबाट सम्भव छैन।
    /// यो सामान्यतया `for` लूप प्रयोग गर्नका लागि बढी इडिओमेटिक हो, तर एक्स इन्ट्रेटर चेनको अन्त्यमा आईटमहरू प्रशोधन गर्दा `for_each` अधिक सुस्त हुन सक्छ।
    ///
    /// केहि केसहरूमा `for_each` पनि एउटा लूप भन्दा छिटो हुन सक्दछ, किनभने यसले `Chain` जस्तो एडेप्टरमा आन्तरिक पुनरावृत्ति प्रयोग गर्दछ।
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// यस्तो सानो उदाहरणको लागि, एक `for` लूप सफा हुन सक्छ, तर `for_each` अब लामो पुनरावृत्तिका साथ कार्य शैली राख्न राम्रो हुन सक्छ:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// एक इटरेटर बनाउँदछ जसले एलिमेन्ट उत्पन्न हुनु पर्छ कि हुँदैन भनेर निर्धारित गर्न क्लोजर प्रयोग गर्दछ।
    ///
    /// एउटा तत्त्व दिंदा क्लोजर `true` वा `false` फर्काउनु पर्छ।फिर्ता ईटरेटरले केवल तत्त्वहरू उत्पादन गर्दछ जसको लागि बन्द साँचो हुन्छ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// किनभने क्लोजरले `filter()` मा पठाइयो सन्दर्भ लिन्छ, र धेरै पुनरावृत्तिहरू सन्दर्भहरूमा पुनरावृत्ति हुन्छ, यसले सम्भावित गोलमाल गर्ने स्थितितर्फ डो leads्याउँछ जहाँ बन्दको प्रकार एक डबल सन्दर्भ हो:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // दुई * s चाहिन्छ!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// यसको सट्टामा यसलाई हटाउनको लागि तर्कमा विवादास्पदको प्रयोग गर्न सामान्य छ।
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // दुबै र *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// वा दुबै:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // दुई &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// यी तहहरूको।
    ///
    /// नोट गर्नुहोस् कि `iter.filter(f).next()` `iter.find(f)` बराबर छ।
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// फिल्टर र नक्सा दुबै एक इटरेटर सिर्जना गर्दछ।
    ///
    /// फिर्ता ईटरेटरले केवल `value`s प्राप्त गर्दछ जसको लागि आपूर्ति बन्द गरियो `Some(value)`।
    ///
    /// `filter_map` [`filter`] र [`map`] अधिक संक्षिप्तको चेन बनाउन प्रयोग गर्न सकिन्छ।
    /// तलको उदाहरणले देखाउँदछ कि कसरी `map().filter().map()` एकल कल `filter_map` मा छोटो पार्न सकिन्छ।
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// यहाँ उही उदाहरण छ, तर [`filter`] र [`map`] को साथ:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// एक पुनरावृत्ति सिर्जना गर्दछ जसले वर्तमान पुनरावृत्ति गणना साथै अर्को मान दिन्छ।
    ///
    /// पुनरावृत्तिकर्ताले `(i, val)` उत्पादनहरू फिर्ता ग where्यो, जहाँ `i` पुनरावृत्तिको हालको अनुक्रमणिका हो र `val` इटरेटरले फर्काएको मान हो।
    ///
    ///
    /// `enumerate()` यसलाई [`usize`] को रूपमा गणना गर्दछ।
    /// यदि तपाईं फरक आकारको पूर्णांक द्वारा गणना गर्न चाहनुहुन्छ भने, [`zip`] प्रकार्य समान कार्यक्षमता प्रदान गर्दछ।
    ///
    /// # ओभरफ्लो व्यवहार
    ///
    /// विधिले ओभरफ्लोहरू विरूद्ध कुनै सुरक्षा गर्दैन, त्यसैले [`usize::MAX`] भन्दा बढी तत्वहरू गणना गर्दा गलत परिणाम वा panics उत्पादन गर्दछ।
    /// यदि डिबग assertions सक्षम छन्, एक panic ग्यारेन्टी छ।
    ///
    /// # Panics
    ///
    /// फिर्ता पुनरावर्तक panic हुन सक्छ यदि फिर्ता-फिर्ता सूचकांक एक [`usize`] ओभरफ्लो हुनेछ।
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// एक इटरेटर बनाउँदछ जुन [`peek`] प्रयोग गर्न सक्दछ यसलाई उपभोग नगरी पुनरावृत्तिको अर्को तत्त्व अवलोकन गर्न।
    ///
    /// एक इरेटरमा [`peek`] विधि थप्दछ।अधिक जानकारीको लागि यसको कागजात हेर्नुहोस्।
    ///
    /// नोट गर्नुहोस् कि अंतर्निहित इट्रेटर अझै उन्नत छ जब [`peek`] पहिलो पटक बोलाइएको छ: अर्को तत्व पुनः प्राप्त गर्न क्रममा [`next`] अन्तर्निहित इट्रेटरमा कल गरिएको छ, त्यसैले कुनै पनि साइड इफेक्टहरू (जस्तै)।
    ///
    /// [`next`] विधिको अर्को मान ल्याउने बाहेक केहि पनि हुन्छ)।
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() हामीलाई future मा हेर्न दिनुहोस्
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // हामी धेरै पटक peek() गर्न सक्छौं, ईट्रेटर अगाडि बढ्दैन
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // इटरेटर समाप्त भएपछि peek() पनि हुन्छ
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// एक इट्रेटर सिर्जना गर्दछ जुन [`skip`] s एलिमेंट्स प्रेडिकेटमा आधारित हुन्छ।
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` तर्कको रूपमा बन्द गर्दछ।यसले इट्रेटरको प्रत्येक तत्वमा यो क्लोजर कल गर्दछ, र तत्वहरू वेवास्ता गर्दछ जब सम्म यो `false` फर्काउँदैन।
    ///
    /// `false` फिर्ता भएपछि, `skip_while()`'s कार्य सकियो, र बाँकी एलिमेन्टहरू उत्पन्न भयो।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// किनभने क्लोजरले `skip_while()` मा पठाइयो सन्दर्भ लिन्छ, र धेरै पुनरावृत्तिहरू सन्दर्भहरूमा पुनरावृत्ति हुन्छ, यसले सम्भावित गोलमाल गर्ने स्थितितर्फ डो leads्याउँछ जहाँ बन्दको तर्कको प्रकार एक दोहोरो सन्दर्भ हो:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // दुई * s चाहिन्छ!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// प्रारम्भिक `false` पछि रोकिदै:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // जबकि यो गलत हुने थियो, किनकि हामीले पहिले नै एक गलत बनायौं, skip_while() अब प्रयोग गरिएको छैन
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// एक ईटरेटर सिर्जना गर्दछ जसले पूर्वानुमानको आधारमा तत्वहरू दिन्छ।
    ///
    /// `take_while()` तर्कको रूपमा बन्द गर्दछ।यसले इट्रेटरको प्रत्येक तत्वमा यो क्लोजर कल गर्दछ, र उत्पादन तत्वहरू जब यो `true` फर्काउँछ।
    ///
    /// `false` फिर्ता भएपछि, `take_while()`'s कार्य सकियो, र बाँकी तत्वहरूलाई वेवास्ता गरियो।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// किनभने क्लोजरले `take_while()` मा पठाइयो सन्दर्भ लिन्छ, र धेरै पुनरावृत्तिहरू सन्दर्भहरूमा पुनरावृत्ति हुन्छ, यसले सम्भावित गोलमाल गर्ने स्थितितर्फ डो leads्याउँछ जहाँ बन्दको प्रकार एक डबल सन्दर्भ हो:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // दुई * s चाहिन्छ!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// प्रारम्भिक `false` पछि रोकिदै:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // हामीसँग अधिक एलिमेन्टहरू छन् जुन शून्य भन्दा कम छ, तर हामीसँग पहिले नै गलत भयो, take_while() अब प्रयोग भएको छैन
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// किनभने `take_while()` लाई मान हेर्नु आवश्यक छ कि यसलाई समावेश गर्नु पर्छ वा हुँदैन भनेर, उपभोक्ता उपभोक्ताहरूले देख्छन् कि यसलाई हटाइएको छ भनेर:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` अब छैन, किनकि यो खपत भएको थियो कि यो हेर्नका लागि खपत गरियो कि यदि पुनरावृत्ति रोकिन्छ कि भनेर, तर यसलाई पुनरावृत्तकर्तामा राखिएको थिएन।
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// एक ईटरेटर बनाउँदछ कि दुबै उत्पादनहरू एक भविष्यसूची र नक्शामा आधारित हुन्छ।
    ///
    /// `map_while()` तर्कको रूपमा बन्द गर्दछ।
    /// यसले इट्रेटरको प्रत्येक तत्वमा यो क्लोजर कल गर्दछ, र उत्पादन तत्वहरू जब यो [`Some(_)`][`Some`] फर्काउँछ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// यहाँ उही उदाहरण छ, तर [`take_while`] र [`map`] को साथ:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// प्रारम्भिक [`None`] पछि रोकिदै:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // हामीसँग अधिक एलिमेन्टहरू छन् जुन u32 (,, fit) मा फिट हुन सक्दछ, तर `map_while` `None` लाई `-3` (`predicate` फिर्ता `None` फिर्ता गरे) र `collect` स्टक्स भएको पहिलो `None` मा रोकिन्छ।
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// किनभने `map_while()` लाई मान हेर्नु आवश्यक छ कि यसलाई समावेश गर्नु पर्छ वा हुँदैन भनेर, उपभोक्ता उपभोक्ताहरूले देख्छन् कि यसलाई हटाइएको छ भनेर:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` अब छैन, किनकि यो खपत भएको थियो कि यो हेर्नका लागि खपत गरियो कि यदि पुनरावृत्ति रोकिन्छ कि भनेर, तर यसलाई पुनरावृत्तकर्तामा राखिएको थिएन।
    ///
    /// नोट गर्नुहोस् कि [`take_while`] विपरीत यो ईट्रेटर **फाईज** छैन।
    /// यो पनि निर्दिष्ट गरिएको छैन कि यो पुनरावृत्तिले के फर्काउँछ पहिलो [`None`] फिर्ताको पछि।
    /// यदि तपाईंलाई फ्यूज गरिएको इटरेटर चाहिएको छ भने, [`fuse`] प्रयोग गर्नुहोस्।
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// एक इटरेटर बनाउँदछ जुन पहिला `n` एलिमेन्ट्स स्किप गर्दछ।
    ///
    /// तिनीहरू उपभोग भएपछि, बाँकी तत्त्वहरू उत्पादन गरिन्छ।
    /// यस विधिलाई सीधा ओभरराइड गर्नुको सट्टा `nth` विधिलाई ओभरराइड गर्नुहोस्।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// एक इटरेटर बनाउँदछ जुन यसको पहिलो `n` एलिमेन्टहरू उत्पन्न गर्दछ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` प्राय: असीमित पुनरावृत्तिको साथ प्रयोग गरिन्छ, यसलाई सीमित गर्नका लागि:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// यदि `n` भन्दा कम तत्त्वहरू उपलब्ध छन् भने, `take` ले अन्तर्निहित पुनरावृत्तिको आकारमा सीमित गर्नेछ:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// एक्सटोरर एडाप्टर [`fold`] जस्तै समान छ कि आन्तरिक राज्य होल्ड गर्दछ र नयाँ इट्रेटर उत्पादन गर्दछ।
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` दुई आर्गुमेन्टहरू लिन्छन्: एक प्रारम्भिक मान जसले आन्तरिक राज्यलाई बीउ गर्दछ, र दुई तर्कहरूको साथ बन्द, पहिलो आन्तरिक राज्यको लागि एक परिवर्तनीय सन्दर्भ र दोस्रो एक इट्रेटर तत्व।
    ///
    /// बन्दले आन्तरिक अवस्थालाई पुनरावृत्तिको बीचमा साझेदारी गर्न सक्दछ।
    ///
    /// पुनरावृत्तिमा, क्लोजर इट्रेटरको प्रत्येक तत्वमा लागू हुनेछ र क्लोजरबाट फिर्ता मान, एक [`Option`], इट्रेटरद्वारा उत्पन्न हुनेछ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // प्रत्येक पुनरावृत्ति, हामी तत्वद्वारा राज्य गुणा गर्नेछौं
    ///     *state = *state * x;
    ///
    ///     // त्यसो भए, हामी राज्यको उपेक्षा पैदा गर्नेछौं
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// नक्शा जस्तो काम गर्ने एक इट्रेटर सिर्जना गर्दछ, तर नेस्ट स्ट्रक्चर सपाट गर्दछ।
    ///
    /// [`map`] एडाप्टर धेरै उपयोगी छ, तर मात्र जब बन्द तर्कले मानहरू उत्पादन गर्दछ।
    /// यदि यसको सट्टामा एक इरेटरको उत्पादन गर्दछ भने, त्यहाँ इन्डिरेक्शनको अतिरिक्त तह छ।
    /// `flat_map()` यस अतिरिक्त लेयर आफैले हटाउनेछ।
    ///
    /// तपाईं `flat_map(f)` को अर्थ [`map`] पिंगको अर्थको बराबरको रूपमा सोच्न सक्नुहुन्छ, र त्यसपछि [` समतल] in `map(f).flatten()` जस्तो।
    ///
    /// `flat_map()` को बारेमा सोच्ने अर्को तरिका: [`map`] को बन्देजले प्रत्येक तत्वको लागि एक वस्तु फिर्ता गर्छ, र `flat_map()`'s क्लोजरले प्रत्येक तत्वको लागि एक इटरेटर फिर्ता गर्छ।
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() एक iterator फिर्ता
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// नेरेटेड संरचना समतल बनाउने ईटरेटर सिर्जना गर्दछ।
    ///
    /// यो उपयोगी छ जब तपाईंसँग पुनरावृत्तकर्ताहरूको इटररेटर वा चीजहरूको इटरेटर छ जुन इटरेटरमा परिणत गर्न सकिन्छ र तपाईं ईन्डरिकेसनको एक स्तर हटाउन चाहानुहुन्छ।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// म्यापि and र त्यसपछि चाप्ने:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() एक iterator फिर्ता
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// तपाईं यो [`flat_map()`] को सर्तमा पनि पुन: लेख्न सक्नुहुन्छ, जुन यस अवस्थामा राम्रो हुन्छ किनकि यसले अधिक स्पष्ट रुपमा अभिव्यक्त गर्दछ:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() एक iterator फिर्ता
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// फ्ल्याटनिंगले एक पटकमा नेस्टिंगको एक स्तर मात्र हटाउँछ:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// यहाँ हामी हेर्दछौं कि `flatten()` ले "deep" सपाट प्रदर्शन गर्दैन।
    /// यसको सट्टा, नेस्टिंगको केवल एक तह हटाइन्छ।त्यो हो, यदि तपाईंले तीन आयामिक एर्रे `flatten()` गर्नुभयो भने, नतीजा द्वि-आयामी र एक आयामी होइन।
    /// एक आयामी संरचना प्राप्त गर्न, तपाईले फेरि `flatten()` गर्नु पर्छ।
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// एक इटरेटर बनाउँदछ जुन पहिलो [`None`] पछि समाप्त हुन्छ।
    ///
    /// एक इटर्रेटरले [`None`] फर्काएपछि, future कलहरू फेरि [`Some(T)`] दिन सक्दैन वा हुन सक्दैन।
    /// `fuse()` एक पुनरावृत्तिकर्ता लाई रूपान्तरण गर्दछ, XXX दिईएको पछि पनी यो निश्चित हुन्छ XX1X सदाका लागि फिर्ता हुन्छ।
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// // एक पुनरावृत्तिकर्ता जसले केहि र केहि बीचमा वैकल्पिक गर्दैन
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // यदि यो छ भने, Some(i32), अरु कुनै हैन
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // हामी देख्न सक्छौं हाम्रो इट्रेटर पछाडि र पछाडि जाँदैछन्
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // जे होस्, एक पटक हामी यसलाई फ्यूज ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // यो सँधै पहिलो पटक पछि `None` फिर्ता हुनेछ।
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// एक इटरेटरको प्रत्येक तत्वको साथ केहि गर्दछ, मानलाई पार गर्दै।
    ///
    /// पुनरावृत्तिको प्रयोग गर्दा, तपाई प्राय ती मध्ये धेरै सँगै सँगै हुनुहुन्छ।
    /// त्यस्ता कोडमा काम गर्दा, तपाईं पाइपलाइनमा विभिन्न भागमा के भइरहेको छ भनेर जाँच गर्न सक्नुहुन्छ।त्यसो गर्न, `inspect()` मा कल सम्मिलित गर्नुहोस्।
    ///
    /// तपाईंको अन्तिम कोडमा अवस्थित हुनु भन्दा डिबगिंग उपकरणको रूपमा प्रयोग गर्न `inspect()` को लागि यो अधिक सामान्य हो, तर अनुप्रयोगहरू यसलाई निश्चित अवस्थामा उपयोगी हुन सक्दछ जब त्रुटिहरू खारेज हुनु अघि लग गर्नु आवश्यक पर्दछ।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // यो पुनरावृत्ति क्रम जटिल छ।
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // के हुँदैछ भनेर अनुसन्धान गर्न केहि inspect() कलहरू थपौं
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// यो प्रिन्ट हुनेछ:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// त्रुटिहरू उनीहरूलाई खारेज अघि लगि Log गर्दै:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// यो प्रिन्ट हुनेछ:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// एक इटरेटर लिन्छ, यसलाई खपत भन्दा।
    ///
    /// मूल पुनरावृत्तिकर्ताको स्वामित्व कायम गर्दै अझै पुनरावृत्तकर्ता एडेप्टरहरू लागू गर्न अनुमति दिन यो उपयोगी छ।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // यदि हामी यसलाई फेरि प्रयोग गर्ने प्रयास गर्‍यौं भने यसले काम गर्दैन।
    /// // निम्न प line्क्तिले "त्रुटि दिन्छ: सारिएको मानको प्रयोग: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // यसलाई पुन: प्रयास गरौं
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // यसको सट्टामा, हामी .by_ref() मा थप गर्दछौं
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // अब यो ठीक छ:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// एक इटेटरलाई संग्रहमा रूपान्तरण गर्दछ।
    ///
    /// `collect()` कुनै पनि पुनरावृत्ति लिन सक्छ, र यसलाई एक सान्दर्भिक संग्रह मा बदल्न।
    /// यो मानक लाइब्रेरीमा अधिक शक्तिशाली विधिहरू मध्ये एक हो जुन विभिन्न प्रस in्गहरूमा प्रयोग हुन्छ।
    ///
    /// सब भन्दा आधारभूत ढाँचा जसमा `collect()` प्रयोग गरिन्छ एक संग्रहलाई अर्कोमा बदल्नु हो।
    /// तपाईं संग्रह लिनुहुन्छ, यसमा [`iter`] कल गर्नुहोस्, रूपान्तरणको गुच्छा गर्नुहोस्, र अन्तमा `collect()`।
    ///
    /// `collect()` प्रकारका उदाहरणहरू पनि बनाउँदछ जुन ठिक संग्रह होईन।
    /// उदाहरण को लागी, एक [`String`] [`char`] s बाट निर्माण गर्न सकिन्छ, र [`Result<T, E>`][`Result`] आईटमहरूको पुनरावृत्ति `Result<Collection<T>, E>` मा संकलन गर्न सकिन्छ।
    ///
    /// अधिकका लागि तलका उदाहरणहरू हेर्नुहोस्।
    ///
    /// किनभने `collect()` यति सामान्य छ, यसले प्रकारको अनुमानको साथ समस्या उत्पन्न गर्न सक्छ।
    /// त्यस्तै, `collect()` केहि पटक हो तपाईंले सिन्ट्याक्सलाई मायालु तरिकाले 'turbofish' भनेर चिनिनुहुनेछ: `::<>`.
    /// यसले अनुमान एल्गोरिथ्मलाई विशेष रूपमा बुझ्न कुन संग्रहमा तपाईंले संकलन गर्न खोज्नु भएको छ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// नोट गर्नुहोस् कि हामीलाई `: Vec<i32>` को बायाँ तर्फ पट्टि चाहिएको थियो।यसको कारण हामी संकलन गर्न सक्दछौं, उदाहरणको लागि, यसको सट्टामा एक [`VecDeque<T>`]:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// `doubled` लाई एनोटेट गर्नुको सट्टा 'turbofish' प्रयोग गर्दै:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// किनभने `collect()` ले केवल तपाईंले स collecting्कलन गरिरहनुभएको कुराको ख्याल राख्दछ, तपाईं अझै पनि आंशिक प्रकारको संकेत, `_`, टर्बोफिशको साथ प्रयोग गर्न सक्नुहुनेछ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// `collect()` [`String`] बनाउन प्रयोग गर्दै:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// यदि तपाईंसँग एउटा सूची छ भने of परिणाम<T, E>`][` Result`] s, तपाईं `collect()` प्रयोग गर्न सक्नुहुन्छ ती मध्ये कुनै पनि असफल भयो कि भनेर हेर्नका लागि:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // हामीलाई पहिलो त्रुटि दिन्छ
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // हामीलाई उत्तरहरूको सूची दिन्छ
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// एक पुनरावृत्ति खान्छ, यसबाट दुई संग्रहहरू सिर्जना गर्दछ।
    ///
    /// `partition()` मा पारित प्रेडिकेट `true`, वा `false` फर्काउन सक्छ।
    /// `partition()` जोडी फर्काउँछ, सबै तत्वहरू जसको लागि यसले `true` फर्काउँछ, र सबै तत्वहरू जसको लागि यसले `false` फर्काउँछ।
    ///
    ///
    /// [`is_partitioned()`] र [`partition_in_place()`] पनि हेर्नुहोस्।
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// दिईएको पूर्वानुमानको अनुसार यो इट्रेटरको एलिमेन्टहरू *इन-प्लेस* पुन: क्रमबद्ध गर्दछ, जस्तै कि `true` फर्कने सबै ती `false` फर्केका सबै पछि।
    ///
    /// भेटिए `true` तत्वहरूको संख्या फर्काउँछ।
    ///
    /// विभाजित वस्तुहरूको सापेक्षिक आदेश कायम छैन।
    ///
    /// [`is_partitioned()`] र [`partition()`] पनि हेर्नुहोस्।
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // साँझ र बाधा को बीचमा पार्टिसन
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: के हामीले काउन्ट ओभरफ्लो हुनेको बारेमा चिन्ता गर्नुपर्छ?भन्दा बढि पाउनको लागि एक मात्र तरीका
        // `usize::MAX` परिवर्तनीय सन्दर्भ ZSTs सँग छ, जुन विभाजनको लागि उपयोगी छैन ...

        // यी बन्द "factory" प्रकार्यहरू `Self` मा उदारता बाट बच्नको लागि अवस्थित छ।

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // बारम्बार पहिलो `false` फेला पार्नुहोस् र अन्तिम `true` सँग यसलाई बदल्नुहोस्।
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// जाँच गर्दछ कि यदि यो इट्रेटरको एलिमेन्ट्स पूर्वानुमानको अनुसार विभाजन गरिएको छ, कि ती सबै जसले `true` फर्कन्छन् ती सबै `false` फर्केका पहिले।
    ///
    ///
    /// [`partition()`] र [`partition_in_place()`] पनि हेर्नुहोस्।
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // कि त सबै आईटमहरू `true` परिक्षण गर्दछ, वा पहिलो खण्ड `false` मा रोकिन्छ र हामी जाँच गर्दछौं कि त्यहाँ पछि `true` 2X आईटमहरू छैनन्।
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// एक पुनरावृत्ति विधि जुन एक फंक्शन लागू गर्दछ जबसम्म यो सफलतापूर्वक फिर्ता हुन्छ, एकल, अन्तिम मानको उत्पादन गर्दछ।
    ///
    /// `try_fold()` दुई आर्गुमेन्टहरू लिन्छ: एक प्रारंभिक मान, र दुई आर्गुमेन्टहरूको साथ बन्द: एक 'accumulator', र एक एलिमेन्ट।
    /// क्लोजर या त सफलतापूर्वक फिर्ता हुन्छ, अर्को इट्रेसनको लागि इक्युमेटर हुनु पर्ने मानको साथ, वा यसले विफलता फिर्ता गर्दछ, एक त्रुटि मानको साथ कलरलाई फिर्ता प्रचार गरिएको छ (short-circuiting)।
    ///
    ///
    /// प्रारम्भिक मान पहिलो मानमा स accum्ग्रहणकर्ताको मान हुन्छ।यदि क्लोजर लागू गर्दा पुनरावृत्तिको प्रत्येक तत्त्वको बिरूद्ध सफल भयो, `try_fold()` अन्तिम संचयकलाई सफलताको रूपमा फर्काउँछ।
    ///
    /// फोल्डि useful उपयोगी छ जब तपाईंसँग केहि चीजको स it्ग्रह हुन्छ, र यसबाट एकल मान सिर्जना गर्न चाहनुहुन्छ।
    ///
    /// # कार्यान्वयनकर्ताहरूलाई नोट
    ///
    /// धेरै अन्य (forward) विधिहरूको यससँग एक पूर्वनिर्धारित कार्यान्वयनहरू छन्, त्यसैले यसलाई स्पष्ट रूपमा कार्यान्वयन गर्ने प्रयास गर्नुहोस् यदि यसले पूर्वनिर्धारित `for` लूप कार्यान्वयन भन्दा राम्रो केहि गर्न सक्दछ भने।
    ///
    /// विशेष रूपमा, यो कल `try_fold()` आन्तरिक भागहरूमा यस ईट्रेटर कम्पोज गरिएको छ कोशिस गर्नुहोस्।
    /// यदि बहु कलहरू आवश्यक छन् भने, `?` अपरेटर संचयकर्ता मानको साथसाथै चेनका लागि उपयुक्त हुन सक्छ, तर कुनै प्रारम्भिक वापसीको अघि समर्थन गर्न आवश्यक रहेको कुनै पनि आक्रमणकर्ताहरूदेखि सावधान रहनुहोस्।
    /// यो एक `&mut self` विधि हो, त्यसैले पुनरावृत्ति यहाँ त्रुटि थिचे पछि पुनः सुरु गर्न आवश्यक छ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // एर्रेको सबै एलिमेन्टहरूको चेक योग
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // 100 योग थप्दा यो योग ओभरफ्लो हुन्छ
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // किनकि यो छोटो सर्किट गरिएको छ, बाँकी तत्त्वहरू अझै पनी ईरेटरको माध्यमबाट उपलब्ध छन्।
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// एक पुनरावृत्ति विधि जुन इट्रेटरमा प्रत्येक वस्तुमा फलब्याउने प्रकार्य लागू गर्दछ, पहिलो त्रुटिमा रोकिन्छ र त्यो त्रुटि फिर्ता गर्छ।
    ///
    ///
    /// यो [`for_each()`] को फल्लिबल रूपको रूपमा वा [`try_fold()`] को स्टेटलेस संस्करणको रूपमा सोच्न पनि सकिन्छ।
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // यो छोटो सर्किट गरिएको छ, त्यसैले बाँकी वस्तुहरू अझै पनी अझै छन्:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// अन्तिम परिणाम फिर्ता गर्दै, अपरेशन लागू गरेर प्रत्येक तत्वलाई एक सञ्चयकर्तामा मोड्दछ।
    ///
    /// `fold()` दुई आर्गुमेन्टहरू लिन्छ: एक प्रारंभिक मान, र दुई आर्गुमेन्टहरूको साथ बन्द: एक 'accumulator', र एक एलिमेन्ट।
    /// क्लोजरले मानलाई फर्काउँछ जुन इक्युमेटरले अर्को पुनरावृत्तिको लागि हुनुपर्दछ।
    ///
    /// प्रारम्भिक मान पहिलो मानमा स accum्ग्रहणकर्ताको मान हुन्छ।
    ///
    /// यो क्लोजर एट्रेटरको प्रत्येक तत्वमा लागू गरिसकेपछि, `fold()` संचयकर्तालाई फर्काउँछ।
    ///
    /// यस अपरेशनलाई कहिलेकाँही 'reduce' वा 'inject' पनि भनिन्छ।
    ///
    /// फोल्डि useful उपयोगी छ जब तपाईंसँग केहि चीजको स it्ग्रह हुन्छ, र यसबाट एकल मान सिर्जना गर्न चाहनुहुन्छ।
    ///
    /// Note: `fold()`, र समान विधिहरू जुन सम्पूर्ण पुनरावृतकर्तालाई ट्रान्स् गर्दछ, अनन्त पुनरावृत्तिको लागि समाप्त हुन सक्दैन, traits मा पनि, जसको लागि परिणाम सीमित समयमा निर्धारित हुन्छ।
    ///
    /// Note: [`reduce()`] पहिलो तत्वलाई प्रारम्भिक मानको रूपमा प्रयोग गर्न सकिन्छ, यदि यदि संचयक प्रकार र वस्तु प्रकार समान छ।
    ///
    /// # कार्यान्वयनकर्ताहरूलाई नोट
    ///
    /// धेरै अन्य (forward) विधिहरूको यससँग एक पूर्वनिर्धारित कार्यान्वयनहरू छन्, त्यसैले यसलाई स्पष्ट रूपमा कार्यान्वयन गर्ने प्रयास गर्नुहोस् यदि यसले पूर्वनिर्धारित `for` लूप कार्यान्वयन भन्दा राम्रो केहि गर्न सक्दछ भने।
    ///
    ///
    /// विशेष रूपमा, यो कल `fold()` आन्तरिक भागहरूमा यस ईट्रेटर कम्पोज गरिएको छ कोशिस गर्नुहोस्।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // एर्रेको सबै तत्वहरूको योगफल
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// यहाँ पुनरावृत्ति को प्रत्येक चरण को माध्यम ले हिंड्न को लागी:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// र यसैले हाम्रो अन्तिम परिणाम, `6`.
    ///
    /// यो त्यस्तो व्यक्तिको लागि सामान्य हो जसले परिणाम निर्माणको लागि चीजहरूको सूचीको साथ X०1X लूप प्रयोग गर्न ईटरेटर्सको अधिक प्रयोग गरेन।ती `fold()`s मा परिवर्तन गर्न सकिन्छ:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // लुपको लागि:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // तिनीहरू उस्तै छन्
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// बारम्वार घटाउने अपरेशन लागू गरेर, एकलमा तत्वहरूलाई कम गर्दछ।
    ///
    /// यदि इटरेटर खाली छ भने, [`None`] फर्काउँछ;अन्यथा, कटौतीको परिणाम फर्काउँछ।
    ///
    /// कम्तिमा एक तत्वको साथ पुनरावृत्तिको लागि, यो [`fold()`] समान छ इटिएटरको पहिलो तत्वको साथ इनिशिअल मानको रूपमा, यसमा प्रत्येक पछिल्लो तत्व तहमा।
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// अधिकतम मान पत्ता लगाउनुहोस्:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// परीक्षण गर्दछ यदि एट्रेटरको प्रत्येक तत्व एक पूर्वानुमानसँग मेल खान्छ।
    ///
    /// `all()` `true` वा `false` फर्काउने क्लोजर लिन्छ।यसले यो बन्दकर्ताको प्रत्येक तत्वमा यो क्लोजर लागू गर्दछ, र यदि ती सबै `true` फर्काउँछन्, तब `all()` गर्दछ।
    /// यदि तिनीहरू मध्ये कुनै `false` फर्काउँछ भने, यसले `false` फर्काउँछ।
    ///
    /// `all()` छोटो सर्किटिंग हो;अर्को शब्दहरुमा, यसले `false` फेला पार्ने बित्तिकै प्रशोधन गर्न रोकिनेछ, केही फरक पर्दैन भन्ने कुरालाई ध्यान दिईन्छ भने परिणाम पनि `false` हुन्छ।
    ///
    ///
    /// खाली इट्रेटरले `true` फर्काउँछ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// पहिलो `false` मा रोकिदै:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // हामी अझै पनि `iter` प्रयोग गर्न सक्छौं, किनकि त्यहाँ अधिक तत्वहरू छन्।
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// परीक्षण गर्दछ यदि पुनरावृत्तिका कुनै पनि तत्त्व एक पूर्वानुमानसँग मेल खान्छ।
    ///
    /// `any()` `true` वा `false` फर्काउने क्लोजर लिन्छ।यसले यो बन्दकर्ताको प्रत्येक तत्वमा यो क्लोजर लागू गर्दछ, र यदि तिनीहरू मध्ये कुनै `true` फर्काउँछ, तब `any()` गर्दछ।
    /// यदि तिनीहरू सबै `false` फर्काउँछन्, यसले `false` फर्काउँछ।
    ///
    /// `any()` छोटो सर्किटिंग हो;अर्को शब्दहरुमा, यसले `true` फेला पार्ने बित्तिकै प्रशोधन गर्न रोकिनेछ, केही फरक पर्दैन भन्ने कुरालाई ध्यान दिईन्छ भने परिणाम पनि `true` हुन्छ।
    ///
    ///
    /// खाली इट्रेटरले `false` फर्काउँछ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// पहिलो `true` मा रोकिदै:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // हामी अझै पनि `iter` प्रयोग गर्न सक्छौं, किनकि त्यहाँ अधिक तत्वहरू छन्।
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// ईट्रेटरको एलिमेन्टको लागि खोजी गर्दछ जुन पूर्वानुमानलाई सन्तुष्टि दिन्छ।
    ///
    /// `find()` `true` वा `false` फर्काउने क्लोजर लिन्छ।
    /// यसले यो बन्दकर्ताको प्रत्येक तत्वमा यो क्लोजर लागू गर्दछ, र यदि ती मध्ये कुनै `true` फर्काउँछ, तब `find()` ले [`Some(element)`] फर्काउँछ।
    /// यदि तिनीहरू सबै `false` फर्काउँछन्, यसले [`None`] फर्काउँछ।
    ///
    /// `find()` छोटो सर्किटिंग हो;अर्को शब्दहरुमा, यसले `true` फर्कने बित्तिकै प्रशोधन गर्न रोकिनेछ।
    ///
    /// किनभने `find()` ले सन्दर्भ लिन्छ, र धेरै पुनरावृत्तिहरू सन्दर्भहरूमा पुनरावृत्ति गर्दछ, यसले सम्भावित भ्रमित स्थितितर्फ डो .्याउँछ जहाँ तर्क दोहोरो सन्दर्भ हो।
    ///
    /// तपाईं XTX को साथ तलका उदाहरणहरूमा यो प्रभाव देख्न सक्नुहुनेछ।
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// पहिलो `true` मा रोकिदै:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // हामी अझै पनि `iter` प्रयोग गर्न सक्छौं, किनकि त्यहाँ अधिक तत्वहरू छन्।
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// नोट गर्नुहोस् कि `iter.find(f)` `iter.filter(f).next()` बराबर छ।
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// पुनरावृत्तिको तत्वहरूमा प्रकार्य लागू गर्दछ र पहिलो गैर-परिणामलाई फर्काउँछ।
    ///
    ///
    /// `iter.find_map(f)` `iter.filter_map(f).next()` बराबर छ।
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// पुनरावृत्तिको तत्वहरूमा प्रकार्य लागू गर्दछ र पहिलो सही परिणाम वा पहिलो त्रुटि फर्काउँछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// एक इटरेटरमा एक तत्वको लागि खोजी गर्दछ, यसको सूचकांक फिर्ता गर्दै।
    ///
    /// `position()` `true` वा `false` फर्काउने क्लोजर लिन्छ।
    /// यसले यो बन्दकर्ताको प्रत्येक तत्वमा यो क्लोजर लागू गर्दछ, र यदि ती मध्ये एक `true` फर्काउँछ, तब `position()` [`Some(index)`] फर्काउँछ।
    /// यदि तिनीहरू सबै `false` फर्काउँछन्, यसले [`None`] फर्काउँछ।
    ///
    /// `position()` छोटो सर्किटिंग हो;अर्को शब्दहरुमा, यो `true` फेला परेपछि यसको प्रकृया रोकिनेछ।
    ///
    /// # ओभरफ्लो व्यवहार
    ///
    /// विधिले ओभरफ्लोहरू विरूद्ध कुनै सुरक्षा गर्दैन, त्यसैले यदि त्यहाँ [`usize::MAX`] भन्दा बढी मेल खाने तत्वहरू छन् भने, यसले या त गलत परिणाम वा panics उत्पादन गर्दछ।
    ///
    /// यदि डिबग assertions सक्षम छन्, एक panic ग्यारेन्टी छ।
    ///
    /// # Panics
    ///
    /// यो प्रकार्य panic हुन सक्छ यदि ईटरटरमा `usize::MAX` भन्दा बढी मिल्दो तत्त्वहरू छन् भने।
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// पहिलो `true` मा रोकिदै:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // हामी अझै पनि `iter` प्रयोग गर्न सक्छौं, किनकि त्यहाँ अधिक तत्वहरू छन्।
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // फिर्ता सूचकांक पुनरावृत्तिक स्थितिमा निर्भर गर्दछ
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// दायाँबाट इटरेटरमा एलिमेन्टको लागि खोजी गर्दछ, यसको सूचकांक फिर्ता गर्दै।
    ///
    /// `rposition()` `true` वा `false` फर्काउने क्लोजर लिन्छ।
    /// यसले यो बन्दकर्तालाई एलिटरको प्रत्येक तत्वमा अन्त्यबाट सुरू गरेर लागू गर्दछ, र यदि ती मध्ये एक `true` फर्काउँछ भने, `rposition()` ले [`Some(index)`] फर्काउँछ।
    ///
    /// यदि तिनीहरू सबै `false` फर्काउँछन्, यसले [`None`] फर्काउँछ।
    ///
    /// `rposition()` छोटो सर्किटिंग हो;अर्को शब्दहरुमा, यो `true` फेला परेपछि यसको प्रकृया रोकिनेछ।
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// पहिलो `true` मा रोकिदै:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // हामी अझै पनि `iter` प्रयोग गर्न सक्छौं, किनकि त्यहाँ अधिक तत्वहरू छन्।
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // यहाँ एक ओभरफ्लो जाँचको आवश्यक छैन, किनकि `ExactSizeIterator` ले देखाउँदछ कि तत्वहरूको संख्या `usize` मा फिट हुन्छ।
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// एक इटरेटरको अधिकतम तत्व फर्काउँछ।
    ///
    /// यदि धेरै तत्वहरू समान रूपमा अधिकतम भएमा, अन्तिम तत्व फिर्ता हुन्छ।
    /// यदि इटरेटर खाली छ, [`None`] फिर्ता गरियो।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// एक इरेटरको न्यूनतम तत्व फर्काउँछ।
    ///
    /// यदि धेरै तत्वहरू समान रूपमा न्यूनतम छन् भने, पहिलो तत्व फिर्ता हुन्छ।
    /// यदि इटरेटर खाली छ, [`None`] फिर्ता गरियो।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// एलिमेन्ट फिर्ता गर्दछ जुन निर्दिष्ट प्रकार्यबाट अधिकतम मान दिन्छ।
    ///
    ///
    /// यदि धेरै तत्वहरू समान रूपमा अधिकतम भएमा, अन्तिम तत्व फिर्ता हुन्छ।
    /// यदि इटरेटर खाली छ, [`None`] फिर्ता गरियो।
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// एलिमेन्ट फर्काउँछ जुन निर्दिष्ट तुलना प्रकार्यको सन्दर्भमा अधिकतम मान दिन्छ।
    ///
    ///
    /// यदि धेरै तत्वहरू समान रूपमा अधिकतम भएमा, अन्तिम तत्व फिर्ता हुन्छ।
    /// यदि इटरेटर खाली छ, [`None`] फिर्ता गरियो।
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// एलिमेन्ट फिर्ता गर्दछ जुन निर्दिष्ट प्रकार्यबाट न्यूनतम मान दिन्छ।
    ///
    ///
    /// यदि धेरै तत्वहरू समान रूपमा न्यूनतम छन् भने, पहिलो तत्व फिर्ता हुन्छ।
    /// यदि इटरेटर खाली छ, [`None`] फिर्ता गरियो।
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// एलिमेन्ट फर्काउँछ जुन निर्दिष्ट तुलना प्रकार्यको सन्दर्भमा न्यूनतम मान दिन्छ।
    ///
    ///
    /// यदि धेरै तत्वहरू समान रूपमा न्यूनतम छन् भने, पहिलो तत्व फिर्ता हुन्छ।
    /// यदि इटरेटर खाली छ, [`None`] फिर्ता गरियो।
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// एक पुनरावृतकर्ताको दिशा बदल्छ।
    ///
    /// सामान्यतया, पुनरावृत्तिहरू बाँयाबाट दायाँ तिर लाग्छ।
    /// `rev()` प्रयोग गरिसकेपछि, एक पुनरावृत्तिकर्ताले यसको सट्टा दायाँबाट बाँया पुनरावृत गर्दछ।
    ///
    /// यो मात्र सम्भव छ यदि ईटरटरको अन्त्य छ, त्यसैले `rev()` मात्र [`DoubleEidedIterator`] s मा काम गर्दछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// जोडीहरूको ईटरेटर कन्टेनरको जोडीमा रूपान्तरण गर्दछ।
    ///
    /// `unzip()` जोडीहरूको सम्पूर्ण इट्रेटर खान्छ, दुई संग्रहहरू उत्पादन गर्दछ: एक जोडीको बायाँ तत्वहरूबाट, र एक दायाँ तत्त्वहरूबाट।
    ///
    ///
    /// यो प्रकार्य एक अर्थमा [`zip`] को विपरित हो।
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// एक इटरेटर बनाउँदछ जसले यसको सबै तत्वहरूको प्रतिलिपि गर्दछ।
    ///
    /// यो उपयोगी छ जब तपाईंसँग `&T` भन्दा माथि एक iterator छ, तर तपाईंलाई `T` मा एक इटरेटर चाहिन्छ।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // प्रतिलिपि गरिएको .map(|&x| x) जस्तै छ
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// एक इटरेटर बनाउँदछ जुन [`क्लोन] यसको सबै तत्वहरू।
    ///
    /// यो उपयोगी छ जब तपाईंसँग `&T` भन्दा माथि एक iterator छ, तर तपाईंलाई `T` मा एक इटरेटर चाहिन्छ।
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // क्लोन गरिएको पूर्ण .map(|&x| x) X जस्तै छ
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// एक निरन्तर पुनरावृत्ति हुन्छ।
    ///
    /// [`None`] मा रोक्नुको सट्टा, इट्रेटर बरु फेरि सुरु हुनेछ, शुरूबाट।फेरि पुनरावृत्ति पछि, यो फेरि सुरूमा फेरि सुरू हुन्छ।र फेरि।
    /// र फेरि।
    /// Forever.
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// एक ईरेटरको तत्वहरूको योगफल दिन्छ।
    ///
    /// प्रत्येक तत्व लिन्छ, तिनीहरूलाई जोड्दछ, र परिणाम फर्काउँछ।
    ///
    /// खाली इट्रेटरले प्रकारको शून्य मान फर्काउँछ।
    ///
    /// # Panics
    ///
    /// जब `sum()` कल गर्दै र एक आदिम पूर्णांक प्रकार फिर्ता भइरहेको छ, यो विधि panic हुनेछ यदि गणना ओभरफ्लो र डिबग एसेर्सन सक्षम भए।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// सम्पूर्ण एट्रेटरमा इन्टरेट गर्दछ, सबै तत्वहरूलाई गुणा गर्दछ
    ///
    /// खाली इट्रेटरले प्रकारको एक मान फर्काउँछ।
    ///
    /// # Panics
    ///
    /// जब `product()` कल गर्दै र एक आदिम पूर्णांक प्रकार फिर्ता भइरहेको छ, विधि panic हुनेछ यदि गणना ओभरफ्लोज र डिबग एसेर्सन सक्षम भए।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) यो [`Iterator`] को तत्वहरूलाई अर्कोसँग तुलना गर्दछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) यो [`Iterator`] को तत्वहरूलाई निर्दिष्ट तुलना प्रकार्यको सन्दर्भमा अर्कोसँग तुलना गर्दछ।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) यो [`Iterator`] को तत्वहरूलाई अर्कोसँग तुलना गर्दछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) यो [`Iterator`] को तत्वहरूलाई निर्दिष्ट तुलना प्रकार्यको सन्दर्भमा अर्कोसँग तुलना गर्दछ।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// निर्धारण गर्दछ कि यदि यो [`Iterator`] को एलिमेन्ट्स अर्कोसँग बराबर छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// निर्धारित गर्दछ यदि यो [`Iterator`] को एलिमेन्ट्स अर्कोसँग समान बराबर कार्य तोकिएको समानता समारोहमा।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// निर्धारित गर्दछ कि यदि यो [`Iterator`] को एलिमेन्ट्स अर्कोसँग असमान छन्।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// निर्धारित गर्दछ कि यदि यो [`Iterator`] को एलिमेन्ट्स [lexicographically](Ord#lexicographical-comparison) अर्कोको भन्दा कम छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// निर्धारित गर्दछ कि यदि [`Iterator`] X को एलिमेन्ट्स [lexicographically](Ord#lexicographical-comparison) कम वा अर्कोको बराबर छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// निर्धारित गर्दछ कि यदि यो [`Iterator`] को एलिमेन्ट्स [lexicographically](Ord#lexicographical-comparison) अर्कोको भन्दा ठूलो छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// निर्धारित गर्दछ कि यदि यो [`Iterator`] को एलिमेन्ट्स [lexicographically](Ord#lexicographical-comparison) ठूलो वा अर्को भन्दा बराबर छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// जाँच गर्दछ कि यदि यो इट्रेटरको तत्व क्रमबद्ध गरिएको छ।
    ///
    /// त्यो हो, प्रत्येक तत्व `a` र यसको निम्न तत्व `b` को लागि, `a <= b` पकड गर्नुपर्छ।यदि इटरेटरले ठीक शून्य वा एक तत्व उत्पादन गर्दछ भने, `true` फिर्ता हुन्छ।
    ///
    /// नोट गर्नुहोस् कि यदि `Self::Item` मात्र `PartialOrd` हो, तर `Ord` होईन, माथिको परिभाषाले संकेत गर्दछ कि यदि कुनै दुई लगातार आईटमहरू तुलना नगरेमा यस प्रकार्यले `false` फिर्ता गर्दछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// जाँच गर्दछ कि यदि यो इट्रेटरको एलिमेन्ट दिईएको कम्प्यारेटर प्रकार्य प्रयोग गरी क्रमबद्ध गरिएको छ।
    ///
    /// `PartialOrd::partial_cmp` को सट्टामा, यो प्रकार्य दिईएको `compare` प्रकार्य प्रयोग गर्दछ दुई तत्वहरूको अर्डरिंग निर्धारित गर्न।
    /// यस बाहेक, यो [`is_sorted`] को बराबर हो;अधिक जानकारीको लागि यसको कागजात हेर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// जाँच गर्दछ कि यदि यो इट्रेटरको एलिमेन्ट्स दिइएको कुञ्जी एक्स्ट्र्यासन प्रकार्य प्रयोग गरी क्रमबद्ध गरिएको छ।
    ///
    /// इटरेटरको तत्वहरू सिधा तुलना गर्नुको सट्टा, यो प्रकार्यले तत्वहरूको कुञ्जीहरू तुलना गर्छ, `f` द्वारा निर्धारण गरे अनुसार।
    /// यस बाहेक, यो [`is_sorted`] को बराबर हो;अधिक जानकारीको लागि यसको कागजात हेर्नुहोस्।
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// [TrustedRandomAccess] हेर्नुहोस्
    // असामान्य नाम विधि रिजोलुसनमा X टक्कर हेर्नुहोस् नाम टकरावबाट जोगिन हो।
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}