use crate::iter;
use crate::num::Wrapping;

/// Trait प्रकारहरू प्रतिनिधित्व गर्न जुन एक इट्रेटरको योगफल सिर्जना गरेर सिर्जना गर्न सकिन्छ।
///
/// यो trait पुनरावर्तनकर्ताहरूमा [`sum()`] विधि कार्यान्वयन गर्न प्रयोग गरिन्छ।
/// trait लागू गर्ने प्रकारहरू [`sum()`] विधिद्वारा उत्पन्न गर्न सकिन्छ।
/// [`FromIterator`] जस्तै यो trait शायद नै सीधा कल गर्नु पर्छ र यसको सट्टा [`Iterator::sum()`] मार्फत अन्तरक्रिया गर्नु पर्छ।
///
///
/// [`sum()`]: Sum::sum
/// [`FromIterator`]: iter::FromIterator
#[stable(feature = "iter_arith_traits", since = "1.12.0")]
pub trait Sum<A = Self>: Sized {
    /// विधि जसले एक इटरेटर लिन्छ र "summing up" वस्तुहरू द्वारा `Self` उत्पन्न गर्दछ।
    ///
    #[stable(feature = "iter_arith_traits", since = "1.12.0")]
    fn sum<I: Iterator<Item = A>>(iter: I) -> Self;
}

/// Trait प्रकारहरू प्रतिनिधित्व गर्न जुन इट्रेटरको गुणा तत्त्वहरू द्वारा सिर्जना गर्न सकिन्छ।
///
/// यो trait पुनरावर्तनकर्ताहरूमा [`product()`] विधि कार्यान्वयन गर्न प्रयोग गरिन्छ।
/// trait लागू गर्ने प्रकारहरू [`product()`] विधिद्वारा उत्पन्न गर्न सकिन्छ।
/// [`FromIterator`] जस्तै यो trait शायद नै सीधा कल गर्नु पर्छ र यसको सट्टा [`Iterator::product()`] मार्फत अन्तरक्रिया गर्नु पर्छ।
///
///
/// [`product()`]: Product::product
/// [`FromIterator`]: iter::FromIterator
///
#[stable(feature = "iter_arith_traits", since = "1.12.0")]
pub trait Product<A = Self>: Sized {
    /// विधि जसले एक इट्रेटर लिन्छ र वस्तुहरू गुणा गरेर तत्त्वहरूबाट `Self` उत्पन्न गर्दछ।
    ///
    #[stable(feature = "iter_arith_traits", since = "1.12.0")]
    fn product<I: Iterator<Item = A>>(iter: I) -> Self;
}

macro_rules! integer_sum_product {
    (@impls $zero:expr, $one:expr, #[$attr:meta], $($a:ty)*) => ($(
        #[$attr]
        impl Sum for $a {
            fn sum<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    $zero,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[$attr]
        impl Product for $a {
            fn product<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    $one,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }

        #[$attr]
        impl<'a> Sum<&'a $a> for $a {
            fn sum<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    $zero,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[$attr]
        impl<'a> Product<&'a $a> for $a {
            fn product<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    $one,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }
    )*);
    ($($a:ty)*) => (
        integer_sum_product!(@impls 0, 1,
                #[stable(feature = "iter_arith_traits", since = "1.12.0")],
                $($a)*);
        integer_sum_product!(@impls Wrapping(0), Wrapping(1),
                #[stable(feature = "wrapping_iter_arith", since = "1.14.0")],
                $(Wrapping<$a>)*);
    );
}

macro_rules! float_sum_product {
    ($($a:ident)*) => ($(
        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl Sum for $a {
            fn sum<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    0.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl Product for $a {
            fn product<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    1.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl<'a> Sum<&'a $a> for $a {
            fn sum<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    0.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl<'a> Product<&'a $a> for $a {
            fn product<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    1.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }
    )*)
}

integer_sum_product! { i8 i16 i32 i64 i128 isize u8 u16 u32 u64 u128 usize }
float_sum_product! { f32 f64 }

#[stable(feature = "iter_arith_traits_result", since = "1.16.0")]
impl<T, U, E> Sum<Result<U, E>> for Result<T, E>
where
    T: Sum<U>,
{
    /// प्रत्येक तत्वलाई [`Iterator`] मा लिन्छ: यदि यो [`Err`] हो भने, अरू कुनै पनि तत्त्वहरू लिइने छैन, र [`Err`] फर्काइन्छ।
    /// कुनै [`Err`] देखा पर्दैन, सबै तत्वहरूको योग फर्काउँछ।
    ///
    /// # Examples
    ///
    /// यो एक vector मा प्रत्येक पूर्णांक योगफल, यदि एक नकारात्मक तत्व सामना भयो भने योग अस्वीकार:
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<i32, &'static str> = v.iter().map(|&x: &i32|
    ///     if x < 0 { Err("Negative element found") }
    ///     else { Ok(x) }
    /// ).sum();
    /// assert_eq!(res, Ok(3));
    /// ```
    ///
    ///
    fn sum<I>(iter: I) -> Result<T, E>
    where
        I: Iterator<Item = Result<U, E>>,
    {
        iter::process_results(iter, |i| i.sum())
    }
}

#[stable(feature = "iter_arith_traits_result", since = "1.16.0")]
impl<T, U, E> Product<Result<U, E>> for Result<T, E>
where
    T: Product<U>,
{
    /// प्रत्येक तत्वलाई [`Iterator`] मा लिन्छ: यदि यो [`Err`] हो भने, अरू कुनै पनि तत्त्वहरू लिइने छैन, र [`Err`] फर्काइन्छ।
    /// कुनै [`Err`] देखा पर्दैन, सबै तत्वहरूको उत्पाद फिर्ता हुन्छ।
    ///
    fn product<I>(iter: I) -> Result<T, E>
    where
        I: Iterator<Item = Result<U, E>>,
    {
        iter::process_results(iter, |i| i.product())
    }
}

#[stable(feature = "iter_arith_traits_option", since = "1.37.0")]
impl<T, U> Sum<Option<U>> for Option<T>
where
    T: Sum<U>,
{
    /// प्रत्येक तत्वलाई [`Iterator`] मा लिन्छ: यदि यो [`None`] हो भने, अरू कुनै पनि तत्त्वहरू लिइने छैन, र [`None`] फर्काइन्छ।
    /// कुनै [`None`] देखा पर्दैन, सबै तत्वहरूको योग फर्काउँछ।
    ///
    /// # Examples
    ///
    /// यसले अक्षरको 'a' तारको vector मा स्थिति पूरा गर्दछ, यदि एक शब्दसँग 'a' वर्ण नभएको खण्डमा अपरेशनले `None` फर्काउँछ:
    ///
    ///
    /// ```
    /// let words = vec!["have", "a", "great", "day"];
    /// let total: Option<usize> = words.iter().map(|w| w.find('a')).sum();
    /// assert_eq!(total, Some(5));
    /// ```
    ///
    fn sum<I>(iter: I) -> Option<T>
    where
        I: Iterator<Item = Option<U>>,
    {
        iter.map(|x| x.ok_or(())).sum::<Result<_, _>>().ok()
    }
}

#[stable(feature = "iter_arith_traits_option", since = "1.37.0")]
impl<T, U> Product<Option<U>> for Option<T>
where
    T: Product<U>,
{
    /// प्रत्येक तत्वलाई [`Iterator`] मा लिन्छ: यदि यो [`None`] हो भने, अरू कुनै पनि तत्त्वहरू लिइने छैन, र [`None`] फर्काइन्छ।
    /// कुनै [`None`] देखा पर्दैन, सबै तत्वहरूको उत्पाद फिर्ता हुन्छ।
    ///
    fn product<I>(iter: I) -> Option<T>
    where
        I: Iterator<Item = Option<U>>,
    {
        iter.map(|x| x.ok_or(())).product::<Result<_, _>>().ok()
    }
}