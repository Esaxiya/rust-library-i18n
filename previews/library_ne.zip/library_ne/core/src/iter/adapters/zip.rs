use crate::cmp;
use crate::fmt::{self, Debug};
use crate::iter::{DoubleEndedIterator, ExactSizeIterator, FusedIterator, Iterator};
use crate::iter::{InPlaceIterable, SourceIter, TrustedLen};

/// एक पुनरावृत्ति जसले एक साथ दुई अन्य पुनरावृत्तिको पुनरावृत्ति गर्दछ।
///
/// यो `struct` [`Iterator::zip`] द्वारा बनाईएको हो।
/// अधिकको लागि यसको कागजात हेर्नुहोस्।
#[derive(Clone)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Zip<A, B> {
    a: A,
    b: B,
    // अनुक्रमणिका, लेन र a_len केवल zip को विशेष संस्करण द्वारा प्रयोग गरिन्छ
    index: usize,
    len: usize,
    a_len: usize,
}
impl<A: Iterator, B: Iterator> Zip<A, B> {
    pub(in crate::iter) fn new(a: A, b: B) -> Zip<A, B> {
        ZipImpl::new(a, b)
    }
    fn super_nth(&mut self, mut n: usize) -> Option<(A::Item, B::Item)> {
        while let Some(x) = Iterator::next(self) {
            if n == 0 {
                return Some(x);
            }
            n -= 1;
        }
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> Iterator for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        ZipImpl::next(self)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        ZipImpl::size_hint(self)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        ZipImpl::nth(self, n)
    }

    #[inline]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        // सुरक्षा: `ZipImpl::__iterator_get_unchecked` को उही सुरक्षा छ
        // `Iterator::__iterator_get_unchecked` को रूपमा आवश्यकताहरू।
        unsafe { ZipImpl::get_unchecked(self, idx) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> DoubleEndedIterator for Zip<A, B>
where
    A: DoubleEndedIterator + ExactSizeIterator,
    B: DoubleEndedIterator + ExactSizeIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)> {
        ZipImpl::next_back(self)
    }
}

// Zip विशेषज्ञता trait
#[doc(hidden)]
trait ZipImpl<A, B> {
    type Item;
    fn new(a: A, b: B) -> Self;
    fn next(&mut self) -> Option<Self::Item>;
    fn size_hint(&self) -> (usize, Option<usize>);
    fn nth(&mut self, n: usize) -> Option<Self::Item>;
    fn next_back(&mut self) -> Option<Self::Item>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator;
    // योसँग `Iterator::__iterator_get_unchecked` को जस्तै सुरक्षा आवश्यकताहरू छन्
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item
    where
        Self: Iterator + TrustedRandomAccess;
}

// जनरल जि.प.
#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);
    default fn new(a: A, b: B) -> Self {
        Zip {
            a,
            b,
            index: 0, // unused
            len: 0,   // unused
            a_len: 0, // unused
        }
    }

    #[inline]
    default fn next(&mut self) -> Option<(A::Item, B::Item)> {
        let x = self.a.next()?;
        let y = self.b.next()?;
        Some((x, y))
    }

    #[inline]
    default fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.super_nth(n)
    }

    #[inline]
    default fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        let a_sz = self.a.len();
        let b_sz = self.b.len();
        if a_sz != b_sz {
            // A, b लाई बराबर लम्बाइ समायोजित गर्नुहोस्
            if a_sz > b_sz {
                for _ in 0..a_sz - b_sz {
                    self.a.next_back();
                }
            } else {
                for _ in 0..b_sz - a_sz {
                    self.b.next_back();
                }
            }
        }
        match (self.a.next_back(), self.b.next_back()) {
            (Some(x), Some(y)) => Some((x, y)),
            (None, None) => None,
            _ => unreachable!(),
        }
    }

    #[inline]
    default fn size_hint(&self) -> (usize, Option<usize>) {
        let (a_lower, a_upper) = self.a.size_hint();
        let (b_lower, b_upper) = self.b.size_hint();

        let lower = cmp::min(a_lower, b_lower);

        let upper = match (a_upper, b_upper) {
            (Some(x), Some(y)) => Some(cmp::min(x, y)),
            (Some(x), None) => Some(x),
            (None, Some(y)) => Some(y),
            (None, None) => None,
        };

        (lower, upper)
    }

    default unsafe fn get_unchecked(&mut self, _idx: usize) -> <Self as Iterator>::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: TrustedRandomAccess + Iterator,
    B: TrustedRandomAccess + Iterator,
{
    fn new(a: A, b: B) -> Self {
        let a_len = a.size();
        let len = cmp::min(a_len, b.size());
        Zip { a, b, index: 0, len, a_len }
    }

    #[inline]
    fn next(&mut self) -> Option<(A::Item, B::Item)> {
        if self.index < self.len {
            let i = self.index;
            self.index += 1;
            // सुरक्षा: `i` `self.len` भन्दा सानो छ, त्यसैले `self.a.len()` र `self.b.len()` भन्दा सानो छ
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else if A::MAY_HAVE_SIDE_EFFECT && self.index < self.a_len {
            let i = self.index;
            self.index += 1;
            self.len += 1;
            // बेस कार्यान्वयनको सम्भावित साइड इफेक्ट्स SAFETY सँग मेल खान्छ: हामीले भर्खरै यो जाँच गर्‍यौं कि `i` <`self.a.len()`
            //
            unsafe {
                self.a.__iterator_get_unchecked(i);
            }
            None
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len - self.index;
        (len, Some(len))
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        let delta = cmp::min(n, self.len - self.index);
        let end = self.index + delta;
        while self.index < end {
            let i = self.index;
            self.index += 1;
            if A::MAY_HAVE_SIDE_EFFECT {
                // सुरक्षा: `delta` गणना गर्न `cmp::min` को उपयोग
                // `end` `self.len` भन्दा सानो वा बराबर हो भनेर सुनिश्चित गर्दछ, त्यसैले `i` `self.len` भन्दा सानो पनि छ।
                //
                unsafe {
                    self.a.__iterator_get_unchecked(i);
                }
            }
            if B::MAY_HAVE_SIDE_EFFECT {
                // सुरक्षा: माथिको जस्तै।
                unsafe {
                    self.b.__iterator_get_unchecked(i);
                }
            }
        }

        self.super_nth(n - delta)
    }

    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        if A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT {
            let sz_a = self.a.size();
            let sz_b = self.b.size();
            // A, b लाई बराबर लम्बाइ समायोजित गर्नुहोस्, `next_back` को केवल पहिलो कलले यो सुनिश्चित गर्नुहोला निश्चित गर्नुहोस्, अन्यथा हामी `get_unchecked()` कल गरेपछि `self.next_back()` मा कलमा प्रतिबन्ध तोड्नेछौं।
            //
            //
            if sz_a != sz_b {
                let sz_a = self.a.size();
                if A::MAY_HAVE_SIDE_EFFECT && sz_a > self.len {
                    for _ in 0..sz_a - self.len {
                        self.a.next_back();
                    }
                    self.a_len = self.len;
                }
                let sz_b = self.b.size();
                if B::MAY_HAVE_SIDE_EFFECT && sz_b > self.len {
                    for _ in 0..sz_b - self.len {
                        self.b.next_back();
                    }
                }
            }
        }
        if self.index < self.len {
            self.len -= 1;
            self.a_len -= 1;
            let i = self.len;
            // सुरक्षा: `i` `self.len` को अघिल्लो मान भन्दा सानो छ,
            // जुन `self.a.len()` र `self.b.len()` भन्दा सानो वा बराबर पनि छ
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else {
            None
        }
    }

    #[inline]
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item {
        let idx = self.index + idx;
        // सुरक्षा: कलरले `Iterator::__iterator_get_unchecked` का लागि अनुबंध समर्थन गर्नु पर्छ।
        //
        unsafe { (self.a.__iterator_get_unchecked(idx), self.b.__iterator_get_unchecked(idx)) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> ExactSizeIterator for Zip<A, B>
where
    A: ExactSizeIterator,
    B: ExactSizeIterator,
{
}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<A, B> TrustedRandomAccess for Zip<A, B>
where
    A: TrustedRandomAccess,
    B: TrustedRandomAccess,
{
    const MAY_HAVE_SIDE_EFFECT: bool = A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT;
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A, B> FusedIterator for Zip<A, B>
where
    A: FusedIterator,
    B: FusedIterator,
{
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, B> TrustedLen for Zip<A, B>
where
    A: TrustedLen,
    B: TrustedLen,
{
}

// मनपरी रूपमा ztr पुनरावृत्ति को बायाँ तिर निकाल्न योग्य "source" को रूपमा चयन गर्दछ यसलाई दुबै प्रयास गर्न सक्षम हुन नकारात्मक trait bounds आवश्यक पर्दछ
//
#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S, A, B> SourceIter for Zip<A, B>
where
    A: SourceIter<Source = S>,
    B: Iterator,
    S: Iterator,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // सुरक्षा: असुरक्षित प्रकार्य अगाडि नै समान आवश्यकताहरूको साथ असुरक्षित प्रकार्यमा
        unsafe { SourceIter::as_inner(&mut self.a) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
// आईटममा सीमित: प्रतिलिपि गर्नुहोस् Zip को ट्रस्टेडड्रान्ड एसेकको प्रयोग र स्रोतको ड्रप कार्यान्वयनको बीचको कुराकानी अस्पष्ट छ।
//
// स्रोतको तार्किक रूपमा उन्नत गरिएको समय संख्या फिर्ता गर्ने थप विधि (next()) कल नगरी स्रोतको बाँकी अंश ड्रप गर्न आवश्यक पर्दछ।
//
//
unsafe impl<A: InPlaceIterable, B: Iterator> InPlaceIterable for Zip<A, B> where A::Item: Copy {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Debug, B: Debug> Debug for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        ZipFmt::fmt(self, f)
    }
}

trait ZipFmt<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result;
}

impl<A: Debug, B: Debug> ZipFmt<A, B> for Zip<A, B> {
    default fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Zip").field("a", &self.a).field("b", &self.b).finish()
    }
}

impl<A: Debug + TrustedRandomAccess, B: Debug + TrustedRandomAccess> ZipFmt<A, B> for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // यो *सुरक्षित छैन* समाहित पुनरावृत्तकर्ताहरुमा fmt मा कल गर्न को लागी, एकपटक जब हामी पुनरावृत्ति गर्न थाल्छौं तिनीहरू अनौंठो, सम्भावित असुरक्षित, स्थितिमा छन्।
        //
        f.debug_struct("Zip").finish()
    }
}

/// एक पुनरावृत्तिकर्ता जसको वस्तुहरू अनियमित-पहुँचयोग्य कुशलतापूर्वक छन्
///
/// # Safety
///
/// पुनरावृत्तिको `size_hint` कल गर्न सटीक र सस्ता हुनुपर्दछ।
///
/// `size` ओभरराइड हुन सक्दैन।
///
/// `<Self as Iterator>::__iterator_get_unchecked` निम्नलिखित सर्तहरू पूरा भएमा कल गर्न सुरक्षित हुनुपर्दछ।
///
/// 1. `0 <= idx` र `idx < self.size()`।
/// 2. यदि `self: !Clone`, तब `get_unchecked` कहिल्यै एकै पटक `self` मा एक भन्दा बढि मा भनिदैन।
/// 3. `self.get_unchecked(idx)` बोलाए पछि `next_back` अधिकतम `self.size() - idx - 1` पटक मात्र कल गरीन्छ।
/// 4. `get_unchecked` कल भएपछि, तलका विधिहरू मात्र भनिनेछ `self`:
///     * `std::clone::Clone::clone()`
///     * `std::iter::Iterator::size_hint()`
///     * `std::iter::Iterator::next_back()`
///     * `std::iter::Iterator::__iterator_get_unchecked()`
///     * `std::iter::TrustedRandomAccess::size()`
///
/// यसबाहेक, यी सर्तहरू पूरा भएका छन्, यसले ग्यारेन्टी गर्नै पर्छ:
///
/// * यो `size_hint` बाट फिर्ता मान परिवर्तन गर्दैन
/// * `get_unchecked` कल गरेपछि `self` मा माथि सूचीबद्ध विधिहरू कल गर्न सुरक्षित हुनुपर्दछ, आवश्यक traits कार्यान्वयन गरिएको छ भन्ने विश्वास गरेर।
///
/// * यो `get_unchecked` कल पछि `self` ड्रप गर्न पनि सुरक्षित हुनुपर्दछ।
///
///
///
///
#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
#[rustc_specialization_trait]
pub unsafe trait TrustedRandomAccess: Sized {
    // सुविधा विधि।
    fn size(&self) -> usize
    where
        Self: Iterator,
    {
        self.size_hint().0
    }
    /// `true` यदि एक इट्रेटर तत्व पाउँदा साइड इफेक्ट हुन सक्छ।
    /// खातामा भित्री पुनरावृत्तिकै लिन नबिर्सनुहोस्।
    const MAY_HAVE_SIDE_EFFECT: bool;
}

/// `Iterator::__iterator_get_unchecked` लाई मन पराउछ, तर यो `U: TrustedRandomAccess` जान्न कम्पाइलर आवश्यक पर्दैन।
///
///
/// ## Safety
///
/// समान आवश्यकताहरू `get_unchecked` लाई सीधा कल गर्दै।
#[doc(hidden)]
pub(in crate::iter::adapters) unsafe fn try_get_unchecked<I>(it: &mut I, idx: usize) -> I::Item
where
    I: Iterator,
{
    // सुरक्षा: कलरले `Iterator::__iterator_get_unchecked` का लागि अनुबंध समर्थन गर्नु पर्छ।
    //
    unsafe { it.try_get_unchecked(idx) }
}

unsafe trait SpecTrustedRandomAccess: Iterator {
    /// यदि `Self: TrustedRandomAccess`, यो `Iterator::__iterator_get_unchecked(self, index)` कल गर्न सुरक्षित हुनुपर्दछ।
    ///
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item;
}

unsafe impl<I: Iterator> SpecTrustedRandomAccess for I {
    default unsafe fn try_get_unchecked(&mut self, _: usize) -> Self::Item {
        panic!("Should only be called on TrustedRandomAccess iterators");
    }
}

unsafe impl<I: Iterator + TrustedRandomAccess> SpecTrustedRandomAccess for I {
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item {
        // सुरक्षा: कलरले `Iterator::__iterator_get_unchecked` का लागि अनुबंध समर्थन गर्नु पर्छ।
        //
        unsafe { self.__iterator_get_unchecked(index) }
    }
}