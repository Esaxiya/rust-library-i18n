use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable, TrustedLen};
use crate::ops::Try;

/// एक इन्ट्रेटर `peek()` को साथ अर्को तत्वमा वैकल्पिक सन्दर्भ फर्काउँछ।
///
///
/// यो `struct` [`Iterator`] मा [`peekable`] विधिद्वारा सिर्जना गरिएको हो।
/// अधिकको लागि यसको कागजात हेर्नुहोस्।
///
/// [`peekable`]: Iterator::peekable
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Peekable<I: Iterator> {
    iter: I,
    /// एक peeked मान याद गर्नुहोस्, यो केहि थिएन भने पनि।
    peeked: Option<Option<I::Item>>,
}

impl<I: Iterator> Peekable<I> {
    pub(in crate::iter) fn new(iter: I) -> Peekable<I> {
        Peekable { iter, peeked: None }
    }
}

// Peekable को याद गर्नु पर्छ यदि `.peek()` विधिमा कुनै पनि देखिएको छैन।
// यसले `.peek() लाई सुनिश्चित गर्दछ;.peek();` वा `.peek();.next();` मात्र एक पटक मा अन्तर्निहित iterator अग्रिम।
// यसले आफैंमा इरेटरलाई फ्युज बनाउँदैन।
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> Iterator for Peekable<I> {
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        match self.peeked.take() {
            Some(v) => v,
            None => self.iter.next(),
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn count(mut self) -> usize {
        match self.peeked.take() {
            Some(None) => 0,
            Some(Some(_)) => 1 + self.iter.count(),
            None => self.iter.count(),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        match self.peeked.take() {
            Some(None) => None,
            Some(v @ Some(_)) if n == 0 => v,
            Some(Some(_)) => self.iter.nth(n - 1),
            None => self.iter.nth(n),
        }
    }

    #[inline]
    fn last(mut self) -> Option<I::Item> {
        let peek_opt = match self.peeked.take() {
            Some(None) => return None,
            Some(v) => v,
            None => None,
        };
        self.iter.last().or(peek_opt)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let peek_len = match self.peeked {
            Some(None) => return (0, Some(0)),
            Some(Some(_)) => 1,
            None => 0,
        };
        let (lo, hi) = self.iter.size_hint();
        let lo = lo.saturating_add(peek_len);
        let hi = match hi {
            Some(x) => x.checked_add(peek_len),
            None => None,
        };
        (lo, hi)
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let acc = match self.peeked.take() {
            Some(None) => return try { init },
            Some(Some(v)) => f(init, v)?,
            None => init,
        };
        self.iter.try_fold(acc, f)
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let acc = match self.peeked {
            Some(None) => return init,
            Some(Some(v)) => fold(init, v),
            None => init,
        };
        self.iter.fold(acc, fold)
    }
}

#[stable(feature = "double_ended_peek_iterator", since = "1.38.0")]
impl<I> DoubleEndedIterator for Peekable<I>
where
    I: DoubleEndedIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        match self.peeked.as_mut() {
            Some(v @ Some(_)) => self.iter.next_back().or_else(|| v.take()),
            Some(None) => None,
            None => self.iter.next_back(),
        }
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        match self.peeked.take() {
            Some(None) => try { init },
            Some(Some(v)) => match self.iter.try_rfold(init, &mut f).into_result() {
                Ok(acc) => f(acc, v),
                Err(e) => {
                    self.peeked = Some(Some(v));
                    Try::from_error(e)
                }
            },
            None => self.iter.try_rfold(init, f),
        }
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        match self.peeked {
            Some(None) => init,
            Some(Some(v)) => {
                let acc = self.iter.rfold(init, &mut fold);
                fold(acc, v)
            }
            None => self.iter.rfold(init, fold),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator> ExactSizeIterator for Peekable<I> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator> FusedIterator for Peekable<I> {}

impl<I: Iterator> Peekable<I> {
    /// एक्सटोररको प्रगति नगरी next() मानको सन्दर्भ फर्काउँछ।
    ///
    /// [`next`] जस्तै, यदि त्यहाँ मान छ भने, यो `Some(T)` मा लपेटिन्छ।
    /// तर यदि पुनरावृत्ति समाप्त भयो, `None` फर्काइयो।
    ///
    /// [`next`]: Iterator::next
    ///
    /// किनभने `peek()` एक सन्दर्भ फर्काउँछ, र धेरै पुनरावृत्तिहरू सन्दर्भमा पुनरावृत्ति गर्दछ, त्यहाँ सम्भावित भ्रमित स्थिति हुन सक्दछ जहाँ फिर्ती मान डबल सन्दर्भ हो।
    /// तपाईं तलका उदाहरणहरूमा यो प्रभाव देख्न सक्नुहुन्छ।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() हामीलाई future मा हेर्न दिनुहोस्
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // यदि हामीले बहु पटक `peek` गर्यौं भने पनि इटरेटर अग्रिम हुँदैन
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // इटररेटर समाप्त भएपछि `peek()` पनि हुन्छ
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&mut self) -> Option<&I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_ref()
    }

    /// एक्सटोररलाई अगाडि बढाउनु नै next() मानमा म्यूटेबल सन्दर्भ फर्काउँछ।
    ///
    /// [`next`] जस्तै, यदि त्यहाँ मान छ भने, यो `Some(T)` मा लपेटिन्छ।
    /// तर यदि पुनरावृत्ति समाप्त भयो, `None` फर्काइयो।
    ///
    /// किनभने `peek_mut()` एक सन्दर्भ फर्काउँछ, र धेरै पुनरावृत्तिहरू सन्दर्भमा पुनरावृत्ति गर्दछ, त्यहाँ सम्भावित भ्रमित स्थिति हुन सक्दछ जहाँ फिर्ती मान डबल सन्दर्भ हो।
    /// तपाईं तलका उदाहरणहरूमा यो प्रभाव देख्न सक्नुहुन्छ।
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// #![feature(peekable_peek_mut)]
    /// let mut iter = [1, 2, 3].iter().peekable();
    ///
    /// // `peek()` जस्तै, हामी future मा ईट्रेटरको प्रगति नगरी देख्न सक्छौं।
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // इटरेटरमा हेर्नुहोस् र म्युटेबल सन्दर्भको पछाडि मान सेट गर्नुहोस्।
    /// if let Some(p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     *p = &5;
    /// }
    ///
    /// // हामीले पुनरावृत्तिमा राख्नु पर्ने मान पुनरावृतकर्ताको रूपमा जारी रहन्छ।
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&5, &3]);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "peekable_peek_mut", issue = "78302")]
    pub fn peek_mut(&mut self) -> Option<&mut I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_mut()
    }

    /// उपभोक्ता गर्नुहोस् र यस इट्रेटरको अर्को मान फिर्ता गर्नुहोस् यदि सर्त सही छ भने।
    /// यदि `func` ले यस इटरेटरको अर्को मानको लागि `true` फर्काउँछ भने उपभोग गर्नुहोस् र फिर्ता गर्नुहोस्।
    /// अन्यथा, `None` फिर्ता गर्नुहोस्।
    /// # Examples
    /// नम्बर उपभोग गर्नुहोस् यदि यो ० बराबर छ।
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // पुनरावृत्तिको पहिलो वस्तु ० हो;उपभोग
    /// assert_eq!(iter.next_if(|&x| x == 0), Some(0));
    /// // पछिल्लो आइटम अब १ हो, त्यसैले X०१ X `false` फर्काउँछ।
    /// assert_eq!(iter.next_if(|&x| x == 0), None);
    /// // `next_if` अर्को वस्तुको मान बचत गर्दछ यदि यो `expected` बराबर थिएन।
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    ///
    /// १० भन्दा कम कुनै पनि उपभोग गर्नुहोस्।
    ///
    /// ```
    /// let mut iter = (1..20).peekable();
    /// // १० भन्दा कम सबै अंकहरू उपभोग गर्नुहोस्
    /// while iter.next_if(|&x| x < 10).is_some() {}
    /// // अर्को मान फिर्ता १० हुनेछ
    /// assert_eq!(iter.next(), Some(10));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if(&mut self, func: impl FnOnce(&I::Item) -> bool) -> Option<I::Item> {
        match self.next() {
            Some(matched) if func(&matched) => Some(matched),
            other => {
                // किनकि हामीले `self.next()` बोलायौं, हामीले `self.peeked` ख्यौं।
                assert!(self.peeked.is_none());
                self.peeked = Some(other);
                None
            }
        }
    }

    /// उपभोग गर्नुहोस् र अर्को वस्तु फिर्ता गर्नुहोस् यदि यो `expected` बराबर हो।
    /// # Example
    /// नम्बर उपभोग गर्नुहोस् यदि यो ० बराबर छ।
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // पुनरावृत्तिको पहिलो वस्तु ० हो;उपभोग
    /// assert_eq!(iter.next_if_eq(&0), Some(0));
    /// // पछिल्लो आइटम अब १ हो, त्यसैले X०१ X `false` फर्काउँछ।
    /// assert_eq!(iter.next_if_eq(&0), None);
    /// // `next_if_eq` अर्को वस्तुको मान बचत गर्दछ यदि यो `expected` बराबर थिएन।
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if_eq<T>(&mut self, expected: &T) -> Option<I::Item>
    where
        T: ?Sized,
        I::Item: PartialEq<T>,
    {
        self.next_if(|next| next == expected)
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I> TrustedLen for Peekable<I> where I: TrustedLen {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I: Iterator> SourceIter for Peekable<I>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // सुरक्षा: असुरक्षित प्रकार्य अगाडि नै समान आवश्यकताहरूको साथ असुरक्षित प्रकार्यमा
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable> InPlaceIterable for Peekable<I> {}