use crate::{iter::FusedIterator, ops::Try};

/// एक पुनरावृत्ति जसले अन्ततः दोहोर्याउँदछ।
///
/// यो `struct` [`Iterator`] मा [`cycle`] विधिद्वारा सिर्जना गरिएको हो।
/// अधिकको लागि यसको कागजात हेर्नुहोस्।
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // चक्र इटररेटर या त खाली वा असीम छ
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // पूर्ण पुनरावृत्ति हालको इटरेटर
        // यो आवश्यक छ किनकि `self.iter` खाली हुन सक्छ `self.orig` नभए पनि
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // पूर्ण चक्र पूरा गर्नुहोस्, ट्र्याक गर्दै साइकल ईटरटर खाली छ वा छैन भनेर।
        // हामी एक असीम लुप रोक्न खाली इट्रेटरको मामलामा प्रारम्भिक फर्कन आवश्यक छ
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // कुनै `fold` ओभरराइड छैन, किनकि `fold` `Cycle` को लागी धेरै अर्थ दिदैन, र हामी पूर्वनिर्धारित भन्दा राम्रो केहि गर्न सक्दैनौं।
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}