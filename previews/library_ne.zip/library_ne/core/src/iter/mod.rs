//! कम्पोजेबल बाह्य पुनरावृत्ति।
//!
//! यदि तपाईंले आफूलाई केही प्रकारको स of्ग्रहको साथ फेला पार्नुभयो, र भनेका संग्रहको तत्त्वहरूमा अपरेशन गर्न आवश्यक छ भने, तपाईं छिटो 'iterators' मा भाग्नुहुनेछ।
//! इटेटरहरू इडिएमेटिक Rust कोडमा भारी प्रयोग गरिन्छ, त्यसैले तिनीहरूसँग परिचित हुन लायक छ।
//!
//! अधिक वर्णन गर्नु अघि, यो मोड्युल कसरी संरचना गरिएको छ भन्ने कुरा गरौं:
//!
//! # Organization
//!
//! यो मोड्युल ठूलो रूपमा प्रकार द्वारा आयोजित गरीएको छ:
//!
//! * [Traits] मुख्य अंश हो: यी traits ले परिभाषित गर्छ कि कस्तो प्रकारको पुनरावृत्तिकर्ताहरू अवस्थित छन् र तपाईं तिनीहरूसँग के गर्न सक्नुहुन्छ।यी traits को विधिहरू केहि थप अध्ययन समय राख्न लायक छ।
//! * [Functions] केहि आधारभूत इटरेटर्स सिर्जना गर्नका लागि केहि उपयोगी तरीका प्रदान गर्नुहोस्
//! * [Structs] प्राय: यस मोड्युलको traits मा बिभिन्न विधिहरूको रिटर्न प्रकारहरू हुन्छन्।तपाईं सामान्यतया `struct` लाई नभई `struct` सिर्जना गर्ने विधिमा हेर्न चाहानुहुन्छ।
//! किन यसको बारेमा थप विवरणको लागि, '[कार्यान्वयन Iterator]' (#कार्यान्वयन-आइटरटर) हेर्नुहोस्।
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! त्यो हो!आउटरहरुमा खन्नुहोस्
//!
//! # Iterator
//!
//! यस मोड्युलको मुटु र आत्मा [`Iterator`] trait हो।[`Iterator`] को कोर यस्तो देखिन्छ:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! एक इटरेटरसँग एक विधि छ, [`next`], जुन जब कल गरिन्छ, [[Option`]] returns फिर्ता गर्दछ<Item>`।
//! [`next`] [`Some(Item)`] फिर्ता हुन्छ जब सम्म त्यहाँ तत्वहरू हुन्छन्, र एकचोटि ती सबै समाप्त भएपछि `None` फिर्ता हुन्छ कि इन्टरेसन समाप्त भएको स indicate्केत गर्न।
//! व्यक्तिगत पुनरावर्तीहरू पुनरावृत्ति पुनःसुरु गर्न छनौट गर्न सक्दछ, र त्यसैले [`next`] कल गरेर फेरि [`Some(Item)`] फिर्ता केहि बिन्दुमा सुरू गर्न सक्दछ (उदाहरणका लागि [`TryIter`] हेर्नुहोस्)।
//!
//!
//! [Te Iterator`] को पूर्ण परिभाषामा अरू धेरै विधिहरू समावेश गर्दछन्, तर तिनीहरू पूर्वनिर्धारित विधिहरू हुन्, [`next`] को शीर्षमा निर्मित, र त्यसैले तपाईं तिनीहरूलाई सित्तैमा पाउनुहुनेछ।
//!
//! इटेटरहरू कम्पोजेबल पनि हुन्छन्, र प्रशोधनको अधिक जटिल रूपहरू गर्न तिनीहरूलाई सँगै चेन गर्नु सामान्य छ।अधिक जानकारीको लागि तलको [Adapters](#adapters) सेक्सन हेर्नुहोस्।
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # पुनरावृत्ति को तीन रूपहरू
//!
//! त्यहाँ तीन साधारण विधिहरू छन् जुन संग्रहबाट पुनरावृत्तिहरू सिर्जना गर्न सक्दछ:
//!
//! * `iter()`, जुन `&T` मा पुनरावृत्ति हुन्छ।
//! * `iter_mut()`, जुन `&mut T` मा पुनरावृत्ति हुन्छ।
//! * `into_iter()`, जुन `T` मा पुनरावृत्ति हुन्छ।
//!
//! मानक पुस्तकालयमा बिभिन्न चीजहरूले एक वा तीन मध्ये तीन बढी लागू गर्दछ, जहाँ उपयुक्त छ।
//!
//! # Iterator कार्यान्वयन गर्दै
//!
//! तपाईंको आफ्नै इटररेटर सिर्जना गर्न दुई चरणहरू सामेल छन्: एक्सरेक्टरको राज्य समात्न `struct` सिर्जना गर्नुहोस्, र त्यस `struct` का लागि [`Iterator`] कार्यान्वयन गर्नुहोस्।
//! यो मॉड्युलमा धेरै `संरचनाहरू छन् किन यो छ: त्यहाँ प्रत्येक पुनरावृत्ति र पुनरावृत्ति एडेप्टर को लागी एक छ।
//!
//! `Counter` नामको एक इटरेटर बनाउनुहोस् जुन `1` बाट `5` सम्म गणना हुन्छ:
//!
//! ```
//! // पहिलो, संरचना:
//!
//! /// एक पुनरावृत्तिकर्ता जुन एकदेखि पाँच सम्म गणना गरिन्छ
//! struct Counter {
//!     count: usize,
//! }
//!
//! // हामी हाम्रो गणना एकबाट सुरू गर्न चाहन्छौं, त्यसैले मद्दतको लागि new() विधि थपौं।
//! // यो कडाइका साथ आवश्यक छैन, तर सुविधाजनक छ।
//! // नोट गर्नुहोस् कि हामीले `count` शून्यमा सुरु गर्छौं, हामी किन `next()`'s कार्यान्वयनमा तल देख्नेछौं।
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // त्यसो भए, हामी हाम्रो `Counter` को लागी `Iterator` लागू गर्दछौं:
//!
//! impl Iterator for Counter {
//!     // हामी usize संग गणना हुनेछ
//!     type Item = usize;
//!
//!     // next() मात्र आवश्यक विधि हो
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // हाम्रो गणना बढाउनुहोस्।हामीले शून्यबाट सुरु गर्यौं।
//!         self.count += 1;
//!
//!         // हामीले गणना पूरा गरिसकेका छौं कि छैन भनेर जाँच गर्नुहोस्।
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // र अब हामी यसलाई प्रयोग गर्न सक्छौं!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! यस तरीकाले [`next`] कल गर्दै दोहोरिन्छ।Rust सँग कन्स्ट्रक्ट छ जसले तपाईंको इट्रेटरमा [`next`] कल गर्न सक्दछ, जब सम्म यो `None` सम्म पुग्दैन।कि अर्को पछाडि जानुहोस्।
//!
//! यो पनि नोट गर्नुहोस् कि `Iterator` ले `nth` र `fold` जस्ता विधिहरूको पूर्वनिर्धारित कार्यान्वयन प्रदान गर्दछ जसले `next` आन्तरिक कल गर्दछ।
//! यद्यपि `nth` र `fold` जस्ता विधिहरूको अनुकूलन कार्यान्वयन लेख्न पनि सम्भव छ यदि यदि एक इरेटरले तिनीहरूलाई `next` कल नगरी अधिक प्रभावकारी गणना गर्न सक्दछ।
//!
//! # `for` छोराहरू र `IntoIterator`
//!
//! Rust को `for` लूप सिन्ट्याक्स वास्तवमा पुनरावृत्तिको लागि चिनी हो।यहाँ `for` को आधारभूत उदाहरण छ:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! यो संख्या एक देखि पाँच सम्म प्रिन्ट हुनेछ, प्रत्येक आफ्नै लाइन मा।तर तपाईले यहाँ केहि देख्नुहुनेछ: हामीले हाम्रो vector मा कहिले पनि केहि पनि कल गर्दैनौं एक ईटररेटर उत्पादन गर्नका लागि।के दिन्छ?
//!
//! त्यहाँ एक trait मानक पुस्तकालय मा केहि एक iterator मा रूपान्तरण को लागी: [`IntoIterator`].
//! यो trait सँग एक विधि छ, [`into_iter`], जसले [`IntoIterator`] कार्यान्वयन गर्ने वस्तुलाई एक इरेटरमा रूपान्तरण गर्दछ।
//! त्यस `for` लूपलाई फेरि हेर्नुहोस्, र कम्पाइलरले यसलाई रूपान्तरण गर्दछ:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust डी-सुगर यसमा:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! पहिले, हामी मानमा `into_iter()` कल गर्छौं।त्यसो भए, हामी इट्रेटरमा मेल खान्छौं जुन फिर्ता हुन्छ, [`next`] लाई फोन गरेर र अधिकमा `None` X नदेखेसम्म।
//! त्यस बिन्दुमा हामी लूपबाट `break` गर्छौं, र हामीले इटरेटिंग सक्यौं।
//!
//! यहाँ एक अर्को सूक्ष्म बिट छ: मानक पुस्तकालयले [`IntoIterator`] को एक रोचक कार्यान्वयन समावेश गर्दछ:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! अर्को शब्दमा, सबै [`Iterator`] ले [`IntoIterator`] कार्यान्वयन गर्छन्, आफैं फर्केर।यसको अर्थ दुई चीजहरू हुन्:
//!
//! 1. यदि तपाइँ [`Iterator`] लेख्दै हुनुहुन्छ भने, तपाइँ यसलाई `for` लूपको साथ प्रयोग गर्न सक्नुहुनेछ।
//! 2. यदि तपाईं संग्रह सिर्जना गर्दै हुनुहुन्छ, यसको लागि [`IntoIterator`] कार्यान्वयन गर्नाले तपाईंको संग्रहलाई `for` लूपसँग प्रयोग गर्न अनुमति दिनेछ।
//!
//! # सन्दर्भ द्वारा Iterating
//!
//! किनकि [`into_iter()`] ले `self` मान द्वारा लिन्छ, `for` लूप प्रयोग गरेर संग्रहमा पुनरावृत्ति गर्न स that्ग्रहको उपभोग गर्दछ।प्राय: तपाईले यसलाई उपभोग नगरी संग्रहमा पुनरावृत्ति गर्न सक्नुहुन्छ।
//! धेरै संग्रहले विधिहरू प्रदान गर्दछ जुन सन्दर्भहरूमा पुनरावृत्ति प्रदान गर्दछ, परम्परागत रूपमा क्रमशः `iter()` र `iter_mut()`:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` अझै यो कार्यको स्वामित्वमा छ।
//! ```
//!
//! यदि संग्रह प्रकार `C` `iter()` प्रदान गर्दछ, यसले सामान्यतया `&C` को लागि `&C` लागू गर्दछ, कार्यान्वयनको साथ मात्र `iter()` कल गर्दछ।
//! त्यस्तै प्रकारको `C` संग्रह `iter_mut()` ले `&mut C` का लागि `iter_mut()` लाई आमन्त्रित गरेर सामान्यतया `IntoIterator` लागू गर्दछ।यो एक सुविधाजनक शॉर्टहैंड सक्षम गर्दछ:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // `values.iter_mut()` जस्तै
//!     *x += 1;
//! }
//! for x in &values { // `values.iter()` जस्तै
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! जबकि धेरै संग्रहले `iter()` प्रस्ताव गर्दछ, सबै प्रस्ताव `iter_mut()` होईन।
//! उदाहरणको लागि, [`HashSet<T>`] वा [`HashMap<K, V>`] का कुञ्जीहरू परिवर्तन गर्नाले संग्रहलाई असंगत स्थितिमा राख्न सक्दछ यदि कुञ्जी ह्यासहरू परिवर्तन भयो भने यी संग्रहहरूले मात्र `iter()` प्रस्ताव गर्दछ।
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! प्रकार्यहरू जुन [`Iterator`] लिन्छ र अर्को [`Iterator`] फिर्ता गर्छन जसलाई 'एट्रेटर एडेप्टर' भनिन्छ, किनकि तिनीहरू 'एडाप्टरको रूप हुन्।
//! pattern'.
//!
//! सामान्य ईट्रेटर एडेप्टरमा [`map`], [`take`], र [`filter`] समावेश छ।
//! अधिकको लागि, उनीहरूको कागजात हेर्नुहोस्।
//!
//! यदि एक एट्रेटर एडेप्टर panics, ईट्रेटर एक अनिर्दिष्ट (तर मेमोरी सुरक्षित) स्थितिमा हुनेछ।
//! यस राज्यलाई Rust को संस्करणहरूमा उस्तै रहनको पनि ग्यारेन्टी छैन, त्यसैले तपाईले दुबै ईट्रेटरले फर्काएको सही मानमा भरोसा राख्नु हुँदैन।
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! इटेटरहरू (र इट्रेटर एक्स ०१ एक्स *आलसी* हुन्। यसको मतलब यो हो कि केवल एक इटरेटर बनाउँदा पूरै ठूलो _do_ हुँदैन। तपाईंले [`next`] कल नगरेसम्म केहि पनि हुँदैन।
//! यो कहिलेकाँही दुबै पक्षको स्रोत हुन्छ जब केवल ईटरटर बनाउँदा मात्र यसको साइड इफेक्टको लागि।
//! उदाहरणको लागि, [`map`] विधि प्रत्येक इन्टर्मेन्टमा क्लोजर कल गर्दछ जुन यो दोहोरिन्छ:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! यसले कुनै पनि मानहरू प्रिन्ट गर्दैन, किनकि हामीले यसलाई प्रयोग नगरी केवल एक इटरेटर सिर्जना गर्‍यौं।कम्पाइलरले हामीलाई यस प्रकारको व्यवहार बारे चेतावनी दिन्छ:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! यसको साइड इफेक्टका लागि [`map`] लेख्नको ईडिओमेटिक तरीका भनेको `for` लूप प्रयोग गर्नु वा [`for_each`] विधि कल गर्नु हो:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! एक इरेटर मूल्या to्कन गर्ने अर्को साधारण तरिका नयाँ संग्रहको उत्पादन गर्न [`collect`] विधि प्रयोग गर्नु हो।
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! इटेरेटर्स सीमित हुनु हुँदैन।एक उदाहरण को रूप मा, एक खुला समाप्त श्रेणी एक असीमित पुनरावृत्ति हो:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! असीम पुनरावृत्तकर्तालाई एक परिमितमा बदल्नको लागि [`take`] इट्रेटर एडेप्टर प्रयोग गर्न सामान्य छ:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! यसले X001 को माध्यम बाट `0` नम्बरहरू प्रिन्ट गर्दछ, प्रत्येक आफ्नै लाइनमा।
//!
//! दिमागमा राख्नुहोस् कि अनन्त पुनरावृत्तिहरूमा विधिहरू, जसका लागि परिणाम परिमित समयमा गणितमा निर्धारण गर्न सकिन्छ, समाप्त हुन सक्दैन।
//! विशेष रूपमा, विधिहरू जस्तै [`min`], जसलाई सामान्य अवस्थामा इट्रेटरमा प्रत्येक तत्त्वलाई ट्र्यावर्स गर्न आवश्यक पर्दछ, कुनै पनि अनन्त पुनरावृत्तिका लागि सफलतापूर्वक फिर्ता नहुन सक्छ।
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // धत्तेरिका!एक असीम लूप!
//! // `ones.min()` असीम लूपको कारण, त्यसैले हामी यस बिन्दुमा पुग्न सक्दैनौं!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;