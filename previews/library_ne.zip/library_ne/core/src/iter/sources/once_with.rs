use crate::iter::{FusedIterator, TrustedLen};

/// एक इटरेटर सिर्जना गर्दछ जुन आलस्य रूपमा ठीक एक पटक प्रदान गर्दछ बन्द गरिएको बिन्दुलाई आह्वान गरेर।
///
/// यो सामान्यतया एकल मान जनरेटरलाई अन्य प्रकारको पुनरावृत्तिको [`chain()`] मा अनुकूल गर्न प्रयोग गरिन्छ।
/// हुनसक्छ तपाईसँग इट्रेटर छ जसले लगभग सबै चीज ढाक्छ, तर तपाईलाई थप विशेष केस चाहिन्छ।
/// हुनसक्छ तपाईसँग एउटा प्रकार्य छ जुन ईटरेटर्समा काम गर्दछ, तर तपाईले एउटा मानलाई मात्र प्रक्रिया गर्नु पर्छ।
///
/// [`once()`] विपरीत, यो प्रकार्य सुस्त अनुरोध मा मान उत्पन्न गर्दछ।
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// आधारभूत उपयोग:
///
/// ```
/// use std::iter;
///
/// // एउटा सबैभन्दा लामो संख्या हो
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // एउटा मात्र, हामीले पाउँछौं
/// assert_eq!(None, one.next());
/// ```
///
/// अर्को इट्रेटरको साथ सँगै चेन गर्दै।
/// मानिलिनुहोस् हामी `.foo` डाइरेक्टरीको प्रत्येक फाईलमा पुनरावृत्ति गर्न चाहन्छौं, तर कन्फिगरेसन फाइल पनि,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // हामीले DirEntry-s को पुनरावृत्तकर्तालाई पथबफ्सको इट्रेटरमा रूपान्तरण गर्न आवश्यक छ, त्यसैले हामी नक्सा प्रयोग गर्दछौं।
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // अब, हाम्रो कन्टेन्ट फाइलको लागि केवल हाम्रो पुनरावृत्ति
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // दुई पुनरावृत्तिको सँगै एउटा ठूलो इट्रेटरमा श्रृंखला बनाउनुहोस्
/// let files = dirs.chain(config);
///
/// // यसले हामीलाई .foo मा साथै .foorc मा सबै फाईलहरू दिन्छ
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// एक पुनरावृत्तिक जसले `A` प्रकारको एक्लो एलिमेन्ट प्रदान गर्दछ बन्द गरिएको `F: FnOnce() -> A` लागू गरेर।
///
///
/// यो `struct` [`once_with()`] प्रकार्य द्वारा बनाईएको हो।
/// अधिकको लागि यसको कागजात हेर्नुहोस्।
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}