use crate::iter::{FusedIterator, TrustedLen};

/// एक नयाँ इटरेटर बनाउँदछ जुन प्रकारको `A` को तत्वहरू अन्तत: दोहोर्याइएको प्रदान गरिएको क्लोजर, पुनरावर्तक, `F: FnMut() -> A`.
///
/// `repeat_with()` प्रकार्य दोहोर्याउँदछ र दोहोर्याउँदछ।
///
/// `repeat_with()` जस्तो अनन्त पुनरावृत्तिको प्राय: [`Iterator::take()`] जस्तै एडेप्टरको साथ प्रयोग गरिन्छ, तिनीहरूलाई परिमित बनाउनको लागि।
///
/// यदि एट्रेटरको एलिमेन्ट प्रकारले तपाईंलाई [`Clone`] कार्यान्वयन गर्न आवश्यक छ, र स्रोत तत्व मेमोरीमा राख्न ठीक छ, तपाईंले [`repeat()`] प्रकार्य प्रयोग गर्नुपर्नेछ।
///
///
/// `repeat_with()` द्वारा उत्पादित ईटरेटर एक [`DoubleEndedIterator`] हैन।
/// यदि तपाईंलाई [`DoubleEndedIterator`] फिर्ता गर्न `repeat_with()` आवश्यक छ भने, कृपया GitHub मुद्दा खोल्नुहोस् तपाईंको प्रयोगको केस वर्णन गर्दै।
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// आधारभूत उपयोग:
///
/// ```
/// use std::iter;
///
/// // मानौं हामीसँग यस्तो प्रकारको केहि मूल्य छ जुन `Clone` होईन वा जुन अझै मेमोरीमा राख्न चाहँदैन किनकी यो महँगो छ:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // एक खास मान सँधै:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// उत्परिवर्तन र सीमित जाने प्रयोग गर्दै:
///
/// ```rust
/// use std::iter;
///
/// // शून्यबाट तेस्रो पावर दुईमा:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... र अब हामीले सक्यौं
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// एक पुनरावृत्तिक जसले `A` प्रकारको तत्वहरूलाई निरन्तर रूपमा बन्द बन्द `F: FnMut() -> A` लागू गरेर दोहोर्याउँदछ।
///
///
/// यो `struct` [`repeat_with()`] प्रकार्य द्वारा बनाईएको हो।
/// अधिकको लागि यसको कागजात हेर्नुहोस्।
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}