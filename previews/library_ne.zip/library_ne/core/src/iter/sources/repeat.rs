use crate::iter::{FusedIterator, TrustedLen};

/// एक नयाँ इटरेटर सिर्जना गर्दछ जुन अन्तत: एकल तत्वको पुनरावृत्ति गर्दछ।
///
/// `repeat()` प्रकार्य फेरि एकल मान दोहोर्याउँदछ।
///
/// `repeat()` जस्तो अनन्त पुनरावृत्तिको प्राय: [`Iterator::take()`] जस्तै एडेप्टरको साथ प्रयोग गरिन्छ, तिनीहरूलाई परिमित बनाउनको लागि।
///
/// यदि एट्रेटरको एलिमेन्ट प्रकारले तपाईलाई चाहिन्छ `Clone` कार्यान्वयन गर्दैन, वा यदि तपाई दोहोरिएको तत्वलाई मेमोरीमा राख्न चाहनुहुन्न भने तपाई [`repeat_with()`] प्रकार्य प्रयोग गर्न सक्नुहुनेछ।
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// आधारभूत उपयोग:
///
/// ```
/// use std::iter;
///
/// // नम्बर चार 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // हो, अझै चार
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// [`Iterator::take()`] को साथ परिमित हुँदै:
///
/// ```
/// use std::iter;
///
/// // त्यो अन्तिम उदाहरण धेरै चौका थियो।हामीसँग केवल चार चौका छन्।
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... र अब हामीले सक्यौं
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// एक पुनरावृत्तिकर्ता एक तत्व लगातार अन्तर्गत।
///
/// यो `struct` [`repeat()`] प्रकार्य द्वारा बनाईएको हो।अधिकको लागि यसको कागजात हेर्नुहोस्।
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}