use crate::{fmt, iter::FusedIterator};

/// एक नयाँ पुनरावृत्ति बनाउँदछ जहाँ प्रत्येक क्रमिक आइटम को पूर्ववर्ती एक को आधार मा गणना गरीन्छ।
///
/// पुनरावृत्तिकर्ता पहिलो पहिलो आइटम (यदि कुनै हो) बाट सुरू हुन्छ र दिइएको `FnMut(&T) -> Option<T>` क्लोजर प्रत्येक आईटमको उत्तराधिकारी गणना गर्न कल गर्दछ।
///
///
/// ```
/// use std::iter::successors;
///
/// let powers_of_10 = successors(Some(1_u16), |n| n.checked_mul(10));
/// assert_eq!(powers_of_10.collect::<Vec<_>>(), &[1, 10, 100, 1_000, 10_000]);
/// ```
#[stable(feature = "iter_successors", since = "1.34.0")]
pub fn successors<T, F>(first: Option<T>, succ: F) -> Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    // यदि यो प्रकार्य `impl Iterator<Item=T>` फिर्ता भयो भने यो `unfold` मा आधारित हुन सक्छ र समर्पित प्रकारको आवश्यक पर्दैन।
    //
    // जबकि नाम दिइएको `Successors<T, F>` प्रकारको `Clone` हुन X X 2X र `F` हुन अनुमति दिन्छ।
    Successors { next: first, succ }
}

/// एउटा नयाँ इट्रेटर जहाँ प्रत्येक क्रमिक आइटम अघिल्लोको आधारमा गणना गरिएको छ।
///
/// यो `struct` [`iter::successors()`] प्रकार्य द्वारा बनाईएको हो।
/// अधिकको लागि यसको कागजात हेर्नुहोस्।
///
/// [`iter::successors()`]: successors
#[derive(Clone)]
#[stable(feature = "iter_successors", since = "1.34.0")]
pub struct Successors<T, F> {
    next: Option<T>,
    succ: F,
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> Iterator for Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        let item = self.next.take()?;
        self.next = (self.succ)(&item);
        Some(item)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.next.is_some() { (1, None) } else { (0, Some(0)) }
    }
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> FusedIterator for Successors<T, F> where F: FnMut(&T) -> Option<T> {}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T: fmt::Debug, F> fmt::Debug for Successors<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Successors").field("next", &self.next).finish()
    }
}