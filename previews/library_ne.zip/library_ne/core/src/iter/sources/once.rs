use crate::iter::{FusedIterator, TrustedLen};

/// एक पुनरावृत्तिकर्ता सिर्जना गर्दछ जसले एक पटक तत्काल एलिमेन्ट दिन्छ।
///
/// यो सामान्यतया एकल मानलाई अन्य प्रकारको पुनरावृत्तिको [`chain()`] मा अनुकूल गर्न प्रयोग गरिन्छ।
/// हुनसक्छ तपाईसँग इट्रेटर छ जसले लगभग सबै चीज ढाक्छ, तर तपाईलाई थप विशेष केस चाहिन्छ।
/// हुनसक्छ तपाईसँग एउटा प्रकार्य छ जुन ईटरेटर्समा काम गर्दछ, तर तपाईले एउटा मानलाई मात्र प्रक्रिया गर्नु पर्छ।
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// आधारभूत उपयोग:
///
/// ```
/// use std::iter;
///
/// // एउटा सबैभन्दा लामो संख्या हो
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // एउटा मात्र, हामीले पाउँछौं
/// assert_eq!(None, one.next());
/// ```
///
/// अर्को इट्रेटरको साथ सँगै चेन गर्दै।
/// मानिलिनुहोस् हामी `.foo` डाइरेक्टरीको प्रत्येक फाईलमा पुनरावृत्ति गर्न चाहन्छौं, तर कन्फिगरेसन फाइल पनि,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // हामीले DirEntry-s को पुनरावृत्तकर्तालाई पथबफ्सको इट्रेटरमा रूपान्तरण गर्न आवश्यक छ, त्यसैले हामी नक्सा प्रयोग गर्दछौं।
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // अब, हाम्रो कन्टेन्ट फाइलको लागि केवल हाम्रो पुनरावृत्ति
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // दुई पुनरावृत्तिको सँगै एउटा ठूलो इट्रेटरमा श्रृंखला बनाउनुहोस्
/// let files = dirs.chain(config);
///
/// // यसले हामीलाई .foo मा साथै .foorc मा सबै फाईलहरू दिन्छ
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// एक पुनरावृत्तिकर्ता एक पटक एलिमेन्ट उत्पन्न गर्दछ।
///
/// यो `struct` [`once()`] प्रकार्य द्वारा बनाईएको हो।अधिकको लागि यसको कागजात हेर्नुहोस्।
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}