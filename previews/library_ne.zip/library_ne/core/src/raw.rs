#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! कम्पाइलर निर्मित प्रकारका सजावटका लागि संरचना परिभाषाहरू समावेश गर्दछ।
//!
//! तिनीहरू असुरक्षित कोडमा कच्चा प्रतिनिधित्व प्रत्यक्ष रूपमा हेरफेर गर्न को लागी transmutes को लक्ष्य को रूप मा प्रयोग गर्न सकिन्छ।
//!
//!
//! तिनीहरूको परिभाषा सँधै `rustc_middle::ty::layout` मा परिभाषित ABI सँग मेल खानु पर्छ।
//!

/// trait वस्तुको प्रतिनिधित्व जस्तै `&dyn SomeTrait`।
///
/// यस संरचनाको `&dyn SomeTrait` र `Box<dyn AnotherTrait>` जस्तो प्रकारको लेआउट छ।
///
/// `TraitObject` लेआउटहरूसँग मिलान ग्यारेन्टी गरिएको छ, तर यो trait वस्तुहरूको प्रकार होइन (उदाहरणका लागि, क्षेत्रहरू `&dyn SomeTrait` X मा सिधा पहुँच योग्य हुँदैन) न त यसले लेआउटलाई नियन्त्रण गर्दछ (परिभाषा परिवर्तन गर्दा `&dyn SomeTrait` लेआउट बदल्दैन)।
///
/// यो असुरक्षित कोड द्वारा प्रयोग गर्नको लागि मात्र डिजाइन गरिएको हो जुन तल्लो तहको विवरणहरू हेरफेर गर्न आवश्यक पर्दछ।
///
/// त्यहाँ सबै trait वस्तुहरू जेनेरियर रूपमा सन्दर्भ गर्न कुनै तरिका छैन, त्यसैले यस प्रकारको मानहरू सिर्जना गर्ने एक मात्र तरिका [`std::mem::transmute`][transmute] जस्तै कार्यहरूसँग हो।
/// त्यस्तै, `TraitObject` मानबाट वास्तविक trait वस्तु सिर्जना गर्ने एक मात्र तरिका `transmute` सँग छ।
///
/// [transmute]: crate::intrinsics::transmute
///
/// trait वस्तु बेमेल प्रकारका साथ संश्लेषण गर्दै-एक जहाँ vtable मानको प्रकारसँग मेल खाँदैन जुन डाटा पोइन्टर पोइन्ट - को अपरिभाषित व्यवहारमा उच्च सम्भावनाको रूपमा छ।
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // एक उदाहरण trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // कम्पाइलरले trait वस्तु बनाउनुहोस्
/// let object: &dyn Foo = &value;
///
/// // कच्चा प्रतिनिधित्व मा हेर्नुहोस्
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // डाटा पोइन्टर भनेको `value` को ठेगाना हो
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // `object` बाट `i32` vtable प्रयोग गर्न सावधान हुँदै, नयाँ `i32` लाई दर्साई नयाँ वस्तु बनाउनुहोस्
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // यो कार्य गर्दछ जस्तै हामीले `other_value` बाहिर trait वस्तु निर्माण गरेको थियो
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}