//! वैकल्पिक मान।
//!
//! प्रकार [`Option`] एक वैकल्पिक मान प्रतिनिधित्व गर्दछ: प्रत्येक [`Option`] या त [`Some`] हो वा एक मान, वा [`None`] समावेश गर्दछ, र गर्दैन।
//! [`Option`] प्रकारहरू Rust कोडमा धेरै सामान्य हुन्छन्, किनकि उनीहरूसँग धेरै जसो प्रयोगहरू छन्:
//!
//! * प्रारम्भिक मानहरू
//! * कार्यहरूको लागि मानहरू फिर्ता गर्नुहोस् जुन उनीहरूको सम्पूर्ण इनपुट दायरा (आंशिक प्रकार्यहरू) मा परिभाषित छैनन्।
//! * सामान्य त्रुटि रिपोर्टिंगको लागि मान फिर्ता गर्नुहोस्, जहाँ [`None`] त्रुटिमा फिर्ता आयो
//! * वैकल्पिक संरचना क्षेत्रहरू
//! * क्षेत्रहरू बनाउनुहोस् जुन edण लिन सकिन्छ वा "taken"
//! * वैकल्पिक प्रकार्य तर्क
//! * Nulalable सूचकहरू
//! * गाह्रो अवस्थाबाट बाहिर चीजहरू बदली गर्दै
//!
//! [`विकल्प`] s सामान्यतया मानको उपस्थिति क्वेरी गर्न कारबाही र मिलानको साथ जोडा बनाइएको छ र सँधै [`None`] केसको लागि लेखांकन।
//!
//!
//! ```
//! fn divide(numerator: f64, denominator: f64) -> Option<f64> {
//!     if denominator == 0.0 {
//!         None
//!     } else {
//!         Some(numerator / denominator)
//!     }
//! }
//!
//! // प्रकार्यको फिर्ती मान एक विकल्प हो
//! let result = divide(2.0, 3.0);
//!
//! // ढाँचा मिलान मान पुनः प्राप्त गर्न
//! match result {
//!     // डिभिजन मान्य थियो
//!     Some(x) => println!("Result: {}", x),
//!     // विभाजन अवैध थियो
//!     None    => println!("Cannot divide by 0"),
//! }
//! ```
//!
//!
//!
//!
//!
// FIXME: देखाउनुहोस् कसरी `Option` अभ्यासमा प्रयोग गरिएको छ, धेरै विधिहरूको साथ
//
//! # विकल्प र पोइन्टर ("nullable" सूचक)
//!
//! Rust को सूचक प्रकारहरू सँधै मान्य स्थानमा स point्केत गर्नुपर्दछ;त्यहाँ कुनै "null" सन्दर्भ छैन।यसको सट्टामा, Rust का *वैकल्पिक* पोइन्टर्स छन्, वैकल्पिक स्वामित्व बक्स जस्तै, [`विकल्प`]`<`[`बक्स<T>`]`>`।
//!
//! निम्न उदाहरणले [`i32`] को एक वैकल्पिक बक्स सिर्जना गर्न [`Option`] प्रयोग गर्दछ।
//! ध्यान दिनुहोस् कि पहिले भित्री [`i32`] मान प्रयोग गर्न, `check_optional` प्रकार्यले बक्सको मान छ कि भनेर निर्धारण गर्न मिलान बान्की प्रयोग गर्न आवश्यक छ (जस्तै, यो [`Some(...)`][`Some`]) हो कि ([`None`]) हैन।
//!
//!
//! ```
//! let optional = None;
//! check_optional(optional);
//!
//! let optional = Some(Box::new(9000));
//! check_optional(optional);
//!
//! fn check_optional(optional: Option<Box<i32>>) {
//!     match optional {
//!         Some(p) => println!("has value {}", p),
//!         None => println!("has no value"),
//!     }
//! }
//! ```
//!
//! # Representation
//!
//! Rust ले `T` लाई निम्न प्रकारहरू अनुकूलित गर्न ग्यारेन्टी दिन्छ जस्तै [`Option<T>`] सँग `T` जस्तै आकार छ:
//!
//! * [`Box<U>`]
//! * `&U`
//! * `&mut U`
//! * `fn`, `extern "C" fn`
//! * [`num::NonZero*`]
//! * [`ptr::NonNull<U>`]
//! * `#[repr(transparent)]` यस सूचीमा एक प्रकारका वरपर संरचना गर्नुहोस्।
//!
//! यो थप ग्यारेन्टी गरिएको छ कि माथिको अवस्थाहरूका लागि,[`mem::transmute`] X को `Option<T>` को सबै मान्य मानहरूबाट [`mem::transmute`] र X0X बाट `T` मा (तर `None::<T>` लाई `T` मा ट्रान्समिट गर्ने अपरिभाषित व्यवहार हो)।
//!
//! # Examples
//!
//! [`Option`] मा आधारभूत बान्की मिल्दो:
//!
//! ```
//! let msg = Some("howdy");
//!
//! // निहित स्ट्रिंगको सन्दर्भ लिनुहोस्
//! if let Some(m) = &msg {
//!     println!("{}", *m);
//! }
//!
//! // विकल्पलाई नष्ट गर्दै, निहित स्ट्रिंग हटाउनुहोस्
//! let unwrapped_msg = msg.unwrap_or("default message");
//! ```
//!
//! लूप अघि [`None`] मा परिणाम सुरू गर्नुहोस्:
//!
//! ```
//! enum Kingdom { Plant(u32, &'static str), Animal(u32, &'static str) }
//!
//! // खोजी को लागी डेटा को एक सूची।
//! let all_the_big_things = [
//!     Kingdom::Plant(250, "redwood"),
//!     Kingdom::Plant(230, "noble fir"),
//!     Kingdom::Plant(229, "sugar pine"),
//!     Kingdom::Animal(25, "blue whale"),
//!     Kingdom::Animal(19, "fin whale"),
//!     Kingdom::Animal(15, "north pacific right whale"),
//! ];
//!
//! // हामी सबैभन्दा ठूलो जनावरको नाम खोजी गर्न गइरहेका छौं, तर सुरु गर्न हामीले भर्खरै `None` पाएका छौं।
//! //
//! let mut name_of_biggest_animal = None;
//! let mut size_of_biggest_animal = 0;
//! for big_thing in &all_the_big_things {
//!     match *big_thing {
//!         Kingdom::Animal(size, name) if size > size_of_biggest_animal => {
//!             // अब हामीले केहि ठुलो जनावरको नाम फेला पार्‍यौं
//!             size_of_biggest_animal = size;
//!             name_of_biggest_animal = Some(name);
//!         }
//!         Kingdom::Animal(..) | Kingdom::Plant(..) => ()
//!     }
//! }
//!
//! match name_of_biggest_animal {
//!     Some(name) => println!("the biggest animal is {}", name),
//!     None => println!("there are no animals :("),
//! }
//! ```
//!
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Box<U>`]: ../../std/boxed/struct.Box.html
//! [`num::NonZero*`]: crate::num
//! [`ptr::NonNull<U>`]: crate::ptr::NonNull
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{FromIterator, FusedIterator, TrustedLen};
use crate::pin::Pin;
use crate::{
    fmt, hint, mem,
    ops::{self, Deref, DerefMut},
};

/// `Option` प्रकार।अधिकको लागि [the module level documentation](self) हेर्नुहोस्।
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[rustc_diagnostic_item = "option_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Option<T> {
    /// कुनै मान छैन
    #[lang = "None"]
    #[stable(feature = "rust1", since = "1.0.0")]
    None,
    /// केहि मान `T`
    #[lang = "Some"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Some(#[stable(feature = "rust1", since = "1.0.0")] T),
}

/////////////////////////////////////////////////////////////////////////////
// प्रकारको कार्यान्वयन
/////////////////////////////////////////////////////////////////////////////

impl<T> Option<T> {
    /////////////////////////////////////////////////////////////////////////
    // निहित मानहरूको खोजी गर्दै
    /////////////////////////////////////////////////////////////////////////

    /// `true` फर्काउँछ यदि विकल्प [`Some`] मान हो।
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_some(), true);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_some(), false);
    /// ```
    #[must_use = "if you intended to assert that this has a value, consider `.unwrap()` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_some(&self) -> bool {
        matches!(*self, Some(_))
    }

    /// `true` फर्काउँछ यदि विकल्प [`None`] मान हो।
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_none(), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_none(), true);
    /// ```
    #[must_use = "if you intended to assert that this doesn't have a value, consider \
                  `.and_then(|| panic!(\"`Option` had a value when expected `None`\"))` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_none(&self) -> bool {
        !self.is_some()
    }

    /// `true` फर्काउँछ यदि विकल्पमा प्रदान गरिएको मान समावेश भएको [`Some`] मान हो।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Option<u32> = Some(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Some(y) => x == y,
            None => false,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // सन्दर्भको साथ काम गर्नका लागि एडाप्टर
    /////////////////////////////////////////////////////////////////////////

    /// `&Option<T>` बाट `Option<&T>` मा रूपान्तरण।
    ///
    /// # Examples
    ///
    /// मौलिक संरक्षण गर्दै an विकल्प <`[` String`]`>`लाई`विकल्प <<[`usize`] `> Con मा रूपान्तरण गर्दछ।
    /// [`map`] विधिले `self` आर्गुमेन्टलाई मानले लिन्छ, मूल उपभोग गर्दछ, त्यसैले यो प्रविधीले `as_ref` प्रयोग गर्दछ पहिलो `Option` मूल भित्र मानको सन्दर्भमा लिन।
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let text: Option<String> = Some("Hello, world!".to_string());
    /// // पहिले `Option<String>` लाई `as_ref` X मा `as_ref` कास्ट गर्नुहोस्, त्यसपछि *उपभोग गर्नुहोस् कि*`map` का साथ, स्ट्याकमा `text` छोड्नुहोस्।
    /////
    /// let text_length: Option<usize> = text.as_ref().map(|s| s.len());
    /// println!("still can print text: {:?}", text);
    /// ```
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Option<&T> {
        match *self {
            Some(ref x) => Some(x),
            None => None,
        }
    }

    /// `&mut Option<T>` बाट `Option<&mut T>` मा रूपान्तरण।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// match x.as_mut() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Some(ref mut x) => Some(x),
            None => None,
        }
    }

    /// [`Pin`] from <र विकल्प बाट रूपान्तरण<T>> `बाट ption विकल्प <` [`Pin`]`<&T>>`।
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_ref(self: Pin<&Self>) -> Option<Pin<&T>> {
        // सुरक्षा: `x` पिन गर्न ग्यारेन्टी गरिएको छ किनकि यो `self` बाट आउँदछ
        // जो पिन गरिएको छ।
        unsafe { Pin::get_ref(self).as_ref().map(|x| Pin::new_unchecked(x)) }
    }

    /// [`Pin`] Con <र म्युट विकल्प बाट रूपान्तरण<T>> `बाट ption विकल्प <` [`Pin`]`<र म्यूट T>>`।
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_mut(self: Pin<&mut Self>) -> Option<Pin<&mut T>> {
        // सुरक्षा: `get_unchecked_mut` `Option` `self` भित्र सार्न प्रयोग कहिल्यै।
        // `x` पिन गर्न ग्यारेन्टी गरिएको छ किनकि यो `self` बाट आउँदछ जुन पिन गरिएको छ।
        unsafe { Pin::get_unchecked_mut(self).as_mut().map(|x| Pin::new_unchecked(x)) }
    }

    /////////////////////////////////////////////////////////////////////////
    // समाहित मानहरूमा पुग्न
    /////////////////////////////////////////////////////////////////////////

    /// [`Some`] X मान खपत, निहित [`Some`] मान फर्काउँछ।
    ///
    /// # Panics
    ///
    /// Panics यदि मान `msg` द्वारा प्रदान गरिएको कस्टम panic सन्देशको साथ [`None`] छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("value");
    /// assert_eq!(x.expect("fruits are healthy"), "value");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// x.expect("fruits are healthy"); // panics with `fruits are healthy`
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Some(val) => val,
            None => expect_failed(msg),
        }
    }

    /// [`Some`] X मान खपत, निहित [`Some`] मान फर्काउँछ।
    ///
    /// किनभने यो प्रकार्य panic हुन सक्छ, यसको प्रयोग सामान्यतया निरुत्साहित हुन्छ।
    /// यसको सट्टामा, ढाँचा मिलान प्रयोग गर्न र [`None`] केसलाई स्पष्ट रूपमा ह्यान्डल गर्न रुचाउँनुहोस्, वा [`unwrap_or`], [`unwrap_or_else`], वा [`unwrap_or_default`] कल गर्नुहोस्।
    ///
    ///
    /// [`unwrap_or`]: Option::unwrap_or
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    /// [`unwrap_or_default`]: Option::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics यदि स्वयं मान [`None`] बराबर।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("air");
    /// assert_eq!(x.unwrap(), "air");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// assert_eq!(x.unwrap(), "air"); // fails
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn unwrap(self) -> T {
        match self {
            Some(val) => val,
            None => panic!("called `Option::unwrap()` on a `None` value"),
        }
    }

    /// निहित [`Some`] मान वा प्रदान गरिएको पूर्वनिर्धारित फर्काउँछ।
    ///
    /// `unwrap_or` मा पठाइएको तर्कहरू उत्कटताका साथ मूल्या are्कन गरिन्छ;यदि तपाईं प्रकार्य कलको नतिजा पास गर्दै हुनुहुन्छ भने, [`unwrap_or_else`] प्रयोग गर्न सिफारिस गरिन्छ, जुन आल evalu्गिक मूल्यांकन गरिएको छ।
    ///
    ///
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(Some("car").unwrap_or("bike"), "car");
    /// assert_eq!(None.unwrap_or("bike"), "bike");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Some(x) => x,
            None => default,
        }
    }

    /// निहित [`Some`] मान फर्काउँछ वा बन्दबाट यसको गणना गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 10;
    /// assert_eq!(Some(4).unwrap_or_else(|| 2 * k), 4);
    /// assert_eq!(None.unwrap_or_else(|| 2 * k), 20);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce() -> T>(self, f: F) -> T {
        match self {
            Some(x) => x,
            None => f(),
        }
    }

    /// `self` मान उपभोग गरी निहित [`Some`] मान फर्काउँछ, मान [`None`] होईन भनेर जाँच नगरी।
    ///
    ///
    /// # Safety
    ///
    /// यो विधिलाई [`None`] मा कल गर्नु *[अपरिभाषित व्यवहार]* हो।
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x = Some("air");
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air");
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Option<&str> = None;
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air"); // अपरिभाषित व्यवहार!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_some());
        match self {
            Some(val) => val,
            // सुरक्षा: सुरक्षा सम्झौता कलरले समर्थन गर्नै पर्छ।
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // रूपान्तरणमा समावेश मानहरू
    /////////////////////////////////////////////////////////////////////////

    /// एउटा `Option<T>` मा `Option<U>` मा नक्साहरू समावेश गरिएको मानमा प्रकार्य लागू गरेर।
    ///
    /// # Examples
    ///
    /// एक `विकल्प <` [`String`]`>`लाई एक`विकल्प <`[`usize`] `>` मा बदल्छ, मूल उपभोग गर्दै:
    ///
    /// [`String`]: ../../std/string/struct.String.html
    /// ```
    /// let maybe_some_string = Some(String::from("Hello, World!"));
    /// // `Option::map` सेल्फ *मान द्वारा* लिन्छ, उपभोक्ता `maybe_some_string`
    /// let maybe_some_len = maybe_some_string.map(|s| s.len());
    ///
    /// assert_eq!(maybe_some_len, Some(13));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, f: F) -> Option<U> {
        match self {
            Some(x) => Some(f(x)),
            None => None,
        }
    }

    /// निहित मान (यदि कुनै भएमा) प्रकार्य लागू गर्दछ, वा प्रदान गरिएको पूर्वनिर्धारित (यदि होईन) फर्काउँछ।
    ///
    /// `map_or` मा पठाइएको तर्कहरू उत्कटताका साथ मूल्या are्कन गरिन्छ;यदि तपाईं प्रकार्य कलको नतिजा पास गर्दै हुनुहुन्छ भने, [`map_or_else`] प्रयोग गर्न सिफारिस गरिन्छ, जुन आल evalu्गिक मूल्यांकन गरिएको छ।
    ///
    ///
    /// [`map_or_else`]: Option::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default,
        }
    }

    /// समाहित मान (यदि कुनै) मा फंक्शन लागू गर्दछ, वा पूर्वनिर्धारित गणना गर्दछ (यदि होईन भने)।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x = Some("foo");
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 42);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or_else<U, D: FnOnce() -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default(),
        }
    }

    /// `Option<T>` लाई [`Result<T, E>`] मा [`Some(v)`] लाई [`Ok(v)`] र [`None`] लाई [`Err(err)`] मा म्यापि .्ग रूपान्तरण गर्दछ।
    ///
    /// `ok_or` मा पठाइएको तर्कहरू उत्कटताका साथ मूल्या are्कन गरिन्छ;यदि तपाईं प्रकार्य कलको नतिजा पास गर्दै हुनुहुन्छ भने, [`ok_or_else`] प्रयोग गर्न सिफारिस गरिन्छ, जुन आल evalu्गिक मूल्यांकन गरिएको छ।
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err)`]: Err
    /// [`Some(v)`]: Some
    /// [`ok_or_else`]: Option::ok_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or(0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or(0), Err(0));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or<E>(self, err: E) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err),
        }
    }

    /// `Option<T>` लाई [`Result<T, E>`] मा [`Some(v)`] लाई [`Ok(v)`] र [`None`] लाई [`Err(err())`] मा म्यापि .्ग रूपान्तरण गर्दछ।
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err())`]: Err
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or_else(|| 0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or_else(|| 0), Err(0));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or_else<E, F: FnOnce() -> E>(self, err: F) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err()),
        }
    }

    /// विकल्पमा `value` सम्मिलित गर्दछ त्यसपछि यसलाई म्यूटेबल सन्दर्भ फर्काउँछ।
    ///
    /// यदि विकल्पमा पहिले नै मान छ भने, पुरानो मान खसालिन्छ।
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(option_insert)]
    ///
    /// let mut opt = None;
    /// let val = opt.insert(1);
    /// assert_eq!(*val, 1);
    /// assert_eq!(opt.unwrap(), 1);
    /// let val = opt.insert(2);
    /// assert_eq!(*val, 2);
    /// *val = 3;
    /// assert_eq!(opt.unwrap(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "option_insert", reason = "newly added", issue = "78271")]
    pub fn insert(&mut self, value: T) -> &mut T {
        *self = Some(value);

        match self {
            Some(v) => v,
            // सुरक्षा: माथिको कोड भर्खरै विकल्प भरियो
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Iterator कन्स्ट्रक्टर
    /////////////////////////////////////////////////////////////////////////

    /// सम्भावित निहित मानमा एक इटरेटर फर्काउँछ।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(4);
    /// assert_eq!(x.iter().next(), Some(&4));
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn iter(&self) -> Iter<'_, T> {
        Iter { inner: Item { opt: self.as_ref() } }
    }

    /// सम्भावित निहित मानमा म्यूटेबल ईटररेटर फर्काउँछ।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(4);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    ///
    /// let mut x: Option<u32> = None;
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: Item { opt: self.as_mut() } }
    }

    /////////////////////////////////////////////////////////////////////////
    // मानहरूमा बुलियन अपरेशनहरू, उत्सुक र अल्छी
    /////////////////////////////////////////////////////////////////////////

    /// [`None`] फर्काउँछ यदि विकल्प [`None`] हो, अन्यथा `optb` फर्काउँछ।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), None);
    ///
    /// let x = Some(2);
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), Some("foo"));
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, optb: Option<U>) -> Option<U> {
        match self {
            Some(_) => optb,
            None => None,
        }
    }

    /// यदि विकल्प [`None`] हो भने [`None`] फर्काउँछ, अन्यथा आवरण मानको साथ `f` कल गर्दछ र परिणाम फर्काउँछ।
    ///
    ///
    /// केही भाषाहरूले यस अपरेशनलाई फ्ल्याटम्याप भन्छन्।
    ///
    /// # Examples
    ///
    /// ```
    /// fn sq(x: u32) -> Option<u32> { Some(x * x) }
    /// fn nope(_: u32) -> Option<u32> { None }
    ///
    /// assert_eq!(Some(2).and_then(sq).and_then(sq), Some(16));
    /// assert_eq!(Some(2).and_then(sq).and_then(nope), None);
    /// assert_eq!(Some(2).and_then(nope).and_then(sq), None);
    /// assert_eq!(None.and_then(sq).and_then(sq), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Option<U>>(self, f: F) -> Option<U> {
        match self {
            Some(x) => f(x),
            None => None,
        }
    }

    /// [`None`] फर्काउँछ यदि विकल्प [`None`] हो, अन्यथा आवरण मानको साथ `predicate` कल गर्दछ र फिर्ता गर्छ:
    ///
    ///
    /// - [`Some(t)`] यदि `predicate` `true` फर्काउँछ (जहाँ `t` लपेटिएको मान हो), र
    /// - [`None`] यदि `predicate` `false` फर्काउँछ भने।
    ///
    /// यो प्रकार्य [`Iterator::filter()`] जस्तै समान कार्य गर्दछ।
    /// तपाईं कल्पना गर्न सक्नुहुन्छ `Option<T>` एक वा शून्य तत्त्वहरूमा इटरेटर हो।
    /// `filter()` कुन तत्वहरू राख्नु पर्छ तपाईले निर्णय गर्न दिन्छ।
    ///
    /// # Examples
    ///
    /// ```rust
    /// fn is_even(n: &i32) -> bool {
    ///     n % 2 == 0
    /// }
    ///
    /// assert_eq!(None.filter(is_even), None);
    /// assert_eq!(Some(3).filter(is_even), None);
    /// assert_eq!(Some(4).filter(is_even), Some(4));
    /// ```
    ///
    /// [`Some(t)`]: Some
    ///
    #[inline]
    #[stable(feature = "option_filter", since = "1.27.0")]
    pub fn filter<P: FnOnce(&T) -> bool>(self, predicate: P) -> Self {
        if let Some(x) = self {
            if predicate(&x) {
                return Some(x);
            }
        }
        None
    }

    /// विकल्प फिर्ता गर्दछ यदि यसले मान समावेश गर्दछ, अन्यथा `optb` फर्काउँछ।
    ///
    /// `or` मा पठाइएको तर्कहरू उत्कटताका साथ मूल्या are्कन गरिन्छ;यदि तपाईं प्रकार्य कलको नतिजा पास गर्दै हुनुहुन्छ भने, [`or_else`] प्रयोग गर्न सिफारिस गरिन्छ, जुन आल evalu्गिक मूल्यांकन गरिएको छ।
    ///
    ///
    /// [`or_else`]: Option::or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y = None;
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x = None;
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(100));
    ///
    /// let x = Some(2);
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = None;
    /// assert_eq!(x.or(y), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or(self, optb: Option<T>) -> Option<T> {
        match self {
            Some(_) => self,
            None => optb,
        }
    }

    /// विकल्प फिर्ता गर्छ यदि यसले मान समावेश गर्दछ, अन्यथा `f` कल गर्दछ र परिणाम फर्काउँछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn nobody() -> Option<&'static str> { None }
    /// fn vikings() -> Option<&'static str> { Some("vikings") }
    ///
    /// assert_eq!(Some("barbarians").or_else(vikings), Some("barbarians"));
    /// assert_eq!(None.or_else(vikings), Some("vikings"));
    /// assert_eq!(None.or_else(nobody), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F: FnOnce() -> Option<T>>(self, f: F) -> Option<T> {
        match self {
            Some(_) => self,
            None => f(),
        }
    }

    /// [`Some`] फर्काउँदछ यदि `self` मध्ये एक हो, `optb` [`Some`] हो, अन्यथा [`None`] फर्काउँछ।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x = Some(2);
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), None);
    /// ```
    #[inline]
    #[stable(feature = "option_xor", since = "1.37.0")]
    pub fn xor(self, optb: Option<T>) -> Option<T> {
        match (self, optb) {
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            _ => None,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // प्रविष्टि-जस्तो अपरेशनहरू सम्मिलित गर्न यदि कुनै होईन र सन्दर्भ फर्काउँदछ
    /////////////////////////////////////////////////////////////////////////

    /// विकल्पमा `value` सम्मिलित गर्दछ यदि यो [`None`] हो, तब समावेश गरिएको मानमा म्यूटेबल सन्दर्भ फर्काउँछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert(5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert(&mut self, value: T) -> &mut T {
        self.get_or_insert_with(|| value)
    }

    /// विकल्पमा पूर्वनिर्धारित मान सम्मिलित गर्दछ यदि यो [`None`] छ, तब समावेश मानको लागि एक म्यूटेबल सन्दर्भ फर्काउँछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_get_or_insert_default)]
    ///
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_default();
    ///     assert_eq!(y, &0);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[unstable(feature = "option_get_or_insert_default", issue = "82901")]
    pub fn get_or_insert_default(&mut self) -> &mut T
    where
        T: Default,
    {
        self.get_or_insert_with(Default::default)
    }

    /// विकल्पमा `f` बाट गणना गरिएको मान सम्मिलित गर्दछ यदि यो [`None`] हो भने, त्यसपछि समावेश गरिएको मानमा म्यूटेबल सन्दर्भ फर्काउँछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_with(|| 5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert_with<F: FnOnce() -> T>(&mut self, f: F) -> &mut T {
        if let None = *self {
            *self = Some(f());
        }

        match self {
            Some(v) => v,
            // सुरक्षा: `self` का लागि एक `None` संस्करण `Some` द्वारा प्रतिस्थापन गरिएको थियो
            // माथिको कोडमा भिन्नता।
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Misc
    /////////////////////////////////////////////////////////////////////////

    /// विकल्पको बाहिर मान लिन्छ, यसको ठाउँमा [`None`] छोड्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, Some(2));
    ///
    /// let mut x: Option<u32> = None;
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self)
    }

    /// विकल्पमा वास्तविक मान प्रतिस्थापन गर्दछ प्यारामिटरमा दिइएको मानले, पुरानो मान फिर्ता भएको खण्डमा [`Some`] लाई त्यसको ठाउँमा छोड्ने होईन कुनै एक लाई डिनिटाइज नगरिकन।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let old = x.replace(5);
    /// assert_eq!(x, Some(5));
    /// assert_eq!(old, Some(2));
    ///
    /// let mut x = None;
    /// let old = x.replace(3);
    /// assert_eq!(x, Some(3));
    /// assert_eq!(old, None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "option_replace", since = "1.31.0")]
    pub fn replace(&mut self, value: T) -> Option<T> {
        mem::replace(self, Some(value))
    }

    /// अर्को `Option` को साथ Zip `self`।
    ///
    /// यदि `self` `Some(s)` हो र `other` `Some(o)` हो भने, यो विधिले `Some((s, o))` फर्काउँछ।
    /// अन्यथा, `None` फिर्ता भयो।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(1);
    /// let y = Some("hi");
    /// let z = None::<u8>;
    ///
    /// assert_eq!(x.zip(y), Some((1, "hi")));
    /// assert_eq!(x.zip(z), None);
    /// ```
    #[stable(feature = "option_zip_option", since = "1.46.0")]
    pub fn zip<U>(self, other: Option<U>) -> Option<(T, U)> {
        match (self, other) {
            (Some(a), Some(b)) => Some((a, b)),
            _ => None,
        }
    }

    /// Zip `self` र अर्को `Option` प्रकार्य `f`।
    ///
    /// यदि `self` `Some(s)` हो र `other` `Some(o)` हो भने, यो विधिले `Some(f(s, o))` फर्काउँछ।
    /// अन्यथा, `None` फिर्ता भयो।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_zip)]
    ///
    /// #[derive(Debug, PartialEq)]
    /// struct Point {
    ///     x: f64,
    ///     y: f64,
    /// }
    ///
    /// impl Point {
    ///     fn new(x: f64, y: f64) -> Self {
    ///         Self { x, y }
    ///     }
    /// }
    ///
    /// let x = Some(17.5);
    /// let y = Some(42.7);
    ///
    /// assert_eq!(x.zip_with(y, Point::new), Some(Point { x: 17.5, y: 42.7 }));
    /// assert_eq!(x.zip_with(None, Point::new), None);
    /// ```
    #[unstable(feature = "option_zip", issue = "70086")]
    pub fn zip_with<U, F, R>(self, other: Option<U>, f: F) -> Option<R>
    where
        F: FnOnce(T, U) -> R,
    {
        Some(f(self?, other?))
    }
}

impl<T: Copy> Option<&T> {
    /// विकल्पको सामग्रीहरू प्रतिलिपि गरेर `Option<T>` मा `Option<&T>` नक्सा।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&t| t)
    }
}

impl<T: Copy> Option<&mut T> {
    /// विकल्पको सामग्रीहरू प्रतिलिपि गरेर `Option<T>` मा `Option<&mut T>` नक्सा।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone> Option<&T> {
    /// विकल्पको सामग्री क्लोनिंग गरेर `Option<T>` मा `Option<&T>` नक्सा।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone> Option<&mut T> {
    /// विकल्पको सामग्री क्लोनिंग गरेर `Option<T>` मा `Option<&mut T>` नक्सा।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(since = "1.26.0", feature = "option_ref_mut_cloned")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: fmt::Debug> Option<T> {
    /// `self` X अपेक्षा गर्दै र केहि पनि फिर्ता लिन `self` उपभोग गर्दछ।
    ///
    /// # Panics
    ///
    /// Panics यदि मान एक [`Some`] हो, पारित सन्देश सहित panic सन्देश सहित, र [`Some`] को सामग्री।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // यसले panic गर्दैन, किनकि सबै कुञ्जीहरू अद्वितीय छन्।
    ///     squares.insert(i, i * i).expect_none("duplicate key");
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).expect_none("duplicate key");
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_expect_none", reason = "newly added", issue = "62633")]
    pub fn expect_none(self, msg: &str) {
        if let Some(val) = self {
            expect_none_failed(msg, &val);
        }
    }

    /// `self` X अपेक्षा गर्दै र केहि पनि फिर्ता लिन `self` उपभोग गर्दछ।
    ///
    /// # Panics
    ///
    /// Panics यदि मान [`Some`] हो भने, [`Some`] को मान द्वारा प्रदान गरिएको कस्टम panic सन्देशको साथ।
    ///
    ///
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // यसले panic गर्दैन, किनकि सबै कुञ्जीहरू अद्वितीय छन्।
    ///     squares.insert(i, i * i).unwrap_none();
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).unwrap_none();
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_unwrap_none", reason = "newly added", issue = "62633")]
    pub fn unwrap_none(self) {
        if let Some(val) = self {
            expect_none_failed("called `Option::unwrap_none()` on a `Some` value", &val);
        }
    }
}

impl<T: Default> Option<T> {
    /// निहित [`Some`] मान वा पूर्वनिर्धारित फर्काउँछ
    ///
    /// `self` आर्गुमेन्ट लिन्छ त्यसपछि, यदि [`Some`], समावेश गरिएको मान फिर्ता गर्दछ, अन्यथा यदि [`None`], त्यस प्रकारको लागि [default value] फर्काउँछ।
    ///
    ///
    /// # Examples
    ///
    /// स्ट्रिंगलाई पूर्णांकमा रूपान्तरण गर्छ, खराब रूपले बनेको स्ट्रिंगहरूलाई ० मा बदल्छ (पूर्णांकहरूको लागि पूर्वनिर्धारित मान)।
    /// [`parse`] स्ट्रिंगलाई अन्य कुनै प्रकारमा रूपान्तरण गर्दछ जुन [`FromStr`] लागू गर्दछ, [`None`] त्रुटिमा फर्काउँदै।
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().ok().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().ok().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [default value]: Default::default
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Some(x) => x,
            None => Default::default(),
        }
    }
}

impl<T: Deref> Option<T> {
    /// `Option<T>` (वा `&Option<T>`) बाट `Option<&T::Target>` मा रूपान्तरण।
    ///
    /// मौलिक विकल्पलाई ठाउँमै छोड्छ, नयाँ एक मूल सन्दर्भको साथ नयाँ बनाउँदछ, थप रूपमा [`Deref`] मार्फत सामग्रीहरू जबरजस्ती गर्‍यो।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref(), Some("hey"));
    ///
    /// let x: Option<String> = None;
    /// assert_eq!(x.as_deref(), None);
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref(&self) -> Option<&T::Target> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut> Option<T> {
    /// `Option<T>` (वा `&mut Option<T>`) बाट `Option<&mut T::Target>` मा रूपान्तरण।
    ///
    /// मूल `Option` लाई ठाउँमा छोड्छ, नयाँ बनाएर भित्री प्रकारको `Deref::Target` प्रकारको म्यूटेबल सन्दर्भ समावेश गर्दछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref_mut().map(|x| {
    ///     x.make_ascii_uppercase();
    ///     x
    /// }), Some("HEY".to_owned().as_mut_str()));
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref_mut(&mut self) -> Option<&mut T::Target> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Option<Result<T, E>> {
    /// [`Result`] को X0 `Option` को `Option` X को [`Result`] मा बदल्छ।
    ///
    /// [`None`] [`Ok`]`(`[`કંઈ`] `)` मा म्याप गरिने छ।
    /// [`Some`]`(`[`Ok`] `(_))` र [`Some`]`(`[`एर्रे]`(_))`[`Ok`]` मा म्याप गरिनेछ। `[` Some`]`(_))`र [`Err`]` (_) `।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x, y.transpose());
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn transpose(self) -> Result<Option<T>, E> {
        match self {
            Some(Ok(x)) => Ok(Some(x)),
            Some(Err(e)) => Err(e),
            None => Ok(None),
        }
    }
}

// यो एक अलग प्रकार्य छ .expect() को कोड को आकार कम गर्न।
#[inline(never)]
#[cold]
#[track_caller]
fn expect_failed(msg: &str) -> ! {
    panic!("{}", msg)
}

// यो एक अलग प्रकार्य छ .expect_none() को कोड को आकार कम गर्न।
#[inline(never)]
#[cold]
#[track_caller]
fn expect_none_failed(msg: &str, value: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, value)
}

/////////////////////////////////////////////////////////////////////////////
// Trait कार्यान्वयन
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for Option<T> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Some(x) => Some(x.clone()),
            None => None,
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Some(to), Some(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Option<T> {
    /// [`None`][Option::None] फर्काउँछ।
    ///
    /// # Examples
    ///
    /// ```
    /// let opt: Option<u32> = Option::default();
    /// assert!(opt.is_none());
    /// ```
    #[inline]
    fn default() -> Option<T> {
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for Option<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// सम्भावित निहित मानमा खपत इट्रेटर फर्काउँछ।
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("string");
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert_eq!(v, ["string"]);
    ///
    /// let x = None;
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: Item { opt: self } }
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a Option<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a mut Option<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(since = "1.12.0", feature = "option_from")]
impl<T> From<T> for Option<T> {
    /// `val` लाई नयाँ `Some` मा प्रतिलिपि गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// let o: Option<u8> = Option::from(67);
    ///
    /// assert_eq!(Some(67), o);
    /// ```
    fn from(val: T) -> Option<T> {
        Some(val)
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a Option<T>> for Option<&'a T> {
    /// `&Option<T>` बाट `Option<&T>` मा रूपान्तरण।
    ///
    /// # Examples
    ///
    /// मौलिक संरक्षण गर्दै an विकल्प <`[` String`]`>`लाई`विकल्प <<[`usize`] `> Con मा रूपान्तरण गर्दछ।
    /// [`map`] विधिले `self` आर्गुमेन्टलाई मानले लिन्छ, मूल उपभोग गर्दछ, त्यसैले यो प्रविधीले `as_ref` प्रयोग गर्दछ पहिलो `Option` मूल भित्र मानको सन्दर्भमा लिन।
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let s: Option<String> = Some(String::from("Hello, Rustaceans!"));
    /// let o: Option<usize> = Option::from(&s).map(|ss: &String| ss.len());
    ///
    /// println!("Can still print s: {:?}", s);
    ///
    /// assert_eq!(o, Some(18));
    /// ```
    ///
    fn from(o: &'a Option<T>) -> Option<&'a T> {
        o.as_ref()
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a mut Option<T>> for Option<&'a mut T> {
    /// `&mut Option<T>` बाट `Option<&mut T>` मा रूपान्तरण
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = Some(String::from("Hello"));
    /// let o: Option<&mut String> = Option::from(&mut s);
    ///
    /// match o {
    ///     Some(t) => *t = String::from("Hello, Rustaceans!"),
    ///     None => (),
    /// }
    ///
    /// assert_eq!(s, Some(String::from("Hello, Rustaceans!")));
    /// ```
    fn from(o: &'a mut Option<T>) -> Option<&'a mut T> {
        o.as_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// विकल्प Iterators
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
struct Item<A> {
    opt: Option<A>,
}

impl<A> Iterator for Item<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.opt.take()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        match self.opt {
            Some(_) => (1, Some(1)),
            None => (0, Some(0)),
        }
    }
}

impl<A> DoubleEndedIterator for Item<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.opt.take()
    }
}

impl<A> ExactSizeIterator for Item<A> {}
impl<A> FusedIterator for Item<A> {}
unsafe impl<A> TrustedLen for Item<A> {}

/// एक [`Option`] को [`Some`] संस्करणको सन्दर्भमा एक पुनरावृत्ति।
///
/// यदि इरेटरले [`Option`] [`Some`] हो भने एक मान प्रदान गर्दछ, अन्यथा कुनै पनि होईन।
///
/// यो `struct` [`Option::iter`] प्रकार्य द्वारा बनाईएको हो।
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct Iter<'a, A: 'a> {
    inner: Item<&'a A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for Iter<'a, A> {
    type Item = &'a A;

    #[inline]
    fn next(&mut self) -> Option<&'a A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for Iter<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for Iter<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for Iter<'_, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Clone for Iter<'_, A> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner.clone() }
    }
}

/// एक [`Option`] को [`Some`] भेरिएन्टमा म्यूटेबल सन्दर्भमा एक पुनरावृत्ति।
///
/// यदि इरेटरले [`Option`] [`Some`] हो भने एक मान प्रदान गर्दछ, अन्यथा कुनै पनि होईन।
///
/// यो `struct` [`Option::iter_mut`] प्रकार्य द्वारा बनाईएको हो।
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, A: 'a> {
    inner: Item<&'a mut A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for IterMut<'a, A> {
    type Item = &'a mut A;

    #[inline]
    fn next(&mut self) -> Option<&'a mut A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for IterMut<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IterMut<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IterMut<'_, A> {}
#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// एक [`Option`] को [`Some`] भेरिएन्टमा मानमा एक पुनरावृत्तिकर्ता।
///
/// यदि इरेटरले [`Option`] [`Some`] हो भने एक मान प्रदान गर्दछ, अन्यथा कुनै पनि होईन।
///
/// यो `struct` [`Option::into_iter`] प्रकार्य द्वारा बनाईएको हो।
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<A> {
    inner: Item<A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Iterator for IntoIter<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> DoubleEndedIterator for IntoIter<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IntoIter<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IntoIter<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, V: FromIterator<A>> FromIterator<Option<A>> for Option<V> {
    /// प्रत्येक तत्वलाई [`Iterator`] मा लिन्छ: यदि यो [`None`][Option::None] हो भने, अरू कुनै पनि तत्त्वहरू लिइने छैन, र [`None`][Option::None] फर्काइन्छ।
    /// कुनै [`None`][Option::None] देखा पर्दैन, प्रत्येक [`Option`] को मानको एक कन्टेनर फिर्ता आयो।
    ///
    /// # Examples
    ///
    /// यहाँ एक उदाहरण हो जुन vector मा प्रत्येक पूर्णांक वृद्धि गर्दछ।
    /// हामी `add` को जाँच भेरियन्ट को उपयोग गर्छौं जसले `None` रिटर्न गर्छ जब गणना एक ओभरफ्लोको परिणाम हुनेछ।
    ///
    /// ```
    /// let items = vec![0_u16, 1, 2];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_add(1))
    ///     .collect();
    ///
    /// assert_eq!(res, Some(vec![1, 2, 3]));
    /// ```
    ///
    /// तपाईमले देख्न सक्नुहुने रूपमा, यसले अपेक्षित, मान्य आईटमहरू फर्काउँछ।
    ///
    /// यहाँ अर्को उदाहरण हो जुन अर्को पूर्णांकको सूचीबाट एकलाई घटाउने प्रयास गर्दछ, यस बखत अन्डरफ्लो जाँच गर्दै:
    ///
    /// ```
    /// let items = vec![2_u16, 1, 0];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_sub(1))
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// ```
    ///
    /// अन्तिम तत्व शून्य भएकोले, यो बग्नेछ।यसैले, नतिजा मान `None` हो।
    ///
    /// यहाँ अघिल्लो उदाहरणमा भिन्नता छ, देखाउँदै कि पहिलो `None` पछि अरु कुनै पनि तत्वहरू `iter` बाट लिएका छैनन्।
    ///
    /// ```
    /// let items = vec![3_u16, 2, 1, 10];
    ///
    /// let mut shared = 0;
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| { shared += x; x.checked_sub(2) })
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// तेस्रो तत्त्वले एक इन्डफ्लोको कारणले, कुनै थप तत्वहरू लिएको थिएन, त्यसैले `shared` को अन्तिम मान 16 (= `3 + 2 + 1`) हो, १ not होईन।
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Option<A>>>(iter: I) -> Option<V> {
        // FIXME(#11084): यो Iterator::scan का साथ प्रतिस्थापन गर्न सकिन्छ जब यो प्रदर्शन बग बन्द छ।
        //

        iter.into_iter().map(|x| x.ok_or(())).collect::<Result<_, _>>().ok()
    }
}

/// त्रुटि प्रकार जुन X1X X को मान अपरेटिंग अपरेटर (`?`) लागू गर्दा परिणाम दिन्छ।
/// यदि तपाइँ `x?` (जहाँ `x` एक `Option<T>` हो) लाई तपाइँको त्रुटि प्रकारमा रूपान्तरण गर्न चाहानुहुन्छ भने तपाइँ `YourErrorType` को लागी `impl From<NoneError>` लागू गर्न सक्नुहुनेछ।
///
/// त्यो अवस्थामा,`x?` X फिर्ता बीचमा `x?` `Result<_, YourErrorType>` परिणामलाई `None` मान अनुवाद गर्दछ।
#[rustc_diagnostic_item = "none_error"]
#[unstable(feature = "try_trait", issue = "42327")]
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
pub struct NoneError;

#[unstable(feature = "try_trait", issue = "42327")]
impl<T> ops::Try for Option<T> {
    type Ok = T;
    type Error = NoneError;

    #[inline]
    fn into_result(self) -> Result<T, NoneError> {
        self.ok_or(NoneError)
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Some(v)
    }

    #[inline]
    fn from_error(_: NoneError) -> Self {
        None
    }
}

impl<T> Option<Option<T>> {
    /// `Option<Option<T>>` बाट `Option<T>` मा रूपान्तरण
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let x: Option<Option<u32>> = Some(Some(6));
    /// assert_eq!(Some(6), x.flatten());
    ///
    /// let x: Option<Option<u32>> = Some(None);
    /// assert_eq!(None, x.flatten());
    ///
    /// let x: Option<Option<u32>> = None;
    /// assert_eq!(None, x.flatten());
    /// ```
    ///
    /// फ्ल्याटनिंगले एक पटकमा नेस्टिंगको एक स्तर मात्र हटाउँछ:
    ///
    /// ```
    /// let x: Option<Option<Option<u32>>> = Some(Some(Some(6)));
    /// assert_eq!(Some(Some(6)), x.flatten());
    /// assert_eq!(Some(6), x.flatten().flatten());
    /// ```
    #[inline]
    #[stable(feature = "option_flattening", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn flatten(self) -> Option<T> {
        match self {
            Some(inner) => inner,
            None => None,
        }
    }
}