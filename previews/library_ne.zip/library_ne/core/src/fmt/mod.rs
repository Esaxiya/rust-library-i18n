//! ढाँचा र प्रिन्टिंग तारका लागि उपयोगिताहरू।

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// सम्भावित पign्क्तिबद्धताहरू `Formatter::align` द्वारा फर्कियो
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// सूचित गर्नुहोस् कि सामग्री बाँया-पigned्क्तिबद्ध हुनुपर्छ।
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// सामग्री सही-पigned्क्तिबद्ध हुनु पर्छ भनेर संकेत।
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// सामग्री केन्द्र-पigned्क्तिबद्ध हुनु पर्छ भनेर संकेत।
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// प्रकार ढाँचा विधिहरु द्वारा फिर्ता।
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// स्ट्रिममा सन्देश ढाँचा गरेकोबाट फर्काइएको त्रुटि प्रकार।
///
/// यस प्रकारले एक त्रुटि भएको बाहेक त्रुटिको प्रसारण समर्थन गर्दैन।
/// कुनै पनि अतिरिक्त जानकारी केहि अन्य माध्यमहरू मार्फत प्रसारित गर्न व्यवस्थित गरिएको हुनुपर्दछ।
///
/// सम्झनको लागि एउटा महत्त्वपूर्ण कुरा यो छ कि प्रकार `fmt::Error` [`std::io::Error`] वा [`std::error::Error`] संग भ्रमित गर्नु हुँदैन, जुन तपाईं पनि दायरामा हुन सक्नुहुन्छ।
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// एक trait लेखन वा युनिकोड स्वीकार्य बफरहरू वा स्ट्रिमहरूमा ढाँचाका लागि।
///
/// यो trait मात्र UTF-8 od एन्कोड गरिएको डाटा स्वीकार गर्दछ र [flushable] होईन।
/// यदि तपाईं केवल युनिकोड स्वीकार गर्न चाहानुहुन्छ र तपाईंलाई फ्ल्याशिंगको आवश्यक पर्दैन भने, तपाईंले यो trait कार्यान्वयन गर्नु पर्छ;
/// अन्यथा तपाईंले [`std::io::Write`] कार्यान्वयन गर्नुपर्छ।
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// यस लेखकमा स्ट्रि sl स्लाइस लेख्दछ, लेखन सफल भयो कि हुन्न भनेर फिर्ता।
    ///
    /// यो विधि मात्र सफल हुन सक्दछ यदि सम्पूर्ण स्ट्रिंग स्लाइस सफलतापूर्वक लेखिएको थियो, र यो विधि फिर्ता हुनेछैन जब सम्म सबै डाटा लेखिएको छ वा त्रुटि देखा पर्दैन।
    ///
    ///
    /// # Errors
    ///
    /// यो प्रकार्य त्रुटि मा [`Error`] को एक उदाहरण फर्काउँछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// यस लेखकमा [`char`] लेख्दछ, लेखन सफल भयो कि हुन्न भनेर फिर्ता।
    ///
    /// एकल [`char`] एक भन्दा बढी बाइटको रूपमा स enc्केतन हुन सक्छ।
    /// यो विधि मात्र सफल हुन सक्दछ यदि सम्पूर्ण बाइट अनुक्रम सफलतापूर्वक लेखिएको थियो, र यो विधि फिर्ता हुनेछैन जब सम्म सबै डाटा लेखिएको छ वा त्रुटि देखा पर्दैन।
    ///
    ///
    /// # Errors
    ///
    /// यो प्रकार्य त्रुटि मा [`Error`] को एक उदाहरण फर्काउँछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// यस trait को लागूकर्ताहरूसँग [`write!`] म्याक्रोको उपयोगको लागि ग्लू।
    ///
    /// यो विधि सामान्यतया मैन्युअल रूपमा आह्वान गरिनु हुँदैन, तर [`write!`] म्याक्रोको माध्यमबाट मात्र।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// ढाँचाका लागि कन्फिगरेसन।
///
/// एक `Formatter` ढाँचा सम्बन्धित विभिन्न विकल्प प्रतिनिधित्व गर्दछ।
/// प्रयोगकर्ताहरू सिधा mat ढाँचा निर्माण गर्दैन;एकलाई एक परिवर्तनीय सन्दर्भ [`Debug`] र [`Display`] जस्तै traits, सबै ढाँचाको `fmt` विधिमा पारित गरियो।
///
///
/// `Formatter` सँग कुराकानी गर्न, तपाई ढाँचामा सम्बन्धित विभिन्न विकल्पहरू परिवर्तन गर्न विभिन्न विधिहरू कल गर्नुहुनेछ।
/// उदाहरणका लागि, कृपया तल `Formatter` मा परिभाषित विधिहरूको कागजात हेर्नुहोस्।
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// तर्क मूलत: एक अप्टिमाइजेड आंशिक रूपमा लागू ढाँचा समारोह हो, `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result` बराबर।

extern "C" {
    type Opaque;
}

/// यस संरचनाले जेनेरिक "argument" प्रतिनिधित्व गर्दछ जुन कार्यहरूको Xprintf परिवार द्वारा लिइएको हो।यसले दिईएको मान ढाँचा गर्नको लागि प्रकार्य समावेश गर्दछ।
/// कम्पाइल समयमा यो सुनिश्चित गरिन्छ कि प्रकार्य र मानसँग सहि प्रकारहरू छन्, र त्यसपछि यो संरचना एक प्रकारको आर्गुमेन्टहरूलाई प्रमाणिकरण गर्न प्रयोग गरिन्छ।
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// यसले ढाँचा पूर्वाधारमा indices/counts सँग सम्बन्धित प्रकार्य सूचकका लागि एकल स्थिर मूल्यको ग्यारेन्टी गर्दछ।
//
// नोट गर्नुहोस् कि यस प्रकार परिभाषित कार्य सही हुँदैन किनकि प्रकार्यहरू सँधै LLVM IR मा हालको घट्नेसँग अज्ञात_addr ट्याग गरिन्छ, त्यसैले उनीहरूको ठेगाना LLVM लाई महत्त्वपूर्ण ठानिदैन र त्यस्तै as_usize कास्टको गलत मिसन गरिएको हुन सक्दछ।
//
// अभ्यासमा, हामी कहिले पनि as-usize लाई गैर-प्रयोग युक्त डेटामा ढाँचा गर्दैनौं (ढाँचा तर्कहरूको स्थिर पिढीको कुराको रूपमा), त्यसैले यो केवल अतिरिक्त जाँच हो।
//
// हामी मुख्य रूपमा यो सुनिश्चित गर्न चाहन्छौं कि `USIZE_MARKER` मा प्रकार्य सूचकसँग एउटा ठेगाना छ *केवल* प्रकार्यहरूमा जुन `&usize` लाई पनि आफ्नो पहिलो तर्कको रूपमा लिन्छ।
// यहाँ पढ्ने_अस्थिरताले सुनिश्चित गर्दछ कि हामी पारित सन्दर्भबाट एक युजलाई सुरक्षित रूपमा तयार गर्न सक्छौं र यो ठेगानाले गैर-प्रयोग आकार लिने समारोहमा सूचित गर्दैन।
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // सुरक्षा: ptr एक सन्दर्भ हो
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // सुरक्षा: `mem::transmute(x)` सुरक्षित छ किनभने
        //     1. `&'b T` यो `'b` को साथ उत्पन्न जीवनकाल राख्छ (ताकि एक अनबाउन्ड जीवनकाल छैन)
        //     2.
        //     `&'b T` र `&'b Opaque` सँग समान मेमोरी लेआउट छ (जब `T` `Sized` छ, यो यहाँ छ) `mem::transmute(f)` सुरक्षित छ किनकि `fn(&T, &mut Formatter<'_>) -> Result` र `fn(&Opaque, &mut Formatter<'_>) -> Result` सँग समान ABI (`T` `Sized` सम्म लामो)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // सुरक्षा: `formatter` फिल्ड मात्र USIZE_MARKER मा सेट गरिएको छ यदि
            // मान एक usize हो, त्यसैले यो सुरक्षित छ
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// फ्ल्यागहरू v1 ढाँचामा format_args मा उपलब्ध छ
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// Format_args! () म्याक्रो प्रयोग गर्दा, यो प्रकार्य आर्गुमेन्ट संरचना उत्पन्न गर्न प्रयोग गरिन्छ।
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// यो प्रकार्य अमानक स्वरूपण प्यारामिटरहरू निर्दिष्ट गर्न प्रयोग गरिन्छ।
    /// `pieces` एरे कम्तिमा `fmt` सम्म लामो हुनुपर्दछ मान्य आर्गुमेन्ट संरचना निर्माण गर्न।
    /// साथै, कुनै `Count` `fmt` भित्र `CountIsParam` वा `CountIsNextParam` `argumentusize` को साथ बनेको एउटा तर्कलाई देखाउनु पर्छ।
    ///
    /// जे होस्, त्यसो गर्न असफल भयो असुरक्षित कारणले गर्दैन, तर अवैध बेवास्ता गर्दछ।
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// फर्म्याट गरिएको पाठको लम्बाइ अनुमान गर्छ।
    ///
    /// यो `format!` प्रयोग गर्दा प्रारम्भिक `String` क्षमता सेट गर्नका लागि प्रयोग गर्नका लागि प्रयोग गरिएको हो।
    /// Note: यो तल्लो वा माथिल्लो सीमा होईन।
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // यदि ढाँचा स्ट्रिंग एक आर्गुमेन्ट को साथ शुरू हुन्छ भने, केहि पनि prealloc छैन, जब सम्म टुक्रा को लम्बाई महत्वपूर्ण छ।
            //
            //
            0
        } else {
            // त्यहाँ केही आर्गुमेन्टहरू छन्, त्यसैले कुनै पनि थप धक्काले स्ट्रिंग पुन: स्थानान्तरण गर्दछ।
            //
            // यसलाई रोक्नको लागि, हामी यहाँ "pre-doubling" क्षमता छौं।
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// यो संरचना एक ढाँचा स्ट्रि string र यसको आर्गुमेन्ट को एक सुरक्षित पूर्वावलोकन संस्करण प्रतिनिधित्व गर्दछ।
/// यो रनटाइममा उत्पन्न गर्न सकिदैन किनकि यो सुरक्षित तरिकाले गर्न सकिदैन, त्यसैले कुनै निर्माणकर्ताहरू दिइएनन् र फिल्डहरू निजीकरण छन् परिमार्जन रोक्नको लागि।
///
///
/// [`format_args!`] म्याक्रो सुरक्षित यस संरचनाको एक घटना सिर्जना गर्दछ।
/// म्याक्रोले कम्पाईल समयमा ढाँचा स्ट्रिंग मान्य गर्दछ त्यसैले [`write()`] र [`format()`] प्रकार्यहरूको उपयोग सुरक्षित रूपमा गर्न सकिन्छ।
///
/// तपाईं `Arguments<'a>` प्रयोग गर्न सक्नुहुनेछ जुन [`format_args!`] `Debug` र `Display` प्रसंगहरूमा तल देखा पर्दछ।
/// उदाहरणले `Debug` र `Display` ढाँचामा समान कुरा पनि देखाउँदछ: `format_args!` मा इंटरपोलटेड ढाँचा स्ट्रि।।
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // मुद्रण गर्न स्ट्रिंग टुक्रा फर्म्याट गर्नुहोस्।
    pieces: &'a [&'static str],

    // प्लेसहोल्डर चश्मा, वा `None` यदि सबै चश्मा पूर्वनिर्धारित छन् ("{}{}" मा जस्तै)।
    fmt: Option<&'a [rt::v1::Argument]>,

    // इन्टरपोलेसनको लागि डाईनामिक तर्कहरू, स्ट्रि pieces्ग टुक्राको साथ इन्टरल्याभ गर्न।
    // (प्रत्येक तर्क स्ट्रिंग टुक्रा द्वारा अगाडि छ।)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// ढाँचाबद्ध स्ट्रि Get प्राप्त गर्नुहोस्, यदि यससँग स्वरूपण गर्न कुनै तर्कहरू छैन भने।
    ///
    /// यो सबै भन्दा तुच्छ मामला मा विनियोजन रोक्न को लागी प्रयोग गर्न सकिन्छ।
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` प्रोग्रामर-डिबगिंग कन्टेक्स्टमा आउटपुटलाई ढाँचा गर्नु पर्छ।
///
/// सामान्यतया, तपाईले `derive` मात्र `Debug` कार्यान्वयन गर्नुपर्छ।
///
/// जब वैकल्पिक ढाँचा निर्दिष्टकर्ता `#?` का साथ प्रयोग गर्दा आउटपुट सुन्दर-प्रिन्ट गरिएको छ।
///
/// ढाँचामा अधिक जानकारीको लागि, हेर्नुहोस् [the module-level documentation][module]।
///
/// [module]: ../../std/fmt/index.html
///
/// यो trait `#[derive]` का साथ प्रयोग गर्न सकिन्छ यदि सबै फिल्डहरू `Debug` लागू गर्दछ।
/// जब स्ट्राक्टहरूको लागि deriv`d, यो `struct` को नाम, तब `{`, तब अल्पविराम-विभाजित प्रत्येक क्षेत्रको नाम र `Debug` मानको सूची प्रयोग गर्दछ, तब `}`।
/// `Enum`s को लागि, यसले संस्करणको नाम प्रयोग गर्दछ र यदि लागू हुन्छ भने `(`, तब फिल्डहरूको `Debug` मानहरू, तब `)`।
///
/// # Stability
///
/// व्युत्पन्न `Debug` ढाँचा स्थिर छैन, र future Rust संस्करणको साथ परिवर्तन हुन सक्दछ।
/// थप रूपमा, मानक पुस्तकालय (by libstd`, `libcore`, `liballoc`, आदि) द्वारा प्रदान गरिएको प्रकारहरूको `Debug` कार्यान्वयन स्थिर छैन, र future Rust संस्करणको साथ परिवर्तन हुन सक्दछ।
///
///
/// # Examples
///
/// कार्यान्वयनको खोजी गर्दै:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// मैन्युअली कार्यान्वयन:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// [`Formatter`] संरचनामा तपाइँलाई म्यानुअल कार्यान्वयनको लागि मद्दत गर्न धेरै सहयोगी विधिहरू छन्, जस्तै [`debug_struct`]।
///
/// `Debug` या त `derive` वा डिबग बिल्डर एपीआई प्रयोग गरेर कार्यान्वयन [`Formatter`] वैकल्पिक झण्डा प्रयोग गरी प्रिन्टि प्रिन्टि support समर्थन गर्दछ। `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// `#?` को साथ धेरै प्रिन्टि: :
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// दिइएको ढाँचा प्रयोग गरि मान ढाँचा।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// trait `Debug` बिना preolve बाट म्याक्रो `Debug` पुन: निर्यात गर्न मोड्युल अलग गर्नुहोस्।
pub(crate) mod macros {
    /// trait `Debug` को एक इम्प्ली उत्पन्न डेरिभ म्याक्रो।
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// खाली ढाँचाको लागि trait ढाँचा, `{}`.
///
/// `Display` [`Debug`] सँग समान छ, तर `Display` प्रयोगकर्ता-सामना आउटपुटको लागि हो, र त्यसैले व्युत्पन्न हुन सक्दैन।
///
///
/// ढाँचामा अधिक जानकारीको लागि, हेर्नुहोस् [the module-level documentation][module]।
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// एक प्रकारमा `Display` कार्यान्वयन गर्दै:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// दिइएको ढाँचा प्रयोग गरि मान ढाँचा।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` trait ले यसको आउटपुट base-8 मा नम्बरको रूपमा ढाँचा गर्नुपर्दछ।
///
/// आदिममा हस्ताक्षरित पूर्णांक (`i8` बाट `i128`, र `isize`) को लागि, नकारात्मक मानहरू दुईको पूरक प्रतिनिधित्वको रूपमा ढाँचा गरिएको छ।
///
///
/// वैकल्पिक झण्डा, `#`, आउटपुट अगाडि `0o` जोड्छ।
///
/// ढाँचामा अधिक जानकारीको लागि, हेर्नुहोस् [the module-level documentation][module]।
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` को साथ आधारभूत उपयोग:
///
/// ```
/// let x = 42; // २ अक्टलमा '52' हो
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// एक प्रकारमा `Octal` कार्यान्वयन गर्दै:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // i32 को कार्यान्वयन गर्न प्रतिनिधि
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// दिइएको ढाँचा प्रयोग गरि मान ढाँचा।
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait ले बाइनरीमा नम्बरको रूपमा यसको आउटपुट ढाँचा गर्नुपर्दछ।
///
/// आदिममा हस्ताक्षरित पूर्णांक ([`i8`] बाट [`i128`], र [`isize`]) को लागि, नकारात्मक मानहरू दुईको पूरक प्रतिनिधित्वको रूपमा ढाँचा गरिएको छ।
///
///
/// वैकल्पिक झण्डा, `#`, आउटपुट अगाडि `0b` जोड्छ।
///
/// ढाँचामा अधिक जानकारीको लागि, हेर्नुहोस् [the module-level documentation][module]।
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// [`i32`] को साथ आधारभूत उपयोग:
///
/// ```
/// let x = 42; // B२ बाइनरीमा '101010' हो
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// एक प्रकारमा `Binary` कार्यान्वयन गर्दै:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // i32 को कार्यान्वयन गर्न प्रतिनिधि
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// दिइएको ढाँचा प्रयोग गरि मान ढाँचा।
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` trait ले यसको आउटपुट हेक्साडेसिमलमा नम्बरको रूपमा ढाँचा गर्नुपर्नेछ, `a` मार्फत `f` कम केसमा।
///
/// आदिममा हस्ताक्षरित पूर्णांक (`i8` बाट `i128`, र `isize`) को लागि, नकारात्मक मानहरू दुईको पूरक प्रतिनिधित्वको रूपमा ढाँचा गरिएको छ।
///
///
/// वैकल्पिक झण्डा, `#`, आउटपुट अगाडि `0x` जोड्छ।
///
/// ढाँचामा अधिक जानकारीको लागि, हेर्नुहोस् [the module-level documentation][module]।
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` को साथ आधारभूत उपयोग:
///
/// ```
/// let x = 42; // २ हेक्समा '2a' हो
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// एक प्रकारमा `LowerHex` कार्यान्वयन गर्दै:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // i32 को कार्यान्वयन गर्न प्रतिनिधि
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// दिइएको ढाँचा प्रयोग गरि मान ढाँचा।
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait ले यसको आउटपुट हेक्साडेसिमलमा नम्बरको रूपमा ढाँचा गर्नुपर्दछ, `A` मार्फत `F` माथिल्लो केसमा।
///
/// आदिममा हस्ताक्षरित पूर्णांक (`i8` बाट `i128`, र `isize`) को लागि, नकारात्मक मानहरू दुईको पूरक प्रतिनिधित्वको रूपमा ढाँचा गरिएको छ।
///
///
/// वैकल्पिक झण्डा, `#`, आउटपुट अगाडि `0x` जोड्छ।
///
/// ढाँचामा अधिक जानकारीको लागि, हेर्नुहोस् [the module-level documentation][module]।
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` को साथ आधारभूत उपयोग:
///
/// ```
/// let x = 42; // २ हेक्समा '2A' हो
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// एक प्रकारमा `UpperHex` कार्यान्वयन गर्दै:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // i32 को कार्यान्वयन गर्न प्रतिनिधि
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// दिइएको ढाँचा प्रयोग गरि मान ढाँचा।
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait ले यसको आउटपुट मेमोरी स्थानको रूपमा ढाँचा गर्नुपर्दछ।
/// यो सामान्यतया हेक्साडेसिमलको रूपमा प्रस्तुत गरिन्छ।
///
/// ढाँचामा अधिक जानकारीको लागि, हेर्नुहोस् [the module-level documentation][module]।
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `&i32` को साथ आधारभूत उपयोग:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // यसले '0x7f06092ac6d0' जस्तो उत्पादन गर्दछ
/// ```
///
/// एक प्रकारमा `Pointer` कार्यान्वयन गर्दै:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // `*const T` प्रयोग गर्नुहोस् `* const T` मा रूपान्तरण गर्न, जसले पोइन्टर लागू गर्दछ, जुन हामी प्रयोग गर्न सक्छौं
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// दिइएको ढाँचा प्रयोग गरि मान ढाँचा।
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// `LowerExp` trait ले यसको आउटपुट वैज्ञानिक नोटेशनमा सानो केस `e` को साथ ढाँचा गर्नुपर्दछ।
///
/// ढाँचामा अधिक जानकारीको लागि, हेर्नुहोस् [the module-level documentation][module]।
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` को साथ आधारभूत उपयोग:
///
/// ```
/// let x = 42.0; // 42.0 वैज्ञानिक संकेतन मा '4.2e1' छ
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// एक प्रकारमा `LowerExp` कार्यान्वयन गर्दै:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // F64 को कार्यान्वयन प्रतिनिधि
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// दिइएको ढाँचा प्रयोग गरि मान ढाँचा।
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` trait एक अपर केस `E` को साथ वैज्ञानिक संकेत मा यसको आउटपुट स्वरूपित गर्नु पर्छ।
///
/// ढाँचामा अधिक जानकारीको लागि, हेर्नुहोस् [the module-level documentation][module]।
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` को साथ आधारभूत उपयोग:
///
/// ```
/// let x = 42.0; // 42.0 वैज्ञानिक संकेतन मा '4.2E1' छ
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// एक प्रकारमा `UpperExp` कार्यान्वयन गर्दै:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // F64 को कार्यान्वयन प्रतिनिधि
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// दिइएको ढाँचा प्रयोग गरि मान ढाँचा।
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `write` प्रकार्यले आउटपुट स्ट्रिम लिन्छ, र `Arguments` स्ट्रक्चर जुन `format_args!` म्याक्रोको साथ प्रम्पम्पिल गर्न सकिन्छ।
///
///
/// आर्गुमेन्टहरू प्रदान गरिएको आउटपुट स्ट्रिममा निर्दिष्ट ढाँचा स्ट्रिंगको आधारमा फर्म्याट हुनेछन्।
///
/// # Examples
///
/// आधारभूत उपयोग:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// कृपया नोट गर्नुहोस् कि [`write!`] प्रयोग गर्नु राम्रो हुन सक्छ।उदाहरण:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // हामी सबै तर्कहरूको लागि पूर्वनिर्धारित ढाँचा प्यारामिटरहरू प्रयोग गर्न सक्छौं।
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // प्रत्येक कल्पनासँग एक सान्दर्भिक तर्क छ जुन स्ट्रिंग पीस पछि हुन्छ।
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // सुरक्षा: आर्ग र args.args उही आर्गुमेन्टहरूबाट आउँदछ,
                // जसले अनुक्रमणिका ग्यारेन्टी गर्दछ सधैं सीमा भित्र हुन्छ।
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // त्यहाँ केवल एक ट्रेलि string स्ट्रि piece टुक्रा बाँकी हुन सक्छ।
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // सुरक्षा: आर्ग र आर्गुमेन्टहरु उहि आर्गुमेन्टहरुबाट आउँदछ,
    // जसले अनुक्रमणिका ग्यारेन्टी गर्दछ सधैं सीमा भित्र हुन्छ।
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // सही तर्क निकाल्नुहोस्
    debug_assert!(arg.position < args.len());
    // सुरक्षा: आर्ग र आर्गुमेन्टहरु उहि आर्गुमेन्टहरुबाट आउँदछ,
    // जसले यसको सूचकांक सधैं सीमा भित्र हुन्छ।
    let value = unsafe { args.get_unchecked(arg.position) };

    // त्यसो हो भने केही प्रिन्टिंग गर्नुहोस्
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // सुरक्षा: cnt र आर्कहरु एउटै तर्क बाट आयो,
            // जसले ग्यारेन्टी गर्दछ यो सूचकांक सँधै सिमाना भित्र हुन्छ।
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// केहीको अन्त्य पछि प्याडिंग।`Formatter::padding` द्वारा फिर्ता
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// यो पोष्ट प्याडि। लेख्नुहोस्।
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // हामी यसलाई परिवर्तन गर्न चाहन्छौं
            buf: wrap(self.buf),

            // र यी संरक्षण गर्नुहोस्
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // प्याडिंग र फर्म्याटि arguग आर्गुमेन्टहरू प्रशोधन गर्नका लागि सहयोगी विधिहरू जुन सबै traits ले ढाँचामा प्रयोग गर्न सक्दछ।
    //

    /// पूर्णांकको लागि सही प्याडि Per प्रदर्शन गर्दछ जुन एक स्ट्र्याममा पहिल्यै सारिएको छ।
    /// Str *मा* पूर्णांकको लागि चिन्ह हुनु हुँदैन, जुन यो विधिद्वारा थपिने छ।
    ///
    /// # Arguments
    ///
    /// * is_nonnegative, कि मूल पूर्णांक या त सकारात्मक थियो वा शून्य।
    /// * उपसर्ग, यदि '#' वर्ण (Alternate) प्रदान गरीएको छ, यो नम्बर को लागी उपसर्ग हो।
    ///
    /// * बुफ, बाइट एर्रे जुन नम्बर फर्म्याट गरिएको छ
    ///
    /// यो प्रकार्य सही रूपमा प्रदान गरिएको फ्ल्यागका लागि कम से कम चौडाईको लागि खाता दिनेछ।
    /// यो ध्यानमा लिने छैन।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // हामीले नम्बर आउटपुटबाट "-" हटाउनु पर्छ।
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // यदि यो अवस्थित भएमा चिन्ह लेख्छ, र त्यसपछि यदि यो अनुरोध गरिएको थियो भने उपसर्ग
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // `width` फिल्ड यस बिन्दुमा `min-width` प्यारामिटरको बढी छ।
        match self.width {
            // यदि त्यहाँ न्यूनतम लम्बाइ आवश्यकताहरू छैन भने हामी बाइटहरू मात्र लेख्न सक्दछौं।
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // हामी न्यूनतम चौडाई भन्दा बढि जाँच गर्नुहोस्, यदि त्यसो हो भने हामी बाइट पनि लेख्न सक्छौं।
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // चिन्ह र उपसर्ग प्याडिंग अघि जान्छ यदि भरण वर्ण शून्य छ
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // अन्यथा, चिन्ह र उपसर्ग प्याडिंग पछि जान्छ
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// यो प्रकार्यले स्ट्रि sl स्लाइस लिन्छ र निर्दिष्ट गरिएको ढाँचा फ्ल्याग निर्दिष्ट गरिएको पछि आन्तरिक बफरमा यसलाई प्रस्फुटन गर्दछ।
    /// सामान्य स्ट्रिंगको लागि मान्यता प्राप्त फ्ल्यागहरू हुन्:
    ///
    /// * चौडाई, के emitted के न्यूनतम चौडाई
    /// * fill/align - के उत्सर्जन गर्ने र कहाँ उत्सर्जन गर्ने यदि स्ट्रिंग प्याड गर्न आवश्यक छ
    /// * परिशुद्धता, उत्सर्जन गर्न अधिकतम लम्बाई, स्ट्रिun काटिन्छ यदि यो लम्बाइ भन्दा लामो छ भने
    ///
    /// विशेष रूपमा यो प्रकार्यले `flag` प्यारामिटरहरू बेवास्ता गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // निश्चित गर्नुहोस् कि त्यहाँ छिटो बाटो छ अगाडि छ
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // `precision` फाँटलाई `max-width` स्ट्रिंग ढाँचामा लागि व्याख्या गर्न सकिन्छ।
        //
        let s = if let Some(max) = self.precision {
            // यदि हाम्रो स्ट्रिंग लामो भन्दा सटीक छ, तब हामी काट्नु पर्छ।
            // जबकि अन्य फ्ल्यागहरू `fill`, `width` र `align` जहिले कार्य गर्दछ।
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // यहाँ LLVM प्रमाणित गर्न सक्दैन `..i` panic `&s[..i]` गर्दैन, तर हामी जान्दछौं कि यो panic सक्दैन।
                // `unsafe` बचाउन `get` + `unwrap_or` प्रयोग गर्नुहोस् र अन्यथा यहाँ कुनै panic सम्बन्धित कोडको उत्सर्जन नगर्नुहोस्।
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // `width` फिल्ड यस बिन्दुमा `min-width` प्यारामिटरको बढी छ।
        match self.width {
            // यदि हामी अधिकतम लम्बाई मुनि छौं, र त्यहाँ न्यूनतम लम्बाइ आवश्यकता छैन भने, हामी केवल स्ट्रिंग उत्सर्जन गर्न सक्दछौं
            //
            None => self.buf.write_str(s),
            // यदि हामी अधिकतम चौडाई मुनि छौं भने, हामी न्यूनतम चौडाई भन्दा माथि छ कि छैन जाँच गर्नुहोस्, यदि यो स्ट्रिंग उत्सर्जन गर्ने जत्तिकै सजिलो छ।
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // यदि हामी दुबै अधिकतम र न्यूनतम चौडाई मुनि छौं भने, तब निर्दिष्ट स्ट्रि + + केही पign्क्तिबद्धको साथ न्यूनतम चौडाइ भर्नुहोस्।
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// प्रि-प्याडि Write लेख्नुहोस् र अलिखित पोस्ट-प्याडि return फिर्ता गर्नुहोस्।
    /// कलरहरू पोस्ट प्याडिंग सुनिश्चित गर्नका लागि जिम्मेवार छन् प्याडेड भइरहेको कुरा पछि लेखिएको छ।
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// ढाँचाको भागहरू लिन्छ र प्याडिding लागू गर्दछ।
    /// मान्नुहोस् कि कलरले पहिले नै आवश्यक सटीकको साथ भागहरू रेन्डर गरिसकेका छ, ताकि `self.precision` उपेक्षा गर्न सकिन्छ।
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // साइन-अवेयर शून्य प्याडि forको लागि, हामी पहिलो साइन रेन्डर गर्दछौं र व्यवहार गर्दछौं जस्तो कि यदि शुरूदेखि नै कुनै साइन छैन।
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // चिन्ह सधैं पहिले जान्छ
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // ढाँचाको भागबाट साइन हटाउनुहोस्
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // बाँकी भागहरू साधारण प्याडि process प्रक्रिया मार्फत जान्छन्।
            let len = formatted.len();
            let ret = if width <= len {
                // प्याडि no छैन
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // यो सामान्य केस हो र हामी एक सर्टकट लिन्छौं
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // सुरक्षा: यो `flt2dec::Part::Num` र `flt2dec::Part::Copy` का लागि प्रयोग गरीन्छ।
            // यो `flt2dec::Part::Num` को लागि प्रयोग गर्न सुरक्षित छ किनकि हरेक Char `c` `b'0'` र `b'9'` को बिचमा छ, जसको मतलब `s` मान्य UTF-8 हो।
            // यो `flt2dec::Part::Copy(buf)` को लागि प्रयोग गर्न अभ्यासमा सुरक्षित पनि छ किनकि `buf` सादा ASCII हुनु पर्छ, तर यो सम्भव छ कसैले `buf` को खराब मानमा `flt2dec::to_shortest_str` मा पास गर्न सक्दछ किनकि यो एक सार्वजनिक समारोह हो।
            //
            // FIXME: निर्धारण गर्नुहोस् कि यसले यूबीमा परिणाम दिन सक्छ।
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // Z 64 शून्य
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// यस ढाँचा भित्र निहित अंतर्निहित बफरमा केहि डेटा लेख्दछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // यो बराबर छ:
    ///         // लेख्नुहोस्! (ढाँचा, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// यस उदाहरण मा केहि स्वरूपित जानकारी लेख्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// ढाँचाका लागि फ्ल्यागहरू
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// क्यारेक्टर 'fill' को रूपमा प्रयोग गरीएको छ जब प .्क्तिबद्धता हुन्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // हामीले ">" का साथ दायाँ प al्क्तिबद्धता सेट गर्‍यौं।
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// झण्डा स्केत गर्दै कुन प्रकारको पign्क्तिबद्धता अनुरोध गरिएको थियो।
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// वैकल्पिक रूपमा निर्दिष्ट पूर्णांक चौड़ाई जुन आउटपुट हुनुपर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // यदि हामीले चौडाई प्राप्त गर्यौं भने, हामी यसलाई प्रयोग गर्दछौं
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // अन्यथा हामी विशेष केहि गर्दैनौं
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// वैकल्पिक रूपमा संख्यात्मक प्रकारहरूको लागि निर्दिष्ट सटीक।
    /// वैकल्पिक रूपमा, स्ट्रिंग प्रकारका लागि अधिकतम चौडाई।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // यदि हामीले सटीक प्राप्त गरेका छौं भने, हामी यसलाई प्रयोग गर्दछौं।
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // अन्यथा हामी २ मा पूर्वनिर्धारित गर्दछौं।
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// यदि `+` झण्डा निर्दिष्ट गरिएको थियो निर्धारण गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// यदि `-` झण्डा निर्दिष्ट गरिएको थियो निर्धारण गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // तपाईं माइनस चिन्ह चाहनुहुन्छ?एक छ!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// यदि `#` झण्डा निर्दिष्ट गरिएको थियो निर्धारण गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// यदि `0` झण्डा निर्दिष्ट गरिएको थियो निर्धारण गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // हामी ढाँचाका विकल्पहरूलाई वेवास्ता गर्दछौं।
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: निर्णय गर्नुहोस् कि कुन सार्वजनिक एपीआई हामी यी दुई फ्ल्यागहरूको लागि चाहन्छौं।
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// स्ट्राक्टहरूको लागि [`fmt::Debug`] कार्यान्वयनको सिर्जना गर्न सहयोग पुर्‍याउन एक [`DebugStruct`] बिल्डर सिर्जना गर्दछ।
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// ट्युपल स्ट्राक्टहरूको लागि `fmt::Debug` कार्यान्वयनको सिर्जना गर्न सहयोग पुर्‍याउन एक `DebugTuple` बिल्डर सिर्जना गर्दछ।
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// एक `DebugList` बिल्डर बनाउँदछ सूची जस्तै संरचनाहरूको लागि `fmt::Debug` कार्यान्वयनको निर्माणको साथ सहयोग पुर्‍याउन।
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// एक `DebugSet` बिल्डर सेट-जस्तो संरचनाहरूको लागि `fmt::Debug` कार्यान्वयनको सिर्जनाको साथ सहयोग गर्न डिजाइन गरिएको हो।
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// यो अधिक जटिल उदाहरणमा, हामी [`format_args!`] र `.debug_set()` प्रयोग हतियारहरूको एक सूची बनाउनको लागि:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// `DebugMap` बिल्डर बनाउँदछ नक्शा जस्तो संरचनाहरूको लागि `fmt::Debug` कार्यान्वयनको सिर्जना गर्न सहयोग पुर्‍याउन।
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// कोर ढाँचा traits को कार्यान्वयन

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // यदि चरलाई उम्कन आवश्यक छ भने, ब्याकलोग यति टाढा फ्लश गर्नुहोस् र लेख्नुहोस्, अन्यथा छोड्नुहोस्
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // वैकल्पिक झण्डा पहिले नै लोवरहेक्स द्वारा विशेष मानिन्छ-यसले ०x सँग उपसर्ग लिनु हुँदैन भनेर बुझाउँदछ।
        // हामी यसलाई शून्य विस्तार गर्ने कि नगर्ने कार्य गर्न प्रयोग गर्छौं, र त्यसपछि यो पूर्व शर्त बिना शर्त सेट गर्दछ।
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// विभिन्न कोर प्रकारहरूको लागि Display/Debug कार्यान्वयन

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // RefCell परस्पर उधारो लिइएको छ त्यसैले हामी यसको मान यहाँ हेर्न सक्दैनौं।
                // सट्टामा प्लेसहोल्डर देखाउनुहोस्।
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// यदि तपाइँ यहाँ परिक्षणको हुने आशा गर्नुहुन्छ भने core/tests/fmt.rs फाईलमा हेर्नुहोस्, यो सबै rt::Piece संरचनाहरू सिर्जना गर्नु भन्दा धेरै सजिलो छ।
//
// त्यहाँ ZTcrate0Z को आवंटनमा परीक्षणहरू छन्, जसको लागि बाँडफाँड आवश्यक छ।