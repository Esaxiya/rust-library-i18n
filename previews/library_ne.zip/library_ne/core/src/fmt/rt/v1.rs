//! यो ifmt द्वारा प्रयोग गरिएको एक आन्तरिक मोड्युल हो!रनटाइमयी संरचनाहरू स्थैतिक एर्रेमा पहिले प्रिम्पोम्पाईल ढाँचा स्ट्रिंग गर्न उत्सर्जित हुन्छ।
//!
//! यी परिभाषाहरू उनीहरूको `ct` समकक्षसँग मिल्दोजुल्दो छ, तर भिन्न छन् जुन यिनीहरूलाई स्थिर रूपमा विनियोजित गर्न सकिन्छ र रनटाइमका लागि थोरै अनुकूलित हुन्छन्।
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// सम्भावित पign्क्तिबद्धहरू जुन फर्म्याटि dire निर्देशको भागको रूपमा अनुरोध गर्न सकिन्छ।
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// सूचित गर्नुहोस् कि सामग्री बाँया-पigned्क्तिबद्ध हुनुपर्छ।
    Left,
    /// सामग्री सही-पigned्क्तिबद्ध हुनु पर्छ भनेर संकेत।
    Right,
    /// सामग्री केन्द्र-पigned्क्तिबद्ध हुनु पर्छ भनेर संकेत।
    Center,
    /// कुनै प al्क्तिबद्धता अनुरोध गरिएको थिएन।
    Unknown,
}

/// [width](https://doc.rust-lang.org/std/fmt/#width) र [precision](https://doc.rust-lang.org/std/fmt/#precision) निर्दिष्टकर्ता द्वारा प्रयोग गरीयो।
#[derive(Copy, Clone)]
pub enum Count {
    /// शाब्दिक संख्याको साथ निर्दिष्ट, मान भण्डारण गर्दछ
    Is(usize),
    /// `$` र `*` सिन्ट्याक्स प्रयोग गरेर निर्दिष्ट, `args` मा अनुक्रमणिका स्टोर गर्दछ
    Param(usize),
    /// तोकिएको छैन
    Implied,
}