//! मेमोरीसँग काम गर्ने आधारभूत कार्यहरू।
//!
//! यस मोड्युलले प्रकारको साइज र एलाइनमेन्ट क्वेरी गर्न, मेमोरीलाई आरम्भ गर्न र हेरफेर गर्नका लागि कार्यहरू समावेश गर्दछ।
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// स्वामित्व लिन्छ र "forgets" मानको **यसको डिस्ट्रक्टर बिना** चलाएको बिना लिन्छ।
///
/// कुनै पनि संसाधनहरू मान प्रबन्धन गर्दछ, जस्तै हिप मेमोरी वा फाइल ह्यान्डल, सँधै एक पहुँचयोग्य राज्यमा ढिलाइ हुनेछ।जे होस्, यो ग्यारेन्टी छैन कि यस स्मृति को सूचक वैध रहनेछ।
///
/// * यदि तपाईं मेमोरी लीक गर्न चाहनुहुन्छ भने, [`Box::leak`] हेर्नुहोस्।
/// * यदि तपाईं मेमोरीमा कच्चा सूचक प्राप्त गर्न चाहानुहुन्छ, [`Box::into_raw`] हेर्नुहोस्।
/// * यदि तपाईं मानको राम्रोसँग डिस्पोजेस गर्न चाहनुहुन्छ भने, यसको डिस्ट्रक्टर चलाउँदै, [`mem::drop`] हेर्नुहोस्।
///
/// # Safety
///
/// `forget` `unsafe` को रूपमा चिन्ह लगाईएको छैन, किनकि Rust को सुरक्षा ग्यारेन्टीमा ग्यारेन्टी समावेश छैन जुन विध्वंसकहरू सँधै चल्नेछन्।
/// उदाहरण को लागी, एक कार्यक्रम [`Rc`][rc] को उपयोग गरी एक संदर्भ चक्र सिर्जना गर्न सक्दछ, वा [`process::exit`][exit] कल गर्न विना विक्रेताहरु बाहिर निस्कन को लागी।
/// यसैले, `mem::forget` लाई सुरक्षित कोडबाट अनुमति दिंदा Rust को सुरक्षा ग्यारेन्टीहरू मौलिक रूपमा परिवर्तन हुँदैन।
///
/// त्योले भने, मेमोरी वा I/O वस्तुहरू जस्ता स्रोतहरू चुहावट सामान्यतया अवांछनीय हो।
/// FFI वा असुरक्षित कोड को लागी केहि विशेष प्रयोग मामिलाहरुमा आवश्यकता आउँछ, तर पनि, [`ManuallyDrop`] सामान्यतया प्राथमिकता छ।
///
/// किनभने मान बिर्सनुको लागि अनुमति छ, कुनै `unsafe` कोड तपाईंले लेख्नु भएको यो सम्भावनाको लागि अनुमति दिनुपर्दछ।तपाईं मान फिर्ता गर्न सक्नुहुन्न र आशा राख्नुहुन्छ कि कलरले आवश्यक मानको विनाश चलाउनेछ।
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// `mem::forget` को प्रमाणिक सुरक्षित प्रयोग `Drop` trait द्वारा लागू गरिएको मानको डिस्ट्रक्टरलाई रोक्नु हो।उदाहरण को लागी, यो एक `File` लीक हुनेछ, अर्थात्
/// भ्यारीएबलले लिएको खाली ठाउँ पुन: दावी गर्नुहोस् तर अन्तर्निहित प्रणाली संसाधन कहिल्यै बन्द नगर्नुहोस्:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// यो उपयोगी छ जब अन्तर्निहित स्रोतको स्वामित्व पहिले Rust बाहिरको कोडमा हस्तान्तरण गरिएको थियो, उदाहरणका लागि सी कोडमा कच्चा फाइल वर्णनकर्ता स्थानान्तरण गरेर।
///
/// # `ManuallyDrop` सँग सम्बन्ध
///
/// जबकि `mem::forget`*मेमोरी* स्वामित्व हस्तान्तरण गर्न पनि प्रयोग गर्न सकिन्छ, त्यसो गर्दा त्रुटि प्रवण हुन्छ।
/// [`ManuallyDrop`] यसको सट्टामा प्रयोग गर्नुपर्दछ।उदाहरणको लागि, यो कोडलाई विचार गर्नुहोस्:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // `v` को सामग्री प्रयोग गरेर `String` निर्माण गर्नुहोस्
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // लीक `v` किनभने यसको मेमोरी अब `s` द्वारा प्रबन्ध गरिएको छ
/// mem::forget(v);  // ERROR, v अमान्य छ र प्रकार्यमा पास गर्नु हुँदैन
/// assert_eq!(s, "Az");
/// // `s` स्पष्ट रूपमा ड्रप गरिएको छ र यसको मेमोरी deallocated।
/// ```
///
/// माथिको उदाहरणका साथ त्यहाँ दुई मुद्दाहरू छन्:
///
/// * यदि अधिक कोड `String` को निर्माण र `mem::forget()` को आह्वानको बीचमा थप गरिएको छ भने, यो भित्रको panic ले डबल फ्री पैदा गर्दछ किनकि उही मेमोरी `v` र `s` दुबै द्वारा ह्यान्डल गरिएको छ।
/// * `v.as_mut_ptr()` कल गरेर र `s` मा डाटाको स्वामित्व प्रसारित गरेपछि, `v` मान अवैध छ।
/// एक मान `mem::forget` मा सारियो भने पनि (यसले यसलाई निरीक्षण गर्दैन), केहि प्रकारहरूको उनीहरूको मानहरूमा कडा आवश्यकताहरू हुन्छन् जुन उनीहरूलाई झण्डा बनाउँदा वा अवैध बनाउँदछ वा अब स्वामित्वमा छैन।
/// कुनै पनि हिसाबले अवैध मानहरू प्रयोग गर्दा, तिनीहरूलाई फर्काउने वा तिनीहरूलाई प्रकार्यहरूबाट फर्काउँदा, अपरिभाषित व्यवहारको गठन गर्दछ र कम्पाइलरले गरेका अनुमानहरू भ break्ग गर्न सक्दछ।
///
/// `ManuallyDrop` मा स्विच गर्दा दुबै मुद्दालाई वेवास्ता गर्दछ:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // हामीले यसको कच्चा भागहरूमा `v` डिसेस्सेम्बल गर्नुभन्दा पहिले यो झर्ने छैन भनेर निश्चित गर्नुहोस्!
/////
/// let mut v = ManuallyDrop::new(v);
/// // अब `v` अलग गर्नुहोस्।यी अपरेशनहरू panic गर्न सक्दैन, त्यसैले त्यहाँ चुहावट हुन सक्दैन।
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // अन्तमा, एक `String` निर्माण गर्नुहोस्।
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` स्पष्ट रूपमा ड्रप गरिएको छ र यसको मेमोरी deallocated।
/// ```
///
/// `ManuallyDrop` मजबुत रूपमा डबल फ्री रोक्छ किनभने हामी केहि अक्षम गर्नु अघि `v` डिस्ट्रक्टर अक्षम गर्दछ।
/// `mem::forget()` यसलाई अनुमति दिदैन किनकि यसले यसको तर्क खान्छ, हामीलाई `v` बाट चाहिएको कुनै पनि चीजहरू निकाले पछि मात्र कल गर्न बाध्य पार्छ।
/// `ManuallyDrop` को निर्माण र स्ट्रि building निर्माण गर्ने बिच z zpanpanic0Z पेश गरिएको भए पनि, जुन कोडमा देखाइएको जस्तो हुन सक्दैन) यसले लीक हुने छ र डबल नि: शुल्क हुने छैन।
/// अर्को शब्दमा, `ManuallyDrop` ड्रपको छेउमा एरिंग गर्नुको सट्टा लीकको छेउमा एरर्स गर्दछ।
///
/// साथै, `ManuallyDrop` "touch" `v` मा `s` मा स्वामित्व हस्तान्तरण पछि रोक्छ-`v` सँग अन्तर्क्रियाको अन्तिम चरण यसको डिस्ट्रक्टर बिना चलाउनको लागि यसलाई बेवास्ता गर्दछ।
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// [`forget`] लाई मन पराउछ, तर असफल मान पनि स्वीकार गर्दछ।
///
/// यो प्रकार्य केवल एक शिम मात्र हटाउन को लागी जब `unsized_locals` सुविधा स्थिर हुन्छ।
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// बाइट्समा एक प्रकारको आकार फर्काउँछ।
///
/// अधिक विशेष रूपमा, यो प type्क्तिबद्ध प्याडि including सहित वस्तुको प्रकारको साथ एरेमा क्रमबद्ध तत्वहरू बीचको बाइट्समा अफसेट हो।
///
/// यसैले, कुनै पनि प्रकारको `T` र लम्बाई `n` को लागी, `[T; n]` को आकार `n * size_of::<T>()` छ।
///
/// सामान्यतया, कुनै प्रकारको आकार कम्पाइलेसन भर स्थिर हुँदैन, तर विशिष्ट प्रकारहरू जस्तै आदिमहरू हुन्।
///
/// निम्न तालिकाले आदिमहरूको लागि आकार दिन्छ।
///
/// प्रकार |आकार_को: :\<Type>()
/// ---- | ---------------
/// () |० bool |१ u8 |१ u16 |२ u32 |X u64 |8 u128 |१ X i8 |१ i16 |2 i32 |X i64 |I आई १२8 |१ X f32 |X f64 |Char चर |।
///
/// यसबाहेक, `usize` र `isize` सँग समान आकार छ।
///
/// प्रकारहरू `*const T`, `&T`, `Box<T>`, `Option<&T>`, र `Option<Box<T>>` सबैको आकार एक समान छ।
/// यदि `T` आकार छ, ती सबै प्रकारको `usize` जस्तै आकार छ।
///
/// सूचकको म्युटेबिलिटीले यसको आकार परिवर्तन गर्दैन।त्यस्तै, `&T` र `&mut T` सँग समान आकार छ।
/// त्यस्तै `*const T` र `* mut T` को लागी।
///
/// # `#[repr(C)]` वस्तुहरूको आकार
///
/// आईटमहरूको लागि `C` प्रतिनिधित्वको एक परिभाषित लेआउट छ।
/// यो रूपरेखा संग, आइटम को आकार पनि स्थिर छ जब सम्म सबै क्षेत्रहरु को एक स्थिर आकार छ।
///
/// ## स्ट्रोकको आकार
///
/// `structs` को लागि, आकार निम्न एल्गोरिथ्मद्वारा निर्धारित गरिन्छ।
///
/// संरचना आदेश मा प्रत्येक क्षेत्र को लागी घोषणा आदेश द्वारा आदेश:
///
/// 1. क्षेत्र को आकार जोड्नुहोस्।
/// 2. अर्को फिल्डको [alignment] को नजिकको बहुलाई वर्तमान आकार राउन्ड गर्नुहोस्।
///
/// अन्तमा, स्ट्रक्सको आकारलाई यसको [alignment] को नजिकको बहुलाई गोल गर्नुहोस्।
/// संरचनाको प al्क्तिबद्धता सबै यसका क्षेत्रहरू सबै भन्दा ठूलो पign्क्तिबद्धता हो;यो `repr(align(N))` को उपयोगको साथ परिवर्तन गर्न सकिन्छ।
///
/// `C` भन्दा विपरीत, शून्य आकारका स्ट्रिक्स आकारमा एक बाइट सम्म राउन्ड हुँदैनन्।
///
/// ## Enums को आकार
///
/// विभेदक बाहेक अरू कुनै डेटा नराख्ने एनिमहरूको प्लेटफर्ममा सी एम्म्स जत्तिकै आकार हुन्छन् जसका लागि उनीहरूले कम्पाइल गरेका छन्।
///
/// ## युनियनहरूको आकार
///
/// एक संघको आकार यसको ठूलो क्षेत्रको आकार हो।
///
/// `C` भन्दा विपरीत, शून्य आकारका युनियनहरू साइजमा एक बाइट सम्म गोलाकार हुँदैनन्।
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // केही आदिम
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // केहि एर्रेहरू
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // सूचक आकार समानता
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// `#[repr(C)]` प्रयोग गर्दै।
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // पहिलो फिल्डको साइज १ हो, त्यसैले साइजमा १ थप्नुहोस्।आकार १ हो।
/// // दोस्रो फिल्डको पign्क्तिबद्धता २ हो, त्यसैले प्याडि forको लागि आकारमा १ थप्नुहोस्।आकार २ हो।
/// // दोस्रो फिल्डको साइज २ हो, त्यसैले साइजमा २ थप्नुहोस्।आकार is हो।
/// // तेस्रो फिल्डको पign्क्तिबद्धता १ हो, त्यसैले प्याडिंगको लागि आकारमा ० थप्नुहोस्।आकार is हो।
/// // तेस्रो फिल्डको साइज १ हो, त्यसैले साइजमा १ थप्नुहोस्।आकार is हो।
/// // अन्तमा, संरचनाको पign्क्तिबद्धता २ हो (किनकि यसको क्षेत्रहरू बीच सबै भन्दा ठूलो पign्क्तिबद्धता २ हो), त्यसैले प्याडि forको लागि आकारमा १ थप्नुहोस्।
/// // आकार is हो।
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // टपल स्टर्क्टले उहि नियमहरू पालना गर्दछ।
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // नोट गर्नुहोस् कि फिल्डहरू क्रमबद्ध गर्दा साइज कम हुन सक्छ।
/// // हामी दुबै प्याडिंग बाइटहरू हटाउन सक्छौं `second` अघि `third` राखेर।
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // संघ आकार सबैभन्दा ठूलो क्षेत्र को आकार हो।
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// बाइट्समा पोइन्ट-टु valueको मान फर्काउँछ।
///
/// यो सामान्यतया `size_of::<T>()` जस्तै हो।
/// जहाँसम्म, जब `T` * का कुनै स्थिर रूपमा ज्ञात आकार हुँदैन, उदाहरणका लागि, टुक्रा [`[T]`][slice] वा [trait object], तब गतिशील रूपमा ज्ञात आकार प्राप्त गर्न `size_of_val` प्रयोग गर्न सकिन्छ।
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // सुरक्षा: `val` एक सन्दर्भ हो, त्यसैले यो एक वैध कच्चा सूचक हो
    unsafe { intrinsics::size_of_val(val) }
}

/// बाइट्समा पोइन्ट-टु valueको मान फर्काउँछ।
///
/// यो सामान्यतया `size_of::<T>()` जस्तै हो।जहाँसम्म, जब `T` * का कुनै स्थिर रूपमा ज्ञात आकार हुँदैन, उदाहरणका लागि, टुक्रा [`[T]`][slice] वा [trait object], तब `size_of_val_raw` गतिशील-ज्ञात आकार प्राप्त गर्न प्रयोग गर्न सकिन्छ।
///
/// # Safety
///
/// यो प्रकार्य केवल कल गर्न सुरक्षित छ यदि निम्न सर्तहरू राख्छन्:
///
/// - यदि `T` `Sized` हो, यो प्रकार्य कल गर्न सुरक्षित छ।
/// - यदि `T` को असत्यापित पूंछ हो:
///     - एक [slice], त्यसपछि टुक्राको पुच्छरको लम्बाइ एक शुरुवात इन्टिजर हुनुपर्दछ, र *सम्पूर्ण मान* को आकार (गतिशील टेल लम्बाई + स्थिर आकारको उपसर्ग) `isize` मा फिट हुनुपर्दछ।
///     - एक [trait object], तब सूचकको vtable भाग एक unsizing जबरजस्ती द्वारा प्राप्त एक मान्य vtable इंगित गर्नु पर्छ, र *सम्पूर्ण मान* को आकार (गतिशील टेल लम्बाई + स्थिर आकारको उपसर्ग) `isize` मा फिट हुनु पर्छ।
///
///     - एक (unstable) [extern type], तब यो प्रकार्य जहिले पनि कल गर्न सुरक्षित हुन्छ, तर panic वा अन्यथा गलत मान फिर्ता गर्न सक्दछ, बाह्य प्रकारको रूपरेखा ज्ञात छैन।
///     यो [`size_of_val`] X को समान व्यवहार हो बाह्य प्रकारको पुच्छरको साथ एक प्रकारको सन्दर्भमा।
///     - अन्यथा, यस कार्यलाई कल गर्न यसलाई रूढिवादी रूपमा अनुमति छैन।
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // सुरक्षा: कलरले एक मान्य कच्चा सूचक प्रदान गर्नु पर्छ
    unsafe { intrinsics::size_of_val(val) }
}

/// [ABI] एक प्रकारको न्यूनतम पign्क्तिबद्धता फर्काउँछ।
///
/// प्रकारको `T` को मानको प्रत्येक संदर्भ यस संख्याको एक गुणक हुनुपर्दछ।
///
/// यो स्ट्रक्चर फाँटहरूका लागि प्रयोग गरिएको पign्क्तिबद्धता हो।यो मनपर्दो पign्क्तिबद्धता भन्दा सानो हुन सक्छ।
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// [ABI] फर्काउँछ न्यूनतम पign्क्तिबद्धता मानको प्रकारको जुन `val` देखाउदछ।
///
/// प्रकारको `T` को मानको प्रत्येक संदर्भ यस संख्याको एक गुणक हुनुपर्दछ।
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // सुरक्षा: भ्याल एक सन्दर्भ हो, त्यसैले यो एक वैध कच्चा सूचक हो
    unsafe { intrinsics::min_align_of_val(val) }
}

/// [ABI] एक प्रकारको न्यूनतम पign्क्तिबद्धता फर्काउँछ।
///
/// प्रकारको `T` को मानको प्रत्येक संदर्भ यस संख्याको एक गुणक हुनुपर्दछ।
///
/// यो स्ट्रक्चर फाँटहरूका लागि प्रयोग गरिएको पign्क्तिबद्धता हो।यो मनपर्दो पign्क्तिबद्धता भन्दा सानो हुन सक्छ।
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// [ABI] फर्काउँछ न्यूनतम पign्क्तिबद्धता मानको प्रकारको जुन `val` देखाउदछ।
///
/// प्रकारको `T` को मानको प्रत्येक संदर्भ यस संख्याको एक गुणक हुनुपर्दछ।
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // सुरक्षा: भ्याल एक सन्दर्भ हो, त्यसैले यो एक वैध कच्चा सूचक हो
    unsafe { intrinsics::min_align_of_val(val) }
}

/// [ABI] फर्काउँछ न्यूनतम पign्क्तिबद्धता मानको प्रकारको जुन `val` देखाउदछ।
///
/// प्रकारको `T` को मानको प्रत्येक संदर्भ यस संख्याको एक गुणक हुनुपर्दछ।
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// यो प्रकार्य केवल कल गर्न सुरक्षित छ यदि निम्न सर्तहरू राख्छन्:
///
/// - यदि `T` `Sized` हो, यो प्रकार्य कल गर्न सुरक्षित छ।
/// - यदि `T` को असत्यापित पूंछ हो:
///     - एक [slice], त्यसपछि टुक्राको पुच्छरको लम्बाइ एक शुरुवात इन्टिजर हुनुपर्दछ, र *सम्पूर्ण मान* को आकार (गतिशील टेल लम्बाई + स्थिर आकारको उपसर्ग) `isize` मा फिट हुनुपर्दछ।
///     - एक [trait object], तब सूचकको vtable भाग एक unsizing जबरजस्ती द्वारा प्राप्त एक मान्य vtable इंगित गर्नु पर्छ, र *सम्पूर्ण मान* को आकार (गतिशील टेल लम्बाई + स्थिर आकारको उपसर्ग) `isize` मा फिट हुनु पर्छ।
///
///     - एक (unstable) [extern type], तब यो प्रकार्य जहिले पनि कल गर्न सुरक्षित हुन्छ, तर panic वा अन्यथा गलत मान फिर्ता गर्न सक्दछ, बाह्य प्रकारको रूपरेखा ज्ञात छैन।
///     यो [`align_of_val`] X को समान व्यवहार हो बाह्य प्रकारको पुच्छरको साथ एक प्रकारको सन्दर्भमा।
///     - अन्यथा, यस कार्यलाई कल गर्न यसलाई रूढिवादी रूपमा अनुमति छैन।
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // सुरक्षा: कलरले एक मान्य कच्चा सूचक प्रदान गर्नु पर्छ
    unsafe { intrinsics::min_align_of_val(val) }
}

/// `T` प्रकारको मानको ड्रप गर्दछ भने `true` फर्काउँछ।
///
/// यो विशुद्ध रुपले अप्टिमाइजेसन संकेत हो, र रूढीवादी रूपमा कार्यान्वयन हुन सक्छ:
/// यसले त्यस्ता प्रकारका लागि `true` फिर्ता गर्न सक्दछ जुन वास्तवमा छोड्नु पर्दैन।
/// जस्तो कि सधैं फिर्ता `true` यस प्रकार्यको वैध कार्यान्वयन हुनेछ।जहाँ सम्म यो समारोह वास्तवमा `false` फिर्ता, तब तपाईं निश्चित ड्रपिंग `T` कुनै साइड प्रभाव छैन हुन सक्छ।
///
/// स level्कलनहरू जस्ता चीजहरूको तल्लो स्तरको कार्यान्वयन, जसले म्यानुअल रूपमा उनीहरूको डाटा छोड्नुपर्दछ, यस प्रकार्य प्रयोग गर्नुपर्दछ अनावश्यक रूपमा उनीहरूको सबै सामग्रीहरू नष्ट गर्न खोज्नु हुँदैन।
///
/// यो रिलीज निर्माणमा भिन्नता नहुन सक्छ (जहाँ कुनै साइड-इफेक्ट नभएको लूप सजिलैसँग पत्ता लगाउन सकिन्छ र हटाइन्छ), तर डिबग बिल्डहरूको लागि प्राय: ठूलो जीत हो।
///
/// नोट गर्नुहोस् कि [`drop_in_place`] ले यो चेक पहिले नै प्रदर्शन गर्दछ, त्यसैले यदि तपाईको कार्यभारलाई [`drop_in_place`] कलको केही साना संख्यामा कम गर्न सकिन्छ, यसको प्रयोग अनावश्यक छ।
/// विशेष नोटमा कि तपाईं [`drop_in_place`] एउटा टुक्रा गर्न सक्नुहुन्छ, र यसले एकल need_DP सबै मानहरूको लागि जाँच गर्दछ।
///
/// Vec जस्तै प्रकारहरू केवल `drop_in_place(&mut self[..])` स्पष्ट रूपमा `needs_drop` प्रयोग नगरी।
/// [`HashMap`] जस्तै प्रकारहरू, अर्कोतर्फ, एक पटकमा मानहरू ड्रप गर्नुपर्दछ र यो एपीआई प्रयोग गर्नुपर्दछ।
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// यहाँ कसरी संग्रहले `needs_drop` को उपयोग गर्न सक्दछ को उदाहरण छ:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // डाटा छोड्नुहोस्
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// X-X प्रकारको मानलाई सबै शून्य बाइट-ढाँचाले प्रतिनिधित्व गर्छ।
///
/// यसको मतलब यो हो कि, उदाहरणका लागि, `(u8, u16)` मा प्याडिंग बाइट शून्य छैन।
///
/// कुनै ग्यारेन्टी छैन कि सबै-शून्य बाइट-ढाँचाले केहि `T` X का मान्य मान प्रतिनिधित्व गर्दछ।
/// उदाहरण को लागी, सबै शून्य बाइट-ढाँचा संदर्भ प्रकार (`&T`, `&mut T`) र प्रकार्य सूचकहरूको लागि मान्य मान होईन।
/// त्यस्ता प्रकारहरूमा `zeroed` प्रयोग गर्नाले तत्काल [undefined behavior][ub] निम्त्याउँदछ किनभने [the Rust compiler assumes][inv] कि त्यहाँ सधैं एक वैध मान हुन्छ कि यसलाई आरम्भिक मान्दछ।
///
///
/// यो [`MaybeUninit::zeroed().assume_init()`][zeroed] को जस्तै प्रभाव छ।
/// यो कहिलेकाँही एफएफआई को लागी उपयोगी छ, तर सामान्यतया टाढा रहनु पर्छ।
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// यो प्रकार्यको सहि उपयोग: शून्यको साथ पूर्णा .्क आरम्भ गर्दै।
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *गलत* यस प्रकार्यको प्रयोग: शून्यको साथ सन्दर्भ आरम्भ गर्दै।
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // अपरिभाषित व्यवहार!
/// let _y: fn() = unsafe { mem::zeroed() }; // र फेरि!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // सुरक्षा: कलरले ग्यारेन्टी गर्नै पर्दछ कि एक शून्य मान `T` को लागी मान्य छ।
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// बाइपास गर्दछ Rust को सामान्य मेमोरी-इनिसियलाइजेशन जाँच प्रकार `T` को मान उत्पादन गर्ने बहाना गरेर, केही पनि नगर्दै।
///
/// **यो प्रकार्य निषेध गरिएको छ।** यसको सट्टा [`MaybeUninit<T>`] प्रयोग गर्नुहोस्।
///
/// मूल्यह्रासको कारण यो हो कि समारोह मूल रूपमा सहि रूपमा प्रयोग गर्न सकिदैन: यसले [`MaybeUninit::uninit().assume_init()`][uninit] को जस्तै प्रभाव पार्छ।
///
/// [`assume_init` documentation][assume_init] व्याख्या गरेझैं [the Rust compiler assumes][inv] मानहरू सही रूपमा आरम्भ भयो।
/// परिणामको रूपमा, कल गर्दै
/// `mem::uninitialized::<bool>()` `bool` फिर्ताको लागि तत्काल अपरिभाषित व्यवहारको कारण गर्दछ जुन कि त निश्चित रूपमा `true` वा `false` हैन।
/// सबैभन्दा खराब कुरा, साँच्चिकै इनिटिटलाइज गरिएको मेमोरी जस्तो यहाँ फर्कन्छ विशेषको लागि कम्पाइलरले यो जान्दछ कि यसमा निश्चित मूल्य छैन।
/// यसले यसलाई एक अपरिभाषित व्यवहार बनाउँदछ एक भ्यारीएबलमा इनिटिटिअलाइज्ड डाटा राख्न चाहे त्यो भेरिएबलको इन्टिजर प्रकार छ।
/// (ध्यान दिनुहोस् कि अनावश्यक इन्टिजरको वरपरको नियम अझ सम्म अन्तिम रूप छैन, तर तिनीहरू नहुनुसम्म उनीहरूबाट टाढा रहन सल्लाह दिइन्छ।)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // सुरक्षा: कलरले ग्यारेन्टी गर्नु पर्छ कि एक एकाईकरण गरिएको मान `T` को लागी मान्य छ।
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// कुनै एक लाई डिनाइटाइज नगरिकन, दुई म्यूटेबल स्थानहरूमा मानहरू स्वैप गर्दछ।
///
/// * यदि तपाईं पूर्वनिर्धारित वा डमी मानको साथ बदल्न चाहनुहुन्छ भने [`take`] हेर्नुहोस्।
/// * यदि तपाईं पारित मानको साथ स्वैप गर्न चाहनुहुन्छ भने, पुरानो मान फिर्ता गर्दै, [`replace`] हेर्नुहोस्।
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // सुरक्षा: कच्चा सूचकहरू सबैलाई सन्तोषजनक सुरक्षित पारस्परिक सन्दर्भबाट सिर्जना गरिएको हो
    // `ptr::swap_nonoverlapping_one` मा अवरोधहरू
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// `dest` लाई `T` को पूर्वनिर्धारित मानको साथ बदल्छ, अघिल्लो `dest` मान फर्काउँछ।
///
/// * यदि तपाईं दुई भ्यारीएबलको मान बदल्न चाहनुहुन्छ भने [`swap`] हेर्नुहोस्।
/// * यदि तपाईं पूर्वनिर्धारित मानको सट्टामा पारित मानसँग बदल्न चाहनुहुन्छ भने [`replace`] हेर्नुहोस्।
///
/// # Examples
///
/// एक साधारण उदाहरण:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` "empty" मानको साथ बदले संरचना क्षेत्रको स्वामित्व लिन यसले अनुमति दिन्छ।
/// `take` बिना तपाईं यी जस्तो मुद्दामा चलाउन सक्नुहुन्छ:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// नोट गर्नुहोस् कि `T` ले आवश्यक रूपमा [`Clone`] कार्यान्वयन गर्दैन, त्यसैले यसले क्लोन गर्न र `self.buf` रिसेट पनि गर्न सक्दैन।
/// तर `take` यो `self` बाट `self.buf` को मूल मान अलग गर्न प्रयोग गर्न सकिन्छ, यसलाई फिर्ता गर्न अनुमति दिदै:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// `src` सन्दर्भ `dest` मा सार्दछ, अघिल्लो `dest` मान फर्काउँदै।
///
/// न त मान छोडियो।
///
/// * यदि तपाईं दुई भ्यारीएबलको मान बदल्न चाहनुहुन्छ भने [`swap`] हेर्नुहोस्।
/// * यदि तपाईं पूर्वनिर्धारित मानको साथ बदल्न चाहनुहुन्छ भने [`take`] हेर्नुहोस्।
///
/// # Examples
///
/// एक साधारण उदाहरण:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` स्ट्रक्चर क्षेत्रको उपभोगलाई अर्को मानको साथ बदल्न अनुमति दिन्छ।
/// `replace` बिना तपाईं यी जस्तो मुद्दामा चलाउन सक्नुहुन्छ:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// नोट गर्नुहोस् कि `T` ले [`Clone`] आवश्यक रूपमा कार्यान्वयन गर्दैन, त्यसैले हामी चाल बाट बच्न `self.buf[i]` क्लोन पनि गर्न सक्दैनौं।
/// तर `replace` `self` बाट त्यो सूचकांकमा मूल मान अलग गर्न प्रयोग गर्न सकिन्छ, यसलाई फिर्ता गर्न अनुमति दिदै:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // सुरक्षा: हामी `dest` बाट पढ्छौं, तर यसमा `src` प्रत्यक्ष रूपमा लेख्छौं,
    // जस्तै कि पुरानो मान डुप्लिकेट छैन।
    // केहि पनि छोडियो र यहाँ केहि पनि panic गर्न सक्दैन।
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// मानको डिस्पोजेस।
///
/// यो [`Drop`][drop] को कार्यान्वयन कल गरेर यो गर्छ।
///
/// यसले `Copy` कार्यान्वयन गर्ने प्रकारहरूको लागि प्रभावकारी रूपमा केही गर्दैन
/// integers.
/// त्यस्ता मानहरू प्रतिलिपि गरीयो र _then_ प्रकार्यमा सारियो, त्यसैले मान यस प्रकार्य कल पछि पनी रहिरहन्छ।
///
///
/// यो प्रकार्य जादू छैन;यो शाब्दिक रूपमा परिभाषित छ
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// किनभने `_x` प्रकार्यमा सारियो, यो कार्य फिर्ताको पहिले स्वचालित रूपमा झर्छ।
///
/// [drop]: Drop
///
/// # Examples
///
/// आधारभूत उपयोग:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // स्पष्ट रूपमा vector ड्रप गर्नुहोस्
/// ```
///
/// [`RefCell`] रनटाइममा उधार नियम लागू गर्दछ, `drop` एक [`RefCell`] उधारो जारी गर्न सक्नुहुन्छ:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // यस स्लटमा म्यूटेबल orrowण त्याग्नुहोस्
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// पूर्णांकहरू र [`Copy`] कार्यान्वयन गर्ने अन्य प्रकारहरू `drop` द्वारा अप्रभावित हुन्छन्।
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // `x` को एक प्रतिलिपि सारियो र ड्रप गरियो
/// drop(y); // `y` को एक प्रतिलिपि सारियो र ड्रप गरियो
///
/// println!("x: {}, y: {}", x, y.0); // अहिले पनि उपलब्ध छ
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// `src` लाई `&U` प्रकारको रूपमा परिभाषित गर्छ, र त्यसपछि समावेश गरिएको मानलाई नलगाई `src` पढ्छ।
///
/// यो प्रकार्यले असुरक्षित रूपमा सूचक `src` लाई [`size_of::<U>`][size_of] बाइट्स को लागी `&T` लाई `&U` लाई ट्रान्समिट गरी `&U` पढेर मान्य गर्दछ (यो बाहेक यो सही तरिकाले गरिएको छ जब `&U` भन्दा कडा पign्क्तिबद्ध आवश्यकताहरू बनाउँदछ भने बाहेक)।
/// यसले असुरक्षित रूपमा `src` बाहिर जानेको सट्टामा निहित मूल्यको प्रतिलिपि पनि सिर्जना गर्दछ।
///
/// यो कम्पाईल समय त्रुटि होइन यदि `T` र `U` का भिन्न आकारहरू छन्, तर यो अत्यधिक रूपमा यो प्रकार्यलाई निम्त्याउन प्रोत्साहित गरिएको छ जहाँ `T` र `U` समान आकारका छन्।यदि `U` `T` भन्दा ठूलो छ भने यो प्रकार्य [undefined behavior][ub] ट्रिगर गर्दछ।
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // 'foo_array' बाट डाटा प्रतिलिपि गर्नुहोस् र यसलाई 'Foo' को रूपमा व्यवहार गर्नुहोस्
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // प्रतिलिपि गरिएको डाटा परिमार्जन गर्नुहोस्
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // 'foo_array' को सामग्रीहरू परिवर्तन हुनुहुन्न
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // यदि U सँग उच्च पign्क्तिबद्धता आवश्यक छ भने, src उचित रूपमा पigned्क्तिबद्ध हुन सक्दैन।
    if align_of::<U>() > align_of::<T>() {
        // सुरक्षा: `src` एक संदर्भ हो जुन पठनको लागि मान्य हुने ग्यारेन्टी गरिएको छ।
        // कलरले ग्यारेन्टी गर्नु पर्छ कि वास्तविक ट्रान्समासन सुरक्षित छ।
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // सुरक्षा: `src` एक संदर्भ हो जुन पठनको लागि मान्य हुने ग्यारेन्टी गरिएको छ।
        // हामीले भर्खरै जाँच्यौं कि `src as *const U` सही तरिकाले पigned्क्तिबद्ध गरिएको थियो।
        // कलरले ग्यारेन्टी गर्नु पर्छ कि वास्तविक ट्रान्समासन सुरक्षित छ।
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// अस्पष्ट प्रकारले एनमको विभेद प्रतिनिधित्व गर्दछ।
///
/// अधिक जानकारीको लागि यस मोड्युलमा [`discriminant`] प्रकार्य हेर्नुहोस्।
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. यी trait कार्यान्वयनहरू प्राप्त गर्न सकिदैन किनकि हामी T मा कुनै सीमानाहरू चाहँदैनौं।

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// `v` मा एनम प्रकारलाई अद्वितीय रूपमा पहिचान गर्न मान फर्काउँछ।
///
/// यदि `T` एक ईनम हैन भने, यो प्रकार्य कल गर्दा अपरिभाषित व्यवहारको परिणाम दिँदैन, तर फिर्ता मान अनिर्दिष्ट छ।
///
///
/// # Stability
///
/// एनम परिभाषा परिवर्तन भएमा एनम भिन्नताको भेदभाव हुन सक्छ।
/// केहि फरकको भेदभाव समान संकलकको साथ संकलनको बिच बदलिने छैन।
///
/// # Examples
///
/// वास्तविक डेटालाई बेवास्ता गर्ने बेलामा डाटा बोक्ने एम्म्सलाई तुलना गर्न यो प्रयोग गर्न सकिन्छ:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// एनम प्रकार `T` मा भेरियन्टहरूको संख्या फर्काउँछ।
///
/// यदि `T` एक ईनम हैन भने, यो प्रकार्य कल गर्दा अपरिभाषित व्यवहारको परिणाम दिँदैन, तर फिर्ता मान अनिर्दिष्ट छ।
/// त्यस्तै, यदि `T` `usize::MAX` भन्दा अधिक भेरियन्ट्सको साथ एक एनम भने रिटर्न मान अनिर्दिष्ट छ।
/// निर्बाध रूपहरु गणना हुनेछ।
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}