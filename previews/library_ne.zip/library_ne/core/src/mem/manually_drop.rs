use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// कम्पाइलर स्वचालित रूपमा कल from T` को विनाशक कल गर्नबाट रोक्नको लागि एउटा आवरण।
/// यो र्यापर ०-लागतको छ।
///
/// `ManuallyDrop<T>` `T` को रूपमा समान लेआउट अप्टिमाइजेसनको बिषय हो।
/// परिणामको रूपमा, यसले कम्पाइलरले यसको सामग्रीको बारेमा बनाएको धारणामा * कुनै प्रभाव पार्दैन।
/// उदाहरण को लागी `ManuallyDrop<&mut T>` X का साथ X0X शुरुवात अपरिभाषित व्यवहार हो।
/// यदि तपाईंलाई अनावश्यक डेटा ह्यान्डल गर्न आवश्यक छ भने, यसको सट्टामा [`MaybeUninit<T>`] प्रयोग गर्नुहोस्।
///
/// नोट गर्नुहोस् कि `ManuallyDrop<T>` भित्र मानको पहुँच सुरक्षित छ।
/// यसको मतलव `ManuallyDrop<T>` जसको सामग्री हटाइएको छ सार्वजनिक सुरक्षा एपीआई मार्फत उजागर गर्नु हुँदैन।
/// संगत रूपमा, `ManuallyDrop::drop` असुरक्षित छ।
///
/// # `ManuallyDrop` र ड्रप अर्डर।
///
/// Rust सँग राम्रोसँग परिभाषित [drop order] मानहरू छन्।
/// निश्चित गर्न कि फिल्डहरू वा स्थानीयहरू एक निश्चित क्रममा खसालिएका छन्, घोषणाहरू पुनःक्रमित गर्नुहोस् यस्तै बाहिरी ड्रप अर्डर सहि छ।
///
/// यो ड्रप अर्डर नियन्त्रण गर्न `ManuallyDrop` प्रयोग गर्न सम्भव छ, तर यसले असुरक्षित कोडको आवश्यक पर्दछ र अनवाइन्डिंगको उपस्थितिमा ठीकसँग गर्न गाह्रो हुन्छ।
///
///
/// उदाहरण को लागी, यदि तपाई यो निश्चित गर्न चाहानुहुन्छ कि अरुको पछि एक निर्दिष्ट फाँट झर्छ भने यसलाई संरचनाको अन्तिम फिल्ड बनाउनुहोस्।
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` `children` पछि छोडिनेछ।
///     // Rust ग्यारेन्टी गर्दछ कि क्षेत्र घोषणाको क्रममा छोडियो।
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// म्यानुअल रूपमा ड्रप गर्न मान र्‍याप गर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // तपाईं अझै पनि सुरक्षित रूपमा मूल्यमा अपरेट गर्न सक्नुहुन्छ
    /// assert_eq!(*x, "Hello");
    /// // तर `Drop` यहाँ चल्दैन
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// `ManuallyDrop` कन्टेनरबाट मान निकाल्छ।
    ///
    /// यसले मानलाई फेरि छोड्न अनुमति दिन्छ।
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // यसले `Box` खसाल्छ।
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// `ManuallyDrop<T>` कन्टेनरबाट मान लिन्छ।
    ///
    /// यो विधि मुख्यत: ड्रपमा मानहरू सार्नको लागि हो।
    /// [`ManuallyDrop::drop`] म्यानुअल रूपमा मान ड्रप गर्न प्रयोग गर्नुको सट्टा, तपाई यो विधि प्रयोग गर्न सक्नुहुनेछ मान लिनका लागि र यसलाई चाहिएको प्रयोग गर्नुहोस्।
    ///
    /// जब सम्भव हुन्छ, यसको सट्टा [`into_inner`][`ManuallyDrop::into_inner`] प्रयोग गर्नु राम्रो हुन्छ, जसले `ManuallyDrop<T>` को सामग्री नक्कल गर्नबाट रोक्छ।
    ///
    ///
    /// # Safety
    ///
    /// यस प्रकार्यले शिथिलतापूर्वक थप प्रयोगमा रोक लगाईएको मानलाई बाहिर सार्दछ, यस कन्टेनरको स्थिति बिना नै छोडिन्छ।
    /// यो `ManuallyDrop` फेरि प्रयोग गरिएको छैन भन्ने सुनिश्चित गर्न यो तपाईंको जिम्मेवारी हो।
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // सुरक्षा: हामी सन्दर्भबाट पढ्दै छौं, जुन ग्यारेन्टी छ
        // पढ्नको लागि मान्य हुन।
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// मैन्युअल्ली समावेश गरिएको मान खसाल्छ।यो ठिकसँग बराबर हो [`ptr::drop_in_place`] कल गर्न समाहित मानमा सूचकको साथ।
    /// जस्तो कि, समावेश गरिएको मान प्याक स्ट्रक्चर नभएसम्म डिस्ट्रक्टरलाई मानमा स्थान नलगाईकन भनिन्छ, र यसरी सुरक्षित रूपमा [pinned] डाटा ड्रप गर्न प्रयोग गर्न सकिन्छ।
    ///
    /// यदि तपाईंसँग मूल्यको स्वामित्व छ भने, तपाईं यसको सट्टा [`ManuallyDrop::into_inner`] प्रयोग गर्न सक्नुहुनेछ।
    ///
    /// # Safety
    ///
    /// यो प्रकार्यले समावेश गरिएको मानको विनाशकलाई चलाउँछ।
    /// डिस्ट्रक्टर आफैंले गरेका परिवर्तनहरू बाहेक, मेमोरी अपरिवर्तित छोडियो, र जहाँसम्म कम्पाइलर सम्बन्धित छ अझै पनि एक बिट-प्याटर्न होल्ड गर्दछ जुन प्रकार `T` को लागी मान्य छ।
    ///
    ///
    /// यद्यपि यो "zombie" मान सुरक्षित कोडमा पर्न हुँदैन, र यो प्रकार्य एक भन्दा बढि कल गर्नु हुँदैन।
    /// यसलाई छोडेपछि मान प्रयोग गर्न, वा एक मानलाई धेरै पटक छोड्दा, अपरिभाषित व्यवहार निम्त्याउँदछ (`drop` केमा निर्भर गर्दछ)।
    /// यो सामान्यतया प्रकार प्रणाली द्वारा रोकिन्छ, तर `ManuallyDrop` का प्रयोगकर्ताहरूले ती ग्यारेन्टीहरू कम्पाइलरको सहयोग बिना नै समर्थन गर्न आवश्यक छ।
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // सुरक्षा: हामी एक परिवर्तनीय सन्दर्भ द्वारा औंल्याइएको मान ड्रप गर्दैछौं
        // जुन लेख्नका लागि मान्य हुने ग्यारेन्टी छ।
        // यो सुनिश्चित गर्न कलरमा निर्भर हुन्छ कि `slot` फेरि छोडियो।
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}