use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// `T` को uninitialization ईन्स्टान्स निर्माण गर्न आवरण प्रकार।
///
/// # आरम्भिक इन्वाइरनेट
///
/// कम्पाइलर, सामान्यतया, मान गर्छ कि भ्यारीएबल भेरिएबलको प्रकारको आवश्यक्ता अनुसार राम्रोसँग आरम्भ गरिएको छ।उदाहरण को लागी, सन्दर्भ प्रकारको एक चर पigned्क्तिबद्ध र गैर-NULL हुनु पर्छ।
/// यो एक इन्भेर्नेट हो जुन *सँधै* असम्बन्धित कोडमा पनि समेट्नुपर्दछ।
/// नतिजाको रूपमा, शून्य-आरम्भिक सन्दर्भको प्रकारले तुरुन्त [undefined behavior][ub] निम्त्याउँदछ, जेसुकै पनि त्यो सन्दर्भ मेमोरीमा पहुँच गर्न प्रयोग गरीन्छ कि हुँदैन:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // अपरिभाषित व्यवहार!⚠️
/// // `MaybeUninit<&i32>` को साथ बराबर कोड:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // अपरिभाषित व्यवहार!⚠️
/// ```
///
/// यो कम्पाइलरले विभिन्न अप्टिमाइजेसनहरूको लागि शोषण गरेको छ, जस्तै रन-टाइम जाँचहरू रोक्न र `enum` लेआउटलाई अनुकूलन गर्ने।
///
/// त्यस्तै, पूर्ण रूपमा अनावश्यक मेमोरीमा कुनै सामग्री हुन सक्दछ, जबकि `bool` सँधै `true` वा `false` हुनु पर्छ।तसर्थ, एक अनावश्यक `bool` सिर्जना अपरिभाषित व्यवहार हो:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // अपरिभाषित व्यवहार!⚠️
/// // `MaybeUninit<bool>` को साथ बराबर कोड:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // अपरिभाषित व्यवहार!⚠️
/// ```
///
/// यसबाहेक, अनावश्यक मेमोरी योमा विशेष हो कि यसमा निश्चित मूल्य छैन ("fixed" जसको अर्थ "it won't change without being written to" हो)।एउटै अनावश्यक बाइट बहुविध पटक पढ्दा बिभिन्न नतिजाहरु दिन सक्छ।
/// यसले एक भ्यारीएबलमा इनिटिटलाइज्ड डाटा राख्न यसलाई अपरिभाषित व्यवहार बनाउँदछ कि भ्यारीएबलको इन्टिजर प्रकार छ, जो अन्यथा कुनै *निश्चित* बिट प्याटर्न होल्ड गर्न सक्दछ:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // अपरिभाषित व्यवहार!⚠️
/// // `MaybeUninit<i32>` को साथ बराबर कोड:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // अपरिभाषित व्यवहार!⚠️
/// ```
/// (ध्यान दिनुहोस् कि अनावश्यक इन्टिजरको वरपरको नियम अझ सम्म अन्तिम रूप छैन, तर तिनीहरू नहुनुसम्म उनीहरूबाट टाढा रहन सल्लाह दिइन्छ।)
///
/// त्यसमाथि, याद गर्नुहोस् कि प्राय प्रकारहरूसँग अतिरिक्त स्तरहरू मात्र हुन्छन् मात्र प्रकारको स्तरमा आरम्भ विचार गरीएको भन्दा बाहिर।
/// उदाहरण को लागी, एक `१`-इनिशियलाइज्ड [`Vec<T>`] इनिशिलाइज्ड मानिन्छ (हालको कार्यान्वयन अन्तर्गत; यसले स्थिर ग्यारेन्टीको गठन गर्दैन) किनभने कम्पाइलरले यस बारे थाहा पाउनु पर्ने एक मात्र आवश्यकता भनेको डाटा पोइन्टर गैर-अशक्त हुनुपर्दछ।
/// यस्तो `Vec<T>` सिर्जना गर्नाले *तत्काल* अपरिभाषित व्यवहारको कारण हुँदैन, तर अधिकतर सुरक्षित अपरेसनहरू (यसलाई छोड्ने सहित) सँग अपरिभाषित व्यवहारको कारण गर्दछ।
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` असुरक्षित डेटा सक्षम गर्नको लागि ईन्निटिटलाइज्ड डाटासँग डिल गर्न कार्य गर्दछ।
/// यो कम्पाइलरमा संकेत हो कि डाटा यहाँ * * आरम्भ हुन सकीदैन।
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // एक स्पष्ट रूपमा uninitialized सन्दर्भ सिर्जना गर्नुहोस्।
/// // कम्पाइलरले थाहा पाउँदछ कि `MaybeUninit<T>` भित्रको डेटा अमान्य हुन सक्छ, र त्यसैले यो UB होईन:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // यसलाई मान्य मानमा सेट गर्नुहोस्।
/// unsafe { x.as_mut_ptr().write(&0); }
/// // आरम्भ गरिएको डाटा निकाल्नुहोस्-यो मात्र *अनुमति दिईएको छ* उचित रूपमा `x` इनिसियलाइज पछि *
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// कम्पाइलरले यस कोडमा कुनै पनि गलत अनुमान वा अनुकूलन नगर्न जान्दछ।
///
/// तपाईं `MaybeUninit<T>` को लागी `Option<T>` जस्तै हुन सोच्न सक्नुहुन्छ तर कुनै रन-टाइम ट्र्याकिंग बिना र कुनै सुरक्षा जाँच बिना।
///
/// ## out-pointers
///
/// "out-pointers" कार्यान्वयन गर्न तपाई `MaybeUninit<T>` प्रयोग गर्न सक्नुहुनेछ: प्रकार्यबाट डाटा फिर्ता गर्नुको सट्टामा परिणामलाई राख्न केहि (uninitialized) मेमोरीमा सूचक दिनुहोस्।
/// यो उपयोगी हुन सक्दछ जब कलरको लागी नियन्त्रण गर्नु महत्वपूर्ण छ कि कसरी मेमोरीको नतिजा संग्रह गरिएको छ र यो अनावश्यक चालबाट बच्न चाहन्छ।
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` पुरानो सामग्री ड्रप गर्दैन, जुन महत्त्वपूर्ण छ।
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // अब हामीलाई थाहा छ कि `v` इनिसियलाइज गरिएको छ!यसले vector राम्रोसँग ड्रप भएको सुनिश्चित गर्दछ।
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## एर्रे एलिमेन्ट-ए-एलिमेन्ट सुरू गर्दै
///
/// `MaybeUninit<T>` एक ठूलो एर्रे एलिमेन्ट-ए-एलिमेन्ट सुरूवात गर्न प्रयोग गर्न सकिन्छ:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // `MaybeUninit` को एक uninitialized एर्रे सिर्जना गर्नुहोस्।
///     // `assume_init` सुरक्षित छ किनकि हामीले यहाँ सुरु गरेको दावी गरिरहेको प्रकार initial शायदUninit`s को समूह हो, जसलाई इनिसियलासनको आवश्यक्ता पर्दैन।
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // `MaybeUninit` छोड्दा केही गर्दैन।
///     // यसैले `ptr::write` को सट्टा कच्चा पोइन्टर असाइनमेन्ट प्रयोग गर्नाले पुरानो Unditialized मान छोड्दैन।
/////
///     // यस लूपको बखत त्यहाँ panic भएमा, हामीसँग मेमोरी चुहावट छ, तर त्यहाँ मेमोरी सुरक्षा मुद्दा छैन।
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // सबै कुराको शुरुवात भयो।
///     // सुरूवात प्रकारमा एर्रे ट्रान्समिट गर्नुहोस्।
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// तपाईं आंशिक रूपमा आरम्भ गरिएको एर्रेसँग पनि काम गर्न सक्नुहुनेछ जुन कम-स्तर डाटास्ट्राक्चरमा फेला पर्न सक्दछ।
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // `MaybeUninit` को एक uninitialized एर्रे सिर्जना गर्नुहोस्।
/// // `assume_init` सुरक्षित छ किनकि हामीले यहाँ सुरु गरेको दावी गरिरहेको प्रकार initial शायदUninit`s को समूह हो, जसलाई इनिसियलासनको आवश्यक्ता पर्दैन।
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // हामीले नियुक्त गरेका तत्वहरूको संख्या गणना गर्नुहोस्।
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // एर्रेमा प्रत्येक वस्तुको लागि ड्रप गर्नुहोस् यदि हामीले यसलाई बाँड्यौं भने।
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## एक स्ट्रक्चर क्षेत्र-द्वारा-क्षेत्र शुरूआत गर्दै
///
/// तपाई `MaybeUninit<T>` र [`std::ptr::addr_of_mut`] म्याक्रो प्रयोग गर्न सक्नुहुनेछ क्षेत्र द्वारा स्ट्रिक्ट फिल्ड शुरुवात गर्नका लागि:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // `name` क्षेत्र सुरू गर्दै
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // `list` क्षेत्र सुरू गर्दै यदि यहाँ panic छ भने, `name` फिल्ड लीकमा `String`।
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // सबै फिल्डहरू इनिसियलाइज्ड छन्, त्यसैले हामी `assume_init` कल गर्नुहोस् इनिसियलाइज्ड Foo प्राप्त गर्न।
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` `T` को रूपमा उही आकार, पign्क्तिबद्धता, र ABI लाई ग्यारेन्टी गरिएको छ:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// जबकि याद गर्नुहोस् कि एक प्रकार * * एक `MaybeUninit<T>` एक समान रूपरेखा जरूरी छैन;Rust सामान्य ग्यारेन्टीमा छैन कि `Foo<T>` का फाँटहरू `Foo<U>` को समान अर्डर छ `T` 3X र `U` को आकार र पign्क्तिबद्धता भए पनि।
///
/// यसबाहेक किनभने कुनै बिट मान `MaybeUninit<T>` को लागी वैध हो कम्पाइलरले non-zero/niche-filling अप्टिमाइजेसनहरू लागू गर्न सक्दैन, सम्भाव्य रूपमा ठूलो आकारको परिणामस्वरूप:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// यदि `T` FFI-सुरक्षित छ, तब `MaybeUninit<T>` छ।
///
/// जबकि `MaybeUninit` `#[repr(transparent)]` हो (यसले समान आकार, प al्क्तिबद्धता, र ABI लाई `T` को रूपमा ग्यारेन्टी गर्दछ), यसले * अघिल्लो चेतावनीहरूमध्ये कुनै परिवर्तन गर्दैन।
/// `Option<T>` र `Option<MaybeUninit<T>>` अझै पनी फरक आकार हुन सक्छ, र प्रकार `T` को क्षेत्र भएको प्रकार बाहिर बिछ्याउन सकिन्छ (र आकार) कि क्षेत्र `MaybeUninit<T>` थिए भन्दा।
/// `MaybeUninit` एक यूनियन प्रकार हो, र यूनियनहरूमा `#[repr(transparent)]` अस्थिर छ (हेर्नुहोस् [the tracking issue](https://github.com/rust-lang/rust/issues/60405))।
/// समयको साथसाथै युनियनहरूमा `#[repr(transparent)]` को सहि ग्यारेन्टीहरू विकसित हुन सक्छ, र `MaybeUninit` `#[repr(transparent)]` रहन वा नहुन सक्छ।
/// त्योले भन्यो, `MaybeUninit<T>`*सँधै* ग्यारेन्टी गर्दछ कि योसँग उही आकार, पign्क्तिबद्धता, र ABI `T` को रूपमा छ;यो मात्र हो कि `MaybeUninit` कार्यान्वयन गर्ने ग्यारेन्टी विकसित हुन सक्छ।
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// ल्यांग वस्तु ताकि हामी यसमा अन्य प्रकारका लपेट्न सक्दछौं।यो जेनरेटर को लागी उपयोगी छ।
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // `T::clone()` कल गर्दै, हामी जान्दैनौं कि हामी यसको लागि पर्याप्त इनिसियलाइज गरिएको छ।
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// दिइएको मानको साथ इनिसियलाइज्ड नयाँ `MaybeUninit<T>` सिर्जना गर्दछ।
    /// यस प्रकार्यको फिर्ती मूल्यमा [`assume_init`] कल गर्न सुरक्षित छ।
    ///
    /// नोट गर्नुहोस् कि `MaybeUninit<T>` छोड्नाले never T` को ड्रप कोड कहिले पनि कल गर्दैन।
    /// यो `T` खसाल्यो भने सुनिश्चित भयो भने यो तपाईंको जिम्मेवारी हो कि यो आरम्भ भयो।
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// अनावश्यक राज्यमा नयाँ `MaybeUninit<T>` सिर्जना गर्दछ।
    ///
    /// नोट गर्नुहोस् कि `MaybeUninit<T>` छोड्नाले never T` को ड्रप कोड कहिले पनि कल गर्दैन।
    /// यो `T` खसाल्यो भने सुनिश्चित भयो भने यो तपाईंको जिम्मेवारी हो कि यो आरम्भ भयो।
    ///
    /// केहि उदाहरणका लागि [type-level documentation][MaybeUninit] हेर्नुहोस्।
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// `MaybeUninit<T>` आईटमको नयाँ एर्रे सिर्जना गर्नुहोस्, अनावश्यक अवस्थामा।
    ///
    /// Note: future Rust संस्करणमा यो विधि अनावश्यक हुन सक्छ जब एरे लिटरल सिन्ट्याक्सले [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) लाई अनुमति दिँदछ।
    ///
    /// तलको उदाहरणले त्यसपछि `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` प्रयोग गर्न सक्दछ।
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// (सम्भवतः सानो) डाटाको स्लाइस फर्काउँछ जुन वास्तवमा पढिएको थियो
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // सुरक्षा: एक uninitialized `[MaybeUninit<_>; LEN]` मान्य छ।
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Xit1X बाइट्सको साथ मेमोरी भरिएको साथ, एक uninitialized स्थिति मा एक नयाँ `MaybeUninit<T>` सिर्जना गर्दछ।यो `T` मा निर्भर गर्दछ कि त्यो पहिले नै उचित आरम्भको लागि बनाउँदछ कि भनेर।
    ///
    /// उदाहरणको लागि, `MaybeUninit<usize>::zeroed()` सुरूवात गरिएको छ, तर `MaybeUninit<&'static i32>::zeroed()` होईन किनकि सन्दर्भहरू शून्य हुनुहुन्न।
    ///
    /// नोट गर्नुहोस् कि `MaybeUninit<T>` छोड्नाले never T` को ड्रप कोड कहिले पनि कल गर्दैन।
    /// यो `T` खसाल्यो भने सुनिश्चित भयो भने यो तपाईंको जिम्मेवारी हो कि यो आरम्भ भयो।
    ///
    /// # Example
    ///
    /// यस प्रकार्यको सहि उपयोग: एक शुन्यको साथ संरचना आरम्भ गर्दै, जहाँ संरचनाको सबै क्षेत्रहरूले बिट-प्याटर्न ० लाई एक वैध मानको रूपमा समात्न सक्छ।
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *यो प्रकार्यको* गलत * उपयोग: `x.zeroed().assume_init()` लाई कल गर्दा `0` प्रकारको लागि मान्य बिट-प्याटर्न छैन।
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // एक जोडी भित्र, हामी एक `NotZero` सिर्जना गर्दछौं जसमा वैध भेदभाव हुने छैन।
    /// // यो अपरिभाषित व्यवहार हो।⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // सुरक्षा: `u.as_mut_ptr()` अ allocated्कित मेमोरीमा पोइन्टहरू।
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// `MaybeUninit<T>` को मान सेट गर्दछ।
    /// यसले कुनै पनि अघिल्लो मानलाई यसलाई छोड्दा अधिलेखन गर्दछ, त्यसैले सावधान रहनुहोस् यस पटक दुई पटक प्रयोग नगर्नुहोस् जबसम्म तपाईं डिस्ट्रक्टर चलाउनुहुन्न।
    ///
    /// तपाईंको सुविधाको लागि, यसले `self` को सामग्रीहरू (अब सुरक्षित रूपमा आरम्भ गरिएको) मा एक परिवर्तनको रूपमा फर्काउँछ।
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // सुरक्षा: हामीले भर्खर यस मूल्यलाई आरम्भ गरेका छौं।
        unsafe { self.assume_init_mut() }
    }

    /// निहित मानमा सूचक प्राप्त गर्दछ।
    /// यस पोइन्टरबाट पढ्नु वा यसलाई सन्दर्भमा परिर्वतन गर्नु अपरिभाषित व्यवहार हो जबसम्म `MaybeUninit<T>` आरम्भ हुँदैन।
    /// मेमोरीमा लेख्ने कि यो पोइन्टर (non-transitively) लाई औंल्याइएको अपरिभाषित व्यवहार हो (एक `UnsafeCell<T>` भित्र बाहेक)।
    ///
    /// # Examples
    ///
    /// यस विधिको सहि उपयोग:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<T>` मा एक सन्दर्भ सिर्जना गर्नुहोस्।यो ठीक छ किनकि हामीले त्यसलाई आरम्भ गर्‍यौं।
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *गलत* यस विधिको उपयोग:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // हामीले एक Unditialized vector को सन्दर्भ सिर्जना गरेका छौं!यो अपरिभाषित व्यवहार हो।⚠️
    /// ```
    ///
    /// (ध्यान दिनुहोस् कि इनिटिटलाइज्ड डाटाको सन्दर्भमा नियमहरू अझै अन्तिम रूप दिईएको छैन, तर तिनीहरू नहुन्जेल यो सल्लाहबाट जोगिनु पर्छ।)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` र `ManuallyDrop` दुबै `repr(transparent)` हुन् त्यसैले हामी सूचकलाई कास्ट गर्न सक्छौं।
        self as *const _ as *const T
    }

    /// निहित मानमा म्यूटेबल पोइन्टर हुन्छ।
    /// यस पोइन्टरबाट पढ्नु वा यसलाई सन्दर्भमा परिर्वतन गर्नु अपरिभाषित व्यवहार हो जबसम्म `MaybeUninit<T>` आरम्भ हुँदैन।
    ///
    /// # Examples
    ///
    /// यस विधिको सहि उपयोग:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<Vec<u32>>` मा एक सन्दर्भ सिर्जना गर्नुहोस्।
    /// // यो ठीक छ किनकि हामीले त्यसलाई आरम्भ गर्‍यौं।
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *गलत* यस विधिको उपयोग:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // हामीले एक Unditialized vector को सन्दर्भ सिर्जना गरेका छौं!यो अपरिभाषित व्यवहार हो।⚠️
    /// ```
    ///
    /// (ध्यान दिनुहोस् कि इनिटिटलाइज्ड डाटाको सन्दर्भमा नियमहरू अझै अन्तिम रूप दिईएको छैन, तर तिनीहरू नहुन्जेल यो सल्लाहबाट जोगिनु पर्छ।)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` र `ManuallyDrop` दुबै `repr(transparent)` हुन् त्यसैले हामी सूचकलाई कास्ट गर्न सक्छौं।
        self as *mut _ as *mut T
    }

    /// `MaybeUninit<T>` कन्टेनरबाट मान निकाल्छ।यो सुनिश्चित गर्नका लागि एक उत्तम तरिका हो कि डाटा छोडिनेछ, किनकि परिणामस्वरूप `T` सामान्य ड्रप ह्यान्डलिंगको अधीनमा छ।
    ///
    /// # Safety
    ///
    /// यो `MaybeUninit<T>` वास्तवमा एक आरम्भिक राज्य मा छ कि ग्यारेन्टी गर्न कलर माथि छ।यो कलिंग गर्दा जब सामग्री अझै पूर्ण रूपमै आरम्भ गरिएको छैन तत्काल अपरिभाषित व्यवहारको कारण गर्दछ।
    /// [type-level documentation][inv] ले यो आरम्भ ईरिएन्टको बारेमा अधिक जानकारी समावेश गर्दछ।
    ///
    /// [inv]: #initialization-invariant
    ///
    /// त्यसमाथि, याद गर्नुहोस् कि प्राय प्रकारहरूसँग अतिरिक्त स्तरहरू मात्र हुन्छन् मात्र प्रकारको स्तरमा आरम्भ विचार गरीएको भन्दा बाहिर।
    /// उदाहरण को लागी, एक `१`-इनिशियलाइज्ड [`Vec<T>`] इनिशिलाइज्ड मानिन्छ (हालको कार्यान्वयन अन्तर्गत; यसले स्थिर ग्यारेन्टीको गठन गर्दैन) किनभने कम्पाइलरले यस बारे थाहा पाउनु पर्ने एक मात्र आवश्यकता भनेको डाटा पोइन्टर गैर-अशक्त हुनुपर्दछ।
    ///
    /// यस्तो `Vec<T>` सिर्जना गर्नाले *तत्काल* अपरिभाषित व्यवहारको कारण हुँदैन, तर अधिकतर सुरक्षित अपरेसनहरू (यसलाई छोड्ने सहित) सँग अपरिभाषित व्यवहारको कारण गर्दछ।
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// यस विधिको सहि उपयोग:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *गलत* यस विधिको उपयोग:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` अझसम्म आरम्भ गरिएको थिएन, त्यसैले यो अन्तिम रेखा अपरिभाषित व्यवहारको कारण।⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // सुरक्षा: कलरले `self` आरम्भ गरिएको ग्यारेन्टी गर्नै पर्छ।
        // यसको मतलब `self` `value` भेरियन्ट हुनु पर्छ।
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// `MaybeUninit<T>` कन्टेनरबाट मान पढ्छ।परिणामस्वरूप `T` सामान्य ड्रप ह्यान्डलिंगको अधीनमा छ।
    ///
    /// जब सम्भव हुन्छ, यसको सट्टा [`assume_init`] प्रयोग गर्नु राम्रो हुन्छ, जसले `MaybeUninit<T>` को सामग्री नक्कल गर्नबाट रोक्छ।
    ///
    /// # Safety
    ///
    /// यो `MaybeUninit<T>` वास्तवमा एक आरम्भिक राज्य मा छ कि ग्यारेन्टी गर्न कलर माथि छ।यो कल गर्दा जब सामग्री अझै पूर्ण रूपमै आरम्भ गरिएको छैन अपरिभाषित व्यवहारको कारण गर्दछ।
    /// [type-level documentation][inv] ले यो आरम्भ ईरिएन्टको बारेमा अधिक जानकारी समावेश गर्दछ।
    ///
    /// यसबाहेक, यसले `MaybeUninit<T>` मा पछाडि उही डाटाको प्रतिलिपि छोड्दछ।
    /// डाटाको बहु प्रतिलिपिहरू प्रयोग गर्दा (`assume_init_read` बहु चोटि कल गरेर, वा पहिले `assume_init_read` र त्यसपछि [`assume_init`] कल गरेर), यो डाटा वास्तवमा नक्कल हुन सक्छ भन्ने सुनिश्चित गर्न यो तपाईंको जिम्मेवारी हो।
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// यस विधिको सहि उपयोग:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` `Copy` हो, त्यसैले हामी धेरै पटक पढ्न सक्छौं।
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // एक `None` मान नक्कल ठीक छ, त्यसैले हामी धेरै पटक पढ्न सक्छौं।
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *गलत* यस विधिको उपयोग:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // हामीले अब समान vector को दुई प्रतिलिपिहरू सिर्जना गरेका छौं, जुन डबल-फ्रीमा अग्रणी छ-जब ती दुबै छोडिन्छन्!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // सुरक्षा: कलरले `self` आरम्भ गरिएको ग्यारेन्टी गर्नै पर्छ।
        // `self.as_ptr()` बाट पढाइ सुरक्षित छ किनकि `self` आरम्भ हुनु पर्छ।
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// ठाउँमा समावेश गरिएको मान खसाल्छ।
    ///
    /// यदि तपाईंसँग `MaybeUninit` को स्वामित्व छ भने, तपाईं यसको सट्टामा [`assume_init`] प्रयोग गर्न सक्नुहुनेछ।
    ///
    /// # Safety
    ///
    /// यो `MaybeUninit<T>` वास्तवमा एक आरम्भिक राज्य मा छ कि ग्यारेन्टी गर्न कलर माथि छ।यो कल गर्दा जब सामग्री अझै पूर्ण रूपमै आरम्भ गरिएको छैन अपरिभाषित व्यवहारको कारण गर्दछ।
    ///
    /// यसको शीर्षमा, प्रकार `T` का सबै अतिरिक्त आक्रमकहरू सन्तुष्ट हुनुपर्दछ, किनकि `T` (वा यसको सदस्यहरू) को `Drop` कार्यान्वयन यसमा निर्भर हुन सक्छ।
    /// उदाहरण को लागी, एक `१`-इनिशियलाइज्ड [`Vec<T>`] इनिशिलाइज्ड मानिन्छ (हालको कार्यान्वयन अन्तर्गत; यसले स्थिर ग्यारेन्टीको गठन गर्दैन) किनभने कम्पाइलरले यस बारे थाहा पाउनु पर्ने एक मात्र आवश्यकता भनेको डाटा पोइन्टर गैर-अशक्त हुनुपर्दछ।
    ///
    /// यस्तो `Vec<T>` छोड्दा तथापि अपरिभाषित व्यवहार हुन्छ।
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // सुरक्षा: कलरले `self` शुरुवात भएको ग्यारेन्टी गर्नै पर्छ र
        // `T` का सबै आक्रमणहरूलाई सन्तुष्ट पार्दछ।
        // स्थानमा मान छोड्ने काम सुरक्षित छ यदि त्यो हो भने।
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// समाहित मानको लागि साझा संदर्भ प्राप्त गर्दछ।
    ///
    /// यो उपयोगी हुन सक्दछ जब हामी `MaybeUninit` पहुँच गर्न चाहान्छौं जुन सुरूवात गरिएको छ तर `MaybeUninit` को स्वामित्व छैन (`.assume_init()`) को प्रयोग रोक्दै)।
    ///
    /// # Safety
    ///
    /// यो कल गर्दा जब सामग्री पूर्ण रूपमा आरम्भ गरिएको छैन अपरिभाषित व्यवहारको कारण हुन्छ: `MaybeUninit<T>` वास्तवमै आरम्भ अवस्थामा छ भन्ने कुराको ग्यारेन्टी गर्न कलरमा निर्भर हुन्छ।
    ///
    ///
    /// # Examples
    ///
    /// ### यस विधिको सहि उपयोग:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // `x` सुरू गर्नुहोस्:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // अब जब हाम्रो `MaybeUninit<_>` इनिसियलाइजको रूपमा परिचित छ, यससँग एक साझा सन्दर्भ सिर्जना गर्न ठीक छ:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // सुरक्षा: `x` सुरूवात गरिएको छ।
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *गलत* यस विधिको उपयोगहरू:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // हामीले एक Unditialized vector को सन्दर्भ सिर्जना गरेका छौं!यो अपरिभाषित व्यवहार हो।⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // `Cell::set` `Cell::set` प्रयोग गरेर आरम्भ गर्नुहोस्:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // एक अनावश्यक `Cell<bool>` सन्दर्भ: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // सुरक्षा: कलरले `self` आरम्भ गरिएको ग्यारेन्टी गर्नै पर्छ।
        // यसको मतलब `self` `value` भेरियन्ट हुनु पर्छ।
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// निहित मूल्यमा म्यूटेबल (unique) सन्दर्भ प्राप्त गर्दछ।
    ///
    /// यो उपयोगी हुन सक्दछ जब हामी `MaybeUninit` पहुँच गर्न चाहान्छौं जुन सुरूवात गरिएको छ तर `MaybeUninit` को स्वामित्व छैन (`.assume_init()`) को प्रयोग रोक्दै)।
    ///
    /// # Safety
    ///
    /// यो कल गर्दा जब सामग्री पूर्ण रूपमा आरम्भ गरिएको छैन अपरिभाषित व्यवहारको कारण हुन्छ: `MaybeUninit<T>` वास्तवमै आरम्भ अवस्थामा छ भन्ने कुराको ग्यारेन्टी गर्न कलरमा निर्भर हुन्छ।
    /// उदाहरण को लागी, `.assume_init_mut()` एक `MaybeUninit` इनिशिलाइज गर्न प्रयोग गर्न सकिदैन।
    ///
    /// # Examples
    ///
    /// ### यस विधिको सहि उपयोग:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// इनपुट बफरको *सबै* बाइट्स सुरु गर्दछ।
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // `buf` सुरू गर्नुहोस्:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // अब हामीलाई थाहा छ कि `buf` इनिसियलाइज गरिएको छ, त्यसैले हामी यसलाई `.assume_init()` गर्न सक्छौं।
    /// // जे होस्, `.assume_init()` प्रयोग गर्नाले २०4848 बाइट्सको `memcpy` ट्रिगर गर्न सक्दछ।
    /// // हाम्रो बफर दावी गर्न यसलाई प्रतिलिपि नगरीएको छ, हामी `&mut MaybeUninit<[u8; 2048]>` लाई `&mut [u8; 2048]` मा अपग्रेड गर्दछौं।
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // सुरक्षा: `buf` सुरूवात गरिएको छ।
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // अब हामी सामान्य स्लाइसको रूपमा `buf` प्रयोग गर्न सक्छौं:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *गलत* यस विधिको उपयोगहरू:
    ///
    /// तपाईं `.assume_init_mut()` प्रयोग गर्न सक्नुहुन्न मान सुरू गर्न:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // हामीले एक Xit1X सन्दर्भ सिर्जना नगरिएको `bool` सिर्जना गरेका छौं।
    ///     // यो अपरिभाषित व्यवहार हो।⚠️
    /// }
    /// ```
    ///
    /// उदाहरण को लागी, तपाईं एक बुनियादीकरण बफर मा [`Read`] गर्न सक्नुहुन्न:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) Unditialized स्मृति सन्दर्भ!
    ///                             // यो अपरिभाषित व्यवहार हो।
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// न त तपाई फिल्ड-बाय-फिल्ड क्रमिक आरम्भिकरण गर्न सीधा फिल्ड पहुँच प्रयोग गर्न सक्नुहुनेछ।
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) Unditialized स्मृति सन्दर्भ!
    ///                  // यो अपरिभाषित व्यवहार हो।
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) Unditialized स्मृति सन्दर्भ!
    ///                  // यो अपरिभाषित व्यवहार हो।
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): हामी हाल माथिको गलत रहेकोमा निर्भर छौं, अर्थात्, हामीसँग इन्टीटिटलाइज्ड डाटाको सन्दर्भ छ (उदाहरणका लागि, `libcore/fmt/float.rs` मा)।
    // हामीले स्थिरीकरण हुनु अघि नियमहरूको बारेमा अन्तिम निर्णय लिनु पर्छ।
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // सुरक्षा: कलरले `self` आरम्भ गरिएको ग्यारेन्टी गर्नै पर्छ।
        // यसको मतलब `self` `value` भेरियन्ट हुनु पर्छ।
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// `MaybeUninit` कन्टेनरहरूको एरेबाट मानहरू निकाल्छ।
    ///
    /// # Safety
    ///
    /// यो कलरमा ग्यारेन्टी गर्न को लागी हो कि एर्रेको सबै एलिमेन्टेड अवस्थामा छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // सुरक्षा: अब सुरक्षित रूपमा हामीले सबै तत्वहरू आरम्भ गरे
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * कलरले ग्यारेन्टी दिन्छ कि एर्रेको सबै एलिमेन्टस इनिसियलाइज गरियो
        // * `MaybeUninit<T>` र T समान लेआउटको ग्यारेन्टी गरिएको छ
        // * हुनसक्छ युनिन्ट ड्रप हुँदैन, त्यसैले त्यहाँ कुनै डबल फ्री छैन र रूपान्तरण सुरक्षित छ
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// मानौं कि सबै तत्वहरू आरम्भ छन्, तिनीहरूलाई स्लाइस गर्नुहोस्।
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` एलिमेन्टहरू वास्तवमै ईनिसियलाइज्ड अवस्थामा छन् भन्ने ग्यारेन्टी गर्न यो कलरमा भर पर्छ।
    ///
    /// यो कल गर्दा जब सामग्री अझै पूर्ण रूपमै आरम्भ गरिएको छैन अपरिभाषित व्यवहारको कारण गर्दछ।
    ///
    /// अधिक विवरण र उदाहरणका लागि [`assume_init_ref`] हेर्नुहोस्।
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // सुरक्षा: कलरले `*const [T]` मा स्लाइस कास्टिंग सुरक्षित छ किनकि कलरले ग्यारेन्टी गर्दछ
        // `slice` आरम्भ गरिएको छ, र `MaybeUninit` `T` जस्तै लेआउटको ग्यारेन्टी गरिएको छ।
        // प्राप्त सूचक वैध छ किनकि यसले `slice` को स्वामित्वमा रहेको मेमोरीलाई जनाउँछ जुन सन्दर्भ हो र यसरी पढ्नका लागि मान्य हुने ग्यारेन्टी छ।
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// मानौं कि सबै तत्वहरू आरम्भ छन्, तिनीहरूलाई एक म्यूटेबल स्लाइस पाउनुहोस्।
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` एलिमेन्टहरू वास्तवमै ईनिसियलाइज्ड अवस्थामा छन् भन्ने ग्यारेन्टी गर्न यो कलरमा भर पर्छ।
    ///
    /// यो कल गर्दा जब सामग्री अझै पूर्ण रूपमै आरम्भ गरिएको छैन अपरिभाषित व्यवहारको कारण गर्दछ।
    ///
    /// अधिक विवरण र उदाहरणका लागि [`assume_init_mut`] हेर्नुहोस्।
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // सुरक्षा: `slice_get_ref` का लागि सुरक्षा नोटहरू जस्तै, तर हामीसँग एक छ
        // परिवर्तनीय सन्दर्भ जुन पनि लेख्नको लागि मान्य हुन ग्यारेन्टी गरिएको छ।
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// एर्रेको पहिलो तत्वमा सूचक प्राप्त गर्दछ।
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// एर्रेको पहिलो एलिमेन्टमा म्यूटेबल पोइन्टर हुन्छ।
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// `src` बाट `this` मा तत्त्वहरू प्रतिलिपि गर्दछ, `this` को हालको इनलिटाइज गरिएको सामग्रीको म्यूटेबल सन्दर्भ फर्काउँछ।
    ///
    /// यदि `T` `Copy` कार्यान्वयन गर्दैन, [`write_slice_cloned`] प्रयोग गर्नुहोस्
    ///
    /// यो [`slice::copy_from_slice`] जस्तै छ।
    ///
    /// # Panics
    ///
    /// यो प्रकार्य panic हुनेछ यदि दुई स्लाइसहरू फरक लम्बाई छ भने।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // सुरक्षा: हामीले भर्खरका सबै सामग्रीहरूको खाली क्षमतामा प्रतिलिपि गरेका छौं
    /// // Vec का प्रथम src.len() एलिमेन्टहरू अब मान्य छन्।
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // सुरक्षा: &[T] र&[शायदUninit<T>] समान लेआउट छ
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // सुरक्षा: मान्य तत्वहरू भर्खरै `this` मा प्रतिलिपि गरिएको छ त्यसैले यो ईनिटाइलाइज गरिएको छ
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// `src` बाट `this` मा तत्त्वहरू क्लोन गर्दछ, `this` को अब initalized सामग्रीको एक परिवर्तनीय सन्दर्भ फिर्ता।
    /// कुनै पहिल्यै पहल गरिएको ईलिमेन्ट्स ड्रप गरिने छैन।
    ///
    /// यदि `T` `Copy` लागू गर्दछ, [`write_slice`] प्रयोग गर्नुहोस्
    ///
    /// यो [`slice::clone_from_slice`] सँग मिल्दोजुल्दो छ तर अवस्थित तत्वहरू ड्रप गर्दैन।
    ///
    /// # Panics
    ///
    /// यो प्रकार्य panic हुनेछ यदि दुई स्लाइसहरू फरक लम्बाई छ, वा `Clone` panics को कार्यान्वयन।
    ///
    /// यदि एक panic छ भने, पहिले नै क्लोन गरिएका तत्त्वहरू छोडिनेछ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // सुरक्षा: हामीले भर्खरको क्षमतामा लेनका सबै तत्त्वहरूलाई क्लोन गरेका छौं
    /// // Vec का प्रथम src.len() एलिमेन्टहरू अब मान्य छन्।
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // copy_from_slice विपरीत यो स्लाइस मा clone_from_slice कल गर्दैन किनभने `MaybeUninit<T: Clone>` क्लोन कार्यान्वयन गर्दैन।
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // सुरक्षा: यस कच्चा स्लाइसले केवल आरम्भ गरिएको वस्तुहरू समावेश गर्दछ
                // त्यसैले पनि, यो ड्रप गर्न अनुमति छ।
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: हामीले उनीहरूलाई स्पष्ट रूपमा समान लम्बाईमा टुक्राउन आवश्यक छ
        // सीमाहरू जाँच गर्न बाध्य हुनको लागि, र अप्टिमाइजरले साधारण केसहरूको लागि मेम्पी उत्पन्न गर्दछ (उदाहरणका लागि T= u8)।
        //
        let len = this.len();
        let src = &src[..len];

        // गार्ड आवश्यक छ b/c panic एक क्लोनको समयमा हुन सक्छ
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // सुरक्षा: मान्य तत्वहरू भर्खर `this` मा लेखिएका छन् त्यसैले यो ईनिटाइलाइज गरिएको छ
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}