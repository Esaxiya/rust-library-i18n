use crate::iter::FromIterator;

/// एक इटरेटरबाट सबै एकाई आईटमहरू एकमा संकुचन गर्दछ।
///
/// यो अधिक उपयोगी हुन्छ जब उच्च स्तरको अमूर्तका साथ जोडीएको छ, जस्तै `Result<(), E>` लाई स collecting्कलन गर्दा जहाँ तपाईं त्रुटिहरूको मात्र ख्याल गर्नुहुन्छ:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}