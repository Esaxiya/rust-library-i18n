//! एक अलग भाग र त्रुटि दायरा मा एक फ्लोटिंग पोइन्ट मान डिकोड।

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// डिकोड नगरिएको सीमित मूल्य, जस्तो कि:
///
/// - मूल मान `mant * 2^exp` बराबर।
///
/// - `(mant - minus)*2^exp` बाट `(mant + plus)* 2^exp` मा कुनै पनि संख्या मूल मानमा मिल्नेछ।
/// `inclusive` `true` हुँदा मात्र दायरा समावेशी हुन्छ।
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// नाप्ने मन्तिसा।
    pub mant: u64,
    /// तल्लो त्रुटि दायरा।
    pub minus: u64,
    /// माथिल्लो त्रुटि दायरा।
    pub plus: u64,
    /// बेस २ मा साझा घाता .्क।
    pub exp: i16,
    /// यो सत्य दायरा समावेशी भएको छ।
    ///
    /// आईईईई 75 754 मा, यो साँचो हो जब सक्कली मूल मन्टिस्सा पनि थियो।
    pub inclusive: bool,
}

/// डिकोड नगरिकन हस्ताक्षर मान।
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// इन्फिनिटीहरू, या त सकारात्मक वा नकारात्मक।
    Infinite,
    /// शून्य, कि त सकारात्मक वा नकारात्मक।
    Zero,
    /// थप डिकोड क्षेत्रहरूसँग परिमित संख्याहरू।
    Finite(Decoded),
}

/// फ्लोटिंग पोइन्ट प्रकार जुन `डिकोड गर्नुहोस्।
pub trait DecodableFloat: RawFloat + Copy {
    /// न्यूनतम सकारात्मक सामान्यीकृत मान।
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// दिइएको फ्लोटिंग पोइन्ट नम्बरबाट एउटा चिन्ह (सही हुँदा नकारात्मक) र `FullDecoded` मान फर्काउँछ।
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // छिमेकीहरू: (मन्त, २, म्याद)-(मन्त, समाप्ति)-(मन्त + २, म्याद)
            // Float::integer_decode सँधै घाता .्क जोगाउँदछ, त्यसैले म्यान्टिसा subnormals को लागि मापन गरिएको छ।
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // छिमेकीहरू: (अधिकतम, म्याद, १)-(minnormmant, Exp)-(minnormmant + १, म्याद)
                // जहाँ अधिकतम=minnormmant * २, १
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // छिमेकीहरू: (मन्त, १, म्याद)-(मन्त, Exp)-(मन्त + १, म्याद)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}