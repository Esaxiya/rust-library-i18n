//! लगभग प्रत्यक्ष (तर थोरै अप्टिमाइज गरिएको) Rust अनुवाद "छिटो र सटीक रूपमा" प्रिन्टिंग फ्लोटिंग पोइन्ट नम्बरहरू "[^ १] को चित्र of को चित्र।
//!
//!
//! [^1]: Burger, RG र Dybvig, RK १ 1996 1996।। फ्लोटिंग पोइन्ट नम्बरहरू प्रिन्ट गर्दै
//!   छिटो र सही रूपमा।सिग्नल छैन।,१, ((मे। १ 1996 1996)), १०-1-१११।।

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// १० ^ (२ ^ n) को लागी `Digit`s को precalculated arrays
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// केवल प्रयोगयोग्य जब `x < 16 * scale`;`scaleN` `scale.mul_small(N)` हुनु पर्छ
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// ड्र्यागनका लागि सब भन्दा छोटो मोड कार्यान्वयन।
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // नम्बर `v` ढाँचामा हुन ज्ञात छ:
    // - `mant * 2^exp` बराबर;
    // - `(mant - 2 *minus)* 2^exp` द्वारा सुरुमा मूल प्रकारमा;र
    // - `(mant + 2 *plus)* 2^exp` द्वारा पछि मूल प्रकारमा
    //
    // स्पष्ट रूपमा, `minus` र `plus` शून्य हुन सक्दैन।(इन्फिनिटीहरूको लागि, हामी सीमा बाहिरका मानहरू प्रयोग गर्दछौं।) साथै हामी यो पनि मान्दछौं कि कम्तिमा एउटा अ generated्क उत्पन्न भएको छ, अर्थात, `mant` पनि शून्य हुन सक्दैन।
    //
    // यसको मतलब `low = (mant - minus)*2^exp` र `high = (mant + plus)* 2^exp` बिचको कुनै पनि संख्याले यस सटीक फ्लोटिंग पोइन्ट नम्बरमा नक्सा गर्नेछ, मौलिक मँटिस्सा सम (जस्तै, `!mant_was_odd`) पनि समावेश हुँदा सीमा सहित।
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` `if d.inclusive {a <= b} else {a < b}` हो
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // `k_0` अनुमानित सक्कली इनपुट्सबाट सन्तोषजनक `10^(k_0-1) < high <= 10^(k_0+1)`।
    // टाईट बाउन्ड `k` संतोषजनक `10^(k-1) < high <= 10^k` पछि गणना गरिन्छ।
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // `{mant, plus, minus} * 2^exp` लाई आंशिक रुपमा रूपान्तरण गर्नुहोस् कि:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // `mant` लाई `10^k` द्वारा विभाजित गर्नुहोस्।अब `scale / 10 < mant + plus <= scale * 10`।
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // फिक्सअप जब `mant + plus > scale` (वा `>=`)।
    // हामी वास्तवमै `scale` परिमार्जन गरिरहेका छैनौं, किनकि हामी यसको सट्टामा प्रारम्भिक गुणा छोड्न सक्छौं।
    // अब `scale < mant + plus <= scale * 10` र हामी अंक उत्पन्न गर्न को लागी तयार छौं।
    //
    // नोट गर्नुहोस् कि `d[0]`* * शून्य हुन सक्छ, जब `scale - plus < mant < scale`।
    // यस अवस्थामा राउन्डिंग अप सर्त (तल `up`) तुरून्त ट्रिगर हुनेछ।
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // १० द्वारा `scale` स्केल गर्ने बराबर
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // अंक उत्पादनको लागि क्यास `(2, 4, 8) * scale`।
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // आक्रमणकर्ताहरू, जहाँ `d[0..n-1]` अहिले सम्म अंक उत्पन्न गरिएको छ:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (त्यसैले `mant / scale < 10`) जहाँ `d[i..j]` short d [i] * १० ^ (जी) को लागी एक संक्षिप्तमा हो ...
        // + d [j-1] * १० + d[j]`।

        // एउटा अंक उत्पन्न गर्नुहोस्: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // यो परिमार्जित ड्र्यागन एल्गोरिथ्मको सरलीकृत वर्णन हो।
        // धेरै मध्यवर्ती व्युत्पन्नहरू र पूर्णता तर्कहरू सुविधाको लागि हटाइन्छन्।
        //
        // परिमार्जित आक्रमणकारीहरूसँग सुरु गर्नुहोस्, जसरी हामीले `n` अपडेट गर्‍यौं।
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // मान्नुहोस् कि `d[0..n-1]` `low` र `high` बीच सब भन्दा छोटो प्रतिनिधित्व हो, अर्थात `d[0..n-1]` दुबैलाई निम्न कुराले सन्तुष्ट पार्छ तर `d[0..n-2]` ले गर्दैन:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (विचित्रता: `v` मा राउन्ड);र
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (अन्तिम अंक सहि छ)।
        //
        // दोस्रो सर्त `2 * mant <= scale` मा सरलीकृत हुन्छ।
        // `mant`, `low` र `high` को सर्तमा इन्भेन्ट्रन्टहरू समाधान गर्दै पहिलो शर्तको एक सरल संस्करण उपल्बध: `-plus < mant < minus`.
        // `-plus < 0 <= mant` पछि, हामीसँग सही छोटो प्रतिनिधित्व छ जब `mant < minus` र `2 * mant <= scale`।
        // (पहिलेको `mant <= minus` हुन्छ जब मौलिक मन्टिसा समान हुन्छ।)
        //
        // जब दोस्रो होईन (`२ * मँट> स्केल`), हामीले अन्तिम अंक बढाउनु पर्छ।
        // यो अवस्थालाई पूर्वावस्थामा ल्याउनका लागि यो पर्याप्त छ: हामीलाई थाहा छ कि अंक जेनरेशनले `0 <= v / 10^(k-n) - d[0..n-1] < 1` ग्यारेन्टी गर्दछ।
        // यस अवस्थामा, पहिलो सर्त `-plus < mant - scale < minus` हुन्छ।
        // `mant < scale` जेनेरेसन पछि, हामीसंग `scale < mant + plus` छ।
        // (फेरि, यो `scale <= mant + plus` हुन्छ जब मौलिक मन्टिस्सा सम हो।)
        //
        // छोटकरीमा:
        // - `mant < minus` (वा `<=`) मा रोक्नुहोस् र राउन्ड `down` (जस्तै अ keep्कहरू राख्नुहोस्)।
        // - रोक्नुहोस् र राउन्ड `up` (अन्तिम अंक बढाउनुहोस्) जब `scale < mant + plus` (वा `<=`)।
        // - अन्यथा उत्पादन जारी राख्नुहोस्।
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // हामीसँग छोटो प्रतिनिधित्व छ, राउन्डिंगमा अगाडि बढ्नुहोस्

        // आक्रमणकर्ताहरू पुनःस्थापना गर्नुहोस्।
        // यसले एल्गोरिदमलाई सँधै समाप्त गर्ने बनाउँदछ: `minus` र `plus` सँधै बढ्छ, तर `mant` क्लिप गरिएको मोडुलो `scale` र `scale` स्थिर गरिएको छ।
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // राउन्डिंग अप हुन्छ जब i) मात्र राउन्डिंग-अप अवस्था ट्रिगर गरिएको थियो, वा ii) दुबै सर्तहरू ट्रिगर गरियो र टाई ब्रेकिंग प्राथमिकताहरू मिलाउँदा।
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // यदि राउन्ड अपले लम्बाइ परिवर्तन गर्दछ, घाता also्क पनि परिवर्तन गर्नुपर्दछ।
        // यस्तो देखिन्छ कि यो अवस्था संतुष्ट गर्न धेरै गाह्रो छ (सम्भव सम्भव), तर हामी यहाँ मात्र सुरक्षित र एकरूप छौं।
        //
        // सुरक्षा: हामीले माथि त्यो मेमोरी आरम्भ गरेका छौं।
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // सुरक्षा: हामीले माथि त्यो मेमोरी आरम्भ गरेका छौं।
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// ड्र्यागनको लागि सहि र निश्चित मोड कार्यान्वयन।
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // `k_0` अनुमानित सक्कली इनपुट्सबाट सन्तोषजनक `10^(k_0-1) < v <= 10^(k_0+1)`।
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // `mant` लाई `10^k` द्वारा विभाजित गर्नुहोस्।अब `scale / 10 < mant <= scale * 10`।
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // फिक्सअप जब `mant + plus >= scale`, जहाँ `plus / scale = 10^-buf.len() / 2`।
    // फिक्स-साइज बिग्नुम राख्नको लागि, हामी वास्तवमै एक्स २०० एक्स प्रयोग गर्दछौं।
    // हामी वास्तवमै `scale` परिमार्जन गरिरहेका छैनौं, किनकि हामी यसको सट्टामा प्रारम्भिक गुणा छोड्न सक्छौं।
    // फेरि छोटो एल्गोरिथ्मको साथ, `d[0]` शून्य हुनसक्दछ तर अन्तत: राउन्ड अप हुन्छ।
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // १० द्वारा `scale` स्केल गर्ने बराबर
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // यदि हामी अन्तिम-अ lim्क सीमाका साथ काम गर्दैछौं भने, डबल राउन्डिंगबाट बच्नको लागि हामीले वास्तविक रेन्डरिंग गर्नु अघि बफरलाई छोटो पार्नु पर्छ।
    //
    // नोट गर्नुहोस् कि हामीले फेरी फेरि बफर विस्तार गर्नुपर्नेछ जब राउन्ड अप हुन्छ।
    let mut len = if k < limit {
        // ओहो, हामी *एक* अंक उत्पादन गर्न सक्दैनौं।
        // यो सम्भव छ जब, मानौं, हामीले 9.5 जस्तो केहि पाएकाछौं र यसलाई १० मा राउन्ड गरिँदै छ।
        // हामी खाली बफर फिर्ता गर्छौं, पछिल्लो राउन्डिंग-अप केसको अपवादको साथ जुन `k == limit` मा देखा पर्दछ र ठीक एक अ produce्कको उत्पादन गर्नुपर्दछ।
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // अंक उत्पादनको लागि क्यास `(2, 4, 8) * scale`।
        // (यो महँगो हुन सक्छ, त्यसैले बफर खाली हुँदा तिनीहरूको गणना नगर्नुहोस्।)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // निम्न अंकहरू सबै शून्यहरू हुन्, हामी यहाँ रोक्छौं *राउन्डिंग प्रदर्शन गर्न* कोसिस गर्नुहुन्न!बरु, बाँकी अंकहरू भर्नुहोस्।
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // सुरक्षा: हामीले माथि त्यो मेमोरी आरम्भ गरेका छौं।
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // राउन्ड अप यदि हामी अंकको बीचमा रोक्दछौं यदि निम्न अंकहरू ठ्याक्कै are००० छन् ..., पहिले अंक जाँच गर्नुहोस् र सम (to मा, अघिल्लो अंक बराबर हुँदा राउन्ड अप गर्नबाट बच्नुहोस्) को लागि पनि प्रयास गर्नुहोस्।
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // सुरक्षा: `buf[len-1]` सुरूवात गरिएको छ।
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // यदि राउन्ड अपले लम्बाइ परिवर्तन गर्दछ, घाता also्क पनि परिवर्तन गर्नुपर्दछ।
        // तर हामीलाई अंकहरूको एक निश्चित संख्यामा अनुरोध गरिएको छ, त्यसैले बफरलाई नबनाउनुहोस् ...
        // सुरक्षा: हामीले माथि त्यो मेमोरी आरम्भ गरेका छौं।
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... जबसम्म हामीलाई यसको सट्टा स्थिर प्रेसिजन अनुरोध गरिएको छैन।
            // हामीले यो पनि जाँच गर्नु पर्छ, यदि मूल बफर खाली थियो भने, अतिरिक्त अंक मात्र थप्न सकिन्छ जब `k == limit` (edge केस)।
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // सुरक्षा: हामीले माथि त्यो मेमोरी आरम्भ गरेका छौं।
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}