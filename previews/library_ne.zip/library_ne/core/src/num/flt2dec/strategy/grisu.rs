//! Grisu3 एल्गोरिथ्मको Rust अनुकूलन "प्रिन्टिंग फ्लोटिंग पोइन्ट नम्बरहरू द्रुत र सही साथ पूर्णांकहरू" मा वर्णन गरियो [^ १]।
//! यसले लगभग 1KB पूर्वप्रिय तालिका प्रयोग गर्दछ, र परिणाममा, यो धेरै इनपुटका लागि धेरै छिटो हुन्छ।
//!
//! [^1]: Florian Loitsch।२०१०. फ्लोटिंग-पोइन्ट नम्बरहरू छिटो प्रिन्ट गर्दै र
//!   सही पूर्णाgers्कको साथ।सिग्नल छैन।, 45, ((जून २०१०), २33-२43।।
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// तर्कको लागि `format_shortest_opt` मा टिप्पणीहरू हेर्नुहोस्।
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // १० **-i;e=** i, .०
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// `x > 0` दिइएको, `(k, 10^k)` यस्तो `10^k <= x < 10^(k+1)` फर्काउँछ।
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Grisu को लागी सब भन्दा छोटो मोड कार्यान्वयन।
///
/// यसले `None` फर्काउँछ जब यो अन्यथा एक सही प्रतिनिधित्व फिर्ता हुनेछ।
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // हामीलाई थप शुद्धताको कम्तिमा तीन बिट्स चाहिन्छ

    // साझा घाता .्कको साथ सामान्य मानको साथ सुरु गर्नुहोस्
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // कुनै `cached = 10^minusk` जस्तो कि `ALPHA <= minusk + plus.e + 64 <= GAMMA` फेला पार्नुहोस्।
    // किनकि `plus` सामान्यीकृत गरिएको छ, यसको मतलब `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // हाम्रो `ALPHA` र `GAMMA` को छनौट दिईयो, यसले `plus * cached` लाई `[4, 2^32)` मा राख्दछ।
    //
    // यो `GAMMA - ALPHA` अधिकतम गर्न स्पष्ट रूपले वांछनीय छ, ताकि हामीलाई १० को धेरै क्यास शक्तिहरू आवश्यक पर्दैन, तर त्यहाँ केही विचारहरू छन्:
    //
    //
    // 1. हामी `floor(plus * cached)` लाई `u32` भित्र राख्न चाहन्छौं किनकि यसलाई महँगो विभाजनको आवश्यकता छ।
    //    (यो वास्तवमै अपहेलना योग्य छैन, सटीकता अनुमानका लागि बाँकीको आवश्यक छ।)
    // 2.
    // `floor(plus * cached)` को बाँकी बारम्बार १० ले गुणा हुन्छ, र यो ओभरफ्लो हुनु हुँदैन।
    //
    // पहिलोले `64 + GAMMA <= 32` दिन्छ, जबकि दोस्रोले `10 * 2^-ALPHA <= 2^64` दिन्छ;
    // -60 र -32 यो अवरोधको साथ अधिकतम दायरा हो, र V8 पनि तिनीहरूलाई प्रयोग गर्दछ।
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // स्केल एफपीएस।यसले १ ulp को अधिकतम त्रुटि दिन्छ (प्रमेय 5.1 बाट प्रमाणित)।
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-शून्यको वास्तविक दायरा
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | १ ulp | १ ulp || १ ulp | १ ulp || १ ulp | १ ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // `minus` माथि, `v` र `plus`*quanised* अनुमानित (त्रुटि <1 ulp) हो।
    // जस्तो कि हामीलाई थाहा छैन त्रुटि सकरात्मक वा नकारात्मक हो, हामी दुई समानहरू बराबर दूरीमा प्रयोग गर्दछौं र २ ulps को अधिकतम त्रुटि छ।
    //
    // "unsafe region" उदार अन्तराल हो जुन हामीले सुरुमा उत्पन्न गर्छौं।
    // "safe region" एक रूढिवादी अन्तराल हो जुन हामी केवल स्वीकार गर्दछौं।
    // हामी असुरक्षित क्षेत्र भित्र सही repr को साथ शुरू गर्दछौं, र `v` को नजिकको repr खोज्न प्रयास गर्दछौं जुन सुरक्षित क्षेत्र भित्र पनि छ।
    // यदि हामी सक्दैनौं भने हामी छोडिदिन्छौं।
    //
    let plus1 = plus.f + 1;
    // plus0 = plus.f, १;//व्याख्याको लागि मात्र minus0 = minus.f + 1;//केवल व्याख्याको लागि
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // साझा घाता .्क

    // `plus1` लाई अभिन्न र आंशिक भागहरूमा विभाजन गर्नुहोस्।
    // अभिन्न अंगहरू u32 मा फिट हुने ग्यारेन्टी गरिएको छ, किनकि क्याच पावर `plus < 2^32` ग्यारेन्टी गर्दछ र सामान्य `plus.f` सटीक आवश्यकताको कारण सधैं `2^64 - 2^4` भन्दा कम हुन्छ।
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // `plus1` भन्दा अधिक ठूलो `10^max_kappa` गणना गर्नुहोस् (त्यसैले `plus1 < 10^(max_kappa+1)`)।
    // यो तल `kappa` को एक माथिल्लो सीमा छ।
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // प्रमेय 6.2: यदि `k` सबैभन्दा ठूलो पूर्णांक st हो भने
    // `0 <= y mod 10^k <= y - x`,              त्यसो भए `V = floor(y / 10^k) * 10^k` `[x, y]` मा छ र छोटो प्रतिनिधित्वहरू मध्ये एक (महत्वपूर्ण अंकको न्यूनतम संख्याको साथ) त्यो दायरामा छ।
    //
    //
    // `(minus1, plus1)` बीच प्रमेय 6.2 अनुसार अंक लम्बाई `kappa` फेला पार्नुहोस्।
    // प्रमेय 6.2 यसको सट्टामा `y mod 10^k < y - x` आवश्यक गरेर `x` लाई हटाउन अपनाउन सकिन्छ।
    // (उदाहरणका लागि, `x` =32000, `y` =32777; `kappa` =2 किनकि mod y मोड १० ^==7 777 <y, x=`77``।) एल्गोरिथ्म पछिल्लो प्रमाणिकरण चरणमा `y` निकाल्न निर्भर गर्दछ।
    //
    let delta1 = plus1 - minus1;
    // delta1int=(delta1>> e) लाई usize को रूपमा दिनुहोस्;//केवल व्याख्याको लागि
    let delta1frac = delta1 & ((1 << e) - 1);

    // अभिन्न भागहरू प्रस्तुत गर्नुहोस्, प्रत्येक चरणमा शुद्धता जाँच गर्दा।
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // अंकहरू अझै रेन्डर हुन बाँकी छ
    loop {
        // हामीसँग कम्तिमा कम्तिमा एउटा अंक रेन्डर गर्नका लागि हुन्छ, `plus1 >= 10^kappa` आक्रमणकारीहरूको रूपमाः
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (यसले `remainder = plus1int % 10^(kappa+1)` लाई पछ्याउँदछ)
        //
        //

        // `remainder` लाई `10^kappa` द्वारा विभाजित गर्नुहोस्।दुबै `2^-e` द्वारा मापन गरिएको छ।
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ कप्पा) * २ ^ ई
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; हामीले सह `kappa` X भेट्टायौं।
            let ten_kappa = (ten_kappa as u64) << e; // स्केल १० ^ kappa साझा घातामा फिर्ता
            return round_and_weed(
                // सुरक्षा: हामीले माथि त्यो मेमोरी आरम्भ गरेका छौं।
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // हामी सबै अभिन्न अंक रेन्डर गरेको छौं जब लूप ब्रेक।
        // अंकको सहि संख्या `max_kappa + 1` `plus1 < 10^(max_kappa+1)` को रूपमा छ।
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // आक्रमणकर्ताहरू पुनर्स्थापित गर्नुहोस्
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // आंशिक भागहरू प्रस्तुत गर्नुहोस्, प्रत्येक चरणमा शुद्धता जाँच गर्दा।
    // यस पटक हामी दोहोर्याइएको गुणनमा निर्भर गर्दछौं, किनकि डिभिजनले सटीक हराउनेछ।
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // अर्को अंक महत्त्वपूर्ण हुनुपर्दछ किनकी हामीले यो परीक्षण गरेका छौं कि आक्रमणकर्ताहरू बाहिर फूट्नु अघि, जहाँ `m = max_kappa + 1` (अभिन्न भागमा अंकहरूको#):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // बग्ने छैन, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // `remainder` लाई `10^kappa` द्वारा विभाजित गर्नुहोस्।
        // दुबै `2^e / 10^kappa` द्वारा स्केल गरिएको छ, त्यसैले पछि यहाँ निहित छ।
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // निहित विभाजक
            return round_and_weed(
                // सुरक्षा: हामीले माथि त्यो मेमोरी आरम्भ गरेका छौं।
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // आक्रमणकर्ताहरू पुनर्स्थापित गर्नुहोस्
        kappa -= 1;
        remainder = r;
    }

    // हामीले `plus1` का सबै महत्वपूर्ण अंकहरू उत्पन्न गरेका छौं, तर यकिन छैन कि यो अधिकतम हो कि होइन।
    // उदाहरणको लागि, यदि `minus1` 14.१15१33 छ ... र X0१X 3..१14१88 हो ..., त्यहाँ different भिन्न छोटो प्रतिनिधित्वहरू छन् 3.14154 बाट 3.14158 मा तर हामीसँग मात्र सब भन्दा ठूलो छ।
    // हामीले क्रमिक रूपमा अन्तिम अंक कम गर्नुपर्नेछ र जाँच गर्नुहोस् कि यदि यो इष्टतम repr हो।
    // त्यहाँ कम्तिमा candidates जना उम्मेदवारहरू छन् (.. १ देखि २।), त्यसैले यो एकदम छिटो छ।("rounding" चरण)
    //
    // प्रकार्यले जाँच गर्दछ कि यदि यो "optimal" repr वास्तवमा ulp दायरा भित्र छ, र साथै, यो सम्भव छ कि "second-to-optimal" repr वास्तवमा राउन्डिंग त्रुटिका कारण इष्टतम हुन सक्छ।
    // कुनै पनि केसहरूमा यसले `None` फर्काउँछ।
    // ("weeding" चरण)
    //
    // यहाँ सबै आर्गुमेन्टहरू साझा (तर निहित) मान `k` द्वारा मापन गरिएको छ, जसले गर्दा:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (र पनि, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (र पनि, `threshold > plus1v` पूर्व आक्रमणकारीहरूबाट)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // `v` X (xx2X) लाई 1.5 ulps भित्र दुई अनुमानित उत्पादन गर्दछ।
        // परिणामस्वरूप प्रतिनिधित्व दुबैको नजीकको प्रतिनिधित्व हुनुपर्दछ।
        //
        // यहाँ `plus1 - v` प्रयोग गरिएको छ किनकि overflow/underflow लाई सम्बोधन गर्न गणनाहरू `plus1` बाट गरिन्छ (त्यसैले यस्तो देखिन्छ जस्तो लागी बदल्ने नामहरू)।
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, १ ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + १ उल्ट)

        // अन्तिम अंक घटाउनुहोस् र `v + 1 ulp` को नजिकको प्रतिनिधित्वमा रोक्नुहोस्।
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // हामी अनुमानित अंक `w(n)` सँग काम गर्छौं जुन सुरुमा `plus1 - plus1 % 10^kappa` बराबर हुन्छ।लूप बडी `n` पटक चलाए पछि, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // हामीले `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` सेट गर्नुभयो (त्यसैले `शेष= plus1w(0)`) चेकहरू सरलीकृत गर्न।
            // नोट गर्नुहोस् कि `plus1w(n)` सँधै बढ्दो छ।
            //
            // हामीसँग समाप्त गर्न तीन शर्तहरू छन्।तिनीहरू मध्ये कुनैले पनि लूपलाई अगाडि बढ्न असमर्थ बनाउँदछ, तर हामी पनी कम्तिमा एउटा मान्य प्रतिनिधित्व `v + 1 ulp` लाई नजिकको रूपमा पनि जानिन्छ।
            // हामी तिनीहरूलाई दर्साउँदछौं TC1 को माध्यम बाट TC3 मार्फत।
            //
            // TC1: `w(n) <= v + 1 ulp`, अर्थात्, यो अन्तिम repr हो जुन नजिकको हो।
            // यो `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up` को बराबर हो।
            // TC2 का साथ संयुक्त (जसले `w(n+1)` is valid) जाँच गर्दछ भने, यसले `plus1w(n)` को गणनामा सम्भावित ओभरफ्लोलाई रोक्दछ।
            //
            // TC2: `w(n+1) < minus1`, अर्थात्, अर्को repr निश्चित रूपमा `v` मा राउन्ड गर्दैन।
            // यो `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold` को बराबर हो।
            // बाँया पट्टि ओभरफ्लो हुन सक्छ, तर हामी `threshold > plus1v` जान्छौं, त्यसैले यदि TC1 गलत छ, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` र हामी X103X सट्टामा सुरक्षित रूपमा परीक्षण गर्न सक्छौं।
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, अर्थात्, अर्को repr हो
            // वर्तमान repr भन्दा `v + 1 ulp` नजिक छैन।
            // `z(n) = plus1v_up - plus1w(n)` दिइयो, यो `abs(z(n)) <= abs(z(n+1))` हुन्छ।फेरि TC1 गलत छ भनेर मान्दै, हामीसंग `z(n) > 0` छ।हामीले विचार गर्नुपर्ने दुईवटा केसहरू छन्:
            //
            // - जब `z(n+1) >= 0`: TC3 `z(n) <= z(n+1)` हुन्छ।
            // `plus1w(n)` बढ्दै जाँदा, `z(n)` घट्दै हुनुपर्दछ र यो स्पष्ट छ।
            // - जब `z(n+1) < 0`:
            //   - TC3a: पूर्व शर्त `plus1v_up < plus1w(n) + 10^kappa` हो।TC2 लाई मानौं गलत छ, `threshold >= plus1w(n) + 10^kappa` ताकि यो ओभरफ्लो हुन सक्दैन।
            //   - TC3b: TC3 `z(n) <= -z(n+1)` हुन्छ, अर्थात्, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   अस्वीकृत TC1 ले `plus1v_up > plus1w(n)` दिन्छ, त्यसैले यो TC3a को साथ जोडेको बगैंचामा वा बगैंचा बग्न सक्दैन।
            //
            // यसको परिणाम स्वरूप हामीले `TC1 || TC2 || (TC3a && TC3b)` रोक्नु पर्छ।निम्न यसको विपरित बराबर छ, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // सब भन्दा छोटो रिप्रेटर `0` का साथ अन्त्य हुन सक्दैन
                plus1w += ten_kappa;
            }
        }

        // जाँच गर्नुहोस् कि यदि यो प्रतिनिधित्व पनि `v - 1 ulp` मा नजिकको प्रतिनिधित्व हो।
        //
        // यो केवल `v + 1 ulp` को लागि टर्मिनेटि to शर्तहरूसँग समान छ, सबै `plus1v_up` यसको सट्टामा `plus1v_down` द्वारा प्रतिस्थापित गरियो।
        // ओभरफ्लो विश्लेषण पनि त्यस्तै होल्ड।
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // अब हामीसँग `plus1` र `minus1` बीचको `v` को नजीक प्रतिनिधित्व छ।
        // यो धेरै उदार हो, यद्यपि, हामी `plus0` र `minus0`, अर्थात, `plus1 - plus1w(n) <= minus0` वा `plus1 - plus1w(n) >= plus0` बीचमा कुनै `w(n)` अस्वीकृत गर्दछौं।
        // हामी `threshold = plus1 - minus1` र `plus1 - plus0 = minus0 - minus1 = 2 ulp` तथ्यहरु को उपयोग गर्छौं।
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// ड्र्यागन फलब्याकको साथ ग्रिसुको लागि छोटो मोड कार्यान्वयन।
///
/// यो प्राय जसो केसहरूको लागि प्रयोग गर्नुपर्दछ।
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // सुरक्षा: उधारो जाँचकर्ता हामीलाई `buf` प्रयोग गर्न पर्याप्त स्मार्ट छैन
    // दोस्रो branch मा, त्यसैले हामी यहाँ जीवनकाल लुन्डिंग।
    // तर हामी केवल `buf` पुन: प्रयोग गर्छौं यदि `format_shortest_opt` `None` फिर्ता गर्दछ त्यसैले यो ठीक छ।
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Grisu को लागि सहि र निश्चित मोड कार्यान्वयन।
///
/// यसले `None` फर्काउँछ जब यो अन्यथा एक सही प्रतिनिधित्व फिर्ता हुनेछ।
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // हामीलाई थप शुद्धताको कम्तिमा तीन बिट्स चाहिन्छ
    assert!(!buf.is_empty());

    // सामान्य बनाउनुहोस् र `v` मापन गर्नुहोस्।
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // `v` लाई अभिन्न र आंशिक भागहरूमा विभाजन गर्नुहोस्।
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // दुबै पुरानो `v` र नयाँ `v` (`10^-k` द्वारा स्केल गरिएको) <1 ulp (प्रमेय 5.1) को त्रुटि छ।
    // जस्तो कि हामीलाई थाहा छैन त्रुटि सकरात्मक वा नकारात्मक हो, हामी दुई समानहरू बराबर दूरीमा प्रयोग गर्दछौं र अधिकतम त्रुटि २ ulps (छोटो केसमा समान) हुन्छ।
    //
    //
    // लक्ष्य भनेको अंकको ठीक गोलो श्रृंखला पत्ता लगाउनु हो जुन दुबै `v - 1 ulp` र `v + 1 ulp` मा सामान्य छन्, ताकि हामी अधिकतम विश्वास गर्न सकौं।
    // यदि यो सम्भव छैन भने,`v` X को लागि कुन सही आउटपुट हो भनेर हामीलाई थाहा छैन, त्यसैले हामी छोडिदिन्छौं र पछाडि झर्छौं।
    //
    // `err` यहाँ `1 ulp * 2^e` को रूपमा परिभाषित गरिएको छ (`vfrac` मा ulp समान), र हामी यसलाई मापन गर्नेछौं जब `v` मापन हुन्छ।
    //
    //
    //
    let mut err = 1;

    // `v` भन्दा अधिक ठूलो `10^max_kappa` गणना गर्नुहोस् (त्यसैले `v < 10^(max_kappa+1)`)।
    // यो तल `kappa` को एक माथिल्लो सीमा छ।
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // यदि हामी अन्तिम-अ lim्क सीमाका साथ काम गर्दैछौं भने, डबल राउन्डिंगबाट बच्नको लागि हामीले वास्तविक रेन्डरिंग गर्नु अघि बफरलाई छोटो पार्नु पर्छ।
    //
    // नोट गर्नुहोस् कि हामीले फेरी फेरि बफर विस्तार गर्नुपर्नेछ जब राउन्ड अप हुन्छ।
    let len = if exp <= limit {
        // ओहो, हामी *एक* अंक उत्पादन गर्न सक्दैनौं।
        // यो सम्भव छ जब, मानौं, हामीले 9.5 जस्तो केहि पाएकाछौं र यसलाई १० मा राउन्ड गरिँदै छ।
        //
        // सिद्धान्तमा हामी तुरून्त `possibly_round` कल गर्न सक्दछ खाली बफरको साथ, तर १० द्वारा `max_ten_kappa << e` मापन गर्दा ओभरफ्लो हुन सक्छ।
        //
        // यसैले हामी यहाँ मैला भइरहेका छौं र १० को गुणक द्वारा त्रुटि दायरा चौडा गर्ने।
        // यसले गलत नकारात्मक दर बढाउँदछ, तर केवल धेरै,*थोरै*;
        // जब केवल म्यान्टिसा b० बिट्स भन्दा ठूलो हुन्छ यो मात्र ध्यान दिन सक्दछ।
        //
        // सुरक्षा: `len=0`, त्यसैले यो स्मृति आरम्भको बाध्यता तुच्छ हो।
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // अभिन्न अंग रेन्डर गर्नुहोस्।
    // त्रुटि पूर्ण आंशिक हो, त्यसैले हामीले यसलाई यस भागमा जाँच गर्नुपर्दैन।
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // अंकहरू अझै रेन्डर हुन बाँकी छ
    loop {
        // हामीसँग सधैँ कम्तिमा पनि एक अंकको हुन्छ आक्रमकहरू प्रस्तुत गर्नका लागि:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (यसले `remainder = vint % 10^(kappa+1)` लाई पछ्याउँदछ)
        //
        //

        // `remainder` लाई `10^kappa` द्वारा विभाजित गर्नुहोस्।दुबै `2^-e` द्वारा मापन गरिएको छ।
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // बफर भरिएको छ?बाँकीको साथ राउन्डिंग पास चलाउनुहोस्।
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% १० ^ कप्पा) * २ ^ ई
            // सुरक्षा: हामीले `len` धेरै बाइट्स आरम्भ गरेका छौं।
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // हामी सबै अभिन्न अंक रेन्डर गरेको छौं जब लूप ब्रेक।
        // अंकको सहि संख्या `max_kappa + 1` `plus1 < 10^(max_kappa+1)` को रूपमा छ।
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // आक्रमणकर्ताहरू पुनर्स्थापित गर्नुहोस्
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // भिन्नात्मक भाग रेन्डर गर्नुहोस्।
    //
    // सिद्धान्तमा हामी अन्तिम उपलब्ध अंकमा जारी राख्न सक्छौं र शुद्धताको लागि जाँच गर्न सक्छौं।
    // दुर्भाग्यवश हामी परिमित आकारको पूर्णा with्कसँग काम गरिरहेका छौं, त्यसैले अतिप्रवाह पत्ता लगाउन हामीलाई केही मापदण्डको आवश्यकता छ।
    // V8 `remainder > err` प्रयोग गर्दछ, जुन गलत हुन्छ जब `v - 1 ulp` र `v` को पहिलो `i` महत्वपूर्ण अंक भिन्न हुन्छन्।
    // यद्यपि यो धेरै अन्यथा मान्य इनपुट अस्वीकार गर्दछ।
    //
    // पछिल्लो चरणको सही ओभरफ्लो पहिचान भएदेखि हामी थप सख्त मापदण्ड प्रयोग गर्दछौं।
    // हामी Til `err` `10^kappa / 2` भन्दा बढि जारी राख्छौं, ताकि `v - 1 ulp` र `v + 1 ulp` बीचको दायरामा निश्चित रूपमा दुई वा अधिक गोल प्रतिनिधित्वहरू समावेश गर्दछ।
    //
    // यो सन्दर्भका लागि `possibly_round` बाट पहिलेका दुई तुलनाहरूसँग मिल्दोजुल्दो छ।
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // आक्रमणकर्ताहरू, जहाँ `m = max_kappa + 1` (अभिन्न भागमा अंकहरूको#):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // बग्ने छैन, `2^e * 10 < 2^64`
        err *= 10; // बग्ने छैन, `err * 10 < 2^e * 5 < 2^64`

        // `remainder` लाई `10^kappa` द्वारा विभाजित गर्नुहोस्।
        // दुबै `2^e / 10^kappa` द्वारा स्केल गरिएको छ, त्यसैले पछि यहाँ निहित छ।
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // बफर भरिएको छ?बाँकीको साथ राउन्डिंग पास चलाउनुहोस्।
        if i == len {
            // सुरक्षा: हामीले `len` धेरै बाइट्स आरम्भ गरेका छौं।
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // आक्रमणकर्ताहरू पुनर्स्थापित गर्नुहोस्
        remainder = r;
    }

    // थप गणना बेकार छ (`possibly_round` निश्चित रूपमा असफल), त्यसैले हामी हार मान्छौं।
    return None;

    // हामीले `v` का सबै अनुरोधित अंकहरू उत्पन्न गरेका छौं जुन `v - 1 ulp` को स digit्ख्यक अंकसँग समान हुनुपर्दछ।
    // अब हामी जाँच गर्छौं कि `v - 1 ulp` 1X र `v + 1 ulp` दुबै साझेदारी गरिएको एक अद्वितीय प्रतिनिधित्व छ कि छैन;यो या त उत्पन्न अंकहरूमा समान हुन सक्छ, वा ती अंकहरूको राउन्ड-अप संस्करणमा।
    //
    // यदि दायरामा समान लम्बाईको बहु प्रतिनिधित्व समावेश छ भने हामी निश्चित हुन सक्दैनौं र यसको सट्टा `None` फर्काउनु पर्छ।
    //
    // यहाँ सबै आर्गुमेन्टहरू साझा (तर निहित) मान `k` द्वारा मापन गरिएको छ, जसले गर्दा:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // सुरक्षा: `buf` को पहिलो `len` बाइट आरम्भ हुनु पर्छ।
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | १ ulp | १ ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (सन्दर्भको लागि, डटेड रेखाले अंकको दिइएको संख्यामा सम्भावित प्रतिनिधित्वहरूको लागि सहि मूल्य दर्शाउँछ।)
        //
        //
        // त्रुटि धेरै ठूलो छ कि त्यहाँ `v - 1 ulp` र `v + 1 ulp` बीच कम्तिमा तीन सम्भावित प्रतिनिधित्वहरू छन्।
        // कुन सहि छ भनेर हामी निर्धारित गर्न सक्दैनौं।
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | १ ulp | १ ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // वास्तवमा, 1/2 ulp दुई सम्भावित प्रतिनिधित्वहरू परिचय गर्न पर्याप्त छ।
        // (याद गर्नुहोस् कि हामीलाई दुबै `v - 1 ulp` र `v + १ उल्टाको लागि अद्वितीय प्रतिनिधित्व चाहिन्छ।) यो ओभरफ्लो हुने छैन, पहिलो चेकबाट `ulp < ten_kappa` को रूपमा।
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------१० ^ कप्पा---------->:
        //     | :   |                           :
        //     | १ ulp | १ ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // यदि `v + 1 ulp` राउन्ड-डाउन प्रतिनिधित्वको नजिक छ (जुन पहिले नै `buf` मा छ), तब हामी सुरक्षित रूपमा फर्कन सक्दछौं।
        // नोट गर्नुहोस् कि `v - 1 ulp` * वर्तमान प्रतिनिधित्व भन्दा कम हुन सक्छ, तर `1 ulp < 10^kappa / 2` को रूपमा, यो सर्त पर्याप्त छ:
        // `v - 1 ulp` र वर्तमान प्रतिनिधित्व बीचको दूरी `10^kappa / 2` भन्दा बढी हुन सक्दैन।
        //
        // अवस्था `remainder + ulp < 10^kappa / 2` बराबर छ।
        // किनकि यसले सजिलैसँग ओभरफ्लो गर्न सक्छ, पहिले जाँच गर्नुहोस् कि `remainder < 10^kappa / 2`।
        // हामीले पहिले नै त्यो `ulp < 10^kappa / 2` प्रमाणित गरिसकेका छौं, जबसम्म `10^kappa` पछि नहटाइन्छ, दोस्रो चेक ठीक छ।
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // सुरक्षा: हाम्रो कलरले त्यो मेमोरी आरम्भ गर्‍यो।
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------शेष------> |:
        //   :                          |   :
        //   : <---------१० ^ कप्पा--------->:
        //   :                    |     |   : |
        //   : | १ ulp | १ ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // अर्कोतर्फ, यदि `v - 1 ulp` राउन्ड-अप प्रतिनिधित्वको नजिक छ भने, हामीले राउन्ड अप गरेर फर्कनु पर्छ।
        // उही कारणका लागि हामीले `v + 1 ulp` जाँच गर्न आवश्यक पर्दैन।
        //
        // अवस्था `remainder - ulp >= 10^kappa / 2` बराबर छ।
        // फेरी हामी पहिले `remainder > ulp` जाँच गर्छौं (ध्यान दिनुहोस् कि यो `remainder >= ulp` होईन, किनकि `10^kappa` कहिल्यै शून्य हुँदैन)।
        //
        // नोट गर्नुहोस् कि `remainder - ulp <= 10^kappa`, त्यसैले दोस्रो चेक अतिप्रवाह हुँदैन।
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // सुरक्षा: हाम्रो कलरले त्यो मेमोरी आरम्भ गरेको हुनुपर्दछ।
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // एक अतिरिक्त अंक मात्र थप्नुहोस् जब हामीलाई स्थिर सटीक अनुरोध गरिएको छ।
                // हामीले यो पनि जाँच गर्नु पर्छ, यदि मूल बफर खाली थियो भने, अतिरिक्त अंक मात्र थप्न सकिन्छ जब `exp == limit` (edge केस)।
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // सुरक्षा: हामी र हाम्रो कलरले त्यो मेमोरी आरम्भ गर्‍यो।
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // अन्यथा हामी डूममेड छौं (उदाहरणका लागि, `v - 1 ulp` र `v + 1 ulp` बीचको केहि मानहरू राउन्ड गर्दै छन् र अरू राउन्ड अप गर्दै छन्) र छोडिन्छ।
        //
        None
    }
}

/// ड्र्यागन फलब्याकको साथ ग्रिसुको लागि सहि र स्थिर मोड कार्यान्वयन।
///
/// यो प्राय जसो केसहरूको लागि प्रयोग गर्नुपर्दछ।
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // सुरक्षा: उधारो जाँचकर्ता हामीलाई `buf` प्रयोग गर्न पर्याप्त स्मार्ट छैन
    // दोस्रो branch मा, त्यसैले हामी यहाँ जीवनकाल लुन्डिंग।
    // तर हामी केवल `buf` पुन: प्रयोग गर्छौं यदि `format_exact_opt` `None` फिर्ता गर्दछ त्यसैले यो ठीक छ।
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}