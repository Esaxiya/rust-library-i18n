/*!

Floating-point number to decimal conversion routines.

# Problem statement

We are given the floating-point number `v = f * 2^e` with an integer `f`,
and its bounds `minus` and `plus` such that any number between `v - minus` and
`v + plus` will be rounded to `v`. For the simplicity we assume that
this range is exclusive. Then we would like to get the unique decimal
representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero.

- It's correctly rounded when parsed back: `v - minus < V < v + plus`.
  Furthermore it is shortest such one, i.e., there is no representation
  with less than `n` digits that is correctly rounded.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Note that
  there might be two representations satisfying this uniqueness requirement,
  in which case some tie-breaking mechanism is used.

We will call this mode of operation as to the *shortest* mode. This mode is used
when there is no additional constraint, and can be thought as a "natural" mode
as it matches the ordinary intuition (it at least prints `0.1f32` as "0.1").

We have two more modes of operation closely related to each other. In these modes
we are given either the number of significant digits `n` or the last-digit
limitation `limit` (which determines the actual `n`), and we would like to get
the representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero, unless `n` was zero in which case only `k` is returned.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Again,
  there might be some tie-breaking mechanism.

When `limit` is given but not `n`, we set `n` such that `k - n = limit`
so that the last digit `d[n-1]` is scaled by `10^(k-n) = 10^limit`.
If such `n` is negative, we clip it to zero so that we will only get `k`.
We are also limited by the supplied buffer. This limitation is used to print
the number up to given number of fractional digits without knowing
the correct `k` beforehand.

We will call the mode of operation requiring `n` as to the *exact* mode,
and one requiring `limit` as to the *fixed* mode. The exact mode is a subset of
the fixed mode: the sufficiently large last-digit limitation will eventually fill
the supplied buffer and let the algorithm to return.

# Implementation overview

It is easy to get the floating point printing correct but slow (Russ Cox has
[demonstrated](http://research.swtch.com/ftoa) how it's easy), or incorrect but
fast (naïve division and modulo). But it is surprisingly hard to print
floating point numbers correctly *and* efficiently.

There are two classes of algorithms widely known to be correct.

- The "Dragon" family of algorithm is first described by Guy L. Steele Jr. and
  Jon L. White. They rely on the fixed-size big integer for their correctness.
  A slight improvement was found later, which is posthumously described by
  Robert G. Burger and R. Kent Dybvig. David Gay's `dtoa.c` routine is
  a popular implementation of this strategy.

- The "Grisu" family of algorithm is first described by Florian Loitsch.
  They use very cheap integer-only procedure to determine the close-to-correct
  representation which is at least guaranteed to be shortest. The variant,
  Grisu3, actively detects if the resulting representation is incorrect.

We implement both algorithms with necessary tweaks to suit our requirements.
In particular, published literatures are short of the actual implementation
difficulties like how to avoid arithmetic overflows. Each implementation,
available in `strategy::dragon` and `strategy::grisu` respectively,
extensively describes all necessary justifications and many proofs for them.
(It is still difficult to follow though. You have been warned.)

Both implementations expose two public functions:

- `format_shortest(decoded, buf)`, which always needs at least
  `MAX_SIG_DIGITS` digits of buffer. Implements the shortest mode.

- `format_exact(decoded, buf, limit)`, which accepts as small as
  one digit of buffer. Implements exact and fixed modes.

They try to fill the `u8` buffer with digits and returns the number of digits
written and the exponent `k`. They are total for all finite `f32` and `f64`
inputs (Grisu internally falls back to Dragon if necessary).

The rendered digits are formatted into the actual string form with
four functions:

- `to_shortest_str` prints the shortest representation, which can be padded by
  zeroes to make *at least* given number of fractional digits.

- `to_shortest_exp_str` prints the shortest representation, which can be
  padded by zeroes when its exponent is in the specified ranges,
  or can be printed in the exponential form such as `1.23e45`.

- `to_exact_exp_str` prints the exact representation with given number of
  digits in the exponential form.

- `to_exact_fixed_str` prints the fixed representation with *exactly*
  given number of fractional digits.

They all return a slice of preallocated `Part` array, which corresponds to
the individual part of strings: a fixed string, a part of rendered digits,
a number of zeroes or a small (`u16`) number. The caller is expected to
provide a large enough buffer and `Part` array, and to assemble the final
string from resulting `Part`s itself.

All algorithms and formatting functions are accompanied by extensive tests
in `coretests::num::flt2dec` module. It also shows how to use individual
functions.

*/

// जबकि यो विस्तृत रूपमा कागजात गरिएको छ, यो सिद्धान्त निजी हो जुन परीक्षणको लागि मात्र सार्वजनिक गरिएको छ।
// हामीलाई पर्दाफास नगर्नुहोस्।
#![doc(hidden)]
#![unstable(
    feature = "flt2dec",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

pub use self::decoder::{decode, DecodableFloat, Decoded, FullDecoded};

use crate::mem::MaybeUninit;

pub mod decoder;
pub mod estimator;

/// डिजिट-जेनरेशन एल्गोरिदमहरू।
pub mod strategy {
    pub mod dragon;
    pub mod grisu;
}

/// सब भन्दा छोटो मोडको लागि आवश्यक बफरको न्यूनतम आकार।
///
/// यो निकाल्नको लागि यो अलि तुच्छ छ, तर यो छोटो परिणामको साथ एल्गोरिदम ढाँचाबाट महत्वपूर्ण दशमलव अ of्कको अधिकतम संख्या हो।
///
/// सही सूत्र `ceil(# bits in mantissa * log_10 2 + 1)` हो।
pub const MAX_SIG_DIGITS: usize = 17;

/// जब `d` ले दशमलव अंक समावेश गर्दछ, अन्तिम अंक बढाउनुहोस् र क्यारी प्रचार गर्नुहोस्।
/// अर्को अंक फिर्ता गर्दछ जब यो लम्बाई परिवर्तन गर्न को कारण।
#[doc(hidden)]
pub fn round_up(d: &mut [u8]) -> Option<u8> {
    match d.iter().rposition(|&c| c != b'9') {
        Some(i) => {
            // d [i + 1..n] सबै नाइनहरू हो
            d[i] += 1;
            for j in i + 1..d.len() {
                d[j] = b'0';
            }
            None
        }
        None if d.len() > 0 => {
            // 999..999 बढाइ घाता .को साथ १०००..०० मा राउन्ड
            d[0] = b'1';
            for j in 1..d.len() {
                d[j] = b'0';
            }
            Some(b'0')
        }
        None => {
            // खाली बफर राउन्ड अप (अलि अनौंठो तर व्यावहारिक)
            Some(b'1')
        }
    }
}

/// स्वरूपित भागहरू।
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Part<'a> {
    /// शून्य अंकहरूको संख्या दिइयो।
    Zero(usize),
    /// 5 अंक सम्म शाब्दिक संख्या।
    Num(u16),
    /// दिइएको बाइट्सको एक शाब्दिक प्रतिलिपि।
    Copy(&'a [u8]),
}

impl<'a> Part<'a> {
    /// दिइएको भागको ठीक बाइट लम्बाइ फर्काउँछ।
    pub fn len(&self) -> usize {
        match *self {
            Part::Zero(nzeroes) => nzeroes,
            Part::Num(v) => {
                if v < 1_000 {
                    if v < 10 {
                        1
                    } else if v < 100 {
                        2
                    } else {
                        3
                    }
                } else {
                    if v < 10_000 { 4 } else { 5 }
                }
            }
            Part::Copy(buf) => buf.len(),
        }
    }

    /// आपूर्ति बफरमा एक अंश लेख्छ।
    /// लिखित बाइट्स, वा `None` को संख्या फर्काउँछ यदि बफर पर्याप्त छैन।
    /// (यसले अझै पनि बफरमा आंशिक रूपमा लेखिएको बाइट्स छोड्न सक्छ; यसमा भरोसा नगर्नुहोस्।)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        let len = self.len();
        if out.len() >= len {
            match *self {
                Part::Zero(nzeroes) => {
                    for c in &mut out[..nzeroes] {
                        *c = b'0';
                    }
                }
                Part::Num(mut v) => {
                    for c in out[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                }
                Part::Copy(buf) => {
                    out[..buf.len()].copy_from_slice(buf);
                }
            }
            Some(len)
        } else {
            None
        }
    }
}

/// एक वा धेरै भागहरू समावेश ढाँचा परिणाम।
/// यो बाइट बफरमा लेख्न सकिन्छ वा आवंटित स्ट्रि toमा रूपान्तरण गर्न सकिन्छ।
#[allow(missing_debug_implementations)]
#[derive(Clone)]
pub struct Formatted<'a> {
    /// एक बाइट स्लाइस चिन्ह प्रतिनिधित्व गर्दै, या त `""`, `"-"` वा `"+"`।
    pub sign: &'static str,
    /// फर्म्याट भागहरू साइन र वैकल्पिक शून्य प्याडि after पछि रेन्डर गर्न।
    pub parts: &'a [Part<'a>],
}

impl<'a> Formatted<'a> {
    /// संयुक्त स्वरूपित परिणामको ठीक बाइट लम्बाइ फर्काउँछ।
    pub fn len(&self) -> usize {
        let mut len = self.sign.len();
        for part in self.parts {
            len += part.len();
        }
        len
    }

    /// आपूर्ति गरिएको बफरमा सबै स्वरूपित भागहरू लेख्दछ।
    /// लिखित बाइट्स, वा `None` को संख्या फर्काउँछ यदि बफर पर्याप्त छैन।
    /// (यसले अझै पनि बफरमा आंशिक रूपमा लेखिएको बाइट्स छोड्न सक्छ; यसमा भरोसा नगर्नुहोस्।)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < self.sign.len() {
            return None;
        }
        out[..self.sign.len()].copy_from_slice(self.sign.as_bytes());

        let mut written = self.sign.len();
        for part in self.parts {
            let len = part.write(&mut out[written..])?;
            written += len;
        }
        Some(written)
    }
}

/// स्वरूप दशमलव अंकहरू `0.<...buf...> * 10^exp` दशमलव फारममा दिइएको कम्तिमा अंशात्मक अंकको संख्या दिइएको।
///
/// परिणाम आपूर्ति गरिएको भागहरू एर्रेमा भण्डार गरिएको छ र लिखित भागहरूको टुक्रा फिर्ता हुन्छ।
///
/// `frac_digits` `buf` मा वास्तविक आंशिक अंकको संख्या भन्दा कम हुन सक्छ;
/// यसलाई बेवास्ता गरिनेछ र पूर्ण अंकहरू मुद्रित हुनेछन्।रेन्डर गरिएको अंकहरू पछि यो अतिरिक्त शून्य प्रिन्ट गर्न मात्र प्रयोग गरिन्छ।
/// यसैले ० को `frac_digits` यसको मतलब यो दिईएको अंकहरू मात्र प्रिन्ट गर्दछ र अरू केहि पनि होइन।
///
fn digits_to_dec_str<'a>(
    buf: &'a [u8],
    exp: i16,
    frac_digits: usize,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 4);

    // यदि त्यहाँ अन्तिम अंक स्थितिमा प्रतिबन्ध छ भने, `buf` भर्चुअल शून्यको साथ बाँया प्याडेड मानिन्छ।
    // भर्चुअल शून्यको संख्या, `nzeroes`, `max(0, exp + frac_digits - buf.len())` बराबर, ताकि अन्तिम अंक `exp - buf.len() - nzeroes` को स्थिति `-frac_digits` भन्दा बढि हो:
    //
    //
    //                       |<-virtual->|
    //       | <----बुफ----> |शून्य |समाप्ति
    //    0. १ २ 4 5 6 7 8 9 X _ _ _ _ _ _ x 10
    //    |                  |           |
    // १० ^ मिति 10^(exp-buf.len()) 10^(exp-buf.len()-nzeroes)
    //
    // `nzeroes` अतिप्रवाहबाट बच्न प्रत्येक केसका लागि व्यक्तिगत रूपमा गणना गरिन्छ।
    //

    if exp <= 0 {
        // दशमलव बिन्दु रेन्डर गरिएको अंक भन्दा पहिले हो: [0.][000...000][1234][____]
        let minus_exp = -(exp as i32) as usize;
        parts[0] = MaybeUninit::new(Part::Copy(b"0."));
        parts[1] = MaybeUninit::new(Part::Zero(minus_exp));
        parts[2] = MaybeUninit::new(Part::Copy(buf));
        if frac_digits > buf.len() && frac_digits - buf.len() > minus_exp {
            parts[3] = MaybeUninit::new(Part::Zero((frac_digits - buf.len()) - minus_exp));
            // सुरक्षा: हामीले भर्खरै एलिमेन्ट्स `..4` आरम्भ गरेका छौं।
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
        } else {
            // सुरक्षा: हामीले भर्खरै एलिमेन्ट्स `..3` आरम्भ गरेका छौं।
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
        }
    } else {
        let exp = exp as usize;
        if exp < buf.len() {
            // दशमलव बिन्दु रेन्डर गरिएको अंक भित्र हुन्छ: [12][.][34][____]
            parts[0] = MaybeUninit::new(Part::Copy(&buf[..exp]));
            parts[1] = MaybeUninit::new(Part::Copy(b"."));
            parts[2] = MaybeUninit::new(Part::Copy(&buf[exp..]));
            if frac_digits > buf.len() - exp {
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits - (buf.len() - exp)));
                // सुरक्षा: हामीले भर्खरै एलिमेन्ट्स `..4` आरम्भ गरेका छौं।
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // सुरक्षा: हामीले भर्खरै एलिमेन्ट्स `..3` आरम्भ गरेका छौं।
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
            }
        } else {
            // दशमलव बिन्दु रेन्डर गरिएको अंक पछि हो: [1234][____0000] वा [1234][__][.][__]।
            parts[0] = MaybeUninit::new(Part::Copy(buf));
            parts[1] = MaybeUninit::new(Part::Zero(exp - buf.len()));
            if frac_digits > 0 {
                parts[2] = MaybeUninit::new(Part::Copy(b"."));
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits));
                // सुरक्षा: हामीले भर्खरै एलिमेन्ट्स `..4` आरम्भ गरेका छौं।
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // सुरक्षा: हामीले भर्खरै एलिमेन्ट्स `..2` आरम्भ गरेका छौं।
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) }
            }
        }
    }
}

/// दिइएको दशमलव अंक `0.<...buf...> * 10^exp` लाई घाता .्क फारममा रूपान्तरण गर्दछ कम्तिमा दिईएको महत्त्वपूर्ण संख्याको संख्याको साथ।
///
/// जब `upper` `true` हो, घाता X्ग `E` द्वारा उपसर्ग हुनेछ;अन्यथा त्यो `e` हो।
/// परिणाम आपूर्ति गरिएको भागहरू एर्रेमा भण्डार गरिएको छ र लिखित भागहरूको टुक्रा फिर्ता हुन्छ।
///
/// `min_digits` `buf` मा वास्तविक महत्वपूर्ण अंकको संख्या भन्दा कम हुन सक्छ;
/// यसलाई बेवास्ता गरिनेछ र पूर्ण अंकहरू मुद्रित हुनेछन्।रेन्डर गरिएको अंकहरू पछि यो अतिरिक्त शून्य प्रिन्ट गर्न मात्र प्रयोग गरिन्छ।
/// यसैले, `min_digits == 0` यसको मतलब यो दिईएको अंकहरू मात्र प्रिन्ट गर्दछ र अरू केहि पनि होइन।
///
fn digits_to_exp_str<'a>(
    buf: &'a [u8],
    exp: i16,
    min_ndigits: usize,
    upper: bool,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 6);

    let mut n = 0;

    parts[n] = MaybeUninit::new(Part::Copy(&buf[..1]));
    n += 1;

    if buf.len() > 1 || min_ndigits > 1 {
        parts[n] = MaybeUninit::new(Part::Copy(b"."));
        parts[n + 1] = MaybeUninit::new(Part::Copy(&buf[1..]));
        n += 2;
        if min_ndigits > buf.len() {
            parts[n] = MaybeUninit::new(Part::Zero(min_ndigits - buf.len()));
            n += 1;
        }
    }

    // 0.1234 x १० ^ म्याद= 1.234 x १० exp (समाप्ति १)
    let exp = exp as i32 - 1; // एक्सपोर एक्स १०० हुँदा अन्डरफ्लोबाट बच्नुहोस्
    if exp < 0 {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E-" } else { b"e-" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(-exp as u16));
    } else {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E" } else { b"e" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(exp as u16));
    }
    // सुरक्षा: हामीले भर्खरै एलिमेन्ट्स `..n + 2` आरम्भ गरेका छौं।
    unsafe { MaybeUninit::slice_assume_init_ref(&parts[..n + 2]) }
}

/// विकल्प ढाँचामा चिन्ह लगाउनुहोस्।
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Sign {
    /// Intsणात्मक गैर-शून्य मानहरूको लागि मात्र `-` प्रिन्ट गर्दछ।
    Minus, // -inf -1 0 0 1 inf नान
    /// `-` प्रिन्ट गर्नुहोस् कुनै पनि नकारात्मक मानहरूको लागि (नकारात्मक शून्य सहित)।
    MinusRaw, // -inf -1 -0 0 1 inf नान
    /// Xणात्मक गैर-शून्य मानहरूको लागि `-`, वा अन्यथा `+` प्रिन्ट गर्दछ।
    MinusPlus, // -inf -1 + ० + ० +१ + इन्फान नान
    /// कुनै पनि नकारात्मक मानहरू (नकारात्मक शून्य सहित), वा `+` अन्यथा प्रिन्ट गर्दछ।
    MinusPlusRaw, // -inf -1 -0 + ० +१ + inf नान
}

/// ढाँचामा हुन साइनको अनुरूप स्थिर बाइट स्ट्रिंग फर्काउँछ।
/// यो या त `""`, `"+"` वा `"-"` हुन सक्छ।
fn determine_sign(sign: Sign, decoded: &FullDecoded, negative: bool) -> &'static str {
    match (*decoded, sign) {
        (FullDecoded::Nan, _) => "",
        (FullDecoded::Zero, Sign::Minus) => "",
        (FullDecoded::Zero, Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (FullDecoded::Zero, Sign::MinusPlus) => "+",
        (FullDecoded::Zero, Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
        (_, Sign::Minus | Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (_, Sign::MinusPlus | Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
    }
}

/// दिइएको फ्लोटिंग पोइन्ट नम्बरलाई दशमलव फारममा रूपान्तरण गर्दछ कम्तिमा दिइएको अंशात्मक अंकको संख्यामा।
/// परिणाम एक आपूर्ति को रूपमा आपूर्ति एर्रेमा भण्डारण गरिएको छ जबकि एक स्क्र्याचको रूपमा दिए बाइट बफर प्रयोग।
/// `upper` हाल प्रयोग नगरिएको छ तर Z-future0Z निर्णयलाई बाँकी छ गैर-सीमित मानहरू, उदाहरणका लागि, `inf` र `nan` को केस परिवर्तन गर्न।
///
/// रेन्डर गरिने पहिलो भाग सँधै `Part::Sign` (यदि खाली रेखांकन हुन सक्दछ यदि कुनै चिन्ह रेन्डर गरिएको छैन)।
///
/// `format_shortest` अन्तर्निहित डिजिट-जेनेसन फंक्शन हुनुपर्छ।
/// यसले सुरूवात गरेको बफरको अंश फिर्ता गर्नुपर्दछ।
/// तपाई सायद यसको लागि `strategy::grisu::format_shortest` चाहानुहुन्छ।
///
/// `frac_digits` `v` मा वास्तविक आंशिक अंकको संख्या भन्दा कम हुन सक्छ;
/// यसलाई बेवास्ता गरिनेछ र पूर्ण अंकहरू मुद्रित हुनेछन्।रेन्डर गरिएको अंकहरू पछि यो अतिरिक्त शून्य प्रिन्ट गर्न मात्र प्रयोग गरिन्छ।
/// यसैले ० को `frac_digits` यसको मतलब यो दिईएको अंकहरू मात्र प्रिन्ट गर्दछ र अरू केहि पनि होइन।
///
/// बाइट बफर कम्तिमा `MAX_SIG_DIGITS` बाइट लामो हुनुपर्छ।
/// त्यहाँ कम्तिमा parts भागहरू उपलब्ध हुनुपर्दछ, `frac_digits = 10` सँग `[+][0.][0000][2][0000]` जस्ता खराब स्थितिका कारण।
///
///
///
pub fn to_shortest_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);
    assert!(buf.len() >= MAX_SIG_DIGITS);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // सुरक्षा: हामीले भर्खरै एलिमेन्ट्स `..1` लाई आरम्भ गरेका छौं।
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // सुरक्षा: हामीले भर्खरै एलिमेन्ट्स `..1` लाई आरम्भ गरेका छौं।
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // सुरक्षा: हामीले भर्खरै एलिमेन्ट्स `..2` आरम्भ गरेका छौं।
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // सुरक्षा: हामीले भर्खरै एलिमेन्ट्स `..1` लाई आरम्भ गरेका छौं।
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
        }
    }
}

/// दिईएको फ्लोटिंग पोइन्ट नम्बरलाई दशमलव फारम वा घाताential्कीय फारममा ढाँचा, परिणामस्वरूप निर्णायक मा निर्भर गर्दछ।
/// परिणाम एक आपूर्ति को रूपमा आपूर्ति एर्रेमा भण्डारण गरिएको छ जबकि एक स्क्र्याचको रूपमा दिए बाइट बफर प्रयोग।
/// `upper` गैर-परिमित मान (`inf` र `nan`) वा घाता .्क उपसर्ग (`e` वा `E`) को मामला निर्धारण गर्न प्रयोग गरिन्छ।
/// रेन्डर गरिने पहिलो भाग सँधै `Part::Sign` (यदि खाली रेखांकन हुन सक्दछ यदि कुनै चिन्ह रेन्डर गरिएको छैन)।
///
/// `format_shortest` अन्तर्निहित डिजिट-जेनेसन फंक्शन हुनुपर्छ।
/// यसले सुरूवात गरेको बफरको अंश फिर्ता गर्नुपर्दछ।
/// तपाई सायद यसको लागि `strategy::grisu::format_shortest` चाहानुहुन्छ।
///
/// `dec_bounds` एक tuple `(lo, hi)` यस्तो छ कि संख्या दशमलव रूपमा ढाँचा जब `10^lo <= V < 10^hi` मात्र।
/// नोट गर्नुहोस् कि यो वास्तविक `v` को सट्टा * ** `V` हो!यस प्रकार घाता form्कीय फारममा कुनै पनि मुद्रित घाता this्क यस दायरामा हुन सक्दैन, कुनै गडबड बेवास्ता गर्दै।
///
///
/// बाइट बफर कम्तिमा `MAX_SIG_DIGITS` बाइट लामो हुनुपर्छ।
/// त्यहाँ कम्तिमा parts भागहरू उपलब्ध हुनुपर्दछ, `[+][1][.][2345][e][-][6]` जस्ता खराब स्थितिका कारण।
///
///
///
///
///
pub fn to_shortest_exp_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    dec_bounds: (i16, i16),
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(dec_bounds.0 <= dec_bounds.1);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // सुरक्षा: हामीले भर्खरै एलिमेन्ट्स `..1` लाई आरम्भ गरेका छौं।
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // सुरक्षा: हामीले भर्खरै एलिमेन्ट्स `..1` लाई आरम्भ गरेका छौं।
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            parts[0] = if dec_bounds.0 <= 0 && 0 < dec_bounds.1 {
                MaybeUninit::new(Part::Copy(b"0"))
            } else {
                MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }))
            };
            // सुरक्षा: हामीले भर्खरै एलिमेन्ट्स `..1` लाई आरम्भ गरेका छौं।
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            let vis_exp = exp as i32 - 1;
            let parts = if dec_bounds.0 as i32 <= vis_exp && vis_exp < dec_bounds.1 as i32 {
                digits_to_dec_str(buf, exp, 0, parts)
            } else {
                digits_to_exp_str(buf, exp, 0, upper, parts)
            };
            Formatted { sign, parts }
        }
    }
}

/// दिइएको डिकोड गरिएको घाता .्कबाट गणना गरिएको अधिकतम बफर साइजको लागि बरु क्रूड सन्निकरण (माथिल्लो बाउन्ड) फर्काउँछ।
///
/// सहि सीमा छ:
///
/// - जब `exp < 0`, अधिकतम लम्बाई `ceil(log_10 (5^-exp * (2^64 - 1)))` हो।
/// - जब `exp >= 0`, अधिकतम लम्बाई `ceil(log_10 (2^exp * (2^64 - 1)))` हो।
///
/// `ceil(log_10 (x^exp * (2^64 - 1)))` `ceil(log_10 (2^64 - 1)) + ceil(exp *log_10 x)` भन्दा कम हो, जुन `20 + (1 + exp* log_10 x)` भन्दा कममा बदल्दै छ।
/// हामी तथ्यहरू प्रयोग गर्छौं जुन `log_10 2 < 5/16` र `log_10 5 < 12/16`, जुन हाम्रो उद्देश्यका लागि पर्याप्त छ।
///
/// हामीलाई किन यो चाहिन्छ?`format_exact` प्रकार्यहरू पछिल्लो अंक प्रतिबन्ध द्वारा सीमित नभएसम्म सम्पूर्ण बफर भरिन्छ, तर यस्तो सम्भव छ कि अनुरोध गरिएको अंकहरूको संख्या हास्यास्पद रूपमा ठूलो छ (मानौं, ,000०,००० अंक)।
///
/// बफरको विशाल बहुमत शून्यले भरिने छ, त्यसैले हामी पहिले नै सबै बफर आवंटित गर्न चाहँदैनौं।
/// फलस्वरूप, कुनै पनि आर्गुमेन्टहरूको लागि,
/// बफरको 6२6 बाइट्स `f64` को लागी पर्याप्त हुनुपर्छ।सबैभन्दा खराब अवस्थाको लागि वास्तविक संख्यासँग तुलना गर्नुहोस्: 7070० बाइट्स (जब `exp = -1074`)।
///
///
///
///
///
fn estimate_max_buf_len(exp: i16) -> usize {
    21 + ((if exp < 0 { -12 } else { 5 } * exp as i32) as usize >> 4)
}

/// घाता point बिन्दु संख्यालाई घाता form्क फारममा दिइन्छ महत्त्वपूर्ण अंकको ठीकसँग दिइएको संख्यासँग।
/// परिणाम एक आपूर्ति को रूपमा आपूर्ति एर्रेमा भण्डारण गरिएको छ जबकि एक स्क्र्याचको रूपमा दिए बाइट बफर प्रयोग।
/// `upper` घाता .्क उपसर्ग (`e` वा `E`) को मामला निर्धारण गर्न प्रयोग गरिन्छ।
/// रेन्डर गरिने पहिलो भाग सँधै `Part::Sign` (यदि खाली रेखांकन हुन सक्दछ यदि कुनै चिन्ह रेन्डर गरिएको छैन)।
///
/// `format_exact` अन्तर्निहित डिजिट-जेनेसन फंक्शन हुनुपर्छ।
/// यसले सुरूवात गरेको बफरको अंश फिर्ता गर्नुपर्दछ।
/// तपाई सायद यसको लागि `strategy::grisu::format_exact` चाहानुहुन्छ।
///
/// बाइट बफर कम्तिमा `ndigits` बाइट लामो हुनुपर्दछ जबसम्म `ndigits` ठूलो छैन कि केवल अ only्कहरूको स्थिर संख्या मात्र लेखिन्छ।
/// (`f64` का लागि टिपिंग पोइन्ट लगभग 800०० छ, त्यसैले १००० बाइट्स पर्याप्त हुनुपर्दछ।) कम्तिमा parts भागहरू उपलब्ध हुनुपर्दछ, `[+][1][.][2345][e][-][6]` जस्ता खराब अवस्थाका कारण।
///
///
///
///
///
pub fn to_exact_exp_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    ndigits: usize,
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(ndigits > 0);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // सुरक्षा: हामीले भर्खरै एलिमेन्ट्स `..1` लाई आरम्भ गरेका छौं।
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // सुरक्षा: हामीले भर्खरै एलिमेन्ट्स `..1` लाई आरम्भ गरेका छौं।
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if ndigits > 1 {
                // [0.][0000][e0]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(ndigits - 1));
                parts[2] = MaybeUninit::new(Part::Copy(if upper { b"E0" } else { b"e0" }));
                Formatted {
                    sign,
                    // सुरक्षा: हामीले भर्खरै एलिमेन्ट्स `..3` आरम्भ गरेका छौं।
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }));
                Formatted {
                    sign,
                    // सुरक्षा: हामीले भर्खरै एलिमेन्ट्स `..1` लाई आरम्भ गरेका छौं।
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= ndigits || buf.len() >= maxlen);

            let trunc = if ndigits < maxlen { ndigits } else { maxlen };
            let (buf, exp) = format_exact(decoded, &mut buf[..trunc], i16::MIN);
            Formatted { sign, parts: digits_to_exp_str(buf, exp, ndigits, upper, parts) }
        }
    }
}

/// दशमलव फाराममा फ्लोटि of पोइन्ट नम्बर दिईएको फोरमेन्टल अंकहरूको ठीक दिइएको संख्यासँग ढाँचा।
/// परिणाम एक आपूर्ति को रूपमा आपूर्ति एर्रेमा भण्डारण गरिएको छ जबकि एक स्क्र्याचको रूपमा दिए बाइट बफर प्रयोग।
/// `upper` हाल प्रयोग नगरिएको छ तर Z-future0Z निर्णयलाई बाँकी छ गैर-सीमित मानहरू, उदाहरणका लागि, `inf` र `nan` को केस परिवर्तन गर्न।
/// रेन्डर गरिने पहिलो भाग सँधै `Part::Sign` (यदि खाली रेखांकन हुन सक्दछ यदि कुनै चिन्ह रेन्डर गरिएको छैन)।
///
/// `format_exact` अन्तर्निहित डिजिट-जेनेसन फंक्शन हुनुपर्छ।
/// यसले सुरूवात गरेको बफरको अंश फिर्ता गर्नुपर्दछ।
/// तपाई सायद यसको लागि `strategy::grisu::format_exact` चाहानुहुन्छ।
///
/// बाइट बफर आउटपुटको लागि पर्याप्त हुनुपर्दछ जबसम्म `frac_digits` यति ठूलो छैन कि केवल अ only्कहरूको स्थिर संख्या मात्र लेखिन्छ।
/// (`f64` का लागि टिपिंग पोइन्ट लगभग 800०० हो, र १००० बाइट्स पर्याप्त हुनुपर्दछ।) कम्तिमा parts भागहरू उपलब्ध हुनुपर्दछ, `frac_digits = 10` को साथ `[+][0.][0000][2][0000]` जस्ता खराब अवस्थाको कारण।
///
///
///
///
///
pub fn to_exact_fixed_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // सुरक्षा: हामीले भर्खरै एलिमेन्ट्स `..1` लाई आरम्भ गरेका छौं।
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // सुरक्षा: हामीले भर्खरै एलिमेन्ट्स `..1` लाई आरम्भ गरेका छौं।
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // सुरक्षा: हामीले भर्खरै एलिमेन्ट्स `..2` आरम्भ गरेका छौं।
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // सुरक्षा: हामीले भर्खरै एलिमेन्ट्स `..1` लाई आरम्भ गरेका छौं।
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= maxlen);

            // यो * सम्भव छ कि `frac_digits` हास्यास्पद ठूलो छ।
            // `format_exact` यस अवस्थामा धेरै भन्दा पहिले रेन्डरिंग अंकहरूको अन्त्य हुनेछ, किनकि हामी `maxlen` द्वारा कडा रूपमा सीमित छौं।
            //
            let limit = if frac_digits < 0x8000 { -(frac_digits as i16) } else { i16::MIN };
            let (buf, exp) = format_exact(decoded, &mut buf[..maxlen], limit);
            if exp <= limit {
                // प्रतिबन्ध भेट्न सकिएन, त्यसैले यो शून्यको रूपमा प्रस्तुत गर्नु पर्दछ `exp` कुनै फरक पर्दैन।
                // यसमा समावेश छैन कि अन्तिम राउन्ड अप पछि मात्र प्रतिबन्ध पूरा भयो;यो `exp = limit + 1` को साथ नियमित मामला हो।
                //
                debug_assert_eq!(buf.len(), 0);
                if frac_digits > 0 {
                    // [0.][0000]
                    parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                    parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                    Formatted {
                        sign,
                        // सुरक्षा: हामीले भर्खरै एलिमेन्ट्स `..2` आरम्भ गरेका छौं।
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                    }
                } else {
                    parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                    Formatted {
                        sign,
                        // सुरक्षा: हामीले भर्खरै एलिमेन्ट्स `..1` लाई आरम्भ गरेका छौं।
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                    }
                }
            } else {
                Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
            }
        }
    }
}