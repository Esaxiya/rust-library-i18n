//! `f32` एकल-परिशुद्धता फ्लोटिंग पोइन्ट प्रकारको लागि निर्दिष्ट।
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! `consts` उप-मोड्युलमा गणितीय रूपमा महत्त्वपूर्ण संख्या प्रदान गरियो।
//!
//! यस मोड्युलमा सिधा परिभाषित स्थिरहरूको लागि (`consts` उप-मोड्युलमा परिभाषित ती भन्दा फरक), नयाँ कोडले सट्टा `f32` प्रकारमा सिधा परिभाषित सम्बन्धित कन्स्टन्टहरूको प्रयोग गर्नुपर्दछ।
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// रेडिक्स वा `f32` को आन्तरिक प्रतिनिधित्वको आधार।
/// यसको सट्टामा [`f32::RADIX`] प्रयोग गर्नुहोस्।
///
/// # Examples
///
/// ```rust
/// // अस्वीकृत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // इच्छित तरिका
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// आधार २ मा महत्वपूर्ण अंकहरूको संख्या।
/// यसको सट्टामा [`f32::MANTISSA_DIGITS`] प्रयोग गर्नुहोस्।
///
/// # Examples
///
/// ```rust
/// // अस्वीकृत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // इच्छित तरिका
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// आधार १० मा महत्वपूर्ण अंकहरूको अनुमानित संख्या।
/// यसको सट्टामा [`f32::DIGITS`] प्रयोग गर्नुहोस्।
///
/// # Examples
///
/// ```rust
/// // अस्वीकृत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // इच्छित तरिका
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] `f32` को लागी मान।
/// यसको सट्टामा [`f32::EPSILON`] प्रयोग गर्नुहोस्।
///
/// यो `1.0` र अर्को ठूलो प्रतिनिधित्व संख्या बीचको भिन्नता हो।
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // अस्वीकृत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // इच्छित तरिका
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// सबैभन्दा सानो परिमित `f32` मान।
/// यसको सट्टामा [`f32::MIN`] प्रयोग गर्नुहोस्।
///
/// # Examples
///
/// ```rust
/// // अस्वीकृत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // इच्छित तरिका
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// सबैभन्दा सानो सकारात्मक सामान्य `f32` मान।
/// यसको सट्टामा [`f32::MIN_POSITIVE`] प्रयोग गर्नुहोस्।
///
/// # Examples
///
/// ```rust
/// // अस्वीकृत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // इच्छित तरिका
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// सबैभन्दा ठूलो परिमित `f32` मान।
/// यसको सट्टामा [`f32::MAX`] प्रयोग गर्नुहोस्।
///
/// # Examples
///
/// ```rust
/// // अस्वीकृत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // इच्छित तरिका
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// २ घाता .को न्यूनतम सम्भावित सामान्य पावर भन्दा ठूलो।
/// यसको सट्टामा [`f32::MIN_EXP`] प्रयोग गर्नुहोस्।
///
/// # Examples
///
/// ```rust
/// // अस्वीकृत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // इच्छित तरिका
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// २ घाता .्कको अधिकतम सम्भव उर्जा।
/// यसको सट्टामा [`f32::MAX_EXP`] प्रयोग गर्नुहोस्।
///
/// # Examples
///
/// ```rust
/// // अस्वीकृत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // इच्छित तरिका
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// १० घाता .्कको न्यूनतम सम्भव सामान्य उर्जा।
/// यसको सट्टामा [`f32::MIN_10_EXP`] प्रयोग गर्नुहोस्।
///
/// # Examples
///
/// ```rust
/// // अस्वीकृत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // इच्छित तरिका
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// १० घाता .्कको अधिकतम सम्भव उर्जा।
/// यसको सट्टामा [`f32::MAX_10_EXP`] प्रयोग गर्नुहोस्।
///
/// # Examples
///
/// ```rust
/// // अस्वीकृत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // इच्छित तरिका
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// नम्बर (NaN) हैन।
/// यसको सट्टामा [`f32::NAN`] प्रयोग गर्नुहोस्।
///
/// # Examples
///
/// ```rust
/// // अस्वीकृत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // इच्छित तरिका
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// अनन्त (∞)।
/// यसको सट्टामा [`f32::INFINITY`] प्रयोग गर्नुहोस्।
///
/// # Examples
///
/// ```rust
/// // अस्वीकृत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // इच्छित तरिका
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// नकरात्मक अनन्त (−∞)।
/// यसको सट्टामा [`f32::NEG_INFINITY`] प्रयोग गर्नुहोस्।
///
/// # Examples
///
/// ```rust
/// // अस्वीकृत तरीका
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // इच्छित तरिका
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// आधारभूत गणितीय स्थिरता।
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: cmath बाट गणितीय स्थिरहरु को साथ बदल्नुहोस्।

    /// आर्किमिडीजको स्थिर (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// पूर्ण सर्कल स्थिर (τ)
    ///
    /// 2π बराबर।
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// Euler को संख्या (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// रेडिक्स वा `f32` को आन्तरिक प्रतिनिधित्वको आधार।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// आधार २ मा महत्वपूर्ण अंकहरूको संख्या।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// आधार १० मा महत्वपूर्ण अंकहरूको अनुमानित संख्या।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] `f32` को लागी मान।
    ///
    /// यो `1.0` र अर्को ठूलो प्रतिनिधित्व संख्या बीचको भिन्नता हो।
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// सबैभन्दा सानो परिमित `f32` मान।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// सबैभन्दा सानो सकारात्मक सामान्य `f32` मान।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// सबैभन्दा ठूलो परिमित `f32` मान।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// २ घाता .को न्यूनतम सम्भावित सामान्य पावर भन्दा ठूलो।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// २ घाता .्कको अधिकतम सम्भव उर्जा।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// १० घाता .्कको न्यूनतम सम्भव सामान्य उर्जा।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// १० घाता .्कको अधिकतम सम्भव उर्जा।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// नम्बर (NaN) हैन।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// अनन्त (∞)।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// नकरात्मक अनन्त (−∞)।
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// `true` फिर्ता गर्दछ यदि यो मान `NaN` हो।
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` पोर्टेबिलिटीको बारेमा चिन्ताको कारण लिबकोरमा सार्वजनिक रूपमा अनुपलब्ध छ, त्यसैले यो कार्यान्वयन आन्तरिक रूपमा निजी प्रयोगको लागि हो।
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// `true` फर्काउँछ यदि यो मान सकरात्मक अनन्तता वा नकारात्मक अनन्तता हो, र अन्यथा `false`।
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// `true` फर्काउँछ यदि यो संख्या न त असीम हो न `NaN` हो।
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // NaN लाई छुट्टै ह्यान्डल गर्न आवश्यक छैन: यदि स्वयं NaN हो भने, तुलना सही जस्तो छैन, ठीक जस्तो छैन।
        //
        self.abs_private() < Self::INFINITY
    }

    /// यदि नम्बर [subnormal] हो भने `true` फर्काउँछ।
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // `0` र `min` को बीच मानहरू सामान्य हो।
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// `true` फर्काउँछ यदि संख्या शुन्य, असीम, [subnormal], वा `NaN` होईन।
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // `0` र `min` को बीच मानहरू सामान्य हो।
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// नम्बरको फ्लोटिंग पोइन्ट कोटी फर्काउँछ।
    /// यदि केवल एक सम्पत्ती परीक्षण गर्न जाँदैछ भने, यसको सट्टा विशेष प्रेडिकेट प्रयोग गर्न यो छिटो हुन्छ।
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// `true` फर्काउँछ यदि `self` सँग सकरात्मक चिह्न छ, `+0.0` सहित, `NaN`s साईनिट बिट र सकारात्मक इन्फिनिटीको साथ।
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// `true` फर्काउँछ यदि `self` सँग नकारात्मक संकेत छ, `-0.0` सहित, negative NaN`s negativeणात्मक चिन्ह बिट र नकारात्मक इन्फिनिटीको साथ।
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // आईईई 75754 ले भन्छ: isSignMinus(x) सही हो यदि र x मा नकारात्मक संकेत छ भने मात्र।
        // isSignMinus शून्य र NaNs मा पनि लागू हुन्छ।
        self.to_bits() & 0x8000_0000 != 0
    }

    /// नम्बरको पारस्परिक (inverse) लिन्छ, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// रेडियनहरूलाई डिग्रीमा बदल्छ।
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // राम्रो परिशुद्धताका लागि स्थिर प्रयोग गर्नुहोस्।
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// डिग्रीलाई रेडियनमा रूपान्तरण गर्दछ।
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// दुई संख्याको अधिकतम फर्काउँछ।
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// यदि एउटा आर्गुमेन्ट NaN हो भने, अर्को आर्गुमेन्ट फिर्ता हुन्छ।
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// दुई संख्याको न्यूनतम फर्काउँछ।
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// यदि एउटा आर्गुमेन्ट NaN हो भने, अर्को आर्गुमेन्ट फिर्ता हुन्छ।
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// शून्य तर्फ राउन्ड र कुनै पनि आदिम पूर्णा type्क प्रकारमा रूपान्तरण गर्छ, मान मापदण्ड छ कि मान परिमित छ र त्यस प्रकार मा फिट छ।
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// मान हुनु पर्छ:
    ///
    /// * `NaN` नहुनुहोस्
    /// * असीम नहुनुहोस्
    /// * यसको आंशिक भाग काटेर पछि, फिर्ती प्रकार `Int` मा प्रतिनिधित्व गर्नुहोस्
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // सुरक्षा: कलरले `FloatToInt::to_int_unchecked` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ।
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// `u32` मा कच्चा ट्रान्समिटेशन।
    ///
    /// यो हाल सबै प्लेटफर्महरूमा `transmute::<f32, u32>(self)` सँग मिल्दोजुल्दो छ।
    ///
    /// यस अपरेशनको पोर्टेबिलिटीको बारेमा छलफलको लागि `from_bits` हेर्नुहोस् (लगभग कुनै समस्याहरू छैनन्)।
    ///
    /// नोट गर्नुहोस् कि यो प्रकार्य `as` कास्टिंग भन्दा भिन्न छ, जसले *संख्यात्मक* मानलाई बचाउन कोसिस गर्दछ, र बिटवाइज मानलाई गर्दैन।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() कास्टिंग छैन!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // सुरक्षा: `u32` सादा पुरानो डाटाटाइप हो त्यसैले हामी त्यसलाई सँधै ट्रान्समिट गर्न सक्दछौं
        unsafe { mem::transmute(self) }
    }

    /// `u32` बाट कच्चा ट्रान्समिटेशन।
    ///
    /// यो हाल सबै प्लेटफर्महरूमा `transmute::<u32, f32>(v)` सँग मिल्दोजुल्दो छ।
    /// यो दुई कारणका लागि अविश्वसनीय रूपले पोर्टेबल हो भन्ने पता लाग्छ:
    ///
    /// * सबै समर्थित प्लेटफर्महरूमा फ्लोट्स र ईन्ट्सको समान समापन हुन्छ।
    /// * आईईईई 75 754 एकदमै फ्लोटको बिट रूपरेखा निर्दिष्ट गर्दछ।
    ///
    /// जबकि त्यहाँ एक चेतावनी छ: आईईईई 75 754 को २०० version संस्करण अघि, कसरी NaN सN्केतन बिटको व्याख्या गर्ने भनेर निर्दिष्ट गरिएको थिएन।
    /// धेरै प्लेटफर्महरू (विशेष गरी x86 र एआरएम) ले व्याख्यालाई छान्छ जुन अन्ततः २०० 2008 मा मानकीकरण गरिएको थियो, तर केहीले (विशेष रूपमा MIP) गरेन।
    /// नतिजा स्वरूप, MIPS मा सबै सaling्केतन NaNs x86 मा शान्त NaNs, र यसको विपरित हो।
    ///
    /// सिग्नलिंग-नेस क्रस-प्लेटफर्मलाई संरक्षण गर्ने प्रयास गर्नुको सट्टा, यो कार्यान्वयनले सहि बिट्सलाई संरक्षण गर्ने पक्षमा गर्दछ।
    /// यसको मतलब यो छ कि NaNs मा स enc्केतन भएका कुनै पनि पेलोडहरू सुरक्षित गरिनेछन् यदि यस विधिको नतीजा नेटवर्क मार्फत x86 मेशिनबाट MIPS एकमा पठाइयो भने।
    ///
    ///
    /// यदि यस विधिका परिणामहरू उही वास्तुकलाले मात्र उनीहरूलाई उत्पादन गर्दछ भने मात्र हेरफेर गर्न मिल्दैन।
    ///
    /// यदि इनपुट NaN हैन भने, त्यहाँ कुनै पोर्टेबिलिटी चिन्ता छैन।
    ///
    /// यदि तपाइँ सिग्नलिनेसको बारेमा मतलब गर्नुहुन्न (धेरै सम्भावित), त्यसो भए त्यहाँ पोर्टेबिलिटी चिन्ता छैन।
    ///
    /// नोट गर्नुहोस् कि यो प्रकार्य `as` कास्टिंग भन्दा भिन्न छ, जसले *संख्यात्मक* मानलाई बचाउन कोसिस गर्दछ, र बिटवाइज मानलाई गर्दैन।
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // सुरक्षा: `u32` सादा पुरानो डाटाटाइप हो त्यसैले हामी यसलाई सँधै ट्रान्समिट गर्न सक्दछौं
        // यो sNaN का साथ सुरक्षा मुद्दाहरूलाई ओझेलमा पर्यो!हुर्रे!
        unsafe { mem::transmute(v) }
    }

    /// यस फ्लोटिंग पोइन्ट नम्बरको मेमोरी प्रतिनिधित्व बिग एन्डियन (network) बाइट क्रममा बाइट एर्रेको रूपमा फर्काउनुहोस्।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// यस अस्थायी बिन्दु संख्याको मेमोरी प्रतिनिधित्व कम-एन्डियन बाइट क्रममा बाइट एर्रेको रूपमा फिर्ता गर्नुहोस्।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// नेटिभ बाइट क्रममा बाइट एर्रेको रूपमा यस फ्लोटिंग पोइन्ट नम्बरको मेमोरी प्रतिनिधित्व फर्काउनुहोस्।
    ///
    /// लक्षित प्लेटफर्मको मूल endianness को रूप मा, पोर्टेबल कोड को सट्टा [`to_be_bytes`] वा [`to_le_bytes`], उचित को रूप मा प्रयोग गर्नु पर्छ।
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// नेटिभ बाइट क्रममा बाइट एर्रेको रूपमा यस फ्लोटिंग पोइन्ट नम्बरको मेमोरी प्रतिनिधित्व फर्काउनुहोस्।
    ///
    ///
    /// [`to_ne_bytes`] सम्भव भएसम्म यस भन्दा बढि चाहिन्छ।
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // सुरक्षा: `f32` सादा पुरानो डाटाटाइप हो त्यसैले हामी त्यसलाई सँधै ट्रान्समिट गर्न सक्दछौं
        unsafe { &*(self as *const Self as *const _) }
    }

    /// ठूलो इन्डियनमा बाइट एर्रेको रूपमा यसको प्रतिनिधित्वबाट फ्लोटिंग पोइन्ट मान सिर्जना गर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// सानो इन्डियनमा बाइट एर्रेको रूपमा यसको प्रतिनिधित्वबाट फ्लोटिंग पोइन्ट मान सिर्जना गर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// नेटिभ एन्डियनमा बाइट एरेको रूपमा यसको प्रतिनिधित्वबाट फ्लोटिंग पोइन्ट मान सिर्जना गर्नुहोस्।
    ///
    /// लक्ष्य प्लेटफर्मको मूल endianness को रूप मा प्रयोग गरिएको छ, पोर्टेबल कोड सम्भवतः उपयुक्त को रूप मा, [`from_be_bytes`] वा [`from_le_bytes`] प्रयोग गर्न चाहन्छ।
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// स्वयं र अन्य मानहरू बीच अर्डर फर्काउँछ।
    /// फ्लोटिंग पोइन्ट नम्बरहरूको बीचको आंशिक तुलनाको विपरीत, यो तुलना सँधै आईईईई 75 754 (२०० 2008 संशोधन) फ्लोटिंग प्वाइन्ट मानकमा परिभाषित गरीएको कुल अर्डर प्रेडिकेट अनुसार आदेश सिर्जना गर्दछ।
    /// मानहरू निम्न क्रममा क्रमबद्ध गरिएको छ:
    /// - नकारात्मक शान्त NaN
    /// - नकरात्मक सaling्केतन NaN
    /// - नकारात्मक अनन्तता
    /// - नकरात्मक संख्या
    /// - नकारात्मक सब्नोर्मल नम्बरहरू
    /// - नकारात्मक शून्य
    /// - सकारात्मक शून्य
    /// - सकारात्मक सब्नोर्मल नम्बरहरू
    /// - सकारात्मक संख्याहरू
    /// - सकारात्मक अनन्तता
    /// - सकारात्मक स sign्केतन NaN
    /// - सकारात्मक शान्त NaN
    ///
    /// नोट गर्नुहोस् कि यो प्रकार्य XX1X र [`PartialEq`] कार्यान्वयनको साथ सधैं सहमत हुँदैन।विशेष रूपमा, तिनीहरू नकारात्मक र सकारात्मक शून्यलाई बराबर मान्दछन्, जबकि `total_cmp` ले गर्दैन।
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // नेगेटिभको मामलामा, दुईको पूरक पूर्णांकको रूपमा समान लेआउट प्राप्त गर्न साइन बाहेक सबै बिटहरू फ्लिप गर्नुहोस्
        //
        // किन यो काम गर्दछ?आईईईई 75 754 फ्लोटहरूमा तीन क्षेत्र हुन्छन्:
        // साईन बिट, घाता .्क र मन्टिस्साघातांक र मन्टिसा क्षेत्रको समग्रमा सम्पत्ति छ कि तिनीहरूको बिटवाईज अर्डर संख्यात्मक परिमाणमा बराबर छ जहाँ परिमाण परिभाषित गरिएको छ।
        // परिमाण सामान्यतया NaN मानहरूमा परिभाषित हुँदैन, तर आईईईई 75 754 टोटल अर्डरले बिटवाइज अर्डरलाई पछ्याउन एनएएन मानहरू पनि परिभाषित गर्दछ।यसले कागजात टिप्पणीमा व्याख्या गरिएको अर्डरमा पुर्‍याउँछ।
        // जबकि, परिमाणको प्रतिनिधित्व नकारात्मक र सकारात्मक संख्याहरूको लागि समान हो-केवल साइन बिट भिन्न छ।
        // फ्लोट्सलाई सजिलैसँग हस्ताक्षरित पूर्णा we्कको रूपमा तुलना गर्न, हामीले घाता .्क र मन्टिसा बिट्स फ्लिप गर्नु पर्छ नकारात्मक नम्बरहरूको मामलामा।
        // हामी संख्यालाई "two's complement" फारममा प्रभावकारी रूपमा रूपान्तरण गर्दछौं।
        //
        // फ्लिपिंग गर्न हामी यसको विरुद्धमा मास्क र XOR निर्माण गर्दछौं।
        // हामी शाखाविहीन रूपमा signedणात्मक-हस्ताक्षर गरिएको मानहरूबाट "all-ones except for the sign bit" मास्क गणना गर्दछौं: दायाँ स्थानान्तरणले इन्टिजरलाई विस्तार गर्दछ, त्यसैले हामी "fill" मास्क चिन्ह बिटको साथ बनाउँछौं, र त्यसपछि साइनर्डमा रूपान्तरण गर्छौं अर्को शून्य बिटमा।
        //
        // सकारात्मक मानहरूमा, मास्क सबै शून्य हो, त्यसैले यो कुनै अप्ट छैन।
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// निश्चित अंतरालमा मान प्रतिबन्धित गर्नुहोस् जबसम्म यो Na हुन्छ।
    ///
    /// `max` फर्काउँछ यदि `self` `max` भन्दा ठूलो छ, र `min` यदि `self` `min` भन्दा कम छ भने।
    /// अन्यथा यसले `self` फिर्ता गर्दछ।
    ///
    /// नोट गर्नुहोस् कि यस प्रकार्यले NaN फिर्ता गर्दछ यदि प्रारम्भिक मान पनि NaN थियो।
    ///
    /// # Panics
    ///
    /// Panics यदि `min > max`, `min` NaN, वा `max` NaN हो भने।
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}