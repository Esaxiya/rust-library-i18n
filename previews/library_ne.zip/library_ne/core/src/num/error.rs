//! अभिन्न प्रकारहरूमा रूपान्तरणको लागि त्रुटि प्रकारहरू।

use crate::convert::Infallible;
use crate::fmt;

/// त्रुटि प्रकार फर्काईयो जब एक जाँच अभिन्न प्रकार रूपान्तरण विफल हुन्छ।
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // मापदण्डको सट्टामा X X1X जस्ता कोडले कार्य गरिरहनेछ भनेर X X2X मा एक्स नाम हुनु हुँदैन भन्ने कुरा सुनिश्चित गर्न कोसिस गर्नु भन्दा।
        //
        //
        match never {}
    }
}

/// एउटा त्रुटि जुन पूर्णांक पार्स गर्ने क्रममा फर्किन्छ।
///
/// यो त्रुटि `from_str_radix()` प्रकार्यहरू जस्तै [`i8::from_str_radix`] जस्तै आदिम पूर्णांक प्रकारहरूमा `from_str_radix()` प्रकार्यहरूको लागि त्रुटि प्रकारको रूपमा प्रयोग गरिन्छ।
///
/// # सम्भावित कारणहरू
///
/// अन्य कारणहरू मध्ये, `ParseIntError` स्ट्रिंगमा अग्रणी वा ट्रेलिंग व्हाइटस्पेसको कारण फ्याक्न सकिन्छ किनभने जब यो मानक इनपुटबाट प्राप्त गरिन्छ।
///
/// [`str::trim()`] विधि प्रयोगले सुनिश्चित गर्दछ कि कुनै पनि खाली ठाउँ पार्स गर्नु अघि नै रहन्छ।
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// एनमले बिभिन्न प्रकारका त्रुटिहरू भण्डारण गर्न सक्छ जुन पूर्णांक पार्स गर्न विफल हुन सक्छ।
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// पार्स गरिएको मान खाली छ।
    ///
    /// अन्य कारणहरू मध्ये, यो पट्टि खाली स्ट्रि p पार्स गर्दा निर्माण गरिने छ।
    Empty,
    /// यसको सन्दर्भमा अमान्य अंक समावेश गर्दछ।
    ///
    /// अन्य कारणहरूको बीचमा, यस भिन्नता निर्माण हुनेछ जब स्ट्रि string पार्सिars गर्दा गैर-ASCII चार समावेश गर्दछ।
    ///
    /// यो संस्करण पनि निर्माण गरिएको छ जब `+` वा `-` या त आफ्नै मा वा स of्ख्याको बिचमा स्ट्रिंग भित्र गलत ठाउँमा राखिन्छ।
    ///
    ///
    InvalidDigit,
    /// पूर्णांक लक्ष्य पूर्णा inte्क प्रकारमा भण्डार गर्न धेरै ठूलो छ।
    PosOverflow,
    /// लक्ष्य पूर्णांक प्रकारमा भण्डार गर्न पूर्णांक निकै सानो छ।
    NegOverflow,
    /// मूल्य शून्य थियो
    ///
    /// यो भिन्नता उत्सर्जित हुनेछ जब पार्सि string स्ट्रिको शून्यको मान हुन्छ, जुन गैर-शून्य प्रकारहरूको लागि अवैध हो।
    ///
    Zero,
}

impl ParseIntError {
    /// पूर्णांक विफलताको विस्तृत कारणलाई आउटपुट गर्दछ।
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}