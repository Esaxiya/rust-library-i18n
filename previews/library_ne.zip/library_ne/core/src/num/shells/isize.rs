//! सूचक-साइजमा अ signed्कित पूर्णांक प्रकारको लागि स्थिर।
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! नयाँ कोडले सम्बन्धित प्रकारको सीधा आदिम प्रकारमा प्रयोग गर्नुपर्नेछ।

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }