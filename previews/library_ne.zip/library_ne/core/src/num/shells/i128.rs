//! १२8-बिट साइन इन गरिएको पूर्णांक प्रकारको लागि स्थिर।
//!
//! *[See also the `i128` primitive type][i128].*
//!
//! नयाँ कोडले सम्बन्धित प्रकारको सीधा आदिम प्रकारमा प्रयोग गर्नुपर्नेछ।

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i128`"
)]

int_module! { i128, #[stable(feature = "i128", since="1.26.0")] }