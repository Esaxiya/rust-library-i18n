//! फर्मको दशमलव स्ट्रिंग मान्य गर्दै र विघटन गर्दै:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! अर्को शब्दहरूमा, दुई अपवादको साथ मानक फ्लोटिंग-पोइन्ट सिन्ट्याक्स: कुनै चिन्ह छैन, र "inf" र "NaN" को ह्यान्डलिंग छैन।यी ड्राइभर प्रकार्य (super::dec2flt) द्वारा ह्यान्डल गरिएको छ।
//!
//! वैध इनपुटहरू चिन्न अपेक्षाकृत सजिलो छ, तर यस मोड्युलले अनगिन्ती अवैध भिन्नताहरूलाई पनि अस्वीकार गर्नुपर्दछ, panic कहिले पनि गर्दैन, र असंख्य जाँचहरू प्रदर्शन गर्दछ जुन अन्य मोड्युलहरूले बदले panic (वा ओभरफ्लो) मा भर पर्दैन।
//!
//! कुरा बिगार्नको लागि, ती सबै इनपुटमा एकल पासमा हुन्छ।
//! त्यसोभए, केहि पनि परिमार्जन गर्दा सावधान हुनुहोस्, र अन्य मोड्युलहरूको साथ डबल-जाँच गर्नुहोस्।
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// दशमलव स्ट्रि ofको रोचक अंश।
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// दशमलव घाता .्क, १ 18 भन्दा कम दशमलव अंकहरू हुने ग्यारेन्टी।
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// जाँच गर्नुहोस् यदि इनपुट स्ट्रि a वैध फ्लोटिंग पोइन्ट नम्बर हो र यदि हो भने, अभिन्न हिस्सा, आंशिक अंश, र त्यसमा एक्सपोन्टर फेला पार्दछ।
/// संकेतहरू सम्हाल्दैन।
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // 'e' भन्दा पहिले कुनै अंक छैन
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // हामीलाई पोइन्ट अघि वा पछाडि कम्तिमा एउटा अंक चाहिन्छ।
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // पछिल्लो भाग कच्छ भिन्न पछि
            }
        }
        _ => Invalid, // पहिलो अंकको स्ट्रि after पछि पछाडिको जंक
    }
}

/// दशमलव अ off्कलाई पहिले गैर-अ character्कको क्यारेक्टरमा नक्सा गर्छ।
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// घातांक निकासी र त्रुटि जाँच।
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // घाता after्क पछि पछाडि जंक
    }
    if number.is_empty() {
        return Invalid; // खाली घाता .्
    }
    // यस बिन्दुमा, हामीसँग निश्चित रूपमा अंकहरूको मान्य स्ट्रिंग छ।यो एक `i64` मा राख्न को लागी धेरै लामो हुन सक्छ, तर यदि यो धेरै ठूलो छ, इनपुट पक्कै शून्य वा अनन्त छ।
    // दशमलव अ in्कमा भएका प्रत्येक शून्यले घाता .्गलाई +/-१ ले समायोजित गर्दछ, Exp=१० ^ १ at मा इनपुट १ ex एक्सबाइट (!) शून्यको पनि हुन सक्दछ र टाढाको रूपमा परिमितको नजिक हुन पनि।
    //
    // यो ठ्याक्कै प्रयोगको केस होईन जुन हामीले भर्नु पर्छ।
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}