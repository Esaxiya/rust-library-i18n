//! कागजबाट विभिन्न एल्गोरिदम।

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Fp मा महत्वपुर्ण बिट्सको संख्या
const P: u32 = 64;

// हामी केवल सबै * एक्सपोन्टरहरूको लागि उत्तम अनुमानित भण्डारण गर्दछौं, त्यसैले चर "h" र सम्बन्धित सर्तहरू हटाउन सकिन्छ।
// यसले केहि किलोबाइट स्पेसका लागि प्रदर्शन ट्रेड गर्दछ।

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// प्राय: आर्किटेक्चरमा, फ्लोटिंग पोइन्ट अपरेशन्सको स्पष्ट बिट आकार हुन्छ, त्यसैले गणनाको शुद्धता प्रति-अपरेशन आधारमा निर्धारित गरिन्छ।
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// x86 मा, x87 FPU फ्लोट कार्यहरूको लागि प्रयोग गरिन्छ यदि SSE/SSE2 एक्सटेन्सनहरू उपलब्ध छैनन्।
// x87 FPU पूर्वनिर्धारित द्वारा b० बिट प्रेसिजनका साथ अपरेट गर्दछ, जसको मतलब अपरेशन्स b० बिटमा गोल हुन्छ जब डबल राउन्डिंग हुने हुन्छ जब मान अन्ततः प्रतिनिधित्व हुन्छ।
//
// 32/64 बिट फ्लोट मानहरू।यसलाई पार गर्न, FPU नियन्त्रण शब्द सेट गर्न सकिन्छ ताकि कम्प्युटिजेसनहरू इच्छित परिशुद्धतामा प्रदर्शन गर्न सकियोस्।
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// FPU नियन्त्रण शव्दको मूल मान बचाउनको लागि एउटा संरचना, ताकि संरचना ड्रप गर्दा यसलाई पूर्वावस्थामा ल्याउन सकिन्छ।
    ///
    ///
    /// x87 FPU १ 16-बिट्स रजिस्टर हो जसको क्षेत्रहरू निम्नानुसार छन्:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// सबै फाँटहरूको लागि कागजात IA-32 आर्किटेक्चर सफ्टवेयर डेभलपरको म्यानुअल (खण्ड १) मा उपलब्ध छ।
    ///
    /// मात्र कोड जुन निम्न कोडको लागि प्रासंगिक छ पीसी, प्रेसिजन नियन्त्रण।
    /// यस फिल्डले FPU द्वारा गरिएको अपरेशनको सटीकता निर्धारण गर्दछ।
    /// यो सेट गर्न सकिन्छ:
    ///  - ० बी ०, एकल परिशुद्धता अर्थात,-२-बिट्स
    ///  - ० बी १०, डबल प्रेसिजन अर्थात्,-64-बिट्स
    ///  - ० बी ११, डबल विस्तारित प्रेसिजन अर्थात्,-०-बिट्स (पूर्वनिर्धारित राज्य) ० बी ०१ मान आरक्षित छ र प्रयोग गर्नु हुँदैन।
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // सुरक्षा: `fldcw` निर्देशन सही संग काम गर्न सक्षम हुन अडिट गरिएको छ
        // कुनै `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: LLVM and र LLVM support समर्थन गर्न हामी ATT सिन्ट्याक्स प्रयोग गर्दैछौं।
                options(att_syntax, nostack),
            )
        }
    }

    /// XP1X मा FPU को सटीक क्षेत्र सेट गर्दछ र `FPUControlWord` फर्काउँछ।
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // `T` को लागी उपयुक्त प्रेसिजन कन्ट्रोल फिल्डको लागि मान गणना गर्नुहोस्।
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // B२ बिट्स
            8 => 0x0200, // B 64 बिट्स
            _ => 0x0300, // पूर्वनिर्धारित, b० बिट्स
        };

        // यसलाई पछि पुन: भण्डारण गर्न कन्ट्रोल शव्दको मूल मान पाउनुहोस्, जब `FPUControlWord` संरचना सुरक्षित छोडियो: `fnstcw` निर्देशन कुनै पनि `u16` सँग सही ढ work्गले काम गर्न सक्षम हुनको लागि अडिट गरिएको छ।
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: LLVM and र LLVM support समर्थन गर्न हामी ATT सिन्ट्याक्स प्रयोग गर्दैछौं।
                options(att_syntax, nostack),
            )
        }

        // इच्छित शब्दलाई नियन्त्रण शब्द सेट गर्नुहोस्।
        // पुरानो सटीक (बिट्स and र,, 0x300) मास्किंग गरेर र माथिको गणना गरिएको सटीक झण्डाको साथ बदलेको यो हासिल गरिएको हो।
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// बेलेरोफनको द्रुत मार्ग मेशिन आकारको पूर्णांक र फ्लोटहरू प्रयोग गरेर।
///
/// यो एक अलग प्रकार्यमा झिकिएको छ ताकि यो बिग्नुम निर्माण गर्नु अघि प्रयास गर्न सकिन्छ।
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95।
    // हामी अन्तको MAX_SIG सँग सहि मानको तुलना गर्छौं, यो केवल द्रुत, सस्तो अस्वीकृति हो (र बाँकी कोडलाई भूमिगतिको चिन्ताबाट पनि मुक्त गर्दछ)।
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // द्रुत मार्ग महत्त्वपूर्ण अंकगणितमा निर्भर गर्दछ बिट्सको सहि संख्यामा कुनै मध्यवर्ती राउन्डिंग बिना।
    // x86 मा (SSE वा SSE2 बिना) यसको लागि x87 FPU स्ट्याकको सटीकता परिवर्तन गर्न आवश्यक छ ताकि यसलाई सिधा 64/32 बिटमा गोल भयो।
    // `set_precision` प्रकार्यले आर्किटेक्चरमा सटीक सेटि settingको ध्यान राख्दछ जुन यसलाई ग्लोबल स्टेट (x87 FPU को नियन्त्रण शब्द जस्तै) परिवर्तन गरेर यसलाई स्थापित गर्न आवश्यक पर्दछ।
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // केस e <० लाई अन्य branch मा फोल्ड गर्न सकिदैन।
    // नकारात्मक शक्तिहरूको परिणामस्वरूप बाइनरीमा दोहोरिने आंशिक अंश हुन्छ, जुन गोलाकार हुन्छन्, जसले अन्तिम परिणाममा वास्तविक (र कहिलेकाँही महत्त्वपूर्ण महत्वपूर्ण!) त्रुटिहरू निम्त्याउँछ।
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// एल्गोरिथ्म बेलेरोफन ट्रिभियल कोड गैर-तुच्छ संख्यात्मक विश्लेषणद्वारा ठीक छ।
///
/// यसले bit `f`` लाई bit 64 बिट महत्वको साथ फ्लोटमा जान्छ र यसलाई `10^e` को उत्तम अनुमानितमा गुणा गर्दछ (उही फ्लोटिंग पोइन्ट ढाँचामा)।सही परिणाम प्राप्त गर्न यो प्रायः पर्याप्त हुन्छ।
/// जे होस्, जब परिणाम दुई सान्दर्भिक (ordinary) फ्लोट्स बीचको आधा बाटोको नजिक हुन्छ, दुई अनुमानित गुणा गर्नबाट कम्पाउन्ड राउन्डिंग त्रुटि मतलब केही बिट्स द्वारा परिणाम बन्द हुन सक्छ।
/// जब यो हुन्छ, पुनरावर्ती एल्गोरिथ्म R ले चीजहरू ठीक गर्दछ।
///
/// कागजातमा संख्यात्मक विश्लेषणले ह्यान्ड-वेवी "close to halfway" सटीक बनाएको छ।
/// क्लिन्गरको शब्दमा:
///
/// > ढलान, कम से कम महत्वपूर्ण बिटको इकाईहरूमा अभिव्यक्त, त्रुटिको लागि समावेशी सीमा हो
/// > f * 10 ^ e को अनुमानितको फ्लोटिंग पोइन्ट गणनाको बेला संचय गरियो।(ढलान हो
/// > सहि त्रुटिका लागि बाउन्ड होइन, तर अनुमानित z र
/// > उत्तम सम्भावित सटीकता जुन कि महत्वको पी बिट्स प्रयोग गर्दछ।)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // abs(e) <log5(2^N) केस fast_path() मा छन्
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // के ढलान एन बिट्समा राउन्ड गर्ने क्रममा फरक पार्न ठूलो छ?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// एक पुनरावर्ती एल्गोरिथ्म जसले `f * 10^e` को फ्लोटिंग पोइन्ट अनुमानित सुधार गर्दछ।
///
/// प्रत्येक पुनरावृत्ति अन्तिम स्थानमा नजिकै एक एकाई हुन्छ, को पाठ्यक्रम जो `z0` हल्का बन्द छ भने रूपान्तरण गर्न धेरै लामो लिन्छ।
/// भाग्यवस, जब बेलेरोफनको लागि फलब्याकको रूपमा प्रयोग गरिन्छ, सुरूवात करीव अधिकतम एक यूएलपी द्वारा बन्द छ।
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // सकारात्मक पूर्णांकहरू `x`, `y` फेला पार्नुहोस् जुन `x / y` ठीक `(f *10^e) / (m* 2^k)` हो।
        // यसले केवल `e` र `k` को संकेतहरूसँग व्यवहार गर्नबाट जोगाउँदछ, हामी संख्याहरूलाई सानो बनाउन `10^e` र `2^k` मा दुई साधारणको शक्तिलाई पनि हटाउँछौं।
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // यो केहि अजीब ढ written्गले लेखिएको छ किनभने हाम्रो बिग्नुमहरूले नकारात्मक संख्या समर्थन गर्दैन, त्यसैले हामी परिपेक्ष मान + चिन्ह जानकारी प्रयोग गर्दछौं।
        // M_digits को साथ गुणा ओभरफ्लो हुन सक्दैन।
        // यदि `x` वा `y` पर्याप्त ठूलो छ कि हामीलाई ओभरफ्लोको बारेमा चिन्ता गर्न आवश्यक छ, तब तिनीहरू पनि यति ठूला छन् कि X 2 2X ले २ ^ or^ वा अधिकको एक कारकले फ्र्याक्सन घटाएको छ।
        //
        //
        let (d2, d_negative) = if x >= y {
            // अब x को आवश्यकता पर्दैन, clone() बचत गर्नुहोस्।
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // अझै y चाहिन्छ, प्रतिलिपि बनाउनुहोस्।
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// `x = f` र `y = m` जहाँ `f` सामान्य रूपमा इनपुट दशमलव अंक प्रतिनिधित्व गर्दछ र `m` एक फ्लोटिंग पोइन्ट अनुमानितको महत्व हो, `x / y` लाई `(f *10^e) / (m* 2^k)` बराबर बनाउँदछ, सम्भवतः दुईको पावरले कम गर्दा दुबैमा समानता छ।
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *१० ^ e, y=m* २ ^ k, बाहेक हामी दुईको केही शक्तिले भिन्न भिन्न गर्छौं।
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *१० ^ e* 2^abs(k), y=m यसले ओभरफ्लो गर्न सक्दैन किनकि यसको लागि सकारात्मक `e` र नकारात्मक `k` चाहिन्छ, जुन केवल १ को नजदीक मानको लागि मात्र हुन सक्दछ, जसको मतलब `e` र `k` तुलनात्मक रूपमा सानो हुनेछ।
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* २ ^ k यो कि त ओभरफ्लो हुन सक्दैन, माथि हेर्नुहोस्।
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), फेरि दुईको साझा शक्तिले घटाउँदै।
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// अवधारणाको रूपमा, एल्गोरिथ्म एम एक दशमलवलाई फ्लोटमा रूपान्तरण गर्ने सरल तरिका हो।
///
/// हामी एउटा अनुपात बनाउँछौं जुन `f * 10^e` सँग बराबर छ, त्यसपछि दुईको पावरमा फ्याँक्दा सम्म यसले वैध फ्लोट महत्त्व दिदैन।
/// बाइनरी एक्सपेनन्ट `k` समयको संख्या हो जुन हामीले दुई गुणा संख्या वा भाजकलाई गुणा गर्दछ, अर्थात, सबै समयमा `f *10^e` `(u / v)* 2^k` बराबर हुन्छ।
/// जब हामीले यसको महत्व पत्ता लगायौं, हामीले केवल भागको बाँकी भागको अन्वेषण गरेर गोल गर्नु आवश्यक छ, जुन तलका सहयोगी कार्यहरूमा गरिन्छ।
///
///
/// यो एल्गोरिथ्म एकदम सुस्त छ, `quick_start()` मा वर्णन गरिएको अप्टिमाइजेसनको साथ।
/// यद्यपि ओभरफ्लो, इनफ्लो र सबर्नोरमल नतीजाहरूको लागि अनुकूलन गर्न यो एल्गोरिदमहरूमध्ये सबैभन्दा सरल हो।
/// Bellerophon र Algorithm R अभिभूत भएको बेला यो कार्यान्वयन लिन्छ।
/// अन्डरफ्लो र ओभरफ्लो पत्ता लगाउन सजिलो छ: अनुपात अझै पनी सीमा होईन, एक्स एक्स एक्स एक्सपोनेन्टमा पुगेको छ।
/// ओभरफ्लोको मामलामा, हामी अनन्तता मात्र फर्काउँछौं।
///
/// भूमिगत र subnormals ह्यान्डल गर्न मुश्किल छ।
/// एउटा ठूलो समस्या यो हो कि, न्यूनतम घाता .्कको साथ, अनुपात अझै पनि एक महत्वको लागि धेरै ठूलो हुन सक्छ।
/// विवरणका लागि underflow() हेर्नुहोस्।
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME सम्भावित अप्टिमाइजेसन: big_to_fp सामान्यीकृत गर्नुहोस् ताकि हामी यहाँ fp_to_float(big_to_fp(u)) को बराबर गर्न सक्दछौं, मात्र डबल राउन्डिंग बिना।
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // हामीले न्यूनतम घाता .्कमा रोक्नु पर्छ, यदि हामी `k < T::MIN_EXP_INT` सम्म पर्ख्यौं भने, हामी दुईको कारकबाट बाहिर आउँछौं।
            // दुर्भाग्यवस यसको मतलब हामीले न्यूनतम घाता .्कको साथ सामान्य नम्बरहरू गर्नुपर्दछ।
            // FIXME एक अधिक सुरुचिपूर्ण सुत्र पत्ता लगाउनुहोस्, तर `tiny-pow10` परीक्षण चलाउनुहोस् कि यो वास्तवमा सहि छ!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// अधिकतर एल्गोरिथ्म एम पुनरावर्तन बिट लम्बाइ जाँच गरेर छोड्दछ।
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // बिट लम्बाइ आधार दुई लोगारिदम र log(u / v) = log(u), log(v) को अनुमान छ।
    // अनुमान १ भन्दा बढि बन्द छ, तर जहिले पनि एक अनुमान-अन्तर्गत, त्यसैले log(u) र log(v) मा त्रुटि समान चिन्हको हुन्छ र रद्द गर्नुहोस् (यदि दुबै ठूला छन् भने)।
    // त्यसैले log(u / v) को लागि त्रुटि पनि अधिकमा एक हो।
    // लक्ष्य अनुपात एक हो जहाँ u/v एक in-दायरा महत्त्व में छ।यसैले हाम्रो टर्मिनेसन कन्डिसन log2(u / v) महत्व र बिट्स भएको, plus/minus एक हो।
    // FIXME दोस्रो बिट हेराईले अनुमानलाई सुधार गर्न सक्दछ र केहि बढि भागहरू बाट बच्न सक्छ।
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // अन्डरफ्लो वा सबनोर्मल।मुख्य समारोहमा यसलाई छोड्नुहोस्।
            break;
        }
        if *k == T::MAX_EXP_INT {
            // ओभरफ्लोमुख्य समारोहमा यसलाई छोड्नुहोस्।
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // अनुपात न्यूनतम घाता .्कको साथ कुनै सीमाको महत्व हुँदैन, त्यसैले हामीले अधिक बिटहरू गोल गर्न र त्यस आधारमा घाता .्कीय समायोजन गर्न आवश्यक छ।
    // वास्तविक मान अब यस्तो देखिन्छ:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q ट्रंक।(रीमद्वारा प्रतिनिधित्व)
    //
    // त्यसकारण, जब राउन्ड-अफ बिट्स हुन्छ!= 0.5 ULP, तिनीहरूले आफैंमा राउन्डिंग निर्णय गर्छन्।
    // जब तिनीहरू बराबर छन् र बाँकी बाँकी शून्य छ, मान अझै गोल गर्न आवश्यक छ।
    // मात्र जब राउन्ड अफ बिट्स 1/2 हुन्छ र बाँकी शून्य हुन्छ, हामीसँग आधा-देखि-सम्म अवस्था हुन्छ।
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// साधारण राउन्ड-टु-इभन, प्रभागको बाँकीको आधारमा राउन्ड गरेर पछाडि सर्दै।
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}