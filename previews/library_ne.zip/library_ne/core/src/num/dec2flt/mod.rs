//! दशमलव स्ट्रि IEलाई आईईईई 4 754 बाइनरी फ्लोटिंग पोइन्ट नम्बरहरूमा रूपान्तरण गर्दै।
//!
//! # समस्या कथन
//!
//! हामीलाई दशमलव स्ट्रिंग दिइन्छ जस्तै `12.34e56`।
//! यस स्ट्रिमा अभिन्न (`12`), आंशिक (`34`), र घाता (`56`) भागहरू हुन्छन्।सबै भागहरू वैकल्पिक हुन्छन् र शून्य रूपमा परिभाषित हुँदा हराइरहेको छ।
//!
//! हामी आईईईई 75 754 फ्लोटिंग पोइन्ट नम्बर खोज्छौं जुन दशमलव स्ट्रि ofको वास्तविक मानको नजिक छ।
//! यो राम्रोसँग ज्ञात छ कि धेरै दशमलव ताराको आधारभूत दुईमा टर्मिनेटिations्ग प्रतिनिधित्व हुँदैन, त्यसैले हामी 0.5 इकाईहरूमा अन्तिम स्थानमा राउन्ड गर्छौं (अर्को शब्दमा, साथै सम्भव पनि)।
//! टाईहरू, दुई लगातार फ्लोटहरूको बिचमा आधा बाटोमा दशमलव मानहरू, आधा देखि समातिको रणनीतिको साथ समाधान गरिन्छ, जसलाई बैंकरको गोलाकार पनि भनिन्छ।
//!
//! भन्न आवश्यक छैन, यो कार्यान्वयन जटिलता र CPU चक्रको सर्तमा दुबैमा दुबै कडा छ।
//!
//! # Implementation
//!
//! पहिले हामी संकेतहरूलाई वेवास्ता गर्दछौं।वा बरु, हामी यसलाई रूपान्तरण प्रक्रियाको सुरूमा नै हटाउँछौं र यसलाई अन्तमा पुन: लागू गर्दछौं।
//! यो सबै edge मामिलाहरूमा सही छ किनकि आईईईई फ्लोटहरू शून्यको वरिपरि सममित हुन्छ, बेवास्ता गर्दा केवल पहिलो बिट फ्लिप हुन्छ।
//!
//! त्यसपछि हामी दशमलव बिन्दु हटाउँछौं घाता adjust्क समायोजित गरेर: अवधारणा अनुसार, `12.34e56` `1234e54` मा परिणत हुन्छ, जुन हामीले सकारात्मक इन्टिजर `f = 1234` र पूर्णांक `e = 54` सँग वर्णन गर्छौं।
//! `(f, e)` प्रतिनिधित्व पार्सिंग स्टेजको पछिल्लो सबै कोडहरू द्वारा प्रयोग गरिन्छ।
//!
//! हामी त्यसपछि मेशिन-आकारको पूर्णांक र सानो, फिक्स्ड-साइज फ्लोटिंग पोइन्ट नम्बरहरू प्रयोग गरेर क्रमिक रूपमा सामान्य र महँगो विशेष केसहरूको लामो श्रृंखलाको प्रयास गर्छौं (पहिलो `f32`/`f64`, त्यसपछि bit 64 बिट महत्त्वको साथ एक प्रकार, X०१ एक्स)।
//!
//! जब यी सबै विफल हुन्छन्, हामी बुलेटलाई टोक्छौं र साधारण तर धेरै ढिलो एल्गोरिथ्मको लागि सहारा गर्छौं जुन `f * 10^e` लाई पूर्ण रूपले गणना गर्दै र उत्तम अनुमानितताको लागि एक पुनरावृत्तिक खोज गर्दैछ।
//!
//! मुख्य रूपमा, यो मोड्युल र यसका बच्चाहरूले वर्णन गरिएको एल्गोरिदमहरू कार्यान्वयन गर्छन्:
//! "How to Read Floating Point Numbers Accurately" विलियम डी द्वारा
//! क्लिंगर, अनलाइन उपलब्ध: <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! थप रूपमा, त्यहाँ असंख्य सहयोगी कार्यहरू छन् जुन कागजमा प्रयोग गरिन्छ तर Rust मा उपलब्ध छैन (वा कम्तिमा कोरमा)।
//! हाम्रो संस्करण ओभरफ्लो र अन्डरफ्लो र उपनॉर्मल नम्बरहरू ह्यान्डल गर्ने इच्छाले ह्यान्डल गर्न आवश्यकताले थप जटिल बनाएको छ।
//! बेलेरोफन र एल्गोरिथ्म आरको ओभरफ्लो, सबनोर्मलहरू, र भूमिहीनसँग समस्या छ।
//! हामी रूढिवादी रुपमा एल्गोरिथ्म एम (कागजको खण्ड in मा वर्णन गरिएको परिमार्जन सहित) मा इनपुटहरू महत्वपूर्ण क्षेत्रमा प्रवेश गर्नु अघि स्विच गर्छौं।
//!
//! अर्को पक्ष जसलाई ध्यान चाहिन्छ त्यो हो ``RawFloat`` trait जस द्वारा प्राय सबै कार्यहरू प्यारामेटरिजेसन गरिएको छ।कसैले सोच्दछ कि `f64` लाई पार्स गर्न र XxX मा नतिजा पर्याप्त छ।
//! दुर्भाग्यवश यो हामी बाँचिरहेको संसार हैन, र यसको आधार दुई वा आधा-देखि-गोलाकार प्रयोगको साथ केही गर्नुपर्दैन।
//!
//! उदाहरणका लागि दुई प्रकारहरू `d2` र `d4` दुई दशमलव अंकहरू र चार दशमलव अंकहरूको साथ दशमलव प्रकार प्रतिनिधित्व गर्ने विचार गर्नुहोस् र "0.01499" इनपुटको रूपमा लिनुहोस्।आधा माथि राउन्डिंग प्रयोग गरौं।
//! सीधा दुई दशमलव अंकमा जान `0.01` दिन्छ, तर यदि हामी चार अंक पहिले दौर, हामी `0.0150`, जो पछि `0.02` मा गोलाकार हुन्छ।
//! उही सिद्धान्त अन्य अपरेसनहरूमा पनि लागू हुन्छ, यदि तपाईं 0.5 ULP सटीकता चाहनुहुन्छ भने तपाईले सबै कुरा *पूर्ण सटीक र राउन्ड* मा ठीक एक पटक गर्नु पर्छ, अन्तमा *, एकैचोटि सबै काटिएका बिट्सलाई विचार गरेर।
//!
//! FIXME: जे होस् केहि कोड नक्कल आवश्यक छ, सायद कोडका केही अंशहरू त्यस्तै कम कोड नक्कल भएको वरपर घुम्न सकिन्छ।
//! एल्गोरिदमका ठूला भागहरू फ्लोट प्रकारबाट आउटपुटमा स्वतन्त्र हुन्छन्, वा केवल केही स्थिरमा पहुँच आवश्यक पर्दछ, जुन प्यारामिटरको रूपमा पार गर्न सकिन्छ।
//!
//! # Other
//!
//! रूपान्तरण *कहिल्यै* panic हुँदैन।
//! त्यहाँ कोडमा दावी र स्पष्ट panics छन्, तर तिनीहरू कहिल्यै ट्रिगर हुनु हुँदैन र केवल आन्तरिक विवेक जाँचको रूपमा सेवा गर्दछ।कुनै पनि panics एक बग मानिनु पर्छ।
//!
//! त्यहाँ एकाइ परीक्षणहरू छन् तर तिनीहरू दु: खको रूपमा शुद्धता सुनिश्चित गर्न अपर्याप्त छन्, तिनीहरूले सम्भावित त्रुटिहरूको थोरै मात्र मात्र कभर गर्दछन्।
//! धेरै विस्तृत परीक्षणहरू Python स्क्रिप्टको रूपमा `src/etc/test-float-parse` निर्देशिकामा अवस्थित छन्।
//!
//! पूर्णांक ओभरफ्लोमा नोट: यस फाईलको धेरै भागले दशमलव एक्सपेन्सन `e` का साथ अंकगणित प्रदर्शन गर्दछ।
//! मुख्य रूपमा, हामी दशमलव बिन्दु चारै तिर बदल्छौं: पहिलो दशमलव अ Before्क अघि, अन्तिम दशमलव अंक पछि, र यस्तै।यदि बेवास्ता गरेमा यो ओभरफ्लो हुन सक्छ।
//! हामी केवल पार्सिंग सबमोडुलमा मात्र निर्भर गर्दछ पर्याप्त साना एक्सपोन्टरहरू मात्र हस्तान्तरण गर्नका लागि, जहाँ "sufficient" को अर्थ "such that the exponent +/- the number of decimal digits fits into a 64 bit integer" हो।
//! ठूला एक्सपोन्टरहरू स्वीकार गरिन्छ, तर हामी उनीहरूसँग गणित गर्दैनौं, तिनीहरू तुरून्त {positive,negative} {zero,infinity} मा परिणत हुन्छन्।
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// यी दुईको आफ्नै टेस्ट छन्।
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// आधार १० मा एक स्ट्रिंगलाई फ्लोटमा रूपान्तरण गर्दछ।
            /// वैकल्पिक दशमलव घाता .्कार स्वीकार्छ।
            ///
            /// यो प्रकार्यले स्ट्रिंगहरू स्वीकार गर्दछ जस्तै
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', वा बराबर, '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', वा, बराबर, '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// अग्रणी र ट्रेलि wh ह्वाइटस्पेसले त्रुटि प्रतिनिधित्व गर्दछ।
            ///
            /// # Grammar
            ///
            /// सबै स्ट्रिंगहरू जुन निम्न [EBNF] व्याकरणको पालना गर्दछ [`Ok`] फिर्ता हुनेछ।
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # ज्ञात बगहरू
            ///
            /// केहि अवस्थाहरूमा, केहि स्ट्रिंगहरू जुन वैध फ्लोट सिर्जना गर्नुपर्दछ बरु त्रुटि फिर्ता गर्दछ।
            /// विवरणका लागि [issue #31407] हेर्नुहोस्।
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src, एक स्ट्रि
            ///
            /// # फिर्ता मान
            ///
            /// `Err(ParseFloatError)` यदि स्ट्रिंगले मान्य संख्याको प्रतिनिधित्व गर्दैन।
            /// अन्यथा, `Ok(n)` जहाँ `n` `src` द्वारा प्रतिनिधित्व फ्लोटिंग पोइन्ट नम्बर हो।
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// एउटा त्रुटि जुन फ्लोट पार्सिंग गर्दा फर्किन्छ।
///
/// यो त्रुटि [`f32`] र [`f64`] का लागि [`FromStr`] कार्यान्वयनको लागि त्रुटि प्रकारको रूपमा प्रयोग भयो।
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// दशमलव स्ट्रि signलाई साइन र बाँकीमा विभाजन गर्दछ, बाँकीको निरीक्षण वा मान्य नगरी।
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // यदि स्ट्रिंग अवैध छ भने हामी कहिले पनि चिन्ह प्रयोग गर्दैनौं, त्यसैले हामीलाई यहाँ मान्य गर्न आवश्यक पर्दैन।
        _ => (Sign::Positive, s),
    }
}

/// दशमलव स्ट्रि aलाई फ्लोटिंग पोइन्ट नम्बरमा रूपान्तरण गर्दछ।
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// दशमलव देखि फ्लोट रूपान्तरणको लागि मुख्य workhorse: सबै पूर्वप्रक्रिया अर्केस्ट्रेट गर्नुहोस् र पत्ता लगाउनुहोस् कि कुन एल्गोरिथ्म वास्तविक रूपान्तरण गर्नुपर्छ।
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift दशमलव बिन्दु बाहिर
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // Big32x40 १२80० बिटहरूमा सीमित छ, जुन लगभग 5 38 dec दशमलव अ to्कमा अनुवाद हुन्छ।
    // यदि हामी यस भन्दा बढि जान्छौं, हामी क्र्यास हुनेछौं, त्यसैले धेरै नजिक हुनु अघि त्रुटि (१० ^ १० भित्र)।
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // अब घाता .्ग निश्चित रूपमा १ bit बिटमा फिट हुन्छ जुन मुख्य एल्गोरिदममा प्रयोग गरिन्छ।
    let e = e as i16;
    // FIXME यी सीमाहरू बरु रूढिवादी छन्।
    // Bellerophon को विफलता मोड को एक अधिक सावधान विश्लेषण एक विशाल गति को लागी अधिक केसहरुमा यसलाई प्रयोग गर्न अनुमति दिन सक्छ।
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// लेखिएको रूपमा, यसले नराम्ररी अप्टिमाइज गर्दछ (हेर्नुहोस् #27130, यद्यपि यसले कोडको पुरानो संस्करणलाई जनाउँदछ)।
// `inline(always)` त्यो लागि एक workaround छ।
// त्यहाँ केवल दुई कल साइटहरू समग्र छन् र यसले कोड आकारलाई नराम्रो बनाउँदैन।

/// स्ट्रिप शून्यहरू जहाँ सम्भव छ, यसको लागि विस्तारकर्तालाई परिवर्तन गर्न आवश्यक पर्दा पनि
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // यी शून्य ट्रिमिंगले केहि परिवर्तन गर्दैन तर द्रुत मार्ग सक्षम गर्न सक्दछ (<१ digit अंकहरू)।
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // ०.० ... x र x ... ० को संख्याहरू सरलीकृत गर्नुहोस्, तदनुसार घाता adjust्क समायोजन गर्दै।
    // यो जहिले पनि विजय नहुन सक्छ (सम्भवत: केहि नम्बरहरूलाई द्रुत मार्गबाट बाहिर धकेल्छ), तर यसले अन्य भागहरूलाई उल्लेखनीय रूपमा सरलीकृत गर्दछ (विशेष गरी, मानको परिमाणको अनुमानित)।
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// एल्गोरिथ्म आर र एल्गोरिथ्म एमले दिएको दशमलवमा कार्य गर्दा गणना गर्ने सब भन्दा ठूलो मानको (log10) को आकार मा छिटो-एक-फोहोर माथिल्लो सीमा फर्काउँछ।
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // हामीलाई यहाँ ओभरफ्लोको बारेमा धेरै चिन्ता लिनु पर्दैन trivial_cases() X र पार्सरलाई धन्यवाद छ, जसले हाम्रो लागि अत्यन्त चरम इनपुटहरू फिल्टर गर्दछ।
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // केस e>=० मा दुबै एल्गोरिदम `f * 10^e` को बारे मा गणना गर्नुहोस्।
        // एल्गोरिथ्म आर यसको साथ केहि जटिल गणना गर्न अगाडि बढ्छ तर हामी त्यसलाई वेवास्ता गर्न सक्छौं माथिल्लो बाउन्डको लागि किनकि यसले फ्र्याक्सन पहिले नै कम गर्दछ, त्यसैले हामीसँग प्रशस्त बफर छ।
        //
        f_len + (e as u64)
    } else {
        // यदि e <०, एल्गोरिथ्म आर लगभग समान चीज गर्दछ, तर एल्गोरिथ्म एम फरक:
        // यसले एक सकारात्मक नम्बर k फेला पार्न कोशिस गर्दछ कि `f << k / 10^e` एक in-सीमा महत्व हो।
        // यसले `2^53 *f* 10^e` <`10^17 *f* 10^e` को बारेमा परिणाम दिनेछ।
        // एउटा इनपुट जुन यसलाई ट्रिगर गर्दछ 0.33 ... 33 (375 x 3)।
        f_len + e.unsigned_abs() + 17
    }
}

/// दशमलव अ at्कहरू पनि नहेर्दा स्पष्ट ओभरफ्लो र अंडरफ्लोहरू पत्ता लगाउँछ।
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // त्यहाँ शून्यहरू थिए तर तिनीहरू simplify() द्वारा हटाइयो
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // यो ceil(log10(the real value)) को एक कच्चा अनुमानित हो।
    // हामीलाई यहाँ ओभरफ्लोको बारेमा धेरै चिन्ता लिनु आवश्यक पर्दैन किनकि इनपुट लम्बाइ सानो छ (कम्तिमा २ ^ to to को तुलनामा) र पार्सरले पहिले नै एक्सपोन्टरहरू ह्यान्डल गर्दछ जसको पूर्ण मान १० ^ १ than भन्दा बढी छ (जुन अझै १० ^ १ छोटो छ २ ^)^ को)।
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}