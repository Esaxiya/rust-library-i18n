//! सकारात्मक आईईईई 4 754 फ्लोटहरूमा बिट फिडलिंग।नकरात्मक संख्याहरू होईन र ह्यान्डल हुन आवश्यक पर्दैन।
//! सामान्य फ्लोटिंग पोइन्ट नम्बरहरूको क्यानोनिकल प्रतिनिधित्व हुन्छ (frac, exp) जस्तै कि मान २ <sup>exp</sup> * (१ + sum(frac[N-i] / 2<sup>i</sup>)) हो जहाँ N बिट्सको संख्या हो)।
//!
//! सब्नोर्मलहरू थोरै फरक र अनौंठो हुन्छन्, तर समान सिद्धान्त लागू हुन्छ।
//!
//! यहाँ, तथापि, हामी उनीहरूलाई प्रतिनिधित्व गर्दछौं (sig, k) f सकारात्मकसँग, जस्तै कि मान f *
//! २ <sup>ई</sup> ।"hidden bit" स्पष्ट बनाउनुका साथै, यसले तथाकथित मन्टिस्सा शिफ्टबाट घाता परिवर्तन गर्दछ।
//!
//! अर्को तरिका राख्नुहोस्, सामान्यतया फ्लोट्स (1) को रूपमा लेखिन्छ तर यहाँ तिनीहरू (2) का रूपमा लेखिएका छन्:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! हामी (1) लाई **आंशिक प्रतिनिधित्व** र (2)**अभिन्न प्रतिनिधित्व** भन्छौं।
//!
//! यस मोड्युलमा धेरै प्रकार्यहरू सामान्य संख्याहरू मात्र गर्दछन्।Dec2flt दिनचर्या पुराणमतवादी धेरै साना र धेरै ठूलो संख्या को लागी विश्वव्यापी सहि ढिलो मार्ग (एल्गोरिथ्म M) लिन्छ।
//! त्यो अल्गोरिदमलाई केवल next_float() चाहिन्छ जसले उपनर्मलहरू र शून्यहरू ह्यान्डल गर्दछ।
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// `f32` र `f64` का लागि मूल रूपले सबै रूपान्तरण कोड नक्कलबाट बच्न एक सहायक trait।
///
/// किन आवश्यक छ को लागी अभिभावक मोड्युल को कागजात हेर्नुहोस्।
///
/// **कहिल्यै कहिल्यै** अन्य प्रकारका लागि कार्यान्वयन गर्न वा dec2flt मोड्युल बाहिर प्रयोग गर्नु पर्छ।
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// `to_bits` र `from_bits` द्वारा प्रयोग प्रकार।
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// पूर्णांकमा कच्चा ट्रान्समिटेशन गर्दछ।
    fn to_bits(self) -> Self::Bits;

    /// पूर्णांकबाट कच्चा ट्रान्समिटेशन गर्दछ।
    fn from_bits(v: Self::Bits) -> Self;

    /// कोटी फर्काउँछ जुन यो संख्यामा पर्दछ।
    fn classify(self) -> FpCategory;

    /// म्यान्टिसा, घाता .्क र पूर्णांकको रूपमा साइन फर्काउँछ।
    fn integer_decode(self) -> (u64, i16, i8);

    /// फ्लोट डिकोड गर्नुहोस्।
    fn unpack(self) -> Unpacked;

    /// सानो पूर्णांकबाट कास्टहरू जुन सहि प्रतिनिधित्व गर्न सकिन्छ।
    /// Panic यदि इन्टिजर प्रतिनिधित्व हुन सक्दैन, यस मोड्युलमा अन्य कोडले कहिले पनि यस्तो हुन नदिने सुनिश्चित गर्दछ।
    fn from_int(x: u64) -> Self;

    /// प्रि-गणना गरिएको तालिकाबाट १० <sup>e</sup> प्राप्त गर्दछ।
    /// `e >= CEIL_LOG5_OF_MAX_SIG` का लागि Panics।
    fn short_fast_pow10(e: usize) -> Self;

    /// नाम के भन्छ।
    /// यो हार्ड कोड गर्न सजिलो छ जागल गर्ने ईन्ट्रिन्सिक भन्दा र आशा गर्दै LLVM स्थिर फोल्ड गर्दछ।
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // दशमलव अंकमा परम्परागत बाउन्ड इनपुटहरू जुन ओभरफ्लो वा शून्य वा उत्पादन गर्न सक्दैन
    /// subnormals।सम्भवत: अधिकतम सामान्य मानको दशमलव घण्टा, यसैले नाम।
    const MAX_NORMAL_DIGITS: usize;

    /// जब सब भन्दा महत्वपूर्ण दशमलव अंकको एक भन्दा बढि स्थान मान हुन्छ, संख्या निश्चित रूपमा अनन्तको लागि गोल हुन्छ।
    ///
    const INF_CUTOFF: i64;

    /// जब सब भन्दा महत्वपूर्ण दशमलव अंकको यस भन्दा कम स्थानको मान हुन्छ, संख्या निश्चित रूपमा शून्यमा गोल हुन्छ।
    ///
    const ZERO_CUTOFF: i64;

    /// घाता .्कमा बिट्सको संख्या।
    const EXP_BITS: u8;

    /// महत्वमा बिट्सको संख्या, * लुकाइएको बिट सहित।
    const SIG_BITS: u8;

    /// अर्थमा बिट्सको संख्या, * लुकाइएको बिट बाहेक।
    const EXPLICIT_SIG_BITS: u8;

    /// आंशिक प्रतिनिधित्वमा अधिकतम कानूनी घाता .्क।
    const MAX_EXP: i16;

    /// आंशिक प्रतिनिधित्व बाहेक न्यूनतम कानूनी घाता .्क।
    const MIN_EXP: i16;

    /// `MAX_EXP` अभिन्न प्रतिनिधित्वको लागि, अर्थात्, सिफ्ट सहित।
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` एन्कोड गरिएको (जस्तै, अफसेट पूर्वाग्रहको साथ)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` अभिन्न प्रतिनिधित्वको लागि, अर्थात्, सिफ्ट सहित।
    const MIN_EXP_INT: i16;

    /// अभिन्न प्रतिनिधित्व मा अधिकतम सामान्यीकृत महत्व।
    const MAX_SIG: u64;

    /// अभिन्न प्रतिनिधित्व मा न्यूनतम सामान्यीकृत महत्व।
    const MIN_SIG: u64;
}

// अधिकतर #34344 को लागी एक workaround।
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// म्यान्टिसा, घाता .्क र पूर्णांकको रूपमा साइन फर्काउँछ।
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // घातांक पूर्वाग्रह + मँटिसा शिफ्ट
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe अनिश्चित छ कि `as` सही सबै प्लेटफर्ममा राउन्ड गर्दछ।
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// म्यान्टिसा, घाता .्क र पूर्णांकको रूपमा साइन फर्काउँछ।
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // घातांक पूर्वाग्रह + मँटिसा शिफ्ट
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe अनिश्चित छ कि `as` सही सबै प्लेटफर्ममा राउन्ड गर्दछ।
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// एक `Fp` लाई नजीकको मेशिन फ्लोट प्रकारमा रूपान्तरण गर्दछ।
/// असामान्य परिणामहरू सम्हाल्दैन।
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f bit 64 बिट हो, त्यसैले xe को mant 63 को मन्टिसा सिफ्ट छ
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// आधा-देखि-सम्मको साथ T::SIG_BITS बिट्समा-64-बिट महत्वको राउन्ड गर्नुहोस्।
/// घाता .्क ओभरफ्लो ह्यान्डल गर्दैन।
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // म्यान्टिसा शिफ्ट समायोजित गर्नुहोस्
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// सामान्यीकृत संख्याहरूको लागि `RawFloat::unpack()` को विपरित।
/// Panics यदि महत्व या घातांक सामान्य नम्बरका लागि मान्य छैन।
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // लुकाइएको बिट हटाउनुहोस्
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // घातांक पूर्वाग्रह र मन्टिसा शिफ्टको लागि एक्सपोन्टर समायोजित गर्नुहोस्
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // 0 ("+") मा साइन बिट छोड्नुहोस्, हाम्रो संख्याहरू सबै सकारात्मक छन्
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// एक subnormal निर्माण।० को म्यान्टिसा अनुमति छ र शून्य निर्माण गर्दछ।
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // ईन्कोड गरिएको घाता 0्क ० हो, साइन बिट ० हो, त्यसैले हामीले बिट्सलाई पुनः व्याख्या गर्नु पर्छ।
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// एक एफपीको साथ अनुमानित बिग्नुम।0.5 ULP भित्र राउन्ड आधा-देखि-सम्मको साथ।
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // हामीले अनुक्रमणिका `start` भन्दा पहिले सबै बिट्स काट्यौं, अर्थात्, हामी प्रभावी रूपमा `start` को राशिबाट दायाँ-शिफ्ट, त्यसैले यो पनि हामीलाई चाहिने एक्सपोनेन्ट हो।
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // काटिएको बिट्समा निर्भर गर्दै गोल (half-to-even)।
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// आर्गुमेन्ट भन्दा कडा सानो स the्ख्यामा सब भन्दा ठूलो फ्लोटिंग पोइन्ट खोज्छ।
/// Subnormals, शून्य, वा घाता .्ग बहाव ह्यान्डल गर्दैन।
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// आर्गुमेन्ट भन्दा कडा भन्दा ठूलो फ्लोटिंग पोइन्ट नम्बर फेला पार्नुहोस्।
// यो अपरेशन स्याउरेटिंग हो, अर्थात्, next_float(inf) ==inf।
// यस मोड्युलमा प्राय जसो कोडको विपरीत यस प्रकार्यले शून्य, उपनर्मलहरू, र इन्फिनिटीहरू ह्यान्डल गर्दछ।
// यद्यपि यहाँ अन्य सबै कोडहरू जस्तै यो पनि NaN र negativeणात्मक नम्बरहरूको साथ काम गर्दैन।
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // यो सहि हुन एकदम राम्रो देखिन्छ, तर यसले काम गर्दछ।
        // 0.0 सबै-शून्य शब्दको रूपमा ईनकोड गरिएको छ।सब्नोर्मल ०x000 मीटर हो ... m जहाँ म्यान्टिसा हो।
        // विशेष रूपमा, सब भन्दा सानो सबनोर्मल ०x० ... ० र सबैभन्दा ठूलो ०x००F हो ... एफ।
        // सब भन्दा सानो सामान्य संख्या ०x0010 ... ० हो, त्यसैले यो कुना केसले पनि काम गर्दछ।
        // यदि इन्ट्रिमेन्ट मन्टिस्सालाई ओभरफ्लो गर्दछ भने क्यारी बिटले हामीले बढाउने ब्यक्तिलाई बढाउँदछ, र म्यान्टिसा बिट्स शून्य हुन्छ।
        // लुकाइएको बिट अधिवेशनको कारण, यो पनि हामी चाहान्छौं!
        // अन्तमा, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY।
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}