//! Bignums को लागि उपयोगिता कार्यहरू जुन विधिहरूमा परिवर्तन गर्न धेरै अर्थ राख्दैन।

// FIXME यस मोड्युलको नाम अलि दुर्भाग्यपूर्ण छ, किनकि अन्य मोड्युलहरूले पनि `core::num` आयात गर्दछ।

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// `ones_place` भन्दा कम सवै महत्वपूर्ण बिट्सलाई काट्ने कि सम्बन्धित छ कम, बराबर, वा 0.5 ULP भन्दा ठूलो सापेक्ष त्रुटि प्रस्तुत गर्दछ।
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // यदि सबै बाँकी बिट्स शून्य छन् भने, यो= 0.5 ULP, अन्यथा> 0.5 यदि त्यहाँ अधिक बिटहरू छैनन् भने (आधी_ बिट==०), तल पनि सही रूपमा बराबर फिर्ता हुन्छ।
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// दशमलव अ containing्कहरू सहितको ASCII स्ट्रिंगलाई `u64` मा बदल्छ।
///
/// ओभरफ्लो वा अवैध क्यारेक्टरहरूको लागि चेकहरू प्रदर्शन गर्दैन, त्यसैले यदि कलर सावधान भएन भने परिणाम बोगस हो र panic गर्न सक्दछ (यद्यपि यो `unsafe` हुनेछैन)।
/// थप रूपमा, खाली तारहरूलाई शून्य मानिन्छ।
/// यो प्रकार्य अवस्थित छ किनकि
///
/// 1. `&[u8]` मा `FromStr` प्रयोग गर्न `from_utf8_unchecked` आवश्यक छ, जुन खराब छ, र
/// 2. `integral.parse()` र `fractional.parse()` का परिणामहरू सँगै piecing यो सम्पूर्ण प्रकार्य भन्दा बढी जटिल छ।
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// ASCII अंकको एक स्ट्रि a बिग्नुममा रूपान्तरण गर्दछ।
///
/// `from_str_unchecked` जस्तै, यो प्रकार्य गैर-अ we्कलाई झारलाई पार्सरमा निर्भर गर्दछ।
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Bit 64 बिट पूर्णांकमा एक बिग्नेम अनप्रप गर्दछ।Panics यदि संख्या एकदम ठूलो छ।
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// बिट्सको दायरा निकाल्छ।

/// सूचकांक ० कम्तिमा महत्वपूर्ण बिट हो र दायरा सामान्य रूपमा आधा खुला छ।
/// Panics यदि फिर्ती प्रकार मा फिट भन्दा बढी बिट्स निकाल्न भनियो।
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}