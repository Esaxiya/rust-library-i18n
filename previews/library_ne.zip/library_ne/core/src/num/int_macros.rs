macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// सबैभन्दा सानो मान जुन यो पूर्णांक प्रकारले प्रतिनिधित्व गर्न सक्दछ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// यस पूर्णांक प्रकारले प्रतिनिधित्व गर्न सक्ने सबैभन्दा ठूलो मान।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// यस पूर्णांकको आकार बिट्समा।
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// दिइएको आधारमा एक स्ट्रिंग स्लाइस इन्टिजरमा रूपान्तरण गर्दछ।
        ///
        /// स्ट्रि एक वैकल्पिक `+` वा `-` साइन हुन अंकको लागी हुने अपेक्षा गरिएको छ।
        /// अग्रणी र ट्रेलि wh ह्वाइटस्पेसले त्रुटि प्रतिनिधित्व गर्दछ।
        /// अंकहरू यी पात्रहरूको सबसेट हुन्, `radix` को आधारमा:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// यो प्रकार्य panics यदि `radix` २ देखि from 36 को दायरामा छैन।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// `self` को बाइनरी प्रतिनिधित्वमा भएका व्यक्तिको संख्या फर्काउँछ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// `self` को बाइनरी प्रतिनिधित्वमा शून्यको संख्या फर्काउँछ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// `self` को बाइनरी प्रतिनिधित्वमा अग्रणी शून्यहरूको संख्या फर्काउँछ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// `self` को बाइनरी प्रतिनिधित्वमा पछाडि शून्यको संख्या फर्काउँछ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// `self` को बाइनरी प्रतिनिधित्वमा अग्रणीको संख्या फर्काउँछ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// `self` को बाइनरी प्रतिनिधित्वमा पछाडि संख्याको संख्या फर्काउँछ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// बिट्सलाई बायाँपट्टि निर्दिष्ट रकम, `n` द्वारा बदल्नुहोस्, काटिएको बिट्सलाई र्‍याप गरि परिणाम पूर्णा inte्कको अन्तमा।
        ///
        ///
        /// कृपया नोट गर्नुहोस् यो `<<` शिफ्टिंग अपरेटर जस्ता अपरेशन होइन!
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// बिट्सलाई दायाँ निर्दिष्ट रकममा बदल्नुहोस्, `n`, काटिएको बिट्सलाई र्यापिppingमा परिणामको पूर्णांकको सुरूमा।
        ///
        ///
        /// कृपया नोट गर्नुहोस् यो `>>` शिफ्टिंग अपरेटर जस्ता अपरेशन होइन!
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// पूर्णांकको बाइट क्रमलाई उल्टाउँदछ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// पूर्णांकमा बिट्सको क्रम बदल्छ।
        /// कम से कम महत्वपूर्ण बिट सबैभन्दा महत्त्वपूर्ण बिट हुन्छ, दोस्रो कम से कम महत्वपूर्ण बिट दोस्रो सबैभन्दा महत्त्वपूर्ण बिट हुन्छ, आदि।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// ठूलो इन्डियनबाट लक्ष्यको अन्त्यमा बदल्छ।
        ///
        /// ठूलो एन्डियनमा यो कुनै अप्ट छैन।सानो एन्डियनमा बाइटहरू अद्भुत हुन्छन्।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// यदि cfg! (लक्ष्य_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } अर्को {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// सानो इन्डियनबाट लक्ष्यको अन्त्यमा बदल्दछ।
        ///
        /// सानो एन्डियनमा यो कुनै अप्ट छैन।ठूला एरिडियनमा बाइटहरू स्वप हुन्छन्।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// यदि cfg! (लक्ष्य_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } अर्को {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// `self` लाई लक्ष्यको अन्त्यबाट ठूलो अन्डियनमा रूपान्तरण गर्दछ।
        ///
        /// ठूलो एन्डियनमा यो कुनै अप्ट छैन।सानो एन्डियनमा बाइटहरू अद्भुत हुन्छन्।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// यदि cfg! (लक्ष्य_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// X अन्य { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // वा हुन छैन?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// `self` लक्ष्यको endianness बाट सानो endian मा रूपान्तरण।
        ///
        /// सानो एन्डियनमा यो कुनै अप्ट छैन।ठूला एरिडियनमा बाइटहरू स्वप हुन्छन्।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// यदि cfg! (लक्ष्य_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// X अन्य { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// पूर्णांक थपको जाँच गरियो।
        /// गणना `self + rhs`, अधिक प्रवाह भए `None` फिर्ता।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// जाँच नगरिएको पूर्णांक थप।गणना `self + rhs`, अधिक प्रवाह हुन सक्दैन भनेर فرض गर्दै।
        /// यो अपरिभाषित व्यवहारमा जब परिणाम हुन्छ
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // सुरक्षा: कलरले `unchecked_add` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ।
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// पूर्णांक घटाव जाँच गरियो।
        /// गणना `self - rhs`, अधिक प्रवाह भए `None` फिर्ता।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// चेक नगरिएको पूर्णांक घटाव।गणना `self - rhs`, अधिक प्रवाह हुन सक्दैन भनेर فرض गर्दै।
        /// यो अपरिभाषित व्यवहारमा जब परिणाम हुन्छ
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // सुरक्षा: कलरले `unchecked_sub` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ।
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// पूर्णांकको गुणा जाँच गरियो।
        /// गणना `self * rhs`, अधिक प्रवाह भए `None` फिर्ता।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// चेक नगरिएको पूर्णांक गुणागणना `self * rhs`, अधिक प्रवाह हुन सक्दैन भनेर فرض गर्दै।
        /// यो अपरिभाषित व्यवहारमा जब परिणाम हुन्छ
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // सुरक्षा: कलरले `unchecked_mul` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ।
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// पूर्णांक विभाजन जाँच गरियो।
        /// गणना `self / rhs`, `None` फिर्ता यदि `rhs == 0` वा प्रभागले ओभरफ्लोमा परिणाम दिन्छ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // SAFETY: div द्वारा शून्य र INT_MIN द्वारा माथि जाँच गरिएको छ
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// युक्लिडियन डिभिजन जाँच गरियो।
        /// गणना `self.div_euclid(rhs)`, `None` फिर्ता यदि `rhs == 0` वा प्रभागले ओभरफ्लोमा परिणाम दिन्छ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// पूर्णांक शेष जाँच गरियो।
        /// गणना `self % rhs`, `None` फिर्ता यदि `rhs == 0` वा प्रभागले ओभरफ्लोमा परिणाम दिन्छ।
        ///
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // SAFETY: div द्वारा शून्य र INT_MIN द्वारा माथि जाँच गरिएको छ
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Euclidean शेष जाँच गरियो।
        /// गणना `self.rem_euclid(rhs)`, `None` फिर्ता यदि `rhs == 0` वा प्रभागले ओभरफ्लोमा परिणाम दिन्छ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// अस्वीकार जाँच गरियो।
        /// गणना `-self`, `None` फिर्ता यदि `self == MIN`।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// बायाँ जाँच गरियो।
        /// `self << rhs` गणना गर्दै, `None` फिर्ता गर्दै यदि `rhs` `self` मा बिट्सको संख्या भन्दा ठूलो वा बराबर छ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// दाँया सिफ्ट दाँजिएको छ।
        /// `self >> rhs` गणना गर्दै, `None` फिर्ता गर्दै यदि `rhs` `self` मा बिट्सको संख्या भन्दा ठूलो वा बराबर छ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// पूर्ण मान जाँच गरियो।
        /// गणना `self.abs()`, `None` फिर्ता यदि `self == MIN`।
        ///
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// जाँच गरियो
        /// गणना `self.pow(exp)`, अतिप्रवाह आयो भने `None` फिर्ता।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // exp बाट!=० पछि, म्याद १ हुनु पर्छ।
            // घाता .को अन्तिम बिटलाई अलगसँग सम्झौता गर्नुहोस्, किनकि पछि आधार बेस गर्न आवश्यक छैन र अनावश्यक ओभरफ्लोको कारण हुन सक्छ।
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Saturating पूर्णांक जोड।
        /// गणना `self + rhs`, अतिप्रवाहको सट्टा संख्यात्मक सीमामा भरिपूर्ण।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// पूर्णांक पूर्णांक घटाई।
        /// गणना `self - rhs`, अतिप्रवाहको सट्टा संख्यात्मक सीमामा भरिपूर्ण।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// पूर्णांक इन्टिग्रेसन स्याचुरटिंग।
        /// गणना `-self`, `MAX` फर्कदै यदि ओभरफ्लोको सट्टा `self == MIN`।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// पूर्ण मानको स्याचरेटि।।
        /// गणना `self.abs()`, `MAX` फर्कदै यदि ओभरफ्लोको सट्टा `self == MIN`।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// पूर्णांक पूर्णांकको गुणा
        /// गणना `self * rhs`, अतिप्रवाहको सट्टा संख्यात्मक सीमामा भरिपूर्ण।
        ///
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// पूर्णांकको संख्या घटाउँदै।
        /// गणना `self.pow(exp)`, अतिप्रवाहको सट्टा संख्यात्मक सीमामा भरिपूर्ण।
        ///
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// र्‍यापि X (modular) थप।
        /// प्रकारको बाउन्डरी वरिपरि लपेट्दै कम्प्युट्स `self + rhs`।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// र्‍यापि X (modular) घटाउ।
        /// प्रकारको बाउन्डरी वरिपरि लपेट्दै कम्प्युट्स `self - rhs`।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// र्‍यापि X (modular) गुणन।
        /// प्रकारको बाउन्डरी वरिपरि लपेट्दै कम्प्युट्स `self * rhs`।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// र्‍यापिंग (modular) डिभिजन।प्रकारको बाउन्डरी वरिपरि लपेट्दै कम्प्युट्स `self / rhs`।
        ///
        /// केवल त्यस्ता केसहरूमा र्यापि occur हुन सक्दछ जब एक हस्ताक्षरित प्रकारमा `MIN / -1` विभाजित गर्दछ (जहाँ `MIN` प्रकारको लागि न्यूनतम न्यूनतम मान हो);यो `-MIN` बराबर हो, एक सकारात्मक मान जुन प्रकारमा प्रतिनिधित्व गर्न एकदम ठूलो छ।
        /// यस्तो अवस्थामा, यो प्रकार्य `MIN` X आफै फिर्ता गर्दछ।
        ///
        /// # Panics
        ///
        /// यो प्रकार्य panic हुनेछ यदि `rhs` ० छ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// र्‍यापिंग युक्लिडियन डिभिजन।
        /// प्रकारको बाउन्डरी वरिपरि लपेट्दै कम्प्युट्स `self.div_euclid(rhs)`।
        ///
        /// र्‍यापिंग केवल `MIN / -1` मा हस्ताक्षरित प्रकारमा देखा पर्दछ (जहाँ `MIN` प्रकारको नकारात्मक न्यूनतम मान हो)।
        /// यो `-MIN` बराबर हो, एक सकारात्मक मान जुन प्रकारमा प्रतिनिधित्व गर्न एकदम ठूलो छ।
        /// यस अवस्थामा यस विधिले `MIN` आफै फिर्ता गर्दछ।
        ///
        /// # Panics
        ///
        /// यो प्रकार्य panic हुनेछ यदि `rhs` ० छ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// र्‍यापि X (modular) शेष।प्रकारको बाउन्डरी वरिपरि लपेट्दै कम्प्युट्स `self % rhs`।
        ///
        /// यस्तो र्‍याप-वरपर वास्तवमै कहिल्यै गणितीय हुँदैन;कार्यान्वयन कलाकृतिले `x % y` लाई हस्ताक्षरित प्रकारमा `MIN / -1` का लागि अवैध बनाउँदछ (जहाँ `MIN` नकारात्मक न्यूनतम मान हो)।
        ///
        /// यस्तो अवस्थामा, यो प्रकार्य `0` फर्काउँछ।
        ///
        /// # Panics
        ///
        /// यो प्रकार्य panic हुनेछ यदि `rhs` ० छ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// Euclidean शेष लपेट्दै।प्रकारको बाउन्डरी वरिपरि लपेट्दै कम्प्युट्स `self.rem_euclid(rhs)`।
        ///
        /// र्‍यापिंग केवल `MIN % -1` मा हस्ताक्षरित प्रकारमा देखा पर्दछ (जहाँ `MIN` प्रकारको नकारात्मक न्यूनतम मान हो)।
        /// यस अवस्थामा यस विधि ० ले फर्काउँछ।
        ///
        /// # Panics
        ///
        /// यो प्रकार्य panic हुनेछ यदि `rhs` ० छ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// र्‍यापिंग (modular) नकारात्मकता।प्रकारको बाउन्डरी वरिपरि लपेट्दै कम्प्युट्स `-self`।
        ///
        /// केवल त्यस्ता केसहरूमा र्यापि occur हुन सक्दछ जब एक हस्ताक्षरित प्रकारमा `MIN` लाई बेवास्ता गर्दछ (जहाँ `MIN` प्रकारको नकारात्मक न्यूनतम मान हो);यो एक सकारात्मक मान हो जुन प्रकारमा प्रतिनिधित्व गर्न धेरै ठूलो छ।
        /// यस्तो अवस्थामा, यो प्रकार्य `MIN` X आफै फिर्ता गर्दछ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic मुक्त बिटवाइज शिफ्ट-बाँया;`self << mask(rhs)`, जहाँ `mask` `rhs` को कुनै पनि उच्च अर्डर बिट्स हटाउँछ कि शिफ्ट प्रकार को बिटविड्थ पार गर्न को कारण पैदा गर्दछ।
        ///
        /// नोट गर्नुहोस् कि यो *घुमाइएको बायाँ जस्तो* होईन;र्‍यापिpping शिफ्ट-बाँयाको RHS प्रकारको दायरामा प्रतिबन्धित छ, LHS बाट बाहिर सर्ने बिट्सलाई अर्को छेउमा फर्काइनु भन्दा।
        ///
        /// आदिम पूर्णांक प्रकारहरू सबै [`rotate_left`](Self::rotate_left) प्रकार्य कार्यान्वयन गर्दछ, जुन तपाईं यसको सट्टामा चाहानु हुने हुन सक्छ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // सुरक्षा: यस प्रकारको बिट्सइजले मास्किंगले सुनिश्चित गर्दछ कि हामी शिफ्ट हुँदैनौं
            // सीमा बाहिर
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-free bitwise shift-सही;`self >> mask(rhs)`, जहाँ `mask` `rhs` को कुनै पनि उच्च अर्डर बिट्स हटाउँछ कि शिफ्ट प्रकार को बिटविड्थ भन्दा बढाउन कारण पैदा गर्दछ।
        ///
        /// नोट गर्नुहोस् कि यो *घुमाउन दायाँ जस्तो* होईन;र्‍यापिpping शिफ्ट-राइटको RHS प्रकारको दायरामा प्रतिबन्धित छ, LHS बाट बाहिर सर्ने बिट्सलाई अर्को छेउमा फर्काइनु भन्दा।
        ///
        /// आदिम पूर्णांक प्रकारहरू सबै [`rotate_right`](Self::rotate_right) प्रकार्य कार्यान्वयन गर्दछ, जुन तपाईं यसको सट्टामा चाहानु हुने हुन सक्छ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // सुरक्षा: यस प्रकारको बिट्सइजले मास्किंगले सुनिश्चित गर्दछ कि हामी शिफ्ट हुँदैनौं
            // सीमा बाहिर
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// र्‍यापि X (modular) निरपेक्ष मान।प्रकारको बाउन्डरी वरिपरि लपेट्दै कम्प्युट्स `self.abs()`।
        ///
        /// केवल त्यस्ता केसहरूमा र्यापि occur हुन सक्दछ जब एक प्रकारको लागि नकारात्मक न्यूनतम मानको पूर्ण मान लिन्छ;यो एक सकारात्मक मान हो जुन प्रकारमा प्रतिनिधित्व गर्न धेरै ठूलो छ।
        /// यस्तो अवस्थामा, यो प्रकार्य `MIN` X आफै फिर्ता गर्दछ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// कुनै रैपिंग वा पन्कि without बिना `self` को निरपेक्ष मानको गणना गर्दछ।
        ///
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// र्‍यापिंग (modular) एक्सपोनेन्सेसन।
        /// प्रकारको बाउन्डरी वरिपरि लपेट्दै कम्प्युट्स `self.pow(exp)`।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // exp बाट!=० पछि, म्याद १ हुनु पर्छ।
            // घाता .को अन्तिम बिटलाई अलगसँग सम्झौता गर्नुहोस्, किनकि पछि आधार बेस गर्न आवश्यक छैन र अनावश्यक ओभरफ्लोको कारण हुन सक्छ।
            //
            //
            acc.wrapping_mul(base)
        }

        /// `self` + `rhs` गणना गर्दछ
        ///
        /// अंकको अंकगणित ओभरफ्लो हुन्छ वा हुँदैन भन्ने कुरा बुझाउने बुलियनको साथमा जोडको टपल फर्काउँछ।
        /// यदि एक ओभरफ्लो भएको भए त र्याप गरिएको मान फिर्ता हुन्छ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self`, `rhs` गणना गर्दछ
        ///
        /// बुलियनको साथ घटाउको टपल फर्काउँछ जुन अंकगणित ओभरफ्लो हुन्छ वा हुँदैन।
        /// यदि एक ओभरफ्लो भएको भए त र्याप गरिएको मान फिर्ता हुन्छ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` र `rhs` को गुणा गणना गर्दछ।
        ///
        /// अंकले अंकगणित ओभरफ्लो हुन्छ वा हुँदैन भन्ने बुझाउने बुलियनको साथ गुणाको टपल फर्काउँछ।
        /// यदि एक ओभरफ्लो भएको भए त र्याप गरिएको मान फिर्ता हुन्छ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (१100१656565०40०8, सत्य));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` `rhs` द्वारा विभाजित हुँदा भाजक गणना गर्दछ।
        ///
        /// अंकगणित ओभरफ्लो हुन्छ वा हुँदैन भन्ने बुझाउने बुलियनको साथ विभाजकको टपल फर्काउँछ।
        /// यदि एक ओभरफ्लो भयो भने आफैं फिर्ता हुन्छ।
        ///
        /// # Panics
        ///
        /// यो प्रकार्य panic हुनेछ यदि `rhs` ० छ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// युक्लिडियन डिभिजन `self.div_euclid(rhs)` को योगफल गणना गर्दछ।
        ///
        /// अंकगणित ओभरफ्लो हुन्छ वा हुँदैन भन्ने बुझाउने बुलियनको साथ विभाजकको टपल फर्काउँछ।
        /// यदि एक ओभरफ्लो हुन्छ भने `self` फिर्ता हुन्छ।
        ///
        /// # Panics
        ///
        /// यो प्रकार्य panic हुनेछ यदि `rhs` ० छ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// `rhs` लाई `rhs` द्वारा विभाजित गर्दा शेष गणना गर्दछ।
        ///
        /// अंकको गणित अतिप्रवाह हुनेछ कि हुँदैन भन्ने बुझाउने बुलियनको साथ भाग पछि बाँकीको टपल फर्काउँछ।
        /// यदि एक ओभरफ्लो हुन्छ भने ० फिर्ता हुन्छ।
        ///
        /// # Panics
        ///
        /// यो प्रकार्य panic हुनेछ यदि `rhs` ० छ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// ओभरफ्लो गर्ने युक्लिडियन शेष।`self.rem_euclid(rhs)` गणना गर्दछ।
        ///
        /// अंकको गणित अतिप्रवाह हुनेछ कि हुँदैन भन्ने बुझाउने बुलियनको साथ भाग पछि बाँकीको टपल फर्काउँछ।
        /// यदि एक ओभरफ्लो हुन्छ भने ० फिर्ता हुन्छ।
        ///
        /// # Panics
        ///
        /// यो प्रकार्य panic हुनेछ यदि `rhs` ० छ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// Negates आत्म, अतिप्रवाह यदि यो न्यूनतम मान बराबर हो।
        ///
        /// ओभरफ्लो भयो वा छैन भनेर दर्साउने बुलियनको साथ आफैंको उपेक्षित संस्करणको टपल फर्काउँछ।
        /// यदि `self` न्यूनतम मान हो (उदाहरणका लागि `i32::MIN` प्रकारका मानहरूको लागि `i32::MIN`), तब न्यूनतम मान फेरि फिर्ता हुनेछ र `true` ओभरफ्लो हुने क्रममा फिर्ता हुनेछ।
        ///
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// `rhs` बिट्स द्वारा स्वयं बायाँ बदल्नुहोस्।
        ///
        /// शिफ्ट मान बिट्सको स than्ख्या भन्दा ठूलो वा बराबर थियो कि छैन भन्ने बुझाउने बुलियनको साथ स्वचालित रूपान्तरित संस्करणको टपल फर्काउँछ।
        /// यदि सिफ्ट मान धेरै ठूलो छ भने, तब मान मास्क गरिएको छ (N-1) जहाँ N बिट्सको संख्या हो, र यो मान पारी प्रदर्शन गर्न प्रयोग गरिन्छ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (०x10, सही));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// `rhs` बिट्स द्वारा स्वयं सिफ्ट गरियो।
        ///
        /// शिफ्ट मान बिट्सको स than्ख्या भन्दा ठूलो वा बराबर थियो कि छैन भन्ने बुझाउने बुलियनको साथ स्वचालित रूपान्तरित संस्करणको टपल फर्काउँछ।
        /// यदि सिफ्ट मान धेरै ठूलो छ भने, तब मान मास्क गरिएको छ (N-1) जहाँ N बिट्सको संख्या हो, र यो मान पारी प्रदर्शन गर्न प्रयोग गरिन्छ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (०x१, सत्य));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// `self` को निरपेक्ष मान गणना गर्दछ।
        ///
        /// अति बुलियनको साथ आफैको निरपेक्ष संस्करणको ट्यपल फिर्ता गर्छ जुन एक ओभरफ्लो भयो वा छैन भनेर दर्साउँछ।
        /// यदि आत्म न्यूनतम मान हो
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// तब न्यूनतम मान फेरि फिर्ता हुनेछ र एक ओभरफ्लो हुनको लागि सत्य फिर्ता हुनेछ।
        ///
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// वर्गीकरणको आधारमा एक्सपोन्सेन्टेसनको प्रयोग गरेर, `exp` को शक्तिमा आफूलाई बढाउँछ।
        ///
        /// एक bool साथ एक अधिक प्रवाह भयो कि भनेर दर्साउँदै exponenseation को एक tuple फर्काउँछ।
        ///
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, सही));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // ओभरफ्लोइ__मुलका नतीजाहरू भण्डारणका लागि स्क्र्याच स्पेस।
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // exp बाट!=० पछि, म्याद १ हुनु पर्छ।
            // घाता .को अन्तिम बिटलाई अलगसँग सम्झौता गर्नुहोस्, किनकि पछि आधार बेस गर्न आवश्यक छैन र अनावश्यक ओभरफ्लोको कारण हुन सक्छ।
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// वर्गीकरणको आधारमा एक्सपोन्सेन्टेसनको प्रयोग गरेर, `exp` को शक्तिमा आफूलाई बढाउँछ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // exp बाट!=० पछि, म्याद १ हुनु पर्छ।
            // घाता .को अन्तिम बिटलाई अलगसँग सम्झौता गर्नुहोस्, किनकि पछि आधार बेस गर्न आवश्यक छैन र अनावश्यक ओभरफ्लोको कारण हुन सक्छ।
            //
            //
            acc * base
        }

        /// `rhs` द्वारा `self` को Euclidean डिवीजनको भागफल गणना गर्दछ।
        ///
        /// यसले पूर्णांक `n` गणना गर्दछ जस्तै `self = n * rhs + self.rem_euclid(rhs)`, `0 <= self.rem_euclid(rhs) < rhs` का साथ।
        ///
        ///
        /// अर्को शब्दहरुमा, नतिजा `self / rhs` पूर्णांक `n` को गोलाकार हुन्छ कि `self >= n * rhs`।
        /// यदि `self > 0`, यो शून्य तिर गोल बराबर हो (Rust मा पूर्वनिर्धारित);
        /// यदि `self < 0`, यो गोल गोल बराबर +/-अनन्त तिर।
        ///
        /// # Panics
        ///
        /// यो प्रकार्य panic हुनेछ यदि `rhs` ० छ वा प्रभागले ओभरफ्लोमा परिणाम दिन्छ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// गरौं b=4;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //>>= * * १ assert_eq!(a.div_euclid(-b), -1);//7>= -4 *-1 assert_eq!((-a).div_euclid(b), -2);//-7>=4*-2 assert_eq!((-a).div_euclid(-b), 2);//-7>= -4 * २
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// `self (mod rhs)` को कम्तिमा nonnegative शेष गणना गर्दछ।
        ///
        /// यो यस्तै गरीएको छ यदि यूक्लिडियन डिभिजन एल्गोरिथ्म द्वारा दिइएको-`r = self.rem_euclid(rhs)`, `self = rhs * self.div_euclid(rhs) + r`, र `0 <= r < abs(rhs)`।
        ///
        ///
        /// # Panics
        ///
        /// यो प्रकार्य panic हुनेछ यदि `rhs` ० छ वा प्रभागले ओभरफ्लोमा परिणाम दिन्छ।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// गरौं b=4;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// `self` को निरपेक्ष मान गणना गर्दछ।
        ///
        /// # अतिप्रवाह व्यवहार
        ///
        /// को निरपेक्ष मान
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// प्रतिनिधित्व गर्न सकिदैन
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// र गणना गर्न को लागी प्रयास एक ओभरफ्लो हुनेछ।
        /// यसको मतलब यो कि डिबग मोडमा कोडले panic यस केसमा ट्रिगर गर्दछ र अनुकूलित कोड फिर्ता हुनेछ
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// panic बिना।
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // नोट गर्नुहोस् कि माथिको#[इनलाइन] मतलब यो हो कि घटाउको ओभरफ्लो अर्थ अर्थशास्त्र crate मा निर्भर गर्दछ जुन हामी भित्र छिरेका छौं।
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// `self` को प्रतिनिधित्व गर्ने संख्या फिर्ता गर्छ।
        ///
        ///  - `0` यदि संख्या शून्य छ भने
        ///  - `1` यदि संख्या सकारात्मक छ
        ///  - `-1` यदि संख्या नकारात्मक छ
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// यदि `self` सकारात्मक छ भने `true` र `false` फर्काउँछ यदि संख्या शून्य वा नकारात्मक हो।
        ///
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// `true` X नकारात्मक छ र `false` फर्काउँछ यदि संख्या शून्य वा धनात्मक हो।
        ///
        ///
        /// # Examples
        ///
        /// आधारभूत उपयोग:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// यस पूर्णांकको मेमोरी प्रतिनिधित्व बिग एन्डियन (network) बाइट क्रममा बाइट एर्रेको रूपमा फर्काउनुहोस्।
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// यस पूर्णांकको मेमोरी प्रतिनिधित्व थोरै-एन्डियन बाइट क्रममा बाइट एर्रेको रूपमा फर्काउनुहोस्।
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// नेटिभ बाइट क्रममा बाइट एर्रेको रूपमा यो पूर्णांकको मेमोरी प्रतिनिधित्व फर्काउनुहोस्।
        ///
        /// लक्षित प्लेटफर्मको मूल endianness को रूप मा, पोर्टेबल कोड को सट्टा [`to_be_bytes`] वा [`to_le_bytes`], उचित को रूप मा प्रयोग गर्नु पर्छ।
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     बाइट्स, यदि cfg! (लक्ष्य_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } अर्को {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // सुरक्षा: कन्स्ट्रन्ट ध्वनि किनभने इन्टिजरहरू प्लेन पुरानो डाटाटाइपहरू हुन्छन् ताकि हामी सँधै गर्न सक्दछौं
        // तिनीहरूलाई बाइट्सको एरेमा ट्रान्समिट गर्नुहोस्
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // सुरक्षा: पूर्णांकहरू पुरानो डाटाटाइपहरू हुन् त्यसैले हामी तिनीहरूलाई सँधै ट्रान्समिट गर्न सक्दछौं
            // बाइट्सको एर्रे
            unsafe { mem::transmute(self) }
        }

        /// नेटिभ बाइट क्रममा बाइट एर्रेको रूपमा यो पूर्णांकको मेमोरी प्रतिनिधित्व फर्काउनुहोस्।
        ///
        ///
        /// [`to_ne_bytes`] सम्भव भएसम्म यस भन्दा बढि चाहिन्छ।
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// बाइट्स= num.as_ne_bytes();
        /// assert_eq!(
        ///     बाइट्स, यदि cfg! (लक्ष्य_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } अर्को {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // सुरक्षा: पूर्णांकहरू पुरानो डाटाटाइपहरू हुन् त्यसैले हामी तिनीहरूलाई सँधै ट्रान्समिट गर्न सक्दछौं
            // बाइट्सको एर्रे
            unsafe { &*(self as *const Self as *const _) }
        }

        /// यसको प्रतिनिधित्वबाट पूर्ण अन्डियनमा बाइट एर्रेको रूपमा पूर्णांक मान सिर्जना गर्नुहोस्।
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto प्रयोग गर्नुहोस्;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * इनपुट=बाकी;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// सानो इन्डियनमा बाइट एर्रेको रूपमा यसको प्रतिनिधित्वबाट पूर्णांक मान सिर्जना गर्नुहोस्।
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto प्रयोग गर्नुहोस्;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * इनपुट=बाकी;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// नेटिभ इन्डियाननेसमा बाइट एरेको रूपमा यसको मेमोरी प्रतिनिधित्वबाट पूर्णांक मान सिर्जना गर्नुहोस्।
        ///
        /// लक्ष्य प्लेटफर्मको मूल endianness को रूप मा प्रयोग गरिएको छ, पोर्टेबल कोड सम्भवतः उपयुक्त को रूप मा, [`from_be_bytes`] वा [`from_le_bytes`] प्रयोग गर्न चाहन्छ।
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } अर्को {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto प्रयोग गर्नुहोस्;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * इनपुट=बाकी;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // सुरक्षा: कन्स्ट्रन्ट ध्वनि किनभने इन्टिजरहरू प्लेन पुरानो डाटाटाइपहरू हुन्छन् ताकि हामी सँधै गर्न सक्दछौं
        // तिनीहरूमा ट्रान्समिट गर्नुहोस्
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // सुरक्षा: पूर्णांकहरू पुरानो डाटाटाइपहरू हुन् त्यसैले हामी सँधै तिनीहरूलाई ट्रान्समिट गर्न सक्दछौं
            unsafe { mem::transmute(bytes) }
        }

        /// नयाँ कोड प्रयोग गर्न रुचाउनु पर्छ
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// सबैभन्दा सानो मान फर्काउँछ जुन यस पूर्णांक प्रकारले प्रतिनिधित्व गर्न सक्दछ।
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// नयाँ कोड प्रयोग गर्न रुचाउनु पर्छ
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// यस पूर्णांक प्रकारले प्रतिनिधित्व गर्न सक्ने सबैभन्दा ठूलो मान फर्काउँछ।
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}