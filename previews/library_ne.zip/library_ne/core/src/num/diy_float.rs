//! विस्तारित सटीकता "soft float", आन्तरिक प्रयोगको लागि मात्र।

// यो मोड्युल केवल dec2flt र flt2dec को लागी हो, र कोर्सेट्स को कारण मात्र सार्वजनिक।
// यो सँधै स्थिर हुने उद्देश्यले गरिएको छैन।
#![doc(hidden)]
#![unstable(
    feature = "core_private_diy_float",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

/// कस्टम 64 64-बिट फ्लोटिंग पोइन्ट प्रकार, `f * 2^e` प्रतिनिधित्व गर्दछ।
#[derive(Copy, Clone, Debug)]
#[doc(hidden)]
pub struct Fp {
    /// पूर्णांक मन्टिसा।
    pub f: u64,
    /// बेस २ मा घातांक।
    pub e: i16,
}

impl Fp {
    /// आफै र `other` को एक सही राउन्ड उत्पाद फर्काउँछ।
    pub fn mul(&self, other: &Fp) -> Fp {
        const MASK: u64 = 0xffffffff;
        let a = self.f >> 32;
        let b = self.f & MASK;
        let c = other.f >> 32;
        let d = other.f & MASK;
        let ac = a * c;
        let bc = b * c;
        let ad = a * d;
        let bd = b * d;
        let tmp = (bd >> 32) + (ad & MASK) + (bc & MASK) + (1 << 31) /* round */;
        let f = ac + (ad >> 32) + (bc >> 32) + (tmp >> 32);
        let e = self.e + other.e + 64;
        Fp { f, e }
    }

    /// आफैंलाई सामान्य बनाउँदछ ताकि नतीजा मन्टिस्सा कम्तिमा `2^63` हुन्छ।
    pub fn normalize(&self) -> Fp {
        let mut f = self.f;
        let mut e = self.e;
        if f >> (64 - 32) == 0 {
            f <<= 32;
            e -= 32;
        }
        if f >> (64 - 16) == 0 {
            f <<= 16;
            e -= 16;
        }
        if f >> (64 - 8) == 0 {
            f <<= 8;
            e -= 8;
        }
        if f >> (64 - 4) == 0 {
            f <<= 4;
            e -= 4;
        }
        if f >> (64 - 2) == 0 {
            f <<= 2;
            e -= 2;
        }
        if f >> (64 - 1) == 0 {
            f <<= 1;
            e -= 1;
        }
        debug_assert!(f >= (1 >> 63));
        Fp { f, e }
    }

    /// आफैलाई साझा घाता .्कको लागि सामान्य बनाउँदछ।
    /// यसले केवल घाता घटाउन सक्छ (र यसरी म्यान्टिसा बढाउछ)।
    pub fn normalize_to(&self, e: i16) -> Fp {
        let edelta = self.e - e;
        assert!(edelta >= 0);
        let edelta = edelta as usize;
        assert_eq!(self.f << edelta >> edelta, self.f);
        Fp { f: self.f << edelta, e }
    }
}