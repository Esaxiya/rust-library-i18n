//! अनुकूलन मध्यस्थता-सटीक संख्या (bignum) कार्यान्वयन।
//!
//! यो स्ट्याक मेमोरीको खर्चमा हिप एलोभसनलाई बेवास्ता गर्न डिजाइन गरिएको हो।
//! सबै भन्दा बढि प्रयोग गरिएको बिग्नुम प्रकार, `Big32x40`, ×२ ×=०=१,२80० बिट्स द्वारा सीमित छ र अधिकतम १ 160० बाइट्स स्ट्याक मेमोरीमा लिन्छ।
//! सबै सम्भावित सिमित `f64` मानहरूलाई राउन्ड-ट्रिपिंगको लागि यो पर्याप्त छ।
//!
//! सिद्धान्तमा विभिन्न इनपुटहरूका लागि बहुबिग्नुम प्रकारहरू हुन सम्भव छ, तर हामी कोड ब्लोटबाट बच्न त्यसो गर्दैनौं।
//!
//! प्रत्येक बिग्नुम अझै वास्तविक उपयोगहरूको लागि ट्र्याक गरिएको छ, त्यसैले यसले सामान्यतया फरक पार्दैन।
//!

// यो मोड्युल केवल dec2flt र flt2dec को लागी हो, र कोर्सेट्स को कारण मात्र सार्वजनिक।
// यो सँधै स्थिर हुने उद्देश्यले गरिएको छैन।
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// Bignums द्वारा अंकगणित अपरेशनहरू आवश्यक छन्।
pub trait FullOps: Sized {
    /// `(carry', v')` फिर्ता दिन्छ कि `carry' * 2^W + v' = self + other + carry`, जहाँ `W` `Self` मा बिटको संख्या हो।
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// `(carry', v')` फिर्ता दिन्छ कि `carry'*2^W + v' = self* other + carry`, जहाँ `W` `Self` मा बिटको संख्या हो।
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// `(carry', v')` फिर्ता दिन्छ कि `carry'*2^W + v' = self* other + other2 + carry`, जहाँ `W` `Self` मा बिटको संख्या हो।
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// `(quo, rem)` यस्तो `borrow *2^W + self = quo* other + rem` र `0 <= rem < other` फर्काउँछ, जहाँ `W` `Self` मा बिटहरूको संख्या हो।
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // यो ओभरफ्लो हुन सक्दैन;आउटपुट `0` र `2 * 2^nbits - 1` बीच हो।
                    // FIXME: के LLVM यसलाई ADC वा समानमा अनुकूलित गर्दछ?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // यो ओभरफ्लो हुन सक्दैन;
                    // आउटपुट `0` र `2^nbits * (2^nbits - 1)` बीच हो।
                    // FIXME: के LLVM यसलाई ADC वा समानमा अनुकूलित गर्दछ?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // यो ओभरफ्लो हुन सक्दैन;
                    // आउटपुट `0` र `2^nbits * (2^nbits - 1)` बीच हो।
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // यो ओभरफ्लो हुन सक्दैन;आउटपुट `0` र `other * (2^nbits - 1)` बीच हो।
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // यसलाई सक्षम गर्नको लागि RFC #521 हेर्नुहोस्।
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// अ in्कमा प्रतिनिधित्व गर्न in को शक्तिहरूको तालिका।विशेष रूपमा, सब भन्दा ठूलो {u8, u16, u32} मान जुन पाँचको पावर, साथै सम्बन्धित घातांकको पावर हो।
/// `mul_pow5` मा प्रयोग भयो।
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// स्ट्याक-आवंटित मध्यस्थता-सटीकता (निश्चित सीमा सम्म) पूर्णांक।
        ///
        /// यो दिइएको प्रकार ("digit") को एक निश्चित-आकार एरे द्वारा समर्थित छ।
        /// जबकि एर्रे धेरै ठूलो छैन (सामान्यतया केहि सय बाइट्स), लापरवाह रूपमा यसको प्रतिलिपि बनाउँदा परिणाम प्रदर्शन हिट हुन सक्छ।
        ///
        /// यसैले यो जानाजानी `Copy` होईन।
        ///
        /// सबै अपरेशनहरू Bignums panic मा उपलब्ध छ ओभरफ्लोको मामलामा।
        /// कलर ठूलो पर्याप्त बिग्नुम प्रकारहरू प्रयोग गर्न जिम्मेदार छ।
        pub struct $name {
            /// एक प्लस अफसेटमा अधिकतम "digit" प्रयोगमा।
            /// यो कम हुँदैन, त्यसैले गणना क्रममा सचेत रहनुहोस्।
            /// `base[size..]` शून्य हुनु पर्छ।
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` प्रतिनिधित्व गर्दछ `a + b *2^W + c* 2^(2W) + ...` जहाँ `W` अंक प्रकारमा बिट्सको संख्या हो।
            base: [$ty; $n],
        }

        impl $name {
            /// एक अंक बाट एक bignum बनाउँछ।
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// `u64` मानबाट एक बिग्नेम बनाउँदछ।
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// आन्तरिक अंकलाई टुक्रा `[a, b, c, ...]` को रूपमा फर्काउँछ जुन संख्यात्मक मान `a + b *2^W + c* 2^(2W) + ...` हुन्छ जहाँ `W` अ type्कको बिटको संख्या हो।
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// Bit i`-th बिट फर्काउँछ जहाँ बिट ० कम से कम महत्वपूर्ण छ।
            /// अर्को शब्दहरुमा, वजन `2^i` को साथ बिट।
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// यदि बिग्नुम शून्य छ भने `true` फर्काउँछ।
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// यो मान प्रतिनिधित्व गर्न आवश्यक बिट्सको संख्या फर्काउँछ।
            /// नोट गर्नुहोस् कि शून्यलाई ० बिट्स चाहिन्छ।
            pub fn bit_length(&self) -> usize {
                // सबैभन्दा महत्त्वपूर्ण अंकहरूमा जानुहोस् जुन शून्य हो।
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // त्यहाँ कुनै गैर-शून्य अंकहरू छैनन्, अर्थात् संख्या शून्य हो।
                    return 0;
                }
                // यो leading_zeros() र बिट शिफ्टहरु संग अप्टिमाइज गर्न सकिन्छ, तर यो समस्या को लायक छैन।
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// आफैमा `other` थप गर्दछ र आफ्नै म्युटेबल सन्दर्भ फर्काउँछ।
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// आफैंबाट `other` घटाउँछ र आफ्नै म्युटेबल सन्दर्भ फर्काउँछ।
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// अंकको आकारको `other` बाट गुणा गर्दछ र आफ्नै म्युटेबल सन्दर्भ फर्काउँछ।
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// `2^bits` ले गुणा गर्दछ र आफ्नै म्युटेबल सन्दर्भ फर्काउँछ।
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // `digits * digitbits` बिट्स द्वारा सिफ्ट
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // `bits` बिट्स द्वारा सिफ्ट
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // सेल्फ.बेस [.. अंक] शून्य हो, सिफ्ट गर्न आवश्यक पर्दैन
                }

                self.size = sz;
                self
            }

            /// `5^e` ले गुणा गर्दछ र आफ्नै म्युटेबल सन्दर्भ फर्काउँछ।
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // त्यहाँ २ ^ n मा ठीक एन ट्रेलिंग शून्यहरू छन्, र केवल सान्दर्भिक अंक आकारहरू दुईको लगातार शक्तिहरू छन्, त्यसैले यो तालिकाको लागि राम्रो सूचकांक हो।
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // सम्भव भएसम्म सबैभन्दा ठूलो एकल अंकको पावरसँग गुणन गर्नुहोस् ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... त्यसपछि बाँकी समाप्त।
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` (जहाँ `W` अ type्क प्रकारमा बिट्सको संख्या हो) द्वारा वर्णन गरिएको संख्याले गुणा गर्दछ र आफ्नै म्युटेबल सन्दर्भ फर्काउँछ।
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // आन्तरिक तालिका aa.len() <= bb.len() जब उत्तम कार्य गर्दछ।
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// आफैलाई एक अंकको आकारको `other` द्वारा विभाजित गर्दछ र आफ्नै म्युटेबल सन्दर्भ *र* बाँकी फर्काउँछ।
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// अर्को बिगिनमद्वारा आफैलाई विभाजन गर्नुहोस्, `q` लाई भावीसँग ओभरराइट गर्दै र शेषको साथ `r`।
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // मूर्ख ढिलो base-2 लामो विभाजन बाट लिइएको
                // https://en.wikipedia.org/wiki/Division_algorithm
                // FIXME ले लामो डिभिजनको लागि अधिक ठूलो आधार ($ty) प्रयोग गर्दछ।
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // १ लाई बिट `i` सेट गर्नुहोस्।
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// `Big32x40` का लागि अंक प्रकार।
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// यो एक मात्र परीक्षणको लागि प्रयोग गरीन्छ।
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}