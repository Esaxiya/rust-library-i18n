//! कम्पाइलर ईन्टरिक्स
//!
//! सम्बन्धित परिभाषाहरू `compiler/rustc_codegen_llvm/src/intrinsic.rs` मा छन्।
//! सम्बन्धित कन्स्ट्रक्ट कार्यान्वयनहरू `compiler/rustc_mir/src/interpret/intrinsics.rs` मा छन्
//!
//! # कन्स्ट इन्ट्रिक्स
//!
//! Note: आन्तरिकताको स्थिरतामा कुनै परिवर्तन भाषा टीमसँग छलफल गर्नुपर्दछ।
//! यसले स्थिरताको स्थिरतामा परिवर्तनहरू समावेश गर्दछ।
//!
//! कम्पाइल समयमा ईन्टरसिन्को उपयोगी बनाउनको लागि, XL1X बाट `compiler/rustc_mir/src/interpret/intrinsics.rs` मा कार्यान्वयनको प्रतिलिपि गर्न आवश्यक छ र `#[rustc_const_unstable(feature = "foo", issue = "01234")]` ईन्टरिसिकमा थप्न आवश्यक छ।
//!
//!
//! यदि ईन्टर्न्सिक `const fn` एट्रिब्युट `rustc_const_stable` एट्रिब्युटको साथ प्रयोग गरिएको छ भने, ईन्टर्न्सिकको विशेषता पनि `rustc_const_stable` हुनुपर्दछ।
//! यस्तो परिवर्तन टी-लै consultation्ग परामर्श बिना हुनु हुँदैन, किनकि यसले भाषामा यस्तो सुविधा ल्याउँदछ जुन कम्पाइलर समर्थन बिना प्रयोगकर्ता कोडमा नक्कल गर्न सकिँदैन।
//!
//! # Volatiles
//!
//! अस्थिर इंटिरनिक्सले I/O मेमोरीमा कार्य गर्ने उद्देश्यले अपरेशन्स प्रदान गर्दछ, जुन अन्य अस्थिर इंटिरनिक्सहरूमा कम्पाइलरद्वारा क्रमबद्ध नगर्न ग्यारेन्टी गरिन्छ।LLVM कागजात [[volatile]] मा हेर्नुहोस्।
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! आणविक ईन्ट्रिन्सिक्सले धेरै सम्भावित मेमोरी अर्डरिंगहरूको साथ, मेशिन शब्दहरूमा साधारण आणविक अपरेशनहरू प्रदान गर्दछ।तिनीहरू C++ 11 को समान अर्थशास्त्र पालन गर्छन्।LLVM कागजात [[atomics]] मा हेर्नुहोस्।
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! मेमोरी अर्डरिंगमा एक द्रुत रिफ्रेसर:
//!
//! * ताल्चा प्राप्त गर्नका लागि अवरोध प्राप्त गर्नुहोस्।पछि पढ्ने र लेख्ने रोकावट पछि हुन्छ।
//! * रिलीज गर्नुहोस्, लक जारी गर्नको लागि बाधा।अघिल्लो पढ्ने र लेख्ने रोकावट अघि ठाउँ लिन्छ।
//! * अनुक्रमिक रूपमा सुसंगत, क्रमिक रूपमा लगातार क्रियाहरू क्रममा हुने ग्यारेन्टी हुन्छ।यो आणविक प्रकारहरूसँग काम गर्नको लागि मानक मोड हो र Java को `volatile` बराबर हो।
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// यी आयातहरू इंट्रा-कागजात लिंकहरू सरलीकरणको लागि प्रयोग गरिन्छ
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // सुरक्षा: `ptr::drop_in_place` हेर्नुहोस्
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, यी आंतरिकहरूले कच्चा सters्केतहरू लिन्छन् किनकि तिनीहरू एलाइज्ड मेमोरी परिवर्तन गर्छन्, जुन कि त `&` वा `&mut` को लागि मान्य छैन।
    //

    /// भण्डार गर्दछ यदि हालको मान `old` मान जस्तै हो।
    ///
    /// [`Ordering::SeqCst`] र [`Ordering::SeqCst`] दुबै `success` लाई पार गरेर `compare_exchange` विधि मार्फत X0 `failure` विधि मार्फत यो ईन्टरिसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा उपलब्ध छ।
    ///
    /// उदाहरण को लागी, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// भण्डार गर्दछ यदि हालको मान `old` मान जस्तै हो।
    ///
    /// [`Ordering::Acquire`] र [`Ordering::Acquire`] दुबै `success` लाई पार गरेर `compare_exchange` विधि मार्फत X0 `failure` विधि मार्फत यो ईन्टरिसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा उपलब्ध छ।
    ///
    /// उदाहरण को लागी, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// भण्डार गर्दछ यदि हालको मान `old` मान जस्तै हो।
    ///
    /// यो आन्तरिकको स्थिर संस्करण X0XX विधि मार्फत `compare_exchange` विधि द्वारा [`Ordering::Release`] लाई `success` र [`Ordering::Relaxed`] `failure` प्यारामिटरको रूपमा पार गरेर [`atomic`] प्रकारहरूमा उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// भण्डार गर्दछ यदि हालको मान `old` मान जस्तै हो।
    ///
    /// यो आन्तरिकको स्थिर संस्करण X0XX विधि मार्फत `compare_exchange` विधि द्वारा [`Ordering::AcqRel`] लाई `success` र [`Ordering::Acquire`] `failure` प्यारामिटरको रूपमा पार गरेर [`atomic`] प्रकारहरूमा उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// भण्डार गर्दछ यदि हालको मान `old` मान जस्तै हो।
    ///
    /// [`Ordering::Relaxed`] र [`Ordering::Relaxed`] दुबै `success` लाई पार गरेर `compare_exchange` विधि मार्फत X0 `failure` विधि मार्फत यो ईन्टरिसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा उपलब्ध छ।
    ///
    /// उदाहरण को लागी, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// भण्डार गर्दछ यदि हालको मान `old` मान जस्तै हो।
    ///
    /// यो आन्तरिकको स्थिर संस्करण X0XX विधि मार्फत `compare_exchange` विधि द्वारा [`Ordering::SeqCst`] लाई `success` र [`Ordering::Relaxed`] `failure` प्यारामिटरको रूपमा पार गरेर [`atomic`] प्रकारहरूमा उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// भण्डार गर्दछ यदि हालको मान `old` मान जस्तै हो।
    ///
    /// यो आन्तरिकको स्थिर संस्करण X0XX विधि मार्फत `compare_exchange` विधि द्वारा [`Ordering::SeqCst`] लाई `success` र [`Ordering::Acquire`] `failure` प्यारामिटरको रूपमा पार गरेर [`atomic`] प्रकारहरूमा उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// भण्डार गर्दछ यदि हालको मान `old` मान जस्तै हो।
    ///
    /// यो आन्तरिकको स्थिर संस्करण X0XX विधि मार्फत `compare_exchange` विधि द्वारा [`Ordering::Acquire`] लाई `success` र [`Ordering::Relaxed`] `failure` प्यारामिटरको रूपमा पार गरेर [`atomic`] प्रकारहरूमा उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// भण्डार गर्दछ यदि हालको मान `old` मान जस्तै हो।
    ///
    /// यो आन्तरिकको स्थिर संस्करण X0XX विधि मार्फत `compare_exchange` विधि द्वारा [`Ordering::AcqRel`] लाई `success` र [`Ordering::Relaxed`] `failure` प्यारामिटरको रूपमा पार गरेर [`atomic`] प्रकारहरूमा उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// भण्डार गर्दछ यदि हालको मान `old` मान जस्तै हो।
    ///
    /// [`Ordering::SeqCst`] र [`Ordering::SeqCst`] दुबै `success` लाई पार गरेर `compare_exchange_weak` विधि मार्फत X0 `failure` विधि मार्फत यो ईन्टरिसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा उपलब्ध छ।
    ///
    /// उदाहरण को लागी, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// भण्डार गर्दछ यदि हालको मान `old` मान जस्तै हो।
    ///
    /// [`Ordering::Acquire`] र [`Ordering::Acquire`] दुबै `success` लाई पार गरेर `compare_exchange_weak` विधि मार्फत X0 `failure` विधि मार्फत यो ईन्टरिसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा उपलब्ध छ।
    ///
    /// उदाहरण को लागी, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// भण्डार गर्दछ यदि हालको मान `old` मान जस्तै हो।
    ///
    /// यो आन्तरिकको स्थिर संस्करण X0XX विधि मार्फत `compare_exchange_weak` विधि द्वारा [`Ordering::Release`] लाई `success` र [`Ordering::Relaxed`] `failure` प्यारामिटरको रूपमा पार गरेर [`atomic`] प्रकारहरूमा उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// भण्डार गर्दछ यदि हालको मान `old` मान जस्तै हो।
    ///
    /// यो आन्तरिकको स्थिर संस्करण X0XX विधि मार्फत `compare_exchange_weak` विधि द्वारा [`Ordering::AcqRel`] लाई `success` र [`Ordering::Acquire`] `failure` प्यारामिटरको रूपमा पार गरेर [`atomic`] प्रकारहरूमा उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// भण्डार गर्दछ यदि हालको मान `old` मान जस्तै हो।
    ///
    /// [`Ordering::Relaxed`] र [`Ordering::Relaxed`] दुबै `success` लाई पार गरेर `compare_exchange_weak` विधि मार्फत X0 `failure` विधि मार्फत यो ईन्टरिसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा उपलब्ध छ।
    ///
    /// उदाहरण को लागी, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// भण्डार गर्दछ यदि हालको मान `old` मान जस्तै हो।
    ///
    /// यो आन्तरिकको स्थिर संस्करण X0XX विधि मार्फत `compare_exchange_weak` विधि द्वारा [`Ordering::SeqCst`] लाई `success` र [`Ordering::Relaxed`] `failure` प्यारामिटरको रूपमा पार गरेर [`atomic`] प्रकारहरूमा उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// भण्डार गर्दछ यदि हालको मान `old` मान जस्तै हो।
    ///
    /// यो आन्तरिकको स्थिर संस्करण X0XX विधि मार्फत `compare_exchange_weak` विधि द्वारा [`Ordering::SeqCst`] लाई `success` र [`Ordering::Acquire`] `failure` प्यारामिटरको रूपमा पार गरेर [`atomic`] प्रकारहरूमा उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// भण्डार गर्दछ यदि हालको मान `old` मान जस्तै हो।
    ///
    /// यो आन्तरिकको स्थिर संस्करण X0XX विधि मार्फत `compare_exchange_weak` विधि द्वारा [`Ordering::Acquire`] लाई `success` र [`Ordering::Relaxed`] `failure` प्यारामिटरको रूपमा पार गरेर [`atomic`] प्रकारहरूमा उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// भण्डार गर्दछ यदि हालको मान `old` मान जस्तै हो।
    ///
    /// यो आन्तरिकको स्थिर संस्करण X0XX विधि मार्फत `compare_exchange_weak` विधि द्वारा [`Ordering::AcqRel`] लाई `success` र [`Ordering::Relaxed`] `failure` प्यारामिटरको रूपमा पार गरेर [`atomic`] प्रकारहरूमा उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// पोइन्टरको हालको मान लोड गर्दछ।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `load` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// पोइन्टरको हालको मान लोड गर्दछ।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `load` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// पोइन्टरको हालको मान लोड गर्दछ।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `load` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// निर्दिष्ट स्मृति स्थानमा मान भण्डार गर्दछ।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `store` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// निर्दिष्ट स्मृति स्थानमा मान भण्डार गर्दछ।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `store` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// निर्दिष्ट स्मृति स्थानमा मान भण्डार गर्दछ।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `store` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// पुरानो मान फिर्ता गर्दै निर्दिष्ट स्मृति स्थानमा मान भण्डार गर्दछ।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `swap` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// पुरानो मान फिर्ता गर्दै निर्दिष्ट स्मृति स्थानमा मान भण्डार गर्दछ।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `swap` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// पुरानो मान फिर्ता गर्दै निर्दिष्ट स्मृति स्थानमा मान भण्डार गर्दछ।
    ///
    /// यो ईन्टर्न्सिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `swap` विधि मार्फत [`Ordering::Release`] लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// पुरानो मान फिर्ता गर्दै निर्दिष्ट स्मृति स्थानमा मान भण्डार गर्दछ।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `swap` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// पुरानो मान फिर्ता गर्दै निर्दिष्ट स्मृति स्थानमा मान भण्डार गर्दछ।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `swap` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// हालको मानमा थप गर्दछ, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `fetch_add` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// हालको मानमा थप गर्दछ, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `fetch_add` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// हालको मानमा थप गर्दछ, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `fetch_add` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// हालको मानमा थप गर्दछ, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `fetch_add` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// हालको मानमा थप गर्दछ, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `fetch_add` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// हालको मानबाट घटाउनुहोस्, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `fetch_sub` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// हालको मानबाट घटाउनुहोस्, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `fetch_sub` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// हालको मानबाट घटाउनुहोस्, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `fetch_sub` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// हालको मानबाट घटाउनुहोस्, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `fetch_sub` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// हालको मानबाट घटाउनुहोस्, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `fetch_sub` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise र हालको मानको साथ, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `fetch_and` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise र हालको मानको साथ, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `fetch_and` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise र हालको मानको साथ, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `fetch_and` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise र हालको मानको साथ, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `fetch_and` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise र हालको मानको साथ, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यो ईन्टर्न्सिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `fetch_and` विधि मार्फत [`Ordering::Relaxed`] लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// हालको मानको साथ Bitwise नान्ड, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`AtomicBool`] प्रकार मार्फत `fetch_nand` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// हालको मानको साथ Bitwise नान्ड, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`AtomicBool`] प्रकार मार्फत `fetch_nand` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// हालको मानको साथ Bitwise नान्ड, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`AtomicBool`] प्रकार मार्फत `fetch_nand` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// हालको मानको साथ Bitwise नान्ड, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`AtomicBool`] प्रकार मार्फत `fetch_nand` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// हालको मानको साथ Bitwise नान्ड, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`AtomicBool`] प्रकार मार्फत `fetch_nand` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise वा हालको मानको साथ, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `fetch_or` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise वा हालको मानको साथ, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `fetch_or` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise वा हालको मानको साथ, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `fetch_or` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise वा हालको मानको साथ, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `fetch_or` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise वा हालको मानको साथ, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `fetch_or` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// हालको मानको साथ Bitwise xor, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `fetch_xor` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// हालको मानको साथ Bitwise xor, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `fetch_xor` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// हालको मानको साथ Bitwise xor, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `fetch_xor` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// हालको मानको साथ Bitwise xor, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `fetch_xor` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// हालको मानको साथ Bitwise xor, अघिल्लो मान फिर्ता गर्दै।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] प्रकारहरूमा `fetch_xor` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर उपलब्ध छ।
    /// उदाहरण को लागी, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// हालको मानको साथ हस्ताक्षर गरिएको तुलना प्रयोग गरेर अधिकतम।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] हस्ताक्षर पूर्णांक प्रकारहरूमा उपलब्ध छ `fetch_max` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर।
    /// उदाहरण को लागी, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// हालको मानको साथ हस्ताक्षर गरिएको तुलना प्रयोग गरेर अधिकतम।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] हस्ताक्षर पूर्णांक प्रकारहरूमा उपलब्ध छ `fetch_max` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर।
    /// उदाहरण को लागी, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// हालको मानको साथ हस्ताक्षर गरिएको तुलना प्रयोग गरेर अधिकतम।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] हस्ताक्षर पूर्णांक प्रकारहरूमा उपलब्ध छ `fetch_max` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर।
    /// उदाहरण को लागी, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// हालको मानको साथ हस्ताक्षर गरिएको तुलना प्रयोग गरेर अधिकतम।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] हस्ताक्षर पूर्णांक प्रकारहरूमा उपलब्ध छ `fetch_max` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर।
    /// उदाहरण को लागी, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// हालको मानको साथ अधिकतम।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] हस्ताक्षर पूर्णांक प्रकारहरूमा उपलब्ध छ `fetch_max` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर।
    /// उदाहरण को लागी, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// हालको मानको साथ हस्ताक्षर गरिएको तुलना प्रयोग गरेर न्यूनतम।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] हस्ताक्षर पूर्णांक प्रकारहरूमा उपलब्ध छ `fetch_min` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर।
    /// उदाहरण को लागी, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// हालको मानको साथ हस्ताक्षर गरिएको तुलना प्रयोग गरेर न्यूनतम।
    ///
    /// यो ईन्टरिसिकको स्थिर संस्करण [`atomic`] हस्ताक्षर पूर्णांक प्रकारहरूमा उपलब्ध छ `fetch_min` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर।
    /// उदाहरण को लागी, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// हालको मानको साथ हस्ताक्षर गरिएको तुलना प्रयोग गरेर न्यूनतम।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] हस्ताक्षर पूर्णांक प्रकारहरूमा उपलब्ध छ `fetch_min` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर।
    /// उदाहरण को लागी, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// हालको मानको साथ हस्ताक्षर गरिएको तुलना प्रयोग गरेर न्यूनतम।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] हस्ताक्षर पूर्णांक प्रकारहरूमा उपलब्ध छ `fetch_min` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर।
    /// उदाहरण को लागी, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// हालको मानको साथ हस्ताक्षर गरिएको तुलना प्रयोग गरेर न्यूनतम।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] हस्ताक्षर पूर्णांक प्रकारहरूमा उपलब्ध छ `fetch_min` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर।
    /// उदाहरण को लागी, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// एक हस्ताक्षर नगरिएको तुलना प्रयोग गरी हालको मानको साथ न्यूनतम।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] हस्ताक्षरित पूर्णांक प्रकारहरूमा उपलब्ध छ `fetch_min` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर।
    /// उदाहरण को लागी, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// एक हस्ताक्षर नगरिएको तुलना प्रयोग गरी हालको मानको साथ न्यूनतम।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] हस्ताक्षरित पूर्णांक प्रकारहरूमा उपलब्ध छ `fetch_min` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर।
    /// उदाहरण को लागी, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// एक हस्ताक्षर नगरिएको तुलना प्रयोग गरी हालको मानको साथ न्यूनतम।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] हस्ताक्षरित पूर्णांक प्रकारहरूमा उपलब्ध छ `fetch_min` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर।
    /// उदाहरण को लागी, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// एक हस्ताक्षर नगरिएको तुलना प्रयोग गरी हालको मानको साथ न्यूनतम।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] हस्ताक्षरित पूर्णांक प्रकारहरूमा उपलब्ध छ `fetch_min` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर।
    /// उदाहरण को लागी, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// एक हस्ताक्षर नगरिएको तुलना प्रयोग गरी हालको मानको साथ न्यूनतम।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] हस्ताक्षरित पूर्णांक प्रकारहरूमा उपलब्ध छ `fetch_min` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर।
    /// उदाहरण को लागी, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// एक हस्ताक्षर नगरिएको तुलना प्रयोग गरी हालको मानको साथ अधिकतम।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] हस्ताक्षरित पूर्णांक प्रकारहरूमा उपलब्ध छ `fetch_max` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर।
    /// उदाहरण को लागी, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// एक हस्ताक्षर नगरिएको तुलना प्रयोग गरी हालको मानको साथ अधिकतम।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] हस्ताक्षरित पूर्णांक प्रकारहरूमा उपलब्ध छ `fetch_max` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर।
    /// उदाहरण को लागी, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// एक हस्ताक्षर नगरिएको तुलना प्रयोग गरी हालको मानको साथ अधिकतम।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] हस्ताक्षरित पूर्णांक प्रकारहरूमा उपलब्ध छ `fetch_max` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर।
    /// उदाहरण को लागी, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// एक हस्ताक्षर नगरिएको तुलना प्रयोग गरी हालको मानको साथ अधिकतम।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] हस्ताक्षरित पूर्णांक प्रकारहरूमा उपलब्ध छ `fetch_max` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर।
    /// उदाहरण को लागी, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// एक हस्ताक्षर नगरिएको तुलना प्रयोग गरी हालको मानको साथ अधिकतम।
    ///
    /// यस इन्टरसिकको स्थिर संस्करण [`atomic`] हस्ताक्षरित पूर्णांक प्रकारहरूमा उपलब्ध छ `fetch_max` विधि मार्फत `order` लाई `order` को रूपमा पार गरेर।
    /// उदाहरण को लागी, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// `prefetch` ईन्टर्न्सिक कोड जनरेटरको संकेत हो यदि प्रिफेच निर्देशन सम्मिलित गर्न को लागी समर्थित छ भने;अन्यथा, यो कुनै अप्ट छैन।
    /// प्रिफेचेसले कार्यक्रमको व्यवहारमा कुनै प्रभाव पार्दैन तर यसको प्रदर्शन विशेषताहरू परिवर्तन गर्न सक्दछ।
    ///
    /// `locality` आर्गुमेन्ट स्थिर इन्टिजर हुनुपर्दछ र अस्थायी स्थान निर्दिष्टकर्ता हो (0) बाट, कुनै स्थानीय छैन, (3) सम्म, क्यासमा अत्यधिक स्थानीय राख्नुहोस्।
    ///
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// `prefetch` ईन्टर्न्सिक कोड जनरेटरको संकेत हो यदि प्रिफेच निर्देशन सम्मिलित गर्न को लागी समर्थित छ भने;अन्यथा, यो कुनै अप्ट छैन।
    /// प्रिफेचेसले कार्यक्रमको व्यवहारमा कुनै प्रभाव पार्दैन तर यसको प्रदर्शन विशेषताहरू परिवर्तन गर्न सक्दछ।
    ///
    /// `locality` आर्गुमेन्ट स्थिर इन्टिजर हुनुपर्दछ र अस्थायी स्थान निर्दिष्टकर्ता हो (0) बाट, कुनै स्थानीय छैन, (3) सम्म, क्यासमा अत्यधिक स्थानीय राख्नुहोस्।
    ///
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// `prefetch` ईन्टर्न्सिक कोड जनरेटरको संकेत हो यदि प्रिफेच निर्देशन सम्मिलित गर्न को लागी समर्थित छ भने;अन्यथा, यो कुनै अप्ट छैन।
    /// प्रिफेचेसले कार्यक्रमको व्यवहारमा कुनै प्रभाव पार्दैन तर यसको प्रदर्शन विशेषताहरू परिवर्तन गर्न सक्दछ।
    ///
    /// `locality` आर्गुमेन्ट स्थिर इन्टिजर हुनुपर्दछ र अस्थायी स्थान निर्दिष्टकर्ता हो (0) बाट, कुनै स्थानीय छैन, (3) सम्म, क्यासमा अत्यधिक स्थानीय राख्नुहोस्।
    ///
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// `prefetch` ईन्टर्न्सिक कोड जनरेटरको संकेत हो यदि प्रिफेच निर्देशन सम्मिलित गर्न को लागी समर्थित छ भने;अन्यथा, यो कुनै अप्ट छैन।
    /// प्रिफेचेसले कार्यक्रमको व्यवहारमा कुनै प्रभाव पार्दैन तर यसको प्रदर्शन विशेषताहरू परिवर्तन गर्न सक्दछ।
    ///
    /// `locality` आर्गुमेन्ट स्थिर इन्टिजर हुनुपर्दछ र अस्थायी स्थान निर्दिष्टकर्ता हो (0) बाट, कुनै स्थानीय छैन, (3) सम्म, क्यासमा अत्यधिक स्थानीय राख्नुहोस्।
    ///
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// एक आणविक बार
    ///
    /// [`Ordering::SeqCst`] लाई `order` को रूपमा पार गरेर यस इन्टरसिकको स्थिर संस्करण [`atomic::fence`] मा उपलब्ध छ।
    ///
    ///
    pub fn atomic_fence();
    /// एक आणविक बार
    ///
    /// [`Ordering::Acquire`] लाई `order` को रूपमा पार गरेर यस इन्टरसिकको स्थिर संस्करण [`atomic::fence`] मा उपलब्ध छ।
    ///
    ///
    pub fn atomic_fence_acq();
    /// एक आणविक बार
    ///
    /// [`Ordering::Release`] लाई `order` को रूपमा पार गरेर यस इन्टरसिकको स्थिर संस्करण [`atomic::fence`] मा उपलब्ध छ।
    ///
    ///
    pub fn atomic_fence_rel();
    /// एक आणविक बार
    ///
    /// [`Ordering::AcqRel`] लाई `order` को रूपमा पार गरेर यस इन्टरसिकको स्थिर संस्करण [`atomic::fence`] मा उपलब्ध छ।
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// कम्पाइलर मात्र मेमोरी बाधा।
    ///
    /// कम्पाइलर द्वारा मेमोरी एक्सेसहरू यस अवरोधको पार कहिले पनि पुन: क्रमबद्ध गरिने छैन, तर यसका लागि कुनै निर्देशनहरू उत्सव गरिने छैन।
    /// यो उही थ्रेडमा अपरेशन्सका लागि उपयुक्त छ जुन प्रीम्ट हुन सक्छ, जस्तै जब सिग्नल ह्यान्डलरहरूसँग अन्तर्क्रिया गर्दा।
    ///
    /// [`Ordering::SeqCst`] लाई `order` को रूपमा पार गरेर यस इन्टरसिकको स्थिर संस्करण [`atomic::compiler_fence`] मा उपलब्ध छ।
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// कम्पाइलर मात्र मेमोरी बाधा।
    ///
    /// कम्पाइलर द्वारा मेमोरी एक्सेसहरू यस अवरोधको पार कहिले पनि पुन: क्रमबद्ध गरिने छैन, तर यसका लागि कुनै निर्देशनहरू उत्सव गरिने छैन।
    /// यो उही थ्रेडमा अपरेशन्सका लागि उपयुक्त छ जुन प्रीम्ट हुन सक्छ, जस्तै जब सिग्नल ह्यान्डलरहरूसँग अन्तर्क्रिया गर्दा।
    ///
    /// [`Ordering::Acquire`] लाई `order` को रूपमा पार गरेर यस इन्टरसिकको स्थिर संस्करण [`atomic::compiler_fence`] मा उपलब्ध छ।
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// कम्पाइलर मात्र मेमोरी बाधा।
    ///
    /// कम्पाइलर द्वारा मेमोरी एक्सेसहरू यस अवरोधको पार कहिले पनि पुन: क्रमबद्ध गरिने छैन, तर यसका लागि कुनै निर्देशनहरू उत्सव गरिने छैन।
    /// यो उही थ्रेडमा अपरेशन्सका लागि उपयुक्त छ जुन प्रीम्ट हुन सक्छ, जस्तै जब सिग्नल ह्यान्डलरहरूसँग अन्तर्क्रिया गर्दा।
    ///
    /// [`Ordering::Release`] लाई `order` को रूपमा पार गरेर यस इन्टरसिकको स्थिर संस्करण [`atomic::compiler_fence`] मा उपलब्ध छ।
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// कम्पाइलर मात्र मेमोरी बाधा।
    ///
    /// कम्पाइलर द्वारा मेमोरी एक्सेसहरू यस अवरोधको पार कहिले पनि पुन: क्रमबद्ध गरिने छैन, तर यसका लागि कुनै निर्देशनहरू उत्सव गरिने छैन।
    /// यो उही थ्रेडमा अपरेशन्सका लागि उपयुक्त छ जुन प्रीम्ट हुन सक्छ, जस्तै जब सिग्नल ह्यान्डलरहरूसँग अन्तर्क्रिया गर्दा।
    ///
    /// [`Ordering::AcqRel`] लाई `order` को रूपमा पार गरेर यस इन्टरसिकको स्थिर संस्करण [`atomic::compiler_fence`] मा उपलब्ध छ।
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// जादुई इंटर्न्सिक जसले यसको अर्थ प्रकार्यसँग जोडिएका विशेषताहरूबाट उत्पन्न गर्दछ।
    ///
    /// उदाहरण को लागी, डाटाफ्लोले स्थिर एस्टेन्सनहरू इन्जेक्सन गर्न प्रयोग गर्दछ ताकि `rustc_peek(potentially_uninitialized)` वास्तवमै डबल-जाँच गर्दछ कि डाटाफ्लोले वास्तवमा गणना गर्‍यो कि यो नियन्त्रण प्रवाहको त्यो बिन्दुमा अनावश्यक छ।
    ///
    ///
    /// यो इन्टरनसिक कम्पाइलर बाहिर प्रयोग गर्नु हुँदैन।
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// प्रक्रियाको कार्यान्वयनलाई रोक्दछ।
    ///
    /// यस अपरेशनको अधिक प्रयोगकर्ता-मैत्री र स्थिर संस्करण [`std::process::abort`](../../std/process/fn.abort.html) हो।
    ///
    pub fn abort() -> !;

    /// अप्टिमाइजरलाई सूचित गर्दछ कि कोडको यो पोइन्ट पहुँच योग्य छैन, थप अनुकूलन सक्षम पार्दै।
    ///
    /// NB, यो `unreachable!()` म्याक्रो भन्दा धेरै फरक छ: म्याक्रो भन्दा फरक, जुन panics जब कार्यान्वयन गरिन्छ, यो प्रकार्यको साथ चिह्नित कोडमा पुग्न *अपरिभाषित व्यवहार* हो।
    ///
    ///
    /// यस ईन्टरिसिकको स्थिर संस्करण [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked) हो।
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// अप्टिमाइजरलाई सूचित गर्दछ कि सर्त जहिले पनि सहि हुन्छ।
    /// यदि सर्त गलत छ भने, व्यवहार अपरिभाषित छ।
    ///
    /// कुनै कोड यस आन्तरिकको लागि उत्पन्न गरिएको छैन, तर अप्टिमाइजरले यसलाई (र यसको सर्त) लाई पासको बीचमा संरक्षित गर्ने प्रयास गर्नेछ, जसले वरपरको कोडको अप्टिमाइजेशन र हस्तक्षेप कम गर्न सक्छ।
    /// यो प्रयोग गर्न सकिदैन यदि इनभेरान्ट आफैंमा अनुकूलकले पत्ता लगाउन सक्छ, वा यदि यसले कुनै महत्त्वपूर्ण अप्टिमाइजेसन सक्षम गर्दैन।
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// कम्पाईलरलाई संकेत: branch शर्त सही हुन सक्छ।
    /// योमा पठाइएको मान फर्काउँछ।
    ///
    /// `if` कथन बाहेक कुनै पनि प्रयोगको सायद प्रभाव हुँदैन।
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// कम्पाइलरलाई संकेत: branch शर्त गलत हुन सक्छ।
    /// योमा पठाइएको मान फर्काउँछ।
    ///
    /// `if` कथन बाहेक कुनै पनि प्रयोगको सायद प्रभाव हुँदैन।
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// डिबगरद्वारा निरीक्षणको लागि ब्रेकपॉइन्ट जाल कार्यान्वयन गर्दछ।
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    pub fn breakpoint();

    /// बाइट्समा एक प्रकारको आकार।
    ///
    /// अधिक विशेष रूपमा, यो प type्क्तिबद्ध प्याडि including सहित समान प्रकारको क्रमिक वस्तुहरू बीचको बाइट्समा अफसेट हो।
    ///
    ///
    /// यस ईन्टरिसिकको स्थिर संस्करण [`core::mem::size_of`](crate::mem::size_of) हो।
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// एक प्रकारको न्यूनतम पign्क्तिबद्धता।
    ///
    /// यस ईन्टरिसिकको स्थिर संस्करण [`core::mem::align_of`](crate::mem::align_of) हो।
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// एक प्रकारको मनपर्दो पign्क्तिबद्धता।
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// बाइट्समा सन्दर्भ मानको आकार।
    ///
    /// यस ईन्टरिसिकको स्थिर संस्करण [`mem::size_of_val`] हो।
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// सन्दर्भित मानको आवश्यक पign्क्तिबद्धता।
    ///
    /// यस ईन्टरिसिकको स्थिर संस्करण [`core::mem::align_of_val`](crate::mem::align_of_val) हो।
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// एक प्रकारको नाम सहित स्थिर स्ट्रि sl स्लाइस प्राप्त गर्दछ।
    ///
    /// यस ईन्टरिसिकको स्थिर संस्करण [`core::any::type_name`](crate::any::type_name) हो।
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// एक पहिचानकर्ता हुन्छ जुन विश्वव्यापी रूपमा निर्दिष्ट प्रकारको लागि अद्वितीय हो।
    /// यो प्रकार्य एक प्रकारको लागि समान मान फर्काउँदछ जुनसुकै crate यो आमन्त्रित छ।
    ///
    ///
    /// यस ईन्टरिसिकको स्थिर संस्करण [`core::any::TypeId::of`](crate::any::TypeId::of) हो।
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// असुरक्षित प्रकार्यहरूको लागि गार्ड जुन कहिले कार्यान्वयन हुन सक्दैन यदि `T` निर्वासित छ भने:
    /// यो स्थिर रूपमा या त panic, वा केहि गर्दैन।
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// असुरक्षित प्रकार्यहरूको लागि गार्ड जसले कहिले कार्यान्वयन गर्न सक्दैन यदि `T` शून्य-इनिसियलाइजेशनको अनुमति दिदैन: यसले स्थैतिक रूपमा या त panic, वा केहि पनि गर्दैन।
    ///
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    pub fn assert_zero_valid<T>();

    /// असुरक्षित प्रकार्यहरूको लागि गार्ड जुन कहिले कार्यान्वयन हुन सक्दैन यदि `T` अमान्य बिट पैटर्नहरू छन्: यसले स्थिर रूपमा या त panic, वा केहि पनि गर्दैन।
    ///
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    pub fn assert_uninit_valid<T>();

    /// एक स्ट्याटिक `Location` को संदर्भ प्राप्त गर्दछ जहाँ यो बोलाइएको थियो।
    ///
    /// यसको सट्टामा [`core::panic::Location::caller`](crate::panic::Location::caller) प्रयोग गर्ने बारे विचार गर्नुहोस्।
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// ड्रप ग्लू बिना चालको मानको दायरा बाहिर सार्छ।
    ///
    /// यो केवल [`mem::forget_unsized`] को लागी अवस्थित छ;सामान्य `forget` यसको सट्टामा `ManuallyDrop` प्रयोग गर्दछ।
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// एक प्रकारको मानको बिट्सलाई अर्को प्रकारको रूपमा पुनः परिभाषित गर्दछ।
    ///
    /// दुबै प्रकारको साइज एकै हुनुपर्छ।
    /// न त मूल, न नतिजा, एक [invalid value](../../nomicon/what-unsafe-does.html) हुन सक्छ।
    ///
    /// `transmute` एक प्रकारको अर्को तरीकामा बिटवाईज चालको बराबर हो।यसले गन्तव्य मानमा स्रोत मानबाट बिट्स प्रतिलिपि गर्दछ, त्यसपछि मूल बिर्सन्छ।
    /// यो हुड मुनि सीको `memcpy` बराबर हो, `transmute_copy` जस्तै।
    ///
    /// किनभने `transmute` एक उप-मान अपरेशन हो,*ट्रान्समिट गरिएको मान आफैंको* संरेखण चिन्ताको विषय होइन।
    /// कुनै पनि अन्य प्रकार्यसँग यो कम्पाइलरले दुबै `T` र `U` दुबै पigned्क्तिबद्ध गरिएको छ भनेर सुनिश्चित गर्दछ।
    /// जे होस्, ट्रान्समिटि values मानहरू जुन *पोइन्ट अन्य ठाउँमा*(जस्तै पोइन्टर्स, सन्दर्भ, बक्सहरू ...), कलरले पोइन्ट-टु मूल्योंको उचित प proper्क्तिबद्धता सुनिश्चित गर्नुपर्दछ।
    ///
    /// `transmute` **अविश्वसनीय** असुरक्षित हो।यस प्रकार्यको साथ [undefined behavior][ub] पैदा गर्ने धेरै तरिकाहरू छन्।`transmute` पूर्ण अन्तिम उपाय हुनु पर्छ।
    ///
    /// [nomicon](../../nomicon/transmutes.html) सँग अतिरिक्त कागजातहरू छन्।
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// त्यहाँ केहि चीजहरू छन् जुन `transmute` वास्तवमै उपयोगी छ।
    ///
    /// प्रकार्य सूचकमा सूचक परिवर्तन गर्दै।यो मेशिनहरूमा * पोर्टेबल होईन जहाँ प्रकार्य सूचक र डाटा पोइन्टरहरूको भिन्न आकार हुन्छ।
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// जीवनभर विस्तार गर्दै, वा एक आक्रमणकर्ताको जीवनकाल छोटो पार्दै।यो उन्नत छ, धेरै असुरक्षित Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// निराश नहुनुहोस्: `transmute` को धेरै प्रयोगहरू अन्य माध्यमहरू मार्फत प्राप्त गर्न सकिन्छ।
    /// तल `transmute` का साधारण अनुप्रयोगहरू छन् जुन सुरक्षित निर्माणहरूद्वारा प्रतिस्थापन गर्न सकिन्छ।
    ///
    /// कच्चा bytes(`&[u8]`) लाई `u32`, `f64`, आदिमा बदल्दै।
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // यसको सट्टामा `u32::from_ne_bytes` प्रयोग गर्नुहोस्
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // वा `u32::from_le_bytes` वा `u32::from_be_bytes` endianness निर्दिष्ट गर्न प्रयोग गर्नुहोस्
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// सूचकलाई `usize` मा परिवर्तन गर्दै:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // यसको सट्टामा एक `as` कास्ट प्रयोग गर्नुहोस्
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// `*mut T` लाई `&mut T` मा बदल्दै:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // सट्टामा रिब्रो प्रयोग गर्नुहोस्
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// `&mut T` लाई `&mut U` मा बदल्दै:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // अब `as` र reborrowing सँगै राख्नुहोस्, `as` `as` को चेन नोट गर्नुहोस् ट्रान्जिटिव छैन
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// `&str` लाई `&[u8]` मा बदल्दै:
    ///
    /// ```
    /// // यो गर्न यो राम्रो तरिका छैन।
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // तपाईं `str::as_bytes` प्रयोग गर्न सक्नुहुनेछ
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // वा, केवल एउटा बाइट स्ट्रि use प्रयोग गर्नुहोस्, यदि तपाइँसँग स्ट्रि lite लिटरलमा नियन्त्रण छ
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// `Vec<&T>` लाई `Vec<Option<&T>>` मा बदल्दै।
    ///
    /// कन्टेनरको सामग्रीको भित्री प्रकारलाई ट्रान्समिट गर्न, तपाईंले कन्टेनरको कुनै पनि आक्रमणकर्तालाई उल्लंघन नगर्न निश्चित गर्नुपर्दछ।
    /// `Vec` को लागी, यसको मतलब दुबै भित्री प्रकारको साइज * र पign्क्तिबद्धता मेल गर्नु पर्छ।
    /// अन्य कन्टेनरहरू प्रकार, पign्क्तिबद्धता, वा `TypeId` को आकारमा निर्भर हुन सक्छ, जहाँ कन्टेनर आक्रमणकारीहरूको उल्लंघन नगरी ट्रान्समिटि। सम्भव छैन।
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // vector क्लोन गर्नुहोस् किनकि हामी तिनीहरूलाई पछि पुन: प्रयोग गर्नेछौं
    /// let v_clone = v_orig.clone();
    ///
    /// // ट्रान्समूट प्रयोग गरी: यसले `Vec` को अनिर्दिष्ट डाटा लेआउटमा निर्भर गर्दछ, जुन नराम्रो विचार हो र यसले अपरिभाषित व्यवहार निम्त्याउन सक्छ।
    /////
    /// // यद्यपि यो कुनै प्रतिलिपि होईन।
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // यो सुझाव, सुरक्षित तरीका हो।
    /// // यसले सम्पूर्ण vector प्रतिलिपि गर्दछ, जे होस्, नयाँ एर्रेमा।
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // यो उचित No-copy, "transmuting" को एक `Vec` को असुरक्षित तरीका हो, डाटा सजावटमा निर्भर बिना।
    /// // `transmute` लाई शाब्दिक कल गर्नुको सट्टा, हामी पोइन्टर कास्ट प्रदर्शन गर्दछौं, तर मूल भित्री प्रकार (`&i32`) लाई नयाँ एक (`Option<&i32>`) मा रूपान्तरण गर्ने सन्दर्भमा, यसमा सबै त्यस्तै समान चेतावनीहरू छन्।
    /////
    /// // माथी प्रदान गरिएको जानकारीका साथै [`from_raw_parts`] कागजातलाई पनि परामर्श लिनुहोस्।
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME यसलाई अपडेट गर्नुहोस् जब vec_into_raw_parts स्थिर हुन्छ।
    ///     // सुनिश्चित गर्नुहोस् कि मूल vector छोडियो छैन।
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// `split_at_mut` कार्यान्वयन गर्दै:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // त्यहाँ धेरै तरीकाले यसो गर्न सकिन्छ, र निम्न (transmute) तरीकासँग त्यहाँ धेरै समस्याहरू छन्।
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // पहिलो: transmute सुरक्षित प्रकार छैन;यो सबै जाँच गर्दछ कि टी र
    ///         // यू उही आकारको हो।
    ///         // दोस्रो, अहिले यहाँ तपाईसँग दुईवटा म्यूटेबल सन्दर्भ छ जुन समान मेमोरीमा देखाईन्छ।
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // यसले प्रकार सुरक्षा समस्याबाट छुटकारा पाउँदछ;`&mut *` मात्र* तपाईं `&mut T` वा `*mut T` बाट एक `&mut T` दिन्छ।
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // जे होस्, तपाईं अझै पनी दुई परिवर्तनकारी सन्दर्भ छ उही मेमोरीमा देखाउँदै।
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // मानक पुस्तकालयले यसलाई कसरी गर्छ।
    /// // यो उत्तम विधि हो, यदि तपाईंलाई यस्तो केहि गर्न आवश्यक छ भने
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // यो अब तीन म्यूटेबल सन्दर्भ छ उही मेमोरीमा इशारा गर्दै।`slice`, मूल्य ret.0, र मूल्य ret.1।
    ///         // `slice` `let ptr = ...` पछि कहिले पनि प्रयोग गरिएको छैन, र त्यसैले यसलाई "dead" को रूपमा व्यवहार गर्न सकिन्छ, र त्यसैले तपाईंसँग दुईवटा वास्तविक परिवर्तनकारी स्लाइसहरू मात्र छन्।
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: जबकि यसले इन्निसिनिक कन्स्टन्ट स्थिर बनाउँदछ, हामीसँग कन्स्ट्रक्ट fn मा केही कस्टम कोड छ
    // `const fn` भित्र यसको प्रयोग रोक्ने जाँच गर्दछ।
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// `true` फर्काउँछ यदि वास्तविक प्रकारलाई `T` को रूपमा दिइयो ड्रप ग्लूको आवश्यक छ;`false` फर्काउँछ यदि वास्तविक प्रकार `T` कार्यान्वयन `Copy` को लागी प्रदान गरीन्छ।
    ///
    ///
    /// यदि वास्तविक प्रकार न त ड्रप ग्लूको आवश्यकता छ न `Copy` कार्यान्वयन गर्दछ भने, तब यस प्रकार्यको फिर्ती मान अनिर्दिष्ट छ।
    ///
    /// यस ईन्टरिसिकको स्थिर संस्करण [`mem::needs_drop`](crate::mem::needs_drop) हो।
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// सूचकबाट अफसेट गणना गर्दछ।
    ///
    /// रूपान्तरणले एलियासिंग जानकारी फ्याँक्छ किनभने पूर्णांकमा र कन्टेजरमा रूपान्तरण हुनबाट रोक्नको लागि यो एक आंतरिक रूपमा लागू गरिएको छ।
    ///
    /// # Safety
    ///
    /// दुबै सुरूवात र नतिजा सूचक या त सीमा मा वा एक बाइट एक आवंटित वस्तु को अन्त मा हुनु पर्छ।
    /// यदि या त सूचक सीमा बाहिर छ वा अंकगणित ओभरफ्लो हुन्छ भने फिर्ता मानको कुनै पनि अर्को प्रयोग अपरिभाषित व्यवहारको परिणाम हुनेछ।
    ///
    ///
    /// यस ईन्टरिसिकको स्थिर संस्करण [`pointer::offset`] हो।
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// पोइन्टरबाट अफसेट गणना गर्दछ, संभावित र्‍यापिंग।
    ///
    /// रूपान्तरणले केही अप्टिमाइजेसनलाई रोक्ने हुनाले, पूर्णांकमा र कन्भर्टरबाट परिवर्तन हुनबाट रोक्नको लागि यो एक आंतरिक रूपमा लागू गरिएको छ।
    ///
    /// # Safety
    ///
    /// `offset` ईन्टर्सेनिकको विपरीत, यो इन्टरन्सिकले परिणामस्वरूप पोइन्टरलाई निर्दिष्ट गर्न को लागी बाधा दिन्छ वा एक बाइटलाई अन्तिम वस्तुको अन्तमा बाइट गर्छ, र यसले दुईको पूरक अंकगणितको साथ लपेट्छ।
    /// परिणामस्वरूप मान वास्तविक मेमोरीमा पहुँचका लागि प्रयोग गर्नका लागि मान्य हुनुपर्दैन।
    ///
    /// यस ईन्टरिसिकको स्थिर संस्करण [`pointer::wrapping_offset`] हो।
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// `count`*`size_of::<T>()` को आकार र एक पign्क्तिबद्धको साथ उपयुक्त `llvm.memcpy.p0i8.0i8.*` आन्तरिक सँग समान।
    ///
    /// `min_align_of::<T>()`
    ///
    /// अस्थिर प्यारामिटर `true` मा सेट गरिएको छ, त्यसैले यो शून्य बराबर नभएसम्म अप्टिमाइज हुने छैन।
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// `count *size_of::<T>()` को आकार र एक पign्क्तिबद्धको साथ उपयुक्त `llvm.memmove.p0i8.0i8.*` आन्तरिक सँग समान
    ///
    /// `min_align_of::<T>()`
    ///
    /// अस्थिर प्यारामिटर `true` मा सेट गरिएको छ, त्यसैले यो शून्य बराबर नभएसम्म अप्टिमाइज हुने छैन।
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// `count *size_of::<T>()` को आकार र `min_align_of::<T>()` को प with्क्तिबद्धको साथ उपयुक्त `llvm.memset.p0i8.*` आन्तरिकसँग समान।
    ///
    ///
    /// अस्थिर प्यारामिटर `true` मा सेट गरिएको छ, त्यसैले यो शून्य बराबर नभएसम्म अप्टिमाइज हुने छैन।
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// `src` सूचक बाट एक वाष्पशील लोड प्रदर्शन गर्दछ।
    ///
    /// यस ईन्टरिसिकको स्थिर संस्करण [`core::ptr::read_volatile`](crate::ptr::read_volatile) हो।
    pub fn volatile_load<T>(src: *const T) -> T;
    /// `dst` सूचक लाई एक वाष्पशील स्टोर प्रदर्शन गर्दछ।
    ///
    /// यस ईन्टरिसिकको स्थिर संस्करण [`core::ptr::write_volatile`](crate::ptr::write_volatile) हो।
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// `src` सूचक बाट एक अस्थिर लोड प्रदर्शन गर्दछ सूचक प al्क्तिबद्ध गर्न आवश्यक छैन।
    ///
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// `dst` सूचक लाई एक वाष्पशील स्टोर प्रदर्शन गर्दछ।
    /// सूचक प al्क्तिबद्ध हुन आवश्यक छैन।
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// `f32` को वर्गमूल फर्काउँछ
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// `f64` को वर्गमूल फर्काउँछ
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// एक पूर्णांक शक्तिमा `f32` खडा गर्छ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// एक पूर्णांक शक्तिमा `f64` खडा गर्छ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// `f32` को साइन फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// `f64` को साइन फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// `f32` कोसाइन फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// `f64` कोसाइन फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// एक `f32` लाई `f32` पावरमा उठाउँदछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// एक `f64` लाई `f64` पावरमा उठाउँदछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// `f32` को घाता .्क फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// `f64` को घाता .्क फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// 2 `f32` X को शक्तिमा उठाइएको फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// 2 `f64` X को शक्तिमा उठाइएको फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// `f32` को प्राकृतिक लघुगणक फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// `f64` को प्राकृतिक लघुगणक फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// `f32` को आधार १० लोगारिथम फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// `f64` को आधार १० लोगारिथम फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// एक `f32` को आधार 2 लोगारिथम फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// एक `f64` को आधार 2 लोगारिथम फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// `f32` मानहरूको लागि `a * b + c` फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// `f64` मानहरूको लागि `a * b + c` फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// `f32` को निरपेक्ष मान फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// `f64` को निरपेक्ष मान फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// न्यूनतम दुई `f32` मानहरू फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// न्यूनतम दुई `f64` मानहरू फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// अधिकतम दुई `f32` मानहरू फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// अधिकतम दुई `f64` मानहरू फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// `f32` मानहरूको लागि `y` बाट `x` मा साइन प्रतिलिपि गर्दछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// `f64` मानहरूको लागि `y` बाट `x` मा साइन प्रतिलिपि गर्दछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// `f32` भन्दा कम वा बराबर सबैभन्दा ठूलो पूर्णांक फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// `f64` भन्दा कम वा बराबर सबैभन्दा ठूलो पूर्णांक फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// `f32` भन्दा ठूलो वा बराबर सब भन्दा सानो पूर्णा Return्क फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// `f64` भन्दा ठूलो वा बराबर सब भन्दा सानो पूर्णा Return्क फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// `f32` को पूर्णांक भाग फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// `f64` को पूर्णांक भाग फर्काउँछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// `f32` मा नजिकको पूर्णांक फर्काउँछ।
    /// तर्क एक अस्थायी बिन्दु अपवाद उठाउन सक्छ यदि तर्क एक पूर्णांक हैन।
    pub fn rintf32(x: f32) -> f32;
    /// `f64` मा नजिकको पूर्णांक फर्काउँछ।
    /// तर्क एक अस्थायी बिन्दु अपवाद उठाउन सक्छ यदि तर्क एक पूर्णांक हैन।
    pub fn rintf64(x: f64) -> f64;

    /// `f32` मा नजिकको पूर्णांक फर्काउँछ।
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    pub fn nearbyintf32(x: f32) -> f32;
    /// `f64` मा नजिकको पूर्णांक फर्काउँछ।
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    pub fn nearbyintf64(x: f64) -> f64;

    /// `f32` मा नजिकको पूर्णांक फर्काउँछ।शून्य देखि आधा बाटो केस राउन्ड गर्दछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// `f64` मा नजिकको पूर्णांक फर्काउँछ।शून्य देखि आधा बाटो केस राउन्ड गर्दछ।
    ///
    /// यस आन्तरिक को स्थिर संस्करण हो
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// फ्लोट एडिज जसले बीजगणित नियममा आधारित अनुकूलन अनुमति दिन्छ।
    /// हुन सक्छ इनपुटहरू परिमित छन्।
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// फ्लोट घटाउ जुन बीजगणित नियममा आधारित अनुकूलन अनुमति दिन्छ।
    /// हुन सक्छ इनपुटहरू परिमित छन्।
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// फ्लोट गुणन जसले बीजगणित नियममा आधारित अनुकूलन अनुमति दिन्छ।
    /// हुन सक्छ इनपुटहरू परिमित छन्।
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// फ्लोट डिभिजन जसले बीजगणित नियममा आधारित अनुकूलन अनुमति दिन्छ।
    /// हुन सक्छ इनपुटहरू परिमित छन्।
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// फ्लोट शेष र बीजगणित नियमहरूको आधारमा अनुकूलन अनुमति दिन्छ।
    /// हुन सक्छ इनपुटहरू परिमित छन्।
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// LLVM को fptoui/fptosi को साथ रूपान्तरण गर्नुहोस्, जुन दायरा भन्दा बाहिरको मानहरूको लागि अपरिचित फिर्ता हुन सक्छ
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// [`f32::to_int_unchecked`] र [`f64::to_int_unchecked`] को रूपमा स्थिर।
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// पूर्णांक प्रकार `T` मा सेट बिट्सको संख्या फर्काउँछ
    ///
    /// यस इन्टरसिकको स्थिर संस्करणहरू पूर्णांक प्रिमिटिभहरूमा `count_ones` विधि मार्फत उपलब्ध छन्।
    /// उदाहरण को लागी,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// पूर्णांक प्रकार `T` मा अग्रणी अनसेट बिट्स (zeroes) को संख्या फर्काउँछ।
    ///
    /// यस इन्टरसिकको स्थिर संस्करणहरू पूर्णांक प्रिमिटिभहरूमा `leading_zeros` विधि मार्फत उपलब्ध छन्।
    /// उदाहरण को लागी,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `0` मानको साथ एक `x` `T` को बिट चौड़ाई फर्काउँछ।
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// `ctlz` जस्तै, तर अतिरिक्त असुरक्षित यो `undef` फर्काउँछ जब `0` मानको साथ `x` दिईयो।
    ///
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// पूर्णांक प्रकार `T` मा ट्रेलिंग अनसेट बिट्स (zeroes) को संख्या फर्काउँछ।
    ///
    /// यस इन्टरसिकको स्थिर संस्करणहरू पूर्णांक प्रिमिटिभहरूमा `trailing_zeros` विधि मार्फत उपलब्ध छन्।
    /// उदाहरण को लागी,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `0` मानको साथ एक `x` `T` को बिट चौड़ाई फर्काउँछ:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// `cttz` जस्तै, तर अतिरिक्त असुरक्षित यो `undef` फर्काउँछ जब `0` मानको साथ `x` दिईयो।
    ///
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// बाइट्सलाई पूर्णा type्क `T` मा फर्काउँछ।
    ///
    /// यस इन्टरसिकको स्थिर संस्करणहरू पूर्णांक प्रिमिटिभहरूमा `swap_bytes` विधि मार्फत उपलब्ध छन्।
    /// उदाहरण को लागी,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// बिट्सलाई पूर्णा type्क `T` मा फर्काउँछ।
    ///
    /// यस इन्टरसिकको स्थिर संस्करणहरू पूर्णांक प्रिमिटिभहरूमा `reverse_bits` विधि मार्फत उपलब्ध छन्।
    /// उदाहरण को लागी,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// पूर्णांक जोडिएको जाँच गर्दछ।
    ///
    /// यस इन्टरसिकको स्थिर संस्करणहरू पूर्णांक प्रिमिटिभहरूमा `overflowing_add` विधि मार्फत उपलब्ध छन्।
    /// उदाहरण को लागी,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// जाँचिएको पूर्णांक घटाव प्रदर्शन गर्दछ
    ///
    /// यस इन्टरसिकको स्थिर संस्करणहरू पूर्णांक प्रिमिटिभहरूमा `overflowing_sub` विधि मार्फत उपलब्ध छन्।
    /// उदाहरण को लागी,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// जाँचिएको पूर्णांक गुणन प्रदर्शन गर्दछ
    ///
    /// यस इन्टरसिकको स्थिर संस्करणहरू पूर्णांक प्रिमिटिभहरूमा `overflowing_mul` विधि मार्फत उपलब्ध छन्।
    /// उदाहरण को लागी,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Xx1X वा `y == 0` वा `x == T::MIN && y == -1` जहाँ अपरिभाषित व्यवहारको परिणाममा एक सटीक विभाजन गर्दछ
    ///
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// `y == 0` वा `x == T::MIN && y == -1` जहाँ अपरिभाषित व्यवहारको परिणाम स्वरूप, एक जाँच नगरिएको विभाजन प्रदर्शन गर्दछ
    ///
    ///
    /// यस इन्टरसिनिकको लागि सुरक्षित र्यापर्सहरू इन्टिजर प्रिमिटिभहरूमा `checked_div` विधि मार्फत उपलब्ध छन्।
    /// उदाहरण को लागी,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// `y == 0` वा `x == T::MIN && y == -1` जब अपरिभाषित व्यवहारको परिणामस्वरूप चिनिएको जाँच नगरिएको बाँकी फर्काउँछ
    ///
    ///
    /// यस इन्टरसिनिकको लागि सुरक्षित र्यापर्सहरू इन्टिजर प्रिमिटिभहरूमा `checked_rem` विधि मार्फत उपलब्ध छन्।
    /// उदाहरण को लागी,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// `y < 0` वा `y >= N`, जहाँ N बिटमा T को चौडाइ हो, जब `y < 0` वा `y >= N`, अपरिभाषित व्यवहारको परिणामस्वरूप एक जाँच नगरिएको बाँया सिफ्ट प्रदर्शन गर्दछ।
    ///
    ///
    /// यस इन्टरसिनिकको लागि सुरक्षित र्यापर्सहरू इन्टिजर प्रिमिटिभहरूमा `checked_shl` विधि मार्फत उपलब्ध छन्।
    /// उदाहरण को लागी,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// `y < 0` वा `y >= N`, जहाँ N बिटमा T को चौडाइ छ, जब `y < 0` वा `y >= N`, अपरिभाषित व्यवहारको परिणामस्वरूप एक जाँच नगरिएको दायाँ सिफ्ट प्रदर्शन गर्दछ।
    ///
    ///
    /// यस इन्टरसिनिकको लागि सुरक्षित र्यापर्सहरू इन्टिजर प्रिमिटिभहरूमा `checked_shr` विधि मार्फत उपलब्ध छन्।
    /// उदाहरण को लागी,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// `x + y > T::MAX` वा `x + y < T::MIN` जब अपरिभाषित व्यवहारको नतिजामा, जाँच नगरिएको थपको नतिजा फर्काउँछ।
    ///
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// `x - y > T::MAX` वा `x - y < T::MIN` जब अपरिभाषित व्यवहारको परिणामस्वरूप चिनिएको जाँच नगरिएको घटाउको परिणाम दिन्छ।
    ///
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// `x *y > T::MAX` वा `x* y < T::MIN` जब अपरिभाषित व्यवहारको नतिजामा चिनिएको चेक गरिएको गुणनको परिणाम फर्काउँछ।
    ///
    ///
    /// यो इनर्न्सिक एक स्थिर समकक्ष छैन।
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// बायाँ घुमाउनुहोस्।
    ///
    /// यस इन्टरसिकको स्थिर संस्करणहरू पूर्णांक प्रिमिटिभहरूमा `rotate_left` विधि मार्फत उपलब्ध छन्।
    /// उदाहरण को लागी,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// दायाँ घुमाउनुहोस्।
    ///
    /// यस इन्टरसिकको स्थिर संस्करणहरू पूर्णांक प्रिमिटिभहरूमा `rotate_right` विधि मार्फत उपलब्ध छन्।
    /// उदाहरण को लागी,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// फर्काउँछ (a + b) मोड २ <sup>N</sup>, जहाँ N बिटमा T को चौडाइ हो।
    ///
    /// यस इन्टरसिकको स्थिर संस्करणहरू पूर्णांक प्रिमिटिभहरूमा `wrapping_add` विधि मार्फत उपलब्ध छन्।
    /// उदाहरण को लागी,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// फर्काउँछ (a, b) मोड २ <sup>N</sup>, जहाँ N बिटमा T को चौडाइ हो।
    ///
    /// यस इन्टरसिकको स्थिर संस्करणहरू पूर्णांक प्रिमिटिभहरूमा `wrapping_sub` विधि मार्फत उपलब्ध छन्।
    /// उदाहरण को लागी,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// फर्काउँछ (a * b) मोड २ <sup>N</sup>, जहाँ N बिटमा T को चौडाइ हो।
    ///
    /// यस इन्टरसिकको स्थिर संस्करणहरू पूर्णांक प्रिमिटिभहरूमा `wrapping_mul` विधि मार्फत उपलब्ध छन्।
    /// उदाहरण को लागी,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// गणना `a + b`, संख्यात्मक सीमा मा saturating।
    ///
    /// यस इन्टरसिकको स्थिर संस्करणहरू पूर्णांक प्रिमिटिभहरूमा `saturating_add` विधि मार्फत उपलब्ध छन्।
    /// उदाहरण को लागी,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// गणना `a - b`, संख्यात्मक सीमा मा saturating।
    ///
    /// यस इन्टरसिकको स्थिर संस्करणहरू पूर्णांक प्रिमिटिभहरूमा `saturating_sub` विधि मार्फत उपलब्ध छन्।
    /// उदाहरण को लागी,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// 'v' मा भेरियन्टको लागि भेदभावकर्ताको मान फर्काउँछ;
    /// यदि `T` का कुनै भेदभाव छैन भने, `0` फर्काउँछ।
    ///
    /// यस ईन्टरिसिकको स्थिर संस्करण [`core::mem::discriminant`](crate::mem::discriminant) हो।
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// `T` प्रकारको प्रकारलाई `usize` मा फर्काउँदछ;
    /// यदि `T` का कुनै भेरियन्ट छैन भने, `0` फर्काउँछ।निर्बाध रूपहरु गणना हुनेछ।
    ///
    /// यस इन्टरनसिकको हुनुपर्ने स्थिर संस्करण [`mem::variant_count`] हो।
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust को "try catch" निर्माण जो डेटा सूचक `try_fn` डाटा पोइन्टर `data` साथ आह्वान गर्दछ।
    ///
    /// तेस्रो आर्गुमेन्ट एक कार्य भनिन्छ यदि panic देखा पर्‍यो।
    /// यो प्रकार्यले डाटा पॉईन्टर र सूचक लिन्छ लक्षित-विशिष्ट अपवाद वस्तुमा जुन समातिएको थियो।
    ///
    /// अधिक जानकारीको लागि कम्पाइलरको स्रोतको साथ साथै std को क्याच कार्यान्वयन हेर्नुहोस्।
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// LLVM (उनीहरूको कागजातहरू हेर्नुहोस्) को अनुसार `!nontemporal` स्टोर निकाल्छ।
    /// सायद कहिल्यै स्थिर हुँदैन।
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// विवरणका लागि `<*const T>::offset_from` को कागजात हेर्नुहोस्।
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// विवरणका लागि `<*const T>::guaranteed_eq` को कागजात हेर्नुहोस्।
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// विवरणका लागि `<*const T>::guaranteed_ne` को कागजात हेर्नुहोस्।
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// कम्पाईल समयमा आवंटित गर्नुहोस्।रनटाइममा कल गर्नु हुँदैन।
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// केहि कार्यहरू यहाँ परिभाषित छन् किनकि ती गल्तिले स्थिरमा यो मोड्युलमा उपलब्ध गराइयो।
// <https://github.com/rust-lang/rust/issues/15702> हेर्नुहोस्।
// (`transmute` पनि यस कोटी मा पर्दछ, तर यो `T` र `U` को समान आकार छ भनेर चेकको कारण यसलाई लपेट्न सकिदैन।)
//

/// `ptr` `align_of::<T>()` को सम्बन्धमा उचित रूपमा पigned्क्तिबद्ध गरिएको छ कि छैन जाँच गर्दछ।
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// `count *size_of::<T>()` बाट `dst` मा `count* size_of::<T>()` बाइट्स प्रतिलिपि गर्दछ।स्रोत र गन्तव्य * ओभरल्याप हुँदैन।
///
/// मेमोरी क्षेत्रका लागि जुन ओभरल्याप हुन सक्छ, यसको सट्टामा [`copy`] प्रयोग गर्नुहोस्।
///
/// `copy_nonoverlapping` शब्दार्थको रूपमा C को [`memcpy`] बराबर छ, तर तर्क अर्डरको साथ बदली भयो।
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// निम्न शर्तहरु मध्ये कुनै एक उल्लंघन गरिएको छ भने व्यवहार अपरिभाषित छ:
///
/// * `src` `count * size_of::<T>()` बाइट्स पढ्नको लागि [valid] हुनु पर्छ।
///
/// * `dst` `count * size_of::<T>()` बाइट्सका लागि [valid] हुनु पर्छ।
///
/// * दुबै `src` र `dst` उचित रूपमा प al्क्तिबद्ध गरिएको हुनुपर्दछ।
///
/// * Memory गणनाको आकारको साथ `src` मा मेमोरीको क्षेत्र सुरू हुन्छ *
///   आकार_को: :<T>() `बाइट्स * एकै आकारको `dst` मा मेमोरी शुरू हुने क्षेत्रसँग ओभरल्याप हुँदैन।
///
/// [`read`] जस्तै, `copy_nonoverlapping` `T` को एक बिटवाइज प्रतिलिपि सिर्जना गर्दछ, `T` [`Copy`] हो कि होइन।
/// यदि `T` [`Copy`] हैन भने,*दुबै* क्षेत्रको मानहरू `*src` मा शुरू हुने र `* dst` बाट सुरु हुने क्षेत्र [violate memory safety][read-ownership] प्रयोग गरेर।
///
///
/// नोट गर्नुहोस् कि प्रभावी ढ cop्गले प्रतिलिपि गरिएको आकार (`गणना * आकार_of: :<T>()`) `0` हो, पोइन्टरहरू गैर-NULL हुनुपर्दछ र राम्रोसँग पigned्क्तिबद्ध गरिएको हुनुपर्दछ।
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// म्यानुअली [`Vec::append`] कार्यान्वयन गर्नुहोस्:
///
/// ```
/// use std::ptr;
///
/// /// `src` का सबै तत्वहरूलाई `dst` मा सार्दछ, `src` खाली छोड्छ।
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // सुनिश्चित गर्नुहोस् कि `dst` को सबै `src` लाई समात्न पर्याप्त क्षमता छ।
///     dst.reserve(src_len);
///
///     unsafe {
///         // अफसेटमा कल सँधै सुरक्षित हुन्छ किनकि `Vec` कहिले पनि `isize::MAX` बाइट भन्दा बढि आबंटन गर्दैन।
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // यसको सामग्री ड्रप नगरी `src` काट्नुहोस्।
///         // हामी पहिले यो गर्छौं, केहि बढि panics तल समस्याहरूमा पर्नबाट जोगिन।
///         src.set_len(0);
///
///         // दुई क्षेत्रहरू ओभरल्याप हुन सक्दैन किनकि उत्परिवर्तनिय सन्दर्भहरू उपनाम हुँदैन, र दुई फरक vectors उही मेमोरीको स्वामित्व लिन सक्दैन।
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // `dst` लाई सूचित गर्नुहोस् कि यसले अब `src` को सामग्री हो।
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: चालु समयमा मात्र यी जाँचहरू प्रदर्शन गर्नुहोस्
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // कोडेजेन प्रभाव सानो राख्न घाबराउने छैन।
        abort();
    }*/

    // सुरक्षा: `copy_nonoverlapping` का लागि सुरक्षा सम्झौता हुनै पर्छ
    // कलरले समर्थन गर्यो।
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// `count *size_of::<T>()` बाट `dst` मा `count* size_of::<T>()` बाइट्स प्रतिलिपि गर्दछ।स्रोत र गन्तव्य ओभरल्याप हुन सक्छ।
///
/// यदि स्रोत र गन्तव्य *कहिल्यै* ओभरल्याप हुँदैन, [`copy_nonoverlapping`] सट्टा प्रयोग गर्न सकिन्छ।
///
/// `copy` शब्दार्थको रूपमा C को [`memmove`] बराबर छ, तर तर्क अर्डरको साथ बदली भयो।
/// प्रतिलिपि गर्ने ठाउँ लिइन्छ यदि बाइट्स `src` बाट अस्थायी एरेमा प्रतिलिपि गरिएको थियो र त्यसपछि एर्रेबाट `dst` मा प्रतिलिपि गरिएको थियो।
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// निम्न शर्तहरु मध्ये कुनै एक उल्लंघन गरिएको छ भने व्यवहार अपरिभाषित छ:
///
/// * `src` `count * size_of::<T>()` बाइट्स पढ्नको लागि [valid] हुनु पर्छ।
///
/// * `dst` `count * size_of::<T>()` बाइट्सका लागि [valid] हुनु पर्छ।
///
/// * दुबै `src` र `dst` उचित रूपमा प al्क्तिबद्ध गरिएको हुनुपर्दछ।
///
/// [`read`] जस्तै, `copy` `T` को एक बिटवाइज प्रतिलिपि सिर्जना गर्दछ, `T` [`Copy`] हो कि होइन।
/// यदि `T` [`Copy`] हैन भने, दुबै क्षेत्रको `*src` मा शुरू हुने क्षेत्र र `* dst` मा शुरू हुने क्षेत्र [violate memory safety][read-ownership] गर्न सक्दछ।
///
///
/// नोट गर्नुहोस् कि प्रभावी ढ cop्गले प्रतिलिपि गरिएको आकार (`गणना * आकार_of: :<T>()`) `0` हो, पोइन्टरहरू गैर-NULL हुनुपर्दछ र राम्रोसँग पigned्क्तिबद्ध गरिएको हुनुपर्दछ।
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// असुरक्षित बफरबाट कुशलतापूर्वक Rust vector सिर्जना गर्नुहोस्:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` यसको प्रकार र गैर-शून्यको लागि सही तरिकाले प .्क्तिबद्ध गरिएको हुनुपर्दछ।
/// /// * `ptr` `elts` प्रकार `T` का मिल्दो तत्वहरूको पढ्नका लागि वैध हुनै पर्छ।
/// /// * ती तत्वहरू `T: Copy` नभएसम्म यो प्रकार्य कल गरेपछि प्रयोग गर्नु हुँदैन।
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // सुरक्षा: हाम्रो पूर्व शर्त सुनिश्चित गर्दछ स्रोत प al्क्तिबद्ध र मान्य छ,
///     // र `Vec::with_capacity` ले सुनिश्चित गर्दछ कि हामीसँग उनीहरूलाई लेख्नको लागि उपयोगी स्थान छ।
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // सुरक्षा: हामीले यो पहिले धेरै क्षमताको साथ सिर्जना गर्यौं।
///     // र अघिल्लो `copy` यी तत्वहरू सुरूवात गरिसक्यो।
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: चालु समयमा मात्र यी जाँचहरू प्रदर्शन गर्नुहोस्
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // कोडेजेन प्रभाव सानो राख्न घाबराउने छैन।
        abort();
    }*/

    // सुरक्षा: `copy` को लागी सुरक्षा सम्झौता कलर द्वारा समर्थित हुनु पर्छ।
    unsafe { copy(src, dst, count) }
}

/// `count *size_of::<T>()` बाट `val` मा मेमोरीको `count* size_of::<T>()` बाइट्स सेट गर्दछ।
///
/// `write_bytes` C को [`memset`] समान छ, तर `count * size_of::<T>()` बाइट्सलाई `val` मा सेट गर्दछ।
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// निम्न शर्तहरु मध्ये कुनै एक उल्लंघन गरिएको छ भने व्यवहार अपरिभाषित छ:
///
/// * `dst` `count * size_of::<T>()` बाइट्सका लागि [valid] हुनु पर्छ।
///
/// * `dst` राम्रोसँग पigned्क्तिबद्ध गरिएको हुनुपर्दछ।
///
/// थप रूपमा, कलरले `count * size_of::<T>()` बाइट्सको लिखित मेमोरीको क्षेत्रलाई `T` को वैध मानमा परिणाम दिन्छ भनेर सुनिश्चित गर्नुपर्दछ।
/// `T` को रूपमा टाइप गरिएको मेमोरीको क्षेत्र प्रयोग गरेर जसले `T` को अमान्य मान समावेश गर्दछ अपरिभाषित व्यवहार हो।
///
/// नोट गर्नुहोस् कि प्रभावी ढ cop्गले प्रतिलिपि गरिएको आकार (`गणना * आकार_of: :<T>()`) `0` हो, सूचक गैर-NULL र सही रूपमा प properly्क्तिबद्ध गरिएको हुनुपर्दछ।
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// आधारभूत उपयोग:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// अवैध मान सिर्जना गर्दै:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // एक नल पोइन्टरको साथ `Box<T>` लाई ओभरराइट गरेर अघिल्लो होल्ड गरिएको मान लीक गर्दछ।
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // यस बिन्दुमा, `v` को प्रयोग वा छोड्दा अपरिभाषित व्यवहारमा परिणामहरू।
/// // drop(v); // ERROR
///
/// // यहाँ सम्म कि `v` "uses" लीक पनि, र त्यसैले अपरिभाषित व्यवहार हो।
/// // mem::forget(v); // ERROR
///
/// // वास्तवमा, `v` आधारभूत प्रकार लेआउट इन्वाइरन्टहरू अनुसार अमान्य छ, त्यसैले *कुनै पनि* यसलाई छुने अपरेसन अपरिभाषित व्यवहार हो।
/////
/// // v2 =v;//ERROR
///
/// unsafe {
///     // हामी यसको सट्टा वैध मान राखौं
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // अब बक्स ठीक छ
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // सुरक्षा: `write_bytes` को लागी सुरक्षा सम्झौता कलर द्वारा समर्थित हुनु पर्छ।
    unsafe { write_bytes(dst, val, count) }
}