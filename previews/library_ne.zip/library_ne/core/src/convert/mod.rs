//! प्रकारहरू बीचको रूपान्तरणको लागि Traits।
//!
//! यस मोड्युलमा traits एक प्रकार बाट अर्को प्रकारमा रूपान्तरण गर्न एक तरिका प्रदान गर्दछ।
//! प्रत्येक trait ले बिभिन्न उद्देश्यका लागि कार्य गर्दछ:
//!
//! - [`AsRef`] trait सस्तो सन्दर्भ-सन्दर्भ रूपान्तरणको लागि लागू गर्नुहोस्
//! - [`AsMut`] trait लागू गर्नुहोस् सस्तो म्युटेबल-बाट-रूपान्तरण रूपान्तरणको लागि
//! - मूल्य-देखि-मान रूपान्तरण उपभोगको लागि [`From`] trait कार्यान्वयन गर्नुहोस्
//! - वर्तमान crate बाहिरका प्रकारहरूमा मान-बाट-रूपान्तरण उपभोगको लागि [`Into`] trait कार्यान्वयन गर्नुहोस्।
//! - [`TryFrom`] र [`TryInto`] traits [`From`] र [`Into`] जस्तो व्यवहार गर्दछ, तर कार्यान्वयन गरिनु पर्छ जब रूपान्तरण असफल हुन सक्छ।
//!
//! यस मोड्युलमा traits प्राय: trait bounds को रूपमा जेनेरिक फंक्शन्सको लागि प्रयोग गरिन्छ जस्तै बहु प्रकारका आर्गुमेन्टहरूलाई समर्थन गर्दछ।उदाहरणका लागि प्रत्येक trait को कागजात हेर्नुहोस्।
//!
//! पुस्तकालय लेखकको रूपमा तपाईले सँधै [`From<T>`][`From`] वा [`TryFrom<T>`][`TryFrom`] [`Into<U>`][`Into`] वा [`TryInto<U>`][`TryInto`] लाई लागू गर्न रुचाउनु पर्छ, किनभने [`From`] र [`TryFrom`] अधिक लचकता प्रदान गर्दछ र बराबर [`Into`] वा [`TryInto`] कार्यान्वयनको नि: शुल्क प्रस्ताव गर्दछ, मानक लाइब्रेरीमा कम्बल कार्यान्वयनको लागि धन्यवाद।
//! Rust 1.41 भन्दा पहिले संस्करणलाई लक्षित गर्दा, वर्तमान crate बाहिर प्रकारमा रूपान्तरण गर्दा [`Into`] वा [`TryInto`] प्रत्यक्ष रूपमा कार्यान्वयन गर्न आवश्यक हुन सक्छ।
//!
//! # सामान्य कार्यान्वयन
//!
//! - [`AsRef`] र [`AsMut`] स्वत: dereferences यदि भित्री प्रकार सन्दर्भ हो
//! - [`From`]`<U>T` को लागी [`Into`]`को लागी</u><T><U>U` को लागी</u>
//! - [`TryFrom`]`<U>T` को लागी [`TryInto`] lies संकेत गर्दछ</u><T><U>U` को लागी</u>
//! - [`From`] र [`Into`] रिफ्लेक्सिभ हो, जसको मतलब सबै प्रकारहरू आफैले `into` र आफै `from` गर्न सक्छन्
//!
//! उपयोग उदाहरणका लागि प्रत्येक trait हेर्नुहोस्।
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// पहिचान प्रकार्य।
///
/// यस प्रकार्यका बारे दुई कुरा ध्यान दिनुहोस्:
///
/// - यो सँधै `|x| x` जस्तै बन्द हुने बराबरी हुँदैन, किनकि क्लोजरले `x` लाई बिभिन्न प्रकारमा बाध्य पार्दछ।
///
/// - यसले कार्यमा पारित इनपुट `x` सार्दछ।
///
/// जबकि यो समारोहमा अनौंठो लाग्न सक्छ जुन केवल इनपुट फिर्ता फिर्ता गर्छ, त्यहाँ केहि चाखलाग्दो प्रयोगहरू छन्।
///
///
/// # Examples
///
/// अन्य, रोचक, प्रकार्यहरूको क्रममा केही गर्न `identity` प्रयोग गर्दै:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // एक बहाना एक रोचक समारोह हो कि नाटक गरौं।
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// सशर्तमा `identity` X आधार केसको रूपमा `identity` प्रयोग गर्दै:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // रमाईलो चीज गर्नुहोस् ...
///
/// let _results = do_stuff(42);
/// ```
///
/// `identity` प्रयोग गर्दै X002 को एक इटरेटरको `Some` भेरियन्टहरू राख्न:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// सस्तो सन्दर्भ-बाट रूपान्तरण गर्न प्रयोग गरियो।
///
/// यो trait [`AsMut`] सँग मिल्दोजुल्दो छ जुन परिवर्तनकारी सन्दर्भहरूको बीचमा रूपान्तरणको लागि प्रयोग गरिन्छ।
/// यदि तपाइँ महँगो रूपान्तरण गर्नु पर्छ भने [`From`] लाई `&T` टाइपको साथ कार्यान्वयन गर्नु राम्रो हुन्छ वा अनुकूलित प्रकार्य लेख्नुहोस्।
///
/// `AsRef` [`Borrow`] को समान हस्ताक्षर छ, तर [`Borrow`] केहि पक्षहरुमा फरक छ:
///
/// - `AsRef` विपरीत, [`Borrow`] सँग कुनै `T` का लागि एक कम्बल ईम्प्ल छ, र कि त सन्दर्भ वा मान स्वीकार गर्न प्रयोग गर्न सकिन्छ।
/// - [`Borrow`] [`Hash`], [`Eq`] र [`Ord`] उधारो मानको लागि स्वामित्वको मूल्यको बराबरको पनि आवश्यक छ।
/// यस कारणका लागि, यदि तपाइँ संरचनाको केवल एकल क्षेत्र उधार लिन चाहनुहुन्छ भने तपाइँ `AsRef` कार्यान्वयन गर्न सक्नुहुन्छ, तर [`Borrow`]।
///
/// **Note: यो trait असफल हुनु हुँदैन **।यदि रूपान्तरण असफल हुन सक्छ, एक समर्पित विधि प्रयोग गर्नुहोस् जुन [`Option<T>`] वा [`Result<T, E>`] फर्काउँछ।
///
/// # सामान्य कार्यान्वयन
///
/// - `AsRef` स्वत: dereferences यदि भित्री प्रकार एक संदर्भ वा एक परिवर्तनीय संदर्भ हो (उदाहरण: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// trait bounds प्रयोग गरेर हामी विभिन्न प्रकारका आर्गुमेन्टहरू स्वीकार गर्न सक्दछौं जबसम्म तिनीहरू निर्दिष्ट प्रकार `T` मा रूपान्तरण गर्न सकिन्छ।
///
/// उदाहरणका लागि: जेनेरिक फंक्शन बनाएर जुन `AsRef<str>` लिन्छ हामी व्यक्त गर्दछौं कि हामी सबै सन्दर्भहरू स्वीकार गर्न चाहान्छौं जुन [`&str`] मा आर्गुमेन्टका रूपमा रूपान्तरण गर्न सकिन्छ।
/// दुबै [`String`] र [`&str`] `AsRef<str>` कार्यान्वयन गर्नाले हामी दुबैलाई आगत आर्गुमेन्टका रूपमा स्वीकार्न सक्छौं।
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// रूपान्तरण गर्छ
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// सस्तो म्युटेबल-बाट-म्युटेबल सन्दर्भ रूपान्तरण गर्न प्रयोग।
///
/// यो trait [`AsRef`] सँग मिल्दोजुल्दो छ तर परिवर्तनीय सन्दर्भहरूको बीच रूपान्तरणको लागि प्रयोग गरिन्छ।
/// यदि तपाइँ महँगो रूपान्तरण गर्नु पर्छ भने [`From`] लाई `&mut T` टाइपको साथ कार्यान्वयन गर्नु राम्रो हुन्छ वा अनुकूलित प्रकार्य लेख्नुहोस्।
///
/// **Note: यो trait असफल हुनु हुँदैन **।यदि रूपान्तरण असफल हुन सक्छ, एक समर्पित विधि प्रयोग गर्नुहोस् जुन [`Option<T>`] वा [`Result<T, E>`] फर्काउँछ।
///
/// # सामान्य कार्यान्वयन
///
/// - `AsMut` स्वत: dereferences यदि भित्री प्रकार एक परिवर्तनीय संदर्भ हो (उदाहरण: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// `AsMut` trait bound को रूपमा जेनेरिक फंक्शनको लागि प्रयोग गरेर हामी सबै परिवर्तनीय सन्दर्भहरू स्वीकार गर्न सक्छौं जुन `&mut T` प्रकारमा रूपान्तरण गर्न सकिन्छ।
/// किनभने [`Box<T>`] ले `AsMut<T>` कार्यान्वयन गर्दछ हामी एउटा प्रकार्य `add_one` लेख्न सक्दछौं जुन `&mut u64` X मा रूपान्तरण गर्न सकिने सबै आर्गुमेन्टहरू लिन्छन्।
/// किनभने [`Box<T>`] ले `AsMut<T>` लागू गर्दछ, `add_one` `&mut Box<u64>` प्रकारको आर्गुमेन्टहरू पनि स्वीकार गर्दछ:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// रूपान्तरण गर्छ
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// एक मान-देखि-मान रूपान्तरण जसले इनपुट मूल्य खपत गर्दछ।[`From`] को विपरित।
///
/// कसैले [`Into`] कार्यान्वयनबाट टाढा रहनु पर्छ र यसको सट्टा [`From`] कार्यान्वयन गर्नु पर्छ।
/// [`From`] कार्यान्वयन स्वचालित रूपमा [`Into`] को कार्यान्वयनको साथ मानक लाइब्रेरीमा कम्बल कार्यान्वयनको लागि प्रदान गर्दछ।
///
/// [`Into`] X मा [`Into`] प्रयोग गर्न प्राथमिकता दिनुहोस् जब जेनेरेटिक प्रकार्यमा trait bounds निर्दिष्ट गर्दा निश्चित गर्नुहोस् कि केवल [`Into`] कार्यान्वयन गर्ने प्रकारहरू पनि प्रयोग गर्न सकिन्छ।
///
/// **Note: यो trait असफल हुनु हुँदैन **।यदि रूपान्तरण असफल हुन सक्छ, [`TryInto`] प्रयोग गर्नुहोस्।
///
/// # सामान्य कार्यान्वयन
///
/// - [`From`]`<T>U` को लागि `Into<U> for T` संकेत गर्छ
/// - [`Into`] रिफ्लेक्सिभ हो, जसको मतलब हो कि `Into<T> for T` कार्यान्वयन गरिएको छ
///
/// # Rust को पुरानो संस्करणमा बाह्य प्रकारमा रूपान्तरणको लागि [`Into`] कार्यान्वयन गर्दै
///
/// Rust 1.41 अघि, यदि गन्तव्य प्रकार हालको crate को हिस्सा थिएन भने तपाईं [`From`] सीधा कार्यान्वयन गर्न सक्नुहुन्न।
/// उदाहरण को लागी, यो कोड लिनुहोस्:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// यसले भाषाको पुरानो संस्करणमा कम्पाइल गर्न असफल हुने छ किनकि Rust को अनाथाई नियमहरू थोरै बढी कडा हुने थियो।
/// यसलाई बाइपास गर्न, तपाईं [`Into`] सिधा लागू गर्न सक्नुहुनेछ:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// यो बुझ्नु महत्त्वपूर्ण छ कि [`Into`] ले [`From`] कार्यान्वयन प्रदान गर्दैन (जस्तो [`From`] [`Into`] लाई गर्दछ)।
/// त्यसकारण, तपाइँ जहिले पनि [`From`] कार्यान्वयन गर्न कोसिस गर्नुपर्दछ र [`Into`] मा फिर्ता जानुहोस् यदि [`From`] कार्यान्वयन हुन सकेन।
///
/// # Examples
///
/// [`String`] कार्यान्वयन [`Into`]`<`[`Vec`] `<` [`u8`]`>> >>`:
///
/// व्यक्त गर्न कि हामी जेनेरिक प्रकार्यहरू सबै आर्गुमेन्टहरू लिन चाहन्छौं जुन निर्दिष्ट प्रकार `T` मा रूपान्तरण गर्न सकिन्छ, हामी [`Into`]`को trait bound प्रयोग गर्न सक्दछौं।<T>`।
///
/// उदाहरण को लागी: प्रकार्य `is_hello` ले सबै आर्गुमेन्ट लिन्छ जुन [`Vec`]`<`[`u8`] `>` मा रूपान्तरण गर्न सकिन्छ।
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// रूपान्तरण गर्छ
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// इनपुट मूल्य खपत गर्दा मूल्य-देखि-मान रूपान्तरण गर्न प्रयोग गरियो।यो [`Into`] को पारस्परिक हो।
///
/// कसैले जहिले पनि `From` लाई [`Into`] भन्दा कार्यान्वयन गर्न रुचाउनु पर्छ किनभने `From` कार्यान्वयनले स्वचालित रूपमा [`Into`] को कार्यान्वयनको साथ प्रदान गर्दछ मानक लाइब्रेरीमा कम्बल कार्यान्वयनको लागि धन्यवाद।
///
///
/// [`Into`] मात्र कार्यान्वयन गर्नुहोस् जब Rust 1.41 भन्दा पहिले संस्करणलाई लक्षित गर्दै र वर्तमान crate बाहिर प्रकारमा रूपान्तरण गर्दा।
/// `From` Rust अनाथ नियमहरूको कारण पहिलेका संस्करणहरूमा रूपान्तरणका यी प्रकारहरू गर्न सक्षम थिएनन्।
/// अधिक जानकारीको लागि [`Into`] हेर्नुहोस्।
///
/// [`Into`] प्रयोग गरेर [`Into`] लाई प्राथमिकता दिनुहोस् जब जेनेरिक समारोहमा trait bounds निर्दिष्ट गर्नुहुन्छ।
/// यस तरिकाले [`Into`] प्रत्यक्ष रूपमा लागू गर्ने प्रकारहरू आर्गुमेन्टको रूपमा पनि प्रयोग गर्न सकिन्छ।
///
/// `From` पनि धेरै उपयोगी छ जब त्रुटि ह्यान्डलिंग प्रदर्शन गर्दा।असफल गर्न सक्षम भएको प्रकार्य निर्माण गर्दा, फिर्ती प्रकार सामान्यतया `Result<T, E>` फारमको हुन्छ।
/// `From` trait ले कार्यलाई एकल त्रुटि प्रकार फिर्ता गर्न अनुमति दिदै त्रुटि ह्यान्डलिंगलाई सरल बनाउँदछ जुन बहु त्रुटि प्रकारहरू समेट्छ।अधिक जानकारीको लागि "Examples" सेक्सन र [the book][book] हेर्नुहोस्।
///
/// **Note: यो trait असफल हुनु हुँदैन **।यदि रूपान्तरण असफल हुन सक्छ, [`TryFrom`] प्रयोग गर्नुहोस्।
///
/// # सामान्य कार्यान्वयन
///
/// - `From<T> for U` संकेत गर्दछ [`Into`]`<U>T` को लागि</u>
/// - `From` रिफ्लेक्सिभ हो, जसको मतलब हो कि `From<T> for T` कार्यान्वयन गरिएको छ
///
/// # Examples
///
/// [`String`] `From<&str>` लागू गर्दछ:
///
/// `&str` बाट स्ट्रिंगमा स्पष्ट रूपान्तरण निम्नानुसार गरिन्छ:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// त्रुटि ह्यान्डलिंग प्रदर्शन गर्दा यो तपाइँको आफ्नै त्रुटि प्रकारको लागि `From` कार्यान्वयन गर्न प्राय उपयोगी हुन्छ।
/// अन्तर्निहित त्रुटि प्रकारहरू हाम्रो आफ्नै अनुकूलन त्रुटि प्रकारमा रूपान्तरण गरेर जुन अन्तर्निहित त्रुटि प्रकार encapsates, हामी एकल त्रुटि प्रकार अन्तर्निहित कारण जानकारी खोले बिना फर्काउन सक्छौं।
/// '?' अपरेटरले स्वचालित रूपमा अन्तर्निहित त्रुटि प्रकारलाई हाम्रो अनुकूलन त्रुटि प्रकारमा रूपान्तरण गर्दछ `Into<CliError>::into` कल गरेर जुन `From` कार्यान्वयन गर्दा स्वचालित रूपमा प्रदान गरिन्छ।
/// कम्पाइलरले त्यसपछि infers कुन `Into` को कार्यान्वयन प्रयोग गरिनु पर्छ।
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// रूपान्तरण गर्छ
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// एक प्रयास रूपान्तरण जुन `self` खान्छ, जुन महँगो वा नसकिने हुन सक्छ।
///
/// पुस्तकालय लेखकहरूले सामान्यतया यो trait प्रत्यक्ष रूपमा लागू गर्नु हुँदैन, तर [`TryFrom`] trait कार्यान्वयन गर्न रुचाउनु पर्छ, जसले अधिक लचकता प्रदान गर्दछ र सित्तैको लागि बराबर `TryInto` कार्यान्वयन प्रदान गर्दछ, मानक लाइब्रेरीमा कम्बल कार्यान्वयनको लागि धन्यवाद।
/// यसमा थप जानकारीको लागि, [`Into`] का लागि कागजात हेर्नुहोस्।
///
/// # `TryInto` कार्यान्वयन गर्दै
///
/// यो [`Into`] कार्यान्वयनको रूपमा उही प्रतिबन्ध र तर्क ग्रस्त छ, विवरणको लागि यहाँ हेर्नुहोस्।
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// प्रकार एक रूपान्तरण त्रुटि को घटना मा फिर्ता।
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// रूपान्तरण गर्छ
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// सरल र सुरक्षित प्रकार रूपान्तरणहरू जुन केहि परिस्थितिहरूमा नियन्त्रणित तरिकामा असफल हुन सक्छ।यो [`TryInto`] को पारस्परिक हो।
///
/// यो उपयोगी छ जब तपाईं एक प्रकारको रूपान्तरण गर्दै हुनुहुन्छ जुन संक्षिप्त रूपमा सफल हुन सक्छ तर विशेष ह्यान्डलिंगको आवश्यक हुन सक्छ।
/// उदाहरण को लागी, [`From`] trait को प्रयोग गरी [`i64`] लाई [`i32`] मा रूपान्तरण गर्ने कुनै उपाय छैन, किनकि [`i64`] ले [`i32`] ले प्रतिनिधित्व गर्न नसक्ने मान समावेश गर्न सक्छ र त्यसैले रूपान्तरणले डेटा हराउनेछ।
///
/// यो [`i64`] लाई [`i32`] लाई काटेर (अनिवार्य रूपमा [`i64`] को मूल्य मोड्युलो [`i32::MAX`] दिने) वा [`i32::MAX`] फिर्ता द्वारा वा अन्य कुनै विधिद्वारा ह्यान्डल गर्न सकिन्छ।
/// [`From`] trait उत्तम रूपान्तरणको लागि लक्षित हो, त्यसैले `TryFrom` trait प्रोग्रामरलाई सूचित गर्दछ जब एक प्रकारको रूपान्तरण खराब हुन सक्दछ र तिनीहरूलाई यसलाई कसरी ह्याण्डल गर्ने निर्णय गर्न दिन्छ।
///
/// # सामान्य कार्यान्वयन
///
/// - `TryFrom<T> for U` implies [`TryInto`] <U>T`लागि`</u>
/// - [`try_from`] रिफ्लेक्सिभ हो, जसको अर्थ `TryFrom<T> for T` कार्यान्वयन गरिएको छ र असफल हुन सक्दैन-`T` प्रकारको मानमा `T::try_from()` कल गर्नको लागि सम्बन्धित `Error` प्रकार [`Infallible`] हो।
/// जब [`!`] प्रकार [`Infallible`] स्थिर हो र [`!`] बराबर हुनेछ।
///
/// `TryFrom<T>` निम्नको रूपमा कार्यान्वयन गर्न सकिन्छ:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// वर्णन गरिए अनुसार, [`i32`] कार्यान्वयनहरू `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // चुपचाप `big_number` छाटिन्छ, पत्ता लगाई तथ्यको पछाडि काँटछाँट गर्न आवश्यक छ।
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // `big_number` `i32` मा फिट गर्न एकदम ठूलो छ किनभने एक त्रुटि फर्काउँछ।
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // `Ok(3)` फर्काउँछ।
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// प्रकार एक रूपान्तरण त्रुटि को घटना मा फिर्ता।
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// रूपान्तरण गर्छ
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// सामान्य IMPLS
////////////////////////////////////////////////////////////////////////////////

// लिफ्टमा
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// &mut माथि लिफ्टको रूपमा
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): माथिको प्रतीक बदल्नुहोस्&/र म्यूटको लागि निम्न अधिक सामान्य एकको साथ:
// // डेरेफ भन्दा माथि उठेको रूपमा
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? आकार> <U>D {</u> fn as_ref(&self) को <U>लागि AsRef-> &U ef</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut &mut भन्दा माथि उठ्छ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): &mut का लागि माथिको ईम्प्लीलाई तलका सामान्य सामान्यसँग बदल्नुहोस्:
// // AsMut ले DerefMut माथि लिफ्ट गर्दछ
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? आकार> <U>D {</u> fn as_mut(&mut self) को <U>लागी AsMut-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// देखि भित्र सम्मिलित
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// बाट (र यसैले भित्र) रिफ्लेक्सिभ छ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **स्थिरता नोट:** यो impl अझै अवस्थित छैन, तर हामी यसलाई future मा जोड्न "reserving space" छौं।
/// विवरणका लागि [rust-lang/rust#64715][#64715] हेर्नुहोस्।
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): यसको सट्टामा एक सिद्धान्त तय गर्नुहोस्।
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// ट्रिफ्रोमले ट्राइन्टो बुझाउँदछ
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// इन्फ्लेबल रूपान्तरण शब्दहित रूपमा एक निर्जन त्रुटि प्रकारको फेलिएबल रूपान्तरणको बराबर हो।
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS संकुचित गर्नुहोस्
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// कुनै ईरर त्रुटि प्रकार
////////////////////////////////////////////////////////////////////////////////

/// त्रुटिको लागि त्रुटि प्रकार जुन कहिले पनि हुँदैन।
///
/// यो एनमको कुनै भेरियन्ट नभएकोले यस प्रकारको मान वास्तवमा कहिले पनि अवस्थित हुन सक्दैन।
/// यो जेनेरिक एपीआईको लागि उपयोगी हुन सक्दछ जसले [`Result`] प्रयोग गर्दछ र त्रुटि प्रकार प्यारामिटरिज गर्दछ, यो संकेत गर्न कि परिणाम सँधै [`Ok`] हुन्छ।
///
/// उदाहरणको लागि, [`TryFrom`] trait (रूपान्तरण जुन एक [`Result`] फिर्ता गर्दछ) का सबै प्रकारका लागि कम्बल कार्यान्वयन छ जहाँ एक रिभर्स [`Into`] कार्यान्वयन अवस्थित छ।
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future अनुकूलता
///
/// यो एनमको [the `!`“never”type][never] सँग समान भूमिका छ, जुन Rust को यस संस्करणमा अस्थिर छ।
/// जब `!` स्थिर हुन्छ, हामी यसको लागि `Infallible` प्रकार उपनाम बनाउने योजना गर्छौं:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... र अन्ततः `Infallible` लाई निषेध।
///
/// जहाँसम्म एक केस छ जहाँ `!` सिन्ट्याक्स `!` पूर्ण विकसित प्रकारको रूपमा स्थिर हुनु अघि प्रयोग गर्न सकिन्छ: प्रकार्यको फिर्ताको प्रकारको स्थितिमा।
/// विशेष रूपमा, यो दुई फरक प्रकार्य सूचक प्रकारहरूका लागि कार्यान्वयन सम्भव छ:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// `Infallible` एक एनम हुनुको साथ, यो कोड मान्य छ।
/// जे होस् `Infallible` never type को लागी एक उपनाम हुन्छ, दुई `impl`s ओभरल्याप हुन थाल्छ र त्यसैले भाषाको trait सहबद्ध नियमहरू द्वारा अस्वीकृत हुनेछ।
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}