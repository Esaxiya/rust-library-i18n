//! साझेदारी योग्य म्यूटेबल कन्टेनरहरू।
//!
//! Rust मेमोरी सुरक्षा यस नियममा आधारित छ: कुनै वस्तु `T` दिईएको खण्डमा, निम्न मध्ये एक हुन सम्भव छ:
//!
//! - धेरै अपरिवर्तनीय सन्दर्भ (`&T`) वस्तुको लागि (**aliasing** पनि भनिन्छ)।
//! - वस्तुलाई एक परिवर्तनीय सन्दर्भ (`&mut T`) भएको (**म्यूटेशन** पनि भनिन्छ)।
//!
//! यो Rust कम्पाइलर द्वारा लागू गरिएको छ।यद्यपि त्यहाँ त्यस्ता परिस्थितिहरू छन् जहाँ यो नियम पर्याप्त लचिलो छैन।कहिलेकाँही वस्तुमा बहु सन्दर्भ हुनु आवश्यक पर्दछ र अझै यसलाई म्युट गर्नुहोस्।
//!
//! सेयर गर्न योग्य म्यूटेबल कन्टेनरहरू एक aliasing को उपस्थिति मा पनि, एक नियन्त्रित ढ mut्गले परिवर्तनको अनुमति गर्न अवस्थित छ।दुबै [`Cell<T>`] र [`RefCell<T>`] एकल थ्रेडेड तरीकाले यसलाई अनुमति दिन्छ।
//! यद्यपि, न त `Cell<T>` न `RefCell<T>` थ्रेड सुरक्षित छन् (उनीहरूले [`Sync`] कार्यान्वयन गर्दैन)।
//! यदि तपाइँ बहु थ्रेडहरू बीच एलाइजिंग र म्युटेसन गर्न आवश्यक छ भने [`Mutex<T>`], [`RwLock<T>`] वा [`atomic`] प्रकारहरू प्रयोग गर्न सम्भव छ।
//!
//! `Cell<T>` र `RefCell<T>` प्रकारहरूको मान साझा गरिएको सन्दर्भहरू मार्फत परिवर्तन गर्न सकिन्छ
//! सामान्य `&T` प्रकार), जबकि धेरै जसो Rust प्रकारहरू मात्र अद्वितीय (`&mut T`) सन्दर्भहरूको माध्यमबाट परिवर्तन गर्न सकिन्छ।
//! हामी भन्छौं कि `Cell<T>` र `RefCell<T>` 'आन्तरिक उत्परिवर्तन' प्रदान गर्दछ, विशिष्ट Rust प्रकारको विपरितमा जुन 'विरासतमा आएको उत्परिवर्तन' प्रदर्शन गर्दछ।
//!
//! सेल प्रकारहरू दुई स्वादहरूमा आउँछन्: `Cell<T>` र `RefCell<T>`।`Cell<T>` `Cell<T>` मा र बाहिर मानहरू सार्दै ईन्टीरियर उत्परिवर्तन लागू गर्दछ।
//! मानको सट्टा सन्दर्भ प्रयोग गर्न, एकले `RefCell<T>` प्रकार प्रयोग गर्नुपर्दछ, म्यूट गर्नु अघि लेख्ने लक प्राप्त गर्दै।`Cell<T>` ले हालको आन्तरिक मान पुन: प्राप्त गर्न र परिवर्तन गर्न विधिहरू प्रदान गर्दछ:
//!
//!  - [`Copy`] लागू गर्ने प्रकारहरूको लागि, [`get`](Cell::get) विधिले हालको आन्तरिक मान प्राप्त गर्दछ।
//!  - [`Default`] कार्यान्वयन गर्ने प्रकारहरूको लागि, [`take`](Cell::take) विधिले वर्तमान आन्तरिक मानलाई [`Default::default()`] प्रतिस्थापन गर्दछ र प्रतिस्थापित मान फिर्ता गर्दछ।
//!  - सबै प्रकारका लागि, [`replace`](Cell::replace) विधिले हालको आन्तरिक मान प्रतिस्थापन गर्दछ र प्रतिस्थापित मान फिर्ता गर्दछ र [`into_inner`](Cell::into_inner) विधिले `Cell<T>` खपत गर्दछ र आन्तरिक मान फिर्ता गर्दछ।
//!  थप रूपमा, [`set`](Cell::set) विधिले आन्तरिक मान प्रतिस्थापन गर्दछ, प्रतिस्थापित मान छोड्दै।
//!
//! `RefCell<T>` 'गतिशील orrowण' लागू गर्न Rust को लाइफटाइम प्रयोग गर्दछ, एक यस्तो प्रक्रिया जसमा कसैले अस्थायी, अनन्य, पारस्परिक पहुँच भित्री मानमा पहुँच गर्न सक्दछ।
//! `RefCell का लागि उधारो<T>0 s 'रनटाइममा' ट्र्याक गरियो, Rust को जन्मजात सन्दर्भ प्रकारहरू भन्दा पूर्ण जुन स्थिरै ट्र्याक गरिएको हुन्छ, कम्पाईल समयमा।
//! किनभने `RefCell<T>` उधारो गतिशील छ यो पहिले नै परस्पर रूपले ablyण लिएको छ कि एक valueण लिन प्रयास गर्न सम्भव छ;जब यो हुन्छ यसको परिणाम panic थ्रेडमा हुन्छ।
//!
//! # जब आन्तरिक परिवर्तनशीलता छनौट गर्ने
//!
//! अधिक सामान्य विरासतमा आएको उत्परिवर्तन, जहाँ एकमा मानलाई म्युट गर्न अनौंठो पहुँच हुनुपर्दछ, मुख्य भाषा तत्वहरू मध्ये एक हो जसले Rust लाई पोइन्टर एलाइजि aboutको बारेमा कडा तर्क गर्न सक्षम गर्दछ, स्थिर रूपमा क्र्यास बगहरूलाई रोक्दछ।
//! त्यस कारणले, विरासतमा मिलाइएको परिवर्तनलाई प्राथमिकता दिइन्छ, र आन्तरिक उत्परिवर्तन अन्तिम रिसोर्टको कुरा हो।
//! सेल प्रकारले उत्परिवर्तन सक्षम गर्दछ जहाँ यो अन्यथा अस्वीकृत हुनेछ, त्यहाँ त्यस्ता अवसरहरू छन् जब आन्तरिक उत्परिवर्तन उपयुक्त हुन सक्छ, वा यहाँसम्म कि * प्रयोग हुनुपर्दछ, उदाहरणका लागि।
//!
//! * अपरिवर्तनीय केहिको म्यूटेबिलिटी 'inside' प्रस्तुत गर्दै
//! * तार्किक-अपरिवर्तनीय विधिहरूको कार्यान्वयन विवरण।
//! * [`Clone`] को कार्यान्वयन म्यूट गर्दै।
//!
//! ## अपरिवर्तनीय केहिको म्यूटेबिलिटी 'inside' प्रस्तुत गर्दै
//!
//! धेरै साझा स्मार्ट पोइन्टर प्रकारहरू, [`Rc<T>`] र [`Arc<T>`] सहित, कन्टेनर प्रदान गर्दछ जुन क्लोन गर्न सकिन्छ र बहु पार्टीहरू बीच साझेदारी गर्न सकिन्छ।
//! किनभने समावेश मानहरू गुणा-एलाइज्ड हुनसक्दछ, तिनीहरू केवल `&` सँग सापट लिन सकिन्छ, `&mut` होइन।
//! सेलहरू बिना यो स्मार्ट सूचकहरूको भित्र डेटा बदल्न असम्भव हुनेछ।
//!
//! यो धेरै सामान्य छ तब एक्सएक्सएक्सलाई साझा पोइन्टर प्रकार भित्र राख्न म्युटेबिलिटीलाई पुन: प्रस्तुत गर्नका लागि:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // गतिशील bणको दायरा सीमित गर्न नयाँ ब्लक सिर्जना गर्नुहोस्
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // नोट गर्नुहोस् कि यदि हामीले क्यासको अघिल्लो scopeण दायराबाट बाहिर नलकाएको भए पछि उत्तर orrowणले गतिशील थ्रेड panic निम्त्याउनेछ।
//!     //
//!     // यो `RefCell` प्रयोगको प्रमुख जोखिम हो।
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! नोट गर्नुहोस् कि यस उदाहरणले `Rc<T>` प्रयोग गर्दछ र `Arc<T>` लाई नहीं।`RefCell<T>single s एकल-थ्रेडेड परिदृश्यहरूको लागि हो।[`RwLock<T>`] वा [`Mutex<T>`] प्रयोग गर्ने विचार गर्नुहोस् यदि तपाईंलाई बहु-थ्रेडेड स्थितिमा साझा रूपान्तरणको आवश्यकता छ।
//!
//! ## तार्किक-अपरिवर्तनीय विधिहरूको कार्यान्वयन विवरण
//!
//! कहिलेकाँही यो API मा खुलासा नगरी राम्रो हुन सक्छ कि त्यहाँ उत्परिवर्तन "under the hood" हुन्छ।
//! यो हुन सक्छ किनकि तार्किक रूपमा अपरेशन अपरिवर्तनीय छ, तर उदाहरणका लागि क्याचले कार्यान्वयनलाई म्युटेसन गर्न बाध्य पार्दछ;वा किनभने तपाईंले trait विधि लागू गर्न म्युटेसन रोजगार गर्नै पर्छ जुन `&self` लिनको लागि मूल रूपमा परिभाषित गरिएको थियो।
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // महँगो गणना यहाँ छ
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## `Clone` को कार्यान्वयन म्यूट गर्दै
//!
//! यो केवल एक विशेष, तर सामान्य हो, अघिल्लोको मामला: अपरिहार्य जस्तो देखिन्छ कि अपरेशनहरूको लागि म्युटेबिलिटी लुकाउन।
//! [`clone`](Clone::clone) विधि स्रोत मान परिवर्तन गर्दैन, र `&self` लिन `&mut self` घोषणा गरीएको छ।
//! तसर्थ, कुनै पनि उत्परिवर्तन जुन `clone` विधिमा हुन्छ सेल प्रकार प्रयोग गर्नुपर्दछ।
//! उदाहरण को लागी, [`Rc<T>`] एक `Cell<T>` भित्र यसको संदर्भ गणना रखरखाव गर्दछ।
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// एक म्यूटेबल मेमोरी स्थान।
///
/// # Examples
///
/// यस उदाहरणमा तपाईले देख्न सक्नुहुन्छ कि `Cell<T>` एक अपरिवर्तनीय स्ट्रक्चर भित्र म्युटेसन सक्षम गर्दछ।
/// अर्को शब्दहरूमा, यसले "interior mutability" सक्षम गर्दछ।
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // त्रुटि: `my_struct` अपरिवर्तनीय छ
/// // my_struct.regular_field =new_value;
///
/// // कामहरू: यद्यपि `my_struct` अपरिवर्तनीय छ, `special_field` एक `Cell` हो,
/// // जुन सँधै उत्परिवर्तन गर्न सकिन्छ
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// अधिकको लागि [module-level documentation](self) हेर्नुहोस्।
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// T को लागी `Default` मानको साथ `Cell<T>` सिर्जना गर्दछ।
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// दिइएको मान सहित नयाँ `Cell` सिर्जना गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// निहित मान सेट गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// दुई सेलहरूको मान बदल्छ।
    /// `std::mem::swap` का साथ भिन्नता यो प्रकार्यलाई `&mut` सन्दर्भ आवश्यक पर्दैन।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // सुरक्षा: यो जोखिमपूर्ण हुन सक्छ यदि छुट्टै थ्रेडबाट बोलाइएको छ, तर `Cell`
        // `!Sync` हो त्यसैले यो हुदैन।
        // यसले कुनै पनि पोइन्टर्सलाई अमान्य बनाउँदैन किनकि `Cell` ले निश्चित गर्दछ कि केहि पनि यी `सेल`हरू मध्ये कुनैमा पनि पोइन्ट हुनेछ।
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// `val` का साथ निहित मूल्य बदल्छ, र पुरानो निहित मान फर्काउँछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // सुरक्षा: यसले डेटा दौड निम्त्याउन सक्छ यदि छुट्टै थ्रेडबाट बोलाइयो भने,
        // तर `Cell` `!Sync` हो त्यसैले यस्तो हुँदैन।
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// मूल्य उतारिन्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// निहित मूल्यको प्रतिलिपि फर्काउँछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // सुरक्षा: यसले डेटा दौड निम्त्याउन सक्छ यदि छुट्टै थ्रेडबाट बोलाइयो भने,
        // तर `Cell` `!Sync` हो त्यसैले यस्तो हुँदैन।
        unsafe { *self.value.get() }
    }

    /// प्रकार्य प्रयोग गरी निहित मूल्य अपडेट गर्दछ र नयाँ मान फिर्ता गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// यस सेलमा अंतर्निहित डेटामा एक कच्चा सूचक फिर्ता गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// अन्तर्निहित डेटामा म्यूटेबल सन्दर्भ फर्काउँछ।
    ///
    /// यस कलले `Cell` लाई परस्पर रूपान्तरण गर्दछ (कम्पाइल समयमा) जसले ग्यारेन्टी गर्दछ कि हामीसँग केवल सन्दर्भ छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `&mut T` बाट `&Cell<T>` फर्काउँछ
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // सुरक्षा: `&mut` अनौंठो पहुँच सुनिश्चित गर्दछ।
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// सेलको मान लिन्छ, यसको ठाउँमा `Default::default()` छोड्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// `&Cell<[T]>` बाट `&[Cell<T>]` फर्काउँछ
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // सुरक्षा: `Cell<T>` सँग `T` जस्तै मेमोरी लेआउट छ।
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// गतिशील रूपमा जाँच गरिएको orrowण नियमहरूको साथ एक म्यूटेबल मेमोरी स्थान
///
/// अधिकको लागि [module-level documentation](self) हेर्नुहोस्।
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// [`RefCell::try_borrow`] द्वारा एक त्रुटि फर्काइयो।
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// [`RefCell::try_borrow_mut`] द्वारा एक त्रुटि फर्काइयो।
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// सकारात्मक मानहरूले सक्रिय `Ref` को संख्या प्रतिनिधित्व गर्दछ।नकरात्मक मानहरूले सक्रिय `RefMut` को संख्या प्रतिनिधित्व गर्दछ।
// बहु `RefMut`s केवल एक समय सक्रिय हुन सक्दछ यदि तिनीहरूले `RefCell` का अलग, नोनओवरप्लापि components घटक (उदाहरणका लागि स्लाइसको बिभिन्न दायरा) लाई सन्दर्भ गर्दछ।
//
// `Ref` र `RefMut` दुबै आकारको दुई शब्दहरू छन्, र त्यसैले सम्भवतः कहिले पनि पर्याप्त हुनेछैन `रेफ्रेस वा` रेफमेलस अस्तित्वमा `usize` दायराको आधा ओभरफ्लो गर्न।
// यसैले, एक `BorrowFlag` सायद कहिले ओभरफ्लो वा भूमिगत हुँदैन।
// जे होस्, यो ग्यारेन्टी होईन, किनकि प्याथोलॉजिकल प्रोग्रामले बारम्बार सिर्जना गर्न सक्दछ र त्यसपछि mem::forget `Ref`s वा`RefMut`s।
// यसैले, सबै कोडले स्पष्ट रूपमा ओभरफ्लो र अन्डरफ्लोको लागि जाँच गर्नै पर्छ असुरक्षित हुनबाट बच्न, वा कम्तिमा ठीकसँग व्यवहार गर्नुहोस् जुन घटनामा ओभरफ्लो वा भूमिगत हुन्छ (उदाहरणका लागि BorrowRef::new हेर्नुहोस्)।
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// `value` युक्त नयाँ `RefCell` सिर्जना गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// `RefCell` खपत, आवरण मान फिर्ता।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // किनकि यो प्रकार्यले `self` (`RefCell`) लाई मानले लिन्छ, कम्पाइलरले स्ट्याटिलीफिकरीकृत गर्छ कि यो हाल orrowण लिएको छैन।
        //
        self.value.into_inner()
    }

    /// पुरानो मान फिर्ता, नयाँ एकको साथ लपेटिएको मान प्रतिस्थापन गर्दछ, कुनै एक लाई डिनिटाइज नगरिकन।
    ///
    ///
    /// यो प्रकार्य [`std::mem::replace`](../mem/fn.replace.html) अनुरूप छ।
    ///
    /// # Panics
    ///
    /// Panics यदि मान हाल सापट लिएको छ भने।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// `f` बाट गणना गरिएको नयाँको साथ आवरण मान प्रतिस्थापन गर्दछ, पुरानो मान फिर्ता गर्दै, कुनै एक लाई डिनिटाइज नगरिकन।
    ///
    ///
    /// # Panics
    ///
    /// Panics यदि मान हाल सापट लिएको छ भने।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// X001 को आवरण मानको साथ `self` को आवरण मान बदल्छ, कुनै एक लाई डिनिटाइलाइज नगरी।
    ///
    ///
    /// यो प्रकार्य [`std::mem::swap`](../mem/fn.swap.html) अनुरूप छ।
    ///
    /// # Panics
    ///
    /// Panics यदि `RefCell` मा मान हाल सापट लिएको छ भने।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// तुरुन्तै र्‍याप गरिएको मान उधारो लिन्छ।
    ///
    /// फिर्ता `Ref` स्कोपबाट बाहिर निस्के सम्म پور लिन्छ।
    /// बहु अपरिवर्तनीय उधार एकै समयमा बाहिर लिन सकिन्छ।
    ///
    /// # Panics
    ///
    /// Panics यदि मान हाल पारस्परिक उधारो छ भने।
    /// नन-पिकनिक भेरियन्टका लागि [`try_borrow`](#method.try_borrow) प्रयोग गर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// panic को एक उदाहरण:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// तत्काल लपेटिएको मान उधारो लिन्छ, एक त्रुटि फिर्ता अगर मान हालै परस्पर उधारो लिएको छ।
    ///
    ///
    /// फिर्ता `Ref` स्कोपबाट बाहिर निस्के सम्म پور लिन्छ।
    /// बहु अपरिवर्तनीय उधार एकै समयमा बाहिर लिन सकिन्छ।
    ///
    /// यो X-[`borrow`](#method.borrow) को non-Panicking प्रकार हो।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // सुरक्षा: `BorrowRef` ले केवल अपरिवर्तनीय पहुँच छ भनेर सुनिश्चित गर्दछ
            // उधारो लिँदा मानमा।
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// म्युप्टेलीले लपेटिएको मान उधारो लिन्छ।
    ///
    /// Orrowण फिर्ता `RefMut` वा सबै `RefMut`s यसबाट निकास दायरा बाहिर निस्के सम्म रहन्छ।
    ///
    /// यो activeण सक्रिय छँदा मान bण लिन सकिदैन।
    ///
    /// # Panics
    ///
    /// Panics यदि मान हाल सापट लिएको छ भने।
    /// नन-पिकनिक भेरियन्टका लागि [`try_borrow_mut`](#method.try_borrow_mut) प्रयोग गर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// panic को एक उदाहरण:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// म्युप्टले लपेटिएको मान उधारो लिन्छ, एक त्रुटि फिर्ता अगर मान वर्तमान मा उधारो छ।
    ///
    ///
    /// Orrowण फिर्ता `RefMut` वा सबै `RefMut`s यसबाट निकास दायरा बाहिर निस्के सम्म रहन्छ।
    /// यो activeण सक्रिय छँदा मान bण लिन सकिदैन।
    ///
    /// यो X-[`borrow_mut`](#method.borrow_mut) को non-Panicking प्रकार हो।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // सुरक्षा: `BorrowRef` अनौंठो पहुँचको ग्यारेन्टी गर्दछ।
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// यस सेलमा अंतर्निहित डेटामा एक कच्चा सूचक फिर्ता गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// अन्तर्निहित डेटामा म्यूटेबल सन्दर्भ फर्काउँछ।
    ///
    /// यस कलले `RefCell` लाई परस्पर (कम्पाइल समयमा) उधारो लिन्छ त्यसैले गतिशील जाँचहरूको लागि कुनै आवश्यकता पर्दैन।
    ///
    /// यद्यपि सावधान रहनुहोस्: यो विधिले `self` लाई परिवर्तनीय बनाउँदछ, जुन `RefCell` प्रयोग गर्ने बेलामा सामान्यतया हुँदैन।
    ///
    /// यसको सट्टा [`borrow_mut`] विधिमा हेर्नुहोस् यदि `self` परिवर्तनीय छैन।
    ///
    /// साथै, कृपया सावधान रहनुहोस् कि यो विधि केवल विशेष परिस्थितिहरूको लागि मात्र हो र प्राय: तपाईं के चाहानुहुन्छ भनेर होईन।
    /// शंकाको मामलामा, यसको सट्टामा [`borrow_mut`] प्रयोग गर्नुहोस्।
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `RefCell` को उधारो स्थितिमा लीक गार्डहरूको प्रभाव अन्डु गर्नुहोस्।
    ///
    /// यो कल [`get_mut`] जस्तै छ तर अधिक विशिष्ट।
    /// कुनै orrowण छैन भनेर निश्चित गर्न यसले `RefCell` रूपान्तरण उधारो लिन्छ र त्यसपछि राज्य ट्र्याकिंग सेयर गरिएको उधारो रिसेट गर्दछ।
    /// यो प्रासंगिक छ यदि केहि `Ref` वा `RefMut` sण लीक भएको छ।
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// तत्काल लपेटिएको मान उधारो लिन्छ, एक त्रुटि फिर्ता अगर मान हालै परस्पर उधारो लिएको छ।
    ///
    /// # Safety
    ///
    /// `RefCell::borrow` विपरीत, यो विधि असुरक्षित छ किनकि यसले `Ref` फिर्ता गर्दैन, यसैले flagण झण्डालाई छोडियो।
    /// म्यूच्युअल रूपले `RefCell` उधारो लिँदा यो विधिबाट फर्काइएको सन्दर्भ जीवित छ भने अपरिभाषित व्यवहार हो।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // सुरक्षा: हामी जाँच गर्छौं कि अहिले कसैले पनि सक्रिय रूपमा लेखिरहेको छैन, तर यो छ
            // कलरको जिम्मेवारी सुनिश्चित गर्न को लागी सुनिश्चित गरियो कि फिर्ता गरिएको सन्दर्भ लामो समय सम्म प्रयोगमा छैन।
            // साथै, `self.value.get()` `self` द्वारा स्वामित्वको मान दर्साउँछ र त्यसैले `self` को जीवनकालको लागि मान्य हुन ग्यारेन्टी गरिएको छ।
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// र्‍याप गरिएको मान लिन्छ, यसको ठाउँमा `Default::default()` छोड्दै।
    ///
    /// # Panics
    ///
    /// Panics यदि मान हाल सापट लिएको छ भने।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics यदि मान हाल पारस्परिक उधारो छ भने।
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// T को लागी `Default` मानको साथ `RefCell<T>` सिर्जना गर्दछ।
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics यदि `RefCell` मा मान हाल सापट लिएको छ भने।
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics यदि `RefCell` मा मान हाल सापट लिएको छ भने।
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics यदि `RefCell` मा मान हाल सापट लिएको छ भने।
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics यदि `RefCell` मा मान हाल सापट लिएको छ भने।
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics यदि `RefCell` मा मान हाल सापट लिएको छ भने।
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics यदि `RefCell` मा मान हाल सापट लिएको छ भने।
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics यदि `RefCell` मा मान हाल सापट लिएको छ भने।
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // बढ्दो orrowणमा नपठाइएको मानमा परिणाम हुन सक्छ (<=0) यी केसहरूमा:
            // 1. यो <० थियो, अर्थात् त्यहाँ writingण लिनेहरू छन्, त्यसैले हामी Rust सन्दर्भ aliasing नियमहरूको कारण पढ्न orrowण अनुमति दिन सक्दैनौं।
            // 2.
            // यो isize::MAX (पढाई उधारो को अधिकतम राशि) थियो र यो isize::MIN (लेख्ने उधारो को अधिकतम राशि) मा ओतप्रोत भयो त्यसैले हामी एक अतिरिक्त पठन orrowण अनुमति दिन सक्दैन किनभने isize धेरै पढ्न उधारो प्रतिनिधित्व गर्न सक्दैन (यो मात्र हुन सक्छ यदि तपाइँ 0 रेफ्रेसको सानो स्थिर रकम भन्दा अधिक mem::forget गर्नुहुन्छ, जुन राम्रो अभ्यास होईन)
            //
            //
            //
            //
            None
        } else {
            // बढ्दो orrowणले यी केसहरूमा पठन मूल्य (> ०) मा परिणाम दिन सक्दछ:
            // 1. यो=० थियो, अर्थात् यो orrowण लिएको थिएन, र हामी पहिलो पढ्ने उधार लिइरहेका छौं
            // 2. यो ० ० र <isize::MAX, थियो
            // त्यहाँ पढ्ने उधारहरू थिए, र इसाइज पर्याप्त ठूलो छ एक अर्को पढ्न उधारो प्रतिनिधित्व गर्न
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // यो रेफ अवस्थित छ, हामीलाई थाहा छ उधारो झण्डा एक पठन उधार हो।
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Writingण काउन्टरलाई एक लिखित intoणमा ओभरफ्लो गर्नबाट रोक्नुहोस्।
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// `RefCell` बक्समा मानको लागि उधारो सन्दर्भ।
/// `RefCell<T>` बाट स्थिर उधारो मानको लागि आवरण प्रकार।
///
/// अधिकको लागि [module-level documentation](self) हेर्नुहोस्।
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// `Ref` प्रतिलिपि गर्दछ।
    ///
    /// `RefCell` पहिले नै स्थिर उधारो लिइएको छ, त्यसैले यो असफल हुन सक्दैन।
    ///
    /// यो एक सम्बन्धित समारोह छ कि `Ref::clone(...)` को रूपमा प्रयोग गर्न आवश्यक छ।
    /// एक `Clone` कार्यान्वयन वा एक विधि एक `RefCell` को सामग्री क्लोन गर्न `r.borrow().clone()` को व्यापक प्रयोगमा हस्तक्षेप गर्दछ।
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// उधारो डाटा को एक घटक को लागी एक नया `Ref` बनाउँछ।
    ///
    /// `RefCell` पहिले नै स्थिर उधारो लिइएको छ, त्यसैले यो असफल हुन सक्दैन।
    ///
    /// यो एक सम्बन्धित समारोह छ कि `Ref::map(...)` को रूपमा प्रयोग गर्न आवश्यक छ।
    /// एक विधिले `Deref` मार्फत प्रयोग गरिएको `RefCell` को सामग्रीहरूमा उही नामको विधिहरूमा हस्तक्षेप गर्दछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// उधारो डाटा को एक वैकल्पिक घटक को लागी एक नया `Ref` बनाउँछ।
    /// सक्कली गार्ड `Err(..)` को रूपमा फिर्ता भयो यदि क्लोजरले `None` फर्कायो।
    ///
    /// `RefCell` पहिले नै स्थिर उधारो लिइएको छ, त्यसैले यो असफल हुन सक्दैन।
    ///
    /// यो एक सम्बन्धित समारोह छ कि `Ref::filter_map(...)` को रूपमा प्रयोग गर्न आवश्यक छ।
    /// एक विधिले `Deref` मार्फत प्रयोग गरिएको `RefCell` को सामग्रीहरूमा उही नामको विधिहरूमा हस्तक्षेप गर्दछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// उधारो डाटा को विभिन्न कम्पोनेन्टहरु को लागी एक `Ref` को एकाधिक `Ref`s मा विभाजित गर्दछ।
    ///
    /// `RefCell` पहिले नै स्थिर उधारो लिइएको छ, त्यसैले यो असफल हुन सक्दैन।
    ///
    /// यो एक सम्बन्धित समारोह छ कि `Ref::map_split(...)` को रूपमा प्रयोग गर्न आवश्यक छ।
    /// एक विधिले `Deref` मार्फत प्रयोग गरिएको `RefCell` को सामग्रीहरूमा उही नामको विधिहरूमा हस्तक्षेप गर्दछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// अन्तर्निहित डाटाको सन्दर्भमा रूपान्तरण गर्नुहोस्।
    ///
    /// अन्तर्निहित `RefCell` कहिल्यै परस्पर रूपबाट bण लिन सकिन्न र सँधै अपार उधारोमा देखा पर्नेछ।
    ///
    /// सन्दर्भको स्थिर संख्या भन्दा बढि लीक गर्नु राम्रो उपाय होइन।
    /// `RefCell` पुनः स्थिर उधार लिन सकिन्छ यदि केवल एक सानो स le्ख्या लीक कूल मा नै आएको छ भने।
    ///
    /// यो एक सम्बन्धित समारोह छ कि `Ref::leak(...)` को रूपमा प्रयोग गर्न आवश्यक छ।
    /// एक विधिले `Deref` मार्फत प्रयोग गरिएको `RefCell` को सामग्रीहरूमा उही नामको विधिहरूमा हस्तक्षेप गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // यस रेफलाई बिर्सेर हामी यो सुनिश्चित गर्दछौं कि रेफसेलमा orrowण काउन्टर जीवनभर `'b` भित्र UNUSED मा फिर्ता जान सक्दैन।
        // सन्दर्भ ट्र्याकि state स्थिति रिसेट गर्नको लागि उधारो लिएको रेफसेलको लागि एक अद्वितीय सन्दर्भ आवश्यक पर्दछ।
        // कुनै अर्को परिवर्तनकारी सन्दर्भहरू मूल सेलबाट सिर्जना गर्न सकिँदैन।
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// उधारो डाटा को एक घटक को लागी एक नया `RefMut` बनाउँछ, उदाहरण को लागी, एक enum संस्करण।
    ///
    /// `RefCell` पहिले नै परस्पर उधारो लिएको छ, त्यसैले यो असफल हुन सक्दैन।
    ///
    /// यो एक सम्बन्धित समारोह छ कि `RefMut::map(...)` को रूपमा प्रयोग गर्न आवश्यक छ।
    /// एक विधिले `Deref` मार्फत प्रयोग गरिएको `RefCell` को सामग्रीहरूमा उही नामको विधिहरूमा हस्तक्षेप गर्दछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): orrowण-चेक ठीक गर्नुहोस्
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// उधारो डाटा को एक वैकल्पिक घटक को लागी एक नया `RefMut` बनाउँछ।
    /// सक्कली गार्ड `Err(..)` को रूपमा फिर्ता भयो यदि क्लोजरले `None` फर्कायो।
    ///
    /// `RefCell` पहिले नै परस्पर उधारो लिएको छ, त्यसैले यो असफल हुन सक्दैन।
    ///
    /// यो एक सम्बन्धित समारोह छ कि `RefMut::filter_map(...)` को रूपमा प्रयोग गर्न आवश्यक छ।
    /// एक विधिले `Deref` मार्फत प्रयोग गरिएको `RefCell` को सामग्रीहरूमा उही नामको विधिहरूमा हस्तक्षेप गर्दछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): orrowण-चेक ठीक गर्नुहोस्
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // सुरक्षा: समारोह अवधि को लागी एक विशेष सन्दर्भ मा होल्ड
        // `orig` को माध्यमबाट यसको कलको, र पोइन्टर केवल डि-रेफरन्डेसन हो फंक्शन कलको भित्र कहिल्यै विशेष कुरा भाग्न अनुमति दिँदैन।
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // सुरक्षा: माथिको जस्तै।
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// उधारो डाटा को विभिन्न कम्पोनेन्टहरु को लागी एक `RefMut` को एकाधिक `RefMut`s मा विभाजित गर्दछ।
    ///
    /// अंतर्निहित `RefCell` दुबै फर्किएसम्म म्यूटेस्ट उधार लिइनेछ `RefMut`s दायरा बाहिर जानुहोस्।
    ///
    /// `RefCell` पहिले नै परस्पर उधारो लिएको छ, त्यसैले यो असफल हुन सक्दैन।
    ///
    /// यो एक सम्बन्धित समारोह छ कि `RefMut::map_split(...)` को रूपमा प्रयोग गर्न आवश्यक छ।
    /// एक विधिले `Deref` मार्फत प्रयोग गरिएको `RefCell` को सामग्रीहरूमा उही नामको विधिहरूमा हस्तक्षेप गर्दछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// अन्तर्निहित डेटाको लागि म्यूटेबल सन्दर्भमा रूपान्तरण गर्नुहोस्।
    ///
    /// अन्तर्निहित `RefCell` फेरि बाट orrowण लिन सकिदैन र सधैं पहिले नै परस्पर उधारो देखा पर्नेछ, फर्काइएको सन्दर्भलाई मात्र भित्रीमा बनाउँदछ।
    ///
    ///
    /// यो एक सम्बन्धित समारोह छ कि `RefMut::leak(...)` को रूपमा प्रयोग गर्न आवश्यक छ।
    /// एक विधिले `Deref` मार्फत प्रयोग गरिएको `RefCell` को सामग्रीहरूमा उही नामको विधिहरूमा हस्तक्षेप गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // यो बोर्नर्याफमटलाई बिर्सिएर हामी यो सुनिश्चित गर्दछौं कि रेफसेलमा theण काउन्टर जीवनभर `'b` भित्र UNUSED मा फिर्ता जान सक्दैन।
        // सन्दर्भ ट्र्याकि state स्थिति रिसेट गर्नको लागि उधारो लिएको रेफसेलको लागि एक अद्वितीय सन्दर्भ आवश्यक पर्दछ।
        // कुनै थप सन्दर्भहरू त्यस जीवनकालमा मूल सेलबाट सिर्जना गर्न सकिँदैन, हालको orrowणलाई बाँकी जीवनकालको लागि मात्र सन्दर्भ बनाउँदछ।
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: BorrowRefMut::clone विपरीत, नयाँलाई आरम्भिक सिर्जना गर्न भनिन्छ
        // परिवर्तनीय सन्दर्भ, र त्यसैले हाल कुनै अवस्थित सन्दर्भ हुनु हुँदैन।
        // यसैले क्लोनले बढेको म्युटेबल रिफकाउन्टको बखत, यहाँ हामी स्पष्ट रूपमा मात्र प्रयोग नगरिएकाबाट प्रयोग नगरिएका, १।
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // क्लोनहरू एक `BorrowRefMut`।
    //
    // यो मात्र वैध हुन्छ यदि प्रत्येक `BorrowRefMut` मौलिक वस्तुको भिन्न, नोनओवरप्ल्यापि range दायरामा म्यूटेबल सन्दर्भ ट्र्याक गर्न प्रयोग गरियो।
    //
    // यो क्लोन इम्प्लीमा छैन त्यसैले कोडले यसलाई स्पष्ट रूपमा कल गर्दैन।
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // बहावबाट orrowण काउन्टर रोक्नुहोस्।
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// `RefCell<T>` बाट परस्पर उधारो मानको लागि आवरण प्रकार।
///
/// अधिकको लागि [module-level documentation](self) हेर्नुहोस्।
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Rust मा आन्तरिक उत्परिवर्तनको लागि कोर आदिम।
///
/// यदि तपाईंसँग सन्दर्भ `&T` छ भने सामान्य रूपमा Rust मा कम्पाइलर ज्ञानको आधारमा अप्टिमाइजेसन गर्दछ जुन `&T` अपरिवर्तनीय डेटामा औंल्याउँछ।त्यो डेटा म्यूट गर्नु उदाहरणका लागि कुनै उपनाम वा `&T` लाई `&mut T` मा रूपान्तरण गरेर, अपरिभाषित व्यवहार मानिन्छ।
/// `UnsafeCell<T>` अप्ट-आउट `&T` का लागि अपरिवर्तनीय ग्यारेन्टी: एक साझा संदर्भ `&UnsafeCell<T>` परिवर्तन हुन लागेको डाटामा स point्केत गर्न सक्दछ।यसलाई "interior mutability" भनिन्छ।
///
/// अन्य सबै प्रकारहरू जुन `Cell<T>` र `RefCell<T>` जस्ता आन्तरिक उत्परिवर्तनलाई अनुमति दिन्छ, आन्तरिक रूपमा तिनीहरूको डाटा र्याप गर्न `UnsafeCell` प्रयोग गर्दछ।
///
/// नोट गर्नुहोस् कि साझा सन्दर्भहरूको लागि मात्र अपवित्रता ग्यारेन्टी `UnsafeCell` द्वारा प्रभावित छ।परिवर्तनीय सन्दर्भको लागि विशिष्टता ग्यारेन्टी अप्रभावित छ।त्यहाँ कुनै * कानूनी तरीका छैन Aliasing `&mut` प्राप्त गर्न, `UnsafeCell<T>` सँग पनि होईन।
///
/// `UnsafeCell` एपीआई आफै प्राविधिक रूपमा धेरै सरल छ: [`.get()`] तपाईंलाई यसको सामग्रीमा एक कच्चा सूचक `*mut T` दिन्छ।यो कच्चा सूचक सही रूपमा प्रयोग गर्न अमूर्त डिजाइनरको रूपमा _you_ सम्म छ।
///
/// [`.get()`]: `UnsafeCell::get`
///
/// सटीक Rust aliasing नियमहरू केहि फ्लक्समा हुन्, तर मुख्य पोइन्टहरू विवादास्पद छैनन्।
///
/// - यदि तपाईं आजीवन `'a` (या त `&T` वा `&mut T` सन्दर्भ) संग सुरक्षित सन्दर्भ सिर्जना गर्नुभयो जुन सुरक्षित कोड द्वारा पहुँचयोग्य छ (उदाहरणका लागि, किनकि तपाईंले त्यसलाई फिर्ता गर्नुभयो), त्यसो भए तपाईले कुनै पनि हिसाबले डाटा पहुँच गर्नु हुदैन कि बाँकी रहेको सन्दर्भलाई विरोधाभास गर्ने। `'a` को।
/// उदाहरण को लागी, यसको मतलब यो छ कि यदि तपाईले `*mut T` लाई `UnsafeCell<T>` बाट `&T` X मा राख्नु भयो भने `T` मा भएको डेटा अपर्याप्त रहनु पर्छ (`T` भित्र कुनै `UnsafeCell` डेटा भेटिएन, पाठ्यक्रम) जब संदर्भको जीवनकाल समाप्त हुन्छ।
/// त्यस्तै, यदि तपाइँ `&mut T` सन्दर्भ सिर्जना गर्नुहुन्छ जुन सुरक्षित कोडमा जारी गरिएको छ भने, तपाइँले `UnsafeCell` भित्र डाटा पहुँच गर्नुपर्दैन जबसम्म त्यो सन्दर्भ समाप्त हुँदैन।
///
/// - सबै समयमा, तपाईंले डाटा दौडबाट जोगिनु पर्छ।यदि बहु थ्रेडहरूमा समान `UnsafeCell` को पहुँच छ भने, कुनै पनि लेखोटहरूको उचित घटना हुनुपर्दछ-सबै अन्य पहुँचहरू (वा एटोमिक्स प्रयोग गर्नुहोस्) सम्बन्धमा पहिले।
///
/// उचित डिजाइनको साथ सहयोग गर्न, निम्न परिदृश्यहरू स्पष्ट रूपमा एकल-थ्रेडेड कोडका लागि कानुनी रूपमा घोषणा गरिएको छ:
///
/// 1. एक `&T` सन्दर्भ सुरक्षित कोडमा रिलिज गर्न सकिन्छ र त्यहाँ यो अन्य `&T` सन्दर्भसँग सह-अवस्थित हुन सक्छ, तर `&mut T` का साथ होईन।
///
/// 2. एक `&mut T` सन्दर्भ सुरक्षित कोडमा रिलिज गर्न सकिन्छ नत्र अन्य `&mut T` न `&T` यससँग सह-अवस्थित छ।एक `&mut T` सँधै विशिष्ट हुनुपर्दछ।
///
/// नोट गर्नुहोस् कि जब `&UnsafeCell<T>` X को सामग्रीहरू म्युटेर गर्दै (जबकि अन्य `&UnsafeCell<T>` सन्दर्भ उप सेल सेल) ठीक छ (यदि तपाईंले माथिका आक्रमणकारीहरूलाई अन्य तरिकाले लागू गर्नुभयो भने), बहुविध `&mut UnsafeCell<T>` उपनामहरू राख्न यो अझै अपरिभाषित व्यवहार हो।
/// त्यो हो, `UnsafeCell` एक र्यापर हो जुन _shared_ accesses (_i.e._ का साथ विशेष अन्तरक्रियाको लागि डिजाइन गरिएको छ, `&UnsafeCell<_>` सन्दर्भ मार्फत);_exclusive_ accesses (_e.g._ मार्फत `&mut UnsafeCell<_>` मार्फत व्यवहार गर्दा त्यहाँ कुनै जादू छैन) न त सेल नै न त रैप गरिएको मान उक्त `&mut` orrowणको अवधिको लागि उपनाम हुन सक्छ।
///
/// यो [`.get_mut()`] एक्सेसर द्वारा प्रदर्शन गरिएको छ, जुन _safe_ getter हो जसले `&mut T` दिन्छ।
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// यहाँ एक उदाहरण प्रस्तुत गर्दै छ कि कसरी सेल Xiasing बहु सन्दर्भहरू भए पनि `UnsafeCell<_>` को सामग्रीहरू ध्वनि रूपान्तरण गर्न:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // एउटै `x` मा बहु/समवर्ती/साझा सन्दर्भहरू पाउनुहोस्।
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // सुरक्षा: यस क्षेत्र भित्र `x` को सामग्रीको अन्य कुनै सन्दर्भ छैन,
///     // त्यसैले हाम्रो प्रभावी ढंगले अद्वितीय छ।
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- उधारो-+
///     *p1_exclusive += 27; // |
/// } // <---------- यस बिन्दु भन्दा बाहिर जान सक्दैन -------------------+
///
/// unsafe {
///     // सुरक्षा: यस दायरा भित्र कोहीले पनि `x` को सामग्रीहरूमा विशेष पहुँच हुने अपेक्षा गर्दैन,
///     // त्यसैले हामी सँगै धेरै साझा पहुँचहरू गर्न सक्दछौं।
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// निम्न उदाहरणले `UnsafeCell<T>` का लागि एक्सेस एक्स्क्लोभेट पहुँचले यसको `T` मा विशेष पहुँचलाई दर्साउँदछ भन्ने तथ्यलाई प्रदर्शन गर्दछ:
///
/// ```rust
/// #![forbid(unsafe_code)] // विशेष पहुँचको साथ,
///                         // `UnsafeCell` पारदर्शी नो-ओप आवरण हो, त्यसैले यहाँ `unsafe` को आवश्यकता पर्दैन।
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // एक कम्पाईल-समय-जाँच अद्वितीय सन्दर्भ `x` मा प्राप्त गर्नुहोस्।
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // एक विशेष सन्दर्भको साथ, हामी सामग्री नि: शुल्क परिवर्तन गर्न सक्दछौं।
/// *p_unique.get_mut() = 0;
/// // वा, समान रूपमा:
/// x = UnsafeCell::new(0);
///
/// // जब हामीसँग मान छ, हामी नि: शुल्क सामग्रीहरू निकाल्न सक्छौं।
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// `UnsafeCell` को नयाँ उदाहरण निर्माण गर्दछ जसले निर्दिष्ट मानलाई लपेट्छ।
    ///
    ///
    /// विधिहरू मार्फत आन्तरिक मानमा सबै पहुँचहरू `unsafe` हो।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// मूल्य उतारिन्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// र्‍याप गरिएको मानमा म्यूटेबल पोइन्टर हुन्छ।
    ///
    /// यो कुनै पनि प्रकारको सूचकमा कास्ट गर्न सकिन्छ।
    /// `&mut T` मा कास्टि when गर्दा पहुँच अनौंठो छ (यो कुनै सक्रिय सन्दर्भ, परिवर्तनीय वा हैन), र `&T` मा कास्टिंग गर्दा त्यहाँ कुनै म्युटेसन वा उत्परिवर्तन उपनामहरू भइरहेको छ भनेर निश्चित गर्नुहोस्।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // हामी केवल सूचक `UnsafeCell<T>` बाट `T` लाई #[repr(transparent)] को कारणले कास्ट गर्न सक्छौं।
        // यसले लिब्स्टको विशेष स्थितिलाई शोषण गर्दछ, प्रयोगकर्ता कोडको लागि कुनै ग्यारेन्टी छैन कि यसले कम्पाइलरको future संस्करणहरूमा काम गर्दछ!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// अन्तर्निहित डेटामा म्यूटेबल सन्दर्भ फर्काउँछ।
    ///
    /// यो कलले `UnsafeCell` लाई परस्पर उधारो दिन्छ (कम्पाइल समयमा) जुन ग्यारेन्टी गर्दछ कि हामीसंग केवल सन्दर्भ छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// र्‍याप गरिएको मानमा म्यूटेबल पोइन्टर हुन्छ।
    /// [`get`] को भिन्नता यो प्रकार्यले एक कच्चा सूचक स्वीकार गर्दछ, जुन अस्थायी सन्दर्भको सिर्जनालाई रोक्नका लागि उपयोगी छ।
    ///
    /// परिणाम कुनै पनि प्रकारको सूचकमा कास्ट गर्न सकिन्छ।
    /// `&mut T` मा कास्टि when गर्दा पहुँच अनौंठो छ (यो कुनै सक्रिय सन्दर्भ, परिवर्तनीय वा हैन) लाई सुनिश्चित गर्नुहोस्, र `&T` मा कास्टिंग गर्दा त्यहाँ कुनै म्यूटेशन वा म्युटेबल उपनामहरू भइरहेको छैन भनेर निश्चित गर्नुहोस्।
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// `UnsafeCell` को क्रमिक आरम्भ `raw_get` X को आवश्यकता छ, `get` कल गर्दा uninitialized डेटा को लागी एक संदर्भ बनाउन आवश्यक छ:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // हामी केवल सूचक `UnsafeCell<T>` बाट `T` लाई #[repr(transparent)] को कारणले कास्ट गर्न सक्छौं।
        // यसले लिब्स्टको विशेष स्थितिलाई शोषण गर्दछ, प्रयोगकर्ता कोडको लागि कुनै ग्यारेन्टी छैन कि यसले कम्पाइलरको future संस्करणहरूमा काम गर्दछ!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// एक `UnsafeCell` सिर्जना गर्दछ, T को लागि `Default` मानको साथ।
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}