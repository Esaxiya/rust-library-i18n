use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` तर गैर-शून्य र कोभेरियन्ट।
///
/// कच्चा पोइन्टर्स प्रयोग गरेर डाटा संरचना निर्माण गर्दा यो प्रयोग गर्नका लागि प्राय: सहि चीज हुन्छ, तर यसको अतिरिक्त गुणहरूका कारण अन्ततः प्रयोग गर्न अझ खतरनाक हुन्छ।यदि तपाइँ निश्चित हुनुहुन्न कि यदि तपाइँ `NonNull<T>` प्रयोग गर्नु पर्छ भने मात्र `*mut T` प्रयोग गर्नुहोस्!
///
/// `*mut T` को विपरीत, सूचक सधैं नल-हुलिएको हुनुपर्दछ, यदि पोइन्टर कहिले पनि डेरेन्फर्ड हुँदैन।यो यस्तो छ कि एन्म्सले यो निषेधित मानलाई भेदभावको रूपमा प्रयोग गर्न सक्दछ-`Option<NonNull<T>>` सँग `* mut T` को जस्तो आकार छ।
/// यद्यपि पोइन्टर अझै पनि झुक्न सक्छ यदि यसलाई डिरेफर गरिएको छैन।
///
/// `*mut T` विपरीत, `NonNull<T>` `T` मा covariant हुनका लागि चुनिएको थियो।यसले कोभेरियन्ट प्रकारहरू बनाउँदा `NonNull<T>` प्रयोग गर्न सम्भव बनाउँदछ, तर असहायपनको जोखिम प्रस्तुत गर्दछ यदि त्यस्तो प्रकारमा प्रयोग गरियो जुन वास्तवमै कोभेरियन्ट हुनुहुँदैन।
/// (विपरित छनौट `*mut T` को लागी बनाइएको थियो, जबकि प्राविधिक रूप बाट ध्वनी असुरक्षा मात्र असुरक्षित कार्यहरू कल गरेर हुन सक्छ।)
///
/// कोभेरियन्सन अधिकांश सुरक्षित अमूर्तका लागि सही छ, जस्तै `Box`, `Rc`, `Arc`, `Vec`, र `LinkedList`।यो केस हो किनकि उनीहरूले सार्वजनिक एपीआई प्रदान गर्दछ जुन Rust को सामान्य साझा XOR म्यूटेबल नियमहरू पछ्याउँदछ।
///
/// यदि तपाइँको प्रकार सुरक्षित रूपमा covariant हुन सक्दैन, तपाइँ यो निश्चित गर्न पर्छ केहि ईवायरिएन्स प्रदान गर्न को लागी केहि अतिरिक्त फाईल छ।प्राय: यस फिल्ड [`PhantomData`] प्रकार `PhantomData<Cell<T>>` वा `PhantomData<&'a mut T>` हुनेछ।
///
/// ध्यान दिनुहोस् कि `NonNull<T>` सँग `&T` का लागि `From` उदाहरण छ।जे होस्, यसले तथ्यलाई परिवर्तन गर्दैन कि (a बाट उत्पन्न गरिएको सूचक) साझा संदर्भको अपरिभाषित व्यवहार हो जबसम्म उत्परिवर्तन [`UnsafeCell<T>`] भित्र हुँदैन।एक समान संदर्भ बाट एक परिवर्तनीय सन्दर्भ सिर्जना गर्न को लागी समान छ।
///
/// यो `From` उदाहरण `UnsafeCell<T>` बिना प्रयोग गर्दा, `as_mut` कहिल्यै बोलाइएको छैन र `as_ptr` कहिल्यै उत्परिवर्तनको लागि प्रयोग नगर्ने कुराको सुनिश्चित गर्नु तपाईंको उत्तरदायित्व हो।
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` पोइन्टर्स `Send` छैनन् किनकि उनीहरूले सन्दर्भ डेटा डाटा alies हुन सक्छ।
// NB, यो impl अनावश्यक छ, तर राम्रो त्रुटि सन्देशहरू प्रदान गर्नु पर्छ।
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` पोइन्टर्स `Sync` छैनन् किनकि उनीहरूले सन्दर्भ डेटा डाटा alies हुन सक्छ।
// NB, यो impl अनावश्यक छ, तर राम्रो त्रुटि सन्देशहरू प्रदान गर्नु पर्छ।
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// नयाँ `NonNull` सिर्जना गर्दछ जुन ड्याang्लि is्ग छ, तर राम्रोसँग पigned्क्तिबद्ध गरिएको छ।
    ///
    /// यो प्रारम्भिक प्रकारका सुरू गर्नका लागि उपयोगी छ जुन `Vec::new` गर्दछ।
    ///
    /// नोट गर्नुहोस् कि सूचक मानले सम्भावित रूपमा `T` लाई वैध पोइन्टर प्रतिनिधित्व गर्न सक्दछ, जसको मतलब यो "not yet initialized" सेन्टिनल मानको रूपमा प्रयोग गर्नु हुँदैन।
    /// प्रकारहरू जुन आलम्बित रूपमा आवंटित हुन्छन् अरू केही माध्यमद्वारा इनिसियलाइज ट्र्याक गर्नुपर्दछ
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // सुरक्षा: mem::align_of() एक गैर-शून्य usize फर्काउँछ जुन त्यसपछि कास्ट गरियो
        // एक * mut T. लाई
        // तसर्थ, `ptr` शून्य छैन र new_unchecked() कल गर्नका लागि सर्तहरूको सम्मान गरिएको छ।
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// मानमा साझेदारी गरिएको सन्दर्भ फर्काउँछ।[`as_ref`] को विपरित, यसको लागि मानलाई सुरूवात गर्न आवश्यक पर्दैन।
    ///
    /// म्यूटेबल समकक्षको लागि [`as_uninit_mut`] हेर्नुहोस्।
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// यो विधि कल गर्दा, तपाईले निम्न सबै कुरा ठीक छन् भनेर सुनिश्चित गर्नुपर्दछ:
    ///
    /// * सूचक ठीकसँग प properly्क्तिबद्ध गरिएको हुनुपर्दछ।
    ///
    /// * यो [the module documentation] मा परिभाषित अर्थमा "dereferencable" हुनुपर्दछ।
    ///
    /// * तपाईंले Rust को aliasing नियम लागू गर्नुपर्नेछ, किनकि फिर्ता जीवनकाल `'a` मनमाने ढंगले छनौट गरिएको छ र डाटाको वास्तविक जीवनकाल प्रतिबिम्बित गर्दैन।
    ///
    ///   विशेष रूपमा, यस जीवनकालको अवधिको लागि, सूचक विन्दुमा मेमोरी म्युट हुनु हुँदैन (`UnsafeCell` भित्र बाहेक)।
    ///
    /// यो लागू हुन्छ यदि यो विधिको परिणाम अप्रयुक्त छ!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // सुरक्षा: कलरले ग्यारेन्टी गर्नु पर्छ `self` X सबै भेट्छन्
        // एक सन्दर्भ को लागी आवश्यकताहरु।
        unsafe { &*self.cast().as_ptr() }
    }

    /// मानको लागि एक अद्वितीय सन्दर्भ फर्काउँछ।[`as_mut`] को विपरित, यसको लागि मानलाई सुरूवात गर्न आवश्यक पर्दैन।
    ///
    /// साझा समकक्षको लागि [`as_uninit_ref`] हेर्नुहोस्।
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// यो विधि कल गर्दा, तपाईले निम्न सबै कुरा ठीक छन् भनेर सुनिश्चित गर्नुपर्दछ:
    ///
    /// * सूचक ठीकसँग प properly्क्तिबद्ध गरिएको हुनुपर्दछ।
    ///
    /// * यो [the module documentation] मा परिभाषित अर्थमा "dereferencable" हुनुपर्दछ।
    ///
    /// * तपाईंले Rust को aliasing नियम लागू गर्नुपर्नेछ, किनकि फिर्ता जीवनकाल `'a` मनमाने ढंगले छनौट गरिएको छ र डाटाको वास्तविक जीवनकाल प्रतिबिम्बित गर्दैन।
    ///
    ///   विशेष रूपमा, यस जीवनकालको अवधिको लागि, पोइन्टरले औंल्याएको मेमोरीमा अन्य पोइन्टर मार्फत पहुँच गर्न (पढ्न वा लेखिएको) हुदैन।
    ///
    /// यो लागू हुन्छ यदि यो विधिको परिणाम अप्रयुक्त छ!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // सुरक्षा: कलरले ग्यारेन्टी गर्नु पर्छ `self` X सबै भेट्छन्
        // एक सन्दर्भ को लागी आवश्यकताहरु।
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// नयाँ `NonNull` सिर्जना गर्दछ।
    ///
    /// # Safety
    ///
    /// `ptr` गैर-शून्य हुनु पर्छ।
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // सुरक्षा: कलरले `ptr` गैर-शून्य ग्यारेन्टी गर्नु पर्छ।
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// `ptr` गैर-शून्य छ भने एक नयाँ `NonNull` सिर्जना गर्दछ।
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // सुरक्षा: सूचक पहिले नै जाँच गरीएको छ र खाली छैन
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// [`std::ptr::from_raw_parts`] को रूपमा समान कार्यक्षमता प्रदर्शन गर्दछ, `NonNull` सूचक फिर्ताको लागि बाहेक, कच्चा `*const` सूचकको विपरित।
    ///
    ///
    /// अधिक जानकारीको लागि [`std::ptr::from_raw_parts`] को कागजात हेर्नुहोस्।
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // सुरक्षा: `ptr::from::raw_parts_mut` को नतिजा गैर-शून्य छ किनभने `data_address` छ।
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// एक (संभवत: फराकिलो) सूचकलाई विघटन गर्नुहोस् ठेगाना र मेटाडाटा कम्पोनेन्टहरू।
    ///
    /// सूचक पछि [`NonNull::from_raw_parts`] को साथ पुनर्निर्माण गर्न सकिन्छ।
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// अन्तर्निहित `*mut` सूचक प्राप्त गर्दछ।
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// मानको लागि एक साझा सन्दर्भ फर्काउँछ।यदि मान अनावश्यक हुन सक्छ भने यसको सट्टामा [`as_uninit_ref`] प्रयोग गर्नुपर्नेछ।
    ///
    /// म्यूटेबल समकक्षको लागि [`as_mut`] हेर्नुहोस्।
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// यो विधि कल गर्दा, तपाईले निम्न सबै कुरा ठीक छन् भनेर सुनिश्चित गर्नुपर्दछ:
    ///
    /// * सूचक ठीकसँग प properly्क्तिबद्ध गरिएको हुनुपर्दछ।
    ///
    /// * यो [the module documentation] मा परिभाषित अर्थमा "dereferencable" हुनुपर्दछ।
    ///
    /// * सूचक `T` को एक शुरुआती दृष्टान्त औंल्याउनु पर्छ।
    ///
    /// * तपाईंले Rust को aliasing नियम लागू गर्नुपर्नेछ, किनकि फिर्ता जीवनकाल `'a` मनमाने ढंगले छनौट गरिएको छ र डाटाको वास्तविक जीवनकाल प्रतिबिम्बित गर्दैन।
    ///
    ///   विशेष रूपमा, यस जीवनकालको अवधिको लागि, सूचक विन्दुमा मेमोरी म्युट हुनु हुँदैन (`UnsafeCell` भित्र बाहेक)।
    ///
    /// यो लागू हुन्छ यदि यो विधिको परिणाम अप्रयुक्त छ!
    /// (आरम्भमा हुने बारेको अंश अझै पूर्ण निर्णय भएको छैन, तर यो नभएसम्म मात्र सुरक्षित दृष्टिकोण भनेको उनीहरूलाई वास्तवमै आरम्भ गरिएको सुनिश्चित गर्नु हो।)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // सुरक्षा: कलरले ग्यारेन्टी गर्नु पर्छ `self` X सबै भेट्छन्
        // एक सन्दर्भ को लागी आवश्यकताहरु।
        unsafe { &*self.as_ptr() }
    }

    /// मानको लागि एक अद्वितीय सन्दर्भ फर्काउँछ।यदि मान अनावश्यक हुन सक्छ भने यसको सट्टामा [`as_uninit_mut`] प्रयोग गर्नुपर्नेछ।
    ///
    /// साझा समकक्षको लागि [`as_ref`] हेर्नुहोस्।
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// यो विधि कल गर्दा, तपाईले निम्न सबै कुरा ठीक छन् भनेर सुनिश्चित गर्नुपर्दछ:
    ///
    /// * सूचक ठीकसँग प properly्क्तिबद्ध गरिएको हुनुपर्दछ।
    ///
    /// * यो [the module documentation] मा परिभाषित अर्थमा "dereferencable" हुनुपर्दछ।
    ///
    /// * सूचक `T` को एक शुरुआती दृष्टान्त औंल्याउनु पर्छ।
    ///
    /// * तपाईंले Rust को aliasing नियम लागू गर्नुपर्नेछ, किनकि फिर्ता जीवनकाल `'a` मनमाने ढंगले छनौट गरिएको छ र डाटाको वास्तविक जीवनकाल प्रतिबिम्बित गर्दैन।
    ///
    ///   विशेष रूपमा, यस जीवनकालको अवधिको लागि, पोइन्टरले औंल्याएको मेमोरीमा अन्य पोइन्टर मार्फत पहुँच गर्न (पढ्न वा लेखिएको) हुदैन।
    ///
    /// यो लागू हुन्छ यदि यो विधिको परिणाम अप्रयुक्त छ!
    /// (आरम्भमा हुने बारेको अंश अझै पूर्ण निर्णय भएको छैन, तर यो नभएसम्म मात्र सुरक्षित दृष्टिकोण भनेको उनीहरूलाई वास्तवमै आरम्भ गरिएको सुनिश्चित गर्नु हो।)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // सुरक्षा: कलरले ग्यारेन्टी गर्नु पर्छ `self` X सबै भेट्छन्
        // एक परिवर्तनीय सन्दर्भ को लागी आवश्यकताहरु।
        unsafe { &mut *self.as_ptr() }
    }

    /// अर्को प्रकारको सूचकमा क्यास्ट गर्नुहोस्।
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // सुरक्षा: `self` एक `NonNull` सूचक हो जो अनावश्यक रूपमा अशक्त छ
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// पातलो सूचक र लम्बाइबाट एक गैर-नल कच्चा स्लाइस सिर्जना गर्दछ।
    ///
    /// `len` आर्गुमेन्ट **एलिमेन्ट्स** को संख्या हो, बाइट्सको संख्या होईन।
    ///
    /// यो प्रकार्य सुरक्षित छ, तर फिर्ता मूल्य dereferences असुरक्षित छ।
    /// टुक्रा सुरक्षा आवश्यकताहरूको लागि [`slice::from_raw_parts`] को कागजात हेर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // पहिलो एलिमेन्टमा सूचकको साथ सुरू गर्दा स्लाइस पोइन्टर सिर्जना गर्नुहोस्
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (नोट गर्नुहोस् कि यो उदाहरण कृत्रिम रूपमा यस विधिको प्रयोग दर्साउँछ, तर ice टुक्रा गरौं= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // सुरक्षा: `data` एक `NonNull` सूचक हो जो अनावश्यक रूपमा अशक्त छ
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// गैर-शून्य कच्चा स्लाइसको लम्बाइ फर्काउँछ।
    ///
    /// फर्काइएको मान **एलिमेन्ट्स** को संख्या हो, बाइट्सको संख्या होईन।
    ///
    /// यो प्रकार्य सुरक्षित छ, जबकि गैर-नल कच्चा स्लाइसलाई स्लाइसमा डेरेन्टर गर्न सकिदैन किनकि पोइन्टरमा मान्य ठेगाना छैन।
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// स्लाइसको बफरमा नन-नल पोइन्टर फर्काउँछ।
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // सुरक्षा: हामीलाई थाहा छ `self` गैर-शून्य छ।
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// स्लाइसको बफरमा एक कच्चा सूचक फर्काउँछ।
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// सम्भावित अनावश्यक मानको एक टुक्रामा साझेदारी संदर्भ फर्काउँछ।[`as_ref`] को विपरित, यसको लागि मानलाई सुरूवात गर्न आवश्यक पर्दैन।
    ///
    /// म्यूटेबल समकक्षको लागि [`as_uninit_slice_mut`] हेर्नुहोस्।
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// यो विधि कल गर्दा, तपाईले निम्न सबै कुरा ठीक छन् भनेर सुनिश्चित गर्नुपर्दछ:
    ///
    /// * सूचक [valid] X धेरै बाइट्सका लागि पढ्नको लागि हुनुपर्दछ, र यो सही प properly्क्तिबद्ध गरिएको हुनुपर्दछ।यसको अर्थ विशेष रूपमा:
    ///
    ///     * यस स्लाइसको सम्पूर्ण मेमोरी दायरा एकल विनियोजित वस्तु बीचमा हुनुपर्दछ!
    ///       स्लाइसहरू कहिले पनि बहु नियत वस्तुहरूमा फ्याँक्न सक्दैन।
    ///
    ///     * सूचकलाई शून्य-लम्बाइका स्लाइसहरूका लागि पigned्क्तिबद्ध गर्नुपर्दछ
    ///     यसको लागि एक कारण यो हो कि एनम लेआउट अप्टिमाइजेसनहरू सन्दर्भमा निर्भर हुन सक्छ (कुनै पनि लम्बाइको स्लाइसहरू सहित) पigned्क्तिबद्ध गरिएको छ र गैर डाटालाई अन्य डाटाबाट छुट्ट्याउन।
    ///
    ///     तपाइँले एक सूचक प्राप्त गर्न सक्नुहुन्छ जुन [`NonNull::dangling()`] को प्रयोग गरेर शून्य-लम्बाइका स्लाइसहरूको लागि `data` को रूपमा प्रयोग योग्य छ।
    ///
    /// * स्लाइसको कुल आकार `ptr.len() * mem::size_of::<T>()` `isize::MAX` भन्दा ठूलो हुनु हुँदैन।
    ///   [`pointer::offset`] को सुरक्षा दस्तावेज हेर्नुहोस्।
    ///
    /// * तपाईंले Rust को aliasing नियम लागू गर्नुपर्नेछ, किनकि फिर्ता जीवनकाल `'a` मनमाने ढंगले छनौट गरिएको छ र डाटाको वास्तविक जीवनकाल प्रतिबिम्बित गर्दैन।
    ///   विशेष रूपमा, यस जीवनकालको अवधिको लागि, सूचक विन्दुमा मेमोरी म्युट हुनु हुँदैन (`UnsafeCell` भित्र बाहेक)।
    ///
    /// यो लागू हुन्छ यदि यो विधिको परिणाम अप्रयुक्त छ!
    ///
    /// [`slice::from_raw_parts`] पनि हेर्नुहोस्।
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // सुरक्षा: कलरले `as_uninit_slice` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ।
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// सम्भावित अनावश्यक मानको स्लाइसमा अद्वितीय सन्दर्भ फर्काउँछ।[`as_mut`] को विपरित, यसको लागि मानलाई सुरूवात गर्न आवश्यक पर्दैन।
    ///
    /// साझा समकक्षको लागि [`as_uninit_slice`] हेर्नुहोस्।
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// यो विधि कल गर्दा, तपाईले निम्न सबै कुरा ठीक छन् भनेर सुनिश्चित गर्नुपर्दछ:
    ///
    /// * सूचक [valid] X धेरै बाइट्सका लागि पढ्न र लेख्नको लागि [valid] हुनुपर्दछ, र यो सही पigned्क्तिबद्ध गरिएको हुनुपर्दछ।यसको अर्थ विशेष रूपमा:
    ///
    ///     * यस स्लाइसको सम्पूर्ण मेमोरी दायरा एकल विनियोजित वस्तु बीचमा हुनुपर्दछ!
    ///       स्लाइसहरू कहिले पनि बहु नियत वस्तुहरूमा फ्याँक्न सक्दैन।
    ///
    ///     * सूचकलाई शून्य-लम्बाइका स्लाइसहरूका लागि पigned्क्तिबद्ध गर्नुपर्दछ
    ///     यसको लागि एक कारण यो हो कि एनम लेआउट अप्टिमाइजेसनहरू सन्दर्भमा निर्भर हुन सक्छ (कुनै पनि लम्बाइको स्लाइसहरू सहित) पigned्क्तिबद्ध गरिएको छ र गैर डाटालाई अन्य डाटाबाट छुट्ट्याउन।
    ///
    ///     तपाइँले एक सूचक प्राप्त गर्न सक्नुहुन्छ जुन [`NonNull::dangling()`] को प्रयोग गरेर शून्य-लम्बाइका स्लाइसहरूको लागि `data` को रूपमा प्रयोग योग्य छ।
    ///
    /// * स्लाइसको कुल आकार `ptr.len() * mem::size_of::<T>()` `isize::MAX` भन्दा ठूलो हुनु हुँदैन।
    ///   [`pointer::offset`] को सुरक्षा दस्तावेज हेर्नुहोस्।
    ///
    /// * तपाईंले Rust को aliasing नियम लागू गर्नुपर्नेछ, किनकि फिर्ता जीवनकाल `'a` मनमाने ढंगले छनौट गरिएको छ र डाटाको वास्तविक जीवनकाल प्रतिबिम्बित गर्दैन।
    ///   विशेष रूपमा, यस जीवनकालको अवधिको लागि, पोइन्टरले औंल्याएको मेमोरीमा अन्य पोइन्टर मार्फत पहुँच गर्न (पढ्न वा लेखिएको) हुदैन।
    ///
    /// यो लागू हुन्छ यदि यो विधिको परिणाम अप्रयुक्त छ!
    ///
    /// [`slice::from_raw_parts_mut`] पनि हेर्नुहोस्।
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // यो सुरक्षित छ किनकि `memory` पढ्नको लागि मान्य छ र `memory.len()` धेरै बाइटहरूको लागि लेख्छ।
    /// // नोट गर्नुहोस् कि `memory.as_mut()` लाई कल गर्न को लागी अनुमति छैन किनभने सामग्री को अनावश्यक हुन सक्छ।
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // सुरक्षा: कलरले `as_uninit_slice_mut` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ।
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// एन्डिमेन्ट जाँच नगरी कुनै तत्त्व वा सब्सलिसमा कच्चा सूचक फिर्ता गर्दछ।
    ///
    /// यस विधिलाई आउट-आउट-सीमाहरू अनुक्रमणिकाको साथ कल गर्नु वा जब `self` डेरेफ्रेन्सेबल हुँदैन * *[अपरिभाषित व्यवहार] * पनि यदि परिणामस्वरूप पोइन्टर प्रयोग गरिएको छैन।
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // सुरक्षा: कलरले `self` लाई डेरेन्सेकेबल र `index` इन-बाउन्ड सुनिश्चित गर्दछ।
        // परिणामको रूपमा, परिणामस्वरूप सूचक NUL हुन सक्दैन।
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // सुरक्षा: एक अद्वितीय सूचक खाली हुन सक्दैन, त्यसैले सर्तहरूको लागि
        // new_unchecked() सम्मानित छन्।
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // सुरक्षा: एक परिवर्तनीय सन्दर्भ खाली हुन सक्दैन।
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // सुरक्षा: एउटा सन्दर्भ शून्य हुन सक्दैन, त्यसैले सर्तहरूको लागि
        // new_unchecked() सम्मानित छन्।
        unsafe { NonNull { pointer: reference as *const T } }
    }
}