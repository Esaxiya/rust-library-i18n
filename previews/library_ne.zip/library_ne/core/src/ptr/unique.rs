use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// एक कच्चा गैर-नल `*mut T` वरपर एउटा र्यापर जसले यो रैपरको मालिकले रेफरेक्टको स्वामित्व दर्साउँछ।
/// `Box<T>`, `Vec<T>`, `String`, र `HashMap<K, V>` जस्ता अमूर्त निर्माणका लागि उपयोगी छ।
///
/// `*mut T` विपरीत, `Unique<T>` "as if" व्यवहार गर्दछ यो `T` को एक उदाहरण हो।
/// यो `Send`/`Sync` लागू गर्दछ यदि `T` `Send`/`Sync` हो।
/// यसले `T` को उदाहरणले अपेक्षित गर्न सक्ने बलियो एलिजिasing ग्यारेन्टीहरू पनि जनाउँदछ:
/// सूचकको भिन्नै यसको अनौंठो को अनौंठो मार्ग बिना परिमार्जन हुँदैन।
///
/// यदि तपाइँ यस उद्देश्यको लागि `Unique` प्रयोग गर्न सही हो वा होइन भनेर अनिश्चित हुनुहुन्छ भने, `NonNull` प्रयोग गर्ने बारे विचार गर्नुहोस्, जसमा कमजोर शब्दांकन छ।
///
///
/// `*mut T` को विपरीत, सूचक सधैं नल-हुलिएको हुनुपर्दछ, यदि पोइन्टर कहिले पनि आदरयुक्त हुँदैन।
/// यो यस्तो छ कि एन्म्सले यो निषेधित मानलाई भेदभावको रूपमा प्रयोग गर्न सक्दछ-`Option<Unique<T>>` सँग `Unique<T>` X को जस्तो आकार छ।
/// यद्यपि पोइन्टर अझै पनि झुक्न सक्छ यदि यसलाई डिरेफर गरिएको छैन।
///
/// `*mut T` विपरीत, `Unique<T>` `T` मा covariant छ।
/// यो सँधै कुनै पनि प्रकारको लागि सही हुनुपर्छ जुन अद्वितीयको एलियाजिंग आवश्यकताहरूलाई समर्थन गर्दछ।
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: यस मार्करको विचरणको लागि कुनै परिणामहरू छैनन्, तर आवश्यक छ
    // ड्रप को लागी बुझ्न कि हामी तार्किक रूपमा एक `T` को मालिकौं।
    //
    // विवरणका लागि, हेर्नुहोस्:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` सूचकहरू `Send` हुन् यदि `T` `Send` छ किनकि उनीहरूले सन्दर्भ गरेको डाटा असम्बन्धित छ।
/// नोट गर्नुहोस् कि यो एलियासि inv इन्भेन्टेरन्ट प्रकार प्रणाली द्वारा असुरक्षित छ;`Unique` प्रयोग गर्ने अमूर्तले यसलाई लागू गर्नुपर्दछ।
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` सूचकहरू `Sync` हुन् यदि `T` `Sync` छ किनकि उनीहरूले सन्दर्भ गरेको डाटा असम्बन्धित छ।
/// नोट गर्नुहोस् कि यो एलियासि inv इन्भेन्टेरन्ट प्रकार प्रणाली द्वारा असुरक्षित छ;`Unique` प्रयोग गर्ने अमूर्तले यसलाई लागू गर्नुपर्दछ।
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// नयाँ `Unique` सिर्जना गर्दछ जुन ड्याang्लि is्ग छ, तर राम्रोसँग पigned्क्तिबद्ध गरिएको छ।
    ///
    /// यो प्रारम्भिक प्रकारका सुरू गर्नका लागि उपयोगी छ जुन `Vec::new` गर्दछ।
    ///
    /// नोट गर्नुहोस् कि सूचक मानले सम्भावित रूपमा `T` लाई वैध पोइन्टर प्रतिनिधित्व गर्न सक्दछ, जसको मतलब यो "not yet initialized" सेन्टिनल मानको रूपमा प्रयोग गर्नु हुँदैन।
    /// प्रकारहरू जुन आलम्बित रूपमा आवंटित हुन्छन् अरू केही माध्यमद्वारा इनिसियलाइज ट्र्याक गर्नुपर्दछ
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // सुरक्षा: mem::align_of() एक मान्य, गैर शून्य सूचक फिर्ता गर्छ।को
        // new_unchecked() कल गर्न शर्तहरु यसैले सम्मान गरिन्छ।
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// नयाँ `Unique` सिर्जना गर्दछ।
    ///
    /// # Safety
    ///
    /// `ptr` गैर-शून्य हुनु पर्छ।
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // सुरक्षा: कलरले `ptr` गैर-शून्य ग्यारेन्टी गर्नु पर्छ।
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// `ptr` गैर-शून्य छ भने एक नयाँ `Unique` सिर्जना गर्दछ।
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // सुरक्षा: सूचक पहिले नै जाँच गरीएको छ र खाली छैन।
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// अन्तर्निहित `*mut` सूचक प्राप्त गर्दछ।
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// सामग्री Dereferences।
    ///
    /// परिणामस्वरूप जीवनकाल स्वयंमा बाध्य छ त्यसैले यो व्यवहार गर्दछ "as if" यो वास्तवमा टी को एक उदाहरण हो कि उधारो भइरहेको छ।
    /// यदि लामो (unbound) आजीवन आवश्यक छ भने, `&*my_ptr.as_ptr()` प्रयोग गर्नुहोस्।
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // सुरक्षा: कलरले ग्यारेन्टी गर्नु पर्छ `self` X सबै भेट्छन्
        // एक सन्दर्भ को लागी आवश्यकताहरु।
        unsafe { &*self.as_ptr() }
    }

    /// म्यूटेबल सामग्रीलाई dereferences।
    ///
    /// परिणामस्वरूप जीवनकाल स्वयंमा बाध्य छ त्यसैले यो व्यवहार गर्दछ "as if" यो वास्तवमा टी को एक उदाहरण हो कि उधारो भइरहेको छ।
    /// यदि लामो (unbound) आजीवन आवश्यक छ भने, `&mut *my_ptr.as_ptr()` प्रयोग गर्नुहोस्।
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // सुरक्षा: कलरले ग्यारेन्टी गर्नु पर्छ `self` X सबै भेट्छन्
        // एक परिवर्तनीय सन्दर्भ को लागी आवश्यकताहरु।
        unsafe { &mut *self.as_ptr() }
    }

    /// अर्को प्रकारको सूचकमा क्यास्ट गर्नुहोस्।
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // सुरक्षा: Unique::new_unchecked() एक नयाँ अद्वितीय र आवश्यकता सिर्जना गर्दछ
        // दिइएको सूचक खाली छैन।
        // किनकि हामी एक सूचकको रूपमा आफैमा जाँदैछौं, यो शून्य हुन सक्दैन।
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // सुरक्षा: एक परिवर्तनीय सन्दर्भ खाली हुन सक्दैन
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}