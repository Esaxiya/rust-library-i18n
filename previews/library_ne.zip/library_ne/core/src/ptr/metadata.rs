#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// कुनै पनि पोइन्ट-टु प्रकारको सूचक मेटाडाटा प्रकार प्रदान गर्दछ।
///
/// # सूचक मेटाडाटा
///
/// Rust मा कच्चा सूचक प्रकार र सन्दर्भ प्रकारहरू दुई भागहरू द्वारा बनेको सोच्न सकिन्छ:
/// डाटा सूचक जसले मानको मेमोरी ठेगाना, र केही मेटाडेटा समावेश गर्दछ।
///
/// स्थिर-आकारका प्रकारहरूका लागि (जुन `Sized` traits लागू गर्दछ) साथै `extern` प्रकारहरूका लागि, पोइन्टर्स "पातलो" भनिन्छ: मेटाडाटा शून्य आकारको हुन्छ र यसको प्रकार `()` हो।
///
///
/// पोइन्टरहरू [dynamically-sized types][dst] भनिन्छ "फराकिलो" वा "फ्याट", तिनीहरूसँग गैर-शून्य-आकारको मेटाडेटा छ:
///
/// * स्ट्रिक्टको लागि जसको अन्तिम फिल्ड एक DST हो, मेटाडेटा अन्तिम फिल्डको लागि मेटाडेटा हो
/// * `str` प्रकारको लागि, मेटाडेटा `usize` को रूपमा बाइट्समा लम्बाई हो
/// * `[T]` जस्तो स्लाइस प्रकारका लागि, मेटाडेटा `usize` को रूपमा आइटमहरूमा लम्बाई हो
/// * trait वस्तुहरू जस्तै `dyn SomeTrait` को लागि, मेटाडेटा [`DynMetadata<Self>`][DynMetadata] हो (उदाहरणका लागि `DynMetadata<dyn SomeTrait>`)
///
/// future मा, Rust भाषा नयाँ प्रकारका प्राप्त गर्न सक्दछ जुन बिभिन्न सूचक मेटाडेटा छ।
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// यस trait को पोइन्ट यसको `Metadata` सम्बन्धित प्रकार हो जुन `()` वा `usize` वा `DynMetadata<_>` माथि वर्णन गरिएको छ।
/// यो स्वचालित रूपमा प्रत्येक प्रकारको लागी लागू हुन्छ।
/// यो जेनेरिक प्रस implemented्गमा कार्यान्वयन गरिएको मान्न सकिन्छ, एक मिल्दो सीमा बिना पनि।
///
/// # Usage
///
/// कच्चा सूचक डेटा [`to_raw_parts`] X विधिको साथ डाटा ठेगाना र मेटाडाटा कम्पोनेन्टहरूमा विघटन गर्न सकिन्छ।
///
/// वैकल्पिक रूपमा, एक्लै मेटाडेटा [`metadata`] प्रकार्यको साथ निकाल्न सकिन्छ।
/// एक संदर्भ [`metadata`] मा पारित गर्न सकिन्छ र स्पष्ट रूपमा जबरजस्ती।
///
/// एक (possibly-wide) सूचक [`from_raw_parts`] वा [`from_raw_parts_mut`] को साथ यसको ठेगाना र मेटाडेटाबाट फेरि सँगै राख्न सकिन्छ।
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// `Self` मा पोइन्टर्स र सन्दर्भहरूमा मेटाडेटाको लागि प्रकार।
    #[lang = "metadata_type"]
    // NOTE: `static_assert_expected_bounds_for_metadata` मा trait bounds राख्नुहोस्
    //
    // `library/core/src/ptr/metadata.rs` मा तीसँग समन्वयनमा:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// यो trait उपनाम लागू गर्ने प्रकारहरूमा पोइन्टरहरू "पातलो" छन्।
///
/// यसले स्ट्याटिकली-`Sized` प्रकार र `extern` प्रकारहरू समावेश गर्दछ।
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: trait उपनामहरू भाषामा स्थिर हुनु अघि यसलाई स्थिर नगर्नुहोस्?
pub trait Thin = Pointee<Metadata = ()>;

/// सूचकको मेटाडाटा घटक निकाल्नुहोस्।
///
/// `*mut T`, `&T`, वा `&mut T` प्रकारको मानहरू यस प्रकार्यमा सीधा पार गर्न सकिन्छ किनकि उनीहरूले स्पष्ट रूपमा `* const T` लाई जबरजस्ती गर्छन्।
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // सुरक्षा: `PtrRepr` युनियनबाट मान पहुँच गर्न * कन्स्ट्रक्ट टी पछि सुरक्षित छ
    // र PtrComp घटक<T>उही मेमोरी लेआउटहरू छन्।
    // केवल std ले यो ग्यारेन्टी गर्न सक्दछ।
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// डाटा ठेगाना र मेटाडाटाबाट (possibly-wide) कच्चा सूचक फार्म गर्दछ।
///
/// यो प्रकार्य सुरक्षित छ तर फिर्ता सूचक डेरेन्सनको लागि आवश्यक छैन।
/// स्लाइसहरूको लागि, सुरक्षा आवश्यकताहरूको लागि [`slice::from_raw_parts`] को कागजात हेर्नुहोस्।
/// trait वस्तुहरूको लागि, मेटाडेटा पोइन्टरबाट उहि अन्तर्निहित ईरेस्ड प्रकारमा आउनुपर्दछ।
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // सुरक्षा: `PtrRepr` युनियनबाट मान पहुँच गर्न * कन्स्ट्रक्ट टी पछि सुरक्षित छ
    // र PtrComp घटक<T>उही मेमोरी लेआउटहरू छन्।
    // केवल std ले यो ग्यारेन्टी गर्न सक्दछ।
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// [`from_raw_parts`] को समान कार्यक्षमता प्रदर्शन गर्दछ, एक कच्चा `*mut` सूचक फिर्ताको फिर्ता बाहेक, कच्चा `* const` सूचकको विपरित।
///
///
/// अधिक जानकारीको लागि [`from_raw_parts`] को कागजात हेर्नुहोस्।
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // सुरक्षा: `PtrRepr` युनियनबाट मान पहुँच गर्न * कन्स्ट्रक्ट टी पछि सुरक्षित छ
    // र PtrComp घटक<T>उही मेमोरी लेआउटहरू छन्।
    // केवल std ले यो ग्यारेन्टी गर्न सक्दछ।
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// `T: Copy` बाउन्ड हुनबाट म्यानुअल impl आवश्यक छ।
impl<T: ?Sized> Copy for PtrComponents<T> {}

// `T: Clone` बाउन्ड हुनबाट म्यानुअल impl आवश्यक छ।
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// `Dyn = dyn SomeTrait` trait वस्तु प्रकारका लागि मेटाडेटा।
///
/// यो एक vtable (भर्चुअल कल तालिका) को सूचक हो कि trait वस्तु भित्र भण्डारण ठोस प्रकार हेरफेर गर्न सबै आवश्यक जानकारी प्रतिनिधित्व गर्दछ।
/// Vtable ले यो समावेश गर्दछ:
///
/// * प्रकारको आकार
/// * प्रकार पign्क्तिबद्ध गर्नुहोस्
/// * प्रकारको `drop_in_place` impl को सूचक (सादा पुरानो-डाटाको लागि नो-ओप हुन सक्छ)
/// * trait को प्रकारको कार्यान्वयनको लागि सबै विधिहरूमा सूचक
///
/// नोट गर्नुहोस् कि पहिलो तीन विशेष छन् किनकि तिनीहरूलाई आवश्यक पर्ने trait वस्तु आवंटित गर्न, ड्रप गर्न र डिलोकट गर्न आवश्यक छ।
///
/// यो संरचनालाई प्रकार प्यारामिटरको साथ नाम दिन सम्भव छ जुन `dyn` trait वस्तु हैन (उदाहरणका लागि `DynMetadata<u64>`) तर त्यस संरचनाको अर्थपूर्ण मान प्राप्त गर्नलाई होईन।
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// सबै vtables को साधारण उपसर्ग।यो trait विधिहरूको लागि कार्य सूचकहरू द्वारा पछ्याएको छ।
///
/// `DynMetadata::size_of` आदि को निजी कार्यान्वयन विवरण।
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// यस vtable सँग सम्बन्धित प्रकारको आकार फर्काउँछ।
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// यस vtable सँग सम्बन्धित प्रकारको पign्क्तिबद्धता फर्काउँछ।
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// `Layout` को रूपमा आकार र पign्क्तिबद्धता फर्काउँछ
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // सुरक्षा: कम्पाइलरले कन्ट्र्याक्ट Rust प्रकारको लागि यो भ्याटेबललाई उत्सर्जित गर्‍यो जुन
        // एक मान्य लेआउट हुन ज्ञात छ।`Layout::for_value` मा जस्तै उस्तै तर्क।
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// `Dyn: $Trait` सीमानाहरू लाई बेवास्ता गर्न म्यानुअल लागूहरू आवश्यक छ।

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}