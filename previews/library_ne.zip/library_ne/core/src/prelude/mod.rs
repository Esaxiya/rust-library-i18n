//! लाइबकोर prelude
//!
//! यो मोड्युल लिबकोरका प्रयोगकर्ताहरूको लागि हो जुन लिबस्टडीसँग लि not्क हुँदैन।
//! यो मोड्युल पूर्वनिर्धारितद्वारा आयात गरिन्छ जब `#![no_std]` मानक लाइब्रेरीको preolve समान तरिकाले प्रयोग गरिन्छ।
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// कोर prelude को २०१ version संस्करण।
///
/// अधिकको लागि [module-level documentation](self) हेर्नुहोस्।
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// कोर prelude को २०१ version संस्करण।
///
/// अधिकको लागि [module-level documentation](self) हेर्नुहोस्।
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// कोर prelude को २०२१ संस्करण।
///
/// अधिकको लागि [module-level documentation](self) हेर्नुहोस्।
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: थप चीजहरू थप्नुहोस्।
}