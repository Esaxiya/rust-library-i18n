/// `*v` जस्तै, अपरिवर्तनीय डिरेफरेन्स कार्यका लागि प्रयोग गरिएको।
///
/// अपरिवर्तनीय सन्दर्भमा (unary) `*` अपरेटरको साथ स्पष्ट डेरेफरेन्स अपरेशनको लागि प्रयोग हुनुको साथै, `Deref` पनि धेरै जसो परिस्थितिहरूमा कम्पाइलरले स्पष्ट रूपमा प्रयोग गर्दछ।
/// यस संयन्त्रलाई ['`Deref` coercion'][more] भनिन्छ।
/// परिवर्तनीय सन्दर्भमा, [`DerefMut`] प्रयोग गरियो।
///
/// स्मार्ट पोइन्टर्सको लागि `Deref` कार्यान्वयन गर्दा पछाडि डाटा पहुँच गर्न सजिलो हुन्छ, त्यसैले गर्दा उनीहरू `Deref` कार्यान्वयन गर्छन्।
/// अर्कोतर्फ, `Deref` र [`DerefMut`] सम्बन्धी नियमहरू स्मार्ट सूचकहरूको समायोजनको लागि विशेष रूपमा डिजाइन गरिएको थियो।
/// यसको कारणले,**`डेरेफ स्मार्ट स्मार्ट पोइन्टर्स** को लागी मात्र लागू गर्नुपर्दछ भ्रमबाट बच्न।
///
/// समान कारणका लागि,**यो trait कहिल्यै असफल हुन्न**।डिरेफरेन्सिंगको बेला असफलता अत्यधिक भ्रमित हुन सक्छ जब `Deref` निहित रूपमा आह्वान गरिएको छ।
///
/// # `Deref` जबरजस्ती मा अधिक
///
/// यदि `T` ले `Deref<Target = U>` लागू गर्दछ, र `x` `T` प्रकारको मान हो भने, तब:
///
/// * अपरिवर्तनीय सन्दर्भमा, `*x` (जहाँ `T` न त संदर्भ हो न कच्चा सूचक हो) `* Deref::deref(&x)` बराबर हो।
/// * प्रकार `&T` का मानहरू `&U` प्रकारका मानहरूमा जबरजस्ती गरिन्छ
/// * `T` स्पष्ट रूपमा `U` प्रकारको सबै (immutable) विधिहरू लागू गर्दछ।
///
/// अधिक विवरणहरूको लागि, [the chapter in *The Rust Programming Language*][book] साथै [the dereference operator][ref-deref-op], [method resolution] र [type coercions] मा सन्दर्भ सेक्सनको भ्रमण गर्नुहोस्।
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// एकल फाँटको साथ संरचना जुन संरचनालाई डेरेन्फरेसन गरेर पहुँचयोग्य छ।
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// डिरेफरेन्स पछि नतिजा प्रकार।
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// मान विचार गर्छ।
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// म्यूटेबल डिरेफरेन्सिंग अपरेसनहरूको लागि प्रयोग गरियो, जस्तै `*v = 1;` मा।
///
/// (unary) `*` अपरेटरको साथ परिवर्तनीय सन्दर्भमा स्पष्ट डिरेफरेन्सिंग अपरेशनको लागि प्रयोग हुनुको साथै, `DerefMut` पनि धेरै जसो परिस्थितिहरूमा कम्पाइलरले स्पष्ट रूपमा प्रयोग गर्दछ।
/// यस संयन्त्रलाई ['`Deref` coercion'][more] भनिन्छ।
/// अपरिवर्तनीय सन्दर्भमा, [`Deref`] प्रयोग गरियो।
///
/// स्मार्ट पोइन्टर्सको लागि `DerefMut` कार्यान्वयन गर्दा तिनीहरूको पछाडि डाटा परिवर्तन गर्न सजिलो हुन्छ, त्यसैले किन उनीहरू `DerefMut` कार्यान्वयन गर्छन्।
/// अर्कोतर्फ, [`Deref`] र `DerefMut` सम्बन्धी नियमहरू स्मार्ट सूचकहरूको समायोजनको लागि विशेष रूपमा डिजाइन गरिएको थियो।
/// यसको कारणले,**`DerefMut` केवल स्मार्ट पोइन्टर्स** को लागु लागू गर्नुपर्नेछ भ्रमबाट जोगिनका लागि।
///
/// समान कारणका लागि,**यो trait कहिल्यै असफल हुन्न**।डिरेफरेन्सिंगको बेला असफलता अत्यधिक भ्रमित हुन सक्छ जब `DerefMut` निहित रूपमा आह्वान गरिएको छ।
///
/// # `Deref` जबरजस्ती मा अधिक
///
/// यदि `T` ले `DerefMut<Target = U>` लागू गर्दछ, र `x` `T` प्रकारको मान हो भने, तब:
///
/// * परिवर्तनीय सन्दर्भमा, `*x` (जहाँ `T` न त संदर्भ हो न कच्चा सूचक हो) `* DerefMut::deref_mut(&mut x)` बराबर हो।
/// * प्रकार `&mut T` का मानहरू `&mut U` प्रकारका मानहरूमा जबरजस्ती गरिन्छ
/// * `T` स्पष्ट रूपमा `U` प्रकारको सबै (mutable) विधिहरू लागू गर्दछ।
///
/// अधिक विवरणहरूको लागि, [the chapter in *The Rust Programming Language*][book] साथै [the dereference operator][ref-deref-op], [method resolution] र [type coercions] मा सन्दर्भ सेक्सनको भ्रमण गर्नुहोस्।
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// एकल फिल्डको साथ एक स्ट्रक्चर जुन स्ट्रिक्ट डिरेफरेन्सिंग द्वारा परिमार्जन योग्य छ।
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// परिवर्तन मानको मूल्य
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// `arbitrary_self_types` सुविधाविना स्ट्रिक्ट मेथड रिसीभरको रूपमा प्रयोग गर्न सकिन्छ भनेर सic्केत गर्दछ।
///
/// यो x01X, `Rc<T>`, `&T`, र `Pin<P>` जस्तै stdlib सूचक प्रकार द्वारा कार्यान्वयन गरिएको छ।
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}