/// अपरिवर्तनीय सन्दर्भमा (`container[index]`) अनुक्रमणिकाको लागि प्रयोग।
///
/// `container[index]` वास्तवमा `*container.index(index)` को लागि सिन्टेटिक चिनी हो, तर केवल जब एक अपरिवर्तनीय मानको रूपमा प्रयोग गरिन्छ।
/// यदि एक म्यूटेबल मान अनुरोध गरियो, यसको सट्टामा [`IndexMut`] प्रयोग गरिन्छ।
/// यसले `let value = v[index]` जस्ता राम्रा चीजहरूलाई अनुमति दिन्छ यदि `value` प्रकार [`Copy`] X लागू गर्दछ।
///
/// # Examples
///
/// निम्न उदाहरणले `Index` लाई केवल पढ्न-मात्र `NucleotideCount` कन्टेनरमा लागू गर्दछ, व्यक्तिगत गणनालाई अनुक्रमणिका सिन्ट्याक्सको साथ पुन: प्राप्त गर्न सक्षम पार्दछ।
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// अनुक्रमणिका पछि फर्काइएको प्रकार।
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// अनुक्रमणिका (`container[index]`) सञ्चालन गर्दछ।
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// Xbox X लाई अनुक्रमणिका अपर्याप्त सन्दर्भमा प्रयोग गर्न सकिन्छ।
///
/// `container[index]` वास्तवमा `*container.index_mut(index)` को लागि सिन्टेटिक चिनी हो, तर मात्र एक म्यूटेबल मानको रूपमा प्रयोग गर्दा।
/// यदि एक परिवर्तनीय मान अनुरोध गरियो भने, यसको सट्टामा [`Index`] trait प्रयोग गरिन्छ।
/// यसले राम्रा चीजहरूलाई अनुमति दिन्छ जस्तै `v[index] = value`।
///
/// # Examples
///
/// एक `Balance` संरचना को एक धेरै साधारण कार्यान्वयन जुन दुई पक्षहरू छन्, जहाँ प्रत्येक पारस्परिक र अस्थिर अनुक्रमित गर्न सकिन्छ।
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // यस अवस्थामा, `balance[Side::Right]` `*balance.index(Side::Right)` को लागी चिनी हो, किनकि हामी केवल*`balance[Side::Right]` मात्र पढ्दैछौं, यसलाई लेख्दैनौं।
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // यद्यपि यस अवस्थामा `balance[Side::Left]` `*balance.index_mut(Side::Left)` का लागि चिनी हो, किनकि हामी `balance[Side::Left]` लेख्दैछौं।
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// म्यूटेबल अनुक्रमणिका (`container[index]`) अपरेशन प्रदर्शन गर्दछ।
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}