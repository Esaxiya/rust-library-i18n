use crate::ops::Try;

/// यो अपरेशनलाई बताउन प्रयोग गरीन्छ कि यो चाँडै निस्कन्छ वा सामान्य रूपमा जान्छ।
///
/// यो चीजहरूको पर्दाफाश गर्दा प्रयोग गरिन्छ (जस्तै ग्राफ ट्राभर्सल वा आगन्तुकहरू) जहाँ तपाईं चाहानुहुन्छ प्रयोगकर्ता छिटो बाहिर निस्कन छनौट गर्न सक्षम होस्।
/// एनम भएकोले यसलाई स्पष्ट बनाउँदछ-कुनै आश्चर्यको कुरा होइन "wait, what did `false` mean again?"-र मान सहित अनुमति दिन्छ।
///
/// # Examples
///
/// [`Iterator::try_for_each`] बाट प्रारम्भिक-प्रस्थान:
///
/// ```
/// #![feature(control_flow_enum)]
/// use std::ops::ControlFlow;
///
/// let r = (2..100).try_for_each(|x| {
///     if 403 % x == 0 {
///         return ControlFlow::Break(x)
///     }
///
///     ControlFlow::Continue(())
/// });
/// assert_eq!(r, ControlFlow::Break(13));
/// ```
///
/// आधारभूत रूख traversal:
///
/// ```no_run
/// #![feature(control_flow_enum)]
/// use std::ops::ControlFlow;
///
/// pub struct TreeNode<T> {
///     value: T,
///     left: Option<Box<TreeNode<T>>>,
///     right: Option<Box<TreeNode<T>>>,
/// }
///
/// impl<T> TreeNode<T> {
///     pub fn traverse_inorder<B>(&self, mut f: impl FnMut(&T) -> ControlFlow<B>) -> ControlFlow<B> {
///         if let Some(left) = &self.left {
///             left.traverse_inorder(&mut f)?;
///         }
///         f(&self.value)?;
///         if let Some(right) = &self.right {
///             right.traverse_inorder(&mut f)?;
///         }
///         ControlFlow::Continue(())
///     }
/// }
/// ```
#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum ControlFlow<B, C = ()> {
    /// सामान्य रूपमा अपरेशनको अर्को चरणमा जानुहोस्।
    Continue(C),
    /// पछाडि चरणहरू बिना नै अपरेशनबाट बाहिर निस्कनुहोस्।
    Break(B),
    // हो, भेरियन्टको अर्डर प्रकार प्यारामिटरसँग मेल खाँदैन।
    // तिनीहरू यो क्रममा छन् ताकि `ControlFlow<A, B>` <-> `Result<B, A>` `Try` कार्यान्वयनमा एक अप-रूपान्तरण हो।
    //
}

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
impl<B, C> Try for ControlFlow<B, C> {
    type Ok = C;
    type Error = B;
    #[inline]
    fn into_result(self) -> Result<Self::Ok, Self::Error> {
        match self {
            ControlFlow::Continue(y) => Ok(y),
            ControlFlow::Break(x) => Err(x),
        }
    }
    #[inline]
    fn from_error(v: Self::Error) -> Self {
        ControlFlow::Break(v)
    }
    #[inline]
    fn from_ok(v: Self::Ok) -> Self {
        ControlFlow::Continue(v)
    }
}

impl<B, C> ControlFlow<B, C> {
    /// `true` फर्काउँछ यदि यो `Break` प्रकार हो।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// assert!(ControlFlow::<i32, String>::Break(3).is_break());
    /// assert!(!ControlFlow::<String, i32>::Continue(3).is_break());
    /// ```
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn is_break(&self) -> bool {
        matches!(*self, ControlFlow::Break(_))
    }

    /// `true` फर्काउँछ यदि यो `Continue` प्रकार हो।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// assert!(!ControlFlow::<i32, String>::Break(3).is_continue());
    /// assert!(ControlFlow::<String, i32>::Continue(3).is_continue());
    /// ```
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn is_continue(&self) -> bool {
        matches!(*self, ControlFlow::Continue(_))
    }

    /// `ControlFlow` लाई `Option` मा रूपान्तरण गर्दछ जुन `Some` हो यदि `ControlFlow` `Break` र `None` अन्यथा थियो।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// assert_eq!(ControlFlow::<i32, String>::Break(3).break_value(), Some(3));
    /// assert_eq!(ControlFlow::<String, i32>::Continue(3).break_value(), None);
    /// ```
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn break_value(self) -> Option<B> {
        match self {
            ControlFlow::Continue(..) => None,
            ControlFlow::Break(x) => Some(x),
        }
    }

    /// नक्शा `ControlFlow<B, C>` गर्न `ControlFlow<T, C>` गर्न ब्रेक मूल्य मा एक कार्य लागू गरेर यदि यो अवस्थित छ।
    ///
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn map_break<T, F>(self, f: F) -> ControlFlow<T, C>
    where
        F: FnOnce(B) -> T,
    {
        match self {
            ControlFlow::Continue(x) => ControlFlow::Continue(x),
            ControlFlow::Break(x) => ControlFlow::Break(f(x)),
        }
    }
}

impl<R: Try> ControlFlow<R, R::Ok> {
    /// `Try` कार्यान्वयन गर्ने कुनै पनि प्रकारबाट `ControlFlow` सिर्जना गर्नुहोस्।
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    #[inline]
    pub fn from_try(r: R) -> Self {
        match Try::into_result(r) {
            Ok(v) => ControlFlow::Continue(v),
            Err(v) => ControlFlow::Break(Try::from_error(v)),
        }
    }

    /// `Try` लाई कुनै पनि प्रकारको कार्यान्वयन `Try` मा रूपान्तरण गर्नुहोस्;
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    #[inline]
    pub fn into_try(self) -> R {
        match self {
            ControlFlow::Continue(v) => Try::from_ok(v),
            ControlFlow::Break(v) => v,
        }
    }
}

impl<B> ControlFlow<B, ()> {
    /// यो अक्सर यस्तो अवस्थामा हुन्छ कि `Continue` को साथ कुनै मानको आवश्यक पर्दैन, त्यसैले यसले `(())` टाइप नगर्न एक तरिका प्रदान गर्दछ, यदि तपाईं यसलाई प्राथमिकतामा चाहनुहुन्छ भने।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// let mut partial_sum = 0;
    /// let last_used = (1..10).chain(20..25).try_for_each(|x| {
    ///     partial_sum += x;
    ///     if partial_sum > 100 { ControlFlow::Break(x) }
    ///     else { ControlFlow::CONTINUE }
    /// });
    /// assert_eq!(last_used.break_value(), Some(22));
    /// ```
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub const CONTINUE: Self = ControlFlow::Continue(());
}

impl<C> ControlFlow<(), C> {
    /// `try_for_each` जस्तो एपीआईहरूलाई `Break` को साथ मानहरू आवश्यक पर्दैन, त्यसैले यो `(())` टाइप गर्नबाट बच्न एक तरिका प्रदान गर्दछ, यदि तपाईं यसलाई प्राथमिकतामा हुनुहुन्छ भने।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// let mut partial_sum = 0;
    /// (1..10).chain(20..25).try_for_each(|x| {
    ///     if partial_sum > 100 { ControlFlow::BREAK }
    ///     else { partial_sum += x; ControlFlow::CONTINUE }
    /// });
    /// assert_eq!(partial_sum, 108);
    /// ```
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub const BREAK: Self = ControlFlow::Break(());
}