/// कल अपरेटरको संस्करण जुन एक अपरिवर्तनीय रिसीभर लिन्छ।
///
/// `Fn` का उदाहरणहरू उत्परिवर्तन अवस्था बिना बारम्बार कल गर्न सकिन्छ।
///
/// *यो trait (`Fn`) [function pointers] (`fn`) का साथ भ्रमित हुनु हुँदैन।*
///
/// `Fn` क्लोजरहरू द्वारा स्वचालित रूपमा कार्यान्वयन गरिन्छ जसले क्याप्चर भेरियबल्सलाई मात्र अपरिवर्तनीय सन्दर्भ लिन्छ वा केहि पनि कब्जा गर्दैन, साथै (safe) [function pointers] (केही सावधानहरूको साथ, अधिक विवरणको लागि तिनीहरूको कागजात हेर्नुहोस्)।
///
/// थप रूपमा, कुनै पनि प्रकारको `F` को लागी `Fn`, `&F` कार्यान्वयन `Fn`,।
///
/// जुनै [`FnMut`] र [`FnOnce`] दुबै `Fn` को सुपरट्रिट हो, `Fn` को कुनै पनि उदाहरण प्यारामिटरको रूपमा प्रयोग गर्न सकिन्छ जहाँ [`FnMut`] वा [`FnOnce`] अपेक्षित छ।
///
/// `Fn` बाउन्डको रूपमा प्रयोग गर्नुहोस् जब तपाईं प्रकार्य जस्तो प्रकारको प्यारामिटर स्वीकार गर्न चाहानुहुन्छ र यसलाई बारम्बार कल गर्नुपर्दछ र उत्परिवर्तन अवस्था बिना नै (उदाहरणका लागि जब यसलाई एकसाथ कल गर्दा)।
/// यदि तपाईंलाई त्यस्ता सख्त आवश्यकताहरू आवश्यक छैन भने, [`FnMut`] वा [`FnOnce`] सीमाको रूपमा प्रयोग गर्नुहोस्।
///
/// यस शीर्षकमा केहि थप जानकारीको लागि [chapter on closures in *The Rust Programming Language*][book] हेर्नुहोस्।
///
/// नोटको `Fn` X traits (उदाहरण को लागी) को लागि विशेष वाक्यविन्यास पनि हो
/// `Fn(usize, bool) -> usize`)।यसको प्राविधिक विवरणहरूमा रुचि राख्नेहरूले [the relevant section in the *Rustonomicon*][nomicon] लाई सन्दर्भ गर्न सक्दछन्।
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## कल गर्दै
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## `Fn` प्यारामिटर प्रयोग गर्दै
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ताकि regex कि `&str: !FnMut` भरोसा गर्न सक्दछ
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// कल अपरेशन गर्दछ।
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// कल अपरेटरको संस्करण जुन एक म्यूटेबल रिसीभर लिन्छ।
///
/// `FnMut` का उदाहरणहरू बारम्बार कल गर्न सकिन्छ र राज्यलाई उत्परिवर्तन गर्न सक्दछ।
///
/// `FnMut` क्लोजरहरू द्वारा स्वचालित रूपमा लागू गरिन्छ जसले क्याप्चर भेरिएबलहरूमा म्यूटेबल सन्दर्भ लिन्छ, साथै साथै [`Fn`] कार्यान्वयन गर्ने सबै प्रकारहरू, उदाहरणका लागि, (safe) [function pointers] (किनकि `FnMut` [`Fn`] को एक सुपरट्राइट हो)।
/// थप रूपमा, कुनै पनि प्रकारको `F` को लागी `FnMut`, `&mut F` कार्यान्वयन `FnMut`,।
///
/// [`FnOnce`] `FnMut` को सुपरट्रैट हो, `FnMut` को कुनै पनि उदाहरण प्रयोग गर्न सकिन्छ जहाँ [`FnOnce`] अपेक्षित छ, र [`Fn`] `FnMut` को सबट्रेट भएकोले [`Fn`] को कुनै पनि उदाहरण प्रयोग गर्न सकिन्छ जहाँ `FnMut` अपेक्षित हुन्छ।
///
/// `FnMut` बाउन्डको रूपमा प्रयोग गर्नुहोस् जब तपाईं प्रकार्य-जस्तो प्रकारको प्यारामिटर स्वीकार गर्न चाहानुहुन्छ र यसलाई बारम्बार कल गर्न आवश्यक पर्दछ, जबकि यसले राज्यलाई म्युट गर्न अनुमति दिँदछ।
/// यदि तपाईं प्यारामिटर राज्य परिवर्तन गर्न चाहनुहुन्न भने, [`Fn`] बाउन्डको रूपमा प्रयोग गर्नुहोस्;यदि तपाईंलाई बारम्बार कल गर्न आवश्यक पर्दैन भने, [`FnOnce`] प्रयोग गर्नुहोस्।
///
/// यस शीर्षकमा केहि थप जानकारीको लागि [chapter on closures in *The Rust Programming Language*][book] हेर्नुहोस्।
///
/// नोटको `Fn` X traits (उदाहरण को लागी) को लागि विशेष वाक्यविन्यास पनि हो
/// `Fn(usize, bool) -> usize`)।यसको प्राविधिक विवरणहरूमा रुचि राख्नेहरूले [the relevant section in the *Rustonomicon*][nomicon] लाई सन्दर्भ गर्न सक्दछन्।
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## एक परस्पर कब्जा क्लोजर कल गर्दै
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## `FnMut` प्यारामिटर प्रयोग गर्दै
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ताकि regex कि `&str: !FnMut` भरोसा गर्न सक्दछ
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// कल अपरेशन गर्दछ।
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// कल अपरेटरको संस्करण जुन उप-मान रिसीभर लिन्छ।
///
/// `FnOnce` का उदाहरणहरू कल गर्न सकिन्छ, तर धेरै पटक कल गर्न मिल्दैन।यसको कारणले, यदि एक मात्र चीजको बारेमा ज्ञात मात्र यो `FnOnce` कार्यान्वयन गर्दछ भने, यो मात्र एक पटक कल गर्न सकिन्छ।
///
/// `FnOnce` क्लोजरहरू द्वारा स्वचालित रूपमा कार्यान्वयन गरिन्छ जुन क्याप्चर भ्यारीएबलहरू उपभोग गर्न सक्छ, साथै साथै [`FnMut`] कार्यान्वयन गर्ने सबै प्रकारहरू, उदाहरणका लागि, (safe) [function pointers] (किनकि `FnOnce` [`FnMut`] को एक सुपरट्राइट हो)।
///
///
/// किनकि दुबै [`Fn`] र [`FnMut`] `FnOnce` का सबट्रेटहरू छन्, [`Fn`] वा [`FnMut`] को कुनै पनि उदाहरण प्रयोग गर्न सकिन्छ जहाँ `FnOnce` अपेक्षित हुन्छ।
///
/// `FnOnce` बाउन्डको रूपमा प्रयोग गर्नुहोस् जब तपाईं प्रकार्य जस्तो प्रकारको प्यारामिटर स्वीकार गर्न चाहानुहुन्छ र मात्र एकचोटि कल गर्न आवश्यक पर्दछ।
/// यदि तपाईंलाई बारम्बार प्यारामिटर कल गर्न आवश्यक छ भने, [`FnMut`] बाउन्डको रूपमा प्रयोग गर्नुहोस्;यदि तपाईंलाई यो अवस्था परिवर्तन गर्न पनि आवश्यक पर्दछ भने, [`Fn`] प्रयोग गर्नुहोस्।
///
/// यस शीर्षकमा केहि थप जानकारीको लागि [chapter on closures in *The Rust Programming Language*][book] हेर्नुहोस्।
///
/// नोटको `Fn` X traits (उदाहरण को लागी) को लागि विशेष वाक्यविन्यास पनि हो
/// `Fn(usize, bool) -> usize`)।यसको प्राविधिक विवरणहरूमा रुचि राख्नेहरूले [the relevant section in the *Rustonomicon*][nomicon] लाई सन्दर्भ गर्न सक्दछन्।
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## `FnOnce` प्यारामिटर प्रयोग गर्दै
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` यसको क्याप्चर भ्यारीएबलहरू खान्छ, त्यसैले यो एक पटक भन्दा बढि चलाउन सकिदैन।
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // फेरि `func()` लाई आह्वान गर्ने प्रयास गर्दा `func` का लागि `use of moved value` त्रुटि फ्याँकिनेछ।
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` अब यस बिन्दुमा आह्वान गर्न सकिँदैन
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ताकि regex कि `&str: !FnMut` भरोसा गर्न सक्दछ
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// कल अपरेटर प्रयोग गरिए पछि फिर्ता प्रकार।
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// कल अपरेशन गर्दछ।
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}