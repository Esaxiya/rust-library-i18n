use crate::marker::Unsize;

/// Trait ले संकेत गर्दछ कि यो पोइन्टर वा र्यापर एकको लागि हो, जब अनसाइजिंग पोइन्टिमा प्रदर्शन गर्न सकिन्छ।
///
/// अधिक जानकारीको लागि [DST coercion RFC][dst-coerce] र [the nomicon entry on coercion][nomicon-coerce] हेर्नुहोस्।
///
/// निर्मित सूचक प्रकारका लागि, `T` मा पोइन्टर्स `U` मा सूचक गर्न बाध्य हुनेछ यदि `T: Unsize<U>` पातलो सूचकबाट फ्याट पोइन्टरमा रूपान्तरण गरेर।
///
/// अनुकूलन प्रकारहरूका लागि, यहाँ जबरजस्ती `Foo<T>` X X1X मा `CoerceUnsized<Foo<U>> for Foo<T>` को ईम्प्ली अवस्थित गराएर काम गर्दछ।
/// यस्तो इम्प्लीएल केवल तब लेख्न सकिन्छ यदि `Foo<T>` सँग केवल एकल गैर-फ्यान्टोमडाटा फिल्ड छ `T`।
/// यदि त्यो क्षेत्रको प्रकार `Bar<T>` हो, `CoerceUnsized<Bar<U>> for Bar<T>` को एक कार्यान्वयन अवस्थित हुनु पर्छ।
/// जबरजस्ती `Bar<T>` फिल्डलाई `Bar<U>` मा जबरजस्ती गरेर र बाँकी फिल्डहरू X0 `Foo<T>` बाट `Foo<U>` सिर्जना गर्न भर्न कार्य गर्दछ।
/// यसले प्रभावकारी रूपमा सूचक फिल्डमा ड्रिल गर्दछ र त्यो बाध्य पार्छ।
///
/// सामान्यतया, स्मार्ट सूचकहरूको लागि तपाईंले `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` कार्यान्वयन गर्नुहुनेछ, वैकल्पिक `?Sized` `T` मा नै सीमित छ।
/// रैपर प्रकारहरूको लागि जुन `T` प्रत्यक्ष रूपमा `Cell<T>` र `RefCell<T>` एम्बेड गर्दछ, तपाईं सीधा `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` कार्यान्वयन गर्न सक्नुहुनेछ।
///
/// यसले `Cell<Box<T>>` कार्य जस्तो प्रकारको जबरजस्ती गर्न दिनेछ।
///
/// [`Unsize`][unsize] प्रकार मार्क गर्न प्रयोग गरिन्छ जुन सूचकको पछाडि DSTs मा जबरजस्ती गर्न सकिन्छ।यो कम्पाइलरद्वारा स्वचालित रूपमा लागू गरियो।
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * कन्स्ट U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * कन्स्ट U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *कन्स्ट टी->* कन्स्ट यू
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// यो वस्तुको सुरक्षाको लागि प्रयोग गरीन्छ, कि मेथिडको रिसिभर प्रकार पठाउन सकिन्छ भनेर जाँच गर्न।
///
/// trait को एक उदाहरण कार्यान्वयन:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *कन्स्ट टी->* कन्स्ट यू
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}