//! ओभरलोड योग्य अपरेटरहरू।
//!
//! यी traits कार्यान्वयन गर्नाले तपाईंलाई केहि अपरेटरहरूलाई ओभरलोड गर्न अनुमति दिन्छ।
//!
//! केहि traits prelude द्वारा आयात गरियो, त्यसैले तिनीहरू प्रत्येक Rust कार्यक्रममा उपलब्ध छन्।traits द्वारा समर्थित केवल अपरेटरहरू ओभरलोड गर्न सकिन्छ।
//! उदाहरण को लागी, अतिरिक्त अपरेटर (`+`) लाई [`Add`] trait को माध्यमबाट ओभरलोड गर्न सकिन्छ, तर किनभने असाइनमेन्ट अपरेटर (`=`) को समर्थन trait छैन, यसको अर्थशास्त्र ओभरलोडिंगको कुनै तरीका छैन।
//! थप रूपमा, यो मोड्युलले नयाँ अपरेटरहरू सिर्जना गर्न कुनै संयन्त्र प्रदान गर्दैन।
//! यदि ट्रिटलेस ओभरलोडिंग वा कस्टम अपरेटरहरू आवश्यक छन्, तपाईंले Rust को वाक्य रचना विस्तार गर्न म्याक्रो वा कम्पाइलर प्लगइनहरू तिर हेर्नु पर्छ।
//!
//! अपरेटर traits को कार्यान्वयन तिनीहरूको सामान्य संदर्भ र [operator precedence] लाई ध्यानमा राख्दै, उनीहरू सम्बन्धित सन्दर्भमा आश्चर्यजनक हुनुपर्दैन।
//! उदाहरणको लागि, [`Mul`] कार्यान्वयन गर्दा, अपरेशनसँग गुणनको केहि समानता हुनुपर्दछ (र अपेक्षित सम्पत्तीहरू जस्तै एसोसिएटिभीटिको साझेदारी गर्नुहोस्)।
//!
//! नोट गर्नुहोस् कि `&&` र `||` अपरेटरहरू शॉर्ट-सर्किट, अर्थात्, तिनीहरूले केवल आफ्नो दोस्रो अपरेन्ड मूल्यांकन गर्दछ यदि यसले परिणाममा योगदान गर्दछ।किनकि यो व्यवहार traits द्वारा लागू गर्न योग्य छैन, `&&` र `||` अधिभार योग्य अपरेटरहरूको रूपमा समर्थित छैनन्।
//!
//! धेरै अपरेटरहरु मान द्वारा आफ्नो अपरेन्डहरु लिन।निर्मित प्रकार समावेशी गैर-सामान्य संदर्भहरूमा, यो सामान्यतया समस्या होईन।
//! यद्यपि जेनेरिक कोडमा यी अपरेटरहरू प्रयोग गर्नका लागि ध्यान दिन आवश्यक छ यदि मानहरूको पुन: उपयोग गर्नुपर्दछ अपरेटरहरूले उपभोग गर्न दिँदा यसको बिरूद्ध।एउटा विकल्प कहिलेकाँही [`clone`] प्रयोग गर्नु हो।
//! अर्को विकल्प भनेको सन्दर्भहरूको लागि अतिरिक्त अपरेटर कार्यान्वयन प्रदान गर्ने प्रकारहरूमा भर पर्नु हो।
//! उदाहरण को लागी, एक उपयोगकर्ता परिभाषित प्रकार `T` को लागी जसलाई थप समर्थन गर्छ, `T` र `T` दुबै traits [`Add<T>`][`Add`] र [`Add<&T>`][`Add`] कार्यान्वयन गर्नु राम्रो विचार हो ताकि जेनेरिक कोड अनावश्यक क्लोनिंग बिना लेख्न सकिन्छ।
//!
//!
//! # Examples
//!
//! यो उदाहरणले `Point` संरचना सिर्जना गर्दछ जसले [`Add`] र [`Sub`] कार्यान्वयन गर्दछ, र त्यसपछि दुई `पोइन्ट्स जोड र घटाउ प्रदर्शन गर्दछ।
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! उदाहरण कार्यान्वयनको लागि प्रत्येक trait का लागि कागजात हेर्नुहोस्।
//!
//! [`Fn`], [`FnMut`], र [`FnOnce`] traits प्रकारहरू द्वारा कार्यान्वयन गरिन्छ जुन प्रकार्यहरू जस्ता आव्हान गर्न सकिन्छ।नोट गर्नुहोस् कि [`Fn`] ले `&self` लिन्छ, [`FnMut`] ले `&mut self` र [`FnOnce`] ले `self` लिन्छ।
//! यी तीन प्रकारका विधिहरू अनुरूप छन् जुन ईन्स्टान्समा आमन्त्रित गर्न सकिन्छ: कल-द्वारा-सन्दर्भ, कल-द्वारा-म्युटेबल-सन्दर्भ, र कल-द्वारा-मान।
//! यी traits को सब भन्दा सामान्य प्रयोग उच्च स्तरीय कार्यहरूमा सीमाको रूपमा कार्य गर्नु हो जुन कार्यहरू वा क्लोजरहरू आर्गुमेन्टको रूपमा लिन्छ।
//!
//! एक प्यारामिटरको रूपमा [`Fn`] लिदै:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! एक प्यारामिटरको रूपमा [`FnMut`] लिदै:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! एक प्यारामिटरको रूपमा [`FnOnce`] लिदै:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` यसको क्याप्चर भ्यारीएबलहरू खान्छ, त्यसैले यो एक पटक भन्दा बढि चलाउन सकिदैन
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // फेरि `func()` लाई आह्वान गर्ने प्रयास गर्दा `func` का लागि `use of moved value` त्रुटि फ्याँकिनेछ
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` अब यस बिन्दुमा आह्वान गर्न सकिँदैन
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;