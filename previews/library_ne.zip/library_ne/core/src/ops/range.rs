use crate::fmt;
use crate::hash::Hash;

/// एक अनबाउन्ड दायरा (`..`)।
///
/// `RangeFull` मुख्य रूपमा [slicing index] को रूपमा प्रयोग गरीन्छ, यसको शर्टह्यान्ड `..` हो।
/// यसले [`Iterator`] को रूपमा काम गर्न सक्दैन किनकि यससँग सुरूवात बिन्दु छैन।
///
/// # Examples
///
/// `..` सिन्ट्याक्स एक `RangeFull` हो:
///
/// ```
/// assert_eq!((..), std::ops::RangeFull);
/// ```
///
/// योसँग [`IntoIterator`] कार्यान्वयन छैन, त्यसैले तपाईं यसलाई `for` लूपमा सिधा प्रयोग गर्न सक्नुहुन्न।
/// यसले कम्पाइल गर्ने छैन:
///
/// ```compile_fail,E0277
/// for i in .. {
///     // ...
/// }
/// ```
///
/// [slicing index] को रूपमा प्रयोग गरिएको, `RangeFull` स्लाइसको रूपमा पूर्ण एरे उत्पादन गर्दछ।
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]); // यो `RangeFull` हो
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeFull"]
#[doc(alias = "..")]
#[derive(Copy, Clone, Default, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFull;

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for RangeFull {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")
    }
}

/// एक (half-open) दायरा समावेशी रूपमा तल र विशेष रूपमा (`start..end`) माथि सीमित छ।
///
///
/// दायरा `start..end` ले `start <= x < end` का साथ सबै मानहरू समावेश गर्दछ।
/// यो खाली छ यदि `start >= end`।
///
/// # Examples
///
/// `start..end` सिन्ट्याक्स एक `Range` हो:
///
/// ```
/// assert_eq!((3..5), std::ops::Range { start: 3, end: 5 });
/// assert_eq!(3 + 4 + 5, (3..6).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]); // यो एक `Range` हो
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
#[lang = "Range"]
#[doc(alias = "..")]
#[derive(Clone, Default, PartialEq, Eq, Hash)] // प्रतिलिपि गरिएको छैन-#27186 हेर्नुहोस्
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Range<Idx> {
    /// दायरा (inclusive) को तल्लो सीमा।
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
    /// (exclusive) दायराको माथिल्लो सीमा।
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for Range<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> Range<Idx> {
    /// `true` फर्काउँछ यदि `item` दायरामा समावेश छ।
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).contains(&2));
    /// assert!( (3..5).contains(&3));
    /// assert!( (3..5).contains(&4));
    /// assert!(!(3..5).contains(&5));
    ///
    /// assert!(!(3..3).contains(&3));
    /// assert!(!(3..2).contains(&3));
    ///
    /// assert!( (0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// `true` फर्काउँछ यदि दायरामा कुनै आईटमहरू छैन।
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).is_empty());
    /// assert!( (3..3).is_empty());
    /// assert!( (3..2).is_empty());
    /// ```
    ///
    /// दायरा खाली छ यदि दुबै पक्ष अतुलनीय छ।
    ///
    /// ```
    /// assert!(!(3.0..5.0).is_empty());
    /// assert!( (3.0..f32::NAN).is_empty());
    /// assert!( (f32::NAN..5.0).is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    pub fn is_empty(&self) -> bool {
        !(self.start < self.end)
    }
}

/// दायरा केवल समावेशी रूपमा (`start..`) सीमित छ।
///
/// `RangeFrom` `start..` `x >= start` का साथ सबै मानहरू समावेश गर्दछ।
///
/// *नोट*: [`Iterator`] कार्यान्वयनमा ओभरफ्लो (जब समावेश डाटा प्रकारले यसको संख्यात्मक सीमामा पुग्छ) panic, र्‍याप, वा संतृप्त गर्न अनुमति दिईन्छ।
/// यो व्यवहार [`Step`] trait को कार्यान्वयनद्वारा परिभाषित गरिएको छ।
/// आदिम पूर्णांकहरूको लागि, यसले सामान्य नियमहरूको पालना गर्दछ, र ओभरफ्लो जाँच प्रोफाइललाई आदर गर्दछ (डिबगमा panic, रिलीजमा लपेट्नुहोस्)।
/// यो पनि नोट गर्नुहोस् कि ओभरफ्लो तपाईंले सोचेभन्दा पहिले देखिएको हुन्छ: ओभरफ्लो `next` मा कलमा हुन्छ जसले अधिकतम मान दिन्छ, दायरा अर्को राज्य उपजको लागि राज्यमा सेट गर्नुपर्नेछ।
///
///
/// [`Step`]: crate::iter::Step
///
/// # Examples
///
/// `start..` सिन्ट्याक्स एक `RangeFrom` हो:
///
/// ```
/// assert_eq!((2..), std::ops::RangeFrom { start: 2 });
/// assert_eq!(2 + 3 + 4, (2..).take(3).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]); // यो एक `RangeFrom` हो
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
///
///
#[lang = "RangeFrom"]
#[doc(alias = "..")]
#[derive(Clone, PartialEq, Eq, Hash)] // प्रतिलिपि गरिएको छैन-#27186 हेर्नुहोस्
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFrom<Idx> {
    /// दायरा (inclusive) को तल्लो सीमा।
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeFrom<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeFrom<Idx> {
    /// `true` फर्काउँछ यदि `item` दायरामा समावेश छ।
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..).contains(&2));
    /// assert!( (3..).contains(&3));
    /// assert!( (3..).contains(&1_000_000_000));
    ///
    /// assert!( (0.0..).contains(&0.5));
    /// assert!(!(0.0..).contains(&f32::NAN));
    /// assert!(!(f32::NAN..).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// दायरा केवल (`..end`) माथि मात्र सीमित छ।
///
/// `RangeTo` `..end` `x < end` का साथ सबै मानहरू समावेश गर्दछ।
/// यसले [`Iterator`] को रूपमा काम गर्न सक्दैन किनकि यससँग सुरूवात बिन्दु छैन।
///
/// # Examples
///
/// `..end` सिन्ट्याक्स एक `RangeTo` हो:
///
/// ```
/// assert_eq!((..5), std::ops::RangeTo { end: 5 });
/// ```
///
/// योसँग [`IntoIterator`] कार्यान्वयन छैन, त्यसैले तपाईं यसलाई `for` लूपमा सिधा प्रयोग गर्न सक्नुहुन्न।
/// यसले कम्पाइल गर्ने छैन:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeTo<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..5 {
///     // ...
/// }
/// ```
///
/// जब [slicing index] को रूपमा प्रयोग हुन्छ, `RangeTo` `end` द्वारा संकेतित अनुक्रमणिका अघि सबै एर्रे एलिमेन्टसको स्लाइस उत्पादन गर्दछ।
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]); // यो एक `RangeTo` हो
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeTo"]
#[doc(alias = "..")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeTo<Idx> {
    /// (exclusive) दायराको माथिल्लो सीमा।
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeTo<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeTo<Idx> {
    /// `true` फर्काउँछ यदि `item` दायरामा समावेश छ।
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..5).contains(&-1_000_000_000));
    /// assert!( (..5).contains(&4));
    /// assert!(!(..5).contains(&5));
    ///
    /// assert!( (..1.0).contains(&0.5));
    /// assert!(!(..1.0).contains(&f32::NAN));
    /// assert!(!(..f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// (`start..=end`) मुनि र माथी समावेशी दायरा।
///
/// `RangeInclusive` `start..=end` `x >= start` र `x <= end` को साथ सबै मानहरू समावेश गर्दछ।यो खाली छ `start <= end` नभएसम्म
///
/// यो इरेटर [fused] हो, तर एक्सरेसन समाप्त भएपछि `start` र `end` का विशिष्ट मानहरू **अनिर्दिष्ट**[`.is_empty()`] बाहेक `true` फिर्ता हुनेछ जब कुनै अधिक मानहरू उत्पादन हुँदैन।
///
///
/// [fused]: crate::iter::FusedIterator
/// [`.is_empty()`]: RangeInclusive::is_empty
///
/// # Examples
///
/// `start..=end` सिन्ट्याक्स एक `RangeInclusive` हो:
///
/// ```
/// assert_eq!((3..=5), std::ops::RangeInclusive::new(3, 5));
/// assert_eq!(3 + 4 + 5, (3..=5).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]); // यो एक `RangeInclusive` हो
/// ```
///
///
#[lang = "RangeInclusive"]
#[doc(alias = "..=")]
#[derive(Clone, PartialEq, Eq, Hash)] // प्रतिलिपि गरिएको छैन-#27186 हेर्नुहोस्
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeInclusive<Idx> {
    // नोट गर्नुहोस् कि यहाँ क्षेत्रहरू future मा प्रतिनिधित्व परिवर्तन गर्न अनुमति दिन सार्वजनिक छैनन्;विशेष रूपमा, जब हामी एक्सियस एक्स एक्स एक्स एक्सपोज गर्न सक्दछौं, तिनीहरूलाई परिमार्जन बिना (future/current) निजी क्षेत्रहरू गलत व्यवहारमा निम्त्याउन सक्छ, त्यसैले हामी त्यो मोड समर्थन गर्न चाहँदैनौं।
    //
    //
    //
    //
    pub(crate) start: Idx,
    pub(crate) end: Idx,

    // यो क्षेत्र हो:
    //  - `false` निर्माणमा
    //  - `false` जब इन्टरेसनले एलिमेन्ट उत्पन्न गरेको छ र ईटरेटर थकित छैन
    //  - `true` जब पुनरावृत्ति इटररेटर निकासको लागि प्रयोग गरिएको छ
    //
    // आंशिक ओआरडी वा विशेषज्ञता बिना आंशिकEq र ह्यास समर्थन गर्न यो आवश्यक छ।
    pub(crate) exhausted: bool,
}

impl<Idx> RangeInclusive<Idx> {
    /// नयाँ समावेशी दायरा सिर्जना गर्दछ।`start..=end` लेखनको बराबरी।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ops::RangeInclusive;
    ///
    /// assert_eq!(3..=5, RangeInclusive::new(3, 5));
    /// ```
    #[lang = "range_inclusive_new"]
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    #[rustc_promotable]
    #[rustc_const_stable(feature = "const_range_new", since = "1.32.0")]
    pub const fn new(start: Idx, end: Idx) -> Self {
        Self { start, end, exhausted: false }
    }

    /// दायरा (inclusive) को तल्लो सीमा फर्काउँछ।
    ///
    /// पुनरावृत्तिको लागि समावेशी दायरा प्रयोग गर्दा, `start()` र [`end()`] को मानहरू पुनरावृत्ति समाप्त भएपछि निर्दिष्ट नगरिएका हुन्छन्।
    /// समावेशी दायरा खाली छ कि छैन भनेर निर्धारण गर्न, `start() > end()` तुलनाको सट्टा [`is_empty()`] विधि प्रयोग गर्नुहोस्।
    ///
    /// Note: यस विधिबाट फर्काएको मान निश्चित गरीएको छैन दायरा थकाइलाई पुनरावृत गरिसकेपछि।
    ///
    /// [`end()`]: RangeInclusive::end
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).start(), &3);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn start(&self) -> &Idx {
        &self.start
    }

    /// (inclusive) दायराको माथिल्लो सीमा फर्काउँछ।
    ///
    /// पुनरावृत्तिको लागि समावेशी दायरा प्रयोग गर्दा, [`start()`] र `end()` को मानहरू पुनरावृत्ति समाप्त भएपछि निर्दिष्ट नगरिएका हुन्छन्।
    /// समावेशी दायरा खाली छ कि छैन भनेर निर्धारण गर्न, `start() > end()` तुलनाको सट्टा [`is_empty()`] विधि प्रयोग गर्नुहोस्।
    ///
    /// Note: यस विधिबाट फर्काएको मान निश्चित गरीएको छैन दायरा थकाइलाई पुनरावृत गरिसकेपछि।
    ///
    /// [`start()`]: RangeInclusive::start
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).end(), &5);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn end(&self) -> &Idx {
        &self.end
    }

    /// `RangeInclusive` मा निर्माण गर्दछ (तल्लो बाउन्ड, अपर (inclusive) बाउन्ड)।
    ///
    /// Note: यस विधिबाट फर्काएको मान निश्चित गरीएको छैन दायरा थकाइलाई पुनरावृत गरिसकेपछि।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).into_inner(), (3, 5));
    /// ```
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    pub fn into_inner(self) -> (Idx, Idx) {
        (self.start, self.end)
    }
}

impl RangeInclusive<usize> {
    /// `SliceIndex` कार्यान्वयनको लागि एक विशेष `Range` मा रूपान्तरण।
    /// कलर `end == usize::MAX` सँग डील गर्न जिम्मेदार छ।
    #[inline]
    pub(crate) fn into_slice_range(self) -> Range<usize> {
        // यदि हामी थकित छैनौं भने, हामी केवल `start..end + 1` टुक्रा गर्न चाहन्छौं।
        // यदि हामी थकित छौं भने, तब `end + 1..end + 1` को साथ काट्नुले हामीलाई खाली दायरा दिन्छ जुन अझै अन्तको पोइन्टको लागि सीमा-जाँचहरूको अधीनमा छ।
        //
        let exclusive_end = self.end + 1;
        let start = if self.exhausted { exclusive_end } else { self.start };
        start..exclusive_end
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        if self.exhausted {
            write!(fmt, " (exhausted)")?;
        }
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeInclusive<Idx> {
    /// `true` फर्काउँछ यदि `item` दायरामा समावेश छ।
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).contains(&2));
    /// assert!( (3..=5).contains(&3));
    /// assert!( (3..=5).contains(&4));
    /// assert!( (3..=5).contains(&5));
    /// assert!(!(3..=5).contains(&6));
    ///
    /// assert!( (3..=3).contains(&3));
    /// assert!(!(3..=2).contains(&3));
    ///
    /// assert!( (0.0..=1.0).contains(&1.0));
    /// assert!(!(0.0..=1.0).contains(&f32::NAN));
    /// assert!(!(0.0..=f32::NAN).contains(&0.0));
    /// assert!(!(f32::NAN..=1.0).contains(&1.0));
    /// ```
    ///
    /// यो विधि जहिले पनि `false` फिर्ता पछि समाप्त हुन्छ:
    ///
    /// ```
    /// let mut r = 3..=5;
    /// assert!(r.contains(&3) && r.contains(&5));
    /// for _ in r.by_ref() {}
    /// // सटीक क्षेत्र मानहरू यहाँ अनिर्दिष्ट छन्
    /// assert!(!r.contains(&3) && !r.contains(&5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// `true` फर्काउँछ यदि दायरामा कुनै आईटमहरू छैन।
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).is_empty());
    /// assert!(!(3..=3).is_empty());
    /// assert!( (3..=2).is_empty());
    /// ```
    ///
    /// दायरा खाली छ यदि दुबै पक्ष अतुलनीय छ।
    ///
    /// ```
    /// assert!(!(3.0..=5.0).is_empty());
    /// assert!( (3.0..=f32::NAN).is_empty());
    /// assert!( (f32::NAN..=5.0).is_empty());
    /// ```
    ///
    /// यो विधिले पुनरावृत्ति समाप्त भएपछि `true` फर्काउँछ:
    ///
    /// ```
    /// let mut r = 3..=5;
    /// for _ in r.by_ref() {}
    /// // सटीक क्षेत्र मानहरू यहाँ अनिर्दिष्ट छन्
    /// assert!(r.is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    #[inline]
    pub fn is_empty(&self) -> bool {
        self.exhausted || !(self.start <= self.end)
    }
}

/// दायरा केवल समावेशी रूपमा (`..=end`) माथि सीमित।
///
/// `RangeToInclusive` `..=end` `x <= end` का साथ सबै मानहरू समावेश गर्दछ।
/// यसले [`Iterator`] को रूपमा काम गर्न सक्दैन किनकि यससँग सुरूवात बिन्दु छैन।
///
/// # Examples
///
/// `..=end` सिन्ट्याक्स एक `RangeToInclusive` हो:
///
/// ```
/// assert_eq!((..=5), std::ops::RangeToInclusive{ end: 5 });
/// ```
///
/// योसँग [`IntoIterator`] कार्यान्वयन छैन, त्यसैले तपाईं यसलाई `for` लूपमा सिधा प्रयोग गर्न सक्नुहुन्न।यसले कम्पाइल गर्ने छैन:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeToInclusive<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..=5 {
///     // ...
/// }
/// ```
///
/// जब [slicing index] को रूपमा प्रयोग हुन्छ, `RangeToInclusive` ले सबै एर्रे एलिमेन्टसको स्लाइस उत्पादन गर्दछ र `end` द्वारा संकेतित अनुक्रमणिका सहित।
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]); // यो एक `RangeToInclusive` हो
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
///
#[lang = "RangeToInclusive"]
#[doc(alias = "..=")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeToInclusive<Idx> {
    /// (inclusive) दायराको माथिल्लो सीमा
    #[stable(feature = "inclusive_range", since = "1.26.0")]
    pub end: Idx,
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeToInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeToInclusive<Idx> {
    /// `true` फर्काउँछ यदि `item` दायरामा समावेश छ।
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..=5).contains(&-1_000_000_000));
    /// assert!( (..=5).contains(&5));
    /// assert!(!(..=5).contains(&6));
    ///
    /// assert!( (..=1.0).contains(&1.0));
    /// assert!(!(..=1.0).contains(&f32::NAN));
    /// assert!(!(..=f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

// RangeToInclusive<Idx>बाट उत्प्रेरित गर्न सक्दैन <RangeTo<Idx>> किनभने अन्डरफ्लो (..0).into() को साथ सम्भव छ
//

/// कुञ्जीहरूको दायराको अन्त्य बिन्दु।
///
/// # Examples
///
/// `बाउन्ड्स दायरा अन्त बिन्दु हुन्:
///
/// ```
/// use std::ops::Bound::*;
/// use std::ops::RangeBounds;
///
/// assert_eq!((..100).start_bound(), Unbounded);
/// assert_eq!((1..12).start_bound(), Included(&1));
/// assert_eq!((1..12).end_bound(), Excluded(&12));
/// ```
///
/// [`BTreeMap::range`] को आर्गुमेन्टको रूपमा `Bound`s को ट्युपल प्रयोग गर्दै।
/// नोट गर्नुहोस् कि प्राय जसो केसहरूमा, यसको सट्टामा दायरा सिन्ट्याक्स (`1..5`) प्रयोग गर्नु राम्रो हो।
///
/// ```
/// use std::collections::BTreeMap;
/// use std::ops::Bound::{Excluded, Included, Unbounded};
///
/// let mut map = BTreeMap::new();
/// map.insert(3, "a");
/// map.insert(5, "b");
/// map.insert(8, "c");
///
/// for (key, value) in map.range((Excluded(3), Included(8))) {
///     println!("{}: {}", key, value);
/// }
///
/// assert_eq!(Some((&3, &"a")), map.range((Unbounded, Included(5))).next());
/// ```
///
/// [`BTreeMap::range`]: ../../std/collections/btree_map/struct.BTreeMap.html#method.range
#[stable(feature = "collections_bound", since = "1.17.0")]
#[derive(Clone, Copy, Debug, Hash, PartialEq, Eq)]
pub enum Bound<T> {
    /// समावेशी सीमा।
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Included(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// एक विशिष्ट सीमा।
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Excluded(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// एक असीम अन्त्यबिन्दु।दर्शाउँछ कि यस दिशा मा कुनै बाध्य छैन।
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Unbounded,
}

#[unstable(feature = "bound_as_ref", issue = "80996")]
impl<T> Bound<T> {
    /// `&Bound<T>` बाट `Bound<&T>` मा रूपान्तरण।
    #[inline]
    pub fn as_ref(&self) -> Bound<&T> {
        match *self {
            Included(ref x) => Included(x),
            Excluded(ref x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }

    /// `&mut Bound<T>` बाट `Bound<&T>` मा रूपान्तरण।
    #[inline]
    pub fn as_mut(&mut self) -> Bound<&mut T> {
        match *self {
            Included(ref mut x) => Included(x),
            Excluded(ref mut x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }
}

impl<T: Clone> Bound<&T> {
    /// X0 `Bound<T>` मा बाउन्डको सामग्री क्लोनिंग गरेर एक `Bound<&T>` को नक्सा।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(bound_cloned)]
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((1..12).start_bound(), Included(&1));
    /// assert_eq!((1..12).start_bound().cloned(), Included(1));
    /// ```
    #[unstable(feature = "bound_cloned", issue = "61356")]
    pub fn cloned(self) -> Bound<T> {
        match self {
            Bound::Unbounded => Bound::Unbounded,
            Bound::Included(x) => Bound::Included(x.clone()),
            Bound::Excluded(x) => Bound::Excluded(x.clone()),
        }
    }
}

/// `RangeBounds` Rust को बिल्ट-इन दायरा प्रकारहरू द्वारा कार्यान्वयन गरिएको छ, दायरा सिन्ट्याक्स द्वारा `..`, `a..`, `..b`, `..=c`, `d..e`, वा `f..=g` जस्तो उत्पादन।
///
#[stable(feature = "collections_range", since = "1.28.0")]
pub trait RangeBounds<T: ?Sized> {
    /// सुरू सूचकांक बाउन्ड।
    ///
    /// `Bound` को रूपमा सुरू मूल्य फर्काउँछ।
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((..10).start_bound(), Unbounded);
    /// assert_eq!((3..10).start_bound(), Included(&3));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn start_bound(&self) -> Bound<&T>;

    /// अन्त्य सूचकांक बाध्य।
    ///
    /// `Bound` को रूपमा अन्तिम मान फर्काउँछ।
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((3..).end_bound(), Unbounded);
    /// assert_eq!((3..10).end_bound(), Excluded(&10));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn end_bound(&self) -> Bound<&T>;

    /// `true` फर्काउँछ यदि `item` दायरामा समावेश छ।
    ///
    /// # Examples
    ///
    /// ```
    /// जोर दिनुहोस्! ((3..5).contains(&4));
    /// assert!(!(3..5).contains(&2));
    ///
    /// जोर दिनुहोस्! ((0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    #[stable(feature = "range_contains", since = "1.35.0")]
    fn contains<U>(&self, item: &U) -> bool
    where
        T: PartialOrd<U>,
        U: ?Sized + PartialOrd<T>,
    {
        (match self.start_bound() {
            Included(ref start) => *start <= item,
            Excluded(ref start) => *start < item,
            Unbounded => true,
        }) && (match self.end_bound() {
            Included(ref end) => item <= *end,
            Excluded(ref end) => item < *end,
            Unbounded => true,
        })
    }
}

use self::Bound::{Excluded, Included, Unbounded};

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T: ?Sized> RangeBounds<T> for RangeFull {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        if self.exhausted {
            // जब इटरेटर थकित हुन्छ, हामीसँग सामान्यतया सुरू==अन्त्य हुन्छ, तर हामी दायरा खाली देखियोस् भन्ने चाहन्छौं, केहि पनि समावेश छैन।
            //
            Excluded(&self.end)
        } else {
            Included(&self.end)
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for (Bound<T>, Bound<T>) {
    fn start_bound(&self) -> Bound<&T> {
        match *self {
            (Included(ref start), _) => Included(start),
            (Excluded(ref start), _) => Excluded(start),
            (Unbounded, _) => Unbounded,
        }
    }

    fn end_bound(&self) -> Bound<&T> {
        match *self {
            (_, Included(ref end)) => Included(end),
            (_, Excluded(ref end)) => Excluded(end),
            (_, Unbounded) => Unbounded,
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<'a, T: ?Sized + 'a> RangeBounds<T> for (Bound<&'a T>, Bound<&'a T>) {
    fn start_bound(&self) -> Bound<&T> {
        self.0
    }

    fn end_bound(&self) -> Bound<&T> {
        self.1
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}