Panics वर्तमान थ्रेड।

यसले कार्यक्रमलाई तुरून्त समाप्त गर्ने अनुमति दिन्छ र कार्यक्रम कलरलाई प्रतिक्रिया प्रदान गर्दछ।
`panic!` जब प्रोग्राम एक अपूरणीय राज्यमा पुग्छ तब प्रयोग गर्नुपर्नेछ।

यो म्याक्रो उदाहरण कोडमा र परीक्षणहरूमा सर्तहरू सम्मिलित गर्न उत्तम तरिका हो।
`panic!` दुबै [`Option`][ounwrap] र [`Result`][runwrap] enums दुवैको `unwrap` विधिसँग नजिकै छ।
दुबै कार्यान्वयनहरूले `panic!` कल गर्छन् जब उनीहरू [`None`] वा [`Err`] भेरियन्टहरूमा सेट हुन्छन्।

`panic!()` प्रयोग गर्दा तपाईं स्ट्रि pay पेलोड निर्दिष्ट गर्न सक्नुहुनेछ, जुन [`format!`] सिन्ट्याक्स प्रयोग गरेर निर्माण गरिएको हो।
ZoPanic0Z लाई कलिंग Rust थ्रेडमा इंजेक्सन गर्दा त्यो पेलोड प्रयोग हुन्छ, थ्रेड पूर्ण रूपमा panic मा।

पूर्वनिर्धारित `std` hook को व्यवहार, अर्थात्
panic आमन्त्रित पछाडि सीधा चलेको कोड `panic!()` कलको file/line/column जानकारीको साथ `stderr` मा सन्देश पेलोड प्रिन्ट गर्नु हो।

तपाईं panic hook [`std::panic::set_hook()`] प्रयोग गरेर ओभरराइड गर्न सक्नुहुनेछ।
hook भित्र एक panic `&dyn Any + Send` को रूपमा पहुँच गर्न सकिन्छ, जसमा `&str` वा `String` नियमित `panic!()` आमन्त्रितहरूको लागि समावेश गर्दछ।
अर्को0 प्रकारको मानको साथ panic गर्न, [`panic_any`] प्रयोग गर्न सकिन्छ।

[`Result`] `panic!` म्याक्रो प्रयोग नगरीकन त्रुटिहरूबाट पुन: प्राप्तिका लागि एनम प्राय: राम्रो समाधान हो।
यस म्याक्रोलाई गलत मानहरू प्रयोग गरेर अगाडि बढ्नबाट बच्न प्रयोग गर्न सकिन्छ, जस्तै बाह्य स्रोतहरूबाट।
त्रुटि ह्यान्डलिंगको बारेमा विस्तृत जानकारी [book] मा फेला पर्‍यो।

संकलनको बेला त्रुटिहरू बढाउनको लागि म्याक्रो [`compile_error!`] पनि हेर्नुहोस्।

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# वर्तमान कार्यान्वयन

यदि मुख्य थ्रेड panics यसले तपाईंको सबै थ्रेडहरू समाप्त गर्नेछ र कोड `101` को साथ तपाईंको कार्यक्रम समाप्त गर्दछ।

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





