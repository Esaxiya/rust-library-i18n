#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // या त `$crate::panic::panic_2015` वा `$crate::panic::panic_2021` मा कलरको संस्करणमा निर्भर गर्दछ।
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// दुई अभिव्यक्तिहरू एक अर्का बराबर हुन् भनेर जोड दिन्छ ([`PartialEq`] प्रयोग गरेर)।
///
/// panic मा, यस म्याक्रोले उनीहरूको डिबग प्रतिनिधित्वहरूको साथ अभिव्यक्तिहरूको मानहरू प्रिन्ट गर्दछ।
///
///
/// [`assert!`] जस्तै, यस म्याक्रोको दोस्रो फारम छ, जहाँ अनुकूलन panic सन्देश प्रदान गर्न सकिन्छ।
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // तलका रिब्रोहरू जानाजानी छन्।
                    // तिनीहरू बिना, orrowणको लागि स्ट्याक स्लट मानहरू तुलना गर्नु अघि नै आरम्भ हुन्छ, यसले सुस्त देखिने गतिलाई निम्त्याउँछ।
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // तलका रिब्रोहरू जानाजानी छन्।
                    // तिनीहरू बिना, orrowणको लागि स्ट्याक स्लट मानहरू तुलना गर्नु अघि नै आरम्भ हुन्छ, यसले सुस्त देखिने गतिलाई निम्त्याउँछ।
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// दुई अभिव्यक्तिहरू एक अर्कासँग बराबरी नभएको दावी गर्दछ ([`PartialEq`] प्रयोग गरेर)।
///
/// panic मा, यस म्याक्रोले उनीहरूको डिबग प्रतिनिधित्वहरूको साथ अभिव्यक्तिहरूको मानहरू प्रिन्ट गर्दछ।
///
///
/// [`assert!`] जस्तै, यस म्याक्रोको दोस्रो फारम छ, जहाँ अनुकूलन panic सन्देश प्रदान गर्न सकिन्छ।
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // तलका रिब्रोहरू जानाजानी छन्।
                    // तिनीहरू बिना, orrowणको लागि स्ट्याक स्लट मानहरू तुलना गर्नु अघि नै आरम्भ हुन्छ, यसले सुस्त देखिने गतिलाई निम्त्याउँछ।
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // तलका रिब्रोहरू जानाजानी छन्।
                    // तिनीहरू बिना, orrowणको लागि स्ट्याक स्लट मानहरू तुलना गर्नु अघि नै आरम्भ हुन्छ, यसले सुस्त देखिने गतिलाई निम्त्याउँछ।
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// जोर दिन्छ कि बुलियन अभिव्यक्ति रनटाइममा `true` हो।
///
/// यसले [`panic!`] म्याक्रोलाई बोलाउनेछ यदि प्रदान गरिएको अभिव्यक्ति रनटाइममा `true` मा मूल्या .्कन हुन सकेन।
///
/// [`assert!`] जस्तै, यस म्याक्रोको दोस्रो संस्करण पनि छ, जहाँ अनुकूलन panic सन्देश प्रदान गर्न सकिन्छ।
///
/// # Uses
///
/// [`assert!`] को विपरीत, `debug_assert!` कथनहरू मात्र पूर्वनिर्धारित द्वारा अप्टिमाइज गरिएको निर्माणमा सक्षम हुन्छन्।
/// कम्पाइलरमा `-C debug-assertions` पास नभएसम्म एक अनुकूलित निर्माणले `debug_assert!` कथनहरू कार्यान्वयन गर्दैन।
/// यसले `debug_assert!` लाई जाँचको लागि उपयोगी बनाउँदछ जुन रिलिज निर्माणमा उपस्थित हुन धेरै महँगो हुन्छ तर विकासको बखत मद्दत पुर्‍याउँछ।
/// `debug_assert!` विस्तारको परिणाम सँधै टाइपको जाँच गरीएको हुन्छ।
///
/// एक जाँच नगरिएको दाबीले एक असंगत स्थितिमा कार्यक्रमलाई चालू राख्न अनुमति दिँदछ, जसले अप्रत्याशित परिणामहरू निम्त्याउन सक्छ तर असुरक्षित परिचय दिदैन जबसम्म यो केवल सुरक्षित कोडमा हुन्छ।
///
/// दावीको प्रदर्शन लागत, तथापि, सामान्य मापनयोग्य हुँदैन।
/// [`assert!`] लाई `debug_assert!` प्रतिस्थापन गर्दा मात्र प्रोफाईल पछि प्रोत्साहन गरिन्छ, र अझ महत्त्वपूर्ण कुरा, सुरक्षित कोडमा मात्र!
///
/// # Examples
///
/// ```
/// // यी दावीहरूको लागि panic सन्देश दिइएको अभिव्यक्तिको स्ट्रिंगिफाइड मान हो।
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // एक धेरै साधारण समारोह
/// debug_assert!(some_expensive_computation());
///
/// // अनुकूलन सन्देशको साथ जोड दिनुहोस्
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// दुई अभिव्यक्तिहरू एक अर्का बराबर छन् भनेर दाबी गर्दछ।
///
/// panic मा, यस म्याक्रोले उनीहरूको डिबग प्रतिनिधित्वहरूको साथ अभिव्यक्तिहरूको मानहरू प्रिन्ट गर्दछ।
///
/// [`assert_eq!`] को विपरीत, `debug_assert_eq!` कथनहरू मात्र पूर्वनिर्धारित द्वारा अप्टिमाइज गरिएको निर्माणमा सक्षम हुन्छन्।
/// कम्पाइलरमा `-C debug-assertions` पास नभएसम्म एक अनुकूलित निर्माणले `debug_assert_eq!` कथनहरू कार्यान्वयन गर्दैन।
/// यसले `debug_assert_eq!` लाई जाँचको लागि उपयोगी बनाउँदछ जुन रिलिज निर्माणमा उपस्थित हुन धेरै महँगो हुन्छ तर विकासको बखत मद्दत पुर्‍याउँछ।
///
/// `debug_assert_eq!` विस्तारको परिणाम सँधै टाइपको जाँच गरीएको हुन्छ।
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// दुई अभिव्यक्तिहरु एक अर्का बराबर छैनन् भनेर जोड दिन्छ।
///
/// panic मा, यस म्याक्रोले उनीहरूको डिबग प्रतिनिधित्वहरूको साथ अभिव्यक्तिहरूको मानहरू प्रिन्ट गर्दछ।
///
/// [`assert_ne!`] को विपरीत, `debug_assert_ne!` कथनहरू मात्र पूर्वनिर्धारित द्वारा अप्टिमाइज गरिएको निर्माणमा सक्षम हुन्छन्।
/// कम्पाइलरमा `-C debug-assertions` पास नभएसम्म एक अनुकूलित निर्माणले `debug_assert_ne!` कथनहरू कार्यान्वयन गर्दैन।
/// यसले `debug_assert_ne!` लाई जाँचको लागि उपयोगी बनाउँदछ जुन रिलिज निर्माणमा उपस्थित हुन धेरै महँगो हुन्छ तर विकासको बखत मद्दत पुर्‍याउँछ।
///
/// `debug_assert_ne!` विस्तारको परिणाम सँधै टाइपको जाँच गरीएको हुन्छ।
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// दिईएको अभिव्यक्ति दिईएको कुनै पनि ढाँचासँग मेल खान्छ कि खान्छ।
///
/// एक `match` अभिव्यक्ति जस्तै, ढाँचा वैकल्पिक रूपमा `if` अनुगमन गर्न सकिन्छ र ढाँचामा बाँधिएका नामहरूमा पहुँच भएको गार्ड अभिव्यक्ति।
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// परिणामलाई उतार्न वा यसको त्रुटि प्रचार गर्दछ।
///
/// `?` अपरेटर `try!` प्रतिस्थापन गर्न थपिएको थियो र सट्टामा प्रयोग गर्नु पर्छ।
/// यसबाहेक, `try` Rust 2018 मा एक आरक्षित शब्द हो, त्यसैले यदि तपाईंले यसलाई प्रयोग गर्नु पर्छ भने, तपाईंले [raw-identifier syntax][ris] प्रयोग गर्नु पर्छ: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` दिइएको [`Result`] सँग मेल खान्छ।`Ok` भेरियन्टको मामलामा, अभिव्यक्तिले र्याप गरिएको मानको मान गर्दछ।
///
/// `Err` भेरियन्टको मामलामा, यसले भित्री त्रुटि पुनः प्राप्त गर्दछ।`try!` तब `From` प्रयोग गरेर रूपान्तरण गर्दछ।
/// यसले विशेष त्रुटिहरू र अधिक सामान्यहरूका बीच स्वचालित रूपान्तरण प्रदान गर्दछ।
/// परिणामस्वरूप त्रुटि तुरुन्तै फिर्ता हुन्छ।
///
/// प्रारम्भिक फिर्ताको कारण, `try!` मात्र [`Result`] फर्काउने कार्यहरूमा प्रयोग गर्न सकिन्छ।
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // छिटो फर्कने त्रुटिहरूको रुचाइएको विधि
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // द्रुत फिर्ती त्रुटिहरूको अघिल्लो विधि
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // यो बराबर छ:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// बफरमा फर्म्याट गरिएको डाटा लेख्छ।
///
/// यस म्याक्रोले 'writer', ढाँचा स्ट्रि,, र तर्कहरूको सूची स्वीकार गर्दछ।
/// तर्क निर्दिष्ट ढाँचा स्ट्रि accordingको आधारमा ढाँचाबद्ध गरिनेछ र परिणाम लेखकलाई दिइनेछ।
/// लेखक `write_fmt` विधिको साथ कुनै मूल्य हुन सक्छ;सामान्यतया यो या त [`fmt::Write`] वा [`io::Write`] trait को कार्यान्वयनबाट आउँदछ।
/// म्याक्रो जुन `write_fmt` विधि फर्काउँछ;सामान्यतया एक [`fmt::Result`], वा एक [`io::Result`]।
///
/// [`std::fmt`] ढाँचा स्ट्रि synt सिन्ट्याक्समा अधिक जानकारीको लागि हेर्नुहोस्।
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// मोड्युलले दुबै `std::fmt::Write` र `std::io::Write` आयात गर्न सक्दछ र `write!` लाई कार्यान्वयन गर्ने वस्तुमा या त कार्यान्वयन गर्न सक्छ, किनकि वस्तुले सामान्यतया दुबै कार्यान्वयन गर्दैन।
///
/// जे होस्, मोड्युलले traits योग्यता आयात गर्नु पर्छ त्यसैले तिनीहरूको नामहरू विरोधाभास नहोस्:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt प्रयोग गर्दछ
///     write!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt प्रयोग गर्दछ
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: यो म्याक्रो `no_std` सेटअपमा पनि प्रयोग गर्न सकिन्छ।
/// `no_std` सेटअपमा तपाई कम्पोनेन्ट्सको कार्यान्वयन विवरणको लागि जिम्मेवार हुनुहुन्छ।
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// नयाँ लाइन जोडिएको बफरमा फर्म्याट गरिएको डाटा लेख्नुहोस्।
///
/// सबै प्लेटफर्महरूमा, नयाँ रेखा भनेको लाइन फीड अक्षर (`\n`/`U+000A`) एक्लो हो (कुनै थप CARRIAGE वापसी (`\r`/`U+000D`) छैन।
///
/// अधिक जानकारीको लागि, [`write!`] हेर्नुहोस्।ढाँचा स्ट्रि synt सिन्ट्याक्समा जानकारीको लागि, हेर्नुहोस् [`std::fmt`]।
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// मोड्युलले दुबै `std::fmt::Write` र `std::io::Write` आयात गर्न सक्दछ र `write!` लाई कार्यान्वयन गर्ने वस्तुमा या त कार्यान्वयन गर्न सक्छ, किनकि वस्तुले सामान्यतया दुबै कार्यान्वयन गर्दैन।
/// जे होस्, मोड्युलले traits योग्यता आयात गर्नु पर्छ त्यसैले तिनीहरूको नामहरू विरोधाभास नहोस्:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt प्रयोग गर्दछ
///     writeln!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt प्रयोग गर्दछ
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// पहुँचयोग्य कोडलाई दर्साउँछ।
///
/// यो कुनै पनि समयमा उपयोगी छ कि कम्पाइलरले निर्धारण गर्न सक्दैन कि केहि कोड पहुँचयोग्य छैन।उदाहरण को लागी:
///
/// * गार्ड सर्तहरूको साथ हतियारहरू मिलाउनुहोस्।
/// * लुप्स जुन गतिशील रूपमा समाप्त हुन्छ।
/// * इटेरेटर्स जुन गतिशील ढंगले समाप्त हुन्छ।
///
/// यदि कोडमा पहुँचयोग्य छैन भन्ने दृढ संकल्पले गलत प्रमाणित गर्दछ भने, कार्यक्रम तुरून्त [`panic!`] को साथ समाप्त हुन्छ।
///
/// यस म्याक्रोको असुरक्षित समकक्ष [`unreachable_unchecked`] प्रकार्य हो, जुन कोडमा पुगेको छ भने अपरिभाषित व्यवहारको कारण हुनेछ।
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// यो सँधै [`panic!`] हुनेछ।
///
/// # Examples
///
/// मिल्दो हतियार:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // कम्पाइल त्रुटि यदि टिप्पणी गरीएको छ भने
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // x/3 को सब भन्दा गरीब कार्यान्वयन मध्ये एक
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// "not implemented" को सन्देशको साथ प्यानिक गरेर कार्यान्वयन नगरिएको सic्केत गर्दछ।
///
/// यसले तपाईंको कोडलाई टाइप-चेक गर्न अनुमति दिन्छ, जो उपयोगी छ यदि तपाईं trait प्रोटोटाइप गर्दै हुनुहुन्छ वा कार्यान्वयन गर्दै हुनुहुन्छ भने बहुविध विधिहरू आवश्यक पर्दछ जुन तपाईंले सबै प्रयोग गर्ने योजना गर्नुहुन्न।
///
/// `unimplemented!` र [`todo!`] बीचको भिन्नता यो छ कि `todo!` पछि कार्यक्षमता कार्यान्वयन गर्ने अभिप्राय प्रस्तुत गर्दछ र सन्देश "not yet implemented" हो, `unimplemented!` त्यस्ता कुनै दावी गर्दैन।
/// यसको सन्देश "not implemented" हो।
/// साथै केहि IDEs ले `todo! Mark s चिन्ह लगाउनेछ।
///
/// # Panics
///
/// यो सँधै [`panic!`] हुनेछ किनकि `unimplemented!` एक निश्चित, विशिष्ट सन्देशको साथ `panic!` को लागी मात्र एक छोटो समय हो।
///
/// `panic!` जस्तै, यस म्याक्रोसँग अनुकूलन मानहरू प्रदर्शन गर्न दोस्रो फारम छ।
///
/// # Examples
///
/// भन्नुहोस् हामीसँग trait `Foo` छ:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// हामी 'MyStruct' को लागी `Foo` कार्यान्वयन गर्न चाहन्छौं, तर केहि कारणले यो `bar()` प्रकार्य कार्यान्वयन गर्न मात्र समझको हुन्छ।
/// `baz()` र `qux()` अझै पनि हाम्रो `Foo` को कार्यान्वयनमा परिभाषित गर्न आवश्यक छ, तर हामी `unimplemented!` प्रयोग गर्न सक्दछौं परिभाषामा हाम्रो कोड कम्पाइल गर्न अनुमति दिन।
///
/// हामी अझै पनी चाहन्छौं कि यदि कार्यान्वयन विधिहरू पुगेमा हाम्रा प्रोग्रामहरू चालू हुन रोकिन्छन्।
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // यसले `baz` लाई `MyStruct` मा कुनै अर्थ राख्दैन, त्यसैले हामीसंग यहाँ कुनै तर्क छैन।
/////
///         // यसले "thread 'main' panicked at 'not implemented'" प्रदर्शन गर्दछ।
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // हामीसँग यहाँ केहि तर्कहरू छन्, हामी सन्देश कार्यान्वयन गर्न सक्दछौं!हाम्रो बेवास्ता प्रदर्शन गर्न।
///         // यसले प्रदर्शन गर्दछ: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// अधूरो कोड दर्साउँछ।
///
/// यो उपयोगी हुन सक्छ यदि तपाईं प्रोटोटाइप गरिरहनु भएको छ र तपाईको कोड typecheck मात्र खोज्दै हुनुहुन्छ।
///
/// [`unimplemented!`] र `todo!` बीचको भिन्नता यो छ कि `todo!` पछि कार्यक्षमता कार्यान्वयन गर्ने अभिप्राय प्रस्तुत गर्दछ र सन्देश "not yet implemented" हो, `unimplemented!` त्यस्ता कुनै दावी गर्दैन।
/// यसको सन्देश "not implemented" हो।
/// साथै केहि IDEs ले `todo! Mark s चिन्ह लगाउनेछ।
///
/// # Panics
///
/// यो सँधै [`panic!`] हुनेछ।
///
/// # Examples
///
/// यहाँ केहि प्रगति कोडको उदाहरण छ।हामीसँग trait `Foo` छ:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// हामी हाम्रो कुनै प्रकारमा `Foo` कार्यान्वयन गर्न चाहन्छौं, तर हामी पहिले `bar()` मा पनि काम गर्न चाहन्छौं।हाम्रो कोड कम्पाइल गर्नका लागि, हामीले `baz()` कार्यान्वयन गर्न आवश्यक छ, त्यसैले हामी `todo!` प्रयोग गर्न सक्दछौं:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // कार्यान्वयन यहाँ जान्छ
///     }
///
///     fn baz(&self) {
///         // अबको लागि baz() कार्यान्वयनको बारेमा चिन्ता नगरौं
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // हामी baz() पनि प्रयोग गरिरहेका छैनौं, त्यसैले यो ठीक छ।
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// अंतर्निहित म्याक्रोहरूको परिभाषा।
///
/// अधिकांश म्याक्रो गुणहरू (स्थिरता, दृश्यता, आदि) यहाँ स्रोत कोडबाट लिइएको हो, विस्तार प्रकार्यहरूको अपवाद बाहेक म्याक्रो इनपुटलाई आउटपुटमा रूपान्तरण गर्दछ, ती कार्यहरू कम्पाइलरद्वारा प्रदान गरिन्छ।
///
///
pub(crate) mod builtin {

    /// कम्पाइलेसन दिईएको त्रुटि सन्देशको साथ असफल भयो जब सामना गर्नु पर्‍यो।
    ///
    /// यो म्याक्रो प्रयोग गरिनुपर्नेछ जब crate गलत सर्तहरूको लागि राम्रो त्रुटि सन्देशहरू प्रदान गर्न ससर्त संकलन रणनीति प्रयोग गर्दछ।
    ///
    /// यो [`panic!`] को कम्पाइलर-स्तर फारम हो, तर *कम्पाइलेसन**रनटाइम* भन्दा नभई एउटा त्रुटि निकाल्छ।
    ///
    /// # Examples
    ///
    /// यस प्रकारका दुई उदाहरणहरू म्याक्रो र `#[cfg]` वातावरण हुन्।
    ///
    /// राम्रो कम्पाइलर त्रुटि उत्सर्जन गर्नुहोस् यदि म्याक्रो अवैध मानहरू पारित गरियो।
    /// अन्तिम branch बिना, कम्पाइलरले अझै एउटा त्रुटि उत्सर्जन गर्दछ, तर त्रुटि सन्देशले दुई मान्य मानहरूको उल्लेख गर्दैन।
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// ईम्पाइलर त्रुटि ईमर्ट गर्नुहोस् यदि कुनै एक सुविधाहरू उपलब्ध छैनन्।
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// अन्य स्ट्रि--स्वरूपण म्याक्रोहरूको लागि प्यारामिटरहरू निर्माण गर्दछ।
    ///
    /// यस म्याक्रोले कार्य गर्दछ एक अतिरिक्त ढाँचा को लागी `{}` समावेश ढाँचा स्ट्रि lite शाब्दिक ले।
    /// `format_args!` अतिरिक्त प्यारामिटरहरू तैयार गर्दछ आउटपुटलाई स्ट्रिंगको रूपमा व्याख्या गर्न सकिन्छ र आर्गुमेन्टहरूलाई एकल प्रकारमा क्यानोनिकल गर्दछ।
    /// [`Display`] trait लागू गर्ने कुनै मान `format_args!` मा पास गर्न सकिन्छ, कुनै [`Debug`] कार्यान्वयन ढाँचा स्ट्रि within भित्र `{:?}` गर्न सकिन्छ।
    ///
    ///
    /// यो म्याक्रोले [`fmt::Arguments`] प्रकारको मान उत्पादन गर्दछ।यो मान [`std::fmt`] भित्र म्याक्रोमा उपयोगी रिडाइरेक्शन प्रदर्शन गर्नका लागि पास गर्न सकिन्छ।
    /// सबै अन्य स्वरूपण म्याक्रो ([`format!`], [`write!`], [`println!`], आदि) यो एक मार्फत प्रोक्सी गरिएको छ।
    /// `format_args!`, यसको व्युत्पन्न म्याक्रोहरू जस्तो छैन, ढेर वाटपलाई बेवास्ता गर्दछ।
    ///
    /// तपाईं [`fmt::Arguments`] मान प्रयोग गर्न सक्नुहुनेछ जुन `format_args!` `Debug` र `Display` प्रसंगहरूमा तल देखा पर्दछ।
    /// उदाहरणले `Debug` र `Display` ढाँचामा समान कुरा पनि देखाउँदछ: `format_args!` मा इंटरपोलटेड ढाँचा स्ट्रि।।
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// अधिक जानकारीको लागि, [`std::fmt`] मा कागजात हेर्नुहोस्।
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// `format_args` को जस्तै, तर अन्तमा एक नयाँ लाइन थप गर्दछ।
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// कम्पाईल समयमा वातावरण चलको निरीक्षण गर्दछ।
    ///
    /// यो म्याक्रो कम्पाईल समयमा नामित वातावरण चरको मानमा विस्तार हुन्छ, प्रकार `&'static str` को अभिव्यक्ति उपज।
    ///
    ///
    /// यदि वातावरण परिवर्तन परिभाषित गरिएको छैन भने, तब एक कम्पाइलेसन त्रुटि उत्सर्जित हुनेछ।
    /// एक कम्पाईल त्रुटि उत्सर्जन गर्न, यसको सट्टा [`option_env!`] म्याक्रो प्रयोग गर्नुहोस्।
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// तपाईंले त्रुटि सन्देश अनुकूलन गर्न सक्नुहुनेछ जुन दोस्रो प्यारामिटरको रूपमा स्ट्रि passing पार गरेर:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// यदि `documentation` वातावरण चर परिभाषित गरिएको छैन भने, तपाईं निम्न त्रुटि प्राप्त गर्नुहुनेछ:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// वैकल्पिक रूपमा कम्पाईल समयमा एक वातावरण चरको निरीक्षण गर्दछ।
    ///
    /// यदि नाम गरिएको वातावरण चर कम्पाइल समयमा उपस्थित छ भने, यो प्रकार `Option<&'static str>` को अभिव्यक्तिमा विस्तार हुन्छ जसको मान वातावरण चरको मानको `Some` हो।
    /// यदि वातावरण चर उपस्थित छैन भने, तब यो `None` मा विस्तार हुनेछ।
    /// यस प्रकारको अधिक जानकारीको लागि [`Option<T>`][Option] हेर्नुहोस्।
    ///
    /// कम्पाइल समय त्रुटि कहिले पनि उत्सर्जित हुँदैन यस म्याक्रोको प्रयोग गर्दा वातावरण भ्यारीएबल उपस्थित छ कि छैन।
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// एक पहिचानकर्तामा परिचयकर्ताहरूलाई समेट्छ।
    ///
    /// यस म्याक्रोले कुनै पनि संख्याको अल्पविराम-विभाजित पहिचानकर्ता लिन्छ, र ती सबैलाई एकमा जोड दिन्छ, एक अभिव्यक्ति उत्पन्न गर्दछ जुन एक नयाँ परिचयकर्ता हो।
    /// नोट गर्नुहोस् कि स्वच्छताले यसलाई यस्तो बनाउँदछ कि यस म्याक्रोले स्थानीय भेरिएबलहरू कब्जा गर्न सक्दैन।
    /// साथै, सामान्य नियमको रूपमा, म्याक्रोहरूलाई केवल वस्तु, स्टेटमेन्ट वा अभिव्यक्ति स्थितिमा मात्र अनुमति छ।
    /// यसको मतलब जब तपाईं यो म्याक्रोलाई अवस्थित भेरिएबलहरू, प्रकार्यहरू वा मोड्युलहरू इत्यादि सन्दर्भको लागि प्रयोग गर्न सक्नुहुनेछ, तपाईं यसको साथ नयाँ परिभाषित गर्न सक्नुहुन्न।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_ferences! (नयाँ, रमाईलो, नाम) { }//यस तरिकाले प्रयोग गर्न योग्य छैन!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// स्थिर स्ट्रि sl स्लाइसमा अक्षरशहरूलाई जोड्दछ।
    ///
    /// यस म्याक्रोले कुनै पनि संख्याको अल्पविराम-विभाजित लिट्रल्स लिन्छ, `&'static str` प्रकारको अभिव्यक्ति उपज दिन्छ जसले सबै अक्षरशः लेटेर बायाँ देखि दायाँ प्रतिनिधित्व गर्दछ।
    ///
    ///
    /// इन्टिजर र फ्लोटिंग पोइन्ट लिटरेलहरू कified्कनेट गर्नका लागि स्ट्रिंग गरिएको छ।
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// लाईन नम्बरमा विस्तार हुन्छ जसमा यो आमन्त्रित गरिएको थियो।
    ///
    /// [`column!`] र [`file!`] का साथ, यी म्याक्रोहरूले स्रोत भित्रका स्थानको बारेमा विकासकर्ताहरूको लागि डिबगिंग जानकारी प्रदान गर्दछ।
    ///
    /// विस्तारित अभिव्यक्तिसँग प्रकार `u32` छ र १-आधारित छ, त्यसैले प्रत्येक फाईलमा पहिलो लाइन १, दोस्रो दोस्रो २, आदिमा मूल्या to्कन गर्दछ।
    /// यो सामान्य कम्पाइलरहरू वा लोकप्रिय सम्पादकहरू द्वारा त्रुटि सन्देशसँग अनुरूप छ।
    /// फिर्ता गरिएको लाइन * * आवश्यक छैन `line!` X आह्वानको लाइन आफैं हो, बरू `line!` म्याक्रोको निम्तो पुर्‍याउने पहिलो म्याक्रो निम्तो।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// यो आमन्त्रित गरिएको थियो जुनमा स्तम्भ संख्यामा विस्तार गर्दछ।
    ///
    /// [`line!`] र [`file!`] का साथ, यी म्याक्रोहरूले स्रोत भित्रका स्थानको बारेमा विकासकर्ताहरूको लागि डिबगिंग जानकारी प्रदान गर्दछ।
    ///
    /// विस्तारित अभिव्यक्तिसँग प्रकार `u32` छ र १-आधारित छ, त्यसैले प्रत्येक प in्क्तिमा पहिलो स्तम्भ १ लाई मूल्या the्कन गर्दछ, दोस्रोलाई २, इत्यादि।
    /// यो सामान्य कम्पाइलरहरू वा लोकप्रिय सम्पादकहरू द्वारा त्रुटि सन्देशसँग अनुरूप छ।
    /// फिर्ता भएको स्तम्भ *जरूरी* मात्र `column!` आह्वान को लाइन हो, तर बरु पहिलो म्याक्रो बिन्दु `column!` म्याक्रो को निम्तो मा अग्रणी।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// फाईल नाममा विस्तार भयो जुन यो आमन्त्रित गरिएको थियो।
    ///
    /// [`line!`] र [`column!`] का साथ, यी म्याक्रोहरूले स्रोत भित्रका स्थानको बारेमा विकासकर्ताहरूको लागि डिबगिंग जानकारी प्रदान गर्दछ।
    ///
    /// विस्तारित अभिव्यक्तिसँग प्रकार `&'static str` छ, र फिर्ता गरिएको फाईल आफै `file!` म्याक्रोको आह्वान होईन, बरु प्रथम म्याक्रो निम्ता `file!` म्याक्रोको निम्तो सम्म पुग्दछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// यसको तर्कलाई Stringifies।
    ///
    /// यस म्याक्रोले `&'static str` प्रकारको अभिव्यक्ति निकाल्नेछ जुन म्याक्रोमा पारित सबै tokens को स्ट्रिंगिफिकेशन हो।
    /// कुनै पनि प्रतिबन्ध मैक्रो ईन्भोकेसनको सिन्ट्याक्समा राखिएको छैन।
    ///
    /// नोट गर्नुहोस् कि इनपुट tokens का विस्तारित परिणामहरू future मा परिवर्तन हुन सक्दछ।तपाईं सावधान हुनुपर्छ यदि तपाईं आउटपुटमा निर्भर हुनुहुन्छ भने।
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// UTF-8 एन्कोड गरिएको फाइललाई स्ट्रि asको रूपमा समावेश गर्दछ।
    ///
    /// फाईल हालको फाँटको सापेक्ष स्थित छ (त्यस्तै मोड्युलहरू कसरी फेला पर्दछ)।
    /// प्रदान गरिएको मार्ग कम्पाइल समयमा एक प्लेटफर्म-विशेष तरिकामा व्याख्या गरिएको छ।
    /// त्यसो भए, उदाहरणका लागि, Windows पथको साथ एउटा आह्वानले ब्याकस्लासहरू `\` Unix मा सहि कम्पाइल गर्दैन।
    ///
    ///
    /// यस म्याक्रोले `&'static str` प्रकारको अभिव्यक्ति ल्याउनेछ जुन फाईलका सामग्रीहरू छन्।
    ///
    /// # Examples
    ///
    /// मान्नुहोस् कि त्यहाँ समान सामग्रीहरूमा निम्न सामग्रीका साथ दुई फाइलहरू छन्:
    ///
    /// फाइल 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// फाइल 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs' कम्पाइल गरेर नतिजा बाइनरी "adiós" प्रिन्ट गर्नेछ।
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// एउटा बाइट एर्रेमा सन्दर्भको रूपमा फाईल समावेश गर्दछ।
    ///
    /// फाईल हालको फाँटको सापेक्ष स्थित छ (त्यस्तै मोड्युलहरू कसरी फेला पर्दछ)।
    /// प्रदान गरिएको मार्ग कम्पाइल समयमा एक प्लेटफर्म-विशेष तरिकामा व्याख्या गरिएको छ।
    /// त्यसो भए, उदाहरणका लागि, Windows पथको साथ एउटा आह्वानले ब्याकस्लासहरू `\` Unix मा सहि कम्पाइल गर्दैन।
    ///
    ///
    /// यस म्याक्रोले `&'static [u8; N]` प्रकारको अभिव्यक्ति ल्याउनेछ जुन फाईलका सामग्रीहरू छन्।
    ///
    /// # Examples
    ///
    /// मान्नुहोस् कि त्यहाँ समान सामग्रीहरूमा निम्न सामग्रीका साथ दुई फाइलहरू छन्:
    ///
    /// फाइल 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// फाइल 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs' कम्पाइल गरेर नतिजा बाइनरी "adiós" प्रिन्ट गर्नेछ।
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// स्ट्रिंगमा विस्तार गर्दछ जुन हालको मोड्युल पथलाई प्रतिनिधित्व गर्दछ।
    ///
    /// हालको मोड्युल पथ crate root मा फर्केर अग्रणी मोड्युलहरूको पदानुक्रमको रूपमा सोच्न सकिन्छ।
    /// फर्काइएको पथको पहिलो घटक crate नाम हालै कम्पाइल भइरहेको छ।
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// कम्पाइल समयमा कन्फिगरेसन फ्ल्यागको बुलियन संयोजनहरूको मूल्या .्कन गर्दछ।
    ///
    /// `#[cfg]` एट्रिब्युटको साथसाथै, यो म्याक्रो कन्फिगरेसन फ्ल्यागको बुलियन अभिव्यक्ति मूल्यांकनलाई अनुमति दिन प्रदान गरिएको छ।
    /// यसले प्राय: कम नक्कल कोडतर्फ डो .्याउँछ।
    ///
    /// यस म्याक्रोलाई दिइएको सिन्ट्याक्स [`cfg`] एट्रिब्युटको समान सिन्ट्याक्स हो।
    ///
    /// `cfg!`, `#[cfg]` विपरीत, कुनै कोड हटाउदैन र मात्र सही वा गलतमा मूल्याates्कन गर्दछ।
    /// उदाहरण को लागी if/else अभिव्यक्ति मा सबै अवरोधहरु XT1X को मूल्यांकन गरीरहेको भए पनि शर्तका लागि `cfg!` प्रयोग गरिने बेला मान्य हुनु पर्छ।
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// सन्दर्भको आधारमा एक फाईललाई अभिव्यक्ति वा वस्तुको रूपमा पार्स गर्दछ।
    ///
    /// फाईल हालको फाँटको सापेक्ष स्थित छ (त्यस्तै मोड्युलहरू कसरी फेला पर्दछ)।प्रदान गरिएको मार्ग कम्पाइल समयमा एक प्लेटफर्म-विशेष तरिकामा व्याख्या गरिएको छ।
    /// त्यसो भए, उदाहरणका लागि, Windows पथको साथ एउटा आह्वानले ब्याकस्लासहरू `\` Unix मा सहि कम्पाइल गर्दैन।
    ///
    /// यस म्याक्रोको प्रयोग अक्सर खराब विचार हो, किनकि यदि फाइल अभिव्यक्तिको रूपमा पार्स गरिएको छ भने, यसलाई आसपासको कोडमा अस्वच्छिक रूपमा राखिनेछ।
    /// यसले भ्यारीएबलहरू वा प्रकार्यहरू फाईलले सोचेभन्दा फरक हुन सक्दछ यदि हालको फाईलमा समान नामहरू भ्यारीएबलहरू वा प्रकार्यहरू छन् भने।
    ///
    ///
    /// # Examples
    ///
    /// मान्नुहोस् कि त्यहाँ समान सामग्रीहरूमा निम्न सामग्रीका साथ दुई फाइलहरू छन्:
    ///
    /// फाइल 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// फाइल 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs' कम्पाइल गरेर नतिजा बाइनरी "🙈🙊🙉🙈🙊🙉" प्रिन्ट गर्नेछ।
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// जोर दिन्छ कि बुलियन अभिव्यक्ति रनटाइममा `true` हो।
    ///
    /// यसले [`panic!`] म्याक्रोलाई बोलाउनेछ यदि प्रदान गरिएको अभिव्यक्ति रनटाइममा `true` मा मूल्या .्कन हुन सकेन।
    ///
    /// # Uses
    ///
    /// दावीहरू सँधै दुबै डिबग र रिलिज बिल्डहरूमा जाँच गरिन्छ, र असक्षम गर्न सकिँदैन।
    /// [`debug_assert!`] हेर्नुहोस्को लागि हेर्नुहोस् जुन पूर्वनिर्धारितमा रिलीज निर्माणमा सक्षम छैनन्।
    ///
    /// असुरक्षित कोड रन-टाइम इनवाइरन्टहरू लागू गर्न `assert!` मा भर पर्न सक्छ कि, यदि उल्लlated्घन भयो भने असुरक्षा निम्त्याउन सक्छ।
    ///
    /// `assert!` को अन्य प्रयोगका केसहरूमा सेफ कोडमा रन-टाइम ईन्ग्राइन्टहरू परीक्षण गर्न र लागू गर्नु समावेश गर्दछ (जसको उल्ल .्घनले असफलतामा परिणाम दिन सक्दैन)।
    ///
    ///
    /// # अनुकूलन सन्देशहरू
    ///
    /// यो म्याक्रोको दोस्रो फारम छ, जहाँ अनुकूलन panic सन्देश स्वरुपणको लागि वा बिना तर्कहरू प्रदान गर्न सकिन्छ।
    /// यस फारमको लागि वाक्यविन्यासको लागि [`std::fmt`] हेर्नुहोस्।
    /// ढाँचा आर्गुमेन्टहरूको रूपमा प्रयोग अभिव्यक्तिहरू मात्र मूल्या will्कन गरिनेछ यदि जोर असफल भयो।
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // यी दावीहरूको लागि panic सन्देश दिइएको अभिव्यक्तिको स्ट्रिंगिफाइड मान हो।
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // एक धेरै साधारण समारोह
    ///
    /// assert!(some_computation());
    ///
    /// // अनुकूलन सन्देशको साथ जोड दिनुहोस्
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// इनलाइन विधानसभा।
    ///
    /// उपयोगको लागि [unstable book] पढ्नुहोस्।
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM-शैली इनलाइन असेंब्ली।
    ///
    /// उपयोगको लागि [unstable book] पढ्नुहोस्।
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// मोड्युल-स्तर इनलाइन असेंबली।
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// प्रिन्ट्स tokens मानक आउटपुट मा पारित।
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// अन्य म्याक्रोहरूको डिबगिंगका लागि प्रयोग गरिएको ट्रेसि function कार्यक्षमतालाई सक्षम वा अक्षम गर्दछ।
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// एट्रिब्यूट म्याक्रो व्युत्पन्न म्याक्रोहरू लागू गर्न प्रयोग गरियो।
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// एनिट टेस्टमा परिणत गर्न प्रकार्यमा एट्रीब्यूट म्याक्रो लागू गरियो।
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// एट्रिब्यूट म्याक्रोले एउटा फ्यान्चमा लागू गरियो यसलाई बेन्चमार्क परीक्षणमा परिवर्तन गर्नका लागि।
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]` र `#[bench]` म्याक्रोहरूको कार्यान्वयन विवरण।
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// एट्रिब्युट म्याक्रो एक स्थिरमा लागू गरियो यसलाई विश्वव्यापी आवाश्यककर्ताको रूपमा दर्ता गर्न।
    ///
    /// [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html) पनि हेर्नुहोस्।
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// वस्तुलाई लागू गरिएको छ यदि यो पारित पथ पहुँच योग्य छ, र यसलाई अन्यथा हटाउछ।
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// यो लागू गरिएको कोड खण्डमा सबै `#[cfg]` र `#[cfg_attr]` गुणहरू विस्तार गर्दछ।
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// `rustc` कम्पाइलरको अस्थिर कार्यान्वयन विवरण, प्रयोग नगर्नुहोस्।
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// `rustc` कम्पाइलरको अस्थिर कार्यान्वयन विवरण, प्रयोग नगर्नुहोस्।
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}