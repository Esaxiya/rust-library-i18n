//! `Clone` trait प्रकारहरूको लागि जुन 'स्पष्ट रूपमा प्रतिलिपि गर्न सकिदैन'।
//!
//! Rust मा, केहि साधारण प्रकारहरू "implicitly copyable" हुन् र जब तपाइँ तिनीहरूलाई माना assign्कन गर्नुहुन्छ वा तिनीहरूलाई तर्कको रूपमा पास गर्नुहुन्छ, रिसीभरले एक प्रतिलिपि प्राप्त गर्दछ, मूल मान स्थानमा छोड्दा।
//! यी प्रकारहरूलाई प्रतिलिपि गर्न आवाश्यकता आवाश्यक पर्दैन र फाइनलाइजरहरू हुँदैन (उदाहरण: तिनीहरूसँग स्वामित्वयुक्त बाकस हुँदैन वा [`Drop`] कार्यान्वयन हुँदैन), त्यसैले कम्पाइलरले तिनीहरूलाई सस्तो र प्रतिलिपि गर्न सुरक्षित ठान्छ।
//!
//! अन्य प्रकारका लागि प्रतिलिपिहरू स्पष्ट रूपमा बनाउनुपर्दछ, [`Clone`] trait लागू गरेर र [`clone`] विधि कल गरेर।
//!
//! [`clone`]: Clone::clone
//!
//! आधारभूत उपयोग उदाहरण:
//!
//! ```
//! let s = String::new(); // स्ट्रिंग प्रकारले क्लोन कार्यान्वयन गर्‍यो
//! let copy = s.clone(); // त्यसैले हामी यसलाई क्लोन गर्न सक्छौं
//! ```
//!
//! क्लोन trait सजिलैसँग कार्यान्वयन गर्न, तपाईं `#[derive(Clone)]` पनि प्रयोग गर्न सक्नुहुनेछ।उदाहरण:
//!
//! ```
//! #[derive(Clone)] // हामी क्लोन trait मोर्फिस स्ट्र्याक्टमा थप्दछौं
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // र अब हामी यसलाई क्लोन गर्न सक्छौं!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// एक स्पष्ट trait कुनै वस्तु स्पष्ट रूपमा नक्कल गर्न को क्षमता को लागी।
///
/// [`Copy`] X X1X मा भिन्नै भिन्न र अत्यन्त सस्तो हो, जबकि `Clone` जहिले पनि स्पष्ट हुन्छ र महँगो पनि हुन सक्दैन।
/// यी सुविधाहरू कार्यान्वयन गर्न, Rust ले तपाईंलाई [`Copy`] रिम्पिमेन्ट गर्न अनुमति दिँदैन, तर तपाईं `Clone` रिम्पिमेन्ट गर्न सक्नुहुन्छ र मनमाना कोड चलाउन सक्नुहुन्छ।
///
/// `Clone` [`Copy`] भन्दा अधिक सामान्य हो, तपाईं स्वचालित रूपमा [`Copy`] `Clone` पनि केहि बनाउन सक्नुहुन्छ।
///
/// ## Derivable
///
/// यो trait `#[derive]` को साथ प्रयोग गर्न सकिन्छ यदि सबै फिल्डहरू `Clone` छन्।[`Clone`] को `derive`d कार्यान्वयनले प्रत्येक फिल्डमा [`clone`] कल गर्दछ।
///
/// [`clone`]: Clone::clone
///
/// जेनेरिक संरचनाको लागि, `#[derive]` जेनेरिक पैरामीटरमा बाउन्ड `Clone` थपेर `Clone` सर्तमा लागू गर्दछ।
///
/// ```
/// // `derive` पढ्नको लागि क्लोन लागू गर्दछ<T>जब टी क्लोन हुन्छ।
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## म कसरी `Clone` कार्यान्वयन गर्न सक्छु?
///
/// प्रकारहरू जुन [`Copy`] का `Clone` को एक तुच्छ कार्यान्वयन हुनुपर्दछ।अधिक औपचारिक:
/// यदि `T: Copy`, `x: T`, र `y: &T`, तब `let x = y.clone();` `let x = *y;` बराबर हो।
/// म्यानुअल कार्यान्वयनहरू यस ईरिएन्टलाई कायम राख्न सावधान हुनुपर्छ;जे होस्, असुरक्षित कोड मेमोरी सुरक्षा सुनिश्चित गर्न मा निर्भर हुँदैन।
///
/// उदाहरण एक जेनेरिक संरचना हो जुन प्रकार्य सूचक हो।यस अवस्थामा, `Clone` को कार्यान्वयन `derive`d हुन सक्दैन, तर कार्यान्वयन गर्न सकिन्छ:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## थप कार्यान्वयनकर्ताहरू
///
/// [implementors listed below][impls] को साथसाथै, निम्न प्रकारहरूले `Clone` लागू गर्दछ:
///
/// * प्रकार्य वस्तु प्रकारहरू (उदाहरणका लागि, प्रत्येक प्रकार्यका लागि फरक प्रकार परिभाषित)
/// * प्रकार्य सूचक प्रकारहरू (जस्तै, `fn() -> i32`)
/// * एर्रे प्रकारहरू, सबै आकारका लागि, यदि वस्तु प्रकारले `Clone` (जस्तै, `[i32; 123456]`) लागू गर्दछ।
/// * Tuple प्रकारहरू, यदि प्रत्येक घटकले `Clone` (उदाहरण, `()`, `(i32, bool)`) लागू गर्दछ।
/// * बन्द गर्ने प्रकारहरू, यदि तिनीहरूले वातावरणबाट कुनै मान लिदैन वा यदि ती सबै क्याप्चर मानहरू आफैं `Clone` कार्यान्वयन गर्छन्।
///   नोट गर्नुहोस् कि साझा सन्दर्भ द्वारा क्याप्चर भेरिएबलले सँधै `Clone` कार्यान्वयन गर्दछ (चाहे रेफर गरेन पनि), जबकि परिवर्तनीय सन्दर्भले क्याप्चर भ्यारीएबलले कहिले पनि `Clone` लागू गर्दैन।
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// मानको प्रतिलिपि फर्काउँछ।
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str क्लोन लागू गर्दछ
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// `source` बाट प्रतिलिपि असाइनमेन्ट प्रदर्शन गर्दछ।
    ///
    /// `a.clone_from(&b)` कार्यक्षमतामा `a = b.clone()` को बराबर हो, तर अनावश्यक विनियोजनहरू जोगिन `a` को स्रोतहरू पुनःप्रयोग गर्न अधिलेखन गर्न सकिन्छ।
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// trait `Clone` को एक इम्प्ली उत्पन्न डेरिभ म्याक्रो।
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): यी स्ट्रिकहरू पूर्ण रूपमा#[व्युत्पन्न] द्वारा प्रयोग गरिन्छ कि एक प्रकारको प्रत्येक घटक क्लोन वा प्रतिलिपि लागू गर्दछ।
//
//
// यी स्ट्रिकहरू प्रयोगकर्ता कोडमा कहिले देखा पर्दैन।
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// आदिम प्रकारका लागि `Clone` को कार्यान्वयन।
///
/// Rust मा वर्णन गर्न सकिदैन कार्यान्वयनहरू `rustc_trait_selection` मा `traits::SelectionContext::copy_clone_conditions()` मा लागू गरियो।
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// साझेदारी सन्दर्भ क्लोन गर्न सकिन्छ, तर परिवर्तनीय सन्दर्भ *गर्न सक्दैन*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// साझेदारी सन्दर्भ क्लोन गर्न सकिन्छ, तर परिवर्तनीय सन्दर्भ *गर्न सक्दैन*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}