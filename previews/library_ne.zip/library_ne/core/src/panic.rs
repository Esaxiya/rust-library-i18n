//! Panic मानक पुस्तकालयमा समर्थन।

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// panic को बारेमा जानकारी प्रदान गर्ने संरचना।
///
/// `PanicInfo` संरचना 0panic hook मा पारित गरियो [`set_hook`] प्रकार्य द्वारा सेट।
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// panic सँग सम्बन्धित पेलोड फर्काउँछ।
    ///
    /// यो सामान्यतया, तर सँधै हुँदैन, एक `&'static str` वा [`String`]।
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// यदि `core` crate (`std` बाट होईन) बाट `panic!` म्याक्रो ढाँचा स्ट्रि and र केही थप आर्गुमेन्टहरूको साथ प्रयोग गरिएको थियो भने, त्यो सन्देश [`fmt::write`] का साथ उदाहरणका लागि प्रयोग गर्नका लागि तयार हुन्छ।
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// panic उत्पत्ति भएको छ भने स्थानको बारेमा जानकारी फर्काउँछ, यदि उपलब्ध छ भने।
    ///
    /// यो विधि वर्तमानमा सँधै [`Some`] फर्काउँछ, तर यो future संस्करणहरूमा परिवर्तन हुन सक्दछ।
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: यदि यो कहिलेकाँही फिर्ता कुनैमा फिर्ता परिवर्तन गरियो
        // std::panicking::default_hook र std::panicking::begin_panic_fmt मा त्यस मामलासँग सम्झौता गर्नुहोस्।
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: हामी डाउनकास्ट_रेफ: : प्रयोग गर्न सक्दैनौं<String>() यहाँ
        // स्ट्रिंग लाइबकोरमा उपलब्ध छैन!
        // पेलोड एक स्ट्रि is हो जब `std::panic!` बहु तर्कहरूको साथ बोलाइन्छ, तर त्यो अवस्थामा सन्देश पनि उपलब्ध हुन्छ।
        //

        self.location.fmt(formatter)
    }
}

/// panic को स्थानको बारेमा जानकारी समावेश एउटा संरचना।
///
/// यो संरचना [`PanicInfo::location()`] द्वारा बनाईएको हो।
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// समानता र अर्डरिंगको तुलना फाईल, लाइन, त्यसपछि स्तम्भ प्राथमिकतामा गरिन्छ।
/// फाईलहरू `Path` होईन, तारको रूपमा तुलना गरिएको छ, जुन अप्रत्याशित हुन सक्छ।
/// अधिक छलफलको लागि [`स्थान: : फाइल`] को कागजात हेर्नुहोस्।
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// यस प्रकार्यको कलरको स्रोत स्थान फर्काउँछ।
    /// यदि त्यस प्रकार्यको कलर एनोटेट गरिएको छ भने यसको कल स्थान फिर्ता हुनेछ, र यस्तै स्ट्याक अप पहिलो ट्र्याकमा ट्र्याक नभएको प्रकार्य शरीर भित्र।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// यो कल गरिएको [`Location`] फर्काउँछ।
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// यस प्रकार्यको परिभाषा भित्रबाट एक [`Location`] फर्काउँछ।
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // बिभिन्न स्थानमा उस्तै ट्रयाक गरिएको प्रकार्य चलाउँदा हामीलाई समान परिणाम दिन्छ
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // ट्र्याक गरिएको प्रकार्य बिभिन्न स्थानमा चलाउँदा फरक मानको उत्पादन हुन्छ
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// panic उत्पन्न भएको स्रोत फाईलको नाम फर्काउँछ।
    ///
    /// # `&str`, `&Path` होईन
    ///
    /// फिर्ता गरिएको नामले कम्पाइल प्रणालीमा श्रोत मार्गलाई जनाउँछ, तर यसलाई सिधा `&Path` को रूपमा प्रतिनिधित्व गर्न मान्य छैन।
    /// कम्पाइल गरिएको कोड फरक प्रणालीमा चलाउन सक्छ बिभिन्न `Path` कार्यान्वयनको साथ सामग्री प्रदान गर्ने प्रणाली र यस पुस्तकालयमा हाल भिन्न "host path" प्रकार छैन।
    ///
    /// सबैभन्दा आश्चर्यजनक व्यवहार तब हुन्छ जब "the same" फाईल मोड्युल प्रणालीमा बहु पथहरू मार्फत पहुँचयोग्य हुन्छ (सामान्यतया `#[path = "..."]` विशेषता वा समान प्रयोग गर्दै), जसले यस प्रकार्यबाट फरक मानहरू फिर्ता गर्न समान कोड जस्तो देखिन सक्छ।
    ///
    ///
    /// # Cross-compilation
    ///
    /// यो मान `Path::new` वा समान कन्स्ट्रक्टर पास गर्नका लागि उपयुक्त हुँदैन जब होस्ट प्लेटफर्म र लक्षित प्लेटफर्म फरक हुन्छ।
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// panic उत्पन्न भएको लाइन नम्बर फर्काउँछ।
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// panic उत्पन्न भएको स्तम्भ फर्काउँछ।
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// Libstd बाट `panic_unwind` र अन्य panic रनटाइममा डाटा पास गर्न libstd द्वारा प्रयोग गरिएको एक आन्तरिक trait।
/// कुनै पनि समय चाँडै स्थिर हुने उद्देश्यले गरिएको छैन, प्रयोग नगर्नुहोस्।
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// सामग्रीको पूर्ण स्वामित्व लिनुहोस्।
    /// फिर्ती प्रकार वास्तवमा `Box<dyn Any + Send>` हो, तर हामी लिबकोरमा `Box` प्रयोग गर्न सक्दैनौं।
    ///
    /// यो विधि कल भएपछि, केहि डमी पूर्वनिर्धारित मान `self` मा बाँकी छ।
    /// यस विधिलाई दुई पटक कल गर्नु, वा `get` लाई कल गर्नु यस विधिलाई कल गर्नु एक त्रुटि हो।
    ///
    /// आर्गुमेन्ट उधारो लिइएको छ किनकी panic रनटाइम (`__rust_start_panic`) मात्र एक orrowण लिइएको `dyn BoxMeUp` प्राप्त गर्दछ।
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// सामग्री मात्र उधारो लिनुहोस्।
    fn get(&mut self) -> &(dyn Any + Send);
}