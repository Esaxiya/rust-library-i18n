//! `&[T]` र `&mut [T]` सिर्जना गर्न निःशुल्क प्रकार्यहरू।

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// सूचक र लम्बाइबाट स्लाइस फर्म गर्दछ।
///
/// `len` आर्गुमेन्ट **एलिमेन्ट्स** को संख्या हो, बाइट्सको संख्या होईन।
///
/// # Safety
///
/// निम्न शर्तहरु मध्ये कुनै एक उल्लंघन गरिएको छ भने व्यवहार अपरिभाषित छ:
///
/// * `data` `len * mem::size_of::<T>()` धेरै बाइट्सका लागि पढ्नको लागि [valid] हुनुपर्दछ, र यो सही प al्क्तिबद्ध गरिएको हुनुपर्दछ।यसको अर्थ विशेष रूपमा:
///
///     * यस स्लाइसको सम्पूर्ण मेमोरी दायरा एकल विनियोजित वस्तु बीचमा हुनुपर्दछ!
///       स्लाइसहरू कहिले पनि बहु नियत वस्तुहरूमा फ्याँक्न सक्दैन।[below](#incorrect-usage) हेर्नुहोस् उदाहरणको लागि गलत यसलाई ध्यानमा राख्नुहुन्न।
///     * `data` शून्य-लम्बाइका स्लाइसहरूका लागि पनि गैर-शून्य र पigned्क्तिबद्ध हुनै पर्छ।
///     यसको लागि एक कारण यो हो कि एनम लेआउट अप्टिमाइजेसनहरू सन्दर्भमा निर्भर हुन सक्छ (कुनै पनि लम्बाइको स्लाइसहरू सहित) पigned्क्तिबद्ध गरिएको छ र गैर डाटालाई अन्य डाटाबाट छुट्ट्याउन।
///     तपाइँले एक सूचक प्राप्त गर्न सक्नुहुन्छ जुन [`NonNull::dangling()`] को प्रयोग गरेर शून्य-लम्बाइका स्लाइसहरूको लागि `data` को रूपमा प्रयोग योग्य छ।
///
/// * `data` प्रकार `T` को क्रमशः राम्रोसँग आरम्भ गरिएको मानहरू `len` मा देखाउनु पर्छ।
///
/// * फिर्ता स्लाइस द्वारा संदर्भित स्मृति `UnsafeCell` X भित्र बाहेक, `'a` जीवनकालको अवधिको लागि परिवर्तित गर्नु हुँदैन।
///
/// * स्लाइसको कुल आकार `len * mem::size_of::<T>()` `isize::MAX` भन्दा ठूलो हुनु हुँदैन।
///   [`pointer::offset`] को सुरक्षा दस्तावेज हेर्नुहोस्।
///
/// # Caveat
///
/// फिर्ता स्लाईस को लागी जीवनकाल यसको उपयोग बाट inferred छ।
/// आकस्मिक दुरुपयोग रोक्नको लागि, यसलाई जीवनभर जोसुकैले पनि बाँच्न सुझाव दिन्छ जुन जीवनको स्रोत जीवनकालमा सुरक्षित छ, जस्तै स्लाइसको लागि होस्ट मूल्यको जीवनकाल लिने सहयोगी समारोह प्रदान गरेर, वा स्पष्ट एनोटेशन द्वारा।
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // एकल तत्वका लागि स्लाइस प्रकट गर्नुहोस्
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### गलत प्रयोग
///
/// निम्न `join_slices` प्रकार्य **अनबाउन्ड** ⚠️ हो
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // माथिको जोडले `fst` र `snd` संगत छन् भनेर सुनिश्चित गर्दछ, तर तिनीहरू अझै पनि _different allocated objects_ भित्र समावेश गर्न सक्दछन्, जहाँ यस्तो स्लाइस बनाउने अपरिभाषित व्यवहार हो।
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` र `b` बिभिन्न आबंटित वस्तुहरू हुन् ...
///     let a = 42;
///     let b = 27;
///     // ... जुन जे भए पनि स्मृति मा संगै राखिन्छ: |एक |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // सुरक्षा: कलरले `from_raw_parts` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ।
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// [`from_raw_parts`] को रूपमा उही कार्यक्षमता प्रदर्शन गर्दछ, एक परिवर्तनीय स्लाईस फिर्ती बाहेक।
///
/// # Safety
///
/// निम्न शर्तहरु मध्ये कुनै एक उल्लंघन गरिएको छ भने व्यवहार अपरिभाषित छ:
///
/// * `data` दुबै `len * mem::size_of::<T>()` धेरै बाइट्सका लागि पढ्न र लेख्नको लागि [valid] हुनुपर्दछ, र यो सही पigned्क्तिबद्ध गरिएको हुनुपर्दछ।यसको अर्थ विशेष रूपमा:
///
///     * यस स्लाइसको सम्पूर्ण मेमोरी दायरा एकल विनियोजित वस्तु बीचमा हुनुपर्दछ!
///       स्लाइसहरू कहिले पनि बहु नियत वस्तुहरूमा फ्याँक्न सक्दैन।
///     * `data` शून्य-लम्बाइका स्लाइसहरूका लागि पनि गैर-शून्य र पigned्क्तिबद्ध हुनै पर्छ।
///     यसको लागि एक कारण यो हो कि एनम लेआउट अप्टिमाइजेसनहरू सन्दर्भमा निर्भर हुन सक्छ (कुनै पनि लम्बाइको स्लाइसहरू सहित) पigned्क्तिबद्ध गरिएको छ र गैर डाटालाई अन्य डाटाबाट छुट्ट्याउन।
///
///     तपाइँले एक सूचक प्राप्त गर्न सक्नुहुन्छ जुन [`NonNull::dangling()`] को प्रयोग गरेर शून्य-लम्बाइका स्लाइसहरूको लागि `data` को रूपमा प्रयोग योग्य छ।
///
/// * `data` प्रकार `T` को क्रमशः राम्रोसँग आरम्भ गरिएको मानहरू `len` मा देखाउनु पर्छ।
///
/// * फिर्ता स्लाईस द्वारा संदर्भित मेमोरी कुनै पनि अन्य सूचक (फिर्ता मानबाट उत्पन्न हुँदैन) लाई आजीवन `'a` को अवधिमा पहुँच गर्न हुदैन।
///   दुबै पढ्ने र लेख्ने पहुँच निषेधित छ।
///
/// * स्लाइसको कुल आकार `len * mem::size_of::<T>()` `isize::MAX` भन्दा ठूलो हुनु हुँदैन।
///   [`pointer::offset`] को सुरक्षा दस्तावेज हेर्नुहोस्।
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // सुरक्षा: कलरले `from_raw_parts_mut` को लागी सुरक्षा सम्झौता समर्थन गर्नु पर्छ।
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// T लाई संदर्भ १ लाई लम्बाई १ को प्रतिलिपिमा बदल्छ (प्रतिलिपि नगरी)।
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// T लाई संदर्भ १ लाई लम्बाई १ को प्रतिलिपिमा बदल्छ (प्रतिलिपि नगरी)।
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}