//! ASCII `[u8]` मा अपरेशन्स।

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// जाँच गर्दछ कि यदि यस स्लाइसमा सबै बाइटहरू ASCII दायरा भित्र छन्।
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// दुई स्लाइसहरू ASCII केस-असंवेदनशील खेल हो भनेर जाँच गर्दछ।
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` को रूपमा उस्तै, तर अस्थायी वाटप र प्रतिलिपि बिना।
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// यस स्लाइसलाई यसको ASCII माथिल्लो केसमा बराबर स्थानमा रूपान्तरण गर्दछ।
    ///
    /// 'z' लाई 'a' लाई ASCII अक्षरहरू 'A' लाई 'Z' मा म्याप गरिएको छ, तर गैर-ASCII अक्षर परिवर्तन गरिएको छैन।
    ///
    /// अवस्थित एकलाई परिमार्जन नगरी नयाँ ठूलो ठूलो मान फर्काउन [`to_ascii_uppercase`] प्रयोग गर्नुहोस्।
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// यस स्लाइसलाई यसको ASCII लोअर केसमा बराबर स्थानमा रूपान्तरण गर्दछ।
    ///
    /// 'Z' लाई 'A' लाई ASCII अक्षरहरू 'a' लाई 'z' मा म्याप गरिएको छ, तर गैर-ASCII अक्षर परिवर्तन गरिएको छैन।
    ///
    /// अवस्थित एकलाई परिमार्जन नगरी नयाँ लोअरकेस मान फिर्ता गर्न [`to_ascii_lowercase`] प्रयोग गर्नुहोस्।
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// `true` फर्काउँदछ यदि `v` शब्दमा कुनै बाइट भने nonascii (>=128) हो।
/// `../str/mod.rs` बाट Snarfed, जसले utf8 मान्यताको लागि केहि समान गर्दछ।
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// अनुकूलित ASCII परीक्षणले बाइट-ए-ए-टाइम अपरेसनहरू (जब सम्भव हुन्छ) को सट्टामा us-at-a-a समय कामहरू प्रयोग गर्दछ।
///
/// हामीले यहाँ प्रयोग गर्ने एल्गोरिथ्म एकदम सरल छ।यदि `s` कम छ भने, हामी केवल प्रत्येक बाइट जाँच गर्छौं र योसँगै सम्पन्न हुन्छौं।अन्यथा:
///
/// - पहिलो हस्ताक्षर एक अनहाइन्डन लोडको साथ पढ्नुहोस्।
/// - सूचक लाई पign्क्तिबद्ध गर्नुहोस्, प words्क्तिबद्ध प read्क्तिहरू प read्क्तिबद्ध भारको साथ अन्त सम्म पढ्नुहोस्।
/// - पछिल्लो `usize` `s` बाट एक हस्ताक्षर नगरिएको लोडको साथ पढ्नुहोस्।
///
/// यदि यी मध्ये कुनै पनि `contains_nonascii` (above) साँचो फिर्ता को लागि केहि उत्पादन गर्दछ भने, तब हामी उत्तर गलत छ थाहा छ।
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // यदि हामी शब्द-ए-ए-टाइम कार्यान्वयनबाट केहि पनि प्राप्त गर्दैनौं भने, स्केलर लूपमा फिर्ता जानुहोस्।
    //
    // हामी यो पनि आर्किटेक्चरका लागि गर्छौं जहाँ `size_of::<usize>()` `usize` को लागी पर्याप्त पign्क्तिबद्ध छैन, किनकि यो अनौंठो edge केस हो।
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // हामी जहिले पहिलो शब्द अनलिनेन्डिड पढ्छौं, जसको मतलब हो `align_offset` हो
    // ०, हामी प value्क्तिबद्ध पठनको लागि फेरि उही मान पढ्ने छौं।
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // सुरक्षा: हामी माथि `len < USIZE_SIZE` प्रमाणित गर्दछौं।
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // हामीले माथि केहि जाँच गरेका थियौं।
    // नोट गर्नुहोस् कि `offset_to_aligned` या त `align_offset` वा `USIZE_SIZE` हो, दुबै माथि माथि जाँच गरियो।
    //
    debug_assert!(offset_to_aligned <= len);

    // सुरक्षा: word_ptr (सही प al्क्तिबद्ध) प्रयोग ptr हो जुन हामी पढ्न प्रयोग गर्दछौं
    // टुक्राको मध्य भाग।
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` `word_ptr` को बाइट अनुक्रमणिका हो, लूप अन्त जाँचहरूको लागि प्रयोग गरिन्छ।
    let mut byte_pos = offset_to_aligned;

    // पारानोइया प al्क्तिबद्धको बारे जाँच गर्नुहोस्, किनकि हामी अनलिनेन्ड गरिएको लोडहरूको गुच्छा गर्न लाग्यौं।
    // अभ्यासमा यो `align_offset` मा बग बाहेक असम्भव हुनुपर्दछ।
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // पछिल्लो शब्दहरू पछिल्लो प check्क्तिबद्ध शब्द सम्म पढ्नुहोस्, पछिल्लो प al्क्तिमा बाहेक अन्तिम प check्क्तिबद्ध शब्दलाई बाहेक, पुच्छर सधैं एक `usize` हुन्छ भनेर निश्चित गर्न अतिरिक्त branch `byte_pos == len` मा।
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // सेनिटी जाँच गर्नुहोस् कि पठन सीमामा छ
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // र त्यो `byte_pos` होल्डको बारेमा हाम्रो मान्यताहरू।
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // सुरक्षा: हामीलाई थाहा छ `word_ptr` सही तरिकाले प al्क्तिबद्ध गरिएको छ (किनभने किनकि
        // `align_offset`), र हामी जान्दछौं कि हामीसंग `word_ptr` र अन्त्य बीच पर्याप्त बाइट छ
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // सुरक्षा: हामीलाई थाहा छ कि `byte_pos <= len - USIZE_SIZE`, जसको मतलब हो
        // यो `add` पछि, `word_ptr` अधिकतम एक-भूत-अन्त्यमा हुनेछ।
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // त्यहाँ एक मात्र `usize` बाँकी छ सुनिश्चित गर्न शुद्धता जाँच।
    // हाम्रो लूप सर्तबाट यो ग्यारेन्टी हुनुपर्दछ।
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // सुरक्षा: यो `len >= USIZE_SIZE` मा निर्भर गर्दछ, जुन हामी सुरुमा जाँच गर्छौं।
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}