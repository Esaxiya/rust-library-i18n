// मूल कार्यान्वयन rust-mechr बाट लिइएको।
// प्रतिलिपि अधिकार २०१ And एन्ड्र्यू गलान्ट, bluss र निकोलस कोच

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// काट्नुहोस् प्रयोग गर्नुहोस्।
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// `true` फिर्ता गर्दछ यदि `x` ले कुनै शून्य बाइट समावेश गर्दछ।
///
/// *मामिला कम्प्युटेसनल*, जे। अर्न्डटबाट:
///
/// "विचार भनेको प्रत्येक बाइट्सबाट एउटा घटाउनुहोस् र त्यसपछि बाइटहरू खोज्नुहोस् जहाँ orrowण ले सबै महत्त्वपूर्ण मार्गमा प्रचार गर्‍यो।
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// X001 मा बाइट `x` मिल्दो पहिलो अनुक्रमणिका फर्काउँछ।
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // साना स्लाइसहरूको लागि द्रुत मार्ग
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // एक पटकमा दुई `usize` शब्दहरू पढेर एकल बाइट मानको लागि स्क्यान गर्नुहोस्।
    //
    // XlX तीन भागमा विभाजन गर्नुहोस्
    // - पहिलो हस्ताक्षर पाठको पाठमा पigned्क्तिबद्ध गरिएको अघि, हस्ताक्षर नगरिएको शुरुवात भाग
    // - शरीर, एक पटकमा २ शब्दहरू द्वारा स्क्यान
    // - अन्तिम बाँकी भाग, <२ शब्द आकार

    // प al्क्तिबद्ध सीमामा खोजी गर्नुहोस्
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // पाठको मुख्य भाग खोजी गर्नुहोस्
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // SAFETY: जबको प्रेडिक्टले कम्तिमा २ * usize_bytes को दूरीको ग्यारेन्टी गर्दछ
        // अफसेट र स्लाइसको अन्त्यको बीचमा।
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // यदि त्यहाँ मिल्दो बाइट छ भने ब्रेक गर्नुहोस्
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // शरीर लूप रोकेपछि पोइन्ट पछि बाइट फेला पार्नुहोस्।
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// `text` मा बाइट `x` मिल्दो अन्तिम अनुक्रमणिका फर्काउँछ।
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // एक पटकमा दुई `usize` शब्दहरू पढेर एकल बाइट मानको लागि स्क्यान गर्नुहोस्।
    //
    // स्प्लिट `text` तीन भागमा:
    // - अन्नाइन्ड टेल, पछिल्लो शब्द प address्क्तिमा पigned्क्तिबद्ध गरिएको ठेगाना पछि
    // - शरीर, एक पटकमा २ शब्दहरू द्वारा स्क्यान,
    // - पहिलो बाँकी बाइट्स, <२ शब्द आकार।
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // हामी यसलाई उपसर्ग र प्रत्यय को लम्बाई प्राप्त गर्नका लागि कल गर्दछौं।
        // बीचमा हामी जहिले पनि एक पटकमा दुई भागहरू प्रशोधन गर्दछौं।
        // सुरक्षा: `[u8]` लाई `[usize]` मा ट्रान्समिट गर्नु सुरक्षित छ `align_to` X द्वारा ह्यान्डल गरिएका आकार भिन्नता बाहेक।
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // पाठको मुख्य भाग खोजी गर्नुहोस्, निश्चित गर्नुहोस् कि हामी मिनेट_लिनेन्ड_अफसेट पार गर्दैनौं।
    // अफसेट सँधै पigned्क्तिबद्ध हुन्छ, त्यसैले मात्र `>` परीक्षण पर्याप्त छ र सम्भव ओभरफ्लोलाई बेवास्ता गर्दछ।
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // सुरक्षा: अफसेट लेन, suffix.len() मा सुरू हुन्छ, जबसम्म यो भन्दा ठूलो छ
        // min_aligned_offset (prefix.len()) बाँकी दूरी कम्तिमा २ * भाग_बाइट्स हो।
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // त्यहाँ मिल्दो बाइट छ भने ब्रेक गर्नुहोस्।
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // बाइट खोज्नुहोस् पोइन्ट अघि शरीर लूप रोक्नु अघि।
    text[..offset].iter().rposition(|elt| *elt == x)
}