// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// दायरा `[mid-left, mid+right)` घुमाउँदछ जुन `mid` मा एलिमेन्ट पहिलो तत्व हुन्छ।समान रूपमा, दायरा `left` एलिमेन्टहरूलाई बाँया वा `right` एलिमेन्टहरूलाई दायाँ घुमाउँछ।
///
/// # Safety
///
/// निर्दिष्ट दायरा पढ्न र लेख्नका लागि मान्य हुनुपर्दछ।
///
/// # Algorithm
///
/// एल्गोरिथ्म १ `left + right` को सानो मान वा ठूलो `T` का लागि प्रयोग गरीन्छ।
/// तत्वहरू अन्तिम लि one्कमा एक पटक `mid - left` मा शुरू हुन्छन् र `right` चरणहरू Modulo `left + right` द्वारा अगाडि बढाइन्छ, त्यस्तै कि केवल एक अस्थायी आवश्यक छ।
/// अन्तत: हामी `mid - left` मा फर्क्यौं।
/// जहाँसम्म, यदि `gcd(left + right, right)` 1 छैन भने, माथिको चरणहरू तत्वहरूमा छोडियो।
/// उदाहरण को लागी:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// भाग्यवस, अन्तिम तत्वहरू बीच तत्वहरूमा छोडियो संख्या सँधै बराबर हुन्छ, त्यसैले हामी केवल हाम्रो सुरूवात स्थिति अफसेट गर्न सक्दछौं र अधिक गोलहरू गर्न सक्दछ (राउन्ड्सको कुल संख्या `gcd(left + right, right)` value) हो।
///
/// अन्तिम परिणाम यो हो कि सबै तत्वहरू एक पटक र एक पटक मात्र अन्तिम हुन्छ।
///
/// एल्गोरिथ्म २ प्रयोग गरिन्छ यदि `left + right` ठूलो छ तर `min(left, right)` पर्याप्त सानो छ एक स्ट्याक बफर मा फिट गर्न।
/// `min(left, right)` एलिमेन्टहरू बफरमा प्रतिलिपि हुन्छन्, `memmove` अरूलाई लागू हुन्छ, र बफरमा भएका व्यक्तिहरू फेरि उत्पत्ति भएको विपरित छेउमा प्वालमा सारिन्छ।
///
/// एक पटक `left + right` पर्याप्त ठूलो भएपछि माथिल्लो प्रदर्शनमा भेक्टरमा पुर्‍याउन सकिने एल्गोरिदमहरू।
/// एल्गोरिथ्म १ लाई एकचोटि धेरै राउन्ड छाँटकाँट गरेर प्रदर्शन गर्न सकिन्छ, तर त्यहाँ औसतमा केहि राउन्डहरू छन् जबसम्म `left + right` विशाल हुँदैन, र एकल राउन्डको नराम्रो केस सधैं हुन्छ।
/// यसको सट्टामा, एल्गोरिथ्म ले `min(left, right)` एलिमेन्ट्सको बारम्बार स्व्यापिंगको उपयोग गर्दछ जब सम्म सानो घुमाउने समस्या बाँकी हुँदैन।
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// जब `left < right` बदल्नुको सट्टा बायाँबाट हुन्छ।
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. यदि यी केसहरू जाँच गरिएन भने तलको एल्गोरिदमहरू असफल हुन सक्दछन्
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // एल्गोरिथ्म १ माइक्रोबेन्चमार्कले संकेत गर्दछ कि अनियमित पालीहरूका लागि औसत प्रदर्शन लगभग `left + right == 32` सम्म सबै तरिकाले राम्रो हुन्छ, तर सबैभन्दा खराब केसको प्रदर्शन १ around भन्दा पनि टुक्रिन्छ।
            // २ middle बीचको मैदानको रूपमा छनौट गरिएको थियो।
            // यदि `T` को आकार ``usize`s भन्दा ठूलो छ भने, यो एल्गोरिथ्मले अन्य एल्गोरिदमलाई पनि प्रदर्शन गर्दछ।
            //
            //
            let x = unsafe { mid.sub(left) };
            // पहिलो चरणको सुरुवात
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` `gcd(left + right, right)` को गणना गरेर हात अघि फेला पार्न सकिन्छ, तर यो एक लूप गर्न छिटो हुन्छ जुन gcd लाई साइड इफेक्टको रूपमा गणना गर्दछ, त्यसपछि बाँकी भागलाई गरेर।
            //
            //
            let mut gcd = right;
            // बेन्चमार्कले पत्ता लगायो कि अस्थायीहरू एक पटक पढ्नुको सट्टामा पछाडि प्रतिलिपि गर्नुको सट्टा सम्पूर्ण रूपमा अस्थायी रूप बदल्न चाँडो हुन्छ र अन्तमा त्यो अस्थायी लेख्न।
            // यो सायद यो तथ्यको कारणले हो कि अस्थायी अदलीकरण वा बदलीले दुईलाई व्यवस्थापन गर्नुको सट्टा लूपमा केवल एक मेमोरी ठेगाना प्रयोग गर्दछ।
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // `i` बढाउनुको सट्टा र त्यसपछि यो सीमा बाहिर छ कि छैन जाँच, हामी `i` अर्को वृद्धिमा सीमा बाहिर बाहिर जान्छौं कि जाँच।
                // यसले पोइन्टर वा `usize` को कुनै र्यापि। रोक्दछ।
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // पहिलो राउन्डको अन्त्य
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // यो ससर्त यहाँ `left + right >= 15` हुनु पर्छ
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // अधिक गोलको साथ भाग समाप्त गर्नुहोस्
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` शून्य आकारको प्रकार होईन, त्यसैले यसको साइजले भाग गर्न ठीक छ।
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // एल्गोरिथ्म २ यहाँ `[T; 0]` यो सुनिश्चित गर्न को लागी उचित T को लागी गरीएको छ
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // एल्गोरिथ्म sw त्यहाँ स्व्यापिंगको वैकल्पिक तरीका छ जुन यस एल्गोरिथ्मको अन्तिम स्वप कहाँ हुन्छ भन्ने पत्ता लगाउन समावेश गर्दछ, र अन्तिम एल्गको प्रयोग गरेर स्व्यापिंगको सट्टा यस एल्गोरिथ्म जस्तो आसन्न भागहरू स्वप्याप गर्दैछ, तर यो मार्ग अझै छिटो छ।
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // एल्गोरिथ्म,, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}