//! स्लाइसको इटरेटरहरूले प्रयोग गरेको म्याक्रोहरू।

// Inlining is_empty र लेनले ठूलो प्रदर्शन फरक पार्छ
macro_rules! is_empty {
    // जसरी हामी ZST पुनरावृत्तिको लम्बाई सode्केतन गर्दछ, यसले दुबै ZST र गैर-ZST का लागि काम गर्दछ।
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// केहि सीमा जाँचहरूबाट छुटकारा पाउन (हेर्नुहोस् `position`), हामी केही अनपेक्षित तरिकामा लम्बाइ गणना गर्छौं।
// (Gen Codegen/स्लाइस-स्थिति-सीमा-चेक` द्वारा परीक्षण गरिएको।)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // हामी कहिलेकाँही असुरक्षित खण्ड भित्र प्रयोग गर्दछौं

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // यो _cannot_ `unchecked_sub` प्रयोग गर्दछ किनकि हामी र्‍यापिंगमा निर्भर गर्दछौं लामो ZST स्लाइस इटरेटर्सको लम्बाई प्रतिनिधित्व गर्न।
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // हामीलाई थाहा छ कि `start <= end`, त्यसैले `offset_from` भन्दा राम्रो गर्न सक्दछ, जुन साइन इनमा सम्झौता गर्न आवश्यक पर्दछ।
            // यहाँ उपयुक्त फ्ल्यागहरू सेट गरेर हामी LLVM लाई यो बताउन सक्दछौं, जसले यसले सीमा जाँच हटाउन मद्दत गर्दछ।
            // सुरक्षा: प्रकार इन्वाइरन्टद्वारा, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // LLVM लाई यो पनि बताईयो कि सूचकहरू प्रकार आकारको सटीक बहुबाट अलग छन्, यसले `len() == 0` लाई `(end - start) < size` को सट्टा `start == end` मा अनुकूलित गर्न सक्दछ।
            //
            // सुरक्षा: प्रकार इन्वाइरन्टद्वारा, पोइन्टरहरू पigned्क्तिबद्ध गरियो त्यसैले
            //         ती दुरी बीचको दूरी पोइन्टी साइजको एकाधिक हुनुपर्दछ
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// `Iter` र `IterMut` पुनरावृत्तिको साझा परिभाषा
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // पहिलो एलिमेन्ट फर्काउँछ र 1 बाट अगाडि बढ्ने इटरेटरको सुरूवात गर्दछ।
        // ईनलाईन प्रकार्यको तुलनामा प्रदर्शनमा उत्कृष्ट सुधार गर्दछ।
        // इटरेटर खाली हुनु हुँदैन।
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // अन्तिम एलिमेन्ट फर्काउँछ र 1 द्वारा पछिटरको अन्त्य सार्छ।
        // ईनलाईन प्रकार्यको तुलनामा प्रदर्शनमा उत्कृष्ट सुधार गर्दछ।
        // इटरेटर खाली हुनु हुँदैन।
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // इरेटरलाई सानो बनाउँदछ जब T ZST हुन्छ, एक्सट्रेटरको अन्त्यलाई `n` द्वारा पछिल्तिर सार्दै।
        // `n` `self.len()` भन्दा बढि हुनु हुँदैन।
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // ईटरेटरबाट स्लाइस सिर्जना गर्नका लागि सहयोगी प्रकार्य।
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // सुरक्षा: पुनरावृत्ति सूचकको साथ स्लाइसबाट सिर्जना गरिएको थियो
                // `self.ptr` र लम्बाई `len!(self)`।
                // यसले ग्यारेन्टी गर्दछ कि `from_raw_parts` का लागि सबै शर्तहरू पूरा भए।
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // पुरानो सुरुवात फिर्ता गर्दै, `offset` एलिमेन्टहरू द्वारा इट्रेटर अगाडि सार्नको लागि सहयोगी कार्य।
            //
            // असुरक्षित किनकि अफसेट `self.len()` भन्दा बढि हुनु हुँदैन।
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // सुरक्षा: कलरले ग्यारेन्टी दिन्छ कि `offset` `self.len()` भन्दा बढि छैन,
                    // त्यसोभए यो नयाँ सूचक `self` भित्र छ र यसैले नल नलिन ग्यारेन्टी गरिएको छ।
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // एक्सरेक्सको अन्त्यमा `offset` एलिमेन्टहरू द्वारा पछाडि सर्दै नयाँ सहायक फिर्ताका लागि सहयोगी कार्य।
            //
            // असुरक्षित किनकि अफसेट `self.len()` भन्दा बढि हुनु हुँदैन।
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // सुरक्षा: कलरले ग्यारेन्टी दिन्छ कि `offset` `self.len()` भन्दा बढि छैन,
                    // जुन `isize` ओभरफ्लो नहुने ग्यारेन्टी गरिएको छ।
                    // साथै, परिणामस्वरूप सूचक `slice` को सीमा भित्र छ, जसले `offset` का लागि अन्य आवश्यकताहरू पूरा गर्दछ।
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // स्लाइसहरू मार्फत लागू गर्न सकिन्छ, तर यसले सीमा जाँचहरू बेवास्ता गर्दछ

                // सुरक्षा: `assume` कलहरू स्लाइसको सुरू सूचक पछि सुरक्षित छन्
                // गैर-शून्य हुनुपर्दछ, र Z-ZST मा टुक्राहरूमा गैर-शून्य अन्तिम सूचक पनि हुनुपर्दछ।
                // `next_unchecked!` मा कल सुरक्षित छ किनकि हामीले जाँच गर्यौं कि यदि एट्रेटर पहिले खाली छ भने।
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // यो इट्रेटर अब खाली छ।
                    if mem::size_of::<T>() == 0 {
                        // हामीले यसलाई यो तरिकाले गर्नुपर्दछ किनकि `ptr` कहिले पनि ० हुन सक्दैन, तर `end` हुन सक्छ (र्‍यापि toको कारण)।
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // सुरक्षा: अन्त ० हुन सक्दैन यदि T ZST होईन किनकि ptr ० छैन र अन्त्य>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // सुरक्षा: हामी सीमित छौं।`post_inc_start` ZSTs को लागि पनि सही काम गर्दछ।
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // हामी पूर्वनिर्धारित कार्यान्वयनलाई ओभरराइड गर्दछौं, जसले `try_fold` प्रयोग गर्दछ, किनकि यो साधारण कार्यान्वयनले कम LLVM IR उत्पन्न गर्छ र कम्पाइल गर्न द्रुत छ।
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // हामी पूर्वनिर्धारित कार्यान्वयनलाई ओभरराइड गर्दछौं, जसले `try_fold` प्रयोग गर्दछ, किनकि यो साधारण कार्यान्वयनले कम LLVM IR उत्पन्न गर्छ र कम्पाइल गर्न द्रुत छ।
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // हामी पूर्वनिर्धारित कार्यान्वयनलाई ओभरराइड गर्दछौं, जसले `try_fold` प्रयोग गर्दछ, किनकि यो साधारण कार्यान्वयनले कम LLVM IR उत्पन्न गर्छ र कम्पाइल गर्न द्रुत छ।
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // हामी पूर्वनिर्धारित कार्यान्वयनलाई ओभरराइड गर्दछौं, जसले `try_fold` प्रयोग गर्दछ, किनकि यो साधारण कार्यान्वयनले कम LLVM IR उत्पन्न गर्छ र कम्पाइल गर्न द्रुत छ।
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // हामी पूर्वनिर्धारित कार्यान्वयनलाई ओभरराइड गर्दछौं, जसले `try_fold` प्रयोग गर्दछ, किनकि यो साधारण कार्यान्वयनले कम LLVM IR उत्पन्न गर्छ र कम्पाइल गर्न द्रुत छ।
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // हामी पूर्वनिर्धारित कार्यान्वयनलाई ओभरराइड गर्दछौं, जसले `try_fold` प्रयोग गर्दछ, किनकि यो साधारण कार्यान्वयनले कम LLVM IR उत्पन्न गर्छ र कम्पाइल गर्न द्रुत छ।
            // साथै, `assume` एक सीमा जाँच बेवास्ता गर्दछ।
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // सुरक्षा: हामी लूप इन्वाइरन्टद्वारा सीमित हुन ग्यारेन्टी गरिएको छ:
                        // जब `i >= n`, `self.next()` `None` र लूप ब्रेक फिर्ता गर्दछ।
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // हामी पूर्वनिर्धारित कार्यान्वयनलाई ओभरराइड गर्दछौं, जसले `try_fold` प्रयोग गर्दछ, किनकि यो साधारण कार्यान्वयनले कम LLVM IR उत्पन्न गर्छ र कम्पाइल गर्न द्रुत छ।
            // साथै, `assume` एक सीमा जाँच बेवास्ता गर्दछ।
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // सुरक्षा: `i` `n` भन्दा कम हुनुपर्दछ जब यो `n` मा शुरू हुन्छ
                        // र केवल कम हुँदैछ।
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // सुरक्षा: कलरले `i` को दायरा भित्र छ भनेर ग्यारेन्टी गर्नै पर्छ
                // अन्तर्निहित स्लाइस, त्यसैले `i` एक `isize` ओभरफ्लो गर्न सक्दैन, र फिर्ता सन्दर्भ स्लाइस को एक तत्व सन्दर्भ ग्यारेन्टी छ र यसरी मान्य हुन ग्यारेन्टी।
                //
                // र नोट गर्नुहोस् कि कलरले ग्यारेन्टी पनि दिन्छ कि हामीलाई फेरि उही सूचकांकको साथ कहिलै पनि बोलाइएको छैन, र कुनै पनि अन्य विधिहरू जुन यो उप-उपसाधन पहुँच गर्दैन भनिन्छ, त्यसैले यो फिर्ती सन्दर्भको लागि वैध हुन्छ वैकल्पिक अवस्थामा
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // स्लाइसहरू मार्फत लागू गर्न सकिन्छ, तर यसले सीमा जाँचहरू बेवास्ता गर्दछ

                // सुरक्षा: `assume` कल सुरक्षित छ किनकि स्लाईसको सुरू पोइन्टर गैर-अशक्त हुनुपर्दछ,
                // र गैर-ZSTs मा स्लाइसहरूसँग नल-नल अन्त सूचक पनि हुनुपर्दछ।
                // `next_back_unchecked!` मा कल सुरक्षित छ किनकि हामीले जाँच गर्यौं कि यदि एट्रेटर पहिले खाली छ भने।
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // यो इट्रेटर अब खाली छ।
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // सुरक्षा: हामी सीमित छौं।`pre_dec_end` ZSTs को लागि पनि सही काम गर्दछ।
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}