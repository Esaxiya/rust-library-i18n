//! टुक्रा क्रमबद्ध
//!
//! यस मोड्युलले ओर्सन पीटर्सको ढाँचामा पराजित क्विकोर्टमा आधारित छँटेको एल्गोरिथ्म समावेश गर्दछ, यहाँ प्रकाशित: <https://github.com/orlp/pdqsort>
//!
//!
//! अस्थिर वर्गीकरण लिबकोरसँग मिल्दो छ किनकि यसले स्मृतिको बाँडफाँड गर्दैन, हाम्रो स्थिर क्रमबद्ध कार्यान्वयनको विपरीत।
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// जब छोडियो, `src` बाट `dest` मा प्रतिलिपिहरू।
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // सुरक्षा: यो एक सहयोगी वर्ग हो।
        //          शुद्धताको लागि यसको प्रयोगलाई हेर्नुहोस्।
        //          अर्थात्, एकले `src` र `dst` `ptr::copy_nonoverlapping` द्वारा आवश्यक ओवरलैप हुँदैन भनेर निश्चित हुनुपर्दछ।
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// पहिलो तत्वलाई दायाँ सिफ्ट गर्नुहोस् जब सम्म यो ठूलो वा बराबर तत्त्वको सामना गर्दैन।
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // सुरक्षा: तल असुरक्षित अपरेशनहरूमा बाउन्ड चेक (`get_unchecked` र `get_unchecked_mut`) बिना अनुक्रमणिका समावेश छ।
    // र मेमोरी (`ptr::copy_nonoverlapping`) प्रतिलिपि गर्दै।
    //
    // aअनुक्रमणिका:
    //  1. हामीले एर्रेको आकार>=२ मा जाँच्यौं।
    //  2. सबै अनुक्रमणिका जुन हामी गर्छौं अधिकतम {0 <= index < len} को बीचमा हुन्छ।
    //
    // bमेमोरी प्रतिलिपि गर्दै
    //  1. हामी सन्दर्भमा पोइन्टरहरू प्राप्त गर्दै छौं जुन मान्य हुन ग्यारेन्टी गरिएको छ।
    //  2. तिनीहरू ओभरल्याप गर्न सक्दैन किनकि हामी स्लाइसको सूचकहरू फरक पार्ने सूचकहरू प्राप्त गर्दछौं।
    //     अर्थात्, `i` र `i-1`।
    //  3. यदि स्लाइस राम्रोसँग पigned्क्तिबद्ध गरियो भने, तत्वहरू ठीक प properly्क्तिबद्ध गरियो।
    //     यो कलरको जिम्मेवारी हो कि स्लाइस सही तरिकाले पigned्क्तिबद्ध गरिएको छ।
    //
    // थप विवरणको लागि तल टिप्पणीहरू हेर्नुहोस्।
    unsafe {
        // यदि पहिलो दुई तत्वहरू-बाहिर-अर्डर छन् ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // पहिलो एलिमेन्ट स्ट्याक-विनियोजित चलमा पढ्नुहोस्।
            // यदि निम्न तुलना अपरेशन panics, `hole` ड्रप हुन्छ र स्वचालित रूपमा तत्वलाई स्लाइसमा लेख्दछ।
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // `I`-th एलिमेन्ट एक स्थानको बाँयामा सार्नुहोस्, यस प्रकार प्वाललाई दायाँ सार्नुहोस्।
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` झर्छ र यसैले `tmp` लाई `v` मा बाँकी प्वालमा प्रतिलिपि गर्दछ।
        }
    }
}

/// अन्तिम तत्वलाई बाँयामा बदल्नुहोस् जबसम्म यो सानो वा बराबर तत्त्वको सामना गर्दैन।
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // सुरक्षा: तल असुरक्षित अपरेशनहरूमा बाउन्ड चेक (`get_unchecked` र `get_unchecked_mut`) बिना अनुक्रमणिका समावेश छ।
    // र मेमोरी (`ptr::copy_nonoverlapping`) प्रतिलिपि गर्दै।
    //
    // aअनुक्रमणिका:
    //  1. हामीले एर्रेको आकार>=२ मा जाँच्यौं।
    //  2. सबै अनुक्रमणिका जुन हामी गर्छौं अधिकतम `0 <= index < len-1` को बीचमा हुन्छ।
    //
    // bमेमोरी प्रतिलिपि गर्दै
    //  1. हामी सन्दर्भमा पोइन्टरहरू प्राप्त गर्दै छौं जुन मान्य हुन ग्यारेन्टी गरिएको छ।
    //  2. तिनीहरू ओभरल्याप गर्न सक्दैन किनकि हामी स्लाइसको सूचकहरू फरक पार्ने सूचकहरू प्राप्त गर्दछौं।
    //     अर्थात्, `i` र `i+1`।
    //  3. यदि स्लाइस राम्रोसँग पigned्क्तिबद्ध गरियो भने, तत्वहरू ठीक प properly्क्तिबद्ध गरियो।
    //     यो कलरको जिम्मेवारी हो कि स्लाइस सही तरिकाले पigned्क्तिबद्ध गरिएको छ।
    //
    // थप विवरणको लागि तल टिप्पणीहरू हेर्नुहोस्।
    unsafe {
        // यदि अन्तिम दुई तत्वहरू क्रमानुसार छन् ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // अन्तिम तत्वलाई स्ट्याक-विनियोजित चलमा पढ्नुहोस्।
            // यदि निम्न तुलना अपरेशन panics, `hole` ड्रप हुन्छ र स्वचालित रूपमा तत्वलाई स्लाइसमा लेख्दछ।
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // `I`-th एलिमेन्ट एक स्थानको दायाँ सर्नुहोस्, यस प्रकार प्वाललाई बाँयामा सार्नुहोस्।
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` झर्छ र यसैले `tmp` लाई `v` मा बाँकी प्वालमा प्रतिलिपि गर्दछ।
        }
    }
}

/// आंशिक रूपमा क्रमबद्ध धेरै बाहिर अर्डर को तत्त्वहरूलाई स्थान परिवर्तन गरेर एक टुक्रा।
///
/// `true` फर्काउँछ यदि स्लाइस अन्त्यमा क्रमबद्ध गरियो।यो प्रकार्य *O*(*n*) सबैभन्दा खराब केस हो।
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // स adj्क्रमित हुने अर्डर-आउट-अफर जोडीहरूको अधिकतम संख्या।
    const MAX_STEPS: usize = 5;
    // यदि स्लाइस यस भन्दा छोटो छ भने कुनै पनि तत्व शिफ्ट नगर्नुहोस्।
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // सुरक्षा: हामीले `i < len` का साथ बाउन्ड जाँच स्पष्ट रूपमा गरेका छौं।
        // हाम्रो सबै पछिल्लो अनुक्रमणिका केवल `0 <= index < len` दायरामा छ
        unsafe {
            // आसन्न बाह्य-अर्डर-तत्व तत्त्वहरूको अर्को जोडी फेला पार्नुहोस्।
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // के हामीले सक्यौं?
        if i == len {
            return true;
        }

        // छोटो एर्रेमा एलिमेन्टहरू शिफ्ट नगर्नुहोस्, यसको प्रदर्शन लागत छ।
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // भेटिएको जोडी तत्वहरू स्वैप गर्नुहोस्।यसले तिनीहरूलाई सही क्रममा राख्दछ।
        v.swap(i - 1, i);

        // बायाँ मा सानो तत्व बदलाव।
        shift_tail(&mut v[..i], is_less);
        // ठूलो तत्व दायाँ सार्नुहोस्।
        shift_head(&mut v[i..], is_less);
    }

    // चरणहरूको सीमित संख्यामा स्लाइस क्रमबद्ध गर्न व्यवस्थित छैन।
    false
}

/// सम्मिलित प्रकारको प्रयोग गरेर स्लाइसलाई क्रमबद्ध गर्दछ, जुन *O*(*n*^ 2) खराब केसमा छ।
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// `v` हेप्सोर्टको प्रयोग गरेर क्रमबद्ध गर्दछ, जसले *O*(*n*\*log(* n*)) खराब अवस्था) लाई ग्यारेन्टी गर्दछ।
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // यो बाइनरी हिपले इन्भिएन्ट `parent >= child` लाई सम्मान गर्दछ।
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // `node` का बच्चाहरू:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // ठूलो बच्चा छनौट गर्नुहोस्।
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // रोक्नुहोस् यदि इन्भेर्नेटले `node` मा समात्छ।
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // ठूलो बच्चासँग `node` बदल्नुहोस्, एक चरण तल सार्नुहोस्, र सिफ्टि continue जारी राख्नुहोस्।
            v.swap(node, greater);
            node = greater;
        }
    };

    // रेखीय समयमा हिप बनाउनुहोस्।
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // हिपबाट अधिकतम तत्वहरू पप गर्नुहोस्।
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// `pivot` भन्दा सानो तत्वमा `v` विभाजनहरू, `pivot` भन्दा ठूलो वा बराबर तत्त्वहरू द्वारा पछ्याईन्छ।
///
///
/// `pivot` भन्दा सानो तत्वहरूको संख्या फर्काउँछ।
///
/// शाखा कार्यालय सञ्चालनको लागत न्यूनतम गर्न विभाजन ब्लक-दर-ब्लक प्रदर्शन गरिन्छ।
/// यो विचार [BlockQuicksort][pdf] कागज मा प्रस्तुत छ।
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // विशिष्ट ब्लकमा तत्वहरूको संख्या।
    const BLOCK: usize = 128;

    // विभाजन एल्गोरिथ्म पूरा नभएसम्म निम्न चरणहरू दोहोर्याउँदछ:
    //
    // 1. पिभट भन्दा ठूलो वा बराबर तत्त्वहरू पहिचान गर्न बायाँ तर्फबाट ब्लक ट्रेस गर्नुहोस्।
    // 2. पिभोट भन्दा सानो तत्वहरू पहिचान गर्न दायाँ तिरबाट ब्लक ट्रेस गर्नुहोस्।
    // 3. बायाँ र दायाँ पट्टि बीच पहिचान गरिएको तत्त्वहरूलाई आदान प्रदान
    //
    // तत्वहरूको ब्लकको लागि हामी निम्न भ्यारीएबलहरू राख्छौं:
    //
    // 1. `block` - ब्लकमा तत्वहरूको संख्या।
    // 2. `start` - सूचक सुरू गर्नुहोस् `offsets` एर्रेमा।
    // 3. `end` - `offsets` एर्रेमा अन्त्य सूचक।
    // 4. se अफसेटहरू, ब्लक भित्र-बाहिर-अर्डर तत्त्वहरूको सूचकहरू।

    // बायाँ पट्टीको वर्तमान ब्लक (`l` बाट `l.add(block_l)`) मा।
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // दायाँ पट्टीको वर्तमान ब्लक (`r.sub(block_r)` to `r`) बाट।
    // सुरक्षा: .add() का लागि दस्तावेजले `vec.as_ptr().add(vec.len())` सँधै सुरक्षित छ भनेर उल्लेख गर्दछ
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: जब हामी VLAs पाउँछौं, `min(v.len(), २ * BLOCK) को लम्बाइको एक एर्रे बनाउने प्रयास गर्नुहोस्-बरु
    // `BLOCK` लम्बाईको दुई निश्चित-आकार arrays भन्दा।VLAs अधिक क्याच-कुशल हुन सक्छ।

    // `l` (inclusive) र `r` (exclusive) बिचको तत्त्वहरूको संख्या फर्काउँछ।
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // `l` र `r` धेरै नजिक आएपछि हामी विभाजन ब्लक-द्वारा-ब्लकका साथ गर्यौं।
        // तब हामी बाँच्ने तत्त्वहरूलाई बीचमा विभाजन गर्न केहि प्याच-अप कार्य गर्छौं।
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // बाँकी तत्वहरूको संख्या (अझै पनि पिभोटसँग तुलना गरिएको छैन)।
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // ब्लक आकारहरू समायोजित गर्नुहोस् ताकि बायाँ र दायाँ खण्ड ओभरल्याप नहोस्, तर पूरै बाँकी अन्तरलाई कभर गर्नको लागि पूर्ण रूपमा पigned्क्तिबद्ध गर्नुहोस्।
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // बायाँ तर्फबाट `block_l` एलिमेन्टहरू ट्रेस गर्नुहोस्।
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // सुरक्षा: तल असुरक्षित अपरेसनहरूमा `offset` को उपयोग समावेश छ।
                //         समारोह द्वारा आवश्यक सर्तहरू अनुसार हामी तिनीहरूलाई संतुष्ट गर्छौं किनभने:
                //         1. `offsets_l` स्ट्याक-विनियोजित गरीएको छ, र यसरी अलग छुट्याइएको वस्तु मानिन्छ।
                //         2. प्रकार्य `is_less` ले `bool` फिर्ता गर्दछ।
                //            `bool` कास्ट गर्नाले कहिल्यै `isize` ओभरफ्लो हुने छैन।
                //         3. हामीले ग्यारेन्टी गरेका छौं कि `block_l` `<= BLOCK` हुनेछ।
                //            थप, `end_l` शुरूमा `offsets_` को शुरुवात सूचकमा सेट गरियो जुन स्ट्याकमा घोषित गरियो।
                //            यसैले, हामीलाई थाहा छ कि सबैभन्दा खराब अवस्थामा पनि (`is_less` का सबै आह्वानहरू गलत फर्काउँछन्) हामी अधिकतम १ बाइट अन्त मात्र पास हुनेछौं।
                //        यहाँ अर्को असुरक्षित अपरेसन `elem` लाई डिरेफर गर्दै छ।
                //        जे होस्, `elem` सुरूमा स्लाइसको लागि सुरू सूचक हो जुन सँधै मान्य हुन्छ।
                unsafe {
                    // शाखाविहीन तुलना।
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // दाँया पट्टिबाट `block_r` एलिमेन्टहरू ट्रेस गर्नुहोस्।
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // सुरक्षा: तल असुरक्षित अपरेसनहरूमा `offset` को उपयोग समावेश छ।
                //         समारोह द्वारा आवश्यक सर्तहरू अनुसार हामी तिनीहरूलाई संतुष्ट गर्छौं किनभने:
                //         1. `offsets_r` स्ट्याक-विनियोजित गरीएको छ, र यसरी अलग छुट्याइएको वस्तु मानिन्छ।
                //         2. प्रकार्य `is_less` ले `bool` फिर्ता गर्दछ।
                //            `bool` कास्ट गर्नाले कहिल्यै `isize` ओभरफ्लो हुने छैन।
                //         3. हामीले ग्यारेन्टी गरेका छौं कि `block_r` `<= BLOCK` हुनेछ।
                //            थप, `end_r` सुरुमा `offsets_` को शुरुवात सूचकमा सेट गरियो जुन स्ट्याकमा घोषित गरियो।
                //            यसैले, हामीलाई थाहा छ कि सबैभन्दा खराब अवस्थामा पनि (`is_less` का सबै आह्वानहरू सत्य फर्काउँछ) हामी अधिकतम १ बाइट अन्त मात्र पास हुनेछौं।
                //        यहाँ अर्को असुरक्षित अपरेसन `elem` लाई डिरेफर गर्दै छ।
                //        यद्यपि `elem` शुरुमा `1 *sizeof(T)` अन्त्यको बितेको थियो र हामी यसलाई `1* sizeof(T)` ले पहुँच गर्न अघि यसलाई घट्दछौं।
                //        प्लस, `block_r` `BLOCK` भन्दा कम हुन भनिएको थियो र `elem` तसर्थ स्लाइसको सुरूवाततिर अधिक देखाउने।
                unsafe {
                    // शाखाविहीन तुलना।
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // बायाँ र दायाँ पक्षको बीचमा स्व्याप गर्न-बाहिर-अर्डर तत्वहरूको संख्या।
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // यो समयमा एक जोडी बदल्नुको साटो चक्रीय क्रम बनाउन यो अझ बढी सक्षम छ।
            // यो कडाईका साथ अदला-बदलीको बराबर छैन, तर कम मेमोरी अपरेसनहरू प्रयोग गरेर यस्तै परिणामको परिणाम दिन्छ।
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // बाँया ब्लकमा सबै-बाहिर-अर्डर तत्वहरू सारियो।अर्को खण्डमा सार्नुहोस्।
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // सहि ब्लकमा सबै-बाहिर-अर्डर तत्वहरू सारियो।अघिल्लो ब्लकमा सार्नुहोस्।
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // सबै अब बाँकी सबै भन्दा बढि एक ब्लकमा छ (या त देब्रे वा दायाँ) को क्रममा-बाहिर-आदेश तत्वहरू जुन सार्न आवश्यक छ।
    // त्यस्ता बाँकी तत्वहरू सजिलैसँग तिनीहरूको ब्लक भित्र अन्तमा सर्न सकिन्छ।
    //

    if start_l < end_l {
        // बाँया खण्ड बाँकी छ।
        // यसका बाँकी-आउट-अर्डर तत्त्वहरू टाढा दायाँ सार्नुहोस्।
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // दायाँ ब्लक बाँकी छ।
        // टाढाको बाँयामा यसको बाँकी-आउट-अर्डर तत्त्वहरू सार्नुहोस्।
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // अरू केहि गर्न छैन, हामीले सक्यौं।
        width(v.as_mut_ptr(), l)
    }
}

/// `v[pivot]` भन्दा सानो तत्वमा `v` विभाजनहरू, `v[pivot]` भन्दा ठूलो वा बराबर तत्त्वहरू द्वारा पछ्याईन्छ।
///
///
/// को एक tuple फर्काउँछ:
///
/// 1. `v[pivot]` भन्दा सानो तत्वहरूको संख्या।
/// 2. सत्य यदि `v` पहिले नै विभाजित थियो।
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // स्लाइसको सुरूमा पिभोट राख्नुहोस्।
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // पिभोट दक्षताका लागि स्ट्याक-विनियोजित चलमा पढ्नुहोस्।
        // यदि निम्न तुलना अपरेशन panics, pivot स्वतः स्लाइसमा लेखिन्छ।
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // आउट-अफ-अर्डर एलिमेन्ट्सको पहिलो जोडी फेला पार्नुहोस्।
        let mut l = 0;
        let mut r = v.len();

        // सुरक्षा: तल असुरक्षितमा एर्रे अनुक्रमणिका समावेश छ।
        // पहिलो एकको लागि: हामी पहिले नै `l < r` यहाँ सीमाना जाँच गर्दैछौं।
        // दोस्रोको लागि: हामीसँग सुरुमा `l == 0` र `r == v.len()` छ र हामीले प्रत्येक अनुक्रमणिका अपरेशनमा त्यो `l < r` जाँच्यौं।
        //                     यहाँबाट हामीलाई थाहा छ कि `r` कम्तिमा `r == l` हुनु पर्छ जुन पहिलोबाट मान्य देखाइएको थियो।
        unsafe {
            // पिभोट भन्दा ठूलो वा बराबर पहिलो तत्व फेला पार्नुहोस्।
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // पिभोटको अन्तिम तत्व सानो फेला पार्नुहोस्।
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` क्षेत्रको बाहिर जान्छ र पिभोट लेख्छ (जुन एक स्ट्याक-विनियोजित चल हो) फर्काएर स्लाइसमा जहाँ यो मूल थियो।
        // सुरक्षा सुनिश्चित गर्न यो चरण महत्त्वपूर्ण छ!
        //
    };

    // पिभोट दुई विभाजनको बिचमा राख्नुहोस्।
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// `v[pivot]` बराबरको तत्वहरूमा `v` विभाजनहरू `v[pivot]` भन्दा ठूलो तत्त्वहरू द्वारा।
///
/// पिभोट बराबर एलिमेन्टहरूको संख्या फर्काउँछ।
/// यो मानिन्छ कि `v` मा पिभोट भन्दा सानो तत्व समावेश गर्दैन।
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // स्लाइसको सुरूमा पिभोट राख्नुहोस्।
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // पिभोट दक्षताका लागि स्ट्याक-विनियोजित चलमा पढ्नुहोस्।
    // यदि निम्न तुलना अपरेशन panics, pivot स्वतः स्लाइसमा लेखिन्छ।
    // सुरक्षा: यहाँ पोइन्टर मान्य छ किनकि यो स्लाइसको सन्दर्भबाट लिइएको हो।
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // अब टुक्रा विभाजन।
    let mut l = 0;
    let mut r = v.len();
    loop {
        // सुरक्षा: तल असुरक्षितमा एर्रे अनुक्रमणिका समावेश छ।
        // पहिलो एकको लागि: हामी पहिले नै `l < r` यहाँ सीमाना जाँच गर्दैछौं।
        // दोस्रोको लागि: हामीसँग सुरुमा `l == 0` र `r == v.len()` छ र हामीले प्रत्येक अनुक्रमणिका अपरेशनमा त्यो `l < r` जाँच्यौं।
        //                     यहाँबाट हामीलाई थाहा छ कि `r` कम्तिमा `r == l` हुनु पर्छ जुन पहिलोबाट मान्य देखाइएको थियो।
        unsafe {
            // पिभट भन्दा ठूलो पहिलो तत्व फेला पार्नुहोस्।
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // पिभट बराबर अन्तिम तत्व फेला पार्नुहोस्।
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // के हामीले सक्यौं?
            if l >= r {
                break;
            }

            // आउट-अफ-ऑर्डर तत्वहरूको फेला परेको जोडी स्वैप गर्नुहोस्।
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // हामीले `l` एलिमेन्टहरू पिभटको बराबर भेट्यौं।पिभट आफैंको लागि खातामा १ थप्नुहोस्।
    l + 1

    // `_pivot_guard` क्षेत्रको बाहिर जान्छ र पिभोट लेख्छ (जुन एक स्ट्याक-विनियोजित चल हो) फर्काएर स्लाइसमा जहाँ यो मूल थियो।
    // सुरक्षा सुनिश्चित गर्न यो चरण महत्त्वपूर्ण छ!
}

/// ढाँचाहरू तोड्ने प्रयासमा केहि एलिमेन्टर्सलाई तितरबितर बनाउँदछ जुन क्विकसोर्टमा असंतुलित विभाजनहरूको कारण हुन सक्छ।
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // जर्ज मार्साग्लिया द्वारा "Xorshift RNGs" कागजबाट pseudorandom संख्या जनरेटर।
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // यस नम्बरको अनियमित संख्या लिनुहोस्।
        // नम्बर `usize` मा फिट भयो किनभने `len` `isize::MAX` भन्दा ठूलो छैन।
        let modulus = len.next_power_of_two();

        // केहि पिभोट उम्मेद्वारहरू यो अनुक्रमणिकाको नजिकमा हुनेछन्।तिनीहरूलाई अनियमित गरौं।
        let pos = len / 4 * 2;

        for i in 0..3 {
            // अनियमित संख्या मोडुलो `len` उत्पन्न गर्नुहोस्।
            // जे होस्, महँगो अपरेशन्सबाट बच्न हामी पहिले यसलाई दुईको पावर मोड्युल गर्छौं, र त्यसपछि `len` ले घट्छ जब सम्म यो दायरा `[0, len - 1]` मा फिट हुँदैन।
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` `2 * len` भन्दा कमको ग्यारेन्टी गरिएको छ।
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// `v` मा एक पिभोट छनौट गर्दछ र यदि अनुक्रमणिका पहिले नै क्रमबद्ध गरिएको छ भने अनुक्रमणिका र `true` फर्काउँछ।
///
/// `v` मा तत्वहरू प्रक्रियामा पुनःक्रमित हुन सक्छ।
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Median-of-medians विधि छनौट गर्न न्यूनतम लम्बाई।
    // छोटो स्लाइसहरू सरल मेडिया-अफ-तीन विधि प्रयोग गर्दछ।
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // यस प्रकार्यमा प्रदर्शन गर्न सकिने स्व्यापहरूको अधिकतम संख्या।
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // तीन सूचकांकहरू जुन नजिक हामी एक पिभोट रोज्न गइरहेका छौं।
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // सूचकांक क्रमबद्ध गर्ने क्रममा हामीले प्रदर्शन गर्न लाग्यौं।
    let mut swaps = 0;

    if len >= 8 {
        // सूचकहरू सूचकहरू ताकि `v[a] <= v[b]`।
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // सूचकहरू सूचकहरू ताकि `v[a] <= v[b] <= v[c]`।
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // `v[a - 1], v[a], v[a + 1]` को मध्यस्थता फेला पार्छ र `a` मा सूचकांक भण्डार गर्दछ।
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // `a`, `b`, र `c` को छिमेकमा मेडियनहरू फेला पार्नुहोस्।
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // `a`, `b`, र `c` बीच मध्यस्थ फेला पार्नुहोस्।
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // स्व्यापहरूको अधिकतम संख्या प्रदर्शन गरिएको थियो।
        // स्लाइस तल झर्ने वा प्रायः तल झर्ने सम्भावनाहरू हुन्, त्यसैले उल्टाउँदा यसलाई चाँडो क्रमबद्ध गर्न मद्दत गर्दछ।
        v.reverse();
        (len - 1 - b, true)
    }
}

/// `v` पुनरावर्ती क्रमबद्ध गर्नुहोस्।
///
/// यदि स्लाइसको मूल एर्रेमा पूर्ववर्ती छ भने, यो `pred` को रूपमा तोकिन्छ।
///
/// `limit` `heapsort` मा स्विच गर्नु अघि अनुमति प्राप्त असंतुलित विभाजनहरूको संख्या हो।
/// यदि शून्य छ भने, यो प्रकार्य तुरून्तै heapsort मा स्विच हुनेछ।
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // यस लम्बाइ सम्मका स्लाइसहरू सम्मिलित क्रममा प्रयोग गरेर क्रमबद्ध हुन्छ।
    const MAX_INSERTION: usize = 20;

    // यदि अन्तिम विभाजन यथोचित सन्तुलित थियो भने ठीक हो।
    let mut was_balanced = true;
    // यो साँचो हो यदि अन्तिम विभाजनले तत्वहरू शफल गरेन (टुक्रा पहिले नै विभाजित गरिएको थियो)।
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // धेरै छोटो टुक्रा सम्मिलित क्रम को उपयोग गरेर क्रमबद्ध हुन्छ।
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // यदि धेरै खराब पिभोट छनौटहरू गरियो भने, `O(n * log(n))` खराब अवस्थाको ग्यारेन्टी गर्नको लागि केवल हिप्सोर्टमा फिर्ता जानुहोस्।
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // यदि अन्तिम विभाजन असंतुलित थियो भने, स्लाइसमा विच्छेदन बान्कीहरू वरिपरि केही तत्वहरू shuffling द्वारा प्रयास गर्नुहोस्।
        // आशा छ हामी यस पटक एक राम्रो पिभोट छनौट गर्नेछौं।
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // पिभट छनौट गर्नुहोस् र स्लाइस पहिले नै क्रमबद्ध गरिएको छ कि छैन अनुमान लगाउनुहोस्।
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // यदि अन्तिम विभाजन सभ्य रूपमा सन्तुलित थियो र तत्वहरू शफल थिएन भने, र यदि पिभोट चयनले भविष्यवाणी गर्यो भने टुक्रा पहिल्यै नै क्रमबद्ध गरिएको छ ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // क्रमबद्ध गर्नुहोस् धेरै आउट-आउट-अर्डर एलिमेन्टहरू पहिचान गर्नुहोस् र तिनीहरूलाई स्थान परिवर्तन गर्न को लागी।
            // यदि स्लाइस पूर्ण रूपमा क्रमबद्ध भइरहेको समाप्त भयो भने, हामी सक्यौं।
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // यदि छनौट गरिएको पिभोट पूर्ववर्ती बराबर हो भने, यो स्लाइसमा सब भन्दा सानो तत्व हो।
        // पिभोट भन्दा ठूलो र एलिमेन्टमा ठूलो टुक्रामा पार्टिस गर्नुहोस्।
        // यो केस सामान्यतया हिट हुन्छ जब स्लाइसमा धेरै नक्कल तत्त्वहरू समावेश हुन्छन्।
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // पिभट भन्दा ठूलो तत्व क्रमबद्ध गर्न जारी राख्नुहोस्।
                v = &mut { v }[mid..];
                continue;
            }
        }

        // टुक्रा विभाजन।
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // `left`, `pivot`, र `right` मा स्लाइस विभाजित गर्नुहोस्।
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // संक्षिप्त पक्षमा मात्र recurse क्रममा कुल रिकर्सिव कलहरूको संख्या कम गर्न र कम स्ट्याक स्पेस खपत गर्दछ।
        // त्यसो भए लामो पक्षको साथ जारी राख्नुहोस् (यो पुच्छर पुनरावृत्तिको समान हो)।
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// `v` प्याटर्न-हराउने quicksort प्रयोग गरी, जुन *O*(*n*\*log(* n*)) खराब अवस्था) हो।
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // क्रमबद्ध गर्न शून्य आकारका प्रकारहरूमा कुनै अर्थपूर्ण व्यवहार हुँदैन।
    if mem::size_of::<T>() == 0 {
        return;
    }

    // असंतुलित विभाजनहरूको संख्यालाई `floor(log2(len)) + 1` मा सीमित गर्नुहोस्।
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // यस लम्बाइका स्लाइसहरूका लागि सायद तिनीहरूलाई क्रमबद्ध गर्न चाँडो छ।
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // पिभट छनौट गर्नुहोस्
        let (pivot, _) = choose_pivot(v, is_less);

        // यदि छनौट गरिएको पिभोट पूर्ववर्ती बराबर हो भने, यो स्लाइसमा सब भन्दा सानो तत्व हो।
        // पिभोट भन्दा ठूलो र एलिमेन्टमा ठूलो टुक्रामा पार्टिस गर्नुहोस्।
        // यो केस सामान्यतया हिट हुन्छ जब स्लाइसमा धेरै नक्कल तत्त्वहरू समावेश हुन्छन्।
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // यदि हामीले हाम्रो अनुक्रमणिका पार गरिसकेका छौं, तब हामी राम्रो छौं।
                if mid > index {
                    return;
                }

                // अन्यथा पिभट भन्दा ठूलो तत्व क्रमबद्ध गर्न जारी राख्नुहोस्।
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // `left`, `pivot`, र `right` मा स्लाइस विभाजित गर्नुहोस्।
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // यदि मध्य==अनुक्रमणिका, तब हामीले सम्पन्न गरेका छौं, किनकि partition() ग्यारेन्टी छ कि मध्य पछि सबै तत्वहरू मध्य भन्दा ठूलो वा बराबर हुन्छ।
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // क्रमबद्ध गर्न शून्य आकारका प्रकारहरूमा कुनै अर्थपूर्ण व्यवहार हुँदैन।केहि नगर।
    } else if index == v.len() - 1 {
        // अधिकतम तत्व फेला पार्नुहोस् र एर्रेको अन्तिम स्थितिमा राख्नुहोस्।
        // हामी यहाँ `unwrap()` प्रयोग गर्न स्वतन्त्र छौं किनकि हामीलाई थाहा छ v खाली हुनुहुन्न।
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // न्यूनतम तत्व फेला पार्नुहोस् र एर्रेको पहिलो स्थानमा राख्नुहोस्।
        // हामी यहाँ `unwrap()` प्रयोग गर्न स्वतन्त्र छौं किनकि हामीलाई थाहा छ v खाली हुनुहुन्न।
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}