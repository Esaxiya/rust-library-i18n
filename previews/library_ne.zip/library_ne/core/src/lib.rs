//! # Rust कोर पुस्तकालय
//!
//! Rust कोर पुस्तकालय [The Rust Standard Library](../std/index.html) को निर्भरता-मुक्त [^ नि: शुल्क] फाउन्डेसन हो।
//! यो भाषा र यसको पुस्तकालयहरूको बिच पोर्टेबल गोंद हो, सबै Rust कोडको भित्री र आदिम बिल्डिंग ब्लक परिभाषित गर्दछ।
//!
//! यसले अपस्ट्रीम लाइब्रेरीहरू, कुनै प्रणाली लाइब्रेरी, र कुनै लाइबसीकमा लिंक गर्दैन।
//!
//! [^free]: Strictly बोल्दै, त्यहाँ केहि प्रतीकहरु छन् जुन चाहिन्छ तर
//!          तिनीहरू सधैं आवश्यक हुँदैनन्।
//!
//! मुख्य लाइब्रेरी *न्यूनतम* हो: यो हिप एलोकमेसनको बारेमा पनि सचेत हुँदैन, न यसले समितिको वा I/O प्रदान गर्दछ।
//! यी चीजहरूलाई प्लेटफर्म एकीकरणको आवश्यकता पर्दछ, र यो लाइब्रेरी प्लेटफर्म-अज्ञेष्टिक हो।
//!
//! # मूल पुस्तकालय को उपयोग कसरी गर्ने
//!
//! कृपया नोट गर्नुहोस् कि यी सबै विवरणहरू हाललाई स्थिर ठानिदैन।
//!
//!
//!
// FIXME: इन्टरफेस समाधान भएपछि मलाई विस्तृत रूपमा भर्नुहोस्
//! यो पुस्तकालय केहि अवस्थित प्रतीक को धारणा मा निर्मित छ:
//!
//! * `memcpy`, `memcmp`, `memset`, यी कोर मेमोरी रुटीनहरू हुन् जुन प्राय LLVM द्वारा उत्पन्न गरिन्छ।
//! थप रूपमा, यस पुस्तकालयले यी प्रकार्यहरूमा स्पष्ट कल गर्न सक्छ।
//! उनीहरूका हस्ताक्षर सीमा फेला परे जस्तै छन्।
//!   यी प्रकार्यहरू प्राय: प्रणाली libc द्वारा प्रदान गरिएको हो, तर [compiler-builtins crate](https://crates.io/crates/compiler_builtins) द्वारा पनि प्रदान गर्न सकिन्छ।
//!
//!
//! * `rust_begin_panic` - यो प्रकार्यले चार तर्कहरू लिन्छ, एक `fmt::Arguments`, एक `&'static str`, र दुई `u32`।
//! यी चार आर्गुमेन्टहरूले panic सन्देश, फाईल जसमा panic बोलाइएको थियो, र लाइन र स्तम्भ फाइल भित्र आदेश।
//! यो panic प्रकार्य परिभाषित गर्न यो मुख्य पुस्तकालयको उपभोक्ताहरू माथि निर्भर छ;यो कहिले पनि फिर्ता आउन आवश्यक छ।
//! यसको लागि `panic_impl` नामको `lang` गुण आवश्यक छ।
//!
//! * `rust_eh_personality` - कम्पाइलरको विफलता संयन्त्र द्वारा प्रयोग गरीन्छ।
//! यो प्रायः GCC को व्यक्तित्व प्रकार्यमा म्याप गरिन्छ, तर crates जसले panic ट्रिगर गर्दैन, यो कार्य कहिले पनि भनिदैन भनेर विश्वस्त हुन सक्छ।
//! `lang` विशेषतालाई `eh_personality` भनिन्छ।
//!
//!
//!

// लिबकोरले धेरै मौलिक ल्या lang वस्तुहरू परिभाषित गरेको हुनाले, सबै परीक्षणहरू अलग crate, लाइबकोरेस्टमा बस्छन्, विचित्र मुद्दाहरूबाट बच्न।
//
// यहाँ हामी स्पष्ट रूपमा#[cfg]-पूरा यो crate जब परीक्षण गर्दै।
// यदि हामी यो गर्दैनौं, उत्पन्न गरिएको परीक्षण विरूपण साक्ष्य र लि li्क लिबटेस्ट (जसले ट्रान्सभेटिभली लाइबकोर समावेश गर्दछ) दुबै ल्यांग वस्तुहरूको सेट सेट गर्दछ, र यसले E0152 "found duplicate lang item" त्रुटि उत्पन्न गर्दछ।
//
// विवरणका लागि #50466 मा छलफल हेर्नुहोस्।
//
// यो सीएफजी कागजात परीक्षण असर गर्दैन।
//
//
#![cfg(not(test))]
#![stable(feature = "core", since = "1.6.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![no_core]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(asm)]
#![feature(cfg_target_has_atomic)]
#![feature(const_heap)]
#![feature(const_alloc_layout)]
#![feature(const_assert_type)]
#![feature(const_discriminant)]
#![feature(const_cell_into_inner)]
#![feature(const_intrinsic_copy)]
#![feature(const_intrinsic_forget)]
#![feature(const_float_classify)]
#![feature(const_float_bits_conv)]
#![feature(const_int_unchecked_arith)]
#![feature(const_mut_refs)]
#![feature(const_refs_to_cell)]
#![feature(const_cttz)]
#![feature(const_panic)]
#![feature(const_pin)]
#![feature(const_fn)]
#![feature(const_fn_union)]
#![feature(const_impl_trait)]
#![feature(const_fn_floating_point_arithmetic)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(const_option)]
#![feature(const_precise_live_drops)]
#![feature(const_ptr_offset)]
#![feature(const_ptr_offset_from)]
#![feature(const_ptr_read)]
#![feature(const_ptr_write)]
#![feature(const_raw_ptr_comparison)]
#![feature(const_raw_ptr_deref)]
#![feature(const_slice_from_raw_parts)]
#![feature(const_slice_ptr_len)]
#![feature(const_size_of_val)]
#![feature(const_swap)]
#![feature(const_align_of_val)]
#![feature(const_type_id)]
#![feature(const_type_name)]
#![feature(const_likely)]
#![feature(const_unreachable_unchecked)]
#![feature(const_maybe_uninit_assume_init)]
#![feature(const_maybe_uninit_as_ptr)]
#![feature(custom_inner_attributes)]
#![feature(decl_macro)]
#![feature(doc_cfg)]
#![feature(doc_spotlight)]
#![feature(duration_consts_2)]
#![feature(duration_saturating_ops)]
#![feature(extended_key_value_attributes)]
#![feature(extern_types)]
#![feature(fundamental)]
#![feature(intra_doc_pointers)]
#![feature(intrinsics)]
#![feature(lang_items)]
#![feature(link_llvm_intrinsics)]
#![feature(llvm_asm)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(exhaustive_patterns)]
#![feature(no_core)]
#![feature(auto_traits)]
#![feature(or_patterns)]
#![feature(prelude_import)]
#![cfg_attr(not(bootstrap), feature(ptr_metadata))]
#![feature(repr_simd, platform_intrinsics)]
#![feature(rustc_attrs)]
#![feature(simd_ffi)]
#![feature(min_specialization)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(stmt_expr_attributes)]
#![feature(str_split_as_str)]
#![feature(str_split_inclusive_as_str)]
#![feature(trait_alias)]
#![feature(transparent_unions)]
#![feature(try_blocks)]
#![feature(unboxed_closures)]
#![feature(unsized_fn_params)]
#![feature(unwind_attributes)]
#![feature(variant_count)]
#![feature(tbm_target_feature)]
#![feature(sse4a_target_feature)]
#![feature(arm_target_feature)]
#![feature(powerpc_target_feature)]
#![feature(mips_target_feature)]
#![feature(aarch64_target_feature)]
#![feature(wasm_target_feature)]
#![feature(avx512_target_feature)]
#![feature(cmpxchg16b_target_feature)]
#![feature(rtm_target_feature)]
#![feature(f16c_target_feature)]
#![feature(hexagon_target_feature)]
#![feature(const_fn_transmute)]
#![feature(abi_unadjusted)]
#![feature(adx_target_feature)]
#![feature(external_doc)]
#![feature(associated_type_bounds)]
#![feature(const_caller_location)]
#![feature(slice_ptr_get)]
#![feature(no_niche)] // rust-lang/rust#68303
#![feature(int_error_matching)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![deny(unsafe_op_in_unsafe_fn)]

#[prelude_import]
#[allow(unused)]
use prelude::v1::*;

#[cfg(not(test))] // #65860 हेर्नुहोस्
#[macro_use]
mod macros;

#[macro_use]
mod internal_macros;

#[path = "num/shells/int_macros.rs"]
#[macro_use]
mod int_macros;

#[path = "num/shells/i128.rs"]
pub mod i128;
#[path = "num/shells/i16.rs"]
pub mod i16;
#[path = "num/shells/i32.rs"]
pub mod i32;
#[path = "num/shells/i64.rs"]
pub mod i64;
#[path = "num/shells/i8.rs"]
pub mod i8;
#[path = "num/shells/isize.rs"]
pub mod isize;

#[path = "num/shells/u128.rs"]
pub mod u128;
#[path = "num/shells/u16.rs"]
pub mod u16;
#[path = "num/shells/u32.rs"]
pub mod u32;
#[path = "num/shells/u64.rs"]
pub mod u64;
#[path = "num/shells/u8.rs"]
pub mod u8;
#[path = "num/shells/usize.rs"]
pub mod usize;

#[path = "num/f32.rs"]
pub mod f32;
#[path = "num/f64.rs"]
pub mod f64;

#[macro_use]
pub mod num;

/* The libcore prelude, not as all-encompassing as the libstd prelude */

pub mod prelude;

/* Core modules for ownership management */

pub mod hint;
pub mod intrinsics;
pub mod mem;
pub mod ptr;

/* Core language traits */

pub mod borrow;
pub mod clone;
pub mod cmp;
pub mod convert;
pub mod default;
pub mod marker;
pub mod ops;

/* Core types and methods on primitives */

pub mod any;
pub mod array;
pub mod ascii;
pub mod cell;
pub mod char;
pub mod ffi;
pub mod iter;
#[unstable(feature = "once_cell", issue = "74465")]
pub mod lazy;
pub mod option;
pub mod panic;
pub mod panicking;
pub mod pin;
pub mod raw;
pub mod result;
#[unstable(feature = "async_stream", issue = "79024")]
pub mod stream;
pub mod sync;

pub mod fmt;
pub mod hash;
pub mod slice;
pub mod str;
pub mod time;

pub mod unicode;

/* Async */
pub mod future;
pub mod task;

/* Heap memory allocator trait */
#[allow(missing_docs)]
pub mod alloc;

// note: सार्वजनिक हुन आवश्यक छैन
mod bool;
mod tuple;
mod unit;

#[stable(feature = "core_primitive", since = "1.43.0")]
pub mod primitive;

// `core_arch` crate लाई लिबकोरमा तान्नुहोस्।`core_arch` को सामग्रीहरू फरक भण्डारमा छन्: rust-lang/stdarch.
//
// `core_arch` लाइबकोरमा निर्भर गर्दछ, तर यो मोड्युलको सामग्रीहरू यस्तो सेट अप गरिन्छ कि यसलाई यहाँ प्रत्यक्ष तान्दा crate ले यसको crate लाई यसको लाइबकोरको रूपमा प्रयोग गर्दछ।
//
//
//
#[path = "../../stdarch/crates/core_arch/src/mod.rs"]
#[allow(
    missing_docs,
    missing_debug_implementations,
    dead_code,
    unused_imports,
    unsafe_op_in_unsafe_fn
)]
#[cfg_attr(bootstrap, allow(non_autolinks))]
#[cfg_attr(not(bootstrap), allow(rustdoc::non_autolinks))]
// FIXME: यो एनोटेशन rust-lang/stdarch मा सारिनु पर्छ क्लाईशिंग_फेस्टर्न_डेक्लेरेसनहरू पछि
// मर्ज गरियो।यो हाल गर्न सक्दैन किनकि बुटस्ट्र्याप असफल भयो किनकि lint अझै परिभाषित गरिएको छैन।
#[allow(clashing_extern_declarations)]
#[unstable(feature = "stdsimd", issue = "48556")]
mod core_arch;

#[stable(feature = "simd_arch", since = "1.27.0")]
pub use core_arch::arch;