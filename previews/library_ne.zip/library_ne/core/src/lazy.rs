//! आलस्य मानहरू र स्थिर डाटाको एक पटकको आरम्भ।

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// एक पटक मात्र लेख्न सकिने सेल।
///
/// `RefCell` विपरीत, एक `OnceCell` मात्र यसको मूल्य को लागी साझा `&T` सन्दर्भ प्रदान गर्दछ।
/// `Cell` विपरित, एक `OnceCell` लाई यसको पहुँच गर्न मूल्यलाई प्रतिलिपि वा बदल्नको आवश्यक पर्दैन।
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // इन्भेरियन्ट: एक पटक मा धेरै नै लेखिएको
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// नयाँ खाली सेल सिर्जना गर्दछ।
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// अन्तर्निहित मानको सन्दर्भ हुन्छ।
    ///
    /// यदि सेल खाली छ भने `None` फर्काउँछ।
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // सुरक्षा: सुरक्षित आन्तरिकको इन्भेर्नेटको कारण
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// अन्तर्निहित मानको लागि म्यूटेबल सन्दर्भ प्राप्त गर्दछ।
    ///
    /// यदि सेल खाली छ भने `None` फर्काउँछ।
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // सुरक्षा: सुरक्षित छ किनकि हामीसँग अद्वितीय पहुँच छ
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// `value` मा सेलको सामग्री सेट गर्दछ।
    ///
    /// # Errors
    ///
    /// यो विधि `Ok(())` फर्काउँछ यदि सेल खाली छ र `Err(value)` यदि यो भरिएको थियो।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // सुरक्षा: सुरक्षित किनकि हामीसँग अतिव्यापी परिवर्तनकारी haveण लिन सक्दैन
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // सुरक्षा: यो एक मात्र स्थान हो जहाँ हामी स्लट सेट, कुनै दौड
        // reentrancy/concurrency को कारण सम्भव छ, र हामीले यो जाँच गर्‍यौं कि स्लट हाल `None` हो, त्यसैले यो लेखोटले `आन्तरिक` इन्भेर्नेटलाई कायम राख्छ।
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// कक्षको सामग्रीहरू प्राप्त गर्दछ, `f` को साथ आरम्भ गर्दै यदि कक्ष खाली छ भने।
    ///
    /// # Panics
    ///
    /// यदि `f` panics, panic कलरमा प्रचार गरियो, र सेल अनावश्यक रहन्छ।
    ///
    ///
    /// `f` बाट सेल पुनःक्रमिकरण गर्न यो त्रुटि हो।त्यसो गर्नाले panic मा परिणाम हुन्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// कक्षको सामग्रीहरू प्राप्त गर्दछ, `f` को साथ आरम्भ गर्दै यदि कक्ष खाली छ भने।
    /// यदि सेल खाली थियो र `f` असफल भयो भने, त्रुटि फिर्ता गरियो।
    ///
    /// # Panics
    ///
    /// यदि `f` panics, panic कलरमा प्रचार गरियो, र सेल अनावश्यक रहन्छ।
    ///
    ///
    /// `f` बाट सेल पुनःक्रमिकरण गर्न यो त्रुटि हो।त्यसो गर्नाले panic मा परिणाम हुन्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // नोट गर्नुहोस् कि *रेन्ट्रन्ट इनिसियलाइजेशनको केहि* फारामहरूले यूबीतर्फ डो lead्याउन सक्छ (हेर्नुहोस् `reentrant_init` परीक्षण)।
        // म विश्वास गर्दछु कि यो `assert` हटाउँदा मात्र `set/get` राख्दा ध्वनि हुनेछ, तर यो panic लाई राम्रो लाग्दछ, चुपचाप पुरानो मान प्रयोग गर्नु भन्दा।
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// सेल खपत, आवरण मान फर्काउँदै।
    ///
    /// `None` फर्काउँछ यदि सेल खाली थियो।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // किनभने `into_inner` ले `self` लाई मानबाट लिन्छ, कम्पाइलरले स्थिरताले प्रमाणित गर्छ कि यो हाल सापट लिएको छैन।
        // त्यसैले यो `Option<T>` बाहिर सार्न सुरक्षित छ।
        self.inner.into_inner()
    }

    /// यस `OnceCell` को मान लिन्छ, यसलाई पुन: अनावश्यक अवस्थामा सार्दै।
    ///
    /// कुनै प्रभाव छैन र `None` फर्काउँछ यदि `OnceCell` आरम्भ गरिएको छैन।
    ///
    /// सुरक्षा एक परिवर्तनीय सन्दर्भको आवश्यकता द्वारा ग्यारेन्टी गरिएको छ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// पहिलो पहुँचमा आरम्भ गरिएको मान।
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   आरम्भ गर्दै
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// दिईएको आरम्भिक प्रकार्यको साथ एक नयाँ आलस्य मान सिर्जना गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// यो अल्छी मूल्यको मूल्या Forces्कन गर्न बाध्य पार्छ र परिणामलाई सन्दर्भ फर्काउँछ।
    ///
    ///
    /// यो `Deref` impl को बराबर हो, तर स्पष्ट छ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// `Default` सुरूवात प्रकार्यको रूपमा प्रयोग गरेर नयाँ आलस्य मान सिर्जना गर्दछ।
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}