//! Panic लाइबकोरका लागि समर्थन
//!
//! मूल पुस्तकालयले प्यानकि def परिभाषित गर्न सक्दैन, तर यसले *घोषित* पैनिक गर्दछ।
//! यसको मतलब लिबकोर भित्रका कार्यहरूलाई panic लाई अनुमति छ, तर उपयोगीका लागि अपस्ट्रिम crate लाईबकोर प्रयोग गर्नको लागि प्यानकिking परिभाषित गर्नुपर्दछ।
//! आतंकको लागि हालको इन्टरफेस हो:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! यस परिभाषाले कुनै पनि सामान्य सन्देशसँग आतंकको लागि अनुमति दिन्छ, तर यसले `Box<Any>` मानको साथ असफलताको लागि अनुमति दिँदैन।
//! (`PanicInfo` मा एउटा `&(dyn Any + Send)` मात्र समावेश छ, जसको लागि हामी `PanicInfo: : आन्तरिक_कन्स्ट्रक्टर in मा एक डमी मान भर्छौं।) यसको कारण यो छ कि लिबकोरलाई विनियोजन गर्न अनुमति छैन।
//!
//!
//! यस मोड्युलले केहि अन्य प्यानकिking प्रकार्यहरू समावेश गर्दछ, तर ती केवल कम्पाइलरका लागि आवश्यक ल्यांग आईटमहरू छन्।सबै panics यो एक प्रकार्य मार्फत फनेल गरिएको छ।
//! वास्तविक प्रतीक `#[panic_handler]` विशेषता मार्फत घोषणा गरियो।
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Libcore को `panic!` म्याक्रोको अन्तर्निहित कार्यान्वयन जब कुनै ढाँचा प्रयोग गरिदैन।
#[cold]
// जतिसक्दो सम्भव भएसम्म कल साइटहरूमा कोड ब्लोटबाट बच्न Panic_imedia_abort सम्म कहिले पनि इनलाइन इनलाईन नगर्नुहोस्
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // panic को लागि ओभरफ्लो र अन्य `Assert` MIR टर्मिनेटरमा कोडेजेन द्वारा आवश्यक
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Arguments::new_v1 को सट्टा format_args को सट्टा प्रयोग गर्नुहोस्! ("{}", Expr) सम्भवतः ओभरहेड साइज कम गर्न।
    // Format_args!म्याक्रोले एक्सप्रेस लेख्नको लागि str को प्रदर्शन trait प्रयोग गर्दछ, जसले Formatter::pad कल गर्दछ, जुन स्ट्रिंग काट्ने र प्याडि accom समायोजित गर्नुपर्दछ (जे भए पनि यहाँ कुनै पनि प्रयोग गरिएको छैन)।
    //
    // Arguments::new_v1 प्रयोग गर्नाले कम्पाइलरले Formatter::pad लाई आउटपुट बाइनरीबाट हटाउन सक्छ, केहि किलोबाइट्समा बचत गर्न।
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // कन्स्ट्यालेटेड panics को लागी आवश्यक छ
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // O0B array/slice पहुँचमा panic को लागी कोडजेन द्वारा आवश्यक छ
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// अन्तर्निहित कार्यान्वयन libcore को `panic!` म्याक्रो जब ढाँचा प्रयोग गरिन्छ।
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // नोट: यो प्रकार्य कहिल्यै FFI सीमा पार गर्दैन;यो एक Rust-to-Rust कल हो जुन `#[panic_handler]` प्रकार्यमा समाधान हुन्छ।
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // सुरक्षा: `panic_impl` सुरक्षित Rust कोड मा परिभाषित छ र यसैले कल गर्न सुरक्षित छ।
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// `assert_eq!` र `assert_ne!` म्याक्रोहरूको लागि आन्तरिक प्रकार्य
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}