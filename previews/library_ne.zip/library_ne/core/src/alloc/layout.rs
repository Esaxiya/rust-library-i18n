use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// जबकि यो प्रकार्य एक ठाउँमा प्रयोग गरीएको छ र यसको कार्यान्वयन इनलाइन गर्न सकिन्छ, त्यसो गर्न अघिल्ला प्रयासहरू rustc सुस्त बनायो।
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// मेमोरीको ब्लकको लेआउट।
///
/// `Layout` को एक उदाहरण मेमोरी को एक विशेष लेआउट वर्णन गर्दछ।
/// तपाईं एक `Layout` एक आवाबकर्तालाई दिन एक इनपुटको रूपमा माथि निर्माण।
///
/// सबै रूपरेखासँग एक सम्बन्धित आकार र पावर अफ दुई दुई पign्क्तिबद्धता छ।
///
/// (नोट गर्नुहोस् कि रूपरेखा * * शून्य नहुनु आवश्यक छ, `GlobalAlloc` लाई सबै मेमोरी अनुरोधहरू साइजमा गैर-शून्य हुनु आवश्यक छ।
/// कलरले या त यो सुनिश्चित गर्नु पर्छ कि यी जस्तो सर्तहरू मिलेका छन्, लोजर आवश्यकताहरूको साथ निर्दिष्ट आवाश्यककर्ताहरू प्रयोग गर्नुहोस्, वा अधिक लेन्ट `Allocator` इन्टरफेस प्रयोग गर्नुहोस्।)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // अनुरोध गरिएको मेमोरीको ब्लकको साइज, बाइट्समा मापन गरियो।
    size_: usize,

    // अनुरोध गरिएको मेमोरीको पign्क्तिबद्धता, बाइट्समा मापन गरियो।
    // हामी यो सुनिश्चित गर्दछौं कि यो सँधै दुईको पावर अफ हुन्छ, किनभने एपीआईको `posix_memalign` जस्तो चाहिन्छ र लेआउट कन्स्ट्रक्टरहरूमा थोपाउन यो उचित अवरोध हो।
    //
    //
    // (यद्यपि, हामी समान रूपमा `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.) को आवश्यकता छैन
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// `size` र `align` बाट `Layout` निर्माण गर्दछ, वा यदि निम्न सर्तहरू मध्ये कुनै एक पूरा गरीएको छैन भने `LayoutError` फर्काउँछ:
    ///
    /// * `align` शून्य हुनु हुँदैन,
    ///
    /// * `align` दुईको शक्ति हुनु पर्छ,
    ///
    /// * `size`, जब `align` को नजिकको एकाधिकमा राउन्ड गरियो, ओभरफ्लो हुनु हुँदैन (जस्तै, गोलाकार मान `usize::MAX` भन्दा कम वा बराबर हुनुपर्दछ)।
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (दुई-पावर अफ दुई प al्क्तिबद्ध!=०)

        // राउन्ड अप आकार हो:
        //   आकार_ग्र्यान्ड_अप=(आकार + पign्क्तिबद्ध, १)&! (पign्क्तिबद्ध, १);
        //
        // हामी माथिबाट थाहा छ कि पign्क्तिबद्ध!=0।
        // यदि (पign्क्तिबद्ध, १) ओभरफ्लो छैन भने, फेरि मिलान ठीक हुनेछ।
        //
        // यसको विपरीत,&-masking! (Align, १) केवल कम-अर्डर बिट्सको घटाउनेछ।
        // यसैले यदि ओभरफ्लो योगसँग देखा पर्‍यो भने, र-मास्कले त्यो ओभरफ्लोलाई अनडू गर्न पर्याप्त घटाउन सक्दैन।
        //
        //
        // माथिको संकेत यो छ कि संहिता ओभरफ्लोको लागि जाँच दुबै आवश्यक र पर्याप्त छ।
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // सुरक्षा: `from_size_align_unchecked` को लागी सर्तहरू भएको छ
        // माथि जाँच गरियो।
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// सबै चेकहरू बाइपास गरेर लेआउट सिर्जना गर्दछ।
    ///
    /// # Safety
    ///
    /// यो प्रकार्य असुरक्षित छ किनकि यसले [`Layout::from_size_align`] बाट पूर्व शर्तहरू प्रमाणित गर्दैन।
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // सुरक्षा: कलरले `align` शून्य भन्दा ठूलो छ भनेर यकिन गर्नु पर्छ।
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// यस लेआउटको मेमोरी ब्लकका लागि बाइट्समा न्यूनतम आकार।
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// यस रूपरेखाको मेमोरी ब्लकको लागि न्यूनतम बाइट पign्क्तिबद्धता।
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// प्रकार `T` को मूल्य होल्ड गर्नका लागि उपयुक्त `Layout` बनाउँछ।
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // सुरक्षा: पign्क्तिबद्ध Z2Rust0Z ले दुई र। को एक शक्ति हुन ग्यारेन्टी गरेको छ
        // आकार + पign्क्तिबद्ध कोम्बो ग्यारेन्टी गरिएको छ जुन हाम्रो ठेगाना स्थानमा फिट हुनेछ।
        // परिणाम स्वरूप यहाँ अनचेक कन्स्ट्रक्टर प्रयोग गर्नुहोस् कोड सम्मिलित गर्नबाट बच्न जुन panics यदि यो राम्रोसँग अप्टिमाइज गरिएको छैन भने।
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` (जुन trait वा स्लाइस जस्तो अन्य असुरक्षित प्रकार हुन सक्छ) को लागी ब्याकिking संरचना आवंटित गर्न प्रयोग गर्न सकिन्छ कि एक रेकर्ड वर्णन लेआउट उत्पादन गर्दछ।
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // सुरक्षा: किन असुरक्षित संस्करण प्रयोग गरिरहेको छ `new` X मा तर्क हेर्नुहोस्
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` (जुन trait वा स्लाइस जस्तो अन्य असुरक्षित प्रकार हुन सक्छ) को लागी ब्याकिking संरचना आवंटित गर्न प्रयोग गर्न सकिन्छ कि एक रेकर्ड वर्णन लेआउट उत्पादन गर्दछ।
    ///
    /// # Safety
    ///
    /// यो प्रकार्य केवल कल गर्न सुरक्षित छ यदि निम्न सर्तहरू राख्छन्:
    ///
    /// - यदि `T` `Sized` हो, यो प्रकार्य कल गर्न सुरक्षित छ।
    /// - यदि `T` को असत्यापित पूंछ हो:
    ///     - एक [slice], त्यसपछि स्लाइस पूंछको लम्बाई एक इन्टेलाइज्ड पूर्णांक हुनुपर्दछ, र *सम्पूर्ण मान* को आकार (गतिशील टेल लम्बाई + स्थिर आकारको उपसर्ग) `isize` मा फिट हुनुपर्दछ।
    ///     - एक [trait object], तब पोइन्टरको vtable अंश एक अनसाइजिंग कोर्सियन द्वारा प्राप्त `T` प्रकारका लागि वैध vtable मा औंल्याउनु पर्छ, र *सम्पूर्ण मान* को आकार (गतिशील टेल लम्बाई + स्थिर आकारको उपसर्ग) `isize` मा फिट हुनुपर्दछ।
    ///
    ///     - एक (unstable) [extern type], तब यो प्रकार्य जहिले पनि कल गर्न सुरक्षित हुन्छ, तर panic वा अन्यथा गलत मान फिर्ता गर्न सक्दछ, बाह्य प्रकारको रूपरेखा ज्ञात छैन।
    ///     यो बाह्य प्रकारको पुच्छरको सन्दर्भमा [`Layout::for_value`] को समान व्यवहार हो।
    ///     - अन्यथा, यस कार्यलाई कल गर्न यसलाई रूढिवादी रूपमा अनुमति छैन।
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // सुरक्षा: हामी कलरलाई यी प्रकार्यहरूका लागि आवश्यक चीजहरू पार गर्दछौं
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // सुरक्षा: किन असुरक्षित संस्करण प्रयोग गरिरहेको छ `new` X मा तर्क हेर्नुहोस्
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// एक `NonNull` सिर्जना गर्दछ जुन dangling छ, तर यस लेआउटको लागि राम्रो प al्क्तिबद्ध।
    ///
    /// नोट गर्नुहोस् कि सूचक मानले सम्भावित रूपमा वैध पोइन्टर प्रतिनिधित्व गर्न सक्दछ, जसको मतलब यो "not yet initialized" सेन्टिनल मानको रूपमा प्रयोग गर्नु हुँदैन।
    /// प्रकारहरू जुन आलम्बित रूपमा आवंटित हुन्छन् अरू केही माध्यमद्वारा इनिसियलाइज ट्र्याक गर्नुपर्दछ
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // सुरक्षा: पign्क्तिबद्ध गैर-शून्य को ग्यारेन्टी छ
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// रेकर्ड वर्णन गर्ने लेआउट सिर्जना गर्दछ जुन `self` को रूपमा समान लेआउटको मान समात्न सक्दछ, तर त्यो प that्क्तिबद्ध `align` (बाइट्समा मापन) प al्क्तिबद्ध पनि हुन्छ।
    ///
    ///
    /// यदि `self` ले पहिले नै निर्धारित पign्क्तिबद्धता पूरा गर्दछ, तब `self` फर्काउँछ।
    ///
    /// नोट गर्नुहोस् कि यस विधिले समग्र आकारमा कुनै प्याडि add थप गर्दैन, फर्काइएको लेआउटको फरक पign्क्तिबद्ध छ वा छैन भन्ने फरक पर्दैन।
    /// अर्को शब्दहरुमा, यदि `K` को आकार १ 16 छ, `K.align_to(32)`*अझै** को आकार १ 16 हुन्छ।
    ///
    /// `self.size()` र दिइएको `align` को संयोजनले [`Layout::from_size_align`] मा सूचीबद्ध सर्तहरूको उल्लंघन गर्छ भने त्रुटि फिर्ता गर्छ।
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// तलको ठेगानाले `align` (बाइट्समा मापन गरिएको) लाई सन्तुष्ट पार्नेछ भन्ने कुरा सुनिश्चित गर्न हामीले `self` पछि घुसाउनु पर्ने प्याडिंगको मात्रा फर्काउँछ।
    ///
    /// उदाहरणको लागि, यदि `self.size()` 9 हो, तब `self.padding_needed_for(4)` ले 3 फिर्ता गर्छ, किनकि त्यो--पigned्क्तिबद्ध ठेगाना प्राप्त गर्न आवश्यक प्याडिंगको बाइट्सको न्यूनतम संख्या हो (मान्दछ कि सम्बन्धित मेमोरी ब्लक--प-्क्तिबद्ध ठेगानाबाट सुरू हुन्छ)।
    ///
    ///
    /// यस प्रकार्यको फिर्ती मानको कुनै अर्थ छैन यदि `align` एक दुईको पावर अफ होईन।
    ///
    /// नोट गर्नुहोस् कि फर्काइएको मानको उपयोगितालाई `align` मेमोरीको पूरा आवंटित ब्लकको लागि सुरू ठेगानाको पign्क्तिबद्धता भन्दा कम वा बराबर हुन आवश्यक छ।यस अवरोध पूरा गर्नका लागि एक तरिका `align <= self.align()` लाई सुनिश्चित गर्नु हो।
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // राउन्ड अप मूल्य हो:
        //   len_rounded_up=(len + align, 1)&! (पign्क्तिबद्ध, १);
        // र त्यसपछि हामी प्याडि difference फर्काउँछौं: `len_rounded_up - len`.
        //
        // हामी मॉड्युलर अंकगणित भर प्रयोग:
        //
        // 1. पign्क्तिबद्ध गर्न ग्यारेन्टी गरिएको छ ० ०, त्यसैले पign्क्तिबद्ध गर्नुहोस्, १ सधैं मान्य हुन्छ।
        //
        // 2.
        // `len + align - 1` अधिकतम `align - 1` द्वारा ओभरफ्लो हुन सक्छ, त्यसैले `!(align - 1)` सँग&मास्कले ओभरफ्लोको मामलामा, `len_rounded_up` आफै ० ० हुन्छ भन्ने कुरा निश्चित गर्दछ।
        //
        //    यसैले फर्काएको प्याडि,, जब `len` मा थपियो, ० ले उपज दिन्छ, जसले क्षुल्दो प the्क्तिबद्धता `align` लाई सन्तुष्ट पार्छ।
        //
        // (निस्सन्देह, माथिको ब्लकहरू वाटप गर्ने प्रयास गर्दछ जसको आकार र प्याडिंग ओभरफ्लो माथिको तरिकामा आवंटकले जे भए पनि त्रुटि उत्पन्न गर्दछ।)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// लेआउटको पign्क्तिबद्धको बहुसम्म यस लेआउटको आकार राउन्ड गरेर एउटा सजावट सिर्जना गर्दछ।
    ///
    ///
    /// यो लेआउटको वर्तमान आकारमा `padding_needed_for` को नतिजा थप्न बराबर छ।
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // यो ओभरफ्लो हुन सक्दैन।लेआउटको आक्रमणकर्ताबाट उद्धृत गर्दै:
        // > `size`, जब `align` को नजिकको एकाधिकमा राउन्ड गरियो,
        // > ओभरफ्लो हुनु हुँदैन (जस्तै, गोलाकार मान भन्दा कम हुनुपर्दछ
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// `self` को `n` उदाहरणहरूका लागि रेकर्ड वर्णन गर्ने लेआउट सिर्जना गर्दछ, प्रत्येक बिचको अनुरोध गरिएको आकार र पign्क्तिबद्धतालाई सुनिश्चित गर्नका लागि प्रत्येक बीच प्याडिंगको उचित रकमको साथ।
    /// सफलतामा, `(k, offs)` फर्काउँछ जहाँ `k` एर्रेको लेआउट हो र `offs` एर्रेमा प्रत्येक एलिमेन्टको सुरू बीचको दूरी हो।
    ///
    /// अंकगणित ओभरफ्लोमा, `LayoutError` फर्काउँछ।
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // यो ओभरफ्लो हुन सक्दैन।लेआउटको आक्रमणकर्ताबाट उद्धृत गर्दै:
        // > `size`, जब `align` को नजिकको एकाधिकमा राउन्ड गरियो,
        // > ओभरफ्लो हुनु हुँदैन (जस्तै, गोलाकार मान भन्दा कम हुनुपर्दछ
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // सुरक्षा: self.align पहिले नै वैध हुन भनेर ज्ञात छ र Vot_size भएको छ
        // पहिले नै प्याडेड छ।
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// `self` लाई पछ्याई `next` का लागि रेकर्ड वर्णन गर्ने लेआउट सिर्जना गर्दछ, कुनै आवश्यक प्याडि including सहित `next` सही तरिकाले प .्क्तिबद्ध हुनेछ भनेर निश्चित गर्न, तर *कुनै पछाडि प्याडिding* छैन।
    ///
    /// C प्रतिनिधित्व लेआउट `repr(C)` मिलान गर्न, तपाईंले `pad_to_align` कल गर्नुपर्नेछ सबै क्षेत्रहरूको साथ लेआउट विस्तार गरेपछि।
    /// (त्यहाँ कुनै तरीका छैन पूर्वनिर्धारित Rust प्रतिनिधित्व लेआउट `repr(Rust)`, as it is unspecified.) मिलान गर्न
    ///
    /// नोट गर्नुहोस् कि परिणामको रूपरेखाको पign्क्तिबद्धता `self` र `next` को अधिकतम हुनेछ, दुबै भागहरूको प ensure्क्तिबद्धता सुनिश्चित गर्नका लागि।
    ///
    /// `Ok((k, offset))` फर्काउँदछ, जहाँ `k` ले कated्कनेट गरिएको रेकर्डको लेआउट हो र `offset` सापेक्षित स्थान, बाइट्समा, `next` को शुरुवातको कन्क्टेनेट रेकर्ड भित्रै सम्मिलित छ (यो रेकर्ड आफैंमा अफसेट ० बाट शुरू हुन्छ भन्ने मान्दै)।
    ///
    ///
    /// अंकगणित ओभरफ्लोमा, `LayoutError` फर्काउँछ।
    ///
    /// # Examples
    ///
    /// `#[repr(C)]` संरचनाको लेआउट र फिल्डको अफसेटहरू यसको फिल्डको लेआउटबाट गणना गर्न:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // `pad_to_align` को साथ अन्तिम सम्झना गर्नुहोस्!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // यो काम गर्दछ कि परीक्षण
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// `self` का `n` उदाहरणहरूका लागि रेकर्ड वर्णन गर्ने लेआउट सिर्जना गर्दछ, प्रत्येक उदाहरणको बिचमा कुनै प्याडिंगको साथ।
    ///
    /// नोट गर्नुहोस्, `repeat` विपरीत, `repeat_packed` ग्यारेन्टी गर्दैन कि `self` को दोहोरिएका घटनाहरू सही पigned्क्तिबद्ध हुनेछ, यदि `self` को दिइएको उदाहरण ठीक प properly्क्तिबद्ध गरिएको छ भने।
    /// अर्को शब्दमा, यदि `repeat_packed` द्वारा फिर्ता गरिएको लेआउट एर्रे वाटपको लागि प्रयोग गरियो भने, यो ग्यारेन्टी छैन कि एर्रेमा सबै तत्वहरू सही पigned्क्तिबद्ध हुनेछन्।
    ///
    /// अंकगणित ओभरफ्लोमा, `LayoutError` फर्काउँछ।
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// दुई बीचमा कुनै अतिरिक्त प्याडि with बिना `self` X द्वारा `self` का लागि रेकर्ड वर्णन गर्ने सजावट सिर्जना गर्दछ।
    /// कुनै प्याडि in सम्मिलित गरिएको छैन, `next` का पign्क्तिबद्ध अप्रासंगिक छ, र परिणाम *लेआउट* मा * सबै समावेश गरीएको छैन।
    ///
    ///
    /// अंकगणित ओभरफ्लोमा, `LayoutError` फर्काउँछ।
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// `[T; n]` का लागि रेकर्ड वर्णन गर्ने सजावट सिर्जना गर्दछ।
    ///
    /// अंकगणित ओभरफ्लोमा, `LayoutError` फर्काउँछ।
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// `Layout::from_size_align` वा केहि अन्य `Layout` कन्स्ट्रक्टरलाई दिइएका प्यारामिटरहरू यसको कागजात अवरोधहरू पूरा गर्दैन।
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (हामीलाई trait त्रुटि को डाउनस्ट्रीम impl को लागी यो आवश्यक छ)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}