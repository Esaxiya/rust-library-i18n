//! मेमोरी विनियोजन एपीआई

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// `AllocError` त्रुटि एक विनियोजन विफलता स indicates्केत गर्दछ जुन स्रोत थकानको कारण वा केही गलत गर्न सकिन्छ जुन यस आबेलरसँग दिईएको इनपुट आर्गुमेन्टहरू संयोजन गर्दा हुन्छ।
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (हामीलाई trait त्रुटि को डाउनस्ट्रीम impl को लागी यो आवश्यक छ)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// `Allocator` को कार्यान्वयनले [`Layout`][] मार्फत वर्णन गरिएको डाटाको मनमानी ब्लकहरू आवंटित गर्न, बढ्न, सिक्न, र डेअलोकेट गर्न सक्दछ।
///
/// `Allocator` ZSTs, सन्दर्भ, वा स्मार्ट सूचकहरूमा लागू गर्न डिजाइन गरिएको छ किनकि `MyAlloc([u8; N])` जस्तो एक आवंटक भएकोले सार्न मिल्दैन, पोइन्टर्स विनियोजित स्मृतिमा अपडेट नगरीकन।
///
/// [`GlobalAlloc`][] भन्दा विपरीत, `Allocator` मा शून्य आकारको विनियोजनलाई अनुमति छ।
/// यदि एक अन्तर्निहित आवंटक यस (जेमेलोक जस्तै) समर्थन गर्दैन वा शून्य सूचक (जस्तै `libc::malloc`) फर्काउँदैन भने, यसलाई कार्यान्वयनले समात्नै पर्छ।
///
/// ### हालै मेमोरी बाँडिएको
///
/// केहि तरिकाहरूका लागि आवाश्यककर्ताको माध्यमबाट मेमोरी ब्लक *हालै विनियोजित* हुनु आवश्यक हुन्छ।यसको मतलब यो हो कि:
///
/// * त्यो मेमोरी ब्लकको लागि सुरू ठेगाना पहिले [`allocate`], [`grow`], वा [`shrink`], र द्वारा फिर्ता आएको थियो
///
/// * मेमोरी ब्लक पछि डेकलोकट गरिएको छैन, जहाँ ब्लकहरू या त [`deallocate`] मा सिधा पार गरी Deallocated वा [`grow`] वा [`shrink`] मा पारित गरेर परिवर्तन गरियो जुन `Ok` फर्काउँदछ।
///
/// यदि `grow` वा `shrink` `Err` फर्कायो भने, पारित सूचक मान्य रहन्छ।
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### मेमोरी फिटिंग
///
/// केहि तरिकाहरूका लागि लेआउट *फिट* मेमोरी ब्लक आवश्यक हुन्छ।
/// "fit" लाई मेमोरी ब्लकको अर्थ यसको मतलब के हो (वा समरूपमा, मेमोरी ब्लकको लागि "fit" लेआउटमा लेआउट) भनेको निम्न सर्तहरू होल्ड गर्नुपर्दछ:
///
/// * ब्लक [`layout.align()`], र समान प .्क्तिबद्धको साथ विनियोजित हुनुपर्छ
///
/// * प्रदान गरिएको [`layout.size()`] दायरा `min ..= max` मा पर्दछ, जहाँ:
///   - `min` हालसालै ब्लक बाँडफाँड गर्न प्रयोग गरिएको लेआउटको आकार, र
///   - `max` [`allocate`], [`grow`], वा [`shrink`] बाट फिर्ता आएको भर्खरको वास्तविक आकार हो।
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * एक विनियोजकबाट फर्केका मेमोरी ब्लकहरूले वैध मेमोरीमा औंल्याउनु पर्छ र उनीहरूको वैधता उदाहरण र यसका सबै क्लोनहरू ड्रप नगरेसम्म कायम राख्नुपर्दछ,
///
/// * क्लोनिंग वा एन्डोलेटर सार्दा यो आवाबरेटरबाट फर्केका मेमोरी ब्लकहरू अवैध पार्नु हुँदैन।क्लोन गरिएको वितरकले उही समान वितरक जस्तो व्यवहार गर्नुपर्दछ, र
///
/// * कुनै मेमोरी ब्लकमा कुनै सूचक जुन [*currently allocated*] छ आवाश्यककर्ताको कुनै पनि अन्य विधिमा पारित गर्न सकिन्छ।
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// मेमोरीको ब्लक बाँडफाँड गर्न प्रयासहरू।
    ///
    /// सफलतामा, X001 को आकार र पign्क्तिबद्ध ग्यारेन्टीहरू भेट गर्दै [`NonNull<[u8]>`][NonNull] फिर्ता गर्दछ।
    ///
    /// फिर्ता ब्लक `layout.size()` द्वारा निर्दिष्ट भन्दा ठूलो आकार हुन सक्छ, र हुनसक्छ वा यसको सामग्री आरम्भ हुन सक्छ।
    ///
    /// # Errors
    ///
    /// `Err` फिर्तीले संकेत गर्दछ कि या त मेमोरी समाप्त भएको छ वा `layout` ले विनियोजकको आकार वा पign्क्तिबद्ध अवरोध पूरा गर्दैन।
    ///
    /// कार्यान्वयनहरूलाई आतंक वा परित्याग गर्नुको सट्टा मेमरी थकावटमा `Err` फिर्ता गर्न प्रोत्साहन दिइन्छ, तर यो सख्त आवश्यकता होइन।
    /// (विशेष रूपमा: यो trait एक अंतर्निहित मूल आबंटन लाइब्रेरी माथि जुन मेमोरी थकावटमा छोडिन्छ माथिको कार्यान्वयन गर्न *कानूनी* हो।)
    ///
    /// एक आवंटन त्रुटि को जवाफ मा गणना परित्याग गर्न चाहने ग्राहकहरु [`handle_alloc_error`] प्रकार्य कल गर्न को लागी प्रोत्साहित गरिन्छ, `panic!` वा समान रूपमा आमन्त्रित गर्नु भन्दा।
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// `allocate` जस्तो व्यवहार गर्दछ, तर यो पनि सुनिश्चित गर्दछ कि फर्काएको मेमोरी शून्य-इनिशियलाइज्ड छ।
    ///
    /// # Errors
    ///
    /// `Err` फिर्तीले संकेत गर्दछ कि या त मेमोरी समाप्त भएको छ वा `layout` ले विनियोजकको आकार वा पign्क्तिबद्ध अवरोध पूरा गर्दैन।
    ///
    /// कार्यान्वयनहरूलाई आतंक वा परित्याग गर्नुको सट्टा मेमरी थकावटमा `Err` फिर्ता गर्न प्रोत्साहन दिइन्छ, तर यो सख्त आवश्यकता होइन।
    /// (विशेष रूपमा: यो trait एक अंतर्निहित मूल आबंटन लाइब्रेरी माथि जुन मेमोरी थकावटमा छोडिन्छ माथिको कार्यान्वयन गर्न *कानूनी* हो।)
    ///
    /// एक आवंटन त्रुटि को जवाफ मा गणना परित्याग गर्न चाहने ग्राहकहरु [`handle_alloc_error`] प्रकार्य कल गर्न को लागी प्रोत्साहित गरिन्छ, `panic!` वा समान रूपमा आमन्त्रित गर्नु भन्दा।
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // सुरक्षा: `alloc` एक मान्य मेमोरी ब्लक फर्काउँछ
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// `ptr` द्वारा संदर्भित मेमोरी मेटाउनुहोस्।
    ///
    /// # Safety
    ///
    /// * `ptr` यो आबیلوक मार्फत [*currently allocated*] मेमोरीको ब्लक दर्साउनुपर्दछ, र
    /// * `layout` [*fit*] हुनुपर्छ जुन मेमोरीको ब्लक हो।
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// मेमोरी ब्लक विस्तार गर्न प्रयासहरू।
    ///
    /// एक नयाँ [`NonNull<[u8]>`][NonNull] फर्काउँछ जुन सूचक र बाँडिएको मेमोरीको वास्तविक आकार समावेश गर्दछ।सूचक `new_layout` द्वारा वर्णन गरिएको डाटा समात्नका लागि उपयुक्त छ।
    /// यो पूरा गर्न, विनियोजकले नयाँ लेआउट फिट गर्न `ptr` द्वारा निर्दिष्ट विनियोजन विस्तार गर्न सक्दछ।
    ///
    /// यदि यसले `Ok` फर्काउँछ भने, `ptr` द्वारा संदर्भित मेमोरी ब्लकको स्वामित्व यस आब्रोतालाई हस्तान्तरण गरिएको छ।
    /// मेमोरी मुक्त गरिएको हुन सक्छ वा हुन सक्दैन, र यो विधिको फिर्ती मूल्य मार्फत फेरि कलरमा हस्तान्तरण नगरेसम्म यो बेकार मानिनेछ।
    ///
    /// यदि यो विधिले `Err` फर्काउँछ भने, त्यसपछि मेमोरी ब्लकको स्वामित्व यस आब्रोटरमा हस्तान्तरण गरिएको छैन, र मेमोरी ब्लकको सामग्रीहरू अनलिटर गरिएको छ।
    ///
    /// # Safety
    ///
    /// * `ptr` यो आवाबकर्ता मार्फत मेमोरी [*currently allocated*] को ब्लक दर्साउनु पर्छ।
    /// * `old_layout` [*fit*] हुनुपर्दछ जुन मेमोरीको ब्लक हो (`new_layout` आर्गुमेन्टमा यो फिट हुँदैन।)
    /// * `new_layout.size()` `old_layout.size()` भन्दा ठूलो वा बराबर हुनुपर्छ।
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// `Err` फर्काउँछ यदि नयाँ लेआउटरले विनियोजकको आकार र आवंटकको पign्क्तिबद्धता बाधा पूरा गर्दैन, वा बढ्दो अन्यथा असफल भयो भने।
    ///
    /// कार्यान्वयनहरूलाई आतंक वा परित्याग गर्नुको सट्टा मेमरी थकावटमा `Err` फिर्ता गर्न प्रोत्साहन दिइन्छ, तर यो सख्त आवश्यकता होइन।
    /// (विशेष रूपमा: यो trait एक अंतर्निहित मूल आबंटन लाइब्रेरी माथि जुन मेमोरी थकावटमा छोडिन्छ माथिको कार्यान्वयन गर्न *कानूनी* हो।)
    ///
    /// एक आवंटन त्रुटि को जवाफ मा गणना परित्याग गर्न चाहने ग्राहकहरु [`handle_alloc_error`] प्रकार्य कल गर्न को लागी प्रोत्साहित गरिन्छ, `panic!` वा समान रूपमा आमन्त्रित गर्नु भन्दा।
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // सुरक्षा: किनकि `new_layout.size()` भन्दा ठूलो वा बराबर हुनुपर्छ
        // `old_layout.size()`, पुरानो र नयाँ दुबै दुबै `old_layout.size()` बाइट्सका लागि पढ्न र लेख्न मान्य छ।
        // साथै, किनकि पुरानो विनियोजन अझै डेलोकेट गरिएको थिएन, यसले `new_ptr` लाई ओभरल्याप गर्न सक्दैन।
        // यसैले, `copy_nonoverlapping` मा कल सुरक्षित छ।
        // `dealloc` को लागि सुरक्षा सम्झौता कलर द्वारा समर्थित हुनुपर्दछ।
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// `grow` जस्तो व्यवहार गर्दछ, तर यो पनि सुनिश्चित गर्दछ कि नयाँ सामग्रीहरू फर्काउनु अघि शून्यमा सेट गरिएको छ।
    ///
    /// मेमोरी ब्लकमा सफल कल पछि निम्न सामग्रीहरू समावेश गर्दछ
    /// `grow_zeroed`:
    ///   * बाइट्स `0..old_layout.size()` मूल विनियोजनबाट सुरक्षित गरिएको छ।
    ///   * बाइट्स `old_layout.size()..old_size` या त संरक्षक वा शून्य हुनेछ, विनियोजक कार्यान्वयनमा निर्भर गर्दै।
    ///   `old_size` `grow_zeroed` कल भन्दा पहिले मेमोरी ब्लकको आकारलाई जनाउँछ, जुन यो विनियोजन गर्दा मूल अनुरोध गरिएको आकार भन्दा ठूलो हुन सक्दछ।
    ///   * बाइट्स `old_size..new_size` शून्य छ।`new_size` `grow_zeroed` कल द्वारा फिर्ता गरिएको मेमोरी ब्लकको आकारलाई जनाउँछ।
    ///
    /// # Safety
    ///
    /// * `ptr` यो आवाबकर्ता मार्फत मेमोरी [*currently allocated*] को ब्लक दर्साउनु पर्छ।
    /// * `old_layout` [*fit*] हुनुपर्दछ जुन मेमोरीको ब्लक हो (`new_layout` आर्गुमेन्टमा यो फिट हुँदैन।)
    /// * `new_layout.size()` `old_layout.size()` भन्दा ठूलो वा बराबर हुनुपर्छ।
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// `Err` फर्काउँछ यदि नयाँ लेआउटरले विनियोजकको आकार र आवंटकको पign्क्तिबद्धता बाधा पूरा गर्दैन, वा बढ्दो अन्यथा असफल भयो भने।
    ///
    /// कार्यान्वयनहरूलाई आतंक वा परित्याग गर्नुको सट्टा मेमरी थकावटमा `Err` फिर्ता गर्न प्रोत्साहन दिइन्छ, तर यो सख्त आवश्यकता होइन।
    /// (विशेष रूपमा: यो trait एक अंतर्निहित मूल आबंटन लाइब्रेरी माथि जुन मेमोरी थकावटमा छोडिन्छ माथिको कार्यान्वयन गर्न *कानूनी* हो।)
    ///
    /// एक आवंटन त्रुटि को जवाफ मा गणना परित्याग गर्न चाहने ग्राहकहरु [`handle_alloc_error`] प्रकार्य कल गर्न को लागी प्रोत्साहित गरिन्छ, `panic!` वा समान रूपमा आमन्त्रित गर्नु भन्दा।
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // सुरक्षा: किनकि `new_layout.size()` भन्दा ठूलो वा बराबर हुनुपर्छ
        // `old_layout.size()`, पुरानो र नयाँ दुबै दुबै `old_layout.size()` बाइट्सका लागि पढ्न र लेख्न मान्य छ।
        // साथै, किनकि पुरानो विनियोजन अझै डेलोकेट गरिएको थिएन, यसले `new_ptr` लाई ओभरल्याप गर्न सक्दैन।
        // यसैले, `copy_nonoverlapping` मा कल सुरक्षित छ।
        // `dealloc` को लागि सुरक्षा सम्झौता कलर द्वारा समर्थित हुनुपर्दछ।
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// मेमोरी ब्लक हान्ने प्रयास।
    ///
    /// एक नयाँ [`NonNull<[u8]>`][NonNull] फर्काउँछ जुन सूचक र बाँडिएको मेमोरीको वास्तविक आकार समावेश गर्दछ।सूचक `new_layout` द्वारा वर्णन गरिएको डाटा समात्नका लागि उपयुक्त छ।
    /// यो पूरा गर्न, विनियोजकले नयाँ लेआउट फिट गर्न `ptr` द्वारा निर्दिष्ट विनियोजनलाई संकुचन गर्न सक्दछ।
    ///
    /// यदि यसले `Ok` फर्काउँछ भने, `ptr` द्वारा संदर्भित मेमोरी ब्लकको स्वामित्व यस आब्रोतालाई हस्तान्तरण गरिएको छ।
    /// मेमोरी मुक्त गरिएको हुन सक्छ वा हुन सक्दैन, र यो विधिको फिर्ती मूल्य मार्फत फेरि कलरमा हस्तान्तरण नगरेसम्म यो बेकार मानिनेछ।
    ///
    /// यदि यो विधिले `Err` फर्काउँछ भने, त्यसपछि मेमोरी ब्लकको स्वामित्व यस आब्रोटरमा हस्तान्तरण गरिएको छैन, र मेमोरी ब्लकको सामग्रीहरू अनलिटर गरिएको छ।
    ///
    /// # Safety
    ///
    /// * `ptr` यो आवाबकर्ता मार्फत मेमोरी [*currently allocated*] को ब्लक दर्साउनु पर्छ।
    /// * `old_layout` [*fit*] हुनुपर्दछ जुन मेमोरीको ब्लक हो (`new_layout` आर्गुमेन्टमा यो फिट हुँदैन।)
    /// * `new_layout.size()` `old_layout.size()` भन्दा सानो वा बराबर हुनुपर्छ।
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// `Err` फर्काउँछ यदि नयाँ लेआउटरले विनियोजकको आकार र आवंटकको पign्क्तिबद्धता सीमितहरू पूरा गर्दैन, वा यदि सinking्कि otherwise अन्यथा असफल हुन्छ भने।
    ///
    /// कार्यान्वयनहरूलाई आतंक वा परित्याग गर्नुको सट्टा मेमरी थकावटमा `Err` फिर्ता गर्न प्रोत्साहन दिइन्छ, तर यो सख्त आवश्यकता होइन।
    /// (विशेष रूपमा: यो trait एक अंतर्निहित मूल आबंटन लाइब्रेरी माथि जुन मेमोरी थकावटमा छोडिन्छ माथिको कार्यान्वयन गर्न *कानूनी* हो।)
    ///
    /// एक आवंटन त्रुटि को जवाफ मा गणना परित्याग गर्न चाहने ग्राहकहरु [`handle_alloc_error`] प्रकार्य कल गर्न को लागी प्रोत्साहित गरिन्छ, `panic!` वा समान रूपमा आमन्त्रित गर्नु भन्दा।
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // सुरक्षा: किनकि `new_layout.size()` कम वा बराबर हुनुपर्छ
        // `old_layout.size()`, पुरानो र नयाँ दुबै दुबै `new_layout.size()` बाइट्सका लागि पढ्न र लेख्न मान्य छ।
        // साथै, किनकि पुरानो विनियोजन अझै डेलोकेट गरिएको थिएन, यसले `new_ptr` लाई ओभरल्याप गर्न सक्दैन।
        // यसैले, `copy_nonoverlapping` मा कल सुरक्षित छ।
        // `dealloc` को लागि सुरक्षा सम्झौता कलर द्वारा समर्थित हुनुपर्दछ।
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// `Allocator` को यस उदाहरणको लागि एक "by reference" एडाप्टर सिर्जना गर्दछ।
    ///
    /// फर्काइएको एडेप्टरले `Allocator` पनि कार्यान्वयन गर्दछ र यसलाई सापट लिन्छ।
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // सुरक्षा: सुरक्षा सम्झौता कलरले समर्थन गर्नै पर्छ
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // सुरक्षा: सुरक्षा सम्झौता कलरले समर्थन गर्नै पर्छ
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // सुरक्षा: सुरक्षा सम्झौता कलरले समर्थन गर्नै पर्छ
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // सुरक्षा: सुरक्षा सम्झौता कलरले समर्थन गर्नै पर्छ
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}