#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// एक `RawWaker` ले कार्य परीक्षकको कार्यान्वयनकर्तालाई [`Waker`] सिर्जना गर्न अनुमति दिन्छ जसले अनुकूलित वेकअप व्यवहार प्रदान गर्दछ।
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// यो एक डाटा सूचक र एक [virtual function pointer table (vtable)][vtable] को `RawWaker` को व्यवहार अनुकूलित गर्दछ।
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// एक डाटा सूचक, जुन कार्यकारीकर्ताले आवश्यक अनुसार मध्यस्थ डाटा भण्डारण गर्न प्रयोग गर्न सकिन्छ।
    /// यो उदाहरण को लागी हुन सक्छ
    /// `Arc` मा टाईप गरीएको पोइन्टर जुन कार्यसँग सम्बन्धित छ।
    /// यस फिल्डको मान सबै प्रकार्यहरूमा पठाइन्छ जुन पहिलो प्यारामिटरको रूपमा vtable का अंश हुन्।
    ///
    data: *const (),
    /// भर्चुअल प्रकार्य सूचक तालिका जसले यो बेकरको व्यवहारलाई अनुकूलित गर्दछ।
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// `data` सूचक र `vtable` बाट नयाँ `RawWaker` सिर्जना गर्दछ।
    ///
    /// `data` सूचक कार्यकारी द्वारा आवश्यक अनुसार मध्यस्थ डेटा भण्डारण गर्न प्रयोग गर्न सकिन्छ।यो उदाहरण को लागी हुन सक्छ
    /// `Arc` मा टाईप गरीएको पोइन्टर जुन कार्यसँग सम्बन्धित छ।
    /// यस सूचकको मान सबै प्रकार्यहरूमा पठाइनेछ जुन पहिलो प्यारामिटरको रूपमा `vtable` को भाग हो।
    ///
    /// `vtable` `Waker` को व्यवहार अनुकूलित गर्दछ जुन `RawWaker` बाट सिर्जना हुन्छ।
    /// `Waker` मा प्रत्येक अपरेशनको लागि, अन्तर्निहित `RawWaker` को `vtable` मा सम्बन्धित समारोह भनिन्छ।
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// एक भर्चुअल प्रकार्य सूचक तालिका (vtable) जसले [`RawWaker`] को व्यवहारलाई निर्दिष्ट गर्दछ।
///
/// Vtable भित्रका सबै कार्यहरूमा स passed्केतक सूचक भनेको X0 [`RawWaker`] बिन्दुबाट `data` सूचक हो।
///
/// यस संरचना भित्रका प्रकार्यहरू [`RawWaker`] कार्यान्वयन भित्रबाट राम्ररी निर्माण गरिएको [`RawWaker`] वस्तुको `data` सूचकमा कल गर्नका लागि मात्र हुन्।
/// कुनै पनि अन्य `data` पोइन्टर प्रयोग गरेर समावेश भएको प्रकार्यहरू मध्ये एक कल गर्दा अपरिभाषित व्यवहार हुन्छ।
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// यो प्रकार्य भनिन्छ जब [`RawWaker`] क्लोन हुन्छ, उदाहरणको लागि जब [`Waker`] मा [`RawWaker`] भण्डार गरिएको क्लोन हुन्छ।
    ///
    /// यस प्रकार्यको कार्यान्वयनले सबै स्रोतहरू राख्नु पर्छ जुन [`RawWaker`] र सम्बन्धित कार्यको यस अतिरिक्त उदाहरणको लागि आवश्यक छ।
    /// `wake` लाई नतिजा [`RawWaker`] मा कल गर्दा उही कार्यको वेकअपमा परिणामित हुनुपर्दछ जुन मूल [`RawWaker`] द्वारा जगाइएको थियो।
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// यो प्रकार्य भनिनेछ जब `wake` [`Waker`] मा कल गरिन्छ।
    /// यो [`RawWaker`] सँग सम्बन्धित कार्यलाई उठाउनु पर्छ।
    ///
    /// यस प्रकार्यको कार्यान्वयनले [`RawWaker`] X र सम्बन्धित कार्यसँग सम्बन्धित कुनै पनि स्रोतहरू रिलीज गर्न निश्चित गर्नुपर्दछ।
    ///
    ///
    wake: unsafe fn(*const ()),

    /// यो प्रकार्य भनिनेछ जब `wake_by_ref` [`Waker`] मा कल गरिन्छ।
    /// यो [`RawWaker`] सँग सम्बन्धित कार्यलाई उठाउनु पर्छ।
    ///
    /// यो प्रकार्य `wake` सँग मिल्दोजुल्दो छ, तर प्रदान गरिएको डाटा पोइन्टर उपभोग गर्नु हुँदैन।
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// यो प्रकार्य भनिन्छ जब [`RawWaker`] ड्रप हुन्छ।
    ///
    /// यस प्रकार्यको कार्यान्वयनले [`RawWaker`] X र सम्बन्धित कार्यसँग सम्बन्धित कुनै पनि स्रोतहरू रिलीज गर्न निश्चित गर्नुपर्दछ।
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// `clone`, `wake`, `wake_by_ref`, र `drop` प्रकार्यबाट नयाँ `RawWakerVTable` सिर्जना गर्दछ।
    ///
    /// # `clone`
    ///
    /// यो प्रकार्य भनिन्छ जब [`RawWaker`] क्लोन हुन्छ, उदाहरणको लागि जब [`Waker`] मा [`RawWaker`] भण्डार गरिएको क्लोन हुन्छ।
    ///
    /// यस प्रकार्यको कार्यान्वयनले सबै स्रोतहरू राख्नु पर्छ जुन [`RawWaker`] र सम्बन्धित कार्यको यस अतिरिक्त उदाहरणको लागि आवश्यक छ।
    /// `wake` लाई नतिजा [`RawWaker`] मा कल गर्दा उही कार्यको वेकअपमा परिणामित हुनुपर्दछ जुन मूल [`RawWaker`] द्वारा जगाइएको थियो।
    ///
    /// # `wake`
    ///
    /// यो प्रकार्य भनिनेछ जब `wake` [`Waker`] मा कल गरिन्छ।
    /// यो [`RawWaker`] सँग सम्बन्धित कार्यलाई उठाउनु पर्छ।
    ///
    /// यस प्रकार्यको कार्यान्वयनले [`RawWaker`] X र सम्बन्धित कार्यसँग सम्बन्धित कुनै पनि स्रोतहरू रिलीज गर्न निश्चित गर्नुपर्दछ।
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// यो प्रकार्य भनिनेछ जब `wake_by_ref` [`Waker`] मा कल गरिन्छ।
    /// यो [`RawWaker`] सँग सम्बन्धित कार्यलाई उठाउनु पर्छ।
    ///
    /// यो प्रकार्य `wake` सँग मिल्दोजुल्दो छ, तर प्रदान गरिएको डाटा पोइन्टर उपभोग गर्नु हुँदैन।
    ///
    /// # `drop`
    ///
    /// यो प्रकार्य भनिन्छ जब [`RawWaker`] ड्रप हुन्छ।
    ///
    /// यस प्रकार्यको कार्यान्वयनले [`RawWaker`] X र सम्बन्धित कार्यसँग सम्बन्धित कुनै पनि स्रोतहरू रिलीज गर्न निश्चित गर्नुपर्दछ।
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// एसिन्क्रोनस कार्यको `Context`।
///
/// हाल, `Context` मात्र `&Waker` पहुँच प्रदान गर्दछ जुन वर्तमान कार्यलाई जगाउन प्रयोग गर्न सकिन्छ।
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // सुनिश्चित गर्नुहोस् कि हामी future-प्रुफ भिन्नता परिवर्तनहरूका बिरूद्ध जीवनकाल बाध्य गरेर इन्भेरियन्ट हुन (आर्गुमेन्ट स्थिति स्थिति लाइफटाइम विपरीत हो जबकि रिटर्न-स्थिति लाईफटाइम सहकर्मी हो)।
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// `&Waker` बाट नयाँ `Context` सिर्जना गर्नुहोस्।
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// वर्तमान कार्यको लागि `Waker` को सन्दर्भ फर्काउँछ।
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// एक `Waker` कार्य चलाउनको लागि एक ह्यान्डल हो यसको कार्यवाहकलाई सूचित गरेर जुन यो चालुको लागि तयार छ।
///
/// यस ह्यान्डलले [`RawWaker`] उदाहरण समाहित गर्दछ, जसले कार्यकारी-विशेष वेकअप व्यवहार परिभाषित गर्दछ।
///
///
/// [`Clone`], [`Send`], र [`Sync`]।
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// यस `Waker` सँग सम्बन्धित कार्यलाई उठाउनुहोस्।
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // वास्तविक वेकअप कल कार्यान्वयन गर्न भर्चुअल प्रकार्य कल मार्फत हस्तान्तरण गरिएको छ जुन कार्यवाहकले परिभाषित गरेको छ।
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // `drop` कल नगर्नुहोस्-Waker `wake` द्वारा खपत हुनेछ।
        crate::mem::forget(self);

        // सुरक्षा: यो सुरक्षित छ किनभने `Waker::from_raw` मात्र एक तरीका हो
        // `wake` र `data` सुरू गर्न प्रयोगकर्ताले `RawWaker` को सम्झौता समर्थन गरिएको छ भनेर स्वीकार गर्न आवश्यक छ।
        //
        unsafe { (wake)(data) };
    }

    /// `Waker` उपभोग नगरी यस `Waker` सँग सम्बन्धित कार्यलाई उठाउनुहोस्।
    ///
    /// यो `wake` सँग मिल्दोजुल्दो छ, तर स्वाभाविक `Waker` उपलब्ध भएको ठाउँमा अलि कम कुशल हुन सक्छ।
    /// यस विधिलाई `waker.clone().wake()` कल गर्न रुचाउनु पर्छ।
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // वास्तविक वेकअप कल कार्यान्वयन गर्न भर्चुअल प्रकार्य कल मार्फत हस्तान्तरण गरिएको छ जुन कार्यवाहकले परिभाषित गरेको छ।
        //

        // सुरक्षा: `wake` हेर्नुहोस्
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// `true` फर्काउँछ यदि यो `Waker` र अर्को `Waker` उस्तै कार्य अगाडि बढेको छ।
    ///
    /// यो प्रकार्य एक उत्तम प्रयासको आधारमा काम गर्दछ, र गलत फिर्ता हुन सक्छ जब Waker`s समान कार्य जगाउने थियो।
    /// जे होस्, यदि यो प्रकार्य `true` फर्काउँछ भने, ग्यारेन्टी छ कि `Waker`s ले समान कार्य जगाउनेछ।
    ///
    /// यो प्रकार्य मुख्य रूपले अनुकूलन उद्देश्यको लागि प्रयोग गरीन्छ।
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// [`RawWaker`] बाट नयाँ `Waker` सिर्जना गर्दछ।
    ///
    /// फिर्ता `Waker` को व्यवहार अपरिभाषित छ यदि [`RawWaker`] को र [`RawWakerVTable`] को कागजात समर्थन गरिएको छैन भने।
    ///
    /// त्यसकारण यो विधि असुरक्षित छ।
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // सुरक्षा: यो सुरक्षित छ किनभने `Waker::from_raw` मात्र एक तरीका हो
            // `clone` र `data` आरम्भ गर्न प्रयोगकर्ताले [`RawWaker`] को सम्झौता समर्थन गरिएको छ भनेर स्वीकार गर्न आवश्यक छ।
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // सुरक्षा: यो सुरक्षित छ किनभने `Waker::from_raw` मात्र एक तरीका हो
        // `drop` र `data` सुरू गर्न प्रयोगकर्ताले `RawWaker` को सम्झौता समर्थन गरिएको छ भनेर स्वीकार गर्न आवश्यक छ।
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}