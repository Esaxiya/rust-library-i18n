//! अर्डर र तुलनाको लागि कार्यक्षमता।
//!
//! यो मोड्युलले अर्डर र मान तुलना गर्नका लागि विभिन्न उपकरणहरू समावेश गर्दछ।संक्षिप्तमा:
//!
//! * [`Eq`] र [`PartialEq`] traits हो जसले तपाईंलाई क्रमशः मानहरू बीच पूर्ण र आंशिक समानता परिभाषित गर्न अनुमति दिन्छ।
//! तिनीहरूलाई कार्यान्वयन गर्दै `==` र `!=` अपरेटरहरू ओभरलोड गर्दछ।
//! * [`Ord`] र [`PartialOrd`] traits हो जसले तपाईंलाई क्रमशः मानहरू बीचको कुल र आंशिक क्रम परिभाषित गर्न अनुमति दिन्छ।
//!
//! तिनीहरूलाई कार्यान्वयन गर्दै `<`, `<=`, `>`, र `>=` अपरेटरहरू।
//! * [`Ordering`] [`Ord`] र [`PartialOrd`] को मुख्य प्रकार्यहरू द्वारा फिर्ता गरिएको एनम हो, र एक अर्डरिंग वर्णन गर्दछ।
//! * [`Reverse`] एक संरचना हो जुन तपाईंलाई सजिलैसँग अर्डरिंग रिभर्स गर्न अनुमति दिन्छ।
//! * [`max`] र [`min`] कार्यहरू हुन् जसले [`Ord`] का निर्माण गर्दछ र तपाईंलाई अधिकतम वा न्यूनतम दुई मानहरू फेला पार्न अनुमति दिन्छ।
//!
//! अधिक विवरणहरूको लागि सूचीमा प्रत्येक वस्तुको सम्बन्धित कागजात हेर्नुहोस्।
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait समानता तुलनाको लागि जुन [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation) हुन्।
///
/// यस trait ले आंशिक समानताको लागि अनुमति दिन्छ, पूर्ण प्रकारको समानता सम्बन्ध नभएका प्रकारहरूको लागि।
/// उदाहरणका लागि, फ्लोटिंग पोइन्ट नम्बर `NaN != NaN` मा, त्यसैले फ्लोटिंग पोइन्ट प्रकारहरूले `PartialEq` कार्यान्वयन गर्दछ तर [`trait@Eq`] लाई लागू गर्दैन।
///
/// औपचारिक रूपमा, समानता हुनुपर्दछ (सबै `a`, `b`, `A` प्रकारको `c`, `B`, `C`):
///
/// - **सममित**: यदि `A: PartialEq<B>` र `B: PartialEq<A>`, तब **`a==b` संकेत गर्दछ`b==a`**;र
///
/// - **ट्रान्जिटिव**: यदि `A: PartialEq<B>` र `B: PartialEq<C>` र `A:
///   आंशिक<C>`, त्यसपछि **` a==b`र `b == c` लागू गर्दछ`a==c`**।
///
/// नोट गर्नुहोस् कि `B: PartialEq<A>` (symmetric) र `A: PartialEq<C>` (transitive) impls अवस्थित गर्न बाध्य छैन, तर यी आवश्यकताहरू लागू हुन्छ जब तिनीहरू अवस्थित हुन्छन्।
///
/// ## Derivable
///
/// यो trait `#[derive]` को साथ प्रयोग गर्न सकिन्छ।जब स्ट्रिक्टमा derive`d हुन्छ, दुई क्षेत्रहरु बराबर हुन्छ यदि सबै फिल्डहरू बराबर छ, र बराबर छैन यदि फिल्डहरू बराबर छैन भने।जब enums मा derive`d, प्रत्येक संस्करण आफै बराबर हो र अन्य भेरियन्टको बराबर हुँदैन।
///
/// ## म कसरी `PartialEq` कार्यान्वयन गर्न सक्छु?
///
/// `PartialEq` [`eq`] विधि मात्र कार्यान्वयन गर्न आवश्यक छ;[`ne`] पूर्वनिर्धारित द्वारा यसको सर्तमा परिभाषित गरिएको छ।[`ne`]*को कुनै मैन्युअल कार्यान्वयन* नियमलाई [`eq`] 6X [`ne`] का एक सख्त व्युत्क्रम मान्नु पर्छ;त्यो हो, `!(a == b)` यदि र मात्र यदि `a != b`।
///
/// `PartialEq`, [`PartialOrd`], र [`Ord`]*को कार्यान्वयन* एक अर्कासँग सहमत हुनुपर्दछ।यो गल्तिले तिनीहरूलाई traits को व्युत्पन्न गरेर र अरूलाई मैन्युअल रूपमा कार्यान्वयन गरेर असहमत बनाउन सजिलो छ।
///
/// डोमेनको लागि उदाहरण कार्यान्वयन जहाँ दुई पुस्तकहरू उही किताब मानिन्छ यदि उनीहरूको ISBN मिल्दछ भने, ढाँचा फरक भए पनि:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## म कसरी दुई फरक प्रकारहरू तुलना गर्न सक्छु?
///
/// तपाइँसँग तुलना गर्न सक्ने प्रकार `PartialEq` प्रकार प्यारामिटर द्वारा नियन्त्रण गरिन्छ।
/// उदाहरण को लागी, हाम्रो पहिलेको कोड थोरै ट्वीक गर्नुहोस्:
///
/// ```
/// // व्युत्पन्न उपकरणहरू<BookFormat>==<BookFormat>तुलना
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // कार्यान्वयन<Book>==<BookFormat>तुलना
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // कार्यान्वयन<BookFormat>==<Book>तुलना
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// `impl PartialEq for Book` लाई `impl PartialEq<BookFormat> for Book` मा परिवर्तन गरेर, हामी `Bookformat`s लाई`Book`s सँग तुलना गर्न अनुमति दिन्छौं।
///
/// माथिको जस्तो तुलना, जुन संरचनाको केहि क्षेत्रहरू उपेक्षा गर्दछ, खतरनाक हुन सक्छ।यसले सजिलैसँग आंशिक बराबर सम्बन्धको लागि आवश्यकताहरूको अनावश्यक उल्लंघन गर्न सक्छ।
/// उदाहरणको लागि, यदि हामीले `PartialEq<Book>` का `PartialEq<Book>` को माथिको कार्यान्वयन राख्यौं र `Book` को लागी `PartialEq<Book>` को कार्यान्वयन जोड्‍यौं (या त `#[derive]` मार्फत वा पहिलो उदाहरणबाट म्यानुअल कार्यान्वयन मार्फत) तब परिणामले ट्रान्जिसिटिटीलाई उल्लंघन गर्दछ:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// यो विधि `self` र `other` मान बराबरको लागि परीक्षण गर्दछ, र `==` द्वारा प्रयोग गरिएको छ।
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// यो विधि `!=` का लागि परीक्षण गर्दछ।
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// trait `PartialEq` को एक इम्प्ली उत्पन्न डेरिभ म्याक्रो।
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait समानता तुलनाको लागि जुन [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation) हुन्।
///
/// यसको मतलब यो हो कि `a == b` र `a != b` सख्त व्युत्क्रम हुनुको साथ, समानता हुनु पर्छ (सबै `a`, `b` र `c` को लागी):
///
/// - reflexive: `a == a`;
/// - सममित: `a == b` ले `b == a` लागू गर्दछ;र
/// - ट्रान्जिटिभ: `a == b` र `b == c` ले `a == c` लाई संकेत गर्छ।
///
/// यो सम्पत्ती कम्पाइलरले जाँच गर्न सक्दैन, र त्यसैले `Eq` ले [`PartialEq`] संकेत गर्दछ, र कुनै अतिरिक्त विधिहरू छैनन्।
///
/// ## Derivable
///
/// यो trait `#[derive]` को साथ प्रयोग गर्न सकिन्छ।
/// जब `derive`d, किनभने `Eq` का कुनै अतिरिक्त विधिहरू छैनन्, यसले केवल कम्पाइलरलाई सूचित गरिरहेको छ कि यो आंशिक बराबर सम्बन्धको भन्दा एक समानता सम्बन्ध हो।
///
/// नोट गर्नुहोस् कि `derive` रणनीतिलाई सबै फिल्डहरू `Eq` चाहिन्छ, जुन सँधै चाहँदैन।
///
/// ## म कसरी `Eq` कार्यान्वयन गर्न सक्छु?
///
/// यदि तपाईं `derive` रणनीति प्रयोग गर्न सक्नुहुन्न भने, निर्दिष्ट गर्नुहोस् कि तपाईंको प्रकारले `Eq` लागू गर्दछ, जससँग कुनै विधिहरू छैनन्:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // यस विधिलाई केवल#[व्युत्पन्न] द्वारा प्रयोग गरीन्छ कि यो प्रकारको प्रत्येक कम्पोनेन्ट्स आफैंमा [[व्युत्पन्न]] कार्यान्वयन गर्दछ, वर्तमान व्युत्पन्न संरचना यस trait मा एक विधि प्रयोग नगरी यो जिम्मेवारी गर्नु भनेको लगभग असम्भव छ।
    //
    //
    // यो कहिले पनि हातले कार्यान्वयन गर्नु हुँदैन।
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// trait `Eq` को एक इम्प्ली उत्पन्न डेरिभ म्याक्रो।
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: यो संरचना पूर्ण रूपमा#[व्युत्पन्न] द्वारा प्रयोग गरीन्छ
// एक प्रकारको प्रत्येक घटक Eq कार्यान्वयनको रूपमा जोड दिनुहोस्।
//
// यो संरचना प्रयोगकर्ता कोडमा कहिले देखा पर्दैन।
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// एक `Ordering` दुई मान बीचको तुलनाको परिणाम हो।
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// एक अर्डरिंग जहाँ तुलनात्मक मान अर्को भन्दा कम छ।
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// एक अर्डरिंग जहाँ तुलनात्मक मान अर्कोसँग बराबर हुन्छ।
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// अर्डर जहाँ तुलनात्मक मान अर्को भन्दा ठूलो छ।
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// `true` फर्काउँछ यदि अर्डरिंग `Equal` संस्करण हो।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// `true` फर्काउँछ यदि अर्डरिंग `Equal` भेरिएन्ट छैन।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// `true` फर्काउँछ यदि अर्डरिंग `Less` संस्करण हो।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// `true` फर्काउँछ यदि अर्डरिंग `Greater` संस्करण हो।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// `true` फर्काउँछ यदि आदेश या त `Less` वा `Equal` भेरियन्ट हो।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// `true` फर्काउँछ यदि आदेश या त `Greater` वा `Equal` भेरियन्ट हो।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// `Ordering` उल्टो।
    ///
    /// * `Less` `Greater` हुन्छ।
    /// * `Greater` `Less` हुन्छ।
    /// * `Equal` `Equal` हुन्छ।
    ///
    /// # Examples
    ///
    /// मूल व्यवहार:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// यो विधि तुलनालाई उल्टाउन प्रयोग गर्न सकिन्छ:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // एर्रेलाई सबैभन्दा ठूलो बाट सानोमा क्रमबद्ध गर्नुहोस्।
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// चेन दुई अर्डरिंगहरू।
    ///
    /// `self` फर्काउँछ जब यो `Equal` होईन।अन्यथा `other` फर्काउँछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// दिईएको प्रकार्यको साथ क्रममा क्रमबद्ध गर्नुहोस्।
    ///
    /// `self` फर्काउँछ जब यो `Equal` होइन।
    /// अन्यथा `f` कल गर्दछ र परिणाम फर्काउँछ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// रिभर्स अर्डरिंगका लागि सहयोगी संरचना।
///
/// यो संरचना [`Vec::sort_by_key`] जस्तै प्रकार्यहरूसँग प्रयोग गर्न मद्दत गर्ने सहायक हो र कुञ्जीको अंशलाई क्रमबद्ध गर्न प्रयोग गर्न सकिन्छ।
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait प्रकारहरूको लागि जुन [total order](https://en.wikipedia.org/wiki/Total_order) रूपान्दछन्।
///
/// एउटा अर्डर कुल आदेश हो जुन यो हो (सबै `a`, `b` र `c` को लागी):
///
/// - कुल र असममित: ठीक `a < b`, `a == b` वा `a > b` मध्ये एक सही हो;र
/// - ट्रान्जिटिभ, `a < b` र `b < c` `a < c` लागू गर्दछ।समान दुबै `==` र `>` को लागी समात्नु पर्छ।
///
/// ## Derivable
///
/// यो trait `#[derive]` को साथ प्रयोग गर्न सकिन्छ।
/// जब स्ट्राक्टमा derive`d, यसले [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) अर्डरिंग उत्पादन गर्दछ स्ट्रक्सका सदस्यहरूका शीर्ष-देखि-तल घोषणा अर्डरमा आधारित।
///
/// जब enums मा derive`d, भेरियन्ट्स तिनीहरूको शीर्ष देखि तल भेदभावपूर्ण आदेश द्वारा क्रमबद्ध छ।
///
/// ## शब्दकोष तुलना
///
/// शब्दकोष तुलना निम्न गुणहरूको साथ एक अपरेशन हो:
///  - दुई अनुक्रम तत्व द्वारा तत्व तुलना गरिएको छ।
///  - पहिलो बेमेल तत्वले परिभाषित गर्छ जुन कुन अनुक्रम लेक्सिकोग्राफिक भन्दा कम वा अर्को भन्दा ठूलो छ।
///  - यदि एउटा अनुक्रम अर्कोको उपसर्ग हो भने, छोटो अनुक्रम अर्को भन्दा तुलनाको भन्दा कम छ।
///  - यदि दुई अनुक्रम सँग बराबर तत्वहरू छन् र समान लम्बाईको छ भने, तब अनुक्रमहरू शब्दकोशको रूपमा बराबर हुन्छन्।
///  - खाली अनुक्रम कुनै गैर-खाली अनुक्रम भन्दा शब्दावलीमा कम हुन्छ।
///  - दुई खाली दृश्यहरू शब्दावलीमा बराबर छन्।
///
/// ## म कसरी `Ord` कार्यान्वयन गर्न सक्छु?
///
/// `Ord` प्रकारलाई [`PartialOrd`] र [`Eq`] (जसलाई [`PartialEq`] चाहिन्छ) पनि आवश्यक पर्दछ।
///
/// त्यसोभए तपाईंले [`cmp`] को लागी एक कार्यान्वयन परिभाषित गर्नु पर्छ।तपाईले आफ्नो प्रकारको फाँटहरूमा [`cmp`] प्रयोग गर्न यो उपयोगी फेला पार्न सक्नुहुनेछ।
///
/// [`PartialEq`], [`PartialOrd`], र `Ord`*को कार्यान्वयन* एक अर्कासँग सहमत हुनुपर्दछ।
/// त्यो हो, `a.cmp(b) == Ordering::Equal` यदि र केवल `a == b` र `Some(a.cmp(b)) == a.partial_cmp(b)` सबै `a` र `b` का लागि।
/// यो गल्तिले तिनीहरूलाई traits को व्युत्पन्न गरेर र अरूलाई मैन्युअल रूपमा कार्यान्वयन गरेर असहमत बनाउन सजिलो छ।
///
/// यहाँ उदाहरण छ जहाँ तपाईं मानिसहरूलाई उचाई द्वारा मात्र क्रमबद्ध गर्न चाहनुहुन्छ `id` र `name` लाई बेवास्ता गर्दै:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// यो विधिले `self` र `other` बीच [`Ordering`] फर्काउँछ।
    ///
    /// कन्भेन्सनद्वारा, `self.cmp(&other)` सही क्रममा `self <operator> other` अभिव्यक्तिसँग मेल खाने क्रमलाई फर्काउँछ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// दुई मानहरूको अधिकतम तुलना र फर्काउँछ।
    ///
    /// दोस्रो आर्गुमेन्ट फिर्ता गर्छ यदि तुलनाले तिनीहरूलाई बराबरको निर्धारण गर्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// दुई मानहरूको न्यूनतम तुलना गर्दछ र फर्काउँछ।
    ///
    /// पहिलो तर्क फर्काउँछ यदि तुलनाले तिनीहरूलाई बराबरको निर्धारण गर्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// निश्चित अंतरालमा मान प्रतिबन्धित गर्नुहोस्।
    ///
    /// `max` फर्काउँछ यदि `self` `max` भन्दा ठूलो छ, र `min` यदि `self` `min` भन्दा कम छ भने।
    /// अन्यथा यसले `self` फिर्ता गर्दछ।
    ///
    /// # Panics
    ///
    /// Panics यदि `min > max`।
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// trait `Ord` को एक इम्प्ली उत्पन्न डेरिभ म्याक्रो।
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait मानहरूको लागि जुन क्रमबद्ध-अर्डरको लागि तुलना गर्न सकिन्छ।
///
/// सबै `a`, `b` र `c` को लागि तुलना सन्तुष्ट हुनुपर्दछ:
///
/// - असममिति: यदि `a < b` त्यसोभए `!(a > b)`, साथै `a > b` पनि `!(a < b)` लागू गर्दै;र
/// - संक्रमण: `a < b` र `b < c` `a < c` लागू गर्दछ।समान दुबै `==` र `>` को लागी समात्नु पर्छ।
///
/// नोट गर्नुहोस् कि यी आवश्यकताहरूको trait आफैं symmetrically र transitively कार्यान्वयन हुनु पर्छ: यदि `T: PartialOrd<U>` र `U: PartialOrd<V>` तब `U: PartialOrd<T>` र `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// यो trait `#[derive]` को साथ प्रयोग गर्न सकिन्छ।जब स्ट्राक्ट्समा डेरिभिड हुन्छ, यसले कोटिक्सको सदस्यहरूको शीर्ष-देखि-तल घोषणा अर्डरमा आधारित कोशिक क्रम उत्पादन गर्दछ।
/// जब enums मा derive`d, भेरियन्ट्स तिनीहरूको शीर्ष देखि तल भेदभावपूर्ण आदेश द्वारा क्रमबद्ध छ।
///
/// ## म कसरी `PartialOrd` कार्यान्वयन गर्न सक्छु?
///
/// `PartialOrd` केवल पूर्वनिर्धारित कार्यान्वयनबाट उत्पन्न अन्यसँग [`partial_cmp`] विधि कार्यान्वयन आवश्यक छ।
///
/// जहाँसम्म पूर्ण प्रकारको अर्डर नभएका प्रकारका लागि अन्यलाई अलग कार्यान्वयन गर्न सम्भव छ।
/// उदाहरणका लागि, फ्लोटिंग पोइन्ट नम्बरहरूको लागि, `NaN < 0 == false` र `NaN >= 0 == false` (cf.
/// आईईईई 4 754-२००8 सेक्सन 5.11)।
///
/// `PartialOrd` तपाइँको प्रकार [`PartialEq`] हुन आवश्यक छ।
///
/// [`PartialEq`], `PartialOrd`, र [`Ord`]*को कार्यान्वयन* एक अर्कासँग सहमत हुनुपर्दछ।
/// यो गल्तिले तिनीहरूलाई traits को व्युत्पन्न गरेर र अरूलाई मैन्युअल रूपमा कार्यान्वयन गरेर असहमत बनाउन सजिलो छ।
///
/// यदि तपाईंको प्रकार [`Ord`] हो, तपाईं [`cmp`] प्रयोग गरेर [`partial_cmp`] कार्यान्वयन गर्न सक्नुहुनेछ:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// तपाईले आफ्नो प्रकारको फाँटहरूमा [`partial_cmp`] प्रयोग गर्न यो उपयोगी पनि फेला पार्न सक्नुहुन्छ।
/// यहाँ `Person` प्रकारहरूको उदाहरण छ जससँग फ्लोटिंग पोइन्ट `height` क्षेत्र छ जुन क्रमबद्ध गर्नका लागि मात्र क्षेत्र हो।
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// यस विधिले `self` र `other` मान बीचको अर्डरिंग फिर्ता गर्दछ यदि एक अवस्थित छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// जब तुलना असम्भव छ:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// यो विधि (`self` र `other` का लागि) भन्दा कम परीक्षण गर्दछ र `<` अपरेटर द्वारा प्रयोग गरीन्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// यो विधि भन्दा कम वा बराबर (`self` र `other` का लागि) परीक्षण गर्दछ र `<=` अपरेटर द्वारा प्रयोग गरीन्छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// यस विधिले (`self` र `other` का लागि) भन्दा बढि परीक्षण गर्दछ र `>` अपरेटर द्वारा प्रयोग गरीन्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// यस विधिले (`self` र `other` का लागि) भन्दा ठूलो वा बराबरको परीक्षण गर्दछ र `>=` अपरेटर द्वारा प्रयोग गरिन्छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// trait `PartialOrd` को एक इम्प्ली उत्पन्न डेरिभ म्याक्रो।
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// दुई मानहरूको न्यूनतम तुलना गर्दछ र फर्काउँछ।
///
/// पहिलो तर्क फर्काउँछ यदि तुलनाले तिनीहरूलाई बराबरको निर्धारण गर्छ।
///
/// आन्तरिक रूपमा [`Ord::min`] मा एक उपनाम प्रयोग गर्दछ।
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// निर्दिष्ट तुलना प्रकार्यको सन्दर्भमा न्यूनतम दुई मानहरू फर्काउँछ।
///
/// पहिलो तर्क फर्काउँछ यदि तुलनाले तिनीहरूलाई बराबरको निर्धारण गर्छ।
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// एलिमेन्ट फिर्ता गर्दछ जुन निर्दिष्ट प्रकार्यबाट न्यूनतम मान दिन्छ।
///
/// पहिलो तर्क फर्काउँछ यदि तुलनाले तिनीहरूलाई बराबरको निर्धारण गर्छ।
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// दुई मानहरूको अधिकतम तुलना र फर्काउँछ।
///
/// दोस्रो आर्गुमेन्ट फिर्ता गर्छ यदि तुलनाले तिनीहरूलाई बराबरको निर्धारण गर्छ।
///
/// आन्तरिक रूपमा [`Ord::max`] मा एक उपनाम प्रयोग गर्दछ।
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// निर्दिष्ट तुलना प्रकार्यको सन्दर्भमा अधिकतम दुई मानहरू फर्काउँछ।
///
/// दोस्रो आर्गुमेन्ट फिर्ता गर्छ यदि तुलनाले तिनीहरूलाई बराबरको निर्धारण गर्छ।
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// एलिमेन्ट फिर्ता गर्दछ जुन निर्दिष्ट प्रकार्यबाट अधिकतम मान दिन्छ।
///
/// दोस्रो आर्गुमेन्ट फिर्ता गर्छ यदि तुलनाले तिनीहरूलाई बराबरको निर्धारण गर्छ।
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// आंशिक प्रकारको लागि आंशिकEq, Eq, आंशिक ओर्ड र अर्डरको कार्यान्वयन
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // यहाँको अर्डर अधिक इष्टतम असेंबली उत्पन्न गर्न महत्त्वपूर्ण छ।
                    // अधिक जानकारीको लागि <https://github.com/rust-lang/rust/issues/63758> हेर्नुहोस्।
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // आई's को कास्ट गर्दै र फरकलाई अर्डरमा रूपान्तरण गर्नाले अधिक इष्टतम असेंबली उत्पन्न गर्दछ।
            //
            // अधिक जानकारीको लागि <https://github.com/rust-lang/rust/issues/66780> हेर्नुहोस्।
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // सुरक्षा: bool i8 ० वा १ फर्काउँछ, त्यसैले भिन्नता केहि अरू हुन सक्दैन
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &पोइन्टरहरू

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}