#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// [Unicode](http://www.unicode.org/) को संस्करण जुन `char` र `str` विधिहरूको यूनिकोड भागहरूमा आधारित छ।
///
/// युनिकोडका नयाँ संस्करणहरू नियमित रिलिज हुन्छन् र युनिकोडमा निर्भर मानक लाइब्रेरीमा सबै विधिहरू अपडेट हुन्छन्।
/// त्यसकारण केहि `char` र `str` विधिहरूको व्यवहार र समयको साथ यो स्थिर परिवर्तनको मान।
/// यो एक ब्रेक परिवर्तन मानिन्छ *।
///
/// संस्करण संख्या योजना [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) मा वर्णन गरिएको छ।
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// Liballoc मा प्रयोगको लागि, libstd मा पुनः निर्यात छैन।
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;