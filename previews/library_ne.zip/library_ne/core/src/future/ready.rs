use crate::future::Future;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future सिर्जना गर्दछ जुन तत्काल मानको साथ तयार छ।
///
/// यो `struct` [`ready()`] द्वारा बनाईएको हो।
/// अधिकको लागि यसको कागजात हेर्नुहोस्।
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
#[derive(Debug, Clone)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
pub struct Ready<T>(Option<T>);

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
impl<T> Unpin for Ready<T> {}

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
impl<T> Future for Ready<T> {
    type Output = T;

    #[inline]
    fn poll(mut self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<T> {
        Poll::Ready(self.0.take().expect("Ready polled after completion"))
    }
}

/// future सिर्जना गर्दछ जुन तत्काल मानको साथ तयार छ।
///
/// यस प्रकार्यको माध्यमबाट सिर्जना गरिएको Futures `async {}` मार्फत सिर्जना गरिएकोसँग कार्यमा मिल्दोजुल्दो छ।
/// मुख्य फरक यो हो कि यस प्रकार्य मार्फत सिर्जना गरिएको futures नाम र `Unpin` कार्यान्वयन गरिएको छ।
///
/// # Examples
///
/// ```
/// use std::future;
///
/// # async fn run() {
/// let a = future::ready(1);
/// assert_eq!(a.await, 1);
/// # }
/// ```
///
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub fn ready<T>(t: T) -> Ready<T> {
    Ready(Some(t))
}