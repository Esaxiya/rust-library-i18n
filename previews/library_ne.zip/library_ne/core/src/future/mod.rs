#![stable(feature = "futures_api", since = "1.36.0")]

//! एसिन्क्रोनस मानहरू।

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// यस प्रकारको आवश्यक छ किनकि:
///
/// a) जेनरेटरहरूले `for<'a, 'b> Generator<&'a mut Context<'b>>` कार्यान्वयन गर्न सक्दैन, त्यसैले हामीले एक कच्चा सूचक पार गर्न आवश्यक छ (<https://github.com/rust-lang/rust/issues/68923> हेर्नुहोस्)।
///
/// बी) कच्चा सters्केतकहरू र `NonNull` `Send` वा `Sync` होइनन्, ताकि प्रत्येक future non-Send/Sync पनि बनाउँदछ, र हामी त्यो चाहदैनौं।
///
/// यसले `.await` को HIR कम गर्नेलाई पनि सरल बनाउँछ।
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// future मा एक जेनेरेटर लपेट्नुहोस्।
///
/// यस प्रकार्यले तल `GenFuture` X फिर्ता गर्दछ, तर यसलाई `impl Trait` मा लुकाउँदछ राम्रो त्रुटि सन्देशहरू दिन (`impl Future` बरू `GenFuture<[closure.....]>`)।
///
// यो `const` हो जब हामी `const async fn` पुन: प्राप्ति पछि अतिरिक्त त्रुटिहरू जोगिन सक्छौं
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // हामी यस तथ्यमा भर पर्दछौं कि अन्तर्निहित जेनेरेटरमा आत्म-रेफरन्टल createण सिर्जना गर्न async/await futures अचल हो।
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // सुरक्षा: सुरक्षित किनभने हामी !Unpin + !Drop, र यो सिर्फ एक क्षेत्र प्रक्षेपण हो।
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // जेनरेटर पुनःसुरु गर्नुहोस्, `&mut Context` लाई `NonNull` कच्चा सूचकमा बदल्नुहोस्।
            // `.await` कम गर्दा सुरक्षित `&mut Context` मा कास्ट हुनेछ।
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // सुरक्षा: कलरले `cx.0` एक मान्य सूचक हो कि ग्यारेन्टी गर्न पर्छ
    // कि एक परिवर्तनीय सन्दर्भ को लागी सबै आवश्यकताहरु को पूरा।
    unsafe { &mut *cx.0.as_ptr().cast() }
}