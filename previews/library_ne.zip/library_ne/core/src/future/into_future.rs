use crate::future::Future;

/// एक `Future` मा रूपान्तरण।
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// आउटपुट जुन future पूरा हुने मा उत्पादन गर्दछ।
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// कस्तो प्रकारको future हामी यसलाई परिवर्तन गर्दैछौं?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// मानबाट future सिर्जना गर्दछ।
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}