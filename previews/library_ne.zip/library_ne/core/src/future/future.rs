#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// एक future एक एसिन्क्रोनस गणना प्रतिनिधित्व गर्दछ।
///
/// एक future एक मान हो कि कम्प्युटि finished समाप्त भएको हुन सक्छ।
/// यस प्रकारको "asynchronous value" यसले थ्रेडलाई उपयोगी काम गर्न जारी राख्नको लागि संभव बनाउँदछ जबकि यो मूल्य उपलब्ध हुनको लागि कुर्दै।
///
///
/// # `poll` विधि
///
/// को मुख्य विधि future, `poll`,*प्रयास गर्दछ* future अन्तिम मानमा समाधान गर्न।
/// यदि यो मूल्य तयार छैन भने यो विधि ब्लक हुँदैन।
/// यसको सट्टामा, वर्तमान कार्य ब्यूँझिने तालिकामा छ जब यो सम्भव छ फेरि `पोलिंग गरेर थप प्रगति गर्न।
/// `poll` विधिमा पार गरिएको `context` ले [`Waker`] प्रदान गर्न सक्दछ, जुन हालको कार्यलाई उठाउनको लागि ह्यान्डल हो।
///
/// जब future प्रयोग गर्दा, तपाईं सामान्य रूपमा `poll` कल गर्नुहुने छैन, तर यसको सट्टामा `.await` मान।
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// पूर्ण हुनेमा उत्पादित मानको प्रकार।
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// future लाई अन्तिम मानमा समाधान गर्न प्रयास गर्नुहोस्, वेकअपका लागि हालको कार्य दर्ता गर्नुहोस् यदि मान अझै उपलब्ध छैन भने।
    ///
    /// # फिर्ता मान
    ///
    /// यस प्रकार्यले फर्काउँछ:
    ///
    /// - [`Poll::Pending`] यदि future अझै तयार छैन
    /// - [`Poll::Ready(val)`] यो future को `val` परिणामको साथ यदि यो सफलतापूर्वक समाप्त भयो भने।
    ///
    /// एक पटक future समाप्त भएपछि, ग्राहकहरूले यसलाई फेरि `poll` हुँदैन।
    ///
    /// जब एक future अझै तैयार छैन, `poll` `Poll::Pending` फर्काउँछ र [`Waker`] को क्लोन वर्तमान [`Context`] बाट प्रतिलिपि गर्दछ।
    /// यो [`Waker`] फेरि एक पटक future प्रगति गर्न सक्दछ उठ्यो।
    /// उदाहरण को लागी, एक future एक सॉकेट को लागी पठन को लागी [`Waker`] मा `.clone()` कल र भण्डार गर्न को लागी।
    /// जब स else्केत अन्य ठाउँमा आइपुग्छ जुन सket्केत पढ्न योग्य छ भनेर संकेत गर्दै [`Waker::wake`] कल गरिन्छ र सकेट future को कार्य ब्यूँझियो।
    /// एक पटक कार्य उठिसकेपछि, यसले `poll` फेरि future प्रयास गर्नुपर्दछ, जसले अन्तिम मान उत्पादन गर्न सक्दछ वा गर्दैन।
    ///
    /// नोट गर्नुहोस् कि `poll` मा बहु कलहरूमा, [`Context`] बाट [`Waker`] मात्र भर्खरको कलमा वेकअप प्राप्त गर्नको लागि तालिकाबद्ध गरिएको थियो।
    ///
    /// # रनटाइम विशेषताहरू
    ///
    /// Futures एक्लो *inert* हुन्;प्रगति गर्नका लागि तिनीहरू *सक्रिय रूपमा*`हुनुपर्दछ, जसको अर्थ प्रत्येक पटक वर्तमान कार्य बिउँझन्छ, यसले सक्रियतासाथ पुन: shouldpoll` पेन्डिंग futures लाई पेन्डि should गर्नु पर्छ जुन अझै यसको चासो छ।
    ///
    /// `poll` प्रकार्यलाई टाईट लूपमा बारम्बार कल गरिएको छैन-यसको सट्टामा, यो केवल तब भनिन्छ जब future सूचित गर्दछ कि यो प्रगति गर्न तयार छ (`wake()`) कल गरेर)।
    /// यदि तपाईं `poll(2)` वा `select(2)` Unix मा Syscall सँग परिचित हुनुहुन्छ भने यो याद गर्नु उपयुक्त छ कि futures ले सामान्यतया *लिदैन*"all wakeups must poll all events" जस्तै समस्याहरू;तिनीहरू अधिक `epoll(4)` जस्तै छन्।
    ///
    /// `poll` को कार्यान्वयन छिटो फर्कने कोसिस गर्नु पर्छ, र रोक्नु हुँदैन।द्रुत फिर्तीले अनावश्यक रूपमा थ्रेडहरू वा घटना लूपहरू बन्द गर्दै रोक्दछ।
    /// यदि `poll` मा कलले केहि समय लिई समाप्त हुन सक्दछ भने यो कार्य पहिले थोरै पूलमा (वा त्यस्तै केहि) अफलोड हुनुपर्दछ कि `poll` चाँडै फर्कन सक्दछ भन्ने कुरालाई सुनिश्चित गर्न।
    ///
    /// # Panics
    ///
    /// एक पटक future पूरा भएपछि (`poll` बाट `Ready` फिर्ता गरियो), यसको `poll` विधिलाई फेरि कल गर्दै panic, सँधै रोक्न सक्छ, वा अन्य प्रकारका समस्याहरू निम्त्याउँदछ;`Future` trait ले त्यस्तो कलको प्रभावहरूमा कुनै आवश्यकताहरू राख्दैन।
    /// जहाँसम्म, `poll` विधिलाई `unsafe` चिन्ह लगाइएको छैन, Rust को सामान्य नियमहरू लागू हुन्छ: कलले कहिले पनि अपरिभाषित व्यवहार (मेमोरी भ्रष्टाचार, `unsafe` प्रकार्यहरूको गलत प्रयोग, वा त्यस्तै किसिमको) ल्याउनु हुँदैन, future राज्यको पर्वाह नगरी।
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}