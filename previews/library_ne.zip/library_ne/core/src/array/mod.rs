//! `Eq` जस्ता चीजहरूको कार्यान्वयन निश्चित लम्बाई एर्रेको लागि निश्चित लम्बाइसम्म।
//! अन्तमा, हामी सबै लम्बाइमा सामान्यीकरण गर्न सक्षम हुनुपर्दछ।
//!
//! *[See also the array primitive type](array).*
//!

#![stable(feature = "core_array", since = "1.36.0")]

use crate::borrow::{Borrow, BorrowMut};
use crate::cmp::Ordering;
use crate::convert::{Infallible, TryFrom};
use crate::fmt;
use crate::hash::{self, Hash};
use crate::iter::TrustedLen;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{Index, IndexMut};
use crate::slice::{Iter, IterMut};

mod iter;

#[stable(feature = "array_value_iter", since = "1.51.0")]
pub use iter::IntoIter;

/// `T` मा सन्दर्भलाई रूपान्तरण गर्दछ 1 लम्बाईको एर्रे (प्रतिलिपि बिना)।
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_ref<T>(s: &T) -> &[T; 1] {
    // सुरक्षा: `&T` लाई `&[T; 1]` रूपान्तरण ध्वनि हो।
    unsafe { &*(s as *const T).cast::<[T; 1]>() }
}

/// `T` को एक परिवर्तनीय सन्दर्भ लाई एक परिवर्तनीय सन्दर्भ को रूप मा बदलिन्छ 1 लम्बाईको एर्रे (प्रतिलिपि बिना)।
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_mut<T>(s: &mut T) -> &mut [T; 1] {
    // सुरक्षा: `&mut T` लाई `&mut [T; 1]` रूपान्तरण ध्वनि हो।
    unsafe { &mut *(s as *mut T).cast::<[T; 1]>() }
}

/// उपयोगिता trait स्थिर आकार को एरेमा मात्र लागू गरियो
///
/// यो trait अधिक मेटाडाटा ब्लोट बिना नै स्थिर आकार सानामा अन्य traits कार्यान्वयन गर्न प्रयोग गर्न सकिन्छ।
///
/// trait फिक्स-साइज एर्रेमा लागूकर्ताहरूलाई प्रतिबन्ध गर्न असुरक्षितको रूपमा चिनो लगाइएको छ।
/// यस trait को प्रयोगकर्ता मान्न सक्दछ कि कार्यान्वयनकर्ताहरूको निश्चित आकार एर्रेको स्मृतिमा सटीक रूपरेखा छ (उदाहरणका लागि असुरक्षित आरम्भको लागि)।
///
///
/// नोट गर्नुहोस् कि traits [`AsRef`] र [`AsMut`] प्रकारका लागि समान विधिहरू प्रदान गर्दछ जुन फिक्स-साइज एर्रेहरू हुन सक्दैन।
/// लागूकर्ताहरूले ती traits को सट्टा प्राथमिकता दिनुपर्दछ।
///
///
///
#[unstable(feature = "fixed_size_array", issue = "27778")]
pub unsafe trait FixedSizeArray<T> {
    /// एरेलाई परिवर्तनीय स्लाइसमा रूपान्तरण गर्दछ
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_slice(&self) -> &[T];
    /// एरेलाई म्यूटेबल स्लाइसमा रूपान्तरण गर्दछ
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_mut_slice(&mut self) -> &mut [T];
}

#[unstable(feature = "fixed_size_array", issue = "27778")]
unsafe impl<T, A: Unsize<[T]>> FixedSizeArray<T> for A {
    #[inline]
    fn as_slice(&self) -> &[T] {
        self
    }
    #[inline]
    fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }
}

/// त्रुटि प्रकार फर्काईयो जब स्लाईसबाट एर्रेमा रूपान्तरण असफल भयो।
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone)]
pub struct TryFromSliceError(());

#[stable(feature = "core_array", since = "1.36.0")]
impl fmt::Display for TryFromSliceError {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self.__description(), f)
    }
}

impl TryFromSliceError {
    #[unstable(
        feature = "array_error_internals",
        reason = "available through Error trait and this method should not \
                     be exposed publicly",
        issue = "none"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "could not convert slice to array"
    }
}

#[stable(feature = "try_from_slice_error", since = "1.36.0")]
impl From<Infallible> for TryFromSliceError {
    fn from(x: Infallible) -> TryFromSliceError {
        match x {}
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsRef<[T]> for [T; N] {
    #[inline]
    fn as_ref(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsMut<[T]> for [T; N] {
    #[inline]
    fn as_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> Borrow<[T]> for [T; N] {
    fn borrow(&self) -> &[T] {
        self
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> BorrowMut<[T]> for [T; N] {
    fn borrow_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<T, const N: usize> TryFrom<&[T]> for [T; N]
where
    T: Copy,
{
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<[T; N], TryFromSliceError> {
        <&Self>::try_from(slice).map(|r| *r)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a [T]> for &'a [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<&[T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_ptr() as *const [T; N];
            // सुरक्षा: हुन्छ किनकि हामीले भर्खरै जाँच्यौं कि लम्बाइ ठीक छ
            unsafe { Ok(&*ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a mut [T]> for &'a mut [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &mut [T]) -> Result<&mut [T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_mut_ptr() as *mut [T; N];
            // सुरक्षा: हुन्छ किनकि हामीले भर्खरै जाँच्यौं कि लम्बाइ ठीक छ
            unsafe { Ok(&mut *ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, const N: usize> Hash for [T; N] {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        Hash::hash(&self[..], state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for [T; N] {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&&self[..], f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a [T; N] {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a mut [T; N] {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> Index<I> for [T; N]
where
    [T]: Index<I>,
{
    type Output = <[T] as Index<I>>::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(self as &[T], index)
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> IndexMut<I> for [T; N]
where
    [T]: IndexMut<I>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(self as &mut [T], index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B; N]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &[B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&mut [B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&mut [B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&mut [B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &mut [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

// NOTE: कोड ब्लोट कम गर्न केहि कम महत्त्वपूर्ण प्रवर्तनहरू हटाइन्छन्
// __impl_slice_eq2!{ [A; $N], &'b [B; $N] } __impl_slice_eq2! { [A; $N], &'b mut [B; $N] }
//

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, const N: usize> Eq for [T; N] {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, const N: usize> PartialOrd for [T; N] {
    #[inline]
    fn partial_cmp(&self, other: &[T; N]) -> Option<Ordering> {
        PartialOrd::partial_cmp(&&self[..], &&other[..])
    }
    #[inline]
    fn lt(&self, other: &[T; N]) -> bool {
        PartialOrd::lt(&&self[..], &&other[..])
    }
    #[inline]
    fn le(&self, other: &[T; N]) -> bool {
        PartialOrd::le(&&self[..], &&other[..])
    }
    #[inline]
    fn ge(&self, other: &[T; N]) -> bool {
        PartialOrd::ge(&&self[..], &&other[..])
    }
    #[inline]
    fn gt(&self, other: &[T; N]) -> bool {
        PartialOrd::gt(&&self[..], &&other[..])
    }
}

/// एरे [lexicographically](Ord#lexicographical-comparison) को तुलना लागू गर्दछ।
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, const N: usize> Ord for [T; N] {
    #[inline]
    fn cmp(&self, other: &[T; N]) -> Ordering {
        Ord::cmp(&&self[..], &&other[..])
    }
}

// डिफल्ट इम्प्ल्स कन्सर्ट जेनेरिक्सका साथ गर्न सकिदैन किनकि `[T; 0]` लाई पूर्वनिर्धारित कार्यान्वयनको आवश्यकता पर्दैन, र बिभिन्न नम्बरहरूको लागि बिभिन्न इम्प्ली ब्लकहरू अझै समर्थित छैन।
//
//

macro_rules! array_impl_default {
    {$n:expr, $t:ident $($ts:ident)*} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] where T: Default {
            fn default() -> [T; $n] {
                [$t::default(), $($ts::default()),*]
            }
        }
        array_impl_default!{($n - 1), $($ts)*}
    };
    {$n:expr,} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] {
            fn default() -> [T; $n] { [] }
        }
    };
}

array_impl_default! {32, T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T}

#[lang = "array"]
impl<T, const N: usize> [T; N] {
    /// `self` को समान आकारको एर्रे फर्काउँछ, प्रकार्य `f` क्रममा प्रत्येक तत्वमा लागू गरियो।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_map)]
    /// let x = [1, 2, 3];
    /// let y = x.map(|v| v + 1);
    /// assert_eq!(y, [2, 3, 4]);
    ///
    /// let x = [1, 2, 3];
    /// let mut temp = 0;
    /// let y = x.map(|v| { temp += 1; v * temp });
    /// assert_eq!(y, [1, 4, 9]);
    ///
    /// let x = ["Ferris", "Bueller's", "Day", "Off"];
    /// let y = x.map(|v| v.len());
    /// assert_eq!(y, [6, 9, 3, 3]);
    /// ```
    #[unstable(feature = "array_map", issue = "75243")]
    pub fn map<F, U>(self, f: F) -> [U; N]
    where
        F: FnMut(T) -> U,
    {
        // सुरक्षा: हामी निश्चित रूपमा जान्दछौं कि यस पुनरावृत्तिले ठीक `N` उत्पादन गर्दछ
        // items.
        unsafe { collect_into_array_unchecked(&mut IntoIter::new(self).map(f)) }
    }

    /// 'Zip up' दुई एरे जोडीको एकल एर्रेमा।
    ///
    /// `zip()` नयाँ एर्रे फर्काउँछ जहाँ प्रत्येक एलिमेन्ट्स ट्युपल हुन्छ जहाँ पहिलो एलिमेन्ट पहिलो एरेबाट आउँछ, र दोस्रो एलिमेन्ट दोस्रो एरेबाट आउँदछ।
    ///
    /// अर्को शब्दहरुमा, यसले एकलमा दुई एरे सँगै zip गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_zip)]
    /// let x = [1, 2, 3];
    /// let y = [4, 5, 6];
    /// let z = x.zip(y);
    /// assert_eq!(z, [(1, 4), (2, 5), (3, 6)]);
    /// ```
    ///
    #[unstable(feature = "array_zip", issue = "80094")]
    pub fn zip<U>(self, rhs: [U; N]) -> [(T, U); N] {
        let mut iter = IntoIter::new(self).zip(IntoIter::new(rhs));

        // सुरक्षा: हामी निश्चित रूपमा जान्दछौं कि यस पुनरावृत्तिले ठीक `N` उत्पादन गर्दछ
        // items.
        unsafe { collect_into_array_unchecked(&mut iter) }
    }

    /// सम्पूर्ण एर्रे भएको स्लाइस फर्काउँछ।`&s[..]` को बराबरी।
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// सम्पूर्ण एर्रे सहितको म्यूटेबल स्लाइस फर्काउँछ।
    /// `&mut s[..]` को बराबरी।
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// प्रत्येक तत्व उधारो लिन्छ र `self` को समान आकारको साथ एर्रेन्सको एरे फर्काउँछ।
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&f64; 3] = floats.each_ref();
    /// assert_eq!(float_refs, [&3.1, &2.7, &-1.0]);
    /// ```
    ///
    /// यो विधि विशेष गरी उपयोगी छ यदि [`map`](#method.map) जस्तै अन्य विधिहरूसँग मिलाइन्छ।
    /// यस तरिकाले, तपाईं मूल एरे सार्नबाट बच्न सक्नुहुन्छ यदि यसको तत्वहरू `Copy` छैनन् भने।
    ///
    /// ```
    /// #![feature(array_methods, array_map)]
    ///
    /// let strings = ["Ferris".to_string(), "♥".to_string(), "Rust".to_string()];
    /// let is_ascii = strings.each_ref().map(|s| s.is_ascii());
    /// assert_eq!(is_ascii, [true, false, true]);
    ///
    /// // हामी अझै सक्कली एर्रेमा पहुँच गर्न सक्दछौं: यसलाई सारिएको छैन।
    /// assert_eq!(strings.len(), 3);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_ref(&self) -> [&T; N] {
        // सुरक्षा: हामी निश्चित रूपमा जान्दछौं कि यस पुनरावृत्तिले ठीक `N` उत्पादन गर्दछ
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter()) }
    }

    /// प्रत्येक तत्व परिवर्तनीय उधारो लिन्छ र `self` को समान आकारको साथ परिवर्तनीय सन्दर्भहरूको एर्रे फर्काउँछ।
    ///
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let mut floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&mut f64; 3] = floats.each_mut();
    /// *float_refs[0] = 0.0;
    /// assert_eq!(float_refs, [&mut 0.0, &mut 2.7, &mut -1.0]);
    /// assert_eq!(floats, [0.0, 2.7, -1.0]);
    /// ```
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_mut(&mut self) -> [&mut T; N] {
        // सुरक्षा: हामी निश्चित रूपमा जान्दछौं कि यस पुनरावृत्तिले ठीक `N` उत्पादन गर्दछ
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter_mut()) }
    }
}

/// `iter` बाट `N` वस्तुहरू तान्छ र तिनीहरूलाई एर्रेको रूपमा फर्काउँछ।
/// यदि इटरेटरले `N` भन्दा कम वस्तुहरू उत्पादन गर्दछ भने, यो प्रकार्य अपरिभाषित व्यवहार प्रदर्शन गर्दछ।
///
///
/// अधिक जानकारीको लागि [`collect_into_array`] हेर्नुहोस्।
///
/// # Safety
///
/// `iter` ले कम्तिमा `N` आईटमहरू दिन्छ भन्ने ग्यारेन्टी गर्न कलरमा निर्भर हुन्छ।
/// यस अवस्थालाई उल्लंघन गर्नाले अपरिभाषित व्यवहार हुन्छ।
unsafe fn collect_into_array_unchecked<I, const N: usize>(iter: &mut I) -> [I::Item; N]
where
    // Note: यहाँ `TrustedLen` प्रयोगको केहि हो।यो मात्र एक हो
    // आन्तरिक प्रकार्य, त्यसैले यदि यो बाउन्ड खराब विचार हुन जान्छ भने हटाउन स्वतन्त्र महसुस गर्नुहोस्।
    // त्यस्तो अवस्थामा, तलको बाउन्ड `debug_assert!` हटाउन पनि सम्झनुहोस्!
    //
    I: Iterator + TrustedLen,
{
    debug_assert!(N <= iter.size_hint().1.unwrap_or(usize::MAX));
    debug_assert!(N <= iter.size_hint().0);

    match collect_into_array(iter) {
        Some(array) => array,
        // सुरक्षा: समारोह सम्झौता द्वारा कभर।
        None => unsafe { crate::hint::unreachable_unchecked() },
    }
}

/// `iter` बाट `N` वस्तुहरू तान्छ र तिनीहरूलाई एर्रेको रूपमा फर्काउँछ।यदि इटरेटरले `N` आईटमहरू भन्दा कम उत्पादन गरे, `None` फिर्ता भयो र सबै पहिले नै उत्पन्न वस्तुहरू खसालियो।
///
/// किनकि इट्रेटर एक परिवर्तनीय सन्दर्भको रूपमा पारित गरियो र यो प्रकार्यले `next` लाई अधिकतम `N` पटक कल गर्दछ, ईटररेटर अझै पनी बाँकी वस्तुहरू पुनःप्राप्ति गर्न प्रयोग गर्न सकिन्छ।
///
///
/// यदि `iter.next()` देखी, सबै आईटमहरू पहिले नै पुनरावृत्तकर्ता द्वारा उत्पन्न गरीएको छ।
///
///
///
///
fn collect_into_array<I, const N: usize>(iter: &mut I) -> Option<[I::Item; N]>
where
    I: Iterator,
{
    if N == 0 {
        // सुरक्षा: एक खाली एर्रे सँधै बसोबास गर्दछ र कुनै वैधता इनवाइन्टहरू छैन।
        return unsafe { Some(mem::zeroed()) };
    }

    struct Guard<T, const N: usize> {
        ptr: *mut T,
        initialized: usize,
    }

    impl<T, const N: usize> Drop for Guard<T, N> {
        fn drop(&mut self) {
            debug_assert!(self.initialized <= N);

            let initialized_part = crate::ptr::slice_from_raw_parts_mut(self.ptr, self.initialized);

            // सुरक्षा: यस कच्चा स्लाइसले केवल आरम्भ गरिएको वस्तुहरू समावेश गर्दछ।
            unsafe {
                crate::ptr::drop_in_place(initialized_part);
            }
        }
    }

    let mut array = MaybeUninit::uninit_array::<N>();
    let mut guard: Guard<_, N> =
        Guard { ptr: MaybeUninit::slice_as_mut_ptr(&mut array), initialized: 0 };

    while let Some(item) = iter.next() {
        // सुरक्षा: `guard.initialized` ० मा सुरू हुन्छ, एउटामा बढाइयो
        // यो N (जुन `array.len()`) हो) मा पुग्दा एकपटक लूप र लूप परित्याग गरिन्छ।
        //
        unsafe {
            array.get_unchecked_mut(guard.initialized).write(item);
        }
        guard.initialized += 1;

        // सम्पूर्ण एर्रेसन आरम्भ गरिएको छ कि छैन जाँच गर्नुहोस्।
        if guard.initialized == N {
            mem::forget(guard);

            // सुरक्षा: माथिको सर्तले सबै तत्वहरू छन् भनेर जोड दिन्छ
            // initialized.
            let out = unsafe { MaybeUninit::array_assume_init(array) };
            return Some(out);
        }
    }

    // यो मात्र पुग्न सकिन्छ यदि एक्सरेक्टर थोरै छ `guard.initialized` `N` पुग्नु भन्दा पहिले।
    //
    // यो पनि नोट गर्नुहोस् कि `guard` यहाँ ड्रप गरिएको छ, सबै पहिले नै आरम्भ गरिएका तत्वहरू छोड्दै।
    None
}