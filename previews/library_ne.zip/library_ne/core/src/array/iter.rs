//! एर्रेहरूको लागि `IntoIter` स्वामित्व प्राप्त इट्रेटर परिभाषित गर्दछ।

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// A by-value [array] iterator।
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// यो एरे छ जुन हामी पुनरावृत्ति गर्दैछौं।
    ///
    /// अनुक्रमणिका `i` सँग एलिमेन्टहरू जहाँ `alive.start <= i < alive.end` अझै उत्पन्न गरिएको छैन र मान्य एरे प्रविष्टिहरू छन्।
    /// सूचकांक `i < alive.start` वा `i >= alive.end` सँग एलिमेन्टहरू पहिले नै उत्पन्न भएका छन् र अब पहुँच गर्न हुदैन!ती मरेका तत्वहरू पूर्ण रूपमा अनावश्यक अवस्थामा हुन सक्छन्!
    ///
    ///
    /// त्यसैले आक्रमणकारीहरू हुन्:
    /// - `data[alive]` जीवित छ (जस्तै मान्य तत्वहरू समावेश गर्दछ)
    /// - `data[..alive.start]` र `data[alive.end..]` मरेका छन् (अर्थात् तत्त्वहरू पहिल्यै पढिएको थियो र अब छुनु हुँदैन!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// `data` मा तत्त्वहरू जुन अहिले सम्म उत्पादन गरिएको छैन।
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// दिइएको `array` मा नयाँ इटरेटर बनाउँदछ।
    ///
    /// *नोट*: यो विधि future मा [`IntoIterator` is implemented for arrays][array-into-iter] पछि अस्वीकृत हुन सक्छ।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // `value` को प्रकार यहाँ `&i32` को सट्टामा `i32` हो
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // सुरक्षा: यहाँ transmute वास्तवमा सुरक्षित छ।`MaybeUninit` को कागजात
        // promise:
        //
        // > `MaybeUninit<T>` उही आकार र पign्क्तिबद्धता भएको ग्यारेन्टी गरिएको छ
        // > `T` को रूपमा।
        //
        // कागजातहरूले `MaybeUninit<T>` को एरेबाट `T` को एर्रेमा ट्रान्समिट पनि देखाउँदछ।
        //
        //
        // कि संग, यस इनिसियलाइसनले आक्रमणकर्ताहरुलाई सन्तुष्ट पार्छ।

        // FIXME(LukasKalbertodt): वास्तवमा यहाँ `mem::transmute` प्रयोग गर्नुहोस्, एकचोटि यसले जेनेरिकसँग काम गर्दछ:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // त्यतिन्जेल हामी `mem::transmute_copy` प्रयोग गर्न सक्छौं बिटवाइज प्रतिलिपि बिभिन्न प्रकारको रूपमा सिर्जना गर्न, त्यसपछि `array` बिर्सनुहोस् ताकि यो छोडियो।
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// सबै तत्वहरूको एक अपरणीय स्लाइस फर्काउँछ जुन अहिले सम्म उत्पन्न गरिएको छैन।
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // सुरक्षा: हामीलाई थाहा छ कि `alive` भित्र सबै तत्वहरू ठीकसँग आरम्भ भएका छन्।
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// सबै तत्वहरूको म्यूटेबल स्लाइस फर्काउँछ जुन अहिले सम्म प्राप्त गरिएको छैन।
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // सुरक्षा: हामीलाई थाहा छ कि `alive` भित्र सबै तत्वहरू ठीकसँग आरम्भ भएका छन्।
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // अगाडिबाट अर्को सूचकांक प्राप्त गर्नुहोस्।
        //
        // १ द्वारा `alive.start` लाई बढाउँदै `alive` को सम्बन्धमा इन्वाइरन्ट कायम गर्दछ।
        // जे होस्, यस परिवर्तनको कारण, छोटो समयको लागि, जीवित क्षेत्र अब `data[alive]` होइन, तर `data[idx..alive.end]`।
        //
        self.alive.next().map(|idx| {
            // एर्रेबाट एलिमेन्ट पढ्नुहोस्।
            // सुरक्षा: `idx` को पूर्व "alive" क्षेत्र मा एक अनुक्रमणिका हो
            // एर्रे।यस तत्वलाई पढ्नु भनेको `data[idx]` लाई अब मृतको रूपमा लिइन्छ (अर्थात स्पर्श नगर्नुहोस्)।
            // जस्तो कि `idx` जिउँदो जोनको सुरुवात थियो, जीवित क्षेत्र अब `data[alive]` फेरि हो, सबै आक्रमणकर्ताहरू पुनर्स्थापना गर्दै।
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // पछाडिबाट अर्को सूचकांक प्राप्त गर्नुहोस्।
        //
        // १ द्वारा `alive.end` लाई घटाउँदै `alive` को सम्बन्धमा इन्भिएरन्ट कायम गर्दछ।
        // जे होस्, यस परिवर्तनको कारण, छोटो समयको लागि, जीवित क्षेत्र अब `data[alive]` होइन, तर `data[alive.start..=idx]`।
        //
        self.alive.next_back().map(|idx| {
            // एर्रेबाट एलिमेन्ट पढ्नुहोस्।
            // सुरक्षा: `idx` को पूर्व "alive" क्षेत्र मा एक अनुक्रमणिका हो
            // एर्रे।यस तत्वलाई पढ्नु भनेको `data[idx]` लाई अब मृतको रूपमा लिइन्छ (अर्थात स्पर्श नगर्नुहोस्)।
            // जस्तो कि `idx` जिउँदो क्षेत्रको अन्त्य हो, जीवित क्षेत्र अब फेरि `data[alive]` छ, सबै आक्रमणकर्ताहरू पुनर्स्थापना गर्दै।
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // सुरक्षा: यो सुरक्षित छ: `as_mut_slice` ठीक सब-स्लाइस फर्काउँछ
        // तत्त्वहरूको जुन अझै बाहिर सारिएको छैन र ड्रप गर्न बाँकी छ।
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // आक्रमणकारी arian live.start <=को कारणले कहिले बहाउँदैन
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// पुनरावृत्तिकर्ताले सहि सही लम्बाई रिपोर्ट गर्दछ।
// "alive" एलिमेन्ट्सको संख्या (जुन अझै पनी उत्पादन हुन्छ) दायरा `alive` को लम्बाई हो।
// यो दायरा `next` वा `next_back` मा लम्बाइमा घटाइन्छ।
// यो ती विधिहरूमा सँधै १ द्वारा घटाइन्छ, तर मात्र यदि `Some(_)` फिर्ता हुन्छ।
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // नोट, हामीले वास्तवमै उही समान जीवित दायरासँग मेल खान आवश्यक पर्दैन, त्यसैले हामी केवल अफसेट ० मा क्लोन गर्न सक्छौं `self` X जहाँ भए पनि।
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // सबै जीवित तत्वहरू क्लोन गर्नुहोस्।
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // नयाँ एर्रेमा क्लोन लेख्नुहोस्, त्यसपछि यसको जीवित दायरा अपडेट गर्नुहोस्।
            // यदि panics क्लोनिंग गर्दै, हामी अघिल्लो आईटमहरू सहि छोड्नेछौं।
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // केवल एलिमेन्टहरू प्रिन्ट गर्नुहोस् जुन अझै उत्पादन गरिएको थिएन: हामी अब उपज तत्वहरू पहुँच गर्न सक्दैनौं।
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}