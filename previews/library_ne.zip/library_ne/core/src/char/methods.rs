//! impl Char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// `char` हुन सक्ने उच्चतम मान्य कोड पोइन्ट।
    ///
    /// एक `char` एक [Unicode Scalar Value] हो, यसको मतलब यो एक [Code Point] हो, तर निश्चित दायरा भित्र केवल एक।
    /// `MAX` उच्च मान्य वैध कोड पोइन्ट हो जुन मान्य [Unicode Scalar Value] हो।
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () डिकोडिंग त्रुटि प्रतिनिधित्व गर्न युनिकोडमा प्रयोग भयो।
    ///
    /// यो देखा पर्न सक्छ, उदाहरणका लागि, जब [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy) लाई X-01X बाइट्स बाट बनावट दिनुहुन्छ।
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// [Unicode](http://www.unicode.org/) को संस्करण जुन `char` र `str` विधिहरूको यूनिकोड भागहरूमा आधारित छ।
    ///
    /// युनिकोडका नयाँ संस्करणहरू नियमित रिलिज हुन्छन् र युनिकोडमा निर्भर मानक लाइब्रेरीमा सबै विधिहरू अपडेट हुन्छन्।
    /// त्यसकारण केहि `char` र `str` विधिहरूको व्यवहार र समयको साथ यो स्थिर परिवर्तनको मान।
    /// यो एक ब्रेक परिवर्तन मानिन्छ *।
    ///
    /// संस्करण संख्या योजना [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) मा वर्णन गरिएको छ।
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// `iter` मा UTF-16 एन्कोडेड कोड पोइन्टमा ईटरर बनाउँदछ, अविवाहित surrogatesलाई `Err`s को रूपमा फर्काउँदै।
    ///
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// हानिकारक डिकोडर `Err` परिणाम प्रतिस्थापन चरित्रको साथ बदली प्राप्त गर्न सकिन्छ:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// `u32` लाई `char` मा बदल्छ।
    ///
    /// नोट गर्नुहोस् कि सबै `char`s मान्य [[`u32`] s हो, र यसको साथ कास्ट गर्न सकिन्छ
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// जबकि, रिभर्स सही होइन: सबै मान्य [valid u32`] s मान्य`Char`s छैनन्।
    /// `from_u32()` `None` फर्काउँछ यदि इनपुट `char` को लागी मान्य मान होईन।
    ///
    /// यस कार्यको असुरक्षित संस्करणको लागि जसले यी जाँचहरूलाई बेवास्ता गर्दछ, हेर्नुहोस् [`from_u32_unchecked`]।
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// `None` फिर्ता गर्दै जब इनपुट मान्य `char` छैन:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// `u32` लाई `char` मा बदल्छ, मान्यताको बेवास्ता गर्दै।
    ///
    /// नोट गर्नुहोस् कि सबै `char`s मान्य [[`u32`] s हो, र यसको साथ कास्ट गर्न सकिन्छ
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// जबकि, रिभर्स सही होइन: सबै मान्य [valid u32`] s मान्य`Char`s छैनन्।
    /// `from_u32_unchecked()` यसलाई बेवास्ता गर्दछ, र अन्धाधुन्ध `char` मा कास्ट गर्दछ, एक अवैध एक सिर्जना गर्न।
    ///
    ///
    /// # Safety
    ///
    /// यो प्रकार्य असुरक्षित छ, किनकि यसले अवैध `char` मानहरू निर्माण गर्न सक्छ।
    ///
    /// यस प्रकार्यको सुरक्षित संस्करणको लागि, [`from_u32`] प्रकार्य हेर्नुहोस्।
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // सुरक्षा: सुरक्षा सम्झौता कलरले समर्थन गर्नै पर्छ।
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// दिइएको अंकलाई `char` मा बदल्छ।
    ///
    /// यहाँ एक 'radix' कहिलेकाँही 'base' पनि भनिन्छ।
    /// दुईको एक रेडिक्सले बाइनरी नम्बर, दशको दशमलव, र १teen को हेडसाडेसिमलको रेडिक्स स indicates्केत गर्दछ।
    ///
    /// मनमानी रेडिकलहरू समर्थित छन्।
    ///
    /// `from_digit()` `None` फर्काउँछ यदि इनपुट दिइएको radix मा एक अंक छैन।
    ///
    /// # Panics
    ///
    /// Panics यदि rad 36 भन्दा ठूलो रेडिक्स दिइयो।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // दशमलव ११ आधार १ in मा एकल अंक हो
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// फर्कदै `None` जब इनपुट अंक होईन:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// panic पैदा गर्दै, ठूलो रेडिक्स पास गर्दै:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// यदि `char` दिइएको रेडिक्समा अंक हो भने जाँच गर्दछ।
    ///
    /// यहाँ एक 'radix' कहिलेकाँही 'base' पनि भनिन्छ।
    /// दुईको एक रेडिक्सले बाइनरी नम्बर, दशको दशमलव, र १teen को हेडसाडेसिमलको रेडिक्स स indicates्केत गर्दछ।
    ///
    /// मनमानी रेडिकलहरू समर्थित छन्।
    ///
    /// [`is_numeric()`] को तुलनामा, यो प्रकार्यले `0-9`, `a-z` र `A-Z` लाई मात्र पहिचान गर्दछ।
    ///
    /// 'Digit' केवल निम्न पात्रहरूको रूपमा परिभाषित गरिएको छ:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// 'digit' को अधिक विस्तृत समझको लागि, [`is_numeric()`] हेर्नुहोस्।
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics यदि rad 36 भन्दा ठूलो रेडिक्स दिइयो।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// panic पैदा गर्दै, ठूलो रेडिक्स पास गर्दै:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// `char` X दिइएको अंकमा अंकमा रूपान्तरण गर्दछ।
    ///
    /// यहाँ एक 'radix' कहिलेकाँही 'base' पनि भनिन्छ।
    /// दुईको एक रेडिक्सले बाइनरी नम्बर, दशको दशमलव, र १teen को हेडसाडेसिमलको रेडिक्स स indicates्केत गर्दछ।
    ///
    /// मनमानी रेडिकलहरू समर्थित छन्।
    ///
    /// 'Digit' केवल निम्न पात्रहरूको रूपमा परिभाषित गरिएको छ:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// `None` फर्काउँछ यदि `char` दिइएको रेडिक्स मा एक अंक को सन्दर्भ छैन।
    ///
    /// # Panics
    ///
    /// Panics यदि rad 36 भन्दा ठूलो रेडिक्स दिइयो।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// विफलतामा एक अ digit्कको नतीजा पास गर्दै:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// panic पैदा गर्दै, ठूलो रेडिक्स पास गर्दै:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // `radix` स्थिर र १० वा सानो रहेको केसहरूको कार्यान्वयन गति सुधार गर्न यहाँ कोड छुट्याइएको छ
        //
        let val = if likely(radix <= 10) {
            // यदि एक अंक होईन भने, मूलांक भन्दा ठूलो संख्या सिर्जना हुनेछ।
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// एक पुनरावृत्तिकर्ता फर्काउँछ जुन हेक्साडेसिमल युनिकोड भाग `char`s को रूपमा चरित्रबाट निकाल्छ।
    ///
    /// यो `\u{NNNNNN}` फारमको Rust सिन्ट्याक्सको साथ पात्रहरू उम्कने छ जहाँ `NNNNNN` हेक्साडेसिमल प्रतिनिधित्व हो।
    ///
    ///
    /// # Examples
    ///
    /// एक पुनरावृतकर्ताको रूपमा:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` सीधा प्रयोग गर्दै:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// दुबै बराबर हुन्:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// `to_string` प्रयोग गर्दै:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // वा इ ing्गिंग १ ले सुनिश्चित गर्दछ कि c==० कोड गणना गर्दछ जुन एक अंक प्रिन्ट हुनुपर्दछ र (जुन समान हो)(,१,)२) इनफ्लोलाई बेवास्ता गर्दछ
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // सब भन्दा महत्वपूर्ण हेक्स अंक को सूचकांक
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// `escape_debug` को एक विस्तारित संस्करण जुन वैकल्पिक रूपमा विस्तारित ग्राफाइम कोडेपोइन्ट्सबाट उम्कन अनुमति दिन्छ।
    /// यसले हामीलाई अक्षरहरू प्रारूपित गर्न अनुमति दिन्छ जस्तै nonspacing मार्कहरू जब तिनीहरू स्ट्रिंगको सुरूमा हुन्छन्।
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// ईटररेटर फर्काउँछ जुन अक्षरको शाब्दिक एस्केप कोड `Char`s को रूपमा दिन्छ।
    ///
    /// यो `str` वा `char` को `Debug` कार्यान्वयनको जस्तै पात्रहरू उम्कने छ।
    ///
    ///
    /// # Examples
    ///
    /// एक पुनरावृतकर्ताको रूपमा:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` सीधा प्रयोग गर्दै:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// दुबै बराबर हुन्:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// `to_string` प्रयोग गर्दै:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// ईटररेटर फर्काउँछ जुन अक्षरको शाब्दिक एस्केप कोड `Char`s को रूपमा दिन्छ।
    ///
    /// पूर्वनिर्धारित शाब्दिक उत्पादनको प्रति पूर्वाग्रहको साथ छनौट गरियो जुन C++ 11 र समान C-पारिवारिक भाषाहरू सहित विभिन्न भाषाहरूमा कानूनी हुन्छ।
    /// सहि नियमहरू:
    ///
    /// * ट्याब `\t` को रूपमा भाग्यो।
    /// * क्यारिज रिटर्न `\r` को रूपमा भाग्यो।
    /// * लाइन फिड `\n` को रूपमा भाग्यो।
    /// * एकल उद्धरण `\'` को रूपमा भाग्यो।
    /// * डबल उद्धरण `\"` को रूपमा भाग्यो।
    /// * ब्याकस्लेश `\\` को रूपमा भाग्यो।
    /// * 'मुद्रण योग्य ASCII' दायरा `0x20` मा कुनै पनि वर्ण .. `0x7e` समावेशी उम्कन छैन।
    /// * अन्य सबै पात्रहरूलाई हेक्साडेसिमल युनिकोड एस्केप दिइन्छ;[`escape_unicode`] हेर्नुहोस्।
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// एक पुनरावृतकर्ताको रूपमा:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` सीधा प्रयोग गर्दै:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// दुबै बराबर हुन्:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// `to_string` प्रयोग गर्दै:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// UTF-8 मा ईन्कोड गरिएको छ भने `char` लाई चाहिने बाइट्सको संख्या फर्काउँछ।
    ///
    /// बाइट्सको संख्या सँधै १ र between बिचको हुन्छ, समावेशी।
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str` प्रकार ग्यारेन्टी गर्दछ कि यसको सामग्रीहरू UTF-8 छन्, र त्यसैले हामी लिने लम्बाइ तुलना गर्न सक्छौं यदि प्रत्येक कोड पोइन्ट `char` बनाम `&str` मा प्रतिनिधित्व गरिएको थियो भने:
    ///
    ///
    /// ```
    /// // चराहरूको रूपमा
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // दुबैलाई तीन बाइटको रूपमा प्रतिनिधित्व गर्न सकिन्छ
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // एक &str को रूपमा, यी दुई UTF-8 मा एन्कोड गरिएका छन्
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // हामी देख्न सक्छौं कि उनीहरूले छ वटा बाइट लिन्छन् ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... केवल &str जस्तै
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// १ X-बिट कोड इकाइहरूको संख्या फर्काउँदछ जुन `char` लाई UTF-16 मा ईन्कोड गरिएको हुन आवश्यक पर्दछ।
    ///
    ///
    /// यस अवधारणाको अधिक विवरणको लागि [`len_utf8()`] का लागि कागजात हेर्नुहोस्।
    /// यो प्रकार्य ऐना हो, तर UTF-8 को सट्टा UTF-16 को लागी।
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// यस पात्रलाई UTF-8 को रूपमा प्रदान गरिएको बाइट बफरमा एन्कोड गर्दछ, र त्यसपछि बफरको सब्सलिस फर्काउँछ जुन ईन्कोड गरिएको क्यारेक्टर समावेश गर्दछ।
    ///
    ///
    /// # Panics
    ///
    /// Panics यदि बफर पर्याप्त ठूलो छैन।
    /// चारको लम्बाइको बफर कुनै पनि `char` सode्केतन गर्न पर्याप्त ठूलो छ।
    ///
    /// # Examples
    ///
    /// यी दुबै उदाहरणहरूमा, 'ß' एन्कोड गर्न दुई बाइट्स लिन्छ।
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// धेरै सानो छ कि बफर:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // सुरक्षा: `char` एक surrogate हैन, त्यसैले यो मान्य UTF-8 छ।
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// UTF-16 को रूपमा प्रदान गरिएको `u16` बफरमा यो क्यारेक्टर ईनकोड गर्दछ, र त्यसपछि बफरको सब्सलिस फर्काउँछ जुन इनकोड गरिएको क्यारेक्टर समावेश गर्दछ।
    ///
    ///
    /// # Panics
    ///
    /// Panics यदि बफर पर्याप्त ठूलो छैन।
    /// लम्बाई २ को बफर कुनै पनि `char` स enc्केतन गर्न पर्याप्त ठूलो छ।
    ///
    /// # Examples
    ///
    /// यी दुबै उदाहरणहरूमा, '𝕊' स two्केतन गर्न दुई `u16` लिन्छ।
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// धेरै सानो छ कि बफर:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// `true` फर्काउँछ यदि यो `char` सँग `Alphabetic` सम्पत्ती छ।
    ///
    /// `Alphabetic` [Unicode Standard] को अध्याय 4 (चरित्र गुणहरू) मा वर्णन गरिएको छ र [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] मा निर्दिष्ट छ।
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // प्रेम धेरै चीजहरू हुन्, तर यो वर्णमाला होइन
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// `true` फर्काउँछ यदि यो `char` सँग `Lowercase` सम्पत्ती छ।
    ///
    /// `Lowercase` [Unicode Standard] को अध्याय 4 (चरित्र गुणहरू) मा वर्णन गरिएको छ र [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] मा निर्दिष्ट छ।
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // बिभिन्न चीनियाँ लिपि र विराम चिह्नको केस हुँदैन, र यस्तै:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// `true` फर्काउँछ यदि यो `char` सँग `Uppercase` सम्पत्ती छ।
    ///
    /// `Uppercase` [Unicode Standard] को अध्याय 4 (चरित्र गुणहरू) मा वर्णन गरिएको छ र [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] मा निर्दिष्ट छ।
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // बिभिन्न चीनियाँ लिपि र विराम चिह्नको केस हुँदैन, र यस्तै:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// `true` फर्काउँछ यदि यो `char` सँग `White_Space` सम्पत्ती छ।
    ///
    /// `White_Space` [Unicode Character Database][ucd] [`PropList.txt`] मा तोकिएको छ।
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // एक तोडने ठाउँ
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// `true` फिर्ता गर्दछ यदि यो `char` या त [`is_alphabetic()`] वा [`is_numeric()`] सन्तुष्ट।
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// `true` फिर्ता गर्छ यदि यो `char` लाई नियन्त्रण कोडहरूको लागि सामान्य कोटी छ।
    ///
    /// नियन्त्रण कोड (`Cc` को सामान्य वर्गको साथ कोड पोइन्टहरू) [Unicode Standard] को अध्याय 4 (चरित्र गुणहरू) मा वर्णन गरिएको छ र [Unicode Character Database][ucd] [`UnicodeData.txt`] मा निर्दिष्ट छ।
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// // U + 009C, STRING टर्मिनोर
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// `true` फर्काउँछ यदि यो `char` सँग `Grapheme_Extend` सम्पत्ती छ।
    ///
    /// `Grapheme_Extend` [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] मा वर्णन गरिएको छ र [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] मा तोकिएको छ।
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// `true` फर्काउँछ यदि यो `char` संख्याको लागि सामान्य कोटी मध्ये एक हो।
    ///
    /// संख्याका लागि सामान्य कोटीहरू (दशमलव अंकहरूको लागि `Nd`, अक्षर-जस्तो संख्यात्मक क्यारेक्टरहरूको लागि `Nl`, र अन्य संख्यात्मक वर्णहरूको लागि `No`) [Unicode Character Database][ucd] [`UnicodeData.txt`] मा तोकिन्छ।
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// आधारभूत उपयोग:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// एक पुनरावृत्तिकर्ता फर्काउँछ जुन एक वा अधिकको रूपमा यो `char` को लोअरकेस म्यापि। उत्पादन गर्दछ
    /// `char`s.
    ///
    /// यदि यो `char` एक लोअरकेस म्यापि। छैन भने, ईटरेटर समान `char` उत्पादन गर्दछ।
    ///
    /// यदि यो `char` सँग एक-एक-लोअरकेस म्यापि the [Unicode Character Database][ucd] [`UnicodeData.txt`] द्वारा दिइएको छ भने, ईटरेटरले `char` उत्पादन गर्दछ।
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// यदि यो `char` लाई विशेष विचारको आवश्यक पर्दछ (जस्तै एकाधिक `चार्स) इटरेटर [`SpecialCasing.txt`] द्वारा दिइएको` चार्ट (हरू) उपज दिन्छ।
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// यो अपरेसनले टेलरिंग बिना शर्त म्यापि। कार्य गर्दछ।त्यो हो, रूपान्तरण सन्दर्भ र भाषा स्वतन्त्र छ।
    ///
    /// [Unicode Standard] मा, अध्याय 4 (वर्ण गुणहरू) सामान्य रूपमा केस म्यापि discusको बारेमा चर्चा गर्दछ र अध्याय X (Conformance) केस रूपान्तरणको लागि पूर्वनिर्धारित एल्गोरिथ्मको बारेमा छलफल गर्दछ।
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// एक पुनरावृतकर्ताको रूपमा:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` सीधा प्रयोग गर्दै:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// दुबै बराबर हुन्:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// `to_string` प्रयोग गर्दै:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // कहिलेकाँही परिणाम एक भन्दा बढि चरित्रहरू हुन्:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // क्यारेक्टरहरू जो दुबै अपरकेस र लोवरकेस छैन आफैमा रूपान्तरण।
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// एक पुनरावृत्तिकर्ता फर्काउँछ जुन यस `char` को ठूलो वा एक भन्दा बढीको म्यापि। उपज दिन्छ
    /// `char`s.
    ///
    /// यदि यो `char` सँग अपरकेस म्यापि। छैन भने, इटरेटरले उही `char` उत्पादन गर्दछ।
    ///
    /// यदि यो `char` सँग एक-एक-अपरकेस म्यापि the [Unicode Character Database][ucd] [`UnicodeData.txt`] द्वारा दिइएको छ भने, ईरेटरले `char` उत्पादन गर्छ।
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// यदि यो `char` लाई विशेष विचारको आवश्यक पर्दछ (जस्तै एकाधिक `चार्स) इटरेटर [`SpecialCasing.txt`] द्वारा दिइएको` चार्ट (हरू) उपज दिन्छ।
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// यो अपरेसनले टेलरिंग बिना शर्त म्यापि। कार्य गर्दछ।त्यो हो, रूपान्तरण सन्दर्भ र भाषा स्वतन्त्र छ।
    ///
    /// [Unicode Standard] मा, अध्याय 4 (वर्ण गुणहरू) सामान्य रूपमा केस म्यापि discusको बारेमा चर्चा गर्दछ र अध्याय X (Conformance) केस रूपान्तरणको लागि पूर्वनिर्धारित एल्गोरिथ्मको बारेमा छलफल गर्दछ।
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// एक पुनरावृतकर्ताको रूपमा:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` सीधा प्रयोग गर्दै:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// दुबै बराबर हुन्:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// `to_string` प्रयोग गर्दै:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // कहिलेकाँही परिणाम एक भन्दा बढि चरित्रहरू हुन्:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // क्यारेक्टरहरू जो दुबै अपरकेस र लोवरकेस छैन आफैमा रूपान्तरण।
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # लोकेल मा नोट
    ///
    /// टर्कीमा, ल्याटिनमा 'i' को बराबरको दुईको सट्टा पाँच फारामहरू छन्:
    ///
    /// * 'Dotless': I/ı, कहिलेकाँही लिखित ï
    /// * 'Dotted': İ/i
    ///
    /// नोट गर्नुहोस् कि लोअरकेस डटेड 'i' ल्याटिन जस्तै हो।तसर्थ:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// यहाँ `upper_i` को मान पाठको भाषामा निर्भर गर्दछ: यदि हामी `en-US` मा छौं भने यो `"I"` हुनु पर्छ, तर यदि हामी `tr_TR` मा छौं भने यो `"İ"` हुनु पर्छ।
    /// `to_uppercase()` यसलाई ध्यानमा राख्दैन, र:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// भाषाहरू भरि होल्ड गर्दछ।
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// मान ASCII दायरा भित्र छ कि छैन जाँच गर्दछ।
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// यसको ASCII अपर केस बराबरमा मानको प्रतिलिपि बनाउँदछ।
    ///
    /// 'z' लाई 'a' लाई ASCII अक्षरहरू 'A' लाई 'Z' मा म्याप गरिएको छ, तर गैर-ASCII अक्षर परिवर्तन गरिएको छैन।
    ///
    /// ठाउँमा ठूलो मानको लागि, [`make_ascii_uppercase()`] प्रयोग गर्नुहोस्।
    ///
    /// अपरकेस एएससीआईआई क्यारेक्टरहरू गैर-ASCII वर्णहरूको अतिरिक्त, [`to_uppercase()`] प्रयोग गर्नुहोस्।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// यसको ASCII लोअर केस बराबरमा मानको प्रतिलिपि बनाउँदछ।
    ///
    /// 'Z' लाई 'A' लाई ASCII अक्षरहरू 'a' लाई 'z' मा म्याप गरिएको छ, तर गैर-ASCII अक्षर परिवर्तन गरिएको छैन।
    ///
    /// ठाँउमा मूल्य सानो ठाउँमा राख्न, [`make_ascii_lowercase()`] प्रयोग गर्नुहोस्।
    ///
    /// लोअरकेस ASCII वर्णहरू बाहेक-ASCII वर्णहरूमा, [`to_lowercase()`] प्रयोग गर्नुहोस्।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// दुई मानहरू ASCII केस-असंवेदनशील म्याच हो भनेर जाँच गर्दछ।
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` को बराबरी।
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// यस प्रकारलाई यसको ASCII माथिल्लो केसमा बराबर स्थानमा रूपान्तरण गर्दछ।
    ///
    /// 'z' लाई 'a' लाई ASCII अक्षरहरू 'A' लाई 'Z' मा म्याप गरिएको छ, तर गैर-ASCII अक्षर परिवर्तन गरिएको छैन।
    ///
    /// अवस्थित एकलाई परिमार्जन नगरी नयाँ ठूलो ठूलो मान फर्काउन [`to_ascii_uppercase()`] प्रयोग गर्नुहोस्।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// यस प्रकारलाई यसको ASCII लोअर केसमा बराबर स्थानमा रूपान्तरण गर्दछ।
    ///
    /// 'Z' लाई 'A' लाई ASCII अक्षरहरू 'a' लाई 'z' मा म्याप गरिएको छ, तर गैर-ASCII अक्षर परिवर्तन गरिएको छैन।
    ///
    /// अवस्थित एकलाई परिमार्जन नगरी नयाँ लोअरकेस मान फिर्ता गर्न [`to_ascii_lowercase()`] प्रयोग गर्नुहोस्।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// यदि मान एक ASCII वर्णमाला वर्ण हो भने जाँच गर्दछ:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', वा
    /// - U + 0061 'a' ..=U + 007A 'z'।
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// यदि मान एक ASCII अपरकेस क्यारेक्टर हो भनेर जाँच गर्दछ:
    /// U + 0041 'A' ..=U + 005A 'Z'।
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// मान ASCII सानो वर्ण हो भने जाँच गर्दछ:
    /// U + 0061 'a' ..=U + 007A 'z'।
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// यदि मान एक ASCII अक्षरांकीय वर्ण हो भने जाँच गर्दछ:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', वा
    /// - U + 0061 'a' ..=U + 007A 'z', वा
    /// - U + 0030 '0' ..=U + 0039 '9'।
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// यदि मान एक ASCII दशमलव अंक हो भने जाँच गर्दछ:
    /// U + 0030 '0' ..=U + 0039 '9'।
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// यदि मान एक ASCII हेक्साडेसिमल अंक हो भने जाँच गर्दछ:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', वा
    /// - U + 0041 'A' ..=U + 0046 'F', वा
    /// - U + 0061 'a' ..=U + 0066 'f'।
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// यदि मान एक ASCII विराम चिह्न हो भने जाँच गर्दछ:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, वा
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, वा
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, वा
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// यदि मान एक ASCII ग्राफिक चरित्र हो भने जाँच गर्दछ:
    /// U + 0021 '!' ..=U + 007E '~'।
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// यदि मान एक ASCII सेतो स्पेस वर्ण हो भने जाँच गर्दछ:
    /// U + 0020 स्पेस, U + 0009 HORIZONTAL ट्याब, U + 000A लाइन फीड, U + 000C फारम फीड, वा U + 000D कैरिज फिर्ता।
    ///
    /// Rust ले WHWG इन्फ्रा मानकको [definition of ASCII whitespace][infra-aw] प्रयोग गर्दछ।विस्तृत प्रयोगमा अन्य धेरै परिभाषाहरू छन्।
    /// उदाहरण को लागी, [the POSIX locale][pct] ले U + 000B VERTICAL TAB साथ साथै माथिका सबै क्यारेक्टरहरू समावेश गर्दछ, तर very एकै समान स्पेसिफिकेसनबाट-[बॉर्न shell मा "field splitting" का लागि पूर्वनिर्धारित नियम][bfs]*केवल* स्पेस, HORIZONTAL ट्याब, र लाइन फ्ल्याटस्पेसको रूपमा।
    ///
    ///
    /// यदि तपाईले प्रोग्राम लेखिरहनु भएको छ कि अवस्थित फाइल ढाँचा प्रशोधन गर्ने छ भने, यो प्रकार्य प्रयोग गर्नु अघि श्वेतस्थानको त्यो ढाँचाको परिभाषा के हो जाँच गर्नुहोस्।
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// यदि मान एक ASCII नियन्त्रण चरित्र हो भनेर जाँच गर्दछ:
    /// U +0000 NUL ..=U + 001F UNIT SEPARATOR, वा U + 007F हटाउनुहोस्।
    /// नोट गर्नुहोस् कि धेरै जसो एएससीआईआई ह्वाइटस्पेस क्यारेक्टरहरू कन्ट्रोल क्यारेक्टर हुन्, तर स्पेस छैन।
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// प्रदान गरिएको बाइट बफरमा UTF-8 को रूपमा एक कच्चा u32 मान एन्कोड गर्दछ, र त्यसपछि इन्कोड गरिएको चरित्र समावेश भएको बफरको सब्सलिस फर्काउँछ।
///
///
/// `char::encode_utf8` विपरीत, यो विधि ले surrogate दायरा मा codipPoint ह्यान्डल गर्दछ।
/// (Surrogate दायरामा एक `char` सिर्जना UB हो।) परिणाम मान्य [generalized UTF-8] हो तर मान्य UTF-8 होईन।
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics यदि बफर पर्याप्त ठूलो छैन।
/// चारको लम्बाइको बफर कुनै पनि `char` सode्केतन गर्न पर्याप्त ठूलो छ।
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// UTF-16 को रूपमा प्रदान गरिएको `u16` बफरमा एउटा कच्चा u32 मान एन्कोड गर्दछ, र त्यसपछि इन्कोड गरिएको चरित्र समावेश भएको बफरको सदस्यता प्राप्त गर्दछ।
///
///
/// `char::encode_utf16` विपरीत, यो विधि ले surrogate दायरा मा codipPoint ह्यान्डल गर्दछ।
/// (Surrogate दायरामा एक `char` सिर्जना UB हो।)
///
/// # Panics
///
/// Panics यदि बफर पर्याप्त ठूलो छैन।
/// लम्बाई २ को बफर कुनै पनि `char` स enc्केतन गर्न पर्याप्त ठूलो छ।
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // सुरक्षा: प्रत्येक हातले लेख्न को लागी पर्याप्त बिट्स छन् कि छैन जाँच गर्दछ
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP को माध्यमबाट पर्दछ
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // पूरक विमानहरु surrogates मा तोड्न।
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}