//! UTF-8 र UTF-16 डिकोडिंग इटरेटरहरू

use crate::fmt;

use super::from_u32_unchecked;

/// Ite u16` को एक इटरेटरबाट UTF-16 सod्केतन कोड बिन्दुहरू डिकोड गर्ने एक पुनरावृत्ति।
#[stable(feature = "decode_utf16", since = "1.9.0")]
#[derive(Clone, Debug)]
pub struct DecodeUtf16<I>
where
    I: Iterator<Item = u16>,
{
    iter: I,
    buf: Option<u16>,
}

/// एक त्रुटि जुन UTF-16 कोड पोइन्ट्स डिकोडिंग गर्दा फिर्ता गर्न सकिन्छ।
#[stable(feature = "decode_utf16", since = "1.9.0")]
#[derive(Debug, Clone, Eq, PartialEq)]
pub struct DecodeUtf16Error {
    code: u16,
}

/// `iter` मा UTF-16 एन्कोडेड कोड पोइन्टमा ईटरर बनाउँदछ, अविवाहित surrogatesलाई `Err`s को रूपमा फर्काउँदै।
///
///
/// # Examples
///
/// आधारभूत उपयोग:
///
/// ```
/// use std::char::decode_utf16;
///
/// // 𝄞mus<invalid>ic<invalid>
/// let v = [
///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
/// ];
///
/// assert_eq!(
///     decode_utf16(v.iter().cloned())
///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
///         .collect::<Vec<_>>(),
///     vec![
///         Ok('𝄞'),
///         Ok('m'), Ok('u'), Ok('s'),
///         Err(0xDD1E),
///         Ok('i'), Ok('c'),
///         Err(0xD834)
///     ]
/// );
/// ```
///
/// हानिकारक डिकोडर `Err` परिणाम प्रतिस्थापन चरित्रको साथ बदली प्राप्त गर्न सकिन्छ:
///
/// ```
/// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
///
/// // 𝄞mus<invalid>ic<invalid>
/// let v = [
///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
/// ];
///
/// assert_eq!(
///     decode_utf16(v.iter().cloned())
///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
///        .collect::<String>(),
///     "𝄞mus�ic�"
/// );
/// ```
#[stable(feature = "decode_utf16", since = "1.9.0")]
#[inline]
pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
    DecodeUtf16 { iter: iter.into_iter(), buf: None }
}

#[stable(feature = "decode_utf16", since = "1.9.0")]
impl<I: Iterator<Item = u16>> Iterator for DecodeUtf16<I> {
    type Item = Result<char, DecodeUtf16Error>;

    fn next(&mut self) -> Option<Result<char, DecodeUtf16Error>> {
        let u = match self.buf.take() {
            Some(buf) => buf,
            None => self.iter.next()?,
        };

        if u < 0xD800 || 0xDFFF < u {
            // सुरक्षा: एक surrogate हैन
            Some(Ok(unsafe { from_u32_unchecked(u as u32) }))
        } else if u >= 0xDC00 {
            // एक अनुगामी surrogate
            Some(Err(DecodeUtf16Error { code: u }))
        } else {
            let u2 = match self.iter.next() {
                Some(u2) => u2,
                // eof
                None => return Some(Err(DecodeUtf16Error { code: u })),
            };
            if u2 < 0xDC00 || u2 > 0xDFFF {
                // ट्रेलि sur सरोगेट होईन त्यसैले हामी एक मान्य surrogate जोडी होइनौं, त्यसैले अर्को पटक u2 रेडकोड गर्नुहोस्।
                //
                self.buf = Some(u2);
                return Some(Err(DecodeUtf16Error { code: u }));
            }

            // सबै ठीक छ, त्यसैले यसलाई डिकोड गरौं।
            let c = (((u - 0xD800) as u32) << 10 | (u2 - 0xDC00) as u32) + 0x1_0000;
            // सुरक्षा: हामीले जाँच गर्‍यौं कि यो कानूनी युनिकोड मान हो
            Some(Ok(unsafe { from_u32_unchecked(c) }))
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let (low, high) = self.iter.size_hint();
        // हामी पूर्ण रूपमा मान्य वैध surrogates (प्रति चार्ट २ तत्व), वा पूर्ण गैर-surrogates (प्रति चार्ट १ तत्व)
        //
        (low / 2, high)
    }
}

impl DecodeUtf16Error {
    /// अविवाहित surrogate फर्काउँछ जुन यो त्रुटिको कारण भयो।
    #[stable(feature = "decode_utf16", since = "1.9.0")]
    pub fn unpaired_surrogate(&self) -> u16 {
        self.code
    }
}

#[stable(feature = "decode_utf16", since = "1.9.0")]
impl fmt::Display for DecodeUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "unpaired surrogate found: {:x}", self.code)
    }
}