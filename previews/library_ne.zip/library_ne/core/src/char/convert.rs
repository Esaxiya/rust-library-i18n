//! चरित्र रूपान्तरण।

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// `u32` लाई `char` मा बदल्छ।
///
/// नोट गर्नुहोस् कि सबै [`char`] s मान्य [`u32`] s हो, र यसको साथ एकमा कास्ट गर्न सकिन्छ
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// जहाँसम्म, उल्टो सहि हुँदैन: सबै मान्य [`u32`] s मान्य छैन [`Char`] s।
/// `from_u32()` `None` फर्काउँछ यदि इनपुट [`char`] को लागी मान्य मान होईन।
///
/// यस कार्यको असुरक्षित संस्करणको लागि जसले यी जाँचहरूलाई बेवास्ता गर्दछ, हेर्नुहोस् [`from_u32_unchecked`]।
///
///
/// # Examples
///
/// आधारभूत उपयोग:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// `None` फिर्ता गर्दै जब इनपुट मान्य [`char`] छैन:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// `u32` लाई `char` मा बदल्छ, मान्यताको बेवास्ता गर्दै।
///
/// नोट गर्नुहोस् कि सबै [`char`] s मान्य [`u32`] s हो, र यसको साथ एकमा कास्ट गर्न सकिन्छ
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// जहाँसम्म, उल्टो सहि हुँदैन: सबै मान्य [`u32`] s मान्य छैन [`Char`] s।
/// `from_u32_unchecked()` यसलाई बेवास्ता गर्दछ, र अन्धाधुन्ध [`char`] मा कास्ट गर्दछ, एक अवैध एक सिर्जना गर्न।
///
///
/// # Safety
///
/// यो प्रकार्य असुरक्षित छ, किनकि यसले अवैध `char` मानहरू निर्माण गर्न सक्छ।
///
/// यस प्रकार्यको सुरक्षित संस्करणको लागि, [`from_u32`] प्रकार्य हेर्नुहोस्।
///
/// # Examples
///
/// आधारभूत उपयोग:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // सुरक्षा: कलरले `i` को मान्य मान मान ग्यारेन्टी गर्नै पर्छ।
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// [`char`] लाई [`u32`] मा बदल्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// [`char`] लाई [`u64`] मा बदल्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // चार कोड बिन्दुको मानमा कास्ट गरिएको छ, त्यसपछि शून्य-extended 64 बिटमा विस्तार गरियो।
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] हेर्नुहोस्
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// [`char`] लाई [`u128`] मा बदल्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // चार कोड बिन्दुको मानमा कास्ट गरिएको छ, त्यसपछि शून्य-विस्तारित १२8 बिटमा।
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] हेर्नुहोस्
        c as u128
    }
}

/// 0x00 मा बाइट नक्सा .. 0xFF `char` मा जसको कोड पोइन्टको उही मान छ, U + ०००० मा।=U + 00FF।
///
/// युनिकोड यस्तो डिजाईन गरिएको छ कि यसले प्रभावी ढAN्गले बाइट्सलाई क्यारेक्टर सod्केतनसँग डिकोड गर्दछ जुन IANA ले आईएसओ--8585-1-१ कल गर्दछ।
/// यो एन्कोडि AS ASCII का साथ उपयुक्त छ।
///
/// नोट गर्नुहोस् कि यो ISO/IEC 8859-1 उर्फ भन्दा फरक छ
/// आईएसओ 858585-1-१ (एक कम हाइफनको साथ), जसले केहि "blanks" छोड्दछ, बाइट मान जुन कुनै क्यारेक्टरमा तोकिएको छैन।
/// ISO-8859-1 (IANA एक) C0 र C1 नियन्त्रण कोडमा तिनीहरूलाई असाइन गर्दछ।
///
/// नोट गर्नुहोस् कि यो *पनि* विन्डोज-१२२२ उर्फ भन्दा फरक छ
/// कोड पृष्ठ १२2२, जुन सुपरसेट ISO/IEC 88585-1-१ हो जसले विराम चिह्न र विभिन्न ल्याटिन वर्णहरूमा केही (सबै होइन!) खाली स्थानहरू निर्दिष्ट गर्दछ।
///
/// चीजहरूलाई थप भ्रमित गर्न, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1`, र `windows-1252` Windows-1252 को सुपरसेटको लागि सबै उपनामहरू हुन् जुन शेष C0 र C1 नियन्त्रण कोडको साथ बाँकी खाली स्थानहरू भर्छ।
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// [`u8`] लाई [`char`] मा बदल्छ।
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// एउटा त्रुटि जुन चार्ट पार्सिंग गर्दा फर्किन्छ।
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // सुरक्षा: जाँच गरियो कि यो एक कानूनी युनिकोड मान हो
            Ok(unsafe { transmute(i) })
        }
    }
}

/// u32 बाट चारमा रूपान्तरण असफल हुँदा त्रुटि प्रकार फर्कियो।
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// दिइएको अंकलाई `char` मा बदल्छ।
///
/// यहाँ एक 'radix' कहिलेकाँही 'base' पनि भनिन्छ।
/// दुईको एक रेडिक्सले बाइनरी नम्बर, दशको दशमलव, र १teen को हेडसाडेसिमलको रेडिक्स स indicates्केत गर्दछ।
///
/// मनमानी रेडिकलहरू समर्थित छन्।
///
/// `from_digit()` `None` फर्काउँछ यदि इनपुट दिइएको radix मा एक अंक छैन।
///
/// # Panics
///
/// Panics यदि rad 36 भन्दा ठूलो रेडिक्स दिइयो।
///
/// # Examples
///
/// आधारभूत उपयोग:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // दशमलव ११ आधार १ in मा एकल अंक हो
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// फर्कदै `None` जब इनपुट अंक होईन:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// panic पैदा गर्दै, ठूलो रेडिक्स पास गर्दै:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}