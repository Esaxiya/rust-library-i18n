//! Note
//! ----
//! तपाईं सायद यो फाईल हेरिरहनु भएको छ किनकि तपाईंले एक परीक्षण थप्दै हुनुहुन्छ (वा तपाईं केवल ब्राउज गर्दै हुनुहुन्छ, त्यो अवस्थामा, हे त्यहाँ!)।
//!
//! इटेर टेस्ट सुइट दुई ठूला मोड्युलमा विभाजित छ, र केहि विविध साना मोड्युलहरू।दुई ठूला मोड्युलहरू `adapters` र `traits` हुन्।
//!
//! `adapters` `Iterator` मा विधिहरूको लागि हो जुन एट्रेटर भित्र डाटा अनुकूल गर्दछ, यो अर्को इट्रेटर उत्सर्जन गरेर वा प्रत्येक वस्तुमा क्लोजर कार्यान्वयन गरिसकेपछि पुनरावृत्ति भित्रबाट कुनै वस्तु फर्काएर हो।
//!
//!
//! `traits` trait को लागि हो जुन `Iterator` (र `Iterator` trait आफैंमा प्रायः विविध विधिहरू समावेश) विस्तार गर्दछ।
//! अधिकांश भागको लागि, यदि `traits` मा एक परीक्षण एक विशिष्ट एडेप्टर प्रयोग गर्दछ, तब यो `adapters` मा कि एडाप्टरको परीक्षण फाइलमा सर्नु पर्छ।
//!
//!
//!
//!
//!

mod adapters;
mod range;
mod sources;
mod traits;

use core::cell::Cell;
use core::convert::TryFrom;
use core::iter::*;

pub fn is_trusted_len<I: TrustedLen>(_: I) {}

#[test]
fn test_multi_iter() {
    let xs = [1, 2, 3, 4];
    let ys = [4, 3, 2, 1];
    assert!(xs.iter().eq(ys.iter().rev()));
    assert!(xs.iter().lt(xs.iter().skip(2)));
}

#[test]
fn test_counter_from_iter() {
    let it = (0..).step_by(5).take(10);
    let xs: Vec<isize> = FromIterator::from_iter(it);
    assert_eq!(xs, [0, 5, 10, 15, 20, 25, 30, 35, 40, 45]);
}

#[test]
fn test_functor_laws() {
    // identity:
    fn identity<T>(x: T) -> T {
        x
    }
    assert_eq!((0..10).map(identity).sum::<usize>(), (0..10).sum());

    // composition:
    fn f(x: usize) -> usize {
        x + 3
    }
    fn g(x: usize) -> usize {
        x * 2
    }
    fn h(x: usize) -> usize {
        g(f(x))
    }
    assert_eq!((0..10).map(f).map(g).sum::<usize>(), (0..10).map(h).sum());
}

#[test]
fn test_monad_laws_left_identity() {
    fn f(x: usize) -> impl Iterator<Item = usize> {
        (0..10).map(move |y| x * y)
    }
    assert_eq!(once(42).flat_map(f.clone()).sum::<usize>(), f(42).sum());
}

#[test]
fn test_monad_laws_right_identity() {
    assert_eq!((0..10).flat_map(|x| once(x)).sum::<usize>(), (0..10).sum());
}

#[test]
fn test_monad_laws_associativity() {
    fn f(x: usize) -> impl Iterator<Item = usize> {
        0..x
    }
    fn g(x: usize) -> impl Iterator<Item = usize> {
        (0..x).rev()
    }
    assert_eq!(
        (0..10).flat_map(f).flat_map(g).sum::<usize>(),
        (0..10).flat_map(|x| f(x).flat_map(g)).sum::<usize>()
    );
}

#[test]
pub fn extend_for_unit() {
    let mut x = 0;
    {
        let iter = (0..5).map(|_| {
            x += 1;
        });
        ().extend(iter);
    }
    assert_eq!(x, 5);
}