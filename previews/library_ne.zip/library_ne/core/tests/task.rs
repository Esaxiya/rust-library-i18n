use core::task::Poll;

#[test]
fn poll_const() {
    // परीक्षण गर्नुहोस् कि `Poll` का विधिहरू कन्स्ट सन्दर्भमा प्रयोग योग्य छन्

    const POLL: Poll<usize> = Poll::Pending;

    const IS_READY: bool = POLL.is_ready();
    assert!(!IS_READY);

    const IS_PENDING: bool = POLL.is_pending();
    assert!(IS_PENDING);
}