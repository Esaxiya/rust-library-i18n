use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // मिरी एकदम ढिलो छ
fn exact_sanity_test() {
    // यो परिक्षण चलिरहेको समाप्त हुन्छ जुन मैले मात्र लिन सक्छु `exp2` लाइब्रेरी प्रकार्यको केहि कुना-ईश केस हो, जुन हामी प्रयोग गरिरहेको C रनटाइममा परिभाषित हुन्छ।
    // VS २०१ In मा यो प्रकार्यले स्पष्ट रूपमा बग गरेको थियो जब यो परीक्षण लि linked्क भएको बेला असफल हुन्छ, तर VS २०१ with को साथ बग ठीक देखिन्छ किनकि परीक्षण ठीक ठीक चलेको छ।
    //
    // बग `exp2(-1057)` को रिटर्न मूल्यमा भिन्न देखिन्छ, जहाँ VS २०१ in मा यसले बिट पैटर्न 0x2 बाट एक डबल फर्काउँछ र VS २०१ 2015 मा यसले 0x20000 फर्काउँछ।
    //
    //
    // अहिलेको लागि MSVC मा पूर्ण रूपमा यो परीक्षणलाई बेवास्ता गर्नुहोस् किनकि यो जहाँसुकै परिक्षण गरिएको छ र हामी प्रत्येक प्लेटफर्मको exp2 कार्यान्वयनको परीक्षणमा सुपर रुचि राख्दैनौं।
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}