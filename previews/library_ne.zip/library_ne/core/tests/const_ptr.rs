// दुई बाइट्समा प .्क्तिबद्ध
const DATA: [u16; 2] = [u16::from_ne_bytes([0x01, 0x23]), u16::from_ne_bytes([0x45, 0x67])];

const fn unaligned_ptr() -> *const u16 {
    // DATA.as_ptr() दुई बाइट्समा पigned्क्तिबद्ध गरिएकोले, एक बाइट थप्दै कि एक अप्रमाणित * कन्स्ट u16 उत्पादन गर्दछ
    unsafe { (DATA.as_ptr() as *const u8).add(1) as *const u16 }
}

#[test]
fn read() {
    use core::ptr;

    const FOO: i32 = unsafe { ptr::read(&42 as *const i32) };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { ptr::read_unaligned(&42 as *const i32) };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *const u16 = unaligned_ptr();

    const UNALIGNED: u16 = unsafe { ptr::read_unaligned(UNALIGNED_PTR) };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

#[test]
fn const_ptr_read() {
    const FOO: i32 = unsafe { (&42 as *const i32).read() };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { (&42 as *const i32).read_unaligned() };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *const u16 = unaligned_ptr();

    const UNALIGNED: u16 = unsafe { UNALIGNED_PTR.read_unaligned() };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

#[test]
fn mut_ptr_read() {
    const FOO: i32 = unsafe { (&42 as *const i32 as *mut i32).read() };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { (&42 as *const i32 as *mut i32).read_unaligned() };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *mut u16 = unaligned_ptr() as *mut u16;

    const UNALIGNED: u16 = unsafe { UNALIGNED_PTR.read_unaligned() };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

// #[test]
// fn write() {core::ptr प्रयोग गर्नुहोस्;
//
//    कन्स्ट fn write_aligned()-> i32 mut म्यूट रेस=0 दिनुहोस्;
//        असुरक्षित {
//            ptr::write(&mut res as *mut _, 42);
//        }
//        res} const ALIGNED: i32 = write_aligned();
//    assert_eq! (ALIGNED,)२);
//
//    कन्स्ट fn write_unaligned()-> [u16; 2] mut म्युट two_aligned= [0u16; 2];
//        असुरक्षित {unalign_ptr= (two_aligned.as_mut_ptr() लाई *mut u8).add(1)* mut u16 को रूपमा दिनुहोस्;
//            ptr: : write_unaligned (unalign_ptr, u16::from_ne_bytes([0x23, 0x45]));} two_align} const UNALIGNED: [u16; 2] = write_unaligned();
//
//    assert_eq! (UNALIGNED, [u16::from_ne_bytes([0x00, 0x23]), u16::from_ne_bytes([0x45, 0x00])]);
//
//
//
//
//
//
//
//
//
//

// #[test]
// fn mut_ptr_write() {const fn aligned()-> i32 mut म्युट रेस=0;
//        असुरक्षित { (&mut res as *mut i32).write(42); } रेस-कन्टस्ट ALIGNED: i32 = aligned();
//
//    assert_eq! (ALIGNED,)२);
//
//    कन्स्ट fn write_unaligned()-> [u16; 2] mut म्युट two_aligned= [0u16; 2];
//        असुरक्षित {unalign_ptr= (two_aligned.as_mut_ptr() लाई *mut u8).add(1)* mut u16 को रूपमा दिनुहोस्;
//            unaligned_ptr.write_unaligned(u16::from_ne_bytes([0x23, 0x45]));
//        }
//        two_aligned} const UNALIGNED: [u16; 2] = write_unaligned();
//    assert_eq! (UNALIGNED, [u16::from_ne_bytes([0x00, 0x23]), u16::from_ne_bytes([0x45, 0x00])]);
//
//
//
//
//
//
//
//
//
//
//