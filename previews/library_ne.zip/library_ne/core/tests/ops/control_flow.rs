use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // यो स्थिर सतह क्षेत्र होईन, तर तिनीहरूको बीचमा `?` सस्तो राख्न मद्दत गर्दछ, यदि LLVM ले सँधै अहिले यसको फाइदा लिन सक्दैन।
    //
    // (दुःखको कुरा परिणाम र विकल्प असंगत छन्, त्यसैले कन्ट्रोलफ्लो दुबैसँग मेल खाँदैन।)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}