#![feature(no_core)]
#![no_core]

// rustc-std-workpace-core हेर्नुहोस् किन यो crate को आवश्यकता छ।

// crate नाम बदल्नुहोस् liballoc मा विनियोजन मोड्युलसँग विवादास्पद हुनबाट जोगिन।
extern crate alloc as foo;

pub use foo::*;