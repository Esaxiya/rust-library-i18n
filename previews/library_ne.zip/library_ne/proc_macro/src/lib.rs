//! म्याक्रो लेखकहरूको लागि समर्थन लाइब्रेरी जब नयाँ म्याक्रो परिभाषित गर्दछ।
//!
//! यो पुस्तकालय, मानक वितरण द्वारा प्रदान गरीएको प्रकार्य-जस्तै म्याक्रो `#[proc_macro]`, म्याक्रो विशेषताहरू `#[proc_macro_attribute]` र अनुकूलित व्युत्पन्न विशेषताहरू##[proc_macro_derive] as जस्ता प्रक्रियात्मक रूपमा परिभाषित म्याक्रो परिभाषाहरूको इन्टरफेसमा उपभोग गरिएका प्रकारहरू प्रदान गर्दछ।
//!
//!
//! अधिकको लागि [the book] हेर्नुहोस्।
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// वर्तमानमा चलिरहेको कार्यक्रममा प्रो_म्याक्रो सुलभ गरिएको छ वा छैन निर्धारण गर्दछ।
///
/// Proc_macro crate मात्र प्रक्रियात्मक म्याक्रोको कार्यान्वयनको भित्र प्रयोगको लागि मात्र हो।यस crate panic मा सबै प्रकार्यहरू यदि प्रक्रियात्मक म्याक्रोको बाहिरबाट अनुरोध गरिएको छ, जस्तै बिल्ड स्क्रिप्ट वा एकाई परीक्षण वा साधारण Rust बाइनरीबाट।
///
/// Rust लाइब्रेरीहरूको विचारका लागि जुन दुबै म्याक्रो र गैर-म्याक्रो प्रयोगका केसहरूलाई समर्थन गर्न डिजाइन गरिएको छ, `proc_macro::is_available()` ले एक गैर-पनकिking मार्ग प्रदान गर्दछ कि यदि प्रोक_मैक्रोको एपीआई प्रयोग गर्न आवश्यक पूर्वाधार हाल उपलब्ध छ कि छैन भनेर पत्ता लगाउन।
/// यदि प्रक्रियात्मक म्याक्रोको भित्रबाट बोलाइएको खण्डमा फर्काउँछ, गलत यदि कुनै अन्य बाइनरीबाट आमन्त्रित गरियो भने।
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// मुख्य प्रकार यो crate द्वारा प्रदान गरिएको, tokens को अमूर्त स्ट्रिम प्रतिनिधित्व गर्दछ, वा अधिक विशेष रूपमा token रूखहरूको अनुक्रम।
/// प्रकारले ती token रूखहरूमा पुनरावृत्तिको लागि ईन्टरफेस प्रदान गर्दछ र, विपरित रूपमा, token रूखहरूको एक धारामा संकलन गर्दछ।
///
///
/// यो दुबै इनपुट र `#[proc_macro]`, `#[proc_macro_attribute]` र `#[proc_macro_derive]` परिभाषाको आउटपुट हो।
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// `TokenStream::from_str` बाट त्रुटि फिर्ता भयो।
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// token रूख नभएको खाली `TokenStream` फर्काउँछ।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// जाँच गर्दछ कि यो `TokenStream` खाली छ।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// स्ट्रिंग tokens मा तोड्ने प्रयास गर्नुहोस् र tokens लाई token स्ट्रिममा पार्स गर्नुहोस्।
/// धेरै कारणका लागि असफल हुन सक्छ, उदाहरणका लागि, यदि स्ट्रिंगमा असन्तुलित डेलिमिटरहरू वा भाषामा अवस्थित वर्णहरू समावेश छन् भने।
///
/// पार्स गरिएको स्ट्रिममा सबै tokens ले `Span::call_site()` स्प्यानहरू प्राप्त गर्दछ।
///
/// NOTE: केहि त्रुटिहरूले `LexError` फिर्ताको सट्टा panics निम्त्याउन सक्छ।हामी यी त्रुटिहरू पछि `LexError`s मा परिवर्तन गर्ने अधिकार आरक्षित गर्दछौं।
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, ब्रिजले मात्र `to_string` प्रदान गर्दछ, `fmt::Display` कार्यान्वयन गर्नुहोस् यसमा आधारित (दुई बीचको सामान्य सम्बन्धको उल्टो)।
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// token स्ट्रीमलाई स्ट्रिंगको रूपमा मुद्रण गर्दछ जुन समान token स्ट्रीम (मोडुलो स्प्यान) मा हानिरहित रूपले रूपान्तरण हुन सक्ने मानिन्छ, सम्भवतः 00 टोकनट्री: : समूह X को `Delimiter::None` डेलिमिटरहरू र नकारात्मक संख्यात्मक लिटरेलहरू बाहेक।
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// डिबगि forका लागि सुविधाजनक फाराममा token प्रिन्ट गर्दछ।
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// token एक स्ट्रिम सिर्जना गर्दछ जसले एकल token रूख समावेश गर्दछ।
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// token रूखहरूको एकल स्ट्रिममा सlects्कलन गर्दछ।
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// token स्ट्रिमहरूमा एउटा "flattening" अपरेशन, token रूखहरूलाई बहु token स्ट्रिमहरूमा एकल स्ट्रीममा सlects्कलन गर्दछ।
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) एक अनुकूलित कार्यान्वयन if/when सम्भव प्रयोग गर्नुहोस्।
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// `TokenStream` प्रकारको लागि सार्वजनिक कार्यान्वयन विवरणहरू, जस्तै इटरेटरहरू।
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Ite टोकनस्ट्रीम`को en टोकनट्री` मा एक इटरेटर
    /// पुनरावृत्ति "shallow" हो, उदाहरणका लागि, पुनरावृत्तिकै सीमित समूहहरूमा दोहोरिने छैन, र सम्पूर्ण समूहहरूलाई token रूखहरूको रूपमा फर्काउँछ।
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` मनमाना tokens स्वीकार गर्दछ र इनपुट वर्णन `TokenStream` मा विस्तार गर्दछ।
/// उदाहरणको लागि, `quote!(a + b)` ले एक अभिव्यक्ति उत्पादन गर्दछ, कि जब मूल्या when्कन हुन्छ, `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Unquoting `$` को साथ गरिन्छ, र एकल अर्को आईडी unquotated टर्मको रूपमा लिएर काम गर्दछ।
/// `$` नै उद्धृत गर्न, `$$` प्रयोग गर्नुहोस्।
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// स्रोत कोडको क्षेत्र, म्याक्रो विस्तार जानकारीको साथ।
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Span `self` मा दिइएको `message` को साथ एक नयाँ `Diagnostic` सिर्जना गर्दछ।
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// म्याक्रो परिभाषा साइटमा समाधान गर्ने स्प्यान।
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// वर्तमान प्रक्रियात्मक म्याक्रोको आमन्त्रनको अवधि।
    /// यस स्पानको साथ सिर्जना गरिएका पहिचानकर्ताहरू समाधान हुनेछन् यदि तिनीहरू म्याक्रो कल स्थान (कल-साइट स्वच्छता) मा सिधा लेखिएका थिए र म्याक्रो कल साइटमा अन्य कोडले उनीहरूलाई सन्दर्भ गर्न पनि सक्षम हुनेछ।
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// एक स्प्यान जसले `macro_rules` हाइजीन प्रतिनिधित्व गर्दछ, र कहिलेकाँही म्याक्रो परिभाषा साइट (स्थानीय भ्यारीएबलहरू, लेबलहरू, `$crate`) मा समाधान गर्दछ र कहिलेकाँही म्याक्रो कल साइट (सबै कुरा)।
    ///
    /// स्पान स्थान कल-साइटबाट लिइएको हो।
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// मौलिक स्रोत फाइल जुन यस स्प्यानले पोइन्ट गर्दछ।
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// tokens का लागि `Span` अघिल्लो म्याक्रो विस्तारमा जुन `self` बाट उत्पन्न भएको थियो, यदि कुनै छ भने।
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// `self` उत्पन्न भएको मूल स्रोत कोडका लागि स्प्यान।
    /// यदि यो `Span` अन्य म्याक्रो विस्तारबाट उत्पन्न गरिएको थिएन भने फिर्ताको मान `*self` जस्तै छ।
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// यस स्प्यानको लागि स्रोत फाईलमा सुरूवात line/column हुन्छ।
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// यस स्प्यानको लागि स्रोत फाईलमा अन्त्य हुने line/column हुन्छ।
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// `self` र `other` समाहित गर्दै नयाँ स्पान सिर्जना गर्दछ।
    ///
    /// `None` फर्काउँदछ यदि `self` र `other` विभिन्न फाईलहरूबाट हुन्।
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// `self` को रूपमा उही line/column जानकारीको साथ नयाँ स्पान सिर्जना गर्दछ तर त्यसले प्रतीकहरू समाधान गर्दछ जस्तो कि यो `other` मा भए जस्तो छ।
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// `self` को रूप मा उही नाम रिजोलुसन व्यवहारको साथ तर `other` को line/column जानकारीको साथ एक नयाँ स्पान सिर्जना गर्दछ।
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// स्पानहरूसँग तुलना गर्नुहोस् यदि तिनीहरू बराबर छन् भने।
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Span पछि स्रोत पाठ फर्काउँछ।
    /// यसले खाली मूल स्रोत कोड सुरक्षित गर्दछ, खाली ठाउँ र टिप्पणीहरू सहित।
    /// यो मात्र परिणाम फिर्ता गर्छ यदि स्प्यान वास्तविक स्रोत कोडसँग मेल खान्छ।
    ///
    /// Note: म्याक्रोको अवलोकन योग्य परिणाम केवल tokens मा निर्भर गर्दछ र यो स्रोत पाठमा होइन।
    ///
    /// यस प्रकार्यको नतिजा निदानको लागि मात्र प्रयोग गर्न को लागी एक उत्तम प्रयास हो।
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// डिबगिंगका लागि सुविधाजनक फारममा स्प्यान प्रिन्ट गर्दछ।
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// एक लाइन-स्तम्भ जोडी `Span` को शुरू वा अन्त प्रतिनिधित्व गर्दछ।
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// स्रोत फाईलमा १ अनुक्रमित लाइन जसमा स्पान सुरु हुन्छ वा (inclusive) समाप्त हुन्छ।
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// ०-अनुक्रमित स्तम्भ (UTF-8 वर्णहरूमा) स्रोत फाईलमा जसमा स्पान सुरु हुन्छ वा (inclusive) समाप्त हुन्छ।
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// दिइएको `Span` को स्रोत फाइल।
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// यस स्रोत फाईलमा पथ प्राप्त गर्दछ।
    ///
    /// ### Note
    /// यदि यो `SourceFile` सँग सम्बन्धित कोड स्प्यान बाह्य म्याक्रो, यो म्याक्रो द्वारा उत्पन्न गरिएको हो भने, यो फाइल प्रणालीमा वास्तविक पथ नहुन सक्छ।
    /// जाँच गर्न [`is_real`] प्रयोग गर्नुहोस्।
    ///
    /// यो पनि नोट गर्नुहोस् कि यदि `is_real` ले `true` पनि फिर्ता गर्छ भने, यदि `--remap-path-prefix` कमान्ड लाइनमा पारित गरिएको थियो भने दिइएको पथ वास्तवमा मान्य नहुन सक्छ।
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// `true` फर्काउँछ यदि यो स्रोत फाईल वास्तविक स्रोत फाईल हो, र बाह्य म्याक्रोको विस्तारले उत्पन्न गर्दैन।
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // यो एक ह्याक हो जब सम्म इन्टररेट स्प्यानहरू कार्यान्वयन हुँदैन र हामीसँग बाह्य म्याक्रोमा उत्पन्न स्प्यानहरूको लागि वास्तविक स्रोत फाईलहरू हुन सक्दछन्।
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// एकल token वा token रूखहरूको एक सीमांकित अनुक्रम (उदाहरण, `[1, (), ..]`)।
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// एक token स्ट्रिम कोष्ठक डेलिमिटरहरू द्वारा घेरिएको।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// एक पहिचानकर्ता
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// एकल विराम चिह्न (`+`, `,`, `$`, आदि)।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// शाब्दिक चरित्र (`'a'`), स्ट्रि X (`"hello"`), संख्या (`2.3`), आदि।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// यस रूखको span फर्काउँछ, निहित token वा एक सीमांकित स्ट्रिमको `span` विधिमा प्रत्यायोजन गर्दै।
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// स्पान *केवल यो token* को लागि कन्फिगर गर्दछ।
    ///
    /// नोट गर्नुहोस् कि यदि यो token `Group` हो भने यस विधिले प्रत्येक आन्तरिक tokens को स्पान कन्फिगर गर्दैन, यसले प्रत्येक संस्करणको `set_span` विधिलाई प्रतिनिधित्व गर्दछ।
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// डिबगिंगका लागि सुविधाजनक फाराममा token रूख प्रिन्ट गर्दछ।
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // यी मध्ये प्रत्येकको व्युत्पन्न डिबगमा स्ट्रिक प्रकारमा नाम छ, त्यसैले इण्डिरेक्शनको अतिरिक्त तहको साथ चिन्ता नगर्नुहोस्।
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, ब्रिजले मात्र `to_string` प्रदान गर्दछ, `fmt::Display` कार्यान्वयन गर्नुहोस् यसमा आधारित (दुई बीचको सामान्य सम्बन्धको उल्टो)।
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// token रूखलाई स्ट्रि asको रूपमा मुद्रण गर्दछ जुन समान token ट्री (मोडुलो स्प्यान) मा हानिरहित रूपले रूपान्तरण हुन सक्ने मानिन्छ, सम्भवतः `टोकनट्री: : समूह X को `Delimiter::None` डेलिमिटरहरू र नकारात्मक संख्यात्मक लिटरलहरू बाहेक।
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// एक सीमित token स्ट्रीम।
///
/// एक `Group` आन्तरिक एक `TokenStream` समावेश गर्दछ जुन surrounded Delimiter`s द्वारा घेरिएको छ।
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// token रूखहरूको अनुक्रम कसरी सीमा del्करित हुन्छ वर्णन गर्दछ।
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// एक अंतर्निहित डिलिमिटर, उदाहरणका लागि, tokens वरिपरि "macro variable" `$var` बाट आउन सक्छ।
    /// `$var * 3` जहाँ `$var` `1 + 2` हो त्यस्ता केसहरूमा अपरेटर प्राथमिकताहरू सुरक्षित गर्नु महत्त्वपूर्ण छ।
    /// निहित डेलिमिटरहरू token स्ट्रिमको राउन्डट्रिपमा बाँच्न सक्दैनन्।
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// दिइएको डेलिमिटर र token स्ट्रिमको साथ नयाँ `Group` सिर्जना गर्दछ।
    ///
    /// यो कन्स्ट्रक्टरले `Span::call_site()` मा यस समूहको लागि स्प्यान सेट गर्दछ।
    /// स्पान परिवर्तन गर्न तपाईं तल `set_span` विधि प्रयोग गर्न सक्नुहुनेछ।
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// यस `Group` को डेलिमिटर फर्काउँछ
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// tokens को `TokenStream` फर्काउँछ जुन यस `Group` मा सीमित छ।
    ///
    /// याद गर्नुहोस् कि फर्काइएको token स्ट्रिममा माथि फर्केका डिलिमिटर समावेश छैन।
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// सम्पूर्ण 0to0 स्ट्रीमको डेलिमिटरहरूको लागि स्प्यान फर्काउँछ, सम्पूर्ण `Group` फैलाएर।
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// यस समूहको उद्घाटन डेलिमिटरमा देखाउँदै स्प्यान फिर्ता गर्दछ।
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// यस समूहको क्लोजिंग डेलिमिटरमा देखाउँदै स्प्यान फिर्ता गर्दछ।
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// यस `ग्रुप` डेलिमिटरहरूको लागि स्प्यान कन्फिगर गर्दछ, तर यसको आन्तरिक tokens होइन।
    ///
    /// यस विधिले **होइन** यो समूह द्वारा फैलाइएको सबै आन्तरिक tokens को अवधि सेट गर्दछ, तर यसले XMLX को स्तरमा डिलिमिटर tokens को स्प्यान मात्र सेट गर्दछ।
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, ब्रिजले मात्र `to_string` प्रदान गर्दछ, `fmt::Display` कार्यान्वयन गर्नुहोस् यसमा आधारित (दुई बीचको सामान्य सम्बन्धको उल्टो)।
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// समूहलाई स्ट्रि asको रूपमा प्रिन्ट गर्दछ जुन हानिविहीन रूपमा फेरि समान समूह (मोडुलो स्प्यान) मा रूपान्तरण योग्य हुनुपर्दछ, सम्भाव्य रूपमा `टोकनट्री: : समूह XsX डेलिमिटरहरूको साथ बाहेक।
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// एक `Punct` एकल विराम चिह्नहरू जस्तै `+`, `-` वा `#` हो।
///
/// `+=` जस्तो बहु-चरित्र अपरेटरहरू `Punct` का दुई उदाहरणहरूको रूपमा प्रस्तुत गरिन्छ `Spacing` का बिभिन्न फार्महरू सहित।
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// एक `Punct` तुरून्त अर्को `Punct` द्वारा अनुसरण गरीएको छ वा अर्को token वा वाइटस्पेस द्वारा पछ्याएको।
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// उदाहरणको लागि, `+` `Alone` `+ =`, `+ident` वा `+()` मा हो।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// उदाहरणको लागि, `+` `Joint` `+=` वा `'#` मा हो।
    /// थप रूपमा, एकल उद्धरण `'` परिचयकर्ताहरूको साथ आजीवन `'ident` गठन गर्न सक्दछ।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// दिइएको चरित्र र स्पेसि fromबाट नयाँ `Punct` सिर्जना गर्दछ।
    /// `ch` आर्गुमेन्ट भाषा द्वारा अनुमति दिइएको एक वैध विराम चिह्न हुनुपर्दछ, अन्यथा प्रकार्य panic हुनेछ।
    ///
    /// फिर्ता `Punct` सँग `Span::call_site()` को पूर्वनिर्धारित स्पान हुनेछ जुन तल तल `set_span` विधिसँग कन्फिगर गर्न सकिन्छ।
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// यो विराम चिह्नको मान `char` को रूपमा फर्काउँछ।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// यो विराम चिह्नको स्पेसिंग फर्काउँछ, token स्ट्रिममा अर्को `Punct` द्वारा तुरून्त पछ्याइएको हो कि भनेर दर्साउँदछ, त्यसैले तिनीहरू सम्भावित रूपमा बहु-चरित्र अपरेटर (`Joint`) मा मिलाउन सकिन्छ, वा यो पछि अरू token वा व्हाइटस्पेस (`Alone`) पछ्याईन्छ समाप्त भयो।
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// यस विराम चिह्नका लागि स्प्यान फर्काउँछ।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// यस विराम चिह्नका लागि स्प्यान कन्फिगर गर्नुहोस्।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, ब्रिजले मात्र `to_string` प्रदान गर्दछ, `fmt::Display` कार्यान्वयन गर्नुहोस् यसमा आधारित (दुई बीचको सामान्य सम्बन्धको उल्टो)।
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// विराम चिह्नलाई स्ट्रि asको रूपमा प्रिन्ट गर्दछ जुन दोषरहित बिहीन पछाडि उही वर्णमा परिवर्तन हुनुपर्दछ।
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// एक पहिचानकर्ता (`ident`)।
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// दिइएको `string` साथै निर्दिष्ट `span` को साथ एक नयाँ `Ident` सिर्जना गर्दछ।
    /// `string` आर्गुमेन्ट भाषा द्वारा अनुमति दिइएको एक वैध पहिचानकर्ता हुनुपर्दछ (खोजशब्दहरू सहित, उदाहरणका लागि `self` वा `fn`)।अन्यथा, समारोह panic हुनेछ।
    ///
    /// नोट गर्नुहोस् कि `span`, हाल rustc मा, यस पहिचानकर्ताको लागि स्वच्छता जानकारी कन्फिगर गर्दछ।
    ///
    /// यस समयको रूपमा `Span::call_site()` स्पष्ट रूपमा "call-site" हाइजीन अप्ट इन गर्दछ यसको अर्थ यो स्प्यानको साथ सिर्जना गरिएको पहिचानकर्ताहरू समाधान हुनेछन् जस्तो कि तिनीहरू म्याक्रो कलको स्थानमा सिधा लेखिएका थिए, र म्याक्रो कल साइटमा अन्य कोड सन्दर्भ गर्न सक्षम हुनेछ। तिनीहरूलाई पनि।
    ///
    ///
    /// पछि `Span::def_site()` जस्तो स्पानहरूले "definition-site" हाइजीन अप्ट-इन गर्न अनुमति दिनेछ यसको अर्थ यो स्पानको साथ सिर्जना गरिएको पहिचानकर्ताहरू म्याक्रो परिभाषाको स्थानमा समाधान हुनेछन् र म्याक्रो कल साइटमा अन्य कोडले तिनीहरूलाई सन्दर्भ गर्न सक्षम हुनेछैन।
    ///
    /// हालको स्वच्छताको महत्त्वको कारण यस कन्स्ट्रक्टरले अन्य tokens भन्दा फरक, निर्माणमा `Span` तोक्न आवश्यक छ।
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// `Ident::new` जस्तै, तर एक कच्चा परिचयकर्ता (`r#ident`) सिर्जना गर्दछ।
    /// `string` आर्गुमेन्ट भाषा द्वारा अनुमति दिइएको एक वैध पहिचानकर्ता हुन सक्दछ (कुञ्जी शब्दहरू सहित, उदाहरणका लागि `fn`)।
    /// कुञ्जी शव्दहरू जुन पथ क्षेत्रहरूमा प्रयोग योग्य छन् (उदाहरण:
    /// `self`, `सुपर`) समर्थित छैन, र panic पैदा गर्दछ।
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// [`to_string`](Self::to_string) द्वारा फर्केका सम्पूर्ण स्ट्रिंग समेट्दै,`Ident` 1X को अवधि फर्काउँछ।
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// यो `Ident` को अवधि कन्फिगर गर्दछ, सम्भवत: यसको स्वच्छता सन्दर्भ परिवर्तन गर्दै।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, ब्रिजले मात्र `to_string` प्रदान गर्दछ, `fmt::Display` कार्यान्वयन गर्नुहोस् यसमा आधारित (दुई बीचको सामान्य सम्बन्धको उल्टो)।
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// परिचयकर्तालाई स्ट्रिंगको रूपमा प्रिन्ट गर्दछ जुन दोषविहीन हुन उही परिचयकर्तामा फर्किनु पर्छ।
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// शाब्दिक स्ट्रि X (`"hello"`), बाइट स्ट्रि X (`b"hello"`), क्यारेक्टर (`'a'`), बाइट क्यारेक्टर (`b'a'`), पूर्णांक वा फ्लोटिंग पोइन्ट संख्याको साथ वा बिना प्रत्यय (`१`, `1u8`, `2.3`, `2.3f32`)।
///
/// `true` र `false` जस्ता बुलियन अक्षरहरू यहाँ पर्दैन, तिनीहरू `Ident`s हुन्।
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// निर्दिष्ट मानको साथ नयाँ प्रत्यय पूर्णांक संख्यात्मक सिर्जना गर्दछ।
        ///
        /// यो प्रकार्यले `1u32` जस्तो पूर्णा .्क सिर्जना गर्दछ जहाँ निर्दिष्ट गरिएको पूर्णांक मान token को पहिलो भाग हुन्छ र अभिन्न पनि अन्त्यमा प्रत्यय हुन्छ।
        /// नकारात्मक संख्याबाट सिर्जना गरिएको लिट्रलहरू `TokenStream` वा तारहरू मार्फत राउन्ड-ट्रिपहरू बाँच्न सक्दैन र दुई tokens (`-` र सकारात्मक शाब्दिक) मा भाँच्न सकिन्छ।
        ///
        ///
        /// यस विधि मार्फत सिर्जना गरिएको लिटलहरूसँग `Span::call_site()` स्पान पूर्वनिर्धारित हुन्छ, जुन तल `set_span` विधिद्वारा कन्फिगर गर्न सकिन्छ।
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// निर्दिष्ट मानको साथ एक नयाँ असम्बद्ध पूर्णांक शाब्दिक सिर्जना गर्दछ।
        ///
        /// यो प्रकार्यले `1` जस्तो पूर्णा .्ख्या सिर्जना गर्दछ जहाँ निर्दिष्ट गरिएको पूर्णांक मान token को पहिलो भाग हो।
        /// यस token मा कुनै प्रत्यय निर्दिष्ट गरिएको छैन, यसको मतलब `Literal::i8_unsuffixed(1)` जस्ता आमन्त्रणहरू `Literal::u32_unsuffixed(1)` बराबर छन्।
        /// नकारात्मक संख्याबाट सिर्जना गरिएको लिटरलहरू `TokenStream` वा तारहरू मार्फत रोन्ट्रिप्सबाट बच्न सक्दछन् र दुई tokens (`-` र सकारात्मक शाब्दिक) मा विभाजित हुन सक्छन्।
        ///
        ///
        /// यस विधि मार्फत सिर्जना गरिएको लिटलहरूसँग `Span::call_site()` स्पान पूर्वनिर्धारित हुन्छ, जुन तल `set_span` विधिद्वारा कन्फिगर गर्न सकिन्छ।
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// एक नयाँ असफल फ्लोटिंग पोइन्ट शाब्दिक बनाउँछ।
    ///
    /// यो कन्स्ट्रक्टर `Literal::i8_unsuffixed` जस्तै छ जहाँ फ्लोटको मान सीधा token मा उत्सर्जित हुन्छ तर कुनै प्रत्यय प्रयोग गरिएको छैन, त्यसैले यो कम्पाइलरमा पछि `f64` हुन सकेन।
    ///
    /// नकारात्मक संख्याबाट सिर्जना गरिएको लिटरलहरू `TokenStream` वा तारहरू मार्फत रोन्ट्रिप्सबाट बच्न सक्दछन् र दुई tokens (`-` र सकारात्मक शाब्दिक) मा विभाजित हुन सक्छन्।
    ///
    /// # Panics
    ///
    /// यस प्रकार्यका लागि निर्दिष्ट फ्लोट सीमित छ, उदाहरणका लागि यदि यो अनन्त हो वा NaN यस प्रकार्य panic हुनेछ।
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// नयाँ प्रत्यय फ्लोटिंग-पोइन्ट शाब्दिक बनाउँछ।
    ///
    /// यो कन्स्ट्रक्टरले `1.0f32` जस्तो शाब्दिक सिर्जना गर्दछ जहाँ निर्दिष्ट गरिएको मान token को पूर्ववर्ती भाग हो र `f32` token को प्रत्यय हो।
    /// यो token सँधै संकलकमा `f32` हुन अनुमान गरिन्छ।
    /// नकारात्मक संख्याबाट सिर्जना गरिएको लिटरलहरू `TokenStream` वा तारहरू मार्फत रोन्ट्रिप्सबाट बच्न सक्दछन् र दुई tokens (`-` र सकारात्मक शाब्दिक) मा विभाजित हुन सक्छन्।
    ///
    ///
    /// # Panics
    ///
    /// यस प्रकार्यका लागि निर्दिष्ट फ्लोट सीमित छ, उदाहरणका लागि यदि यो अनन्त हो वा NaN यस प्रकार्य panic हुनेछ।
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// एक नयाँ असफल फ्लोटिंग पोइन्ट शाब्दिक बनाउँछ।
    ///
    /// यो कन्स्ट्रक्टर `Literal::i8_unsuffixed` जस्तै छ जहाँ फ्लोटको मान सीधा token मा उत्सर्जित हुन्छ तर कुनै प्रत्यय प्रयोग गरिएको छैन, त्यसैले यो कम्पाइलरमा पछि `f64` हुन सकेन।
    ///
    /// नकारात्मक संख्याबाट सिर्जना गरिएको लिटरलहरू `TokenStream` वा तारहरू मार्फत रोन्ट्रिप्सबाट बच्न सक्दछन् र दुई tokens (`-` र सकारात्मक शाब्दिक) मा विभाजित हुन सक्छन्।
    ///
    /// # Panics
    ///
    /// यस प्रकार्यका लागि निर्दिष्ट फ्लोट सीमित छ, उदाहरणका लागि यदि यो अनन्त हो वा NaN यस प्रकार्य panic हुनेछ।
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// नयाँ प्रत्यय फ्लोटिंग-पोइन्ट शाब्दिक बनाउँछ।
    ///
    /// यो कन्स्ट्रक्टरले `1.0f64` जस्तो शाब्दिक सिर्जना गर्दछ जहाँ निर्दिष्ट गरिएको मान token को पूर्ववर्ती भाग हो र `f64` token को प्रत्यय हो।
    /// यो token सँधै संकलकमा `f64` हुन अनुमान गरिन्छ।
    /// नकारात्मक संख्याबाट सिर्जना गरिएको लिटरलहरू `TokenStream` वा तारहरू मार्फत रोन्ट्रिप्सबाट बच्न सक्दछन् र दुई tokens (`-` र सकारात्मक शाब्दिक) मा विभाजित हुन सक्छन्।
    ///
    ///
    /// # Panics
    ///
    /// यस प्रकार्यका लागि निर्दिष्ट फ्लोट सीमित छ, उदाहरणका लागि यदि यो अनन्त हो वा NaN यस प्रकार्य panic हुनेछ।
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// अक्षरशः
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// चरित्र शाब्दिक।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// बाइट स्ट्रि lite शाब्दिक।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// यस शाब्दिक समाहित स्प्यान फिर्ता गर्दछ।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// यो शाब्दिकको लागि सम्बन्धित स्प्यान कन्फिगर गर्दछ।
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// `Span` फर्काउँछ जुन दायरा `range` मा केवल स्रोत बाइटहरू भएको `self.span()` को उपसेट हो।
    /// `None` फर्काउँछ यदि-ट्रिम्ड स्पान `self` को सीमा बाहिर छ भने।
    ///
    // FIXME(SergioBenitez): जाँच गर्नुहोस् कि बाइट दायरा सुरु हुन्छ र स्रोतको UTF-8 सीमा मा समाप्त हुन्छ।
    // अन्यथा, यस्तो सम्भावना छ कि panic अन्य ठाउँमा देखा पर्नेछ जब स्रोत पाठ मुद्रित हुन्छ।
    // FIXME(SergioBenitez): त्यहाँ प्रयोगकर्तालाई थाहा छैन कि `self.span()` वास्तवमा केमा नक्सा गर्दछ जान्नका लागि कुनै तरिका छैन, त्यसैले यो विधिलाई हाल केवल अन्धाधुन्ध भनिन्छ।
    // उदाहरणको लागि, 'c' क्यारेक्टर `to_string()` को लागी "'\u{63}'" फर्काउँछ;त्यहाँ प्रयोगकर्तालाई थाहा पाउन कुनै तरिका छैन कि स्रोत पाठ 'c' वा यो '\u{63}' हो कि थिएन।
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) केहि `Option::cloned` जस्तै, तर `Bound<&T>` को लागी।
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, ब्रिजले मात्र `to_string` प्रदान गर्दछ, `fmt::Display` कार्यान्वयन गर्नुहोस् यसमा आधारित (दुई बीचको सामान्य सम्बन्धको उल्टो)।
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// साच्चिकै स्ट्रि asको रूपमा प्रिन्ट गर्दछ जुन दोषरहित फेर्नुपर्दछ फर्केर समान शाब्दिकमा (फ्लोटिंग पोइन्ट लिटरलको लागि सम्भावित गोलको लागि बाहेक)।
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// वातावरण चलहरूमा ट्र्याक गरिएको पहुँच।
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// वातावरण चर पुन: प्राप्त गर्नुहोस् र निर्भरता जानकारी निर्माण गर्न यसलाई जोड्नुहोस्।
    /// कम्पाइलर एक्जिक्युट गर्ने बिल्ड प्रणालीले थाहा पाउनेछ कि कम्पाइलेशनको बेला चल पनी पहुँच गरिएको थियो, र बिल्ड पुन: चलाउन सक्नेछ जब त्यो भेरिएबलको मान परिवर्तन हुन्छ।
    ///
    /// निर्भरता ट्र्याकि। बाहेक यो प्रकार्य मानक लाइब्रेरीबाट `env::var` बराबर हुनुपर्दछ, बाहेक यो तर्क UTF-8 हुनु पर्छ।
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}