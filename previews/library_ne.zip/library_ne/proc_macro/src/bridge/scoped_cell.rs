//! `Cell` (scoped) अस्तित्वत्मक लाइफटाइमका लागि संस्करण।

use std::cell::Cell;
use std::mem;
use std::ops::{Deref, DerefMut};

/// जीवनभरको साथ लम्बडा अनुप्रयोग टाइप गर्नुहोस्।
#[allow(unused_lifetimes)]
pub trait ApplyL<'a> {
    type Out;
}

/// प्रकार लाइम्बडा एक जीवनभर ले, अर्थात्, `Lifetime -> Type`.
pub trait LambdaL: for<'a> ApplyL<'a> {}

impl<T: for<'a> ApplyL<'a>> LambdaL for T {}

// HACK(eddyb) newtype FIXME(#52812) `&'a mut <T as ApplyL<'b>>::Out` सँग प्रतिस्थापनको साथ प्रक्षेपण सीमाको वरपर काम गर्नुहोस्
//
pub struct RefMutL<'a, 'b, T: LambdaL>(&'a mut <T as ApplyL<'b>>::Out);

impl<'a, 'b, T: LambdaL> Deref for RefMutL<'a, 'b, T> {
    type Target = <T as ApplyL<'b>>::Out;
    fn deref(&self) -> &Self::Target {
        self.0
    }
}

impl<'a, 'b, T: LambdaL> DerefMut for RefMutL<'a, 'b, T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.0
    }
}

pub struct ScopedCell<T: LambdaL>(Cell<<T as ApplyL<'static>>::Out>);

impl<T: LambdaL> ScopedCell<T> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new(value: <T as ApplyL<'static>>::Out) -> Self {
        ScopedCell(Cell::new(value))
    }

    /// `self` मा `replacement` मा मान सेट गर्दछ `f` चालु गर्दा, जुन पुरानो मान प्राप्त गर्दछ, परस्पर रूपले।
    /// पुरानो मान `f` बन्द भएपछि पुनर्स्थापना हुनेछ, panic द्वारा, `f` द्वारा यसलाई परिमार्जन सहित।
    ///
    ///
    pub fn replace<'a, R>(
        &self,
        replacement: <T as ApplyL<'a>>::Out,
        f: impl for<'b, 'c> FnOnce(RefMutL<'b, 'c, T>) -> R,
    ) -> R {
        /// आवरणले यो सुनिश्चित गर्दछ कि सेल सँधै भरिनेछ (मूल राज्यको साथ, `f` द्वारा वैकल्पिक रूपमा परिवर्तन गरियो), `f` भयभीत भए पनि।
        ///
        ///
        struct PutBackOnDrop<'a, T: LambdaL> {
            cell: &'a ScopedCell<T>,
            value: Option<<T as ApplyL<'static>>::Out>,
        }

        impl<'a, T: LambdaL> Drop for PutBackOnDrop<'a, T> {
            fn drop(&mut self) {
                self.cell.0.set(self.value.take().unwrap());
            }
        }

        let mut put_back_on_drop = PutBackOnDrop {
            cell: self,
            value: Some(self.0.replace(unsafe {
                let erased = mem::transmute_copy(&replacement);
                mem::forget(replacement);
                erased
            })),
        };

        f(RefMutL(put_back_on_drop.value.as_mut().unwrap()))
    }

    /// `self` मा `value` चल्दा `f` X मा मान सेट गर्दछ।
    pub fn set<R>(&self, value: <T as ApplyL<'_>>::Out, f: impl FnOnce() -> R) -> R {
        self.replace(value, |_| f())
    }
}