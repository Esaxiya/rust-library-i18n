// Ez egy kísérlet az ideált követő megvalósításra
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Mivel a Rust valójában nem rendelkezik függő típussal és polimorf rekurzióval, sok bizonytalansággal élünk.
//

// Ennek a modulnak a fő célja a bonyolultság elkerülése azáltal, hogy a fát általános (ha furcsa alakú) konténerként kezeli, és elkerüli a legtöbb B-Tree invariáns kezelését.
//
// Mint ilyen, ez a modul nem érdekli, hogy a bejegyzések rendezve vannak-e, mely csomópontok lehetnek alulteljesítettek, és még az sem, hogy mit jelentenek a hiányosak.Néhány invariánsra támaszkodunk azonban:
//
// - A fáknak egyenletes depth/height-nek kell lenniük.Ez azt jelenti, hogy egy adott csomóponttól a levél felé vezető minden út pontosan azonos hosszúságú.
// - Az `n` hosszúságú csomóponton `n` kulcsok, `n` értékek és `n + 1` élek vannak.
//   Ez azt jelenti, hogy egy üres csomópontnak is van legalább egy edge.
//   Levélcsomópont esetén az "having an edge" csak azt jelenti, hogy azonosíthatunk egy pozíciót a csomópontban, mivel a levélszélek üresek és nincs szükségük adatok ábrázolására.
// A belső csomópontban a edge azonosítja a pozíciót, és tartalmaz egy mutatót egy gyermekcsomópontra.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// A levélcsomópontok mögöttes ábrázolása és a belső csomópontok ábrázolásának egy része.
struct LeafNode<K, V> {
    /// Kovariánsak akarunk lenni az `K` és az `V` rendszerekben.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Ez a csomópont indexe a szülőcsomópont `edges` tömbjébe.
    /// `*node.parent.edges[node.parent_idx]` ugyanaz legyen, mint az `node`.
    /// Ezt csak akkor lehet inicializálni, ha az `parent` nem null.
    parent_idx: MaybeUninit<u16>,

    /// A csomópont által tárolt kulcsok és értékek száma.
    len: u16,

    /// A csomópont tényleges adatait tároló tömbök.
    /// Minden tömbből csak az első `len` elemek inicializálódnak és érvényesek.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Inicializálja az új `LeafNode`-et a helyén.
    unsafe fn init(this: *mut Self) {
        // Általános irányelvként hagyjuk a mezőket inicializálatlanul, ha lehetséges, mivel ennek valamivel gyorsabbnak és könnyebben követhetőnek kell lennie a Valgrind-ben.
        //
        unsafe {
            // a parent_idx, a kulcsok és a valsok mind talánUninitek
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Létrehoz egy új dobozos `LeafNode`-et.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// A belső csomópontok mögöttes ábrázolása.Csakúgy, mint a " LeafNode`-oknál, ezeket is el kell rejteni a " BoxedNode` mögött, hogy megakadályozzák az inicializálatlan kulcsok és értékek elesését.
/// Az `InternalNode` bármely mutatóját közvetlenül a csomópont mögöttes `LeafNode` részébe mutató mutatóra lehet önteni, lehetővé téve a kód számára, hogy a levél és a belső csomópontok generikusan hatjanak anélkül, hogy meg kellene vizsgálniuk, hogy a mutató melyikére mutat.
///
/// Ezt a tulajdonságot az `repr(C)` használata engedélyezi.
///
#[repr(C)]
// gdb_providers.py ezt a típusú nevet használja önvizsgálatra.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// A csomópont gyermekeinek mutatói.
    /// `len + 1` ezek inicializálva és érvényesnek tekinthetők, kivéve, hogy a végén a fa `Dying` típusú hitelfelvételen keresztül tartva ezek a mutatók némelyike lóg.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Létrehoz egy új dobozos `InternalNode`-et.
    ///
    /// # Safety
    /// A belső csomópontok változatlansága, hogy legalább egy inicializált és érvényes edge van.
    /// Ez a funkció nem állít be ilyen edge-t.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Csak az adatokat kell inicializálnunk;az élek talánUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Felügyelt, nem null mutató egy csomópontra.Ez vagy az `LeafNode<K, V>` tulajdonosa, vagy az `InternalNode<K, V>` tulajdonosa.
///
/// Az `BoxedNode` azonban nem tartalmaz információt arról, hogy a két típusú csomópont közül melyiket tartalmazza valójában, és részben ennek az információhiánynak köszönhetően nem különálló típus és nincs romboló.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Egy birtokolt fa gyökércsomópontja.
///
/// Vegye figyelembe, hogy ennek nincs destruktora, ezért manuálisan kell tisztítani.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Visszaad egy új tulajdonú fát, saját gyökércsomópontjával, amely kezdetben üres.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` nem lehet nulla.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Kölcsönösen kölcsönveszi a tulajdonában lévő gyökércsomópontot.
    /// Az `reborrow_mut`-től eltérően ez biztonságos, mert a visszatérési érték nem használható a gyökér megsemmisítésére, és a fára más hivatkozások sem lehetnek.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Kicsit kölcsönösen kölcsönveszi a tulajdonosi gyökércsomópontot.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Visszafordíthatatlanul áttér egy referenciára, amely lehetővé teszi a bejárást, és destruktív módszereket kínál, és nem sok mást.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Új belső csomópontot ad hozzá egyetlen edge mutatóval az előző gyökércsomópontra, tegye az új csomópontot gyökércsomópontként és adja vissza.
    /// Ez 1-vel növeli a magasságot, és ellentétes az `pop_internal_level`-szel.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, csakhogy elfelejtettük, hogy most belsőek vagyunk:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Eltávolítja a belső gyökércsomópontot, az első gyermeket használva új gyökércsomópontként.
    /// Mivel csak akkor hívják meg, ha a gyökércsomópontnak csak egy gyermeke van, a kulcsok, értékek és más gyermekek egyikén sem történik megtisztítás.
    ///
    /// Ez 1-gyel csökkenti a magasságot, és ellentétes az `push_internal_level`-szel.
    ///
    /// Kizárólagos hozzáférést igényel az `Root` objektumhoz, de a gyökércsomóponthoz nem;
    /// nem érvényteleníti a fogantyúkat vagy hivatkozásokat a gyökércsomópontra.
    ///
    /// Panics, ha nincs belső szint, azaz ha a gyökércsomópont levél.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // BIZTONSÁG: belsőnek vallottuk magunkat.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // BIZTONSÁG: kizárólag az `self`-et vettük fel és kölcsönzési típusa exkluzív.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // BIZTONSÁG: az első edge mindig inicializálódik.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. Az `NodeRef` mindig kovariáns `K` és `V` értékekben, még akkor is, ha az `BorrowType` `Mut`.
// Ez technikailag helytelen, de az `NodeRef` belső használata miatt nem okozhat biztonságtalanságot, mert az `K` és az `V` felett teljesen általánosak maradunk.
//
// Mindazonáltal, amikor egy nyilvános típus az `NodeRef`-et tekeri, győződjön meg arról, hogy a megfelelő szórás van.
//
/// Hivatkozás egy csomópontra.
///
/// Ennek a típusnak számos paramétere van, amelyek szabályozzák a működését:
/// - `BorrowType`: Olyan dummy típus, amely leírja a hitelt és egy életen át viseli.
///    - Amikor ez `Immut<'a>`, akkor az `NodeRef` nagyjából úgy működik, mint az `&'a Node`.
///    - Ha ez `ValMut<'a>`, akkor az `NodeRef` nagyjából az `&'a Node`-hez hasonlóan viselkedik a kulcsok és a fa felépítése tekintetében, de lehetővé teszi, hogy a fa egészében található számos mutábilis hivatkozás együtt éljen.
///    - Ha ez `Mut<'a>`, akkor az `NodeRef` nagyjából úgy működik, mint az `&'a mut Node`, bár a beszúrási módszerek lehetővé teszik, hogy egy értékre mutatható mutató együtt létezzen.
///    - Amikor ez `Owned`, akkor az `NodeRef` nagyjából úgy működik, mint az `Box<Node>`, de nincs rombolója, ezért manuálisan kell tisztítani.
///    - Ha ez `Dying`, akkor az `NodeRef` továbbra is nagyjából úgy viselkedik, mint az `Box<Node>`, de van módja a fa apránként történő megsemmisítésére, és a közönséges módszerek, bár nincsenek megjelölve nem biztonságosként hívni, helytelen hívás esetén meghívhatják az UB-t.
///
///   Mivel bármely `NodeRef` lehetővé teszi a fán való navigálást, az `BorrowType` hatékonyan az egész fára vonatkozik, nem csak magára a csomópontra.
/// - `K` és `V`: Ezek a csomópontokban tárolt kulcsok és értékek.
/// - `Type`: Ez lehet `Leaf`, `Internal` vagy `LeafOrInternal`.
/// Ha ez `Leaf`, akkor az `NodeRef` egy levélcsomópontra mutat, amikor ez `Internal`, akkor az `NodeRef` egy belső csomópontra mutat, és amikor ez `LeafOrInternal`, akkor az `NodeRef` bármelyik csomópontra mutat.
///   `Type` `NodeType` néven szerepel, ha `NodeRef`-en kívül használják.
///
/// Az `BorrowType` és az `NodeType` egyaránt korlátozza, hogy milyen módszereket alkalmazzunk a statikus biztonság kihasználása érdekében.Az ilyen korlátozások alkalmazásának módja korlátozott:
/// - Az egyes típusú paraméterekhez csak egy módszert határozhatunk meg, vagy általánosan, vagy egy adott típushoz.
/// Például nem határozhatunk meg olyan módszert, mint az `into_kv`, az összes `BorrowType`-hez, vagy egyszer az összes élettartamot igénylő típushoz, mert azt akarjuk, hogy `&'a`-referenciákat adjon vissza.
///   Ezért csak a legkevésbé hatékony `Immut<'a>` típusra definiáljuk.
/// - Nem kaphatunk implicit kényszert mondjuk az `Mut<'a>`-től az `Immut<'a>`-ig.
///   Ezért kifejezetten meg kell hívnunk az `reborrow`-et egy erőteljesebb `NodeRef`-en, hogy elérjük az olyan módszert, mint az `into_kv`.
///
/// Az `NodeRef` összes metódusa, amely valamilyen referenciát ad vissza, vagy:
/// - Vegyük az `self` értékét, és adjuk meg az `BorrowType` által hordozott élettartamot.
///   Néha egy ilyen módszer meghívásához meg kell hívnunk az `reborrow_mut`-et.
/// - Vegyük az `self`-et referenciaként, és az (implicitly) adja vissza a referencia élettartamát az `BorrowType` által hordozott élettartam helyett.
/// Így a kölcsönellenőr garantálja, hogy az `NodeRef` továbbra is kölcsönzött marad, amíg a visszaküldött referenciát használják.
///   A beszúrást támogató módszerek ezt a szabályt egy nyers mutató, azaz egy élettartam nélküli referencia visszaadásával hajlítják meg.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// A csomópont és a levelek szintjeitől elkülönülő szintek száma, a csomópont állandója, amelyet az `Type` nem írhat le teljesen, és amelyet maga a csomópont nem tárol.
    /// Csak a gyökércsomópont magasságát kell tárolnunk, és minden más csomópont magasságát le kell vonnunk belőle.
    /// Nullának kell lennie, ha `Type` `Leaf`, és nem nulla, ha `Type` `Internal`.
    ///
    ///
    height: usize,
    /// A levél vagy a belső csomópont mutatója.
    /// Az `InternalNode` meghatározása biztosítja, hogy a mutató mindkét irányban érvényes legyen.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Csomagolja ki az `NodeRef::parent` csomagolású csomópont hivatkozást.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Belső csomópont adatait tárja fel.
    ///
    /// Visszaad egy nyers ptr-t, hogy elkerülje a csomópontra vonatkozó más hivatkozások érvénytelenítését.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // BIZTONSÁG: a statikus csomópont típusa `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Exkluzív hozzáférést kölcsönöz egy belső csomópont adataihoz.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Megkeresi a csomópont hosszát.Ez a kulcsok vagy értékek száma.
    /// Az élek száma `len() + 1`.
    /// Vegye figyelembe, hogy annak ellenére, hogy biztonságos, ennek a függvénynek a meghívása mellékhatással járhat, ha érvényteleníti a nem biztonságos kód által létrehozott mutábilis hivatkozásokat.
    ///
    pub fn len(&self) -> usize {
        // Fontos, hogy csak itt érjük el az `len` mezőt.
        // Ha a BorrowType értéke marker::ValMut, előfordulhatnak kiemelkedő mutábilis hivatkozások olyan értékekre, amelyeket nem szabad érvénytelenítenünk.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Visszaadja a csomópont és az elhagyott szintek számát.
    /// A nulla magasság azt jelenti, hogy a csomópont maga a levél.
    /// Ha fákat képez úgy, hogy a gyökér a tetején van, akkor a szám megmondja, hogy a csomópont melyik magasságban jelenik meg.
    /// Ha olyan fákat ábrázol, amelyek tetején levelek vannak, akkor a szám megmondja, hogy a fa milyen magasra nyúlik a csomópont fölé.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Ideiglenesen kivesz egy másik, változhatatlan hivatkozást ugyanarra a csomópontra.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Bármely levél vagy belső csomópont levélrészét kiteszi.
    ///
    /// Visszaad egy nyers ptr-t, hogy elkerülje a csomópontra vonatkozó más hivatkozások érvénytelenítését.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // A csomópontnak legalább a LeafNode részre érvényesnek kell lennie.
        // Ez nem hivatkozás a NodeRef típusban, mert nem tudjuk, hogy egyedinek vagy megosztottnak kell-e lennie.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Megkeresi az aktuális csomópont szülőjét.
    /// Az `Ok(handle)` értéket adja vissza, ha az aktuális csomópontnak valóban van szülője, ahol az `handle` az aktuális csomópontra mutató szülő edge-re mutat.
    ///
    /// Visszaadja az `Err(self)` értéket, ha az aktuális csomópontnak nincs szülője, és visszaadja az eredeti `NodeRef` értéket.
    ///
    /// A metódus neve feltételezi, hogy fákat képez, a gyökércsomópont tetején.
    ///
    /// `edge.descend().ascend().unwrap()` és az `node.ascend().unwrap().descend()`-nek a siker után sem szabad semmit tennie.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Nyers mutatókat kell használnunk a csomópontok számára, mert ha a BorrowType értéke marker::ValMut, előfordulhatnak kiemelkedő mutábilis hivatkozások olyan értékekre, amelyeket nem szabad érvénytelenítenünk.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Vegye figyelembe, hogy az `self` nem lehet üres.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Vegye figyelembe, hogy az `self` nem lehet üres.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Kitárja egy megváltoztathatatlan fa bármely levelének vagy belső csomópontjának levélrészét.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // BIZTONSÁG: ebbe az `Immut` néven kölcsönzött fába nem lehet mutatható utalás.
        unsafe { &*ptr }
    }

    /// Kölcsönvesz egy nézetet a csomópontban tárolt kulcsokba.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Az `ascend`-hez hasonlóan hivatkozást kap egy csomópont szülőcsomópontjára, de a folyamat során az aktuális csomópontot is felosztja.
    /// Ez nem biztonságos, mert az aktuális csomópont továbbra is elérhető lesz annak ellenére, hogy elosztották.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Biztonságosan állítja a fordító számára a statikus információkat, hogy ez a csomópont `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Biztonságosan állítja a fordító számára a statikus információkat, hogy ez a csomópont `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Ideiglenesen kivesz egy másik, módosítható hivatkozást ugyanarra a csomópontra.Vigyázni kell, mivel ez a módszer nagyon veszélyes, duplán, mivel nem biztos, hogy azonnal veszélyesnek tűnik.
    ///
    /// Mivel a mutálható mutatók bárhol kószálhatnak a fa körül, a visszaküldött mutató segítségével egyszerűen az eredeti mutatót lehet függeszteni, határtalanul vagy érvénytelenné tenni a halmozott kölcsönszabályok alapján.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) fontolja meg még egy olyan típusú paraméter hozzáadását az `NodeRef`-hez, amely korlátozza a navigációs módszerek használatát a visszakapott mutatókon, megakadályozva ezt a bizonytalanságot.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Kizárólagos hozzáférést kölcsönöz bármely levél vagy belső csomópont levélrészéhez.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // BIZTONSÁG: kizárólagos hozzáféréssel rendelkezünk a teljes csomóponthoz.
        unsafe { &mut *ptr }
    }

    /// Kizárólagos hozzáférést biztosít bármely levél vagy belső csomópont levélrészéhez.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // BIZTONSÁG: kizárólagos hozzáféréssel rendelkezünk a teljes csomóponthoz.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Kizárólagos hozzáférést kölcsönöz a kulcstároló területéhez.
    ///
    /// # Safety
    /// `index` a 0..KAPACITÁS határain belül van
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // BIZTONSÁG: A hívó fél nem fog tudni további módszereket hívni
        // mindaddig, amíg a kulcsszelet hivatkozás el nem esik, mivel egyedülálló hozzáféréssel rendelkezünk a kölcsön teljes élettartama alatt.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Kizárólagos hozzáférést kölcsönöz a csomópont értéktárolójának egy eleméhez vagy szeletéhez.
    ///
    /// # Safety
    /// `index` a 0..KAPACITÁS határain belül van
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // BIZTONSÁG: A hívó fél nem fog tudni további módszereket hívni
        // mindaddig, amíg az érték szelet referenciáját el nem vesszük, mivel egyedülálló hozzáféréssel rendelkezünk a kölcsön teljes élettartama alatt.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Kizárólagos hozzáférést kölcsönöz a csomópont tárolási területének egy eleméhez vagy szeletéhez a edge tartalomhoz.
    ///
    /// # Safety
    /// `index` a 0..CAPACITY + 1 határok között van
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // BIZTONSÁG: A hívó fél nem fog tudni további módszereket hívni
        // amíg a edge szeletre vonatkozó referenciát el nem vesszük, mivel egyedülálló hozzáféréssel rendelkezünk a kölcsön teljes élettartama alatt.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - A csomópontnak több mint `idx` inicializált eleme van.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Csak arra az egyetlen elemre hozunk létre hivatkozást, amely érdekel minket, hogy elkerüljük a más elemekre, különösen a korábbi iterációkban a hívónak visszaadott elemekre vonatkozó kiemelkedő hivatkozásokkal való álnevezést.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Kényszerítenünk kell a nem méretezett tömbmutatókat, a Rust #74679 kiadása miatt.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Exkluzív hozzáférést kölcsönöz a csomópont hosszához.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Beállítja a csomópont linkjét a szülő edge-re, anélkül, hogy érvénytelenítené a csomópontra vonatkozó egyéb hivatkozásokat.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Törli a gyökér linkjét a edge szülőhöz.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Kulcs-érték párot ad a csomópont végéhez.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Minden `range` által visszaküldött tétel érvényes edge index a csomópont számára.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Hozzáad egy kulcs-érték párot és egy edge-t, amely a pártól jobbra, a csomópont végéig megy.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Ellenőrzi, hogy egy csomópont `Internal` vagy `Leaf` csomópont-e.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Hivatkozás egy adott kulcs-érték párra vagy edge egy csomóponton belül.
/// Az `Node` paraméternek `NodeRef`-nek kell lennie, míg az `Type` lehet `KV` (a kulcs-érték pár fogantyúját jelöli) vagy `Edge` (a edge kezelőjét jelöli).
///
/// Vegye figyelembe, hogy még az `Leaf` csomópontok is rendelkezhetnek `Edge` fogantyúval.
/// Ahelyett, hogy mutatót mutatnának egy gyermekcsomópont számára, ezek azt a teret jelölik, ahová a gyermekmutatók a kulcs-érték párok között kerülnének.
/// Például egy 2 hosszúságú csomópontban 3 lehetséges edge hely lenne, egy a csomóponttól balra, egy a két pár között, egy pedig a csomópont jobb oldalán.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Nincs szükségünk az `#[derive(Clone)]` teljes általánosságára, mivel az `Node` csak akkor lesz `klónozható ', amikor megváltoztathatatlan referencia, ezért `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Letölti azt a csomópontot, amely tartalmazza a edge vagy kulcsérték párot, amelyre ez a fogantyú mutat.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Visszaadja ennek a fogantyúnak a helyzetét a csomópontban.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Új fogantyút hoz létre egy kulcs-érték pár számára az `node`-ben.
    /// Nem biztonságos, mert a hívónak biztosítania kell, hogy az `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Lehet a PartialEq nyilvános megvalósítása, de csak ebben a modulban használható.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Ideiglenesen elővesz egy másik, változhatatlan fogantyút ugyanazon a helyen.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Az Handle::new_kv vagy az Handle::new_edge nem használható, mert nem ismerjük a típusunkat
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Biztonságosan állítja a fordító számára a statikus információkat, hogy a fogantyú csomópontja `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Ideiglenesen elővesz egy másik, változtatható fogantyút ugyanazon a helyen.
    /// Vigyázni kell, mivel ez a módszer nagyon veszélyes, duplán, mivel nem biztos, hogy azonnal veszélyesnek tűnik.
    ///
    ///
    /// Részletekért lásd: `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Az Handle::new_kv vagy az Handle::new_edge nem használható, mert nem ismerjük a típusunkat
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Új fogantyút hoz létre a edge számára az `node`-ben.
    /// Nem biztonságos, mert a hívónak biztosítania kell, hogy az `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Adott egy edge index, ahová be akarunk illeszteni egy kapacitásig megtöltött csomópontot, kiszámítja a hasítási pont ésszerű KV indexét, és hol kell végrehajtani a beillesztést.
///
/// Az osztott pont célja, hogy kulcsa és értéke egy szülőcsomópontba kerüljön;
/// a hasítási ponttól balra levő kulcsok, értékek és élek bal gyermekké válnak;
/// a hasítási ponttól jobbra levő kulcsok, értékek és élek lesznek a megfelelő gyermek.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Az #74834 Rust kérdés megpróbálja megmagyarázni ezeket a szimmetrikus szabályokat.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Új kulcs-érték párot illeszt be a kulcs-érték párok közé a edge jobb és bal oldalán.
    /// Ez a módszer azt feltételezi, hogy a csomópontban elegendő hely van az új pár beillesztésére.
    ///
    /// A visszaadott mutató a beillesztett értékre mutat.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Új kulcs-érték párot illeszt be a kulcs-érték párok közé a edge jobb és bal oldalán.
    /// Ez a módszer felosztja a csomópontot, ha nincs elég hely.
    ///
    /// A visszaadott mutató a beillesztett értékre mutat.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Javítja a szülőmutatót és indexet a gyermek csomópontban, amelyhez ez a edge kapcsolódik.
    /// Ez akkor hasznos, ha az élek sorrendjét megváltoztatták,
    fn correct_parent_link(self) {
        // Hozzon létre backpointer-t anélkül, hogy érvénytelenítené a csomópontra vonatkozó egyéb hivatkozásokat.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Új kulcsérték-párot és egy edge-t illeszt be, amely az új pártól jobbra fog menni ennek a edge-nek és a kulcs-érték párnak a edge-től jobbra.
    /// Ez a módszer azt feltételezi, hogy a csomópontban elegendő hely van az új pár beillesztésére.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Új kulcsérték-párot és egy edge-t illeszt be, amely az új pártól jobbra fog menni ennek a edge-nek és a kulcs-érték párnak a edge-től jobbra.
    /// Ez a módszer felosztja a csomópontot, ha nincs elég hely.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Új kulcs-érték párot illeszt be a kulcs-érték párok közé a edge jobb és bal oldalán.
    /// Ez a módszer felosztja a csomópontot, ha nincs elég hely, és rekurzív módon próbálja beilleszteni a szétválasztott részt a szülőcsomópontba, amíg a gyökér el nem ér.
    ///
    ///
    /// Ha a visszaküldött eredmény `Fit`, akkor annak fogantyúja lehet ennek a edge-nek a csomópontja vagy őse.
    /// Ha a visszaadott eredmény `Split`, akkor az `left` mező lesz a gyökércsomópont.
    /// A visszaadott mutató a beillesztett értékre mutat.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Megkeresi a edge által mutatott csomópontot.
    ///
    /// A metódus neve feltételezi, hogy fákat képez, a gyökércsomópont tetején.
    ///
    /// `edge.descend().ascend().unwrap()` és az `node.ascend().unwrap().descend()`-nek a siker után sem szabad semmit tennie.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Nyers mutatókat kell használnunk a csomópontok számára, mert ha a BorrowType értéke marker::ValMut, előfordulhatnak kiemelkedő mutábilis hivatkozások olyan értékekre, amelyeket nem szabad érvénytelenítenünk.
        // A magassági mező elérésével nem kell aggódni, mert az érték átmásolásra kerül.
        // Vigyázzon, hogy amint a csomópontmutatót kivonják, hivatkozással férünk hozzá az éltömbhöz (Rust #73987 kérdés), és érvénytelenítünk a tömbre vagy annak belsejében található bármely más hivatkozást, ha vannak.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Nem hívhatunk külön kulcs és érték metódusokat, mert a második meghívása érvényteleníti az első által visszaadott referenciát.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Cserélje ki azt a kulcsot és értéket, amelyre a KV fogantyú utal.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// A levéladatok gondozásával segíti az `split` megvalósítását egy adott `NodeType` esetében.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Az alapul szolgáló csomópontot három részre osztja:
    ///
    /// - A csomópont csonka módon csak a kulcs-érték párokat tartalmazza a fogantyú bal oldalán.
    /// - Kivonjuk a kulcsot és az értéket, amelyre e fogantyú mutat.
    /// - A kezelőtől jobbra található összes kulcsérték-pár egy újonnan lefoglalt csomópontba kerül.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Eltávolítja az ezzel a fogantyúval jelölt kulcsérték-párot, és visszaadja azt a edge-szel együtt, amelybe a kulcs-érték pár összeesett.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Az alapul szolgáló csomópontot három részre osztja:
    ///
    /// - A csomópont csonkítva csak a fogantyú bal oldalán található éleket és kulcs-érték párokat tartalmazza.
    /// - Kivonjuk a kulcsot és az értéket, amelyre e fogantyú mutat.
    /// - A fogantyútól jobbra található összes él és kulcs-érték pár egy újonnan lefoglalt csomópontba kerül.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Képvisel egy munkamenetet egy kiegyenlítési művelet kiértékeléséhez és végrehajtásához egy belső kulcs-érték pár körül.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Kiegyensúlyozó kontextust választ ki, amelyben a csomópont gyermekként szerepel, így a KV közvetlenül a szülőcsomópontban balra vagy jobbra.
    /// `Err`-et ad vissza, ha nincs szülő.
    /// Panics, ha a szülő üres.
    ///
    /// A bal oldalt részesíti előnyben, hogy optimális legyen, ha az adott csomópont valahogy alulteljes, vagyis itt csak annyit jelent, hogy kevesebb eleme van, mint a bal testvérének, és a jobb testvérének, ha léteznek.
    /// Ebben az esetben a bal testvérrel való összeolvadás gyorsabb, mivel csak a csomópont N elemét kell mozgatnunk, ahelyett, hogy jobbra tolnánk, és N elemnél többet haladnánk elöl.
    /// A bal testvértől való lopás is jellemzően gyorsabb, mivel csak a csomópont N elemét kell jobbra tolnunk, ahelyett, hogy a testvér eleméből legalább N-t balra tolnánk.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Visszaadja, hogy lehetséges-e az összevonás, azaz van-e elegendő hely egy csomópontban ahhoz, hogy a központi KV-t összekapcsolja mindkét szomszédos gyermekcsomóponttal.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Összevonást hajt végre, és a bezárás eldönti, hogy mit adjon vissza.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // BIZTONSÁG: az egyesítendő csomópontok magassága a magasság alatt van
                // ennek a edge csomópontjának a értéke, tehát nulla fölött, tehát belső.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Egyesíti a szülő kulcs-érték párját és mindkét szomszédos gyermek csomópontot a bal gyermek csomópontba, és visszaadja a zsugorított szülő csomópontot.
    ///
    ///
    /// Panics, hacsak nem `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// A szülő kulcs-érték párját, és mindkét szomszédos gyermek csomópontját egyesíti a bal gyermek csomópontban, és visszaadja azt a csomópontot.
    ///
    ///
    /// Panics, hacsak nem `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Összevonja a szülő kulcs-érték párját és mindkét szomszédos gyermek csomópontot a bal gyermek csomópontba, és visszaadja a edge fogantyút abban a gyermek csomópontban, ahová a nyomon követett gyermek edge került,
    ///
    ///
    /// Panics, hacsak nem `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Eltávolít egy kulcsérték-párot a bal gyermekből, és elhelyezi a szülő kulcsérték-tárolójában, miközben a régi szülő kulcs-érték párját a jobb gyermekbe tolja.
    ///
    /// Visszaad egy fogantyút a jobb gyermek edge-jének, annak megfelelően, ahova az `track_right_edge_idx` által megadott eredeti edge került.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Eltávolít egy kulcs-érték párot a jobb gyermektől, és elhelyezi a szülő kulcs-érték tárolójában, miközben a régi szülő kulcs-érték párját a bal gyermekre tolja.
    ///
    /// Visszaad egy fogantyút a edge-nek az `track_left_edge_idx` által megadott bal gyermeknél, amely nem mozdult.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Ez ugyanúgy lop, mint az `steal_left`, de egyszerre több elemet lop el.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Ügyeljen arra, hogy biztonságosan lophassunk.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Levéladatok áthelyezése.
            {
                // Helyezzen el helyet az ellopott elemeknek a megfelelő gyermeknél.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Mozgassa az elemeket a bal gyermektől a jobbig.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Vigye a bal oldali leglopottabb párt a szülőhöz.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Helyezze át a szülő kulcs-érték párját a megfelelő gyermekre.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Helyezzen el helyet az ellopott éleknek.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Lopja el az éleket.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Az `bulk_steal_left` szimmetrikus klónja.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Ügyeljen arra, hogy biztonságosan lophassunk.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Levéladatok áthelyezése.
            {
                // Vigye a jobb oldali leglopottabb párt a szülőhöz.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Helyezze át a szülő kulcs-érték párját a bal gyermekre.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Mozgassa az elemeket a jobb gyermektől a balig.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Töltse ki a rést ott, ahol az ellopott elemek voltak.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Lopja el az éleket.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Töltse ki a rést ott, ahol az ellopott élek voltak.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Eltávolít minden statikus információt, állítva, hogy ez a csomópont `Leaf` csomópont.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Eltávolít minden statikus információt, állítva, hogy ez a csomópont `Internal` csomópont.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Ellenőrzi, hogy az alapul szolgáló csomópont `Internal` vagy `Leaf` csomópont-e.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Vigye az utótagot az `self` után az egyik csomópontról a másikra.Az `right`-nek üresnek kell lennie.
    /// Az `right` első edge változatlan marad.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// A beillesztés eredménye, amikor egy csomópontnak a kapacitásán túl kell tágulnia.
pub struct SplitResult<'a, K, V, NodeType> {
    // Megváltozott csomópont a meglévő fában, az `kv` bal oldalán található elemekkel és élekkel.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Néhány kulcs és érték elszakad, máshova kell beilleszteni.
    pub kv: (K, V),
    // Saját, nem csatolt, új csomópont elemekkel és élekkel, amelyek az `kv` jobb oldalán találhatók.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Az, hogy az ilyen kölcsön típusú csomópont-hivatkozások lehetővé teszik-e a fa más csomópontjain való áthaladást.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // A bejárásra nincs szükség, az `borrow_mut` eredményének felhasználásával történik.
        // Az áthaladás letiltásával és csak új hivatkozások létrehozásával a gyökerekhez tudjuk, hogy az `Owned` típusú minden hivatkozás egy gyökércsomópontra vonatkozik.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Beszúr egy értéket egy inicializált elem szeletébe, amelyet egy inicializálatlan elem követ.
///
/// # Safety
/// A szeletnek több mint `idx` eleme van.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Eltávolít és visszaad egy értéket az összes inicializált elem szeletéből, egy hátrahagyott inicializálatlan elemet hagyva maga után.
///
///
/// # Safety
/// A szeletnek több mint `idx` eleme van.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Az elemeket egy szelet `distance` pozícióban tolja balra.
///
/// # Safety
/// A szeletnek legalább `distance` eleme van.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Az elemeket egy szelet `distance` pozícióban tolja jobbra.
///
/// # Safety
/// A szeletnek legalább `distance` eleme van.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Az összes értéket áthelyezi az inicializált elemek szeletéből az inicializálatlan elemek szeletévé, az összes inicializálatlanként hagyva hátra az `src`-et.
///
/// Úgy működik, mint az `dst.copy_from_slice(src)`, de nem igényli, hogy az `T` legyen `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;