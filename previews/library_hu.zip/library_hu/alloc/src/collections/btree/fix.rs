use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Egy testvérrel összeolvadva vagy ellopva feltölti az esetlegesen hiányos csomópontot.
    /// Ha ez sikeres, de a szülőcsomópont zsugorításának árán adja vissza, akkor az a zsugorított szülőcsomópont visszatér.
    /// `Err` értéket ad vissza, ha a csomópont üres gyökér.
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Feltölti az esetlegesen hiányos csomópontot, és ha ez szülőcsomópontjának zsugorodását okozza, akkor rekurzívan feltölti a szülőt.
    /// `true`-et ad vissza, ha javította a fát, `false`-et, ha nem sikerült, mert a gyökércsomópont üres lett.
    ///
    /// Ez a módszer nem számít arra, hogy az ősök már a belépéskor elégtelenek lennének, és ha a panics üres őssel találkozik.
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// Eltávolítja az üres szinteket a tetején, de üres levelet tart, ha az egész fa üres.
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// Felrakja vagy összevonja az összes hiányos csomópontot a fa jobb szélén.
    /// A többi csomópontnak, azoknak, amelyek nem a edge gyökerei és nem a jobb szélső részei, már legalább MIN_LEN elemet kell tartalmazniuk.
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// Az `fix_right_border` szimmetrikus klónja.
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// Töltsön fel minden hiányos csomópontot a fa jobb szélén.
    /// A többi csomópontnak, azoknak, amelyek nem a edge gyökerei és nem a jobb szélső részei, fel kell készülniük arra, hogy MIN_LEN elemet ellopjanak.
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // Ellenőrizze, hogy a legtöbb gyermek nem teljes-e.
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // Lopnunk kell.
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // Menj tovább.
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Felteszi a bal gyermeket, feltételezve, hogy a jobb gyermek nem teljes, és egy további elemet tartalmaz, amely lehetővé teszi a gyermekei összevonását anélkül, hogy teljessé válna.
    ///
    /// Visszaadja a bal gyermeket.
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` az újrabeállítás elkerülése érdekében, ha az egyesülés a következő szintre kerül.
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// Feltételezi a jobb gyermeket, feltételezve, hogy a bal gyermek nem teljes, és egy olyan kiegészítő elemet biztosít, amely lehetővé teszi a gyermekei összevonását anélkül, hogy alulteljesítővé válna.
    ///
    /// Visszatér, bárhová is került a megfelelő gyermek.
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` az újrabeállítás elkerülése érdekében, ha az egyesülés a következő szintre kerül.
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}