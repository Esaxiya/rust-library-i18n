use core::intrinsics;
use core::mem;
use core::ptr;

/// Ez az `v` egyedi referencia mögötti értéket helyettesíti az adott függvény meghívásával.
///
///
/// Ha egy panic történik az `change` lezárásakor, akkor a teljes folyamat megszakad.
#[allow(dead_code)] // tartsa szemléltetésként és a future használatához
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Ez az `v` egyedi referencia mögötti értéket helyettesíti az adott függvény meghívásával, és az út során kapott eredményt adja vissza.
///
///
/// Ha egy panic történik az `change` lezárásakor, akkor a teljes folyamat megszakad.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}