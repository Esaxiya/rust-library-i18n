use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Az összes kulcsérték-pár hozzá van adva két felmenő iterátor egyesüléséhez, növelve az út során az `length` változót.Ez utóbbi megkönnyíti a hívó számára a szivárgás elkerülését, amikor a cseppkezelő pánikba esik.
    ///
    /// Ha mindkét iterátor ugyanazt a kulcsot állítja elő, ez a módszer eldobja a párost a bal iterátorból, és hozzáfűzi a párot a jobb iterátortól.
    ///
    /// Ha azt szeretné, hogy a fa szigorúan növekvő sorrendbe kerüljön, mint például az `BTreeMap` esetében, mindkét iterátornak szigorúan növekvő sorrendben kell előállítania a kulcsokat, amelyek mindegyike nagyobb, mint a fa összes kulcsa, beleértve a belépéskor már a fában lévő kulcsokat is.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Felkészülünk arra, hogy az `left` és `right` lineáris időben rendezett szekvenciává egyesüljön.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Eközben a rendezett sorrendből fát építünk lineáris időben.
        self.bulk_push(iter, length)
    }

    /// Az összes kulcsérték-párt a fa végéig tolja, az út mentén növelve az `length` változót.
    /// Ez utóbbi megkönnyíti a hívó számára a szivárgás elkerülését, amikor az iterátor pánikba esik.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Minden kulcsérték-páron keresztül iterálunk, a megfelelő szintű csomópontokba tolva őket.
        for (key, value) in iter {
            // Próbáljon betolni a kulcs-érték párokat az aktuális levélcsomópontba.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Nincs hely, menj fel és nyomulj oda.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Talált egy csomópontot, ahol maradt hely, nyomja ide.
                                open_node = parent;
                                break;
                            } else {
                                // Menj fel újra.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // A csúcson vagyunk, hozzunk létre egy új gyökércsomópontot, és nyomjuk oda.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Nyomja meg a kulcs-érték párot és az új jobb alfát.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Menj le ismét a jobb szélső levélhez.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Növelje az egyes iterációk hosszát, hogy a térkép eldobja a hozzáfűzött elemeket, még akkor is, ha az iterátor előrehaladása pánikba esik.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Iterátor két rendezett szekvencia egyesítéséhez
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Ha két kulcs egyenlő, akkor a megfelelő érték párját adja vissza a megfelelő forrásból.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}