use core::marker::PhantomData;
use core::ptr::NonNull;

/// Valamely egyedi referencia újrafelvételét modellezi, ha tudja, hogy a visszavásárlást és annak összes leszármazottját (azaz az összes mutatót és referenciát abból származtatják) egy bizonyos ponton már nem fogják használni, amely után újra fel akarja használni az eredeti egyedi referenciát .
///
///
/// A kölcsönellenőrző általában kezeli ezt a kölcsönök halmozását az Ön számára, de a vezérlési folyamatok, amelyek ezt a halmozást végrehajtják, túl bonyolultak ahhoz, hogy a fordító kövesse őket.
/// Az `DormantMutRef` lehetővé teszi, hogy ellenőrizze a hitelfelvételt, miközben kifejezi halmozott jellegét, és meghatározatlan viselkedés nélkül beágyazza az ehhez szükséges nyers mutató kódot.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Készítsen egyedi kölcsönt, és azonnal költsön vissza.
    /// A fordító számára az új referencia élettartama megegyezik az eredeti referencia élettartamával, de Ön promise rövidebb ideig használja.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // BIZTONSÁG: A kölcsönt a `_marker`-en keresztül tartjuk, és kitesszük
        // csak ez a hivatkozás, tehát egyedi.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Térjen vissza az eredetileg elfogadott egyedi kölcsönre.
    ///
    /// # Safety
    ///
    /// Az újrahitelnek véget kell vetnie, vagyis az `new` által visszaküldött referenciát, valamint az abból származó összes mutatót és hivatkozást nem szabad tovább használni.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // BIZTONSÁG: saját biztonsági körülményeink azt sugallják, hogy ez a hivatkozás ismét egyedülálló.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;