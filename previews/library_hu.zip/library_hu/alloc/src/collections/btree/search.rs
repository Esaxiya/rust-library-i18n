use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// Egy befogadó köteles keresni, akárcsak az `Bound::Included(T)`.
    Included(T),
    /// Egyedülálló keresés, csakúgy, mint az `Bound::Excluded(T)`.
    Excluded(T),
    /// Feltétlen befogadó kötés, akárcsak az `Bound::Unbounded`.
    AllIncluded,
    /// Feltétel nélküli kizárólagos kötés.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Rekurzív módon megkeresi az adott kulcsot a csomópont által vezetett (al) fában.
    /// Visszaad egy `Found`-et a megfelelő KV fogantyújával, ha van ilyen.
    /// Ellenkező esetben adjon vissza egy `GoDown`-et a edge levél fogantyújával, ahová a kulcs tartozik.
    ///
    /// Az eredmény csak akkor értelmes, ha a fát kulcs szerint rendezik, mint az `BTreeMap`-ben lévő fát.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// Leereszkedik a legközelebbi csomópontra, ahol a tartomány alsó határához illeszkedő edge eltér a felső határnak megfelelő edge-től, vagyis a legközelebbi csomóponttól, amelynek legalább egy kulcsa van a tartományban.
    ///
    ///
    /// Ha megtalálta, akkor egy `Ok`-et ad vissza azzal a csomópontdal, a benne lévő edge indexpár határolja a tartományt, és a megfelelő határpár a keresés folytatásához a gyermekcsomópontokban, ha a csomópont belső.
    ///
    /// Ha nem található, akkor egy `Err`-et ad vissza, amelynek edge levele megfelel a teljes tartománynak.
    ///
    /// Az eredmény csak akkor értelmes, ha a fát kulcs szerint rendezik.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Ezeknek a változóknak a beillesztését kerülni kell.
        // Feltételezzük, hogy az `range` által jelentett határok változatlanok maradnak, de az (#81138) hívások között egy kontradiktórius megvalósítás megváltozhat.
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// Megtalál egy edge értéket a tartomány alsó határát határoló csomópontban.
    /// Visszaadja azt az alsó határt is, amelyet a keresés folytatásához kell használni az egyező gyermekcsomópontban, ha az `self` belső csomópont.
    ///
    ///
    /// Az eredmény csak akkor értelmes, ha a fát kulcs szerint rendezik.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Az `find_lower_bound_edge` klónja a felső határhoz.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Megkeres egy adott kulcsot a csomópontban, rekurzió nélkül.
    /// Visszaad egy `Found`-et a megfelelő KV fogantyújával, ha van ilyen.
    /// Ellenkező esetben visszaad egy `GoDown`-et a edge fogantyújával, ahol a kulcs megtalálható (ha a csomópont belső), vagy ahová be lehet helyezni a kulcsot.
    ///
    ///
    /// Az eredmény csak akkor értelmes, ha a fát kulcs szerint rendezik, mint az `BTreeMap`-ben lévő fát.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// Vagy a KV indexet adja vissza abban a csomópontban, amelynél a kulcs (vagy azzal egyenértékű) létezik, vagy a edge indexet, ahová a kulcs tartozik.
    ///
    ///
    /// Az eredmény csak akkor értelmes, ha a fát kulcs szerint rendezik, mint az `BTreeMap`-ben lévő fát.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// edge indexet keres a csomópontban, amely határolja a tartomány alsó határait.
    /// Visszaadja azt az alsó határt is, amelyet a keresés folytatásához kell használni az egyező gyermekcsomópontban, ha az `self` belső csomópont.
    ///
    ///
    /// Az eredmény csak akkor értelmes, ha a fát kulcs szerint rendezik.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Az `find_lower_bound_index` klónja a felső határhoz.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}