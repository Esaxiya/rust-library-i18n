//! Egyszálú referenciaszámláló mutatók.Az 'Rc' jelentése " Referencia`
//! Counted'.
//!
//! Az [`Rc<T>`][`Rc`] típus megosztott tulajdonjogot biztosít a kupacban kiosztott `T` típusú értékhez.
//! Az [`clone`][clone] meghívása az [`Rc`]-en egy új mutatót hoz létre a halom ugyanarra a felosztásra.
//! Amikor egy adott kiosztás utolsó [`Rc`] mutatója megsemmisül, az abban a kiosztásban tárolt érték (gyakran "inner value" néven is) eldől.
//!
//! A Rust megosztott hivatkozásai alapértelmezés szerint nem engedélyezik a mutációt, és az [`Rc`] sem kivétel: általában nem szerezhet módosítható hivatkozást valamire az [`Rc`]-en belül.
//! Ha mutabilitásra van szüksége, tegyen egy [`Cell`] vagy [`RefCell`] elemet az [`Rc`] belsejébe;lásd [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] nem atomi referenciaszámlálást használ.
//! Ez azt jelenti, hogy a rezsi nagyon alacsony, de egy [`Rc`] nem küldhető el a szálak között, következésképpen az [`Rc`] nem valósítja meg az [`Send`][send]-et.
//! Ennek eredményeként a Rust fordító fordításkor * ellenőrzi, hogy nem küld-e [`Rc`-ket] a szálak között.
//! Ha több szálú, atomi referenciaszámlálásra van szüksége, használja az [`sync::Arc`][arc]-et.
//!
//! Az [`downgrade`][downgrade] módszerrel nem [`Weak`] mutató hozható létre.
//! Az [`Weak`] mutató lehet [`upgrade`][upgrade] d [`Rc`]-re, de ez [`None`]-et ad vissza, ha a kiosztásban tárolt értéket már eldobták.
//! Más szavakkal, az `Weak` mutatók nem tartják életben az allokáción belüli értéket;azonban életben tartják a kiosztást (a belső érték háttértárát).
//!
//! Az [`Rc`] mutatók közötti ciklust soha nem osztják fel.
//! Ezért az [`Weak`]-et a ciklusok megszakítására használják.
//! Például egy fának erős [`Rc`] mutatói lehetnek a szülői csomópontoktól a gyermekekig, az [`Weak`] mutatók pedig a gyerekektől a szüleikig.
//!
//! `Rc<T>` automatikusan elutasítja az `T`-et (az [`Deref`] trait-en keresztül), így meghívhatja a `T` metódusait egy [`Rc<T>`][`Rc`] típusú értékre.
//! A névütközések elkerülése érdekében a `T` metódusokkal, maga az [`Rc<T>`][`Rc`] metódusai társított függvények, az [fully qualified syntax] használatával hívják őket:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>A traits implementációi, például az `Clone`, teljesen minősített szintaxissal is meghívhatók.
//! Vannak, akik inkább a teljesen minősített szintaxist, míg mások a method-call szintaxist használják.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Method-call szintaxis
//! let rc2 = rc.clone();
//! // Teljesen képzett szintaxis
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] nem automatikusan hivatkozik az `T`-re, mert lehet, hogy a belső érték már leesett.
//!
//! # Klónozási referenciák
//!
//! Új referencia létrehozása ugyanarra a felosztásra, mint egy meglévő referencia számlált mutató, az [`Rc<T>`][`Rc`] és [`Weak<T>`][`Weak`] esetén megvalósított `Clone` trait használatával történik.
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Az alábbi két szintaxis egyenértékű.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // az a és a b egyaránt a memóriahelyre mutat, mint a foo.
//! ```
//!
//! Az `Rc::clone(&from)` szintaxis a legidiótikusabb, mert egyértelműbben közvetíti a kód jelentését.
//! A fenti példában ez a szintaxis megkönnyíti annak belátását, hogy ez a kód új referenciát hoz létre, ahelyett, hogy a foo teljes tartalmát átmásolná.
//!
//! # Examples
//!
//! Vegyünk egy olyan forgatókönyvet, amikor egy "Gadget" készlet egy adott `Owner` tulajdonában van.
//! Azt akarjuk, hogy `Gadget'ink mutassanak az `Owner`-re.Ezt nem tehetjük meg egyedi tulajdonjoggal, mert több modul is tartozhat ugyanahhoz az `Owner`-hez.
//! [`Rc`] lehetővé teszi számunkra, hogy megosszunk egy `Owner`-et több "Gadget" között, és az `Owner`-et addig kell osztani, amíg az rajta lévő `Gadget`-pontok vannak.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... más mezők
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... más mezők
//! }
//!
//! fn main() {
//!     // Hozzon létre referencia-számlált `Owner`-et.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Készítse el az `gadget_owner`-hez tartozó `Gadget`-eket.
//!     // Az `Rc<Owner>` klónozása új mutatót ad ugyanahhoz az `Owner` allokációhoz, növelve a referenciaszámot a folyamatban.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Dobja el az `gadget_owner` helyi változónkat.
//!     drop(gadget_owner);
//!
//!     // Annak ellenére, hogy elejtette az `gadget_owner`-et, még mindig ki tudjuk nyomtatni a " Gadget` `Owner` nevét.
//!     // Ez azért van, mert csak egyetlen `Rc<Owner>`-et dobtunk le, az `Owner`-et nem, amelyre mutat.
//!     // Amíg vannak más `Rc<Owner>` mutatók ugyanabban az `Owner` allokációban, az élőben marad.
//!     // Az `gadget1.owner.name` terepi vetület azért működik, mert az `Rc<Owner>` automatikusan hivatkozik az `Owner`-re.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // A függvény végén az `gadget1` és az `gadget2` megsemmisül, és velük együtt utoljára megszámlálták az `Owner`-re vonatkozó hivatkozásokat.
//!     // A Gadget Man most is megsemmisül.
//!     //
//! }
//! ```
//!
//! Ha megváltoznak a követelményeink, és képesnek kell lennünk az `Owner`-ről az `Gadget`-re való átjutásra is, problémákba ütközünk.
//! Az `Owner` és `Gadget` közötti [`Rc`] mutató egy ciklust vezet be.
//! Ez azt jelenti, hogy referenciaszámuk soha nem érheti el a 0 értéket, és az allokáció soha nem semmisül meg:
//! memóriaszivárgás.Ennek megkerülése érdekében használhatunk [`Weak`] mutatókat.
//!
//! A Rust valójában némileg megnehezíti ennek a huroknak a létrehozását.Ahhoz, hogy két egymásra mutató értéket kapjunk, egyiküknek mutálhatónak kell lennie.
//! Ez azért nehéz, mert az [`Rc`] úgy érvényesíti a memória biztonságát, hogy csak megosztott hivatkozásokat ad meg a becsomagolt értékre, és ezek nem teszik lehetővé a közvetlen mutációt.
//! Az érték azon részét, amelyet mutálni akarunk, be kell csomagolnunk egy [`RefCell`]-be, amely *belső mutálhatóságot* biztosít: egy módszert a mutabilitás elérésére megosztott referencián keresztül.
//! [`RefCell`] végrehajtja a Rust hitelfelvételi szabályait futás közben.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... más mezők
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... más mezők
//! }
//!
//! fn main() {
//!     // Hozzon létre referencia-számlált `Owner`-et.
//!     // Ne feledje, hogy a " Gadget` tulajdonosának vector-jét egy `RefCell`-be helyeztük, hogy közös hivatkozással mutálhassuk.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Készítse el az `gadget_owner`-hez tartozó `Gadget`-okat, az előbbiekhez hasonlóan.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Adja hozzá a " modult` az `Owner`-hez.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` dinamikus kölcsön itt ér véget.
//!     }
//!
//!     // Ismételjük a " kütyüinket`, kinyomtatva az adataikat.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` egy `Weak<Gadget>`.
//!         // Mivel az `Weak` mutatók nem tudják garantálni, hogy a kiosztás még mindig létezik, meg kell hívnunk az `upgrade`-et, amely `Option<Rc<Gadget>>`-et ad vissza.
//!         //
//!         //
//!         // Ebben az esetben tudjuk, hogy az allokáció még mindig létezik, ezért egyszerűen `unwrap` az `Option`.
//!         // Egy bonyolultabb programban előfordulhat, hogy kecses hibakezelésre van szükség az `None` eredményekhez.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // A függvény végén az `gadget_owner`, `gadget1` és `gadget2` megsemmisül.
//!     // Most nincsenek erős (`Rc`) mutatók a modulokra, ezért azok megsemmisülnek.
//!     // Ez nullázza a Gadget Man referenciaszámát, így ő is megsemmisül.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Ez repr(C)-től future-ig ellenálló az esetleges terepi átrendezéssel szemben, ami megzavarná a transzmutálható belső típusok egyébként biztonságos [into|from]_raw()-jét.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Egyszálú referenciaszámláló mutató.Az 'Rc' jelentése " Referencia`
/// Counted'.
///
/// További részletekért lásd az [module-level documentation](./index.html)-et.
///
/// Az `Rc` benne rejlő módszerek mindegyike társított függvény, ami azt jelenti, hogy pl. [`Rc::get_mut(&mut value)`][get_mut]-nek kell hívnia őket az `value.get_mut()` helyett.
/// Ezzel elkerülhető a belső típusú `T` módszerekkel való ütközés.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Ez a bizonytalanság rendben van, mert amíg ez az Rc életben van, garantáljuk, hogy a belső mutató érvényes.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Új `Rc<T>`-et épít.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Van egy implicit gyenge mutató, amely az összes erős mutató birtokában van, amely biztosítja, hogy a gyenge destruktor soha ne szabadítsa fel az allokációt, miközben az erős destructor fut, még akkor is, ha a gyenge mutatót az erősen belül tároljuk.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Új `Rc<T>`-et készít, gyenge hivatkozással.
    /// Ha a függvény visszatérése előtt megpróbálja frissíteni a gyenge referenciát, az `None` értéket eredményez.
    ///
    /// A gyenge referencia azonban szabadon klónozható és tárolható későbbi felhasználás céljából.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... több mező
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Konstrukciója a belső "uninitialized" állapotban egyetlen gyenge referenciával.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Fontos, hogy ne adjuk fel a gyenge mutató tulajdonjogát, különben a memória felszabadulhat, mire az `data_fn` visszatér.
        // Ha valóban át akarjuk adni a tulajdonjogot, létrehozhatunk egy további gyenge mutatót magunknak, de ez további frissítéseket eredményez a gyenge referenciaszámhoz, amire egyébként nem lehet szükség.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Az erős referenciáknak együttesen rendelkezniük kell egy megosztott gyenge referenciával, ezért ne futtassák a régi gyenge referenciánkat.
        //
        mem::forget(weak);
        strong
    }

    /// Új, nem inicializált tartalommal rendelkező `Rc` készül.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Halasztott inicializálás:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Új, nem inicializált tartalommal rendelkező `Rc`-et épít, a memóriát `0`-byte-ok töltik meg.
    ///
    ///
    /// Lásd az [`MaybeUninit::zeroed`][zeroed] példákat a módszer helyes és helytelen használatára.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Új `Rc<T>`-et készít, és hibát ad vissza, ha a kiosztás sikertelen
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Van egy implicit gyenge mutató, amely az összes erős mutató birtokában van, amely biztosítja, hogy a gyenge destruktor soha ne szabadítsa fel az allokációt, miközben az erős destructor fut, még akkor is, ha a gyenge mutatót az erősen belül tároljuk.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Új, nem inicializált tartalommal rendelkező `Rc`-et készít, amely hibát eredményez, ha a kiosztás sikertelen
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Halasztott inicializálás:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Új, nem inicializált tartalommal rendelkező `Rc`-et épít, a memória `0` byte-okkal feltöltve, hibát adva, ha az allokáció sikertelen
    ///
    ///
    /// Lásd az [`MaybeUninit::zeroed`][zeroed] példákat a módszer helyes és helytelen használatára.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Új `Pin<Rc<T>>`-et épít.
    /// Ha az `T` nem valósítja meg az `Unpin`-et, akkor az `value` rögzül a memóriában, és nem tudja áthelyezni.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Visszaadja a belső értéket, ha az `Rc` pontosan egy erős referenciával rendelkezik.
    ///
    /// Ellenkező esetben egy [`Err`]-et ugyanazzal az `Rc`-rel adunk vissza, amelyet átadtunk.
    ///
    ///
    /// Ez akkor is sikeres lesz, ha vannak kiemelkedő gyenge referenciák.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // másolja a benne lévő objektumot

                // Jelezze a Weaksnek, hogy az erős szám csökkentésével nem lehet őket népszerűsíteni, majd távolítsa el az implicit "strong weak" mutatót, miközben a hamis gyengeség kidolgozásával a drop logikát is kezeli.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Új, referenciával megszámlált szeletet állít elő inicializálatlan tartalommal.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Halasztott inicializálás:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Új, referenciával megszámlált szeletet állít elő inicializálatlan tartalommal, a memória töltésével `0` bájtokkal.
    ///
    ///
    /// Lásd az [`MaybeUninit::zeroed`][zeroed] példákat a módszer helyes és helytelen használatára.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Átalakítás `Rc<T>`-re.
    ///
    /// # Safety
    ///
    /// Az [`MaybeUninit::assume_init`]-hez hasonlóan a hívónak is garantálnia kell, hogy a belső érték valóban inicializált állapotban van.
    ///
    /// Ennek hívása, ha a tartalom még nincs teljesen inicializálva, azonnal meghatározhatatlan viselkedést okoz.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Halasztott inicializálás:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Átalakítás `Rc<[T]>`-re.
    ///
    /// # Safety
    ///
    /// Az [`MaybeUninit::assume_init`]-hez hasonlóan a hívónak is garantálnia kell, hogy a belső érték valóban inicializált állapotban van.
    ///
    /// Ennek hívása, ha a tartalom még nincs teljesen inicializálva, azonnal meghatározhatatlan viselkedést okoz.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Halasztott inicializálás:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Fogyasztja az `Rc`-et, visszaküldi a becsomagolt mutatót.
    ///
    /// A memória szivárgásának elkerülése érdekében a mutatót vissza kell alakítani `Rc`-be [`Rc::from_raw`][from_raw] használatával.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Nyers mutatót ad az adatokhoz.
    ///
    /// A számlálást semmilyen módon nem befolyásolja, és az `Rc` nem kerül felhasználásra.
    /// A mutató addig érvényes, amíg erős számok vannak az `Rc`-ben.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // BIZTONSÁG: Ez nem megy át az Deref::deref vagy Rc::inner rendszeren, mert
        // erre van szükség az raw/mut eredetének megőrzéséhez, pl
        // `get_mut` írhat a mutatón, miután az Rc helyreállt az `from_raw`-en keresztül.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// `Rc<T>`-et készít egy nyers mutatóból.
    ///
    /// A nyers mutatót korábban vissza kellett adni egy [`Rc<U>::into_raw`][into_raw] hívással, ahol az `U` méretének és igazításának meg kell egyeznie az `T` értékével.
    /// Ez triviálisan igaz, ha az `U` az `T`.
    /// Ne feledje, hogy ha az `U` nem `T`, de azonos méretű és igazítású, akkor ez alapvetően olyan, mint a különböző típusú referenciák átalakítása.
    /// Az ebben az esetben érvényes korlátozásokról az [`mem::transmute`][transmute] oldalon talál további információt.
    ///
    /// Az `from_raw` felhasználójának meg kell győződnie arról, hogy az `T` meghatározott értéke csak egyszer kerül ejtésre.
    ///
    /// Ez a funkció nem biztonságos, mert a nem megfelelő használat memóriabiztonsághoz vezethet, még akkor is, ha a visszaküldött `Rc<T>`-hez soha nem fér hozzá.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Konvertáljon vissza `Rc`-be a szivárgás elkerülése érdekében.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Az `Rc::from_raw(x_ptr)`-re történő további hívások memória-nem biztonságosak lennének.
    /// }
    ///
    /// // A memória felszabadult, amikor az `x` kiment a fenti hatókörből, így az `x_ptr` most lóg!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Fordítsa meg az eltolást az eredeti RcBox megtalálásához.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Új [`Weak`] mutatót hoz létre ehhez a hozzárendeléshez.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Ügyeljen arra, hogy ne hozzunk létre lógó gyengét
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Megkapja az [`Weak`] mutatók számát ehhez a hozzárendeléshez.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Megkapja az erős (`Rc`) mutatók számát ehhez a hozzárendeléshez.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Visszaadja az `true` értéket, ha nincs más `Rc` vagy [`Weak`] mutató ehhez a hozzárendeléshez.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Változtatható referenciát ad vissza az adott `Rc`-be, ha ugyanannak az allokációnak nincsenek más `Rc` vagy [`Weak`] mutatói.
    ///
    ///
    /// Ellenkező esetben az [`None`] értéket adja vissza, mert nem biztonságos egy megosztott érték mutációja.
    ///
    /// Lásd még: [`make_mut`][make_mut], amely [`clone`][clone] a belső értéket, ha más mutatók vannak.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Változtatható referenciát ad vissza az adott `Rc`-be, minden ellenőrzés nélkül.
    ///
    /// Lásd még az [`get_mut`]-et, amely biztonságos és megfelelő ellenőrzéseket végez.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Az ugyanazon felosztáshoz tartozó bármely más `Rc` vagy [`Weak`] mutatót a visszafizetett kölcsön időtartama alatt nem szabad alacsonynak levonni.
    ///
    /// Ez triviálisan így van, ha nincs ilyen mutató, például közvetlenül az `Rc::new` után.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Figyelünk arra, hogy *ne* hozzunk létre egy referenciát, amely lefedi az "count" mezőket, mivel ez ütközne a referenciaszámokhoz való hozzáféréssel (pl.
        // `Weak` által).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Visszaadja az `true` értéket, ha a két "Rc" ugyanazon allokációra mutat (az [`ptr::eq`]-hez hasonló vénában).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Változtatható hivatkozást tesz az adott `Rc`-re.
    ///
    /// Ha más `Rc` mutatók vannak ugyanahhoz a hozzárendeléshez, akkor az `make_mut` [`clone`] az új allokáció belső értékét az egyedi tulajdonjog biztosítása érdekében.
    /// Ezt nevezzük klón-írásra is.
    ///
    /// Ha nincs további `Rc` mutató ehhez a hozzárendeléshez, akkor az ehhez az allokációhoz tartozó [`Weak`] mutatók szét lesznek kapcsolva.
    ///
    /// Lásd még az [`get_mut`]-et, amely a klónozás helyett nem fog sikerülni.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Nem klónoz semmit
    /// let mut other_data = Rc::clone(&data);    // Nem klónozom a belső adatokat
    /// *Rc::make_mut(&mut data) += 1;        // Klónozza a belső adatokat
    /// *Rc::make_mut(&mut data) += 1;        // Nem klónoz semmit
    /// *Rc::make_mut(&mut other_data) *= 2;  // Nem klónoz semmit
    ///
    /// // Most az `data` és az `other_data` különböző kiosztásokra mutat.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] a mutatók el lesznek választva:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Klónozni kell az adatokat, vannak más Rcs-k is.
            // Előre lefoglalja a memóriát, hogy lehetővé tegye a klónozott érték közvetlen megírását.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Csak ellophatja az adatokat, csak a Weaks van hátra
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Távolítsa el az implicit erős-gyenge ref-et (itt nem kell hamis gyengét készíteni-tudjuk, hogy más Weak is takaríthat nekünk)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Ez a bizonytalanság rendben van, mert garantáljuk, hogy a visszaadott mutató az egyetlen * mutató, amelyet valaha visszaadunk T-nek.
        // A referenciaszám garantáltan 1 lesz ezen a ponton, és megköveteltük, hogy maga az `Rc<T>` legyen `mut`, ezért az egyetlen lehetséges hivatkozást visszajuttatjuk az allokációra.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Megpróbálta az `Rc<dyn Any>`-et konkrét típusra lefokozni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Kioszt egy `RcBox<T>`-t, elegendő hellyel egy esetleg nem méretezett belső értékhez, ahol az érték elrendezéssel rendelkezik.
    ///
    /// Az `mem_to_rcbox` függvény meghívásra kerül az adatmutatóval, és vissza kell adnia egy (potenciálisan zsíros) mutatót az `RcBox<T>` számára.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Számítsa ki az elrendezést a megadott értékelrendezés segítségével.
        // Korábban az elrendezést az `&*(ptr as* const RcBox<T>)` kifejezésen számolták, de ez rosszul illesztett hivatkozást hozott létre (lásd: #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Kioszt egy `RcBox<T>`-t elegendő hellyel egy esetleg nem méretezett belső értékhez, ahol az érték elrendezése meg van adva, hibát adva, ha a felosztás nem sikerül.
    ///
    ///
    /// Az `mem_to_rcbox` függvény meghívásra kerül az adatmutatóval, és vissza kell adnia egy (potenciálisan zsíros) mutatót az `RcBox<T>` számára.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Számítsa ki az elrendezést a megadott értékelrendezés segítségével.
        // Korábban az elrendezést az `&*(ptr as* const RcBox<T>)` kifejezésen számolták, de ez rosszul illesztett hivatkozást hozott létre (lásd: #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Kiosztás az elrendezéshez.
        let ptr = allocate(layout)?;

        // Inicializálja az RcBox-ot
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Kioszt egy `RcBox<T>`-et, elegendő hellyel a méret nélküli belső értékhez
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Rendeljen az `RcBox<T>`-hez a megadott érték felhasználásával.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Érték másolása bájtként
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Ingyenes kiosztás a tartalom eldobása nélkül
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Kioszt egy `RcBox<[T]>`-et a megadott hosszúsággal.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Elemek másolása a szeletből az újonnan kiosztott Rc <\[T\]>-be
    ///
    /// Nem biztonságos, mert a hívónak vagy tulajdonjogot kell vállalnia, vagy köteleznie kell az `T: Copy`-et
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// `Rc<[T]>`-et készít egy ismert méretű iterátorról.
    ///
    /// A viselkedés nincs meghatározva, ha a méret nem megfelelő.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic védelem T elemek klónozása közben.
        // panic esetén az új RcBoxba írt elemek eldobódnak, majd felszabadul a memória.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Mutató az első elemhez
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Minden tiszta.Felejtse el az őrséget, hogy ne szabadítsa fel az új RcBox-ot.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Az `From<&[T]>`-hez használt trait specializáció.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Dobja el az `Rc`-et.
    ///
    /// Ez csökkenti az erős referenciaszámot.
    /// Ha az erős referenciaszám eléri a nullát, akkor az egyetlen referencia (ha van ilyen) [`Weak`], tehát `drop` a belső érték.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Nem nyomtat semmit
    /// drop(foo2);   // "dropped!" nyomtatása
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // elpusztítani a zárt tárgyat
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // távolítsa el az implicit "strong weak" mutatót, miután megsemmisítettük a tartalmát.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Klónot készít az `Rc` mutatóból.
    ///
    /// Ez újabb mutatót hoz létre ugyanahhoz a felosztáshoz, növelve az erős referenciaszámot.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Új `Rc<T>`-t hoz létre az `T` `Default` értékével.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack engedélyezze az `Eq` szakosodását, annak ellenére, hogy az `Eq` rendelkezik módszerrel.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Ezt a specializációt itt végezzük, és nem általánosabb optimalizálásként az `&T`-en, mert különben költséget jelentene a referenciák minden egyenlőség-ellenőrzésében.
/// Feltételezzük, hogy az "Rc"-eket nagy értékek tárolására használják, amelyek lassan klónozódnak, de nehézek az egyenlőség ellenőrzése érdekében is, ami miatt ez a költség könnyebben megtérül.
///
/// Valószínűbb, hogy két `Rc` klónja van, amelyek ugyanarra az értékre mutatnak, mint két "&T".
///
/// Csak akkor tudjuk ezt megtenni, ha az `T: Eq` mint `PartialEq` szándékosan nem reflektív lehet.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Két "Rc" egyenlősége.
    ///
    /// Két "Rc" akkor egyenlő, ha belső értéke megegyezik, még akkor is, ha különböző elosztásban vannak tárolva.
    ///
    /// Ha az `T` az `Eq`-et is megvalósítja (ami az egyenlőség reflexivitását jelenti), két ugyanazon allokációra mutató "Rc" mindig egyenlő.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Két "Rc" egyenlőtlensége.
    ///
    /// Két "Rc" egyenlőtlen, ha belső értéke egyenlőtlen.
    ///
    /// Ha az `T` végrehajtja az `Eq`-et is (ami az egyenlőség reflexivitását jelenti), akkor két, ugyanazon allokációra mutató "Rc" soha nem egyenlőtlen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Részleges összehasonlítás két "Rc"-hez.
    ///
    /// A kettőt úgy hasonlítják össze, hogy az `partial_cmp()`-et hívják belső értékeikre.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Kevesebb, mint két "Rc" összehasonlítása.
    ///
    /// A kettőt úgy hasonlítják össze, hogy az `<`-et hívják belső értékeikre.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// "Kevesebb vagy egyenlő" összehasonlítás két "Rc" esetében.
    ///
    /// A kettőt úgy hasonlítják össze, hogy az `<=`-et hívják belső értékeikre.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Nagyobb, mint két "Rc" összehasonlítása.
    ///
    /// A kettőt úgy hasonlítják össze, hogy az `>`-et hívják belső értékeikre.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// "Nagyobb vagy egyenlő" összehasonlítás két "Rc" esetén.
    ///
    /// A kettőt úgy hasonlítják össze, hogy az `>=`-et hívják belső értékeikre.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Két "Rc" összehasonlítása.
    ///
    /// A kettőt úgy hasonlítják össze, hogy az `cmp()`-et hívják belső értékeikre.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Jelöljön ki egy referenciával megszámlált szeletet, és töltse ki a " v` elemek klónozásával.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Jelöljön ki egy hivatkozással megszámlált karakterlánc-szeletet, és másolja bele az `v`-et.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Jelöljön ki egy hivatkozással megszámlált karakterlánc-szeletet, és másolja bele az `v`-et.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Dobozos objektumot helyezzen át egy új, referenciaszámú kiosztásba.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Jelöljön ki egy referenciával megszámlált szeletet, és helyezze bele a `v` elemeket.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Hagyja, hogy a Vec felszabadítsa memóriáját, de ne rontsa el annak tartalmát
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Minden elemet felvesz az `Iterator`-be és összegyűjti egy `Rc<[T]>`-be.
    ///
    /// # Teljesítmény jellemzők
    ///
    /// ## Az általános eset
    ///
    /// Általános esetben az `Rc<[T]>`-be történő gyűjtést úgy végezzük, hogy először `Vec<T>`-be gyűjtjük.Vagyis a következő írásakor:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ez úgy viselkedik, mintha azt írtuk volna:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Az első kiosztási készlet itt történik.
    ///     .into(); // Itt történik az `Rc<[T]>` második kiosztása.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Ez annyiszor fog kiosztani, amennyi az `Vec<T>` elkészítéséhez szükséges, majd egyszer kiosztja az `Vec<T>` átalakítását az `Rc<[T]>`-be.
    ///
    ///
    /// ## Ismert hosszúságú iterátorok
    ///
    /// Amikor az `Iterator` az `TrustedLen`-et valósítja meg és pontos mérete van, akkor az `Rc<[T]>`-hez egyetlen elosztást kell végezni.Például:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Itt csak egyetlen kiosztás történik.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// A trait specializáció az `Rc<[T]>`-be történő gyűjtéshez.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Ez a helyzet az `TrustedLen` iterátor esetében.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // BIZTONSÁG: Biztosítanunk kell, hogy az iterátor pontos hosszúságú legyen és mi is.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Vissza a normál megvalósításhoz.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` az [`Rc`] olyan verziója, amely nem tulajdonosi hivatkozást tartalmaz a felügyelt allokációra.A kiosztáshoz úgy kell hozzáférni, hogy felhívja az [`upgrade`]-et az `Weak` mutatóra, amely egy ["Option"] "<" ["Rc"] értéket ad vissza.<T>> `.
///
/// Mivel egy `Weak` referencia nem számít bele a tulajdonjogba, nem akadályozza meg a kiosztásban tárolt érték elvetését, és maga az `Weak` sem vállal garanciát a még mindig jelen lévő értékre.
/// Így visszaadhatja az [`None`]-et, amikor a [frissítés] d.
/// Ne feledje azonban, hogy az `Weak` referencia *nem* akadályozza meg magának a kiosztásnak (a háttértárnak) a felosztását.
///
/// Az `Weak` mutató hasznos az [`Rc`] által kezelt allokáció ideiglenes hivatkozásának megőrzéséhez anélkül, hogy megakadályozná annak belső értékének elesését.
/// Az [`Rc`] mutatók közötti körös hivatkozások megakadályozására is használják, mivel a kölcsönös tulajdonosi referenciák soha nem engednék el az [`Rc`] eldobását.
/// Például egy fának erős [`Rc`] mutatói lehetnek a szülői csomópontoktól a gyermekekig, az `Weak` mutatók pedig a gyerekektől a szülőkig.
///
/// Az `Weak` mutató beszerzésének tipikus módja az [`Rc::downgrade`] hívása.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Ez egy `NonNull`, amely lehetővé teszi az ilyen típusú fájlok méretének optimalizálását, de nem feltétlenül érvényes mutató.
    //
    // `Weak::new` ezt `usize::MAX`-re állítja, hogy ne kelljen helyet foglalnia a kupacon.
    // Ez nem olyan érték, amellyel valódi mutató valaha is rendelkezhet, mert az RcBox legalább 2-et igazít.
    // Ez csak akkor lehetséges, ha `T: Sized`;méret nélküli `T` soha nem lóg.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Új `Weak<T>`-et épít, memória lefoglalása nélkül.
    /// Az [`upgrade`] visszahívásakor a [`None`] értéket mindig megkapja.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Segítő típus, amely lehetővé teszi a referenciaszámokhoz való hozzáférést anélkül, hogy bármilyen állítást tenne az adatmezővel kapcsolatban.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Visszaad egy nyers mutatót az `T` objektumra, amelyre az `Weak<T>` mutat.
    ///
    /// A mutató csak akkor érvényes, ha van néhány erős hivatkozás.
    /// Előfordulhat, hogy a mutató függő, kiegyenlítetlen, vagy máskülönben [`null`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Mindkettő ugyanarra az objektumra mutat
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Az itteni erősek életben tartják, így mégis hozzáférhetünk az objektumhoz.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // De már nem.
    /// // Meg tudjuk csinálni az weak.as_ptr()-et, de a mutató elérése meghatározatlan viselkedéshez vezetne.
    /// // assert_eq! ("hello", nem biztonságos {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Ha a mutató lóg, közvetlenül visszaküldjük az őrszemet.
            // Ez nem lehet érvényes hasznos cím, mivel a hasznos teher legalább annyira igazodik, mint az RcBox (usize).
            ptr as *const T
        } else {
            // BIZTONSÁG: ha az is_dangling hamis értéket ad vissza, akkor a mutatóra le lehet vonni.
            // A hasznos teher ekkor csökkenhet, és meg kell őriznünk a származást, ezért használjon nyers mutató manipulációt.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Fogyasztja az `Weak<T>`-et, és nyers mutatóvá alakítja.
    ///
    /// Ez a gyenge mutatót nyers mutatóvá alakítja, miközben továbbra is megőrzi egy gyenge referencia tulajdonjogát (a gyenge számot ez a művelet nem módosítja).
    /// Az [`from_raw`] segítségével visszafordítható az `Weak<T>`-be.
    ///
    /// A mutató célpontjának elérésére ugyanazok a korlátozások vonatkoznak, mint az [`as_ptr`] esetében.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Az [`into_raw`] által korábban létrehozott nyers mutatót visszaállítja `Weak<T>`-be.
    ///
    /// Ezt fel lehet használni egy erős referencia biztonságos megszerzésére (az [`upgrade`] későbbi hívásával), vagy a gyenge számok elosztására az `Weak<T>` eldobásával.
    ///
    /// Egy gyenge referencia tulajdonjoga kell (az [`new`] által létrehozott mutatók kivételével, mivel ezek nem birtokolnak semmit; a módszer még mindig működik rajtuk).
    ///
    /// # Safety
    ///
    /// A mutatónak az [`into_raw`]-ből kell származnia, és továbbra is birtokolnia kell a gyenge referenciáját.
    ///
    /// Megengedett, hogy az erős szám 0 legyen a hívás idején.
    /// Mindazonáltal ez egy gyenge referencia tulajdonát képezi, amely jelenleg nyers mutatóként van ábrázolva (a gyenge számot ez a művelet nem módosítja), és ezért párosítani kell egy korábbi [`into_raw`] hívással.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Csökkentse az utolsó gyenge számot.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // A bemeneti mutató levezetésének módját lásd az Weak::as_ptr kontextusban.

        let ptr = if is_dangling(ptr as *mut T) {
            // Ez egy lógó Gyenge.
            ptr as *mut RcBox<T>
        } else {
            // Ellenkező esetben garantáljuk, hogy a mutató egy gátlástalan Gyenge volt.
            // BIZTONSÁG: Az data_offset biztonságosan hívható, mivel a ptr egy valós (potenciálisan elesett) T-re hivatkozik.
            let offset = unsafe { data_offset(ptr) };
            // Így megfordítjuk az eltolást, hogy megkapjuk az egész RcBox-ot.
            // BIZTONSÁG: a mutató gyenge pontból származik, így ez az eltolás biztonságos.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // BIZTONSÁG: Most visszaállítottuk az eredeti Gyenge mutatót, így létrehozhatjuk a Gyenge pontot.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Megpróbálja frissíteni az `Weak` mutatót [`Rc`]-re, és sikeresen késlelteti a belső érték eldobását.
    ///
    ///
    /// [`None`] értéket ad vissza, ha a belső érték azóta leesett.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Pusztítson el minden erős mutatót.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Megkapja az erre a kiosztásra mutató erős (`Rc`) mutatók számát.
    ///
    /// Ha az `self` az [`Weak::new`] használatával jött létre, akkor ez 0-t ad vissza.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Megkapja az erre a kiosztásra mutató `Weak` mutatók számát.
    ///
    /// Ha nem marad erős mutató, akkor ez nullát ad vissza.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // vonja le az implicit gyenge ptr-t
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Az `None` értéket adja vissza, amikor a mutató csüng, és nincs kiosztva az `RcBox` (azaz amikor ezt az `Weak`-et az `Weak::new` hozta létre).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Figyelünk arra, hogy *ne* hozzunk létre egy referenciát, amely lefedi az "data" mezőt, mivel a mező egyidejűleg mutálódhat (például ha az utolsó `Rc`-et eldobja, az adatmező helyben eldobódik).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Visszaadja az `true` értéket, ha a két "gyenge" ugyanazon allokációra mutat (hasonlóan az [`ptr::eq`]-hez), vagy ha mindkettő nem mutat semmiféle allokációt (mert az `Weak::new()`) segítségével jöttek létre.
    ///
    ///
    /// # Notes
    ///
    /// Mivel ez összehasonlítja a mutatókat, ez azt jelenti, hogy az `Weak::new()` egyenlő lesz egymással, annak ellenére, hogy nem utalnak semmilyen kiosztásra.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Az `Weak::new` összehasonlítása.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Eldobja az `Weak` mutatót.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Nem nyomtat semmit
    /// drop(foo);        // "dropped!" nyomtatása
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // a gyenge számolás 1-nél kezdődik, és csak akkor megy nullára, ha az összes erős mutató eltűnt.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Az `Weak` mutató klónját készíti, amely ugyanarra a kiosztásra mutat.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Új `Weak<T>`-et állít elő, memóriát oszt ki az `T` számára inicializálás nélkül.
    /// Az [`upgrade`] visszahívásakor a [`None`] értéket mindig megkapja.
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Itt ellenőriztük a_add-ot, hogy biztonságosan kezeljük az mem::forget-et.Különösen
// ha mem::forget Rcs-t (vagy Weaks-t) használ, akkor a ref-count túlcsordulhat, és akkor felszabadíthatja a kiosztást, amíg a kiemelkedő Rcs (vagy Weaks) létezik.
//
// Megszakítjuk, mert ez olyan degenerált forgatókönyv, hogy nem érdekel, hogy mi történik-egyetlen valódi programnak sem szabad ezt soha megtapasztalnia.
//
// Ennek elenyésző költségekkel kell rendelkeznie, mivel tulajdonképpen és a lépés-szemantikának köszönhetően nem kell ennyit klónoznia a Rust-ben.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // A túlcsordulásnál meg akarunk szakítani az érték elvetése helyett.
        // A referenciaszám soha nem lesz nulla, amikor ezt meghívják;
        // ennek ellenére megszakítással illesztjük ide az LLVM-et az egyébként elmulasztott optimalizálásra.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // A túlcsordulásnál meg akarunk szakítani az érték elvetése helyett.
        // A referenciaszám soha nem lesz nulla, amikor ezt meghívják;
        // ennek ellenére megszakítással illesztjük ide az LLVM-et az egyébként elmulasztott optimalizálásra.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Szerezze meg az eltolást az `RcBox`-en belül a mutató mögött lévő hasznos teherért.
///
/// # Safety
///
/// A mutatónak egy korábban érvényes T példányra kell mutatnia (és érvényes metaadatokkal kell rendelkeznie), de a T eldobható.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Igazítsa a nem méretezett értéket az RcBox végéhez.
    // Mivel az RcBox repr(C), mindig a memória utolsó mezője lesz.
    // BIZTONSÁG: mivel az egyetlen nem méretezett típus a szelet, a trait objektum,
    // és külső típusok esetén a bemeneti biztonsági követelmény jelenleg elegendő az align_of_val_raw követelményeinek kielégítésére;ez a nyelv olyan megvalósítási részlete, amelyre a std kívül nem lehet hivatkozni.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}