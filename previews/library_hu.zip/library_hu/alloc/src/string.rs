//! UTF-8 kódolású, növekvő karakterlánc.
//!
//! Ez a modul tartalmazza az [`String`] típust, az [`ToString`] trait karakterláncokká való konvertálást, és számos hibatípust, amelyek a [`String`] ek használatából eredhetnek.
//!
//!
//! # Examples
//!
//! Többféle módon hozhat létre új [`String`] karakterláncból:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Létrehozhat egy új [`String`]-et egy összefűzéssel
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Ha van érvényes 0vector UTF-8 bájtja, akkor [`String`]-et készíthet belőle.Megteheti fordítva is.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Tudjuk, hogy ezek a bájtok érvényesek, ezért az `unwrap()`-et fogjuk használni.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// UTF-8 kódolású, növekvő karakterlánc.
///
/// Az `String` típus a leggyakoribb karakterlánc-típus, amely tulajdonjoggal rendelkezik a karakterlánc tartalmával kapcsolatban.Szoros kapcsolatban áll kölcsönvett társával, a primitív [`str`]-szel.
///
/// # Examples
///
/// Hozhat létre `String`-et [a literal string][`str`]-ből az [`String::from`]-mel:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Az [`char`]-et hozzáfűzheti az `String`-hez az [`push`] módszerrel, és az [`&str`]-et az [`push_str`] módszerrel:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Ha van vector UTF-8 bájt, akkor létrehozhat belőle egy `String`-et az [`from_utf8`] módszerrel:
///
/// ```
/// // néhány bájt, egy vektorban
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Tudjuk, hogy ezek a bájtok érvényesek, ezért az `unwrap()`-et fogjuk használni.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// A karakterláncok mindig érvényesek UTF-8.Ennek néhány következménye van, amelyek közül az első az, hogy ha nem UTF-8 karakterláncra van szüksége, fontolja meg az [`OsString`] parancsot.Hasonló, de az UTF-8 kényszer nélkül.A második következmény az, hogy nem lehet indexelni egy `String`-be:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Az indexelést állandó idejű műveletnek szánják, de az UTF-8 kódolás ezt nem teszi lehetővé.Továbbá nem világos, hogy az indexnek miféle dolgot kell visszaadnia: bájtot, kódpontot vagy grafémfürtöt.
/// Az [`bytes`] és az [`chars`] módszer az első kettő felett adja vissza az iterátorokat.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `A karakterlánc implementálja a` `Deref`]-t<Target=str>", és így örökli [[str`] összes metódusát.Ez azt is jelenti, hogy egy (`&`) jelet használva átadhat egy `String`-et egy olyan funkciónak, amely [`&str`]-et vesz fel:
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Ez létrehoz egy [`&str`]-et az `String`-ből, és továbbítja azt. Ez az átalakítás nagyon olcsó, és ezért általában a függvények elfogadják argumentumként a [`&str`-eket), hacsak valamilyen konkrét okból nincs szükségük `String`-re.
///
/// Bizonyos esetekben a Rust nem rendelkezik elegendő információval az [`Deref`] kényszer néven ismert konverzió végrehajtásához.A következő példában egy [`&'a str`][`&str`] karakterlánc-szelet hajtja végre a trait `TraitExample`-et, az `example_func` függvény pedig mindent, ami megvalósítja a trait-t.
/// Ebben az esetben a Rust-nek két implicit konverziót kell végrehajtania, amihez a Rust-nek nincs módja.
/// Ezért a következő példa nem áll össze.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Kétféle lehetőség működik.Az első az `example_func(&example_string);` sor megváltoztatása `example_func(example_string.as_str());`-re, az [`as_str()`] módszer segítségével kifejezetten kibontjuk a húrot tartalmazó sztringszeletet.
/// A második út `example_func(&example_string);`-et `example_func(&*example_string);`-re változtatja.
/// Ebben az esetben egy `String`-et és egy [`str`][`&str`]-t vonunk le, majd az [`str`][`&str`]-et visszahelyezzük az [`&str`]-re.
/// A második mód sokkal idiomatikusabb, azonban mindkettő kifejezetten az átalakításon dolgozik, nem pedig az implicit átalakításra támaszkodik.
///
/// # Representation
///
/// Az `String` három alkatrészből áll: egy mutató néhány bájthoz, egy hosszúság és egy kapacitás.A mutató egy belső pufferre mutat, amelyet az `String` használ az adatok tárolására.A hossza a pufferben tárolt bájtok száma, a kapacitás pedig a bájtokban lévő puffer nagysága.
///
/// Mint ilyen, a hossz mindig kisebb vagy egyenlő a kapacitással.
///
/// Ez a puffer mindig a kupacban van tárolva.
///
/// Ezeket az [`as_ptr`], [`len`] és [`capacity`] módszerekkel tekintheti meg:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Frissítse ezt, ha a vec_into_raw_parts stabilizálódik.
/// // A karakterlánc adatainak automatikus eldobásának megakadályozása
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // a történet tizenkilenc bájttal rendelkezik
/// assert_eq!(19, len);
///
/// // Újra felépíthetünk egy String-et a ptr, a len és a kapacitásból.
/// // Ez mind nem biztonságos, mert felelősek vagyunk azért, hogy az alkatrészek érvényesek legyenek:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Ha egy `String` elegendő kapacitással rendelkezik, az elemek hozzáadása nem osztja fel újra.Fontolja meg például ezt a programot:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Ez a következőket eredményezi:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Eleinte egyáltalán nincs lefoglalt memóriánk, de ahogy hozzáfűzünk a karaktersorozathoz, az megfelelően növeli a kapacitását.Ha ehelyett az [`with_capacity`] módszert alkalmazzuk a megfelelő kapacitás felosztásához kezdetben:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Végül más kimenettel rendelkezünk:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Itt nincs szükség több memória lefoglalására a hurokban.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Egy lehetséges hibaérték egy `String` konvertálásakor egy UTF-8 bájtból vector.
///
/// Ez a típus az [`from_utf8`] módszer hibatípusa az [`String`] rendszeren.
/// Úgy lett megtervezve, hogy gondosan elkerülje az átcsoportosításokat: az [`into_bytes`] módszer visszaadja a konverziós kísérlet során használt vector bájtot.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Az [`std::str`] által biztosított [`Utf8Error`] típus hibát jelent, amely akkor fordulhat elő, amikor az ["u8" s szeletet [`&str`]-be konvertálja.
/// Ebben az értelemben az `FromUtf8Error` analógja, és az `FromUtf8Error`-ből az [`utf8_error`] módszerrel juthat hozzá.
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Alapvető használat:
///
/// ```
/// // néhány érvénytelen bájt, egy vector-ben
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Lehetséges hibaérték egy `String` átalakításakor egy UTF-16 bájtos szeletből.
///
/// Ez a típus az [`from_utf16`] módszer hibatípusa az [`String`] rendszeren.
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Alapvető használat:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Létrehoz egy új üres `String`-et.
    ///
    /// Tekintettel arra, hogy az `String` üres, ez nem oszt ki kezdeti puffert.Bár ez azt jelenti, hogy ez a kezdeti művelet nagyon olcsó, az adatok hozzáadásakor később túlzott allokációt okozhat.
    ///
    /// Ha van elképzelése arról, hogy az `String` mennyi adatot fog tárolni, fontolja meg az [`with_capacity`] módszert a túlzott újraelosztás megakadályozása érdekében.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Létrehoz egy új üres `String`-et egy adott kapacitással.
    ///
    /// A "String" belső pufferrel rendelkezik az adatok tárolására.
    /// A kapacitás az adott puffer hossza, és lekérdezhető az [`capacity`] módszerrel.
    /// Ez a módszer létrehoz egy üres `String`-et, de egy kezdeti pufferrel, amely `capacity` bájtokat képes tárolni.
    /// Ez akkor hasznos, ha egy csomó adatot csatol az `String`-hez, ezzel csökkentve az átcsoportosítások számát.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Ha az adott kapacitás `0`, akkor nem történik allokáció, és ez a módszer megegyezik az [`new`] módszerrel.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // A karakterlánc nem tartalmaz karaktereket, pedig többre képes
    /// assert_eq!(s.len(), 0);
    ///
    /// // Ezeket mind újraosztás nélkül végezzük ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... de ettől a húr átcsoportosítható
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): cfg(test) esetén a benne rejlő `[T]::to_vec` módszer, amely ehhez a módszer meghatározásához szükséges, nem áll rendelkezésre.
    // Mivel tesztelési célokra nincs szükségünk erre a módszerre, csak elcsúfítom. További információkért lásd az slice.rs slice::hack modulját
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Átalakítja a bájtok vektorát-ból `String`-be.
    ///
    /// Az ([`String`]) húr ([`u8`]) bájtokból, az ([`Vec<u8>`]) bájtokból pedig egy vektor bájtokból áll, így ez a függvény a kettő között konvertálódik.
    /// Nem minden bájt szelet érvényes "String", azonban: az `String` megköveteli, hogy érvényes UTF-8 legyen.
    /// `from_utf8()` ellenőrzi, hogy a bájtok érvényesek-e az UTF-8-en, majd elvégzi az átalakítást.
    ///
    /// Ha biztos abban, hogy a bájt szelet érvényes UTF-8, és nem akarja az érvényességi ellenőrzés költségeit felvenni, akkor ennek a funkciónak az [`from_utf8_unchecked`] nem biztonságos verziója van, amely ugyanolyan viselkedéssel rendelkezik, de kihagyja az ellenőrzést.
    ///
    ///
    /// Ez a módszer a hatékonyság érdekében gondoskodik arról, hogy ne másolja le a vector-t.
    ///
    /// Ha `String` helyett [`&str`]-re van szüksége, fontolja meg az [`str::from_utf8`]-et.
    ///
    /// Ennek a módszernek az inverze [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Visszaadja az [`Err`] értéket, ha a szelet nem UTF-8, azzal a leírással, hogy a megadott bájt miért nem UTF-8.A beköltözött vector szintén benne van.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// // néhány bájt, egy vektorban
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Tudjuk, hogy ezek a bájtok érvényesek, ezért az `unwrap()`-et fogjuk használni.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Helytelen bájtok:
    ///
    /// ```
    /// // néhány érvénytelen bájt, egy vector-ben
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Az ezzel a hibával kapcsolatos további részletekért tekintse meg az [`FromUtf8Error`] dokumentumait.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// A bájtszeletet karakterlánccá alakítja, beleértve az érvénytelen karaktereket is.
    ///
    /// A húrok ([`u8`]) bájtokból, az ([`&[u8]`][byteslice]) bájtok pedig bájtokból készülnek, így ez a függvény átalakul a kettő között.Nem minden bájtos szelet érvényes karakterlánc, azonban a karakterláncoknak érvényes UTF-8-nek kell lenniük.
    /// A konverzió során az `from_utf8_lossy()` az érvénytelen UTF-8 szekvenciákat [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]-re cseréli, amely így néz ki:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Ha biztos abban, hogy a bájt szelet érvényes UTF-8, és nem akarja az átalakítás általános költségeit felvenni, akkor ennek a funkciónak az [`from_utf8_unchecked`] nem biztonságos verziója van, amely ugyanolyan viselkedéssel rendelkezik, de kihagyja az ellenőrzéseket.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Ez a függvény [`Cow<'a, str>`]-et ad vissza.Ha a bájt szeletünk érvénytelen UTF-8, akkor be kell illesztenünk a helyettesítő karaktereket, amelyek megváltoztatják a karakterlánc méretét, és ezért `String`-t igényelnek.
    /// De ha már érvényes UTF-8, akkor nincs szükségünk új kiosztásra.
    /// Ez a visszatérési típus lehetővé teszi számunkra, hogy mindkét esetet kezeljük.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// // néhány bájt, egy vektorban
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Helytelen bájtok:
    ///
    /// ```
    /// // néhány érvénytelen bájt
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Dekódoljon egy UTF-16 kódolású vector `v` kódot `String`-be, és [`Err`]-t ad vissza, ha az `v` érvénytelen adatokat tartalmaz.
    ///
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Ez nem a következő helyen történik: <Result<_, _>> () teljesítmény okokból.
        // FIXME: a funkció ismét egyszerűsíthető, ha az #48994 zárva van.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Dekódoljon egy UTF-16 kódolt `v` szeletet `String`-be, érvénytelen adatokat cseréljen le [the replacement character (`U+FFFD`)][U+FFFD]-re.
    ///
    /// Az [`from_utf8_lossy`]-től eltérően, amely [`Cow<'a, str>`]-t ad vissza, az `from_utf16_lossy` `String`-et ad vissza, mivel az UTF-16-UTF-8 konverzióhoz memóriafoglalás szükséges.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Bontja az `String`-et a nyers komponenseire.
    ///
    /// Visszaadja a nyers mutatót az alapul szolgáló adatokhoz, a karakterlánc hosszához (bájtban) és az adatokhoz rendelt kapacitáshoz (bájtokban).
    /// Ezek ugyanazok az argumentumok ugyanabban a sorrendben, mint az [`from_raw_parts`] argumentumai.
    ///
    /// A funkció hívása után a hívó felelős az `String` által korábban kezelt memóriáért.
    /// Ennek egyetlen módja az, hogy a nyers mutatót, hosszúságot és kapacitást visszaállítja `String`-be az [`from_raw_parts`] funkcióval, lehetővé téve a romboló számára a tisztítást.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Új `String`-et hoz létre hosszúságból, kapacitásból és mutatóból.
    ///
    /// # Safety
    ///
    /// Ez nagyon nem biztonságos, az ellenőrizetlenek száma miatt, amelyeket nem ellenőriznek:
    ///
    /// * Az `buf` memóriáját ugyanazon lefoglalónak kell elosztania, amelyet a szokásos könyvtár használ, pontosan 1 előírt igazítással.
    /// * `length` kisebbnek vagy egyenlőnek kell lennie, mint `capacity`.
    /// * `capacity` a helyes értéknek kell lennie.
    /// * Az `buf` első `length` bájtjának érvényes UTF-8-nek kell lennie.
    ///
    /// Ezek megsértése olyan problémákat okozhat, mint például az elosztó belső adatstruktúráinak megrongálása.
    ///
    /// Az `buf` tulajdonjogát tulajdonképpen átruházzák az `String`-re, amely ezt követően eloszthatja, átcsoportosíthatja vagy megváltoztathatja a mutató által mutatott memória tartalmát.
    /// Győződjön meg róla, hogy semmi más nem használja a mutatót a funkció meghívása után.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Frissítse ezt, ha a vec_into_raw_parts stabilizálódik.
    ///     // A karakterlánc adatainak automatikus eldobásának megakadályozása
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// A bájtok vector-jét átalakítja `String`-be, anélkül, hogy ellenőrizné, hogy a karakterlánc érvényes UTF-8-et tartalmaz-e.
    ///
    /// További részletekért tekintse meg az [`from_utf8`] biztonságos verzióját.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Ez a funkció nem biztonságos, mert nem ellenőrzi, hogy a neki átadott bájtok érvényesek-e UTF-8.
    /// Ha ezt a korlátozást megsértik, memóriabiztonsági problémákat okozhat az `String` future felhasználói számára, mivel a szabványos könyvtár többi része feltételezi, hogy a "String" érvényes UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// // néhány bájt, egy vektorban
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Az `String`-et átalakítja bájt vector-vé.
    ///
    /// Ez elfogyasztja az `String`-et, így nem kell lemásolnunk annak tartalmát.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Kivonat egy sztringszeletet, amely az egész `String`-et tartalmazza.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Az `String` átalakítható karakterlánc szeletté alakítja.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Adott karakterlánc-szeletet csatol az `String` végéhez.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Visszaadja a `String` kapacitását bájtban.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Biztosítja, hogy ennek a " Stringnek` a kapacitása legalább `additional` bájttal nagyobb legyen, mint a hossza.
    ///
    /// A kapacitás több mint `additional` bájttal növelhető, ha úgy dönt, hogy megakadályozza a gyakori átcsoportosításokat.
    ///
    ///
    /// Ha nem akarja ezt az "at least" viselkedést, olvassa el az [`reserve_exact`] módszert.
    ///
    /// # Panics
    ///
    /// Panics, ha az új kapacitás túlcsordítja az [`usize`]-et.
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Ez valójában nem növelheti a kapacitást:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s hossza most 2, kapacitása 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Mivel már van extra 8 kapacitásunk, ezt hívjuk ...
    /// s.reserve(8);
    ///
    /// // ... valójában nem növekszik.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Biztosítja, hogy a `String` kapacitása `additional` bájttal nagyobb legyen, mint a hossza.
    ///
    /// Fontolja meg az [`reserve`] módszer használatát, hacsak nem tud jobban, mint az allokátor.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics, ha az új kapacitás túlcsordítja az `usize`-et.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Ez valójában nem növelheti a kapacitást:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s hossza most 2, kapacitása 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Mivel már van extra 8 kapacitásunk, ezt hívjuk ...
    /// s.reserve_exact(8);
    ///
    /// // ... valójában nem növekszik.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Megpróbálja lefoglalni a kapacitást legalább `additional` további elem beszúrására az adott `String`-be.
    /// A gyűjtemény több helyet foglalhat el a gyakori átcsoportosítások elkerülése érdekében.
    /// Az `reserve` hívása után a kapacitás nagyobb vagy egyenlő, mint `self.len() + additional`.
    /// Nem csinál semmit, ha a kapacitás már elegendő.
    ///
    /// # Errors
    ///
    /// Ha a kapacitás túlcsordul, vagy az allokátor hibáról számol be, akkor egy hiba jelenik meg.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Előre foglalja le a memóriát, ha nem tudunk, lépjen ki
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Most már tudjuk, hogy ez nem fordulhat elő összetett munkánk közepette
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Megpróbálja fenntartani a minimális kapacitást, hogy pontosan `additional` további elem kerüljön be az adott `String`-be.
    ///
    /// Az `reserve_exact` hívása után a kapacitás nagyobb vagy egyenlő, mint `self.len() + additional`.
    /// Nem csinál semmit, ha a kapacitás már elegendő.
    ///
    /// Vegye figyelembe, hogy az allokátor több helyet adhat a gyűjteménynek, mint amennyit igényel.
    /// Ezért nem lehet megbízni abban, hogy a kapacitás pontosan minimális.
    /// Inkább az `reserve`-et részesítse előnyben, ha future beillesztések várhatók.
    ///
    /// # Errors
    ///
    /// Ha a kapacitás túlcsordul, vagy az allokátor hibáról számol be, akkor egy hiba jelenik meg.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Előre foglalja le a memóriát, ha nem tudunk, lépjen ki
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Most már tudjuk, hogy ez nem fordulhat elő összetett munkánk közepette
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Csökkenti ennek az `String`-nek a kapacitását, hogy megfeleljen a hosszának.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Alacsonyabb határértékkel csökkenti ennek az `String`-nek a kapacitását.
    ///
    /// A kapacitás legalább akkora marad, mint a hossza és a szállított érték.
    ///
    ///
    /// Ha az áramkapacitás kisebb, mint az alsó határ, ez nem engedélyezhető.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Hozzáadja az adott [`char`]-et ennek az `String` végéhez.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// A `String` tartalmának egy bájtos szeletét adja vissza.
    ///
    /// Ennek a módszernek az inverze [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Rövidítse le ezt az `String`-et a megadott hosszúságra.
    ///
    /// Ha az `new_len` nagyobb, mint a karakterlánc aktuális hossza, ennek nincs hatása.
    ///
    ///
    /// Vegye figyelembe, hogy ez a módszer nincs hatással a karakterlánc kiosztott kapacitására
    ///
    /// # Panics
    ///
    /// Panics, ha az `new_len` nem az [`char`] határán fekszik.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Eltávolítja az utolsó karaktert a karakterlánc-pufferből és visszaadja.
    ///
    /// Az [`None`] értéket adja vissza, ha ez az `String` üres.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Eltávolít egy [`char`]-et ettől az `String`-től bájtban, és visszaadja.
    ///
    /// Ez egy *O*(*n*) művelet, mivel meg kell másolni a puffer minden elemét.
    ///
    /// # Panics
    ///
    /// Panics, ha az `idx` nagyobb vagy egyenlő a "String" hosszával, vagy ha nem az [`char`] határán fekszik.
    ///
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Távolítsa el az `pat` minta összes egyezését az `String` eszközből.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Az egyezéseket iteratív módon észlelik és eltávolítják, így azokban az esetekben, amikor a minták átfedik egymást, csak az első minta kerül eltávolításra:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // BIZTONSÁG: a kezdet és a vég az utf8 bájthatárokon lesz
        // a Searcher docs
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Csak az állítmány által megadott karaktereket tartja meg.
    ///
    /// Más szavakkal, távolítsa el az összes `c` karaktert, hogy az `f(c)` az `false` értéket adja vissza.
    /// Ez a módszer a helyén működik, minden karaktert pontosan egyszer látogat meg az eredeti sorrendben, és megőrzi a megtartott karakterek sorrendjét.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// A pontos sorrend hasznos lehet a külső állapot, például egy index nyomon követéséhez.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Mutasson idx-et a következő karakterre
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Karaktert illeszt be ebbe az `String`-ba bájtban.
    ///
    /// Ez egy *O*(*n*) művelet, mivel meg kell másolni a puffer minden elemét.
    ///
    /// # Panics
    ///
    /// Panics, ha az `idx` nagyobb, mint a " String` hossza, vagy ha nem az [`char`] határán fekszik.
    ///
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Karakterlánc szeletet illeszt be ebbe az `String` bájt pozícióba.
    ///
    /// Ez egy *O*(*n*) művelet, mivel meg kell másolni a puffer minden elemét.
    ///
    /// # Panics
    ///
    /// Panics, ha az `idx` nagyobb, mint a " String` hossza, vagy ha nem az [`char`] határán fekszik.
    ///
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Változtatható hivatkozást ad vissza az `String` tartalmára.
    ///
    /// # Safety
    ///
    /// Ez a funkció nem biztonságos, mert nem ellenőrzi, hogy a neki átadott bájtok érvényesek-e UTF-8.
    /// Ha ezt a korlátozást megsértik, memóriabiztonsági problémákat okozhat az `String` future felhasználói számára, mivel a szabványos könyvtár többi része feltételezi, hogy a "String" érvényes UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Visszaadja ennek az `String`-nek a hosszát bájtokban, nem [karakterek] vagy grafémák szerint.
    /// Más szavakkal, nem biztos, hogy az ember figyelembe veszi a húr hosszát.
    ///
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Visszaadja az `true` értéket, ha ennek az `String` hosszúsága nulla, és az `false` értéket különben adja meg.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// A karakterláncot ketté osztja az adott bájtindexnél.
    ///
    /// Visszaad egy újonnan kiosztott `String`-et.
    /// `self` `[0, at)`, a visszaadott `String` pedig `[at, len)` bájtokat tartalmaz.
    /// `at` UTF-8 kódpont határán kell lennie.
    ///
    /// Vegye figyelembe, hogy az `self` kapacitása nem változik.
    ///
    /// # Panics
    ///
    /// Panics, ha az `at` nincs az `UTF-8` kódpont határán, vagy ha túl van a karakterlánc utolsó kódpontján.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Megcsonkítja ezt az `String`-et, eltávolítva az összes tartalmat.
    ///
    /// Bár ez azt jelenti, hogy az `String` nulla lesz, nem érinti a kapacitását.
    ///
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Létrehoz egy leeresztő iterátort, amely eltávolítja az `String` meghatározott tartományát, és az eltávolított `chars`-et adja.
    ///
    ///
    /// Note: Az elemtartomány akkor is eltávolításra kerül, ha az iterátort nem fogyasztják a végéig.
    ///
    /// # Panics
    ///
    /// Panics, ha a kiindulási pont vagy a végpont nem egy [`char`] határon fekszik, vagy ha kívül esnek.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Távolítsa el a tartományt egészen a β-ig a húrból
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // A teljes tartomány törli a karakterláncot
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Memória biztonság
        //
        // A Drain karakterlánc-verziójának nincsenek a vector verzió memóriabiztonsági problémái.
        // Az adatok csak bájtok.
        // Mivel a tartomány eltávolítása a Drop-ban történik, ha a Drain iterátor kiszivárog, az eltávolítás nem fog megtörténni.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Vegyen fel két egyidejű hitelt.
        // Az &mut karakterlánc csak az iteráció végeztével érhető el a Drop fájlban.
        let self_ptr = self as *mut _;
        // BIZTONSÁG: Az `slice::range` és az `is_char_boundary` elvégzi a megfelelő határellenőrzéseket.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Eltávolítja a megadott tartományt a karakterláncból, és lecseréli a megadott karakterlánccal.
    /// A megadott karakterláncnak nem kell azonos hosszúságúnak lennie, mint a tartomány.
    ///
    /// # Panics
    ///
    /// Panics, ha a kiindulási pont vagy a végpont nem egy [`char`] határon fekszik, vagy ha kívül esnek.
    ///
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Cserélje ki a tartományt a karakterlánc β-ig
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Memória biztonság
        //
        // A Replace_range nem rendelkezik a vector Splice memóriabiztonsági problémáival.
        // a vector változat.Az adatok csak bájtok.

        // FIGYELMEZTETÉS: Ennek a változónak a beillesztése nem lenne megfelelő (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // FIGYELMEZTETÉS: Ennek a változónak a beillesztése nem lenne megfelelő (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Az `range` újbóli használata nem lenne jó (#81138) Feltételezzük, hogy az `range` által közölt határok ugyanazok maradnak, de a kontradiktórius végrehajtás megváltozhat a hívások között
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Ezt az `String`-et átalakítja egy ["dobozba"] "<" ["str"] ">.
    ///
    /// Ez csökkenti a felesleges kapacitást.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Visszaad egy szelet [[u8]] bájtot, amelyeket megpróbáltak átalakítani `String`-be.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// // néhány érvénytelen bájt, egy vector-ben
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Visszaadja az `String`-be konvertálni kívánt bájtokat.
    ///
    /// Ez a módszer gondosan van kialakítva az allokáció elkerülése érdekében.
    /// Fogyasztja a hibát, elmozdítva a bájtokat, így nincs szükség a bájtok másolatára.
    ///
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// // néhány érvénytelen bájt, egy vector-ben
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Hívjon egy `Utf8Error`-et, hogy további részleteket kapjon az átalakítási hibáról.
    ///
    /// Az [`std::str`] által biztosított [`Utf8Error`] típus hibát jelent, amely akkor fordulhat elő, amikor az ["u8" s szeletet [`&str`]-be konvertálja.
    /// Ebben az értelemben az `FromUtf8Error` analógja.
    /// A használatával kapcsolatban lásd a dokumentációját.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// // néhány érvénytelen bájt, egy vector-ben
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // az első bájt itt érvénytelen
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Mivel a `String`-eken keresztül ismétlünk, legalább egy allokációt elkerülhetünk, ha megszerezzük az első karakterláncot az iterátorból, és hozzáfűzzük az összes következő karakterláncot.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Mivel a CoW-okon keresztül ismétlünk, (potentially) elkerülhetjük legalább egy allokációt azáltal, hogy megszerezzük az első elemet, és hozzáfűzzük az összes következő elemet.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Kényelmi implikáció, amely az `&str` implicitjét delegálja.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Létrehoz egy üres `String`-et.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Két karakterlánc összefűzéséhez valósítja meg az `+` operátort.
///
/// Ez elfogyasztja az `String`-et a bal oldalon, és újra felhasználja a puffert (ha szükséges, növeli).
/// Ezzel elkerülhető az új `String` kiosztása és a teljes tartalom másolása minden műveletnél, ami *O*(*n*^ 2) futási időhöz vezetne, amikor egy *n* bájtos karakterláncot ismételt összefűzéssel építenek.
///
///
/// A jobb oldali húr csak kölcsönvett;tartalmát átmásolja a visszaküldött `String`-be.
///
/// # Examples
///
/// Két " húr` összefűzése az elsőt érték szerint veszi fel, a másodikat pedig kölcsön adja:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` áthelyezve, és itt már nem használható.
/// ```
///
/// Ha továbbra is használni akarja az első `String`-et, akkor klónozhatja és csatolhatja a klónhoz:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` itt is érvényes.
/// ```
///
/// Az `&str` szeletek összefűzése úgy történhet, hogy az elsőt átalakítjuk `String`-be:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Végrehajtja az `+=` operátort az `String`-hez való csatoláshoz.
///
/// Ennek ugyanaz a viselkedése, mint az [`push_str`][String::push_str] módszernek.
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Az [`Infallible`] típus álneve.
///
/// Ez az álnév a visszamenőleges kompatibilitás miatt létezik, és végül elavulhat.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// trait egy érték `String`-vé konvertálásához.
///
/// Ez a trait automatikusan megvalósul minden olyan típusnál, amely az [`Display`] trait-t valósítja meg.
/// Mint ilyen, az `ToString`-et nem szabad közvetlenül végrehajtani:
/// [`Display`] helyett inkább az `ToString` megvalósítást kapja meg.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// A megadott értéket átalakítja `String`-be.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// Ebben a megvalósításban az `to_string` módszer panics, ha az `Display` megvalósítás hibát ad vissza.
/// Ez helytelen `Display` implementációt jelez, mivel az `fmt::Write for String` soha nem ad vissza hibát.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Általános iránymutatás, hogy ne soroljuk be az általános funkciókat.
    // Az `#[inline]` eltávolítása ebből a módszerből azonban nem elhanyagolható regressziókat okoz.
    // Lásd: <https://github.com/rust-lang/rust/pull/74852>, az utolsó kísérlet az eltávolítására.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// `&mut str`-et átalakít `String`-be.
    ///
    /// Az eredmény kiosztásra kerül a kupacon.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: teszt behúzza a libstd-t, ami itt hibákat okoz
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// A megadott dobozos `str` szeletet átalakítja `String`-be.
    /// Figyelemre méltó, hogy az `str` szelet tulajdonosa.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Az adott `String`-et dobozos `str` szeletté alakítja, amely a tulajdonosa.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// A karakterlánc szeletet kölcsönzött változatgá alakítja.
    /// Halom kiosztás nem történik, és a karakterlánc nincs másolva.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// A karakterláncot saját tulajdonú változatgá alakítja.
    /// Halom kiosztás nem történik, és a karakterlánc nincs másolva.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// A String hivatkozást kölcsönzött változatgá alakítja.
    /// Halom kiosztás nem történik, és a karakterlánc nincs másolva.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Az adott `String`-et átalakítja egy vektor `Vec`-be, amely `u8` típusú értékeket tartalmaz.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Az `String` leeresztő iterátora.
///
/// Ezt a struktúrát az [`drain`] módszer hozza létre az [`String`] rendszeren.
/// További információt a dokumentációjában talál.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// &'Mut mutatott karakterláncként fogják használni a destruktorban
    string: *mut String,
    /// Az eltávolítandó rész kezdete
    start: usize,
    /// Az eltávolítandó rész vége
    end: usize,
    /// A jelenlegi hátralévő tartomány eltávolítandó
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Használja az Vec::drain-et.
            // "Reaffirm" a határok ellenőrzik annak elkerülését, hogy a panic kódot újra beszúrják.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Ennek az iterátornak a maradék (al) karakterláncát adja vissza szeletként.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: nem kommentálva Az AsRef a stabilizáláskor alább olvasható.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Kommentelés az `string_drain_as_str` stabilizálásakor.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>a Drain számára <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> a Drain esetén <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}