#![stable(feature = "rust1", since = "1.0.0")]

//! Menetbiztos referenciaszámláló mutatók.
//!
//! További részletekért lásd az [`Arc<T>`][Arc] dokumentációját.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Lágy korlátozás az `Arc`-re tehető hivatkozások mennyiségére vonatkozóan.
///
/// Ha meghaladja ezt a határt, megszakítja a programot (bár nem feltétlenül) az _exactly_ `MAX_REFCOUNT + 1` hivatkozásoknál.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// A ThreadSanitizer nem támogatja a memóriakerítéseket.
// A hamis pozitív jelentések elkerülése érdekében az Arc/Weak megvalósításban inkább atomterheléseket használjon a szinkronizáláshoz.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Menetbiztos referenciaszámláló mutató.Az 'Arc' jelentése " Atomically Reference Counted`.
///
/// Az `Arc<T>` típus megosztott tulajdonjogot biztosít a halomban kiosztott `T` típusú értékhez.Az [`clone`][clone] meghívása az `Arc` rendszerre egy új `Arc` példányt hoz létre, amely ugyanarra a felosztásra mutat a kupacban, mint az `Arc` forrás, ugyanakkor növeli a referenciaszámot.
/// Amikor egy adott kiosztás utolsó `Arc` mutatója megsemmisül, az abban a kiosztásban tárolt érték (gyakran "inner value" néven is) eldől.
///
/// A Rust megosztott hivatkozásai alapértelmezés szerint nem engedélyezik a mutációt, és az `Arc` sem kivétel: általában nem szerezhet módosítható hivatkozást valamire az `Arc`-en belül.Ha egy `Arc`-en keresztül kell mutálnia, használja az [`Mutex`][mutex], [`RwLock`][rwlock] vagy az [`Atomic`][atomic] típusok egyikét.
///
/// ## Menetbiztonság
///
/// Az [`Rc<T>`]-től eltérően az `Arc<T>` atomi műveleteket használ a referenciaszámláláshoz.Ez azt jelenti, hogy menetbiztos.Hátránya, hogy az atomi műveletek drágábbak, mint a szokásos memória-hozzáférések.Ha nem osztja meg a hivatkozásokkal megszámlált allokációkat a szálak között, fontolja meg az [`Rc<T>`] használatát az alacsonyabb rezsihez.
/// [`Rc<T>`] biztonságos alapértelmezés, mert a fordító minden kísérletet elkap egy [`Rc<T>`] küldésére a szálak között.
/// A könyvtár azonban az `Arc<T>` lehetőséget választja annak érdekében, hogy nagyobb rugalmasságot biztosítson a könyvtár fogyasztóinak.
///
/// `Arc<T>` mindaddig megvalósítja az [`Send`] és [`Sync`], amíg az `T` megvalósítja az [`Send`] és [`Sync`] eszközöket.
/// Miért nem lehet nem szálbiztos `T` típust elhelyezni az `Arc<T>`-ben, hogy szálbiztonságossá váljon?Ez elsőre kissé ellentmondásos lehet: végül is nem az `Arc<T>` menetbiztonság lényege?A legfontosabb ez: Az `Arc<T>` biztonságossá teszi a szálat, hogy ugyanazon adatok többszörös tulajdonjoggal rendelkezzenek, de nem növeli a szálbiztonságot az adataiban.
///
/// Tekintsük az `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] nem [`Sync`], és ha az `Arc<T>` mindig [`Send`] volt, akkor az "Arc <" [`RefCell<T>`]`>`is.
/// De akkor lenne egy problémánk:
/// [`RefCell<T>`] nem biztonságos a menet;nem atomi műveletek segítségével követi nyomon a hitelfelvétel számát.
///
/// Végül ez azt jelenti, hogy szükség lehet az `Arc<T>` párosítására valamilyen [`std::sync`] típusra, általában az [`Mutex<T>`][mutex]-re.
///
/// ## Ciklusok megszakítása az `Weak` segítségével
///
/// Az [`downgrade`][downgrade] módszerrel nem saját tulajdonú [`Weak`] mutató hozható létre.Az [`Weak`] mutató lehet [`upgrade`][upgrade] d `Arc`-re, de ez visszaadja [`None`]-et, ha a kiosztásban tárolt értéket már eldobták.
/// Más szavakkal, az `Weak` mutatók nem tartják életben az allokáción belüli értéket;azonban életben tartják a hozzárendelést (az érték háttértárát).
///
/// Az `Arc` mutatók közötti ciklust soha nem osztják fel.
/// Ezért az [`Weak`]-et a ciklusok megszakítására használják.Például egy fának erős `Arc` mutatói lehetnek a szülői csomópontoktól a gyermekekig, az [`Weak`] mutatók pedig a gyerekektől a szülőkig.
///
/// # Klónozási referenciák
///
/// Új referencia létrehozása egy meglévő referencia-számláló mutatóból az [`Arc<T>`][Arc] és [`Weak<T>`][Weak] esetén megvalósított `Clone` trait használatával történik.
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Az alábbi két szintaxis egyenértékű.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b és foo mind olyan ív, amely ugyanarra a memóriahelyre mutat
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` automatikusan elutasítja az `T`-et (az [`Deref`][deref] trait-en keresztül), így meghívhatja a `T` metódusait egy `Arc<T>` típusú értékre.A névütközések elkerülése érdekében a `T` metódusokkal, maga az `Arc<T>` metódusai társított függvények, az [fully qualified syntax] használatával hívják őket:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// Arc<T>A traits implementációi, például az `Clone`, teljesen minősített szintaxissal is meghívhatók.
/// Vannak, akik inkább a teljesen minősített szintaxist, míg mások a method-call szintaxist használják.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Method-call szintaxis
/// let arc2 = arc.clone();
/// // Teljesen képzett szintaxis
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] nem automatikusan hivatkozik az `T`-re, mert lehet, hogy a belső érték már leesett.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Néhány megváltoztathatatlan adat megosztása szálak között:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Ne feledje, hogy **nem** futtatjuk ezeket a teszteket itt.
// Az windows építők nagyon boldogtalanná válnak, ha egy szál túléli a fő szálat, majd egyszerre kilép (valami holtpontra jut), ezért ezt csak teljesen elkerüljük azzal, hogy nem futtatjuk ezeket a teszteket.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Változtatható [`AtomicUsize`] megosztása:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Lásd az [`rc` documentation][rc_examples]-et az általános referenciaszámlálás további példáihoz.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` az [`Arc`] olyan verziója, amely nem tulajdonosi hivatkozást tartalmaz a felügyelt allokációra.
/// A kiosztáshoz úgy kell hozzáférni, hogy felhívja az [`upgrade`]-et az `Weak` mutatóra, amely egy ["Option"] "<" ["Arc"] értéket ad vissza.<T>> `.
///
/// Mivel egy `Weak` referencia nem számít bele a tulajdonjogba, nem akadályozza meg a kiosztásban tárolt érték elvetését, és maga az `Weak` sem vállal garanciát a még mindig jelen lévő értékre.
///
/// Így visszaadhatja az [`None`]-et, amikor a [frissítés] d.
/// Ne feledje azonban, hogy az `Weak` referencia *nem* akadályozza meg magának a kiosztásnak (a háttértárnak) a felosztását.
///
/// Az `Weak` mutató hasznos az [`Arc`] által kezelt allokáció ideiglenes hivatkozásának megőrzéséhez anélkül, hogy megakadályozná annak belső értékének elesését.
/// Az [`Arc`] mutatók közötti körös hivatkozások megakadályozására is használják, mivel a kölcsönös tulajdonosi referenciák soha nem engednék el az [`Arc`] eldobását.
/// Például egy fának erős [`Arc`] mutatói lehetnek a szülői csomópontoktól a gyermekekig, az `Weak` mutatók pedig a gyerekektől a szülőkig.
///
/// Az `Weak` mutató beszerzésének tipikus módja az [`Arc::downgrade`] hívása.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Ez egy `NonNull`, amely lehetővé teszi az ilyen típusú fájlok méretének optimalizálását, de nem feltétlenül érvényes mutató.
    //
    // `Weak::new` ezt `usize::MAX`-re állítja, hogy ne kelljen helyet foglalnia a kupacon.
    // Ez nem olyan érték, amellyel valódi mutató valaha is rendelkezhet, mert az RcBox legalább 2-et igazít.
    // Ez csak akkor lehetséges, ha `T: Sized`;méret nélküli `T` soha nem lóg.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Ez repr(C)-től future-ig ellenálló az esetleges terepi átrendezéssel szemben, ami megzavarná a transzmutálható belső típusok egyébként biztonságos [into|from]_raw()-jét.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // az usize::MAX érték őrként szolgál az "locking" ideiglenes képességére a gyenge mutatók frissítésére vagy az erősek leminősítésére;ezt használják az `make_mut` és `get_mut` versenyek elkerülésére.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Új `Arc<T>`-et épít.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Indítsa el a gyenge mutatószámot 1-gyel, amely az összes erős mutató (kinda) gyenge mutatója, további információkért lásd: std/rc.rs
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Új `Arc<T>`-et készít, gyenge hivatkozással.
    /// Ha a függvény visszatérése előtt megpróbálja frissíteni a gyenge referenciát, az `None` értéket eredményez.
    /// A gyenge referencia azonban szabadon klónozható és tárolható későbbi felhasználás céljából.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Konstrukciója a belső "uninitialized" állapotban egyetlen gyenge referenciával.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Fontos, hogy ne adjuk fel a gyenge mutató tulajdonjogát, különben a memória felszabadulhat, mire az `data_fn` visszatér.
        // Ha valóban át akarjuk adni a tulajdonjogot, létrehozhatunk egy további gyenge mutatót magunknak, de ez további frissítéseket eredményez a gyenge referenciaszámhoz, amire egyébként nem lehet szükség.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Most megfelelően inicializálhatjuk a belső értéket, és gyenge referenciánkat erős referenciává alakíthatjuk.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Az adatmezőbe írt fenti írásnak láthatónak kell lennie minden olyan szál számára, amely nem nulla erős számolást követ.
            // Ezért legalább "Release" megrendelésre van szükségünk ahhoz, hogy szinkronizálhassunk az X0 `compare_exchange_weak`-szel az `Weak::upgrade`-ben.
            //
            // "Acquire" megrendelés nem szükséges.
            // Az `data_fn` lehetséges viselkedésének mérlegelésekor csak azt kell megvizsgálnunk, hogy mit tehetne egy nem frissíthető `Weak` hivatkozással:
            //
            // - *Klónozhatja* az `Weak`-et, növelve a gyenge referenciaszámot.
            // - Le tudja dobni ezeket a klónokat, csökkentve a gyenge referenciaszámot (de soha nem nullára).
            //
            // Ezek a mellékhatások semmilyen módon nem hatnak ránk, és csak a biztonságos kóddal más mellékhatások nem lehetségesek.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Az erős referenciáknak együttesen rendelkezniük kell egy megosztott gyenge referenciával, ezért ne futtassák a régi gyenge referenciánkat.
        //
        mem::forget(weak);
        strong
    }

    /// Új, nem inicializált tartalommal rendelkező `Arc` készül.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Halasztott inicializálás:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Új, nem inicializált tartalommal rendelkező `Arc`-et épít, a memóriát `0`-byte-ok töltik meg.
    ///
    ///
    /// Lásd az [`MaybeUninit::zeroed`][zeroed] példákat a módszer helyes és helytelen használatára.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Új `Pin<Arc<T>>`-et épít.
    /// Ha az `T` nem valósítja meg az `Unpin`-et, akkor az `data` rögzül a memóriában, és nem tudja áthelyezni.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Új `Arc<T>`-et készít, és hibát ad vissza, ha a kiosztás sikertelen.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Indítsa el a gyenge mutatószámot 1-gyel, amely az összes erős mutató (kinda) gyenge mutatója, további információkért lásd: std/rc.rs
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Új, nem inicializált tartalommal rendelkező `Arc`-et készít, amely hibát ad vissza, ha a kiosztás sikertelen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Halasztott inicializálás:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Új, nem inicializált tartalommal rendelkező `Arc`-et épít, a memória `0` byte-okkal van feltöltve, és hibát ad vissza, ha az allokáció sikertelen.
    ///
    ///
    /// Lásd az [`MaybeUninit::zeroed`][zeroed] példákat a módszer helyes és helytelen használatára.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Visszaadja a belső értéket, ha az `Arc` pontosan egy erős referenciával rendelkezik.
    ///
    /// Ellenkező esetben egy [`Err`]-et ugyanazzal az `Arc`-rel adunk vissza, amelyet átadtunk.
    ///
    ///
    /// Ez akkor is sikeres lesz, ha vannak kiemelkedő gyenge referenciák.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Tegyen egy gyenge mutatót az implicit erős-gyenge referencia tisztításához
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Új, atomilag referencia-számlált szeletet állít elő, inicializálatlan tartalommal.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Halasztott inicializálás:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Új, atomilag referencia-számlált szeletet állít elő inicializálatlan tartalommal, a memória `0` byte-okkal van feltöltve.
    ///
    ///
    /// Lásd az [`MaybeUninit::zeroed`][zeroed] példákat a módszer helyes és helytelen használatára.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Átalakítás `Arc<T>`-re.
    ///
    /// # Safety
    ///
    /// Az [`MaybeUninit::assume_init`]-hez hasonlóan a hívónak is garantálnia kell, hogy a belső érték valóban inicializált állapotban van.
    ///
    /// Ennek hívása, ha a tartalom még nincs teljesen inicializálva, azonnal meghatározhatatlan viselkedést okoz.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Halasztott inicializálás:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Átalakítás `Arc<[T]>`-re.
    ///
    /// # Safety
    ///
    /// Az [`MaybeUninit::assume_init`]-hez hasonlóan a hívónak is garantálnia kell, hogy a belső érték valóban inicializált állapotban van.
    ///
    /// Ennek hívása, ha a tartalom még nincs teljesen inicializálva, azonnal meghatározhatatlan viselkedést okoz.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Halasztott inicializálás:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Fogyasztja az `Arc`-et, visszaküldi a becsomagolt mutatót.
    ///
    /// A memória szivárgásának elkerülése érdekében a mutatót vissza kell alakítani `Arc`-be [`Arc::from_raw`] használatával.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Nyers mutatót ad az adatokhoz.
    ///
    /// A számlálást semmilyen módon nem befolyásolja, és az `Arc` nem kerül felhasználásra.
    /// A mutató addig érvényes, amíg erős számok vannak az `Arc`-ben.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // BIZTONSÁG: Ez nem megy át az Deref::deref vagy RcBoxPtr::inner rendszeren, mert
        // erre van szükség az raw/mut eredetének megőrzéséhez, pl
        // `get_mut` írhat a mutatón, miután az Rc helyreállt az `from_raw`-en keresztül.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// `Arc<T>`-et készít egy nyers mutatóból.
    ///
    /// A nyers mutatót korábban vissza kellett adni egy [`Arc<U>::into_raw`][into_raw] hívással, ahol az `U` méretének és igazításának meg kell egyeznie az `T` értékével.
    /// Ez triviálisan igaz, ha az `U` az `T`.
    /// Ne feledje, hogy ha az `U` nem `T`, de azonos méretű és igazítású, akkor ez alapvetően olyan, mint a különböző típusú referenciák átalakítása.
    /// Az ebben az esetben érvényes korlátozásokról az [`mem::transmute`][transmute] oldalon talál további információt.
    ///
    /// Az `from_raw` felhasználójának meg kell győződnie arról, hogy az `T` meghatározott értéke csak egyszer kerül ejtésre.
    ///
    /// Ez a funkció nem biztonságos, mert a nem megfelelő használat memóriabiztonsághoz vezethet, még akkor is, ha a visszaküldött `Arc<T>`-hez soha nem fér hozzá.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Konvertáljon vissza `Arc`-be a szivárgás elkerülése érdekében.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Az `Arc::from_raw(x_ptr)`-re történő további hívások memória-nem biztonságosak lennének.
    /// }
    ///
    /// // A memória felszabadult, amikor az `x` kiment a fenti hatókörből, így az `x_ptr` most lóg!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Fordítsa meg az eltolást az eredeti ArcInner megkereséséhez.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Új [`Weak`] mutatót hoz létre ehhez a hozzárendeléshez.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Ez a Relaxed rendben van, mert az alábbi CAS-ban ellenőrizzük az értéket.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // ellenőrizze, hogy a gyenge számláló jelenleg "locked"-e;ha igen, forgasd meg.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: ez a kód jelenleg figyelmen kívül hagyja a túlcsordulás lehetőségét
            // az usize::MAX-be;általában az Rc-t és az Arc-t is ki kell igazítani a túlcsordulás kezelésére.
            //

            // Az Clone()-től eltérően erre szükségünk van egy Acquire-olvasásra, hogy szinkronizálhassuk az `is_unique`-től érkező írással, hogy az írást megelőző események az olvasás előtt történjenek.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Ügyeljen arra, hogy ne hozzunk létre lógó gyengét
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Megkapja az [`Weak`] mutatók számát ehhez a hozzárendeléshez.
    ///
    /// # Safety
    ///
    /// Ez a módszer önmagában biztonságos, de a helyes használata különös gondosságot igényel.
    /// Egy másik szál bármikor megváltoztathatja a gyenge számot, többek között a módszer meghívása és az eredményre való hatás között.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Ez az állítás determinisztikus, mert nem osztottuk meg az `Arc` vagy az `Weak` szálak között.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Ha a gyenge számlálás jelenleg zárolva van, akkor a számlálás értéke közvetlenül a zár felvétele előtt 0 volt.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Megkapja az erős (`Arc`) mutatók számát ehhez a hozzárendeléshez.
    ///
    /// # Safety
    ///
    /// Ez a módszer önmagában biztonságos, de a helyes használata különös gondosságot igényel.
    /// Egy másik szál bármikor megváltoztathatja az erős számot, többek között a módszer meghívása és az eredményre való hatás között.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Ez az állítás meghatározó, mert nem osztottuk meg az `Arc`-et a szálak között.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// A megadott mutatóhoz társított `Arc<T>` erős referenciaszámát eggyel növeli.
    ///
    /// # Safety
    ///
    /// A mutatót az `Arc::into_raw` segítségével kellett megszerezni, és a társított `Arc` példánynak érvényesnek kell lennie (azaz
    /// az erős számnak legalább 1)-nek kell lennie a módszer időtartama alatt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Ez az állítás meghatározó, mert nem osztottuk meg az `Arc`-et a szálak között.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Tartsa meg az Arc-t, de ne érintse meg az újraszámlálást a ManuallyDrop csomagolásával
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Most növelje az újraszámlálást, de ne dobjon új újraszámlálást sem
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// A megadott mutatóhoz társított `Arc<T>` erős referenciaszámát eggyel csökkenti.
    ///
    /// # Safety
    ///
    /// A mutatót az `Arc::into_raw` segítségével kellett megszerezni, és a társított `Arc` példánynak érvényesnek kell lennie (azaz
    /// az erős számnak legalább 1)-nek kell lennie, amikor ezt a módszert alkalmazza.
    /// Ez a módszer használható a végső `Arc` és a háttértár felszabadítására, de **nem szabad** meghívni az utolsó `Arc` kiadása után.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Ezek az állítások meghatározóak, mert nem osztottuk meg az `Arc`-et a szálak között.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Ez a nem biztonságos, mert amíg ez az ív él, garantáljuk, hogy a belső mutató érvényes.
        // Továbbá tudjuk, hogy maga az `ArcInner` szerkezet `Sync`, mert a belső adat is `Sync`, tehát rendben van egy kölcsönözhetetlen mutató kölcsönzése ezeknek a tartalmaknak.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Az `drop` nem beillesztett része.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Pusztítsa el az adatokat ebben az időben, annak ellenére, hogy nem biztos, hogy felszabadítjuk a dobozkiosztást (továbbra is gyenge mutatók hevernek).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Dobja el a gyenge ref-t, amelyet minden erős hivatkozás együttesen tart
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Visszaadja az `true` értéket, ha a két ív ugyanazon allokációra mutat (az [`ptr::eq`]-hez hasonló vénában).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Kioszt egy `ArcInner<T>`-t, elegendő hellyel egy esetleg nem méretezett belső értékhez, ahol az érték elrendezéssel rendelkezik.
    ///
    /// Az `mem_to_arcinner` függvény meghívásra kerül az adatmutatóval, és vissza kell adnia egy (potenciálisan zsíros) mutatót az `ArcInner<T>` számára.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Számítsa ki az elrendezést a megadott értékelrendezés segítségével.
        // Korábban az elrendezést az `&*(ptr as* const ArcInner<T>)` kifejezésen számolták, de ez rosszul illesztett hivatkozást hozott létre (lásd: #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Kioszt egy `ArcInner<T>`-t elegendő hellyel egy esetleg nem méretezett belső értékhez, ahol az érték elrendezése meg van adva, hibát adva, ha a felosztás nem sikerül.
    ///
    ///
    /// Az `mem_to_arcinner` függvény meghívásra kerül az adatmutatóval, és vissza kell adnia egy (potenciálisan zsíros) mutatót az `ArcInner<T>` számára.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Számítsa ki az elrendezést a megadott értékelrendezés segítségével.
        // Korábban az elrendezést az `&*(ptr as* const ArcInner<T>)` kifejezésen számolták, de ez rosszul illesztett hivatkozást hozott létre (lásd: #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Inicializálja az ArcInner programot
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Kioszt egy `ArcInner<T>`-et, elegendő hellyel a méret nélküli belső értékhez.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Rendeljen az `ArcInner<T>`-hez a megadott érték felhasználásával.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Érték másolása bájtként
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Ingyenes kiosztás a tartalom eldobása nélkül
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Kioszt egy `ArcInner<[T]>`-et a megadott hosszúsággal.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Elemek másolása a szeletből az újonnan kiosztott Arc <\[T\]>-ba
    ///
    /// Nem biztonságos, mert a hívónak vagy tulajdonjogot kell vállalnia, vagy köteleznie kell az `T: Copy`-et.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// `Arc<[T]>`-et készít egy ismert méretű iterátorról.
    ///
    /// A viselkedés nincs meghatározva, ha a méret nem megfelelő.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic védelem T elemek klónozása közben.
        // panic esetén az új ArcInnerbe írt elemek eldobódnak, majd felszabadul a memória.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Mutató az első elemhez
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Minden tiszta.Felejtse el az őrséget, hogy ne szabadítsa fel az új ArcInner-t.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Az `From<&[T]>`-hez használt trait specializáció.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Klónot készít az `Arc` mutatóból.
    ///
    /// Ez újabb mutatót hoz létre ugyanahhoz a felosztáshoz, növelve az erős referenciaszámot.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // A nyugodt sorrend használata itt rendben van, mivel az eredeti referencia ismerete megakadályozza, hogy más szálak hibásan töröljék az objektumot.
        //
        // Amint az [Boost documentation][1]-ben kifejtették, a referenciaszámláló növelése mindig elvégezhető a memory_order_relaxed opcióval: Az objektumra vonatkozó új hivatkozások csak meglévő referenciákból hozhatók létre, és a meglévő referenciák egyik szálból a másikba továbbításával már biztosítani kell a szükséges szinkronizálást.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Óvnunk kell azonban a hatalmas visszafizetések ellen, ha valaki " elfelejtette` az íveket.
        // Ha ezt nem tesszük meg, akkor a számlálás túlcsordulhat, és a felhasználók az ingyen használhatják.
        // Versenyképesen telítjük az `isize::MAX`-et azzal a feltételezéssel, hogy nincsenek ~2 milliárd szálak, amelyek egyszerre növelnék a referenciaszámot.
        //
        // Ezt a branch-t soha nem veszik fel semmilyen reális programban.
        //
        // Megszakítjuk, mert egy ilyen program hihetetlenül elfajult, és nem érdekel, hogy támogassuk.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Változtatható hivatkozást tesz az adott `Arc`-re.
    ///
    /// Ha más `Arc` vagy [`Weak`] mutató is van ugyanahhoz a hozzárendeléshez, akkor az `make_mut` új allokációt hoz létre, és az egyedi tulajdonjog biztosítása érdekében az [`clone`][clone]-et hívja meg a belső értékre.
    /// Ezt nevezzük klón-írásra is.
    ///
    /// Ne feledje, hogy ez eltér az [`Rc::make_mut`] viselkedésétől, amely szétválasztja a fennmaradó `Weak` mutatókat.
    ///
    /// Lásd még az [`get_mut`][get_mut]-et, amely a klónozás helyett nem fog sikerülni.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Nem klónoz semmit
    /// let mut other_data = Arc::clone(&data); // Nem klónozom a belső adatokat
    /// *Arc::make_mut(&mut data) += 1;         // Klónozza a belső adatokat
    /// *Arc::make_mut(&mut data) += 1;         // Nem klónoz semmit
    /// *Arc::make_mut(&mut other_data) *= 2;   // Nem klónoz semmit
    ///
    /// // Most az `data` és az `other_data` különböző kiosztásokra mutat.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Ne feledje, hogy mind erős, mind gyenge referenciát tartunk.
        // Így csak az erőteljes referenciánk elengedése önmagában nem okozza az emlékezet elosztását.
        //
        // Az Acquire használatával győződjön meg arról, hogy látunk-e olyan írásokat az `weak`-hez, amelyek a kiadás előtti írások (azaz csökkentések) előtt történnek.
        // Mivel gyengén számítunk, nincs esély arra, hogy magát az ArcInner-t el lehetne osztani.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Egy másik erős mutató létezik, ezért klónoznunk kell.
            // Előre lefoglalja a memóriát, hogy lehetővé tegye a klónozott érték közvetlen megírását.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // A fentiekben elég a nyugodt, mert ez alapvetően egy optimalizálás: mindig gyenge mutatók elejtésével versenyzünk.
            // A legrosszabb esetben végül feleslegesen osztunk ki új ívet.
            //

            // Eltávolítottuk az utolsó erős ref-et, de további gyenge ref-ek maradtak.
            // Áthelyezzük a tartalmat egy új Arcba, és érvénytelenítjük a többi gyenge referenciát.
            //

            // Ne feledje, hogy az `weak` olvasása nem eredményezheti az usize::MAX-et (azaz lezárva), mivel a gyenge számot csak egy erős referenciájú szál zárhatja le.
            //
            //

            // Materializálja saját implicit gyenge mutatónkat, hogy szükség szerint meg tudja tisztítani az ArcInner-t.
            //
            let _weak = Weak { ptr: this.ptr };

            // Csak ellophatja az adatokat, csak a Weaks van hátra
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Mi voltunk az egyetlen referencia mindkét fajtának;vissza az erős ref számlálás.
            //
            this.inner().strong.store(1, Release);
        }

        // Mint az `get_mut()` esetében, a nem biztonságos is rendben van, mert referenciánk kezdetben vagy egyedi volt, vagy a tartalom klónozásakor vált azzá.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Változtatható referenciát ad vissza az adott `Arc`-be, ha ugyanannak az allokációnak nincsenek más `Arc` vagy [`Weak`] mutatói.
    ///
    ///
    /// Ellenkező esetben az [`None`] értéket adja vissza, mert nem biztonságos egy megosztott érték mutációja.
    ///
    /// Lásd még: [`make_mut`][make_mut], amely [`clone`][clone] a belső értéket, ha más mutatók vannak.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Ez a bizonytalanság rendben van, mert garantáljuk, hogy a visszaadott mutató az egyetlen * mutató, amelyet valaha visszaadunk T-nek.
            // A referenciaszámunk garantáltan 1 lesz ezen a ponton, és megköveteltük, hogy maga az Arc `mut` legyen, ezért az egyetlen lehetséges hivatkozást a belső adatokra adjuk vissza.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Változtatható referenciát ad vissza az adott `Arc`-be, minden ellenőrzés nélkül.
    ///
    /// Lásd még az [`get_mut`]-et, amely biztonságos és megfelelő ellenőrzéseket végez.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Az ugyanazon felosztáshoz tartozó bármely más `Arc` vagy [`Weak`] mutatót a visszafizetett kölcsön időtartama alatt nem szabad alacsonynak levonni.
    ///
    /// Ez triviálisan így van, ha nincs ilyen mutató, például közvetlenül az `Arc::new` után.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Figyelünk arra, hogy *ne* hozzunk létre egy referenciát, amely lefedi az "count" mezőket, mivel ez egyazon hozzáférést jelentene a referenciaszámokhoz való hozzáféréssel (pl.
        // `Weak` által).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Határozza meg, hogy ez az egyedi hivatkozás (beleértve a gyenge referenciákat is) az alapul szolgáló adatokra.
    ///
    ///
    /// Vegye figyelembe, hogy ehhez meg kell zárni a gyenge ref számlálást.
    fn is_unique(&mut self) -> bool {
        // zárja le a gyenge mutatószámot, ha úgy tűnik, hogy mi vagyunk az egyetlen gyenge mutatótartó.
        //
        // A megszerzés címke itt biztosítja az `strong`-be írt írások (különösen az `Weak::upgrade`-ben történő) előtti kapcsolatokat az `weak`-szám csökkentése előtt (a kiadást használó `Weak::drop`-en keresztül).
        // Ha a frissített gyenge referenciát soha nem dobták el, akkor a CAS itt meghiúsul, ezért nem törődünk a szinkronizálással.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Ennek `Acquire`-nek kell lennie, hogy szinkronizálható legyen az `strong` számláló csökkentésével az `drop`-ben-ez az egyetlen hozzáférés akkor történik, amikor az utolsó hivatkozás kivételével bármelyik más elvetésre kerül.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // A kiadás itt írása szinkronizálódik az `downgrade`-ben olvasással, hatékonyan megakadályozva az `strong` fenti olvasását az írás után.
            //
            //
            self.inner().weak.store(1, Release); // oldja fel a zárat
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Dobja el az `Arc`-et.
    ///
    /// Ez csökkenti az erős referenciaszámot.
    /// Ha az erős referenciaszám eléri a nullát, akkor az egyetlen referencia (ha van ilyen) [`Weak`], tehát `drop` a belső érték.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Nem nyomtat semmit
    /// drop(foo2);   // "dropped!" nyomtatása
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Mivel az `fetch_sub` már atom, ezért nem kell szinkronizálnunk más szálakkal, hacsak nem törölni fogjuk az objektumot.
        // Ugyanez a logika vonatkozik az `fetch_sub` alatti `weak` számlálásra.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Erre a kerítésre van szükség az adatok újrarendezésének és az adatok törlésének megakadályozása érdekében.
        // Mivel az `Release` jelöléssel rendelkezik, a referenciaszám csökkenése szinkronizálódik ezzel az `Acquire` kerítéssel.
        // Ez azt jelenti, hogy az adatok felhasználása a referenciaszám csökkentése előtt történik, ami a kerítés előtt történik, ami az adatok törlése előtt történik.
        //
        // Amint azt az [Boost documentation][1]
        //
        // > Fontos, hogy az objektumhoz való esetleges hozzáférést egyben érvényesítsék
        // > szál (egy meglévő hivatkozáson keresztül) a törlés előtt * megtörténik
        // > az objektum egy másik szálban.Ezt egy "release"-el érik el
        // > művelet referencia eldobása után (bármilyen hozzáférés az objektumhoz
        // > ezen a hivatkozáson keresztül nyilvánvalóan korábban történt), és egy
        // > "acquire" művelet az objektum törlése előtt.
        //
        // Különösen, bár az Arc tartalma általában megváltoztathatatlan, lehetséges, hogy belső írása olyasmi, mint egy Mutex<T>.
        // Mivel a Mutex törléskor nem kerül megszerzésre, nem támaszkodhatunk a szinkronizálási logikájára, hogy az A szálban írásokat láthassuk a B szálban futó destruktorok számára.
        //
        //
        // Vegye figyelembe azt is, hogy az itt található Acquire kerítés valószínűleg helyettesíthető egy Acquire terheléssel, ami javíthatja a teljesítményt erősen vitatott helyzetekben.Lásd: [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Megpróbálta az `Arc<dyn Any + Send + Sync>`-et konkrét típusra lefokozni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Új `Weak<T>`-et épít, memória lefoglalása nélkül.
    /// Az [`upgrade`] visszahívásakor a [`None`] értéket mindig megkapja.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Segítő típus, amely lehetővé teszi a referenciaszámokhoz való hozzáférést anélkül, hogy bármilyen állítást tenne az adatmezővel kapcsolatban.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Visszaad egy nyers mutatót az `T` objektumra, amelyre az `Weak<T>` mutat.
    ///
    /// A mutató csak akkor érvényes, ha van néhány erős hivatkozás.
    /// Előfordulhat, hogy a mutató függő, kiegyenlítetlen, vagy máskülönben [`null`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Mindkettő ugyanarra az objektumra mutat
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Az itteni erősek életben tartják, így mégis hozzáférhetünk az objektumhoz.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // De már nem.
    /// // Meg tudjuk csinálni az weak.as_ptr()-et, de a mutató elérése meghatározatlan viselkedéshez vezetne.
    /// // assert_eq! ("hello", nem biztonságos {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Ha a mutató lóg, közvetlenül visszaküldjük az őrszemet.
            // Ez nem lehet érvényes hasznos cím, mivel a hasznos teher legalább annyira igazodik, mint az ArcInner (usize).
            ptr as *const T
        } else {
            // BIZTONSÁG: ha az is_dangling hamis értéket ad vissza, akkor a mutatóra le lehet vonni.
            // A hasznos teher ekkor csökkenhet, és meg kell őriznünk a származást, ezért használjon nyers mutató manipulációt.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Fogyasztja az `Weak<T>`-et, és nyers mutatóvá alakítja.
    ///
    /// Ez a gyenge mutatót nyers mutatóvá alakítja, miközben továbbra is megőrzi egy gyenge referencia tulajdonjogát (a gyenge számot ez a művelet nem módosítja).
    /// Az [`from_raw`] segítségével visszafordítható az `Weak<T>`-be.
    ///
    /// A mutató célpontjának elérésére ugyanazok a korlátozások vonatkoznak, mint az [`as_ptr`] esetében.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Az [`into_raw`] által korábban létrehozott nyers mutatót visszaállítja `Weak<T>`-be.
    ///
    /// Ezt fel lehet használni egy erős referencia biztonságos megszerzésére (az [`upgrade`] későbbi hívásával), vagy a gyenge számok elosztására az `Weak<T>` eldobásával.
    ///
    /// Egy gyenge referencia tulajdonjoga kell (az [`new`] által létrehozott mutatók kivételével, mivel ezek nem birtokolnak semmit; a módszer még mindig működik rajtuk).
    ///
    /// # Safety
    ///
    /// A mutatónak az [`into_raw`]-ből kell származnia, és továbbra is birtokolnia kell a gyenge referenciáját.
    ///
    /// Megengedett, hogy az erős szám 0 legyen a hívás idején.
    /// Mindazonáltal ez egy gyenge referencia tulajdonát képezi, amely jelenleg nyers mutatóként van ábrázolva (a gyenge számot ez a művelet nem módosítja), és ezért párosítani kell egy korábbi [`into_raw`] hívással.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Csökkentse az utolsó gyenge számot.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // A bemeneti mutató levezetésének módját lásd az Weak::as_ptr kontextusban.

        let ptr = if is_dangling(ptr as *mut T) {
            // Ez egy lógó Gyenge.
            ptr as *mut ArcInner<T>
        } else {
            // Ellenkező esetben garantáljuk, hogy a mutató egy gátlástalan Gyenge volt.
            // BIZTONSÁG: Az data_offset biztonságosan hívható, mivel a ptr egy valós (potenciálisan elesett) T-re hivatkozik.
            let offset = unsafe { data_offset(ptr) };
            // Így megfordítjuk az eltolást, hogy megkapjuk az egész RcBox-ot.
            // BIZTONSÁG: a mutató gyenge pontból származik, így ez az eltolás biztonságos.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // BIZTONSÁG: Most visszaállítottuk az eredeti Gyenge mutatót, így létrehozhatjuk a Gyenge pontot.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Megpróbálja frissíteni az `Weak` mutatót [`Arc`]-re, és sikeresen késlelteti a belső érték eldobását.
    ///
    ///
    /// [`None`] értéket ad vissza, ha a belső érték azóta leesett.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Pusztítson el minden erős mutatót.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // CAS ciklust használunk az erős szám növelésére a fetch_add helyett, mivel ennek a függvénynek soha nem szabad nulláról egyre vennie a referenciaszámot.
        //
        //
        let inner = self.inner()?;

        // Nyugodt terhelés, mert a 0 bármely olyan írása, amelyet megfigyelhetünk, állandóan nulla állapotban hagyja el a mezőt (tehát a 0 "stale" kiolvasása rendben van), és minden más értéket megerősít az alábbi CAS.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Lásd az `Arc::clone` megjegyzéseit, hogy miért csináljuk ezt (az `mem::forget` esetében).
            if n > MAX_REFCOUNT {
                abort();
            }

            // A nyugodt rendben van a kudarc ügyében, mert nincsenek elvárásaink az új állammal kapcsolatban.
            // Az akvizíció szükséges a sikereset szinkronizálásához az `Arc::new_cyclic`-szel, amikor a belső érték inicializálható az `Weak` referenciák létrehozása után.
            // Ebben az esetben a teljesen inicializált érték megfigyelésére számítunk.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null ellenőrzött fent
                Err(old) => n = old,
            }
        }
    }

    /// Megkapja az erre a kiosztásra mutató erős (`Arc`) mutatók számát.
    ///
    /// Ha az `self` az [`Weak::new`] használatával jött létre, akkor ez 0-t ad vissza.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Közelíti az erre a kiosztásra mutató `Weak` mutatók számát.
    ///
    /// Ha az `self` az [`Weak::new`] használatával jött létre, vagy ha még nincsenek erős mutatók, akkor ez 0-t ad vissza.
    ///
    /// # Accuracy
    ///
    /// A megvalósítási részletek miatt a visszaküldött érték 1-vel kikapcsolhat bármelyik irányba, ha más szálak manipulálnak bármelyik " Arc`vagy " Gyenge` elemet, amelyek ugyanarra az allokációra mutatnak.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Mivel megfigyeltük, hogy a gyenge számlálás elolvasása után legalább egy erős mutató volt, tudjuk, hogy az implicit gyenge referencia (jelen van, amikor bármilyen erős referencia él), még mindig ott volt, amikor megfigyeltük a gyenge számot, ezért biztonságosan kivonhatjuk.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Az `None` értéket adja vissza, amikor a mutató csüng, és nincs kiosztva az `ArcInner` (azaz amikor ezt az `Weak`-et az `Weak::new` hozta létre).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Figyelünk arra, hogy *ne* hozzunk létre egy referenciát, amely lefedi az "data" mezőt, mivel a mező egyidejűleg mutálódhat (például ha az utolsó `Arc`-et eldobja, az adatmező helyben eldobódik).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Visszaadja az `true` értéket, ha a két "gyenge" ugyanazon allokációra mutat (hasonlóan az [`ptr::eq`]-hez), vagy ha mindkettő nem mutat semmiféle allokációt (mert az `Weak::new()`) segítségével jöttek létre.
    ///
    ///
    /// # Notes
    ///
    /// Mivel ez összehasonlítja a mutatókat, ez azt jelenti, hogy az `Weak::new()` egyenlő lesz egymással, annak ellenére, hogy nem utalnak semmilyen kiosztásra.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Az `Weak::new` összehasonlítása.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Az `Weak` mutató klónját készíti, amely ugyanarra a kiosztásra mutat.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Lásd az Arc::clone() megjegyzéseit, hogy ez miért nyugodt.
        // Ez használhat egy fetch_add-t (figyelmen kívül hagyva a zárat), mert a gyenge számot csak akkor zárják le, ahol *nincsenek más* gyenge mutatók.
        //
        // (Tehát ebben az esetben nem tudjuk futtatni ezt a kódot).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Lásd az Arc::clone() megjegyzéseit, hogy miért csináljuk ezt (az mem::forget esetében).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Új `Weak<T>`-et épít, memória lefoglalása nélkül.
    /// Az [`upgrade`] visszahívásakor a [`None`] értéket mindig megkapja.
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Eldobja az `Weak` mutatót.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Nem nyomtat semmit
    /// drop(foo);        // "dropped!" nyomtatása
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Ha megtudjuk, hogy mi voltunk az utolsó gyenge mutató, akkor itt az ideje, hogy teljesen elosztjuk az adatokat.Lásd az Arc::drop() beszélgetését a memória sorrendjéről
        //
        // Itt nem szükséges ellenőrizni a lezárt állapotot, mert a gyenge számlálást csak akkor lehet lezárni, ha pontosan egy gyenge ref volt, vagyis ez a csepp csak később futtatható be a maradék gyenge ref-n, ami csak a zár felengedése után történhet meg.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Ezt a specializációt itt végezzük, és nem általánosabb optimalizálásként az `&T`-en, mert különben költséget jelentene a referenciák minden egyenlőség-ellenőrzésében.
/// Feltételezzük, hogy az "Arc"-okat nagy értékek tárolására használják, amelyek lassan klónozódnak, de nehézek az egyenlőség ellenőrzése érdekében is, ami miatt ez a költség könnyebben megtérül.
///
/// Valószínűbb, hogy két `Arc` klónja van, amelyek ugyanarra az értékre mutatnak, mint két "&T".
///
/// Csak akkor tudjuk ezt megtenni, ha az `T: Eq` mint `PartialEq` szándékosan nem reflektív lehet.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Két "Arc" egyenlősége.
    ///
    /// Két ív akkor egyenlő, ha a belső értékük megegyezik, még akkor is, ha különböző kiosztásban vannak tárolva.
    ///
    /// Ha az `T` az `Eq`-et is megvalósítja (az egyenlőség reflexivitását jelenti), akkor két ugyanazon allokációra mutató ív mindig egyenlő.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Két "Arc" egyenlőtlensége.
    ///
    /// Két ív egyenlőtlen, ha belső értéke egyenlőtlen.
    ///
    /// Ha az `T` az `Eq`-et is megvalósítja (ami az egyenlőség reflexivitását jelenti), akkor két ugyanazon értékre mutató ív soha nem egyenlőtlen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Részleges összehasonlítás két "Arc"-hoz.
    ///
    /// A kettőt úgy hasonlítják össze, hogy az `partial_cmp()`-et hívják belső értékeikre.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Kevesebb, mint összehasonlítás két "Arc"-hoz.
    ///
    /// A kettőt úgy hasonlítják össze, hogy az `<`-et hívják belső értékeikre.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// "Kevesebb vagy egyenlő" összehasonlítás két "Arc" esetén.
    ///
    /// A kettőt úgy hasonlítják össze, hogy az `<=`-et hívják belső értékeikre.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Nagyobb összehasonlítás két "Arc"-hoz.
    ///
    /// A kettőt úgy hasonlítják össze, hogy az `>`-et hívják belső értékeikre.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// "Nagyobb vagy egyenlő" összehasonlítás két "Arc" esetén.
    ///
    /// A kettőt úgy hasonlítják össze, hogy az `>=`-et hívják belső értékeikre.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Két "Arc" összehasonlítása.
    ///
    /// A kettőt úgy hasonlítják össze, hogy az `cmp()`-et hívják belső értékeikre.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Új `Arc<T>`-t hoz létre az `T` `Default` értékével.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Jelöljön ki egy referenciával megszámlált szeletet, és töltse ki a " v` elemek klónozásával.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Rendeljen referenciával megszámlált `str`-et, és másolja bele az `v`-et.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Rendeljen referenciával megszámlált `str`-et, és másolja bele az `v`-et.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Dobozos objektumot helyezzen át egy új, referencia által számlált hozzárendelésbe.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Jelöljön ki egy referenciával megszámlált szeletet, és helyezze bele a `v` elemeket.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Hagyja, hogy a Vec felszabadítsa memóriáját, de ne rontsa el annak tartalmát
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Minden elemet felvesz az `Iterator`-be és összegyűjti egy `Arc<[T]>`-be.
    ///
    /// # Teljesítmény jellemzők
    ///
    /// ## Az általános eset
    ///
    /// Általános esetben az `Arc<[T]>`-be történő gyűjtést először egy `Vec<T>`-be történő gyűjtéssel végezzük.Vagyis a következő írásakor:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ez úgy viselkedik, mintha azt írtuk volna:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Az első kiosztási készlet itt történik.
    ///     .into(); // Itt történik az `Arc<[T]>` második kiosztása.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Ez annyiszor fog kiosztani, amennyi az `Vec<T>` elkészítéséhez szükséges, majd egyszer kiosztja az `Vec<T>` átalakítását az `Arc<[T]>`-be.
    ///
    ///
    /// ## Ismert hosszúságú iterátorok
    ///
    /// Amikor az `Iterator` az `TrustedLen`-et valósítja meg és pontos mérete van, akkor az `Arc<[T]>`-hez egyetlen elosztást kell végezni.Például:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Itt csak egyetlen kiosztás történik.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// A trait specializáció az `Arc<[T]>`-be történő gyűjtéshez.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Ez a helyzet az `TrustedLen` iterátor esetében.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // BIZTONSÁG: Biztosítanunk kell, hogy az iterátor pontos hosszúságú legyen és mi is.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Vissza a normál megvalósításhoz.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Szerezze meg az eltolást az `ArcInner`-en belül a mutató mögött lévő hasznos teherért.
///
/// # Safety
///
/// A mutatónak egy korábban érvényes T példányra kell mutatnia (és érvényes metaadatokkal kell rendelkeznie), de a T eldobható.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Igazítsa a nem méretezett értéket az ArcInner végéhez.
    // Mivel az RcBox repr(C), mindig a memória utolsó mezője lesz.
    // BIZTONSÁG: mivel az egyetlen nem méretezett típus a szelet, a trait objektum,
    // és külső típusok esetén a bemeneti biztonsági követelmény jelenleg elegendő az align_of_val_raw követelményeinek kielégítésére;ez a nyelv olyan megvalósítási részlete, amelyre a std kívül nem lehet hivatkozni.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}