/// Létrehoz egy [`Vec`]-et, amely tartalmazza az argumentumokat.
///
/// `vec!` lehetővé teszi a `Vec`s megadását ugyanazzal a szintaxissal, mint a tömb kifejezéseket.
/// Ennek a makrónak két formája van:
///
/// - Hozzon létre egy [`Vec`]-et, amely tartalmazza az elemek adott listáját:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Hozzon létre egy [`Vec`]-t egy adott elemből és méretből:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Ne feledje, hogy a tömbkifejezésektől eltérően ez a szintaxis minden olyan elemet támogat, amely megvalósítja az [`Clone`]-et, és az elemek számának nem kell állandónak lennie.
///
/// Ez az `clone`-et fogja használni egy kifejezés másolásához, ezért körültekintően kell használni ezt olyan típusoknál, amelyek nem szabványos `Clone` megvalósítással rendelkeznek.
/// Például `vec![Rc::new(1);5] "létrehoz egy vektor-t, amely öt hivatkozást tartalmaz ugyanarra a dobozos egész értékre, és nem öt hivatkozás mutat önállóan dobozos egész számokra.
///
///
/// Vegye figyelembe azt is, hogy az `vec![expr; 0]` megengedett, és üres vector-t állít elő.
/// Ez azonban még mindig értékeli az `expr`-et, és azonnal eldobja a kapott értéket, ezért ügyeljen a mellékhatásokra.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): cfg(test) esetén a benne rejlő `[T]::into_vec` módszer, amely ehhez a makródefinícióhoz szükséges, nem érhető el.
// Ehelyett használja az `slice::into_vec` funkciót, amely csak az cfg(test) NB-nél érhető el. További információért lásd az slice::hack modult az slice.rs-ben.
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// A futásidejű kifejezések interpolációjával létrehoz egy `String`-et.
///
/// Az első argumentum, amelyet az `format!` kap, egy formátum-karakterlánc.Ennek sztring literálnak kell lennie.A formázási karakterlánc ereje a (z) "{}"-ban található.
///
/// Az `format!`-nek továbbított további paraméterek a megadott sorrendben helyettesítik a formázási karaktersorozatban található " {}` karaktereket, kivéve, ha megnevezett vagy helyzeti paramétereket használnak;További információkért lásd: [`std::fmt`].
///
///
/// Az `format!` általános használata a karakterláncok összefűzése és interpolálása.
/// Ugyanezt a konvenciót használják az [`print!`] és [`write!`] makróknál, a karakterlánc tervezett rendeltetésétől függően.
///
/// Egyetlen érték karakterláncokká alakításához használja az [`to_string`] metódust.Ehhez az [`Display`] formázást használja a trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics, ha a formázó trait megvalósítás hibát eredményez.
/// Ez helytelen megvalósítást jelez, mivel az `fmt::Write for String` soha nem ad vissza hibát.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Kényszerítse az AST csomópontot egy kifejezésre a minta helyzetének diagnosztikájának javítása érdekében.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}