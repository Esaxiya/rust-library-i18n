//! Unicode karakterlánc szeletek.
//!
//! *[See also the `str` primitive type](str).*
//!
//! Az `&str` típus a két fő karakterlánc-típus egyike, a másik az `String`.
//! Az `String` megfelelőjével ellentétben a tartalma kölcsönzött.
//!
//! # Alapvető használat
//!
//! `&str` típusú alapstring deklaráció:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Itt deklaráltunk egy karakterláncot, más néven húros szeletet.
//! A karakterláncok statikus élettartamúak, ami azt jelenti, hogy az `hello_world` karakterlánc garantáltan érvényes lesz a teljes program időtartamára.
//!
//! Kifejezetten meghatározhatjuk a " hello_world` élettartamát is:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Ennek a modulnak a sok felhasználását csak a tesztkonfigurációban használják.
// Tisztább, ha csak kikapcsolja az unused_imports figyelmeztetést, mint hogy kijavítsa őket.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: Az `Concat<str>` az `Concat<str>`-ben itt nem értelmes.
/// A trait ilyen típusú paramétere csak egy másik implikáció engedélyezéséhez létezik.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // a kemény kódolású hurkok sokkal gyorsabban futnak, a kis elválasztó hosszúságú esetekre szakosodtak
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // tetszőleges nem nulla méretű tartalék
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Optimalizált csatlakozási megvalósítás, amely mindkét Vec számára működik<T>(T: Másolás) és a String belső vecje Jelenleg az (2018-05-13)-ben van egy hiba a típus következtetésével és specializációjával (lásd az #36262 számot). Ezért SliceConcat<T>nem specializálódott T: Copy és SliceConcat<str>az egyetlen felhasználója ennek a funkciónak.
// A helyén marad, amíg ez javul.
//
// a String-join határai: S: Borrow<str>és Vec-csatlakozáshoz kölcsönkérj <[T]> [T] és str, mindkettő AsRef <[T]>-t jelent egyes T
// => s.borrow().as_ref() és mindig vannak szeleteink
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // az első szelet az egyetlen, amely előtt nincs elválasztó
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // kiszámítja az összekapcsolt Vec pontos teljes hosszát, ha az `len` számítás túlcsordul, panic-t kapunk, amúgy is kifogyott volna a memóriánk, és a többi funkcióhoz a teljes Vec-hez előre kell kiosztani a biztonságot
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // készítsen egy inicializálatlan puffert
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // a szeparátor és a szeletek korlátozás nélküli áttekintése ellenõrzõket hoz létre keménykódolt eltolásokkal a kis elválasztók számára hatalmas fejlesztések lehetségesek (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Egy furcsa hitelfelvétel különböző szeleteket adhat vissza a hossz kiszámításához és a tényleges példányhoz.
        //
        // Ügyeljen arra, hogy ne tegyük ki az inicializálatlan bájtokat a hívónak.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Módszerek húrszeletekhez.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// `Box<str>`-et átalakít `Box<[u8]>`-be másolás és kiosztás nélkül.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// A minta összes egyezését lecseréli egy másik karakterlánccal.
    ///
    /// `replace` létrehoz egy új [`String`]-et, és ebből a karaktersorozatból másolja az adatokat.
    /// Ennek során megpróbálja megtalálni a minta egyezését.
    /// Ha talál ilyet, kicseréli őket a helyettesítő karakterlánc szelettel.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Ha a minta nem egyezik:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// A minta első N egyezését lecseréli egy másik karakterlánccal.
    ///
    /// `replacen` létrehoz egy új [`String`]-et, és ebből a karaktersorozatból másolja az adatokat.
    /// Ennek során megpróbálja megtalálni a minta egyezését.
    /// Ha talál ilyet, akkor legfeljebb `count` alkalommal helyettesíti őket a helyettesítő karakterlánccal.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Ha a minta nem egyezik:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Remélem, hogy lecsökkentjük az újraelosztási időket
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Ennek a karakterláncnak a kisbetűvel egyenértékű értékét adja eredményül, új [`String`]-ként.
    ///
    /// 'Lowercase' az Unicode `Lowercase` származtatott magtulajdon feltételei szerint van meghatározva.
    ///
    /// Mivel a kis-és nagybetűk megváltoztatásakor egyes karakterek több karakterré bővülhetnek, ez a függvény [`String`] értéket ad vissza, ahelyett, hogy a paramétert helyben módosítaná.
    ///
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Trükkös példa sigmával:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // de egy szó végén ez ς, nem σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// A kis-és nagybetűk nélküli nyelvek nem változnak:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ a σ-hez térképez, kivéve a szó végén, ahol ς-ra térképez.
                // Ez az egyetlen feltételes (contextual), de nyelvfüggetlen leképezés az `SpecialCasing.txt`-ben, ezért kemény kódolás helyett általános "condition" mechanizmussal rendelkezik.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // az `Final_Sigma` meghatározásához.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Ennek a karakterlánc-szeletnek a nagybetűvel egyenértékű értékét adja vissza, új [`String`]-ként.
    ///
    /// 'Uppercase' az Unicode `Uppercase` származtatott magtulajdon feltételei szerint van meghatározva.
    ///
    /// Mivel a kis-és nagybetűk megváltoztatásakor egyes karakterek több karakterré bővülhetnek, ez a függvény [`String`] értéket ad vissza, ahelyett, hogy a paramétert helyben módosítaná.
    ///
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// A kis-és nagybetűk nélküli szkriptek nem változnak:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Egy karakter többszörössé válhat:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// [`Box<str>`]-et átalakít [`String`]-be másolás és kiosztás nélkül.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Új [`String`]-t hoz létre az `n` karakterlánc ismétlésével.
    ///
    /// # Panics
    ///
    /// Ez a funkció panic lesz, ha a kapacitás túlcsordul.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// panic túlcsorduláskor:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Visszaadja ennek a karaktersorozatnak a másolatát, ahol minden karakter az ASCII nagybetűvel egyenértékűre van leképezve.
    ///
    ///
    /// Az 'a'-'z' ASCII betűk 'A'-'Z'-hez vannak társítva, de a nem ASCII-betűk változatlanok.
    ///
    /// Az érték helyben történő nagybetűvé tételéhez használja az [`make_ascii_uppercase`] billentyűt.
    ///
    /// Az ASCII karakterek nagybetűvé tételéhez a nem ASCII karakterek mellett használja az [`to_uppercase`] billentyűt.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() megőrzi az UTF-8 invariánsát.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Visszaadja ennek a karaktersorozatnak a másolatát, ahol minden karakter az ASCII kisbetű ekvivalenséhez van rendelve.
    ///
    ///
    /// Az 'A'-'Z' ASCII betűk 'a'-'z'-hez vannak társítva, de a nem ASCII-betűk változatlanok.
    ///
    /// Az érték helyben történő kisbetűsítéséhez használja az [`make_ascii_lowercase`] parancsot.
    ///
    /// Az ASCII karakterek kisbetűvé tételéhez a nem ASCII karakterek mellett használja az [`to_lowercase`] billentyűt.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() megőrzi az UTF-8 invariánsát.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// A bájtos dobozos szeletet dobozos karakterlánc szeletté alakítja anélkül, hogy ellenőrizné, hogy a karakterlánc érvényes UTF-8-et tartalmaz-e.
///
///
/// # Examples
///
/// Alapvető használat:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}