//! Dinamikus méretű nézet összefüggő sorrendben, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! A szeletek egy memóriablokk nézet, amelyet mutatóként és hosszként ábrázolnak.
//!
//! ```
//! // felszeletelve egy Vec-t
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // tömb kényszerítése egy szeletre
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! A szeletek vagy módosíthatók, vagy megosztottak.
//! A megosztott szelet típusa `&[T]`, míg a módosítható szelet típusa `&mut [T]`, ahol `T` az elem típusát jelenti.
//! Például mutálhatja azt a memóriablokkot, amelyre egy módosítható szelet mutat:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Íme néhány dolog, amelyet ez a modul tartalmaz:
//!
//! ## Structs
//!
//! Számos struktúra létezik, amelyek hasznosak a szeleteknél, például az [`Iter`], amely a szelet fölötti iterációt képviseli.
//!
//! ## Trait Megvalósítások
//!
//! A szeletekhez a traits közös megvalósítása többféle.Néhány példa:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], olyan szeletekhez, amelyek elemtípusa [`Eq`] vagy [`Ord`].
//! * [`Hash`] - szeletekre, amelyek elemtípusa [`Hash`].
//!
//! ## Iteration
//!
//! A szeletek megvalósítják az `IntoIterator`-et.Az iterátor hivatkozásokat ad a szeletelemekre.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! A mutábilis szelet mutatható hivatkozásokat ad az elemekre:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Ez az iterátor mutáns hivatkozásokat ad a szelet elemeire, így míg a szelet elemtípusa `i32`, addig az iterátor elemtípusa `&mut i32`.
//!
//!
//! * [`.iter`] és az [`.iter_mut`] az explicit módszer az alapértelmezett iterátorok visszaadására.
//! * További módszerek az iterátorok visszaadására: [`.split`], [`.splitn`], [`.chunks`], [`.windows`] és még sok más.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Ennek a modulnak a sok felhasználását csak a tesztkonfigurációban használják.
// Tisztább, ha csak kikapcsolja az unused_imports figyelmeztetést, mint hogy kijavítsa őket.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Alapvető szeletkiterjesztési módszerek
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) szükséges az `vec!` makró megvalósításához az NB tesztelése során, további részletekért lásd a fájl `hack` modulját.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) szükséges az `Vec::clone` megvalósításához az NB tesztelése során, további részletekért lásd a fájl `hack` modulját.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Az cfg(test) használatával az `impl [T]` nem érhető el, ez a három funkció tulajdonképpen az `impl [T]`-ben található, de az `core::slice::SliceExt`-ben nem szereplő módszer, ezeket az `test_permutations`-teszthez meg kell adnunk
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Ehhez nem szabad inline attribútumot adnunk, mivel ez többnyire az `vec!` makróban használatos és tökéletes regressziót okoz.
    // Lásd az #71204-et a megbeszélésekhez és a legjobb eredményekhez.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // az elemeket inicializálva jelöltük az alábbi hurokban
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) szükséges ahhoz, hogy az LLVM eltávolítsa a határellenőrzéseket, és jobb kodegen van, mint a zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // a vec-t legalább ekkorra osztották be és inicializálták.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // `s` kapacitással, és inicializálja `s.len()`-re az alábbi ptr::copy_to_non_overlapping-ben.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Rendezi a szeletet.
    ///
    /// Ez a fajta stabil (azaz nem rendezi át az egyenlő elemeket) és a *O*(*n*\*log(* n*)) legrosszabb esetben.
    ///
    /// Adott esetben az instabil rendezés a preferált, mivel általában gyorsabb, mint a stabil rendezés, és nem oszt ki kiegészítő memóriát.
    /// Lásd: [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Jelenlegi megvalósítás
    ///
    /// A jelenlegi algoritmus egy adaptív, iteratív összevonási sorrend, amelyet az [timsort](https://en.wikipedia.org/wiki/Timsort) ihletett.
    /// Úgy tervezték, hogy nagyon gyors legyen olyan esetekben, amikor a szelet majdnem rendezve van, vagy két vagy több rendezett szekvenciából áll, amelyeket egymás után összefűznek.
    ///
    ///
    /// Ezenkívül az `self` méretének felénél ideiglenes tárhelyet oszt ki, de rövid szeletekhez nem allokáló beillesztési sorrendet használnak.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// A szeletet összehasonlító funkcióval rendezi.
    ///
    /// Ez a fajta stabil (azaz nem rendezi át az egyenlő elemeket) és a *O*(*n*\*log(* n*)) legrosszabb esetben.
    ///
    /// Az összehasonlító függvénynek meg kell határoznia a szelet elemeinek teljes sorrendjét.Ha a sorrend nem teljes, akkor az elemek sorrendje nincs megadva.
    /// A megrendelés teljes megrendelés, ha igen (az összes `a`, `b` és `c` esetében):
    ///
    /// * teljes és antiszimmetrikus: pontosan az `a < b`, `a == b` vagy `a > b` közül az egyik igaz, és
    /// * transzitív, az `a < b` és az `b < c` az `a < c`-et jelenti.Ugyanennek kell lennie az `==` és az `>` esetében is.
    ///
    /// Például, míg az [`f64`] nem valósítja meg az [`Ord`]-et, mert az `NaN != NaN`, az `partial_cmp`-et használhatjuk rendezési funkcióként, ha tudjuk, hogy a szelet nem tartalmaz `NaN`-et.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Adott esetben az instabil rendezés a preferált, mivel általában gyorsabb, mint a stabil rendezés, és nem oszt ki kiegészítő memóriát.
    /// Lásd: [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Jelenlegi megvalósítás
    ///
    /// A jelenlegi algoritmus egy adaptív, iteratív összevonási sorrend, amelyet az [timsort](https://en.wikipedia.org/wiki/Timsort) ihletett.
    /// Úgy tervezték, hogy nagyon gyors legyen olyan esetekben, amikor a szelet majdnem rendezve van, vagy két vagy több rendezett szekvenciából áll, amelyeket egymás után összefűznek.
    ///
    /// Ezenkívül az `self` méretének felénél ideiglenes tárhelyet oszt ki, de rövid szeletekhez nem allokáló beillesztési sorrendet használnak.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // fordított rendezés
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Rendezi a szelet egy kulcs kinyerési funkcióval.
    ///
    /// Ez a fajta stabil (azaz nem rendezi át az egyenlő elemeket) és a *O*(*m*\* * n *\* log(*n*)) legrosszabb esetben, ahol a kulcsfontosságú funkció *O*(*m*).
    ///
    /// Drága kulcsfunkciókhoz (pl
    /// funkciók, amelyek nem egyszerű tulajdonságelérések vagy alapvető műveletek), az [`sort_by_cached_key`](slice::sort_by_cached_key) valószínűleg jelentősen gyorsabb lesz, mivel nem számolja ki újra az elemkulcsokat.
    ///
    ///
    /// Adott esetben az instabil rendezés a preferált, mivel általában gyorsabb, mint a stabil rendezés, és nem oszt ki kiegészítő memóriát.
    /// Lásd: [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Jelenlegi megvalósítás
    ///
    /// A jelenlegi algoritmus egy adaptív, iteratív összevonási sorrend, amelyet az [timsort](https://en.wikipedia.org/wiki/Timsort) ihletett.
    /// Úgy tervezték, hogy nagyon gyors legyen olyan esetekben, amikor a szelet majdnem rendezve van, vagy két vagy több rendezett szekvenciából áll, amelyeket egymás után összefűznek.
    ///
    /// Ezenkívül az `self` méretének felénél ideiglenes tárhelyet oszt ki, de rövid szeletekhez nem allokáló beillesztési sorrendet használnak.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Rendezi a szelet egy kulcs kinyerési funkcióval.
    ///
    /// A rendezés során a kulcsfunkciót elemenként csak egyszer hívják meg.
    ///
    /// Ez a fajta stabil (azaz nem rendezi át az egyenlő elemeket) és a *O*(*m*\* * n *+* n *\* log(*n*)) legrosszabb esetben, ahol a kulcsfüggvény *O*(*m*) .
    ///
    /// Az egyszerű kulcsfontosságú funkciók (például olyan funkciók, amelyek tulajdonhoz való hozzáférés vagy alapvető műveletek) esetén az [`sort_by_key`](slice::sort_by_key) valószínűleg gyorsabb lesz.
    ///
    /// # Jelenlegi megvalósítás
    ///
    /// A jelenlegi algoritmus Orson Peters [pattern-defeating quicksort][pdqsort]-en alapul, amely egyesíti a randomizált quicksort gyors átlagos esetét a leggyorsabb heapsort esettel, miközben lineáris időt ér el bizonyos mintázatú szeleteken.
    /// Némi randomizálást alkalmaz a degenerált esetek elkerülésére, de fix seed-vel mindig meghatározó viselkedést biztosít.
    ///
    /// A legrosszabb esetben az algoritmus ideiglenes tárhelyet oszt ki a szelet hosszában `Vec<(K, usize)>`-ben.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Segítő makró a vector mi indexeléséhez a lehető legkisebb típus szerint, az allokáció csökkentése érdekében.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Az `indices` elemei egyediek, mivel indexelik őket, így bármilyen fajta stabil lesz az eredeti szelethez képest.
                // Az `sort_unstable`-et itt használjuk, mert kevesebb memóriafoglalást igényel.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Másolja az `self`-et egy új `Vec`-be.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Itt az `s` és `x` egymástól függetlenül módosítható.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Másolja az `self`-et egy új `Vec`-be egy elosztóval.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Itt az `s` és `x` egymástól függetlenül módosítható.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // Megjegyzés: további részletekért lásd a fájl `hack` modulját.
        hack::to_vec(self, alloc)
    }

    /// Az `self` klónok és allokáció nélküli vector-vé konvertálja.
    ///
    /// Az így kapott vector a `Vec<T>`into_boxed_slice` módszere.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` már nem használható, mert átalakították `x`-be.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // Megjegyzés: további részletekért lásd a fájl `hack` modulját.
        hack::into_vec(self)
    }

    /// Létrehoz egy vector-t egy szelet `n`-szeres megismétlésével.
    ///
    /// # Panics
    ///
    /// Ez a funkció panic lesz, ha a kapacitás túlcsordul.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// panic túlcsorduláskor:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Ha az `n` nagyobb, mint nulla, akkor felosztható `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` néven.
        // `2^expn` az `n` bal szélső '1' bitjével ábrázolt szám, és `rem` az `n` fennmaradó része.
        //
        //

        // Az `Vec` használata az `set_len()` eléréséhez.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` az ismétlés az `buf` `expn-szorzat duplázásával történik.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Ha `m > 0`, akkor a bal szélső '1'-ig maradnak bitek.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` kapacitása `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) ismétlés úgy történik, hogy az első `rem` ismétléseket lemásolja magáról az `buf`-ről.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Ez az `2^expn > rem` óta nem fedi egymást.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` egyenlő `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Az `T` egy szeletét egyetlen `Self::Output` értékre simítja.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Az `T` szeletet egyetlen `Self::Output` értékre simítja, mindegyik közé egy adott elválasztót helyezve.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Az `T` szeletet egyetlen `Self::Output` értékre simítja, mindegyik közé egy adott elválasztót helyezve.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Visszaad egy vector-t, amely tartalmazza a szelet egy példányát, ahol minden bájt az ASCII nagybetűvel egyenértékűre van leképezve.
    ///
    ///
    /// Az 'a'-'z' ASCII betűk 'A'-'Z'-hez vannak társítva, de a nem ASCII-betűk változatlanok.
    ///
    /// Az érték helyben történő nagybetűvé tételéhez használja az [`make_ascii_uppercase`] billentyűt.
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Visszaad egy vector-t, amely tartalmazza a szelet egy példányát, ahol minden bájt az ASCII kisbetű ekvivalenséhez van hozzárendelve.
    ///
    ///
    /// Az 'A'-'Z' ASCII betűk 'a'-'z'-hez vannak társítva, de a nem ASCII-betűk változatlanok.
    ///
    /// Az érték helyben történő kisbetűsítéséhez használja az [`make_ascii_lowercase`] parancsot.
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// A traits kiterjesztés szeletekre meghatározott típusú adatok fölött
////////////////////////////////////////////////////////////////////////////////

/// Segítő trait a [`[T]: : concat`]-hoz (szelet::concat).
///
/// Note: az `Item` típusú paramétert nem használják ebben a trait-ben, de lehetővé teszi az implusok általánosabbá tételét.
/// Enélkül ezt a hibát kapjuk:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Ugyanis létezhetnek `V` típusok több `Borrow<[_]>` implikációval, így több `T` típus is alkalmazható:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// A kapott típus összefűzés után
    type Output;

    /// A [`[T]: : concat`](szelet::concat) megvalósítása
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Segítő trait a [`[T]: : csatlakozáshoz](szelet::csatlakozás)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// A kapott típus összefűzés után
    type Output;

    /// A [`[T]: : join`] megvalósítása (szelet::join)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Szeletek szabványos trait megvalósítása
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // dobjon be bármit a célba, amelyet nem írnak felül
        target.truncate(self.len());

        // target.len <= self.len a fenti csonka miatt, ezért az itt található szeletek mindig határon belül vannak.
        //
        let (init, tail) = self.split_at(target.len());

        // újból felhasználja a benne szereplő " allocations/resources értékeket.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Beszúrja az `v[0]`-et az előre rendezett `v[1..]` szekvenciába, így az egész `v[..]` rendeződik.
///
/// Ez a beillesztés rendezésének integrált alprogramja.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // A beszúrás megvalósításának három módja van itt:
            //
            // 1. Cserélje a szomszédos elemeket, amíg az első el nem éri a végcélját.
            //    Azonban így a szükségesnél többet másolunk az adatok köré.
            //    Ha az elemek nagy szerkezetűek (költséges a másolás), akkor ez a módszer lassú lesz.
            //
            // 2. Addig iterálunk, amíg meg nem találjuk az első elem megfelelő helyét.
            // Ezután helyezze át az elemeket a helyére, hogy helyet biztosítson neki, és végül helyezze a maradék lyukba.
            // Ez egy jó módszer.
            //
            // 3. Másolja az első elemet egy ideiglenes változóba.Addig iterálunk, amíg meg nem találjuk a megfelelő helyet.
            // Ahogy haladunk, másoljon minden bejárt elemet az azt megelőző résbe.
            // Végül másolja az adatokat az ideiglenes változóból a fennmaradó lyukba.
            // Ez a módszer nagyon jó.
            // A referenciaértékek valamivel jobb teljesítményt mutattak, mint a 2. módszerrel.
            //
            // Valamennyi módszert összehasonlítottuk, és a 3. mutatta a legjobb eredményt.Tehát ezt választottuk.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // A beszúrási folyamat közbenső állapotát mindig az `hole` követi, amely két célt szolgál:
            // 1. Védi az `v` integritását a panics-től az `is_less`-ben.
            // 2. Végül kitölti az `v` maradék lyukat.
            //
            // Panic biztonság:
            //
            // Ha a folyamat bármely pontján az `is_less` panics, az `hole` leesik, és az `v` lyukát kitölti `tmp`-szel, ezzel biztosítva, hogy az `v` továbbra is pontosan megtart minden tárgyat, amelyet eredetileg tartott.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` leesik, és így az `tmp`-et bemásolja az `v` fennmaradó lyukába.
        }
    }

    // Amikor elejtette, az `src`-ről az `dest`-re másol.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// A nem csökkenő `v[..mid]` és `v[mid..]` futtatásokat egyesíti az `buf` használatával ideiglenes tárolóként, és az eredményt az `v[..]` fájlba tárolja.
///
/// # Safety
///
/// A két szeletnek nem üresnek kell lennie, az `mid`-nek pedig határoknak kell lennie.
/// Az `buf` puffernek elég hosszúnak kell lennie a rövidebb szelet másolatának tárolásához.
/// Az `T` nem lehet nulla méretű típus.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Az egyesítési folyamat először a rövidebb futtatást másolja az `buf`-be.
    // Ezután követi az újonnan lemásolt és a hosszabb futást előre (vagy hátra), összehasonlítva a következő el nem használt elemeiket, és a kisebbet (vagy nagyobbat) az `v`-be másolja.
    //
    // Amint a rövidebb táv teljes mértékben elfogy, a folyamat elkészül.Ha először a hosszabb távot fogyasztják el, akkor a rövidebb futásból megmaradt részt át kell másolnunk az `v` megmaradt lyukába.
    //
    // A folyamat közbenső állapotát mindig az `hole` követi, amelynek két célja van:
    // 1. Védi az `v` integritását a panics-től az `is_less`-ben.
    // 2. Az `v` fennmaradó lyukát kitölti, ha a hosszabb távot fogyasztják először.
    //
    // Panic biztonság:
    //
    // Ha a folyamat bármely pontján az `is_less` panics, az `hole` leesik, és kitölti az `v` lyukat az `buf` nem használt tartományával, így biztosítva, hogy az `v` továbbra is minden objektumot pontosan tartson, amelyet eredetileg tartott.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // A bal futás rövidebb.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Eleinte ezek a mutatók tömbjeik kezdetére mutatnak.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Fogyassza a kisebbik oldalt.
            // Ha egyenlő, akkor a stabilitás fenntartása érdekében inkább a bal oldali menetet részesítse előnyben.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // A megfelelő futás rövidebb.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Kezdetben ezek a mutatók túlmutatnak tömbjeik végén.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Fogyassza a nagyobbik oldalt.
            // Ha egyenlő, akkor a stabilitás fenntartása érdekében előnyben részesítse a megfelelő futást.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Végül az `hole` leesik.
    // Ha a rövidebb távot nem használták fel teljesen, akkor a maradékot az `v` lyukába másoljuk.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Ha elejtette, az `start..end` tartományt átmásolja az `dest..` tartományba.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` nem nulla méretű típus, ezért rendben van, ha felosztjuk méretével.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Ez az egyesítési sorrend kölcsönkér néhány (de nem minden) ötletet a TimSort-tól, amelyet az [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) részletesen leír.
///
///
/// Az algoritmus szigorúan csökkenő és nem csökkenő részeket azonosít, amelyeket természetes futásoknak nevezünk.Van egy halom függőben lévő futás, amelyet még össze kell vonni.
/// Minden újonnan talált futást a veremre tolnak, majd egyesítik a szomszédos futáspárokat, amíg ez a két invariáns meg nem teljesül:
///
/// 1. minden `i`-re az `1..runs.len()`-ben: `runs[i - 1].len > runs[i].len`
/// 2. minden `i`-re az `2..runs.len()`-ben: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Az invariánsok biztosítják, hogy a teljes futási idő *O*(*n*\*log(* n*)) legrosszabb esetben.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Az ilyen hosszúságú szeleteket a beszúrási rendezéssel rendezik.
    const MAX_INSERTION: usize = 20;
    // A nagyon rövid futtatásokat meghosszabbítják a beszúrási rendezéssel, hogy legalább ennyi elemre kiterjedjenek.
    const MIN_RUN: usize = 10;

    // A rendezésnek nincs értelmes viselkedése nulla méretű típusoknál.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // A kiosztások elkerülése érdekében a rövid tömbök helyben rendeződnek beillesztési rendezéssel.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Rendeljen egy puffert, amelyet karcolásos memóriaként használna.Megtartjuk a 0 hosszúságot, így az `v` tartalmának sekély másolatait megőrizhetjük anélkül, hogy megkockáztatnánk a másolatokon futó orvosokat, ha `is_less` panics.
    //
    // Két rendezett futás összevonásakor ez a puffer a rövidebb futás másolatát tárolja, amelynek mindig legfeljebb `len / 2` lesz a hossza.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Az `v` természetes futásának azonosítása érdekében visszafelé haladunk.
    // Ez furcsa döntésnek tűnhet, de vegye figyelembe azt a tényt, hogy az egyesülések gyakrabban az (forwards) ellentétes irányába mutatnak.
    // A referenciaértékek szerint az előre összeolvadás valamivel gyorsabb, mint a visszafelé.
    // Összefoglalva, a futások visszafelé haladásával történő azonosítása javítja a teljesítményt.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Keresse meg a következő természetes futást, és fordítsa meg, ha szigorúan csökken.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Helyezzen be még néhány elemet a futásba, ha túl rövid.
        // A beillesztés rendezése gyorsabb, mint a rövid szekvenciák egyesítése, így ez jelentősen javítja a teljesítményt.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Tolja ezt a futást a veremre.
        runs.push(Run { start, len: end - start });
        end = start;

        // Egyesítse a szomszédos futáspárokat, hogy kielégítse az invariánsokat.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Végül pontosan egy futásnak kell maradnia a veremben.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Megvizsgálja a futási halmot és azonosítja a következő egyesítendő futáspárt.
    // Pontosabban, ha az `Some(r)`-t adja vissza, ez azt jelenti, hogy az `runs[r]`-et és az `runs[r + 1]`-et kell legközelebb egyesíteni.
    // Ha az algoritmus folytatja az új futás felépítését, az `None` értéket adja vissza.
    //
    // A TimSort hírhedt az itt leírt hibás megvalósításai miatt:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // A történet lényege: a verem első négy menetében kell érvényesítenünk az invariánsokat.
    // Kényszerítésük csak az első három helyen nem elegendő annak biztosításához, hogy az invariánsok továbbra is megtartsák az összes * futást a veremben.
    //
    // Ez a funkció helyesen ellenőrzi az invariánsokat az első négy futtatás szempontjából.
    // Ezenkívül, ha a felső futás a 0 indexből indul, akkor a rendezés befejezéséhez mindig egyesítési műveletet igényel, amíg a verem teljesen összeomlik.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}