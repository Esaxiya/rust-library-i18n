use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Az Vec::from_iter-hez használt trait specializáció
///
/// ## A delegálás grafikonja:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Gyakori eset, hogy egy vector-t átadunk egy olyan funkciónak, amely azonnal újra összegyűlik egy vector-be.
        // Rövidzárlatba hozhatjuk ezt, ha az IntoIter egyáltalán nem volt fejlett.
        // Ha előrehaladott állapotban van, a memóriát újrafelhasználhatjuk, és az adatokat előre mozgathatjuk.
        // De csak akkor tesszük, ha az így létrejövő Vecnak nincs több kihasználatlan kapacitása, mint azt a FromIterator általános megvalósításával létrehozná.
        //
        // Ez a korlátozás nem feltétlenül szükséges, mivel Vec allokációs viselkedése szándékosan nincs meghatározva.
        // De ez konzervatív választás.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // kell delegálnia az spec_extend()-be, mivel az extend() maga delegálja a spec_from-ot az üres Vecs-hez
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Ez az `iterator.as_slice().to_vec()`-et használja, mivel a spec_extendnek több lépést kell tennie a végső kapacitás + hosszúság megalapozása érdekében, és így több munkát kell végeznie.
// `to_vec()` közvetlenül kiosztja a helyes összeget és pontosan kitölti.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): cfg(test) esetén a benne rejlő `[T]::to_vec` módszer, amely ehhez a módszer meghatározásához szükséges, nem áll rendelkezésre.
    // Ehelyett használja az `slice::to_vec` funkciót, amely csak az cfg(test) NB-nél érhető el. További információért lásd az slice::hack modult az slice.rs-ben.
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}