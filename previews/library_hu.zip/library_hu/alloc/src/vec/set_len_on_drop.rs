// Állítsa be a vec hosszúságát, amikor az `SetLenOnDrop` érték kiesik a hatókörből.
//
// Az ötlet a következő: A SetLenOnDrop hosszmezője egy helyi változó, amelyet az optimalizáló látni fog, és a Vec adatmutatóján keresztül nem álnév egyetlen tárral sem.
// Ez egy megkerülő megoldás az #32155 álnév elemzéshez
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}