use core::ptr::{self};
use core::slice::{self};

// Segítő struktúra a helyben történő iterációhoz, amely eldobja az iteráció célszeletét, azaz a fejet.
// A forrásszeletet (farok) az IntoIter dobja el.
pub(super) struct InPlaceDrop<T> {
    pub(super) inner: *mut T,
    pub(super) dst: *mut T,
}

impl<T> InPlaceDrop<T> {
    fn len(&self) -> usize {
        unsafe { self.dst.offset_from(self.inner) as usize }
    }
}

impl<T> Drop for InPlaceDrop<T> {
    #[inline]
    fn drop(&mut self) {
        unsafe {
            ptr::drop_in_place(slice::from_raw_parts_mut(self.inner, self.len()));
        }
    }
}