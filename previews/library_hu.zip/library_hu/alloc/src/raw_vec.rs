#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Az új memória tartalma inicializálatlan.
    Uninitialized,
    /// Az új memória garantáltan nullázódik.
    Zeroed,
}

/// Alacsony szintű segédprogram a memóriapuffer ergonómikusabb kiosztásához, átcsoportosításához és elosztásához a kupacon anélkül, hogy aggódnia kellene az összes sarok eset miatt.
///
/// Ez a típus kiválóan alkalmas saját adatstruktúrák, például Vec és VecDeque felépítésére.
/// Különösen:
///
/// * `Unique::dangling()`-et gyárt nulla méretű típusokon.
/// * `Unique::dangling()`-et állít elő nulla hosszúságú allokációknál.
/// * Kerüli az `Unique::dangling()` felszabadítását.
/// * Fogja az összes túlcsordulást a kapacitásszámításokban (elősegíti őket "capacity overflow" panics-re).
/// * Óvja a 32 bites rendszereket, amelyek több mint isize::MAX bájtot osztanak ki.
/// * Óvja a hossza túlcsordulásától.
/// * Felhívja az `handle_alloc_error`-et esendő kiosztásokra.
/// * Tartalmaz egy `ptr::Unique`-et, és ezáltal a felhasználó minden kapcsolódó előnyével felruházza a felhasználót.
/// * A rendelkezésre álló legnagyobb kapacitás kihasználására használja fel az elosztótól megtérült többletet.
///
/// Ez a típus egyébként nem ellenőrzi az általa kezelt memóriát.Ha eldobja, felszabadítja a memóriáját, de nem próbálja eldobni a tartalmát.
/// Az `RawVec` felhasználójának kell kezelnie az `RawVec` belsejében *tárolt* tényleges dolgokat.
///
/// Vegye figyelembe, hogy a nulla méretű típusok feleslege mindig végtelen, ezért az `capacity()` mindig `usize::MAX`-et ad vissza.
/// Ez azt jelenti, hogy körültekintőnek kell lennie, amikor ezt a típust egy `Box<[T]>`-el botolja be, mivel az `capacity()` nem adja meg a hosszúságot.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Ez azért létezik, mert az `#[unstable]` `const fn`-eknek nem kell megfelelniük az `min_const_fn`-nek, ezért nem hívhatók meg a`min_const_fn`-ben sem.
    ///
    /// Ha megváltoztatja az `RawVec<T>::new`-et vagy a függőségeket, ügyeljen arra, hogy ne vezessen be olyanokat, amelyek valóban sértenék az `min_const_fn`-et.
    ///
    /// NOTE: Elkerülhetnénk ezt a feltörést, és ellenőrizhetnénk a megfelelőséget valamilyen `#[rustc_force_min_const_fn]` attribútummal, amely megköveteli az `min_const_fn` megfelelőségét, de nem feltétlenül teszi lehetővé az `stable(...) const fn`-ben való hívást/felhasználói kód, amely nem engedélyezi az `foo` használatát, amikor az `#[rustc_const_unstable(feature = "foo", issue = "01234")]` jelen van.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Létrehozás nélkül hozza létre a lehető legnagyobb `RawVec`-et (a rendszerkupacon).
    /// Ha az `T` pozitív mérettel rendelkezik, akkor ez egy `RawVec` lesz, amelynek kapacitása `0`.
    /// Ha az `T` nulla méretű, akkor `RawVec`-et készít `usize::MAX` kapacitással.
    /// Hasznos a késleltetett kiosztás megvalósításához.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Létrehoz egy `RawVec`-et (a rendszerkupacon), pontosan megadva az `[T; capacity]` kapacitását és igazítási követelményeit.
    /// Ez egyenértékű az `RawVec::new` hívásával, ha az `capacity` értéke `0`, vagy az `T` értéke nulla.
    /// Ne feledje, hogy ha az `T` nulla méretű, ez azt jelenti, hogy *nem* kapja meg a kért kapacitású `RawVec`-et.
    ///
    /// # Panics
    ///
    /// Panics, ha a kért kapacitás meghaladja az `isize::MAX` bájtokat.
    ///
    /// # Aborts
    ///
    /// Megszakítás az OOM-on.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Mint az `with_capacity`, de garantálja a puffer nullázását.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Helyreállítja az `RawVec`-et egy mutatóból és kapacitásból.
    ///
    /// # Safety
    ///
    /// Az `ptr`-et ki kell osztani (a rendszerkupacon), és az adott `capacity`-szel.
    /// Az `capacity` mérettípusoknál nem haladhatja meg az `isize::MAX` értéket.(csak a 32 bites rendszerekre vonatkozik).
    /// A ZST vectors kapacitása `usize::MAX`-ig terjedhet.
    /// Ha az `ptr` és az `capacity` egy `RawVec` készülékről származik, akkor ez garantált.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Az apró Vecsek némaak.Ugrás a:
    // - 8, ha az elem mérete 1, mert bármely kupacallokátor valószínűleg 8 bájtnál kisebb kérést kerekít legalább 8 bájtra.
    //
    // - 4, ha az elemek közepes méretűek (<=1 KiB).
    // - 1 különben, hogy elkerülje a túl sok hely elpazarlását a nagyon rövid Vecs számára.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Az `new`-hez hasonlóan, de a visszaküldött `RawVec`-hez tartozó allokátor kiválasztása felett paraméterezett.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` jelentése "unallocated".a nulla méretű típusokat figyelmen kívül hagyják.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Az `with_capacity`-hez hasonlóan, de a visszaküldött `RawVec`-hez tartozó allokátor kiválasztása felett paraméterezett.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Az `with_capacity_zeroed`-hez hasonlóan, de a visszaküldött `RawVec`-hez tartozó allokátor kiválasztása felett paraméterezett.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// `Box<[T]>`-et átalakít `RawVec<T>`-be.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// A teljes puffert átalakítja `Box<[MaybeUninit<T>]>`-be a megadott `len`-szel.
    ///
    /// Ne feledje, hogy ez megfelelően helyreállítja az esetlegesen végrehajtott `cap`-módosításokat.(A részletekért lásd a típus leírását.)
    ///
    /// # Safety
    ///
    /// * `len` - nagyobbnak vagy egyenlőnek kell lennie a legutóbb kért kapacitással, és-
    /// * `len` nem lehet kisebb vagy egyenlő, mint `self.capacity()`.
    ///
    /// Ne feledje, hogy a kért kapacitás és az `self.capacity()` eltérhet, mivel az allokátor a kértnél nagyobb memóriablokkot tud összpontosítani és visszaadni.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // A józan ész ellenőrzése a biztonsági követelmény egyik felét (a másik felét nem tudjuk ellenőrizni).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Itt elkerüljük az `unwrap_or_else`-et, mert felfújja a keletkezett LLVM IR mennyiségét.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Feloldja az `RawVec`-et egy mutatóból, kapacitásból és lefoglalóból.
    ///
    /// # Safety
    ///
    /// Az `ptr`-et (az adott `alloc` allokátoron keresztül) és az adott `capacity`-szel kell lefoglalni.
    /// Az `capacity` mérettípusoknál nem haladhatja meg az `isize::MAX` értéket.
    /// (csak a 32 bites rendszerekre vonatkozik).
    /// A ZST vectors kapacitása `usize::MAX`-ig terjedhet.
    /// Ha az `ptr` és az `capacity` az `alloc`-en keresztül létrehozott `RawVec`-ből származik, akkor ez garantált.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Nyers mutatót kap a kiosztás kezdetéhez.
    /// Vegye figyelembe, hogy ez `Unique::dangling()`, ha az `capacity == 0` vagy az `T` nulla méretű.
    /// Az előbbi esetben óvatosnak kell lennie.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Megkapja az allokáció kapacitását.
    ///
    /// Ez mindig `usize::MAX` lesz, ha az `T` nulla méretű.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Megosztott referenciát ad vissza az `RawVec`-et támogató lefoglalónak.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Van egy kiosztott memóriarészünk, így megkerülhetjük a futásidejű ellenőrzéseket, hogy megkapjuk a jelenlegi elrendezésünket.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Biztosítja, hogy a puffer legalább elegendő helyet tartalmazzon az `len + additional` elemek tárolására.
    /// Ha még nincs elegendő kapacitása, akkor elegendő helyet és kényelmes, kevés helyet foglal el az amortizált *O*(1) viselkedés eléréséhez.
    ///
    /// Korlátozni fogja ezt a viselkedést, ha feleslegesen okozná magát a panic-nek.
    ///
    /// Ha az `len` túllépi az `self.capacity()` értéket, akkor előfordulhat, hogy a kért helyet nem osztja ki ténylegesen.
    /// Ez valójában nem veszélyes, de az a funkció, amelyre a függvény viselkedése támaszkodik, az általad írt nem biztonságos kód megszakadhat.
    ///
    /// Ez ideális olyan tömeges nyomás művelet végrehajtásához, mint az `extend`.
    ///
    /// # Panics
    ///
    /// Panics, ha az új kapacitás meghaladja az `isize::MAX` bájtokat.
    ///
    /// # Aborts
    ///
    /// Megszakítás az OOM-on.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // A tartalék megszakadt volna vagy pánikba esett volna, ha a len meghaladja az `isize::MAX` értéket, így ez most ellenőrizhetetlen.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Ugyanaz, mint az `reserve`, de pánikolás vagy megszakítás helyett hiba esetén tér vissza.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Biztosítja, hogy a puffer legalább elegendő helyet tartalmazzon az `len + additional` elemek tárolására.
    /// Ha még nem teszi meg, akkor a lehető legkevesebb memóriát fogja átosztani.
    /// Általában pontosan ez lesz a szükséges memóriamennyiség, de elvben az allokátor szabadon visszaadhat többet, mint amennyit kértünk.
    ///
    ///
    /// Ha az `len` túllépi az `self.capacity()` értéket, akkor előfordulhat, hogy a kért helyet nem osztja ki ténylegesen.
    /// Ez valójában nem veszélyes, de az a funkció, amelyre a függvény viselkedése támaszkodik, az általad írt nem biztonságos kód megszakadhat.
    ///
    /// # Panics
    ///
    /// Panics, ha az új kapacitás meghaladja az `isize::MAX` bájtokat.
    ///
    /// # Aborts
    ///
    /// Megszakítás az OOM-on.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Ugyanaz, mint az `reserve_exact`, de pánikolás vagy megszakítás helyett hiba esetén tér vissza.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Csökkenti az allokációt a megadott összegig.
    /// Ha a megadott összeg 0, akkor valójában teljesen eloszt.
    ///
    /// # Panics
    ///
    /// Panics, ha az adott összeg *nagyobb*, mint a jelenlegi kapacitás.
    ///
    /// # Aborts
    ///
    /// Megszakítás az OOM-on.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Visszatér, ha a puffernek növekednie kell a szükséges extra kapacitás teljesítéséhez.
    /// Főként a tartalékhívások beágyazásának lehetővé tételére szolgálnak az `grow` beillesztése nélkül.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Ezt a módszert általában sokszor példányosítják.Tehát azt akarjuk, hogy a lehető legkisebb legyen, javítsa a fordítási időket.
    // De azt is szeretnénk, hogy a lehető legtöbb tartalma statikusan kiszámítható legyen, hogy a generált kód gyorsabban fusson.
    // Ezért ezt a módszert gondosan írják meg, hogy az `T`-től függő összes kód benne legyen, míg az `T`-től nem függő kódok lehető legnagyobb része olyan funkciókban található, amelyek nem általánosak az `T` felett.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Ezt a hívó összefüggések biztosítják.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Mivel `usize::MAX` kapacitást adunk vissza, amikor az `elem_size` van
            // 0, az idejutás szükségszerűen azt jelenti, hogy az `RawVec` túlteljes.
            return Err(CapacityOverflow);
        }

        // Sajnos semmit sem tehetünk ezek ellen az ellenõrzések ellen.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Ez garantálja az exponenciális növekedést.
        // A duplázás nem tud túlcsordulni, mert az `cap <= isize::MAX` és az `cap` típusa `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` az `T` felett nem általános.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Ennek a módszernek a korlátozásai nagyjából megegyeznek az `grow_amortized`-en, de ez a módszer általában ritkábban jelenik meg, így kevésbé kritikus.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Mivel `usize::MAX` kapacitást adunk vissza, amikor a típus mérete
            // 0, az idejutás szükségszerűen azt jelenti, hogy az `RawVec` túlteljes.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` az `T` felett nem általános.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Ez a funkció az `RawVec`-en kívül esik a fordítási idők minimalizálása érdekében.A részletekért lásd az `RawVec::grow_amortized` fenti megjegyzést.
// (Az `A` paraméter nem jelentős, mert a gyakorlatban látható különböző `A` típusok száma jóval kisebb, mint az `T` típusoké.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Itt ellenőrizheti a hibát az `RawVec::grow_*` méretének minimalizálása érdekében.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Az allokátor ellenőrzi az igazítás egyenlőségét
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Felszabadítja az `RawVec`*tulajdonában lévő memóriát anélkül, hogy* megpróbálná ledobni a tartalmát.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Központi funkció a tartalék hibakezeléshez.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Garantálnunk kell a következőket:
// * Soha nem osztunk ki `> isize::MAX` bájt méretű objektumokat.
// * Nem töltjük túl az `usize::MAX`-et, és valójában túl keveset osztunk ki.
//
// 64 bites rendszeren csak a túlcsordulást kell ellenőriznünk, mivel az `> isize::MAX` bájtok kiosztásának kísérlete biztosan kudarcot vall.
// A 32 bites és 16 bites rendszereken ehhez hozzá kell adnunk egy külön védelmet, ha olyan platformon futunk, amely mind a 4 GB-ot felhasználhatja a felhasználói térben, például PAE vagy x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Az egyik központi funkció, amely a kapacitás túlcsordulásáért felelős.
// Ez biztosítja, hogy az ezekhez a panics-hez kapcsolódó kódgenerálás minimális legyen, mivel a modulban csak egy hely van, amely a panics helyett egy csomópont.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}