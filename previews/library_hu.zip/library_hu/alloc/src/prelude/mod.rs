//! Az allokáció Prelude
//!
//! Ennek a modulnak az a célja, hogy megkönnyítse az `alloc` crate gyakran használt tételeinek behozatalát globális import hozzáadásával a modulok tetejére:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;