//! # A Rust mag kiosztási és gyűjtési könyvtár
//!
//! Ez a könyvtár intelligens mutatókat és gyűjteményeket kínál a halomhoz rendelt értékek kezeléséhez.
//!
//! Ezt a könyvtárat, hasonlóan a libcore-hoz, általában nem kell közvetlenül használni, mivel tartalmát újból exportálják az [`std` crate](../std/index.html)-be.
//! Az `#![no_std]` attribútumot használó Crates azonban általában nem függ az `std`-től, ezért inkább ezt a crate-t használnák.
//!
//! ## Dobozos értékek
//!
//! Az [`Box`] típus intelligens mutatótípus.Egy [`Box`]-nek csak egy tulajdonosa lehet, és a tulajdonos eldöntheti a halomon élő tartalom módosítását.
//!
//! Ez a típus hatékonyan küldhető el a szálak között, mivel az `Box` érték mérete megegyezik a mutató méretével.
//! A faszerű adatszerkezetek gyakran dobozokkal vannak felépítve, mert minden csomópontnak gyakran csak egy tulajdonosa van, a szülő.
//!
//! ## Referencia számlált mutatók
//!
//! Az [`Rc`] típus nem szálbiztonságos referencia-számláló mutatótípus, amelyet memória megosztására szálon belül szánnak.
//! Az [`Rc`] mutató beburkolja az `T` típust, és csak az `&T`-hez, egy megosztott hivatkozáshoz fér hozzá.
//!
//! Ez a típus akkor hasznos, ha az öröklődő mutabilitás (például az [`Box`] használata) túl korlátozó egy alkalmazás számára, és gyakran párosul az [`Cell`] vagy [`RefCell`] típusokkal a mutáció lehetővé tétele érdekében.
//!
//!
//! ## Atomilag hivatkozott számlált mutatók
//!
//! Az [`Arc`] típus az [`Rc`] típus szálbiztonsági megfelelője.Az [`Rc`] összes funkcióját biztosítja, kivéve, hogy a benne lévő `T` típus megosztható legyen.
//! Ezenkívül az [`Arc<T>`][`Arc`] maga is küldhető, míg az [`Rc<T>`][`Rc`] nem.
//!
//! Ez a típus megosztott hozzáférést tesz lehetővé a tartalmazott adatokhoz, és gyakran párosul szinkronizációs primitívekkel, például mutexekkel, hogy lehetővé tegye a megosztott erőforrások mutációját.
//!
//! ## Collections
//!
//! Ebben a könyvtárban vannak meghatározva a leggyakoribb általános célú adatstruktúrák megvalósítása.Újra exportálják őket az [standard collections library](../std/collections/index.html)-en keresztül.
//!
//! ## Halom interfészek
//!
//! Az [`alloc`](alloc/index.html) modul meghatározza az alapszintű interfészt az alapértelmezett globális lefoglalóhoz.Nem kompatibilis a libc lefoglaló API-val.
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// Technikailag ez egy hiba a rustdoc-ban: az rustdoc úgy látja, hogy az `#[lang = slice_alloc]` blokkok dokumentációja az `&[T]`-hez készült, amelynek dokumentációja szintén rendelkezik ezzel a szolgáltatással az `core`-ben, és megőrül, hogy a feature-gate nincs engedélyezve.
// Ideális esetben nem ellenőrizné a crates más dokumentumaihoz tartozó funkciókaput, de mivel ez csak a lang elemeknél jelenhet meg, úgy tűnik, hogy nem érdemes javítani.
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// Engedélyezze a könyvtár tesztelését

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// Más modulok által használt belső makrókkal rendelkező modul (más modulok előtt be kell építeni).
#[macro_use]
mod macros;

// Halmok biztosítottak alacsony szintű allokációs stratégiákhoz

pub mod alloc;

// Primitív típusok a fenti kupacok használatával

// Feltételesen meg kell határoznunk a modot az `boxed.rs`-ből, hogy elkerüljük a lang-elemek másolatát, amikor a teszt cfg-be építünk;de meg kell engedni a kódnak az `use boxed::Box;` deklarációkat is.
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}