#![stable(feature = "wake_trait", since = "1.51.0")]
//! Típusok és Traits az aszinkron feladatok kezeléséhez.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Feladat végrehajtásának végrehajtása egy végrehajtón.
///
/// Ez a trait használható [`Waker`] létrehozására.
/// A végrehajtó meghatározhatja ennek a trait-nek a megvalósítását, és felhasználhatja arra, hogy létrehozzon egy Wakert, amely átadja az adott végrehajtón végrehajtott feladatoknak.
///
/// Ez a trait memóriában biztonságos és ergonómikus alternatíva az [`RawWaker`] gyártásához.
/// Támogatja a közös végrehajtói tervet, amelyben a feladat felébresztésére használt adatokat egy [`Arc`] tárolja.
/// Néhány végrehajtó (különösen a beágyazott rendszereké) nem tudja használni ezt az API-t, ezért létezik az [`RawWaker`] alternatívája ezeknek a rendszereknek.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Alapvető `block_on` függvény, amely felvesz egy future-t, és az aktuális szálon futtatja.
///
/// **Note:** Ez a példa az egyszerűség kedvéért kereskedik.
/// A holtpontok elkerülése érdekében a gyártási szintű megvalósításoknak az `thread::unpark`-re irányuló közbenső hívásokat, valamint a beágyazott meghívásokat is kezelniük kell.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Olyan ébresztő, amely felhívja az aktuális szálat.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Futtasson egy future fájlt az aktuális szál befejezéséig.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Rögzítse a future-t, hogy lekérdezhesse.
///     let mut fut = Box::pin(fut);
///
///     // Hozzon létre egy új kontextust, amelyet továbbít a future fájlnak.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Futtassa a future szoftvert a befejezésig.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Ébressze fel ezt a feladatot.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Hajtsa végre ezt a feladatot anélkül, hogy felemésztené a wakert.
    ///
    /// Ha egy végrehajtó támogatja az ébresztés olcsóbb módját anélkül, hogy a wakert fogyasztaná, akkor felül kell írnia ezt a módszert.
    /// Alapértelmezés szerint klónozza az [`Arc`]-et és felhívja az [`wake`]-et a klónon.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // BIZTONSÁG: Ez azért biztonságos, mert a raw_waker biztonságosan épít
        // egy RawWaker az Arc-tól<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: A RawWaker elkészítéséhez ezt a privát funkciót használják, nem pedig
// ennek beépítése az `From<Arc<W>> for RawWaker` implicitbe annak biztosítására, hogy az `From<Arc<W>> for Waker` biztonsága ne a helyes trait disztribúciótól függjen, ehelyett mindkét implicit közvetlenül és kifejezetten hívja ezt a funkciót.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Növelje az ív referenciaszámát a klónozáshoz.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Ébredjen érték szerint, az ívet az Wake::wake funkcióba helyezve
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Ébredjen referenciaként, tekerje be az ébresztőt a ManuallyDrop-ba, hogy ne ejtse le
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Csökkentse az ív referenciaszámát csökkenéskor
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}