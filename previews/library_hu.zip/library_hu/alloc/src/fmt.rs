//! Segédprogramok a " String` formázásához és nyomtatásához.
//!
//! Ez a modul az [`format!`] szintaxis kiterjesztés futásidejű támogatását tartalmazza.
//! Ezt a makrót úgy hajtják végre a fordítóban, hogy hívásokat bocsásson ki ebbe a modulba annak érdekében, hogy futás közben argumentumokat formázzon stringekké.
//!
//! # Usage
//!
//! Az [`format!`] makrót a C `printf`/`fprintf` vagy Python `str.format` függvényei ismerik.
//!
//! Néhány példa az [`format!`] kiterjesztésre:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" vezető nullákkal
//! ```
//!
//! Ezekből láthatja, hogy az első argumentum egy formátum-karakterlánc.A fordító megköveteli, hogy ez karakterlánc legyen;ez nem lehet egy átadott változó (az érvényesség ellenőrzésének elvégzése érdekében).
//! A fordító ezt követően elemzi a formátum-karakterláncot, és megállapítja, hogy a megadott argumentumlista alkalmas-e ennek a formátum-karakterláncnak az átadására.
//!
//! Egyetlen érték karakterláncokká alakításához használja az [`to_string`] metódust.Ehhez az [`Display`] formázást használja a trait.
//!
//! ## Pozíciós paraméterek
//!
//! Minden formázó argumentum megadhatja, hogy melyik érték argumentumra hivatkozik, és ha kihagyja, akkor azt feltételezzük, hogy "the next argument".
//! Például az `{} {} {}` formátum-karakterlánc három paramétert vesz fel, és azokat ugyanabban a sorrendben formázzák, ahogyan megadták.
//! Az `{2} {1} {0}` formátum karaktersorozat viszont fordított sorrendben formázná az argumentumokat.
//!
//! A dolgok kissé bonyolulttá válhatnak, ha elkezdi keverni a kétféle helyzetmeghatározót.Az "next argument" specifikátor iterátornak tekinthető az argumentum felett.
//! Valahányszor megjelenik egy "next argument" specifikátor, az iterátor továbbhalad.Ez az ilyen viselkedéshez vezet:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Az argumentum belső iterátora az első `{}` megjelenésekor még nem haladt előre, ezért kinyomtatja az első argumentumot.Aztán a második `{}` elérésekor az iterátor előre lépett a második argumentumra.
//! Lényegében azok a paraméterek, amelyek kifejezetten megnevezik az érvüket, nem befolyásolják azokat a paramétereket, amelyek nem neveznek meg argumentumot a helymeghatározók szempontjából.
//!
//! Minden argumentum használatához formátum-karakterláncra van szükség, különben fordítási időbeli hiba.A formátum-karakterláncban többször hivatkozhat ugyanarra az argumentumra.
//!
//! ## Megnevezett paraméterek
//!
//! Maga a Rust nem rendelkezik a függvény Python-szerű megnevezett paramétereinek megfelelőjével, de az [`format!`] makró egy szintaxis kiterjesztés, amely lehetővé teszi a megnevezett paraméterek kihasználását.
//! A megnevezett paraméterek az argumentumlista végén vannak felsorolva, és szintaxissal rendelkeznek:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Például a következő [`format!`] kifejezések mindegyike megnevezett argumentumot használ:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Nem érvényes, ha a helynévi paramétereket (név nélkülieket) nevekkel rendelkező argumentumok után helyezzük el.A helyzetparaméterekhez hasonlóan, a formátum-karakterlánc által fel nem használt megnevezett paraméterek megadása sem érvényes.
//!
//! # Paraméterek formázása
//!
//! Minden formázandó argumentum számos formázási paraméterrel átalakítható (az [the syntax](#syntax))-nek felel meg az [the syntax](#syntax))-ben. Ezek a paraméterek befolyásolják a formázandó karakterlánc-ábrázolását.
//!
//! ## Width
//!
//! ```
//! // Mindezek "Hello x !"-et nyomtatnak
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Ez az "minimum width" paramétere, amelyet a formátumnak ki kell töltenie.
//! Ha az érték karaktersorozata nem tölti ki ezt a sok karaktert, akkor az fill/alignment által megadott kitöltést használjuk a szükséges hely elfoglalására (lásd alább).
//!
//! A szélesség értéke [`usize`]-ként is megadható a paraméterek listájában egy postfix `$` hozzáadásával, jelezve, hogy a második argumentum a szélességet meghatározó [`usize`].
//!
//! A dollár szintaxissal ellátott érvre való hivatkozás nem érinti az "next argument" számlálót, ezért általában érdemes az argumentumokra pozíciónként hivatkozni, vagy megnevezett argumentumokat használni.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Az opcionális kitöltési karakter és igazítás általában az [`width`](#width) paraméterrel együtt kerül megadásra.`width` előtt, közvetlenül az `:` után kell meghatározni.
//! Ez azt jelzi, hogy ha a formázandó érték kisebb, mint `width`, akkor néhány extra karakter kerül kinyomtatásra.
//! A kitöltés a következő változatokkal lehetséges a különböző igazításokhoz:
//!
//! * `[fill]<` - az argumentum balra igazítva az `width` oszlopokban
//! * `[fill]^` - az argumentum középre igazítva az `width` oszlopokban
//! * `[fill]>` - az argumentum jobbra igazított az `width` oszlopokban
//!
//! A nem numerikus alapértelmezett [fill/alignment](#fillalignment) szóköz és balra igazítva.A numerikus formázók alapértelmezett értéke szintén szóköz, de jobbra igazítva.
//! Ha az `0` jelzőt (lásd alább) megadjuk a numerikus számokhoz, akkor az implicit kitöltési karakter `0`.
//!
//! Ne feledje, hogy az igazítást egyes típusok nem biztos, hogy megvalósítják.Különösen az `Debug` trait esetében nem alkalmazható.
//! A kitöltés alkalmazásának jó módja a bemenet formázása, majd a kapott karaktersorozat kitöltése a kimenet megszerzéséhez:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Hello Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Ezek mindegyike megváltoztatja a formázó viselkedését.
//!
//! * `+` - Ez numerikus típusokra szolgál, és azt jelzi, hogy a jelet mindig ki kell nyomtatni.A pozitív jeleket alapértelmezés szerint soha nem nyomtatják, a negatív jeleket pedig csak az `Signed` trait esetén alapértelmezés szerint.
//! Ez a jelző azt jelzi, hogy mindig a megfelelő jelet (`+` vagy `-`) kell kinyomtatni.
//! * `-` - Jelenleg nincs használatban
//! * `#` - Ez a jelölés azt jelzi, hogy az "alternate" nyomtatási formát kell használni.Az alternatív formák:
//!     * `#?` - szépen kinyomtatni az [`Debug`] formázást
//!     * `#x` - `0x`-el előzi meg az érvelést
//!     * `#X` - `0x`-el előzi meg az érvelést
//!     * `#b` - `0b`-el előzi meg az érvelést
//!     * `#o` - `0o`-el előzi meg az érvelést
//! * `0` - Ezt arra használják, hogy egész szám formátumok esetén jelezzék, hogy az `width`-be történő kitöltést `0` karakterrel kell végrehajtani, valamint előjel-tudatosnak kell lennie.
//! Az `{:08}` formátumhoz hasonló formátum az `1` egész számhoz `00000001`, míg az `-1` egész számhoz `-0000001`.
//! Vegye figyelembe, hogy a negatív változat eggyel kevesebb nulla, mint a pozitív változat.
//!         Ne feledje, hogy a kitöltési nullák mindig a jel (ha van) után és a számjegyek előtt helyezkednek el.Az `#` zászlóval együtt használva hasonló szabály érvényes: a kitöltési nullák az előtag után, de a számjegyek előtt kerülnek beillesztésre.
//!         Az előtagot a teljes szélesség tartalmazza.
//!
//! ## Precision
//!
//! Nem numerikus típusoknál ez "maximum width"-nek tekinthető.
//! Ha az eredményül kapott karakterlánc hosszabb, mint ez a szélesség, akkor ennyi karakterig csonkolódik, és ez a csonka érték megfelelő `fill`, `alignment` és `width` értékkel kerül kiadásra, ha ezek a paraméterek be vannak állítva.
//!
//! Az integrált típusoknál ezt figyelmen kívül hagyják.
//!
//! Lebegőpontos típusoknál ez jelzi, hogy a tizedesjegy után hány számjegyet kell kinyomtatni.
//!
//! Háromféleképpen adhatja meg a kívánt `precision`-t:
//!
//! 1. `.N` egész szám:
//!
//!    maga az `N` egész szám a pontosság.
//!
//! 2. Egész szám vagy név, amelyet dollárjel követ `.N$`:
//!
//!    formátum *argumentum*`N` (amelynek `usize` kell, hogy legyen) pontosságként.
//!
//! 3. Csillag `.*`:
//!
//!    `.*` azt jelenti, hogy ez az `{...}` egy *helyett* két * formátumú bemenethez van társítva: az első bemenet az `usize` pontosságát tartja, a második pedig a nyomtatni kívánt értéket.
//!    Vegye figyelembe, hogy ebben az esetben, ha valaki az `{<arg>:<spec>.*}` formátumú karakterláncot használja, akkor az `<arg>` rész a* értékre * utal a nyomtatáshoz, és az `precision`-nek az `<arg>` előtti bemenetben kell lennie.
//!
//! Például a következő hívások mindegyike ugyanazt az `Hello x is 0.01000`-t nyomtatja:
//!
//! ```
//! // Helló, az {arg 0 ("x")} az {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Helló, az {arg 1 ("x")} az {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Helló, az {arg 0 ("x")} az {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Helló, az {next arg ("x")} az {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Helló, az {next arg ("x")} az {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Helló, az {next arg ("x")} az {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Míg ezek:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! három jelentősen különböző dolgot nyomtat:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Egyes programozási nyelvekben a karakterlánc-formázási függvények viselkedése az operációs rendszer területi beállításaitól függ.
//! A Rust szabványos könyvtárának formázási funkciói nem tartalmazzák a területi beállítás fogalmát, és a felhasználói konfigurációtól függetlenül minden rendszeren ugyanazokat az eredményeket fogják szolgáltatni.
//!
//! Például a következő kód mindig kinyomtatja az `1.5`-et, még akkor is, ha a rendszer területi beállításai ponttól eltérő tizedes elválasztót használnak.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Az `{` és `}` szó szerinti karaktereket egy karakterláncba beilleszthetjük, ugyanazzal a karakterrel megelőzve őket.Például az `{` karakter az `{{`, az `}` karakter pedig az `}}` paranccsal kerül megkerülésre.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Összefoglalva, itt megtalálja a formátum karakterláncok teljes nyelvtanát.
//! A használt formázási nyelv szintaxisa más nyelvekből származik, ezért nem lehet túl idegen.Az érvek formázása Python-szerű szintaxissal történik, ami azt jelenti, hogy az argumentumokat a C-szerű `%` helyett `{}` veszi körül.
//! A formázási szintaxis tényleges nyelvtana a következő:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! A fenti nyelvtanban az `text` nem tartalmazhat `'{'` vagy `'}'` karaktereket.
//!
//! # A traits formázása
//!
//! Amikor egy argumentumot egy adott típussal kell formázni, akkor valójában azt kéri, hogy egy argumentum tulajdonítson egy adott trait-t.
//! Ez lehetővé teszi több tényleges típus formázását az `{:x}`-en keresztül (például az [`i8`] és az [`isize`]).A típusok jelenlegi hozzárendelése a traits-hez:
//!
//! * *semmi* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] kisbetűs hexadecimális egész számokkal
//! * `X?` ⇒ [`Debug`] nagybetűs hexadecimális egész számokkal
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Ez azt jelenti, hogy az [`fmt::Binary`][`Binary`] trait bármelyik argumentumát az `{:b}`-szel formázhatjuk.Ezeknek a traits-nek számos primitív típust implementál a standard könyvtár is.
//!
//! Ha nincs megadva formátum (mint az `{}` vagy `{:6}` esetén), akkor az alkalmazott trait formátum az [`Display`] trait.
//!
//! Ha a trait formátumot saját típusához implementálja, akkor meg kell valósítania az aláírás módszerét:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // egyedi típusunk
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Az Ön típusát `self` hivatkozásként továbbítja, majd a függvénynek kimenetet kell kibocsátania az `f.buf` adatfolyamba.Minden egyes formátum trait megvalósításán múlik, hogy megfelelően betartják-e a kért formázási paramétereket.
//! Ezen paraméterek értékei fel lesznek sorolva az [`Formatter`] struct mezõiben.Ennek segítése érdekében az [`Formatter`] struct néhány segítő módszert is tartalmaz.
//!
//! Ezenkívül ennek a függvénynek a visszatérési értéke [`fmt::Result`], amely a ["Eredmény"] <(), "[" std: : fmt::Hiba "]"> "típus álneve.
//! A megvalósítások formázásával biztosítani kell, hogy azok továbbítsák a hibákat az [`Formatter`]-ről (pl. Az [`write!`] hívásakor).
//! A hibákat azonban soha nem szabad hamisan visszaadniuk.
//! Vagyis a formázási megvalósítás csak akkor adhat hibát, ha az átadott [`Formatter`] hibát ad vissza.
//! A karakterlánc formázása ugyanis ellentétben azzal, amit a funkció aláírása sugallhat, tévedhetetlen művelet.
//! Ez a függvény csak azért ad eredményt, mert az alapul szolgáló adatfolyamba történő írás sikertelen lehet, és módot kell adnia arra, hogy tovább terjessze azt a tényt, hogy hiba történt a verem mentésében.
//!
//! Példa a traits formázás megvalósítására a következőképpen néz ki:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Az `f` érték az `Write` trait-t valósítja meg, ezt írja az írás!makró számít.
//!         // Vegye figyelembe, hogy ez a formázás figyelmen kívül hagyja a karakterláncokhoz megadott különféle jelölőket.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // A különböző traits lehetővé teszi egy típusú kimenet különböző formáit.
//! // Ennek a formátumnak a jelentése a vector nagyságának kinyomtatása.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Tartsa tiszteletben a formázási jelzőket az `pad_integral` segítő módszer használatával a Formázás objektumon.
//!         // A részletekért olvassa el a módszer dokumentációját, és az `pad` funkció használható a húrok kitöltésére.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! A traits e két formázásnak külön célja van:
//!
//! - [`fmt::Display`][`Display`] a megvalósítások azt állítják, hogy a típus mindig hűen ábrázolható UTF-8 karakterláncként.**Nem** várható, hogy minden típus megvalósítja az [`Display`] trait-t.
//! - [`fmt::Debug`][`Debug`] a megvalósításokat **minden** nyilvános típusra be kell vezetni.
//!   Az output általában a lehető leghűségesebben fogja képviselni a belső állapotot.
//!   Az [`Debug`] trait célja a Rust kód hibakeresésének megkönnyítése.A legtöbb esetben elegendő és ajánlott az `#[derive(Debug)]` használata.
//!
//! Néhány példa mindkét traits kimenetére:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Kapcsolódó makrók
//!
//! Az [`format!`] családban számos kapcsolódó makró található.A jelenleg megvalósítottak a következők:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Ez és az [`writeln!`] két makró, amelyek a formátum-karakterláncot egy megadott folyamba bocsátják ki.Ez megakadályozza a formátum-karakterláncok közbenső kiosztását, és ehelyett közvetlenül írja a kimenetet.
//! A motorháztető alatt ez a funkció valójában az [`std::io::Write`] trait-n definiált [`write_fmt`] funkciót hívja meg.
//! Példa a felhasználásra:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Ez és az [`println!`] kibocsátja a kimenetüket a stdout számára.Az [`write!`] makróhoz hasonlóan ezeknek a makróknak a célja a köztes allokációk elkerülése a kimenet nyomtatásakor.Példa a felhasználásra:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Az [`eprint!`] és [`eprintln!`] makrók megegyeznek az [`print!`] és az [`println!`] makrókkal, azzal a különbséggel, hogy a kimenetüket a stderr felé bocsátják.
//!
//! ### `format_args!`
//!
//! Ez egy kíváncsi makró, amelyet a formátum-karakterláncot leíró átlátszatlan objektum biztonságos áthaladására használnak.Ehhez az objektumhoz nincs szükség halomallokációk létrehozására, és csak a veremben található információkra hivatkozik.
//! A motorháztető alatt az összes kapcsolódó makrót ennek értelmében valósítják meg.
//! Először is, néhány példa a felhasználásra:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Az [`format_args!`] makró eredménye egy [`fmt::Arguments`] típusú érték.
//! Ezt a struktúrát aztán át lehet adni a modul belsejében található [`write`] és [`format`] függvényeknek a formátum karakterlánc feldolgozása érdekében.
//! Ennek a makrónak az a célja, hogy még jobban megakadályozza a köztes allokációkat a karakterláncok formázásakor.
//!
//! Például egy naplózó könyvtár használhatja a szokásos formázási szintaxist, de belsőleg áthaladna ezen a struktúrán, amíg meg nem határozják, hová kerüljön a kimenet.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Az `format` függvény felvesz egy [`Arguments`] struktúrát és visszaadja az így kapott formázott karakterláncot.
///
///
/// Az [`Arguments`] példány az [`format_args!`] makróval hozható létre.
///
/// # Examples
///
/// Alapvető használat:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Felhívjuk figyelmét, hogy előnyösebb lehet az [`format!`] használata.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}