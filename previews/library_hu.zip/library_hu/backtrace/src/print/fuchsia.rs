use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // A dl_iterate_phdr visszahívást kezdeményez, amely dl_phdr_info mutatót kap minden, a folyamatba kapcsolt DSO-ról.
    // A dl_iterate_phdr azt is biztosítja, hogy a dinamikus linker az iteráció elejétől a végéig zárolva legyen.
    // Ha a visszahívás nem nulla értéket ad vissza, az iteráció korán megszakad.
    // 'data' minden hívás visszahívásának harmadik argumentumaként kerül továbbításra.
    // 'size' megadja a dl_phdr_info méretét.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Ki kell elemeznünk a build azonosítót és néhány alapvető programfejléc adatot, ami azt jelenti, hogy szükségünk van egy kis cuccra az ELF specifikációból is.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Most bitről bitre meg kell ismételnünk a fukszia jelenlegi dinamikus összekapcsolója által használt dl_phdr_info típusú struktúrát.
// A Chromiumnak megvan az ABI határa, valamint a törlõpad.
// Szeretnénk ezeket az eseteket az elf-search használatára áthelyezni, de ezt meg kell adnunk az SDK-ban, és ez még nem történt meg.
//
// Így nekünk (és nekik) meg kell ragadnunk, ha ezt a módszert kell használnunk, amely szoros összekapcsolódást eredményez a fukszia libc-vel.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Nincs módunk tudni ellenőrizni, hogy az e_phoff és az e_phnum érvényesek-e.
    // A libc-nek ezt biztosítania kell számunkra, így itt biztonságosan lehet szeletet alkotni.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Az Elf_Phdr egy 64 bites ELF programfejlécet képvisel a célarchitektúra végességében.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// A Phdr egy érvényes ELF programfejlécet és annak tartalmát jelenti.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Nincs módunk ellenőrizni, hogy a p_addr vagy a p_memsz érvényes-e.
    // A Fukszia libc-je először elemzi a jegyzeteket, azonban az ittlét miatt ezeknek a fejléceknek érvényesnek kell lenniük.
    //
    // A NoteIter nem követeli meg az alapul szolgáló adatok érvényességét, de a határok érvényességét.
    // Bízunk benne, hogy a libc biztosította, hogy itt nálunk is ez a helyzet.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// A build-azonosítók jegyzettípusa.
const NT_GNU_BUILD_ID: u32 = 3;

// Az Elf_Nhdr egy ELF megjegyzés fejlécet képvisel a cél endianitásában.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// A Note egy ELF megjegyzés (fejléc + tartalom).
// A nevet u8 szeletként hagyják, mert nem mindig szűnik meg, és a rust megkönnyíti annak ellenőrzését, hogy a bájtok mindkét esetben megfelelnek-e.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// A NoteIter segítségével biztonságosan iterálhat egy hangszegmens felett.
// Megszűnik, amint hiba lép fel, vagy nincs több jegyzet.
// Ha érvénytelen adatokat ismételget, akkor úgy fog működni, mintha nem találtak volna megjegyzéseket.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // A függvény változatlan, hogy a megadott mutató és méret egy érvényes bájttartományt jelöl, amelyek mindegyike olvasható.
    // Ezeknek a bájtoknak a tartalma bármi lehet, de a tartománynak érvényesnek kell lennie, hogy ez biztonságos legyen.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to igazítja az 'x'-et a "bájt" igazításhoz, feltéve, hogy az 'to' értéke 2.
// Ez egy szokásos mintát követ a C/C ++ ELF elemzési kódban, ahol (x + to, 1) és -to használatos.
// A Rust nem engedi megtagadni a felhasználást, ezért használom
// 2-komplement átalakítás ennek újrateremtésére.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// A take_bytes_align4 elfogyasztja a szelet bájtjait (ha vannak), és biztosítja, hogy a végső szelet megfelelően illeszkedjen.
// Ha vagy a kért bájtok száma túl nagy, vagy a szelet utólag nem lehet újrarendezni, mert nincs elég fennmaradó bájt, akkor a Nincs értéket adjuk vissza, és a szelet nem módosul.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Ennek a funkciónak nincsenek valós invariánsai, amelyeket a hívó félnek támogatnia kell, kivéve talán azt, hogy az 'bytes'-et igazítani kell a teljesítmény érdekében (és egyes architektúrákon a helyesség).
// Lehet, hogy az Elf_Nhdr mezőkben szereplő értékek értelmetlenek, de ez a függvény nem biztosítja ilyesmit.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Ez addig biztonságos, amíg elegendő hely van, és csak megerősítettük, hogy a fenti if utasításban ez nem lehet veszélyes.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Ne feledje, hogy sice_of: :<Elf_Nhdr>() mindig 4 bájtos igazítású.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Ellenőrizze, hogy elértük-e a végét.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Átalakítunk egy nhdr-t, de alaposan átgondoljuk az eredményül kapott struktúrát.
        // Nem bízunk a nameszben vagy a descsz-ben, és a típus alapján nem hozunk veszélyes döntéseket.
        //
        // Tehát akkor is biztonságban kell lennünk, ha teljes szemetet szállítunk ki.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Jelzi, hogy egy szegmens futtatható.
const PERM_X: u32 = 0b00000001;
/// Jelzi, hogy egy szegmens írható.
const PERM_W: u32 = 0b00000010;
/// Jelzi, hogy egy szegmens olvasható.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Futás közben egy ELF szegmenst képvisel.
struct Segment {
    /// Megadja a szegmens tartalmának futásidejű virtuális címét.
    addr: usize,
    /// Megadja ennek a szegmensnek a memóriáját.
    size: usize,
    /// Megadja ennek a szegmensnek a modul virtuális címét az ELF fájllal.
    mod_rel_addr: usize,
    /// Megadja az ELF fájlban található engedélyeket.
    /// Ezek az engedélyek azonban nem feltétlenül a futás közben meglévő engedélyek.
    flags: Perm,
}

/// Lehetővé teszi az egyik iterációt a szegmensek felett egy DSO-tól.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// ELF DSO-t (dinamikus megosztott objektum) képvisel.
/// Ez a típus a tényleges DSO-ban tárolt adatokra hivatkozik ahelyett, hogy saját másolatot készítene.
struct Dso<'a> {
    /// A dinamikus linker mindig nevet ad nekünk, még akkor is, ha a név üres.
    /// A futtatható fájl esetében ez a név üres lesz.
    /// Megosztott objektum esetén ez lesz a szoname (lásd DT_SONAME).
    name: &'a str,
    /// A Fuksziában gyakorlatilag minden bináris fájl rendelkezik beépítési azonosítóval, de ez nem szigorú követelmény.
    /// Utána nincs mód a DSO-adatok valódi ELF fájlokkal való összehangolására, ha nincs build_id, ezért megköveteljük, hogy minden DSO-nak legyen itt egy.
    ///
    /// A build_id nélküli DSO-kat figyelmen kívül hagyják.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Iterátort ad vissza a DSO szegmensei fölött.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Ezek a hibák olyan kérdéseket kódolnak, amelyek az egyes DSO-k információinak elemzése közben merülnek fel.
///
enum Error {
    /// A NameError azt jelenti, hogy hiba történt egy C stílusú karakterlánc rust karakterláncba történő átalakításakor.
    ///
    NameError(core::str::Utf8Error),
    /// A BuildIDError azt jelenti, hogy nem találtunk build-azonosítót.
    /// Ennek oka lehet az, hogy a DSO-nak nem volt buildazonosítója, vagy pedig azért, mert a buildazonosítót tartalmazó szegmens hibásan alakult.
    ///
    BuildIDError,
}

/// 'dso'-et vagy 'error'-t hív minden egyes DSO-hoz, amelyet a dinamikus összekapcsoló a folyamathoz kapcsol.
///
///
/// # Arguments
///
/// * `visitor` - Egy DsoPrinter, amely rendelkezik a foreach DSO nevű evési módszerek egyikével.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // A dl_iterate_phdr biztosítja, hogy az info.name egy érvényes helyre mutasson.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Ez a funkció kinyomtatja a Fuchsia szimbolizáló jelölést a DSO-ban található összes információra.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}