#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Formátum a visszakövetésekhez.
///
/// Ezzel a típussal visszafelé lehet nyomtatni, függetlenül attól, hogy maga a nyomkövetés honnan származik.
/// Ha `Backtrace` típusú, akkor az `Debug` megvalósítása már ezt a nyomtatási formátumot használja.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// A nyomtatási stílusok, amelyeket ki tudunk nyomtatni
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Terser backtrace-t nyomtat, amely ideális esetben csak releváns információkat tartalmaz
    Short,
    /// Kinyomtat egy visszajelzést, amely minden lehetséges információt tartalmaz
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Hozzon létre egy új `BacktraceFmt`-et, amely a kimenetet írja a mellékelt `fmt`-be.
    ///
    /// Az `format` argumentum vezérli a visszalépés nyomtatásának stílusát, az `print_path` argumentum pedig a fájlnevek `BytesOrWideString` példányainak kinyomtatására szolgál.
    /// Ez a típus önmagában nem nyomtat fájlneveket, de ehhez a visszahívás szükséges.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Kinyomtat egy preambulumot a nyomtatás előtt álló visszalépéshez.
    ///
    /// Erre néhány platformon szükség van ahhoz, hogy a visszakövetés később teljes mértékben szimbolizálódjon, különben ennek csak az első módszert kell meghívnia az `BacktraceFmt` létrehozása után.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Keretet ad a backtrace kimenethez.
    ///
    /// Ez az elkötelezettség egy `BacktraceFrameFmt` RAII példányát adja vissza, amely felhasználható egy keret tényleges kinyomtatására, és megsemmisítéskor növeli a keretszámlálót.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Befejezi a backtrace kimenetet.
    ///
    /// Ez jelenleg nem engedélyezett, de hozzáadódik a future kompatibilitásához a backtrace formátumokkal.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Jelenleg nincs opció-beleértve ezt a hook-t is, hogy lehetővé tegye a future kiegészítéseket.
        Ok(())
    }
}

/// Formázó a backtrace egyetlen képkockájához.
///
/// Ezt a típust az `BacktraceFmt::frame` függvény hozza létre.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Ezzel a képformázóval nyomtat egy `BacktraceFrame`-et.
    ///
    /// Ez rekurzívan kinyomtatja az `BacktraceFrame` összes `BacktraceSymbol` példányát.
    ///
    /// # Szükséges funkciók
    ///
    /// Ehhez a funkcióhoz engedélyezni kell az `backtrace` crate `std` szolgáltatását, és az `std` szolgáltatás alapértelmezés szerint engedélyezve van.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// `BacktraceSymbol` nyomtatása `BacktraceFrame`-en belül.
    ///
    /// # Szükséges funkciók
    ///
    /// Ehhez a funkcióhoz engedélyezni kell az `backtrace` crate `std` szolgáltatását, és az `std` szolgáltatás alapértelmezés szerint engedélyezve van.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: ez nem nagy, hogy végül nem nyomtatunk ki semmit
            // nem utf8 fájlnevekkel.
            // Szerencsére szinte minden utf8, így ez nem lehet túl rossz.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Nyersen nyomon követett `Frame` és `Symbol` nyomtat, általában ennek a crate nyers visszahívásainak belsejéből.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Nyers keretet ad a backtrace kimenethez.
    ///
    /// Ez a módszer, az előzőtől eltérően, a nyers érveket veszi fel arra az esetre, ha különböző helyről származnak.
    /// Vegye figyelembe, hogy ezt egy keretnél többször is meg lehet hívni.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Nyers keretet ad a backtrace kimenethez, az oszlopinformációkat is beleértve.
    ///
    /// Ez a módszer, az előzőhöz hasonlóan, a nyers érveket veszi fel arra az esetre, ha különböző helyről származnak.
    /// Vegye figyelembe, hogy ezt egy keretnél többször is meg lehet hívni.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // A fukszia nem képes szimbolizálni egy folyamaton belül, ezért van egy speciális formátuma, amelyet később szimbolizálni lehet.
        // Itt nyomtassa ki, ahelyett, hogy saját formátumban nyomtatna címeket.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Nem kell "null" képkockákat nyomtatni, ez alapvetően csak azt jelenti, hogy a rendszer visszafelé nyomulása kissé lelkesen volt képes szuper messzire vezetni.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // A TCB méretének csökkentése érdekében az Sgx enklávéban nem akarunk szimbólumfelbontási funkciót megvalósítani.
        // Inkább itt nyomtathatjuk ki a cím eltolását, amelyet később leképezhetünk a helyes működés érdekében.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Nyomtassa ki a keret indexét, valamint a keret opcionális utasításmutatóját.
        // Ha túl vagyunk a keret első szimbólumán, bár csak megfelelő szóközt nyomtatunk.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Ezután írja ki a szimbólum nevét, az alternatív formázással további információkért, ha teljes visszajelzés vagyunk.
        // Itt olyan szimbólumokat is kezelünk, amelyeknek nincs neve,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // És utoljára nyomtassa ki az filename/line számot, ha rendelkezésre állnak.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line a szimbólum neve alatt található vonalakra vannak nyomtatva, ezért nyomtasson ki néhány megfelelő szóközt az önmagunk jobbra igazításához.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Delegáljon a belső visszahívásunkra a fájlnév kinyomtatásához, majd a sorszám kinyomtatásához.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Adja meg az oszlop számát, ha rendelkezésre áll.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Csak a keret első szimbóluma érdekel
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}