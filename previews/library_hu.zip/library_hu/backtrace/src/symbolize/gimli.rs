//! A szimbólumok támogatása az `gimli` crate használatával az crates.io készüléken
//!
//! Ez a Rust alapértelmezett szimbolizációs megvalósítása.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // A statikus élettartam hazugság az önreferenciális struktúrák támogatásának hiánya körül.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Konvertáljon statikus élettartamra, mivel a szimbólumoknak csak az `map` és `stash` eszközöket kellene kölcsönkérniük, és az alábbiakban megőrizzük őket.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // A natív könyvtárak Windows-re történő betöltéséhez lásd az rust-lang/rust#71060-ről szóló beszélgetést a különböző stratégiákról.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // A MinGW könyvtárak jelenleg nem támogatják az ASLR (rust-lang/rust#16514)-et, de a DLL-ek továbbra is áthelyezhetők a címtérbe.
            // Úgy tűnik, hogy a hibakeresési információkban szereplő címek mind olyanok, mintha ezt a könyvtárat az "image base"-en töltötték volna be, ami egy mező a COFF fájlfejlécekben.
            // Mivel úgy tűnik, hogy a debuginfo ezt felsorolja, úgy elemezzük a szimbólumtáblát és tároljuk a címeket, mintha a könyvtárat az "image base"-nél is feltöltötték volna.
            //
            // Lehetséges, hogy a könyvtár nem töltődik be az "image base"-en.
            // (feltehetően valami mást tölthetnek be oda?) Itt játszik szerepet az `bias` mező, és itt kell kitalálnunk az `bias` értékét.Sajnos, bár nem világos, hogyan lehet ezt megszerezni egy betöltött modulból.
            // Megvan azonban az (`modBaseAddr`) tényleges terhelési cím.
            //
            // Most egy kicsit cop-outként mmapozzuk a fájlt, elolvassuk a fájl fejlécének adatait, majd eldobjuk az mmapot.Ez pazarló, mert valószínűleg később újra megnyitjuk az mmap-ot, de ennek egyelőre elég jól kell működnie.
            //
            // Miután megvan az `image_base` (kívánt betöltési hely) és az `base_addr` (tényleges betöltési hely), kitölthetjük az `bias`-et (a tényleges és a kívánt közötti különbség), majd az egyes szegmensek megadott címe az `image_base`, mivel a fájl ezt mondja.
            //
            //
            // Egyelőre úgy tűnik, hogy az ELF/MachO-től eltérően könyvtáranként egy szegmenssel tudunk megbirkózni, teljes méretként az `modBaseSize`-et használva.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS a Mach-O fájlformátumot használja, és a DYLD-specifikus API-kat használja az alkalmazás részét képező natív könyvtárak listájának betöltésére.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Hívja be ennek a könyvtárnak a nevét, amely megfelel a betöltési útvonalának is.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Töltse be ennek a könyvtárnak a képfejlécét, és delegálja az `object`-hez az összes betöltési parancs elemzéséhez, hogy az itt szereplő összes szegmenst kitalálhassuk.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Ismételd meg a szegmenseket, és regisztráld az ismert régiókat a megtalált szegmensekhez.
            // Ezenkívül rögzítse az információs szövegrészeket későbbi feldolgozás céljából, lásd az alábbi megjegyzéseket.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Határozza meg ennek a könyvtárnak az "slide" értékét, amely végül az a torzítás, amelyet arra használunk, hogy kitaláljuk, hol vannak a memóriában objektumok.
            // Ez egy kicsit furcsa számítás, és annak eredménye, hogy megpróbáltam néhány dolgot a vadonban, és megláttuk, mi ragad meg.
            //
            // Általános elképzelés szerint az `bias` és egy szegmens `stated_virtual_memory_address`-je ott lesz, ahol a tényleges címtérben a szegmens található.
            // A másik dolog, amire támaszkodunk, az az, hogy az `bias` mínusz valódi cím az index, amelyet meg kell keresni a szimbólumtáblában és a debuginfóban.
            //
            // Kiderült azonban, hogy a rendszerrel töltött könyvtárak esetében ezek a számítások helytelenek.A natív futtatható fájlok esetében azonban helyesnek tűnik.
            // Néhány logikát kiemelve az LLDB forrásából, van egy speciális burkolata az első `__TEXT` szakasz számára, amely a 0 fájleltolásból töltődik be, nem nulla méretben.
            // Bármi okból, amikor ez jelen van, úgy tűnik, hogy ez azt jelenti, hogy a szimbólumtábla csak a könyvtár vmaddr diájához viszonyul.
            // Ha *nincs*, akkor a szimbólumtábla a vmaddr diához és a szegmens megadott címéhez viszonyítva van.
            //
            // Ha ezt a helyzetet kezeljük, ha nem találunk szöveges szakaszt a fájl nullánál, akkor növeljük az elfogultságot az első szöveges szakaszok megadott címével, és az összes megadott címet ezzel az összeggel csökkentjük.
            //
            // Így a szimbólumtábla mindig megjelenik a könyvtár elfogultságához viszonyítva.
            // Úgy tűnik, hogy ennek megfelelő eredményei vannak a szimbólumtáblán keresztüli szimbolizáláshoz.
            //
            // Őszintén szólva nem vagyok teljesen biztos abban, hogy ez helyes-e, vagy van valami más, ami jelezné, hogyan kell ezt csinálni.
            // Egyelőre bár úgy tűnik, hogy ez elég jól működik az (?)-nél, és szükség esetén mindig képesnek kell lenniünk erre az idő múlásával.
            //
            // További információkért lásd: #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Egyéb Unix (pl
        // Linux) platformok az ELF-et használják objektumfájl-formátumként, és a natív könyvtárak betöltéséhez általában `dl_iterate_phdr` nevű API-t valósítanak meg.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` érvényes mutatóknak kell lenniük.
        // `vec` érvényes mutatónak kell lennie egy `std::Vec`-re.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 nem támogatja natívan a hibakeresési információkat, de a build rendszer a hibakeresési információkat az `romfs:/debug_info.elf` elérési útvonalra helyezi.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Minden másnak az ELF-et kell használnia, de nem tudja, hogyan töltse be a natív könyvtárakat.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Az összes ismert megosztott könyvtár, amelyet betöltöttek.
    libraries: Vec<Library>,

    /// Leképezési gyorsítótár, ahol megtartjuk az elemzett törpe információkat.
    ///
    /// Ez a lista rögzített kapacitással rendelkezik a teljes menetidőre vonatkozóan, amely soha nem növekszik.
    /// Minden pár `usize` eleme egy index a fenti `libraries`-be, ahol `usize::max_value()` az aktuális futtathatót jelöli.
    ///
    /// Az `Mapping` a megfelelő elemzett törpe információ.
    ///
    /// Ne feledje, hogy ez alapvetően egy LRU gyorsítótár, ezért a címeket szimbolizálva itt áthelyezzük a dolgokat.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// A könyvtár szegmensei betöltődnek a memóriába, és hol vannak betöltve.
    segments: Vec<LibrarySegment>,
    /// Ennek a könyvtárnak az "bias"-je, általában ott, ahol a memóriába van töltve.
    /// Ezt az értéket hozzáadjuk az egyes szegmensek megadott címéhez, hogy megkapjuk a tényleges virtuális memória címet, amelybe a szegmens be van töltve.
    /// Ez a torzítás kivonásra kerül a valós virtuális memória címekből a debuginfóba és a szimbólumtáblába történő indexelés céljából.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// A szegmens megadott címe az objektumfájlban.
    /// Valójában nem itt töltődik be a szegmens, hanem ez a cím és a benne lévő könyvtár `bias`-je található.
    ///
    stated_virtual_memory_address: usize,
    /// A memória szegmensének mérete.
    len: usize,
}

// nem biztonságos, mert ezt külső szinkronizálás szükséges
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // nem biztonságos, mert ezt külső szinkronizálás szükséges
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Nagyon kicsi, nagyon egyszerű LRU gyorsítótár a hibakeresési információ leképezésekhez.
        //
        // A találati aránynak nagyon magasnak kell lennie, mivel a tipikus verem nem kereszteződik sok megosztott könyvtár között.
        //
        // Az `addr2line::Context` struktúrák létrehozása meglehetősen drága.
        // Költségét várhatóan amortizálni fogják az ezt követő `locate` lekérdezések, amelyek kihasználják az `addr2line: : Context`s építésénél felépített struktúrákat, hogy szép gyorsításokat kapjanak.
        //
        // Ha nem rendelkeznénk ezzel a gyorsítótárral, akkor az amortizáció soha nem történne meg, és a visszavonulások szimbolizálása ssssllllooooowwww lenne.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Először tesztelje, hogy ennek az `lib`-nek van-e olyan szegmense, amely tartalmazza az `addr`-et (az áthelyezés kezelése).Ha ez az ellenőrzés sikeres, akkor folytathatjuk az alábbiakban, és lefordíthatjuk a címet.
                //
                // Vegye figyelembe, hogy az `wrapping_add`-et itt használjuk a túlcsordulás-ellenőrzések elkerülése érdekében.A vadonban látták, hogy az SVMA + torzítási számítás túlcsordul.
                // Kicsit furcsának tűnik, hogy ez megtörténne, de nincs hatalmas összeg, amit tehetnénk ellene, azon kívül, hogy valószínűleg csak figyelmen kívül hagyjuk ezeket a szegmenseket, mivel valószínűleg az űrbe mutatnak.
                //
                // Ez eredetileg rust-lang/backtrace-rs#329-ben jelent meg.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Most, hogy tudjuk, hogy az `lib` tartalmazza az `addr`-et, ellensúlyozhatjuk az elfogultsággal, hogy megtaláljuk a megadott virtuális memória címet.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Változó: miután ez a feltétel teljes, korai visszatérés nélkül
        // hibából az útvonal gyorsítótár-bejegyzése a 0. indexen található.

        if let Some(idx) = idx {
            // Amikor a leképezés már a gyorsítótárban van, vigye előre.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Ha a leképezés nincs a gyorsítótárban, hozzon létre egy új leképezést, helyezze be a gyorsítótár elejébe, és szükség esetén tegye ki a legrégebbi gyorsítótár-bejegyzést.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // ne szivárogtassa ki az `'static` élettartamát, győződjön meg arról, hogy csak saját magunk számára készült
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Hosszabbítsa meg az `sym` élettartamát az `'static`-re, mivel sajnos nekünk kell itt lennie, de ez mindig referenciaként megy ki, így a kereten kívül semmilyen hivatkozást nem szabad megőrizni.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Végül kap egy gyorsítótárazott leképezést, vagy hozzon létre egy új leképezést ehhez a fájlhoz, és értékelje a DWARF információkat, hogy megtalálja az file/line/name-et ehhez a címhez.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Megtaláltuk ennek a szimbólumnak a keretinformációit, és az `addr2line` képkocka belsőleg tartalmaz minden apró részletet.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// A hibakeresési információkat nem sikerült megtalálni, de az elf futtatható fájl szimbólumtáblázatában megtaláltuk.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}