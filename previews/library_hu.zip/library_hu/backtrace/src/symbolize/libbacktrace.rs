//! Jelképezési stratégia a DWARF-elemző kód használatával a libbacktrace-ben.
//!
//! A libbacktrace C könyvtár, amelyet általában a gcc szerverrel terjesztenek, nem csak egy backtrace létrehozását támogatja (amit valójában nem is használunk), hanem szimbolizálja a backtrace-t és a törpe hibakeresési információkat is olyan dolgokkal kapcsolatban, mint a beillesztett keretek és mi más.
//!
//!
//! Ez viszonylag bonyolult a sokféle aggály miatt, de az alapötlet a következő:
//!
//! * Először hívjuk az `backtrace_syminfo`-et.Ez szimbólum információkat kap a dinamikus szimbólum táblából, ha tehetjük.
//! * Ezután hívjuk az `backtrace_pcinfo`-et.Ez elemzi a debuginfo táblákat, ha rendelkezésre állnak, és lehetővé teszi számunkra, hogy helyreállítsuk az információkat a belső keretekről, fájlnevekről, sorokról stb.
//!
//! Sok trükk van abban, hogy a törpe asztalokat hogyan lehet a libbacktrace-be juttatni, de remélhetőleg ez még nem a világ vége, és elég világos, ha alább olvassuk.
//!
//! Ez az alapértelmezett szimbolizációs stratégia a nem MSVC és nem OSX platformokon.Bár a libstd fájlban ez az OSX alapértelmezett stratégiája.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Ha lehetséges, inkább az `function` nevet részesítse előnyben, amely a debuginfo-ból származik, és általában pontosabb lehet például az inline kereteknél.
                // Ha ez még nincs, akkor térjen vissza az `symname`-ben megadott szimbólumtábla nevéhez.
                //
                // Ne feledje, hogy az `function` néha kevésbé érezhető pontatlannak, például az `try<i32,closure>` néven szerepel, nem pedig az `std::panicking::try::do_call` helyett.
                //
                // Nem igazán világos, miért, de összességében az `function` név tűnik pontosabbnak.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // egyelőre ne tegyen semmit
}

/// Az `data` mutató típusa átkerül az `syminfo_cb`-be
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Miután ezt a visszahívást meghívtuk az `backtrace_syminfo`-ből, amikor elkezdjük a megoldást, tovább megyünk az `backtrace_pcinfo`-hez.
    // Az `backtrace_pcinfo` függvény a hibakeresési információkat és az olyan lépéseket követi, mint az file/line információk helyreállítása, valamint a beágyazott keretek.
    // Ne feledje azonban, hogy az `backtrace_pcinfo` kudarcot okozhat, vagy nem sokat tehet, ha nincsenek hibakeresési információk, ezért ha ez megtörténik, biztosan felhívjuk a visszahívást legalább egy szimbólummal az `syminfo_cb`-től.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Az `data` mutató típusa átkerül az `pcinfo_cb`-be
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// A libbacktrace API támogatja az állapot létrehozását, de nem támogatja az állapot megsemmisítését.
// Én személy szerint ezt úgy értem, hogy egy államot létre kell hozni, majd örökké élni.
//
// Szeretnék regisztrálni egy at_exit() kezelőt, amely megtisztítja ezt az állapotot, de a libbacktrace nem nyújt erre módot.
//
// Ezen korlátok mellett ennek a függvénynek van egy statikusan gyorsítótárazott állapota, amelyet az első igényléskor számolnak ki.
//
// Ne feledje, hogy a visszakövetés minden sorozatosan történik (egy globális zár).
//
// Vegye figyelembe, hogy a szinkronizálás hiánya itt annak a követelménynek köszönhető, hogy az `resolve` külső szinkronizálással rendelkezik.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Ne használja a libbacktrace szálbiztonsági képességeit, mivel mindig szinkronizált módon hívjuk.
        //
        0,
        error_cb,
        ptr::null_mut(), // nincs extra adat
    );

    return STATE;

    // Vegye figyelembe, hogy ahhoz, hogy a libbacktrace egyáltalán működjön, meg kell találnia a DWARF hibakeresési információit az aktuális futtatható fájlhoz.Ezt általában számos mechanizmus révén teszi meg, beleértve, de nem kizárólag:
    //
    // * /proc/self/exe támogatott platformokon
    // * Az állomány létrehozásakor a fájlnév kifejezetten átment
    //
    // A libbacktrace könyvtár nagy mennyiségű C-kód.Ez természetesen azt jelenti, hogy memóriabiztonsági sebezhetőségei vannak, különösen a hibás hibakeresési információk kezelésekor.
    // A Libstd történelmileg rengeteg ilyenbe ütközött.
    //
    // Ha /proc/self/exe-et használunk, ezeket általában figyelmen kívül hagyhatjuk, mivel feltételezzük, hogy a libbacktrace "mostly correct", és különben nem tesz furcsát az "attempted to be correct" törpe hibakeresési információival.
    //
    //
    // Ha azonban átadunk egy fájlnevet, akkor lehetséges néhány olyan platformon (például BSD-k), ahol egy rosszindulatú szereplő tetszőleges fájlt helyezhet el ezen a helyen.
    // Ez azt jelenti, hogy ha a libbacktrace-nek elmondunk egy fájlnevet, akkor egy tetszőleges fájlt használhat, ami valószínűleg szegmentumokat okozhat.
    // Ha azonban a libbacktrace-nek nem mondunk el semmit, akkor az nem tesz semmit azokon a platformokon, amelyek nem támogatják az /proc/self/exe elérési utakat!
    //
    // Mindezt figyelembe véve igyekszünk a lehető legjobban *nem* átadni egy fájlnévnek, de olyan platformokon kell tennünk, amelyek egyáltalán nem támogatják az /proc/self/exe-et.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Ne feledje, hogy ideális esetben az `std::env::current_exe`-et használnánk, de itt nem igényelhetjük az `std`-et.
            //
            // Az `_NSGetExecutablePath` segítségével töltse be az aktuális futtatható útvonalat egy statikus területre (amely ha túl kicsi, csak adja fel).
            //
            //
            // Ne feledje, hogy itt komolyan bízunk abban, hogy a libbacktrace nem hal meg a korrupt futtatható fájlokon, de ez bizony ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows rendelkezik a fájlok megnyitásának módjával, ahol megnyitása után nem lehet törölni.
            // Általában ezt akarjuk itt, mert szeretnénk biztosítani, hogy a futtatható fájlunk ne változzon ki alólunk, miután átadtuk a libbacktrace-nek, remélhetőleg enyhítve azt a képességet, hogy tetszőleges adatokat továbbítsunk a libbacktrace-be (ami rosszul kezelhető).
            //
            //
            // Tekintettel arra, hogy itt egy kicsit táncolunk, hogy megpróbáljunk egyfajta zárat szerezni a saját képünkön:
            //
            // * Kezelje az aktuális folyamatot, töltse be a fájlnevét.
            // * Nyisson meg egy fájlt az adott fájlnévre a megfelelő zászlókkal.
            // * Töltse be újra az aktuális folyamat fájlnevét, és győződjön meg arról, hogy ugyanaz
            //
            // Ha mindez megfelel, elméletileg valóban megnyitottuk a folyamat fájlját, és garantáltan nem fog változni.FWIW egy csomó ilyen történelmileg másolva van a libstd-ből, tehát ez a legjobb értelmezésem a történtekről.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Ez a statikus memóriában él, így vissza tudjuk adni ..
                static mut BUF: [i8; N] = [0; N];
                // ... és ez a veremben él, mivel ideiglenes
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // szándékosan szivárogtatja ide az `handle`-et, mert ha nyitva van, meg kell őriznie a fájlnév zárolását.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Vissza akarunk adni egy szelet, amelynek null-vége van, tehát ha mindent kitöltöttünk, és megegyezik a teljes hosszúsággal, akkor egyenlővé tesszük a kudarccal.
                //
                //
                // Ellenkező esetben a siker visszatérésekor ügyeljen arra, hogy a null bájt szerepeljen a szeletben.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // a backtrace hibákat jelenleg a szőnyeg alá söpörjük
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Hívja meg az `backtrace_syminfo` API-t, amelynek (a kód beolvasása alapján) pontosan egyszer kell felhívnia az `syminfo_cb`-et (vagy vélhetően hibával meghiúsul).
    // Ezután többet kezelünk az `syminfo_cb`-en belül.
    //
    // Ne feledje, hogy ezt tesszük, mivel az `syminfo` megkeresi a szimbólumtáblázatot, és akkor is megtalálja a szimbólumneveket, ha nincs bináris információ a hibakeresésről.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}