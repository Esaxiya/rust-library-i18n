use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Oldja meg a címet egy szimbólumhoz, továbbítva a szimbólumot a megadott lezáráshoz.
///
/// Ez a funkció megkeresi a megadott címet olyan területeken, mint a helyi szimbólumtáblázat, a dinamikus szimbólumtáblázat vagy a DWARF hibakeresési információ (az aktivált megvalósítástól függően), hogy megtalálja a hozható szimbólumokat.
///
///
/// A bezárás nem hívható meg, ha a felbontás nem hajtható végre, és beágyazott funkciók esetén is meghívható többször.
///
/// A kapott szimbólumok a megadott `addr` végrehajtását jelentik, és az adott címhez file/line párokat adnak vissza (ha rendelkezésre állnak).
///
/// Ne feledje, hogy ha rendelkezik `Frame`-szel, akkor ajánlott az `resolve_frame` funkciót használni ez helyett.
///
/// # Szükséges funkciók
///
/// Ehhez a funkcióhoz engedélyezni kell az `backtrace` crate `std` szolgáltatását, és az `std` szolgáltatás alapértelmezés szerint engedélyezve van.
///
/// # Panics
///
/// Ez a funkció arra törekszik, hogy soha ne panic, de ha az `cb` biztosította a panics-t, akkor egyes platformok egy kettős panic-t kényszerítenek a folyamat megszakítására.
/// Egyes platformok egy C könyvtárat használnak, amely belső visszahívásokat használ, amelyeket nem lehet visszacsinálni, így az `cb`-től való pánik elindíthatja a folyamat megszakítását.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // csak a felső keretet nézze
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Oldja fel a korábban elfogott keretet egy szimbólumra, továbbítva a szimbólumot a megadott záróra.
///
/// Ez a functin ugyanazt a funkciót látja el, mint az `resolve`, azzal a különbséggel, hogy cím helyett egy `Frame`-et vesz argumentumként.
/// Ez lehetővé teheti a visszakövetés egyes platformos megvalósításait, hogy pontosabb szimbóluminformációkat vagy például az inline keretekkel kapcsolatos információkat nyújtsanak.
///
/// Javasoljuk, hogy használja ezt, ha teheti.
///
/// # Szükséges funkciók
///
/// Ehhez a funkcióhoz engedélyezni kell az `backtrace` crate `std` szolgáltatását, és az `std` szolgáltatás alapértelmezés szerint engedélyezve van.
///
/// # Panics
///
/// Ez a funkció arra törekszik, hogy soha ne panic, de ha az `cb` biztosította a panics-t, akkor egyes platformok egy kettős panic-t kényszerítenek a folyamat megszakítására.
/// Egyes platformok egy C könyvtárat használnak, amely belső visszahívásokat használ, amelyeket nem lehet visszacsinálni, így az `cb`-től való pánik elindíthatja a folyamat megszakítását.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // csak a felső keretet nézze
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// A veremkeretek IP-értékei általában (always?) a *után a* hívás utáni utasítás, amely a verem tényleges nyomkövetése.
// Ennek szimbolizálása azt eredményezi, hogy az filename/line szám eggyel előbbre kerül, és talán az ürességbe kerül, ha a funkció vége felé jár.
//
// Úgy tűnik, hogy ez minden platformon mindig így van, ezért a megoldott ip-ből mindig kivonunk egyet, hogy az előző hívási utasításra oldjuk fel, ahelyett, hogy visszaadnánk az utasítást.
//
//
// Ideális esetben nem ezt tennénk.
// Ideális esetben azt kérnénk, hogy az itt található `resolve` API-k hívói manuálisan végezzék el az -1-et, és számoljanak azzal, hogy az *előző* utasításhoz helyinformációt szeretnének, nem pedig az aktuálisat.
// Ideális esetben az `Frame`-en is kitennénk, ha valóban a következő utasítás vagy az aktuális cím címe vagyunk.
//
// Egyelőre bár ez nagyon hiánypótló probléma, ezért belsőleg mindig kivonunk egyet.
// A fogyasztóknak folytatniuk kell a munkát és elég jó eredményeket kell elérniük, ezért elég jóknak kell lennünk.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Ugyanaz, mint az `resolve`, csak nem biztonságos, mivel nincs szinkronizálva.
///
/// Ez a funkció nem rendelkezik szinkronizálási garanciákkal, de akkor érhető el, ha a crate `std` szolgáltatása nincs lefordítva.
/// További dokumentációt és példákat az `resolve` funkcióban talál.
///
/// # Panics
///
/// Lásd az `resolve`-ről szóló információkat az `cb` pánikba helyezési figyelmeztetésekről.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Ugyanaz, mint az `resolve_frame`, csak nem biztonságos, mivel nincs szinkronizálva.
///
/// Ez a funkció nem rendelkezik szinkronizálási garanciákkal, de akkor érhető el, ha a crate `std` szolgáltatása nincs lefordítva.
/// További dokumentációt és példákat az `resolve_frame` funkcióban talál.
///
/// # Panics
///
/// Lásd az `resolve_frame`-ről szóló információkat az `cb` pánikba helyezési figyelmeztetésekről.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// A fájlban lévő szimbólum felbontását képviselő trait.
///
/// Ezt a trait-t trait-objektumként kapják meg az `backtrace::resolve` függvény bezárása, és gyakorlatilag elküldik, mivel nem ismert, melyik megvalósítás áll mögötte.
///
///
/// Egy szimbólum kontextus szerinti információt adhat egy funkcióról, például név, fájlnév, sorszám, pontos cím stb.
/// Nem minden információ áll mindig rendelkezésre egy szimbólumban, ezért minden módszer `Option`-et ad vissza.
///
///
pub struct Symbol {
    // TODO: ezt az élettartamot meg kell hosszabbítani az `Symbol`-hez,
    // de ez jelenleg áttörő változás.
    // Ez egyelőre biztonságos, mivel az `Symbol`-et csak referenciaként adják át, és nem klónozható.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Visszaadja ennek a függvénynek a nevét.
    ///
    /// A visszaküldött struktúrával különböző tulajdonságokat lehet lekérdezni a szimbólum nevéről:
    ///
    ///
    /// * Az `Display` megvalósítás kinyomtatja a lekicsinylett szimbólumot.
    /// * A szimbólum nyers `str` értéke elérhető (ha érvényes utf-8).
    /// * A szimbólum neve nyers bájtjaihoz lehet hozzáférni.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Ennek a függvénynek a kezdő címét adja vissza.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// A nyers fájlnevet szeletként adja vissza.
    /// Ez elsősorban `no_std` környezeteknél hasznos.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Visszaadja az oszlop számát, ahol ez a szimbólum éppen fut.
    ///
    /// Jelenleg csak a gimli ad itt értéket, és akkor is, ha az `filename` visszaadja az `Some` értéket, és következésképpen hasonló figyelmeztetéseknek vetik alá.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Visszaadja annak a sornak a számát, ahol ez a szimbólum éppen fut.
    ///
    /// Ez a visszatérési érték általában `Some`, ha az `filename` visszaadja az `Some` értéket, és ezért hasonló figyelmeztetéseknek van kitéve.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Visszaadja a fájl nevét, ahol ezt a függvényt definiálták.
    ///
    /// Ez jelenleg csak a libbacktrace vagy a gimli használatakor érhető el (pl
    /// unix platformok egyéb), és amikor egy bináris fájlt fordítanak a debuginfo segítségével.
    /// Ha egyik feltétel sem teljesül, akkor ez valószínűleg `None`-et ad vissza.
    ///
    /// # Szükséges funkciók
    ///
    /// Ehhez a funkcióhoz engedélyezni kell az `backtrace` crate `std` szolgáltatását, és az `std` szolgáltatás alapértelmezés szerint engedélyezve van.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Lehet, hogy egy elemzett C++ szimbólum, ha az összekevert szimbólum elemzése Rust-ként nem sikerült.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Ügyeljen arra, hogy megőrizze ezt a nulla méretet, hogy az `cpp_demangle` szolgáltatás ne legyen költséges, ha letiltja.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Egy szimbólumnév körüli burkolat, amely ergonómikus hozzáférést biztosít a lebontott névhez, a nyers bájtokhoz, a nyers húrokhoz stb.
///
// Holt kód engedélyezése, ha az `cpp_demangle` szolgáltatás nincs engedélyezve.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Új szimbólumnevet hoz létre a nyers mögöttes bájtokból.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Visszaadja a nyers (mangled) szimbólumnevet `str` néven, ha a szimbólum érvényes utf-8.
    ///
    /// Használja az `Display` implementációt, ha a lebontott verziót szeretné.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Visszaadja a nyers szimbólum nevét bájtok listájaként
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Ez akkor nyomtatható ki, ha a lebontott szimbólum valójában nem érvényes, ezért kezelje itt a hibát kecsesen, ne terjessze kifelé.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Kísérlet visszaszerezni azt a gyorsítótárazott memóriát, amelyet a címek szimbolizálásához használtak.
///
/// Ez a módszer megkísérli felszabadítani azokat a globális adatstruktúrákat, amelyeket egyébként globálisan vagy a szálban tároltak gyorsítótárba, és amelyek általában elemzett DWARF-információkat vagy hasonlót képviselnek.
///
///
/// # Caveats
///
/// Bár ez a funkció mindig elérhető, a legtöbb megvalósításnál valójában nem tesz semmit.
/// Az olyan könyvtárak, mint a dbghelp vagy a libbacktrace, nem biztosítanak lehetőséget az állapot lekiosztására és a lefoglalt memória kezelésére.
/// Egyelőre ennek a crate-nek az `gimli-symbolize` szolgáltatása az egyetlen olyan tulajdonság, ahol ennek a funkciónak bármilyen hatása van.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}