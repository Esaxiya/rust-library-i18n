// csak most használja az Linux-en, ezért engedélyezze máshol a holt kódot
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Egyszerű arénaelosztó bájtpufferekhez.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Kioszt egy megadott méretű puffert, és egy mutatható hivatkozást ad vissza.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // BIZTONSÁG: ez az egyetlen funkció, amely valaha is módosíthatót állít elő
        // hivatkozás az `self.buffers`-re.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // BIZTONSÁG: soha nem távolítunk el elemeket az `self.buffers`-ből, ezért referencia
        // A puffer belsejében lévő adatok mindaddig élnek, amíg az `self` él.
        &mut buffers[i]
    }
}