use core::ffi::c_void;
use core::fmt;

/// Ellenőrzi az aktuális hívásköteget, átadva az összes aktív keretet a bezáráshoz, hogy kiszámítsa a verem nyomát.
///
/// Ez a függvény ennek a könyvtárnak a munkagépe a program veremnyomainak kiszámításakor.Az adott lezáró `cb` egy `Frame` példányt eredményez, amely információt szolgáltat az adott híváskeretről a veremben.
/// A lezárás felülről lefelé keretet eredményez (legutóbb funkcióknak hívják először).
///
/// A bezárás visszatérési értéke jelzi, hogy a visszakövetésnek folytatódnia kell-e.Az `false` visszatérési értéke befejezi a visszalépést és azonnal visszatér.
///
/// Miután megszerezte az `Frame`-et, valószínűleg meg kell hívnia az `backtrace::resolve`-et, hogy az `ip` (utasításmutató) vagy szimbólum címet átalakítsa `Symbol`-be, amelyen keresztül megismerhető a név és/vagy a fájlnév/sor száma.
///
///
/// Ne feledje, hogy ez egy viszonylag alacsony szintű funkció, és ha például szeretne egy visszakövetést rögzíteni, amelyet később ellenőrizni kell, akkor az `Backtrace` típus lehet megfelelőbb.
///
/// # Szükséges funkciók
///
/// Ehhez a funkcióhoz engedélyezni kell az `backtrace` crate `std` szolgáltatását, és az `std` szolgáltatás alapértelmezés szerint engedélyezve van.
///
/// # Panics
///
/// Ez a funkció arra törekszik, hogy soha ne panic, de ha az `cb` biztosította a panics-t, akkor egyes platformok egy kettős panic-t kényszerítenek a folyamat megszakítására.
/// Egyes platformok egy C könyvtárat használnak, amely belső visszahívásokat használ, amelyeket nem lehet visszacsinálni, így az `cb`-től való pánik elindíthatja a folyamat megszakítását.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // folytassa a visszakövetést
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Ugyanaz, mint az `trace`, csak nem biztonságos, mivel nincs szinkronizálva.
///
/// Ez a funkció nem rendelkezik szinkronizálási garanciákkal, de akkor érhető el, ha a crate `std` szolgáltatása nincs lefordítva.
/// További dokumentációt és példákat az `trace` funkcióban talál.
///
/// # Panics
///
/// Lásd az `trace`-ről szóló információkat az `cb` pánikba helyezési figyelmeztetésekről.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// A trait egy backtrace egyik képkockáját képviselve engedett ennek a crate `trace` funkciójának.
///
/// A nyomkövetési függvény bezárása kereteket eredményez, és a keret gyakorlatilag elküldésre kerül, mivel a mögöttes megvalósítás futásig nem mindig ismert.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Visszaadja a keret aktuális utasításmutatóját.
    ///
    /// Ez általában a következő utasítás, amelyet végre kell hajtani a keretben, de nem minden megvalósítás sorolja ezt 100%-os pontossággal (de általában elég közel van).
    ///
    ///
    /// Javasoljuk, hogy ezt az értéket adja át az `backtrace::resolve`-nek, hogy szimbólumnévvé váljon.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Visszaadja a keret aktuális verem mutatóját.
    ///
    /// Abban az esetben, ha egy háttérprogram nem tudja helyreállítani a keret verem mutatóját, egy null mutató kerül visszaadásra.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Visszaadja a függvény keretének kezdő szimbólum címét.
    ///
    /// Ez megkísérli visszatekerni az `ip` által a függvény elejére visszaküldött utasításmutatót, visszaadva ezt az értéket.
    ///
    /// Bizonyos esetekben a háttérprogramok csak visszaadják az `ip`-et ebből a funkcióból.
    ///
    /// A visszaadott érték néha felhasználható, ha az `backtrace::resolve` nem sikerült a fent megadott `ip`-en.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Visszaadja annak a modulnak az alapcímét, amelyhez a keret tartozik.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Ennek elsőnek kell lennie annak biztosítása érdekében, hogy a Miri elsőbbséget élvezzen a fogadó platformmal szemben
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // csak a dbghelp-ben használt szimbolizálja
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}