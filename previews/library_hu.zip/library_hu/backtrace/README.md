# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Könyvtár a visszajelzések futás közbeni megszerzésére a Rust számára.
Ennek a könyvtárnak a célja a szabványos könyvtár támogatásának fokozása azáltal, hogy programozási felületet biztosít a munkához, de támogatja a jelenlegi háttérnyomok egyszerűen nyomtatását is, például a libstd panics-jét.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Ha egyszerűen rögzíteni akar egy visszakövetést, és később elhalasztja a kezelését, használhatja a legfelső szintű `Backtrace` típust.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Ha azonban több nyers hozzáférést szeretne a tényleges nyomkövetési funkcióhoz, akkor közvetlenül használhatja az `trace` és az `resolve` funkciókat.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Oldja fel az utasításmutatót egy szimbólum névre
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // folytassa a következő képkockával
    });
}
```

# License

Ez a projekt a következők egyikével licencelt

 * Apache licenc, 2.0, ([LICENSE-APACHE](LICENSE-APACHE) vagy http://www.apache.org/licenses/LICENSE-2.0 verzió)
 * MIT licenc ([LICENSE-MIT](LICENSE-MIT) vagy http://opensource.org/licenses/MIT)

választása szerint.

### Contribution

Hacsak kifejezetten másként nem állítja, az Ön által a backtrace-rs-be való felvétel céljából szándékosan benyújtott hozzájárulás, a Apache-2.0 licencben meghatározottak szerint, kettős licencű, a fentiek szerint, további feltételek és feltételek nélkül.







