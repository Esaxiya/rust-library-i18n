// rsbegin.o és az rsend.o az úgynevezett "compiler runtime startup objects".
// Ezek tartalmazzák a fordító futásidejének helyes inicializálásához szükséges kódot.
//
// Amikor egy futtatható vagy dylib képet összekapcsolnak, az összes felhasználói kód és könyvtár "sandwiched"-re esik e két objektumfájl között, így az rsbegin.o kódja vagy adatai az elsőek lesznek a kép megfelelő szakaszaiban, míg az rsend.o kód és adatok az utolsók.
// Ez a hatás használható szimbólumok elhelyezésére a szakasz elején vagy végén, valamint a szükséges fejlécek vagy láblécek beszúrására.
//
// Ne feledje, hogy a tényleges modul belépési pont a C futásidejű indítási objektumban található (általában `crtX.o` néven), amely ezután más futásidejű komponensek inicializálási visszahívásait hívja meg (még egy speciális képszakaszon keresztül regisztrálva).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // A veremkeret kikapcsolási információs szakaszának kezdete
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Karcolóhely a kiengedő belső könyveléséhez.
    // Ezt `struct object`-ként definiálják a $ GCC/unfind-dw2-fde.h fájlban.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Tekerje le az információs registration/deregistration rutinokat.
    // Lásd a libpanic_unwind dokumentumait.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // regisztráljon kikapcsolási információkat a modul indításakor
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // regisztráció leállításkor
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-specifikus init/uninit rutinregisztráció
    pub mod mingw_init {
        // A MinGW indítási objektumai (crt0.o/dllcrt0.o) globális konstruktorokat hívnak meg az .ctors és .dtors szakaszokban az indításkor és kilépéskor.
        // DLL-ek esetén ez a DLL be-és kirakásakor történik.
        //
        // A linker rendezi a szakaszokat, ami biztosítja, hogy visszahívásaink a lista végén helyezkedjenek el.
        // Mivel a konstruktorok fordított sorrendben futnak, ez biztosítja, hogy a visszahívásaink legyenek az elsők és az utolsók.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C inicializálási visszahívások
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C felmondási visszahívások
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}