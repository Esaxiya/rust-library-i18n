# Az `rustc-std-workspace-std` crate

Lásd az `rustc-std-workspace-core` crate dokumentációját.