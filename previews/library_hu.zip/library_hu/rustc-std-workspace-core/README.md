# Az `rustc-std-workspace-core` crate

Ez a crate egy simító és üres crate, amely egyszerűen függ az `libcore`-től, és újból exportálja az összes tartalmát.
A crate a lényege, hogy a standard könyvtárat felhatalmazzák az crates.io crates függvényére

Crates az crates.io-en, hogy a standard könyvtár függ az crates.io-től származó `rustc-std-workspace-core` crate-től, amely üres.

Az `[patch]` segítségével felülírjuk ezt a crate-t ebben az adattárban.
Ennek eredményeként az crates.io-en lévő crates edge-függőséget fog húzni az `libcore`-hez, az ebben a tárban definiált verzióhoz.
Ennek meg kell határoznia az összes függőséget, hogy a Cargo sikeresen felépítse a crates-t!

Ne feledje, hogy az crates.io crates-jének ettől a crate-től kell függnie `core` néven, hogy minden megfelelően működjön.Ehhez használhatják:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Az `package` kulcs használatával a crate átnevezésre kerül: `core`, vagyis kinézni fog

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

amikor a Cargo meghívja a fordítót, kielégítve a fordító által beadott implicit `extern crate core` irányelvet.




