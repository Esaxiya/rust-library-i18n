//! A Rust panics megvalósítása folyamatmegszakítással
//!
//! A letekercseléses megvalósításhoz képest ez a crate *sokkal* egyszerűbb!Ennek ellenére nem egészen sokoldalú, de itt van!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" a hasznos terhelés és az alátét a kérdéses platform megfelelő megszakításához.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // hívja az std::sys::abort_internal telefonszámot
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Windows rendszeren használja a processzor-specifikus __fastfail mechanizmust.Az Windows 8 és későbbi verziókban ez azonnal leállítja a folyamatot folyamat közbeni kivételkezelők futtatása nélkül.
            // Az Windows korábbi verzióiban ezt az utasítássorozatot hozzáférési jogsértésként kezeljük, amely leállítja a folyamatot, de nem szükségképpen megkerüli az összes kivételkezelőt.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: ez ugyanaz a megvalósítás, mint a libstd `abort_internal`-jénél
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Ez ... egy kicsit furcsa.A tl; dr;az, hogy erre van szükség a helyes összekapcsoláshoz, a hosszabb magyarázat az alábbiakban található.
//
// Jelenleg az libcore/libstd bináris fájljait, amelyeket szállítunk, mind az `-C panic=unwind`-sel állítjuk össze.Ez annak biztosítására szolgál, hogy a bináris fájlok maximálisan kompatibilisek legyenek a lehető legtöbb helyzettel.
// A fordító azonban "personality function"-t igényel az `-C panic=unwind`-sel lefordított összes funkcióhoz.Ezt a személyiségfüggvényt keményen kódoljuk az `rust_eh_personality` szimbólumba, és az `eh_personality` lang elem határozza meg.
//
// So...
// miért nem csak itt definiálja azt a lang elemet?Jó kérdés!A panic futási idők összekapcsolásának módja valójában egy kicsit finom, mivel "sort of"-et tartalmaznak a fordító crate-áruházában, de csak akkor kapcsolják össze, ha egy másik nincs valójában összekapcsolva.
//
// Ez végül azt jelenti, hogy mind ez a crate, mind a panic_unwind crate megjelenhet a fordító crate tárolójában, és ha mindkettő meghatározza az `eh_personality` lang elemet, az hibát fog elérni.
//
// Ennek kezeléséhez a fordítónak csak akkor kell megadnia az `eh_personality`-et, ha az összekapcsolt panic futásideje a feltekerhető futási idő, és különben nem szükséges megadni (jogosan).
// Ebben az esetben azonban ez a könyvtár csak meghatározza ezt a szimbólumot, így valahol van legalább valamilyen személyiség.
//
// Lényegében ezt a szimbólumot csak az libcore/libstd bináris fájlok vezetékes bekötésére definiálják, de soha nem szabad hívni, mivel egyáltalán nem kapcsolódunk egy kibontó futásidőhöz.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Az x86_64-pc-windows-gnu rendszeren saját személyiségfunkciónkat használjuk, amelynek vissza kell adnia az `ExceptionContinueSearch`-et, amikor az összes keretet továbbadjuk.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // A fentihez hasonlóan ez megfelel az `eh_catch_typeinfo` lang elemnek, amelyet jelenleg csak az Emscripten használnak.
    //
    // Mivel a panics nem generál kivételt, és a külföldi kivételek jelenleg UB -C-szel, panic=megszakítanak (bár ez változhat), a catch_unwind hívások soha nem fogják használni ezt a típusinfót.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Ezt a kettőt az i686-pc-windows-gnu indítóobjektumaink hívják meg, de semmit sem kell tenniük, így a testek nem.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}