use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Ez nem stabil felület, de segít az `?` olcsó megtartásában közöttük, még akkor is, ha az LLVM most nem mindig tudja kihasználni.
    //
    // (Sajnos az eredmény és az opció nem egyeztethető össze, ezért a ControlFlow nem képes mindkettőnek megfelelni.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}