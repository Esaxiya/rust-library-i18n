use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Interfész aszinkron iterátorok kezelésére.
///
/// Ez a trait fő folyama.
/// A streamek fogalmával kapcsolatos további információkért kérjük, olvassa el az [module-level documentation] készüléket.
/// Különösen érdemes tudni, hogyan kell [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// A stream által előállított elemek típusa.
    type Item;

    /// Próbálja meg kihúzni ennek a folyamnak a következő értékét, regisztrálja az aktuális feladatot ébresztésre, ha az érték még nem áll rendelkezésre, és adja vissza az `None`-et, ha a folyam kimerült.
    ///
    /// # Visszatérési érték
    ///
    /// Számos lehetséges visszatérési érték létezik, amelyek mindegyike külön adatfolyam állapotot jelez:
    ///
    /// - `Poll::Pending` azt jelenti, hogy ennek az adatfolyamnak a következő értéke még nem áll készen.A megvalósítások biztosítják, hogy az aktuális feladat értesítést kapjon, amikor a következő érték készen áll.
    ///
    /// - `Poll::Ready(Some(val))` azt jelenti, hogy a folyam sikeresen létrehozott egy értéket, `val`, és további értékeket hozhat létre a következő `poll_next` hívások során.
    ///
    /// - `Poll::Ready(None)` azt jelenti, hogy a folyam leállt, és az `poll_next`-et nem szabad újra meghívni.
    ///
    /// # Panics
    ///
    /// Miután egy adatfolyam befejeződött (az `Ready(None)` from `poll_next`) visszaküldése, az `poll_next` módszer újbóli meghívása, a panic örökre blokkolhat, vagy más típusú problémákat okozhat; az `Stream` trait nem támaszt követelményeket egy ilyen hívás hatásaira vonatkozóan.
    ///
    /// Mivel azonban az `poll_next` módszer nincs `unsafe` jelöléssel ellátva, a Rust szokásos szabályai érvényesek: a hívások soha nem okozhatnak meghatározatlan viselkedést (memória sérülést, az `unsafe` függvények helytelen használatát vagy hasonlókat), függetlenül a folyam állapotától.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Visszaadja a határokat a folyam fennmaradó hosszán.
    ///
    /// Pontosabban, az `size_hint()` egy duplát ad vissza, ahol az első elem az alsó, a második a felső határ.
    ///
    /// A visszaküldött második fél fele egy ["opció"] <<[[`usize`]`>`.
    /// Az [`None`] itt azt jelenti, hogy vagy nincs ismert felső határ, vagy pedig a felső határ nagyobb, mint [`usize`].
    ///
    /// # Végrehajtási megjegyzések
    ///
    /// Nincs kikényszerítve, hogy egy adatfolyam-implementáció a deklarált számú elemet adja.A hibás folyam kevesebbet eredményezhet, mint az elemek alsó határa, vagy több, mint az elemek felső határa.
    ///
    /// `size_hint()` elsősorban optimalizálásra szánták, például helyet foglalva a folyam elemeinek számára, de nem szabad megbízni benne, hogy például a nem biztonságos kódban kihagyják a határellenőrzéseket.
    /// Az `size_hint()` helytelen végrehajtása nem vezethet memóriabiztonsági megsértésekhez.
    ///
    /// Ennek ellenére a megvalósításnak helyes becslést kell szolgáltatnia, mert különben a trait protokolljának megsértését jelentené.
    ///
    /// Az alapértelmezett megvalósítás a következő eredményt adja vissza: ((0, `[None`]`)), amely bármely adatfolyamra helyes.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}