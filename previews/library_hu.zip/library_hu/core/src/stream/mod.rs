//! Komponálható aszinkron iteráció.
//!
//! Ha a futures aszinkron értékek, akkor a folyamok aszinkron iterátorok.
//! Ha valamilyen aszinkron gyűjteményt talált magának, és szüksége volt egy művelet végrehajtására az említett gyűjtemény elemein, gyorsan belefut az 'streams'-be.
//! A folyamokat gyakran használják az idiomatikus aszinkron Rust kódban, ezért érdemes megismerkedni velük.
//!
//! Mielőtt bővebben elmagyaráznánk, beszéljünk a modul felépítéséről:
//!
//! # Organization
//!
//! Ez a modul nagyrészt típus szerint szerveződik:
//!
//! * [Traits] ezek a fő rész: ezek a traits meghatározzák, hogy milyen streamek léteznek, és mit lehet velük kezdeni.Ezeknek a traits módszereinek érdemes némi plusz tanulmányi időt szánni.
//! * A funkciók néhány hasznos módszert kínálnak néhány alapvető adatfolyam létrehozására.
//! * A struktúrák gyakran a modul traits különböző módszereinek visszatérési típusai.Általában az `struct` létrehozására szolgáló módszert kell megvizsgálnia, nem pedig magát az `struct`-et.
//! A miértről bővebben lásd: " [Streaming megvalósítása](#Implementing-stream)`.
//!
//! [Traits]: #traits
//!
//! Ez az!Áskáljunk patakokba.
//!
//! # Stream
//!
//! Ennek a modulnak a szíve és lelke az [`Stream`] trait.Az [`Stream`] magja így néz ki:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Az `Iterator`-től eltérően az `Stream` különbséget tesz az `Stream` megvalósításakor alkalmazott [`poll_next`] módszer és egy adatfolyam fogyasztása során használt (to-be-implemented) `next` módszer között.
//!
//! Az `Stream` fogyasztóinak csak az `next`-et kell figyelembe venniük, amely híváskor egy future-t ad vissza, amely `Option<Stream::Item>`-et eredményez.
//!
//! Az `next` által visszaküldött future az `Some(Item)`-et adja, amíg vannak elemek, és ha mindannyian kimerültek, akkor az `None`-et jelezzük, hogy az iteráció befejeződött.
//! Ha valami aszinkron megoldásra várunk, a future megvárja, amíg az adatfolyam ismét készen áll a hozamra.
//!
//! Az egyes adatfolyamok dönthetnek úgy, hogy folytatják az iterációt, és így az `next` újbóli hívása egy bizonyos ponton előidézheti az `Some(Item)`-et.
//!
//! A [`Stream`] teljes definíciója számos más metódust is tartalmaz, de ezek az alapértelmezett módszerek, az [`poll_next`] tetejére épülnek, és így ingyen kapja meg őket.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # A Stream megvalósítása
//!
//! Saját stream létrehozása két lépésből áll: egy `struct` létrehozása a stream állapotának megőrzéséhez, majd az [`Stream`] megvalósítása ehhez az `struct`-hez.
//!
//! Készítsünk egy `Counter` nevű folyamot, amely `1`-től `5`-ig számít:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Először a struktúra:
//!
//! /// Patak, amely egytől ötig számol
//! struct Counter {
//!     count: usize,
//! }
//!
//! // azt akarjuk, hogy a számlálásunk egyben kezdődjön, ezért adjunk hozzá egy new() módszert a segítségünkre.
//! // Ez nem feltétlenül szükséges, de kényelmes.
//! // Ne feledje, hogy az `count`-et nullán kezdjük, az alábbiakban meglátjuk, hogy miért.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Ezután implementáljuk az `Stream`-et az `Counter`-hez:
//!
//! impl Stream for Counter {
//!     // számolni fogunk usize-vel
//!     type Item = usize;
//!
//!     // poll_next() az egyetlen szükséges módszer
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Növelje a számunkat.Ezért kezdtük nullán.
//!         self.count += 1;
//!
//!         // Ellenőrizze, hogy befejeztük-e a számlálást, vagy sem.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! A patakok *lusták*.Ez azt jelenti, hogy csak egy adatfolyam létrehozása nem jelenti az _do_ egészét.Semmi nem történik igazán, amíg nem hívja az `next`-et.
//! Ez néha zavart okozhat, amikor egy adatfolyamot csak mellékhatásai céljából hozunk létre.
//! A fordító figyelmeztet bennünket az ilyen viselkedésre:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;