#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! A fordító beépített típusainak elrendezéséhez tartalmaz strukturális definíciókat.
//!
//! Használhatók nem biztonságos kódban lévő átvitel célpontjaiként a nyers ábrázolások közvetlen manipulálására.
//!
//!
//! Meghatározásuknak mindig meg kell egyeznie az `rustc_middle::ty::layout`-ben definiált ABI-vel.
//!

/// Egy trait objektum, például az `&dyn SomeTrait` ábrázolása.
///
/// Ez a struktúra ugyanazzal az elrendezéssel rendelkezik, mint az `&dyn SomeTrait` és az `Box<dyn AnotherTrait>`.
///
/// `TraitObject` garantáltan megfelel az elrendezéseknek, de ez nem a trait objektumok típusa (pl. a mezők nem érhetők el közvetlenül egy `&dyn SomeTrait` készüléken), és nem is ellenőrzi ezt az elrendezést (a definíció megváltoztatása nem változtatja meg az `&dyn SomeTrait` elrendezését).
///
/// Csak olyan nem biztonságos kódok számára tervezték, amelyeknek az alacsony szintű részleteket kell kezelniük.
///
/// Nincs mód az összes trait objektum általános hivatkozására, így az ilyen típusú értékek létrehozásának egyetlen módja az [`std::mem::transmute`][transmute]-hez hasonló funkciók.
/// Hasonlóképpen, egy igazi trait objektum `TraitObject` értékből történő létrehozásának egyetlen módja az `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// A trait objektum nem megfelelő típusok szintetizálása-olyan esetben, amikor a vtable nem felel meg annak az értéknek a típusának, amelyre az adatmutató mutat-nagy valószínűséggel meghatározatlan viselkedéshez vezet.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // egy példa trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // a fordító készítsen egy trait objektumot
/// let object: &dyn Foo = &value;
///
/// // nézd meg a nyers ábrázolást
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // az adatmutató az `value` címe
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // készítsen új objektumot, egy másik `i32`-re mutatva, ügyelve arra, hogy az `object`-től származó `i32` vtable-t használja
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // ugyanúgy kellene működnie, mintha egy trait objektumot építettünk volna közvetlenül az `other_value`-ből
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}