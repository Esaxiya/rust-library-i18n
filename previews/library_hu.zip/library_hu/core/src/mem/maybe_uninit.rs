use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Burkolótípus az `T` inicializálatlan példányainak összeállításához.
///
/// # Inicializálás változatlan
///
/// A fordító általában azt feltételezi, hogy egy változó megfelelően inicializált a változó típusának követelményei szerint.Például egy referencia típusú változónak igazodnia kell és nem NULL értékűnek kell lennie.
/// Ez egy invariáns, amelyet *mindig* be kell tartani, még nem biztonságos kódban is.
/// Ennek következtében egy referencia típusú változó nulla inicializálása azonnali [undefined behavior][ub]-t eredményez, függetlenül attól, hogy a hivatkozás valaha is megszokta-e a memória elérését:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // undefined viselkedés!⚠️
/// // Az `MaybeUninit<&i32>` kóddal egyenértékű kód:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // undefined viselkedés!⚠️
/// ```
///
/// Ezt használja a fordító különféle optimalizálásokra, például a futási idő ellenőrzésére és az `enum` elrendezés optimalizálására.
///
/// Hasonlóképpen, a teljesen inicializálatlan memóriában bármilyen tartalom lehet, míg az `bool`-nek mindig `true`-nek vagy `false`-nek kell lennie.Ezért az inicializálatlan `bool` létrehozása nem meghatározott viselkedés:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // undefined viselkedés!⚠️
/// // Az `MaybeUninit<bool>` kóddal egyenértékű kód:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // undefined viselkedés!⚠️
/// ```
///
/// Ráadásul az inicializálatlan memória annyiban különleges, hogy nincs rögzített értéke ("fixed" jelentése "it won't change without being written to").Ugyanazon inicializálatlan bájt többszöri elolvasása különböző eredményeket adhat.
/// Ez meghatározatlanná teszi az inicializálatlan adatok meglétét egy változóban, még akkor is, ha ennek a változónak egész típusú típusa van, amely egyébként bármilyen *fix* bitmintát tartalmazhat:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // undefined viselkedés!⚠️
/// // Az `MaybeUninit<i32>` kóddal egyenértékű kód:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // undefined viselkedés!⚠️
/// ```
/// (Vegye figyelembe, hogy az inicializálatlan egészek körüli szabályok még nincsenek véglegesítve, de mindaddig ajánlatos elkerülni őket.)
///
/// Ráadásul ne feledje, hogy a legtöbb típusnak vannak további invariánsai azon túl, hogy pusztán a típusszinten inicializáltnak tekintjük őket.
/// Például egy "1" inicializált [`Vec<T>`] inicializáltnak tekinthető (a jelenlegi megvalósítás szerint; ez nem jelent stabil garanciát), mert a fordító egyetlen követelménye, hogy az adatmutatónak nem nullnak kell lennie.
/// Egy ilyen `Vec<T>` létrehozása nem okoz *azonnali* meghatározatlan viselkedést, de a legtöbb biztonságos művelettel (beleértve annak eldobását is) meghatározatlan viselkedést okoz.
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` arra szolgál, hogy a nem biztonságos kód kezelje az inicializálatlan adatokat.
/// Jelzés a fordítónak, jelezve, hogy az itt szereplő adatokat inicializálni nem lehet:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Hozzon létre kifejezetten inicializálatlan referenciát.
/// // A fordító tudja, hogy az `MaybeUninit<T>`-en belüli adatok érvénytelenek lehetnek, ezért ez nem UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Állítsa be érvényes értékre.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Bontsa ki az inicializált adatokat-ez csak az `x` megfelelő inicializálása után * engedélyezett!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// A fordító ekkor tudja, hogy ne tegyen hibás feltételezéseket vagy optimalizálást erre a kódra.
///
/// Úgy gondolhatja, hogy az `MaybeUninit<T>` kissé hasonlít az `Option<T>`-hez, de a futásidő-követés és a biztonsági ellenőrzések nélkül.
///
/// ## out-pointers
///
/// Az `MaybeUninit<T>` segítségével megvalósíthatja az "out-pointers"-et: ahelyett, hogy adatokat küldene vissza egy funkcióból, vigye át az egérmutatót valamilyen (uninitialized) memóriába, ahová az eredményt be szeretné helyezni.
/// Ez akkor lehet hasznos, ha a hívónak fontos szabályoznia, hogy az eredmény hogyan tárolja a memóriát, és el akarja kerülni a felesleges mozdulatokat.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` nem dobja el a régi tartalmat, ami fontos.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Most már tudjuk, hogy az `v` inicializálva van!Ez biztosítja azt is, hogy a vector megfelelően leessen.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Egy tömb inicializálása elemenként
///
/// `MaybeUninit<T>` használható egy nagy tömb elemenkénti inicializálására:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Hozzon létre egy inicializálatlan `MaybeUninit` tömböt.
///     // Az `assume_init` biztonságos, mert az a típus, amelyet állítólag itt inicializáltunk, egy csomó `VarbUninit`, amelyek nem igényelnek inicializálást.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Az `MaybeUninit` eldobása nem tesz semmit.
///     // Így a nyers mutató hozzárendelése az `ptr::write` helyett nem okozza a régi inicializálatlan érték eldobását.
/////
///     // Akkor is, ha van egy panic ezen ciklus alatt, akkor memóriaszivárgás tapasztalható, de nincs memóriabiztonsági probléma.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Minden inicializálva van.
///     // Transformálja a tömböt az inicializált típusra.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Dolgozhat részben inicializált tömbökkel is, amelyek megtalálhatók az alacsony szintű adatstruktúrákban.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Hozzon létre egy inicializálatlan `MaybeUninit` tömböt.
/// // Az `assume_init` biztonságos, mert az a típus, amelyet állítólag itt inicializáltunk, egy csomó `VarbUninit`, amelyek nem igényelnek inicializálást.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Számolja meg a hozzárendelt elemek számát.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // A tömb minden eleméhez dobjon, ha kiosztottuk.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## A struktúra mezőnkénti inicializálása
///
/// Az `MaybeUninit<T>` és az [`std::ptr::addr_of_mut`] makró használatával inicializálhatja a struktúrákat mezőnként:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Az `name` mező inicializálása
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Az `list` mező inicializálása Ha van itt panic, akkor az `name` mezőben lévő `String` szivárog.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Az összes mező inicializálva van, ezért felhívjuk az `assume_init`-et az inicializált Foo megszerzéséhez.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` garantáltan megegyezik az `T` méretével, igazításával és ABI-jével:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Ne feledje azonban, hogy az *`MaybeUninit<T>`-et tartalmazó* típus nem feltétlenül ugyanaz az elrendezés;A Rust általában nem garantálja, hogy az `Foo<T>` mezői sorrendben vannak, mint az `Foo<U>`, még akkor is, ha az `T` és az `U` azonos méretű és illesztésű.
///
/// Továbbá, mivel bármely bitérték érvényes egy `MaybeUninit<T>`-re, a fordító nem tudja alkalmazni az non-zero/niche-filling-optimalizációkat, ami nagyobb méretet eredményezhet:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Ha az `T` FFI-biztonságos, akkor az `MaybeUninit<T>` is.
///
/// Míg az `MaybeUninit` az `#[repr(transparent)]` (ami azt jelzi, hogy ugyanolyan méretet, igazítást és ABI-t garantál, mint az `T`), ez *nem* változtatja meg a korábbi figyelmeztetéseket.
/// `Option<T>` és az `Option<MaybeUninit<T>>` továbbra is eltérő méretű lehet, és az `T` típusú mezőt tartalmazó típusok másképpen is elrendezhetők (és méretezhetők), mintha az `MaybeUninit<T>` mező lenne.
/// `MaybeUninit` uniótípus, és a szakszervezeteken az `#[repr(transparent)]` instabil (lásd: [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Idővel az `#[repr(transparent)]` pontos garanciái a szakszervezeteken fejlődhetnek, és az `MaybeUninit` maradhat vagy sem maradhat `#[repr(transparent)]`.
/// Ennek ellenére az `MaybeUninit<T>`*mindig* garantálja, hogy ugyanolyan méretű, illesztésű és ABI-vel rendelkezik, mint az `T`;csak az, hogy az `MaybeUninit` hogyan valósítja meg ezt a garanciát, változhat.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang elem, így más típusokat is be tudunk csomagolni.Ez hasznos a generátorok számára.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Ha nem hívjuk az `T::clone()`-et, nem tudhatjuk, hogy vagyunk-e elég inicializálva ehhez.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Létrehoz egy új `MaybeUninit<T>`-et, amelyet inicializálnak a megadott értékkel.
    /// Biztonságos az [`assume_init`] hívása ennek a funkciónak a visszatérési értékén.
    ///
    /// Ne feledje, hogy az `MaybeUninit<T>` eldobása soha nem fogja meghívni a `T 'drop kódját.
    /// Az Ön felelőssége, hogy megbizonyosodjon arról, hogy az `T` leesik, ha inicializálják.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Új `MaybeUninit<T>`-et hoz létre inicializálatlan állapotban.
    ///
    /// Ne feledje, hogy az `MaybeUninit<T>` eldobása soha nem fogja meghívni a `T 'drop kódját.
    /// Az Ön felelőssége, hogy megbizonyosodjon arról, hogy az `T` leesik, ha inicializálják.
    ///
    /// Néhány példát az [type-level documentation][MaybeUninit]-ben talál.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Hozzon létre egy új tömböt az `MaybeUninit<T>` elemekből, inicializálatlan állapotban.
    ///
    /// Note: a future Rust verzióban ez a módszer szükségtelenné válhat, ha a tömb szó szerinti szintaxisa lehetővé teszi az [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) használatát.
    ///
    /// Az alábbi példa ekkor használhatja az `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`-et.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Visszaad egy (esetleg kisebb) adatszeletet, amelyet ténylegesen elolvastak
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // BIZTONSÁG: Inicializálatlan `[MaybeUninit<_>; LEN]` érvényes.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Új `MaybeUninit<T>`-et hoz létre inicializálatlan állapotban, a memória `0` byte-okkal van feltöltve.Az `T`-től függ, hogy ez már elősegíti-e a megfelelő inicializálást.
    ///
    /// Például az `MaybeUninit<usize>::zeroed()` inicializálva van, de az `MaybeUninit<&'static i32>::zeroed()` nem azért, mert a hivatkozások nem lehetnek nullák.
    ///
    /// Ne feledje, hogy az `MaybeUninit<T>` eldobása soha nem fogja meghívni a `T 'drop kódját.
    /// Az Ön felelőssége, hogy megbizonyosodjon arról, hogy az `T` leesik, ha inicializálják.
    ///
    /// # Example
    ///
    /// Ennek a függvénynek a helyes használata: inicializál egy struktúrát nullával, ahol a struktúra minden mezője érvényes értékként megtarthatja a 0 bitmintát.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *A funkció helytelen* használata: az `x.zeroed().assume_init()` hívása, ha az `0` nem érvényes bitminta a típushoz:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Egy pár belsejében létrehozunk egy `NotZero`-et, amelynek nincs érvényes megkülönböztető képessége.
    /// // Ez nem definiált viselkedés.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // BIZTONSÁG: `u.as_mut_ptr()` a lefoglalt memóriára mutat.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Beállítja az `MaybeUninit<T>` értékét.
    /// Ez felülír minden korábbi értéket anélkül, hogy eldobná, ezért ügyeljen arra, hogy ezt ne használja kétszer, hacsak nem akarja kihagyni a destruktor futtatását.
    ///
    /// Az Ön kényelme érdekében ez az `self` (most már biztonságosan inicializált) tartalmára mutatható hivatkozást is ad.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // BIZTONSÁG: Most inicializáltuk ezt az értéket.
        unsafe { self.assume_init_mut() }
    }

    /// Mutatót kap a benne foglalt értékre.
    /// Ebből a mutatóból olvasás vagy referenciává alakítás nem meghatározott viselkedés, hacsak az `MaybeUninit<T>`-et nem inicializálják.
    /// A memóriába írás, amelyre ez az (non-transitively) mutató mutat, nem meghatározott viselkedés (kivéve az `UnsafeCell<T>` belsejét).
    ///
    /// # Examples
    ///
    /// A módszer helyes használata:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Hozzon létre referenciát az `MaybeUninit<T>`-be.Ez rendben van, mert inicializáltuk.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *A módszer helytelen* használata:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Létrehoztunk egy inicializálatlan vector hivatkozást!Ez nem definiált viselkedés.⚠️
    /// ```
    ///
    /// (Vegye figyelembe, hogy az inicializálatlan adatokra történő hivatkozásokra vonatkozó szabályok még nincsenek véglegesítve, de mindaddig ajánlatos elkerülni őket.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` és az `ManuallyDrop` egyaránt `repr(transparent)`, így leadhatjuk a mutatót.
        self as *const _ as *const T
    }

    /// Megváltoztatható mutatót kap a benne foglalt értékre.
    /// Ebből a mutatóból olvasás vagy referenciává alakítás nem meghatározott viselkedés, hacsak az `MaybeUninit<T>`-et nem inicializálják.
    ///
    /// # Examples
    ///
    /// A módszer helyes használata:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Hozzon létre referenciát az `MaybeUninit<Vec<u32>>`-be.
    /// // Ez rendben van, mert inicializáltuk.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *A módszer helytelen* használata:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Létrehoztunk egy inicializálatlan vector hivatkozást!Ez nem definiált viselkedés.⚠️
    /// ```
    ///
    /// (Vegye figyelembe, hogy az inicializálatlan adatokra történő hivatkozásokra vonatkozó szabályok még nincsenek véglegesítve, de mindaddig ajánlatos elkerülni őket.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` és az `ManuallyDrop` egyaránt `repr(transparent)`, így leadhatjuk a mutatót.
        self as *mut _ as *mut T
    }

    /// Kivonja az értéket az `MaybeUninit<T>` tárolóból.Ez nagyszerű módja annak, hogy az adatokat eldobjuk, mert a kapott `T` a szokásos cseppkezelésnek van alávetve.
    ///
    /// # Safety
    ///
    /// A hívónak kell garantálnia, hogy az `MaybeUninit<T>` valóban inicializált állapotban van.Ennek hívása, ha a tartalom még nincs teljesen inicializálva, azonnal meghatározhatatlan viselkedést okoz.
    /// Az [type-level documentation][inv] több információt tartalmaz erről az inicializáló invariánsról.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Ráadásul ne feledje, hogy a legtöbb típusnak vannak további invariánsai azon túl, hogy pusztán a típusszinten inicializáltnak tekintjük őket.
    /// Például egy "1" inicializált [`Vec<T>`] inicializáltnak tekinthető (a jelenlegi megvalósítás szerint; ez nem jelent stabil garanciát), mert a fordító egyetlen követelménye, hogy az adatmutatónak nem nullnak kell lennie.
    ///
    /// Egy ilyen `Vec<T>` létrehozása nem okoz *azonnali* meghatározatlan viselkedést, de a legtöbb biztonságos művelettel (beleértve annak eldobását is) meghatározatlan viselkedést okoz.
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// A módszer helyes használata:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *A módszer helytelen* használata:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` még nem volt inicializálva, ezért ez az utolsó sor meghatározatlan viselkedést váltott ki.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // BIZTONSÁG: a hívónak garantálnia kell az `self` inicializálását.
        // Ez azt is jelenti, hogy az `self`-nek `value`-változatnak kell lennie.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Beolvassa az értéket az `MaybeUninit<T>` tárolóból.Az így kapott `T` a szokásos cseppkezelésnek van alávetve.
    ///
    /// Lehetőség szerint inkább az [`assume_init`]-et használja, amely megakadályozza az `MaybeUninit<T>` tartalmának másolatát.
    ///
    /// # Safety
    ///
    /// A hívónak kell garantálnia, hogy az `MaybeUninit<T>` valóban inicializált állapotban van.Ennek hívása, ha a tartalom még nincs teljesen inicializálva, meghatározatlan viselkedést okoz.
    /// Az [type-level documentation][inv] több információt tartalmaz erről az inicializáló invariánsról.
    ///
    /// Sőt, ez ugyanazon adatok másolatát hagyja hátra az `MaybeUninit<T>`-ben.
    /// Ha az adatok több példányát használja (az `assume_init_read` többszöri hívásával, vagy először az `assume_init_read`, majd az [`assume_init`] hívásával), az Ön felelőssége biztosítani, hogy az adatok valóban megismétlődjenek.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// A módszer helyes használata:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` az `Copy`, ezért többször is olvashatunk.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Az `None` érték lemásolása rendben van, ezért többször is olvashatunk.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *A módszer helytelen* használata:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Most két példányt készítettünk ugyanabból a vector-ből, ami kettős mentességet eredményez, amikor mindkettő leesik!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // BIZTONSÁG: a hívónak garantálnia kell az `self` inicializálását.
        // Az `self.as_ptr()`-ről történő olvasás biztonságos, mivel az `self`-et inicializálni kell.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// A helyére dobja a benne foglalt értéket.
    ///
    /// Ha az `MaybeUninit` tulajdonosa van, akkor az [`assume_init`]-et használhatja.
    ///
    /// # Safety
    ///
    /// A hívónak kell garantálnia, hogy az `MaybeUninit<T>` valóban inicializált állapotban van.Ennek hívása, ha a tartalom még nincs teljesen inicializálva, meghatározatlan viselkedést okoz.
    ///
    /// Ráadásul minden további `T` típusú invariánsnak meg kell felelnie, mivel az `T` (vagy tagjai) `Drop` megvalósítása erre támaszkodhat.
    /// Például egy "1" inicializált [`Vec<T>`] inicializáltnak tekinthető (a jelenlegi megvalósítás szerint; ez nem jelent stabil garanciát), mert a fordító egyetlen követelménye, hogy az adatmutatónak nem nullnak kell lennie.
    ///
    /// Egy ilyen `Vec<T>` elejtése azonban meghatározatlan viselkedést okoz.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // BIZTONSÁG: a hívónak garantálnia kell az `self` inicializálását és
        // kielégíti az `T` összes invariánsát.
        // Az érték helyére dobása biztonságos, ha ez a helyzet.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Megkapja a hivatkozott érték megosztott hivatkozását.
    ///
    /// Ez akkor lehet hasznos, ha egy inicializált `MaybeUninit`-hez akarunk hozzáférni, de nem rendelkezik az `MaybeUninit` tulajdonjogával (megakadályozva az `.assume_init()`) használatát.
    ///
    /// # Safety
    ///
    /// Ennek hívása, ha a tartalom még nincs teljesen inicializálva, meghatározatlan viselkedést okoz: a hívónak kell garantálnia, hogy az `MaybeUninit<T>` valóban inicializált állapotban van.
    ///
    ///
    /// # Examples
    ///
    /// ### A módszer helyes használata:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Az `x` inicializálása:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Most, hogy ismert, hogy az `MaybeUninit<_>`-t inicializáltuk, rendben van létrehozni egy megosztott hivatkozást rá:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // BIZTONSÁG: Az `x` inicializálva lett.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *A módszer helytelen* használata:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Létrehoztunk egy inicializálatlan vector hivatkozást!Ez nem definiált viselkedés.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Az `MaybeUninit` inicializálása az `Cell::set` használatával:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Hivatkozás egy inicializálatlan `Cell<bool>`: UB-ra!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // BIZTONSÁG: a hívónak garantálnia kell az `self` inicializálását.
        // Ez azt is jelenti, hogy az `self`-nek `value`-változatnak kell lennie.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Megváltoztatható (unique) hivatkozást kap a benne foglalt értékre.
    ///
    /// Ez akkor lehet hasznos, ha egy inicializált `MaybeUninit`-hez akarunk hozzáférni, de nem rendelkezik az `MaybeUninit` tulajdonjogával (megakadályozva az `.assume_init()`) használatát.
    ///
    /// # Safety
    ///
    /// Ennek hívása, ha a tartalom még nincs teljesen inicializálva, meghatározatlan viselkedést okoz: a hívónak kell garantálnia, hogy az `MaybeUninit<T>` valóban inicializált állapotban van.
    /// Például az `.assume_init_mut()` nem használható az `MaybeUninit` inicializálására.
    ///
    /// # Examples
    ///
    /// ### A módszer helyes használata:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Inicializálja a bemeneti puffer *összes* byte-ját.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Az `buf` inicializálása:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Most már tudjuk, hogy az `buf` inicializálva volt, így `.assume_init()`-et is megtehetnénk.
    /// // Az `.assume_init()` használata azonban kiválthatja a 2048 bájt `memcpy` értékét.
    /// // Annak érdekében, hogy a pufferünket inicializáljuk másolás nélkül, frissítjük az `&mut MaybeUninit<[u8; 2048]>`-et `&mut [u8; 2048]`-re:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // BIZTONSÁG: Az `buf` inicializálva lett.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Most az `buf`-et használhatjuk normál szeletként:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *A módszer helytelen* használata:
    ///
    /// Nem használhatja az `.assume_init_mut()`-et egy érték inicializálására:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Hoztunk létre egy (mutable) hivatkozást egy inicializálatlan `bool`-re!
    ///     // Ez nem definiált viselkedés.⚠️
    /// }
    /// ```
    ///
    /// Például nem lehet [`Read`]-et inicializálatlan pufferbe tenni:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) utalás az inicializálatlan memóriára!
    ///                             // Ez nem definiált viselkedés.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// A mezőnkénti fokozatos inicializáláshoz nem használhat közvetlen terepi hozzáférést sem:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) utalás az inicializálatlan memóriára!
    ///                  // Ez nem definiált viselkedés.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) utalás az inicializálatlan memóriára!
    ///                  // Ez nem definiált viselkedés.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Jelenleg arra hivatkozunk, hogy a fentiek helytelenek, azaz hivatkozunk az inicializálatlan adatokra (pl. `libcore/fmt/float.rs`-ben).
    // A stabilizálás előtt végleges döntést kell hoznunk a szabályokról.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // BIZTONSÁG: a hívónak garantálnia kell az `self` inicializálását.
        // Ez azt is jelenti, hogy az `self`-nek `value`-változatnak kell lennie.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Kivonja az értékeket az `MaybeUninit` tárolók tömbjéből.
    ///
    /// # Safety
    ///
    /// A hívónak kell garantálnia, hogy a tömb minden eleme inicializált állapotban van.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // BIZTONSÁG: Most már biztonságban vagyunk, amikor az összes elemet inicializáltuk
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * A hívó garantálja, hogy a tömb összes elemét inicializálják
        // * `MaybeUninit<T>` és T garantáltan azonos elrendezésű
        // * Talán az Unint nem csökken, tehát nincsenek kettős felszabadítások, és így az átalakítás biztonságos
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Feltéve, hogy az összes elem inicializált, szerezzen be egy szeletet hozzájuk.
    ///
    /// # Safety
    ///
    /// A hívónak kell garantálnia, hogy az `MaybeUninit<T>` elemek valóban inicializált állapotban vannak.
    ///
    /// Ennek hívása, ha a tartalom még nincs teljesen inicializálva, meghatározatlan viselkedést okoz.
    ///
    /// További részletek és példák: [`assume_init_ref`].
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // BIZTONSÁG: A szelet `*const [T]`-re történő öntése biztonságos, mivel a hívó ezt garantálja
        // `slice` inicializálva van, és a `TalánUninit` garantáltan megegyezik az `T` elrendezésével.
        // A kapott mutató érvényes, mivel az `slice` tulajdonában lévő memóriára vonatkozik, amely referencia és így garantáltan érvényes az olvasásokra.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Feltéve, hogy az összes elem inicializálva van, kapjon hozzájuk egy módosítható szeletet.
    ///
    /// # Safety
    ///
    /// A hívónak kell garantálnia, hogy az `MaybeUninit<T>` elemek valóban inicializált állapotban vannak.
    ///
    /// Ennek hívása, ha a tartalom még nincs teljesen inicializálva, meghatározatlan viselkedést okoz.
    ///
    /// További részletek és példák: [`assume_init_mut`].
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // BIZTONSÁG: hasonló az `slice_get_ref` biztonsági megjegyzéseihez, de van egy
        // mutábilis hivatkozás, amely garantáltan érvényes az írásokra is.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Mutatót kap a tömb első elemére.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Megváltoztatható mutatót kap a tömb első elemére.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Az elemeket `src`-ről `this`-re másolja, az `this` most inicializált tartalmára mutáns hivatkozást adva.
    ///
    /// Ha az `T` nem valósítja meg az `Copy`-et, akkor használja az [`write_slice_cloned`]-et
    ///
    /// Ez hasonló az [`slice::copy_from_slice`]-hez.
    ///
    /// # Panics
    ///
    /// Ez a funkció akkor lesz panic, ha a két szelet eltérő hosszúságú.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // BIZTONSÁG: a len összes elemét átmásoltuk a tartalék kapacitásba
    /// // a vec első src.len() elemei érvényesek.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // BIZTONSÁG: &[T] és&[TalánUninit<T>] ugyanazzal az elrendezéssel rendelkeznek
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // BIZTONSÁG: Az érvényes elemeket éppen átmásolta az `this`-be, így inicializálva van
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Klónozza az elemeket `src`-től `this`-ig, visszakapcsolva az `this` most inicializált tartalmát.
    /// A már inicializált elemeket nem vesszük el.
    ///
    /// Ha az `T` megvalósítja az `Copy`-et, használja az [`write_slice`]-et
    ///
    /// Ez hasonló az [`slice::clone_from_slice`]-hez, de nem dobja el a meglévő elemeket.
    ///
    /// # Panics
    ///
    /// Ez a funkció akkor lesz panic, ha a két szelet eltérő hosszúságú, vagy ha az `Clone` panics megvalósítása történik.
    ///
    /// Ha van panic, akkor a már klónozott elemek eldobódnak.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // BIZTONSÁG: Most klónoztuk a len összes elemét a tartalék kapacitásba
    /// // a vec első src.len() elemei érvényesek.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // a copy_from_slice-től eltérően ez nem hívja meg a clone_from_slice-t a szeleten, mert az `MaybeUninit<T: Clone>` nem valósítja meg a Clone-t.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // BIZTONSÁG: Ez a nyers szelet csak inicializált objektumokat tartalmaz
                // ezért szabad ledobni.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Kifejezetten azonos hosszúságra kell szeletelnünk őket
        // hogy a határellenőrzés eltűnik, és az optimalizáló memcpy-t generál egyszerű esetekhez (például T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // védelemre van szükség b/c A panic előfordulhat egy klón alatt
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // BIZTONSÁG: Érvényes elemeket épp beírtak az `this`-be, így inicializálva van
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}