use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Egy burkoló, amely megakadályozza, hogy a fordító automatikusan felhívja a `T` rombolóját.
/// Ez a csomagolóanyag 0 költségű.
///
/// `ManuallyDrop<T>` ugyanazok az elrendezési optimalizálások vonatkoznak, mint az `T`.
/// Ennek következtében *nincs hatása* azokra a feltételezésekre, amelyeket a fordító a tartalmával kapcsolatban megfogalmaz.
/// Például az `ManuallyDrop<&mut T>` inicializálása az [`mem::zeroed`] segítségével nem meghatározott viselkedés.
/// Ha nem inicializált adatokat kell kezelnie, akkor használja az [`MaybeUninit<T>`]-et.
///
/// Ne feledje, hogy az `ManuallyDrop<T>`-en belüli érték elérése biztonságos.
/// Ez azt jelenti, hogy egy `ManuallyDrop<T>`-et, amelynek tartalmát elvetették, nem szabad nyilvánosan hozzáférhető API-n keresztül kitenni.
/// Ennek megfelelően az `ManuallyDrop::drop` nem biztonságos.
///
/// # `ManuallyDrop` és dobja el a sorrendet.
///
/// A Rust jól definiált [drop order] értékekkel rendelkezik.
/// Annak érdekében, hogy a mezőket vagy a helyieket meghatározott sorrendben dobják el, rendezze át a deklarációkat úgy, hogy az implicit dobási sorrend legyen a helyes.
///
/// Lehetőség van az `ManuallyDrop` használatára a leadási sorrend vezérléséhez, de ez nem biztonságos kódot igényel, és feloldás esetén nehéz helyesen megtenni.
///
///
/// Például, ha meg akarja győződni arról, hogy egy adott mező el van ejtve a többiek után, tegye azt a struktúra utolsó mezőként:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` `children` után eldobásra kerül.
///     // A Rust garantálja, hogy a mezőket a deklarálás sorrendjében eldobják.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Csomagoljon egy kézzel dobandó értéket.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Az értéket továbbra is biztonságosan működtetheti
    /// assert_eq!(*x, "Hello");
    /// // De az `Drop` itt nem fog futni
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Kivonja az értéket az `ManuallyDrop` tárolóból.
    ///
    /// Ez lehetővé teszi az érték újbóli eldobását.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Ez ledobja az `Box`-et.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Kiveszi az `ManuallyDrop<T>` konténer értékét.
    ///
    /// Ez a módszer elsősorban az értékek cseppenkénti mozgatására szolgál.
    /// Ahelyett, hogy az [`ManuallyDrop::drop`]-et használná az érték manuális eldobására, használhatja ezt a módszert az érték felvételére és a kívánt módon történő felhasználásra.
    ///
    /// Lehetőség szerint inkább az [`into_inner`][`ManuallyDrop::into_inner`]-et használja, amely megakadályozza az `ManuallyDrop<T>` tartalmának másolatát.
    ///
    ///
    /// # Safety
    ///
    /// Ez a függvény szemantikailag elmozdítja a tartalmazott értéket anélkül, hogy megakadályozná a további felhasználást, így a tároló állapota változatlan marad.
    /// Az Ön felelőssége annak biztosítása, hogy ezt az `ManuallyDrop`-et ne használja újra.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // BIZTONSÁG: referenciából olvasunk, ami garantált
        // hogy érvényes legyen az olvasásokra.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Manuálisan eldobja a benne foglalt értéket.Ez pontosan megegyezik azzal, hogy az [`ptr::drop_in_place`]-et hívjuk egy mutatóval a benne foglalt értékre.
    /// Mint ilyen, kivéve, ha a tartalmazott érték csomagolt struktúra, a destruktort az érték elmozdítása nélkül helyben hívják, és így felhasználható az [pinned] adatok biztonságos eldobására.
    ///
    /// Ha az érték tulajdonosa, akkor ehelyett használhatja az [`ManuallyDrop::into_inner`]-et.
    ///
    /// # Safety
    ///
    /// Ez a függvény futtatja a benne lévő érték rombolóját.
    /// Maga a romboló által végrehajtott változtatások mellett a memória változatlan marad, és ami a fordítót illeti, még mindig rendelkezik egy `T` típusra érvényes bitmintával.
    ///
    ///
    /// Ezt az "zombie" értéket azonban nem szabad biztonságos kódnak kitenni, és ezt a funkciót nem szabad többször meghívni.
    /// Ha egy értéket eldobása után használ, vagy ha egy értéket többször eldob, az meghatározhatatlan viselkedést okozhat (attól függően, hogy az `drop` mit csinál).
    /// Ezt általában a típusrendszer megakadályozza, de az `ManuallyDrop` felhasználóinak be kell tartaniuk ezeket a garanciákat a fordító segítsége nélkül.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // BIZTONSÁG: eldobjuk az értéket, amelyre mutábilis hivatkozás mutat
        // ami garantáltan érvényes az írásokra.
        // A hívónak kell megbizonyosodnia arról, hogy az `slot` nem esik-e le újra.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}