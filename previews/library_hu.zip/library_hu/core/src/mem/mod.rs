//! Alapfunkciók a memória kezeléséhez.
//!
//! Ez a modul funkciókat tartalmaz a típusok méretének és igazításának lekérdezéséhez, a memória inicializálásához és kezeléséhez.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Tulajdonjogot és "forgets"-et vesz az **értékre anélkül, hogy a rombolóját működtetné**.
///
/// Bármely erőforrás, amelyet az érték kezel, például halom memória vagy fájlkezelő, örökké megmarad elérhetetlen állapotban.Nem garantálja azonban, hogy az erre a memóriára mutató mutatók érvényesek maradnak.
///
/// * Ha memóriát akar szivárogtatni, lásd: [`Box::leak`].
/// * Ha nyers mutatót szeretne kapni a memóriához, lásd: [`Box::into_raw`].
/// * Ha egy értéket megfelelően akar megsemmisíteni, futtatva a destruktort, lásd: [`mem::drop`].
///
/// # Safety
///
/// `forget` nincs jelölve `unsafe` néven, mert a Rust biztonsági garanciái nem tartalmazzák azt a garanciát, hogy a destruktorok mindig működni fognak.
/// Például egy program létrehozhat egy referencia-ciklust az [`Rc`][rc] használatával, vagy felhívhatja az [`process::exit`][exit]-et a kilépéshez a destruktorok futtatása nélkül.
/// Így az `mem::forget` biztonságos kódból történő engedélyezése alapvetően nem változtatja meg a Rust biztonsági garanciáit.
///
/// Ennek ellenére az erőforrások, például a memória vagy az I/O objektumok kiszivárogtatása általában nem kívánatos.
/// Bizonyos speciális esetekben felmerül az igény az FFI vagy a nem biztonságos kódok használatára, de akkor is az [`ManuallyDrop`] az előnyös.
///
/// Mivel egy érték elfelejtése megengedett, minden `unsafe` kódnak, amelyet ír, engedélyeznie kell ezt a lehetőséget.Nem adhat vissza értéket, és számíthat arra, hogy a hívó feltétlenül futtatja az érték rombolóját.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Az `mem::forget` kanonikus biztonságos használata az `Drop` trait által megvalósított értékrontó megkerülése.Például ez kiszivárogtat egy `File`-et, azaz
/// igényelje vissza a változó által elfoglalt helyet, de soha ne zárja be az alapul szolgáló rendszererőforrást:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Ez akkor hasznos, ha az alapul szolgáló erőforrás tulajdonjogát korábban a Rust-en kívüli kódra ruházták át, például a nyers fájlleíró C-kódba történő továbbításával.
///
/// # Kapcsolat az `ManuallyDrop`-szel
///
/// Míg az `mem::forget` használható a *memória* tulajdonjogának átadására is, ez hibára hajlamos.
/// [`ManuallyDrop`] helyette kell használni.Vegyük például ezt a kódot:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Készítsen egy `String`-et az `v` tartalmának felhasználásával
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // szivárog az `v`, mert a memóriáját most az `s` kezeli
/// mem::forget(v);  // ERROR, v érvénytelen és nem adható át egy függvénynek
/// assert_eq!(s, "Az");
/// // `s` hallgatólagosan el van vetve, és memóriája feloszlik.
/// ```
///
/// A fenti példának két kérdése van:
///
/// * Ha több kód kerülne az `String` építése és az `mem::forget()` meghívása közé, akkor a benne lévő panic kettős szabaddá válást okozna, mert ugyanazt a memóriát kezeli mind az `v`, mind az `s`.
/// * Miután felhívta az `v.as_mut_ptr()`-et, és továbbította az adatok tulajdonjogát az `s`-nek, az `v` értéke érvénytelen.
/// Még akkor is, ha egy értéket éppen áthelyeznek az `mem::forget`-be (amely nem vizsgálja meg), egyes típusok szigorú követelményeket támasztanak az értékeikkel kapcsolatban, amelyek érvénytelenné teszik őket, amikor lógnak, vagy amelyek már nem tulajdonában vannak.
/// Az érvénytelen értékek bármilyen módon történő felhasználása, beleértve a funkciókba történő átadásukat vagy a funkciókból való visszaadásukat, meghatározatlan viselkedésnek minősül, és megsértheti a fordító feltételezéseit.
///
/// Az `ManuallyDrop`-re váltás mindkét problémát elkerüli:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Mielőtt szétszereljük az `v`-et a nyers részeibe, ellenőrizze, hogy nem esik-e le!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Most szedje szét az `v`-et.Ezek a műveletek nem képesek panic-re, ezért nem lehet szivárgás.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Végül készítsen egy `String`-et.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` hallgatólagosan el van vetve, és memóriája feloszlik.
/// ```
///
/// `ManuallyDrop` robusztusan megakadályozza a kettős mentességet, mert mielőtt bármi mást csinálnánk, letiltjuk a `v` destruktorát.
/// `mem::forget()` ezt nem engedi meg, mert elfogyasztja az érvelését, és arra kényszerít minket, hogy csak azután hívjuk fel, hogy bármi kivonatunk volna az `v`-ből.
/// Még akkor is, ha egy panic-t vezetnének be az `ManuallyDrop` építése és a karakterlánc megépítése között (ami nem történhet meg az ábrán látható kódban), az szivárgást eredményez, és nem kétszer szabad.
/// Más szavakkal, az `ManuallyDrop` a szivárgás oldalán hibázik, ahelyett, hogy a (kettős) leesés oldalán hibázna.
///
/// Ezenkívül az `ManuallyDrop` megakadályozza, hogy a tulajdonjog átadása után az "touch" `v`-et kelljen elvégeznünk, miután az `s`-re átruházta az `v`-et-teljesen elkerülhető az utolsó lépés, amikor az `v`-szel interakcióba lépünk, hogy ártalmatlanítsuk a romboló működtetése nélkül.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Mint az [`forget`], de elfogadja a nem méretezett értékeket is.
///
/// Ez a funkció csak egy alátét, amelyet el kell távolítani, amikor az `unsized_locals` funkció stabilizálódik.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Visszaadja a típus méretét bájtban.
///
/// Pontosabban, ez egy tömb egymást követő elemei közötti bájtok közötti eltolás az adott elemtípus mellett, beleértve az igazítási kitöltést is.
///
/// Így bármilyen `T` típushoz és `n` hosszúsághoz az `[T; n]` mérete `n * size_of::<T>()`.
///
/// Általában a típus mérete nem stabil az összeállításokban, de bizonyos típusok, például a primitívek.
///
/// A következő táblázat megadja a primitívek méretét.
///
/// Típus |mérete: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8. u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 karakter |4
///
/// Továbbá az `usize` és az `isize` azonos méretű.
///
/// Az `*const T`, `&T`, `Box<T>`, `Option<&T>` és `Option<Box<T>>` típusok mindegyike azonos méretű.
/// Ha az `T` méretben van, akkor az összes típusnak megegyezik az `usize` méretével.
///
/// A mutató mutabilitása nem változtatja meg a méretét.Mint ilyen, az `&T` és az `&mut T` azonos méretű.
/// Ugyanígy az `*const T` és az `* mut T` esetében is.
///
/// # `#[repr(C)]` elemek mérete
///
/// Az elemek `C` ábrázolása meghatározott elrendezéssel rendelkezik.
/// Ezzel az elrendezéssel az elemek mérete is stabil, amennyiben az összes mező stabil méretű.
///
/// ## A struktúrák mérete
///
/// Az `structs` esetében a méretet a következő algoritmus határozza meg.
///
/// A struktúra deklarációs sorrendben rendelt minden mezőjéhez:
///
/// 1. Adja hozzá a mező méretét.
/// 2. Az aktuális méretet kerekítse fel a következő mező [alignment] legközelebbi többszörösére.
///
/// Végül kerekítse a struktúra méretét az [alignment] legközelebbi többszörösére.
/// A struktúra igazítása általában az összes mező legnagyobb igazítása;ez megváltoztatható az `repr(align(N))` használatával.
///
/// Az `C`-től eltérően a nulla méretű struktúrákat nem kerekítik fel egy bájt méretűre.
///
/// ## Enums mérete
///
/// A diszkriminánson kívül más adatot nem hordozó számlák mérete megegyezik a C enumokkal azon a platformon, amelyhez össze vannak állítva.
///
/// ## A szakszervezetek mérete
///
/// Az unió mérete megegyezik a legnagyobb területével.
///
/// Az `C`-től eltérően a nulla méretű szakszervezetek nincsenek kerekítve egy bájt méretűre.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Néhány primitív
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Néhány tömb
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // A mutató méretének egyenlősége
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Az `#[repr(C)]` használata.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Az első mező mérete 1, ezért adjon hozzá 1-et a mérethez.A méret 1.
/// // A második mező igazítása 2, ezért adjon hozzá 1-et a kitöltés méretéhez.A méret 2.
/// // A második mező mérete 2, ezért adjon hozzá 2-t a mérethez.A méret 4.
/// // A harmadik mező igazítása 1, ezért adjon 0-t a kitöltés méretéhez.A méret 4.
/// // A harmadik mező mérete 1, ezért adjon hozzá 1-et a mérethez.A méret 5.
/// // Végül a struktúra igazítása 2 (mivel a mezők között a legnagyobb igazítás 2), ezért adjon 1-et a kitöltés méretéhez.
/// // A méret 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // A Tuple-csavarások ugyanazokat a szabályokat követik.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Vegye figyelembe, hogy a mezők átrendezése csökkentheti a méretet.
/// // Mindkét kitöltési bájt eltávolítható azáltal, hogy az `third`-et az `second` elé helyezzük.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Az unió mérete a legnagyobb mező nagysága.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Visszaadja a hegyes érték méretét bájtokban.
///
/// Ez általában ugyanaz, mint az `size_of::<T>()`.
/// Ha azonban az `T`* * statikailag nem ismert méretű, például egy [`[T]`][slice] vagy [trait object] szelet, akkor az `size_of_val` használható a dinamikusan ismert méret megszerzésére.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // BIZTONSÁG: Az `val` egy referencia, tehát érvényes nyers mutató
    unsafe { intrinsics::size_of_val(val) }
}

/// Visszaadja a hegyes érték méretét bájtokban.
///
/// Ez általában ugyanaz, mint az `size_of::<T>()`.Ha azonban az `T` *-nak nincs statikailag ismert mérete, például egy [`[T]`][slice] vagy [trait object] szelet, akkor az `size_of_val_raw` használható a dinamikusan ismert méret megszerzésére.
///
/// # Safety
///
/// Ez a funkció csak akkor biztonságos, ha a következő feltételek teljesülnek:
///
/// - Ha az `T` `Sized`, akkor ezt a funkciót mindig biztonságos hívni.
/// - Ha az `T` méret nélküli farka:
///     - egy [slice], akkor a szeletfarok hosszának inicializált egész számnak kell lennie, és a *teljes érték* méretének (dinamikus farokhossz + statikus méretű előtag) illeszkednie kell az `isize`-be.
///     - egy [trait object], akkor a mutató vtable részének egy nem méretező kényszerrel megszerzett érvényes vtable-re kell mutatnia, és a *teljes érték* méretének (dinamikus farokhossz + statikus méretű előtag) illeszkednie kell az `isize`-be.
///
///     - (unstable) [extern type], akkor ezt a funkciót mindig biztonságos hívni, de előfordulhat, hogy a panic vagy más módon rossz értéket ad vissza, mivel a külső típus elrendezése nem ismert.
///     Ez megegyezik az [`size_of_val`] viselkedésével, ha egy külső típusú farokkal rendelkező típusra hivatkozunk.
///     - ellenkező esetben konzervatív módon nem szabad ezt a függvényt meghívni.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // BIZTONSÁG: a hívónak érvényes nyers mutatót kell megadnia
    unsafe { intrinsics::size_of_val(val) }
}

/// Visszaadja a típus [ABI] által előírt minimális igazítását.
///
/// Az `T` típusú értékre történő minden hivatkozásnak ennek a számnak a többszörösének kell lennie.
///
/// Ez a struktúra mezőknél használt igazítás.Kisebb lehet, mint az előnyben részesített igazítás.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Visszaadja az [ABI] szükséges minimális igazítását annak az értéknek a típusához, amelyre az `val` mutat.
///
/// Az `T` típusú értékre történő minden hivatkozásnak ennek a számnak a többszörösének kell lennie.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // BIZTONSÁG: a val referencia, tehát érvényes nyers mutató
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Visszaadja a típus [ABI] által előírt minimális igazítását.
///
/// Az `T` típusú értékre történő minden hivatkozásnak ennek a számnak a többszörösének kell lennie.
///
/// Ez a struktúra mezőknél használt igazítás.Kisebb lehet, mint az előnyben részesített igazítás.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Visszaadja az [ABI] szükséges minimális igazítását annak az értéknek a típusához, amelyre az `val` mutat.
///
/// Az `T` típusú értékre történő minden hivatkozásnak ennek a számnak a többszörösének kell lennie.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // BIZTONSÁG: a val referencia, tehát érvényes nyers mutató
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Visszaadja az [ABI] szükséges minimális igazítását annak az értéknek a típusához, amelyre az `val` mutat.
///
/// Az `T` típusú értékre történő minden hivatkozásnak ennek a számnak a többszörösének kell lennie.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Ez a funkció csak akkor biztonságos, ha a következő feltételek teljesülnek:
///
/// - Ha az `T` `Sized`, akkor ezt a funkciót mindig biztonságos hívni.
/// - Ha az `T` méret nélküli farka:
///     - egy [slice], akkor a szeletfarok hosszának inicializált egész számnak kell lennie, és a *teljes érték* méretének (dinamikus farokhossz + statikus méretű előtag) illeszkednie kell az `isize`-be.
///     - egy [trait object], akkor a mutató vtable részének egy nem méretező kényszerrel megszerzett érvényes vtable-re kell mutatnia, és a *teljes érték* méretének (dinamikus farokhossz + statikus méretű előtag) illeszkednie kell az `isize`-be.
///
///     - (unstable) [extern type], akkor ezt a funkciót mindig biztonságos hívni, de előfordulhat, hogy a panic vagy más módon rossz értéket ad vissza, mivel a külső típus elrendezése nem ismert.
///     Ez megegyezik az [`align_of_val`] viselkedésével, ha egy külső típusú farokkal rendelkező típusra hivatkozunk.
///     - ellenkező esetben konzervatív módon nem szabad ezt a függvényt meghívni.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // BIZTONSÁG: a hívónak érvényes nyers mutatót kell megadnia
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Visszaadja az `true` értéket, ha az `T` típusú értékek esése számít.
///
/// Ez pusztán optimalizálási tipp, és konzervatív módon megvalósítható:
/// visszaadhatja az `true`-et olyan típusok esetében, amelyeket valójában nem kell ledobni.
/// Mint ilyen, az `true` mindig visszatérő értéke ennek a funkciónak a valós megvalósítása lenne.Ha azonban ez a függvény valóban visszaadja az `false` értéket, akkor biztos lehet benne, hogy az `T` eldobásának nincs mellékhatása.
///
/// Az olyan dolgok alacsony szintű megvalósításának, mint a gyűjtemények, amelyeknek kézzel kell eldobniuk adataikat, ezt a funkciót kell használniuk, hogy elkerüljék az összes tartalmuk felesleges megpróbálását, amikor megsemmisítik őket.
///
/// Lehet, hogy ez nem tesz különbséget a kiadás buildjeiben (ahol könnyen észlelhető és kiküszöbölhető egy hurok, amelynek nincs mellékhatása), de a debug buildeknél gyakran nagy győzelmet jelent.
///
/// Ne feledje, hogy az [`drop_in_place`] már elvégzi ezt az ellenőrzést, így ha a munkaterhelés néhány kis [`drop_in_place`] hívásra csökkenthető, akkor ennek használata felesleges.
/// Különösképpen vegye figyelembe, hogy [`drop_in_place`]-szeleteket is készíthet egy szeletből, és ez egyetlen szükséglet_csepp ellenőrzést végez az összes értéknél.
///
/// A Vechez hasonló típusok ezért csak az `drop_in_place(&mut self[..])`-et használják, az `needs_drop` kifejezett használata nélkül.
/// Az [`HashMap`]-hez hasonló típusoknak viszont egyenként kell elvetniük az értékeket, és ezt az API-t kell használniuk.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Íme egy példa arra, hogy egy gyűjtemény hogyan használhatja az `needs_drop`-et:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // dobja az adatokat
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Visszaadja az `T` típusú értéket, amelyet a nulla bájtminta képvisel.
///
/// Ez azt jelenti, hogy például az `(u8, u16)` párnázási bájtját nem feltétlenül nullázzák.
///
/// Nincs garancia arra, hogy a nulla bájtminta valamilyen `T` típus érvényes értékét képviseli.
/// Például a nulla bájtminta nem érvényes érték a referencia típusok (`&T`, `&mut T`) és a funkciómutatók számára.
/// Az `zeroed` használata ilyen típusoknál azonnali [undefined behavior][ub]-et eredményez, mert [the Rust compiler assumes][inv], hogy mindig van érvényes érték egy olyan változóban, amelyet inicializál.
///
///
/// Ennek ugyanaz a hatása, mint az [`MaybeUninit::zeroed().assume_init()`][zeroed]-nek.
/// Néha hasznos az FFI számára, de általában kerülni kell.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Ennek a függvénynek a helyes használata: egy nullával egész szám inicializálása.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *A funkció helytelen* használata: egy referencia inicializálása nullával.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Meghatározatlan viselkedés!
/// let _y: fn() = unsafe { mem::zeroed() }; // És újra!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // BIZTONSÁG: a hívónak garantálnia kell, hogy a nulla érték érvényes az `T` esetében.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Megkerüli a Rust normál memória-inicializálási ellenőrzéseit úgy, mintha `T` típusú értéket állítana elő, miközben semmit sem csinál.
///
/// **Ez a funkció elavult.** Használja helyette az [`MaybeUninit<T>`]-et.
///
/// Az elavulás oka az, hogy a függvény alapvetően nem használható helyesen: ugyanaz a hatása, mint az [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Amint az [`assume_init` documentation][assume_init] megmagyarázza, az [the Rust compiler assumes][inv], amely értékeket megfelelően inicializál.
/// Ennek következtében pl
/// `mem::uninitialized::<bool>()` azonnal meghatározhatatlan viselkedést okoz egy `bool` visszaadásakor, amely nem feltétlenül `true` vagy `false`.
/// A rosszabb, valóban inicializálatlan memória, például az, ami itt visszaküldik, abban különleges, hogy a fordító tudja, hogy nincs fix értéke.
/// Ez meghatározatlanná teszi az inicializálatlan adatok meglétét egy változóban, még akkor is, ha ennek a változónak egész típusú típusa van.
/// (Vegye figyelembe, hogy az inicializálatlan egészek körüli szabályok még nincsenek véglegesítve, de mindaddig ajánlatos elkerülni őket.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // BIZTONSÁG: a hívónak garantálnia kell, hogy az egységesített érték érvényes az `T`-re.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Az értékeket két mutálható helyen cseréli fel, de egyiket sem inicializálva.
///
/// * Ha fel akar cserélni egy alapértelmezett vagy dummy értékkel, lásd: [`take`].
/// * Ha átadott értékkel szeretne cserélni, a régi értéket visszaadva, lásd: [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // BIZTONSÁG: a nyers mutatókat biztonságos, mutábilis referenciákból hozták létre, amelyek kielégítik az összes
    // korlátozások az `ptr::swap_nonoverlapping_one`-en
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Az `dest` helyére az alapértelmezett `T` érték kerül, az előző `dest` értéket adja vissza.
///
/// * Ha két változó értékét szeretné lecserélni, lásd: [`swap`].
/// * Ha az alapértelmezett érték helyett átadott értékkel szeretne lecserélni, lásd: [`replace`].
///
/// # Examples
///
/// Egy egyszerű példa:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` lehetővé teszi egy struktúramező tulajdonjogának megszerzését azáltal, hogy "empty" értékkel helyettesíti.
/// `take` nélkül ilyen problémákba ütközhet:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Ne feledje, hogy az `T` nem feltétlenül valósítja meg az [`Clone`]-et, így nem is tudja klónozni és visszaállítani az `self.buf`-et.
/// De az `take` használható az `self.buf` eredeti értékének elválasztására az `self`-től, lehetővé téve annak visszaadását:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Az `src`-et áthelyezi a hivatkozott `dest`-be, visszaadva az előző `dest`-értéket.
///
/// Egyik érték sem esik le.
///
/// * Ha két változó értékét szeretné lecserélni, lásd: [`swap`].
/// * Ha egy alapértelmezett értékre kíván cserélni, lásd: [`take`].
///
/// # Examples
///
/// Egy egyszerű példa:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` lehetővé teszi a struktúramező fogyasztását egy másik értékkel való helyettesítésével.
/// `replace` nélkül ilyen problémákba ütközhet:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Vegye figyelembe, hogy az `T` nem feltétlenül valósítja meg az [`Clone`]-et, így az áthelyezés elkerülése érdekében még az `self.buf[i]`-et sem klónozhatjuk.
/// De az `replace` használható az index eredeti értékének elválasztására az `self`-től, lehetővé téve annak visszaadását:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // BIZTONSÁG: `dest`-ről olvasunk, de utána közvetlenül beírjuk az `src`-et,
    // olyan, hogy a régi érték nem duplikálódik.
    // Semmi sem esik, és itt semmi sem képes a panic-re.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Értékkel rendelkezik.
///
/// Ez úgy történik, hogy meghívja az argumentum [`Drop`][drop] megvalósítását.
///
/// Ez gyakorlatilag nem tesz semmit az `Copy`-et megvalósító típusoknál, pl
/// integers.
/// Az ilyen értékeket átmásolja és az _then_ bekerül a függvénybe, így az érték a függvényhívást követően is megmarad.
///
///
/// Ez a funkció nem varázslat;szó szerint úgy definiálják
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Mivel az `_x` bekerül a függvénybe, a funkció visszatérése előtt automatikusan eldobja.
///
/// [drop]: Drop
///
/// # Examples
///
/// Alapvető használat:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // kifejezetten dobja el a vector-t
/// ```
///
/// Mivel az [`RefCell`] futás közben hajtja végre a kölcsönzési szabályokat, az `drop` felszabadíthatja az [`RefCell`] hitelt:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // mondjon le erről a résről a változó kölcsönről
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Az `drop` nem befolyásolja az egész számokat és az [`Copy`]-et megvalósító egyéb típusokat.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // az `x` egy példányát áthelyezi és eldobja
/// drop(y); // az `y` egy példányát áthelyezi és eldobja
///
/// println!("x: {}, y: {}", x, y.0); // Raktáron, elérhető
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Az `src`-et `&U` típusúnak értelmezi, majd az `src`-et beolvassa a benne lévő érték mozgatása nélkül.
///
/// Ez a függvény bizonytalanul feltételezi, hogy az `src` mutató [`size_of::<U>`][size_of] bájtokra érvényes, ha az `&T`-et átalakítja `&U`-re, majd elolvassa az `&U`-et (azzal a különbséggel, hogy ez akkor is helyes, ha az `&U` szigorúbb igazítási követelményeket állít elő, mint az `&T`).
/// Az `src`-ből való kilépés helyett nem biztonságos módon létrehoz egy másolatot a benne lévő értékről.
///
/// Nem fordítási időbeli hiba, ha az `T` és az `U` különböző méretű, de erősen javasoljuk, hogy ezt a funkciót csak akkor hívják meg, ahol az `T` és az `U` azonos méretű.Ez a függvény akkor indítja el az [undefined behavior][ub]-et, ha az `U` nagyobb, mint `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Másolja az adatokat az 'foo_array' fájlból, és kezelje 'Foo' fájlként
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Módosítsa a másolt adatokat
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Az 'foo_array' tartalmának nem kellett volna megváltoznia
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Ha U-nak nagyobb a beállítási követelménye, akkor a src nem biztos, hogy megfelelően van beállítva.
    if align_of::<U>() > align_of::<T>() {
        // BIZTONSÁG: Az `src` egy referencia, amely garantáltan érvényes az olvasásokra.
        // A hívónak garantálnia kell, hogy a tényleges transzmutáció biztonságos.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // BIZTONSÁG: Az `src` egy referencia, amely garantáltan érvényes az olvasásokra.
        // Most ellenőriztük, hogy az `src as *const U` megfelelően illeszkedik-e.
        // A hívónak garantálnia kell, hogy a tényleges transzmutáció biztonságos.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Átlátszatlan típus, amely az enum megkülönböztetőjét képviseli.
///
/// További információkért lásd a modul [`discriminant`] funkcióját.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Ezeket a trait megvalósításokat nem lehet levezetni, mert nem akarunk semmiféle határt T-n.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Visszaad egy olyan értéket, amely egyedileg azonosítja az `v` enum változatát.
///
/// Ha az `T` nem enum, akkor ennek a függvénynek a meghívása nem eredményez meghatározatlan viselkedést, de a visszatérési érték nincs meghatározva.
///
///
/// # Stability
///
/// Az enum variáns diszkriminánsa megváltozhat, ha az enum definíció megváltozik.
/// Egyes változatok megkülönböztetése nem változik az ugyanazzal a fordítóval végzett fordítások között.
///
/// # Examples
///
/// Ez felhasználható az adatokat hordozó számlák összehasonlítására, a tényleges adatok figyelmen kívül hagyásával:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Visszaadja az `T` enum típusú változatok számát.
///
/// Ha az `T` nem enum, akkor ennek a függvénynek a meghívása nem eredményez meghatározatlan viselkedést, de a visszatérési érték nincs meghatározva.
/// Hasonlóképpen, ha az `T` olyan szám, amelynél több változat van, mint az `usize::MAX`, akkor a visszatérési érték nincs megadva.
/// A lakatlan változatok megszámlálásra kerülnek.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}