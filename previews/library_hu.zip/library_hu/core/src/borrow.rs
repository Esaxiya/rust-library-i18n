//! A kölcsönzött adatok kezelésére szolgáló modul.

#![stable(feature = "rust1", since = "1.0.0")]

/// trait az adatok hitelfelvételéhez.
///
/// A Rust-ben gyakran előfordul, hogy egy adott típushoz különböző ábrázolásokat adnak különböző felhasználási esetekhez.
/// Például az érték tárolási helyét és kezelését speciálisan meg lehet választani egy adott felhasználáshoz mutatótípusokkal, például [`Box<T>`] vagy [`Rc<T>`].
/// Ezeken a bármilyen típusú típusokkal együtt használható általános csomagolókon kívül egyes típusok opcionális oldalakat kínálnak, amelyek potenciálisan költséges funkciókat kínálnak.
/// Ilyen típusra példa az [`String`], amely hozzáadja a karakterlánc kiterjesztésének képességét az alap [`str`]-hez.
/// Ehhez szükség van további információk szükségtelen megtartására egy egyszerű, megváltoztathatatlan karakterlánc esetében.
///
/// Ezek a típusok hozzáférést biztosítanak az alapul szolgáló adatokhoz az adatok típusára való hivatkozások útján.Állítólag ilyen típusúként " kölcsönzik őket`.
/// Például egy [`Box<T>`]-et `T`-ként, míg egy [`String`]-et `str`-ként lehet kölcsönkérni.
///
/// A típusok kifejezik, hogy valamilyen `T` típusként kölcsönözhetők az `Borrow<T>` megvalósításával, hivatkozást adva egy `T`-re a trait [`borrow`] módszerében.Egy típus szabadon kölcsönözhet többféle típusként.
/// Ha kölcsönösen kölcsön akar adni típusként-lehetővé téve az alapul szolgáló adatok módosítását, akkor az [`BorrowMut<T>`]-et is megvalósíthatja.
///
/// Továbbá, amikor további traits megvalósításokat biztosítanak, meg kell fontolni, hogy az alapul szolgáló típusokkal azonos módon kell-e viselkedniük az adott mögöttes típus ábrázolásaként.
/// Az általános kód általában akkor használja az `Borrow<T>`-et, ha e további trait-implementációk azonos viselkedésére támaszkodik.
/// Ezek a traits valószínűleg további trait bounds néven jelennek meg.
///
/// Különösen az `Eq`-nek, az `Ord`-nek és az `Hash`-nek kell egyenértékűnek lennie a kölcsönzött és a tulajdonban lévő értékeknél: az `x.borrow() == y.borrow()`-nek ugyanazt az eredményt kell adnia, mint az `x == y`-nek.
///
/// Ha az általános kódnak csak minden olyan típusnál működnie kell, amely hivatkozást adhat a kapcsolódó `T` típusra, akkor gyakran jobb az [`AsRef<T>`] használatát, mivel több típus is biztonságosan megvalósíthatja.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Adatgyűjtésként az [`HashMap<K, V>`] mind a kulcsokat, mind az értékeket birtokolja.Ha a kulcs tényleges adatai valamilyen kezelési típusba vannak csomagolva, akkor is lehetővé kell tenni, hogy értéket keressen a kulcs adataira való hivatkozással.
/// Például, ha a kulcs karakterlánc, akkor valószínűleg a kivonatkártyával együtt [`String`]-ként tárolják, míg az [`&str`][`str`] használatával lehetővé kell tenni a keresést.
/// Így az `insert`-nek `String`-en kell működnie, míg az `get`-nek képesnek kell lennie az `&str` használatára.
///
/// Kissé leegyszerűsítve az `HashMap<K, V>` releváns részei így néznek ki:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // mezők kihagyva
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// A teljes hash térkép általános egy `K` típusú kulcs felett.Mivel ezeket a kulcsokat a kivonatkártyával együtt tárolják, ennek a típusnak kell birtokolnia a kulcs adatait.
/// Kulcs-érték pár beszúrásakor a térkép egy ilyen `K`-et kap, és meg kell találnia a megfelelő hash-sávot, és ellenőriznie kell, hogy a kulcs már szerepel-e az `K` alapján.Ezért `K: Hash + Eq` szükséges.
///
/// Ha egy értéket keres a térképen, az `K`-re való hivatkozás megadása kulcsként megköveteli, hogy mindig létrejöjjön egy ilyen tulajdonban lévő érték.
/// A karakterlánc-kulcsoknál ez azt jelentené, hogy `String`-értéket kell létrehozni, csak azon esetek keresésére, ahol csak `str` áll rendelkezésre.
///
/// Ehelyett az `get` módszer általános az alapul szolgáló kulcsadatok típusához képest, amelyet a fenti metódus-aláírás `Q`-nek nevezünk.Azt állítja, hogy az `K` `Q`-ként vesz fel hitelt azzal, hogy megköveteli az `K: Borrow<Q>`-et.
/// Az `Q: Hash + Eq` megkövetelésével jelzi azt a követelményt, hogy az `K` és az `Q` rendelkezik az `Hash` és `Eq` traits megvalósításával, amelyek azonos eredményeket hoznak.
///
/// Az `get` megvalósítása különösen az `Hash` azonos megvalósításaira támaszkodik, amikor meghatározza a kulcs hash-sávját úgy, hogy az `Hash::hash`-et hívja az `Hash::hash` értékre, még akkor is, ha az `K` értékből számított kivonatérték alapján illesztette be a kulcsot.
///
///
/// Ennek következtében a kivonatkártya megszakad, ha az `Q` értéket becsomagoló `K` más kivonatot eredményez, mint az `Q`.Tegyük fel például, hogy van olyan típusa, amely tekercsel egy karakterláncot, de összehasonlítja az ASCII betűket, figyelmen kívül hagyva az esetüket:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Mivel két egyenlő értéknek ugyanazt a kivonatértéket kell előállítania, az `Hash` megvalósításának figyelmen kívül kell hagynia az ASCII eseteket is:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Az `CaseInsensitiveString` megvalósíthatja az `Borrow<str>`-et?Természetesen hivatkozást adhat egy karakterlánc-szeletre a benne lévő karakterláncon keresztül.
/// De mivel az `Hash` megvalósítása eltér, az `str`-től eltérően viselkedik, ezért valójában nem szabad végrehajtania az `Borrow<str>`-et.
/// Ha másoknak is hozzáférést akar biztosítani az alapul szolgáló `str`-hez, akkor ezt megteheti az `AsRef<str>`-en keresztül, amely nem igényel különösebb követelményeket.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Feltétlenül kölcsönöz egy tulajdonosi értékből.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// trait az adatok kölcsönös kölcsönvételéhez.
///
/// Az [`Borrow<T>`] társaként ez a trait lehetővé teszi, hogy egy típus kölcsönözhető alaptípusként kölcsönözhető referencia biztosításával.
/// A hitelfelvételről mint más típusról lásd az [`Borrow<T>`] oldalt.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Kölcsönösen kölcsönvett tulajdonosi értéket.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}