//! Az `Clone` trait típusokhoz, amelyeket nem lehet " hallgatólagosan lemásolni`.
//!
//! A Rust alkalmazásban néhány egyszerű típus az "implicitly copyable", és amikor ezeket hozzárendeli vagy argumentumként adja át, a vevő kap egy példányt, így az eredeti érték a helyén marad.
//! Ezek a típusok nem igényelnek kiosztást a másoláshoz, és nincsenek véglegesítőik (azaz nem tartalmaznak saját dobozokat vagy nem valósítják meg az [`Drop`]-et), ezért a fordító olcsónak és biztonságosnak tartja a másolást.
//!
//! Más típusok esetén a másolatokat kifejezetten kell elkészíteni, az [`Clone`] trait végrehajtásával és az [`clone`] módszer meghívásával.
//!
//! [`clone`]: Clone::clone
//!
//! Alapvető használati példa:
//!
//! ```
//! let s = String::new(); // Karakterlánc típusú klónok
//! let copy = s.clone(); // így klónozhatjuk
//! ```
//!
//! A Clone trait egyszerű megvalósításához használhatja az `#[derive(Clone)]`-et is.Példa:
//!
//! ```
//! #[derive(Clone)] // hozzáadjuk a trait klónt a Morpheus struktúrához
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // és most klónozhatjuk!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Egy közös trait az objektum kifejezett megismétlésének képességére.
///
/// Abban különbözik az [`Copy`]-től, hogy az [`Copy`] implicit és rendkívül olcsó, míg az `Clone` mindig explicit, és lehet, hogy nem is drága.
/// Ezen jellemzők érvényesítése érdekében a Rust nem teszi lehetővé az [`Copy`] újbóli végrehajtását, de az `Clone`-et újratelepítheti és tetszőleges kódot futtathat.
///
/// Mivel az `Clone` általánosabb, mint az [`Copy`], így bármi [`Copy`] automatikusan `Clone` is lehet.
///
/// ## Derivable
///
/// Ez a trait használható az `#[derive]` modellel, ha az összes mező `Clone`.Az [`Clone`] `derive`d megvalósítása minden mezőben felhívja az [`clone`]-et.
///
/// [`clone`]: Clone::clone
///
/// Általános struktúra esetén az `#[derive]` feltételesen hajtja végre az `Clone`-et úgy, hogy az általános paraméterekhez hozzáadja a kötött `Clone`-et.
///
/// ```
/// // `derive` megvalósítja a klón az olvasáshoz<T>amikor T klón.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Hogyan tudom megvalósítani az `Clone`-et?
///
/// Az [`Copy`] típusú típusoknak az `Clone` triviális megvalósításával kell rendelkezniük.Formálisabban:
/// ha `T: Copy`, `x: T` és `y: &T`, akkor `let x = y.clone();` egyenértékű az `let x = *y;` értékkel.
/// A kézi megvalósításnak ügyelnie kell ennek az invariánsnak a fenntartására;a nem biztonságos kód azonban nem támaszkodhat rá a memória biztonságának biztosítása érdekében.
///
/// Ilyen például egy függvénymutatót tartalmazó általános struktúra.Ebben az esetben az `Clone` megvalósítása nem `derive`d, hanem a következőképpen valósítható meg:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## További kivitelezők
///
/// Az [implementors listed below][impls] mellett a következő típusok is megvalósítják az `Clone`-et:
///
/// * Funkció elemtípusok (azaz az egyes funkciókhoz meghatározott külön típusok)
/// * Funkciómutató típusok (pl. `fn() -> i32`)
/// * Tömbtípusok, minden mérethez, ha az elemtípus az `Clone`-et is megvalósítja (pl. `[i32; 123456]`)
/// * Tuple típusok, ha minden alkatrész az `Clone`-et is megvalósítja (pl. `()`, `(i32, bool)`)
/// * Zárástípusok, ha nem vesznek fel értéket a környezetből, vagy ha az összes ilyen rögzített érték maga hajtja végre az `Clone`-et.
///   Ne feledje, hogy a megosztott referenciával rögzített változók mindig az `Clone`-et valósítják meg (még akkor is, ha a referens nem), míg a mutábilis referenciával elfogadott változók soha nem valósítják meg az `Clone`-et.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Visszaadja az érték másolatát.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str megvalósítja a Klón
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Másolás-hozzárendelést hajt végre `source`-ből.
    ///
    /// `a.clone_from(&b)` funkcionalitásával egyenértékű az `a = b.clone()`-szel, de felül lehet írni az `a` erőforrásainak újrafelhasználására a felesleges allokációk elkerülése érdekében.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Származtasson makrót, amely a trait `Clone` implikációját generálja.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): ezeket a struktúrákat kizárólag#[derive] használja annak megállapítására, hogy egy típus minden összetevője megvalósítja a Clone vagy a Copy elemeket.
//
//
// Ezek a struktúrák soha nem jelenhetnek meg a felhasználói kódban.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Az `Clone` implementációi primitív típusokhoz.
///
/// Azok a megvalósítások, amelyek nem írhatók le a Rust-ben, az `traits::SelectionContext::copy_clone_conditions()`-ben kerülnek megvalósításra az `rustc_trait_selection`-ben.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// A megosztott hivatkozások klónozhatók, de a mutálható hivatkozások *nem*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// A megosztott hivatkozások klónozhatók, de a mutálható hivatkozások *nem*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}