//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Az `char` maximálisan érvényes kódpontja lehet.
    ///
    /// Az `char` egy [Unicode Scalar Value], ami azt jelenti, hogy [Code Point], de csak egy bizonyos tartományon belül.
    /// `MAX` a legmagasabb érvényes kódpont, amely érvényes [Unicode Scalar Value].
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` Az () az Unicode-ban dekódolási hiba képviseletére szolgál.
    ///
    /// Ez akkor fordulhat elő például, ha rosszul formált UTF-8 bájtokat ad az [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy)-nek.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Az [Unicode](http://www.unicode.org/) változata, amelyen az `char` és `str` módszer Unicode részei alapulnak.
    ///
    /// Az Unicode új verzióit rendszeresen kiadják, és ezt követően az Unicode-tól függően a standard könyvtár összes módszere frissül.
    /// Ezért egyes `char` és `str` módszerek viselkedése és ennek az állandónak az értéke idővel változik.
    /// Ez *nem* tekinthető feltörő változásnak.
    ///
    /// A verziószámozási sémát az [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) magyarázza.
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Iterátort hoz létre az UTF-16 kódolt kódpontjai fölött az `iter`-ben, és a párosítatlan helyettesítőket `Err`-ként adja vissza.
    ///
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Veszteséges dekóder úgy érhető el, hogy az `Err` eredményeket kicseréli a helyettesítő karakterre:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// `u32`-et átalakít `char`-be.
    ///
    /// Ne feledje, hogy az összes "char" érvényes ["u32"] s, és egybe lehet önteni vele
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Viszont fordítva nem igaz: nem minden érvényes [`u32`] érvényes char.
    /// `from_u32()` visszaadja az `None` értéket, ha a bemenet nem érvényes érték egy `char` esetében.
    ///
    /// A funkció nem biztonságos verzióját, amely figyelmen kívül hagyja ezeket az ellenőrzéseket, lásd: [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// `None` visszaadása, ha a bemenet nem érvényes `char`:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Az `u32`-et átalakítja `char`-be, figyelmen kívül hagyva az érvényességet.
    ///
    /// Ne feledje, hogy az összes "char" érvényes ["u32"] s, és egybe lehet önteni vele
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Viszont fordítva nem igaz: nem minden érvényes [`u32`] érvényes char.
    /// `from_u32_unchecked()` ezt figyelmen kívül hagyja, és vakon átveti az `char`-re, esetleg érvénytelenet hozva létre.
    ///
    ///
    /// # Safety
    ///
    /// Ez a funkció nem biztonságos, mivel érvénytelen `char` értékeket állíthat össze.
    ///
    /// A funkció biztonságos verzióját lásd az [`from_u32`] funkcióban.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // BIZTONSÁG: a biztonsági szerződést a hívó félnek be kell tartania.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Az adott radix számjegyét `char`-vé alakítja.
    ///
    /// Az 'radix'-et itt néha 'base'-nek is hívják.
    /// A kettőből álló radix bináris számot, tíz, tizedes és tizenhat hexadecimális radixot jelent, hogy néhány közös értéket megadjon.
    ///
    /// Önkényes radikumok támogatottak.
    ///
    /// `from_digit()` visszaadja az `None` értéket, ha a bemenet nem egy számjegy az adott radixban.
    ///
    /// # Panics
    ///
    /// Panics, ha 36-nál nagyobb radixot kap.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // A 11. tizedes egy számjegy a 16. alapban
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// `None` visszatérése, ha a bemenet nem számjegy:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Nagy radix átengedése, ami panic-t okoz:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Ellenőrzi, hogy az `char` egy számjegy-e az adott radixban.
    ///
    /// Az 'radix'-et itt néha 'base'-nek is hívják.
    /// A kettőből álló radix bináris számot, tíz, tizedes és tizenhat hexadecimális radixot jelent, hogy néhány közös értéket megadjon.
    ///
    /// Önkényes radikumok támogatottak.
    ///
    /// Az [`is_numeric()`]-hez képest ez a funkció csak az `0-9`, `a-z` és `A-Z` karaktereket ismeri fel.
    ///
    /// 'Digit' meghatározása szerint csak a következő karakterek lehetnek:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Az 'digit' átfogóbb megértéséhez lásd: [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics, ha 36-nál nagyobb radixot kap.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Nagy radix átengedése, ami panic-t okoz:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Átalakítja az `char` számjegyét az adott radixban.
    ///
    /// Az 'radix'-et itt néha 'base'-nek is hívják.
    /// A kettőből álló radix bináris számot, tíz, tizedes és tizenhat hexadecimális radixot jelent, hogy néhány közös értéket megadjon.
    ///
    /// Önkényes radikumok támogatottak.
    ///
    /// 'Digit' meghatározása szerint csak a következő karakterek lehetnek:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Visszaadja az `None` értéket, ha az `char` nem az adott radix számjegyére utal.
    ///
    /// # Panics
    ///
    /// Panics, ha 36-nál nagyobb radixot kap.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Nem számjegy átadása sikertelenséget eredményez:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Nagy radix átengedése, ami panic-t okoz:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // a kód itt fel van osztva, hogy javuljon a végrehajtási sebesség azokban az esetekben, amikor az `radix` állandó és 10 vagy kisebb
        //
        let val = if likely(radix <= 10) {
            // Ha nem egy számjegy, akkor a radixnál nagyobb szám jön létre.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Olyan iterátort ad vissza, amely egy karakter hexadecimális Unicode-menekülését eredményezi "char"-ként.
    ///
    /// Ezzel elkerülheti az `\u{NNNNNN}` formátumú Rust szintaxissal rendelkező karaktereket, ahol az `NNNNNN` hexadecimális ábrázolás.
    ///
    ///
    /// # Examples
    ///
    /// Mint iterátor:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Az `println!` közvetlen használata:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Mindkettő egyenértékű:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Az `to_string` használata:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // vagy az 1-vel biztosítjuk, hogy a c==0 értéknél a kód kiszámolja, hogy egy számjegyet kell kinyomtatni, és (ami ugyanaz) elkerüli a (31, 32) alulcsordulást
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // a legjelentősebb hatszögjegy indexe
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Az `escape_debug` kibővített változata, amely opcionálisan lehetővé teszi az Extended Grapheme kódpontok elhagyását.
    /// Ez lehetővé teszi számunkra, hogy a karaktersorozatok nélküli karaktereket jobban formázzuk, amikor egy karakterlánc elején vannak.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Olyan iterátort ad vissza, amely egy karakter szó szerinti menekülési kódját adja meg "char" karakterként.
    ///
    /// Ezzel elkerülhetők az `str` vagy `char` `Debug` implementációihoz hasonló karakterek.
    ///
    ///
    /// # Examples
    ///
    /// Mint iterátor:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Az `println!` közvetlen használata:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Mindkettő egyenértékű:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Az `to_string` használata:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Olyan iterátort ad vissza, amely egy karakter szó szerinti menekülési kódját adja meg "char" karakterként.
    ///
    /// Az alapértelmezett beállítást a különböző nyelveken legális, a C++ 11 és hasonló C-családok nyelvén érvényes törvényes betűkészletek előállításával kell megválasztani.
    /// A pontos szabályok a következők:
    ///
    /// * A lap megúszik `\t` néven.
    /// * A kocsi visszaadása `\r` néven megúszik.
    /// * A sor előtolás `\n` néven meg van szüntetve.
    /// * Az egyetlen árajánlat `\'` néven kerül megkerülésre.
    /// * A kettős idézet elkerülve `\"`.
    /// * A hátsó perjel `\\` néven elkerülve.
    /// * A " nyomtatható ASCII` `0x20` .. `0x7e` (beleértve a XML) tartományt egyetlen karakter sem kerül elhagyásra.
    /// * Az összes többi karakter hexadecimális Unicode menekülési lehetőséget kap;lásd [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Mint iterátor:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Az `println!` közvetlen használata:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Mindkettő egyenértékű:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Az `to_string` használata:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Visszaadja azoknak a bájtoknak a számát, amelyekre az `char`-nek szüksége lenne, ha UTF-8-be kódolja.
    ///
    /// Ez a bájtok száma mindig 1 és 4 között van.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Az `&str` típus garantálja, hogy a tartalma UTF-8, és így össze tudjuk hasonlítani azt a hosszúságot, amelyre akkor lenne szükség, ha minden kódpont `char`-ként lenne ábrázolva, mint magában az `&str`-ben:
    ///
    ///
    /// ```
    /// // mint csajok
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // mindkettő három bájton ábrázolható
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // mint &str, ezt a kettőt UTF-8 kódolja
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // láthatjuk, hogy összesen hat bájtot vesznek fel ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... akárcsak az &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Visszaadja a 16 bites kódegységek számát, amelyre az `char`-nek szüksége lenne, ha UTF-16-be kódolja.
    ///
    ///
    /// A koncepció további magyarázatát az [`len_utf8()`] dokumentációjában találja.
    /// Ez a funkció tükör, de az UTF-16 helyett az UTF-8 helyett.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Ezt a karaktert UTF-8 formátumban kódolja a megadott bájtpufferbe, majd visszaadja a kódolt karaktert tartalmazó puffer alszeletét.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ha a puffer nem elég nagy.
    /// A négyes hosszúságú puffer elég nagy ahhoz, hogy bármely `char` kódoljon.
    ///
    /// # Examples
    ///
    /// Mindkét példában az 'ß' kódolásához két bájt szükséges.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Túl kicsi puffer:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // BIZTONSÁG: Az `char` nem helyettesítő, tehát ez érvényes UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Ezt a karaktert UTF-16 formátumban kódolja a megadott `u16` pufferbe, majd visszaadja a puffer alszeletét, amely tartalmazza a kódolt karaktert.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ha a puffer nem elég nagy.
    /// A 2 hosszúságú puffer elég nagy bármely `char` kódolásához.
    ///
    /// # Examples
    ///
    /// Mindkét példában az '𝕊' kódolásához két u16 szükséges.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Túl kicsi puffer:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Visszaadja az `true` értéket, ha ennek az `char`-nek van `Alphabetic` tulajdonsága.
    ///
    /// `Alphabetic` az [Unicode Standard] 4. fejezetében (Karaktertulajdonságok) és az [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-ben van megadva.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // a szerelem sok minden, de nem ábécé
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Visszaadja az `true` értéket, ha ennek az `char`-nek van `Lowercase` tulajdonsága.
    ///
    /// `Lowercase` az [Unicode Standard] 4. fejezetében (Karaktertulajdonságok) és az [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-ben van megadva.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // A különféle kínai szkriptek és írásjelek nem tartalmaznak nagybetűket, így:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Visszaadja az `true` értéket, ha ennek az `char`-nek van `Uppercase` tulajdonsága.
    ///
    /// `Uppercase` az [Unicode Standard] 4. fejezetében (Karaktertulajdonságok) és az [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-ben van megadva.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // A különféle kínai szkriptek és írásjelek nem tartalmaznak nagybetűket, így:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Visszaadja az `true` értéket, ha ennek az `char`-nek van `White_Space` tulajdonsága.
    ///
    /// `White_Space` az [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // nem törő tér
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Visszaadja az `true` értéket, ha ez az `char` megfelel [`is_alphabetic()`] vagy [`is_numeric()`] értékeknek.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Az `true` értéket adja vissza, ha ez az `char` rendelkezik a vezérlőkódok általános kategóriájával.
    ///
    /// Az ellenőrző kódokat (az `Cc` általános kategóriájú kódpontokat) az [Unicode Standard] 4. fejezete (Karaktertulajdonságok) írja le, az [Unicode Character Database][ucd] [`UnicodeData.txt`] pedig megadja.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// // U + 009C, húrvégződtetõ
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Visszaadja az `true` értéket, ha ennek az `char`-nek van `Grapheme_Extend` tulajdonsága.
    ///
    /// `Grapheme_Extend` az [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29]-ben van leírva, és az [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-ben van megadva.
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Visszaadja az `true` értéket, ha ez az `char` rendelkezik a számok általános kategóriáinak egyikével.
    ///
    /// A számok általános kategóriáit (`Nd` a tizedesjegyeknél, `Nl` a betűszerű számjegyből, és `No` a többi számjegyből) az [Unicode Character Database][ucd] [`UnicodeData.txt`] tartalmazza.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Olyan iterátort ad vissza, amely ennek az `char` kisbetűs leképezését egy vagy többként adja meg
    /// `char`s.
    ///
    /// Ha ennek az `char`-nek nincs kisbetűs leképezése, akkor az iterátor ugyanazt az `char`-et adja.
    ///
    /// Ha ennek az `char`-nek van egy az egyhez kisbetűs leképezése, amelyet az [Unicode Character Database][ucd] [`UnicodeData.txt`] ad meg, akkor az iterátor megadja ezt az `char`-et.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Ha ez az `char` speciális szempontokat igényel (pl. Több "char"), akkor az iterátor az [`SpecialCasing.txt`] által megadott "char" karaktereket adja.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Ez a művelet feltétel nélküli feltérképezést végez szabás nélkül.Vagyis az átalakítás független a kontextustól és a nyelvtől.
    ///
    /// Az [Unicode Standard]-ben a 4. fejezet (Karaktertulajdonságok) az esetek leképezését tárgyalja általában, a 3. fejezet pedig az (Conformance) az eseti átalakítás alapértelmezett algoritmusát.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Mint iterátor:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Az `println!` közvetlen használata:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Mindkettő egyenértékű:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Az `to_string` használata:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Néha az eredmény több karakterből áll:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Azok a karakterek, amelyeknek nincs nagy-és kisbetűjük, önmagukká válnak.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Olyan iterátort ad vissza, amely ennek az `char`-nek a nagybetűs leképezését eredményezi egy vagy több
    /// `char`s.
    ///
    /// Ha ennek az `char`-nek nincs nagybetűs leképezése, akkor az iterátor ugyanazt az `char`-et adja.
    ///
    /// Ha ennek az `char`-nek van egy az egyhez nagybetűs leképezése, amelyet az [Unicode Character Database][ucd] [`UnicodeData.txt`] ad meg, akkor az iterátor megadja ezt az `char`-et.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Ha ez az `char` speciális szempontokat igényel (pl. Több "char"), akkor az iterátor az [`SpecialCasing.txt`] által megadott "char" karaktereket adja.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Ez a művelet feltétel nélküli feltérképezést végez szabás nélkül.Vagyis az átalakítás független a kontextustól és a nyelvtől.
    ///
    /// Az [Unicode Standard]-ben a 4. fejezet (Karaktertulajdonságok) az esetek leképezését tárgyalja általában, a 3. fejezet pedig az (Conformance) az eseti átalakítás alapértelmezett algoritmusát.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Mint iterátor:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Az `println!` közvetlen használata:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Mindkettő egyenértékű:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Az `to_string` használata:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Néha az eredmény több karakterből áll:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Azok a karakterek, amelyeknek nincs nagy-és kisbetűjük, önmagukká válnak.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Megjegyzés a területi beállításhoz
    ///
    /// Törökül a latin 'i' megfelelője kettő helyett öt alakkal rendelkezik:
    ///
    /// * 'Dotless': I/ı, néha írva ï
    /// * 'Dotted': İ/i
    ///
    /// Vegye figyelembe, hogy az 'i' kisbetűs pontozás megegyezik a latin betűvel.Ebből kifolyólag:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Az `upper_i` értéke itt a szöveg nyelvén nyugszik: ha `en-US`-ben vagyunk, akkor `"I"`-nek kell lennie, de ha `tr_TR`-nek vagyunk, akkor `"İ"`-nek kell lennie.
    /// `to_uppercase()` ezt nem veszi figyelembe, így:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// nyelveken át tart.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Ellenőrzi, hogy az érték az ASCII tartományon belül van-e.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Az érték másolatát az ASCII nagybetűvel egyenértékűvé teszi.
    ///
    /// Az 'a'-'z' ASCII betűk 'A'-'Z'-hez vannak társítva, de a nem ASCII-betűk változatlanok.
    ///
    /// Az érték helyben történő nagybetűvé tételéhez használja az [`make_ascii_uppercase()`] billentyűt.
    ///
    /// Az ASCII karakterek nagybetűvé tételéhez a nem ASCII karakterek mellett használja az [`to_uppercase()`] billentyűt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Az érték másolatát az ASCII kisbetűvel egyenértékűvé teszi.
    ///
    /// Az 'A'-'Z' ASCII betűk 'a'-'z'-hez vannak társítva, de a nem ASCII-betűk változatlanok.
    ///
    /// Az érték helyben történő kisbetűsítéséhez használja az [`make_ascii_lowercase()`] billentyűt.
    ///
    /// Az ASCII karakterek kisbetűvé tételéhez a nem ASCII karakterek mellett használja az [`to_lowercase()`] billentyűt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Ellenőrzi, hogy két érték ASCII-es kis-és nagybetű érzékeny-e.
    ///
    /// Megegyezik az `to_ascii_lowercase(a) == to_ascii_lowercase(b)` értékkel.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Ezt a típust az ASCII nagybetűvel egyenértékűvé konvertálja.
    ///
    /// Az 'a'-'z' ASCII betűk 'A'-'Z'-hez vannak társítva, de a nem ASCII-betűk változatlanok.
    ///
    /// Ha új felsőbetűs értéket szeretne visszaadni a meglévő módosítása nélkül, használja az [`to_ascii_uppercase()`] parancsot.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Ezt a típust konvertálja az ASCII kisbetűvel egyenértékű helyére.
    ///
    /// Az 'A'-'Z' ASCII betűk 'a'-'z'-hez vannak társítva, de a nem ASCII-betűk változatlanok.
    ///
    /// Ha új, kisbetűs értéket szeretne visszaadni a meglévő módosítása nélkül, használja az [`to_ascii_lowercase()`] parancsot.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Ellenőrzi, hogy az érték ASCII alfabetikus karakter-e:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', vagy
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Ellenőrzi, hogy az érték ASCII nagybetűs-e:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Ellenőrzi, hogy az érték ASCII kisbetűs-e:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Ellenőrzi, hogy az érték ASCII alfanumerikus karakter-e:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', vagy
    /// - U + 0061 'a' ..=U + 007A 'z', vagy
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Ellenőrzi, hogy az érték ASCII tizedesjegy-e:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Ellenőrzi, hogy az érték ASCII hexadecimális számjegy-e:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', vagy
    /// - U + 0041 'A' ..=U + 0046 'F', vagy
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Ellenőrzi, hogy az érték ASCII írásjelek-e:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, vagy
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, vagy
    /// - U + 005B ..=U + 0060 "[\] ^ _" ``, vagy
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Ellenőrzi, hogy az érték ASCII grafikus karakter-e:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Ellenőrzi, hogy az érték ASCII szóköz-karakter:
    /// U + 0020 TÉR, U + 0009 VÍZSZINTES TAB, U + 000A VONALTÁP, U + 000C FORMATAKADÉK, vagy U + 000D SZÁLLÍTÁSI VISSZATÉRÉS.
    ///
    /// A Rust a WhatWG Infra Standard [definition of ASCII whitespace][infra-aw] készülékét használja.Számos más definíció létezik széles körben.
    /// Például az [the POSIX locale][pct] tartalmazza az U + 000B FÜGGŐLEGES TAB-ot, valamint az összes fenti karaktert, de-ugyanazon specifikációból kiindulva-[az "field splitting" alapértelmezett szabálya a Bourne shell-ben][bfs] csak a * SPACE, HORIZONTAL TAB, és VONALTAKARÉK fehér szóközként.
    ///
    ///
    /// Ha egy olyan programot ír, amely egy meglévő fájlformátumot fog feldolgozni, akkor ennek a funkciónak a használata előtt ellenőrizze, hogy mi a szóköz formátuma.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Ellenőrzi, hogy az érték ASCII vezérlő karakter-e:
    /// U + 0000 NUL ..=U + 001F EGYSÉGVÁLASZTÓ vagy U + 007F TÖRLÉS.
    /// Vegye figyelembe, hogy a legtöbb ASCII szóköz karakter vezérlő karakter, a SPACE azonban nem.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// A nyers u32 értéket UTF-8 formátumban kódolja a megadott bájtpufferbe, majd visszaadja a puffer alszeletét, amely tartalmazza a kódolt karaktert.
///
///
/// Az `char::encode_utf8`-től eltérően ez a módszer a helyettesítő tartományban lévő kódpontokat is kezeli.
/// (Az `char` létrehozása a helyettesítő tartományban UB.) Az eredmény érvényes [generalized UTF-8], de nem érvényes UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics, ha a puffer nem elég nagy.
/// A négyes hosszúságú puffer elég nagy ahhoz, hogy bármely `char` kódoljon.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// A nyers u32 értéket UTF-16 formátumban kódolja a megadott `u16` pufferbe, majd visszaadja a puffer alszeletét, amely tartalmazza a kódolt karaktert.
///
///
/// Az `char::encode_utf16`-től eltérően ez a módszer a helyettesítő tartományban lévő kódpontokat is kezeli.
/// (Az `char` létrehozása a helyettesítő tartományban UB.)
///
/// # Panics
///
/// Panics, ha a puffer nem elég nagy.
/// A 2 hosszúságú puffer elég nagy bármely `char` kódolásához.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // BIZTONSÁG: mindegyik kar ellenőrzi, hogy van-e elegendő bit ahhoz, hogy beírhassa
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // A BMP átesik
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // A kiegészítő síkok helyettesekké válnak.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}