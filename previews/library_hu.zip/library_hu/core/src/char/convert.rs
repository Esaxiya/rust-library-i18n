//! Karakterkonverziók.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// `u32`-et átalakít `char`-be.
///
/// Ne feledje, hogy az összes ["char"] érvényes ["u32"] s, és egybe lehet önteni vele
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Viszont fordítva nem igaz: nem minden érvényes [`u32`] érvényes [`char`].
/// `from_u32()` visszaadja az `None` értéket, ha a bemenet nem érvényes érték egy [`char`] esetében.
///
/// A funkció nem biztonságos verzióját, amely figyelmen kívül hagyja ezeket az ellenőrzéseket, lásd: [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Alapvető használat:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// `None` visszaadása, ha a bemenet nem érvényes [`char`]:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Az `u32`-et átalakítja `char`-be, figyelmen kívül hagyva az érvényességet.
///
/// Ne feledje, hogy az összes ["char"] érvényes ["u32"] s, és egybe lehet önteni vele
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Viszont fordítva nem igaz: nem minden érvényes [`u32`] érvényes [`char`].
/// `from_u32_unchecked()` ezt figyelmen kívül hagyja, és vakon átveti az [`char`]-re, esetleg érvénytelenet hozva létre.
///
///
/// # Safety
///
/// Ez a funkció nem biztonságos, mivel érvénytelen `char` értékeket állíthat össze.
///
/// A funkció biztonságos verzióját lásd az [`from_u32`] funkcióban.
///
/// # Examples
///
/// Alapvető használat:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // BIZTONSÁG: a hívónak garantálnia kell, hogy az `i` érvényes char érték.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// [`char`]-et átalakít [`u32`]-be.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// [`char`]-et átalakít [`u64`]-be.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // A karakter a kódpont értékére van öntve, majd nulla-kibővítve 64 bitesre.
        // Lásd: [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// [`char`]-et átalakít [`u128`]-be.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // A karakter a kódpont értékére van öntve, majd nulla kiterjesztéssel 128 bitre.
        // Lásd: [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// A 0x00 ..=0xFF bájtot leképezi egy `char`-re, amelynek kódpontja azonos értékkel rendelkezik, U + 0000 ..=U + 00FF formátumban.
///
/// Az Unicode-ot úgy tervezték, hogy ez hatékonyan dekódolja a bájtokat az IANA által ISO-8859-1-nek nevezett karakterkódolással.
/// Ez a kódolás kompatibilis az ASCII-vel.
///
/// Vegye figyelembe, hogy ez eltér az ISO/IEC 8859-1 aka
/// ISO 8859-1 (egy kötőjellel kevesebb), amely néhány "blanks" bájt értéket hagy, amelyek nincsenek hozzárendelve egyetlen karakterhez sem.
/// Az ISO-8859-1 (az IANA) hozzárendeli őket az C0 és C1 vezérlőkódokhoz.
///
/// Vegye figyelembe, hogy ez *szintén* különbözik a Windows-1252 aka-tól
/// kódlap 1252, amely az ISO/IEC 8859-1 szuperhalmaz, amely néhány (nem minden!) üres részt rendel az írásjelekhez és a különféle latin karakterekhez.
///
/// A dolgok további összetévesztése érdekében az [on the Web](https://encoding.spec.whatwg.org/), `ascii`, `iso-8859-1` és `windows-1252`, mind a Windows-1252 egy olyan halmazának álneve, amely kitölti a fennmaradó üres területeket a megfelelő C0 és C1 vezérlőkódokkal.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// [`u8`]-et átalakít [`char`]-be.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Hiba, amelyet vissza lehet adni egy karakter elemzésekor.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // BIZTONSÁG: ellenőrizte, hogy ez egy hivatalos unicode érték
            Ok(unsafe { transmute(i) })
        }
    }
}

/// A hibatípus akkor érkezett vissza, amikor az u32-ből a char-ba történő átalakítás sikertelen volt.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Az adott radix számjegyét `char`-vé alakítja.
///
/// Az 'radix'-et itt néha 'base'-nek is hívják.
/// A kettőből álló radix bináris számot, tíz, tizedes és tizenhat hexadecimális radixot jelent, hogy néhány közös értéket megadjon.
///
/// Önkényes radikumok támogatottak.
///
/// `from_digit()` visszaadja az `None` értéket, ha a bemenet nem egy számjegy az adott radixban.
///
/// # Panics
///
/// Panics, ha 36-nál nagyobb radixot kap.
///
/// # Examples
///
/// Alapvető használat:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // A 11. tizedes egy számjegy a 16. alapban
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// `None` visszatérése, ha a bemenet nem számjegy:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Nagy radix átengedése, ami panic-t okoz:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}