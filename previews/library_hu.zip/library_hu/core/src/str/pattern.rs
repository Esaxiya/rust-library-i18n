//! A string Pattern API.
//!
//! A Pattern API általános mechanizmust biztosít a különféle mintatípusok használatához, amikor sztringen keresztül keres.
//!
//! További részletek: traits [`Pattern`], [`Searcher`], [`ReverseSearcher`] és [`DoubleEndedSearcher`].
//!
//! Bár ez az API instabil, az [`str`] típusú stabil API-k révén érhető el.
//!
//! # Examples
//!
//! [`Pattern`] [implemented][pattern-impls] a stabil API-ban az [`&str`][`str`], [`char`], az [`char`] szeleteihez, valamint az `FnMut(char) -> bool` megvalósító funkciókhoz és bezárásokhoz.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // char minta
//! assert_eq!(s.find('n'), Some(2));
//! // szelet karakterek minta
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // zárási minta
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Egy húrminta.
///
/// Az `Pattern<'a>` kifejezi, hogy az implementációs típus karakterlánc mintaként használható az [`&'a str`][str]-ben való kereséshez.
///
/// Például az `'a'` és az `"aa"` egyaránt olyan minták, amelyek illeszkednek az `"baaaab"` karakterlánc `1` indexéhez.
///
/// Maga a trait építőként működik egy társított [`Searcher`] típushoz, amely elvégzi a minta előfordulásának tényleges keresését egy karakterláncban.
///
///
/// A minta típusától függően az olyan módszerek viselkedése megváltozhat, mint az [`str::find`] és az [`str::contains`].
/// Az alábbi táblázat néhány ilyen viselkedést ismertet.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Társított kereső ehhez a mintához
    type Searcher: Searcher<'a>;

    /// Felépíti a társított keresőt az `self` és az `haystack` közül a keresésre.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Ellenőrzi, hogy a minta megegyezik-e valahol a szénakazalban
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Ellenőrzi, hogy a minta megegyezik-e a szénakazal elején
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Ellenőrzi, hogy a minta megegyezik-e a szénakazal hátulján
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Eltávolítja a mintát a szénakazal elejéről, ha egyezik.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // BIZTONSÁG: Ismert, hogy az `Searcher` érvényes indexeket ad vissza.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Eltávolítja a mintát a szénakazal hátsó részéről, ha egyezik.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // BIZTONSÁG: Ismert, hogy az `Searcher` érvényes indexeket ad vissza.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Az [`Searcher::next()`] vagy az [`ReverseSearcher::next_back()`] hívásának eredménye.
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Kifejezi, hogy a minta egyezését találták az `haystack[a..b]`-nél.
    ///
    Match(usize, usize),
    /// Kifejezi, hogy az `haystack[a..b]` mint a minta lehetséges illesztése elutasításra került.
    ///
    /// Vegye figyelembe, hogy két "Match" meccs között több `Reject` is lehet, nincs szükség arra, hogy ezeket egybe egyesítsék.
    ///
    ///
    Reject(usize, usize),
    /// Kifejezi, hogy a szénakazal minden bájtja felkereste az iterációt.
    ///
    Done,
}

/// Karakterlánc-minta keresője.
///
/// Ez a trait módszereket kínál a minta nem átfedő egyezésének keresésére a karakterlánc elülső (left)-től kezdődően.
///
/// Az [`Pattern`] trait kapcsolódó `Searcher` típusai valósítják meg.
///
/// A trait nem biztonságos, mivel az [`next()`][Searcher::next] módszerekkel visszaküldött indexeknek a szénakazalban érvényes utf8 határokon kell lenniük.
/// Ez lehetővé teszi ennek a trait fogyasztónak, hogy további futásidejű ellenőrzések nélkül szeletelje a szénakazalat.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter az alapul szolgáló karaktersorozathoz
    ///
    /// Mindig ugyanazt az [`&str`][str]-et adja vissza.
    fn haystack(&self) -> &'a str;

    /// Elölről kezdi a következő keresési lépést.
    ///
    /// - Visszaadja az [`Match(a, b)`][SearchStep::Match] értéket, ha az `haystack[a..b]` egyezik a mintával.
    /// - Visszaadja az [`Reject(a, b)`][SearchStep::Reject] értéket, ha az `haystack[a..b]` még részben sem felel meg a mintának.
    /// - Visszaadja az [`Done`][SearchStep::Done] értéket, ha a szénakazal minden bájtját meglátogatták.
    ///
    /// Az [`Match`][SearchStep::Match] és [`Reject`][SearchStep::Reject] értékek egy [`Done`][SearchStep::Done] értékig terjedő adatfolyamának tartományai szomszédos, nem átfedő, az egész szénakazalra kiterjedő és az utf8 határokra fektetett indextartományokat tartalmazzák.
    ///
    ///
    /// Az [`Match`][SearchStep::Match] eredménynek tartalmaznia kell a teljes egyeztetett mintát, azonban az [`Reject`][SearchStep::Reject] eredményeket tetszőlegesen sok szomszédos fragmentumra lehet felosztani.Mindkét tartomány nulla lehet.
    ///
    /// Például az `"aaa"` mintázat és az `"cbaaaaab"` szénakazal hozhatja létre a folyamot
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Megkeresi a következő [`Match`][SearchStep::Match] eredményt.Lásd: [`next()`][Searcher::next].
    ///
    /// Az [`next()`][Searcher::next]-től eltérően nincs garancia arra, hogy ennek és az [`next_reject`][Searcher::next_reject] visszatérő tartományai átfedik egymást.
    /// Ez visszaadja az `(start_match, end_match)` értéket, ahol a start_match az index, ahol a mérkőzés elkezdődik, és end_match az index a meccs vége után.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Megkeresi a következő [`Reject`][SearchStep::Reject] eredményt.Lásd: [`next()`][Searcher::next] és [`next_match()`][Searcher::next_match].
    ///
    /// Az [`next()`][Searcher::next]-től eltérően nincs garancia arra, hogy ennek és az [`next_match`][Searcher::next_match] visszatérő tartományai átfedik egymást.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Fordított kereső egy húrmintához.
///
/// Ez a trait módszereket kínál a minta nem átfedő egyezésének keresésére a karakterlánc hátsó (right)-től kezdődően.
///
/// Az [`Pattern`] trait kapcsolódó [`Searcher`] típusai valósítják meg, ha a minta támogatja a hátulról történő keresést.
///
///
/// Az ezen trait által visszaadott indextartományoknak nem kell pontosan megegyezniük a fordított irányú keresés eredményeivel.
///
/// Annak okáért, hogy miért jelöli ezt a trait nem biztonságos, nézze meg őket a trait [`Searcher`] szülő.
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Végzi a következő keresési lépést hátulról kezdve.
    ///
    /// - Visszaadja az [`Match(a, b)`][SearchStep::Match] értéket, ha az `haystack[a..b]` egyezik a mintával.
    /// - Visszaadja az [`Reject(a, b)`][SearchStep::Reject] értéket, ha az `haystack[a..b]` még részben sem felel meg a mintának.
    /// - Visszaadja az [`Done`][SearchStep::Done] értéket, ha a szénakazal minden bájtját meglátogatták
    ///
    /// Az [`Match`][SearchStep::Match] és [`Reject`][SearchStep::Reject] értékek egy [`Done`][SearchStep::Done] értékig terjedő adatfolyamának tartományai szomszédos, nem átfedő, az egész szénakazalra kiterjedő és az utf8 határokra fektetett indextartományokat tartalmazzák.
    ///
    ///
    /// Az [`Match`][SearchStep::Match] eredménynek tartalmaznia kell a teljes egyeztetett mintát, azonban az [`Reject`][SearchStep::Reject] eredményeket tetszőlegesen sok szomszédos fragmentumra lehet felosztani.Mindkét tartomány nulla lehet.
    ///
    /// Például az `"aaa"` mintázat és az `"cbaaaaab"` szénakazal eredményezheti az `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Megkeresi a következő [`Match`][SearchStep::Match] eredményt.
    /// Lásd: [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Megkeresi a következő [`Reject`][SearchStep::Reject] eredményt.
    /// Lásd: [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// trait jelölő annak kifejezésére, hogy egy [`ReverseSearcher`] használható az [`DoubleEndedIterator`] megvalósításához.
///
/// Ehhez az [`Searcher`] és az [`ReverseSearcher`] implikációjának meg kell felelnie a következő feltételeknek:
///
/// - Az `next()` összes eredményének meg kell egyeznie az `next_back()` eredményeivel fordított sorrendben.
/// - `next()` és az `next_back()`-nek úgy kell viselkednie, mint egy értéktartomány két vége, vagyis nem képesek az "walk past each other"-re.
///
/// # Examples
///
/// `char::Searcher` egy `DoubleEndedSearcher`, mert az [`char`] kereséséhez csak egyszerre kell ránézni, amely mindkét oldalról ugyanúgy viselkedik.
///
/// `(&str)::Searcher` nem `DoubleEndedSearcher`, mert az `"aaa"` szénakazalban az `"aa"` minta egyezik akár `"[aa]a"`, akár `"a[aa]"` névvel, attól függően, hogy melyik oldalról keresik.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl for char
/////////////////////////////////////////////////////////////////////////////

/// Az `<char as Pattern<'a>>::Searcher` társított típusa.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // biztonsági invariáns: Az `finger`/`finger_back`-nek az `haystack` érvényes utf8 bájtindexének kell lennie. Ez az invariáns megszakítható *a* next_match és a következő_match_back * belül, azonban ujjal kell kilépnie az érvényes kódpont határain.
    //
    //
    /// `finger` a továbbított keresés aktuális bájtindexe.
    /// Képzelje el, hogy a bájt előtt létezik az indexében, azaz
    /// `haystack[finger]` a szelet első bájtja, amelyet meg kell vizsgálnunk az előre történő keresés során
    ///
    finger: usize,
    /// `finger_back` a fordított keresés aktuális bájtindexe.
    /// Képzelje el, hogy a bájt után létezik az indexében, azaz
    /// szénakazal [finger_back, 1] a szelet utolsó bájtja, amelyet meg kell vizsgálnunk az előre keresés során (és ezáltal az első bájt, amelyet ellenőrizni kell az next_back()) hívásakor.
    ///
    finger_back: usize,
    /// A keresett karakter
    needle: char,

    // biztonsági invariáns: az `utf8_size`-nek kevesebbnek kell lennie, mint 5
    /// Az `needle` bájtok száma felveszi az utf8 kódolását.
    utf8_size: usize,
    /// Az `needle` utf8 kódolású másolata
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // BIZTONSÁG: 1-4 garantálja az `get_unchecked` biztonságát
        // 1. `self.finger` és az `self.finger_back` az unicode határokon van tartva (ez invariáns)
        // 2. `self.finger >= 0` mivel 0-nál kezdődik és csak növekszik
        // 3. `self.finger < self.finger_back` mert különben az `iter` karakter visszaadná az `SearchStep::Done` értéket
        // 4.
        // `self.finger` a szénakazal vége előtt jön, mert az `self.finger_back` a végén indul, és csak csökken
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // add hozzá az aktuális karakter bájt eltolását anélkül, hogy újra kódolnád utf-8 néven
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // szerezd meg a szénakazalat az utolsó megtalált karakter után
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // az utf8 kódolt tű utolsó bájtja BIZTONSÁG: van egy invariánsunk, amely az `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Az új ujj a megtalált bájt indexe, plusz egy, mivel a karakter utolsó bájtjára emlékeztettük.
                //
                // Ne feledje, hogy ez nem mindig ad ujjat az UTF8 határán.
                // Ha *nem* találtuk meg a karakterünket, előfordulhat, hogy egy 3 vagy 4 bájtos karakter nem utolsó bájtjához indexeltük.
                // Nem ugrhatunk csak a következő érvényes kezdő bájtra, mert egy olyan karakter, mint a ꁁ (U + A041 YI SYLLABLE PA), az utf-8 `EA 81 81` mindig meg fogja találni a második bájtot, amikor a harmadikra keresünk.
                //
                //
                // Ez azonban teljesen rendben van.
                // Noha megvan az az invariánsunk, hogy az self.finger az UTF8 határán van, erre az invariánsra nem hivatkozunk ebben a módszerben (az CharSearcher::next()) az.
                //
                // Csak akkor lépünk ki ebből a módszerből, amikor elérjük a karakterlánc végét, vagy ha találunk valamit.Ha találunk valamit, akkor az `finger` egy UTF8 határra lesz beállítva.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // nem talált semmit, kijárat
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // hagyja, hogy a next_reject használja a Searcher trait alapértelmezett megvalósítását
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // BIZTONSÁG: lásd az next() fenti megjegyzését
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // vonja le az aktuális karakter bájt eltolását anélkül, hogy újrakódolna utf-8 néven
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // fel a szénakazalra, de nem tartalmazza az utoljára keresett karaktert
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // az utf8 kódolt tű utolsó bájtja BIZTONSÁG: van egy invariánsunk, amely az `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // kerestünk egy szeletet, amelyet az self.finger ellensúlyozott, adjuk hozzá az self.finger-et az eredeti index megtérüléséhez
                //
                let index = self.finger + index;
                // A memrchr visszaadja a megtalálni kívánt bájt indexét.
                // ASCII karakter esetén ez valóban az, ha azt kívánjuk, hogy új ujjunk legyen ("after" a talált karakter a fordított iteráció paradigmájában).
                //
                // A többbájtos karaktereknél le kell ugranunk az ASCII-nél több bájtjukkal
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // mozgassa az ujját a megtalált karakter elé (vagyis a kezdő indexéhez)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Itt nem használhatjuk a finger_back=index, size + 1 értéket.
                // Ha megtaláltuk a különböző méretű karakterek utolsó karakterét (vagy egy másik karakter középső bájtját), akkor az ujjat_hátrányt le kell állítanunk `index`-re.
                // Ez hasonlóan lehetővé teszi az `finger_back` számára, hogy többé ne legyen határon, de ez rendben van, mivel csak egy határon lépünk ki ebből a funkcióból, vagy amikor a szénakazalot teljesen átkutattuk.
                //
                //
                // A next_match-szel ellentétben ennek nincs problémája az utf-8 ismételt bájtjaival, mert az utolsó bájtot keressük, és csak fordított keresésnél találtuk meg az utolsó bájtot.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // nem talált semmit, kijárat
                return None;
            }
        }
    }

    // hagyja, hogy a next_reject_back a Searcher trait alapértelmezett megvalósítását használja
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Olyan karaktereket keres, amelyek megegyeznek egy adott [`char`] értékkel.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Impl egy MultiCharEq burkolóhoz
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Hasonlítsa össze a belső byte szelet iterátor hosszát, hogy megtalálja az aktuális karakter hosszát
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Hasonlítsa össze a belső byte szelet iterátor hosszát, hogy megtalálja az aktuális karakter hosszát
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl&[char] számára
/////////////////////////////////////////////////////////////////////////////

// Todo: Változás/eltávolítás a jelentés kétértelműsége miatt.

/// Az `<&[char] as Pattern<'a>>::Searcher` társított típusa.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Olyan karaktereket keres, amelyek megegyeznek a szelet bármelyikének ["char"-jával.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl F: FnMut(char)-> bool esetén
/////////////////////////////////////////////////////////////////////////////

/// Az `<F as Pattern<'a>>::Searcher` társított típusa.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Az adott állítmánynak megfelelő [char]-ok keresése.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl for&&str
/////////////////////////////////////////////////////////////////////////////

/// Delegáltak az `&str` impl.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl for &str
/////////////////////////////////////////////////////////////////////////////

/// Nem allokáló részstruktúra keresés.
///
/// Az `""` mintát üres karakterekként adja vissza az egyes karakterhatároknál.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Ellenőrzi, hogy a minta megegyezik-e a szénakazal elején.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Eltávolítja a mintát a szénakazal elejéről, ha egyezik.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // BIZTONSÁG: az előtag létezését éppen ellenőrizte.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Ellenőrzi, hogy a minta megegyezik-e a szénakazal hátulján.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Eltávolítja a mintát a szénakazal hátsó részéről, ha egyezik.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // BIZTONSÁG: Az utótag éppen létezik.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Kétirányú szubsztring kereső
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Az `<&str as Pattern<'a>>::Searcher` társított típusa.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // az üres tű minden karaktert elutasít, és minden üres húrot egymáshoz illeszt
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // A TwoWaySearcher érvényes *egyeztetési* indexeket állít elő, amelyek a char határán osztódnak, amíg helyes illesztést végez, és hogy a szénakazal és a tű érvényes UTF-8 *Az algoritmus* elutasítja * bármely indexre eshet, de manuálisan a következő karakterhatárig vezetjük őket, így utf-8 biztonságban vannak.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // ugorjon a következő char határra
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // írjon ki `true` és `false` eseteket, hogy ösztönözze a fordítót arra, hogy külön szakosítsa a két esetet.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // ugorjon a következő char határra
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // írja ki az `true`-et és az `false`-et, mint az `next_match`-et
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// A kétirányú szubsztring keresési algoritmus belső állapota.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// kritikus tényező index
    crit_pos: usize,
    /// a fordított tű kritikus faktoros indexe
    crit_pos_back: usize,
    period: usize,
    /// `byteset` kiterjesztés (nem része a kétirányú algoritmusnak);
    /// ez egy 64 bites "fingerprint", ahol minden beállított `j` bit megfelel a tűben lévő (bájt és 63)==j értéknek.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// mutató tűvé, amely előtt már egyeztettünk
    memory: usize,
    /// index tűvé, ami után már egyeztünk
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Különösen olvasható magyarázat az itt zajló dolgokra megtalálható Crochemore és Rytter "Text Algorithms" című könyvében, 13. fejezet.
        // Konkrétan lásd az "Algorithm CP" kódját a (z) oldalon.
        // 323.
        //
        // Ami zajlik, van néhány kritikus faktorizálás (u, v) a tűn, és meg akarjuk állapítani, hogy u-e a&v [.. periódus] utótagja.
        // Ha igen, akkor az "Algorithm CP1"-et használjuk.
        // Ellenkező esetben az "Algorithm CP2"-et használjuk, amelyet arra optimalizáltunk, amikor a tű periódusa nagy.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // rövid periódusos eset-a periódus pontos, külön kritikus tényezőt számoljon a fordított tűre x=u 'v' ahol | v '|<period(x).
            //
            // Ezt felgyorsítja a már ismert időszak.
            // Ne feledje, hogy az x= "acba"-hez hasonló eseteket pontosan előre lehet számolni (crit_pos=1, period=3), míg a hozzávetőleges periódussal fordítva (crit_pos=2, period=2).
            // A megadott fordított tényezőt alkalmazzuk, de megtartjuk a pontos időszakot.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // hosszú periódusos eset-közelítünk a tényleges időszakhoz, és ne használjuk a memorizálást.
            //
            //
            // Közelítse az időszakot az max(|u|, |v|) + 1 alsó határértékkel.
            // A kritikus tényező hatékony mind előre, mind hátra történő keresésre.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Dummy érték annak jelzésére, hogy az időszak hosszú
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // A Kétirányú egyik fő gondolata az, hogy a tűt két félre (u, v) osztjuk, és balról jobbra pásztázva próbáljuk meg megkeresni v-t a szénakazalban.
    // Ha v egyezik, akkor jobbról balra pásztázással próbálunk u-t egyeztetni.
    // Az, hogy meddig tudunk ugrani, ha nem egyezik meg, mind azon a tényen alapul, hogy (u, v) kritikus tényező a tű számára.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` az `self.position`-et használja kurzorként
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Ellenőrizze, hogy van-e helyünk keresésre a + pozícióban, és a tű_utolsó nem tud túlcsordulni, ha feltételezzük, hogy a szeleteket az isize tartománya határolja.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Gyorsan átugorhat nagy részeket, amelyek nem kapcsolódnak az alsorunkhoz
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Nézze meg, hogy a tű jobb része egyezik-e
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Nézze meg, hogy a tű bal oldala egyezik-e
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Találtunk egyezést!
            let match_pos = self.position;

            // Note: add át az self.period-et az needle.len() helyett, hogy átfedések legyenek
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // needle.len(), self.period értékre állítva az átfedő mérkőzésekhez
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Követi az ötleteket az `next()`-ben.
    //
    // A definíciók szimmetrikusak: period(x) = period(reverse(x)) és local_period(u, v) = local_period(reverse(v), reverse(u)), tehát ha (u, v) kritikus tényező, akkor az (reverse(v) is, reverse(u)).
    //
    //
    // A fordított esetben kiszámítottuk az x=u 'v' (`crit_pos_back` mező) kritikus faktorizációt.Szükségünk van | u |-ra<period(x) az előretekintő esethez, így | v '|<period(x) fordítva.
    //
    // A szénakazalban hátramenetben történő kereséshez egy fordított tűvel ellátott, fordított szénakazalban keresünk előre, előbb u ', majd v' egyezéssel.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` az `self.end`-et használja kurzorként-így az `next()` és az `next_back()` független.
        //
        let old_end = self.end;
        'search: loop {
            // Ellenőrizze, hogy van-e helyünk a keresésre a végén, az needle.len() be fog takarni, ha nincs több hely, de a szeletek hosszkorlátozásai miatt soha nem tud visszaforgatni a szénakazal hosszába.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Gyorsan átugorhat nagy részeket, amelyek nem kapcsolódnak az alsorunkhoz
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Nézze meg, hogy a tű bal oldala egyezik-e
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Nézze meg, hogy a tű jobb része egyezik-e
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Találtunk egyezést!
            let match_pos = self.end - needle.len();
            // Note: self.period alcsoport az needle.len() helyett, hogy átfedések legyenek
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Számítsa ki az `arr` maximális utótagját.
    //
    // A maximális utótag az `arr` lehetséges kritikus faktorizálása (u, v).
    //
    // Visszaadja (`i ', `p`) ahol `i` a v kezdőindexe és `p` a v periódusa.
    //
    // `order_greater` meghatározza, hogy a lexikai sorrend `<` vagy `>`.
    // Mindkét megrendelést ki kell számolni-a legnagyobb `i`-tel történő rendelés kritikus tényezőt ad.
    //
    //
    // Hosszú időtartamú esetekben az eredményül kapott időszak nem pontos (túl rövid).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Megfelel a cikk i-jének
        let mut right = 1; // Megfelel a papír j-jének
        let mut offset = 0; // A cikkben szereplő k-nak felel meg, de 0-tól kezdődik
        // hogy megfeleljen a 0 alapú indexelésnek.
        let mut period = 1; // Megfelel a papír p-jének

        while let Some(&a) = arr.get(right + offset) {
            // `left` bejövő lesz, amikor az `right` van.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Az utótag kisebb, a pont a teljes előtag.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Előre a jelenlegi időszak megismétlésével.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Az utótag nagyobb, kezdje újra az aktuális helyről.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Számítsa ki az `arr` hátoldalának maximális utótagját.
    //
    // A maximális utótag az `arr` lehetséges kritikus faktorizálása (u ', v').
    //
    // Visszaadja az `i` értéket, ahol `i` a v 'kezdő indexe, hátulról;
    // Az `known_period` periódus elérésekor azonnal visszatér.
    //
    // `order_greater` meghatározza, hogy a lexikai sorrend `<` vagy `>`.
    // Mindkét megrendelést ki kell számolni-a legnagyobb `i`-tel történő rendelés kritikus tényezőt ad.
    //
    //
    // Hosszú időtartamú esetekben az eredményül kapott időszak nem pontos (túl rövid).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Megfelel a cikk i-jének
        let mut right = 1; // Megfelel a papír j-jének
        let mut offset = 0; // A cikkben szereplő k-nak felel meg, de 0-tól kezdődik
        // hogy megfeleljen a 0 alapú indexelésnek.
        let mut period = 1; // Megfelel a papír p-jének
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Az utótag kisebb, a pont a teljes előtag.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Előre a jelenlegi időszak megismétlésével.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Az utótag nagyobb, kezdje újra az aktuális helyről.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// A TwoWayStrategy lehetővé teszi az algoritmus számára, hogy a nem egyezéseket a lehető leggyorsabban kihagyja, vagy olyan módban működjön, ahol viszonylag gyorsan kiadja az Elutasításokat.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// A lehető leggyorsabban ugorjon az intervallumok egyezésére
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Emit rendszeresen elutasítja
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}