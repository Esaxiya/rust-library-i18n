//! Trait implementációk az `str`-hez.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Végrehajtja a húrok sorrendjét.
///
/// A karakterláncokat az [lexicographically](Ord#lexicographical-comparison) bájtértékeik szerint rendezi.
/// Ez Unicode kódpontokat rendel a kóddiagramokban elfoglalt pozícióik alapján.
/// Ez nem feltétlenül azonos az "alphabetical" sorrenddel, amely nyelvenként és nyelvenként változik.
/// A karakterláncok kulturálisan elfogadott szabványok szerinti rendezéséhez olyan lokálspecifikus adatokra van szükség, amelyek kívül esnek az `str` típuson.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Hasonlító műveleteket hajt végre a húrokon.
///
/// A húrokat az [lexicographically](Ord#lexicographical-comparison) bájtértékeik alapján hasonlítják össze.
/// Ez összehasonlítja az Unicode kódpontokat a kóddiagramokban elfoglalt pozícióik alapján.
/// Ez nem feltétlenül azonos az "alphabetical" sorrenddel, amely nyelvenként és nyelvenként változik.
/// A karakterláncok kulturálisan elfogadott szabványok szerinti összehasonlításához olyan lokálspecifikus adatokra van szükség, amelyek kívül esnek az `str` típuson.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Az `&self[..]` vagy `&mut self[..]` szintaxissal valósítja meg az alsávszeletelést.
///
/// Visszaad egy szeletet az egész karaktersorozatból, azaz `&self` vagy `&mut self`.Megegyezik a `&self [0 ..
/// len] `vagy`&mut self [0 ..
/// len]`.
/// Más indexelési műveletekkel ellentétben ez soha nem lehet panic.
///
/// Ez a művelet *O*(1).
///
/// Az 1.20.0 előtt ezeket az indexelési műveleteket az `Index` és az `IndexMut` közvetlen megvalósítása még támogatta.
///
/// `&self[0 .. len]` vagy `&mut self[0 .. len]` egyenértékű.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Az `&self[begin .. end]` vagy `&mut self[begin .. end]` szintaxissal valósítja meg az alsávszeletelést.
///
/// Az adott karakterlánc egy szeletét adja vissza a bájttartományból [`start`, `end`).
///
/// Ez a művelet *O*(1).
///
/// Az 1.20.0 előtt ezeket az indexelési műveleteket az `Index` és az `IndexMut` közvetlen megvalósítása még támogatta.
///
/// # Panics
///
/// Panics, ha az `begin` vagy `end` nem egy karakter kezdő bájt eltolására mutat (az `is_char_boundary` meghatározása szerint), ha az `begin > end` vagy az `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // ezek a panic:
/// // A 2. bájt az `ö`-en belül található:
/// // &s [2 .3];
///
/// // A 8. bájt az `老`&s-ben található [1 ..
/// // 8];
///
/// // 100 bájt kívül esik az&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // BIZTONSÁG: Csak ellenőrizze, hogy az `start` és az `end` szikrahatáron van-e,
            // és biztonságos referenciát adunk át, így a visszatérési érték is egy lesz.
            // Ellenőriztük a char határait is, tehát ez érvényes UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // BIZTONSÁG: Csak ellenőrizze, hogy az `start` és az `end` szikrahatáron van-e.
            // Tudjuk, hogy a mutató egyedülálló, mert az `slice`-től kaptuk.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // BIZTONSÁG: a hívó garantálja, hogy az `self` az `slice` határán van
        // amely megfelel az `add` összes feltételének.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // BIZTONSÁG: lásd az `get_unchecked` megjegyzéseit.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary ellenőrzi, hogy az index a [0, .len()] nem tudja-e újból felhasználni az `get`-et, mint fent, NLL-problémák miatt
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // BIZTONSÁG: Csak ellenőrizze, hogy az `start` és az `end` szikrahatáron van-e,
            // és biztonságos referenciát adunk át, így a visszatérési érték is egy lesz.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Az `&self[.. end]` vagy `&mut self[.. end]` szintaxissal valósítja meg az alsávszeletelést.
///
/// Az adott karakterlánc szeletét adja vissza a bájttartományból ["0", `end`).
/// `&self[0 .. end]` vagy `&mut self[0 .. end]` egyenértékű.
///
/// Ez a művelet *O*(1).
///
/// Az 1.20.0 előtt ezeket az indexelési műveleteket az `Index` és az `IndexMut` közvetlen megvalósítása még támogatta.
///
/// # Panics
///
/// Panics, ha az `end` nem egy karakter kezdő bájt eltolására mutat (az `is_char_boundary` meghatározása szerint), vagy ha az `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // BIZTONSÁG: csak ellenőrizte, hogy az `end` szikrahatáron van-e,
            // és biztonságos referenciát adunk át, így a visszatérési érték is egy lesz.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // BIZTONSÁG: csak ellenőrizte, hogy az `end` szikrahatáron van-e,
            // és biztonságos referenciát adunk át, így a visszatérési érték is egy lesz.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // BIZTONSÁG: csak ellenőrizte, hogy az `end` szikrahatáron van-e,
            // és biztonságos referenciát adunk át, így a visszatérési érték is egy lesz.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Az `&self[begin ..]` vagy `&mut self[begin ..]` szintaxissal valósítja meg az alsávszeletelést.
///
/// Az adott karakterlánc egy szeletét adja vissza a bájttartományból [`start`, `len`).Egyenértékű a `&self [kezdődik ..
/// len] `vagy`&mut self [kezdődik ..
/// len]`.
///
/// Ez a művelet *O*(1).
///
/// Az 1.20.0 előtt ezeket az indexelési műveleteket az `Index` és az `IndexMut` közvetlen megvalósítása még támogatta.
///
/// # Panics
///
/// Panics, ha az `begin` nem egy karakter kezdő bájt eltolására mutat (az `is_char_boundary` meghatározása szerint), vagy ha az `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // BIZTONSÁG: csak ellenőrizte, hogy az `start` szikrahatáron van-e,
            // és biztonságos referenciát adunk át, így a visszatérési érték is egy lesz.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // BIZTONSÁG: csak ellenőrizte, hogy az `start` szikrahatáron van-e,
            // és biztonságos referenciát adunk át, így a visszatérési érték is egy lesz.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // BIZTONSÁG: a hívó garantálja, hogy az `self` az `slice` határán van
        // amely megfelel az `add` összes feltételének.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // BIZTONSÁG: azonos az `get_unchecked`-szel.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // BIZTONSÁG: csak ellenőrizte, hogy az `start` szikrahatáron van-e,
            // és biztonságos referenciát adunk át, így a visszatérési érték is egy lesz.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Az `&self[begin ..= end]` vagy `&mut self[begin ..= end]` szintaxissal valósítja meg az alsávszeletelést.
///
/// Az adott karakterlánc szeletét adja vissza az [`begin`, `end`] bájttartományból.Megegyezik az `&self [begin .. end + 1]` vagy `&mut self[begin .. end + 1]` értékkel, kivéve, ha az `end` rendelkezik az `usize` maximális értékével.
///
/// Ez a művelet *O*(1).
///
/// # Panics
///
/// Panics, ha az `begin` nem egy karakter kezdő bájt eltolására mutat (az `is_char_boundary` meghatározása szerint), ha az `end` nem a karakter vége bájt eltolására mutat (`end + 1` vagy kezdő bájt eltolás, vagy egyenlő `len`), ha `begin > end`, vagy ha `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // BIZTONSÁG: a hívónak be kell tartania az `get_unchecked` biztonsági szerződését.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // BIZTONSÁG: a hívónak be kell tartania az `get_unchecked_mut` biztonsági szerződését.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Az `&self[..= end]` vagy `&mut self[..= end]` szintaxissal valósítja meg az alsávszeletelést.
///
/// Az adott karakterlánc egy szeletét adja vissza az [0, `end`] bájttartományból.
/// Megegyezik az `&self [0 .. end + 1]` értékkel, kivéve, ha az `end` rendelkezik az `usize` maximális értékével.
///
/// Ez a művelet *O*(1).
///
/// # Panics
///
/// Panics, ha az `end` nem egy karakter befejező bájt eltolására mutat (`end + 1` vagy kezdő bájt eltolás, amelyet az `is_char_boundary` definiál, vagy egyenlő `len`), vagy ha `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // BIZTONSÁG: a hívónak be kell tartania az `get_unchecked` biztonsági szerződését.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // BIZTONSÁG: a hívónak be kell tartania az `get_unchecked_mut` biztonsági szerződését.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Érték elemzése egy karakterláncból
///
/// A `FromStr` [`from_str`] módszerét gyakran implicit módon, az [`str`] [`parse`] módszerén keresztül alkalmazzák.
/// Példákat a [`parse`] dokumentációjában talál.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` nem rendelkezik élettartam-paraméterrel, ezért csak azokat a típusokat elemezheti, amelyek maguk nem tartalmaznak egy élettartam-paramétert.
///
/// Más szavakkal, elemezhet egy `i32`-et az `FromStr`-szel, de az `&i32`-et nem.
/// Elemezheti az `i32`-et tartalmazó struktúrát, de az `&i32`-et nem.
///
/// # Examples
///
/// Az `FromStr` alapvető megvalósítása egy példa `Point` típuson:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Az elemzésből visszaadható társított hiba.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Az `s` karakterláncot elemzi egy ilyen érték visszaadásához.
    ///
    /// Ha az elemzés sikeres, adja vissza az értéket az [`Ok`] belsejében, ellenkező esetben, ha a karakterlánc rosszul van formázva, akkor a belső [`Err`] belső hibát adja vissza.
    /// A hibatípus a trait megvalósítására jellemző.
    ///
    /// # Examples
    ///
    /// Alapvető használat az [`i32`]-szel, amely az `FromStr`-et valósítja meg:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Az `bool` elemzése egy karakterláncból.
    ///
    /// `Result<bool, ParseBoolError>`-t ad, mert az `s` valóban értelmezhető vagy nem.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Megjegyzés: sok esetben az `str`-en az `.parse()` módszer a megfelelőbb.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}