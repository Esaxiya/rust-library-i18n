//! Az UTF-8 érvényesítésével kapcsolatos műveletek.

use crate::mem;

use super::Utf8Error;

/// Visszaadja az első bájt kezdeti kódpont-akkumulátorát.
/// Az első bájt speciális, csak az alsó 5 bitet akarja a 2. szélességhez, 4 bitet a 3. szélességhez és 3 bitet a 4. szélességhez.
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// Visszaadja az `ch` értéket, amely az `byte` folytatási bájttal frissült.
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// Ellenőrzi, hogy a bájt UTF-8 folytatós bájt-e (azaz az `10` bitekkel kezdődik).
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// Beolvassa a következő kódpontot egy bájtos iterátorból (feltételezve egy UTF-8-szerű kódolást).
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // Dekódolja az UTF-8-et
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // A többbájtos eset dekódolást eredményez a következő bájtkombinációból: [[[x y] z] w]
    //
    // NOTE: A teljesítmény érzékeny a pontos megfogalmazásra
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] w] eset
        // 5. bit az 0xE0-ben .. Az 0xEF mindig tiszta, így az `init` továbbra is érvényes
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] esetben csak az `init` alsó 3 bitjét használja
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// Beolvassa az utolsó kódpontot egy bájtos iterátorból (feltételezve egy UTF-8-szerű kódolást).
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // Dekódolja az UTF-8-et
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // A több bájtos eset dekódolást eredményez a bájtkombinációból: [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// csonkolással illessze be az u64 alkalmazást
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// Visszaadja az `true` értéket, ha az `x` szó bármely bájtja nonascii (>=128).
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// Végigmegy az `v`-en, ellenőrizve, hogy érvényes UTF-8-sorrend-e, ebben az esetben adja vissza az `Ok(())`-et, vagy ha érvénytelen, `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // szükségünk volt adatokra, de nem volt: hiba!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // A 2 bájtos kódolás az első C2 80 utolsó DF BF kódpontok számára\u {0080}
            // A 3 bájtos kódolás a kódpontokhoz\u {0800} az első E0 A0 80 utolsó EF BF BF-ig, kivéve a helyettesítő kódpontokat\u {d800}\u {dfff} ED A0 80-tól ED BF BF-ig
            // A 4 bájtos kódolás a kódpontokra vonatkozik: \u {1000} 0-\u {10ff} ff first F0 90 80 80 last F4 8F BF BF
            //
            // Használja az RFC UTF-8 szintaxisát
            //
            // https://tools.ietf.org/html/rfc3629
            // UTF8-1=% x00-7F UTF8-2=% xC2-DF UTF8-farok UTF8-3= %xE0% xA0-BF UTF8-farok/% xE1-EC 2( UTF8-tail )/%xED% x80-9F UTF8-farok/% xEE-EF 2( UTF8-tail ) UTF8-4= %xF0% x90-BF 2( UTF8-tail )/% xF1-F3 3( UTF8-tail )/%xF4% x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // Ascii esetben próbálj meg gyorsan ugrani előre.
            // Amikor a mutató igazodik, olvasson el 2 szó adatot iterációnként, amíg nem találunk egy szót, amely nem ascii bájtot tartalmaz.
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // BIZTONSÁG: mivel az `align - index` és az `ascii_block_size` az
                    // Az `usize_bytes`, `block = ptr.add(index)` többszörösei mindig egy `usize`-hez igazodnak, így biztonságosan lehet eltérni mind az `block`, mind az `block.offset(1)` értékektől.
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // törés, ha van nonascii bájt
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // lépés attól a ponttól, ahol a szó szerinti hurok megállt
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// Adott első bájt, meghatározza, hogy hány bájt van ebben az UTF-8 karakterben.
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// Maszk a folytatódó bájt értékbitjeiről.
const CONT_MASK: u8 = 0b0011_1111;
/// A folytatási bájt címkebitjeinek értéke (a címkemaszk !CONT_MASK).
const TAG_CONT_U8: u8 = 0b1000_0000;

// csonkolja az `&str`-et legfeljebb az `max`-hez, az `true`-et adja vissza, ha csonka lenne, és az új str.
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}