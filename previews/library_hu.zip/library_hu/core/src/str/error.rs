//! Meghatározza az utf8 hibatípust.

use crate::fmt;

/// Hibák, amelyek az [`u8`] sorozatának karakterláncként történő értelmezésének kísérlete során fordulhatnak elő.
///
/// Mint ilyen, az `from_utf8` funkció-és metóduscsalád mind a ["String"], mind a ["&str"] esetén felhasználja ezt a hibát.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Ennek a hibatípusnak a módszerei felhasználhatók az `String::from_utf8_lossy`-hez hasonló funkcionalitás létrehozására halom memória lefoglalása nélkül:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Visszaadja az adott karaktersorozat indexét, amelyig érvényes UTF-8 ellenőrzött.
    ///
    /// Ez az a maximális index, amellyel az `from_utf8(&input[..index])` visszaadja az `Ok(_)` értéket.
    ///
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// use std::str;
    ///
    /// // néhány érvénytelen bájt, egy vector-ben
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 Utf8Error-t ad vissza
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // a második bájt itt érvénytelen
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// További információt nyújt a hibáról:
    ///
    /// * `None`: a bemenet végét váratlanul elérték.
    ///   `self.valid_up_to()` 1-3 bájt a bemenet végétől.
    ///   Ha egy bájtfolyamot (például egy fájlt vagy egy hálózati foglalatot) inkrementálisan dekódolunk, akkor ez egy érvényes `char` lehet, amelynek UTF-8 bájtsorozata több darabot átível.
    ///
    ///
    /// * `Some(len)`: váratlan bájttal találkoztak.
    ///   A megadott hosszúság az érvénytelen bájtsorozat hossza, amely az `valid_up_to()` által megadott indexből indul.
    ///   Veszteséges dekódolás esetén a dekódolásnak az adott szekvencia után ([`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] behelyezése után) kell folytatódnia.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Az `bool` [`from_str`] használatával történő elemzése során visszaadott hiba sikertelen
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}