/// trait az `?` operátor viselkedésének testreszabásához.
///
/// Az `Try` megvalósító típusa kanonikus módon tekinthető meg az success/failure kettősség szempontjából.
/// Ez a trait lehetővé teszi mind a siker vagy kudarc értékeinek kinyerését egy meglévő példányból, mind pedig egy új példány létrehozását a siker vagy kudarc értékéből.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Ennek az értéknek a típusa, ha sikeresnek tekintjük.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Ennek az értéknek a típusa sikertelennek tekintve.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Alkalmazza az "?" operátort.Az `Ok(t)` visszatérése azt jelenti, hogy a végrehajtást normálisan kell folytatni, és az `?` eredménye az `t` értéke.
    /// Az `Err(e)` visszatérése azt jelenti, hogy a végrehajtásnak branch-t kell adnia az `catch` legbelső köré, vagy vissza kell térnie a függvényből.
    ///
    /// Ha `Err(e)` eredményt adunk vissza, akkor az `e` értéke "wrapped" lesz a becsatoló hatókör visszatérési típusában (amelynek magának kell megvalósítania az `Try`-et).
    ///
    /// Pontosabban az `X::from_error(From::from(e))` érték kerül visszaadásra, ahol `X` a záró függvény visszatérési típusa.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Csomagoljon egy hibaértéket az összetett eredmény összeállításához.
    /// Például az `Result::Err(x)` és az `Result::from_error(x)` egyenértékű.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Csomagoljon egy OK értéket az összetett eredmény összeállításához.
    /// Például az `Result::Ok(x)` és az `Result::from_ok(x)` egyenértékű.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}