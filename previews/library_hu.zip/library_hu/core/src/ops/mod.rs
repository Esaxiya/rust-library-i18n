//! Túlterhelhető operátorok.
//!
//! Ezen traits megvalósítása lehetővé teszi bizonyos operátorok túlterhelését.
//!
//! Ezen traits egy részét a prelude importálja, így minden Rust programban elérhetők.Csak a traits által támogatott operátorok lehetnek túlterheltek.
//! Például az (`+`) addíciós operátor túlterhelhető az [`Add`] trait keresztül, de mivel az (`=`) hozzárendelő operátornak nincs háttere trait, a szemantikáját nem lehet túlterhelni.
//! Ezenkívül ez a modul nem nyújt semmilyen mechanizmust új operátorok létrehozására.
//! Ha jellemző nélküli túlterhelésre vagy egyedi operátorokra van szükség, akkor a makrók vagy a fordítói bővítmények felé kell néznie, hogy kibővítse a Rust szintaxisát.
//!
//! A traits operátor megvalósításának nem meglepőnek kell lennie a saját kontextusában, szem előtt tartva a szokásos jelentését és az [operator precedence]-et.
//! Például az [`Mul`] megvalósításakor a műveletnek hasonlítania kell a szorzásra (és meg kell osztania a várható tulajdonságokat, például az asszociativitást).
//!
//! Vegye figyelembe, hogy az `&&` és `||` operátorok rövidzárlatot okoznak, azaz csak akkor értékelik a második operandusukat, ha ez hozzájárul az eredményhez.Mivel ezt a viselkedést a traits nem tudja kikényszeríteni, az `&&` és az `||` nem támogatott, mint túlterhelt operátor.
//!
//! Az operátorok közül sok érték szerint veszi operandusait.A beépített típusokat érintő nem általános összefüggésekben ez általában nem jelent problémát.
//! Ezeknek az operátoroknak az általános kódban való használata azonban némi figyelmet igényel, ha az értékeket újra fel kell használni, nem pedig azt, hogy az operátorok felhasználják őket.Az egyik lehetőség az [`clone`] alkalmanként történő használata.
//! Egy másik lehetőség az érintett típusokra támaszkodni, amelyek további operációs megvalósításokat biztosítanak a referenciákhoz.
//! Például egy felhasználó által definiált `T` típus esetében, amely állítólag támogatja az összeadást, valószínűleg jó ötlet, ha mind az `T`, mind az `&T` megvalósítja a traits [`Add<T>`][`Add`] és [`Add<&T>`][`Add`] programokat, hogy az általános kód felesleges klónozás nélkül írható legyen.
//!
//!
//! # Examples
//!
//! Ez a példa létrehoz egy `Point` struktúrát, amely megvalósítja az [`Add`] és [`Sub`] elemeket, majd bemutatja két "pont" összeadását és kivonását.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Az egyes trait dokumentációban talál egy példát a megvalósításra.
//!
//! Az [`Fn`], [`FnMut`] és [`FnOnce`] traits típusok hajtják végre, amelyek hasonlóan meghívhatók, mint a függvények.Vegye figyelembe, hogy az [`Fn`] az `&self`, az [`FnMut`] az `&mut self`, az [`FnOnce`] pedig az `self` értéket veszi fel.
//! Ezek megfelelnek a példányon meghívható háromféle módszernek: hívás-hivatkozás, hívás-változtatható hivatkozás és hívás-érték szerint.
//! Ezeknek a traits-nek a legelterjedtebb használata az, hogy korlátokként működnek a magasabb szintű funkciók számára, amelyek a függvényeket vagy a bezárásokat argumentumként veszik fel.
//!
//! [`Fn`]-et veszünk paraméterként:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! [`FnMut`]-et veszünk paraméterként:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! [`FnOnce`]-et veszünk paraméterként:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` a rögzített változókat elfogyasztja, ezért nem futtatható többször
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Az `func()` újbóli meghívásának megkísérlése `use of moved value` hibát okoz az `func` számára
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` ekkor már nem lehet hivatkozni
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;