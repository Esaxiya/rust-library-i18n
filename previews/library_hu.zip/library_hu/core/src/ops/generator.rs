use crate::marker::Unpin;
use crate::pin::Pin;

/// A generátor folytatásának eredménye.
///
/// Ez az összeg visszaküldésre kerül az `Generator::resume` módszerből, és jelzi a generátor lehetséges visszatérési értékeit.
/// Jelenleg ez vagy az (`Yielded`) felfüggesztési pontnak, vagy az (`Complete`) végpontnak felel meg.
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// A generátor fel van függesztve egy értékkel.
    ///
    /// Ez az állapot azt jelzi, hogy egy generátort felfüggesztettek, és általában egy `yield` utasításnak felel meg.
    /// Az ebben a változatban megadott érték megfelel az `yield`-nek továbbított kifejezésnek, és lehetővé teszi a generátorok számára, hogy minden alkalommal adják meg az értéküket.
    ///
    ///
    Yielded(Y),

    /// A generátor visszatérő értékkel kiegészítve.
    ///
    /// Ez az állapot azt jelzi, hogy egy generátor befejezte a végrehajtást a megadott értékkel.
    /// Miután egy generátor visszaadta az `Complete`-et, programozói hibának számít az `resume` újbóli felhívása.
    ///
    Complete(R),
}

/// A beépített generátortípusok által megvalósított trait.
///
/// A generátorok, más néven korutinok, jelenleg a Rust kísérleti nyelvi jellemzői.
/// Az [RFC 2033]-ben hozzáadott generátorok célja elsősorban az async/await-szintaxis építőelemének biztosítása, de valószínűleg kiterjed az ergonómiai meghatározásra az iterátorok és más primitívek számára is.
///
///
/// A generátorok szintaxisa és szemantikája instabil, és a stabilizáláshoz további RFC-re lesz szükség.Jelenleg azonban a szintaxis zárásszerű:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// A generátorok további dokumentációja megtalálható az instabil könyvben.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// A generátor által termelt érték típusa.
    ///
    /// Ez a társított típus megfelel az `yield` kifejezésnek és azoknak az értékeknek, amelyeket vissza lehet adni minden alkalommal, amikor egy generátor ad.
    ///
    /// Például egy iterator-as-a-generator-nak valószínűleg ez a típusa `T` lesz, a típus iterálva van.
    ///
    type Yield;

    /// A generátor által visszaadott érték típusa.
    ///
    /// Ez megfelel annak a típusnak, amelyet egy generátortól kaptak vissza, akár `return` utasítással, akár hallgatólagosan, mint egy generátor literál utolsó kifejezése.
    /// Például a futures ezt `Result<T, E>`-ként használja, mivel egy befejezett future-t képvisel.
    ///
    ///
    type Return;

    /// Folytatja ennek a generátornak a végrehajtását.
    ///
    /// Ez a függvény folytatja a generátor végrehajtását, vagy elindítja a végrehajtást, ha még nem tette meg.
    /// Ez a hívás visszatér a generátor utolsó felfüggesztési pontjába, és folytatja a végrehajtást a legújabb `yield`-től.
    /// A generátor addig folytatja a futtatást, amíg vagy hoz, vagy vissza nem tér, ekkor ez a függvény visszatér.
    ///
    /// # Visszatérési érték
    ///
    /// Az ebből a funkcióból visszatért `GeneratorState` enum jelzi, hogy a generátor milyen állapotban van a visszatéréskor.
    /// Ha az `Yielded` változatot visszaküldik, akkor a generátor elérte a felfüggesztési pontot, és egy értéket kapott.
    /// Az ebben az állapotban lévő generátorok később később folytathatók.
    ///
    /// Ha az `Complete`-t visszaküldi, akkor a generátor teljesen elkészült a megadott értékkel.Érvénytelen, ha a generátort újra folytatják.
    ///
    /// # Panics
    ///
    /// Ez a függvény panic lehet, ha az `Complete` változat korábbi visszaküldése után hívják meg.
    /// Míg a nyelv generátor literáljai garantálva vannak a panic számára, amikor az `Complete` után folytatódik, ez nem garantált az `Generator` trait összes megvalósításakor.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}