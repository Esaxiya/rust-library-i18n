/// Egyéni kód a rombolóban.
///
/// Amikor egy értékre már nincs szükség, a Rust futtat egy "destructor"-et ezen az értéken.
/// A leggyakoribb mód, amikor egy értékre már nincs szükség, az az, amikor az kívül esik a hatókörön.Előfordulhat, hogy a rombolók más körülmények között is működnek, de az itt szereplő példákra összpontosítunk.
/// Néhány ilyen esetről az [the reference] roncsolókról szóló részben olvashat.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Ez a romboló két összetevőből áll:
/// - Hívás az `Drop::drop`-re, ha ez a speciális `Drop` trait megvalósul a típusához.
/// - Az automatikusan létrehozott "drop glue", amely rekurzív módon hívja meg ennek az értéknek az összes mezőjét.
///
/// Mivel a Rust automatikusan felhívja az összes mező rombolóit, a legtöbb esetben nem kell végrehajtania az `Drop`-et.
/// Vannak azonban olyan esetek, amikor ez hasznos, például az erőforrásokat közvetlenül kezelő típusok esetében.
/// Ez az erőforrás lehet memória, lehet fájlleíró, lehet hálózati aljzat.
/// Amint egy ilyen típusú értéket már nem fog használni, akkor "clean up"-re kell erőforrását felszabadítania a memóriát, vagy bezárnia a fájlt vagy a foglalatot.
/// Ez a destruktor feladata, ezért az `Drop::drop` feladata.
///
/// ## Examples
///
/// A destruktorok működésének megtekintéséhez nézzük meg a következő programot:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// A Rust először felhívja az `Drop::drop`-et az `_x`-hez, majd az `_x.one`-et és az `_x.two`-et is, ami azt jelenti, hogy ennek futtatása kinyomtatja
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Még akkor is, ha eltávolítjuk az `Drop` for `HasTwoDrop` megvalósítását, a mezők rombolóit továbbra is hívjuk.
/// Ez azt eredményezné
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Az `Drop::drop`-et maga nem hívhatja
///
/// Mivel az `Drop::drop` érték tisztítására szolgál, veszélyes lehet ezt az értéket használni a módszer meghívása után.
/// Mivel az `Drop::drop` nem vállalja tulajdonjogát a bemenetére, a Rust megakadályozza a visszaéléseket, mivel nem engedi meg, hogy közvetlenül felhívja az `Drop::drop`-et.
///
/// Más szavakkal, ha megpróbálta kifejezetten felhívni az `Drop::drop`-et a fenti példában, fordítói hibát kap.
///
/// Ha kifejezetten meg akarja hívni egy érték rombolóját, akkor az [`mem::drop`] használható.
///
/// [`mem::drop`]: drop
///
/// ## Csepprendelés
///
/// A két `HasDrop` közül melyik esik először?Struktúrák esetén ugyanaz a sorrend, amelyet deklaráltak: először `one`, majd `two`.
/// Ha ezt maga szeretné kipróbálni, módosíthatja a fenti `HasDrop`-et úgy, hogy tartalmazzon néhány adatot, például egy egész számot, majd felhasználhatja az `Drop` belsejében található `println!`-ben.
/// Ezt a viselkedést a nyelv garantálja.
///
/// A struktúrákkal ellentétben a helyi változókat fordított sorrendben dobják le:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Ez kinyomtatja
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// A teljes szabályokat lásd az [the reference] oldalon.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` és az `Drop` kizárólagos
///
/// Az [`Copy`] és az `Drop` sem telepíthető ugyanarra a típusra.Az `Copy` típusokat a fordító implicit módon megismétli, így nagyon nehéz megjósolni, hogy a destruktorokat mikor és milyen gyakran hajtják végre.
///
/// Mint ilyen, ezeknek a típusoknak nem lehetnek destruktoraik.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Futtatja az ilyen típusú rombolót.
    ///
    /// Ezt a módszert implicit módon hívjuk meg, ha az érték kimarad a hatókörből, és nem hívható meg kifejezetten (ez az [E0040] fordítói hiba).
    /// Azonban a prelude [`mem::drop`] függvénye meghívható az argumentum `Drop` megvalósításának.
    ///
    /// Amikor ezt a módszert meghívták, az `self` még nem került felosztásra.
    /// Ez csak a módszer lejárta után következik be.
    /// Ha nem ez lenne a helyzet, akkor az `self` lelógó referencia lenne.
    ///
    /// # Panics
    ///
    /// Tekintettel arra, hogy egy [`panic!`] kiengedéskor hívja az `drop`-et, az `drop`-megvalósítás bármely [`panic!`]-je valószínűleg megszakad.
    ///
    /// Vegye figyelembe, hogy még ha ez a panics is, az értéket eldobottnak tekintjük;
    /// nem okozhatja az `drop` újbóli hívását.
    /// Ezt általában a fordító automatikusan kezeli, de nem biztonságos kód használata esetén néha akaratlanul is előfordulhat, különösen az [`ptr::drop_in_place`] használata esetén.
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}