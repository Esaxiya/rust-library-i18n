/// Változtathatatlan dereferenciós műveletekhez használják, mint például az `*v`.
///
/// Amellett, hogy megváltoztathatatlan összefüggésekben kifejezett Xerox (unary) `*` operátorral történő dereferenciós műveletekre használják, az `Deref`-t sok esetben implicit módon használja a fordító is.
/// Ezt a mechanizmust ['`Deref` coercion'][more]-nek hívják.
/// Változtatható környezetben az [`DerefMut`]-et használják.
///
/// Az `Deref` alkalmazása intelligens mutatók számára megkönnyíti a mögöttük lévő adatok elérését, ezért implementálják az `Deref`-et.
/// Másrészt az `Deref`-re és az [`DerefMut`]-re vonatkozó szabályokat kifejezetten az intelligens mutatók befogadására tervezték.
/// Emiatt a **Deref-et csak az intelligens mutatókra** szabad végrehajtani, a zavartság elkerülése érdekében.
///
/// Hasonló okokból **ennek a trait-nek soha nem szabad meghibásodnia**.Az elutasítás során bekövetkező kudarc rendkívül zavaró lehet, ha az `Deref`-t implicit módon hívják meg.
///
/// # További információ az `Deref` kényszerítésről
///
/// Ha az `T` végrehajtja az `Deref<Target = U>`-et, és az `x` az `T` típusú érték, akkor:
///
/// * Változhatatlan kontextusokban az `*x` (ahol az `T` sem referencia, sem nyers mutató) egyenértékű az `* Deref::deref(&x)` értékkel.
/// * Az `&T` típusú értékeket az `&U` típusú értékekre kényszerítik
/// * `T` implicit módon hajtja végre az `U` típusú összes (immutable) módszert.
///
/// További részletekért keresse fel az [the chapter in *The Rust Programming Language*][book] oldalt, valamint az [the dereference operator][ref-deref-op], [method resolution] és [type coercions] referencia szakaszokat.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Egy mezővel rendelkező struktúra, amely a struktúra levonásával érhető el.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Az eredményül kapott típus a derereferencia után.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Levonja az értéket.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Az `*v = 1;`-hez hasonlóan mutálható dereferenciós műveletekhez használják.
///
/// Amellett, hogy az (unary) X0 `*` operátorral mutábilis kontextusban kifejezett dereferenciós műveletekre használják, az `DerefMut`-t sok esetben implicit módon használja a fordító is.
/// Ezt a mechanizmust ['`Deref` coercion'][more]-nek hívják.
/// Változhatatlan körülmények között az [`Deref`]-et használják.
///
/// Az `DerefMut` alkalmazása intelligens mutatók számára megkönnyíti a mögöttük lévő adatok mutálását, ezért implementálják az `DerefMut`-et.
/// Másrészt az [`Deref`]-re és az `DerefMut`-re vonatkozó szabályokat kifejezetten az intelligens mutatók befogadására tervezték.
/// Emiatt a **DerefMut-ot csak az intelligens mutatók** esetében szabad megvalósítani, a zavartság elkerülése érdekében.
///
/// Hasonló okokból **ennek a trait-nek soha nem szabad meghibásodnia**.Az elutasítás során bekövetkező kudarc rendkívül zavaró lehet, ha az `DerefMut`-t implicit módon hívják meg.
///
/// # További információ az `Deref` kényszerítésről
///
/// Ha az `T` végrehajtja az `DerefMut<Target = U>`-et, és az `x` az `T` típusú érték, akkor:
///
/// * Változtatható kontextusban az `*x` (ahol az `T` sem referencia, sem nyers mutató) egyenértékű az `* DerefMut::deref_mut(&mut x)` értékkel.
/// * Az `&mut T` típusú értékeket az `&mut U` típusú értékekre kényszerítik
/// * `T` implicit módon hajtja végre az `U` típusú összes (mutable) módszert.
///
/// További részletekért keresse fel az [the chapter in *The Rust Programming Language*][book] oldalt, valamint az [the dereference operator][ref-deref-op], [method resolution] és [type coercions] referencia szakaszokat.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Egy mezővel rendelkező struktúra, amely módosítható a struktúra elhatárolásával.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Változatosan levonja az értéket.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Jelzi, hogy egy struktúra metódusvevőként is használható, az `arbitrary_self_types` szolgáltatás nélkül.
///
/// Ezt olyan stdlib mutatótípusok valósítják meg, mint az `Box<T>`, `Rc<T>`, `&T` és `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}