use crate::marker::Unsize;

/// Trait, amely azt jelzi, hogy ez egy mutató vagy egy burkoló az egyikhez, ahol méretet lehet méretezni a pointee-on.
///
/// További részletekért lásd: [DST coercion RFC][dst-coerce] és [the nomicon entry on coercion][nomicon-coerce].
///
/// Beépített mutatótípusok esetén az `T`-re mutató mutatók kénytelenek lesznek az `U`-re mutató mutatókra, ha az `T: Unsize<U>` vékony mutatóból zsíros mutatóvá alakulnak át.
///
/// Egyéni típusok esetén a kényszerítés az `Foo<T>` és az `Foo<U>` közötti kényszerítéssel működik, feltéve, hogy létezik `CoerceUnsized<Foo<U>> for Foo<T>` implicit.
/// Ilyen implikáció csak akkor írható, ha az `Foo<T>`-nek csak egyetlen nem fantomdata mezője van, amely magában foglalja az `T`-et.
/// Ha a mező típusa `Bar<T>`, akkor az `CoerceUnsized<Bar<U>> for Bar<T>` megvalósításának léteznie kell.
/// A kényszer úgy működik, hogy az `Bar<T>` mezőt kényszeríti az `Bar<U>` mezőbe, és a többi mezőt kitölti az `Foo<T>` mezőből, így létrejön egy `Foo<U>`.
/// Ez hatékonyan lefúrja a mutató mezőt, és ezt kikényszeríti.
///
/// Általában az intelligens mutatók esetében az `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`-et valósítja meg, az opcionális `?Sized`-mel magához az `T`-hez kötve.
/// Az `T`-et közvetlenül beágyazó burkolótípusokhoz, például az `Cell<T>` és az `RefCell<T>`, közvetlenül megvalósíthatja az `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`-et.
///
/// Ez lehetővé teszi az olyan kényszerítéseket, mint az `Cell<Box<T>>`.
///
/// [`Unsize`][unsize] olyan típusok jelölésére szolgál, amelyek kényszeríthetők a DST-kre, ha a mutató mögött vannak.A fordító automatikusan végrehajtja.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Ezt használják az objektumbiztonság érdekében, annak ellenőrzésére, hogy a módszer vevő típusa továbbítható-e.
///
/// Példa a trait megvalósítására:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}