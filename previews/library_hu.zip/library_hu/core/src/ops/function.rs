/// A hívásoperátor változata, amely megváltoztathatatlan vevőt vesz fel.
///
/// Az `Fn` példányai többször is hívhatók állapotmutáció nélkül.
///
/// *Ez a trait (`Fn`) nem tévesztendő össze az [function pointers] (`fn`)-szel.*
///
/// `Fn` automatikusan lezárásokkal valósul meg, amelyek csak megváltoztathatatlan hivatkozásokat tartalmaznak a rögzített változókra, vagy egyáltalán nem rögzítenek semmit, valamint az (safe) [function pointers] (egyes figyelmeztetésekkel a részletekért lásd a dokumentációjukat).
///
/// Ezenkívül minden olyan `F` típus esetében, amely megvalósítja az `Fn`-et, az `&F` az `Fn`-et is.
///
/// Mivel mind az [`FnMut`], mind az [`FnOnce`] az `Fn` szuperképessége, az `Fn` bármely példánya használható paraméterként, ahol [`FnMut`] vagy [`FnOnce`] várható.
///
/// Használja az `Fn`-et kötésként, ha el akarja fogadni egy függvény-típusú paramétert, és ismételten és mutáció nélküli állapotban kell meghívni (pl. Egyidejű híváskor).
/// Ha nincs szüksége ilyen szigorú követelményekre, akkor az [`FnMut`] vagy az [`FnOnce`] parancsot használja korlátként.
///
/// Lásd az [chapter on closures in *The Rust Programming Language*][book]-et, ha további információt szeretne erről a témáról.
///
/// Figyelemre méltó az `Fn` traits speciális szintaxisa is (pl
/// `Fn(usize, bool) -> felhasználni`).Azok, akiket ennek technikai részletei érdekelnek, hivatkozhatnak az [the relevant section in the *Rustonomicon*][nomicon]-re.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Bezárás hívása
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## `Fn` paraméter használata
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // hogy a regex támaszkodhasson arra az `&str: !FnMut`-re
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Végzi a hívás műveletet.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// A hívásoperátor változata, amely egy mutábilis vevőt vesz fel.
///
/// Az `FnMut` példányai többször is hívhatók, és mutációt okozhatnak.
///
/// `FnMut` automatikusan megvalósul olyan bezárásokkal, amelyek mutábilis hivatkozásokat tartalmaznak a rögzített változókra, valamint minden olyan típusra, amely megvalósítja az [`Fn`]-et, például az (safe) [function pointers]-et (mivel az `FnMut` az [`Fn`] szuperárnyéka).
/// Ezenkívül minden olyan `F` típus esetében, amely megvalósítja az `FnMut`-et, az `&mut F` az `FnMut`-et is.
///
/// Mivel az [`FnOnce`] az `FnMut` felülete, az `FnMut` bármely olyan példánya használható, ahol [`FnOnce`] várható, és mivel [`Fn`] az `FnMut` részvonala, bármely [`Fn`] példány használható, ahol várható `FnMut`.
///
/// Használja az `FnMut`-et kötésként, ha el akarja fogadni egy függvény típusú paramétert, és ismételten meg kell hívnia, miközben lehetővé teszi az állapot mutációját.
/// Ha nem akarja, hogy a paraméter állapotát mutálja, akkor az [`Fn`]-et használja kötésként;ha nem kell többször felhívni, használja az [`FnOnce`]-et.
///
/// Lásd az [chapter on closures in *The Rust Programming Language*][book]-et, ha további információt szeretne erről a témáról.
///
/// Figyelemre méltó az `Fn` traits speciális szintaxisa is (pl
/// `Fn(usize, bool) -> felhasználni`).Azok, akiket ennek technikai részletei érdekelnek, hivatkozhatnak az [the relevant section in the *Rustonomicon*][nomicon]-re.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## A mutánsan elfogó bezárás hívása
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## `FnMut` paraméter használata
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // hogy a regex támaszkodhasson arra az `&str: !FnMut`-re
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Végzi a hívás műveletet.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// A hívásoperátor verziója, amely mellékérték-vevőt vesz fel.
///
/// Az `FnOnce` példányai meghívhatók, de előfordulhat, hogy nem hívhatók meg többször.Emiatt, ha egy típusról csak annyit lehet tudni, hogy az `FnOnce`-et implementálja, akkor csak egyszer hívható meg.
///
/// `FnOnce` automatikusan megvalósul olyan bezárásokkal, amelyek elfogott változókat fogyaszthatnak, valamint minden olyan típusra, amely megvalósítja az [`FnMut`]-et, például az (safe) [function pointers]-et (mivel az `FnOnce` az [`FnMut`] szuperárnyéka).
///
///
/// Mivel mind az [`Fn`], mind az [`FnMut`] az `FnOnce` részmintái, az [`Fn`] vagy [`FnMut`] bármely példánya használható, ahol `FnOnce` várható.
///
/// Használja az `FnOnce`-et kötésként, ha el akarja fogadni egy függvény típusú paramétert, és csak egyszer kell meghívnia.
/// Ha ismételten meg kell hívnia a paramétert, akkor az [`FnMut`]-et használja kötésként;ha arra is szükséged van, hogy ne mutálódjon az állapot, használd az [`Fn`]-et.
///
/// Lásd az [chapter on closures in *The Rust Programming Language*][book]-et, ha további információt szeretne erről a témáról.
///
/// Figyelemre méltó az `Fn` traits speciális szintaxisa is (pl
/// `Fn(usize, bool) -> felhasználni`).Azok, akiket ennek technikai részletei érdekelnek, hivatkozhatnak az [the relevant section in the *Rustonomicon*][nomicon]-re.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## `FnOnce` paraméter használata
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` a rögzített változókat elfogyasztja, ezért nem futtatható többször.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Az `func()` újbóli meghívásának megkísérlése `use of moved value` hibát okoz az `func` számára.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` ekkor már nem lehet hivatkozni
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // hogy a regex támaszkodhasson arra az `&str: !FnMut`-re
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// A visszaküldött típus a hívásoperátor használata után.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Végzi a hívás műveletet.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}