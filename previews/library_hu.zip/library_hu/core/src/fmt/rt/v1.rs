//! Ez egy belső modul, amelyet az ifmt használ!futási idő.Ezeket a struktúrákat statikus tömbök adják ki, hogy idő előtt előre lefordítsák a formátum-karakterláncokat.
//!
//! Ezek a definíciók hasonlóak az `ct` ekvivalenseihez, de abban különböznek, hogy statikusan lefoglalhatók és kissé optimalizálhatók a futásidejére
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Lehetséges igazítások, amelyek formázási irányelv részeként kérhetők.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Jelzés, hogy a tartalmat balra kell igazítani.
    Left,
    /// Annak jelzése, hogy a tartalomnak jobbra kell igazodnia.
    Right,
    /// Annak jelzése, hogy a tartalomnak középre kell igazodnia.
    Center,
    /// Nem kértek igazítást.
    Unknown,
}

/// [width](https://doc.rust-lang.org/std/fmt/#width) és [precision](https://doc.rust-lang.org/std/fmt/#precision) specifikátorok használják.
#[derive(Copy, Clone)]
pub enum Count {
    /// Szó szerinti számmal megadva tárolja az értéket
    Is(usize),
    /// Az `$` és `*` szintaxisokkal megadva tárolja az indexet az `args` fájlba
    Param(usize),
    /// Nem meghatározott
    Implied,
}