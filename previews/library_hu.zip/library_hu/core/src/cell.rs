//! Megosztható, cserélhető konténerek.
//!
//! A Rust memória biztonsága ezen a szabályon alapul: Adott `T` objektum esetén csak az alábbiak egyikével lehet rendelkezni:
//!
//! - Több megváltoztathatatlan (`&T`) hivatkozás van az objektumra (más néven **aliasing**).
//! - Egy módosítható hivatkozás (`&mut T`) van az objektumra (más néven **mutabilitás**).
//!
//! Ezt a Rust fordító hajtja végre.Vannak azonban olyan helyzetek, amikor ez a szabály nem elég rugalmas.Néha megköveteli, hogy több hivatkozás legyen egy objektumra, és mégis mutálja azt.
//!
//! Megosztható, cserélhető konténerek léteznek, amelyek lehetővé teszik a mutálást ellenőrzött módon, még álnév jelenlétében is.Az [`Cell<T>`] és az [`RefCell<T>`] egyaránt lehetővé teszi ezt egyszálú módon.
//! Azonban sem az `Cell<T>`, sem az `RefCell<T>` nem biztonságos a menetben (nem valósítja meg az [`Sync`]-et).
//! Ha több szál között elosztást és mutációt kell végrehajtania, akkor [`Mutex<T>`], [`RwLock<T>`] vagy [`atomic`] típusokat is használhat.
//!
//! Az `Cell<T>` és `RefCell<T>` típusú értékek mutálódhatnak megosztott hivatkozások (pl
//! a közös `&T` típus), míg a legtöbb Rust típus csak egyedi (`&mut T`) hivatkozások révén mutálható.
//! Azt mondjuk, hogy az `Cell<T>` és az `RefCell<T>` " belső mutálhatóságot`biztosít, ellentétben a tipikus Rust típusokkal, amelyek " öröklődő mutabilitást` mutatnak.
//!
//! A sejttípusok kétféle ízben kaphatók: `Cell<T>` és `RefCell<T>`.Az `Cell<T>` a belső mutabilitást úgy valósítja meg, hogy értékeket mozgat be az `Cell<T>`-be.
//! Az értékek helyett referenciák használatához az `RefCell<T>` típust kell használni, megszerezve egy írási zárat mutáció előtt.Az `Cell<T>` módszereket kínál az aktuális belső érték lekérésére és megváltoztatására:
//!
//!  - Az [`Copy`] megvalósító típusok esetében az [`get`](Cell::get) módszer beolvassa az aktuális belső értéket.
//!  - Az [`Default`]-t megvalósító típusok esetében az [`take`](Cell::take) módszer az aktuális belső értéket [`Default::default()`]-re cseréli és visszaadja a kicserélt értéket.
//!  - Minden típus esetében az [`replace`](Cell::replace) módszer kicseréli az aktuális belső értéket és visszaadja a kicserélt értéket, az [`into_inner`](Cell::into_inner) módszer pedig az `Cell<T>` értéket veszi fel és adja vissza a belső értéket.
//!  Ezenkívül az [`set`](Cell::set) módszer helyettesíti a belső értéket, eldobva a kicserélt értéket.
//!
//! `RefCell<T>` A Rust élettartamait használja a " dinamikus hitelfelvétel` megvalósítására, amely folyamat során ideiglenes, kizárólagos, változtatható hozzáférést igényelhet a belső értékhez.
//! Hitelfelvétel a `RefCell<T>Az s-eket futás közben követik, ellentétben a Rust natív referencia típusaival, amelyeket statikusan, fordításkor követnek teljes egészében.
//! Mivel az `RefCell<T>` hitelfelvételek dinamikusak, megkísérelhetünk olyan érték kölcsönzését, amelyet már kölcsönösen kölcsönvettek;amikor ez megtörténik, a panic szálat eredményezi.
//!
//! # Mikor válasszuk a belső mutabilitást
//!
//! A leggyakoribb öröklődő mutabilitás, ahol az érték mutálásához egyedi hozzáféréssel kell rendelkezni, az egyik kulcsfontosságú nyelvi elem, amely lehetővé teszi a Rust számára, hogy erőteljesen érveljen a mutatóaliasolással, statikusan megakadályozva az összeomlási hibákat.
//! Emiatt az öröklött mutabilitást részesítik előnyben, a belső mutabilitás pedig végső megoldás.
//! Mivel a sejttípusok lehetővé teszik a mutációt ott, ahol egyébként nem engednék meg, vannak olyan esetek, amikor a belső mutálhatóság megfelelő lehet, vagy akár *is* kell használni, pl.
//!
//! * Bemutatjuk valami megváltoztathatatlan 'inside' mutabilitását
//! * Logikailag megváltoztathatatlan módszerek megvalósításának részletei.
//! * Az [`Clone`] implementációinak mutációja.
//!
//! ## Bemutatjuk valami megváltoztathatatlan 'inside' mutabilitását
//!
//! Számos megosztott intelligens mutatótípus, köztük az [`Rc<T>`] és az [`Arc<T>`], klónozható és több fél között megosztható tárolókat kínál.
//! Mivel a tartalmazott értékek szorzótanulmányozhatók, csak `&`-tel kölcsönözhetők, az `&mut`-kel nem.
//! Cellák nélkül lehetetlen egyáltalán mutálni az adatokat ezeken az intelligens mutatókon belül.
//!
//! Nagyon gyakori, hogy az `RefCell<T>`-et megosztott mutatótípusokba helyezik a mutabilitás újbóli bevezetése érdekében:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Hozzon létre egy új blokkot a dinamikus hitelfelvétel körének korlátozásához
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Ne feledje, hogy ha nem hagytuk, hogy a gyorsítótár előző kölcsönvétele kieszen a hatókörből, akkor a későbbi kölcsön egy dinamikus panic szálat okozna.
//!     //
//!     // Ez az `RefCell` használatának legfőbb veszélye.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Vegye figyelembe, hogy ez a példa az `Rc<T>`-et használja, nem pedig az `Arc<T>`-et.RefCell<T>Egyszálú forgatókönyvek.Fontolja meg az [`RwLock<T>`] vagy az [`Mutex<T>`] használatát, ha többszálú helyzetben megosztott változtatásokra van szüksége.
//!
//! ## Logikailag megváltoztathatatlan módszerek megvalósításának részletei
//!
//! Időnként kívánatos lehet, hogy egy API-ban ne tegye ki, hogy az "under the hood" mutáció történjen.
//! Ennek oka lehet, hogy logikailag a művelet változhatatlan, de például a gyorsítótárazás a végrehajtást mutáció végrehajtására kényszeríti;vagy mert mutációt kell alkalmaznia egy trait módszer megvalósításához, amelyet eredetileg az `&self` felvételére határoztak meg.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Drága számítás megy itt
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Az `Clone` implementációinak mutációja
//!
//! Ez egyszerűen az előző speciális, de gyakori esete: a változtathatatlannak tűnő műveletek mutabilitásának elrejtése.
//! Az [`clone`](Clone::clone) módszer várhatóan nem változtatja meg a forrásértéket, és az `&self`-et veszi át, nem pedig az `&mut self`-et.
//! Ezért az `clone` módszerben bekövetkező minden mutációnak sejttípusokat kell használnia.
//! Például az [`Rc<T>`] fenntartja referenciaszámát egy `Cell<T>`-en belül.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Változtatható memóriahely.
///
/// # Examples
///
/// Ebben a példában láthatja, hogy az `Cell<T>` lehetővé teszi a mutációt egy megváltoztathatatlan struktúrán belül.
/// Más szavakkal, lehetővé teszi az "interior mutability" használatát.
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // HIBA: Az `my_struct` változhatatlan
/// // my_struct.regular_field =new_value;
///
/// // MŰVEK: bár az `my_struct` megváltoztathatatlan, az `special_field` egy `Cell`,
/// // amely mindig mutálható
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// További információkért lásd az [module-level documentation](self)-et.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Létrehoz egy `Cell<T>`-et, a T-nek az `Default` értékével.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Létrehoz egy új `Cell`-et, amely tartalmazza a megadott értéket.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Beállítja a benne foglalt értéket.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Két Cell értékét felcseréli.
    /// Az `std::mem::swap`-től az a különbség, hogy ehhez a funkcióhoz nincs szükség `&mut`-referenciára.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // BIZTONSÁG: Ez kockázatos lehet, ha külön szálakból hívják meg, de az `Cell`
        // az `!Sync`, tehát ez nem fog megtörténni.
        // Ez szintén nem érvénytelenít egyetlen mutatót sem, mivel az `Cell` biztosítja, hogy semmi más ne mutasson e cellák egyikébe sem.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// A benne foglalt értéket `val`-re cseréli, és a régi tartalmazott értéket adja vissza.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // BIZTONSÁG: Ez külön szálból történő meghívás esetén adatversenyeket okozhat,
        // de az `Cell` az `!Sync`, tehát ez nem fog megtörténni.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Kicsomagolja az értéket.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Visszaadja a tartalmazott érték másolatát.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // BIZTONSÁG: Ez külön szálból történő meghívás esetén adatversenyeket okozhat,
        // de az `Cell` az `!Sync`, tehát ez nem fog megtörténni.
        unsafe { *self.value.get() }
    }

    /// A függvény segítségével frissíti a benne foglalt értéket, és visszaadja az új értéket.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Visszaad egy nyers mutatót a cella mögöttes adataihoz.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Változtatható hivatkozást ad vissza az alapul szolgáló adatokra.
    ///
    /// Ez a hívás kölcsönösen kölcsönadja az `Cell`-et (fordítás idején), ami garantálja, hogy rendelkezünk az egyetlen referenciával.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `&Cell<T>`-et ad vissza az `&mut T`-ből
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // BIZTONSÁG: Az `&mut` egyedülálló hozzáférést biztosít.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// A cella értékét veszi, és az `Default::default()` marad a helyén.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// `&[Cell<T>]`-et ad vissza az `&Cell<[T]>`-ből
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // BIZTONSÁG: Az `Cell<T>` memóriaelrendezése megegyezik az `T` memóriájával.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Változtatható memóriahely dinamikusan ellenőrzött kölcsönszabályokkal
///
/// További információkért lásd az [module-level documentation](self)-et.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Az [`RefCell::try_borrow`] által visszaadott hiba.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Az [`RefCell::try_borrow_mut`] által visszaadott hiba.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// A pozitív értékek az aktív `Ref` számát jelentik.A negatív értékek az aktív `RefMut` számát jelentik.
// Több "RefMut" csak akkor lehet aktív, ha egy `RefCell` különálló, nem átfedő összetevőire utalnak (pl. Egy szelet különböző tartományai).
//
// `Ref` és az `RefMut` mindkettő két szó méretű, ezért valószínűleg soha nem lesz elegendő "Ref" vagy "RefMut" az `usize` tartomány felének túlcsordulásához.
// Így egy `BorrowFlag` valószínűleg soha nem fog túlcsordulni vagy alulfolyni.
// Ez azonban nem garancia, mivel egy kóros program többször is létrehozhat, majd mem::forget `Ref` vagy`RefMut`.
// Tehát az összes kódnak kifejezetten ellenőriznie kell a túlcsordulást és az alulcsordulást a bizonytalanság elkerülése érdekében, vagy legalábbis helyesen kell viselkednie abban az esetben, ha túlcsordulás vagy túlcsordulás történik (pl. Lásd: BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Létrehoz egy új `RefCell`-et, amely tartalmazza az `value`-et.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Fogyasztja az `RefCell`-et, és visszaadja a becsomagolt értéket.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Mivel ez a függvény értékként veszi fel az `self`-et (az `RefCell`-et), a fordító statikusan ellenőrzi, hogy jelenleg nincs-e kölcsön kölcsönözve.
        //
        self.value.into_inner()
    }

    /// A becsomagolt értéket kicseréli egy újra, visszaadva a régi értéket, de egyiket sem inicializálva.
    ///
    ///
    /// Ez a funkció megfelel az [`std::mem::replace`](../mem/fn.replace.html)-nek.
    ///
    /// # Panics
    ///
    /// Panics, ha az érték jelenleg kölcsön van kapva.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// A becsomagolt értéket kicseréli egy újra, amelyet az `f`-ből számítottak ki, visszaadva a régi értéket, de egyiket sem inicializálva.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ha az érték jelenleg kölcsön van kapva.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Felcseréli az `self` becsomagolt értékét az `other` becsomagolt értékével anélkül, hogy egyiket inicializálná.
    ///
    ///
    /// Ez a funkció megfelel az [`std::mem::swap`](../mem/fn.swap.html)-nek.
    ///
    /// # Panics
    ///
    /// Panics, ha az `RefCell` bármelyikét jelenleg kölcsönadják.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Változhatatlanul kölcsönveszi a becsomagolt értéket.
    ///
    /// A kölcsön mindaddig tart, amíg a visszaküldött `Ref` kilép a hatókörből.
    /// Több változatlan hitelt lehet egyszerre felvenni.
    ///
    /// # Panics
    ///
    /// Panics, ha az értéket kölcsönösen kölcsönvettük.
    /// Pánikmentes változat esetén használja az [`try_borrow`](#method.try_borrow)-et.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Példa a panic-re:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Változatlanul kölcsönveszi a becsomagolt értéket, hibát adva, ha az értéket kölcsönösen kölcsönvettük.
    ///
    ///
    /// A kölcsön mindaddig tart, amíg a visszaküldött `Ref` kilép a hatókörből.
    /// Több változatlan hitelt lehet egyszerre felvenni.
    ///
    /// Ez az [`borrow`](#method.borrow) pánikmentes változata.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // BIZTONSÁG: Az `BorrowRef` biztosítja, hogy csak megváltoztathatatlan hozzáférés legyen
            // hitelfelvételig.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Kölcsönösen kölcsönveszi a becsomagolt értéket.
    ///
    /// A kölcsön mindaddig tart, amíg a visszaküldött `RefMut` vagy az ebből származó összes RefMut kilép a hatókörből.
    ///
    /// Az érték nem vehető fel, amíg ez a kölcsön aktív.
    ///
    /// # Panics
    ///
    /// Panics, ha az érték jelenleg kölcsön van kapva.
    /// Pánikmentes változat esetén használja az [`try_borrow_mut`](#method.try_borrow_mut)-et.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Példa a panic-re:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Mutatíven kölcsönveszi a becsomagolt értéket, hibát adva, ha az értéket jelenleg kölcsönadják.
    ///
    ///
    /// A kölcsön mindaddig tart, amíg a visszaküldött `RefMut` vagy az ebből származó összes RefMut kilép a hatókörből.
    /// Az érték nem vehető fel, amíg ez a kölcsön aktív.
    ///
    /// Ez az [`borrow_mut`](#method.borrow_mut) pánikmentes változata.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // BIZTONSÁG: Az `BorrowRef` egyedülálló hozzáférést garantál.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Visszaad egy nyers mutatót a cella mögöttes adataihoz.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Változtatható hivatkozást ad vissza az alapul szolgáló adatokra.
    ///
    /// Ez a hívás kölcsönösen kölcsönadja az `RefCell`-et (fordítási időben), így nincs szükség dinamikus ellenőrzésekre.
    ///
    /// Legyen azonban óvatos: ez a módszer azt várja, hogy az `self` mutálható legyen, ami általában nem az `RefCell` használata esetén.
    ///
    /// Vessen egy pillantást az [`borrow_mut`] módszerre, ha az `self` nem módosítható.
    ///
    /// Kérjük, vegye figyelembe, hogy ez a módszer csak különleges esetekre szolgál, és általában nem az, amire vágyik.
    /// Kétség esetén inkább az [`borrow_mut`]-et használja.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Visszavonja a kiszivárgott védőeszközök hatását az `RefCell` kölcsönállapotára.
    ///
    /// Ez a hívás hasonló az [`get_mut`]-hez, de speciálisabb.
    /// Az `RefCell`-et kölcsönösen felveszi, hogy ne legyen hitelfelvétel, majd visszaállítja a megosztott kölcsönöket követő állapotot.
    /// Ez akkor releváns, ha néhány `Ref` vagy `RefMut` hitelfelvétel szivárgott ki.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Változatlanul kölcsönveszi a becsomagolt értéket, hibát adva, ha az értéket kölcsönösen kölcsönvettük.
    ///
    /// # Safety
    ///
    /// Az `RefCell::borrow`-től eltérően ez a módszer nem biztonságos, mert nem adja vissza az `Ref`-et, így érintetlenül hagyja a kölcsön zászlót.
    /// Meghatározhatatlan viselkedés az `RefCell` kölcsönvétele, amíg az ezzel a módszerrel visszaadott referencia életben van.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // BIZTONSÁG: Ellenőrizzük, hogy most senki sem ír aktívan, de mégis
            // a hívó fél felelőssége annak biztosítása, hogy senki ne írjon, amíg a visszaküldött referenciát már nem használják.
            // Az `self.value.get()` az `self` tulajdonában lévő értékre is utal, és így garantáltan érvényes lesz az `self` élettartama alatt.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// A becsomagolt értéket veszi fel, így az `Default::default()` a helyén marad.
    ///
    /// # Panics
    ///
    /// Panics, ha az érték jelenleg kölcsön van kapva.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics, ha az értéket kölcsönösen kölcsönvettük.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Létrehoz egy `RefCell<T>`-et, a T-nek az `Default` értékével.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics, ha az `RefCell` bármelyikét jelenleg kölcsönadják.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics, ha az `RefCell` bármelyikét jelenleg kölcsönadják.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics, ha az `RefCell` bármelyikét jelenleg kölcsönadják.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, ha az `RefCell` bármelyikét jelenleg kölcsönadják.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, ha az `RefCell` bármelyikét jelenleg kölcsönadják.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, ha az `RefCell` bármelyikét jelenleg kölcsönadják.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics, ha az `RefCell` bármelyikét jelenleg kölcsönadják.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // A hitelfelvétel növelése nem olvasási értéket eredményezhet (<=0) a következő esetekben:
            // 1. <0 volt, azaz vannak hitelfelvételi kölcsönök, ezért a Rust hivatkozási álnevezési szabályai miatt nem engedélyezhetünk olvasási hitelt.
            // 2.
            // isize::MAX volt (az olvasási kölcsönök maximális összege), és túlcsordult az isize::MIN-be (az írásbeli kölcsönök maximális összege), így nem engedélyezhetünk további olvasási hitelt, mert az isize nem képes annyi olvasott hitelt képviselni (ez csak akkor fordulhat elő, ha Ön mem::forget több, mint egy kis állandó mennyiségű "Ref", ami nem jó gyakorlat)
            //
            //
            //
            //
            None
        } else {
            // A hitelfelvétel növelése leolvasási értéket (> 0) eredményezhet az alábbi esetekben:
            // 1. =0 volt, azaz nem kölcsönvették, és az első olvasott hitelt vesszük
            // 2. Ez> 0 és <isize::MAX volt, azaz
            // voltak olvasott kölcsönök, és az isize elég nagy ahhoz, hogy képviseljen még egy olvasott hitelt
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Mivel ez a hivatkozás létezik, tudjuk, hogy a kölcsönkérés zászló olvasó kölcsön.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Akadályozzuk meg, hogy a hitelpult számlálója túlcsorduljon írásbeli kölcsönbe.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Az `RefCell` mezőbe egy kölcsönzött referenciát becsomagol egy értékre.
/// Burkolótípus megváltoztathatatlanul kölcsönzött értékhez egy `RefCell<T>`-től.
///
/// További információkért lásd az [module-level documentation](self)-et.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Másol egy `Ref`-et.
    ///
    /// Az `RefCell` már megváltoztathatatlanul kölcsön van kölcsönözve, így ez nem bukhat meg.
    ///
    /// Ez egy társított függvény, amelyet `Ref::clone(...)`-ként kell használni.
    /// Egy `Clone` megvalósítás vagy egy módszer megzavarhatja az `r.borrow().clone()` széleskörű használatát az `RefCell` tartalmának klónozásához.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Új `Ref`-et készít a kölcsönzött adatok egyik eleméhez.
    ///
    /// Az `RefCell` már megváltoztathatatlanul kölcsön van kölcsönözve, így ez nem bukhat meg.
    ///
    /// Ez egy társított függvény, amelyet `Ref::map(...)`-ként kell használni.
    /// Egy módszer megzavarhatja az azonos nevű módszereket az `Deref`-en keresztül használt `RefCell` tartalmán.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Új `Ref`-et készít a kölcsönzött adatok opcionális komponenseként.
    /// Az eredeti védőelemet `Err(..)`-ként adják vissza, ha a lezárás `None`-et ad vissza.
    ///
    /// Az `RefCell` már megváltoztathatatlanul kölcsön van kölcsönözve, így ez nem bukhat meg.
    ///
    /// Ez egy társított függvény, amelyet `Ref::filter_map(...)`-ként kell használni.
    /// Egy módszer megzavarhatja az azonos nevű módszereket az `Deref`-en keresztül használt `RefCell` tartalmán.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Felosztja az `Ref`-et több "Ref"-re a kölcsönzött adatok különböző összetevői számára.
    ///
    /// Az `RefCell` már megváltoztathatatlanul kölcsön van kölcsönözve, így ez nem bukhat meg.
    ///
    /// Ez egy társított függvény, amelyet `Ref::map_split(...)`-ként kell használni.
    /// Egy módszer megzavarhatja az azonos nevű módszereket az `Deref`-en keresztül használt `RefCell` tartalmán.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Átalakítás hivatkozássá az alapul szolgáló adatokra.
    ///
    /// Az alapul szolgáló `RefCell`-t soha nem lehet kölcsönösen kölcsön kölcsönözni, és mindig már megváltoztathatatlanul kölcsönzöttnek tűnik.
    ///
    /// Nem jó, ha állandó számú hivatkozásnál többet szivárogtatunk ki.
    /// Az `RefCell` újra megváltoztathatatlanul kölcsönözhető, ha összesen csak kisebb számú szivárgás történt.
    ///
    /// Ez egy társított függvény, amelyet `Ref::leak(...)`-ként kell használni.
    /// Egy módszer megzavarhatja az azonos nevű módszereket az `Deref`-en keresztül használt `RefCell` tartalmán.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // A Ref elfelejtésével biztosítjuk, hogy a RefCell hitelfelvevője az `'b` élettartama alatt nem térhet vissza UNUSED értékre.
        // A referenciakövetési állapot visszaállításához egyedi hivatkozásra lenne szükség a kölcsönzött RefCellre.
        // Az eredeti cellából további mutábilis hivatkozások nem hozhatók létre.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Új `RefMut`-et készít a kölcsönzött adatok egy eleméhez, például egy enum-variánshoz.
    ///
    /// Az `RefCell` már kölcsönösen kölcsönvett, így ez nem bukhat meg.
    ///
    /// Ez egy társított függvény, amelyet `RefMut::map(...)`-ként kell használni.
    /// Egy módszer megzavarhatja az azonos nevű módszereket az `Deref`-en keresztül használt `RefCell` tartalmán.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): fix kölcsön-csekk
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Új `RefMut`-et készít a kölcsönzött adatok opcionális komponenseként.
    /// Az eredeti védőelemet `Err(..)`-ként adják vissza, ha a lezárás `None`-et ad vissza.
    ///
    /// Az `RefCell` már kölcsönösen kölcsönvett, így ez nem bukhat meg.
    ///
    /// Ez egy társított függvény, amelyet `RefMut::filter_map(...)`-ként kell használni.
    /// Egy módszer megzavarhatja az azonos nevű módszereket az `Deref`-en keresztül használt `RefCell` tartalmán.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): fix kölcsön-csekk
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // BIZTONSÁG: A funkció egy exkluzív referenciára vonatkozik az időtartam alatt
        // az `orig`-en keresztüli hívásának, és a mutató csak a funkcióhíváson belül hivatkozik le, soha nem engedve, hogy a kizárólagos hivatkozás elmenjen.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // BIZTONSÁG: ugyanaz, mint fent.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Felosztja az `RefMut`-et több "RefMut"-ra a kölcsönzött adatok különböző összetevői számára.
    ///
    /// Az alapul szolgáló `RefCell` mindaddig kölcsönösen kölcsönzött marad, amíg mindkét visszaküldött "RefMut" nem megy ki az alkalmazási körből.
    ///
    /// Az `RefCell` már kölcsönösen kölcsönvett, így ez nem bukhat meg.
    ///
    /// Ez egy társított függvény, amelyet `RefMut::map_split(...)`-ként kell használni.
    /// Egy módszer megzavarhatja az azonos nevű módszereket az `Deref`-en keresztül használt `RefCell` tartalmán.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Átalakítás konvertálható hivatkozássá az alapul szolgáló adatokra.
    ///
    /// Az alapul szolgáló `RefCell` nem kölcsönözhető újra, és mindig kölcsönösen kölcsönzöttként jelenik meg, így a visszaküldött hivatkozás az egyetlen a belső térre.
    ///
    ///
    /// Ez egy társított függvény, amelyet `RefMut::leak(...)`-ként kell használni.
    /// Egy módszer megzavarhatja az azonos nevű módszereket az `Deref`-en keresztül használt `RefCell` tartalmán.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // A BorrowRefMut elfelejtésével biztosítjuk, hogy a RefCell hitelfelvevője az `'b` élettartama alatt nem térhet vissza UNUSED értékre.
        // A referenciakövetési állapot visszaállításához egyedi hivatkozásra lenne szükség a kölcsönzött RefCellre.
        // Az eredeti cellából az adott élettartam alatt további hivatkozások nem hozhatók létre, így az aktuális kölcsön az egyetlen referencia a hátralévő élettartamra.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Az BorrowRefMut::clone-től eltérően az újat hívják meg a kezdőbetű létrehozásához
        // mutábilis hivatkozás, és ezért jelenleg nem létezhet referencia.
        // Így, míg a klón növeli a módosítható újraszámlálást, itt kifejezetten csak a HASZNÁLATTAL a HASZNÁLATTAL szemben engedélyezzük az áttérést, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Klónoz egy `BorrowRefMut`-et.
    //
    // Ez csak akkor érvényes, ha minden `BorrowRefMut`-et az eredeti objektum különálló, nem átfedő tartományához tartozó mutábilis hivatkozás követésére használnak.
    //
    // Ez nem szerepel a klón implikációjában, így a kód nem hívja ezt implicit módon.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Akadályozzuk meg a hitelpult elfolyását.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Burkoló típus egy `RefCell<T>`-től kölcsönösen kölcsönzött értékhez.
///
/// További információkért lásd az [module-level documentation](self)-et.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// A primitív a belső mutabilitás a Rust-ben.
///
/// Ha van referenciája `&T`, akkor a Rust rendszerint a fordító optimalizálást hajt végre annak ismerete alapján, hogy az `&T` megváltoztathatatlan adatokra mutat.Az adatok mutációja, például álnéven keresztül, vagy egy `&T` átalakítása `&mut T`-be, meghatározhatatlan viselkedésnek minősül.
/// `UnsafeCell<T>` kikapcsolja az `&T` módosíthatatlansági garanciáját: az `&UnsafeCell<T>` megosztott hivatkozás mutálható adatokra mutathat.Ezt hívják "interior mutability"-nek.
///
/// Minden más típus, amely lehetővé teszi a belső mutálhatóságot, mint például az `Cell<T>` és az `RefCell<T>`, az `UnsafeCell`-et használja belsőleg az adatok becsomagolásához.
///
/// Vegye figyelembe, hogy az `UnsafeCell` csak a megosztott hivatkozások megváltoztathatatlansági garanciáját érinti.A változtatható hivatkozások egyediségi garanciája nem változik.Az `&mut` álnév megszerzésére *nincs* törvényes módszer, még `UnsafeCell<T>` esetén sem.
///
/// Maga az `UnsafeCell` API technikailag nagyon egyszerű: az [`.get()`] nyers `*mut T` mutatót ad a tartalmához.Az _you_, mint absztrakciótervezõ, az a nyers mutató helyes használata.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// A pontos Rust álnevezési szabályok némileg változnak, de a főbb kérdések nem vitatottak:
///
/// - Ha biztonságos referenciát hoz létre az `'a` élettartammal (akár `&T`, akár `&mut T` referenciával), amely biztonságos kóddal elérhető (például azért, mert Ön visszaküldte), akkor semmilyen módon nem férhet hozzá az adatokhoz, amely ellentmond a referenciának a fennmaradó részében az `'a`.
/// Például ez azt jelenti, hogy ha `UnsafeCell<T>`-et veszünk egy `UnsafeCell<T>`-ből, és `&T`-be vesszük, akkor az `T`-ben szereplő adatoknak változhatatlannak kell maradniuk (természetesen az `T`-ben talált `UnsafeCell`-adatokat modulálni), amíg a hivatkozás élettartama le nem jár.
/// Hasonlóképpen, ha létrehoz egy `&mut T` referenciát, amely biztonságos kódra van kiadva, addig nem szabad hozzáférnie az `UnsafeCell`-en belüli adatokhoz, amíg a hivatkozás le nem jár.
///
/// - Mindig kerülnie kell az adatversenyeket.Ha több szál fér hozzá ugyanahhoz az `UnsafeCell`-hez, akkor minden írásnak megfelelő történés előtt kell lennie az összes többi hozzáféréshez (vagy atomokat kell használnia).
///
/// A megfelelő tervezés elősegítése érdekében a következő forgatókönyveket kifejezetten jogszerűnek nyilvánítják az egyszálú kódok esetében:
///
/// 1. Az `&T` hivatkozás feloldható a biztonságos kódra, és ott létezhet más `&T` referenciákkal, de nem az `&mut T` kóddal
///
/// 2. Az `&mut T` hivatkozás kiadható a biztonságos kódra, feltéve, hogy más `&mut T` és `&T` nem létezik együtt vele.Az `&mut T`-nek mindig egyedinek kell lennie.
///
/// Megjegyezzük, hogy bár az `&UnsafeCell<T>` tartalmának mutációja (még akkor is, ha más `&UnsafeCell<T>` hivatkozások álneve a cella) rendben van (feltéve, hogy a fenti invariantusokat valamilyen más módon érvényesíti), továbbra is meghatározatlan viselkedés, ha több `&mut UnsafeCell<T>` álnév van.
/// Vagyis az `UnsafeCell` egy burkoló, amelyet arra terveztek, hogy különleges interakcióba lépjen az _shared_ accesses (_i.e._-szel, egy `&UnsafeCell<_>` referencián keresztül);nincs semmi varázslat az _exclusive_ accesses (_e.g._ használatakor, egy `&mut UnsafeCell<_>`-en keresztül): sem a cella, sem a becsomagolt érték nem lehet álneves az adott `&mut`-kölcsönzés időtartama alatt.
///
/// Ezt az [`.get_mut()`] hozzáférés mutatja be, amely egy _safe_ getter, amely `&mut T`-et eredményez.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Itt van egy példa, amely bemutatja, hogyan lehet alaposan megmutatni az `UnsafeCell<_>` tartalmát, annak ellenére, hogy több hivatkozás is álnevezi a cellát:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Több/egyidejű/megosztott hivatkozást kaphat ugyanarra az `x`-re.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // BIZTONSÁG: ebben a körben nincs más utalás az `x 'tartalmára,
///     // tehát a miénk gyakorlatilag egyedülálló.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- kölcsön-+
///     *p1_exclusive += 27; // |
/// } // <---------- nem léphet túl ezen a ponton -------------------+
///
/// unsafe {
///     // BIZTONSÁG: ebben a körben senki nem várja, hogy kizárólagos hozzáféréssel rendelkezzen az x tartalmaihoz,
///     // így egyszerre több megosztott hozzáférésünk lehet.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// A következő példa azt a tényt mutatja be, hogy az `UnsafeCell<T>` kizárólagos hozzáférése magában foglalja az `T` kizárólagos hozzáférését is:
///
/// ```rust
/// #![forbid(unsafe_code)] // exkluzív hozzáférésekkel,
///                         // `UnsafeCell` egy átlátszó opció nélküli burkoló, ezért nincs szükség `unsafe`-re.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Kap egy fordítási idő által ellenőrzött egyedi hivatkozást az `x`-re.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Kizárólagos hivatkozással ingyen módosíthatjuk a tartalmat.
/// *p_unique.get_mut() = 0;
/// // Vagy egyenértékűen:
/// x = UnsafeCell::new(0);
///
/// // Amikor birtokoljuk az értéket, ingyen kinyerhetjük a tartalmat.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Új `UnsafeCell` példányt készít, amely beburkolja a megadott értéket.
    ///
    ///
    /// A belső értékhez a módszerekkel való minden hozzáférés `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Kicsomagolja az értéket.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Megváltoztatható mutatót kap a becsomagolt értékre.
    ///
    /// Ez bármilyen mutatóra átdobható.
    /// Győződjön meg arról, hogy a hozzáférés egyedi (nincs aktív hivatkozás, módosítható vagy sem) az `&mut T`-re történő átküldéskor, és győződjön meg arról, hogy az `&T`-re történő átküldés során nincsenek mutációk vagy megváltoztatható álnevek
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Csak át tudjuk vetni a mutatót `UnsafeCell<T>`-ről `T`-re az #[repr(transparent)] miatt.
        // Ez kihasználja a libstd speciális állapotát, nincs garancia a felhasználói kódra, hogy ez a fordító future verzióiban működni fog!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Változtatható hivatkozást ad vissza az alapul szolgáló adatokra.
    ///
    /// Ez a hívás kölcsönösen kölcsönadja az `UnsafeCell`-et (fordítási időben), ami garantálja, hogy mi rendelkezünk az egyetlen referenciával.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Megváltoztatható mutatót kap a becsomagolt értékre.
    /// Az [`get`]-hez képest az a különbség, hogy ez a függvény elfogad egy nyers mutatót, amely hasznos az ideiglenes hivatkozások létrehozásának elkerülése érdekében.
    ///
    /// Az eredmény bármilyen mutatóra leadható.
    /// Győződjön meg arról, hogy a hozzáférés egyedi (nincsenek aktív hivatkozások, módosítható vagy sem) az `&mut T`-re történő átküldéskor, és győződjön meg arról, hogy az `&T`-re történő átküldés során nincsenek mutációk vagy megváltoztatható álnevek.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Az `UnsafeCell` fokozatos inicializálásához `raw_get` szükséges, mivel az `get` hívásához hivatkozást kell létrehozni az inicializálatlan adatokra:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Csak át tudjuk vetni a mutatót `UnsafeCell<T>`-ről `T`-re az #[repr(transparent)] miatt.
        // Ez kihasználja a libstd speciális állapotát, nincs garancia a felhasználói kódra, hogy ez a fordító future verzióiban működni fog!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Létrehoz egy `UnsafeCell`-et, a T `Default` értékével.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}