//! Meghatározza az `IntoIter` tulajdonában lévő iterátort a tömbökhöz.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Mértékértékű [array] iterátor.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Ez az a tömb, amelyen iterálunk.
    ///
    /// Az `i` indexű elemeket, ahol az `alive.start <= i < alive.end` még nem adták meg, és érvényesek tömbbejegyzések.
    /// Az `i < alive.start` vagy `i >= alive.end` indexű elemeket már megadtuk, és már nem lehet hozzájuk férni!Azok a holt elemek akár teljesen inicializálatlan állapotban lehetnek!
    ///
    ///
    /// Tehát az invariánsok a következők:
    /// - `data[alive]` életben van (azaz érvényes elemeket tartalmaz)
    /// - `data[..alive.start]` és az `data[alive.end..]` meghalt (azaz az elemeket már elolvasták, és már nem szabad hozzájuk nyúlni!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Az `data`-ben még nem kapott elemek.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Új iterátort hoz létre az adott `array` felett.
    ///
    /// *Megjegyzés*: Ez a módszer az [`IntoIterator` is implemented for arrays][array-into-iter] után elavult lehet a future alkalmazásban.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Az `value` típusa itt `i32`, az `&i32` helyett
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // BIZTONSÁG: A transzmutáció itt valóban biztonságos.Az `MaybeUninit` dokumentumai
        // promise:
        //
        // > `MaybeUninit<T>` garantáltan azonos méretű és igazítású lesz
        // > mint `T`.
        //
        // A dokumentumok még az `MaybeUninit<T>` tömbből az `T` tömbbe történő átváltást mutatják.
        //
        //
        // Ezzel ez az inicializálás kielégíti az invariánsokat.

        // FIXME(LukasKalbertodt): itt használja az `mem::transmute`-et, ha már működik az const generikusokkal:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Addig az `mem::transmute_copy` segítségével létrehozhatunk bitenként másolatot más típusként, majd elfelejtjük az `array`-et, hogy ne essen el.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Visszaadhatatlan szeletet ad vissza az összes elemről, amelyet még nem hoztak létre.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // BIZTONSÁG: Tudjuk, hogy az `alive` összes elemét megfelelően inicializálták.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Visszaadható szeletet ad vissza az összes olyan elemről, amely még nem volt előállítva.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // BIZTONSÁG: Tudjuk, hogy az `alive` összes elemét megfelelően inicializálták.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Szerezd meg a következő indexet elölről.
        //
        // Az `alive.start` 1-gyel történő növelése fenntartja az `alive` változatlan változatát.
        // Ennek a változásnak köszönhetően azonban rövid ideig az élő zóna már nem az `data[alive]`, hanem az `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Olvassa el a tömb elemét.
            // BIZTONSÁG: Az `idx` egy index a X "alive" X korábbi régiójába
            // sor.Ennek az elemnek az elolvasása azt jelenti, hogy az `data[idx]`-et most halottnak tekintik (azaz ne érintse meg).
            // Mivel az `idx` volt az élő zóna kezdete, az élő zóna most ismét `data[alive]`, helyreállítva az összes invariantust.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Szerezze be a következő indexet hátulról.
        //
        // Az `alive.end` 1-es csökkentése fenntartja az `alive` változatlan változatát.
        // Ennek a változásnak köszönhetően azonban rövid ideig az élő zóna már nem az `data[alive]`, hanem az `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Olvassa el a tömb elemét.
            // BIZTONSÁG: Az `idx` egy index a X "alive" X korábbi régiójába
            // sor.Ennek az elemnek az elolvasása azt jelenti, hogy az `data[idx]`-et most halottnak tekintik (azaz ne érintse meg).
            // Mivel az `idx` az élő zóna vége volt, az élő zóna most ismét `data[alive]`, helyreállítva az összes invariantust.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // BIZTONSÁG: Ez biztonságos: az `as_mut_slice` pontosan visszaadja az alszeletet
        // olyan elemek közül, amelyeket még nem mozdítottak el, és amelyeket még el kell dobni.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Soha nem fog alulcsordulni az invariáns `életben.start <=miatt
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Az iterátor valóban a helyes hosszról számol be.
// Az "alive" elemek száma (amelyeket továbbra is megkapunk) az `alive` tartomány hossza.
// Ennek a tartománynak a hosszát csökkentik `next` vagy `next_back` formátumban.
// Ezekben a módszerekben mindig csökkentik 1-vel, de csak akkor, ha az `Some(_)` értéket adják vissza.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Ne feledje, hogy valójában nem kell pontosan megegyeznünk ugyanazzal az élettartammal, így egyszerűen klónozhatunk a 0 eltolásba, függetlenül az `self` helyétől.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Klónozzon minden élő elemet.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Írjon be egy klónt az új tömbbe, majd frissítse az élő tartományát.
            // A panics klónozása esetén helyesen dobjuk el az előző elemeket.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Csak azokat az elemeket nyomtassa ki, amelyek még nem lettek előállítva: többé nem férhetünk hozzá.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}