use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Ez a trait tranzit hozzáférést biztosít a forrás-szakaszhoz egy interátor-adapter csővezetékben, olyan feltételek mellett
/// * maga az `S` iterátorforrás valósítja meg az `SourceIter<Source = S>`-et
/// * ennek a trait-nek delegált megvalósítása van a csővezeték minden egyes adapteréhez a forrás és a vezeték fogyasztója között.
///
/// Ha a forrás egy iterátor struktúra tulajdonosa (általában `IntoIter` néven szerepel), akkor ez hasznos lehet az [`FromIterator`] implementációk specializálására vagy a fennmaradó elemek helyreállítására az iterátor részleges kimerülése után.
///
///
/// Vegye figyelembe, hogy a megvalósításoknak nem feltétlenül kell hozzáférést biztosítaniuk a csővezeték legbelső forrásához.Egy állapotos közbenső adapter lelkesen értékelheti a csővezeték egy részét, és annak belső tárhelyét tárhatja forrásként.
///
/// A trait nem biztonságos, mert a kivitelezőknek további biztonsági tulajdonságokat kell fenntartaniuk.
/// További részletek: [`as_inner`].
///
/// # Examples
///
/// Részben elfogyasztott forrás lekérdezése:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Forrás szakasz egy iterátor folyamatban.
    type Source: Iterator;

    /// Keresse meg az iterátor-folyamat forrását.
    ///
    /// # Safety
    ///
    /// A implementációknak ugyanazt a mutábilis referenciát kell visszaadniuk életük során, hacsak nem helyettesíti őket a hívó.
    /// A hívók csak akkor cserélhetik ki a referenciát, ha leállítják az iterációt és ledobják az iterátor csővezetékét a forrás kibontása után.
    ///
    /// Ez azt jelenti, hogy az iterátor adapterek támaszkodhatnak arra, hogy a forrás az iteráció során nem változik, de a Drop implementációikban nem támaszkodhatnak rá.
    ///
    /// Ennek a módszernek a megvalósítása azt jelenti, hogy az adapterek lemondanak a magánjellegű hozzáférésről a forrásukhoz, és csak a módszer vevő típusai alapján nyújtott garanciákra támaszkodhatnak.
    /// A korlátozott hozzáférés hiánya azt is megköveteli, hogy az illesztőknek akkor is fenntartaniuk kell a forrás nyilvános API-ját, ha hozzáférnek a belső eszközhöz.
    ///
    /// A hívóknak viszont azt kell elvárniuk, hogy a forrás bármely olyan állapotban legyen, amely összhangban áll a nyilvános API-val, mivel a közte és a forrás között ülő adapterek ugyanolyan hozzáféréssel rendelkeznek.
    /// Különösen az adapter több elemet fogyaszthatott, mint ami feltétlenül szükséges.
    ///
    /// Ezeknek a követelményeknek az az általános célja, hogy lehetővé tegye a fogyasztók számára a csővezeték használatát
    /// * ami az iteráció leállítása után a forrásban marad
    /// * a fogyasztó iterátor előrehaladásával használhatatlanná vált memória
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Egy iterátor adapter, amely mindaddig produkál kimenetet, amíg az alatta lévő iterátor `Result::Ok` értékeket produkál.
///
///
/// Hiba esetén az iterátor leáll, és a hiba tárolódik.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Feldolgozza az adott iterátort, mintha `Result<T, _>` helyett `T`-et kapott volna.
/// Bármely hiba megállítja a belső iterátort, és az összeredmény hiba lesz.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}