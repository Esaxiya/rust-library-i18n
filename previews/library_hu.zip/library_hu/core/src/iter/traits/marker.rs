/// Olyan iterátor, amely mindig kimerülve adja tovább az `None`-et.
///
/// A következő hívás az `None` egyszer visszakapott egyesített iterátoron garantáltan ismét visszatér az [`None`]-hez.
/// Ezt a trait-t minden iterátornak végre kell hajtania, aki így viselkedik, mert lehetővé teszi az [`Iterator::fuse()`] optimalizálását.
///
///
/// Note: Általában nem szabad az `FusedIterator`-et általános korlátok között használni, ha összevont iterátorra van szüksége.
/// Ehelyett csak az [`Iterator::fuse()`]-et kell hívnia az iterátoron.
/// Ha az iterátor már összeolvadt, akkor a további [`Fuse`] burkoló nem használható, teljesítménybüntetés nélkül.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Iterátor, amely pontos méretet jelent a size_hint használatával.
///
/// Az iterátor egy méretre utal, ahol vagy pontos (az alsó határ megegyezik a felső határral), vagy a felső határ [`None`].
///
/// A felső határ csak akkor lehet [`None`], ha az iterátor tényleges hossza nagyobb, mint [`usize::MAX`].
/// Ebben az esetben az alsó határnak [`usize::MAX`]-nek kell lennie, aminek eredményeként [`Iterator::size_hint()`] [`Iterator::size_hint()`] lesz.
///
/// Az iterátornak pontosan annyi elemet kell előállítania, amiről beszámolt, vagy el kell térnie a vége előtt.
///
/// # Safety
///
/// Ezt a trait-t csak a szerződés fenntartása mellett szabad végrehajtani.
/// A trait fogyasztóinak meg kell vizsgálniuk az [`Iterator::size_hint()`]’s felső határát.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Olyan iterátor, amely egy tétel előállításakor legalább egy elemet kivett az alapul szolgáló [`SourceIter`]-ből.
///
/// Bármely olyan módszer meghívása, amely elősegíti az iterátort, pl
/// [`next()`] vagy [`try_fold()`], garantálja, hogy minden lépésnél az iterátor mögöttes forrásából legalább egy értéket elmozdítottak, és az iterátorlánc eredménye beilleszthető a helyére, feltételezve, hogy a forrás strukturális korlátai lehetővé teszik az ilyen beillesztést.
///
/// Más szavakkal, ez a trait azt jelzi, hogy az iterátor csővezeték a helyén összegyűjthető.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}