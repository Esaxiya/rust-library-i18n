use crate::ops::{ControlFlow, Try};

/// Iterátor, amely mindkét oldalról képes elemeket előállítani.
///
/// Valaminek, ami az `DoubleEndedIterator`-et megvalósítja, van egy extra képessége az [`Iterator`]-et megvalósítóval szemben: képes az `Item`-eket hátulról és elölről is elvinni.
///
///
/// Fontos megjegyezni, hogy mind az oda-vissza ugyanazon a tartományon dolgoznak, és nem keresztezik egymást: az iteráció véget ér, amikor középen találkoznak.
///
/// Az [`Iterator`] protokollhoz hasonló módon, ha egy `DoubleEndedIterator` visszaadja az [`None`]-et egy [`next_back()`]-ből, akkor újból hívva az [`Some`]-et visszaadhatja.
/// [`next()`] és az [`next_back()`] felcserélhetők erre a célra.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Alapvető használat:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Eltávolít és visszaad egy elemet az iterátor végéből.
    ///
    /// `None` értéket ad vissza, ha nincs több elem.
    ///
    /// Az [trait-level] dokumentumok további részleteket tartalmaznak.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// A "DoubleEndedIterator" módszereivel kapott elemek eltérhetnek az ["Iterator"] módszereitől:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Az iterátort hátulról `n` elemekkel mozgatja.
    ///
    /// `advance_back_by` az [`advance_by`] fordított változata.Ez a módszer lelkesen hagyja ki az `n` elemeket hátulról, az [`next_back`] hívásával `n`-szeresig, amíg az [`None`]-t észleli.
    ///
    /// `advance_back_by(n)` visszaadja az [`Ok(())`] értéket, ha az iterátor sikeresen halad előre az `n` elemekkel, vagy [`Err(k)`], ha az [`None`] felmerül, ahol `k` az elemek száma, amelyekkel az iterátor továbbhalad, mielőtt elfogyna az elemek (azaz
    /// az iterátor hossza).
    /// Vegye figyelembe, hogy az `k` mindig kisebb, mint az `n`.
    ///
    /// Az `advance_back_by(0)` hívása nem fogyaszt elemeket, és mindig az [`Ok(())`] értéket adja vissza.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // csak az `&3`-et hagyta ki
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Visszaadja az iterátor végéből az n-edik elemet.
    ///
    /// Ez lényegében az [`Iterator::nth()`] fordított változata.
    /// Bár a legtöbb indexelési művelethez hasonlóan, a számlálás nullától indul, így az `nth_back(0)` visszaadja az első értéket a végétől, az `nth_back(1)` a másodikat, és így tovább.
    ///
    ///
    /// Vegye figyelembe, hogy a vég és a visszaküldött elem közötti összes elem el lesz fogyasztva, beleértve a visszaküldött elemet is.
    /// Ez azt is jelenti, hogy az `nth_back(0)` többszöri meghívása ugyanazon iterátoron különböző elemeket ad vissza.
    ///
    /// `nth_back()` akkor adja vissza az [`None`] értéket, ha az `n` nagyobb vagy egyenlő az iterátor hosszával.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Az `nth_back()` többszöri felhívása nem tekeri vissza az iterátort:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Visszatérő `None`, ha kevesebb mint `n + 1` elem van:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Ez az [`Iterator::try_fold()`] fordított változata: az elemeket az iterátor hátuljától kezdve veszi fel.
    ///
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Mivel rövidre záródott, a fennmaradó elemek továbbra is elérhetők az iterátoron keresztül.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Olyan iterációs módszer, amely az iterátor elemeit egyetlen, végső értékre redukálja, hátulról indulva.
    ///
    /// Ez az [`Iterator::fold()`] fordított változata: az elemeket az iterátor hátuljától kezdve veszi fel.
    ///
    /// `rfold()` két érvet vesz fel: egy kezdeti értéket és egy lezárást két argumentummal: egy 'accumulator' és egy elem.
    /// A lezárás azt az értéket adja vissza, amely az akkumulátornak rendelkeznie kell a következő iterációval.
    ///
    /// A kezdeti érték az az érték, amelyet az akkumulátor az első híváskor megkap.
    ///
    /// Miután ezt a zárót alkalmazta az iterátor minden elemére, az `rfold()` visszaadja az akkumulátort.
    ///
    /// Ezt a műveletet néha 'reduce'-nek vagy 'inject'-nek hívják.
    ///
    /// A hajtogatás akkor hasznos, ha van valaminek gyűjteménye, és egyetlen értéket szeretne előállítani belőle.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // az a összes elemének összege
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Ez a példa felépít egy karaktersorozatot, kezdő értékkel kezdve, és minden elemmel folytatva hátulról előre:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Egy iterátor elemét keresi hátulról, amely kielégít egy állítmányt.
    ///
    /// `rfind()` lezárást kap, amely `true` vagy `false` értéket ad vissza.
    /// Ezt a zárást alkalmazza az iterátor minden elemére, kezdve a végétől, és ha bármelyikük visszaadja az `true` értéket, akkor az `rfind()` az [`Some(element)`] értéket adja vissza.
    /// Ha valamennyien visszaadják az `false`-et, akkor az [`None`]-et ad vissza.
    ///
    /// `rfind()` rövidzárlatos;más szóval, leállítja a feldolgozást, amint a bezárás visszaadja az `true`-et.
    ///
    /// Mivel az `rfind()` referenciát vesz fel, és sok iterátor ismétli a referenciákat, ez egy esetleges zavaros helyzethez vezet, ahol az argumentum kettős hivatkozás.
    ///
    /// Ezt a hatást az alábbi példákban láthatja, az `&&x` használatával.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Megállás az első `true`-nél:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // továbbra is használhatjuk az `iter`-et, mivel több elem van.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}