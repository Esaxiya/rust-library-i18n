/// Pontos hosszát ismerő iterátor.
///
/// Sok [`Iterator`] nem tudja, hányszor fognak iterálni, de vannak, akik igen.
/// Ha egy iterátor tudja, hányszor tud ismétlődni, akkor hasznos lehet az információhoz való hozzáférés biztosítása.
/// Például, ha visszafelé akarunk iterálni, akkor jó kezdet az, ha megtudjuk, hol a vége.
///
/// Az `ExactSizeIterator` implementálásakor az [`Iterator`]-et is végre kell hajtania.
/// Ennek során az [`Iterator::size_hint`]*megvalósításának* vissza kell adnia az iterátor pontos méretét.
///
/// Az [`len`] módszer alapértelmezett megvalósítással rendelkezik, ezért általában nem szabad végrehajtania.
/// Lehetséges azonban, hogy az alapértelmezettnél jobban teljesítő megvalósítást tud biztosítani, ezért ebben az esetben van értelme felülírni.
///
///
/// Ne feledje, hogy ez a trait biztonságos trait, és mint ilyen *nem* és *nem* garantálja a megfelelő hosszúságot.
/// Ez azt jelenti, hogy az `unsafe` kód ** nem támaszkodhat az [`Iterator::size_hint`] helyességére.
/// Az instabil és nem biztonságos [`TrustedLen`](super::marker::TrustedLen) trait biztosítja ezt a további garanciát.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Alapvető használat:
///
/// ```
/// // egy véges tartomány pontosan tudja, hányszor fog ismétlődni
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Az [module-level docs]-ben megvalósítottunk egy [`Iterator`]-et, `Counter`.
/// Vezessük be az `ExactSizeIterator`-et is:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Könnyen kiszámíthatjuk a fennmaradó iterációk számát.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // És most már használhatjuk!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Visszaadja az iterátor pontos hosszát.
    ///
    /// A megvalósítás biztosítja, hogy az iterátor pontosan `len()`-rel tér vissza az [`Some(T)`] értékhez képest, mielőtt visszaküldi az [`None`] értéket.
    ///
    /// Ennek a módszernek alapértelmezett megvalósítása van, ezért általában nem közvetlenül kell végrehajtania.
    /// Ha azonban hatékonyabb megvalósítást tud biztosítani, akkor megteheti.
    /// Lásd az [trait-level] dokumentumok példáját.
    ///
    /// Ez a funkció ugyanazokkal a biztonsági garanciákkal rendelkezik, mint az [`Iterator::size_hint`] funkció.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// // egy véges tartomány pontosan tudja, hányszor fog ismétlődni
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Ez az állítás túlságosan védekező, de ellenőrzi az invariánst
        // garantálja a trait.
        // Ha ez a trait rust-belső lenne, használhatnánk a debug_assert !;assert_eq!az összes Rust felhasználói megvalósítást is ellenőrzi.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Az `true` értéket adja vissza, ha az iterátor üres.
    ///
    /// Ennek a módszernek alapértelmezett megvalósítása van az [`ExactSizeIterator::len()`] használatával, így Önnek nem kell ezt végrehajtania.
    ///
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}