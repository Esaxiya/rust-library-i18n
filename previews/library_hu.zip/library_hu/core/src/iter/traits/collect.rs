/// Konvertálás [`Iterator`]-ből.
///
/// Az `FromIterator` implementálásával egy típushoz meghatározhatja, hogyan fog létrehozni egy iterátorból.
/// Ez jellemző azokra a típusokra, amelyek valamilyen gyűjteményt írnak le.
///
/// [`FromIterator::from_iter()`] ritkán hívják kifejezetten, és ehelyett [`Iterator::collect()`] módszerrel használják.
///
/// További példákat az [`Iterator::collect()`]'s dokumentációjában talál.
///
/// Lásd még: [`IntoIterator`].
///
/// # Examples
///
/// Alapvető használat:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Az [`Iterator::collect()`] használata az `FromIterator` implicit használatához:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Az `FromIterator` bevezetése az Ön típusához:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Mintagyűjtemény, ez csak egy csomagolás a Vec felett<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Adjunk neki néhány módszert, így létrehozhatunk egyet, és hozzáadhatunk hozzá dolgokat.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // és megvalósítjuk a FromIterator programot
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Most új iterátort készíthetünk ...
/// let iter = (0..5).into_iter();
///
/// // ... és készíts belőle MyCollection-t
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // gyűjtsön műveket is!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Értéket hoz létre egy iterátorból.
    ///
    /// További információkért lásd az [module-level documentation]-et.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Átalakítás [`Iterator`]-be.
///
/// Az `IntoIterator` implementálásával egy típushoz meghatározhatja, hogyan fog konvertálni iterátorrá.
/// Ez jellemző azokra a típusokra, amelyek valamilyen gyűjteményt írnak le.
///
/// Az `IntoIterator` megvalósításának egyik előnye, hogy a típusod [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) lesz.
///
///
/// Lásd még: [`FromIterator`].
///
/// # Examples
///
/// Alapvető használat:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Az `IntoIterator` bevezetése az Ön típusához:
///
/// ```
/// // Mintagyűjtemény, ez csak egy csomagolás a Vec felett<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Adjunk neki néhány módszert, így létrehozhatunk egyet, és hozzáadhatunk hozzá dolgokat.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // és megvalósítjuk az IntoIterator programot
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Most új kollekciót készíthetünk ...
/// let mut c = MyCollection::new();
///
/// // ... adj hozzá néhány cuccot ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... majd fordítsd Iterátorra:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Általános az `IntoIterator` használata trait bound néven.Ez lehetővé teszi a bemeneti gyűjtemény típusának megváltoztatását, feltéve, hogy még mindig iterátor.
/// További korlátokat lehet megadni a korlátozással
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Az ismételt elemek típusa.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Melyik iterátorrá változtatjuk ezt?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Iterátort hoz létre egy értékből.
    ///
    /// További információkért lásd az [module-level documentation]-et.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Bővítsen egy gyűjteményt egy iterátor tartalmával.
///
/// Az iterátorok értékek sorozatát állítják elő, és a gyűjtemények értékek sorozataként is felfoghatók.
/// Az `Extend` trait áthidalja ezt a rést, lehetővé téve a gyűjtemény bővítését az iterátor tartalmának beépítésével.
/// Ha egy gyűjteményt már meglévő kulccsal bővítenek, akkor a bejegyzés frissül, vagy olyan gyűjtemények esetén, amelyek több bejegyzést engedélyeznek azonos kulcsokkal, a bejegyzés beillesztésre kerül.
///
///
/// # Examples
///
/// Alapvető használat:
///
/// ```
/// // A karakterláncot kiterjesztheti néhány karakterrel:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Az `Extend` megvalósítása:
///
/// ```
/// // Mintagyűjtemény, ez csak egy csomagolás a Vec felett<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Adjunk neki néhány módszert, így létrehozhatunk egyet, és hozzáadhatunk hozzá dolgokat.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // mivel a MyCollection rendelkezik egy i32 listával, megvalósítjuk az Extend for i32 alkalmazást
/// impl Extend<i32> for MyCollection {
///
///     // Ez egy kicsit egyszerűbb a konkrét típusú aláírással: bármit meghívhatunk, amit Iterator-vá lehet alakítani, ami i32-eket ad nekünk.
///     // Mert i32-ekre van szükségünk a MyCollection alkalmazásba.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // A megvalósítás nagyon egyszerű: hurkolja át az iterátort, és add() minden elemet önmagunknak.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // bővítsük gyűjteményünket még három számmal
/// c.extend(vec![1, 2, 3]);
///
/// // ezeket az elemeket a végére adtuk
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Kiterjeszt egy gyűjteményt egy iterátor tartalmával.
    ///
    /// Mivel ez az egyetlen szükséges módszer ehhez a trait-hez, az [trait-level] dokumentumok további részleteket tartalmaznak.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// // A karakterláncot kiterjesztheti néhány karakterrel:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Pontosan egy elemmel bővíti a gyűjteményt.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Az adott számú további elem számára fenntart egy kapacitást egy gyűjteményben.
    ///
    /// Az alapértelmezett megvalósítás nem tesz semmit.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}