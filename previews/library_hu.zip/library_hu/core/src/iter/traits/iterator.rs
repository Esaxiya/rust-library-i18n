// ignore-tidy-filelength Ez a fájl szinte kizárólag az `Iterator` meghatározásából áll.
// Ezt nem oszthatjuk fel több fájlra.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Felület az iterátorok kezeléséhez.
///
/// Ez a fő iterátor trait.
/// Az iterátorok fogalmával kapcsolatos további információkért kérjük, olvassa el az [module-level documentation] készüléket.
/// Különösen érdemes tudni, hogyan kell [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Az ismételt elemek típusa.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Lépteti az iterátort, és visszaadja a következő értéket.
    ///
    /// Az iteráció befejezése után az [`None`] értéket adja vissza.
    /// Az egyes iterátor megvalósítások dönthetnek úgy, hogy folytatják az iterációt, és így az `next()` újbóli hívása egy bizonyos ponton végül megkezdheti az [`Some(Item)`] visszatérését.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Az next() hívása visszaadja a következő értéket ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... és akkor nincs, ha vége.
    /// assert_eq!(None, iter.next());
    ///
    /// // Több hívás visszajuttathatja az `None`-et vagy nem.Itt mindig lesz.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Visszaadja az iterátor hátralévő hosszának határait.
    ///
    /// Pontosabban, az `size_hint()` egy duplát ad vissza, ahol az első elem az alsó, a második a felső határ.
    ///
    /// A visszaküldött második fél fele egy ["opció"] <<[[`usize`]`>`.
    /// Az [`None`] itt azt jelenti, hogy vagy nincs ismert felső határ, vagy pedig a felső határ nagyobb, mint [`usize`].
    ///
    /// # Végrehajtási megjegyzések
    ///
    /// Nincs kikényszerítve, hogy egy iterátor megvalósítás megadja a deklarált számú elemet.A hibás iterátor kevesebbet eredményezhet, mint az elemek alsó határa, vagy több, mint az elemek felső határa.
    ///
    /// `size_hint()` elsősorban optimalizálásra szolgál, például helyfoglalás az iterátor elemeinek számára, de nem szabad megbízni benne, hogy például a nem biztonságos kódban elhagyják a határellenőrzéseket.
    /// Az `size_hint()` helytelen végrehajtása nem vezethet memóriabiztonsági megsértésekhez.
    ///
    /// Ennek ellenére a megvalósításnak helyes becslést kell szolgáltatnia, mert különben a trait protokolljának megsértését jelentené.
    ///
    /// Az alapértelmezett megvalósítás a ((0, `[None`]`)`) értéket adja vissza, amely bármely iterátor esetében helyes.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Összetettebb példa:
    ///
    /// ```
    /// // A páros számok nullától tízig.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Lehet, hogy nulláról tízszer iterálunk.
    /// // Annak ismerete, hogy pontosan öt, az filter() végrehajtása nélkül nem lehetséges.
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Adjunk hozzá még öt számot az chain() segítségével
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // most mindkét hatöt megnövelték
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Az `None` visszaküldése egy felső határértékre:
    ///
    /// ```
    /// // egy végtelen iterátornak nincs felső határa és a lehető legnagyobb alsó határa
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Fogyasztja az iterátort, megszámolja az iterációk számát és visszaadja.
    ///
    /// Ez a módszer addig hívja az [`next`]-et, amíg az [`None`]-be nem ütközik, visszaadva az [`Some`]-es látások számát.
    /// Vegye figyelembe, hogy az [`next`]-et legalább egyszer meg kell hívni, még akkor is, ha az iterátornak nincsenek elemei.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Túlcsorduló viselkedés
    ///
    /// A módszer nem véd a túlcsordulások ellen, ezért az [`usize::MAX`]-nél több elemet tartalmazó iterátor elemeinek megszámlálása vagy rossz eredményt ad, vagy panics.
    ///
    /// Ha a hibakeresés engedélyezve van, akkor a panic garantált.
    ///
    /// # Panics
    ///
    /// Ez a függvény panic lehet, ha az iterátornak több mint [`usize::MAX`] eleme van.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Fogyasztja az iterátort, visszaadva az utolsó elemet.
    ///
    /// Ez a módszer addig értékeli az iterátort, amíg vissza nem adja az [`None`] értéket.
    /// Ennek során nyomon követi az aktuális elemet.
    /// Az [`None`] visszaadása után az `last()` visszaadja az utoljára látott elemet.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Az iterátort `n` elemekkel haladja meg.
    ///
    /// Ez a módszer lelkesen hagyja ki az `n` elemeket azáltal, hogy az [`next`]-et legfeljebb `n`-ig hívja, amíg az [`None`]-t meg nem találja.
    ///
    /// `advance_by(n)` visszaadja az [`Ok(())`][Ok] értéket, ha az iterátor sikeresen halad előre az `n` elemekkel, vagy [`Err(k)`][Err], ha az [`None`] felmerül, ahol `k` az elemek száma, amelyekkel az iterátor továbbhalad, mielőtt elfogyna az elemek (azaz
    /// az iterátor hossza).
    /// Vegye figyelembe, hogy az `k` mindig kisebb, mint az `n`.
    ///
    /// Az `advance_by(0)` hívása nem fogyaszt elemeket, és mindig az [`Ok(())`][Ok] értéket adja vissza.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // csak az `&4`-et hagyta ki
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Visszaadja az iterátor n-edik elemét.
    ///
    /// A legtöbb indexelési művelethez hasonlóan a számlálás is nullától indul, így az `nth(0)` adja vissza az első értéket, az `nth(1)` a másodikat stb.
    ///
    /// Vegye figyelembe, hogy az összes előző elem, valamint a visszaküldött elem az iterátorból kerül felhasználásra.
    /// Ez azt jelenti, hogy az előző elemeket elvetjük, és azt is, hogy az `nth(0)` többszöri meghívása ugyanazon az iterátoron különböző elemeket ad vissza.
    ///
    ///
    /// `nth()` akkor adja vissza az [`None`] értéket, ha az `n` nagyobb vagy egyenlő az iterátor hosszával.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Az `nth()` többszöri felhívása nem tekeri vissza az iterátort:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Visszatérő `None`, ha kevesebb mint `n + 1` elem van:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Létrehoz egy iterátort, amely ugyanabban a pontban kezdődik, de az egyes iterációknál lépeget a megadott összeggel.
    ///
    /// 1. megjegyzés: Az iterátor első eleme mindig adott, függetlenül a megadott lépéstől.
    ///
    /// 2. megjegyzés: A figyelmen kívül hagyott elemek behúzásának ideje nincs rögzítve.
    /// `StepBy` úgy viselkedik, mint az `next(), nth(step-1), nth(step-1),…` szekvencia, de szabadon viselkedhet, mint a szekvencia
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Az alkalmazott módszer megváltozhat néhány iterátor esetében teljesítmény okokból.
    /// A második út előbbrehozza az iterátort, és több elemet fogyaszthat.
    ///
    /// `advance_n_and_return_first` egyenértékű:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// A módszer panic lesz, ha az adott lépés `0`.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Két ismétlőt vesz fel, és egymás után új iterátort hoz létre.
    ///
    /// `chain()` új iterátort ad vissza, amely először az első iterátor értékeit, majd a második iterátor értékeit fogja megismételni.
    ///
    /// Más szavakkal, két iterátort kapcsol össze, egy láncban.🔗
    ///
    /// [`once`] általában arra használatos, hogy egyetlen értéket más típusú iteráció láncához igazítsanak.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Mivel az `chain()`-nek adott argumentum az [`IntoIterator`]-et használja, bármit átadhatunk, ami átalakítható [`Iterator`]-be, nem csak magát az [`Iterator`]-et.
    /// Például az (`&[T]`) szeletek megvalósítják az [`IntoIterator`]-et, és így közvetlenül átadhatók az `chain()`-nek:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ha az Windows API-val dolgozik, akkor érdemes átalakítani az [`OsStr`]-et `Vec<u16>`-be:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// Két iterátort egyetlen páros iterátorba zár össze.
    ///
    /// `zip()` új iterátort ad vissza, amely ismétlődik két másik iterátor felett, egy duplát ad vissza, ahol az első elem az első iterátorból származik, a második elem pedig a második iterátorból származik.
    ///
    ///
    /// Más szavakkal, két iterátort kapcsol össze egyetlen eggyé.
    ///
    /// Ha bármelyik iterátor visszaadja az [`None`] értéket, az [`next`] a csomagolt iterátorból az [`None`] értéket adja vissza.
    /// Ha az első iterátor visszaadja az [`None`] értéket, akkor az `zip` rövidzárlatot okoz, és az `next` nem lesz meghívva a második iterátoron.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Mivel az `zip()`-nek adott argumentum az [`IntoIterator`]-et használja, bármit átadhatunk, ami átalakítható [`Iterator`]-be, nem csak magát az [`Iterator`]-et.
    /// Például az (`&[T]`) szeletek megvalósítják az [`IntoIterator`]-et, és így közvetlenül átadhatók az `zip()`-nek:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` gyakran használják a végtelen iterátor végesre cipzározásához.
    /// Ez azért működik, mert a véges iterátor végül visszaadja az [`None`]-et, és véget vet a cipzárnak.Az `(0..)` segítségével történő cipzárolás nagyon hasonlíthat az [`enumerate`]-re:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Új iterátort hoz létre, amely az `separator` másolatát az eredeti iterátor szomszédos elemei közé helyezi.
    ///
    /// Abban az esetben, ha az `separator` nem valósítja meg az [`Clone`]-et, vagy minden alkalommal ki kell számítani, használja az [`intersperse_with`]-et.
    ///
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Az első elem az `a`-től.
    /// assert_eq!(a.next(), Some(&100)); // Az elválasztó.
    /// assert_eq!(a.next(), Some(&1));   // A következő elem az `a`-ből.
    /// assert_eq!(a.next(), Some(&100)); // Az elválasztó.
    /// assert_eq!(a.next(), Some(&2));   // Az utolsó elem az `a`-ből.
    /// assert_eq!(a.next(), None);       // Az iterátor elkészült.
    /// ```
    ///
    /// `intersperse` nagyon hasznos lehet egy iterátor tételeihez csatlakozni egy közös elem használatával:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Új iterátort hoz létre, amely az `separator` által generált elemet az eredeti iterátor szomszédos elemei közé helyezi.
    ///
    /// A lezárást pontosan egyszer hívják meg, amikor egy elemet az alapul szolgáló iterátor két szomszédos eleme közé helyeznek;
    /// konkrétan a lezárást nem hívják meg, ha az alapul szolgáló iterátor kevesebb, mint két elemet hoz, és az utolsó tétel után.
    ///
    ///
    /// Ha az iterátor tétele megvalósítja az [`Clone`]-et, akkor könnyebb lehet az [`intersperse`] használatát.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Az első elem az `v`-től.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Az elválasztó.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // A következő elem az `v`-ből.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Az elválasztó.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Az utolsó elem az `v`-től.
    /// assert_eq!(it.next(), None);               // Az iterátor elkészült.
    /// ```
    ///
    /// `intersperse_with` használható olyan helyzetekben, amikor az elválasztót ki kell számítani:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // A bezárás kölcsönösen kölcsönadja a kontextust egy tétel előállításához.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Zárást hajt végre, és létrehoz egy iterátort, amely az egyes elemeknél ezt a lezárást hívja meg.
    ///
    /// `map()` az egyik iterátort egy másiká alakítja az érvelése révén:
    /// valami, ami megvalósítja az [`FnMut`]-et.Új iterátort állít elő, amely ezt a zárást hívja az eredeti iterátor minden elemére.
    ///
    /// Ha jól gondolkodik a típusokban, akkor az `map()`-re így gondolhat:
    /// Ha van olyan iterátora, amely valamilyen `A` típusú elemeket ad meg, és valamilyen más típusú `B` iterátort szeretne, használhatja az `map()`-et, elhaladva egy lezárással, amely egy `A`-et vesz fel és egy `B`-et ad vissza.
    ///
    ///
    /// `map()` fogalmilag hasonló egy [`for`] hurokhoz.Mivel azonban az `map()` lusta, akkor a legjobban akkor használható, ha már más iterátorokkal dolgozik.
    /// Ha valamilyen hurkolást végez egy mellékhatás érdekében, akkor idiotikusabbnak tekinthető az [`for`] használata, mint az `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ha valamilyen mellékhatást végez, akkor inkább az [`for`] helyett az `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // ne ezt tedd:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // nem is fogja végrehajtani, mivel lusta.A Rust figyelmeztet erre.
    ///
    /// // Ehelyett használja:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Bezárást kér az iterátor minden elemére.
    ///
    /// Ez egyenértékű az [`for`] hurok használatával az iterátoron, bár az `break` és az `continue` nem lehetséges lezárásból.
    /// Általában idiotikusabb az `for` hurok használata, de az `for_each` olvashatóbb lehet, ha a cikkeket hosszabb iterátorláncok végén dolgozza fel.
    ///
    /// Bizonyos esetekben az `for_each` gyorsabb is lehet, mint egy hurok, mert belső iterációt fog használni az `Chain`-hez hasonló adaptereken.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Ilyen kis példánál az `for` hurok tisztább lehet, de az `for_each` előnyösebb lehet, ha hosszabb iterátorral működőképes stílust kíván megtartani:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Létrehoz egy iterátort, amely bezárást használ annak meghatározásához, hogy el kell-e adni egy elemet.
    ///
    /// Adott elem esetén a zárásnak vissza kell adnia `true` vagy `false` értéket.A visszaadott iterátor csak azokat az elemeket adja meg, amelyekre a lezárás igaz.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Mivel az `filter()`-nek átadott bezárás referenciát vesz igénybe, és sok iterátor ismétli a referenciákat, ez egy esetleges zavaros helyzethez vezet, ahol a lezárás típusa kettős hivatkozás:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // két * kell!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Gyakori, hogy az érvelésnél a destrukturálást használják az egyik eltávolításához:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // Mindkét és *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// vagy mindkettő:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // két &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ezeknek a rétegeknek.
    ///
    /// Vegye figyelembe, hogy az `iter.filter(f).next()` egyenértékű az `iter.find(f)` értékkel.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Létrehoz egy iterátort, amely egyszerre szűr és térképez.
    ///
    /// A visszaadott iterátor csak azokat az `értékeket 'adja meg, amelyekre a mellékelt zárás `Some(value)` értéket ad vissza.
    ///
    /// `filter_map` felhasználható az [`filter`] és [`map`] láncok tömörebbé tételéhez.
    /// Az alábbi példa bemutatja, hogyan lehet egy `map().filter().map()`-et rövidíteni egyetlen hívásként az `filter_map`-be.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Itt ugyanaz a példa, de az [`filter`] és az [`map`] esetében:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Létrehoz egy iterátort, amely megadja az aktuális iterációszámot, valamint a következő értéket.
    ///
    /// A visszaadott iterátor `(i, val)` párokat eredményez, ahol `i` az iteráció aktuális indexe, `val` pedig az iterátor által visszaadott érték.
    ///
    ///
    /// `enumerate()` [`usize`]-ként tartja meg a számát.
    /// Ha különböző méretű egész számmal szeretne számolni, az [`zip`] funkció hasonló funkciókat biztosít.
    ///
    /// # Túlcsorduló viselkedés
    ///
    /// A módszer nem véd a túlcsordulások ellen, így az [`usize::MAX`]-nél több elem felsorolása vagy rossz eredményt ad, vagy a panics-t.
    /// Ha a hibakeresés engedélyezve van, akkor a panic garantált.
    ///
    /// # Panics
    ///
    /// A visszaküldött iterátor panic lehet, ha a visszaadandó index túlcsordítja az [`usize`]-et.
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Létrehoz egy iterátort, amely az [`peek`] segítségével meg tudja nézni az iterátor következő elemét anélkül, hogy elfogyasztaná.
    ///
    /// [`peek`] metódust ad hozzá egy iterátorhoz.További információt a dokumentációjában talál.
    ///
    /// Ne feledje, hogy az alapul szolgáló iterátor még mindig fejlett, amikor az [`peek`]-et először hívják meg: A következő elem lekérése érdekében az [`next`]-et hívják az alapul szolgáló iterátorra, így minden mellékhatás (pl.
    ///
    /// az [`next`] módszer következő értékének lekérésén kívül bármi más bekövetkezik.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() betekinthetünk a future-be
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // peek()-et többször is elvégezhetjük, az iterátor nem halad előre
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // az iterátor befejezése után az peek() is
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Létrehoz egy iterátort, amely az állítmány alapján ["kihagyja"] az elemeket.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` érvelésként lezárást vesz fel.Az iterátor minden eleménél ezt a lezárást fogja hívni, és mindaddig figyelmen kívül hagyja az elemeket, amíg vissza nem adja az `false` értéket.
    ///
    /// Az `false` visszaadása után az `skip_while()`'s feladatnak vége, és a többi elem meg lesz adva.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Mivel az `skip_while()`-nek átadott bezárás referenciát vesz igénybe, és sok iterátor ismétli a referenciákat, ez egy esetleges zavaros helyzethez vezet, ahol a lezárási argumentum típusa kettős hivatkozás:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // két * kell!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Leállítás egy kezdeti `false` után:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // bár ez hamis lett volna, mivel már hamisat kaptunk, az skip_while()-et már nem használják
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Létrehoz egy iterátort, amely predikátum alapján hoz létre elemeket.
    ///
    /// `take_while()` érvelésként lezárást vesz fel.Az iterátor minden eleménél ezt a lezárást fogja hívni, és az `true` érték visszaadásakor hoz létre elemeket.
    ///
    /// Az `false` visszaadása után az `take_while()`'s feladatnak vége, és a többi elemet figyelmen kívül hagyja.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Mivel az `take_while()`-nek átadott bezárás referenciát vesz igénybe, és sok iterátor ismétli a referenciákat, ez egy esetleges zavaros helyzethez vezet, ahol a lezárás típusa kettős hivatkozás:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // két * kell!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Leállítás egy kezdeti `false` után:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Több olyan elemünk van, amelyek nulla alatt vannak, de mivel már hamisat kaptunk, az take_while()-et már nem használjuk
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Mivel az `take_while()`-nek meg kell vizsgálnia az értéket, hogy megnézhesse, be kell-e adni vagy sem, az iterátorok fogyasztása azt látja, hogy eltávolításra került:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// Az `3` már nincs meg, mert azért használták fel, hogy ellenőrizni lehessen-e az iterációt, de nem helyezték vissza az iterátorba.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Létrehoz egy iterátort, amely mind predikátum, mind térképek alapján hoz létre elemeket.
    ///
    /// `map_while()` érvelésként lezárást vesz fel.
    /// Az iterátor minden eleménél ezt a lezárást fogja hívni, és az [`Some(_)`][`Some`] érték visszaadásakor hoz létre elemeket.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Itt ugyanaz a példa, de az [`take_while`] és az [`map`] esetében:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Leállítás egy kezdeti [`None`] után:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Több olyan elemünk van, amelyek elférnek az u32-ben (4, 5), de az `map_while` visszaadta az `None`-et az `-3`-re (mivel az `predicate` visszaadta az `None`-et), és az `collect` megáll az első `None`-nél.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Mivel az `map_while()`-nek meg kell vizsgálnia az értéket, hogy megnézhesse, be kell-e adni vagy sem, az iterátorok fogyasztása azt látja, hogy eltávolításra került:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// Az `-3` már nincs meg, mert azért használták fel, hogy ellenőrizni lehessen-e az iterációt, de nem helyezték vissza az iterátorba.
    ///
    /// Vegye figyelembe, hogy az [`take_while`]-től eltérően ez az iterátor **nem** összeolvad.
    /// Azt sem határozzák meg, hogy ez az iterátor mit ad vissza az első [`None`] visszaadása után.
    /// Ha összeolvadt iterátorra van szüksége, használja az [`fuse`]-et.
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Létrehoz egy iterátort, amely kihagyja az első `n` elemeket.
    ///
    /// Elfogyasztásuk után a többi elemet kapjuk.
    /// Ahelyett, hogy felülírná ezt a módszert, inkább az `nth` metódust írja felül.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Létrehoz egy iterátort, amely megadja az első `n` elemeit.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` gyakran végtelen iterátorral használják, hogy végessé váljon:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ha kevesebb, mint `n` elem áll rendelkezésre, az `take` az alapul szolgáló iterátor méretére korlátozódik:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Az [`fold`]-hez hasonló iterátor adapter, amely belső állapotot tart és új iterátort állít elő.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` két érvet vesz fel: egy kezdeti értéket, amely magába foglalja a belső állapotot, és egy lezárást két argumentummal, az első a belső állapotra mutatható hivatkozás, a második pedig az iterátor elem.
    ///
    /// A bezárás hozzárendelheti a belső állapotot, hogy megossza az állapotot az iterációk között.
    ///
    /// Az iteráció során a zárást az iterátor minden elemére alkalmazzák, és a zárásból származó visszatérési értéket, az [`Option`]-et az iterátor adja.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // minden iterációnál megszorozzuk az állapotot az elemmel
    ///     *state = *state * x;
    ///
    ///     // akkor megadjuk az állam tagadását
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Létrehoz egy iterátort, amely úgy működik, mint a térkép, de simítja a beágyazott struktúrát.
    ///
    /// Az [`map`] adapter nagyon hasznos, de csak akkor, ha a bezárás argumentum értékeket produkál.
    /// Ha helyette iterátort készít, akkor van egy extra réteg indirection.
    /// `flat_map()` önmagában eltávolítja ezt az extra réteget.
    ///
    /// Gondolhat az `flat_map(f)`-re, mint a [`map`] ping szemantikai megfelelőjére, majd [` simításra '], mint az `map(f).flatten()`-ben.
    ///
    /// Egy másik gondolkodásmód az `flat_map()`-ről: A [`map`] bezárása minden elemhez egy elemet ad vissza, az `flat_map()`'s bezárás pedig minden elemhez egy iterátort ad vissza.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() iterátort ad vissza
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Létrehoz egy iterátort, amely ellapítja a beágyazott struktúrát.
    ///
    /// Ez akkor hasznos, ha van iterátorának iterátora, vagy iterátorokká alakítható dolgok iterátora van, és el akarja távolítani az indirekció egy szintjét.
    ///
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Feltérképezés, majd lapítás:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() iterátort ad vissza
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Ezt átírhatja az [`flat_map()`] kifejezésre is, ami ebben az esetben előnyösebb, mivel egyértelműbben közvetíti a szándékot:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() iterátort ad vissza
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// A lapítással egyszerre csak egy szintet lehet eltávolítani:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Itt azt látjuk, hogy az `flatten()` nem hajt végre "deep" lapítást.
    /// Ehelyett csak egy fészkelési szintet távolítanak el.Vagyis, ha `flatten()` háromdimenziós tömböt kap, az eredmény kétdimenziós és nem egydimenziós lesz.
    /// Az egydimenziós struktúra megszerzéséhez megint `flatten()`-et kell használnia.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Létrehoz egy iterátort, amely az első [`None`] után ér véget.
    ///
    /// Miután az iterátor visszaadta az [`None`] értéket, a future hívások újból megadhatják az [`Some(T)`]-et, vagy nem.
    /// `fuse()` alkalmazkodik egy iterátorhoz, biztosítva, hogy az [`None`] megadása után mindig örökre visszaadja az [`None`]-et.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// // iterátor, amely felváltva Néhány és Nincs
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // ha páros, Some(i32), különben Nincs
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // láthatjuk az iterátorunkat oda-vissza
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // ha azonban összeolvasztjuk ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // az első alkalommal mindig visszaadja az `None`-et.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Az iterátor minden elemével tesz valamit, továbbadva az értéket.
    ///
    /// Az iterátorok használatakor gyakran többeket összekapcsol.
    /// Miközben dolgozik egy ilyen kódon, érdemes megnéznie, mi történik a folyamat különböző részein.Ehhez illesszen be egy hívást az `inspect()`-re.
    ///
    /// Gyakrabban fordul elő, hogy az `inspect()`-et hibakereső eszközként használják, mint a végső kódban, de az alkalmazások hasznosnak találhatják bizonyos helyzetekben, amikor a hibákat naplózni kell, mielőtt eldobnák őket.
    ///
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // ez az iterátor szekvencia összetett.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // adjunk hozzá néhány inspect() hívást, hogy megvizsgáljuk, mi történik
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Ez kinyomtatja:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Naplózási hibák, mielőtt elvetné őket:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Ez kinyomtatja:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Kölcsönkér egy iterátort, ahelyett, hogy elfogyasztaná.
    ///
    /// Ez hasznos ahhoz, hogy lehetővé tegyük az iterátor adapterek alkalmazását, miközben megőrizzük az eredeti iterátor tulajdonjogát.
    ///
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // ha megpróbáljuk újra használni az iter alkalmazást, az nem fog menni.
    /// // A következő sor "hiba: az áthelyezett érték használata: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // próbáljuk meg újra
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // ehelyett hozzáadunk egy .by_ref()-et
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // ez most rendben van:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Az iterátort gyűjteménygé alakítja.
    ///
    /// `collect()` bármi iterálhatót el tud készíteni, és releváns gyűjteménygé alakíthatja.
    /// Ez az egyik leghatékonyabb módszer a standard könyvtárban, amelyet különféle körülmények között használnak.
    ///
    /// A legalapvetőbb minta, amelyben az `collect()`-et használják, az, hogy az egyik kollekciót egy másiká alakítja.
    /// Fogsz egy gyűjteményt, felhívod rajta az [`iter`]-et, elvégzel egy csomó átalakítást, majd a végén az `collect()`-et.
    ///
    /// `collect()` olyan tipusú példányokat is létrehozhat, amelyek nem tipikus gyűjtemények.
    /// Például egy [`String`] felépíthető a [`char'-okból), és az [`Result<T, E>`][`Result`] elemek iterátora összegyűjthető az `Result<Collection<T>, E>`-be.
    ///
    /// További információkért lásd az alábbi példákat.
    ///
    /// Mivel az `collect()` annyira általános, problémákat okozhat a típus következtetésében.
    /// Mint ilyen, az `collect()` azon kevés alkalmak egyike, amikor a szintaxist szeretettel 'turbofish' néven ismerjük: `::<>`.
    /// Ez segít a következtetési algoritmusnak megérteni, hogy melyik gyűjteménybe próbál gyűjteni.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Vegye figyelembe, hogy szükségünk volt az `: Vec<i32>`-re a bal oldalon.Ennek az az oka, hogy helyette például [`VecDeque<T>`]-be gyűjthetnénk:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Az 'turbofish' használata az `doubled` kommentálása helyett:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Mivel az `collect()` csak azzal törődik, amibe gyűjt, ezért továbbra is használhat egy részleges `_` típusú tippet a turbohalhoz:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Az `collect()` használatával [`String`] készíthető:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Ha van egy listája az [`Eredmény<T, E>`][`Eredmény`] s, az `collect()` segítségével megnézheti, hogy valamelyik nem sikerült-e:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // megadja nekünk az első hibát
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // megadja nekünk a válaszok listáját
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Iterátort fogyaszt, két gyűjteményt hozva létre belőle.
    ///
    /// Az `partition()`-nek átadott predikátum `true`-et vagy `false`-et adhat vissza.
    /// `partition()` párat ad vissza, az összes elemet, amelyre visszaküldte az `true`-et, és az összes elemet, amelyre visszaküldte az `false`-et.
    ///
    ///
    /// Lásd még: [`is_partitioned()`] és [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Az iterátor *helyben* elemeit a megadott állítmány szerint rendezi át úgy, hogy mindazok, akik `true`-t adnak vissza, megelőzzék mindazokat, akik `false`-et adnak vissza.
    ///
    /// Visszaadja a megtalált `true` elemek számát.
    ///
    /// A particionált elemek relatív sorrendje nem marad fenn.
    ///
    /// Lásd még: [`is_partitioned()`] és [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Partíció a helyeken az egyenlők és az esélyek között
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: aggódnunk kellene a túlcsorduló gróf miatt?Az egyetlen módja annak, hogy több legyen
        // `usize::MAX` a mutábilis hivatkozások a ZST-kkel vannak, amelyek nem hasznosak a particionáláshoz ...

        // Ezek a záró "factory" funkciók azért léteznek, hogy elkerüljék az `Self` általános jellegét.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Ismételten keresse meg az első `false`-et, és cserélje le az utolsó `true`-gyel.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Ellenőrzi, hogy ennek az iterátornak az elemei fel vannak-e osztva a megadott predikátum szerint, úgy, hogy mindazok, akik `true`-et adnak vissza, megelőzzék mindazokat, akik `false`-t adnak vissza.
    ///
    ///
    /// Lásd még: [`partition()`] és [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Vagy az összes elem teszteli az `true`-et, vagy az első mondat megáll az `false`-nél, és ellenőrizzük, hogy utána nincs-e több `true` elem.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Olyan iterátor módszer, amely addig függvényt alkalmaz, amíg sikeresen visszatér, egyetlen, végső értéket állítva elő.
    ///
    /// `try_fold()` két érvet vesz fel: egy kezdeti értéket és egy lezárást két argumentummal: egy 'accumulator' és egy elem.
    /// A lezárás vagy sikeresen visszatér, azzal az értékkel, amellyel az akkumulátornak rendelkeznie kell a következő iterációhoz, vagy meghibásodik, egy hibaértékkel, amelyet azonnal továbbítanak a hívónak (short-circuiting).
    ///
    ///
    /// A kezdeti érték az az érték, amelyet az akkumulátor az első híváskor megkap.Ha a zárás alkalmazása az iterátor minden elemével szemben sikeres volt, az `try_fold()` sikeresen visszaküldi a végső akkumulátort.
    ///
    /// A hajtogatás akkor hasznos, ha van valaminek gyűjteménye, és egyetlen értéket szeretne előállítani belőle.
    ///
    /// # Megjegyzés a végrehajtóknak
    ///
    /// A többi (forward) módszer közül számos rendelkezik alapértelmezett megvalósítással, ezért próbáld meg ezt kifejezetten megvalósítani, ha az alapértelmezett `for` hurok megvalósításnál jobbat tud tenni.
    ///
    /// Különösen próbáld meg ezt az `try_fold()` hívást azokon a belső részeken használni, amelyekből ez az iterátor összeáll.
    /// Ha több hívásra van szükség, az `?` operátor kényelmesen összekapcsolhatja az akkumulátor értékét, de vigyázzon minden invariánsra, amelyet a korai visszatérés előtt fenn kell tartani.
    /// Ez egy `&mut self` módszer, ezért az iterációt folytatni kell, miután itt eltalált egy hibát.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // a tömb összes elemének ellenőrzött összege
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Ez az összeg túlcsordul a 100 elem hozzáadásakor
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Mivel rövidre záródott, a fennmaradó elemek továbbra is elérhetők az iterátoron keresztül.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Olyan iterátor-módszer, amely egy eshető függvényt alkalmaz az iterátor minden elemére, az első hibánál megáll és visszaadja ezt a hibát.
    ///
    ///
    /// Ez felfogható az [`for_each()`] esendő formájának vagy az [`try_fold()`] hontalan változatának is.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Rövidre záródott, így a fennmaradó elemek még mindig az iterátorban vannak:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Minden elemet felhalmoz egy akkumulátorba egy művelet alkalmazásával, a végeredmény visszaadásával.
    ///
    /// `fold()` két érvet vesz fel: egy kezdeti értéket és egy lezárást két argumentummal: egy 'accumulator' és egy elem.
    /// A lezárás azt az értéket adja vissza, amely az akkumulátornak rendelkeznie kell a következő iterációval.
    ///
    /// A kezdeti érték az az érték, amelyet az akkumulátor az első híváskor megkap.
    ///
    /// Miután ezt a zárót alkalmazta az iterátor minden elemére, az `fold()` visszaadja az akkumulátort.
    ///
    /// Ezt a műveletet néha 'reduce'-nek vagy 'inject'-nek hívják.
    ///
    /// A hajtogatás akkor hasznos, ha van valaminek gyűjteménye, és egyetlen értéket szeretne előállítani belőle.
    ///
    /// Note: Az `fold()` és hasonló módszerek, amelyek áthaladnak a teljes iterátoron, nem szűnhetnek meg a végtelen iterátoroknál, még a traits esetében sem, amelynek eredménye véges idő alatt meghatározható.
    ///
    /// Note: Az [`reduce()`] használható az első elem használatára kiinduló értékként, ha az akkumulátor és az elem típusa megegyezik.
    ///
    /// # Megjegyzés a végrehajtóknak
    ///
    /// A többi (forward) módszer közül számos rendelkezik alapértelmezett megvalósítással, ezért próbáld meg ezt kifejezetten megvalósítani, ha az alapértelmezett `for` hurok megvalósításnál jobbat tud tenni.
    ///
    ///
    /// Különösen próbáld meg ezt az `fold()` hívást azokon a belső részeken használni, amelyekből ez az iterátor összeáll.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // a tömb összes elemének összege
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Végigjárjuk az iteráció minden egyes lépését itt:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// És így a végeredmény, `6`.
    ///
    /// Gyakran előfordul, hogy az iterátorokat nem sokat használó emberek `for` ciklust használnak a dolgok felsorolásával az eredmény felépítéséhez.Ezek átalakíthatók `fold()`s-be:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // hurokhoz:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // ugyanazok
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Redukciós művelet ismételt alkalmazásával redukálja az elemeket egyetlen elemre.
    ///
    /// Ha az iterátor üres, akkor az [`None`];ellenkező esetben a csökkentés eredményét adja vissza.
    ///
    /// Legalább egy elemmel rendelkező iterátorok esetében ez megegyezik az [`fold()`] értékkel, amelynek kiindulási értéke az iterátor első eleme, minden további elemet belehajtva.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Keresse meg a maximális értéket:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Megvizsgálja, hogy az iterátor minden eleme megfelel-e egy állítmánynak.
    ///
    /// `all()` lezárást kap, amely `true` vagy `false` értéket ad vissza.Ezt a zárást alkalmazza az iterátor minden elemére, és ha mind visszaadja az `true` értéket, akkor az `all()` értéket is.
    /// Ha bármelyikük visszaadja az `false`-et, akkor az `false`-et adja vissza.
    ///
    /// `all()` rövidzárlatos;más szavakkal, amint egy `false`-t talál, abbahagyja a feldolgozást, tekintettel arra, hogy bármi történjen is, az eredmény is `false` lesz.
    ///
    ///
    /// Egy üres iterátor visszaadja az `true` értéket.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Megállás az első `false`-nél:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // továbbra is használhatjuk az `iter`-et, mivel több elem van.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Megvizsgálja, hogy az iterátor bármely eleme megfelel-e egy állítmánynak.
    ///
    /// `any()` lezárást kap, amely `true` vagy `false` értéket ad vissza.Ezt a zárást alkalmazza az iterátor minden elemére, és ha bármelyikük visszaadja az `true` értéket, akkor az `any()` is.
    /// Ha valamennyien visszaadják az `false`-et, akkor az `false`-et ad vissza.
    ///
    /// `any()` rövidzárlatos;más szavakkal, amint egy `true`-t talál, abbahagyja a feldolgozást, tekintettel arra, hogy bármi történjen is, az eredmény is `true` lesz.
    ///
    ///
    /// Egy üres iterátor visszaadja az `false` értéket.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Megállás az első `true`-nél:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // továbbra is használhatjuk az `iter`-et, mivel több elem van.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Az iterátor olyan elemére keres, amely kielégít egy állítmányt.
    ///
    /// `find()` lezárást kap, amely `true` vagy `false` értéket ad vissza.
    /// Ezt a zárást alkalmazza az iterátor minden elemére, és ha bármelyikük visszaadja az `true` értéket, akkor az `find()` az [`Some(element)`] értéket adja vissza.
    /// Ha valamennyien visszaadják az `false`-et, akkor az [`None`]-et ad vissza.
    ///
    /// `find()` rövidzárlatos;más szóval, leállítja a feldolgozást, amint a bezárás visszaadja az `true`-et.
    ///
    /// Mivel az `find()` referenciát vesz fel, és sok iterátor ismétli a referenciákat, ez egy esetleges zavaros helyzethez vezet, ahol az argumentum kettős hivatkozás.
    ///
    /// Ezt a hatást az alábbi példákban láthatja, az `&&x` használatával.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Megállás az első `true`-nél:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // továbbra is használhatjuk az `iter`-et, mivel több elem van.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Vegye figyelembe, hogy az `iter.find(f)` egyenértékű az `iter.filter(f).next()` értékkel.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// A függvényt alkalmazza az iterátor elemeire, és visszaadja az első non-none eredményt.
    ///
    ///
    /// `iter.find_map(f)` egyenértékű az `iter.filter_map(f).next()`-szel.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// A függvényt alkalmazza az iterátor elemeire, és az első igaz eredményt vagy az első hibát adja vissza.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Elem után kutat egy iterátorban, visszaadva annak indexét.
    ///
    /// `position()` lezárást kap, amely `true` vagy `false` értéket ad vissza.
    /// Ezt a zárást alkalmazza az iterátor minden elemére, és ha az egyikük visszaadja az `true` értéket, akkor az `position()` az [`Some(index)`] értéket adja vissza.
    /// Ha mindegyikük visszaadja az `false` értéket, akkor az [`None`] értéket adja vissza.
    ///
    /// `position()` rövidzárlatos;más szóval, leállítja a feldolgozást, amint megtalálja az `true`-et.
    ///
    /// # Túlcsorduló viselkedés
    ///
    /// A módszer nem véd a túlcsordulások ellen, ezért ha több mint [`usize::MAX`] nem egyező elem van, akkor vagy rossz eredményt ad, vagy a panics értéket.
    ///
    /// Ha a hibakeresés engedélyezve van, akkor a panic garantált.
    ///
    /// # Panics
    ///
    /// Ez a függvény panic lehet, ha az iterátornak több mint `usize::MAX` nem egyező eleme van.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Megállás az első `true`-nél:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // továbbra is használhatjuk az `iter`-et, mivel több elem van.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // A visszaadott index az iterátor állapotától függ
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Jobb oldalról keres egy elemet az iterátorban, visszaadva annak indexét.
    ///
    /// `rposition()` lezárást kap, amely `true` vagy `false` értéket ad vissza.
    /// Ezt a zárást alkalmazza az iterátor minden elemére, kezdve a végétől, és ha az egyikük visszaadja az `true` értéket, akkor az `rposition()` az [`Some(index)`] értéket adja vissza.
    ///
    /// Ha mindegyikük visszaadja az `false` értéket, akkor az [`None`] értéket adja vissza.
    ///
    /// `rposition()` rövidzárlatos;más szóval, leállítja a feldolgozást, amint megtalálja az `true`-et.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Megállás az első `true`-nél:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // továbbra is használhatjuk az `iter`-et, mivel több elem van.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Itt nincs szükség túlcsordulás ellenőrzésre, mert az `ExactSizeIterator` azt jelenti, hogy az elemek száma elfér egy `usize`-ben.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Az iterátor maximális elemét adja eredményül.
    ///
    /// Ha több elem egyforma maximum, akkor az utolsó elem kerül visszaadásra.
    /// Ha az iterátor üres, akkor az [`None`] visszatér.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Visszaadja az iterátor minimális elemét.
    ///
    /// Ha több elem egyformán minimum, az első elem visszatér.
    /// Ha az iterátor üres, akkor az [`None`] visszatér.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Visszaadja azt az elemet, amely megadja a maximális értéket a megadott függvényből.
    ///
    ///
    /// Ha több elem egyforma maximum, akkor az utolsó elem kerül visszaadásra.
    /// Ha az iterátor üres, akkor az [`None`] visszatér.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Visszaadja azt az elemet, amely megadja a maximális értéket a megadott összehasonlító függvényhez képest.
    ///
    ///
    /// Ha több elem egyforma maximum, akkor az utolsó elem kerül visszaadásra.
    /// Ha az iterátor üres, akkor az [`None`] visszatér.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Visszaadja azt az elemet, amely megadja a minimális értéket a megadott függvényből.
    ///
    ///
    /// Ha több elem egyformán minimum, az első elem visszatér.
    /// Ha az iterátor üres, akkor az [`None`] visszatér.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Visszaadja azt az elemet, amely a minimális értéket adja meg a megadott összehasonlító függvényhez képest.
    ///
    ///
    /// Ha több elem egyformán minimum, az első elem visszatér.
    /// Ha az iterátor üres, akkor az [`None`] visszatér.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Megfordítja az iterátor irányát.
    ///
    /// Általában az iterátorok balról jobbra iterálnak.
    /// Az `rev()` használata után az iterátor ehelyett jobbról balra iterál.
    ///
    /// Ez csak akkor lehetséges, ha az iterátornak vége van, így az `rev()` csak [`DoubleEndedIterator`]-on működik.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Átalakítja a párok iterátorát páros tárolóvá.
    ///
    /// `unzip()` a párok teljes iterátorát emészti fel, két gyűjteményt állítva elő: egyet a párok bal elemeiből és egyet a jobb elemeiből.
    ///
    ///
    /// Ez a funkció bizonyos értelemben az [`zip`] ellentéte.
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Létrehoz egy iterátort, amely az összes elemét lemásolja.
    ///
    /// Ez akkor hasznos, ha az `&T` feletti iterátorral rendelkezik, de az `T` feletti iterátorra van szüksége.
    ///
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // másolva ugyanaz, mint az .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Létrehoz egy iterátort, amely minden elemét [klónozza].
    ///
    /// Ez akkor hasznos, ha az `&T` feletti iterátorral rendelkezik, de az `T` feletti iterátorra van szüksége.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // a klónozás megegyezik az .map(|&x| x) értékkel egész számok esetében
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Végtelenül ismételget egy iterátort.
    ///
    /// Ahelyett, hogy az [`None`]-en állna meg, az iterátor újraindul, az elejétől kezdve.Az ismételt ismétlés után az elején kezdődik újra.És újra.
    /// És újra.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Összefoglalja az iterátor elemeit.
    ///
    /// Minden elemet összeszed, összeadja és visszaadja az eredményt.
    ///
    /// Egy üres iterátor visszaadja a típus nulla értékét.
    ///
    /// # Panics
    ///
    /// Ha meghívja az `sum()`-et, és egy primitív egész típusú típust ad vissza, akkor ez a módszer panic lesz, ha a számítási túlcsordulások és a hibakeresési állítások engedélyezve vannak.
    ///
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Az egész iterátoron ismétlődik, megszorozva az összes elemet
    ///
    /// Egy üres iterátor visszaadja a típus egy értékét.
    ///
    /// # Panics
    ///
    /// Ha meghívja az `product()`-et, és egy primitív egész típusú típust ad vissza, a módszer panic lesz, ha a számítási túlcsordulás és a hibakeresés engedélyezve van.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) összehasonlítja ennek az [`Iterator`] elemeit egy másik elemének.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) összehasonlítja ezen [`Iterator`] elemeit egy másik elemével a megadott összehasonlító függvény szempontjából.
    ///
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) összehasonlítja ennek az [`Iterator`] elemeit egy másik elemének.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) összehasonlítja ezen [`Iterator`] elemeit egy másik elemével a megadott összehasonlító függvény szempontjából.
    ///
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Meghatározza, hogy az [`Iterator`] elemei megegyeznek-e egy másik elemével.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Meghatározza, hogy ennek az [`Iterator`]-nek az elemei megegyeznek-e a másikéval a megadott egyenlőségi függvény szempontjából.
    ///
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Meghatározza, hogy az [`Iterator`] elemei nem egyenlőek-e egy másik elemével.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Meghatározza, hogy ennek az [`Iterator`]-nek az elemei [lexicographically](Ord#lexicographical-comparison)-rel kisebbek-e, mint egy másik elemei.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Meghatározza, hogy ennek az [`Iterator`] elemnek az értéke [lexicographically](Ord#lexicographical-comparison) kisebb-e vagy egyenlő-e egy másik elemével.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Meghatározza, hogy az [`Iterator`] elemei nagyobbak-e, mint [lexicographically](Ord#lexicographical-comparison), mint egy másik elemei.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Meghatározza, hogy ennek az [`Iterator`]-nek az elemei [lexicographically](Ord#lexicographical-comparison)-e nagyobb vagy egyenlő-e egy másik elemével.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Ellenőrzi, hogy az iterátor elemei rendezve vannak-e.
    ///
    /// Vagyis minden egyes `a` elemre és az azt követő `b` elemre az `a <= b`-nek tartania kell.Ha az iterátor pontosan nulla vagy egy elemet eredményez, akkor az `true` értéket adja vissza.
    ///
    /// Vegye figyelembe, hogy ha `Self::Item` csak `PartialOrd`, de nem `Ord`, akkor a fenti definíció azt jelenti, hogy ez a függvény `false`-et ad vissza, ha bármely két egymást követő elem nem összehasonlítható.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Ellenőrzi, hogy az iterátor elemei rendezve vannak-e a megadott összehasonlító függvény segítségével.
    ///
    /// Az `PartialOrd::partial_cmp` használata helyett ez a függvény az adott `compare` függvényt használja két elem sorrendjének meghatározásához.
    /// Ettől eltekintve egyenértékű az [`is_sorted`]-szel;további információkért lásd a dokumentációját.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Ellenőrzi, hogy ennek az iterátornak az elemei rendezve vannak-e a megadott kulcs kibontási funkcióval.
    ///
    /// Az iterátor elemeinek közvetlen összehasonlítása helyett ez a függvény összehasonlítja az elemek kulcsait, az `f` meghatározása szerint.
    /// Ettől eltekintve egyenértékű az [`is_sorted`]-szel;további információkért lásd a dokumentációját.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Lásd: [TrustedRandomAccess]
    // A szokatlan név az, hogy elkerüljük a névütközéseket a módszer felbontásában, lásd: #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}