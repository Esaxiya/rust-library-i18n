use crate::fmt;

/// Új iterátort hoz létre, ahol minden egyes iteráció a megadott lezárást `F: FnMut() -> Option<T>`-nek hívja.
///
/// Ez lehetővé teszi egyedi iterátor létrehozását bármilyen viselkedéssel anélkül, hogy a dedikáltabb szintaxist használnánk egy dedikált típus létrehozásához és az [`Iterator`] trait végrehajtásához.
///
/// Ne feledje, hogy az `FromFn` iterátor nem tételez fel feltételeket a bezárás viselkedésével kapcsolatban, ezért konzervatív módon nem valósítja meg az [`FusedIterator`]-et, vagy nem írja felül az [`Iterator::size_hint()`]-et az alapértelmezett `(0, None)`-től.
///
///
/// A bezárás rögzítéseket és környezetét használhatja az iterációk közötti állapot követésére.Az iterátor használatának módjától függően szükség lehet az [`move`] kulcsszó megadására a zárásnál.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Telepítsük újra az [module-level documentation] számláló iterátorát:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Növelje a számunkat.Ezért kezdtük nullán.
///     count += 1;
///
///     // Ellenőrizze, hogy befejeztük-e a számlálást, vagy sem.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Egy iterátor, ahol minden egyes iteráció a megadott lezárást `F: FnMut() -> Option<T>`-nek hívja.
///
/// Ezt az `struct`-et az [`iter::from_fn()`] függvény hozza létre.
/// További információt a dokumentációjában talál.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}