use crate::iter::{FusedIterator, TrustedLen};

/// Új iterátort hoz létre, amely végtelenül megismétli egyetlen elemet.
///
/// Az `repeat()` funkció egyetlen értéket ismételget újra és újra.
///
/// Az `repeat()`-hez hasonló végtelen iterátorokat gyakran használnak az [`Iterator::take()`]-hez hasonló adapterekkel annak érdekében, hogy végesek legyenek.
///
/// Ha a szükséges iterátor elemtípusa nem valósítja meg az `Clone`-et, vagy ha nem szeretné megismételni az ismételt elemet a memóriában, akkor inkább az [`repeat_with()`] funkciót használhatja.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Alapvető használat:
///
/// ```
/// use std::iter;
///
/// // a négyes 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // igen, még mindig négy
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Véges lesz az [`Iterator::take()`] használatával:
///
/// ```
/// use std::iter;
///
/// // az utolsó példa túl sok volt.Csak négyesünk legyen.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... és most készen vagyunk
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Olyan iterátor, amely végtelenül megismétel egy elemet.
///
/// Ezt az `struct`-et az [`repeat()`] függvény hozza létre.További információt a dokumentációjában talál.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}