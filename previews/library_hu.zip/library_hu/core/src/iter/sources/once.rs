use crate::iter::{FusedIterator, TrustedLen};

/// Létrehoz egy iterátort, amely pontosan egyszer hoz létre egy elemet.
///
/// Ezt általában arra használják, hogy egyetlen értéket más típusú iteráció [`chain()`]-be adaptáljanak.
/// Talán van iterátora, amely szinte mindent lefed, de szükség van egy extra speciális esetre.
/// Talán van olyan funkciója, amely az iterátorokon működik, de csak egy értéket kell feldolgoznia.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Alapvető használat:
///
/// ```
/// use std::iter;
///
/// // az egyik a legmagányosabb szám
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // csak egy, ennyit kapunk
/// assert_eq!(None, one.next());
/// ```
///
/// Láncolás egy másik iterátorral.
/// Tegyük fel, hogy szeretnénk iterálni az `.foo` könyvtár minden fájlját, de egy konfigurációs fájlt is,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // át kell állítanunk a DirEntry-s iterátoráról a PathBufs iterátorára, ezért a térképet használjuk
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // iterátorunk csak a konfigurációs fájlunkhoz
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // láncolja össze a két iterátort egy nagy iterátorrá
/// let files = dirs.chain(config);
///
/// // ez megadja nekünk az .foo és az .foorc fájlokat
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Olyan iterátor, amely pontosan egyszer hoz létre elemet.
///
/// Ezt az `struct`-et az [`once()`] függvény hozza létre.További információt a dokumentációjában talál.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}