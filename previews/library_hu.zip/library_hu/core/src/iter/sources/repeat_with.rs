use crate::iter::{FusedIterator, TrustedLen};

/// Új iterátort hoz létre, amely végtelenül megismétli az `A` típusú elemeket a mellékelt záróelem, az átjátszó, `F: FnMut() -> A`.
///
/// Az `repeat_with()` funkció újra és újra felhívja az átjátszót.
///
/// Az `repeat_with()`-hez hasonló végtelen iterátorokat gyakran használnak az [`Iterator::take()`]-hez hasonló adapterekkel annak érdekében, hogy végesek legyenek.
///
/// Ha a szükséges iterátor elemtípusa megvalósítja az [`Clone`]-et, és rendben van, ha a forráselemet a memóriában tartja, akkor inkább az [`repeat()`] funkciót kell használnia.
///
///
/// Az `repeat_with()` által előállított iterátor nem [`DoubleEndedIterator`].
/// Ha `repeat_with()`-re van szüksége az [`DoubleEndedIterator`] visszaküldéséhez, nyissa meg a GitHub kiadást, amely elmagyarázza a felhasználási esetét.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Alapvető használat:
///
/// ```
/// use std::iter;
///
/// // Tegyük fel, hogy van egy olyan típusunk értéke, amely nem `Clone` vagy amely még nem akar memóriában maradni, mert drága:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // egy adott érték örökre:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// A mutáció használata és a véges lépés:
///
/// ```rust
/// use std::iter;
///
/// // A nullától a kettő harmadik erejéig:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... és most készen vagyunk
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Olyan iterátor, amely végtelenül megismétli az `A` típusú elemeket a mellékelt `F: FnMut() -> A` záróelem alkalmazásával.
///
///
/// Ezt az `struct`-et az [`repeat_with()`] függvény hozza létre.
/// További információt a dokumentációjában talál.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}