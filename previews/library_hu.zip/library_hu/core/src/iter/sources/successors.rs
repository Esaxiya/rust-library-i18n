use crate::{fmt, iter::FusedIterator};

/// Új iterátort hoz létre, ahol az egymást követő elemeket az előző alapján számítják ki.
///
/// Az iterátor a megadott első tétellel kezdődik (ha van ilyen), és felhívja az adott `FnMut(&T) -> Option<T>` lezárást az egyes elemek utódjának kiszámításához.
///
///
/// ```
/// use std::iter::successors;
///
/// let powers_of_10 = successors(Some(1_u16), |n| n.checked_mul(10));
/// assert_eq!(powers_of_10.collect::<Vec<_>>(), &[1, 10, 100, 1_000, 10_000]);
/// ```
#[stable(feature = "iter_successors", since = "1.34.0")]
pub fn successors<T, F>(first: Option<T>, succ: F) -> Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    // Ha ez a függvény visszaadta az `impl Iterator<Item=T>`-et, akkor az `unfold`-en alapulhat, és nincs szüksége dedikált típusra.
    //
    // Azonban megnevezett `Successors<T, F>` típus lehetővé teszi, hogy `Clone` legyen, ha `T` és `F`.
    Successors { next: first, succ }
}

/// Új iterátor, ahol minden egymást követő elem kiszámítása az előző alapján történik.
///
/// Ezt az `struct`-et az [`iter::successors()`] függvény hozza létre.
/// További információt a dokumentációjában talál.
///
/// [`iter::successors()`]: successors
#[derive(Clone)]
#[stable(feature = "iter_successors", since = "1.34.0")]
pub struct Successors<T, F> {
    next: Option<T>,
    succ: F,
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> Iterator for Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        let item = self.next.take()?;
        self.next = (self.succ)(&item);
        Some(item)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.next.is_some() { (1, None) } else { (0, Some(0)) }
    }
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> FusedIterator for Successors<T, F> where F: FnMut(&T) -> Option<T> {}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T: fmt::Debug, F> fmt::Debug for Successors<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Successors").field("next", &self.next).finish()
    }
}