use crate::iter::{FusedIterator, TrustedLen};

/// Létrehoz egy iterátort, amely lusta módon pontosan egyszer generál értéket a megadott lezárás hivatkozásával.
///
/// Ezt általában arra használják, hogy egyetlen értékgenerátort alkalmazzanak más típusú iterációk [`chain()`]-hez.
/// Talán van iterátora, amely szinte mindent lefed, de szükség van egy extra speciális esetre.
/// Talán van olyan funkciója, amely az iterátorokon működik, de csak egy értéket kell feldolgoznia.
///
/// Az [`once()`]-től eltérően ez a funkció kérésre lustán generálja az értéket.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Alapvető használat:
///
/// ```
/// use std::iter;
///
/// // az egyik a legmagányosabb szám
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // csak egy, ennyit kapunk
/// assert_eq!(None, one.next());
/// ```
///
/// Láncolás egy másik iterátorral.
/// Tegyük fel, hogy szeretnénk iterálni az `.foo` könyvtár minden fájlját, de egy konfigurációs fájlt is,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // át kell állítanunk a DirEntry-s iterátoráról a PathBufs iterátorára, ezért a térképet használjuk
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // iterátorunk csak a konfigurációs fájlunkhoz
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // láncolja össze a két iterátort egy nagy iterátorrá
/// let files = dirs.chain(config);
///
/// // ez megadja nekünk az .foo és az .foorc fájlokat
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Olyan iterátor, amely egyetlen mellékelt `A` típusú elemet eredményez a mellékelt `F: FnOnce() -> A` záróelem alkalmazásával.
///
///
/// Ezt az `struct`-et az [`once_with()`] függvény hozza létre.
/// További információt a dokumentációjában talál.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}