//! Komponálható külső iteráció.
//!
//! Ha valamilyen gyűjteményt talált magának, és szüksége volt egy művelet végrehajtására az említett gyűjtemény elemein, gyorsan belefut az 'iterators'-be.
//! Az iterátorokat nagyon használják az idiomatikus Rust kódban, ezért érdemes megismerkedni velük.
//!
//! Mielőtt bővebben elmagyaráznánk, beszéljünk a modul felépítéséről:
//!
//! # Organization
//!
//! Ez a modul nagyrészt típus szerint szerveződik:
//!
//! * [Traits] ezek a fő rész: ezek a traits meghatározzák, hogy milyen iterátorok léteznek, és mit tehet velük.Ezeknek a traits módszereinek érdemes némi plusz tanulmányi időt szánni.
//! * [Functions] nyújt néhány hasznos módszert néhány alapvető iterátor létrehozására.
//! * [Structs] gyakran a modul traits különböző módszereinek visszatérési típusai.Általában az `struct` létrehozására szolgáló módszert kell megvizsgálnia, nem pedig magát az `struct`-et.
//! A miértről bővebben lásd: " [Iterator megvalósítása](#implementációs iterátor)`.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Ez az!Bemássuk az iterátorokat.
//!
//! # Iterator
//!
//! Ennek a modulnak a szíve és lelke az [`Iterator`] trait.Az [`Iterator`] magja így néz ki:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Az iterátornak van egy metódusa, az [`next`], amely meghívásakor egy ["Option"] értéket ad vissza<Item>".
//! [`next`] mindaddig visszaadja az [`Some(Item)`]-et, amíg vannak elemek, és ha mindannyian kimerültek, visszaadja az `None`-et, jelezve, hogy az iteráció befejeződött.
//! Az egyes iterátorok dönthetnek úgy, hogy folytatják az iterációt, és így az [`next`] újbóli hívása előbb-utóbb megkezdheti az [`Some(Item)`] visszatérését valamikor (például lásd: [`TryIter`]).
//!
//!
//! Az [`Iterator`] teljes meghatározása számos más módszert is tartalmaz, de ezek az alapértelmezett módszerek, az [`next`] tetejére épülnek, és így ingyen kapja meg őket.
//!
//! Az iterátorok is összeállíthatók, és általában összetettebb feldolgozási formákhoz kapcsolják őket egymáshoz.További részletekért lásd az alábbi [Adapters](#adapters) részt.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Az iteráció három formája
//!
//! Három általános módszer létezik, amelyek iterátorokat hozhatnak létre egy gyűjteményből:
//!
//! * `iter()`, amely az `&T` felett iterál.
//! * `iter_mut()`, amely az `&mut T` felett iterál.
//! * `into_iter()`, amely az `T` felett iterál.
//!
//! A szokásos könyvtár különböző dolgai adott esetben megvalósíthatják a három közül egyet vagy többet.
//!
//! # Az Iterator megvalósítása
//!
//! Saját iterátor létrehozása két lépésből áll: létrehoz egy `struct`-et az iterátor állapotának megtartásához, majd az [`Iterator`] megvalósítását ehhez az `struct`-hez.
//! Ezért van annyi `struct` ebben a modulban: minden iterátorhoz és iterátor adapterhez tartozik egy.
//!
//! Készítsünk egy `Counter` nevű iterátort, amely `1`-től `5`-ig számít:
//!
//! ```
//! // Először a struktúra:
//!
//! /// Iterátor, amely egytől ötig számol
//! struct Counter {
//!     count: usize,
//! }
//!
//! // azt akarjuk, hogy a számlálásunk egyben kezdődjön, ezért adjunk hozzá egy new() módszert a segítségünkre.
//! // Ez nem feltétlenül szükséges, de kényelmes.
//! // Ne feledje, hogy az `count`-et nullán kezdjük, az alábbiakban meglátjuk, hogy miért.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Ezután implementáljuk az `Iterator`-et az `Counter`-hez:
//!
//! impl Iterator for Counter {
//!     // számolni fogunk usize-vel
//!     type Item = usize;
//!
//!     // next() az egyetlen szükséges módszer
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Növelje a számunkat.Ezért kezdtük nullán.
//!         self.count += 1;
//!
//!         // Ellenőrizze, hogy befejeztük-e a számlálást, vagy sem.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // És most már használhatjuk!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Az [`next`] ilyen módon történő hívása ismétlődik.A Rust rendelkezik egy konstrukcióval, amely az [`next`]-et hívhatja az iterátorán, amíg el nem éri az `None` értéket.Ezt nézzük át legközelebb.
//!
//! Vegye figyelembe azt is, hogy az `Iterator` alapértelmezett megvalósítást biztosít az olyan módszerek számára, mint az `nth` és az `fold`, amelyek belsőleg hívják az `next`-et.
//! Lehetséges azonban olyan módszerek egyedi megvalósításának megírása is, mint az `nth` és az `fold`, ha az iterátor hatékonyabban tudja kiszámítani őket az `next` hívása nélkül.
//!
//! # `for` hurkok és `IntoIterator`
//!
//! A Rust `for` hurok szintaxisa valójában cukor az iterátorok számára.Íme az `for` alapvető példája:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Ez kinyomtatja a számokat egytől ötig, mindegyiket a saját sorára.De itt észrevesz valamit: soha nem hívtunk semmit a vector-re iterátor előállítására.Mi ad?
//!
//! Van egy trait a standard könyvtárban, hogy valamit iterátorrá alakítson: [`IntoIterator`].
//! Ennek a trait-nek van egy módszere, az [`into_iter`], amely az [`IntoIterator`]-et megvalósító dolgot iterátorrá alakítja.
//! Vessünk egy pillantást ismét arra az `for` hurokra, és mire alakítja a fordító:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! A Rust ezt cukrozza:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Először hívjuk az `into_iter()` értéket.Ezután egyeztetjük a visszatérő iterátort, és újra és újra felhívjuk az [`next`]-et, amíg meg nem jelenik egy `None`.
//! Ezen a ponton `break`-et kiléptünk a hurokból, és befejeztük az iterációt.
//!
//! Van még egy aprócska apróság itt: a standard könyvtár az [`IntoIterator`] érdekes megvalósítását tartalmazza:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Más szavakkal, az összes [`Iterator`] úgy valósítja meg az [`IntoIterator`]-et, hogy csak visszatér.Ez két dolgot jelent:
//!
//! 1. Ha [`Iterator`]-t ír, használhatja `for`-hurkokkal.
//! 2. Ha gyűjteményt hoz létre, akkor az [`IntoIterator`] bevezetése lehetővé teszi, hogy gyűjteményét az `for` hurokkal használja.
//!
//! # Iterálás referenciával
//!
//! Mivel az [`into_iter()`] az `self` értékét veszi fel, az `for` hurok használata a gyűjtemények ismétléséhez elfogyasztja ezt a gyűjteményt.Gyakran előfordulhat, hogy fel kell ismételni egy gyűjteményt anélkül, hogy el kellene fogyasztania.
//! Számos gyűjtemény kínál olyan módszereket, amelyek iterátorokat biztosítanak referenciák felett, hagyományosan `iter()`, illetve `iter_mut()` néven:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` továbbra is ennek a funkciónak a tulajdonosa.
//! ```
//!
//! Ha az `C` gyűjteménytípus biztosítja az `iter()`-et, akkor általában az `IntoIterator`-et is megvalósítja az `&C`-hez, olyan megvalósítással, amely csak felhívja az `iter()`-et.
//! Hasonlóképpen, az `C` gyűjtemény, amely az `iter_mut()` szolgáltatja, általában az `IntoIterator` for `&mut C` alkalmazást valósítja meg az `iter_mut()`-hez történő delegálással.Ez lehetővé teszi a kényelmes gyorsírást:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // ugyanaz, mint az `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // ugyanaz, mint az `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Míg sok kollekció kínálja az `iter()`-et, nem minden kínálja az `iter_mut()`-et.
//! Például egy [`HashSet<T>`] vagy [`HashMap<K, V>`] kulcsának mutációjával a gyűjtemény inkonzisztens állapotba kerülhet, ha a kulcs kivonata megváltozik, ezért ezek a gyűjtemények csak az `iter()`-et kínálják.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Az [`Iterator`]-et felvevő és egy másik [`Iterator`]-et visszaadó funkciókat gyakran " iterátor adaptereknek`nevezik, mivel ezek az " adapter`
//! pattern'.
//!
//! Az általános iterátoradapterek közé tartozik az [`map`], [`take`] és [`filter`].
//! További információ a dokumentációjukban található.
//!
//! Ha egy iterátor adapter panics, akkor az iterátor meghatározatlan (de memóriában nem biztonságos) állapotban lesz.
//! Ez az állapot szintén nem garantált, hogy ugyanaz marad a Rust verzióiban, ezért kerülni kell a pánikba esett iterátor által adott pontos értékekre való támaszkodást.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Az iterátorok (és az [adapters](#adapters)) iterátor *lusta*. Ez azt jelenti, hogy pusztán egy iterátor létrehozása nem jelent sok mindent az _do_-en. Semmi sem történik igazán, amíg nem hívod az [`next`]-et.
//! Ez néha zavart okozhat, amikor egy iterátort csak mellékhatásai miatt hozunk létre.
//! Például az [`map`] módszer bezárást hív minden egyes elemre, amelyen keresztül ismétlődik:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Ez nem nyomtat semmilyen értéket, mivel csak iterátort hoztunk létre, ahelyett, hogy használnánk.A fordító figyelmeztet bennünket az ilyen viselkedésre:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Az [`map`] mellékhatásainak megírásához egy `for`-hurkot kell használni, vagy meg kell hívni az [`for_each`]-módszert:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Az iterátor értékelésének másik elterjedt módja az [`collect`] módszer használata egy új gyűjtemény előállításához.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Az iterátoroknak nem kell végesnek lenniük.Például egy nyílt végű tartomány végtelen iterátor:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Gyakori, hogy az [`take`] iterátor adapter segítségével egy végtelen iterátort végessé alakítanak:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Ezzel kinyomtatja az `0` - `4` számokat, mindegyiket a saját sorára.
//!
//! Ne feledje, hogy a végtelen iterátorokon alkalmazott módszerek, még azok sem, amelyek matematikailag véges idő alatt meghatározhatók, nem zárulhatnak le.
//! Pontosabban, az olyan módszerek, mint az [`min`], amelyek általában megkövetelik az iterátor minden elemének bejárását, valószínűleg nem térnek vissza egyetlen végtelen iterátorhoz sem.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Óh ne!Végtelen hurok!
//! // `ones.min()` végtelen hurkot okoz, ezért nem érjük el ezt a pontot!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;