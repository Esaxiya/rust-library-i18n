use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Olyan objektumok, amelyeknek fogalma van az *utód* és az * előd műveletekről.
///
/// Az *utód* művelet nagyobb értékek felé halad.
/// Az *előd* művelet a kevésbé összehasonlítható értékek felé halad.
///
/// # Safety
///
/// Ez a trait azért `unsafe`, mert annak megvalósításának megfelelőnek kell lennie az `unsafe trait TrustedLen` implementációk biztonsága érdekében, és ennek a trait használatának eredményeit egyébként az `unsafe` kód megbízhatja abban, hogy helyesek és teljesítik a felsorolt kötelezettségeket.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// Visszaadja az *utód* lépések számát, amelyek szükségesek az `start` és `end` közötti lépésekhez.
    ///
    /// Visszaadja az `None` értéket, ha a lépések száma túlcsordulna az `usize` között (vagy végtelen, vagy ha az `end` soha nem lenne elérhető).
    ///
    ///
    /// # Invariants
    ///
    /// Bármely `a`, `b` és `n` esetén:
    ///
    /// * `steps_between(&a, &b) == Some(n)` csak akkor, ha `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` csak akkor, ha `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` csak ha `a <= b`
    ///   * Következmény: `steps_between(&a, &b) == Some(0)` csak akkor, ha `a == b`
    ///   * Vegye figyelembe, hogy az `a <= b` az _not_-et jelenti az `steps_between(&a, &b) != None`-et;
    ///     ez az eset, amikor az `b` eléréséhez több mint `usize::MAX` lépés szükséges
    /// * `steps_between(&a, &b) == None` ha `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// Visszaadja azt az értéket, amelyet az `self` `count`-szeres *utód* felvételével kapna.
    ///
    /// Ha ez túlcsordulna az `Self` által támogatott értéktartományon, akkor az `None` értéket adja vissza.
    ///
    /// # Invariants
    ///
    /// Bármely `a`, `n` és `m` esetén:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// Minden `a`, `n` és `m` esetén, ahol az `n + m` nem túlcsordul:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// Bármely `a` és `n` esetén:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// Visszaadja azt az értéket, amelyet az `self` `count`-szeres *utód* felvételével kapna.
    ///
    /// Ha ez túlcsordulna az `Self` által támogatott értéktartományon, akkor ez a függvény panic-re, burkolásra vagy telítésre engedélyezett.
    ///
    /// A javasolt viselkedés a panic, ha a hibakeresési állítások engedélyezve vannak, és másként be kell burkolni vagy telíteni.
    ///
    /// A nem biztonságos kód nem támaszkodhat a túlcsordulás utáni viselkedés helyességére.
    ///
    /// # Invariants
    ///
    /// Minden `a`, `n` és `m` esetén, ahol nem történik túlcsordulás:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// Bármely `a` és `n` esetén, ahol nem történik túlcsordulás:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// Visszaadja azt az értéket, amelyet az `self` `count`-szeres *utód* felvételével kapna.
    ///
    /// # Safety
    ///
    /// Meghatározatlan viselkedés, hogy ez a művelet túlcsordítsa az `Self` által támogatott értéktartományt.
    /// Ha nem tudja garantálni, hogy ez nem fog túlcsordulni, használja helyette az `forward` vagy az `forward_checked` alkalmazást.
    ///
    /// # Invariants
    ///
    /// Bármely `a` esetén:
    ///
    /// * ha létezik `b`, amely `b > a`, akkor biztonságosan hívhatja az `Step::forward_unchecked(a, 1)`-et
    /// * ha létezik olyan `b`, `n`, mint `steps_between(&a, &b) == Some(n)`, akkor biztonságosan felhívhatjuk az `Step::forward_unchecked(a, m)`-et bármely `m <= n` esetén.
    ///
    ///
    /// Bármely `a` és `n` esetén, ahol nem történik túlcsordulás:
    ///
    /// * `Step::forward_unchecked(a, n)` egyenértékű az `Step::forward(a, n)`-szel
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// Visszaadja azt az értéket, amelyet az `self` `count` szorzó *elődjének* megszerzésével kapna.
    ///
    /// Ha ez túlcsordulna az `Self` által támogatott értéktartományon, akkor az `None` értéket adja vissza.
    ///
    /// # Invariants
    ///
    /// Bármely `a`, `n` és `m` esetén:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// Bármely `a` és `n` esetén:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// Visszaadja azt az értéket, amelyet az `self` `count` szorzó *elődjének* megszerzésével kapna.
    ///
    /// Ha ez túlcsordulna az `Self` által támogatott értéktartományon, akkor ez a függvény panic-re, burkolásra vagy telítésre engedélyezett.
    ///
    /// A javasolt viselkedés a panic, ha a hibakeresési állítások engedélyezve vannak, és másként be kell burkolni vagy telíteni.
    ///
    /// A nem biztonságos kód nem támaszkodhat a túlcsordulás utáni viselkedés helyességére.
    ///
    /// # Invariants
    ///
    /// Minden `a`, `n` és `m` esetén, ahol nem történik túlcsordulás:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// Bármely `a` és `n` esetén, ahol nem történik túlcsordulás:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// Visszaadja azt az értéket, amelyet az `self` `count` szorzó *elődjének* megszerzésével kapna.
    ///
    /// # Safety
    ///
    /// Meghatározatlan viselkedés, hogy ez a művelet túlcsordítsa az `Self` által támogatott értéktartományt.
    /// Ha nem tudja garantálni, hogy ez nem fog túlcsordulni, használja helyette az `backward` vagy az `backward_checked` alkalmazást.
    ///
    /// # Invariants
    ///
    /// Bármely `a` esetén:
    ///
    /// * ha létezik `b`, amely `b < a`, akkor biztonságosan hívhatja az `Step::backward_unchecked(a, 1)`-et
    /// * ha létezik olyan `b`, `n`, mint `steps_between(&b, &a) == Some(n)`, akkor biztonságosan felhívhatjuk az `Step::backward_unchecked(a, m)`-et bármely `m <= n` esetén.
    ///
    ///
    /// Bármely `a` és `n` esetén, ahol nem történik túlcsordulás:
    ///
    /// * `Step::backward_unchecked(a, n)` egyenértékű az `Step::backward(a, n)`-szel
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Ezeket továbbra is makró által generálták, mert az egész literálok különböző típusúak.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // BIZTONSÁG: a hívónak garantálnia kell, hogy az `start + n` ne folyjon túl.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // BIZTONSÁG: a hívónak garantálnia kell, hogy az `start - n` ne folyjon túl.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // Hibakeresési összeállításoknál indítson el egy panic-t túlcsorduláskor.
            // Ennek teljesen optimalizálnia kell a kiadás buildjeiben.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Csomagoljon matekot, hogy pl `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // Hibakeresési összeállításoknál indítson el egy panic-t túlcsorduláskor.
            // Ennek teljesen optimalizálnia kell a kiadás buildjeiben.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Csomagoljon matekot, hogy pl `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Ez az $u_narrower <=usize-re támaszkodik
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // ha n kívül esik a tartományon, akkor az `unsigned_start + n` is
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // ha n kívül esik a tartományon, akkor az `unsigned_start - n` is
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Ez az $i_narrower <=usize-re támaszkodik
                        //
                        // A méretre öntés kiterjeszti a szélességet, de megőrzi a jelet.
                        // Használja a wrapping_sub elemet az isize szóközben, és a cast használatával számítsa ki azt a különbséget, amely esetleg nem fér bele az isize tartományba.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // A csomagolás olyan tokokat kezel, mint az `Step::forward(-120_i8, 200) == Some(80_i8)`, annak ellenére, hogy a 200 az i8 tartományán kívül esik.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // Az összeadás túlcsordult
                            }
                        }
                        // Ha n kívül esik pl
                        // u8, akkor nagyobb, mint az i8 teljes tartománya, így az `any_i8 + n` szükségszerűen túlcsordítja az i8-et.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // A csomagolás olyan tokokat kezel, mint az `Step::forward(-120_i8, 200) == Some(80_i8)`, annak ellenére, hogy a 200 az i8 tartományán kívül esik.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // A kivonás túlcsordult
                            }
                        }
                        // Ha n kívül esik pl
                        // u8, akkor nagyobb, mint az i8 teljes tartománya, így az `any_i8 - n` szükségszerűen túlcsordítja az i8-et.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // Ha a különbség túl nagy pl
                            // i128, az is túl nagy lesz, hogy kevesebb bitet használhassunk.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // BIZTONSÁG: a res érvényes unicode skalár
            // (0x110000 alatt és nem 0xD800..0xE000 alatt)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // BIZTONSÁG: a res érvényes unicode skalár
        // (0x110000 alatt és nem 0xD800..0xE000 alatt)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // BIZTONSÁG: a hívónak garantálnia kell, hogy ez ne folyjon túl
        // egy karakter értéktartománya.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // BIZTONSÁG: a hívónak garantálnia kell, hogy ez ne folyjon túl
            // egy karakter értéktartománya.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // BIZTONSÁG: az előző szerződés miatt ez garantált
        // hogy a hívó fél érvényes karakter legyen.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // BIZTONSÁG: a hívónak garantálnia kell, hogy ez ne folyjon túl
        // egy karakter értéktartománya.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // BIZTONSÁG: a hívónak garantálnia kell, hogy ez ne folyjon túl
            // egy karakter értéktartománya.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // BIZTONSÁG: az előző szerződés miatt ez garantált
        // hogy a hívó fél érvényes karakter legyen.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // BIZTONSÁG: csak ellenőrizte az előfeltételt
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // BIZTONSÁG: csak ellenőrizte az előfeltételt
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Ezek a makrók különböző tartománytípusokhoz generálnak `ExactSizeIterator` impliciteket.
//
// * `ExactSizeIterator::len` mindig meg kell adni egy pontos `usize` értéket, így egyetlen tartomány sem lehet hosszabb az `usize::MAX`-nél.
//
// * Az `Range<_>`-ben szereplő egész típusú típusok esetében ez az `usize`-nél keskenyebb vagy szélesebb típusok esetében érvényes.
//   Az `RangeInclusive<_>`-ben szereplő egész típusú típusok esetében ez a *szigorúan keskenyebb* típusok esetében érvényes, mint az `usize`, mivel pl
//   `(0..=u64::MAX).len()` `u64::MAX + 1` lenne.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Ezeket a fenti érvelés szerint beépítjük, de eltávolításuk megtörő változás lenne, mivel stabilizálódtak a Rust 1.0.0-ben.
    // Tehát pl
    // `(0..66_000_u32).len()` Például hiba vagy figyelmeztetés nélkül fordít 16 bites platformokon, de továbbra is rossz eredményt ad.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Ezeket a fenti érvelés szerint beépítjük, de eltávolításuk megtörő változás lenne, mivel stabilizálódtak a Rust 1.26.0-ben.
    // Tehát pl
    // `(0..=u16::MAX).len()` Például hiba vagy figyelmeztetés nélkül fordít 16 bites platformokon, de továbbra is rossz eredményt ad.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // BIZTONSÁG: csak ellenőrizte az előfeltételt
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // BIZTONSÁG: csak ellenőrizte az előfeltételt
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // BIZTONSÁG: csak ellenőrizte az előfeltételt
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // BIZTONSÁG: csak ellenőrizte az előfeltételt
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // BIZTONSÁG: csak ellenőrizte az előfeltételt
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // BIZTONSÁG: csak ellenőrizte az előfeltételt
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}