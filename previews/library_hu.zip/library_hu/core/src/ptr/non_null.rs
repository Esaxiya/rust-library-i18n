use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` de nem nulla és kovariáns.
///
/// Ez gyakran helyes, ha az adatstruktúrákat nyers mutatók segítségével építjük fel, de végül további tulajdonságai miatt veszélyesebb használni.Ha nem biztos abban, hogy az `NonNull<T>`-et használja, akkor csak az `*mut T`-et használja!
///
/// Az `*mut T`-től eltérően a mutatónak mindig nem nullának kell lennie, még akkor is, ha a mutatóra soha nem hivatkoznak.Ez azért van, hogy az enums ezt a tiltott értéket diszkriminánsként használhassa-az `Option<NonNull<T>>` mérete megegyezik az `* mut T` méretével.
/// A mutató azonban továbbra is lóghat, ha nem hivatkozunk rá.
///
/// Az `*mut T`-től eltérően az `NonNull<T>`-et úgy választották meg, hogy kovariáns legyen az `T`-hez képest.Ez lehetővé teszi az `NonNull<T>` használatát kovariáns típusok építésénél, de megalapozza az alaptalanság kockázatát, ha olyan típusban használják, amely valójában nem lenne kovariáns.
/// (Az `*mut T` esetében ezzel ellentétes döntést hoztak, annak ellenére, hogy technikailag a hangtalanságot csak nem biztonságos funkciók hívása okozhatta.)
///
/// A kovariancia helyes a legtöbb biztonságos absztrakció esetében, például `Box`, `Rc`, `Arc`, `Vec` és `LinkedList`.Ez azért van, mert egy nyilvános API-t biztosítanak, amely a Rust normál, megosztott XOR módosítható szabályait követi.
///
/// Ha a típusod nem lehet biztonságosan kovariáns, akkor meg kell győződnöd arról, hogy tartalmaz-e további mezőket a változatlanság biztosítása érdekében.Ez a mező gyakran [`PhantomData`] típusú lesz, például `PhantomData<Cell<T>>` vagy `PhantomData<&'a mut T>`.
///
/// Figyelje meg, hogy az `NonNull<T>` rendelkezik `From` példánnyal az `&T` számára.Ez azonban nem változtat azon a tényen, hogy a (hivatkozásból származó mutató) megosztott referencián keresztül történő mutáció nem meghatározott viselkedés, hacsak a mutáció egy [`UnsafeCell<T>`]-en belül nem történik meg.Ugyanez vonatkozik egy módosítható hivatkozás létrehozására megosztott hivatkozásból.
///
/// Ha ezt az `From` példányt `UnsafeCell<T>` nélkül használja, az Ön felelőssége annak biztosítása, hogy az `as_mut` soha ne legyen meghívva, és az `as_ptr`-et soha ne használják mutációra.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` a mutatók nem `Send`, mert az általuk hivatkozott adatok álnéven szerepelhetnek.
// Megjegyzés: ez az implicit felesleges, de jobb hibaüzeneteket kell szolgáltatnia.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` a mutatók nem `Sync`, mert az általuk hivatkozott adatok álnéven szerepelhetnek.
// Megjegyzés: ez az implicit felesleges, de jobb hibaüzeneteket kell szolgáltatnia.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Létrehoz egy új `NonNull`-et, amely lóg, de jól illeszkedik.
    ///
    /// Ez hasznos a lustán allokáló típusok inicializálásához, mint az `Vec::new`.
    ///
    /// Vegye figyelembe, hogy a mutató értéke egy érvényes mutatót jelenthet egy `T`-hez, ami azt jelenti, hogy ezt nem szabad "not yet initialized" őrszem értékként használni.
    /// A lustán kiosztott típusoknak valamilyen más eszközzel kell követniük az inicializálást.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // BIZTONSÁG: Az mem::align_of() nullától eltérő felhasználást ad vissza, amelyet aztán leadnak
        // egy * mut T.
        // Ezért az `ptr` nem semleges, és az new_unchecked() hívásának feltételeit tiszteletben tartják.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Visszaad egy megosztott hivatkozást az értékre.Az [`as_ref`]-szel ellentétben ez nem igényli az érték inicializálását.
    ///
    /// A mutálható megfelelőt lásd: [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// A módszer meghívásakor meg kell győződnie arról, hogy az alábbiak mindegyike igaz:
    ///
    /// * A mutatónak megfelelően kell lennie.
    ///
    /// * Ennek "dereferencable"-nek kell lennie az [the module documentation]-ben meghatározott értelemben.
    ///
    /// * Kényszerítenie kell a Rust álnevezési szabályait, mivel az `'a` visszaadott élettartamot önkényesen választják, és nem feltétlenül tükrözi az adatok tényleges élettartamát.
    ///
    ///   Különösen ezen élettartam alatt a memória, amelyre a mutató mutat, nem mutálódhat (kivéve az `UnsafeCell` belsejét).
    ///
    /// Ez akkor is érvényes, ha a módszer eredményét nem használják fel!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // BIZTONSÁG: a hívónak garantálnia kell, hogy az `self` megfelel az összes követelménynek
        // referenciára vonatkozó követelmények.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Egyedi hivatkozásokat ad vissza az értékre.Az [`as_mut`]-szel ellentétben ez nem igényli az érték inicializálását.
    ///
    /// A megosztott partnerről lásd: [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// A módszer meghívásakor meg kell győződnie arról, hogy az alábbiak mindegyike igaz:
    ///
    /// * A mutatónak megfelelően kell lennie.
    ///
    /// * Ennek "dereferencable"-nek kell lennie az [the module documentation]-ben meghatározott értelemben.
    ///
    /// * Kényszerítenie kell a Rust álnevezési szabályait, mivel az `'a` visszaadott élettartamot önkényesen választják, és nem feltétlenül tükrözi az adatok tényleges élettartamát.
    ///
    ///   Különösen ezen élettartam alatt a memória, amelyre a mutató mutat, semmilyen más mutatón keresztül nem férhet hozzá (olvasható vagy írható).
    ///
    /// Ez akkor is érvényes, ha a módszer eredményét nem használják fel!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // BIZTONSÁG: a hívónak garantálnia kell, hogy az `self` megfelel az összes követelménynek
        // referenciára vonatkozó követelmények.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Létrehoz egy új `NonNull`-et.
    ///
    /// # Safety
    ///
    /// `ptr` nem null értékűnek kell lennie.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // BIZTONSÁG: a hívónak garantálnia kell, hogy az `ptr` nem null.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Új `NonNull`-t hoz létre, ha az `ptr` nem null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // BIZTONSÁG: A mutató már be van jelölve, és nem null
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Ugyanazt a funkciót látja el, mint az [`std::ptr::from_raw_parts`], azzal a különbséggel, hogy egy `NonNull` mutatót ad vissza, szemben a nyers `*const` mutatóval.
    ///
    ///
    /// További részletekért lásd az [`std::ptr::from_raw_parts`] dokumentációját.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // BIZTONSÁG: Az `ptr::from::raw_parts_mut` eredménye nem null, mert az `data_address` az.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Bontani egy (esetleg széles) mutatót cím-és metaadat-összetevőkké.
    ///
    /// A mutató később rekonstruálható az [`NonNull::from_raw_parts`] segítségével.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Megszerzi az alapul szolgáló `*mut` mutatót.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Visszaad egy megosztott hivatkozást az értékre.Ha az érték nem inicializálható, akkor [`as_uninit_ref`]-et kell használni.
    ///
    /// A mutálható megfelelőt lásd: [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// A módszer meghívásakor meg kell győződnie arról, hogy az alábbiak mindegyike igaz:
    ///
    /// * A mutatónak megfelelően kell lennie.
    ///
    /// * Ennek "dereferencable"-nek kell lennie az [the module documentation]-ben meghatározott értelemben.
    ///
    /// * A mutatónak az `T` inicializált példányára kell mutatnia.
    ///
    /// * Kényszerítenie kell a Rust álnevezési szabályait, mivel az `'a` visszaadott élettartamot önkényesen választják, és nem feltétlenül tükrözi az adatok tényleges élettartamát.
    ///
    ///   Különösen ezen élettartam alatt a memória, amelyre a mutató mutat, nem mutálódhat (kivéve az `UnsafeCell` belsejét).
    ///
    /// Ez akkor is érvényes, ha a módszer eredményét nem használják fel!
    /// (Az inicializálásról még nincs teljesen eldöntve, de amíg ez meg nem történik, az egyetlen biztonságos megközelítés az, hogy valóban inicializálják őket.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // BIZTONSÁG: a hívónak garantálnia kell, hogy az `self` megfelel az összes követelménynek
        // referenciára vonatkozó követelmények.
        unsafe { &*self.as_ptr() }
    }

    /// Egyedi hivatkozást ad vissza az értékre.Ha az érték nem inicializálható, akkor [`as_uninit_mut`]-et kell használni.
    ///
    /// A megosztott partnerről lásd: [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// A módszer meghívásakor meg kell győződnie arról, hogy az alábbiak mindegyike igaz:
    ///
    /// * A mutatónak megfelelően kell lennie.
    ///
    /// * Ennek "dereferencable"-nek kell lennie az [the module documentation]-ben meghatározott értelemben.
    ///
    /// * A mutatónak az `T` inicializált példányára kell mutatnia.
    ///
    /// * Kényszerítenie kell a Rust álnevezési szabályait, mivel az `'a` visszaadott élettartamot önkényesen választják, és nem feltétlenül tükrözi az adatok tényleges élettartamát.
    ///
    ///   Különösen ezen élettartam alatt a memória, amelyre a mutató mutat, semmilyen más mutatón keresztül nem férhet hozzá (olvasható vagy írható).
    ///
    /// Ez akkor is érvényes, ha a módszer eredményét nem használják fel!
    /// (Az inicializálásról még nincs teljesen eldöntve, de amíg ez meg nem történik, az egyetlen biztonságos megközelítés az, hogy valóban inicializálják őket.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // BIZTONSÁG: a hívónak garantálnia kell, hogy az `self` megfelel az összes követelménynek
        // a mutálható referenciára vonatkozó követelmények.
        unsafe { &mut *self.as_ptr() }
    }

    /// Más típusú mutatóra vetít.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // BIZTONSÁG: Az `self` egy `NonNull` mutató, amely szükségszerűen nem null
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Nem null nyers szeletet hoz létre egy vékony mutatóból és egy hosszúságból.
    ///
    /// Az `len` argumentum a **elemek** száma, nem a bájtok száma.
    ///
    /// Ez a funkció biztonságos, de a visszatérési érték levonása nem biztonságos.
    /// A szeletek biztonsági követelményeit az [`slice::from_raw_parts`] dokumentációjában találja.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // hozzon létre egy szeletmutatót, amikor az első elem mutatójával kezdi
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Ne feledje, hogy ez a példa mesterségesen mutatja be ennek a módszernek a használatát, de `legyen a slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // BIZTONSÁG: Az `data` egy `NonNull` mutató, amely szükségszerűen nem null
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Visszaadja a nem null nyers szelet hosszát.
    ///
    /// A visszaadott érték a **elemek száma**, nem a bájtok száma.
    ///
    /// Ez a funkció akkor is biztonságos, ha a nem null nyers szelet nem vonható le egy szeletre, mert a mutatónak nincs érvényes címe.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Nem null mutatót ad vissza a szelet pufferjébe.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // BIZTONSÁG: Tudjuk, hogy az `self` nem null.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Visszaad egy nyers mutatót a szelet pufferjébe.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Visszaad egy megosztott hivatkozást egy esetlegesen inicializálatlan értékek szeletére.Az [`as_ref`]-szel ellentétben ez nem igényli az érték inicializálását.
    ///
    /// A mutálható megfelelőt lásd: [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// A módszer meghívásakor meg kell győződnie arról, hogy az alábbiak mindegyike igaz:
    ///
    /// * A mutatónak [valid] értékűnek kell lennie a sok bájtos `ptr.len() * mem::size_of::<T>()` beolvasásokhoz, és megfelelőnek kell lennie.Ez különösen a következőket jelenti:
    ///
    ///     * Ennek a szeletnek a teljes memóriatartományának egyetlen lefoglalt objektumon belül kell lennie!
    ///       A szeletek soha nem terjedhetnek át több allokált objektumon.
    ///
    ///     * A mutatót még a nulla hosszúságú szeleteknél is igazítani kell.
    ///     Ennek egyik oka az, hogy az enum elrendezés optimalizálása támaszkodhat arra, hogy a referenciák (beleértve a bármilyen hosszúságú szeleteket) összehangoltak és nem nullák, hogy megkülönböztessék őket más adatoktól.
    ///
    ///     Az [`NonNull::dangling()`] használatával olyan mutatót kaphat, amely `data` néven használható nulla hosszúságú szeletekhez.
    ///
    /// * A szelet teljes `ptr.len() * mem::size_of::<T>()` mérete nem lehet nagyobb, mint `isize::MAX`.
    ///   Lásd az [`pointer::offset`] biztonsági dokumentációját.
    ///
    /// * Kényszerítenie kell a Rust álnevezési szabályait, mivel az `'a` visszaadott élettartamot önkényesen választják, és nem feltétlenül tükrözi az adatok tényleges élettartamát.
    ///   Különösen ezen élettartam alatt a memória, amelyre a mutató mutat, nem mutálódhat (kivéve az `UnsafeCell` belsejét).
    ///
    /// Ez akkor is érvényes, ha a módszer eredményét nem használják fel!
    ///
    /// Lásd még: [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // BIZTONSÁG: a hívónak be kell tartania az `as_uninit_slice` biztonsági szerződését.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Egyedi hivatkozást ad vissza az esetlegesen inicializálatlan értékek szeletére.Az [`as_mut`]-szel ellentétben ez nem igényli az érték inicializálását.
    ///
    /// A megosztott partnerről lásd: [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// A módszer meghívásakor meg kell győződnie arról, hogy az alábbiak mindegyike igaz:
    ///
    /// * A mutatónak [valid] értékűnek kell lennie az `ptr.len() * mem::size_of::<T>()` sok bájtos olvasáshoz és íráshoz, és megfelelőnek kell lennie.Ez különösen a következőket jelenti:
    ///
    ///     * Ennek a szeletnek a teljes memóriatartományának egyetlen lefoglalt objektumon belül kell lennie!
    ///       A szeletek soha nem terjedhetnek át több allokált objektumon.
    ///
    ///     * A mutatót még a nulla hosszúságú szeleteknél is igazítani kell.
    ///     Ennek egyik oka az, hogy az enum elrendezés optimalizálása támaszkodhat arra, hogy a referenciák (beleértve a bármilyen hosszúságú szeleteket) összehangoltak és nem nullák, hogy megkülönböztessék őket más adatoktól.
    ///
    ///     Az [`NonNull::dangling()`] használatával olyan mutatót kaphat, amely `data` néven használható nulla hosszúságú szeletekhez.
    ///
    /// * A szelet teljes `ptr.len() * mem::size_of::<T>()` mérete nem lehet nagyobb, mint `isize::MAX`.
    ///   Lásd az [`pointer::offset`] biztonsági dokumentációját.
    ///
    /// * Kényszerítenie kell a Rust álnevezési szabályait, mivel az `'a` visszaadott élettartamot önkényesen választják, és nem feltétlenül tükrözi az adatok tényleges élettartamát.
    ///   Különösen ezen élettartam alatt a memória, amelyre a mutató mutat, semmilyen más mutatón keresztül nem férhet hozzá (olvasható vagy írható).
    ///
    /// Ez akkor is érvényes, ha a módszer eredményét nem használják fel!
    ///
    /// Lásd még: [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Ez biztonságos, mivel az `memory` sok bájtos `memory.len()`-re használható.
    /// // Ne feledje, hogy az `memory.as_mut()` hívása itt nem megengedett, mivel előfordulhat, hogy a tartalom inicializálatlan.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // BIZTONSÁG: a hívónak be kell tartania az `as_uninit_slice_mut` biztonsági szerződését.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Visszaad egy nyers mutatót egy elemhez vagy alszelethez, anélkül, hogy korlátokat ellenőrizne.
    ///
    /// Ha ezt a módszert határon kívüli indexszel hívjuk meg, vagy ha az `self` nem engedhető le, akkor a [[meghatározatlan viselkedés] * még akkor is, ha a kapott mutatót nem használjuk.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // BIZTONSÁG: a hívó biztosítja, hogy az `self`-t alárendelhetővé tegye, és az `index`-et határon belülre.
        // Ennek eredményeként a kapott mutató nem lehet NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // BIZTONSÁG: Egy egyedi mutató nem lehet null, tehát a feltételei
        // new_unchecked() tiszteletben tartják.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // BIZTONSÁG: A módosítható hivatkozás nem lehet null.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // BIZTONSÁG: A hivatkozás nem lehet null, ezért a feltételei
        // new_unchecked() tiszteletben tartják.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}