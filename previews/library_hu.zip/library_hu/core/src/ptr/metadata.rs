#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Megadja az összes mutatós metaadat típusát.
///
/// # Mutató metaadatai
///
/// A Rust nyers mutató típusai és referencia típusai két részből állhatnak:
/// adatmutató, amely tartalmazza az érték memória címét és néhány metaadatot.
///
/// A statikus méretű (az `Sized` traits megvalósítására alkalmas) típusok, valamint az `extern` típusok esetében a mutatókat " vékonynak` mondják: a metaadatok nulla méretűek, típusa pedig `()`.
///
///
/// Az [dynamically-sized types][dst]-re mutató mutatók " széles`vagy " kövérek`, nem nulla méretű metaadatokkal rendelkeznek:
///
/// * Azoknál a struktúráknál, amelyek utolsó mezője DST, a metaadatok az utolsó mező metaadatai
/// * Az `str` típusnál a metaadatok a hossza bájtokban, mint `usize`
/// * Az olyan szelettípusoknál, mint az `[T]`, a metaadatok az elemek hossza, mint `usize`
/// * Az olyan trait objektumok esetében, mint az `dyn SomeTrait`, a metaadatok [`DynMetadata<Self>`][DynMetadata] (pl. `DynMetadata<dyn SomeTrait>`)
///
/// A future alkalmazásban a Rust nyelv új típusú típusokat nyerhet, amelyeknek különböző mutató metaadatok vannak.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # Az `Pointee` trait
///
/// Ennek a trait-nek a pontja az `Metadata` társított típusa, amely `()`, `usize` vagy `DynMetadata<_>`, a fent leírtak szerint.
/// Ez automatikusan megvalósul minden típushoz.
/// Feltételezhető, hogy általános összefüggésben valósul meg, még megfelelő kötöttség nélkül is.
///
/// # Usage
///
/// A nyers mutatók az [`to_raw_parts`] módszerükkel bonthatók adatcímre és metaadat-összetevőkre.
///
/// Alternatív megoldásként csak a metaadatokat lehet kinyerni az [`metadata`] funkcióval.
/// Hivatkozás átadható az [`metadata`]-nek és implicit módon kényszeríthető.
///
/// Az (possibly-wide) mutató a címéből és a metaadatokból az [`from_raw_parts`] vagy [`from_raw_parts_mut`] segítségével állítható össze.
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// A metaadatok típusa mutatókban és hivatkozások az `Self`-re.
    #[lang = "metadata_type"]
    // NOTE: Tartsa a trait bounds funkciót `static_assert_expected_bounds_for_metadata`-ben
    //
    // az `library/core/src/ptr/metadata.rs`-ben szinkronban az itt leírtakkal:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Az ezt a trait álnevet megvalósító típusokra mutató mutatók " vékonyak`.
///
/// Ez magában foglalja a statikusan méretezett és az `extern` típusokat.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: ne stabilizáld ezt, mielőtt a trait álnevek stabilak lennének a nyelvben?
pub trait Thin = Pointee<Metadata = ()>;

/// Bontsa ki a mutató metaadat-összetevőjét.
///
/// Az `*mut T`, `&T` vagy `&mut T` típusú értékeket közvetlenül átadhatjuk ennek a függvénynek, mivel azok implicit módon kényszerítik az `* const T`-et.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // BIZTONSÁG: Az érték elérése az `PtrRepr` unióból biztonságos, mivel * const T
    // és a PtrComponents<T>ugyanazokkal a memóriaelrendezésekkel rendelkezik.
    // Csak a std teheti ezt a garanciát.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// (possibly-wide) nyers mutatót képez egy adatcímből és metaadatokból.
///
/// Ez a funkció biztonságos, de a visszaküldött mutató nem feltétlenül biztonságos.
/// A szeletekről az [`slice::from_raw_parts`] dokumentációjában olvashatja el a biztonsági követelményeket.
/// A trait objektumok esetében a metaadatoknak egy mutatóból ugyanahhoz a mögöttes kibontott típushoz kell érkezniük.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // BIZTONSÁG: Az érték elérése az `PtrRepr` unióból biztonságos, mivel * const T
    // és a PtrComponents<T>ugyanazokkal a memóriaelrendezésekkel rendelkezik.
    // Csak a std teheti ezt a garanciát.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Ugyanazt a funkciót látja el, mint az [`from_raw_parts`], azzal a különbséggel, hogy egy nyers `*mut` mutató kerül visszaadásra, szemben a nyers `* const` mutatóval.
///
///
/// További részletekért lásd az [`from_raw_parts`] dokumentációját.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // BIZTONSÁG: Az érték elérése az `PtrRepr` unióból biztonságos, mivel * const T
    // és a PtrComponents<T>ugyanazokkal a memóriaelrendezésekkel rendelkezik.
    // Csak a std teheti ezt a garanciát.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Az `T: Copy` bekötésének elkerülése érdekében kézi implikáció szükséges.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Az `T: Clone` bekötésének elkerülése érdekében kézi implikáció szükséges.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Az `Dyn = dyn SomeTrait` trait objektumtípus metaadatai.
///
/// Ez egy vtable (virtuális hívástábla) mutatója, amely minden szükséges információt képvisel a trait objektumon belül tárolt betontípus kezeléséhez.
/// A vtable nevezetesen a következőket tartalmazza:
///
/// * típusméret
/// * típus igazítás
/// * mutató a típus `drop_in_place` implicitjére (lehet, hogy a sima-old-data esetében nincs opció)
/// * rámutat a trait típusának megvalósításához szükséges összes módszerre
///
/// Ne feledje, hogy az első három azért különleges, mert minden trait objektum lefoglalásához, eldobásához és elosztásához szükségesek.
///
/// Lehetséges ezt a struktúrát olyan típusú paraméterrel megnevezni, amely nem `dyn` trait objektum (például `DynMetadata<u64>`), de nem lehet megszerezni a struktúra értelmes értékét.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Az összes vtable közös előtagja.Ezt követik a funkciómutatók a trait módszerekhez.
///
/// Az `DynMetadata::size_of` stb. Privát megvalósítási részletei
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Visszaadja az ehhez a vtable-hez társított típus méretét.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Visszaadja az ehhez a vtable-hez társított típus igazítását.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// `Layout` formátumban adja vissza a méretet és az igazítást
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // BIZTONSÁG: A fordító ezt a nézetet kiadta egy konkrét Rust típushoz
        // ismert, hogy érvényes elrendezéssel rendelkezik.Ugyanaz az indoklás, mint az `Layout::for_value` esetében.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Az `Dyn: $Trait` határok elkerülése érdekében kézi implikációkra van szükség.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}