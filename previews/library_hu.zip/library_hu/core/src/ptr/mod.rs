//! A memória kézi kezelése nyers mutatók segítségével.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! A modul számos funkciója a nyers mutatókat argumentumként veszi fel, és olvas ki belőlük, vagy ír nekik.A biztonság érdekében ezeknek a mutatóknak * érvényesnek kell lenniük.
//! Az, hogy egy mutató érvényes-e, attól függ, hogy milyen műveletet használunk (olvasás vagy írás), valamint a memória elérési idejétől (azaz hány bájt az read/written).
//! A legtöbb függvény az `*mut T` és az `* const T` használatával csak egyetlen értékhez férhet hozzá, ebben az esetben a dokumentáció elhagyja a méretet, és implicit módon feltételezi, hogy `size_of::<T>()` bájt.
//!
//! Az érvényesség pontos szabályait még nem határozták meg.Az ezen a ponton nyújtott garanciák nagyon minimálisak:
//!
//! * Az [null] mutató *soha* nem érvényes, még az [size zero][zst] hozzáféréseire sem.
//! * Ahhoz, hogy a mutató érvényes legyen, szükséges, de nem mindig elégséges, hogy a mutató legyen *levezethető*: a mutatótól kezdődő megadott méretű memóriatartománynak mind egyetlen lefoglalt objektum határain belül kell lennie.
//!
//! Vegye figyelembe, hogy a Rust alkalmazásban minden (stack-allocated) változó külön allokált objektumnak számít.
//! * Még az [size zero][zst] műveletei esetében sem szabad, hogy a mutató az elosztott memóriára mutasson, vagyis az elosztás a nullátlan műveletek esetén is érvénytelenné teszi a mutatókat.
//! Bármely nem nulla egész szám *literál* mutatóra történő öntése nulla méretű hozzáférések esetén is érvényes, még akkor is, ha az adott címen előfordul némi memória, és elosztják.
//! Ez megfelel a saját allokátorának megírásának: a nulla méretű objektumok kiosztása nem túl nehéz.
//! A nulla méretű hozzáférésekre érvényes mutató megszerzésének kanonikus módja az [`NonNull::dangling`].
//! * Az ebben a modulban található funkciók által végrehajtott összes hozzáférés *nem atomi* az [atomic operations] értelmében szálak szinkronizálására szolgál.
//! Ez azt jelenti, hogy nem meghatározott viselkedés két egyidejű hozzáférést ugyanahhoz a helyhez, különböző szálakból, kivéve, ha mindkét hozzáférés csak a memóriából olvas.
//! Figyelje meg, hogy ez kifejezetten magában foglalja az [`read_volatile`]-et és az [`write_volatile`]-et: Az illékony hozzáférések nem használhatók szálak közötti szinkronizálásra.
//! * A mutatóra történő hivatkozás leadásának eredménye mindaddig érvényes, amíg az alapul szolgáló objektum él, és ugyanarra a memóriára való hozzáféréshez nem használunk referenciát (csak nyers mutatók).
//!
//! Ezek az axiómák, valamint az [`offset`] mutatószámtani körültekintő használata elegendő ahhoz, hogy sok hasznos dolgot helyesen hajtsanak végre nem biztonságos kódban.
//! Erősebb garanciákat nyújtunk végül, mivel az [aliasing] szabályokat meghatározzák.
//! További információkért lásd az [book]-et, valamint az [undefined behavior][ub]-nek szentelt referencia szakaszát.
//!
//! ## Alignment
//!
//! A fent definiált érvényes nyers mutatók nem feltétlenül vannak megfelelően igazítva (ahol az "proper" igazítást a pointee típusa határozza meg, azaz az `*const T`-et az `mem::align_of::<T>()`-hez kell igazítani).
//! A legtöbb függvényhez azonban meg kell követelni az érvek megfelelő összehangolását, és ezt a követelményt kifejezetten megfogalmazzák a dokumentációjukban.
//! Figyelemre méltó kivétel ez alól az [`read_unaligned`] és az [`write_unaligned`].
//!
//! Amikor egy funkció megfelelő összehangolást igényel, akkor is ezt teszi, ha a hozzáférés mérete 0, még akkor is, ha a memóriához valójában nem nyúlnak hozzá.Fontolja meg az [`NonNull::dangling`] használatát ilyen esetekben.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Végrehajtja a rámutatott érték rombolóját (ha van ilyen).
///
/// Ez szemantikailag egyenértékű az [`ptr::read`] hívásával és az eredmény elvetésével, de a következő előnyökkel jár:
///
/// * *Szükséges* az `drop_in_place` használatával olyan méret nélküli típusok eldobására, mint a trait objektumok, mert ezeket nem lehet felolvasni a veremre és normálisan ledobni.
///
/// * Az optimalizálónak barátságosabb ezt [`ptr::read`]-en keresztül csinálni, amikor eldobja a manuálisan kiosztott memóriát (pl. Az `Box`/`Rc`/`Vec` megvalósításaiban), mivel a fordítónak nem kell bizonyítania, hogy hangos-e a másolat elidőzése.
///
///
/// * Használható [pinned] adatok eldobására, ha az `T` nem `repr(packed)` (a rögzített adatokat nem szabad áthelyezni, mielőtt eldobnák).
///
/// Az igazítatlan értékeket nem lehet a helyükre dobni, ezeket az [`ptr::read_unaligned`] segítségével először egy igazított helyre kell másolni.Csomagolt szerkezeteknél ezt a lépést a fordító automatikusan elvégzi.
/// Ez azt jelenti, hogy a becsomagolt szerkezetek mezői nem kerülnek a helyükre.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// A viselkedés nincs meghatározva, ha az alábbi feltételek bármelyikét megsértik:
///
/// * `to_drop` [valid] kell, hogy legyen mind az olvasás, mind az írás esetén.
///
/// * `to_drop` megfelelően kell beállítani.
///
/// * Az `to_drop` pont értéknek érvényesnek kell lennie a dobáshoz, ami azt jelentheti, hogy további invariánsokat kell fenntartania, ez típusfüggő.
///
/// Továbbá, ha az `T` nem [`Copy`], akkor az `drop_in_place` hívása után a hegyes érték használata meghatározatlan viselkedést okozhat.Ne feledje, hogy az `*to_drop = foo` felhasználásnak számít, mert ez az érték ismét csökkenését eredményezi.
/// [`write()`] felhasználható az adatok felülírására anélkül, hogy azok eldobódnának.
///
/// Vegye figyelembe, hogy még akkor is, ha az `T` mérete `0`, a mutatónak nem NULL értékűnek kell lennie, és megfelelően kell igazodnia.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Az utolsó elem kézi eltávolítása a vector alkalmazásból:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Nyers mutató az `v` utolsó elemére.
///     let ptr = &mut v[1] as *mut _;
///     // Rövidítse le az `v`-et, hogy megakadályozza az utolsó elem leejtését.
///     // Először ezt tesszük, hogy megakadályozzuk a problémákat, ha az `drop_in_place` a panics alatt van.
///     v.set_len(1);
///     // `drop_in_place` hívás nélkül az utolsó elem soha nem esne el, és az általa kezelt memória kiszivárog.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Győződjön meg arról, hogy az utolsó elemet eldobta.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Figyelje meg, hogy a fordító ezt a másolatot automatikusan végrehajtja, amikor eldobja a csomagokat, azaz általában nem kell aggódnia az ilyen problémák miatt, hacsak nem manuálisan hívja az `drop_in_place`-et.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // A kód itt nem számít, ezt a fordító valódi drop ragasztóval helyettesíti.
    //

    // BIZTONSÁG: lásd a fenti megjegyzést
    unsafe { drop_in_place(to_drop) }
}

/// Létrehoz egy null nyers mutatót.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Létrehoz egy nullával módosítható nyers mutatót.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Az `T: Clone` bekötésének elkerülése érdekében kézi implikáció szükséges.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Az `T: Copy` bekötésének elkerülése érdekében kézi implikáció szükséges.
impl<T> Copy for FatPtr<T> {}

/// Nyers szeletet képez egy mutatóból és egy hosszúságból.
///
/// Az `len` argumentum a **elemek** száma, nem a bájtok száma.
///
/// Ez a funkció biztonságos, de a visszatérési érték használata valójában nem biztonságos.
/// A szeletek biztonsági követelményeit az [`slice::from_raw_parts`] dokumentációjában találja.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // hozzon létre egy szeletmutatót, amikor az első elem mutatójával kezdi
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // BIZTONSÁG: Az érték elérése az `Repr` unióból biztonságos, mivel * const [T]
        //
        // és a FatPtr ugyanazokkal a memóriaelrendezésekkel rendelkezik.Csak a std teheti ezt a garanciát.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Ugyanazt a funkciót látja el, mint az [`slice_from_raw_parts`], azzal a különbséggel, hogy egy nyers módosítható szelet kerül vissza, szemben a nyers módosíthatatlan szelettel.
///
///
/// További részletekért lásd az [`slice_from_raw_parts`] dokumentációját.
///
/// Ez a funkció biztonságos, de a visszatérési érték használata valójában nem biztonságos.
/// A szeletek biztonsági követelményeit az [`slice::from_raw_parts_mut`] dokumentációjában találja.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // hozzárendel egy értéket a szelet indexéhez
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // BIZTONSÁG: Az érték elérése az `Repr` unióból biztonságos, mivel * mut [T]
        // és a FatPtr ugyanazokkal a memóriaelrendezésekkel rendelkezik
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Az értékeket két azonos típusú mutálható helyen cseréli fel, deinicializálás nélkül.
///
/// De a következő két kivétel esetén ez a függvény szemantikailag egyenértékű az [`mem::swap`]-szel:
///
///
/// * Nyers mutatókon alapul, hivatkozások helyett.
/// Amikor rendelkezésre állnak referenciák, az [`mem::swap`]-et kell előnyben részesíteni.
///
/// * A két rámutatott érték átfedhet.
/// Ha az értékek átfedik egymást, akkor az `x` memóriájának átfedő régiója kerül felhasználásra.
/// Ezt az alábbi második példa mutatja be.
///
/// # Safety
///
/// A viselkedés nincs meghatározva, ha az alábbi feltételek bármelyikét megsértik:
///
/// * Az `x`-nek és az `y`-nek egyaránt [valid]-nek kell lennie mind az olvasás, mind az írás során.
///
/// * Az `x`-et és az `y`-et egyaránt megfelelően kell beállítani.
///
/// Vegye figyelembe, hogy még akkor is, ha az `T` mérete `0`, a mutatóknak nem NULL-nak kell lenniük, és megfelelően be kell állítaniuk.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Két nem átfedő régió cseréje:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // ez az `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // ez az `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Két egymást átfedő régió cseréje:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // ez az `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // ez az `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // A szelet `1..3` indexei átfedik egymást `x` és `y` között.
///     // Ésszerű eredmények szerintük `[2, 3]`, tehát az `0..3` indexek `[1, 2, 3]` (`y` előtt `swap` megegyeznek);vagy hogy `[0, 1]` legyenek, így az `1..4` indexek `[0, 1, 2]` (`x`-hez illeszkednek az `swap` előtt).
/////
///     // Ez a megvalósítás az utóbbi választás megadására van meghatározva.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Adjon magunknak némi karcolási helyet, amellyel dolgozhatunk.
    // Nem kell aggódnunk a cseppek miatt: az `MaybeUninit` nem tesz semmit, ha leesik.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Végezze el a csere BIZTONSÁGOT: a hívónak garantálnia kell, hogy az `x` és az `y` az írásokra érvényes és megfelelően igazodik.
    // `tmp` nem lehet átfedés sem az `x`, sem az `y` között, mert az `tmp` csak külön kiosztott objektumként lett kiosztva a veremben.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` és az `y` átfedhet
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Cserélje az `count * size_of::<T>()` bájtokat a két memóriaterület között, `x` és `y` kezdettel.
/// A két régió nem fedheti egymást.
///
/// # Safety
///
/// A viselkedés nincs meghatározva, ha az alábbi feltételek bármelyikét megsértik:
///
/// * Az `x`-nek és az `y`-nek egyaránt [valid]-nek kell lennie, mind a `count, mind az olvasáshoz *
///   mérete: :<T>() `bájt.
///
/// * Az `x`-et és az `y`-et egyaránt megfelelően kell beállítani.
///
/// * Az `x`-től kezdődő memóriaterület, a `count méret *
///   mérete: :<T>Az () `bájtoknak * nem szabad átfedniük az azonos méretű `y`-től kezdődő memóriaterülettel.
///
/// Vegye figyelembe, hogy még akkor is, ha a ténylegesen másolt méret (`count * size_of: :<T>()`) értéke `0`, a mutatóknak nem NULL értékűeknek kell lenniük, és megfelelően igazodniuk kell.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Alapvető használat:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // BIZTONSÁG: a hívónak garantálnia kell, hogy az `x` és az `y` az
    // írásokra érvényes és megfelelően igazított.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Az alábbi blokkoptimalizálásnál kisebb típusok esetén csak cserélje közvetlenül a kódegen pesszimizálásának elkerülése érdekében.
    //
    if mem::size_of::<T>() < 32 {
        // BIZTONSÁG: a hívónak garantálnia kell az `x` és az `y` érvényességét
        // írásokhoz, megfelelően igazítva és nem átfedésben.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // BIZTONSÁG: a hívónak be kell tartania az `swap_nonoverlapping` biztonsági szerződését.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Itt az a megközelítés, hogy a simd-et felhasználjuk az x&y hatékony cseréjére.
    // A tesztelésből kiderül, hogy 32 bájt vagy 64 bájt egyszerre történő cseréje a leghatékonyabb az Intel Haswell E processzorok számára.
    // Az LLVM jobban képes optimalizálni, ha egy struktúrának #[repr(simd)]-t adunk, még akkor is, ha valójában nem közvetlenül használjuk ezt a struktúrát.
    //
    //
    // A FIXME repr(simd) törött az emscripten és a redoxon
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Hurok az x&y-n keresztül, `Block` egyidejű másolása Az optimalizálónak teljesen le kell tekernie a ciklust a legtöbb NB típusnál
    // Nem használhatunk for for ciklust, mivel az `range` implicit rekurzív módon hívja az `mem::swap`-et
    //
    let mut i = 0;
    while i + block_size <= len {
        // Hozzon létre néhány inicializálatlan memóriát karcolási helyként. Az `t` deklarálása itt elkerüli a verem igazítását, amikor ez a hurok nincs használatban
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // BIZTONSÁG: Mint `i < len`, és mint a hívónak garantálnia kell, hogy az `x` és az `y` érvényes
        // az `len` bájtok esetében az `x + i` és az `y + i` érvényes címeknek kell lenniük, amelyek megfelelnek az `add` biztonsági szerződésének.
        //
        // Ezenkívül a hívónak garantálnia kell, hogy az `x` és az `y` érvényes az írásokra, megfelelően igazítva és nem átfedésben, amely teljesíti az `copy_nonoverlapping` biztonsági szerződését.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Cserélje le az x&y bájtjait, t-t használva ideiglenes pufferként. Ezt optimalizálni kell a hatékony SIMD-műveletekre, ahol elérhető
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Cserélje ki a megmaradt bájtokat
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // BIZTONSÁG: lásd az előző biztonsági megjegyzést.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Az `src`-et áthelyezi a hegyes `dst`-be, visszaadva az előző `dst`-értéket.
///
/// Egyik érték sem esik le.
///
/// Ez a függvény szemantikailag egyenértékű az [`mem::replace`]-szel, azzal a különbséggel, hogy a hivatkozások helyett nyers mutatókon működik.
/// Amikor rendelkezésre állnak referenciák, az [`mem::replace`]-et kell előnyben részesíteni.
///
/// # Safety
///
/// A viselkedés nincs meghatározva, ha az alábbi feltételek bármelyikét megsértik:
///
/// * `dst` [valid] kell, hogy legyen mind az olvasás, mind az írás esetén.
///
/// * `dst` megfelelően kell beállítani.
///
/// * `dst` az `T` típusú megfelelően inicializált értékre kell mutatnia.
///
/// Vegye figyelembe, hogy még akkor is, ha az `T` mérete `0`, a mutatónak nem NULL értékűnek kell lennie, és megfelelően kell igazodnia.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` ugyanolyan hatást fejtene ki a nem biztonságos blokk megkövetelése nélkül.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // BIZTONSÁG: a hívónak garantálnia kell, hogy az `dst` érvényes
    // módosítható referenciára öntve (írásokra érvényes, igazítva, inicializálva), és nem fedheti át az `src`-et, mivel az `dst`-nek egy külön allokált objektumra kell mutatnia.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // nem fedhetik át egymást
    }
    src
}

/// Beolvassa az értéket az `src`-ből anélkül, hogy mozgatná.Ez változatlanul hagyja az `src` memóriáját.
///
/// # Safety
///
/// A viselkedés nincs meghatározva, ha az alábbi feltételek bármelyikét megsértik:
///
/// * `src` [valid] értékűnek kell lennie az olvasásokhoz.
///
/// * `src` megfelelően kell beállítani.Használja az [`read_unaligned`]-et, ha nem ez a helyzet.
///
/// * `src` az `T` típusú megfelelően inicializált értékre kell mutatnia.
///
/// Vegye figyelembe, hogy még akkor is, ha az `T` mérete `0`, a mutatónak nem NULL értékűnek kell lennie, és megfelelően kell igazodnia.
///
/// # Examples
///
/// Alapvető használat:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Az [`mem::swap`] kézi megvalósítása:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Hozzon létre egy bitrészes másolatot az `a` értékről az `tmp` fájlban.
///         let tmp = ptr::read(a);
///
///         // Ezen a ponton való kilépés (akár kifejezett visszatéréssel, akár egy olyan függvény meghívásával, amelyet a panics) az `tmp` értékének csökkenését okozná, miközben ugyanarra az értékre még mindig hivatkozik az `a`.
///         // Ez meghatározatlan viselkedést válthat ki, ha az `T` nem `Copy`.
/////
/////
///
///         // Hozzon létre egy bitrészes másolatot az `b` értékről az `a` fájlban.
///         // Ez biztonságos, mert a mutálható hivatkozások nem lehetnek álnevek.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Mint fent, az itt való kilépés meghatározhatatlan viselkedést válthat ki, mert ugyanarra az értékre hivatkozik az `a` és az `b`.
/////
///
///         // Az `tmp` mozgatása az `b` fájlba.
///         ptr::write(b, tmp);
///
///         // `tmp` áthelyezésre került (az `write` átveszi a második argumentum tulajdonjogát), így itt semmi sem esik implicit módon.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## A visszatérített érték tulajdonjoga
///
/// `read` létrehoz egy bitenkénti másolatot az `T`-ből, függetlenül attól, hogy az `T` [`Copy`]-e.
/// Ha az `T` nem [`Copy`], akkor a visszaadott érték és az `*src` értéknél használt érték is sértheti a memória biztonságát.
/// Ne feledje, hogy az `*src`-hez való hozzárendelés felhasználásnak számít, mert megpróbálja eldobni az értéket `* src`-en.
///
/// [`write()`] felhasználható az adatok felülírására anélkül, hogy azok eldobódnának.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` most ugyanarra az alapul szolgáló memóriára mutat, mint az `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Az `s2`-hez való hozzárendelés miatt az eredeti értéke csökken.
///     // Ezen a ponton túl az `s` már nem használható, mivel az alapul szolgáló memória felszabadult.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Az `s`-hez való hozzárendelés a régi érték újbóli elvetését eredményezné, ami meghatározatlan viselkedést eredményezne.
/////
///     // s= String::from("bar");//HIBA
///
///     // `ptr::write` használható egy érték felülírására anélkül, hogy eldobná.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // BIZTONSÁG: a hívónak garantálnia kell, hogy az `src` érvényes az olvasásokra.
    // `src` nem fedheti át az `tmp`-et, mert az `tmp`-et csak külön kiosztott objektumként osztották ki a veremben.
    //
    //
    // Továbbá, mivel épp egy érvényes értéket írtunk az `tmp`-be, garantáltan megfelelően inicializáljuk.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Beolvassa az értéket az `src`-ből anélkül, hogy mozgatná.Ez változatlanul hagyja az `src` memóriáját.
///
/// Az [`read`]-től eltérően az `read_unaligned` nem igazított mutatókkal működik.
///
/// # Safety
///
/// A viselkedés nincs meghatározva, ha az alábbi feltételek bármelyikét megsértik:
///
/// * `src` [valid] értékűnek kell lennie az olvasásokhoz.
///
/// * `src` az `T` típusú megfelelően inicializált értékre kell mutatnia.
///
/// Az [`read`]-hez hasonlóan az `read_unaligned` létrehozza az `T` bitenkénti másolatát, függetlenül attól, hogy az `T` [`Copy`]-e.
/// Ha az `T` nem [`Copy`], akkor a visszaadott értéket és az `*src` értéknél használt értéket is [violate memory safety][read-ownership].
///
/// Vegye figyelembe, hogy még akkor is, ha az `T` mérete `0`, a mutatónak nem NULL értékűnek kell lennie.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## `packed` vonalakon
///
/// Jelenleg lehetetlen létrehozni nyers mutatókat a csomagolatlan struktúra ki nem igazított mezőire.
///
/// Ha megpróbál létrehozni egy nyers mutatót egy `unaligned` struktúramezőbe egy olyan kifejezéssel, mint az `&packed.unaligned as *const FieldType`, akkor létrehoz egy köztes, egyenes nélküli hivatkozást, mielőtt azt átalakítaná nyers mutatóvá.
///
/// Annak, hogy ez a hivatkozás ideiglenes és azonnal leadott, nincs jelentősége, mivel a fordító mindig arra számít, hogy a hivatkozások megfelelően illeszkednek.
/// Ennek eredményeként az `&packed.unaligned as *const FieldType` használata azonnali* undefined viselkedést * okoz a programban.
///
/// Példa arra, hogy mit ne tegyünk, és ez hogyan kapcsolódik az `read_unaligned`-hez:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Itt megkíséreljük megadni egy 32 bites egész szám címét, amely nincs igazítva.
///     let unaligned =
///         // Itt létrejön egy ideiglenes, nem igazított hivatkozás, amely meghatározatlan viselkedést eredményez, függetlenül attól, hogy a hivatkozást használják-e vagy sem.
/////
///         &packed.unaligned
///         // A nyers mutatóra továbbítás nem segít;a hiba már megtörtént.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Az igazítatlan mezők közvetlen elérése pl. Az `packed.unaligned` segítségével azonban biztonságos.
///
///
///
///
///
///
// FIXME: Frissítse a dokumentumokat az RFC #2582 és barátai eredménye alapján.
/// # Examples
///
/// Olvasson el egy usize értéket egy bájtpufferből:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // BIZTONSÁG: a hívónak garantálnia kell, hogy az `src` érvényes az olvasásokra.
    // `src` nem fedheti át az `tmp`-et, mert az `tmp`-et csak külön kiosztott objektumként osztották ki a veremben.
    //
    //
    // Továbbá, mivel épp egy érvényes értéket írtunk az `tmp`-be, garantáltan megfelelően inicializáljuk.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Felülírja a memória helyét az adott értékkel anélkül, hogy elolvassa vagy eldobná a régi értéket.
///
/// `write` nem dobja el az `dst` tartalmát.
/// Ez biztonságos, de szivároghat az allokációkból vagy az erőforrásokból, ezért ügyelni kell arra, hogy ne írja felül az eldobandó tárgyakat.
///
///
/// Ezenkívül nem dobja el az `src`-et.Szemantikailag az `src` az `dst` által jelzett helyre kerül.
///
/// Ez megfelelő az inicializálatlan memória inicializálásához, vagy a korábban [`read`]-től származó memória felülírásához.
///
/// # Safety
///
/// A viselkedés nincs meghatározva, ha az alábbi feltételek bármelyikét megsértik:
///
/// * `dst` [valid] kell, hogy legyen az írásokhoz.
///
/// * `dst` megfelelően kell beállítani.Használja az [`write_unaligned`]-et, ha nem ez a helyzet.
///
/// Vegye figyelembe, hogy még akkor is, ha az `T` mérete `0`, a mutatónak nem NULL értékűnek kell lennie, és megfelelően kell igazodnia.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Alapvető használat:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Az [`mem::swap`] kézi megvalósítása:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Hozzon létre egy bitrészes másolatot az `a` értékről az `tmp` fájlban.
///         let tmp = ptr::read(a);
///
///         // Ezen a ponton való kilépés (akár kifejezett visszatéréssel, akár egy olyan függvény meghívásával, amelyet a panics) az `tmp` értékének csökkenését okozná, miközben ugyanarra az értékre még mindig hivatkozik az `a`.
///         // Ez meghatározatlan viselkedést válthat ki, ha az `T` nem `Copy`.
/////
/////
///
///         // Hozzon létre egy bitrészes másolatot az `b` értékről az `a` fájlban.
///         // Ez biztonságos, mert a mutálható hivatkozások nem lehetnek álnevek.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Mint fent, az itt való kilépés meghatározhatatlan viselkedést válthat ki, mert ugyanarra az értékre hivatkozik az `a` és az `b`.
/////
///
///         // Az `tmp` mozgatása az `b` fájlba.
///         ptr::write(b, tmp);
///
///         // `tmp` áthelyezésre került (az `write` átveszi a második argumentum tulajdonjogát), így itt semmi sem esik implicit módon.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Közvetlenül hívjuk az intrinsicet, hogy elkerüljük a generált kódban a függvényhívásokat, mivel az `intrinsics::copy_nonoverlapping` egy burkolófüggvény.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // BIZTONSÁG: a hívónak garantálnia kell, hogy az `dst` érvényes az írásokra.
    // `dst` nem fedheti át az `src`-et, mert a hívónak módosítható hozzáférése van az `dst`-hez, míg az `src` ez a funkció.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Felülírja a memória helyét az adott értékkel anélkül, hogy elolvassa vagy eldobná a régi értéket.
///
/// Az [`write()`]-től eltérően a mutató lehet nem igazított.
///
/// `write_unaligned` nem dobja el az `dst` tartalmát.Ez biztonságos, de szivároghat az allokációkból vagy az erőforrásokból, ezért ügyelni kell arra, hogy ne írja felül az eldobandó tárgyakat.
///
/// Ezenkívül nem dobja el az `src`-et.Szemantikailag az `src` az `dst` által jelzett helyre kerül.
///
/// Ez megfelelő az inicializálatlan memória inicializálásához, vagy a korábban az [`read_unaligned`] használatával leolvasott memória felülírásához.
///
/// # Safety
///
/// A viselkedés nincs meghatározva, ha az alábbi feltételek bármelyikét megsértik:
///
/// * `dst` [valid] kell, hogy legyen az írásokhoz.
///
/// Vegye figyelembe, hogy még akkor is, ha az `T` mérete `0`, a mutatónak nem NULL értékűnek kell lennie.
///
/// [valid]: self#safety
///
/// ## `packed` vonalakon
///
/// Jelenleg lehetetlen létrehozni nyers mutatókat a csomagolatlan struktúra ki nem igazított mezőire.
///
/// Ha megpróbál létrehozni egy nyers mutatót egy `unaligned` struktúramezőbe egy olyan kifejezéssel, mint az `&packed.unaligned as *const FieldType`, akkor létrehoz egy köztes, egyenes nélküli hivatkozást, mielőtt azt átalakítaná nyers mutatóvá.
///
/// Annak, hogy ez a hivatkozás ideiglenes és azonnal leadott, nincs jelentősége, mivel a fordító mindig arra számít, hogy a hivatkozások megfelelően illeszkednek.
/// Ennek eredményeként az `&packed.unaligned as *const FieldType` használata azonnali* undefined viselkedést * okoz a programban.
///
/// Példa arra, hogy mit ne tegyünk, és ez hogyan kapcsolódik az `write_unaligned`-hez:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Itt megkíséreljük megadni egy 32 bites egész szám címét, amely nincs igazítva.
///     let unaligned =
///         // Itt létrejön egy ideiglenes, nem igazított hivatkozás, amely meghatározatlan viselkedést eredményez, függetlenül attól, hogy a hivatkozást használják-e vagy sem.
/////
///         &mut packed.unaligned
///         // A nyers mutatóra továbbítás nem segít;a hiba már megtörtént.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Az igazítatlan mezők közvetlen elérése pl. Az `packed.unaligned` segítségével azonban biztonságos.
///
///
///
///
///
///
///
///
///
// FIXME: Frissítse a dokumentumokat az RFC #2582 és barátai eredménye alapján.
/// # Examples
///
/// Írjon egy usize értéket egy bájtpufferbe:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // BIZTONSÁG: a hívónak garantálnia kell, hogy az `dst` érvényes az írásokra.
    // `dst` nem fedheti át az `src`-et, mert a hívónak módosítható hozzáférése van az `dst`-hez, míg az `src` ez a funkció.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Közvetlenül hívjuk az intrinsicet, hogy elkerüljük a generált kódban a függvényhívásokat.
        intrinsics::forget(src);
    }
}

/// Folyamatosan leolvassa az értéket az `src`-ből anélkül, hogy azt elmozdítaná.Ez változatlanul hagyja az `src` memóriáját.
///
/// A volatilis műveletek célja az I/O memória működése, és garantált, hogy a fordító ezeket nem hagyja el és nem rendezi át más illékony műveletek során.
///
/// # Notes
///
/// A Rust jelenleg nem rendelkezik szigorúan és formálisan meghatározott memóriamodellel, így az "volatile" itteni pontos szemantikája idővel változhat.
/// Ennek ellenére a szemantika szinte mindig az [C11's definition of volatile][c11]-hez hasonló lesz.
///
/// A fordítónak nem szabad megváltoztatnia az illékony memória műveletek relatív sorrendjét vagy számát.
/// Azonban a nulla méretű típusokkal kapcsolatos illékony memóriaműveletek (pl. Ha nulla méretű típust adnak át az `read_volatile`-nek) nem jelennek meg, és figyelmen kívül hagyhatók.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// A viselkedés nincs meghatározva, ha az alábbi feltételek bármelyikét megsértik:
///
/// * `src` [valid] értékűnek kell lennie az olvasásokhoz.
///
/// * `src` megfelelően kell beállítani.
///
/// * `src` az `T` típusú megfelelően inicializált értékre kell mutatnia.
///
/// Az [`read`]-hez hasonlóan az `read_volatile` létrehozza az `T` bitenkénti másolatát, függetlenül attól, hogy az `T` [`Copy`]-e.
/// Ha az `T` nem [`Copy`], akkor a visszaadott értéket és az `*src` értéknél használt értéket is [violate memory safety][read-ownership].
/// A nem [`Copy`] típusok tárolása az illékony memóriában azonban szinte biztos, hogy helytelen.
///
/// Vegye figyelembe, hogy még akkor is, ha az `T` mérete `0`, a mutatónak nem NULL értékűnek kell lennie, és megfelelően kell igazodnia.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Csakúgy, mint a C-ben, a művelet ingadozása sem befolyásolja a kérdéseket, amelyek egyidejű hozzáférést jelentenek több szálból.Az illékony hozzáférések ebben a tekintetben pontosan úgy viselkednek, mint a nem atomi hozzáférések.
///
/// Különösen az `read_volatile` és az ugyanarra a helyre irányuló írási műveletek közötti verseny nem meghatározott viselkedés.
///
/// # Examples
///
/// Alapvető használat:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Nincs pánik, hogy kisebb legyen a kodegen hatása.
        abort();
    }
    // BIZTONSÁG: a hívónak be kell tartania az `volatile_load` biztonsági szerződését.
    unsafe { intrinsics::volatile_load(src) }
}

/// A memória helyének illékony írását hajtja végre a megadott értékkel, a régi érték beolvasása vagy elvetése nélkül.
///
/// A volatilis műveletek célja az I/O memória működése, és garantált, hogy a fordító ezeket nem hagyja el és nem rendezi át más illékony műveletek során.
///
/// `write_volatile` nem dobja el az `dst` tartalmát.Ez biztonságos, de szivároghat az allokációkból vagy az erőforrásokból, ezért ügyelni kell arra, hogy ne írja felül az eldobandó tárgyakat.
///
/// Ezenkívül nem dobja el az `src`-et.Szemantikailag az `src` az `dst` által jelzett helyre kerül.
///
/// # Notes
///
/// A Rust jelenleg nem rendelkezik szigorúan és formálisan meghatározott memóriamodellel, így az "volatile" itteni pontos szemantikája idővel változhat.
/// Ennek ellenére a szemantika szinte mindig az [C11's definition of volatile][c11]-hez hasonló lesz.
///
/// A fordítónak nem szabad megváltoztatnia az illékony memória műveletek relatív sorrendjét vagy számát.
/// Azonban a nulla méretű típusokkal kapcsolatos illékony memóriaműveletek (pl. Ha nulla méretű típust adnak át az `write_volatile`-nek) nem jelennek meg, és figyelmen kívül hagyhatók.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// A viselkedés nincs meghatározva, ha az alábbi feltételek bármelyikét megsértik:
///
/// * `dst` [valid] kell, hogy legyen az írásokhoz.
///
/// * `dst` megfelelően kell beállítani.
///
/// Vegye figyelembe, hogy még akkor is, ha az `T` mérete `0`, a mutatónak nem NULL értékűnek kell lennie, és megfelelően kell igazodnia.
///
/// [valid]: self#safety
///
/// Csakúgy, mint a C-ben, a művelet ingadozása sem befolyásolja a kérdéseket, amelyek egyidejű hozzáférést jelentenek több szálból.Az illékony hozzáférések ebben a tekintetben pontosan úgy viselkednek, mint a nem atomi hozzáférések.
///
/// Különösen az `write_volatile` és bármely más, ugyanazon a helyen végzett művelet (olvasás vagy írás) közötti verseny nem meghatározott viselkedés.
///
/// # Examples
///
/// Alapvető használat:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Nincs pánik, hogy kisebb legyen a kodegen hatása.
        abort();
    }
    // BIZTONSÁG: a hívónak be kell tartania az `volatile_store` biztonsági szerződését.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Igazítsa az `p` mutatót.
///
/// Számítsa ki az eltolást (az `stride` lépés elemeit tekintve), amelyet az `p` mutatóra kell alkalmazni, hogy az `p` mutató igazodjon az `a`-hez.
///
/// Note: Ezt a megvalósítást gondosan úgy alakították ki, hogy ne a panic.Ennek UB a panic.
/// Az egyetlen valódi változás, amelyet itt megtehetünk, az `INV_TABLE_MOD_16` és a kapcsolódó állandók megváltoztatása.
///
/// Ha valaha is elhatározzuk, hogy lehetővé tesszük az `a` intrinsic nevét, amely nem kettős erő, akkor valószínűleg körültekintőbb lesz csak áttérni egy naiv végrehajtásra, ahelyett, hogy megpróbálnánk adaptálni ezt a változást.
///
///
/// Minden kérdés a@nagisa címre kerül.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Ezeknek az intrinzikeknek a közvetlen felhasználása jelentősen javítja a kodegeneket opt-szinten <=
    // 1, ahol ezeknek a műveleteknek a metódusváltozatai nincsenek behúzva.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Számítsa ki az `x` modulo `m` multiplikatív moduláris inverzét.
    ///
    /// Ez a megvalósítás az `align_offset`-hez van szabva, és a következő előfeltételekkel rendelkezik:
    ///
    /// * `m` a kettő hatalma;
    /// * `x < m`; (ha `x ≥ m`, adja át helyette az `x % m`-et)
    ///
    /// Ennek a funkciónak a megvalósítása nem lehet panic.Valaha.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Multiplikatív moduláris inverz tábla modulo 2⁴=16.
        ///
        /// Ne feledje, hogy ez a táblázat nem tartalmaz olyan értékeket, ahol inverz nem létezik (pl. `0⁻¹ mod 16`, `2⁻¹ mod 16` stb. Esetén)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo, amelyre az `INV_TABLE_MOD_16`-et szánták.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // BIZTONSÁG: Az `m` kettős hatványnak kell lennie, tehát nem nulla.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Az "up"-et a következő képlet alapján iteráljuk:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // amíg 2²ⁿ ≥ m.Ezután csökkenthetjük a kívánt `m` értékre az `mod m` eredmény felvételével.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Vegye figyelembe, hogy a csomagolási műveleteket szándékosan használjuk itt-az eredeti képlet pl. Az `mod n` kivonását használja.
                // Teljesen rendben van, ha `mod usize::MAX`-et csinálunk helyettük, mert az `mod n` eredményt úgyis a végén vesszük.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // BIZTONSÁG: Az `a` a kettő hatványa, ezért nem nulla.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` eset egyszerűbben kiszámítható az `-p (mod a)`-en keresztül, de ez gátolja az LLVM képességét az `lea`-hez hasonló utasítások kiválasztására.Ehelyett kiszámoljuk
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // amely elosztja a műveleteket a teherbírás körül, de az `and`-et kellőképpen pesszimizálja, hogy az LLVM képes legyen felhasználni a különféle optimalizációkat, amelyekről tud.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Már igazítva.Hurrá!
        return 0;
    } else if stride == 0 {
        // Ha a mutató nincs igazítva, és az elem nulla méretű, akkor egyetlen elem sem fogja igazítani a mutatót.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // BIZTONSÁG: az a kettő hatványa, tehát nem nulla.lépés==0 esetet fentebb kezelünk.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // BIZTONSÁG: A gcdpow felső határértéke legfeljebb egy bit használatának száma.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // BIZTONSÁG: A gcd mindig nagyobb vagy egyenlő 1-vel.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Ez a branch a következő lineáris kongruenciaegyenletet oldja meg:
        //
        // ` p + so = 0 mod a `
        //
        // `p` itt van a mutató értéke, `s`, `T` lépés, `o` eltolás a `T`s-ban, és `a`, a kért igazítás.
        //
        // Ha az `g = gcd(a, s)` és a fenti feltétel azt állítja, hogy `p` osztható `g`-szel, akkor jelölhetjük `a' = a/g`, `s' = s/g`, `p' = p/g`, akkor ez ekvivalenssé válik:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Az első tag "the relative alignment of `p` to `a`" (osztva az `g`-szel), a második kifejezés "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (ismét elosztva `g`-szel).
        //
        // Ha az `a` és az `s` nem társprimer, akkor az inverz jól formálható az `g`-szel.
        //
        // Továbbá, az ezzel a megoldással kapott eredmény nem "minimal", ezért szükséges az `o mod lcm(s, a)` eredményt venni.Az `lcm(s, a)`-et csak `a'`-re cserélhetjük.
        //
        //
        //
        //
        //

        // BIZTONSÁG: Az `gcdpow` felső határértéke nem nagyobb, mint az `a`-ben levő 0-bitek száma.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // BIZTONSÁG: Az `a2` értéke nem nulla.Az `a` `gcdpow`-szel történő eltolása nem tudja a beállított bitek egyikét sem eltolni
        // az `a`-ben (amiből pontosan egy van).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // BIZTONSÁG: Az `gcdpow` felső határértéke nem nagyobb, mint az `a`-ben levő 0-bitek száma.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // BIZTONSÁG: Az `gcdpow` felső határértéke nem nagyobb, mint a 0-ban lévő záró bitek száma
        // `a`.
        // Továbbá a kivonás nem tud túlcsordulni, mert az `a2 = a >> gcdpow` mindig szigorúan nagyobb lesz, mint az `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // BIZTONSÁG: Az `a2` a kettő ereje, amint azt a fentiek bizonyították.Az `s2` szigorúan kisebb, mint az `a2`
        // mert az `(s % a) >> gcdpow` szigorúan kisebb, mint az `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Egyáltalán nem igazítható.
    usize::MAX
}

/// Összehasonlítja az egyenlőség nyers mutatóit.
///
/// Ez megegyezik az `==` operátor használatával, de kevésbé általános:
/// az érveknek `*const T` nyers mutatóknak kell lenniük, nem pedig az `PartialEq` végrehajtására.
///
/// Ez felhasználható az `&T` hivatkozások (amelyek implicit módon az `*const T`-re kényszerítik) összehasonlítására a címük alapján, ahelyett, hogy összehasonlítanák az általuk mutatott értékeket (erre szolgál az `PartialEq for &T` megvalósítás).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// A szeleteket hosszuk (zsírmutatók) alapján is összehasonlítják:
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// A Traits-t a megvalósításuk is összehasonlítja:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // A mutatók címe egyenlő.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Az objektumok címe egyenlő, de az `Trait` megvalósítása különböző.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Ha a referenciát `*const u8`-be konvertálja, összehasonlítja a címet.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash egy nyers mutatót.
///
/// Ezt fel lehet használni egy `&T` referencia kivonatolására (amely implicit módon kényszerít az `*const T`-re) a címe helyett, nem pedig arra az értékre, amelyre mutat (erre az `Hash for &T` implementáció tesz).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Funkciómutatók implikációi
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Az AVR-hez a köztes szereposztás szükséges
                // úgy, hogy a forrás függvénymutató címtere megmaradjon a végső függvénymutatóban.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Az AVR-hez a köztes szereposztás szükséges
                // úgy, hogy a forrás függvénymutató címtere megmaradjon a végső függvénymutatóban.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Nincsenek variadikus függvények 0 paraméterrel
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Hozzon létre egy `const` nyers mutatót egy helyre, közbenső referencia létrehozása nélkül.
///
/// Referencia létrehozása az `&`/`&mut` használatával csak akkor engedélyezett, ha a mutató megfelelően igazodik és inicializált adatokra mutat.
/// Azokban az esetekben, amikor ezek a követelmények nem teljesülnek, helyette nyers mutatókat kell használni.
/// Az `&expr as *const _` azonban létrehoz egy referenciát, mielőtt egy nyers mutatóra küldené, és erre a hivatkozásra ugyanazok a szabályok vonatkoznak, mint az összes többi hivatkozásra.
///
/// Ez a makró létrehozhat egy nyers mutatót * anélkül, hogy először referenciát hozna létre.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` összehangolatlan referenciát hozna létre, és ezáltal meghatározatlan viselkedés lenne!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Hozzon létre egy `mut` nyers mutatót egy helyre, közbenső referencia létrehozása nélkül.
///
/// Referencia létrehozása az `&`/`&mut` használatával csak akkor engedélyezett, ha a mutató megfelelően igazodik és inicializált adatokra mutat.
/// Azokban az esetekben, amikor ezek a követelmények nem teljesülnek, helyette nyers mutatókat kell használni.
/// Az `&mut expr as *mut _` azonban létrehoz egy referenciát, mielőtt egy nyers mutatóra küldené, és erre a hivatkozásra ugyanazok a szabályok vonatkoznak, mint az összes többi hivatkozásra.
///
/// Ez a makró létrehozhat egy nyers mutatót * anélkül, hogy először referenciát hozna létre.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` összehangolatlan referenciát hozna létre, és ezáltal meghatározatlan viselkedés lenne!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` a referencia létrehozása helyett a mező másolására kényszerül.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}