use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// A nyers, nem nullás `*mut T` körüli burkoló, amely jelzi, hogy ennek a burkolatnak a tulajdonosa a referens tulajdonosa.
/// Hasznos olyan absztrakciók készítéséhez, mint az `Box<T>`, `Vec<T>`, `String` és `HashMap<K, V>`.
///
/// Az `*mut T`-től eltérően az `Unique<T>` úgy viselkedik, mint "as if", ez az `T` példánya volt.
/// Az `Send`/`Sync` akkor valósul meg, ha `T` az `Send`/`Sync`.
/// Ez magában foglalja azt a fajta erős álnevet is, amely az `T` egyik példányára számíthat:
/// a mutató hivatkozóját nem szabad módosítani a Unique tulajdonosa egyedi elérési útja nélkül.
///
/// Ha nem biztos abban, hogy helyesen használja-e az `Unique`-et a céljaira, fontolja meg az `NonNull` használatát, amelynek szemantikája gyengébb.
///
///
/// Az `*mut T`-től eltérően a mutatónak mindig nullának kell lennie, még akkor is, ha a mutatóra soha nem hivatkoznak.
/// Ez azért van, hogy az enums ezt a tiltott értéket diszkriminánsként használhassa-az `Option<Unique<T>>` mérete megegyezik az `Unique<T>` méretével.
/// A mutató azonban továbbra is lóghat, ha nem hivatkozunk rá.
///
/// Az `*mut T`-től eltérően az `Unique<T>` kovariáns az `T` felett.
/// Ennek mindig helyesnek kell lennie minden olyan típusnál, amely betartja az Unique álnevezési követelményeit.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: ennek a jelölőnek nincs következménye a varianciára, de szükséges
    // hogy a dropck megértse, hogy logikusan saját tulajdonunkban van egy `T`.
    //
    // Részletekért lásd:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` a mutatók `Send`, ha `T` `Send`, mert az általuk hivatkozott adatok hamisítatlanok.
/// Ne feledje, hogy ezt az álnevező invariantust a típusrendszer nem érvényesíti;az `Unique` használatával végzett absztrakciónak érvényesítenie kell.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` a mutatók `Sync`, ha `T` `Sync`, mert az általuk hivatkozott adatok hamisítatlanok.
/// Ne feledje, hogy ezt az álnevező invariantust a típusrendszer nem érvényesíti;az `Unique` használatával végzett absztrakciónak érvényesítenie kell.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Létrehoz egy új `Unique`-et, amely lóg, de jól illeszkedik.
    ///
    /// Ez hasznos a lustán allokáló típusok inicializálásához, mint az `Vec::new`.
    ///
    /// Vegye figyelembe, hogy a mutató értéke egy érvényes mutatót jelenthet egy `T`-hez, ami azt jelenti, hogy ezt nem szabad "not yet initialized" őrszem értékként használni.
    /// A lustán kiosztott típusoknak valamilyen más eszközzel kell követniük az inicializálást.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // BIZTONSÁG: Az mem::align_of() érvényes, nem null mutatót ad vissza.A
        // Az new_unchecked() hívásának feltételeit tehát tiszteletben tartják.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Létrehoz egy új `Unique`-et.
    ///
    /// # Safety
    ///
    /// `ptr` nem null értékűnek kell lennie.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // BIZTONSÁG: a hívónak garantálnia kell, hogy az `ptr` nem null.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Új `Unique`-t hoz létre, ha az `ptr` nem null.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // BIZTONSÁG: A mutató már ellenőrizve volt, és nem null.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Megszerzi az alapul szolgáló `*mut` mutatót.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Levonja a tartalmat.
    ///
    /// Az így kapott élettartam önmagához van kötve, így ez "as if" viselkedést mutat, valójában egy olyan T példány volt, amelyet kölcsön kapnak.
    /// Ha hosszabb (unbound) élettartamra van szükség, használja az `&*my_ptr.as_ptr()`-et.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // BIZTONSÁG: a hívónak garantálnia kell, hogy az `self` megfelel az összes követelménynek
        // referenciára vonatkozó követelmények.
        unsafe { &*self.as_ptr() }
    }

    /// Változtatva levonja a tartalmat.
    ///
    /// Az így kapott élettartam önmagához van kötve, így ez "as if" viselkedést mutat, valójában egy olyan T példány volt, amelyet kölcsön kapnak.
    /// Ha hosszabb (unbound) élettartamra van szükség, használja az `&mut *my_ptr.as_ptr()`-et.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // BIZTONSÁG: a hívónak garantálnia kell, hogy az `self` megfelel az összes követelménynek
        // a mutálható referenciára vonatkozó követelmények.
        unsafe { &mut *self.as_ptr() }
    }

    /// Más típusú mutatóra vetít.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // BIZTONSÁG: Az Unique::new_unchecked() új egyediséget és igényeket teremt
        // az adott mutató nem lehet null.
        // Mivel mutatóként adjuk át önmagunkat, ez nem lehet null.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // BIZTONSÁG: A módosítható hivatkozás nem lehet null
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}