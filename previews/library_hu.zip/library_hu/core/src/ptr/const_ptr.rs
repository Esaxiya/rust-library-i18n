use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// `true` értéket ad vissza, ha a mutató nulla.
    ///
    /// Ne feledje, hogy a nem méretezett típusok sok lehetséges null mutatóval rendelkeznek, mivel csak a nyers adat mutatót veszik figyelembe, nem pedig a hosszukat, a megadhatókat stb.
    /// Ezért két nullpontos mutató még mindig nem lehet egyenlő egymással.
    ///
    /// ## Viselkedés a const értékelése során
    ///
    /// Ha ezt a függvényt az const kiértékelés során használják, akkor `false` értéket adhat vissza azoknak a mutatóknak, amelyek futás közben nullának bizonyulnak.
    /// Pontosabban, ha egy memória mutatója a határain túllépve úgy van eltolva, hogy az eredményül kapott mutató null, akkor a függvény továbbra is `false` értéket ad vissza.
    ///
    /// A CTFE-nek nincs módja megismerni a memória abszolút helyzetét, ezért nem tudjuk megmondani, hogy a mutató null-e vagy sem.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Hasonlítsa össze a leadáson keresztül a vékony mutatóval, így a kövér mutatók csak az "data" részét veszik figyelembe.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// Más típusú mutatóra vetít.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// Bontani egy (esetleg széles) mutatót cím-és metaadat-összetevőkké.
    ///
    /// A mutató később rekonstruálható az [`from_raw_parts`] segítségével.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// Visszaadja az `None` értéket, ha a mutató nulla, vagy pedig megosztott hivatkozást ad vissza az `Some`-be csomagolt értékre.Ha az érték inicializálatlan lehet, akkor az [`as_uninit_ref`]-et kell használni.
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// A módszer meghívásakor meg kell győződnie arról, hogy *vagy* a mutató NULL *, vagy* az alábbiak mindegyike igaz:
    ///
    /// * A mutatónak megfelelően kell lennie.
    ///
    /// * Ennek "dereferencable"-nek kell lennie az [the module documentation]-ben meghatározott értelemben.
    ///
    /// * A mutatónak az `T` inicializált példányára kell mutatnia.
    ///
    /// * Kényszerítenie kell a Rust álnevezési szabályait, mivel az `'a` visszaadott élettartamot önkényesen választják, és nem feltétlenül tükrözi az adatok tényleges élettartamát.
    ///   Különösen ezen élettartam alatt a memória, amelyre a mutató mutat, nem mutálódhat (kivéve az `UnsafeCell` belsejét).
    ///
    /// Ez akkor is érvényes, ha a módszer eredményét nem használják fel!
    /// (Az inicializálásról még nincs teljesen eldöntve, de amíg ez meg nem történik, az egyetlen biztonságos megközelítés az, hogy valóban inicializálják őket.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Nem ellenőrzött verzió
    ///
    /// Ha biztos abban, hogy a mutató soha nem lehet null, és valamilyen `as_ref_unchecked`-et keres, amely `Option<&T>` helyett az `&T`-et adja vissza, akkor tudja, hogy közvetlenül le lehet vonni a mutatót.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // BIZTONSÁG: a hívónak garantálnia kell az `self` érvényességét
        // referenciaként, ha nem null.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Visszaadja az `None` értéket, ha a mutató nulla, vagy pedig megosztott hivatkozást ad vissza az `Some`-be csomagolt értékre.
    /// Az [`as_ref`]-szel ellentétben ez nem igényli az érték inicializálását.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// A módszer meghívásakor meg kell győződnie arról, hogy *vagy* a mutató NULL *, vagy* az alábbiak mindegyike igaz:
    ///
    /// * A mutatónak megfelelően kell lennie.
    ///
    /// * Ennek "dereferencable"-nek kell lennie az [the module documentation]-ben meghatározott értelemben.
    ///
    /// * Kényszerítenie kell a Rust álnevezési szabályait, mivel az `'a` visszaadott élettartamot önkényesen választják, és nem feltétlenül tükrözi az adatok tényleges élettartamát.
    ///
    ///   Különösen ezen élettartam alatt a memória, amelyre a mutató mutat, nem mutálódhat (kivéve az `UnsafeCell` belsejét).
    ///
    /// Ez akkor is érvényes, ha a módszer eredményét nem használják fel!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // BIZTONSÁG: a hívónak garantálnia kell, hogy az `self` megfelel az összes követelménynek
        // referenciára vonatkozó követelmények.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Kiszámítja az eltolást egy mutatóból.
    ///
    /// `count` T egységben van;pl. egy 3 `count` az `3 * size_of::<T>()` bájtok mutatójának eltolását jelenti.
    ///
    /// # Safety
    ///
    /// Az alábbi feltételek bármelyikének megsértése esetén az eredmény meghatározatlan viselkedés:
    ///
    /// * A kezdő és az eredményes mutatónak határok között vagy egy bájttal kell lennie ugyanazon allokált objektum végén.
    /// Vegye figyelembe, hogy a Rust alkalmazásban minden (stack-allocated) változó külön allokált objektumnak számít.
    ///
    /// * A számított eltolás,**bájtban**, nem tudja túlcsordítani az `isize`-et.
    ///
    /// * A határon lévő eltolás nem támaszkodhat az "wrapping around" címtérre.Vagyis a végtelen pontosságú összegnek,**bájtban**, be kell illeszkednie egy usizbe.
    ///
    /// A fordító és a standard könyvtár általában megpróbálja biztosítani, hogy az allokációk soha ne érjék el azt a méretet, ahol az eltolás aggodalomra ad okot.
    /// Például az `Vec` és az `Box` biztosítja, hogy soha ne rendeljenek többet `isize::MAX` bájtnál, így az `vec.as_ptr().add(vec.len())` mindig biztonságos.
    ///
    /// A legtöbb platform alapvetően nem is képes létrehozni egy ilyen allokációt.
    /// Például egyetlen ismert 64 bites platform sem képes soha kiszolgálni 2 <sup>63</sup> bájt kérést az oldal-tábla korlátozásai vagy a címtér felosztása miatt.
    /// Néhány 32 bites és 16 bites platform azonban sikeresen kiszolgálhatja az `isize::MAX` bájtnál nagyobb kéréseket, például fizikai címkiterjesztéssel.
    ///
    /// Mint ilyen, a közvetlenül az elosztóktól megszerzett memória vagy a memória leképezett fájlok * túl nagyok lehetnek ahhoz, hogy kezelni tudják ezt a funkciót.
    ///
    /// Fontolja meg az [`wrapping_offset`] használatát, ha ezeket a korlátokat nehéz kielégíteni.
    /// A módszer egyetlen előnye, hogy agresszívebb optimalizálást tesz lehetővé a fordítóban.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // BIZTONSÁG: a hívónak be kell tartania az `offset` biztonsági szerződését.
        unsafe { intrinsics::offset(self, count) }
    }

    /// Kiszámítja az eltolást egy mutatóból a becsomagolási aritmetika segítségével.
    ///
    /// `count` T egységben van;pl. egy 3 `count` az `3 * size_of::<T>()` bájtok mutatójának eltolását jelenti.
    ///
    /// # Safety
    ///
    /// Maga a művelet mindig biztonságos, de a kapott mutató használata nem.
    ///
    /// Az eredményül kapott mutató ugyanahhoz a lefoglalt objektumhoz marad csatolva, amelyre az `self` mutat.
    /// Nem *használható* egy másik lefoglalt objektum elérésére.Vegye figyelembe, hogy a Rust alkalmazásban minden (stack-allocated) változó külön allokált objektumnak számít.
    ///
    /// Más szavakkal, az `let z = x.wrapping_offset((y as isize) - (x as isize))`*nem* teszi az `z`-et ugyanazokká, mint az `y`, még akkor is, ha feltételezzük, hogy az `T` mérete `1`, és nincs túlcsordulás: az `z` továbbra is csatolva van az objektumhoz, amelyhez az `x` csatolva van, és az alárendelés meghatározatlan viselkedés, hacsak `x` és `y` pont ugyanabba a lefoglalt objektumba.
    ///
    /// Az [`offset`]-hez képest ez a módszer alapvetően késlelteti az ugyanazon allokált objektumon belüli tartózkodás követelményét: az [`offset`] azonnali, nem meghatározott viselkedés az objektumhatárok átlépésekor;Az `wrapping_offset` létrehoz egy mutatót, de mégis meghatározatlan viselkedéshez vezet, ha egy mutatóra hivatkozás kerül, amikor az objektum határain kívül esik.
    /// [`offset`] jobban optimalizálható, ezért előnyösebb a teljesítményérzékeny kódban.
    ///
    /// A késleltetett ellenőrzés csak a hivatkozott mutató értékét veszi figyelembe, a végeredmény kiszámítása során használt köztes értékeket nem.
    /// Például az `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` mindig ugyanaz, mint az `x`.Más szavakkal, megengedett a lefoglalt objektum elhagyása, majd későbbi újbóli belépés.
    ///
    /// Ha át kell lépnie az objektum határait, dobja a mutatót egész számra, és ott végezze el a számtant.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// // Kétféle lépésenként nyers mutató segítségével iterálunk
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // Ez a hurok kinyomtatja az "1, 3, 5, "-et
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // BIZTONSÁG: Az `arith_offset` intrinsic-nek nincsenek előfeltételei a meghívásra.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// Kiszámítja a két mutató közötti távolságot.A visszaadott érték T egységben van megadva: a bájtokban mért távolság elosztva `mem::size_of::<T>()`-el.
    ///
    /// Ez a függvény az [`offset`] inverze.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// Az alábbi feltételek bármelyikének megsértése esetén az eredmény meghatározatlan viselkedés:
    ///
    /// * A kezdő és a másik mutatónak határok között vagy egy bájttal kell lennie ugyanazon allokált objektum végén.
    /// Vegye figyelembe, hogy a Rust alkalmazásban minden (stack-allocated) változó külön allokált objektumnak számít.
    ///
    /// * Mindkét mutatónak ugyanarra az objektumra mutató * mutatóból kell származnia.
    ///   (Lásd az alábbi példát.)
    ///
    /// * A mutatók közötti távolság bájtokban pontosan meg kell felelnie az `T` méretének.
    ///
    /// * A mutatók közötti távolság **bájtban** nem tudja túlcsordítani az `isize`-et.
    ///
    /// * A határok közötti távolság nem támaszkodhat az "wrapping around" címtérre.
    ///
    /// A Rust típusok soha nem nagyobbak, mint az `isize::MAX`, és a Rust allokációk soha nem veszik körbe a címteret, így bármelyik X0 `T` típusú Rust bármelyik értékén belül két mutató mindig kielégíti az utolsó két feltételt.
    ///
    /// A szokásos könyvtár általában azt is biztosítja, hogy az allokációk soha ne érjék el azt a méretet, ahol az eltolás aggodalomra ad okot.
    /// Például az `Vec` és az `Box` biztosítja, hogy soha ne rendeljenek többet `isize::MAX` bájtnál, ezért az `ptr_into_vec.offset_from(vec.as_ptr())` mindig megfelel az utolsó két feltételnek.
    ///
    /// A legtöbb platform alapvetően nem is képes ekkora kiosztást létrehozni.
    /// Például egyetlen ismert 64 bites platform sem képes soha kiszolgálni 2 <sup>63</sup> bájt kérést az oldal-tábla korlátozásai vagy a címtér felosztása miatt.
    /// Néhány 32 bites és 16 bites platform azonban sikeresen kiszolgálhatja az `isize::MAX` bájtnál nagyobb kéréseket, például fizikai címkiterjesztéssel.
    /// Mint ilyen, a közvetlenül az elosztóktól megszerzett memória vagy a memória leképezett fájlok * túl nagyok lehetnek ahhoz, hogy kezelni tudják ezt a funkciót.
    /// (Vegye figyelembe, hogy az [`offset`] és az [`add`] szintén hasonló korlátozással rendelkezik, és ezért nem használhatók ilyen nagy allokációknál sem.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Ez a panics funkció, ha az `T` nulla méretű ("ZST") típusú.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Helytelen* használat:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Készítsen ptr2_other ptr2 "alias" értéket, de az ptr1 származékot.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Mivel a ptr2_other és az ptr2 különböző objektumokra mutató mutatókból származik, az eltolásuk kiszámítása nem meghatározott viselkedés, annak ellenére, hogy ugyanarra a címre mutatnak!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Meghatározatlan viselkedés
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // BIZTONSÁG: a hívónak be kell tartania az `ptr_offset_from` biztonsági szerződését.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// Visszaadja, hogy garantáltan két mutató egyenlő-e.
    ///
    /// Futás közben ez a funkció úgy viselkedik, mint az `self == other`.
    /// Bizonyos összefüggésekben (pl. Fordítási idő kiértékelése) azonban nem mindig lehet két mutató egyenlőségét meghatározni, így ez a függvény hamisan visszaadhatja az `false`-et azoknak a mutatóknak, amelyek később valóban azonosnak bizonyulnak.
    ///
    /// De amikor visszaadja az `true` értéket, garantáltan egyenlőek lesznek a mutatók.
    ///
    /// Ez a függvény az [`guaranteed_ne`] tükre, de nem fordítottja.Vannak olyan mutató-összehasonlítások, amelyeknél mindkét függvény `false`-et ad vissza.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// A visszatérési érték a fordító verziójától függően változhat, és a nem biztonságos kód nem feltétlenül támaszkodik ennek a funkciónak az eredményességére.
    /// Javasoljuk, hogy ezt a funkciót csak teljesítményoptimalizálásokra használja, ahol a függvény által okozott hamis `false` visszatérési értékek nem az eredményt, hanem csak a teljesítményt befolyásolják.
    /// Ennek a módszernek a futásidejű és a fordítási idejű kódok eltérő viselkedésére való alkalmazásának következményeit nem vizsgálták.
    /// Ezt a módszert nem szabad felhasználni ilyen különbségek bevezetésére, és azt sem szabad stabilizálni, mielőtt jobban megértenénk ezt a kérdést.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// Visszaadja, hogy garantáltan két mutató egyenlőtlen-e.
    ///
    /// Futás közben ez a funkció úgy viselkedik, mint az `self != other`.
    /// Bizonyos összefüggésekben (pl. Fordítási idő kiértékelése) azonban nem mindig lehet két mutató egyenlőtlenségét meghatározni, így ez a függvény hamisan visszaadhatja az `false`-et azoknak a mutatóknak, amelyek később valóban egyenlőtlennek bizonyulnak.
    ///
    /// De amikor visszaadja az `true` értéket, garantáltan egyenlőtlenek lesznek a mutatók.
    ///
    /// Ez a függvény az [`guaranteed_eq`] tükre, de nem fordítottja.Vannak olyan mutató-összehasonlítások, amelyeknél mindkét függvény `false`-et ad vissza.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// A visszatérési érték a fordító verziójától függően változhat, és a nem biztonságos kód nem feltétlenül támaszkodik ennek a funkciónak az eredményességére.
    /// Javasoljuk, hogy ezt a funkciót csak teljesítményoptimalizálásokra használja, ahol a függvény által okozott hamis `false` visszatérési értékek nem az eredményt, hanem csak a teljesítményt befolyásolják.
    /// Ennek a módszernek a futásidejű és a fordítási idejű kódok eltérő viselkedésére való alkalmazásának következményeit nem vizsgálták.
    /// Ezt a módszert nem szabad felhasználni ilyen különbségek bevezetésére, és azt sem szabad stabilizálni, mielőtt jobban megértenénk ezt a kérdést.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// Kiszámítja az eltolást egy mutatóból (kényelem `.offset(count as isize)`) esetén.
    ///
    /// `count` T egységben van;pl. egy 3 `count` az `3 * size_of::<T>()` bájtok mutatójának eltolását jelenti.
    ///
    /// # Safety
    ///
    /// Az alábbi feltételek bármelyikének megsértése esetén az eredmény meghatározatlan viselkedés:
    ///
    /// * A kezdő és az eredményes mutatónak határok között vagy egy bájttal kell lennie ugyanazon allokált objektum végén.
    /// Vegye figyelembe, hogy a Rust alkalmazásban minden (stack-allocated) változó külön allokált objektumnak számít.
    ///
    /// * A számított eltolás,**bájtban**, nem tudja túlcsordítani az `isize`-et.
    ///
    /// * A határon lévő eltolás nem támaszkodhat az "wrapping around" címtérre.Vagyis a végtelen pontosságú összegnek el kell férnie egy `usize`-ben.
    ///
    /// A fordító és a standard könyvtár általában megpróbálja biztosítani, hogy az allokációk soha ne érjék el azt a méretet, ahol az eltolás aggodalomra ad okot.
    /// Például az `Vec` és az `Box` biztosítja, hogy soha ne rendeljenek többet `isize::MAX` bájtnál, így az `vec.as_ptr().add(vec.len())` mindig biztonságos.
    ///
    /// A legtöbb platform alapvetően nem is képes létrehozni egy ilyen allokációt.
    /// Például egyetlen ismert 64 bites platform sem képes soha kiszolgálni 2 <sup>63</sup> bájt kérést az oldal-tábla korlátozásai vagy a címtér felosztása miatt.
    /// Néhány 32 bites és 16 bites platform azonban sikeresen kiszolgálhatja az `isize::MAX` bájtnál nagyobb kéréseket, például fizikai címkiterjesztéssel.
    ///
    /// Mint ilyen, a közvetlenül az elosztóktól megszerzett memória vagy a memória leképezett fájlok * túl nagyok lehetnek ahhoz, hogy kezelni tudják ezt a funkciót.
    ///
    /// Fontolja meg az [`wrapping_add`] használatát, ha ezeket a korlátokat nehéz kielégíteni.
    /// A módszer egyetlen előnye, hogy agresszívebb optimalizálást tesz lehetővé a fordítóban.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // BIZTONSÁG: a hívónak be kell tartania az `offset` biztonsági szerződését.
        unsafe { self.offset(count as isize) }
    }

    /// Kiszámítja az eltolást egy mutatóból (kényelem a `.offset ((isize).wrapping_neg())`) értéknek számít).
    ///
    /// `count` T egységben van;pl. egy 3 `count` az `3 * size_of::<T>()` bájtok mutatójának eltolását jelenti.
    ///
    /// # Safety
    ///
    /// Az alábbi feltételek bármelyikének megsértése esetén az eredmény meghatározatlan viselkedés:
    ///
    /// * A kezdő és az eredményes mutatónak határok között vagy egy bájttal kell lennie ugyanazon allokált objektum végén.
    /// Vegye figyelembe, hogy a Rust alkalmazásban minden (stack-allocated) változó külön allokált objektumnak számít.
    ///
    /// * A kiszámított eltolás nem haladhatja meg az `isize::MAX`**bájtokat**.
    ///
    /// * A határon lévő eltolás nem támaszkodhat az "wrapping around" címtérre.Vagyis a végtelen pontosságú összegnek illeszkednie kell egy usizbe.
    ///
    /// A fordító és a standard könyvtár általában megpróbálja biztosítani, hogy az allokációk soha ne érjék el azt a méretet, ahol az eltolás aggodalomra ad okot.
    /// Például az `Vec` és az `Box` biztosítja, hogy soha ne rendeljenek többet `isize::MAX` bájtnál, így az `vec.as_ptr().add(vec.len()).sub(vec.len())` mindig biztonságos.
    ///
    /// A legtöbb platform alapvetően nem is képes létrehozni egy ilyen allokációt.
    /// Például egyetlen ismert 64 bites platform sem képes soha kiszolgálni 2 <sup>63</sup> bájt kérést az oldal-tábla korlátozásai vagy a címtér felosztása miatt.
    /// Néhány 32 bites és 16 bites platform azonban sikeresen kiszolgálhatja az `isize::MAX` bájtnál nagyobb kéréseket, például fizikai címkiterjesztéssel.
    ///
    /// Mint ilyen, a közvetlenül az elosztóktól megszerzett memória vagy a memória leképezett fájlok * túl nagyok lehetnek ahhoz, hogy kezelni tudják ezt a funkciót.
    ///
    /// Fontolja meg az [`wrapping_sub`] használatát, ha ezeket a korlátokat nehéz kielégíteni.
    /// A módszer egyetlen előnye, hogy agresszívebb optimalizálást tesz lehetővé a fordítóban.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // BIZTONSÁG: a hívónak be kell tartania az `offset` biztonsági szerződését.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Kiszámítja az eltolást egy mutatóból a becsomagolási aritmetika segítségével.
    /// (kényelem az `.wrapping_offset(count as isize)`) számára
    ///
    /// `count` T egységben van;pl. egy 3 `count` az `3 * size_of::<T>()` bájtok mutatójának eltolását jelenti.
    ///
    /// # Safety
    ///
    /// Maga a művelet mindig biztonságos, de a kapott mutató használata nem.
    ///
    /// Az eredményül kapott mutató ugyanahhoz a lefoglalt objektumhoz marad csatolva, amelyre az `self` mutat.
    /// Nem *használható* egy másik lefoglalt objektum elérésére.Vegye figyelembe, hogy a Rust alkalmazásban minden (stack-allocated) változó külön allokált objektumnak számít.
    ///
    /// Más szavakkal, az `let z = x.wrapping_add((y as usize) - (x as usize))`*nem* teszi az `z`-et ugyanazokká, mint az `y`, még akkor is, ha feltételezzük, hogy az `T` mérete `1`, és nincs túlcsordulás: az `z` továbbra is csatolva van az objektumhoz, amelyhez az `x` csatolva van, és az alárendelés meghatározatlan viselkedés, hacsak `x` és `y` pont ugyanabba a lefoglalt objektumba.
    ///
    /// Az [`add`]-hez képest ez a módszer alapvetően késlelteti az ugyanazon allokált objektumon belüli tartózkodás követelményét: az [`add`] azonnali, nem meghatározott viselkedés az objektumhatárok átlépésekor;Az `wrapping_add` létrehoz egy mutatót, de mégis meghatározatlan viselkedéshez vezet, ha egy mutatóra hivatkozás kerül, amikor az objektum határain kívül esik.
    /// [`add`] jobban optimalizálható, ezért előnyösebb a teljesítményérzékeny kódban.
    ///
    /// A késleltetett ellenőrzés csak a hivatkozott mutató értékét veszi figyelembe, a végeredmény kiszámítása során használt köztes értékeket nem.
    /// Például az `x.wrapping_add(o).wrapping_sub(o)` mindig ugyanaz, mint az `x`.Más szavakkal, megengedett a lefoglalt objektum elhagyása, majd későbbi újbóli belépés.
    ///
    /// Ha át kell lépnie az objektum határait, dobja a mutatót egész számra, és ott végezze el a számtant.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// // Kétféle lépésenként nyers mutató segítségével iterálunk
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Ez a hurok kinyomtatja az "1, 3, 5, "-et
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Kiszámítja az eltolást egy mutatóból a becsomagolási aritmetika segítségével.
    /// (kényelem a `.wrapping_offset ((isize).wrapping_neg())`) értéknek számít)
    ///
    /// `count` T egységben van;pl. egy 3 `count` az `3 * size_of::<T>()` bájtok mutatójának eltolását jelenti.
    ///
    /// # Safety
    ///
    /// Maga a művelet mindig biztonságos, de a kapott mutató használata nem.
    ///
    /// Az eredményül kapott mutató ugyanahhoz a lefoglalt objektumhoz marad csatolva, amelyre az `self` mutat.
    /// Nem *használható* egy másik lefoglalt objektum elérésére.Vegye figyelembe, hogy a Rust alkalmazásban minden (stack-allocated) változó külön allokált objektumnak számít.
    ///
    /// Más szavakkal, az `let z = x.wrapping_sub((x as usize) - (y as usize))`*nem* teszi az `z`-et ugyanazokká, mint az `y`, még akkor is, ha feltételezzük, hogy az `T` mérete `1`, és nincs túlcsordulás: az `z` továbbra is csatolva van az objektumhoz, amelyhez az `x` csatolva van, és az alárendelés meghatározatlan viselkedés, hacsak `x` és `y` pont ugyanabba a lefoglalt objektumba.
    ///
    /// Az [`sub`]-hez képest ez a módszer alapvetően késlelteti az ugyanazon allokált objektumon belüli tartózkodás követelményét: az [`sub`] azonnali, nem meghatározott viselkedés az objektumhatárok átlépésekor;Az `wrapping_sub` létrehoz egy mutatót, de mégis meghatározatlan viselkedéshez vezet, ha egy mutatóra hivatkozás kerül, amikor az objektum határain kívül esik.
    /// [`sub`] jobban optimalizálható, ezért előnyösebb a teljesítményérzékeny kódban.
    ///
    /// A késleltetett ellenőrzés csak a hivatkozott mutató értékét veszi figyelembe, a végeredmény kiszámítása során használt köztes értékeket nem.
    /// Például az `x.wrapping_add(o).wrapping_sub(o)` mindig ugyanaz, mint az `x`.Más szavakkal, megengedett a lefoglalt objektum elhagyása, majd későbbi újbóli belépés.
    ///
    /// Ha át kell lépnie az objektum határait, dobja a mutatót egész számra, és ott végezze el a számtant.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// // Iterálás nyers mutató használatával két elem lépésenként (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Ez a hurok kinyomtatja az "5, 3, 1, "-et
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// A mutató értékét `ptr` értékre állítja.
    ///
    /// Abban az esetben, ha az `self` egy nem méretezett (fat) mutató, ez a művelet csak a mutató részt érinti, míg az (thin) méretű típusoknál ez ugyanolyan hatást gyakorol, mint egy egyszerű hozzárendelés.
    ///
    /// Az így kapott mutató `val` eredetű lesz, azaz egy zsírmutató esetében ez a művelet szemantikailag megegyezik egy új zsírmutató létrehozásával `val` adatmutatóval, de az `self` metaadatával.
    ///
    ///
    /// # Examples
    ///
    /// Ez a funkció elsősorban akkor hasznos, ha a potenciálisan zsíros mutatókon belül bájtos mutatószámtant lehet használni:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // kinyomtatja az "3"-et
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // BIZTONSÁG: Vékony mutató esetén ez a művelet azonos
        // egyszerű feladatra.
        // Zsírmutató esetén az aktuális zsírmutató elrendezés megvalósításával az ilyen mutató első mezője mindig az adatmutató, amelyet szintén hozzárendelünk.
        //
        unsafe { *thin = val };
        self
    }

    /// Beolvassa az értéket az `self`-ből anélkül, hogy elmozdítaná.
    /// Ez változatlanul hagyja az `self` memóriáját.
    ///
    /// Lásd az [`ptr::read`] biztonsági problémákat és példákat.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // BIZTONSÁG: a hívónak be kell tartania az `read` biztonsági szerződését.
        unsafe { read(self) }
    }

    /// Folyamatosan leolvassa az értéket az `self`-ből anélkül, hogy azt elmozdítaná.Ez változatlanul hagyja az `self` memóriáját.
    ///
    /// A volatilis műveletek célja az I/O memória működése, és garantált, hogy a fordító ezeket nem hagyja el és nem rendezi át más illékony műveletek során.
    ///
    ///
    /// Lásd az [`ptr::read_volatile`] biztonsági problémákat és példákat.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // BIZTONSÁG: a hívónak be kell tartania az `read_volatile` biztonsági szerződését.
        unsafe { read_volatile(self) }
    }

    /// Beolvassa az értéket az `self`-ből anélkül, hogy elmozdítaná.
    /// Ez változatlanul hagyja az `self` memóriáját.
    ///
    /// Az `read`-től eltérően a mutató lehet nem igazított.
    ///
    /// Lásd az [`ptr::read_unaligned`] biztonsági problémákat és példákat.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // BIZTONSÁG: a hívónak be kell tartania az `read_unaligned` biztonsági szerződését.
        unsafe { read_unaligned(self) }
    }

    /// Az `count * size_of<T>` bájtokat `self`-ről `dest`-re másolja.
    /// A forrás és a cél átfedhetik egymást.
    ///
    /// NOTE: ennek *ugyanaz a* argumentumrendje van, mint az [`ptr::copy`]-nek.
    ///
    /// Lásd az [`ptr::copy`] biztonsági problémákat és példákat.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // BIZTONSÁG: a hívónak be kell tartania az `copy` biztonsági szerződését.
        unsafe { copy(self, dest, count) }
    }

    /// Az `count * size_of<T>` bájtokat `self`-ről `dest`-re másolja.
    /// Előfordulhat, hogy a forrás és a cél nem fedi egymást.
    ///
    /// NOTE: ennek *ugyanaz a* argumentumrendje van, mint az [`ptr::copy_nonoverlapping`]-nek.
    ///
    /// Lásd az [`ptr::copy_nonoverlapping`] biztonsági problémákat és példákat.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // BIZTONSÁG: a hívónak be kell tartania az `copy_nonoverlapping` biztonsági szerződését.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Kiszámítja a mutatóra alkalmazandó eltolást annak érdekében, hogy az `align`-hez igazodjon.
    ///
    /// Ha nem lehet a mutatót igazítani, akkor a megvalósítás `usize::MAX`-et ad vissza.
    /// Megengedett, hogy a megvalósítás *mindig* adja vissza az `usize::MAX` értéket.
    /// Csak az algoritmus teljesítménye függhet attól, hogy itt használható kompenzációt kap-e, és nem annak helyessége.
    ///
    /// Az eltolást `T` elemek számában fejezik ki, és nem bájtokban.A visszaadott érték az `wrapping_add` módszerrel használható.
    ///
    /// Nincs semmilyen garancia arra, hogy a mutató ellentételezése nem fog túlcsordulni, és nem lépi túl azt a kiosztást, amelybe a mutató mutat.
    ///
    /// A hívónak kell megbizonyosodnia arról, hogy a visszaküldött eltolás az igazítás kivételével minden szempontból helyes-e.
    ///
    /// # Panics
    ///
    /// A panics függvény, ha az `align` nem kettős teljesítmény.
    ///
    /// # Examples
    ///
    /// A szomszédos `u8` elérése `u16` néven
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // míg a mutató az `offset`-en keresztül igazítható, az az allokáción kívülre mutat
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // BIZTONSÁG: Az `align` ellenőrzése szerint a fenti érték 2-es
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// Visszaadja a nyers szelet hosszát.
    ///
    /// A visszaadott érték a **elemek száma**, nem a bájtok száma.
    ///
    /// Ez a funkció akkor is biztonságos, ha a nyers szeletet nem lehet szeletre hivatkozni, mert a mutató nulla vagy nem igazított.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // BIZTONSÁG: Ez biztonságos, mert az `*const [T]` és az `FatPtr<T>` azonos elrendezésű.
            // Csak az `std` vállalhatja ezt a garanciát.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Visszaad egy nyers mutatót a szelet pufferjébe.
    ///
    /// Ez egyenértékű az `self` `*const T` formátumba öntésével, de típusbiztonságosabb.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// Visszaad egy nyers mutatót egy elemhez vagy alszelethez, anélkül, hogy korlátokat ellenőrizne.
    ///
    /// Ha ezt a módszert határon kívüli indexszel hívjuk meg, vagy ha az `self` nem engedhető le, akkor a [[meghatározatlan viselkedés] * még akkor is, ha a kapott mutatót nem használjuk.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // BIZTONSÁG: a hívó biztosítja, hogy az `self`-t alárendelhetővé tegye, és az `index`-et határon belülre.
        unsafe { index.get_unchecked(self) }
    }

    /// Visszaadja az `None` értéket, ha a mutató nulla, vagy pedig megosztott szeletet ad vissza az `Some`-be csomagolt értékre.
    /// Az [`as_ref`]-szel ellentétben ez nem igényli az érték inicializálását.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// A módszer meghívásakor meg kell győződnie arról, hogy *vagy* a mutató NULL *, vagy* az alábbiak mindegyike igaz:
    ///
    /// * A mutatónak [valid] értékűnek kell lennie a sok bájtos `ptr.len() * mem::size_of::<T>()` beolvasásokhoz, és megfelelőnek kell lennie.Ez különösen a következőket jelenti:
    ///
    ///     * Ennek a szeletnek a teljes memóriatartományának egyetlen lefoglalt objektumon belül kell lennie!
    ///       A szeletek soha nem terjedhetnek át több allokált objektumon.
    ///
    ///     * A mutatót még a nulla hosszúságú szeleteknél is igazítani kell.
    ///     Ennek egyik oka az, hogy az enum elrendezés optimalizálása támaszkodhat arra, hogy a referenciák (beleértve a bármilyen hosszúságú szeleteket) összehangoltak és nem nullák, hogy megkülönböztessék őket más adatoktól.
    ///
    ///     Az [`NonNull::dangling()`] használatával olyan mutatót kaphat, amely `data` néven használható nulla hosszúságú szeletekhez.
    ///
    /// * A szelet teljes `ptr.len() * mem::size_of::<T>()` mérete nem lehet nagyobb, mint `isize::MAX`.
    ///   Lásd az [`pointer::offset`] biztonsági dokumentációját.
    ///
    /// * Kényszerítenie kell a Rust álnevezési szabályait, mivel az `'a` visszaadott élettartamot önkényesen választják, és nem feltétlenül tükrözi az adatok tényleges élettartamát.
    ///   Különösen ezen élettartam alatt a memória, amelyre a mutató mutat, nem mutálódhat (kivéve az `UnsafeCell` belsejét).
    ///
    /// Ez akkor is érvényes, ha a módszer eredményét nem használják fel!
    ///
    /// Lásd még: [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // BIZTONSÁG: a hívónak be kell tartania az `as_uninit_slice` biztonsági szerződését.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Egyenlőség a mutatók számára
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Mutatók összehasonlítása
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}