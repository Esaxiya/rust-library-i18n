//! Olyan típusok, amelyek rögzítik az adatokat a memóriában.
//!
//! Néha hasznos, ha vannak olyan tárgyak, amelyek garantáltan nem mozognak, abban az értelemben, hogy a memóriában való elhelyezésük nem változik, és így számolni lehet velük.
//! Az ilyen forgatókönyv elsődleges példája az önreferenciális struktúrák felépítése, mivel egy objektum önmagával való mozgatása érvényteleníti őket, ami meghatározhatatlan viselkedést okozhat.
//!
//! Magas szinten az [`Pin<P>`] biztosítja, hogy az `P` típusú pointerek stabil helye legyen a memóriában, vagyis nem mozgatható máshova, és memóriája nem osztható fel, amíg le nem esik.Azt mondjuk, hogy a célpont "pinned".A dolgok finomabbá válnak, ha olyan típusokat tárgyalnak, amelyek rögzítik a nem rögzített adatokkal;[see below](#projections-and-structural-pinning) további részletekért.
//!
//! Alapértelmezés szerint a Rust összes típusa mozgatható.
//! A Rust lehetővé teszi az összes típus értékenkénti átadását, és a gyakori intelligens mutatótípusok, például az [`Box<T>`] és az `&mut T` lehetővé teszik a bennük lévő értékek cseréjét és mozgatását: kiléphet egy [`Box<T>`]-ből, vagy használhatja az [`mem::swap`]-et.
//! [`Pin<P>`] az `P` típusú mutatót tekeri, így a ["Pin"] <"[" Box "]"<T>> `hasonlóan működik, mint egy reguláris
//!
//! [`Box<T>`]: when a ["Pin"] "<" ["Box"] "<T>>`leesik, így a tartalma is, és a memória megkapja
//!
//! elosztva.Hasonlóképpen, a [`Pin`]`<&mut T>`nagyon hasonlít az `&mut T`-re.Az [`Pin<P>`] azonban nem engedi, hogy az ügyfelek ténylegesen megszerezzenek [`Box<T>`] vagy `&mut T` rögzített adatokhoz, ami azt jelenti, hogy nem használhat olyan műveleteket, mint az [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` szüksége van `&mut T`-re, de nem tudjuk megszerezni.
//!     // Elakadtunk, nem tudjuk felcserélni a hivatkozások tartalmát.
//!     // Használhatnánk az `Pin::get_unchecked_mut`-et, de ez okból nem biztonságos:
//!     // nem használhatjuk az `Pin`-ből való mozgatásra.
//! }
//! ```
//!
//! Érdemes megismételni, hogy az [`Pin<P>`]*nem* változtatja meg azt a tényt, hogy egy Rust fordító minden típust mozgathatónak tekint.Az [`mem::swap`] hívható marad bármely `T` esetén.Ehelyett az [`Pin<P>`] megakadályozza bizonyos *értékek* mozgatását (amelyekre az [`Pin<P>`]-be tekert mutatók mutatnak) azáltal, hogy lehetetlenné teszi olyan módszerek meghívását, amelyekhez `&mut T` szükséges (például [`mem::swap`]).
//!
//! [`Pin<P>`] bármely típusú `P` típusú mutató tekercselésére használható, és mint ilyen, kölcsönhatásba lép [`Deref`] és [`DerefMut`] sorokkal.Egy [`Pin<P>`], ahol az `P: Deref`-et "`P`-style pointer"-nek kell tekinteni a rögzített `P::Target`-hez-tehát egy ["Pin"] <"[" Box "]"<T>> `a rögzített `T` tulajdonosa, és egy [` Pin '] `<` [`Rc`]`<T>>> egy rögzített `T` referencia-számláló mutatója.
//! A helyesség kedvéért az [`Pin<P>`] az [`Deref`] és az [`DerefMut`] megvalósításaira támaszkodik, hogy ne mozduljanak ki az `self` paraméterükből, és csak akkor vigyenek vissza mutatót a rögzített adatokba, amikor rögzített mutatóra hívják őket.
//!
//! # `Unpin`
//!
//! Sok típus mindig szabadon mozgatható, még rögzítve is, mert nem támaszkodnak a stabil címre.Ez magában foglalja az összes alapvető típust (például az [`bool`], [`i32`] és hivatkozásokat), valamint a kizárólag ezekből a típusokat.Azok a típusok, amelyek nem törődnek a rögzítéssel, megvalósítják az [`Unpin`] auto-trait-t, amely megsemmisíti az [`Pin<P>`] hatását.
//! Az `T: Unpin` esetében a ["Pin"] <"[" Box "]"<T>> `és az [`Box<T>`] ugyanúgy működnek, mint a [` Pin '] `<&mut T>` és az `&mut T`.
//!
//! Vegye figyelembe, hogy a rögzítés és az [`Unpin`] csak a hegyes típusú `P::Target`-et érinti, nem pedig maga az `P` típusú mutató, amely az [`Pin<P>`]-be lett csomagolva.Például az, hogy [`Box<T>`]-e az [`Unpin`], nincs-e hatással a ["Pin"] "<" ["Box"] "viselkedésére.<T>>`(itt az `T` a hegyes típusú).
//!
//! # Példa: önreferenciális struktúra
//!
//! Mielőtt további részletekbe bocsátkoznánk, hogy elmagyarázzuk az `Pin<T>`-hez kapcsolódó garanciákat és választási lehetőségeket, megvitatunk néhány példát annak felhasználására.
//! Nyugodtan használhatja az [skip to where the theoretical discussion continues](#drop-guarantee) alkalmazást.
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Ez egy önreferenciális struktúra, mert a szelet mező az adatmezőre mutat.
//! // Erről normál referenciával nem tájékoztathatjuk a fordítót, mivel ez a minta nem írható le a szokásos hitelfelvételi szabályokkal.
//! //
//! // Ehelyett egy nyers mutatót használunk, bár ismert, hogy nem null, mivel tudjuk, hogy a karakterláncra mutat.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Annak biztosítása érdekében, hogy az adatok ne mozogjanak, amikor a függvény visszatér, elhelyezzük azokat a kupacban, ahol az objektum élettartama alatt megmaradnak, és az elérésük egyetlen módja a mutatója lesz.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // csak akkor hozzuk létre a mutatót, ha az adatok a helyükön vannak, különben már azelőtt elindult, hogy elkezdtük volna
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // tudjuk, hogy ez biztonságos, mert egy mező módosítása nem mozgatja meg az egész struktúrát
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // A mutatónak a helyes helyre kell mutatnia, mindaddig, amíg a struktúra nem mozdult.
//! //
//! // Közben szabadon mozgathatjuk a mutatót.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Mivel a mi típusunk nem hajtja végre az Unpin-t, ezt nem sikerül lefordítani:
//! // let mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Példa: tolakodó, duplán linkelt lista
//!
//! Egy tolakodó, kétszeresen összekapcsolt listában a gyűjtemény valójában nem maga osztja ki a memóriát az elemek számára.
//! Az allokációt az ügyfelek ellenőrzik, és az elemek olyan veremkereten élhetnek, amely rövidebb ideig él, mint a gyűjtemény.
//!
//! Ahhoz, hogy ez működjön, minden elemnek hivatkoznia kell az elődre és az utódra a listán.Az elemeket csak rögzítéskor lehet hozzáadni, mert az elemek mozgatása érvényteleníti a mutatókat.Ezenkívül egy összekapcsolt listaelem [`Drop`] megvalósítása javítja az előd és utód mutatóit, hogy eltávolítsa magát a listáról.
//!
//! Alapvetően fontosnak kell lennünk abban, hogy az [`drop`]-et hívják.Ha egy elemet el lehetne osztani vagy más módon érvényteleníteni az [`drop`] meghívása nélkül, akkor a szomszédos elemekből származó mutatók érvénytelenné válnak, ami megtöri az adatszerkezetet.
//!
//! Ezért a rögzítéshez egy ["drop"] garancia is jár.
//!
//! # `Drop` guarantee
//!
//! A rögzítés célja, hogy támaszkodhasson néhány adat memóriában való elhelyezésére.
//! Ahhoz, hogy ez működjön, nemcsak az adatok mozgatása korlátozott;Az adatok tárolására használt memória elosztása, újrafelhasználása vagy egyéb érvénytelenítése szintén korlátozott.
//! Konkrétan, a rögzített adatokhoz meg kell őrizni azt az invariánst, hogy * annak memóriája nem lesz érvénytelen vagy újrafelhasználható attól a pillanattól kezdve, amikor rögzül, egészen az [`drop`] hívásáig.Csak akkor, ha az [`drop`] visszatér, vagy a panics, a memória újra felhasználható.
//!
//! A memória lehet "invalidated" az elosztás révén, de az is, hogy egy [`Some(v)`]-et kicserél az [`None`]-re, vagy az [`Vec::set_len`]-t "kill"-re hívja le a vector egyes elemeiről.Az [`ptr::write`] használatával felülírható anélkül, hogy előbb felhívnánk a destruktort.Mindez nem engedélyezett rögzített adatokhoz az [`drop`] hívása nélkül.
//!
//! Pontosan ez a garancia arra, hogy az előző szakaszba behatoló linkelt listának megfelelően kell működnie.
//!
//! Vegye figyelembe, hogy ez a garancia *nem* azt jelenti, hogy a memória nem szivárog!Még mindig teljesen rendben van, ha soha nem hívjuk meg az [`drop`]-et egy rögzített elemen (pl. Akkor is hívhatjuk az [`mem::forget`]-et egy ["Pin"] <"[" Box "]"<T>> `).A kétszeresen összekapcsolt lista példájában ez az elem csak a listán maradna.Azonban nem szabadíthatja fel vagy használhatja fel újra a tárhelyet *a [`drop`]* hívása nélkül.
//!
//! # `Drop` implementation
//!
//! Ha a típusod rögzítést használ (például a fenti két példát), akkor óvatosnak kell lenned az [`Drop`] végrehajtásakor.Az [`drop`] függvény felveszi az `&mut self`-et, de ezt *-nak hívjuk, még akkor is, ha a típusát korábban rögzítettük*!Olyan, mintha a fordító automatikusan felhívta volna az [`Pin::get_unchecked_mut`]-et.
//!
//! Ez soha nem okozhat problémát a biztonságos kódban, mivel a rögzítésre támaszkodó típus végrehajtása nem biztonságos kódot igényel, de vegye figyelembe, hogy a rögzítés használatának eldöntése a típusában (például valamilyen művelet végrehajtása a [`Pin`]`<&Self>`vagy [`Pin`] `<&mut Self>`) következményekkel jár az [`Drop`] implementációjára nézve is: ha egy típusú elemet rögzíteni lehetett volna, akkor az [`Drop`]-et úgy kell kezelni, hogy az implicit módon veszi a [`Pin`]` <&mut Ön>>.
//!
//!
//! Például megvalósíthatja az `Drop`-et az alábbiak szerint:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` rendben van, mert tudjuk, hogy ezt az értéket soha többé nem használjuk, miután eldobtuk.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // A tényleges drop kód ide kerül.
//!         }
//!     }
//! }
//! ```
//!
//! Az `inner_drop` függvény típusa megegyezik az [`drop`]*funkcióval*, így ez biztosítja, hogy véletlenül ne használja az `self`/`this`-et olyan módon, amely ütközik a rögzítéssel.
//!
//! Sőt, ha az Ön típusa `#[repr(packed)]`, a fordító automatikusan áthelyezi a mezőket, hogy eldobhassa őket.Még azt is megteheti, hogy azok a mezők, amelyek történetesen kellően igazodnak.Ennek következtében nem használhatja a rögzítést `#[repr(packed)]` típushoz.
//!
//! # Vetítések és strukturális rögzítés
//!
//! Rögzített struktúrákkal való munka során felmerül a kérdés, hogyan lehet hozzáférni az adott struktúra mezőihez egy olyan módszerben, amely csak ["Pin"] "<&mut Struct>"-t igényel.
//! A szokásos megközelítés olyan segítő módszerek (úgynevezett *vetületek*) megírása, amelyek a ["Pin"] <&mut Struct> "mezőre történő hivatkozássá változtatják, de milyen típusú legyen a hivatkozás?A [`Pin ']`<&mut Field>`vagy az `&mut Field`?
//! Ugyanez a kérdés merül fel egy `enum` mezőivel, és az container/wrapper típusok, például az [`Vec<T>`], [`Box<T>`] vagy [`RefCell<T>`] figyelembe vételével is.
//! (Ez a kérdés mind a mutábilis, mind a megosztott hivatkozásokra vonatkozik, csak a mutábilis hivatkozások gyakoribb esetét használjuk itt szemléltetésül.)
//!
//! Kiderült, hogy valójában az adatszerkezet szerzőjének kell eldöntenie, hogy egy adott mező rögzített vetülete a ["Pin"] <&mut Struct> "-t [[Pin"] "<&mut Field>"-re változtatja-e, vagy `&mut Field`.Van néhány korlátozás, és a legfontosabb korlát a *következetesség*:
//! minden mezőt *kivetíthetünk rögzített referenciára,* vagy * eltávolíthatjuk a rögzítést a vetítés részeként.
//! Ha mindkettő ugyanarra a mezőre készül, akkor ez valószínűleg megalapozatlan!
//!
//! Az adatstruktúra szerzőjeként minden mezőnél el kell döntenie, hogy az "propagates"-et ehhez a mezőhöz rögzíti-e vagy sem.
//! A terjedő rögzítést "structural"-nek is hívják, mert ez követi a típus szerkezetét.
//! A következő alfejezetekben leírjuk azokat a szempontokat, amelyeket bármelyik választásnál meg kell tenni.
//!
//! ## A *rögzítés nem* strukturális az `field` esetében
//!
//! Ellen intuitívnak tűnhet, hogy a rögzített struktúra mezője nem rögzíthető, de valójában ez a legegyszerűbb választás: ha soha nem jön létre egy ["Pin"] "<&mut Field>", akkor semmi sem baj!Tehát, ha úgy dönt, hogy valamely mező nem rendelkezik strukturális rögzítéssel, akkor csak annyit kell biztosítania, hogy soha ne hozzon létre rögzített hivatkozást arra a mezőre.
//!
//! A strukturális rögzítés nélküli mezőknél lehet olyan vetítési módszer, amely a ["Pin"] <&mut Struct> `-t `&mut Field`-be változtatja:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Ez rendben van, mert az `field`-et soha nem tekintik rögzítettnek.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Akkor is `impl Unpin for Struct`*, még akkor is, ha* az `field` típusa nem [`Unpin`].Az, hogy ez a típus mit gondol a rögzítésről, nem releváns, ha soha nem jön létre ["Pin"] "<&mut Field>".
//!
//! ## A rögzítés * az `field` struktúrája
//!
//! A másik lehetőség annak eldöntése, hogy a rögzítés "structural" az `field` esetében, ami azt jelenti, hogy ha a struktúra rögzítve van, akkor a mező is.
//!
//! Ez lehetővé teszi egy olyan vetület megírását, amely létrehoz egy ["Pin"] "<&mut Field>"-t, ezzel tanúsítva, hogy a mező rögzítve van:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Ez rendben van, mert az `field` rögzítve van, amikor az `self` van.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! A szerkezeti rögzítés azonban néhány extra követelményt tartalmaz:
//!
//! 1. A struktúra csak akkor lehet [`Unpin`], ha az összes strukturális mező [`Unpin`].Ez az alapértelmezett, de az [`Unpin`] egy biztonságos trait, így a struktúra szerzőjeként az Ön felelőssége *nem* hozzáadni valamit, mint például az `impl<T> Unpin for Struct<T>`.
//! (Vegye figyelembe, hogy egy vetítési művelet hozzáadása nem biztonságos kódot igényel, így az a tény, hogy az [`Unpin`] biztonságos trait, nem sérti azt az elvet, hogy ezek miatt csak akkor kell aggódnia, ha " nem biztonságos` funkciót használ.)
//! 2. A struct rombolója nem mozdíthatja el a strukturális mezőket az argumentumából.Ez az a pont, amely az [previous section][drop-impl]-ben felvetődött: Az `drop` felveszi az `&mut self`-et, de a struktúra (és ennélfogva a mezői) már korábban rögzíthetők voltak.
//!     Garantálnia kell, hogy az [`Drop`] implementáción belül nem mozgat mezőt.
//!     Különösen, amint azt korábban kifejtettük, ez azt jelenti, hogy a struktúrája *nem* lehet `#[repr(packed)]`.
//!     Ebben a szakaszban megtudhatja, hogyan írhatja az [`drop`]-et úgy, hogy a fordító segítsen abban, hogy ne véletlenül szakítsa meg a rögzítést.
//! 3. Győződjön meg arról, hogy fenntartja az [`Drop` guarantee][drop-guarantee]-et:
//!     A struktúra rögzítése után a tartalmat tartalmazó memória nem kerül felülírásra vagy elosztásra anélkül, hogy felhívnánk a tartalom rombolóit.
//!     Ez bonyolult lehet, amint azt az [`VecDeque<T>`] is tanúsítja: az [`VecDeque<T>`] rombolója nem tudja meghívni az [`drop`]-et minden elemen, ha az egyik romboló panics.Ez sérti az [`Drop`] garanciát, mert ahhoz vezethet, hogy az elemeket elosztják anélkül, hogy rombolójukat meghívnák.(Az [`VecDeque<T>`] nem rendelkezik rögzítő vetületekkel, így ez nem okoz alaptalanságot.)
//! 4. Nem ajánlhat olyan egyéb műveletet, amely az adatok áthelyezéséhez vezethet a szerkezeti mezőkből, amikor a típus rögzítve van.Például, ha a struktúra tartalmaz egy [`Option<T>`]-et, és van egy " take-szerű` művelet `fn(Pin<&mut Struct<T>>) -> Option<T>` típusnál, akkor ezt a műveletet használhatjuk egy `T` mozgatására egy rögzített `Struct<T>`-ből-ami azt jelenti, hogy a rögzítés nem lehet strukturális az ezt tartó mező számára adat.
//!
//!     Az adatok rögzített típusból való áthelyezésének összetettebb példájaként képzelje el, hogy az [`RefCell<T>`] rendelkezik-e `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>` módszerrel.
//!     Akkor a következőket tehettük:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Ez katasztrofális, azt jelenti, hogy először rögzíthetjük az [`RefCell<T>`] tartalmát (az `RefCell::get_pin_mut` használatával), majd áthelyezhetjük azt a később kapott mutábilis referencia segítségével.
//!
//! ## Examples
//!
//! Az [`Vec<T>`]-hez hasonló típusoknál mindkét lehetőségnek (szerkezeti rögzítés vagy nem) van értelme.
//! A strukturális rögzítéssel rendelkező [`Vec<T>`]-nek `get_pin`/`get_pin_mut` metódusai lehetnek az elemek rögzített hivatkozásainak megszerzéséhez.Azonban *nem* engedélyezheti az [`pop`][Vec::pop] hívását egy rögzített [`Vec<T>`]-en, mert ez elmozdítja a (szerkezetileg rögzített) tartalmat!Nem engedélyezhette az [`push`][Vec::push]-et sem, amely átcsoportosíthatja és így a tartalmat is áthelyezheti.
//!
//! Strukturális rögzítés nélküli [`Vec<T>`] az `impl<T> Unpin for Vec<T>`-et, mert a tartalmat soha nem rögzítik, és maga az [`Vec<T>`] is jól mozgatható.
//! Ekkor a rögzítésnek egyáltalán nincs hatása a vector-re.
//!
//! A szokásos könyvtárban a mutatótípusok általában nem rendelkeznek szerkezeti rögzítéssel, ezért nem kínálnak rögzítési vetületeket.Ezért az `Box<T>: Unpin` minden `T` esetén érvényes.
//! Célszerű ezt a mutatótípusoknál megtenni, mert az `Box<T>` mozgatása valójában nem mozgatja az `T`-et: az [`Box<T>`] akkor is szabadon mozgatható (más néven `Unpin`), ha az `T` nem.Valójában még a ["Pin"] <"[" Box "]" is<T>>> és [`Pin ']` <&mut T> `mindig [`Unpin`] maguk, ugyanazon okból kifolyólag: tartalmuk (`T`) rögzítve van, de maguk a mutatók mozgathatók a rögzített adatok mozgatása nélkül.
//! Az [`Box<T>`] és a ["Pin"] esetén is <<[[Box]] `<T>>`, hogy a tartalom rögzítve van-e, teljesen független attól, hogy a mutató rögzítve van-e, vagyis a rögzítés nem * strukturális.
//!
//! Az [`Future`] kombinátor megvalósításakor általában strukturális rögzítésre van szükség a beágyazott futures számára, mivel rögzített hivatkozásokat kell kapnia rájuk az [`poll`] hívásához.
//! De ha a kombinátorod tartalmaz olyan egyéb adatot, amelyet nem kell rögzíteni, akkor ezeket a mezőket nem strukturálttá teheted, és ezáltal szabadon hozzáférhetsz hozzájuk egy mutatható hivatkozással, még akkor is, ha csak ["Pin"] "<&mut Self>" van mint a saját [`poll`] megvalósításában).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Rögzített mutató.
///
/// Ez egyfajta mutató körüli burkolat, amely az "pin" mutatót a helyére teszi, megakadályozva ezzel a mutató által hivatkozott érték mozgatását, hacsak nem hajtja végre az [`Unpin`]-et.
///
///
/// *A rögzítés magyarázatát az [`pin` module] dokumentációjában találja.*
///
/// [`pin` module]: self
///
// Note: az alábbi `Clone` származtatás zavartságot okoz, mivel megvalósítható
// `Clone` mutálható hivatkozásokra.
// További részletek: <https://internals.rust-lang.org/t/unsoundness-in-pin/11311>.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Az alábbi megvalósítások nem a szilárdsági problémák elkerülése érdekében vannak levezetve.
// `&self.pointer` nem férhet hozzá a nem megbízható trait megvalósításokhoz.
//
// További részletek: <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73>.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Szerkesszen egy új `Pin<P>`-et egy mutató körül az [`Unpin`]-t megvalósító típusú adatokra.
    ///
    /// Az `Pin::new_unchecked`-től eltérően ez a módszer azért biztonságos, mert az `P` mutató az [`Unpin`] típusra hivatkozik, ami megsemmisíti a rögzítési garanciákat.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // BIZTONSÁG: a mutatott érték `Unpin`, ezért nincsenek követelményei
        // a rögzítés körül.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Kicsomagolja ezt az `Pin<P>`-et, és visszaadja az alapul szolgáló mutatót.
    ///
    /// Ehhez megköveteli, hogy az `Pin` belsejében lévő adatok [`Unpin`] legyenek, így a kicsomagoláskor figyelmen kívül hagyhatjuk a rögzítő invariánsokat.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Készítsen új `Pin<P>`-et egy olyan adatra való hivatkozás köré, amely megvalósíthatja az `Unpin`-et vagy nem.
    ///
    /// Ha az `pointer` egy `Unpin` típusra vonatkozik, akkor az `Pin::new`-et kell használni.
    ///
    /// # Safety
    ///
    /// Ez a konstruktor nem biztonságos, mert nem tudjuk garantálni, hogy az `pointer` által jelzett adatok rögzítve vannak, ami azt jelenti, hogy az adatok nem kerülnek áthelyezésre vagy tárolásuk érvénytelenségére, amíg el nem esnek.
    /// Ha a felépített `Pin<P>` nem garantálja, hogy az `P` pont adatai rögzítve vannak, akkor ez az API szerződés megsértése, és meghatározatlan viselkedéshez vezethet a későbbi (safe) műveletekben.
    ///
    /// Ezzel a módszerrel promise-t készít az `P::Deref` és `P::DerefMut` megvalósításokról, ha vannak ilyenek.
    /// A legfontosabb, hogy ne mozduljanak ki az `self` argumentumokból: az `Pin::as_mut` és az `Pin::as_ref` felhívja az `DerefMut::deref_mut` és `Deref::deref`*kódokat a rögzített mutatóra*, és elvárják, hogy ezek a módszerek fenntartsák a rögzítő invariánsokat.
    /// Ezenfelül, ha ezt a módszert meghívja, akkor promise, hogy az `P` referencia-hivatkozások nem kerülnek újra;különösen nem lehet lehetséges `&mut P::Target` megszerzése, majd az adott referenciáról való elmozdulás (például [`mem::swap`] használatával).
    ///
    ///
    /// Például az `Pin::new_unchecked` hívása `&'a mut T`-en nem biztonságos, mert bár képes rögzíteni az `'a` adott élettartamára, nem tudja ellenőrizni, hogy az `'a` befejezése után rögzítve legyen-e:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Ennek azt kell jelentenie, hogy a pointee `a` soha többé nem tud mozogni.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Az `a` címe "b" veremhelyre változott, így az `a`-et áthelyezték, annak ellenére, hogy korábban rögzítettük!Megsértettük a rögzítési API-szerződést.
    /////
    /// }
    /// ```
    ///
    /// A rögzített értéknek örökre rögzítve kell maradnia (kivéve, ha típusa megvalósítja az `Unpin`-et).
    ///
    /// Hasonlóképpen az `Pin::new_unchecked` hívása `Rc<T>`-en nem biztonságos, mert ugyanazon adatoknak álnevei lehetnek, amelyekre nem vonatkoznak a rögzítési korlátozások:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Ennek azt kell jelentenie, hogy a célpont soha többé nem mozdulhat.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Most, ha az `x` volt az egyetlen referencia, van egy megváltoztatható hivatkozás a fent rögzített adatokra, amelyeket felhasználhatunk az áthelyezéshez, ahogyan azt az előző példában láttuk.
    ///     // Megsértettük a rögzítési API-szerződést.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Rögzített megosztott hivatkozást kap ebből a rögzített mutatóból.
    ///
    /// Ez egy általános módszer az `&Pin<Pointer<T>>` és az `Pin<&T>` közötti váltásra.
    /// Biztonságos, mert az `Pin::new_unchecked` szerződés részeként a pointee nem tud mozogni az `Pin<Pointer<T>>` létrehozása után.
    ///
    /// "Malicious" Az `Pointer::Deref` megvalósítását szintén kizárja az `Pin::new_unchecked` szerződése.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // BIZTONSÁG: lásd a funkció dokumentációját
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Kicsomagolja ezt az `Pin<P>`-et, és visszaadja az alapul szolgáló mutatót.
    ///
    /// # Safety
    ///
    /// Ez a funkció nem biztonságos.Garantálnia kell, hogy az `P` mutatót továbbra is rögzítve fogja kezelni, miután meghívta ezt a funkciót, hogy az `Pin` típusú invariánsok fenntarthatók legyenek.
    /// Ha az eredményül kapott `P`-et használó kód nem folytatja a rögzítő invariánsok fenntartását, ez megsérti az API-szerződést, és meghatározatlan viselkedéshez vezethet a későbbi (safe)-műveletek során.
    ///
    ///
    /// Ha az alapul szolgáló adatok [`Unpin`], akkor inkább [`Pin::into_inner`]-et kell használni.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Rögzített módosítható hivatkozást kap ebből a rögzített mutatóból.
    ///
    /// Ez egy általános módszer az `&mut Pin<Pointer<T>>` és az `Pin<&mut T>` közötti váltásra.
    /// Biztonságos, mert az `Pin::new_unchecked` szerződés részeként a pointee nem tud mozogni az `Pin<Pointer<T>>` létrehozása után.
    ///
    /// "Malicious" Az `Pointer::DerefMut` megvalósítását szintén kizárja az `Pin::new_unchecked` szerződése.
    ///
    /// Ez a módszer akkor hasznos, ha többször is hívunk olyan funkciókat, amelyek a rögzített típust fogyasztják.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // csinálj valamit
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` az `self`-et fogyasztja, ezért az `Pin<&mut Self>`-et az `as_mut`-en keresztül kell kölcsönadni.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // BIZTONSÁG: lásd a funkció dokumentációját
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Új értéket rendel a rögzített referencia mögött lévő memóriához.
    ///
    /// Ez felülírja a rögzített adatokat, de ez rendben van: a destruktor futtatásra kerül, mielőtt felülírnák, így a rögzítési garancia nem sérül.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Új belső tűt készít a belső érték feltérképezésével.
    ///
    /// Például, ha valaminek a mezőjéről `Pin`-et szeretett volna kapni, akkor ezt használhatja arra, hogy hozzáférjen az adott mezőhöz egy kódsorban.
    /// Az "pinning projections"-hez azonban több getcha is tartozik;
    /// a témával kapcsolatos további részletekért lásd az [`pin` module] dokumentációját.
    ///
    /// # Safety
    ///
    /// Ez a funkció nem biztonságos.
    /// Garantálnia kell, hogy a visszaküldött adatok addig nem mozognak, amíg az argumentum értéke nem mozog (például azért, mert ez az érték egyik mezője), és azt is, hogy ne mozduljon ki a kapott argumentumból a belső funkciót.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // BIZTONSÁG: az `new_unchecked` biztonsági szerződésének meg kell lennie
        // a hívó fél fenntartja.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Megkap egy megosztott referenciát a tűből.
    ///
    /// Ez biztonságos, mert nem lehet kimozdulni egy megosztott referenciából.
    /// Úgy tűnhet, hogy itt van egy kérdés a belső mutabilitással: valójában *lehetséges* mozgatni egy `T`-et az `&RefCell<T>`-ből.
    /// Ez azonban nem jelent problémát, mindaddig, amíg nem létezik ugyanazokra az adatokra mutató `Pin<&T>`, és az `RefCell<T>` nem engedi, hogy rögzített hivatkozást hozzon létre annak tartalmára.
    ///
    /// További részletekért tekintse meg az ["pinning projections"] beszélgetését.
    ///
    /// Note: Az `Pin` az `Deref`-et is megvalósítja a célponton, amely felhasználható a belső érték eléréséhez.
    /// Az `Deref` azonban csak olyan referenciát nyújt, amely mindaddig él, amíg az `Pin` kölcsönt kölcsönöz, nem pedig maga az `Pin` élettartama.
    /// Ez a módszer lehetővé teszi, hogy az `Pin`-et referenciává alakítsák, azonos élettartammal, mint az eredeti `Pin`.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Ezt az `Pin<&mut T>`-et átalakítja azonos élettartamú `Pin<&T>`-be.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Cserélhető hivatkozást kap az `Pin` belsejében lévő adatokra.
    ///
    /// Ehhez megköveteli, hogy az `Pin` belsejében lévő adatok `Unpin` legyenek.
    ///
    /// Note: Az `Pin` az `DerefMut`-et is implementálja az adatokba, amely felhasználható a belső érték eléréséhez.
    /// Az `DerefMut` azonban csak olyan referenciát nyújt, amely mindaddig él, amíg az `Pin` kölcsönt kölcsönöz, nem pedig maga az `Pin` élettartama.
    ///
    /// Ez a módszer lehetővé teszi, hogy az `Pin`-et referenciává alakítsák, azonos élettartammal, mint az eredeti `Pin`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Cserélhető hivatkozást kap az `Pin` belsejében lévő adatokra.
    ///
    /// # Safety
    ///
    /// Ez a funkció nem biztonságos.
    /// Garantálnia kell, hogy soha nem mozdítja el az adatokat a megváltoztatható referenciából, amelyet a funkció meghívásakor kapott, hogy az `Pin` típusú invariánsok fenntarthatók legyenek.
    ///
    ///
    /// Ha az alapul szolgáló adatok `Unpin`, akkor inkább `Pin::get_mut`-et kell használni.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Készítsen új tűt a belső érték feltérképezésével.
    ///
    /// Például, ha valaminek a mezőjéről `Pin`-et szeretett volna kapni, akkor ezt használhatja arra, hogy hozzáférjen az adott mezőhöz egy kódsorban.
    /// Az "pinning projections"-hez azonban több getcha is tartozik;
    /// a témával kapcsolatos további részletekért lásd az [`pin` module] dokumentációját.
    ///
    /// # Safety
    ///
    /// Ez a funkció nem biztonságos.
    /// Garantálnia kell, hogy a visszaküldött adatok addig nem mozognak, amíg az argumentum értéke nem mozog (például azért, mert ez az érték egyik mezője), és azt is, hogy ne mozduljon ki a kapott argumentumból a belső funkciót.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // BIZTONSÁG: a hívó fél felelős azért, hogy ne mozdítsa el
        // érték ebből a referenciából.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // BIZTONSÁG: mivel az `this` értéke garantáltan nem rendelkezik
        // áthelyezték, ez az `new_unchecked` telefonhívás biztonságos.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Szerezzen rögzített hivatkozást egy statikus hivatkozásból.
    ///
    /// Ez biztonságos, mert az `T`-et az `'static` élettartamára kölcsönzik, amely soha nem ér véget.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // BIZTONSÁG: A " statikus hitelfelvétel garantálja, hogy az adatok nem lesznek
        // moved/invalidated amíg le nem esik (ami soha nem).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Szerezzen rögzített változtatható referenciát statikus mutábilis referenciából.
    ///
    /// Ez biztonságos, mert az `T`-et az `'static` élettartamára kölcsönzik, amely soha nem ér véget.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // BIZTONSÁG: A " statikus hitelfelvétel garantálja, hogy az adatok nem lesznek
        // moved/invalidated amíg le nem esik (ami soha nem).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: ez azt jelenti, hogy az `CoerceUnsized` bármely implikációja, amely lehetővé teszi a kényszerítést
// az a típus, amely az `Deref<Target=impl !Unpin>`-et az `Deref<Target=Unpin>`-et implikálja, nem egészséges.
// Bármely ilyen implicit valószínűleg más okokból is ésszerűtlen lenne, ezért csak arra kell vigyáznunk, hogy ne engedjük, hogy az ilyen implikációk a std-ben landoljanak.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}