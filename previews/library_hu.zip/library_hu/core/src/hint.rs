#![stable(feature = "core_hint", since = "1.27.0")]

//! Tippek a fordítóhoz, amelyek befolyásolják a kód kiadásának vagy optimalizálásának módját.
//! Tippek lehetnek fordítási idő vagy futásidő.

use crate::intrinsics;

/// Tájékoztatja a fordítót, hogy a kódnak ez a pontja nem érhető el, lehetővé téve a további optimalizálást.
///
/// # Safety
///
/// Ennek a funkciónak az elérése teljesen *undefined viselkedés*(UB).A fordító azt feltételezi, hogy az összes UB-nak soha nem szabad megtörténnie, és ezért megszünteti az összes elágazást, amely eléri az `unreachable_unchecked()` hívását.
///
/// Mint minden UB eset, ha ez a feltételezés tévesnek bizonyul, azaz az `unreachable_unchecked()` hívás valóban elérhető az összes lehetséges vezérlési folyamat között, a fordító hibás optimalizálási stratégiát alkalmaz, és néha megsértheti a látszólag nem kapcsolódó kódot, ami nehézségeket okozhat. hibakereséshez.
///
///
/// Csak akkor használja ezt a funkciót, ha be tudja bizonyítani, hogy a kód soha nem fogja hívni.
/// Ellenkező esetben fontolja meg az [`unreachable!`] makró használatát, amely nem teszi lehetővé az optimalizálást, de végrehajtásakor a panic értéket fogja megadni.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` mindig pozitív (nem nulla), ezért az `checked_div` soha nem adja vissza az `None` értéket.
/////
///     // Ezért a másik branch elérhetetlen.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // BIZTONSÁG: az `intrinsics::unreachable` biztonsági szerződésének kötelező
    // a hívó fél fenntartja.
    unsafe { intrinsics::unreachable() }
}

/// Gépi utasítást ad ki, hogy jelezze a processzornak, hogy elfoglalt várakozású centrifugában működik ("centrifugálás").
///
/// A spin-loop jel vétele után a processzor optimalizálhatja viselkedését például energiamegtakarítással vagy hyper-szálak kapcsolásával.
///
/// Ez a funkció eltér az [`thread::yield_now`]-től, amely közvetlenül a rendszer ütemezőjének enged, míg az `spin_loop` nem lép kapcsolatba az operációs rendszerrel.
///
/// Az `spin_loop` egyik gyakori esete a korlátozott optimista centrifugálás megvalósítása a CAS hurokban szinkronizációs primitívekben.
/// Az olyan problémák elkerülése érdekében, mint a prioritás inverziója, erősen ajánlott, hogy a centrifugálási ciklust véges számú iteráció után fejezzük be, és megfelelő blokkoló rendszerhívást hajtunk végre.
///
///
/// **Megjegyzés**: Azokon a platformokon, amelyek nem támogatják a spin-loop tippek fogadását, ez a funkció egyáltalán nem tesz semmit.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Közös atomérték, amelyet a szálak használnak a koordinációhoz
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Egy háttérszálban végül beállítjuk az értéket
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Végezzen valamilyen munkát, majd éltesse az értéket
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Visszatérve a jelenlegi szálunkra, megvárjuk az érték beállítását
/// while !live.load(Ordering::Acquire) {
///     // A spin ciklus arra utal, hogy a CPU-ra várunk, de valószínűleg nem túl sokáig
/////
///     hint::spin_loop();
/// }
///
/// // Az érték most be van állítva
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // BIZTONSÁG: Az `cfg` attr biztosítja, hogy ezt csak az x86 célpontokon hajtsuk végre.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // BIZTONSÁG: Az `cfg` attr biztosítja, hogy ezt csak az x86_64 célpontokon hajtsuk végre.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // BIZTONSÁG: Az `cfg` attr biztosítja, hogy ezt csak az aarch64 célpontokon hajtsuk végre.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // BIZTONSÁG: Az `cfg` attr biztosítja, hogy ezt csak a kar célpontjain hajtsuk végre
            // az v6 szolgáltatás támogatásával.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Olyan identitásfüggvény, amely * __ arra utal a fordítónak, hogy maximálisan pesszimista legyen arról, hogy az `black_box` mit tehet.
///
/// Az [`std::convert::identity`]-től eltérően a Rust fordító azt javasolja, hogy feltételezze, hogy az `black_box` az `dummy`-et bármilyen lehetséges érvényes módon felhasználhatja, amire a Rust kód megengedett, anélkül, hogy meghatározatlan viselkedést vezetne be a hívó kódba.
///
/// Ez a tulajdonság teszi az `black_box`-et olyan kódok írásához hasznosak, amelyekben nincs szükség bizonyos optimalizálásokra, például benchmarkokra.
///
/// Ne feledje azonban, hogy az `black_box` csak (és csak akkor biztosítható) "best-effort" alapon.Az optimalizálás blokkolásának mértéke az alkalmazott platformtól és code-gen háttérrendszertől függően változhat.
/// A programok semmilyen módon nem támaszkodhatnak az `black_box`-re a * helyességért.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Valamilyen módon meg kell "use"-en argumentálnunk az argumentumot, az LLVM nem tud önfelügyeletet folytatni, és az ezt támogató célpontokon általában a soros összeszerelést használhatjuk fel erre.
    // Az LLVM úgy értelmezi az inline összeszerelést, hogy ez egy fekete doboz.
    // Ez nem a legnagyobb megvalósítás, mivel valószínűleg többet desoptimalizál, mint amennyit szeretnénk, de egyelőre elég jó.
    //
    //

    #[cfg(not(miri))] // Ez csak egy tipp, ezért rendben van kihagyni a Mirit.
    // BIZTONSÁG: a belső szerelvény nem op.
    unsafe {
        // FIXME: Az `asm!` nem használható, mert nem támogatja az MIPS és más architektúrákat.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}