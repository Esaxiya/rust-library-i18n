#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Az idegen funkciós interfész (FFI) kötésekhez kapcsolódó segédprogramok.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// Megegyezik a C `void` típusával, ha [pointer]-ként használják.
///
/// Lényegében az `*const c_void` egyenértékű a C `const void*` értékével, az `*mut c_void` pedig a C `void*` értékével.
/// Ez azt jelenti, hogy ez *nem* azonos a C `void` visszatérési típusával, amely a Rust `()` típusa.
///
/// Az FFI átlátszatlan típusaira mutató mutatók modellezéséhez az `extern type` stabilizálásáig ajánlott egy newtype burkolót használni egy üres bájt tömb köré.
///
/// A részleteket lásd az [Nomicon]-ben.
///
/// Használhatná az `std::os::raw::c_void`-et, ha a régi Rust fordítóprogramot 1.1.0-ig akarják támogatni.
/// A Rust 1.30.0 után újra exportálta ezt a meghatározást.
/// További információért kérjük, olvassa el az [RFC 2521] oldalt.
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// Megjegyzés: Ahhoz, hogy az LLVM felismerje az érvénytelen mutatótípust és az malloc() kiterjesztésű funkciókkal, i8 *-ként kell ábrázolnunk az LLVM bitkódban.
// Az itt használt enum biztosítja ezt, és megakadályozza az "raw" típus visszaélését azáltal, hogy csak privát változatai vannak.
// Két változatra van szükségünk, mert a fordító egyébként a repr attribútumra panaszkodik, és legalább egy variánsra van szükségünk, mivel különben az enum lakatlan lenne, és legalább az ilyen mutatók levezetése UB lenne.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// Egy `va_list` alapvető megvalósítása.
// A név WIP, egyelőre az `VaListImpl` használatával.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // Variáns az `'f` felett, így minden `VaListImpl<'f>` objektum a függvény azon régiójához van kötve, amelyben meghatározták
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 Egy `va_list` ABI megvalósítása.
/// További részletekért lásd az [AArch64 Procedure Call Standard]-et.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC Egy `va_list` ABI megvalósítása.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 Egy `va_list` ABI megvalósítása.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// Burkoló `va_list`-hez
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Konvertáljon egy `VaListImpl`-et `VaList`-be, amely binárisan kompatibilis a C `va_list`-jével.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Konvertáljon egy `VaListImpl`-et `VaList`-be, amely binárisan kompatibilis a C `va_list`-jével.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// A VaArgSafe trait-t nyilvános interfészekben kell használni, azonban nem szabad megengedni, hogy magát a trait-t ezen a modulon kívül használják.
// Ha a felhasználók engedélyezik a trait új típusra való implementálását (ezáltal lehetővé teszi a va_arg intrinsic új típuson történő használatát), az valószínűleg meghatározatlan viselkedést okoz.
//
// FIXME(dlrobertson): Annak érdekében, hogy a VaArgSafe trait-t nyilvános felületen lehessen használni, de azt is biztosítsuk, hogy másutt ne lehessen használni, a trait-nek nyilvánosnak kell lennie egy privát modulon belül.
// Az RFC 2145 bevezetése után vizsgálja meg ennek javítását.
//
//
//
//
mod sealed_trait {
    /// Trait, amely lehetővé teszi az engedélyezett típusok használatát az [super::VaListImpl::arg] készülékkel.
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Előre a következő arg.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // BIZTONSÁG: a hívónak be kell tartania az `va_arg` biztonsági szerződését.
        unsafe { va_arg(self) }
    }

    /// Az `va_list`-et az aktuális helyre másolja.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // BIZTONSÁG: a hívónak be kell tartania az `va_end` biztonsági szerződését.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // BIZTONSÁG: írunk az `MaybeUninit`-re, így inicializálva van, és az `assume_init` törvényes
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: ennek meg kell hívnia az `va_end`-et, de erre nincs tiszta mód
        // garantálja, hogy az `drop` mindig beilleszkedik a hívójába, így az `va_end`-et közvetlenül a megfelelő `va_copy`-mel megkapja.
        // `man va_end` kijelenti, hogy a C ezt megköveteli, és az LLVM alapvetően a C szemantikát követi, ezért meg kell győződnünk arról, hogy az `va_end` mindig ugyanazon függvényből lesz meghívva, mint az `va_copy`.
        //
        // További részletekért, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // Ez egyelőre működik, mivel az `va_end` nem engedélyezi az összes jelenlegi LLVM célt.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// Pusztítsd el az `ap` arglistát az `va_start` vagy `va_copy` használatával történő inicializálás után.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Az `src` arglist aktuális helyét átmásolja az `dst` arglistára.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// Betölti az `T` típusú argumentumot az `va_list` `ap`-ből, és növeli az `ap` argumentumot.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}