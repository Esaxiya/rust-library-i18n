//! Ez a modul az `Any` trait modult valósítja meg, amely lehetővé teszi bármely `'static` típus dinamikus gépelését futásidejű reflexióval.
//!
//! `Any` maga használható `TypeId` megszerzésére, és több funkcióval rendelkezik, ha trait objektumként használják.
//! `&dyn Any` (kölcsönzött trait objektumként) `is` és `downcast_ref` módszerrel rendelkezik, hogy tesztelje, hogy a megadott érték adott típusú-e, és hogy hivatkozást kapjon a belső értékre, mint típusra.
//! `&mut dyn Any` néven létezik az `downcast_mut` módszer is, amellyel módosítható hivatkozást kapunk a belső értékre.
//! `Box<dyn Any>` hozzáadja az `downcast` metódust, amely megpróbál átalakítani `Box<T>`-be.
//! A részleteket lásd az [`Box`] dokumentációjában.
//!
//! Vegye figyelembe, hogy az `&dyn Any` arra korlátozódik, hogy tesztelje, hogy egy érték meghatározott betontípus-e, és nem használható annak tesztelésére, hogy egy típus megvalósítja-e a trait-t.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Intelligens mutatók és `dyn Any`
//!
//! Az `Any` trait objektumként történő használatakor, különösen az `Box<dyn Any>` vagy az `Arc<dyn Any>` típusoknál, egyik szem előtt tartandó viselkedés az, hogy ha egyszerűen az értékre hívja az `.type_id()` értéket, akkor a *tároló*`TypeId` értékét adja, nem pedig az alatta lévő trait objektumot.
//!
//! Ezt úgy lehet elkerülni, hogy az intelligens mutatót `&dyn Any` formátumba konvertálja, amely visszaadja az objektum `TypeId`-jét.
//! Például:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Nagyobb valószínűséggel akarja ezt:
//! let actual_id = (&*boxed).type_id();
//! // ... mint ez:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Vegyünk egy helyzetet, amikor ki akarunk jelentkezni egy függvénynek átadott értéket.
//! Tudjuk, hogy milyen értéken dolgozunk a Debug megvalósításában, de nem ismerjük annak konkrét típusát.Különleges bánásmódot kívánunk biztosítani bizonyos típusokkal: ebben az esetben a String értékek értékének előtti hosszát nyomtatjuk ki.
//! A fordítás idején nem ismerjük értékünk konkrét típusát, ezért inkább futásidejű reflexiót kell használnunk.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Naplózó funkció minden olyan típushoz, amely végrehajtja a hibakeresést.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Próbálja átalakítani értékünket `String`-be.
//!     // Sikeres eredmény esetén a String hosszát és értékét is ki akarjuk adni.
//!     // Ha nem, akkor más típusú: csak dísz nélkül nyomtassa ki.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Ez a függvény ki akarja jelenteni a paraméterét, mielőtt vele munkát végezne.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... végezzen más munkát
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Bármely trait
///////////////////////////////////////////////////////////////////////////////

/// A trait a dinamikus gépelés utánzásához.
///
/// A legtöbb típus az `Any`-et valósítja meg.Bármely típus, amely nem "statikus" hivatkozást tartalmaz, nem.
/// További részletekért lásd az [module-level documentation][mod]-et.
///
/// [mod]: crate::any
// Ez a trait nem veszélyes, bár egyedüli implikációjának nem biztonságos kódban (például `downcast`) szereplő `type_id` funkciójának sajátosságaira támaszkodunk.Normális esetben ez problémát jelentene, de mivel az `Any` egyetlen következménye egy átfogó megvalósítás, egyetlen más kód sem tudja megvalósítani az `Any`-et.
//
// Valószínűleg ezt a trait-t nem biztonságosvá tehetnénk-ez nem okozna törést, mivel az összes megvalósítást ellenőrizzük-, de úgy döntünk, hogy nem, mivel ez mindkettő nem igazán szükséges, és megzavarhatja a felhasználókat a nem biztonságos traits és a nem biztonságos módszerek (pl. Az `type_id` továbbra is biztonságosan hívható, de valószínűleg ezt szeretnénk a dokumentációban feltüntetni).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Megkapja az `self` `TypeId` értékét.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Kiterjesztési módszerek bármilyen trait objektumhoz.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Győződjön meg arról, hogy a szál összekapcsolásának eredménye kinyomtatható, és így felhasználható az `unwrap`-hez.
// Végül nincs szükség rá, ha a feladás felújítással működik.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Az `true` értéket adja vissza, ha a dobozos típus megegyezik az `T` értékkel.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Szerezze be az `TypeId`-et, amellyel ez a funkció példányos.
        let t = TypeId::of::<T>();

        // Szerezzen be `TypeId`-t a trait (`self`) objektumba.
        let concrete = self.type_id();

        // Hasonlítsa össze az egyenlőség mindkét " TypeId` elemét.
        t == concrete
    }

    /// Visszaad néhány utalást a dobozos értékre, ha az `T` típusú, vagy ha nem, akkor az `None` típusra.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // BIZTONSÁG: csak ellenőrizzük, hogy a megfelelő típusra mutatunk-e, és támaszkodhatunk
            // hogy ellenőrizze a memória biztonságát, mert az Any-t minden típushoz megvalósítottuk;semmilyen más implikáció nem létezhet, mivel ellentmondanának az implicitünknek.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Visszaad néhány mutálható hivatkozást a dobozos értékre, ha az `T` típusú, vagy `None` típusú, ha nem.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // BIZTONSÁG: csak ellenőrizzük, hogy a megfelelő típusra mutatunk-e, és támaszkodhatunk
            // hogy ellenőrizze a memória biztonságát, mert az Any-t minden típushoz megvalósítottuk;semmilyen más implikáció nem létezhet, mivel ellentmondanának az implicitünknek.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Tovább az `Any` típuson meghatározott módszerre.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Tovább az `Any` típuson meghatározott módszerre.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Tovább az `Any` típuson meghatározott módszerre.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Tovább az `Any` típuson meghatározott módszerre.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Tovább az `Any` típuson meghatározott módszerre.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Tovább az `Any` típuson meghatározott módszerre.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID és módszerei
///////////////////////////////////////////////////////////////////////////////

/// Az `TypeId` a típus globálisan egyedi azonosítóját jelenti.
///
/// Minden `TypeId` egy átlátszatlan objektum, amely nem teszi lehetővé a belsejében lévő elemek ellenőrzését, de lehetővé teszi az alapvető műveleteket, például a klónozást, az összehasonlítást, a nyomtatást és a bemutatást.
///
///
/// Az `TypeId` jelenleg csak az `'static`-nek tulajdonított típusoknál érhető el, de a future-ben ez a korlátozás megszüntethető.
///
/// Míg az `TypeId` megvalósítja az `Hash`, `PartialOrd` és `Ord` elemeket, érdemes megjegyezni, hogy a hasítások és a sorrend a Rust kiadások között változik.
/// Óvakodjon attól, hogy rájuk támaszkodhat a kódjában!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Visszaadja annak a típusnak az `TypeId` értékét, amellyel ezt az általános függvényt példányosították.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// A típus nevét karakterlánc szeletként adja vissza.
///
/// # Note
///
/// Ezt diagnosztikai használatra szánják.
/// A visszaküldött karakterlánc pontos tartalma és formátuma nincs megadva, csak a típus legjobb leírása.
/// Például az `type_name::<Option<String>>()` által visszaadható karakterláncok között szerepel az `"Option<String>"` és az `"std::option::Option<std::string::String>"`.
///
///
/// A visszaküldött karakterláncot nem szabad egy típus egyedi azonosítójának tekinteni, mivel több típus azonos típusnévhez társulhat.
/// Hasonlóképpen nincs garancia arra, hogy a típus minden része megjelenik a visszatérő karakterláncban: például az élettartam-specifikátorok jelenleg nincsenek benne.
/// Ezenkívül a kimenet változhat a fordító verziói között.
///
/// A jelenlegi megvalósítás ugyanazt az infrastruktúrát használja, mint a fordító diagnosztikája és a hibakeresési információ, de ez nem garantált.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Visszaadja a hegyes érték típusának nevét karakterlánc szeletként.
/// Ez megegyezik az `type_name::<T>()`-szel, de használható, ha a változó típusa nem könnyen elérhető.
///
/// # Note
///
/// Ezt diagnosztikai használatra szánják.A karakterlánc pontos tartalma és formátuma nincs megadva, csak a típus legjobb leírása.
/// Például az `type_name_of_val::<Option<String>>(None)` visszaadhatja az `"Option<String>"` vagy az `"std::option::Option<std::string::String>"` értékeket, de az `"foobar"` nem.
///
/// Ezenkívül a kimenet változhat a fordító verziói között.
///
/// Ez a funkció nem oldja meg a trait objektumokat, vagyis az `type_name_of_val(&7u32 as &dyn Debug)` visszaadhatja az `"dyn Debug"` értéket, de az `"u32"` nem.
///
/// A típusnév nem tekinthető a típus egyedi azonosítójának;
/// több típus is használhatja ugyanazt a típusnevet.
///
/// A jelenlegi megvalósítás ugyanazt az infrastruktúrát használja, mint a fordító diagnosztikája és a hibakeresési információ, de ez nem garantált.
///
/// # Examples
///
/// Kiírja az alapértelmezett egész és úszó típusokat.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}