//! Primitív traits és a típusok alapvető tulajdonságait képviselő típusok.
//!
//! A Rust típusok különféle hasznos módon osztályozhatók belső tulajdonságaik szerint.
//! Ezeket az osztályozásokat traits néven ábrázolják.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// A szálhatárokon át átvihető típusok.
///
/// Ez a trait automatikusan megvalósításra kerül, amikor a fordító megállapítja, hogy megfelelő.
///
/// A nem `Send` típusra példa az [`rc::Rc`][`Rc`] referenciaszámláló mutató.
/// Ha két szál megkísérli ugyanarra a referencia-számlált értékre mutató [Rc]-eket klónozni, akkor megpróbálhatja egyszerre frissíteni a referenciaszámot, ami [undefined behavior][ub], mert az [`Rc`] nem használ atomi műveleteket.
///
/// Unokatestvére, [`sync::Arc`][arc], atomi műveleteket használ (némi rezsivel jár), és így `Send`.
///
/// További részletek: [the Nomicon](../../nomicon/send-and-sync.html).
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// A fordításkor ismert állandó méretű típusok.
///
/// Minden típusú paraméter implicit kötéssel rendelkezik az `Sized`-hez.Az `?Sized` speciális szintaxissal ezt a kötést eltávolíthatjuk, ha ez nem megfelelő.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//hiba: A méret nem lett implementálva az [i32] számára
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Az egyetlen kivétel a trait implicit `Self` típusa.
/// Egy trait nem rendelkezik implicit `Sized` kötéssel, mivel ez nem kompatibilis az [trait object]-ekkel, ahol értelemszerűen a trait-nek minden lehetséges megvalósítóval együtt kell működnie, és így bármilyen méretű lehet.
///
///
/// Bár a Rust lehetővé teszi az `Sized` összekapcsolását egy trait-vel, később nem fogja tudni használni trait-objektum létrehozására:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // legyen y: &dyn Bár= &Impl;//hiba: a trait `Bar` nem készíthető objektummá
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // például a Default esetében, amely megköveteli, hogy az `[T]: !Default` értékelhető legyen
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Típusok, amelyek "unsized" lehetnek dinamikus méretű típusok.
///
/// Például az `[i8; 2]` típusú tömb megvalósítja az `Unsize<[i8]>` és az `Unsize<dyn fmt::Debug>` elemeket.
///
/// Az `Unsize` összes megvalósítását a fordító automatikusan biztosítja.
///
/// `Unsize` a következőkre valósul meg:
///
/// - `[T; N]` az `Unsize<[T]>`
/// - `T` `Unsize<dyn Trait>`, ha `T: Trait`
/// - `Foo<..., T, ...>` az `Unsize<Foo<..., U, ...>>`, ha:
///   - `T: Unsize<U>`
///   - A Foo egy struktúra
///   - Csak az `Foo` utolsó mezőjében van egy típus, amely `T`-et tartalmaz
///   - `T` nem része más mezők típusának
///   - `Bar<T>: Unsize<Bar<U>>`, ha az `Foo` utolsó mezője `Bar<T>` típusú
///
/// `Unsize` az [`ops::CoerceUnsized`]-szel együtt használják, hogy az "user-defined"-tárolók, például az [`Rc`], dinamikus méretű típusokat tartalmazhassanak.
/// További részletekért lásd: [DST coercion RFC][RFC982] és [the nomicon entry on coercion][nomicon-coerce].
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Szükséges trait a minták egyezéséhez használt állandókhoz.
///
/// Bármely típus, amely az `PartialEq`-t származtatja, automatikusan végrehajtja ezt a trait-t, * függetlenül attól, hogy típus-paraméterei megvalósítják-e az `Eq`-et.
///
/// Ha egy `const` elem tartalmaz valamilyen típust, amely nem valósítja meg ezt a trait-t, akkor az a típus vagy (1.) nem valósítja meg az `PartialEq`-et (ami azt jelenti, hogy az állandó nem fogja megadni ezt az összehasonlítási módszert, amely a kódgenerálás feltételezhető elérhető), vagy (2.)-et *a sajátját hajtja végre* az `PartialEq` változata (amely feltételezzük, hogy nem felel meg a strukturális egyenlőség összehasonlításának).
///
///
/// A fenti két forgatókönyv bármelyikében elvetjük egy ilyen állandó használatát a mintaillesztésben.
///
/// Lásd még az [structural match RFC][RFC1445]-et és az [issue 63438]-et, amely az attribútum-alapú tervezéstől a trait felé történő áttérést motiválta.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Szükséges trait a minták egyezéséhez használt állandókhoz.
///
/// Bármely típus, amely az `Eq`-t származtatja, automatikusan végrehajtja ezt a trait-t, * függetlenül attól, hogy típus-paraméterei megvalósítják-e az `Eq`-et.
///
/// Ez egy feltörés a korlátozás megkerülésére a tipikus rendszerünkben.
///
/// # Background
///
/// Meg kívánjuk követelni, hogy a minták egyezésénél használt torzítások típusai az `#[derive(PartialEq, Eq)]` attribútumot kapják.
///
/// Egy ideálisabb világban ellenőrizhetjük ezt a követelményt azzal, hogy csak ellenőrizzük, hogy az adott típus mind az `StructuralPartialEq` trait *, mind pedig* az `Eq` trait hajtja végre.
/// Ugyanakkor rendelkezhet olyan ADT-kkel, amelyek * megcsinálják az `derive(PartialEq, Eq)`-et, és olyan esetet szeretnénk, ha a fordító elfogadná, és a konstans típusa mégsem tudja megvalósítani az `Eq`-et.
///
/// Mégpedig egy ilyen eset:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (A fenti kódban az a probléma, hogy az `Wrap<fn(&())>` nem valósítja meg az `PartialEq`-et és az `Eq`-et sem, mert "for <" a> fn(&'a _)` does not implement those traits.)
///
/// Ezért nem támaszkodhatunk az `StructuralPartialEq` és a puszta `Eq` naiv ellenőrzésére.
///
/// Hackként ennek kiküszöbölésére két külön traits-t használunk, amelyeket mindkét (`#[derive(PartialEq)]` és `#[derive(Eq)]`) derivátum injektál, és ellenőrizzük, hogy mindkettő jelen van-e a szerkezeti egyezés ellenőrzése részeként.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Olyan típusok, amelyek értékeit egyszerűen meg lehet másolni bitek másolásával.
///
/// Alapértelmezés szerint a változó kötések " szemantikával mozognak`.Más szavakkal:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` az `y`-be költözött, ezért nem használható
///
/// // println! ("{: ?}", x);//hiba: az áthelyezett érték használata
/// ```
///
/// Ha azonban egy típus megvalósítja az `Copy`-et, akkor ehelyett " másolási szemantikát` tartalmaz:
///
/// ```
/// // Levezethetünk egy `Copy` megvalósítást.
/// // `Clone` is szükséges, mivel ez az `Copy` szupraszépe.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` az `x` másolata
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Fontos megjegyezni, hogy ebben a két példában az egyetlen különbség az, hogy a hozzárendelés után hozzáférhet-e az `x`-hez.
/// A motorháztető alatt mind a másolás, mind a mozgatás azt eredményezheti, hogy biteket másolnak a memóriába, bár ezt néha optimalizálják.
///
/// ## Hogyan tudom megvalósítani az `Copy`-et?
///
/// Az `Copy` az Ön típusára kétféleképpen valósítható meg.A legegyszerűbb az `derive` használata:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Az `Copy` és `Clone` manuálisan is megvalósítható:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Van egy kis különbség a kettő között: az `derive` stratégia a típusparaméterekhez kötött `Copy`-et is elhelyez, ami nem mindig szükséges.
///
/// ## Mi a különbség az `Copy` és az `Clone` között?
///
/// A másolások implicit módon történnek, például egy `y = x` hozzárendelés részeként.Az `Copy` viselkedése nem túlterhelhető;ez mindig egy egyszerű, bit-bölcs másolat.
///
/// A klónozás kifejezett akció, az `x.clone()`.Az [`Clone`] megvalósítása bármilyen típusú típusspecifikus viselkedést eredményezhet, amely szükséges az értékek biztonságos másolásához.
/// Például az [`Clone`] for [`String`] megvalósításához le kell másolni a hegyes-húros puffert a kupacban.
/// Az [`String`] értékek egyszerű bitenkénti másolása csupán a mutató másolását eredményezné, ami kettős szabaddá válást eredményez a sorban.
/// Emiatt az [`String`] az [`Clone`], de nem az `Copy`.
///
/// [`Clone`] az `Copy` felülete, ezért mindennek, ami `Copy`, az [`Clone`]-et is végre kell hajtania.
/// Ha egy típus `Copy`, akkor az [`Clone`] megvalósításának csak az `*self` értéket kell megadnia (lásd a fenti példát).
///
/// ## Mikor lehet típusom `Copy`?
///
/// Egy típus akkor tudja megvalósítani az `Copy`-et, ha minden összetevője megvalósítja az `Copy`-et.Például ez a struktúra lehet `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// A struktúra lehet `Copy`, és [`i32`] jelentése `Copy`, ezért `Point` alkalmas `Copy`-re.
/// Ezzel szemben fontolja meg
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// A struct `PointList` nem tudja megvalósítani az `Copy`-et, mert az [`Vec<T>`] nem `Copy`.Ha megpróbáljuk levezetni az `Copy` megvalósítását, akkor hibaüzenetet kapunk:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Az (`&T`) megosztott hivatkozások szintén `Copy`, tehát egy típus lehet `Copy`, még akkor is, ha olyan `T` típusú megosztott referenciákat tartalmaz, amelyek *nem*`Copy`.
/// Tekintsük a következő struktúrát, amely megvalósíthatja az `Copy`-et, mert csak felülről *megosztott hivatkozást* tartalmaz a nem "Copy" típusú `PointList`-re:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Mikor *nem* lehet a típusom `Copy`?
///
/// Egyes típusokat nem lehet biztonságosan lemásolni.Például az `&mut T` másolása álnéven változtatható hivatkozást hoz létre.
/// Az [`String`] másolása megkettőzné a ["String"] puffer kezelésének felelősségét, ami kettős ingyenességhez vezetne.
///
/// Utóbbi esetet összefoglalva, bármely, az [`Drop`]-et megvalósító típus nem lehet `Copy`, mert a saját [`size_of::<T>`] bájtjain kívül valamilyen erőforrást kezel.
///
/// Ha megpróbálja megvalósítani az `Copy`-et egy olyan struktúrán vagy enumon, amely nem "Copy" adatokat tartalmaz, akkor az [E0204] hibát kapja.
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Mikor legyen * a típusom `Copy`?
///
/// Általánosságban elmondható, hogy ha az _can_ típusú X100X-et valósítja meg, akkor annak kell.
/// Ne feledje azonban, hogy az `Copy` bevezetése a típusú nyilvános API része.
/// Ha a típus nem lesz "Másolás" a future-ben, akkor körültekintő lehet az `Copy` implementációjának mostani kihagyása, hogy elkerüljék az API megszakítását.
///
/// ## További kivitelezők
///
/// Az [implementors listed below][impls] mellett a következő típusok is megvalósítják az `Copy`-et:
///
/// * Funkció elemtípusok (azaz az egyes funkciókhoz meghatározott külön típusok)
/// * Funkciómutató típusok (pl. `fn() -> i32`)
/// * Tömbtípusok, minden mérethez, ha az elemtípus az `Copy`-et is megvalósítja (pl. `[i32; 123456]`)
/// * Tuple típusok, ha minden alkatrész az `Copy`-et is megvalósítja (pl. `()`, `(i32, bool)`)
/// * Zárástípusok, ha nem vesznek fel értéket a környezetből, vagy ha az összes ilyen rögzített érték maga hajtja végre az `Copy`-et.
///   Ne feledje, hogy a megosztott referenciával rögzített változók mindig az `Copy`-et valósítják meg (még akkor is, ha a referens nem), míg a mutábilis referenciával elfogadott változók soha nem valósítják meg az `Copy`-et.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Ez lehetővé teszi olyan típusok másolását, amelyek az `Copy`-et nem valósítják meg, a nem kielégítő élettartam-korlátok miatt (az `A<'_>` másolása, ha csak `A<'static>: Copy` és `A<'_>: Clone`).
// Ez az attribútum egyelőre csak azért van itt, mert az `Copy`-en elég sok létező specializáció létezik, amelyek már léteznek a standard könyvtárban, és ez a viselkedés jelenleg nem biztonságos.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Származtasson makrót, amely a trait `Copy` implikációját generálja.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Típusok, amelyek esetében biztonságos a hivatkozások megosztása a szálak között.
///
/// Ez a trait automatikusan megvalósításra kerül, amikor a fordító megállapítja, hogy megfelelő.
///
/// A pontos meghatározás: egy `T` típus [`Sync`] akkor és csak akkor, ha `&T` [`Send`].
/// Más szavakkal, ha nincs lehetőség az [undefined behavior][ub]-re (beleértve az adatversenyeket is), amikor az `&T` hivatkozásokat átadják a szálak között.
///
/// Ahogy az várható volt, az olyan primitív típusok, mint az [`u8`] és az [`f64`], mind az [`Sync`], és az ezeket tartalmazó egyszerű összesített típusok is, például a sorok, a struktúrák és az enumok.
/// Az alapvető [`Sync`] típusok további példái közé tartoznak az "immutable" típusok, mint például az `&T`, és az egyszerű öröklődő mutálhatóságúak, például az [`Box<T>`][box], az [`Vec<T>`][vec] és a legtöbb más gyűjteménytípus.
///
/// (Az általános paramétereknek [`Sync`]-nek kell lenniük, hogy a tárolójuk [[Sync]] legyen.)
///
/// A definíció kissé meglepő következménye, hogy `&mut T` `Sync` (ha `T` `Sync`), bár úgy tűnik, hogy ez szinkronizálatlan mutációt eredményezhet.
/// A trükk az, hogy a megosztott hivatkozás (vagyis az `& &mut T`) mögött található mutábilis hivatkozás csak olvashatóvá válik, mintha `& &T` lenne.
/// Ennélfogva nincs adatverseny veszélye.
///
/// Azok a típusok, amelyek nem `Sync`, azok, amelyeknek az "interior mutability" nem szálbiztos formában van, például [`Cell`][cell] és [`RefCell`][refcell].
/// Ezek a típusok lehetővé teszik tartalmuk mutációját még egy megváltoztathatatlan, megosztott hivatkozás révén is.
/// Például az [`Cell<T>`][cell]-en az `set` módszer az `&self`-et veszi fel, ezért csak megosztott [`&Cell<T>`][cell] hivatkozást igényel.
/// A módszer nem hajt végre szinkronizálást, így az [`Cell`][cell] nem lehet `Sync`.
///
/// Egy másik példa a nem `Sync` típusra az [`Rc`][rc] referenciaszámláló mutató.
/// Bármely [`&Rc<T>`][rc] referencia alapján klónozhat egy új [`Rc<T>`][rc]-et, a nem referencia-számok módosításával.
///
/// Azokban az esetekben, amikor szálbiztos belső mutabilitás szükséges, a Rust biztosítja az [atomic data types]-et, valamint az [`sync::Mutex`][mutex] és az [`sync::RwLock`][rwlock]-en keresztüli kifejezett zárolást.
/// Ezek a típusok biztosítják, hogy semmilyen mutáció nem okozhat adatversenyeket, ezért a típusok `Sync`.
/// Hasonlóképpen, az [`sync::Arc`][arc] biztosítja az [`Rc`][rc] menetbiztos analógját.
///
/// Bármilyen belső mutabilitású típusnak az [`cell::UnsafeCell`][unsafecell] burkolatot is használnia kell az value(s) körül, amely közös hivatkozással mutálható.
/// Ennek elmulasztása az [undefined behavior][ub].
/// Például az [`transmute`][transmute]-ing `&T`-ről `&mut T`-re érvénytelen.
///
/// Lásd az [the Nomicon][nomicon-send-and-sync]-et az `Sync`-ről.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): Miután az `rustc_on_unimplemented`-ben a megjegyzések hozzáadásához nyújtott támogatás bejutott a béta verzióba, és kiterjesztették annak ellenőrzésére, hogy van-e bezárás a követelményláncban, bontsa ki azt (#48534)-ként:
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Nulla méretű típus jelölte meg azokat a dolgokat, amelyek az "act like" tulajdonában vannak az `T`-hez.
///
/// Ha hozzáad egy `PhantomData<T>` mezőt a típusához, azt mondja a fordítónak, hogy a típus úgy viselkedik, mintha `T` típusú értéket tárolna, bár valójában nem.
/// Ezeket az információkat bizonyos biztonsági tulajdonságok kiszámításához használják.
///
/// Az `PhantomData<T>` használatának részletesebb magyarázatát az [the Nomicon](../../nomicon/phantom-data.html) oldalon találja.
///
/// # Iszonyatos jegyzet 👻👻👻
///
/// Bár mindkettőjüknek ijesztő neve van, az `PhantomData` és a " fantomtípusok` rokonok, de nem azonosak.A fantom típusú paraméter egyszerűen olyan típusú paraméter, amelyet soha nem használnak.
/// A Rust alkalmazásban ez gyakran a fordító panaszát okozza, és a megoldás az, ha "dummy" felhasználást adunk hozzá az `PhantomData` útján.
///
/// # Examples
///
/// ## Nem használt élettartam-paraméterek
///
/// Talán az `PhantomData` leggyakoribb használati esete egy struktúra, amelynek fel nem használt élettartam-paramétere van, általában valamilyen nem biztonságos kód részeként.
/// Például itt van egy `Slice` struktúra, amely két `*const T` típusú mutatóval rendelkezik, amelyek feltehetően valahol egy tömbbe mutatnak:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// A szándék az, hogy az alapul szolgáló adatok csak az `'a` élettartamra érvényesek, ezért az `Slice` nem élheti túl az `'a`-et.
/// Ezt a szándékot azonban nem fejezi ki a kód, mivel az `'a` élettartamát nem használják, ezért nem világos, hogy milyen adatokra vonatkozik.
/// Ezt úgy tudjuk kijavítani, hogy a fordítónak azt mondjuk, hogy járjon el úgy, mintha az `Slice` struktúra tartalmazna egy `&'a T` hivatkozást:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Ehhez viszont szükség van az `T: 'a` kommentárra, jelezve, hogy az `T` bármely hivatkozása az `'a` élettartama alatt érvényes.
///
/// Az `Slice` inicializálásakor egyszerűen meg kell adnia az `PhantomData` értéket az `phantom` mezőhöz:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Nem használt típusú paraméterek
///
/// Néha előfordul, hogy használatlan típusú paraméterei vannak, amelyek jelzik, hogy az "tied" milyen típusú adathoz tartozik, annak ellenére, hogy az adatok valójában nem találhatók meg magában a struktúrában.
/// Itt van egy példa, ahol ez felmerül az [FFI] esetében.
/// Az idegen interfész `*mut ()` típusú fogantyúkat használ a különböző típusú Rust értékek hivatkozására.
/// A Rust típust egy fantomtípus paraméter segítségével követjük az `ExternalResource` struktúrán, amely egy fogantyút burkol.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Tulajdonjog és a cseppek ellenőrzése
///
/// `PhantomData<T>` típusú mező hozzáadása azt jelzi, hogy az Ön típusának `T` típusú adatai vannak.Ez viszont azt jelenti, hogy a típus elvetésekor egy vagy több `T` típusú példányt eldobhat.
/// Ez kihat a Rust fordító [drop check] elemzésére.
///
/// Ha a struktúrája valójában nem *az*`T` típusú adatok tulajdonosa, akkor jobb, ha referenciatípust használ, például `PhantomData<&'a T>` (ideally) vagy `PhantomData<*const T>` (ha nincs életciklus), hogy ne jelezze a tulajdonjogot.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// A fordító-belső trait az enum diszkriminánsok típusának jelzésére szolgál.
///
/// Ez a trait automatikusan megvalósul minden típusnál, és nem ad garanciát az [`mem::Discriminant`]-hez.
/// **Meghatározatlan viselkedés** az `DiscriminantKind::Discriminant` és az `mem::Discriminant` közötti átváltás.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// A diszkrimináns típusa, amelynek meg kell felelnie az `mem::Discriminant` által előírt trait bounds követelményeknek.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// A fordító-belső trait annak meghatározására szolgál, hogy egy típus tartalmaz-e belső `UnsafeCell`-et, de nem indirekt módon.
///
/// Ez például azt befolyásolja, hogy az ilyen típusú `static`-et csak olvasható statikus memóriába vagy írható statikus memóriába helyezzük-e.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Rögzítés után biztonságosan mozgatható típusok.
///
/// Magának a Rust-nek nincs fogalma az ingatlantípusokról, és a mozgásokat (pl. Hozzárendelés útján vagy [`mem::replace`]) mindig biztonságosnak tartja.
///
/// Ehelyett az [`Pin`][Pin] típust használják, hogy megakadályozzák a típusrendszerben történő mozgást.Az [`Pin<P<T>>`][Pin] burkolóba csomagolt `P<T>` mutató nem mozdítható ki.
/// A rögzítésről további információkat az [`pin` module] dokumentációjában talál.
///
/// Az `Unpin` trait megvalósítása az `T` számára megszünteti a típus lehúzásának korlátozásait, ami lehetővé teszi az `T` mozgatását az [`Pin<P<T>>`][Pin]-ből olyan funkciókkal, mint az [`mem::replace`].
///
///
/// `Unpin` egyáltalán nincs következménye a nem rögzített adatokra.
/// Különösen az [`mem::replace`] boldogan mozgatja az `!Unpin` adatait (bármely `&mut T` esetén működik, nem csak akkor, ha `T: Unpin`).
/// Az [`mem::replace`]-et azonban nem használhatja az [`Pin<P<T>>`][Pin]-be csomagolt adatokra, mert nem tudja megszerezni az ehhez szükséges `&mut T`-t, és *ez* működteti ezt a rendszert.
///
/// Tehát ezt például csak az `Unpin`-t megvalósító típusokon lehet megtenni:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Változtatható hivatkozásra van szükségünk az `mem::replace` hívásához.
/// // Ilyen referenciát úgy szerezhetünk meg, hogy (implicitly) meghívja az `Pin::deref_mut`-et, de ez csak azért lehetséges, mert az `String` megvalósítja az `Unpin`-et.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Ez a trait automatikusan megvalósul szinte minden típushoz.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Olyan jelölőtípus, amely nem valósítja meg az `Unpin`-et.
///
/// Ha egy típus tartalmaz `PhantomPinned`-et, akkor az alapértelmezés szerint nem valósítja meg az `Unpin`-et.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Az `Copy` implementációi primitív típusokhoz.
///
/// Azok a megvalósítások, amelyek nem írhatók le a Rust-ben, az `traits::SelectionContext::copy_clone_conditions()`-ben kerülnek megvalósításra az `rustc_trait_selection`-ben.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// A megosztott hivatkozások másolhatók, de a mutálható hivatkozások *nem*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}