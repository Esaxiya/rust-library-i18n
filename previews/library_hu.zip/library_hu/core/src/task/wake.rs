#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// Az `RawWaker` lehetővé teszi a feladat végrehajtójának, hogy létrehozzon egy [`Waker`]-et, amely testreszabott ébresztési viselkedést biztosít.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Ez egy adatmutatóból és egy [virtual function pointer table (vtable)][vtable]-ből áll, amely testre szabja az `RawWaker` viselkedését.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Adatmutató, amely tetszőleges adatok tárolására használható a végrehajtó igénye szerint.
    /// Ez lehet pl
    /// a feladathoz társított `Arc`-hez egy típus által törölt mutató.
    /// Ennek a mezőnek az értéke átadódik minden olyan függvénynek, amely első paraméterként a vtable része.
    ///
    data: *const (),
    /// Virtuális funkció mutató tábla, amely testreszabja ennek az ébresztőnek a viselkedését.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Új `RawWaker`-t hoz létre a mellékelt `data`-mutatóból és az `vtable`-ből.
    ///
    /// Az `data` mutató tetszőleges adatok tárolására használható a végrehajtó igénye szerint.Ez lehet pl
    /// a feladathoz társított `Arc`-hez egy típus által törölt mutató.
    /// Ennek a mutatónak az értéke átadódik minden olyan funkciónak, amely első paraméterként az `vtable` része.
    ///
    /// Az `vtable` testreszabja az `Waker` viselkedését, amelyet egy `RawWaker`-ből hoznak létre.
    /// Az `Waker` minden egyes műveletéhez az alapul szolgáló `RawWaker` `vtable`-hez tartozó függvény lesz meghívva.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Virtuális függvénymutató tábla (vtable), amely meghatározza az [`RawWaker`] viselkedését.
///
/// A vtable belsejében lévő összes funkcióhoz továbbított mutató az `data` mutató a körülvevő [`RawWaker`] objektumból.
///
/// A struktúrán belüli függvényeket csak egy megfelelően felépített [`RawWaker`] objektum `data` mutatóján kell meghívni az [`RawWaker`] megvalósítás belsejéből.
/// A tartalmazott funkciók bármelyikének meghívása bármely más `data` mutatóval meghatározatlan viselkedést okoz.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Ezt a funkciót akkor hívjuk meg, amikor az [`RawWaker`] klónozódik, például amikor az [`Waker`], amelyben az [`RawWaker`] van tárolva, klónozódik.
    ///
    /// Ennek a függvénynek a megvalósításakor meg kell őriznie az [`RawWaker`] és a hozzá tartozó feladat további példányához szükséges összes erőforrást.
    /// Az `wake` hívása az eredményül kapott [`RawWaker`] eszközön ugyanazon feladat felébresztését eredményezheti, amelyet az eredeti [`RawWaker`] felébresztett volna.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Ezt a funkciót akkor hívjuk meg, amikor az `wake`-et meghívjuk az [`Waker`]-en.
    /// Fel kell ébresztenie az [`RawWaker`]-hez társított feladatot.
    ///
    /// Ennek a függvénynek a megvalósításakor feltétlenül szabadítson fel minden erőforrást, amely az [`RawWaker`] és a kapcsolódó feladat ezen példányához kapcsolódik.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Ezt a funkciót akkor hívjuk meg, amikor az `wake_by_ref`-et meghívjuk az [`Waker`]-en.
    /// Fel kell ébresztenie az [`RawWaker`]-hez társított feladatot.
    ///
    /// Ez a funkció hasonló az `wake`-hez, de nem használhatja fel a megadott adatmutatót.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Ezt a funkciót akkor hívják meg, amikor egy [`RawWaker`] eldől.
    ///
    /// Ennek a függvénynek a megvalósításakor feltétlenül szabadítson fel minden erőforrást, amely az [`RawWaker`] és a kapcsolódó feladat ezen példányához kapcsolódik.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Új `RawWakerVTable`-t hoz létre a mellékelt `clone`, `wake`, `wake_by_ref` és `drop` függvényekből.
    ///
    /// # `clone`
    ///
    /// Ezt a funkciót akkor hívjuk meg, amikor az [`RawWaker`] klónozódik, például amikor az [`Waker`], amelyben az [`RawWaker`] van tárolva, klónozódik.
    ///
    /// Ennek a függvénynek a megvalósításakor meg kell őriznie az [`RawWaker`] és a hozzá tartozó feladat további példányához szükséges összes erőforrást.
    /// Az `wake` hívása az eredményül kapott [`RawWaker`] eszközön ugyanazon feladat felébresztését eredményezheti, amelyet az eredeti [`RawWaker`] felébresztett volna.
    ///
    /// # `wake`
    ///
    /// Ezt a funkciót akkor hívjuk meg, amikor az `wake`-et meghívjuk az [`Waker`]-en.
    /// Fel kell ébresztenie az [`RawWaker`]-hez társított feladatot.
    ///
    /// Ennek a függvénynek a megvalósításakor feltétlenül szabadítson fel minden erőforrást, amely az [`RawWaker`] és a kapcsolódó feladat ezen példányához kapcsolódik.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Ezt a funkciót akkor hívjuk meg, amikor az `wake_by_ref`-et meghívjuk az [`Waker`]-en.
    /// Fel kell ébresztenie az [`RawWaker`]-hez társított feladatot.
    ///
    /// Ez a funkció hasonló az `wake`-hez, de nem használhatja fel a megadott adatmutatót.
    ///
    /// # `drop`
    ///
    /// Ezt a funkciót akkor hívják meg, amikor egy [`RawWaker`] eldől.
    ///
    /// Ennek a függvénynek a megvalósításakor feltétlenül szabadítson fel minden erőforrást, amely az [`RawWaker`] és a kapcsolódó feladat ezen példányához kapcsolódik.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// Az aszinkron feladat `Context`-je.
///
/// Jelenleg az `Context` csak egy `&Waker` hozzáférést biztosít, amely az aktuális feladat felébresztésére használható.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Gondoskodjunk arról, hogy future-nek ellenálljunk a varianciaváltozások ellen, azáltal, hogy az élettartamot invariánsra kényszerítjük (az argumentum-pozíció élettartama ellentmondásos, míg a visszatérő pozíció-élettartama kovariáns).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Hozzon létre egy új `Context`-et egy `&Waker`-ből.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Visszaadja az aktuális feladat `Waker` hivatkozását.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// Az `Waker` egy fogantyú a feladatok felébresztésére azzal, hogy értesíti végrehajtóját arról, hogy készen áll a futtatásra.
///
/// Ez a fogantyú egy [`RawWaker`] példányt foglal magában, amely meghatározza a végrehajtó-specifikus ébresztési viselkedést.
///
///
/// Végrehajtja az [`Clone`], [`Send`] és [`Sync`] elemeket.
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Ébressze fel az `Waker`-hez társított feladatot.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // A tényleges ébresztési hívást egy virtuális függvényhíváson keresztül delegálják a végrehajtó által meghatározott megvalósításhoz.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Ne hívja az `drop`-et-az ébresztőt az `wake` fogja fogyasztani.
        crate::mem::forget(self);

        // BIZTONSÁG: Ez biztonságos, mert az `Waker::from_raw` az egyetlen módja
        // az `wake` és az `data` inicializálása, megkövetelve a felhasználótól, hogy nyugtázza az `RawWaker` szerződésének betartását.
        //
        unsafe { (wake)(data) };
    }

    /// Ébressze fel az `Waker`-hez társított feladatot az `Waker` fogyasztása nélkül.
    ///
    /// Ez hasonlít az `wake`-hez, de kissé kevésbé hatékony lehet abban az esetben, ha a tulajdonában lévő `Waker` elérhető.
    /// Ezt a módszert kell előnyben részesíteni az `waker.clone().wake()` hívása helyett.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // A tényleges ébresztési hívást egy virtuális függvényhíváson keresztül delegálják a végrehajtó által meghatározott megvalósításhoz.
        //

        // BIZTONSÁG: lásd `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Az `true` értéket adja vissza, ha ez az `Waker` és egy másik `Waker` ugyanazt a feladatot hajtotta végre.
    ///
    /// Ez a funkció a legjobb erőfeszítések alapján működik, és hamis eredményt adhat vissza, még akkor is, ha a " Waker` ugyanazon feladatot ébresztené.
    /// Ha azonban ez a függvény visszaadja az `true` értéket, akkor garantált, hogy a `Waker`s ugyanazon feladatot ébreszti fel.
    ///
    /// Ezt a funkciót elsősorban optimalizálási célokra használják.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Új `Waker`-et hoz létre az [`RawWaker`]-ből.
    ///
    /// A visszaküldött `Waker` viselkedése nincs meghatározva, ha a ["RawWaker"] és ["RawWakerVTable"] dokumentációjában meghatározott szerződést nem tartják be.
    ///
    /// Ezért ez a módszer nem biztonságos.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // BIZTONSÁG: Ez biztonságos, mert az `Waker::from_raw` az egyetlen módja
            // az `clone` és az `data` inicializálása, megkövetelve a felhasználótól, hogy nyugtázza az [`RawWaker`] szerződésének betartását.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // BIZTONSÁG: Ez biztonságos, mert az `Waker::from_raw` az egyetlen módja
        // az `drop` és az `data` inicializálása, megkövetelve a felhasználótól, hogy nyugtázza az `RawWaker` szerződésének betartását.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}