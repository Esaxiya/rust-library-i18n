//! Atomtípusok
//!
//! Az atomtípusok primitív megosztott memóriájú kommunikációt biztosítanak a szálak között, és más egyidejű típusok építőkövei.
//!
//! Ez a modul bizonyos számú primitív típus atomi változatát definiálja, beleértve az [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`] stb.
//! Az atomtípusok olyan műveleteket mutatnak be, amelyek megfelelő használat esetén szinkronizálják a frissítéseket a szálak között.
//!
//! Minden módszer egy [`Ordering`]-et vesz fel, amely az adott művelet memóriagátjának erősségét képviseli.Ezek a megrendelések megegyeznek az [C++20 atomic orderings][1]-kel.További információ: [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Az atomváltozókat biztonságosan meg lehet osztani a szálak között (ők implementálják az [`Sync`]-et), de maguk nem biztosítják a megosztási mechanizmust, és követik a Rust [threading model](../../../std/thread/index.html#the-threading-model)-jét.
//!
//! Az atomi változó megosztásának leggyakoribb módja, ha [`Arc`][arc]-be (atomi referenciával számolt megosztott mutatóba) helyezzük.
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Az atomtípusok statikus változókban tárolhatók, inicializálhatók az állandó inicializálók, például az [`AtomicBool::new`] segítségével.Az atom statikát gyakran használják a lusta globális inicializáláshoz.
//!
//! # Portability
//!
//! Ebben a modulban minden atomtípus garantáltan [lock-free] lesz, ha rendelkezésre állnak.Ez azt jelenti, hogy belsőleg nem szereznek be globális mutexet.Az atomtípusok és műveletek nem garantáltan várakozásmentesek.
//! Ez azt jelenti, hogy az `fetch_or`-hez hasonló műveletek megvalósíthatók összehasonlító és cserélhető hurokkal.
//!
//! Az atomműveletek nagyobb méretű atomokkal végezhetők el az utasításrétegen.Néhány platform például 4 bájtos atom utasításokat használ az `AtomicI8` megvalósításához.
//! Ne feledje, hogy ennek az emulációnak nem szabad befolyásolnia a kód helyességét, csak tisztában kell lennie vele.
//!
//! Előfordulhat, hogy a modul atomtípusai nem minden platformon érhetők el.Az itt található atomtípusok azonban mind széles körben hozzáférhetők, és általában a meglévőekre lehet támaszkodni.Néhány figyelemre méltó kivétel:
//!
//! * PowerPC és a 32 bites mutatókkal rendelkező MIPS platformokon nincs `AtomicU64` vagy `AtomicI64` típus.
//! * ARM az `armv5te`-hez hasonló platformok, amelyek nem az Linux-hez használhatók, csak az `load` és `store` műveleteket biztosítják, és nem támogatják az (CAS) összehasonlítását és cseréjét, például az `swap`, `fetch_add` stb.
//! Ezenkívül az Linux-en ezeket a CAS-műveleteket az [operating system support]-en keresztül hajtják végre, ami teljesítménybüntetéssel járhat.
//! * ARM az `thumbv6m`-tel rendelkező célpontok csak `load` és `store` műveleteket biztosítanak, és nem támogatják az (CAS) összehasonlítás és cserélése műveleteket, például az `swap`, `fetch_add` stb.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Ne feledje, hogy hozzáadhatók olyan future platformok, amelyek szintén nem támogatnak bizonyos atomi műveleteket.A maximálisan hordozható kódnak ügyelnie kell arra, hogy mely atomtípusokat használják.
//! `AtomicUsize` és az `AtomicIsize` általában a leghordozhatóbb, de még akkor sem érhetők el mindenhol.
//! Referenciaként az `std` könyvtár mutató méretű atomokat igényel, bár az `core` nem.
//!
//! Jelenleg elsősorban az `#[cfg(target_arch)]` használatára lesz szükség ahhoz, hogy feltételesen fordítson kódot az atomokkal.Van egy instabil `#[cfg(target_has_atomic)]` is, amely stabilizálódhat a future-ben.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Egy egyszerű spinlock:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Várja meg, amíg a másik szál kioldja a zárat
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Tartsa az élő szálak globális számát:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Logikai típus, amelyet biztonságosan meg lehet osztani a szálak között.
///
/// Ez a típus ugyanolyan a memóriában, mint egy [`bool`].
///
/// **Megjegyzés**: Ez a típus csak azokon a platformokon érhető el, amelyek támogatják az `u8` atomterhelését és tárolását.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Létrehoz egy `AtomicBool`-re inicializált `AtomicBool`-et.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// A küldés implicit módon megvalósult az AtomicBool számára.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Nyers mutatótípus, amelyet biztonságosan meg lehet osztani a szálak között.
///
/// Ez a típus ugyanolyan a memóriában, mint az `*mut T`.
///
/// **Megjegyzés**: Ez a típus csak olyan platformokon érhető el, amelyek támogatják az atomterhelést és a mutatók tárolását.
/// Mérete a célmutató méretétől függ.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Létrehoz egy null `AtomicPtr<T>` értéket.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Atommemória-sorrendek
///
/// A memória sorrendje meghatározza az atomi műveletek szinkronizálásának módját.
/// A leggyengébb [`Ordering::Relaxed`]-ben csak a memória által közvetlenül érintett művelet szinkronizálódik.
/// Másrészt az [`Ordering::SeqCst`] műveletek tároló-betöltési párja szinkronizálja a többi memóriát, miközben megőrzi az ilyen műveletek teljes sorrendjét az összes szálon.
///
///
/// A Rust memóriarendezése [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// További információ: [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Nincs megrendelési kényszer, csak atomi műveletek.
    ///
    /// Az [`memory_order_relaxed`]-nek felel meg C++ 20-ban.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Ha egy tárral van összekapcsolva, akkor az összes korábbi művelet az [`Acquire`] (vagy erősebb) megrendeléssel végrehajtott ilyen értékű terhelés előtt rendbe kerül.
    ///
    /// Különösen az összes korábbi írás láthatóvá válik minden szál számára, amely [`Acquire`] (vagy erősebb) terhelést hajt végre ennek az értéknek.
    ///
    /// Figyelje meg, hogy a rendelés használata egy olyan művelethez, amely kombinálja a terheléseket és a tárolásokat, [`Relaxed`] betöltési művelethez vezet!
    ///
    /// Ez a rendelés csak azokra a műveletekre vonatkozik, amelyek képesek tárolni.
    ///
    /// Az [`memory_order_release`]-nek felel meg C++ 20-ban.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Terheléssel párosítva, ha a betöltött értéket [`Release`] (vagy erősebb) rendeléssel rendelkező tárolási művelettel írták le, akkor minden további művelet az adott tárolás után lesz rendelhető.
    /// Különösen az összes későbbi betöltésnél látni fogja az adatokat a bolt előtt.
    ///
    /// Figyelje meg, hogy a rendelés használata egy olyan művelethez, amely kombinálja a terheléseket és a tárolásokat, [`Relaxed`] tároló művelethez vezet!
    ///
    /// Ez a megrendelés csak azokra a műveletekre vonatkozik, amelyek képesek betölteni a terhelést.
    ///
    /// [`memory_order_acquire`]-nek felel meg C++ 20-ban.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Az [`Acquire`] és az [`Release`] hatásai együttesen vannak:
    /// Terhelésekhez [`Acquire`] rendelést használ.Az üzleteknél az [`Release`] rendelést használja.
    ///
    /// Figyelje meg, hogy az `compare_and_swap` esetében előfordulhat, hogy a művelet végül nem hajt végre egyetlen tárolást sem, ezért csak az [`Acquire`] megrendelését hajtja végre.
    ///
    /// Az `AcqRel` azonban soha nem hajtja végre az [`Relaxed`] hozzáféréseket.
    ///
    /// Ez a megrendelés csak azokra a műveletekre vonatkozik, amelyek kombinálják a rakományokat és a tárolókat.
    ///
    /// Az [`memory_order_acq_rel`]-nek felel meg C++ 20-ban.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Mint az [`Acquire`]/[`Release`]/az ``AcqRel`](betöltés, tárolás és raktárral történő betöltés esetén), azzal a további garanciával, hogy az összes szál az összes, egymást követő műveletet azonos sorrendben látja .
    ///
    ///
    /// Az [`memory_order_seq_cst`]-nek felel meg C++ 20-ban.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// `false`-re inicializált [`AtomicBool`].
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Létrehoz egy új `AtomicBool`-et.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Változtatható hivatkozást ad vissza az alapul szolgáló [`bool`]-re.
    ///
    /// Ez azért biztonságos, mert a megváltoztatható referencia garantálja, hogy más szálak ne férjenek hozzá egyidejűleg az atomadatokhoz.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // BIZTONSÁG: a változtatható referencia egyedülálló tulajdonjogot garantál.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Atom hozzáférés az `&mut bool`-hez.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // BIZTONSÁG: a változtatható referencia garantálja az egyedi tulajdonjogot, és
        // az `bool` és az `Self` összehangolása egyaránt 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Fogyasztja az atomot, és visszaadja a benne foglalt értéket.
    ///
    /// Ez azért biztonságos, mert az `self` érték általi átadása garantálja, hogy más szálak ne érjék el egyidejűleg az atomadatokat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Értéket tölt be a bool-ból.
    ///
    /// `load` vesz egy [`Ordering`] argumentumot, amely leírja a művelet memória sorrendjét.
    /// A lehetséges értékek: [`SeqCst`], [`Acquire`] és [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, ha `order` [`Release`] vagy [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // BIZTONSÁG: minden adatsorozatot megakadályoz az atomi intrinsic és a raw
        // a bevitt mutató érvényes, mert referenciából kaptuk.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Értéket tárol a bool-be.
    ///
    /// `store` vesz egy [`Ordering`] argumentumot, amely leírja a művelet memória sorrendjét.
    /// A lehetséges értékek: [`SeqCst`], [`Release`] és [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, ha `order` [`Acquire`] vagy [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // BIZTONSÁG: minden adatsorozatot megakadályoz az atomi intrinsic és a raw
        // a bevitt mutató érvényes, mert referenciából kaptuk.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Értéket tárol a bool-be, visszaadva az előző értéket.
    ///
    /// `swap` vesz egy [`Ordering`] argumentumot, amely leírja a művelet memória sorrendjét.Minden rendelési mód lehetséges.
    /// Ne feledje, hogy az [`Acquire`] használatával ennek a műveletnek az üzlet része az [`Relaxed`], az [`Release`] használatával pedig a betöltési rész [`Relaxed`].
    ///
    ///
    /// **Note:** Ez a módszer csak azokon a platformokon érhető el, amelyek támogatják az atomi műveleteket az `u8` rendszeren.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // BIZTONSÁG: az atomversenyek megakadályozzák az adatversenyeket.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Értéket tárol az [`bool`]-ben, ha az aktuális érték megegyezik az `current` értékével.
    ///
    /// A visszatérési érték mindig az előző érték.Ha megegyezik az `current` értékkel, akkor az érték frissült.
    ///
    /// `compare_and_swap` vesz egy [`Ordering`] argumentumot is, amely leírja ennek a műveletnek a memóriájában történő sorrendjét.
    /// Figyelje meg, hogy a művelet még az [`AcqRel`] használata esetén is meghiúsulhat, ezért csak végrehajt egy `Acquire` terhelést, de nem rendelkezik `Release` szemantikával.
    /// Az [`Acquire`] használatával ennek a műveletnek az üzlet része az [`Relaxed`], ha ez megtörténik, az [`Release`] használatával pedig a terhelés része az [`Relaxed`].
    ///
    /// **Note:** Ez a módszer csak azokon a platformokon érhető el, amelyek támogatják az atomi műveleteket az `u8` rendszeren.
    ///
    /// # Áttérés `compare_exchange` és `compare_exchange_weak` rendszerekre
    ///
    /// `compare_and_swap` egyenértékű az `compare_exchange`-szel, a következő leképezéssel a memória rendezéséhez:
    ///
    /// Eredeti |Siker |Kudarc
    /// -------- | ------- | -------
    /// Nyugodt |Nyugodt |Nyugodt Acquire |Megszerzése |Kiadás megszerzése |Engedje elNyugodt AcqRel |AcqRel |A SeqCst megszerzéseSeqCst |SeqCst
    ///
    /// `compare_exchange_weak` akkor is megengedett, hogy hibásan bukjon meg akkor is, ha az összehasonlítás sikeres, ami lehetővé teszi a fordító számára, hogy jobb összeállítási kódot generáljon, amikor az összehasonlítást és a cserét egy hurokban használják.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Értéket tárol az [`bool`]-ben, ha az aktuális érték megegyezik az `current` értékével.
    ///
    /// A visszatérési érték olyan eredmény, amely jelzi, hogy az új értéket írták-e, és tartalmazza-e az előző értéket.
    /// Siker esetén ez az érték garantáltan megegyezik az `current` értékkel.
    ///
    /// `compare_exchange` két [`Ordering`] argumentumra van szükség a művelet memóriasorrendjének leírására.
    /// `success` leírja a szükséges sorrendet az olvasás-módosítás-írás művelethez, amely akkor megy végbe, ha az `current`-szel való összehasonlítás sikeres.
    /// `failure` leírja az összehasonlítás sikertelensége esetén bekövetkező terhelési művelethez szükséges sorrendet.
    /// Ha az [`Acquire`]-t sikeres megrendelésként használja, akkor az áruház része lesz az [`Relaxed`] műveletnek, az [`Release`] használata pedig az [`Relaxed`] sikeres betöltését jelenti.
    ///
    /// A hibarendelés csak [`SeqCst`], [`Acquire`] vagy [`Relaxed`] lehet, és egyenértékűnek vagy gyengébbnek kell lennie, mint a sikeres megrendelés.
    ///
    /// **Note:** Ez a módszer csak azokon a platformokon érhető el, amelyek támogatják az atomi műveleteket az `u8` rendszeren.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // BIZTONSÁG: az atomversenyek megakadályozzák az adatversenyeket.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Értéket tárol az [`bool`]-ben, ha az aktuális érték megegyezik az `current` értékével.
    ///
    /// Az [`AtomicBool::compare_exchange`]-től eltérően ez a funkció akkor is meghiúsulhat, ha az összehasonlítás sikeres lesz, ami hatékonyabb kódot eredményezhet egyes platformokon.
    ///
    /// A visszatérési érték olyan eredmény, amely jelzi, hogy az új értéket írták-e, és tartalmazza-e az előző értéket.
    ///
    /// `compare_exchange_weak` két [`Ordering`] argumentumra van szükség a művelet memóriasorrendjének leírására.
    /// `success` leírja a szükséges sorrendet az olvasás-módosítás-írás művelethez, amely akkor megy végbe, ha az `current`-szel való összehasonlítás sikeres.
    /// `failure` leírja az összehasonlítás sikertelensége esetén bekövetkező terhelési művelethez szükséges sorrendet.
    /// Ha az [`Acquire`]-t sikeres megrendelésként használja, akkor az áruház része lesz az [`Relaxed`] műveletnek, az [`Release`] használata pedig az [`Relaxed`] sikeres betöltését jelenti.
    /// A hibarendelés csak [`SeqCst`], [`Acquire`] vagy [`Relaxed`] lehet, és egyenértékűnek vagy gyengébbnek kell lennie, mint a sikeres megrendelés.
    ///
    /// **Note:** Ez a módszer csak azokon a platformokon érhető el, amelyek támogatják az atomi műveleteket az `u8` rendszeren.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // BIZTONSÁG: az atomversenyek megakadályozzák az adatversenyeket.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Logikai "and" logikai értékkel.
    ///
    /// Logikai "and" műveletet hajt végre az aktuális értéken és az `val` argumentumon, és az eredményre állítja az új értéket.
    ///
    /// Visszaadja az előző értéket.
    ///
    /// `fetch_and` vesz egy [`Ordering`] argumentumot, amely leírja a művelet memória sorrendjét.Minden rendelési mód lehetséges.
    /// Ne feledje, hogy az [`Acquire`] használatával ennek a műveletnek az üzlet része az [`Relaxed`], az [`Release`] használatával pedig a betöltési rész [`Relaxed`].
    ///
    ///
    /// **Note:** Ez a módszer csak azokon a platformokon érhető el, amelyek támogatják az atomi műveleteket az `u8` rendszeren.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // BIZTONSÁG: az atomversenyek megakadályozzák az adatversenyeket.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Logikai "nand" logikai értékkel.
    ///
    /// Logikai "nand" műveletet hajt végre az aktuális értéken és az `val` argumentumon, és az eredményre állítja az új értéket.
    ///
    /// Visszaadja az előző értéket.
    ///
    /// `fetch_nand` vesz egy [`Ordering`] argumentumot, amely leírja a művelet memória sorrendjét.Minden rendelési mód lehetséges.
    /// Ne feledje, hogy az [`Acquire`] használatával ennek a műveletnek az üzlet része az [`Relaxed`], az [`Release`] használatával pedig a betöltési rész [`Relaxed`].
    ///
    ///
    /// **Note:** Ez a módszer csak azokon a platformokon érhető el, amelyek támogatják az atomi műveleteket az `u8` rendszeren.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Az atomic_nand itt nem használható, mert érvénytelen értékű bool-t eredményezhet.
        // Ez azért történik, mert az atomi műveletet belsőleg egy 8 bites egész számmal végzik, amely a felső 7 bitet állítja be.
        //
        // Tehát csak a fetch_xor vagy a swap parancsot használjuk.
        if val {
            // ! (x&true)== !x Meg kell fordítanunk a bool-t.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true A bool értéket igazra kell állítanunk.
            //
            self.swap(true, order)
        }
    }

    /// Logikai "or" logikai értékkel.
    ///
    /// Logikai "or" műveletet hajt végre az aktuális értéken és az `val` argumentumon, és az eredményre állítja az új értéket.
    ///
    /// Visszaadja az előző értéket.
    ///
    /// `fetch_or` vesz egy [`Ordering`] argumentumot, amely leírja a művelet memória sorrendjét.Minden rendelési mód lehetséges.
    /// Ne feledje, hogy az [`Acquire`] használatával ennek a műveletnek az üzlet része az [`Relaxed`], az [`Release`] használatával pedig a betöltési rész [`Relaxed`].
    ///
    ///
    /// **Note:** Ez a módszer csak azokon a platformokon érhető el, amelyek támogatják az atomi műveleteket az `u8` rendszeren.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // BIZTONSÁG: az atomversenyek megakadályozzák az adatversenyeket.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Logikai "xor" logikai értékkel.
    ///
    /// Logikai "xor" műveletet hajt végre az aktuális értéken és az `val` argumentumon, és az eredményre állítja az új értéket.
    ///
    /// Visszaadja az előző értéket.
    ///
    /// `fetch_xor` vesz egy [`Ordering`] argumentumot, amely leírja a művelet memória sorrendjét.Minden rendelési mód lehetséges.
    /// Ne feledje, hogy az [`Acquire`] használatával ennek a műveletnek az üzlet része az [`Relaxed`], az [`Release`] használatával pedig a betöltési rész [`Relaxed`].
    ///
    ///
    /// **Note:** Ez a módszer csak azokon a platformokon érhető el, amelyek támogatják az atomi műveleteket az `u8` rendszeren.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // BIZTONSÁG: az atomversenyek megakadályozzák az adatversenyeket.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Változtatható mutatót ad vissza az alapul szolgáló [`bool`]-re.
    ///
    /// Nem atom típusú olvasás és írás az eredményül kapott egész számra lehet adatverseny.
    /// Ez a módszer leginkább az FFI esetében hasznos, ahol a függvényaláírás `*mut bool`-et használhat az `&AtomicBool` helyett.
    ///
    /// Az `*mut` mutató visszaadása egy közös hivatkozás alapján erre az atomra biztonságos, mert az atomtípusok belső mutabilitással működnek.
    /// Az atom minden módosítása megváltoztatja az értéket egy közös referencia segítségével, és biztonságosan megteheti mindaddig, amíg atomi műveleteket alkalmaz.
    /// A visszaküldött nyers mutató használatához `unsafe`-blokk szükséges, és továbbra is be kell tartania ugyanazt a korlátozást: a rajta végrehajtott műveleteknek atomnak kell lenniük.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Behozza az értéket, és alkalmaz egy függvényt, amely választható új értéket ad vissza.Visszaadja az `Ok(previous_value)` `Result` értékét, ha a függvény visszaadja az `Some(_)` értéket, máskülönben az `Err(previous_value)` értéket.
    ///
    /// Note: Ez többször meghívhatja a függvényt, ha az érték időközben megváltozott más szálaktól, mindaddig, amíg a függvény visszaadja az `Some(_)` értéket, de a függvényt csak egyszer alkalmazzák a tárolt értékre.
    ///
    ///
    /// `fetch_update` két [`Ordering`] argumentumra van szükség a művelet memóriasorrendjének leírására.
    /// Az első a szükséges sorrendet írja le, amikor a művelet végül sikeres lesz, míg a második a terhelések előírt sorrendjét.
    /// Ezek megfelelnek az [`AtomicBool::compare_exchange`] siker-és sikertelenségi sorrendjének.
    ///
    /// Ha az [`Acquire`]-t sikeres megrendelésként használja, akkor az áruház része lesz az [`Relaxed`] műveletnek, az [`Release`] használatával pedig az utolsó sikeres betöltés az [`Relaxed`].
    /// Az (failed) terhelésrendelés csak [`SeqCst`], [`Acquire`] vagy [`Relaxed`] lehet, és egyenértékűnek vagy gyengébbnek kell lennie, mint a sikeres megrendelés.
    ///
    /// **Note:** Ez a módszer csak azokon a platformokon érhető el, amelyek támogatják az atomi műveleteket az `u8` rendszeren.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Létrehoz egy új `AtomicPtr`-et.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Változtatható hivatkozást ad vissza az alapul szolgáló mutatóra.
    ///
    /// Ez azért biztonságos, mert a megváltoztatható referencia garantálja, hogy más szálak ne férjenek hozzá egyidejűleg az atomadatokhoz.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Atomi hozzáférés a mutatóhoz.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - a változtatható referencia garantálja az egyedi tulajdonjogot.
        //  - az `*mut T` és az `Self` összehangolása megegyezik a rust által támogatott összes platformon, a fentiek szerint.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Fogyasztja az atomot, és visszaadja a benne foglalt értéket.
    ///
    /// Ez azért biztonságos, mert az `self` érték általi átadása garantálja, hogy más szálak ne érjék el egyidejűleg az atomadatokat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Értéket tölt be a mutatóból.
    ///
    /// `load` vesz egy [`Ordering`] argumentumot, amely leírja a művelet memória sorrendjét.
    /// A lehetséges értékek: [`SeqCst`], [`Acquire`] és [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, ha `order` [`Release`] vagy [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // BIZTONSÁG: az atomversenyek megakadályozzák az adatversenyeket.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Értéket tárol a mutatóban.
    ///
    /// `store` vesz egy [`Ordering`] argumentumot, amely leírja a művelet memória sorrendjét.
    /// A lehetséges értékek: [`SeqCst`], [`Release`] és [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, ha `order` [`Acquire`] vagy [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // BIZTONSÁG: az atomversenyek megakadályozzák az adatversenyeket.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Értéket tárol a mutatóban, visszaadva az előző értéket.
    ///
    /// `swap` vesz egy [`Ordering`] argumentumot, amely leírja a művelet memória sorrendjét.Minden rendelési mód lehetséges.
    /// Ne feledje, hogy az [`Acquire`] használatával ennek a műveletnek az üzlet része az [`Relaxed`], az [`Release`] használatával pedig a betöltési rész [`Relaxed`].
    ///
    ///
    /// **Note:** Ez a módszer csak azokon a platformokon érhető el, amelyek támogatják a mutatókon végzett atomi műveleteket.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // BIZTONSÁG: az atomversenyek megakadályozzák az adatversenyeket.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Értéket tárol a mutatóban, ha az aktuális érték megegyezik az `current` értékével.
    ///
    /// A visszatérési érték mindig az előző érték.Ha megegyezik az `current` értékkel, akkor az érték frissült.
    ///
    /// `compare_and_swap` vesz egy [`Ordering`] argumentumot is, amely leírja ennek a műveletnek a memóriájában történő sorrendjét.
    /// Figyelje meg, hogy a művelet még az [`AcqRel`] használata esetén is meghiúsulhat, ezért csak végrehajt egy `Acquire` terhelést, de nem rendelkezik `Release` szemantikával.
    /// Az [`Acquire`] használatával ennek a műveletnek az üzlet része az [`Relaxed`], ha ez megtörténik, az [`Release`] használatával pedig a terhelés része az [`Relaxed`].
    ///
    /// **Note:** Ez a módszer csak azokon a platformokon érhető el, amelyek támogatják a mutatókon végzett atomi műveleteket.
    ///
    /// # Áttérés `compare_exchange` és `compare_exchange_weak` rendszerekre
    ///
    /// `compare_and_swap` egyenértékű az `compare_exchange`-szel, a következő leképezéssel a memória rendezéséhez:
    ///
    /// Eredeti |Siker |Kudarc
    /// -------- | ------- | -------
    /// Nyugodt |Nyugodt |Nyugodt Acquire |Megszerzése |Kiadás megszerzése |Engedje elNyugodt AcqRel |AcqRel |A SeqCst megszerzéseSeqCst |SeqCst
    ///
    /// `compare_exchange_weak` akkor is megengedett, hogy hibásan bukjon meg akkor is, ha az összehasonlítás sikeres, ami lehetővé teszi a fordító számára, hogy jobb összeállítási kódot generáljon, amikor az összehasonlítást és a cserét egy hurokban használják.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Értéket tárol a mutatóban, ha az aktuális érték megegyezik az `current` értékével.
    ///
    /// A visszatérési érték olyan eredmény, amely jelzi, hogy az új értéket írták-e, és tartalmazza-e az előző értéket.
    /// Siker esetén ez az érték garantáltan megegyezik az `current` értékkel.
    ///
    /// `compare_exchange` két [`Ordering`] argumentumra van szükség a művelet memóriasorrendjének leírására.
    /// `success` leírja a szükséges sorrendet az olvasás-módosítás-írás művelethez, amely akkor megy végbe, ha az `current`-szel való összehasonlítás sikeres.
    /// `failure` leírja az összehasonlítás sikertelensége esetén bekövetkező terhelési művelethez szükséges sorrendet.
    /// Ha az [`Acquire`]-t sikeres megrendelésként használja, akkor az áruház része lesz az [`Relaxed`] műveletnek, az [`Release`] használata pedig az [`Relaxed`] sikeres betöltését jelenti.
    ///
    /// A hibarendelés csak [`SeqCst`], [`Acquire`] vagy [`Relaxed`] lehet, és egyenértékűnek vagy gyengébbnek kell lennie, mint a sikeres megrendelés.
    ///
    /// **Note:** Ez a módszer csak azokon a platformokon érhető el, amelyek támogatják a mutatókon végzett atomi műveleteket.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // BIZTONSÁG: az atomversenyek megakadályozzák az adatversenyeket.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Értéket tárol a mutatóban, ha az aktuális érték megegyezik az `current` értékével.
    ///
    /// Az [`AtomicPtr::compare_exchange`]-től eltérően ez a funkció akkor is meghiúsulhat, ha az összehasonlítás sikeres lesz, ami hatékonyabb kódot eredményezhet egyes platformokon.
    ///
    /// A visszatérési érték olyan eredmény, amely jelzi, hogy az új értéket írták-e, és tartalmazza-e az előző értéket.
    ///
    /// `compare_exchange_weak` két [`Ordering`] argumentumra van szükség a művelet memóriasorrendjének leírására.
    /// `success` leírja a szükséges sorrendet az olvasás-módosítás-írás művelethez, amely akkor megy végbe, ha az `current`-szel való összehasonlítás sikeres.
    /// `failure` leírja az összehasonlítás sikertelensége esetén bekövetkező terhelési művelethez szükséges sorrendet.
    /// Ha az [`Acquire`]-t sikeres megrendelésként használja, akkor az áruház része lesz az [`Relaxed`] műveletnek, az [`Release`] használata pedig az [`Relaxed`] sikeres betöltését jelenti.
    /// A hibarendelés csak [`SeqCst`], [`Acquire`] vagy [`Relaxed`] lehet, és egyenértékűnek vagy gyengébbnek kell lennie, mint a sikeres megrendelés.
    ///
    /// **Note:** Ez a módszer csak azokon a platformokon érhető el, amelyek támogatják a mutatókon végzett atomi műveleteket.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // BIZTONSÁG: Ez a lényege nem biztonságos, mert egy nyers mutatón működik
        // de pontosan tudjuk, hogy a mutató érvényes (most egy `UnsafeCell`-ről kaptuk, amely referenciaként van), és maga az atomi művelet lehetővé teszi számunkra, hogy biztonságosan mutáljuk az `UnsafeCell` tartalmát.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Behozza az értéket, és alkalmaz egy függvényt, amely választható új értéket ad vissza.Visszaadja az `Ok(previous_value)` `Result` értékét, ha a függvény visszaadja az `Some(_)` értéket, máskülönben az `Err(previous_value)` értéket.
    ///
    /// Note: Ez többször meghívhatja a függvényt, ha az érték időközben megváltozott más szálaktól, mindaddig, amíg a függvény visszaadja az `Some(_)` értéket, de a függvényt csak egyszer alkalmazzák a tárolt értékre.
    ///
    ///
    /// `fetch_update` két [`Ordering`] argumentumra van szükség a művelet memóriasorrendjének leírására.
    /// Az első a szükséges sorrendet írja le, amikor a művelet végül sikeres lesz, míg a második a terhelések előírt sorrendjét.
    /// Ezek megfelelnek az [`AtomicPtr::compare_exchange`] siker-és sikertelenségi sorrendjének.
    ///
    /// Ha az [`Acquire`]-t sikeres megrendelésként használja, akkor az áruház része lesz az [`Relaxed`] műveletnek, az [`Release`] használatával pedig az utolsó sikeres betöltés az [`Relaxed`].
    /// Az (failed) terhelésrendelés csak [`SeqCst`], [`Acquire`] vagy [`Relaxed`] lehet, és egyenértékűnek vagy gyengébbnek kell lennie, mint a sikeres megrendelés.
    ///
    /// **Note:** Ez a módszer csak azokon a platformokon érhető el, amelyek támogatják a mutatókon végzett atomi műveleteket.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Az `bool`-et `AtomicBool`-vé alakítja.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Ez a makró végül fel nem használt néhány architektúrán.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Egész számtípus, amelyet biztonságosan meg lehet osztani a szálak között.
        ///
        /// Ennek a típusnak ugyanaz a memóriában való ábrázolása, mint az alapul szolgáló egész típusú típusnak, ["
        ///
        #[doc = $s_int_type]
        /// `].
        /// Ha többet szeretne megtudni az atomi és a nem atomos típusok közötti különbségekről, valamint az ilyen típusú hordozhatóságról, olvassa el az [module-level documentation] készüléket.
        ///
        ///
        /// **Note:** Ez a típus csak azokon a platformokon érhető el, amelyek támogatják az atomterhelést és a [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// `0`-re inicializált atomi egész szám.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // A küldés implicit módon valósul meg.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Új atom egész számot hoz létre.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Változtatható hivatkozást ad vissza az alapul szolgáló egész számra.
            ///
            /// Ez azért biztonságos, mert a megváltoztatható referencia garantálja, hogy más szálak ne férjenek hozzá egyidejűleg az atomadatokhoz.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// legyen mut némi_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (néhány_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - a változtatható referencia garantálja az egyedi tulajdonjogot.
                //  - az `$int_type` és az `Self` illesztése megegyezik, ahogy azt az $cfg_align ígérte és a fentiekben igazolták.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Fogyasztja az atomot, és visszaadja a benne foglalt értéket.
            ///
            /// Ez azért biztonságos, mert az `self` érték általi átadása garantálja, hogy más szálak ne érjék el egyidejűleg az atomadatokat.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Értéket tölt be az atom egész számából.
            ///
            /// `load` vesz egy [`Ordering`] argumentumot, amely leírja a művelet memória sorrendjét.
            /// A lehetséges értékek: [`SeqCst`], [`Acquire`] és [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics, ha `order` [`Release`] vagy [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // BIZTONSÁG: az atomversenyek megakadályozzák az adatversenyeket.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Értéket tárol az atom egész számába.
            ///
            /// `store` vesz egy [`Ordering`] argumentumot, amely leírja a művelet memória sorrendjét.
            ///  A lehetséges értékek: [`SeqCst`], [`Release`] és [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics, ha `order` [`Acquire`] vagy [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // BIZTONSÁG: az atomversenyek megakadályozzák az adatversenyeket.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Egy értéket az atom egész számába tárol, visszaadva az előző értéket.
            ///
            /// `swap` vesz egy [`Ordering`] argumentumot, amely leírja a művelet memória sorrendjét.Minden rendelési mód lehetséges.
            /// Ne feledje, hogy az [`Acquire`] használatával ennek a műveletnek az üzlet része az [`Relaxed`], az [`Release`] használatával pedig a betöltési rész [`Relaxed`].
            ///
            ///
            /// **Megjegyzés**: Ez a módszer csak azokon a platformokon érhető el, amelyek támogatják az atomi műveleteket
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // BIZTONSÁG: az atomversenyek megakadályozzák az adatversenyeket.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Ha az aktuális érték megegyezik az `current` értékkel, akkor az atomi egész számba tárol egy értéket.
            ///
            /// A visszatérési érték mindig az előző érték.Ha megegyezik az `current` értékkel, akkor az érték frissült.
            ///
            /// `compare_and_swap` vesz egy [`Ordering`] argumentumot is, amely leírja ennek a műveletnek a memóriájában történő sorrendjét.
            /// Figyelje meg, hogy a művelet még az [`AcqRel`] használata esetén is meghiúsulhat, ezért csak végrehajt egy `Acquire` terhelést, de nem rendelkezik `Release` szemantikával.
            ///
            /// Az [`Acquire`] használatával ennek a műveletnek az üzlet része az [`Relaxed`], ha ez megtörténik, az [`Release`] használatával pedig a terhelés része az [`Relaxed`].
            ///
            /// **Megjegyzés**: Ez a módszer csak azokon a platformokon érhető el, amelyek támogatják az atomi műveleteket
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Áttérés `compare_exchange` és `compare_exchange_weak` rendszerekre
            ///
            /// `compare_and_swap` egyenértékű az `compare_exchange`-szel, a következő leképezéssel a memória rendezéséhez:
            ///
            /// Eredeti |Siker |Kudarc
            /// -------- | ------- | -------
            /// Nyugodt |Nyugodt |Nyugodt Acquire |Megszerzése |Kiadás megszerzése |Engedje elNyugodt AcqRel |AcqRel |A SeqCst megszerzéseSeqCst |SeqCst
            ///
            /// `compare_exchange_weak` akkor is megengedett, hogy hibásan bukjon meg akkor is, ha az összehasonlítás sikeres, ami lehetővé teszi a fordító számára, hogy jobb összeállítási kódot generáljon, amikor az összehasonlítást és a cserét egy hurokban használják.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Ha az aktuális érték megegyezik az `current` értékkel, akkor az atomi egész számba tárol egy értéket.
            ///
            /// A visszatérési érték olyan eredmény, amely jelzi, hogy az új értéket írták-e, és tartalmazza-e az előző értéket.
            /// Siker esetén ez az érték garantáltan megegyezik az `current` értékkel.
            ///
            /// `compare_exchange` két [`Ordering`] argumentumra van szükség a művelet memóriasorrendjének leírására.
            /// `success` leírja a szükséges sorrendet az olvasás-módosítás-írás művelethez, amely akkor megy végbe, ha az `current`-szel való összehasonlítás sikeres.
            /// `failure` leírja az összehasonlítás sikertelensége esetén bekövetkező terhelési művelethez szükséges sorrendet.
            /// Ha az [`Acquire`]-t sikeres megrendelésként használja, akkor az áruház része lesz az [`Relaxed`] műveletnek, az [`Release`] használata pedig az [`Relaxed`] sikeres betöltését jelenti.
            ///
            /// A hibarendelés csak [`SeqCst`], [`Acquire`] vagy [`Relaxed`] lehet, és egyenértékűnek vagy gyengébbnek kell lennie, mint a sikeres megrendelés.
            ///
            /// **Megjegyzés**: Ez a módszer csak azokon a platformokon érhető el, amelyek támogatják az atomi műveleteket
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // BIZTONSÁG: az atomversenyek megakadályozzák az adatversenyeket.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Ha az aktuális érték megegyezik az `current` értékkel, akkor az atomi egész számba tárol egy értéket.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// ez a funkció akkor is meghiúsulhat, ha az összehasonlítás sikerrel jár, ami hatékonyabb kódot eredményezhet egyes platformokon.
            /// A visszatérési érték olyan eredmény, amely jelzi, hogy az új értéket írták-e, és tartalmazza-e az előző értéket.
            ///
            /// `compare_exchange_weak` két [`Ordering`] argumentumra van szükség a művelet memóriasorrendjének leírására.
            /// `success` leírja a szükséges sorrendet az olvasás-módosítás-írás művelethez, amely akkor megy végbe, ha az `current`-szel való összehasonlítás sikeres.
            /// `failure` leírja az összehasonlítás sikertelensége esetén bekövetkező terhelési művelethez szükséges sorrendet.
            /// Ha az [`Acquire`]-t sikeres megrendelésként használja, akkor az áruház része lesz az [`Relaxed`] műveletnek, az [`Release`] használata pedig az [`Relaxed`] sikeres betöltését jelenti.
            ///
            /// A hibarendelés csak [`SeqCst`], [`Acquire`] vagy [`Relaxed`] lehet, és egyenértékűnek vagy gyengébbnek kell lennie, mint a sikeres megrendelés.
            ///
            /// **Megjegyzés**: Ez a módszer csak azokon a platformokon érhető el, amelyek támogatják az atomi műveleteket
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// let mut old= val.load(Ordering::Relaxed);
            /// hurok {legyen új=régi * 2;
            ///     egyezik val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // BIZTONSÁG: az atomversenyek megakadályozzák az adatversenyeket.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Hozzáadódik az aktuális értékhez, visszaadva az előző értéket.
            ///
            /// Ez a művelet a túlcsordulás körül van.
            ///
            /// `fetch_add` vesz egy [`Ordering`] argumentumot, amely leírja a művelet memória sorrendjét.Minden rendelési mód lehetséges.
            /// Ne feledje, hogy az [`Acquire`] használatával ennek a műveletnek az üzlet része az [`Relaxed`], az [`Release`] használatával pedig a betöltési rész [`Relaxed`].
            ///
            ///
            /// **Megjegyzés**: Ez a módszer csak azokon a platformokon érhető el, amelyek támogatják az atomi műveleteket
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // BIZTONSÁG: az atomversenyek megakadályozzák az adatversenyeket.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Kivonja az aktuális értékből, visszaadva az előző értéket.
            ///
            /// Ez a művelet a túlcsordulás körül van.
            ///
            /// `fetch_sub` vesz egy [`Ordering`] argumentumot, amely leírja a művelet memória sorrendjét.Minden rendelési mód lehetséges.
            /// Ne feledje, hogy az [`Acquire`] használatával ennek a műveletnek az üzlet része az [`Relaxed`], az [`Release`] használatával pedig a betöltési rész [`Relaxed`].
            ///
            ///
            /// **Megjegyzés**: Ez a módszer csak azokon a platformokon érhető el, amelyek támogatják az atomi műveleteket
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // BIZTONSÁG: az atomversenyek megakadályozzák az adatversenyeket.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitenként "and" az aktuális értékkel.
            ///
            /// Az aktuális értéket és az `val` argumentumot bitenkénti "and" művelettel hajtja végre, és az eredményre állítja az új értéket.
            ///
            /// Visszaadja az előző értéket.
            ///
            /// `fetch_and` vesz egy [`Ordering`] argumentumot, amely leírja a művelet memória sorrendjét.Minden rendelési mód lehetséges.
            /// Ne feledje, hogy az [`Acquire`] használatával ennek a műveletnek az üzlet része az [`Relaxed`], az [`Release`] használatával pedig a betöltési rész [`Relaxed`].
            ///
            ///
            /// **Megjegyzés**: Ez a módszer csak azokon a platformokon érhető el, amelyek támogatják az atomi műveleteket
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // BIZTONSÁG: az atomversenyek megakadályozzák az adatversenyeket.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitenként "nand" az aktuális értékkel.
            ///
            /// Az aktuális értéket és az `val` argumentumot bitenkénti "nand" művelettel hajtja végre, és az eredményre állítja az új értéket.
            ///
            /// Visszaadja az előző értéket.
            ///
            /// `fetch_nand` vesz egy [`Ordering`] argumentumot, amely leírja a művelet memória sorrendjét.Minden rendelési mód lehetséges.
            /// Ne feledje, hogy az [`Acquire`] használatával ennek a műveletnek az üzlet része az [`Relaxed`], az [`Release`] használatával pedig a betöltési rész [`Relaxed`].
            ///
            ///
            /// **Megjegyzés**: Ez a módszer csak azokon a platformokon érhető el, amelyek támogatják az atomi műveleteket
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // BIZTONSÁG: az atomversenyek megakadályozzák az adatversenyeket.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitenként "or" az aktuális értékkel.
            ///
            /// Az aktuális értéket és az `val` argumentumot bitenkénti "or" művelettel hajtja végre, és az eredményre állítja az új értéket.
            ///
            /// Visszaadja az előző értéket.
            ///
            /// `fetch_or` vesz egy [`Ordering`] argumentumot, amely leírja a művelet memória sorrendjét.Minden rendelési mód lehetséges.
            /// Ne feledje, hogy az [`Acquire`] használatával ennek a műveletnek az üzlet része az [`Relaxed`], az [`Release`] használatával pedig a betöltési rész [`Relaxed`].
            ///
            ///
            /// **Megjegyzés**: Ez a módszer csak azokon a platformokon érhető el, amelyek támogatják az atomi műveleteket
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // BIZTONSÁG: az atomversenyek megakadályozzák az adatversenyeket.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitenként "xor" az aktuális értékkel.
            ///
            /// Az aktuális értéket és az `val` argumentumot bitenkénti "xor" művelettel hajtja végre, és az eredményre állítja az új értéket.
            ///
            /// Visszaadja az előző értéket.
            ///
            /// `fetch_xor` vesz egy [`Ordering`] argumentumot, amely leírja a művelet memória sorrendjét.Minden rendelési mód lehetséges.
            /// Ne feledje, hogy az [`Acquire`] használatával ennek a műveletnek az üzlet része az [`Relaxed`], az [`Release`] használatával pedig a betöltési rész [`Relaxed`].
            ///
            ///
            /// **Megjegyzés**: Ez a módszer csak azokon a platformokon érhető el, amelyek támogatják az atomi műveleteket
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // BIZTONSÁG: az atomversenyek megakadályozzák az adatversenyeket.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Behozza az értéket, és alkalmaz egy függvényt, amely választható új értéket ad vissza.Visszaadja az `Ok(previous_value)` `Result` értékét, ha a függvény visszaadja az `Some(_)` értéket, máskülönben az `Err(previous_value)` értéket.
            ///
            /// Note: Ez többször meghívhatja a függvényt, ha az érték időközben megváltozott más szálaktól, mindaddig, amíg a függvény visszaadja az `Some(_)` értéket, de a függvényt csak egyszer alkalmazzák a tárolt értékre.
            ///
            ///
            /// `fetch_update` két [`Ordering`] argumentumra van szükség a művelet memóriasorrendjének leírására.
            /// Az első a szükséges sorrendet írja le, amikor a művelet végül sikeres lesz, míg a második a terhelések előírt sorrendjét.Ezek megfelelnek a
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Ha az [`Acquire`]-t sikeres megrendelésként használja, akkor az áruház része lesz az [`Relaxed`] műveletnek, az [`Release`] használatával pedig az utolsó sikeres betöltés az [`Relaxed`].
            /// Az (failed) terhelésrendelés csak [`SeqCst`], [`Acquire`] vagy [`Relaxed`] lehet, és egyenértékűnek vagy gyengébbnek kell lennie, mint a sikeres megrendelés.
            ///
            /// **Megjegyzés**: Ez a módszer csak azokon a platformokon érhető el, amelyek támogatják az atomi műveleteket
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Rendezés: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Rendezés: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Maximum az aktuális értékkel.
            ///
            /// Megkeresi az aktuális érték maximumát és az `val` argumentumot, és az eredményre állítja az új értéket.
            ///
            /// Visszaadja az előző értéket.
            ///
            /// `fetch_max` vesz egy [`Ordering`] argumentumot, amely leírja a művelet memória sorrendjét.Minden rendelési mód lehetséges.
            /// Ne feledje, hogy az [`Acquire`] használatával ennek a műveletnek az üzlet része az [`Relaxed`], az [`Release`] használatával pedig a betöltési rész [`Relaxed`].
            ///
            ///
            /// **Megjegyzés**: Ez a módszer csak azokon a platformokon érhető el, amelyek támogatják az atomi műveleteket
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// legyen bár=42;
            /// legyen max_foo=foo.fetch_max (bar, Ordering::SeqCst).max(bar);
            /// állíts! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // BIZTONSÁG: az atomversenyek megakadályozzák az adatversenyeket.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Minimum az aktuális értékkel.
            ///
            /// Megkeresi az aktuális érték minimumát és az `val` argumentumot, és beállítja az új értéket az eredményre.
            ///
            /// Visszaadja az előző értéket.
            ///
            /// `fetch_min` vesz egy [`Ordering`] argumentumot, amely leírja a művelet memória sorrendjét.Minden rendelési mód lehetséges.
            /// Ne feledje, hogy az [`Acquire`] használatával ennek a műveletnek az üzlet része az [`Relaxed`], az [`Release`] használatával pedig a betöltési rész [`Relaxed`].
            ///
            ///
            /// **Megjegyzés**: Ez a módszer csak azokon a platformokon érhető el, amelyek támogatják az atomi műveleteket
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// legyen bár=12;
            /// legyen min_foo=foo.fetch_min (sáv, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // BIZTONSÁG: az atomversenyek megakadályozzák az adatversenyeket.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Egy módosítható mutatót ad vissza az alapul szolgáló egész számra.
            ///
            /// Nem atom típusú olvasás és írás az eredményül kapott egész számra lehet adatverseny.
            /// Ez a módszer leginkább az FFI esetében hasznos, ahol az aláírás függvény használhatja
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Az `*mut` mutató visszaadása egy közös hivatkozás alapján erre az atomra biztonságos, mert az atomtípusok belső mutabilitással működnek.
            /// Az atom minden módosítása megváltoztatja az értéket egy közös referencia segítségével, és biztonságosan megteheti mindaddig, amíg atomi műveleteket alkalmaz.
            /// A visszaküldött nyers mutató használatához `unsafe`-blokk szükséges, és továbbra is be kell tartania ugyanazt a korlátozást: a rajta végrehajtott műveleteknek atomnak kell lenniük.
            ///
            ///
            /// # Examples
            ///
            /// "hagyja figyelmen kívül az (extern-declaration)-et
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// extern "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // BIZTONSÁG: Biztonságos, amíg az `my_atomic_op` atom.
            /// nem biztonságos {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // BIZTONSÁG: a hívónak be kell tartania az `atomic_store` biztonsági szerződését.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // BIZTONSÁG: a hívónak be kell tartania az `atomic_load` biztonsági szerződését.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BIZTONSÁG: a hívónak be kell tartania az `atomic_swap` biztonsági szerződését.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Visszaadja az előző értéket (például __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BIZTONSÁG: a hívónak be kell tartania az `atomic_add` biztonsági szerződését.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Visszaadja az előző értéket (például __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BIZTONSÁG: a hívónak be kell tartania az `atomic_sub` biztonsági szerződését.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // BIZTONSÁG: a hívónak be kell tartania az `atomic_compare_exchange` biztonsági szerződését.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // BIZTONSÁG: a hívónak be kell tartania az `atomic_compare_exchange_weak` biztonsági szerződését.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BIZTONSÁG: a hívónak be kell tartania az `atomic_and` biztonsági szerződését
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BIZTONSÁG: a hívónak be kell tartania az `atomic_nand` biztonsági szerződését
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BIZTONSÁG: a hívónak be kell tartania az `atomic_or` biztonsági szerződését
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BIZTONSÁG: a hívónak be kell tartania az `atomic_xor` biztonsági szerződését
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// visszaadja a max értéket (aláírt összehasonlítás)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BIZTONSÁG: a hívónak be kell tartania az `atomic_max` biztonsági szerződését
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// visszaadja a min értéket (aláírt összehasonlítás)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BIZTONSÁG: a hívónak be kell tartania az `atomic_min` biztonsági szerződését
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// a max értéket adja vissza (aláíratlan összehasonlítás)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BIZTONSÁG: a hívónak be kell tartania az `atomic_umax` biztonsági szerződését
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// visszaadja a min értéket (aláíratlan összehasonlítás)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BIZTONSÁG: a hívónak be kell tartania az `atomic_umin` biztonsági szerződését
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Atomkerítés.
///
/// A megadott sorrendtől függően a kerítés megakadályozza, hogy a fordító és a CPU bizonyos típusú memóriaműveleteket rendezzen körülötte.
/// Ez szinkronizáló kapcsolatokat hoz létre közte és az atomi műveletek vagy más szálak kerítése között.
///
/// Az 'A' kerítés, amely rendelkezik (legalább) [`Release`] rendezési szemantikával, szinkronizál egy 'B' kerítéssel (legalább) [`Acquire`] szemantikával, ha és csak akkor, ha léteznek X és Y műveletek, mindkettő valamilyen 'M' atomobjektumon működik, úgy, hogy az A X, Y szinkronban van, mielőtt B és Y megfigyelné az M-re való váltást.
/// Ez biztosítja a korábban bekövetkező függőséget A és B között.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Az [`Release`] vagy [`Acquire`] szemantikával végzett atomműveletek szinkronizálhatóak egy kerítéssel is.
///
/// Az [`SeqCst`] rendezésű kerítés azon túl, hogy mind az [`Acquire`], mind az [`Release`] szemantikával rendelkezik, részt vesz a többi [`SeqCst`] művelet és/vagy kerítés globális programrendjében.
///
/// Elfogadja az [`Acquire`], [`Release`], [`AcqRel`] és [`SeqCst`] megrendeléseket.
///
/// # Panics
///
/// Panics ha `order` [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // A spinlockon alapuló kölcsönös kirekesztési primitív.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Várjon, amíg a régi érték `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Ez a kerítés szinkronizálja az `unlock` tárolóját.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // BIZTONSÁG: atomi kerítés használata biztonságos.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Egy fordító memória kerítés.
///
/// `compiler_fence` nem bocsát ki gépi kódot, de korlátozza a fordító számára engedélyezett újrarendelés memóriáját.Pontosabban, az adott [`Ordering`] szemantikától függően a fordító megtagadható az olvasások vagy írások áthelyezésétől a hívás előtti vagy utáni hívás másik oldalára az `compiler_fence` felé.Ne feledje, hogy **nem** akadályozza meg a *hardvert* ilyen újrarendelésben.
///
/// Ez egyszálú végrehajtási környezetben nem jelent problémát, de amikor más szálak módosíthatják a memóriát egyidejűleg, erősebb szinkronizációs primitívekre van szükség, például az [`fence`]-re.
///
/// A különböző rendezési szemantika által megakadályozott újrarendezés a következő:
///
///  - [`SeqCst`] esetén az olvasási és írási sorrend nem engedélyezett ezen a ponton.
///  - az [`Release`] használatával az előző olvasások és írások nem léphetők át a későbbi írások mellett.
///  - az [`Acquire`] használatával a későbbi olvasások és írások nem haladhatók meg az előző olvasások előtt.
///  - az [`AcqRel`] használatával a fenti két szabály érvényesül.
///
/// `compiler_fence` általában csak annak megakadályozására használható, hogy egy szál *önmagával* versenyezzen.Azaz, ha egy adott szál egy darab kódot hajt végre, majd megszakad, és másutt kezdi végrehajtani a kódot (miközben ugyanabban a szálban van, és fogalmilag még mindig ugyanazon a magon van).A hagyományos programokban ez csak jelkezelő regisztrálásakor fordulhat elő.
/// Több alacsony szintű kódban is előfordulhatnak ilyen helyzetek a megszakítások kezelésekor, a zöld szálak előválasztással történő megvalósításakor stb.
/// A kíváncsi olvasókat javasoljuk, hogy olvassák el az Linux kernel [memory barriers]-ről szóló vitáját.
///
/// # Panics
///
/// Panics ha `order` [`Relaxed`].
///
/// # Examples
///
/// `compiler_fence` nélkül az `assert_eq!` a következő kódban nem garantáltan sikeres, annak ellenére, hogy minden egyetlen szálon megy végbe.
/// Hogy miért, ne feledje, hogy a fordító szabadon cserélheti az üzleteket `IMPORTANT_VARIABLE` és `IS_READ` kódokra, mivel mindkettő `Ordering::Relaxed`.Ha ez megtörténik, és a jelkezelőt közvetlenül az `IS_READY` frissítése után hívják meg, akkor a jelkezelő az `IS_READY=1`, de az `IMPORTANT_VARIABLE=0` üzenetet fogja látni.
/// Az `compiler_fence` használata orvosolja ezt a helyzetet.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // megakadályozza, hogy a korábbi írások ezen a ponton túlra kerüljenek
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // BIZTONSÁG: atomi kerítés használata biztonságos.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Jelzi a processzornak, hogy egy foglalt várakozó centrifugában van ("spin lock").
///
/// Ez a funkció elavult az [`hint::spin_loop`] javára.
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}