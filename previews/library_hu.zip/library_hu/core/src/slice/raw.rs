//! Ingyenes funkciók az `&[T]` és `&mut [T]` létrehozásához.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Szeletet alkot egy mutatóból és egy hosszúságból.
///
/// Az `len` argumentum a **elemek** száma, nem a bájtok száma.
///
/// # Safety
///
/// A viselkedés nincs meghatározva, ha az alábbi feltételek bármelyikét megsértik:
///
/// * `data` [valid] értéknek kell lennie az `len * mem::size_of::<T>()` sok bájt olvasásakor, és megfelelően igazítani kell.Ez különösen a következőket jelenti:
///
///     * Ennek a szeletnek a teljes memóriatartományának egyetlen lefoglalt objektumon belül kell lennie!
///       A szeletek soha nem terjedhetnek át több allokált objektumon.Lásd az [below](#incorrect-usage) példát, ha ezt tévesen nem vették figyelembe.
///     * `data` nem nullának kell lennie, és még a nulla hosszúságú szeletekhez is igazítani kell.
///     Ennek egyik oka az, hogy az enum elrendezés optimalizálása támaszkodhat arra, hogy a referenciák (beleértve a bármilyen hosszúságú szeleteket) összehangoltak és nem nullák, hogy megkülönböztessék őket más adatoktól.
///     Az [`NonNull::dangling()`] használatával olyan mutatót kaphat, amely `data` néven használható nulla hosszúságú szeletekhez.
///
/// * `data` mutatnia kell az `len` egymást követő, megfelelően inicializált `T` típusú értékekre.
///
/// * A visszaadott szelet által hivatkozott memória nem mutálható az `'a` élettartama alatt, kivéve az `UnsafeCell` belsejét.
///
/// * A szelet teljes `len * mem::size_of::<T>()` mérete nem lehet nagyobb, mint `isize::MAX`.
///   Lásd az [`pointer::offset`] biztonsági dokumentációját.
///
/// # Caveat
///
/// A visszaküldött szelet élettartama a használatából következik.
/// A véletlen visszaélések elkerülése érdekében javasoljuk, hogy kösse össze az élettartamot azzal a forrással, amely a környezetben biztonságos, például egy segítő funkcióval, amely a szelet gazdagépének élettartamát veszi fel, vagy kifejezett kommentárokkal.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // megnyilvánuljon egy elem szelete
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Helytelen használat
///
/// A következő `join_slices` funkció **hangtalan** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // A fenti állítás biztosítja, hogy az `fst` és az `snd` összefüggenek, de előfordulhat, hogy mégis benne vannak az _different allocated objects_-ben, ebben az esetben a szelet létrehozása nem meghatározott viselkedés.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` és az `b` különböző kiosztott objektumok ...
///     let a = 42;
///     let b = 27;
///     // ... amelyet mégis egybefüggő módon lehet az emlékezetben elhelyezni: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // BIZTONSÁG: a hívónak be kell tartania az `from_raw_parts` biztonsági szerződését.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Ugyanazt a funkciót látja el, mint az [`from_raw_parts`], azzal a különbséggel, hogy egy módosítható szeletet ad vissza.
///
/// # Safety
///
/// A viselkedés nincs meghatározva, ha az alábbi feltételek bármelyikét megsértik:
///
/// * `data` [valid] értékűnek kell lennie mind az olvasás, mind az írás esetén az `len * mem::size_of::<T>()` sok bájtnál, és megfelelőnek kell lennie.Ez különösen a következőket jelenti:
///
///     * Ennek a szeletnek a teljes memóriatartományának egyetlen lefoglalt objektumon belül kell lennie!
///       A szeletek soha nem terjedhetnek át több allokált objektumon.
///     * `data` nem nullának kell lennie, és még a nulla hosszúságú szeletekhez is igazítani kell.
///     Ennek egyik oka az, hogy az enum elrendezés optimalizálása támaszkodhat arra, hogy a referenciák (beleértve a bármilyen hosszúságú szeleteket) összehangoltak és nem nullák, hogy megkülönböztessék őket más adatoktól.
///
///     Az [`NonNull::dangling()`] használatával olyan mutatót kaphat, amely `data` néven használható nulla hosszúságú szeletekhez.
///
/// * `data` mutatnia kell az `len` egymást követő, megfelelően inicializált `T` típusú értékekre.
///
/// * A visszaküldött szelet által hivatkozott memóriához az `'a` élettartama alatt semmilyen más (nem a visszatérési értékből származtatott) mutatón keresztül lehet hozzáférni.
///   Az olvasási és írási hozzáférés egyaránt tilos.
///
/// * A szelet teljes `len * mem::size_of::<T>()` mérete nem lehet nagyobb, mint `isize::MAX`.
///   Lásd az [`pointer::offset`] biztonsági dokumentációját.
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // BIZTONSÁG: a hívónak be kell tartania az `from_raw_parts_mut` biztonsági szerződését.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// A T-re való hivatkozást 1 hosszúságú szeletté alakítja (másolás nélkül).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// A T-re való hivatkozást 1 hosszúságú szeletté alakítja (másolás nélkül).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}