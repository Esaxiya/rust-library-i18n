// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Forgatja az `[mid-left, mid+right)` tartományt úgy, hogy az `mid` pontban lévő elem legyen az első elem.Ezzel egyenértékűen elforgatja az `left` tartományú elemeket balra vagy az `right` elemeket jobbra.
///
/// # Safety
///
/// A megadott tartománynak érvényesnek kell lennie az olvasáshoz és az íráshoz.
///
/// # Algorithm
///
/// Az 1. algoritmust az `left + right` kis értékeihez vagy a nagy `T` értékéhez használjuk.
/// Az elemeket egyenként helyezzük végső helyzetükbe `mid - left`-től kezdve és `right` modulo `left + right` lépésekkel haladva úgy, hogy csak egy ideiglenesre van szükség.
/// Végül visszaérkezünk az `mid - left`-hez.
/// Ha azonban az `gcd(left + right, right)` nem 1, a fenti lépések átugrottak az elemeken.
/// Például:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Szerencsére a véglegesített elemek között az átugrott elemek száma mindig megegyezik, így csak ellensúlyozhatjuk a kiindulási helyzetünket, és több kört tehetünk meg (az összes kör száma az `gcd(left + right, right)` value).
///
/// A végeredmény az, hogy minden elem egyszer és egyszer véglegesítésre kerül.
///
/// A 2. algoritmust akkor használjuk, ha az `left + right` nagy, de az `min(left, right)` elég kicsi ahhoz, hogy elférjen egy verem pufferben.
/// Az `min(left, right)` elemeket átmásoljuk a pufferre, az `memmove`-et a többire, a pufferen lévőket pedig visszahelyezzük a lyukba, a másik oldalon, ahonnan eredtek.
///
/// A vektorizálható algoritmusok felülmúlják a fentieket, ha az `left + right` elég nagy lesz.
/// Az 1. algoritmust sokféle forduló egyszerre történő darabolásával és végrehajtásával lehet vektorizálni, de átlagosan túl kevés a kör, amíg az `left + right` óriási, és az egyetlen kör legrosszabb esete mindig ott van.
/// Ehelyett a 3. algoritmus az `min(left, right)` elemek ismételt cseréjét használja, amíg kisebb forgatási probléma nem marad.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// amikor `left < right`, a csere balról történik.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. az alábbi algoritmusok meghiúsulhatnak, ha ezeket az eseteket nem ellenőrzik
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Az 1. algoritmus mikrohullámai azt jelzik, hogy a véletlen váltások átlagos teljesítménye egészen `left + right == 32`-ig jobb, de a legrosszabb esetben a teljesítmény 16 körül is megszakad.
            // 24-et választották középútnak.
            // Ha az `T` mérete nagyobb, mint 4 "usise", akkor ez az algoritmus felülmúlja a többi algoritmust is.
            //
            //
            let x = unsafe { mid.sub(left) };
            // első kör kezdete
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` kéz előtt megtalálható az `gcd(left + right, right)` kiszámításával, de gyorsabb, ha megcsinálunk egy ciklust, amely a gcd-t mellékhatásként számítja ki, majd elvégzi a többi darabot
            //
            //
            let mut gcd = right;
            // A referenciaértékek azt mutatják, hogy gyorsabb az időbeli változások végigcserélése, ahelyett, hogy egyszer csak egy ideiglenes üzenetet olvasnánk, visszafelé másolnánk, majd ezt az ideiglenest a végére írnánk.
            // Ennek oka valószínűleg az, hogy az ideiglenes adatok cseréje vagy cseréje csak egy memória címet használ a ciklusban, ahelyett, hogy kettőt kellene kezelni.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // ahelyett, hogy növelnénk az `i` értéket, majd ellenőriznénk, hogy kívül esik-e a határokon, ellenőrizzük, hogy az `i` a következő növekményen kívül esik-e a határokon.
                // Ez megakadályozza a mutatók vagy az `usize` csomagolását.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // első kör vége
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // ennek a feltételnek itt kell lennie, ha `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // fejezze be a darabot még több körrel
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` nem nulla méretű típus, ezért rendben van, ha felosztjuk méretével.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // 2. algoritmus Az `[T; 0]` itt biztosítja, hogy ez megfelelően illeszkedjen a T-hez
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // A 3. algoritmusnak van egy alternatív módja a cserére, amely magában foglalja annak keresését, hogy hol lenne ennek az algoritmusnak az utolsó cseréje, és az utolsó darabot használva cserélje fel a szomszédos darabok cseréje helyett, mint ahogy ezt az algoritmus teszi, de ez a módszer még mindig gyorsabb.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // 3. algoritmus, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}