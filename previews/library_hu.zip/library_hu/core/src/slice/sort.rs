//! Szeletek rendezése
//!
//! Ez a modul egy rendezési algoritmust tartalmaz, amely Orson Peters mintázatát legyőző quicksort-on alapul, és amelyet a következő címen tettek közzé: <https://github.com/orlp/pdqsort>
//!
//!
//! Az instabil rendezés kompatibilis a libcore-szal, mert a stabil rendezési megvalósítással ellentétben nem osztja ki a memóriát.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Amikor elejtette, az `src`-ről az `dest`-re másol.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // BIZTONSÁG: Ez egy segítő osztály.
        //          Kérjük, olvassa el a használat helyességét.
        //          Ugyanakkor biztosnak kell lennie abban, hogy az `src` és az `dst` nem fedi egymást az `ptr::copy_nonoverlapping` előírása szerint.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Az első elemet tolja jobbra, amíg nagyobb vagy egyenlő elemmel nem találkozik.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // BIZTONSÁG: Az alábbi nem biztonságos műveletekhez kötelező ellenőrzés nélküli indexelés szükséges (`get_unchecked` és `get_unchecked_mut`)
    // és az (`ptr::copy_nonoverlapping`) memória másolása.
    //
    // a.Indexelés:
    //  1. A tömb méretét>=2 értékre ellenőriztük.
    //  2. Az összes indexelés, amelyet végezni fogunk, mindig legfeljebb az {0 <= index < len} között van.
    //
    // b.Memória másolás
    //  1. Garantáljuk, hogy érvényesek azok a hivatkozások, amelyek garantáltan érvényesek.
    //  2. Nem fedhetik át egymást, mert mutatókat kapunk a szelet különbségi mutatóira.
    //     Mégpedig `i` és `i-1`.
    //  3. Ha a szelet megfelelően van igazítva, akkor az elemek megfelelően vannak igazítva.
    //     A hívó fél felelőssége, hogy megbizonyosodjon a szelet megfelelő igazításáról.
    //
    // További részletekért lásd az alábbi megjegyzéseket.
    unsafe {
        // Ha az első két elem nem működik ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Olvassa el az első elemet egy veremhez rendelt változóba.
            // Ha egy következő összehasonlító művelet panics, `hole` elesik és automatikusan visszaírja az elemet a szeletbe.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Mozgassa az i-edik elemet egy hellyel balra, ezzel tolva a lyukat jobbra.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` leesik, és így az `tmp`-et bemásolja az `v` fennmaradó lyukába.
        }
    }
}

/// Az utolsó elemet tolja balra, amíg kisebb vagy egyenlő elemmel találkozik.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // BIZTONSÁG: Az alábbi nem biztonságos műveletekhez kötelező ellenőrzés nélküli indexelés szükséges (`get_unchecked` és `get_unchecked_mut`)
    // és az (`ptr::copy_nonoverlapping`) memória másolása.
    //
    // a.Indexelés:
    //  1. A tömb méretét>=2 értékre ellenőriztük.
    //  2. Az összes indexelés, amelyet végezni fogunk, mindig legfeljebb az `0 <= index < len-1` között van.
    //
    // b.Memória másolás
    //  1. Garantáljuk, hogy érvényesek azok a hivatkozások, amelyek garantáltan érvényesek.
    //  2. Nem fedhetik át egymást, mert mutatókat kapunk a szelet különbségi mutatóira.
    //     Mégpedig `i` és `i+1`.
    //  3. Ha a szelet megfelelően van igazítva, akkor az elemek megfelelően vannak igazítva.
    //     A hívó fél felelőssége, hogy megbizonyosodjon a szelet megfelelő igazításáról.
    //
    // További részletekért lásd az alábbi megjegyzéseket.
    unsafe {
        // Ha az utolsó két elem nem működik ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Olvassa el az utolsó elemet egy veremhez rendelt változóba.
            // Ha egy következő összehasonlító művelet panics, `hole` elesik és automatikusan visszaírja az elemet a szeletbe.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Helyezze az i-edik elemet egy hellyel jobbra, ezzel tolva a lyukat balra.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` leesik, és így az `tmp`-et bemásolja az `v` fennmaradó lyukába.
        }
    }
}

/// Részlegesen rendez egy szeletet úgy, hogy több rendezetlen elemet áthelyez.
///
/// `true` értéket ad vissza, ha a szelet rendezve van a végén.Ez a függvény a legrosszabb esetben *O*(*n*).
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // A szomszédos, soron kívüli párok maximális száma, amelyek eltolódnak.
    const MAX_STEPS: usize = 5;
    // Ha a szelet ennél rövidebb, ne helyezzen el egyetlen elemet sem.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // BIZTONSÁG: Már kifejezetten elvégeztük a kötött ellenőrzést az `i < len`-szel.
        // Minden későbbi indexelésünk csak az `0 <= index < len` tartományba esik
        unsafe {
            // Keresse meg a következő pár szomszédos nem rendezett elemet.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Végeztünk?
        if i == len {
            return true;
        }

        // Ne helyezzen el elemeket rövid tömbökön, ennek teljesítményköltsége van.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Cserélje ki a megtalált elempárt.Ez megfelelő sorrendbe állítja őket.
        v.swap(i - 1, i);

        // Vigye a kisebb elemet balra.
        shift_tail(&mut v[..i], is_less);
        // Vigye a nagyobb elemet jobbra.
        shift_head(&mut v[i..], is_less);
    }

    // A szeletet nem sikerült a korlátozott számú lépésben rendezni.
    false
}

/// A szeletet beszúrási rendezéssel rendezi, amely a legrosszabb esetben *O*(*n*^ 2).
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Az `v` rendezése heapsort használatával, amely garantálja a *O*(*n*\*log(* n*)) legrosszabb esetet).
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ez a bináris halom tiszteletben tartja az invariáns `parent >= child`-et.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Az `node` gyermekei:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Válassza ki a nagyobb gyermeket.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Állítsa le, ha az invariáns `node`-nél tart.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Cserélje az `node`-et a nagyobb gyerekkel, lépjen lejjebb, és folytassa a rostálást.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Építsd fel a kupacot lineáris időben.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop maximális elemeket a kupacból.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Az `v` particionálása `pivot`-nél kisebb elemekre, majd az `pivot`-nél nagyobb vagy azzal egyenlő elemek.
///
///
/// Visszaadja az `pivot`-nél kisebb elemek számát.
///
/// A particionálást blokkonként hajtják végre az elágazási műveletek költségeinek minimalizálása érdekében.
/// Ezt az ötletet az [BlockQuicksort][pdf] papír mutatja be.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Elemek száma egy tipikus blokkban.
    const BLOCK: usize = 128;

    // A particionáló algoritmus a következő lépéseket ismétli a befejezésig:
    //
    // 1. Kövessen egy blokkot a bal oldalról, hogy azonosítsa a forgáspontnál nagyobb vagy azzal egyenlő elemeket.
    // 2. Nyomozzon egy blokkot a jobb oldalon a forgásnál kisebb elemek azonosításához.
    // 3. Cserélje ki az azonosított elemeket a bal és a jobb oldal között.
    //
    // A következő változókat megtartjuk egy elemblokk számára:
    //
    // 1. `block` - Elemek száma a blokkban.
    // 2. `start` - Indítsa el a mutatót az `offsets` tömbbe.
    // 3. `end` - Végmutató az `offsets` tömbbe.
    // 4. `offsets, A blokkon belüli nem rendelt elemek indexei.

    // Az aktuális blokk a bal oldalon (`l`-től `l.add(block_l)`)-ig).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // A jelenlegi blokk a jobb oldalon (`r.sub(block_r)` to `r`)-től).
    // BIZTONSÁG: Az .add() dokumentációja kifejezetten megemlíti, hogy az `vec.as_ptr().add(vec.len())` mindig biztonságos
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Amikor VLA-kat kapunk, próbáljon inkább létrehozni egy `min(v.len(), 2 * BLOCK) hosszúságú tömböt
    // mint két rögzített méretű `BLOCK` hosszúságú tömb.Lehet, hogy a VLA-k gyorsítótár-hatékonyabbak.

    // Visszaadja az `l` (inclusive) és `r` (exclusive) mutatók közötti elemek számát.
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Blokkról blokkra osztjuk a partíciókat, amikor az `l` és az `r` nagyon közel kerül egymáshoz.
        // Ezután végezzünk néhány javítási munkát annak érdekében, hogy a fennmaradó elemeket feloszthassuk.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // A fennmaradó elemek száma (még mindig nem hasonlítanak a forgáshoz).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Állítsa be a blokk méretét úgy, hogy a bal és a jobb blokk ne fedje egymást, hanem tökéletesen igazodjon a teljes hátramaradó réshez.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Nyomja meg az `block_l` elemeket a bal oldalon.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // BIZTONSÁG: Az alábbi nem biztonságos műveletek az `offset` használatát jelentik.
                //         A függvény által megkövetelt feltételeknek megfelelően kielégítjük őket, mert:
                //         1. `offsets_l` veremkiosztva van, és ezért külön allokált objektumnak tekinthető.
                //         2. Az `is_less` függvény visszaad egy `bool` értéket.
                //            Az `bool` leadása soha nem fogja túlcsordítani az `isize`-et.
                //         3. Garantáltuk, hogy az `block_l` `<= BLOCK` lesz.
                //            Ráadásul az `end_l`-et kezdetben az `offsets_` kezdő mutatójára állították, amelyet a veremben deklaráltak.
                //            Így tudjuk, hogy a legrosszabb esetben is (az `is_less` összes invokációja hamis értéket ad vissza) legfeljebb 1 bájt lesz a vége.
                //        Egy másik nem biztonságos művelet itt az `elem` levezetése.
                //        Az `elem` azonban kezdetben a szelet kezdő mutatója volt, amely mindig érvényes.
                unsafe {
                    // Ág nélküli összehasonlítás.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Nyomja meg az `block_r` elemeket a jobb oldalon.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // BIZTONSÁG: Az alábbi nem biztonságos műveletek az `offset` használatát jelentik.
                //         A függvény által megkövetelt feltételeknek megfelelően kielégítjük őket, mert:
                //         1. `offsets_r` veremkiosztva van, és ezért külön allokált objektumnak tekinthető.
                //         2. Az `is_less` függvény visszaad egy `bool` értéket.
                //            Az `bool` leadása soha nem fogja túlcsordítani az `isize`-et.
                //         3. Garantáltuk, hogy az `block_r` `<= BLOCK` lesz.
                //            Ráadásul az `end_r`-et kezdetben az `offsets_` kezdő mutatójára állították, amelyet a veremben deklaráltak.
                //            Így tudjuk, hogy a legrosszabb esetben is (az `is_less` összes invokációja igazra tér vissza) legfeljebb 1 bájt lesz a vége.
                //        Egy másik nem biztonságos művelet itt az `elem` levezetése.
                //        Az `elem` azonban eredetileg túl volt a `1 *sizeof(T)` végén, és az `1* sizeof(T)` értékkel csökkentjük, mielőtt hozzáférnénk hozzá.
                //        Ráadásul azt állították, hogy az `block_r` kisebb, mint `BLOCK`, és ezért az `elem` legfeljebb a szelet elejére mutat.
                unsafe {
                    // Ág nélküli összehasonlítás.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // A bal és a jobb oldal között felcserélhető, soron kívüli elemek száma.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Ahelyett, hogy egyszerre egy párt cserélne, hatékonyabb egy ciklikus permutációt végrehajtani.
            // Ez nem szigorúan egyenértékű a cserével, de hasonló eredményt hoz kevesebb memóriaművelettel.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // A bal oldali blokk összes rendezetlen elemét áthelyezték.Ugrás a következő blokkra.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // A jobb blokk összes rendezetlen elemét áthelyezték.Ugrás az előző blokkra.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Most már csak egy blokk (vagy bal vagy jobb) marad, sorrenden kívüli elemekkel, amelyeket mozgatni kell.
    // Az ilyen megmaradt elemek egyszerűen eltolhatók a blokkjukon belül.
    //

    if start_l < end_l {
        // A bal oldali blokk megmarad.
        // Helyezze a fennmaradó, renden kívüli elemeit a jobb szélsőbe.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // A megfelelő blokk megmarad.
        // Vigye a fennmaradó renden kívüli elemeit a bal szélsőbe.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Nincs más tennivaló, készen vagyunk.
        width(v.as_mut_ptr(), l)
    }
}

/// Az `v` particionálása `v[pivot]`-nél kisebb elemekre, majd az `v[pivot]`-nél nagyobb vagy azzal egyenlő elemek.
///
///
/// A következőt adja vissza:
///
/// 1. `v[pivot]`-nél kisebb elemek száma.
/// 2. Igaz, ha az `v` már fel volt osztva.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Helyezze a forgást a szelet elejére.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // A hatékonyság érdekében olvassa el az elfordulást egy verem által allokált változóba.
        // Ha egy következő összehasonlító művelet panics, akkor a forgatókönyvet automatikusan visszaírja a szeletbe.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Keresse meg az első pár rendezetlen elemet.
        let mut l = 0;
        let mut r = v.len();

        // BIZTONSÁG: Az alábbi nem biztonságos egy tömb indexelésével jár.
        // Az elsőre: Itt már elvégezzük a határellenőrzést az `l < r` segítségével.
        // A másodikra: Kezdetben `l == 0` és `r == v.len()` van, és minden indexelési műveletnél ellenőrizzük, hogy `l < r`.
        //                     Innen tudjuk, hogy az `r`-nek legalább `r == l`-nek kell lennie, amelyről kiderült, hogy az elsőtől érvényes.
        unsafe {
            // Keresse meg az első elemet, amely nagyobb vagy egyenlő a forgási ponttal.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Keresse meg az utolsó elemet, amely kisebb, mint az elfordulás.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` kijön a hatókörből és visszaírja a pivot-ot (ami egy verem-allokált változó) abba a szeletbe, ahol eredetileg volt.
        // Ez a lépés kritikus a biztonság biztosításában!
        //
    };

    // Helyezze a csapot a két partíció közé.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Az `v` particionálja az `v[pivot]` egyenlő elemekre, majd az `v[pivot]`-nél nagyobb elemekre.
///
/// Visszaadja az elfordulással megegyező elemek számát.
/// Feltételezzük, hogy az `v` nem tartalmaz a forgásnál kisebb elemeket.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Helyezze a forgást a szelet elejére.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // A hatékonyság érdekében olvassa el az elfordulást egy verem által allokált változóba.
    // Ha egy következő összehasonlító művelet panics, akkor a forgatókönyvet automatikusan visszaírja a szeletbe.
    // BIZTONSÁG: A mutató itt érvényes, mert egy szeletre való hivatkozásból származik.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Most ossza szét a szeletet.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // BIZTONSÁG: Az alábbi nem biztonságos egy tömb indexelésével jár.
        // Az elsőre: Itt már elvégezzük a határellenőrzést az `l < r` segítségével.
        // A másodikra: Kezdetben `l == 0` és `r == v.len()` van, és minden indexelési műveletnél ellenőrizzük, hogy `l < r`.
        //                     Innen tudjuk, hogy az `r`-nek legalább `r == l`-nek kell lennie, amelyről kiderült, hogy az elsőtől érvényes.
        unsafe {
            // Keresse meg az első elemet, amely nagyobb, mint az elfordulás.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Keresse meg az utolsó elemet, amely egyenlő a forgatással.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Végeztünk?
            if l >= r {
                break;
            }

            // Cserélje ki a talált pár renden kívüli elemet.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Megtaláltuk a forgatással megegyező `l` elemeket.Adjon hozzá 1-et magához a forgásszámhoz.
    l + 1

    // `_pivot_guard` kijön a hatókörből és visszaírja a pivot-ot (ami egy verem-allokált változó) abba a szeletbe, ahol eredetileg volt.
    // Ez a lépés kritikus a biztonság biztosításában!
}

/// Szétszór néhány elemet, megkísérelve megszakítani azokat a mintákat, amelyek kiegyensúlyozatlan partíciókat okozhatnak a quickortban.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Pszeudorandom számgenerátor George Marsaglia "Xorshift RNGs" papírjából.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Vegyük ezt a számot véletlenszerű számokkal.
        // A szám illeszkedik az `usize`-be, mert az `len` nem nagyobb, mint `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Néhány forgatójelölt ennek az indexnek a közelében található.Véletlenszerűvé tegyük őket.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Generáljon véletlenszámot modulo `len`.
            // Azonban a költséges műveletek elkerülése érdekében először modulo értéket veszünk fel kettőből, majd `len`-rel csökkentjük, amíg be nem illeszkedik az `[0, len - 1]` tartományba.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` garantáltan kisebb lesz, mint `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Kiválaszt egy forgatást az `v`-ben, és visszaadja az indexet és az `true`-et, ha a szelet valószínűleg már rendezve van.
///
/// Az eljárás során az `v` elemei átrendezhetők.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // A medián-medián módszer kiválasztásának minimális hossza.
    // A rövidebb szeletek az egyszerű három-medián módszert alkalmazzák.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Az ebben a funkcióban végrehajtható csereügyletek maximális száma.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Három index, amelyek közelében pivot fogunk választani.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Megszámolja az indexek rendezése során végrehajtandó csereügyletek teljes számát.
    let mut swaps = 0;

    if len >= 8 {
        // Az indexeket felcseréli úgy, hogy az `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Az indexeket felcseréli úgy, hogy az `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Megkeresi az `v[a - 1], v[a], v[a + 1]` mediánját és tárolja az indexet az `a`-be.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Keressen mediánokat az `a`, `b` és `c` környéken.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Keresse meg a mediánt az `a`, `b` és `c` között.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // A swapok maximális számát hajtották végre.
        // Valószínű, hogy a szelet csökkenő vagy többnyire csökkenő, ezért az irányváltás valószínűleg gyorsabb rendezésben segít.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Rekurzívan rendezi az `v`-et.
///
/// Ha a szeletnek volt elődje az eredeti tömbben, akkor az `pred`.
///
/// `limit` a megengedett kiegyensúlyozatlan partíciók száma az `heapsort`-re váltás előtt.
/// Ha nulla, akkor ez a funkció azonnal áttér a heapsort-ra.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Az ilyen hosszúságú szeleteket a beszúrási rendezéssel rendezik.
    const MAX_INSERTION: usize = 20;

    // Igaz, ha az utolsó particionálás ésszerűen kiegyensúlyozott volt.
    let mut was_balanced = true;
    // Igaz, ha az utolsó particionálás nem keverte az elemeket (a szelet már fel volt osztva).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // A nagyon rövid szeleteket beillesztési rendezéssel lehet rendezni.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Ha túl sok rossz döntési döntést hoztak, egyszerűen térjen vissza a heapsorthoz az `O(n * log(n))` legrosszabb esetének garantálása érdekében.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Ha az utolsó particionálás egyensúlyhiányos volt, próbáljon megszakítani a szelet mintáit úgy, hogy néhány elemet összekever.
        // Remélhetőleg ezúttal jobb pivot választunk.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Válasszon egy forgást, és próbálja kitalálni, hogy a szelet már rendezve van-e.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Ha az utolsó particionálás megfelelően kiegyensúlyozott volt, és nem keverte az elemeket, és ha a pivot kiválasztás előrejelzi, akkor a szelet valószínűleg már rendezve van ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Próbáljon meg több rendezetlen elemet azonosítani, és a helyes pozíciókba helyezni.
            // Ha a szelet végül teljesen rendeződik, akkor készen vagyunk.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Ha a kiválasztott forgási pont megegyezik az előddel, akkor ez a szelet legkisebb eleme.
        // Ossza fel a szeletet olyan elemekre, amelyek egyenlőek és nagyobbak, mint az elfordulás.
        // Ez az eset általában akkor érhető el, ha a szelet sok ismétlődő elemet tartalmaz.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Folytassa az elemek forgatásánál nagyobb rendezést.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Ossza fel a szeletet.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Ossza fel a szeletet `left`, `pivot` és `right`-re.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Csak a rövidebb oldalra térjen vissza, hogy minimalizálja a rekurzív hívások teljes számát és kevesebb helyet foglaljon el.
        // Ezután folytassa a hosszabb oldallal (ez hasonlít a farok rekurziójára).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Az `v` rendezése mintamegfigyelő quicksort használatával, amely *O*(*n*\*log(* n*)) legrosszabb eset.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // A rendezésnek nincs értelmes viselkedése nulla méretű típusoknál.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Korlátozza a kiegyensúlyozatlan partíciók számát `floor(log2(len)) + 1`-re.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Ekkora szeleteknél valószínűleg gyorsabb egyszerűen szétválogatni őket.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Válasszon egy forgást
        let (pivot, _) = choose_pivot(v, is_less);

        // Ha a kiválasztott forgási pont megegyezik az előddel, akkor ez a szelet legkisebb eleme.
        // Ossza fel a szeletet olyan elemekre, amelyek egyenlőek és nagyobbak, mint az elfordulás.
        // Ez az eset általában akkor érhető el, ha a szelet sok ismétlődő elemet tartalmaz.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Ha túlléptük az indexünket, akkor jók vagyunk.
                if mid > index {
                    return;
                }

                // Ellenkező esetben folytassa a forgatásnál nagyobb elemek rendezését.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Ossza fel a szeletet `left`, `pivot` és `right`-re.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Ha közép==index, akkor készen vagyunk, mivel az partition() garantálta, hogy a közép után minden elem nagyobb vagy egyenlő, mint a közép.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // A rendezésnek nincs értelmes viselkedése nulla méretű típusoknál.Ne csinálj semmit.
    } else if index == v.len() - 1 {
        // Keresse meg a max elemet, és helyezze a tömb utolsó pozíciójába.
        // Szabadon használhatjuk az `unwrap()`-et itt, mert tudjuk, hogy a v nem lehet üres.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Keresse meg a min elemet, és helyezze a tömb első pozíciójába.
        // Szabadon használhatjuk az `unwrap()`-et itt, mert tudjuk, hogy a v nem lehet üres.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}