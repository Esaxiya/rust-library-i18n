// Eredeti megvalósítás a rust-memchr-től származik.
// Szerzői jog: Andrew Gallant, bluss és Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Csonkolás használata.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Visszaadja az `true` értéket, ha az `x` nulla bájtot tartalmaz.
///
/// From *Matters Computational*, J. Arndt:
///
/// "Az ötlet az, hogy kivonjunk egy-egy bájtból, majd megkeressük azokat a bájtokat, ahol a kölcsön egészen a legjelentősebbé vált
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Visszaadja az `x` bájtnak megfelelő első indexet az `text`-ben.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Gyors út kis szeletekhez
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Egy bájt értéket kereshet egyszerre két `usize` szó beolvasásával.
    //
    // Három részre osztva az `text`-et
    // - ki nem igazított kezdő rész, az első szóval igazított cím előtt a szövegben
    // - test, szkennelés egyszerre 2 szóval
    // - az utolsó hátralévő rész, <2 szóméret

    // keresés egy igazított határig
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // keressen a szöveg törzsében
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // BIZTONSÁG: a while predikátum legalább 2 * usize_byte távolságot garantál
        // a szelet eltolása és vége között.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // törés, ha van egyező bájt
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Keresse meg a bájtot a testhurok leállása után.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Visszaadja az `x` bájtnak megfelelő utolsó indexet az `text`-ben.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Egy bájt értéket kereshet egyszerre két `usize` szó beolvasásával.
    //
    // Az `text` három részből áll:
    // - igazítatlan farok, az utolsó szó igazított cím után a szövegben,
    // - test, egyszerre 2 szóval beolvasva,
    // - az első megmaradt bájt, <2 szóméret.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Ezt csak azért hívjuk, hogy megszerezzük az előtag és az utótag hosszát.
        // Középen mindig két darabot dolgozunk fel egyszerre.
        // BIZTONSÁG: Az `[u8]` átalakítása `[usize]`-re biztonságos, kivéve az `align_to` által kezelt méretbeli különbségeket.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Keressen a szöveg törzsében, és ellenőrizze, hogy nem lépjük-e át a min_aligned_offset értéket.
    // az eltolás mindig igazodik, így az `>` tesztelése elegendő, és elkerüli az esetleges túlcsordulást.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // BIZTONSÁG: az eltolás len, suffix.len() értéknél kezdődik, amennyiben nagyobb, mint
        // min_aligned_offset (prefix.len()) a hátralévő távolság legalább 2 * chunk_byte.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Törd meg, ha van egyező bájt.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Keresse meg a bájtot, mielőtt a testhurok leállna.
    text[..offset].iter().rposition(|elt| *elt == x)
}