//! A szelet iterátorai által használt makrók.

// A beillesztés üres és a len hatalmas teljesítménybeli különbséget jelent
macro_rules! is_empty {
    // Ahogy kódoljuk a ZST iterátor hosszát, ez mind a ZST, mind a nem ZST esetében működik.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// A határellenőrzések megszabadulása érdekében (lásd: `position`) kissé váratlan módon kiszámítjuk a hosszt.
// (A "codegen/slice-position-bounds-check" tesztelte.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // néha nem biztonságos blokkon belül használnak minket

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Ez az _cannot_ azért használja az `unchecked_sub`-et, mert a csomagoláson múlik a hosszú ZST szelet-itátorok hosszának ábrázolása.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Tudjuk, hogy az `start <= end`, tehát jobban teljesíthet, mint az `offset_from`, amelynek aláírással kell foglalkoznia.
            // Megfelelő jelzők beállításával itt elmondhatjuk az LLVM-nek ezt, ami segít eltávolítani a határellenőrzéseket.
            // BIZTONSÁG: Az invariáns típus szerint, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Azzal is, hogy elmondja az LLVM-nek, hogy a mutatók el vannak választva a típusméret pontos többszörösétől, az `len() == 0`-et `(end - start) < size`-ig optimalizálhatja az `(end - start) < size` helyett.
            //
            // BIZTONSÁG: Az invariáns típus szerint a mutatók egymáshoz igazodnak
            //         a köztük lévő távolságnak a pointee méretének többszörösének kell lennie
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Az `Iter` és `IterMut` iterátorok megosztott meghatározása
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Visszaadja az első elemet, és az iterátor elejét 1-vel előre mozgatja.
        // Nagyszerűen javítja a teljesítményt a beágyazott funkcióhoz képest.
        // Az iterátor nem lehet üres.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Visszaadja az utolsó elemet, és az iterátor végét 1-vel hátra mozgatja.
        // Nagyszerűen javítja a teljesítményt a beágyazott funkcióhoz képest.
        // Az iterátor nem lehet üres.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Az iterátor végét `n`-rel hátrafelé mozdítja, ha T jelentése ZST.
        // `n` nem haladhatja meg az `self.len()` értéket.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Segítő funkció szelet létrehozásához az iterátorból.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // BIZTONSÁG: az iterátort egy szeletből, mutatóval hozták létre
                // `self.ptr` és hossza `len!(self)`.
                // Ez garantálja az `from_raw_parts` összes előfeltételének teljesülését.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Segítő funkció az iterátor elejének az `offset` elemekkel történő előre mozgatásához, a régi start visszaadásához.
            //
            // Nem biztonságos, mert az eltolás nem haladhatja meg az `self.len()` értéket.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // BIZTONSÁG: a hívó garantálja, hogy az `offset` nem haladja meg az `self.len()` értéket,
                    // tehát ez az új mutató az `self` belsejében van, és így garantáltan nem null.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Segítő funkció az iterátor végének `offset` elemekkel történő visszafelé mozgatásához, az új vég visszaadásához.
            //
            // Nem biztonságos, mert az eltolás nem haladhatja meg az `self.len()` értéket.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // BIZTONSÁG: a hívó garantálja, hogy az `offset` nem haladja meg az `self.len()` értéket,
                    // ami garantáltan nem fogja túlcsordítani az `isize`-et.
                    // Az eredményül kapott mutató az `slice` határain belül van, amely megfelel az `offset` egyéb követelményeinek.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // szeletekkel megvalósítható, de ez elkerüli a határellenőrzéseket

                // BIZTONSÁG: Az `assume` hívások biztonságban vannak, mivel egy szelet kezdő mutatója van
                // nem null értékűeknek kell lenniük, és a nem ZST-k fölötti szeleteknek nem null végmutatóval kell rendelkezniük.
                // Az `next_unchecked!` hívása biztonságos, mivel először ellenőrizzük, hogy az iterátor üres-e.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Ez az iterátor most üres.
                    if mem::size_of::<T>() == 0 {
                        // Így kell tennünk, mivel az `ptr` soha nem lehet 0, de az `end` lehet (a csomagolás miatt).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // BIZTONSÁG: a vég nem lehet 0, ha T nem ZST, mert a ptr nem 0, és a vég>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // BIZTONSÁG: Korlátozottak vagyunk.Az `post_inc_start` még a ZST-k esetében is helyesen cselekszik.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Felülbíráljuk az alapértelmezett megvalósítást, amely az `try_fold`-et használja, mert ez az egyszerű megvalósítás kevesebb LLVM IR-t generál és gyorsabban lefordítható.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Felülbíráljuk az alapértelmezett megvalósítást, amely az `try_fold`-et használja, mert ez az egyszerű megvalósítás kevesebb LLVM IR-t generál és gyorsabban lefordítható.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Felülbíráljuk az alapértelmezett megvalósítást, amely az `try_fold`-et használja, mert ez az egyszerű megvalósítás kevesebb LLVM IR-t generál és gyorsabban lefordítható.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Felülbíráljuk az alapértelmezett megvalósítást, amely az `try_fold`-et használja, mert ez az egyszerű megvalósítás kevesebb LLVM IR-t generál és gyorsabban lefordítható.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Felülbíráljuk az alapértelmezett megvalósítást, amely az `try_fold`-et használja, mert ez az egyszerű megvalósítás kevesebb LLVM IR-t generál és gyorsabban lefordítható.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Felülbíráljuk az alapértelmezett megvalósítást, amely az `try_fold`-et használja, mert ez az egyszerű megvalósítás kevesebb LLVM IR-t generál és gyorsabban lefordítható.
            // Ezenkívül az `assume` elkerüli a határellenőrzést.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // BIZTONSÁG: garantáltan határt szabunk a hurokvariánsnak:
                        // amikor `i >= n`, az `self.next()` visszaadja az `None` értéket, és a hurok megszakad.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Felülbíráljuk az alapértelmezett megvalósítást, amely az `try_fold`-et használja, mert ez az egyszerű megvalósítás kevesebb LLVM IR-t generál és gyorsabban lefordítható.
            // Ezenkívül az `assume` elkerüli a határellenőrzést.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // BIZTONSÁG: Az `i`-nek alacsonyabbnak kell lennie, mint az `n`, mivel `n`-től kezdődik
                        // és csak csökken.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // BIZTONSÁG: a hívónak garantálnia kell, hogy az `i` határértékei vannak
                // az alapul szolgáló szelet, így az `i` nem tudja túlcsordítani az `isize`-et, és a visszaküldött hivatkozások garantáltan a szelet valamely elemére vonatkoznak, és így garantáltan érvényesek.
                //
                // Vegye figyelembe azt is, hogy a hívó fél garantálja azt is, hogy soha többé nem ugyanazzal az indexkel hívnak minket, és hogy nem hívnak más metódusokat, amelyek elérik ezt az alszeletet, ezért érvényes, hogy a visszaküldött hivatkozás mutálható legyen
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // szeletekkel megvalósítható, de ez elkerüli a határellenőrzéseket

                // BIZTONSÁG: Az `assume` hívások biztonságosak, mivel egy szelet kezdő mutatójának nem nullnak kell lennie,
                // és a nem ZST-k fölötti szeleteknek szintén nem null végmutatóval kell rendelkezniük.
                // Az `next_back_unchecked!` hívása biztonságos, mivel először ellenőrizzük, hogy az iterátor üres-e.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Ez az iterátor most üres.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // BIZTONSÁG: Korlátozottak vagyunk.Az `pre_dec_end` még a ZST-k esetében is helyesen cselekszik.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}