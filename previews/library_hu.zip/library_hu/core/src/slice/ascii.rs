//! Műveletek az ASCII `[u8]` készüléken.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Ellenőrzi, hogy a szelet összes bájtja az ASCII tartományon belül van-e.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Ellenőrzi, hogy két szelet ASCII-es kis-és nagybetű-e.
    ///
    /// Ugyanaz, mint az `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, de anélkül, hogy kiosztanánk és másolnánk az időbeli elemeket.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Ezt a szeletet az ASCII nagybetűvel egyenértékűvé konvertálja.
    ///
    /// Az 'a'-'z' ASCII betűk 'A'-'Z'-hez vannak társítva, de a nem ASCII-betűk változatlanok.
    ///
    /// Ha új felsőbetűs értéket szeretne visszaadni a meglévő módosítása nélkül, használja az [`to_ascii_uppercase`] parancsot.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Ezt a szeletet az ASCII kisbetűvel egyenértékűvé konvertálja.
    ///
    /// Az 'A'-'Z' ASCII betűk 'a'-'z'-hez vannak társítva, de a nem ASCII-betűk változatlanok.
    ///
    /// Ha új, kisbetűs értéket szeretne visszaadni a meglévő módosítása nélkül, használja az [`to_ascii_lowercase`] parancsot.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Visszaadja az `true` értéket, ha az `v` szó bármely bájtja nonascii (>=128).
/// Snarfed az `../str/mod.rs`-ből, amely valami hasonlót csinál az utf8 érvényesítéshez.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Optimalizált ASCII teszt, amely egyszerre használja a műveleteket a byte-at-time műveletek helyett (ha lehetséges).
///
/// Az itt használt algoritmus nagyon egyszerű.Ha az `s` túl rövid, csak ellenőrizzük az egyes bájtokat, és készen vagyunk vele.Másképp:
///
/// - Olvassa el az első szót kiegyenlítetlen terheléssel.
/// - Igazítsa a mutatót, olvassa el a következő szavakat a végére igazított terhelésekkel.
/// - Olvassa el az utolsó `usize`-et az `s`-ből, igazítatlan terheléssel.
///
/// Ha ezen terhelések bármelyike olyan eredményt eredményez, amelyre az `contains_nonascii` (above) igaz, akkor tudjuk, hogy a válasz hamis.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Ha nem nyerünk semmit az egyszeri szó megvalósításból, akkor térjünk vissza egy skalár hurokra.
    //
    // Tesszük ezt olyan architektúrák esetében is, ahol az `size_of::<usize>()` nem elegendő az `usize` beállításához, mert ez egy furcsa edge eset.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Az első szót mindig igazítás nélkül olvassuk, ami azt jelenti, hogy az `align_offset` az
    // 0, ugyanazt az értéket olvassuk újra az igazított olvasáshoz.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // BIZTONSÁG: A fenti `len < USIZE_SIZE`-et ellenőrizzük.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Ezt fentebb némi implicit módon ellenőriztük.
    // Ne feledje, hogy az `offset_to_aligned` vagy `align_offset`, vagy `USIZE_SIZE`, mindkettőt kifejezetten ellenőrizzük a fentiekben.
    //
    debug_assert!(offset_to_aligned <= len);

    // BIZTONSÁG: A word_ptr az a (megfelelően igazított) usize ptr, amelyet a
    // a szelet középső része.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` az `word_ptr` byte indexe, amelyet a hurok végének ellenőrzésére használnak.
    let mut byte_pos = offset_to_aligned;

    // A paranoia ellenőrzi az igazodást, mivel egy rakás kiegyenlítetlen terhelést fogunk végezni.
    // A gyakorlatban ennek lehetetlennek kell lennie az `align_offset` hibájának megakadályozásával.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Olvassa el a következő szavakat az utolsó igazított szóig, kivéve az utolsó igazított szót, amelyet később a farokellenőrzés során el kell végezni, hogy a farok mindig legfeljebb egy `usize` legyen az extra branch `byte_pos == len` értékig.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // A józan ész ellenőrzése, hogy az olvasás korlátok között van-e
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // És hogy az `byte_pos`-re vonatkozó feltételezéseink érvényesek.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // BIZTONSÁG: Tudjuk, hogy az `word_ptr` megfelelően illeszkedik (a. Miatt)
        // `align_offset`), és tudjuk, hogy van elegendő bájtunk az `word_ptr` és a vége között
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // BIZTONSÁG: Tudjuk, hogy az `byte_pos <= len - USIZE_SIZE`, ami azt jelenti
        // ez után az `add` után az `word_ptr` legfeljebb egy a végén lesz.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Egészségügyi ellenőrzés, hogy valóban csak egy marad-e az `usize`.
    // Ezt a hurok állapotunkkal kell garantálni.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // BIZTONSÁG: Ez az `len >= USIZE_SIZE`-re támaszkodik, amelyet az elején ellenőrizünk.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}