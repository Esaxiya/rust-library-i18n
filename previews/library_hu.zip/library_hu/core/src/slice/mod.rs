// ignore-tidy-filelength

//! Szeletkezelés és manipuláció.
//!
//! További részletek: [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Tiszta rust memchr megvalósítás, a rust-memchr-ből származik
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Ez a funkció csak azért nyilvános, mert a heapsort tesztelésére nincs más mód.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Visszaadja a szelet elemeinek számát.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // BIZTONSÁG: const hang, mert a hosszúság mezőt felhasználásként alakítjuk át (aminek lennie kell)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // BIZTONSÁG: Ez biztonságos, mert az `&[T]` és az `FatPtr<T>` azonos elrendezésű.
            // Csak az `std` vállalhatja ezt a garanciát.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Cserélje `crate::ptr::metadata(self)`-re, ha ez állandó.
            // Ez az írás "Const-stable functions can only call other const-stable functions" hibát okoz.
            //

            // BIZTONSÁG: Az érték elérése az `PtrRepr` unióból biztonságos, mivel * const T
            // és a PtrComponents<T>ugyanazokkal a memóriaelrendezésekkel rendelkezik.
            // Csak a std teheti ezt a garanciát.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// `true` értéket ad vissza, ha a szelet hossza 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Visszaadja a szelet első elemét, vagy `None`-et, ha üres.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Változtatható mutatót ad vissza a szelet első eleméhez, vagy `None`-hez, ha üres.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Visszaadja a szelet első és összes többi elemét, vagy ha `None` üres.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Visszaadja a szelet első és összes többi elemét, vagy ha `None` üres.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Visszaadja a szelet utolsó és az összes többi elemét, vagy ha `None` üres.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Visszaadja a szelet utolsó és az összes többi elemét, vagy ha `None` üres.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Visszaadja a szelet utolsó elemét, vagy `None`-et, ha üres.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Változtatható mutatót ad vissza a szelet utolsó eleméhez.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Visszaad egy hivatkozást egy elemre vagy alszeletre, az index típusától függően.
    ///
    /// - Ha megad egy pozíciót, akkor az adott helyzetben lévő elemre utal, vagy ha határon kívül van, akkor az `None` hivatkozást adja meg.
    ///
    /// - Ha megad egy tartományt, akkor az adott tartománynak megfelelő alszeletet adja vissza, vagy ha határon kívül esik, akkor az `None` értéket.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Az index típusától (lásd az [`get`]) függvényében egy elemre vagy alszeletre mutábilis hivatkozást ad vissza, vagy ha az index határon kívül van, akkor az `None` értéket.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Visszaad egy elemre vagy alszeletre mutató hivatkozást, anélkül, hogy korlátozásokat végezne.
    ///
    /// A biztonságos alternatívát lásd: [`get`].
    ///
    /// # Safety
    ///
    /// Ha ezt a módszert határon kívüli indexszel hívjuk meg,*[undefined viselkedés]* még akkor is, ha a kapott referenciát nem használjuk.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // BIZTONSÁG: a hívónak be kell tartania az `get_unchecked` biztonsági követelményeinek nagy részét;
        // a szeletre hivatkozni lehet, mert az `self` biztonságos referencia.
        // A visszaküldött mutató biztonságos, mert az `SliceIndex` implicitjeinek garantálniuk kell, hogy az.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Egy elemre vagy alszeletre mutatható hivatkozást ad vissza, a határellenőrzés elvégzése nélkül.
    ///
    /// A biztonságos alternatívát lásd: [`get_mut`].
    ///
    /// # Safety
    ///
    /// Ha ezt a módszert határon kívüli indexszel hívjuk meg,*[undefined viselkedés]* még akkor is, ha a kapott referenciát nem használjuk.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // BIZTONSÁG: a hívónak be kell tartania az `get_unchecked_mut` biztonsági követelményeit;
        // a szeletre hivatkozni lehet, mert az `self` biztonságos referencia.
        // A visszaküldött mutató biztonságos, mert az `SliceIndex` implicitjeinek garantálniuk kell, hogy az.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Visszaad egy nyers mutatót a szelet pufferjébe.
    ///
    /// A hívónak meg kell győződnie arról, hogy a szelet meghaladja-e azt a mutatót, amelyet ez a függvény visszaad, különben a szemétre mutat.
    ///
    /// A hívónak gondoskodnia kell arról is, hogy az (non-transitively) mutató által tárolt memória soha ne legyen írva (kivéve az `UnsafeCell` belsejét) ezzel a mutatóval vagy az abból származó bármely mutatóval.
    /// Ha módosítania kell a szelet tartalmát, használja az [`as_mut_ptr`]-et.
    ///
    /// Az e szelet által hivatkozott tároló módosítása pufferének átcsoportosítását okozhatja, ami érvénytelenítené a rá mutató hivatkozásokat is.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Visszaad egy nem biztonságos módosítható mutatót a szelet pufferjébe.
    ///
    /// A hívónak meg kell győződnie arról, hogy a szelet meghaladja-e azt a mutatót, amelyet ez a függvény visszaad, különben a szemétre mutat.
    ///
    /// Az e szelet által hivatkozott tároló módosítása pufferének átcsoportosítását okozhatja, ami érvénytelenítené a rá mutató hivatkozásokat is.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Visszaadja a szeleten átívelő két nyers mutatót.
    ///
    /// A visszaküldött tartomány félig nyitott, ami azt jelenti, hogy a végmutató *egy szálon* a szelet utolsó elemén mutat.
    /// Így egy üres szeletet két egyenlő mutató képvisel, a két mutató közötti különbség pedig a szelet méretét jelenti.
    ///
    /// A mutatók használatára vonatkozó figyelmeztetéseket az [`as_ptr`] részben találja.A végmutató fokozott óvatosságot igényel, mivel nem mutat egy érvényes elemet a szeletben.
    ///
    /// Ez a funkció hasznos az idegen interfészekkel való interakcióhoz, amelyek két mutatót használnak a memóriában található elemek egy részének hivatkozására, amint az a C++ -nál megszokott.
    ///
    ///
    /// Hasznos lehet annak ellenőrzése is, hogy egy elemre mutató mutató utal-e a szelet elemére:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // BIZTONSÁG: Az `add` itt biztonságos, mert:
        //
        //   - Mindkét mutató ugyanannak az objektumnak a része, mivel a közvetlenül az objektum mellett történő mutató is számít.
        //
        //   - A szelet mérete soha nem nagyobb, mint az isize::MAX bájt, amint azt itt megjegyeztük:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Az érintettek köré nincs tekercselés, mivel a szeletek nem tekerednek át a címtér végén.
        //
        // Lásd az pointer::add dokumentációját.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Visszaadja a szeleten átívelő két nem biztonságos, módosítható mutatót.
    ///
    /// A visszaküldött tartomány félig nyitott, ami azt jelenti, hogy a végmutató *egy szálon* a szelet utolsó elemén mutat.
    /// Így egy üres szeletet két egyenlő mutató képvisel, a két mutató közötti különbség pedig a szelet méretét jelenti.
    ///
    /// A mutatók használatára vonatkozó figyelmeztetéseket az [`as_mut_ptr`] részben találja.
    /// A végmutató fokozott óvatosságot igényel, mivel nem mutat egy érvényes elemet a szeletben.
    ///
    /// Ez a funkció hasznos az idegen interfészekkel való interakcióhoz, amelyek két mutatót használnak a memóriában található elemek egy részének hivatkozására, amint az a C++ -nál megszokott.
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // BIZTONSÁG: Lásd a fenti as_ptr_range()-et, hogy miért biztonságos itt az `add`.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Két elemet cserél a szeletben.
    ///
    /// # Arguments
    ///
    /// * a, Az első elem mutatója
    /// * b, A második elem mutatója
    ///
    /// # Panics
    ///
    /// Panics, ha az `a` vagy `b` határon kívül esik.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Két felvehető kölcsön nem vehető fel egy vector-től, ezért inkább használjon nyers mutatókat.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // BIZTONSÁG: Az `pa` és `pb` biztonságos, mutábilis hivatkozásokból lettek létrehozva és hivatkoznak
        // a szelet elemeihez, ezért garantáltan érvényesek és igazodnak.
        // Ne feledje, hogy az `a` és `b` mögött lévő elemek elérése be van jelölve, és ha nem lépi túl a panic értéket.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Megfordítja az elemek sorrendjét a szeletben, a helyén.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Nagyon kicsi típusok esetén az összes, a normál úton olvasott személy rosszul teljesít.
        // Jobban járhatunk, ha a hatékony, nem igazított load/store-et vesszük, ha nagyobb darabot töltünk be, és egy nyilvántartást megfordítunk.
        //

        // Ideális esetben az LLVM ezt megtenné helyettünk, mivel nálunk jobban tudja, hogy a nem igazított olvasások hatékonyak-e (mivel ez például változik a különböző ARM verziók között), és mi lenne a legjobb darabméret.
        // Sajnos az LLVM 4.0 (2017-05)-től kezdve csak a hurkot bontja ki, ezért ezt nekünk magunknak kell megtenni.
        // (Hipotézis: a hátramenet problémás, mert az oldalak eltérően igazíthatók-akkor lesznek, ha a hossz páratlan-, így nincs mód elő-és utójelek kibocsátására, hogy középen teljesen igazított SIMD-t használhassunk.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Használja az llvm.bswap intrinsic-et az u8-ok megfordításához egy usize-ben
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // BIZTONSÁG: Itt több dolgot ellenőrizhet:
                //
                // - Vegye figyelembe, hogy az `chunk` értéke 4 vagy 8 a fenti cfg ellenőrzés miatt.Tehát az `chunk - 1` pozitív.
                // - Az indexelés az `i` indexszel rendben van, mivel a hurokellenőrzés garantálja
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Az indexelés az `ln - i - chunk = ln - (i + chunk)` indexszel rendben van:
                //   - `i + chunk > 0` triviálisan igaz.
                //   - A hurokellenőrzés garantálja:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, így a kivonás nem alulfolyik.
                // - Az `read_unaligned` és `write_unaligned` hívások rendben vannak:
                //   - `pa` az `i` indexre mutat, ahol az `i < ln / 2 - (chunk - 1)` (lásd fent) és az `pb` az `ln - i - chunk` indexre mutat, tehát mindkettő legalább `chunk`, sok bájttal az `self` végétől.
                //
                //   - Bármely inicializált memória érvényes `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Használja a 16-os forgatást az u16-ok megfordításához u32-ben
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // BIZTONSÁG: Ha egy `i + 1 < ln`-t használ, akkor egy ki nem igazított u32 leolvasható az `i`-ről
                // (és nyilván `i < ln`), mert minden elem 2 bájt, és 4-et olvasunk.
                //
                // `i + chunk - 1 < ln / 2` # míg feltétel
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Mivel ez kisebb, mint a hossza elosztva 2-vel, akkor határoknak kell lennie.
                //
                // Ez azt is jelenti, hogy az `0 < i + chunk <= ln` feltételt mindig betartják, biztosítva az `pb` mutató biztonságos használatát.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // BIZTONSÁG: Az `i` alacsonyabb, mint a szelet hosszának a fele
            // Az `i` és `ln - i - 1` elérése biztonságos (az `i` 0-tól kezdődik, és nem megy tovább `ln / 2 - 1`-nél).
            // Az így kapott `pa` és `pb` mutatók ezért érvényesek és igazítottak, és onnan olvashatók és írhatók oda.
            //
            //
            unsafe {
                // Nem biztonságos csere a határok elkerülése érdekében ellenőrizze a biztonságos cserét.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Ismétlőt ad vissza a szelet fölött.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Olyan iterátort ad vissza, amely lehetővé teszi az egyes értékek módosítását.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Iterátort ad vissza az összes összefüggő `size` hosszúságra.
    /// Az windows átfedésben van.
    /// Ha a szelet rövidebb, mint `size`, az iterátor nem ad vissza értéket.
    ///
    /// # Panics
    ///
    /// Panics ha `size` értéke 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ha a szelet rövidebb, mint `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Egy iterátort ad vissza a szelet `chunk_size` elemei felett egyszerre, a szelet elejétől kezdve.
    ///
    /// A darabok szeletek és nem fedik egymást.Ha az `chunk_size` nem osztja fel a szelet hosszát, akkor az utolsó darab nem lesz `chunk_size` hosszú.
    ///
    /// Lásd: [`chunks_exact`] ennek az iterátornak egy változatát, amely mindig pontosan `chunk_size` elemek darabjait adja vissza, és az [`rchunks`] ugyanazon iterátorhoz, de a szelet végén kezdődik.
    ///
    ///
    /// # Panics
    ///
    /// Panics ha `chunk_size` értéke 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Egy iterátort ad vissza a szelet `chunk_size` elemei felett egyszerre, a szelet elejétől kezdve.
    ///
    /// A darabok változtatható szeletek, és nem fedik egymást.Ha az `chunk_size` nem osztja fel a szelet hosszát, akkor az utolsó darab nem lesz `chunk_size` hosszú.
    ///
    /// Lásd: [`chunks_exact_mut`] ennek az iterátornak egy változatát, amely mindig pontosan `chunk_size` elemek darabjait adja vissza, és az [`rchunks_mut`] ugyanazon iterátorhoz, de a szelet végén kezdődik.
    ///
    ///
    /// # Panics
    ///
    /// Panics ha `chunk_size` értéke 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Egy iterátort ad vissza a szelet `chunk_size` elemei felett egyszerre, a szelet elejétől kezdve.
    ///
    /// A darabok szeletek és nem fedik egymást.
    /// Ha az `chunk_size` nem osztja fel a szelet hosszát, akkor az utolsó legfeljebb `chunk_size-1` elem kihagyásra kerül, és az iterátor `remainder` funkciójából nyerhető be.
    ///
    ///
    /// Mivel minden egyes darabnak pontosan `chunk_size` elemei vannak, a fordító gyakran jobban tudja optimalizálni a kapott kódot, mint az [`chunks`] esetében.
    ///
    /// Lásd az [`chunks`]-et az iterátor egy változatához, amely a maradékot kisebb darabként is visszaadja, és az [`rchunks_exact`]-et ugyanahhoz az iterátorhoz, de a szelet végén kezdődik.
    ///
    /// # Panics
    ///
    /// Panics ha `chunk_size` értéke 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Egy iterátort ad vissza a szelet `chunk_size` elemei felett egyszerre, a szelet elejétől kezdve.
    ///
    /// A darabok változtatható szeletek, és nem fedik egymást.
    /// Ha az `chunk_size` nem osztja fel a szelet hosszát, akkor az utolsó legfeljebb `chunk_size-1` elem kihagyásra kerül, és az iterátor `into_remainder` funkciójából nyerhető be.
    ///
    ///
    /// Mivel minden egyes darabnak pontosan `chunk_size` elemei vannak, a fordító gyakran jobban tudja optimalizálni a kapott kódot, mint az [`chunks_mut`] esetében.
    ///
    /// Lásd az [`chunks_mut`]-et az iterátor egy változatához, amely a maradékot kisebb darabként is visszaadja, és az [`rchunks_exact_mut`]-et ugyanahhoz az iterátorhoz, de a szelet végén kezdődik.
    ///
    /// # Panics
    ///
    /// Panics ha `chunk_size` értéke 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Felosztja a szeletet egy "N" elem tömb szeletre, feltételezve, hogy nincs maradék.
    ///
    ///
    /// # Safety
    ///
    /// Ez csak akkor hívható fel, amikor
    /// - A szelet pontosan "N" elemekre oszlik (más néven `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // BIZTONSÁG: Az 1 elemű darabok soha nem rendelkeznek maradékkal
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // BIZTONSÁG: Az (6) szelet hossza 3-szorosa
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Ezek megalapozatlanok lennének:
    /// // darabokat engedjen: &[[_;5]]= slice.as_chunks_unchecked()//A szelet hossza nem több, mint 5 letett darab:&[[_;0]]= slice.as_chunks_unchecked()//Nulla hosszúságú darabok soha nem megengedettek
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // BIZTONSÁG: Az előfeltételünk pontosan az, amire szükségünk van
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // BIZTONSÁG: Egy szelet `new_len * N` elemet öntöttünk bele
        // egy szelet `new_len` sok `N` elem darab.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Felosztja a szeletet egy " N` elemű tömb szeletre, a szelet elejétől kezdve, és egy szeletet, amelynek hossza szigorúan kisebb, mint `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ha az `N` értéke 0. Ez az ellenőrzés nagy valószínűséggel fordítási időre változik, mielőtt ez a módszer stabilizálódna.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // BIZTONSÁG: A nulla már pánikba esett, és az építkezés biztosította
        // hogy az alszelet hossza N többszöröse.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Felosztja a szeletet egy "N" elem tömb szeletre, kezdve a szelet végén, és egy szeletet, amelynek hossza szigorúan kisebb, mint `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ha az `N` értéke 0. Ez az ellenőrzés nagy valószínűséggel fordítási időre változik, mielőtt ez a módszer stabilizálódna.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // BIZTONSÁG: A nulla már pánikba esett, és az építkezés biztosította
        // hogy az alszelet hossza N többszöröse.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Egy iterátort ad vissza a szelet `N` elemei felett egyszerre, a szelet elejétől kezdve.
    ///
    /// A darabok tömb referenciák és nem fedik egymást.
    /// Ha az `N` nem osztja fel a szelet hosszát, akkor az utolsó legfeljebb `N-1` elem kihagyásra kerül, és az iterátor `remainder` funkciójából nyerhető be.
    ///
    ///
    /// Ez a módszer az [`chunks_exact`] konst generikus megfelelője.
    ///
    /// # Panics
    ///
    /// Panics, ha az `N` értéke 0. Ez az ellenőrzés nagy valószínűséggel fordítási időre változik, mielőtt ez a módszer stabilizálódna.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Felosztja a szeletet egy "N" elem tömb szeletre, feltételezve, hogy nincs maradék.
    ///
    ///
    /// # Safety
    ///
    /// Ez csak akkor hívható fel, amikor
    /// - A szelet pontosan "N" elemekre oszlik (más néven `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // BIZTONSÁG: Az 1 elemű darabok soha nem rendelkeznek maradékkal
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // BIZTONSÁG: Az (6) szelet hossza 3-szorosa
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Ezek megalapozatlanok lennének:
    /// // darabokat engedjen: &[[_;5]]= slice.as_chunks_unchecked_mut()//A szelet hossza nem több, mint 5 letett darab:&[[_;0]]= slice.as_chunks_unchecked_mut()//Nulla hosszúságú darabok soha nem megengedettek
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // BIZTONSÁG: Az előfeltételünk pontosan az, amire szükségünk van
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // BIZTONSÁG: Egy szelet `new_len * N` elemet öntöttünk bele
        // egy szelet `new_len` sok `N` elem darab.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Felosztja a szeletet egy " N` elemű tömb szeletre, a szelet elejétől kezdve, és egy szeletet, amelynek hossza szigorúan kisebb, mint `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ha az `N` értéke 0. Ez az ellenőrzés nagy valószínűséggel fordítási időre változik, mielőtt ez a módszer stabilizálódna.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // BIZTONSÁG: A nulla már pánikba esett, és az építkezés biztosította
        // hogy az alszelet hossza N többszöröse.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Felosztja a szeletet egy "N" elem tömb szeletre, kezdve a szelet végén, és egy szeletet, amelynek hossza szigorúan kisebb, mint `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ha az `N` értéke 0. Ez az ellenőrzés nagy valószínűséggel fordítási időre változik, mielőtt ez a módszer stabilizálódna.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // BIZTONSÁG: A nulla már pánikba esett, és az építkezés biztosította
        // hogy az alszelet hossza N többszöröse.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Egy iterátort ad vissza a szelet `N` elemei felett egyszerre, a szelet elejétől kezdve.
    ///
    /// A darabok változtatható tömb hivatkozások, és nem fedik egymást.
    /// Ha az `N` nem osztja fel a szelet hosszát, akkor az utolsó legfeljebb `N-1` elem kihagyásra kerül, és az iterátor `into_remainder` funkciójából nyerhető be.
    ///
    ///
    /// Ez a módszer az [`chunks_exact_mut`] konst generikus megfelelője.
    ///
    /// # Panics
    ///
    /// Panics, ha az `N` értéke 0. Ez az ellenőrzés nagy valószínűséggel fordítási időre változik, mielőtt ez a módszer stabilizálódna.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Visszaad egy iterátort a szelet `N` elemeinek windows átfedése felett, a szelet elejétől kezdve.
    ///
    ///
    /// Ez az [`windows`] konst generikus megfelelője.
    ///
    /// Ha az `N` nagyobb, mint a szelet mérete, akkor nem ad vissza windows értéket.
    ///
    /// # Panics
    ///
    /// Panics ha `N` értéke 0.
    /// Ez az ellenőrzés nagy valószínűséggel fordítási időre vált, mielőtt ez a módszer stabilizálódna.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Egy iterátort ad vissza a szelet `chunk_size` elemei felett egyszerre, a szelet végétől kezdve.
    ///
    /// A darabok szeletek és nem fedik egymást.Ha az `chunk_size` nem osztja fel a szelet hosszát, akkor az utolsó darab nem lesz `chunk_size` hosszú.
    ///
    /// Lásd az [`rchunks_exact`]-et ennek az iterátornak egy változatáról, amely mindig pontosan `chunk_size` elemek darabjait adja vissza, és az [`chunks`] azonos iterátorokhoz, de a szelet elején kezdődik.
    ///
    ///
    /// # Panics
    ///
    /// Panics ha `chunk_size` értéke 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Egy iterátort ad vissza a szelet `chunk_size` elemei felett egyszerre, a szelet végétől kezdve.
    ///
    /// A darabok változtatható szeletek, és nem fedik egymást.Ha az `chunk_size` nem osztja fel a szelet hosszát, akkor az utolsó darab nem lesz `chunk_size` hosszú.
    ///
    /// Lásd az [`rchunks_exact_mut`]-et ennek az iterátornak egy változatáról, amely mindig pontosan `chunk_size` elemek darabjait adja vissza, és az [`chunks_mut`] azonos iterátorokhoz, de a szelet elején kezdődik.
    ///
    ///
    /// # Panics
    ///
    /// Panics ha `chunk_size` értéke 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Egy iterátort ad vissza a szelet `chunk_size` elemei felett egyszerre, a szelet végétől kezdve.
    ///
    /// A darabok szeletek és nem fedik egymást.
    /// Ha az `chunk_size` nem osztja fel a szelet hosszát, akkor az utolsó legfeljebb `chunk_size-1` elem kihagyásra kerül, és az iterátor `remainder` funkciójából nyerhető be.
    ///
    /// Mivel minden egyes darabnak pontosan `chunk_size` elemei vannak, a fordító gyakran jobban tudja optimalizálni a kapott kódot, mint az [`chunks`] esetében.
    ///
    /// Lásd az [`rchunks`]-et ennek az iterátornak egy olyan változatához, amely a maradékot szintén kisebb darabként adja vissza, és az [`chunks_exact`]-et ugyanahhoz az iterátorhoz, de a szelet elején kezdődik.
    ///
    ///
    /// # Panics
    ///
    /// Panics ha `chunk_size` értéke 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Egy iterátort ad vissza a szelet `chunk_size` elemei felett egyszerre, a szelet végétől kezdve.
    ///
    /// A darabok változtatható szeletek, és nem fedik egymást.
    /// Ha az `chunk_size` nem osztja fel a szelet hosszát, akkor az utolsó legfeljebb `chunk_size-1` elem kihagyásra kerül, és az iterátor `into_remainder` funkciójából nyerhető be.
    ///
    /// Mivel minden egyes darabnak pontosan `chunk_size` elemei vannak, a fordító gyakran jobban tudja optimalizálni a kapott kódot, mint az [`chunks_mut`] esetében.
    ///
    /// Lásd az [`rchunks_mut`]-et az iterátor egy változatához, amely a maradékot kisebb darabként is visszaadja, és az [`chunks_exact_mut`]-et ugyanahhoz az iterátorhoz, de a szelet elején kezdődik.
    ///
    ///
    /// # Panics
    ///
    /// Panics ha `chunk_size` értéke 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Ismétlőt ad vissza a szelet fölött, amelyek nem átfedő elemfutamokat hoznak létre, az elkülönítésükre az állítmány használatával.
    ///
    /// Az állítmányt két, önmagukat követő elemre hívják meg, ez azt jelenti, hogy az állítmányt `slice[0]`-en és `slice[1]`-en, majd `slice[1]`-en és `slice[2]`-en hívják, és így tovább.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ezzel a módszerrel kiválasztható a rendezett alszeletek:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Ismétlőt ad vissza a szelet fölött, amelyek nem átfedő, mutálható elemfutamokat eredményeznek az elkülönítésre szolgáló predikátum használatával.
    ///
    /// Az állítmányt két, önmagukat követő elemre hívják meg, ez azt jelenti, hogy az állítmányt `slice[0]`-en és `slice[1]`-en, majd `slice[1]`-en és `slice[2]`-en hívják, és így tovább.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ezzel a módszerrel kiválasztható a rendezett alszeletek:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Egy szeletet ketté oszt egy indexben.
    ///
    /// Az első az `[0, mid)` összes indexét tartalmazza (kivéve magát az `mid` indexet), a második pedig az `[mid, len)` összes indexét (kivéve magát az `len` indexet).
    ///
    ///
    /// # Panics
    ///
    /// Panics ha `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // BIZTONSÁG: Az `[ptr; mid]` és az `[mid; len]` az `self` belsejében található
        // megfelel az `from_raw_parts_mut` követelményeinek.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Egy mutálható szeletet ketté oszt egy indexben.
    ///
    /// Az első az `[0, mid)` összes indexét tartalmazza (kivéve magát az `mid` indexet), a második pedig az `[mid, len)` összes indexét (kivéve magát az `len` indexet).
    ///
    ///
    /// # Panics
    ///
    /// Panics ha `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // BIZTONSÁG: Az `[ptr; mid]` és az `[mid; len]` az `self` belsejében található
        // megfelel az `from_raw_parts_mut` követelményeinek.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Oszt egy indexet kettőre egy indexben, anélkül, hogy határellenőrzést végezne.
    ///
    /// Az első az `[0, mid)` összes indexét tartalmazza (kivéve magát az `mid` indexet), a második pedig az `[mid, len)` összes indexét (kivéve magát az `len` indexet).
    ///
    ///
    /// A biztonságos alternatívát lásd: [`split_at`].
    ///
    /// # Safety
    ///
    /// Ha ezt a módszert határon kívüli indexszel hívjuk meg,*[undefined viselkedés]* még akkor is, ha a kapott referenciát nem használjuk.A hívónak biztosítania kell, hogy az `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // BIZTONSÁG: A hívónak ellenőriznie kell, hogy az `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Egy mutálható szeletet ketté oszt egy indexnél, anélkül, hogy határellenőrzést végezne.
    ///
    /// Az első az `[0, mid)` összes indexét tartalmazza (kivéve magát az `mid` indexet), a második pedig az `[mid, len)` összes indexét (kivéve magát az `len` indexet).
    ///
    ///
    /// A biztonságos alternatívát lásd: [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Ha ezt a módszert határon kívüli indexszel hívjuk meg,*[undefined viselkedés]* még akkor is, ha a kapott referenciát nem használjuk.A hívónak biztosítania kell, hogy az `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // BIZTONSÁG: A hívónak ellenőriznie kell, hogy az `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` és az `[mid; len]` nem fedik egymást, ezért a mutábilis referencia visszaadása rendben van.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Iterátort ad vissza az `pred`-nek megfelelő elemekkel elválasztott alszelvényeken.
    /// Az egyező elemet nem tartalmazzák az alszelvények.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ha az első elem egyezik, akkor egy üres szelet lesz az első elem, amelyet az iterátor visszaad.
    /// Hasonlóképpen, ha a szelet utolsó eleme megegyezik, akkor egy üres szelet lesz az utolsó elem, amelyet az iterátor visszaad:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ha két egyeztetett elem közvetlenül szomszédos, akkor üres szelet lesz közöttük:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Az `pred`-nek megfelelő elemekkel elválasztott, módosítható alszelvényeken ismétlődést ad vissza.
    /// Az egyező elemet nem tartalmazzák az alszelvények.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Iterátort ad vissza az `pred`-nek megfelelő elemekkel elválasztott alszelvényeken.
    /// Az egyező elem az előző alszelet végén található, mint terminátor.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ha a szelet utolsó eleme megegyezik, akkor ez az elem az előző szelet végzőjének számít.
    ///
    /// Ez a szelet lesz az utolsó tétel, amelyet az iterátor visszaad.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Az `pred`-nek megfelelő elemekkel elválasztott, módosítható alszelvényeken ismétlődést ad vissza.
    /// Az egyező elemet az előző alszelet tartalmazza terminátorként.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Iterátort ad vissza az `pred`-nek megfelelő elemekkel elválasztott alszelvények fölött, a szelet végétől kezdve és visszafelé haladva.
    /// Az egyező elemet nem tartalmazzák az alszelvények.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Az `split()`-hez hasonlóan, ha az első vagy az utolsó elem egyezik, egy üres szelet lesz az első (vagy utolsó) elem, amelyet az iterátor visszaad.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Ismétlőt ad vissza az `pred`-nek megfelelő elemekkel elválasztott, módosítható alszelvények felett, a szelet végétől kezdve és visszafelé haladva.
    /// Az egyező elemet nem tartalmazzák az alszelvények.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Iterátort ad vissza az `pred`-nek megfelelő elemekkel elválasztott alszelvények felett, legfeljebb `n` elemek visszaadására korlátozva.
    /// Az egyező elemet nem tartalmazzák az alszelvények.
    ///
    /// Az utolsó visszaküldött elem, ha van ilyen, a szelet maradékát fogja tartalmazni.
    ///
    /// # Examples
    ///
    /// Nyomtassa ki egyszerre a szeletet 3-mal osztható számokkal (pl. `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Iterátort ad vissza az `pred`-nek megfelelő elemekkel elválasztott alszelvények felett, legfeljebb `n` elemek visszaadására korlátozva.
    /// Az egyező elemet nem tartalmazzák az alszelvények.
    ///
    /// Az utolsó visszaküldött elem, ha van ilyen, a szelet maradékát fogja tartalmazni.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Iterátort ad vissza olyan alszelvényeken, amelyeket olyan elemek választanak el egymástól, amelyek megfelelnek az `pred`-nek, legfeljebb `n`-es elemek visszaküldésére.
    /// Ez a szelet végén kezdődik és visszafelé működik.
    /// Az egyező elemet nem tartalmazzák az alszelvények.
    ///
    /// Az utolsó visszaküldött elem, ha van ilyen, a szelet maradékát fogja tartalmazni.
    ///
    /// # Examples
    ///
    /// Nyomtassa ki a szeletfelosztást egyszer, a végétől kezdve, 3-mal osztható számokkal (pl. `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Iterátort ad vissza olyan alszelvényeken, amelyeket olyan elemek választanak el egymástól, amelyek megfelelnek az `pred`-nek, legfeljebb `n`-es elemek visszaküldésére.
    /// Ez a szelet végén kezdődik és visszafelé működik.
    /// Az egyező elemet nem tartalmazzák az alszelvények.
    ///
    /// Az utolsó visszaküldött elem, ha van ilyen, a szelet maradékát fogja tartalmazni.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// `true` értéket ad vissza, ha a szelet tartalmaz egy elemet a megadott értékkel.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Ha nincs `&T`, hanem csak egy `&U`, amely `T: Borrow<U>` (pl
    /// String: kölcsön<str>`), használhatja az `iter().any`-et:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // szelet `String`
    /// assert!(v.iter().any(|e| e == "hello")); // keresés az `&str` segítségével
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Visszaadja az `true` értéket, ha az `needle` a szelet előtagja.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Mindig adja vissza az `true` értéket, ha az `needle` üres szelet:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Visszaadja az `true` értéket, ha az `needle` a szelet utótagja.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Mindig adja vissza az `true` értéket, ha az `needle` üres szelet:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Visszaad egy alszeletet, amelynek előtagja eltávolítva.
    ///
    /// Ha a szelet `prefix`-gyel kezdődik, akkor az előtag után az alszeletet adja vissza, `Some`-be csomagolva.
    /// Ha az `prefix` üres, egyszerűen adja vissza az eredeti szeletet.
    ///
    /// Ha a szelet nem `prefix`-gyel kezdődik, akkor az `None`-et adja vissza.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Ezt a függvényt újra kell írni, ha és amikor a SlicePattern kifinomultabbá válik.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Visszaad egy alszeletet az eltávolított utótaggal.
    ///
    /// Ha a szelet `suffix`-gyel végződik, akkor az alszeletet az utótag előtt adja vissza, `Some`-be csomagolva.
    /// Ha az `suffix` üres, egyszerűen adja vissza az eredeti szeletet.
    ///
    /// Ha a szelet nem végződik `suffix`-szel, akkor az `None` értéket adja vissza.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Ezt a függvényt újra kell írni, ha és amikor a SlicePattern kifinomultabbá válik.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// A bináris ebben a rendezett szeletben keres egy adott elemet.
    ///
    /// Ha megtalálja az értéket, akkor az [`Result::Ok`] értéket adja vissza, amely tartalmazza a megfelelő elem indexét.
    /// Ha több mérkőzés van, akkor bármelyik mérkőzést vissza lehet adni.
    /// Ha az érték nem található, akkor az [`Result::Err`] kerül visszaadásra, amely tartalmazza azt az indexet, ahová a rendezett sorrend fenntartása mellett illeszthető elemet lehet beilleszteni.
    ///
    ///
    /// Lásd még: [`binary_search_by`], [`binary_search_by_key`] és [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Négy elemből álló sorozatot keres.
    /// Az első megtalálható, egyedileg meghatározott pozícióval;a második és a harmadik nem található;a negyedik bármelyik pozíciónak megfelelhet az `[1, 4]`-ben.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Ha egy elemet be akar illeszteni egy rendezett vector-be, a rendezési sorrend fenntartása mellett:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// A bináris összehasonlító funkcióval keresi meg ezt a rendezett szeletet.
    ///
    /// Az összehasonlító függvénynek egy olyan sorrendet kell megvalósítania, amely összhangban van az alapul szolgáló szelet rendezési sorrendjével, sorrend kódot ad vissza, amely jelzi, hogy argumentuma `Less`, `Equal` vagy `Greater` a kívánt cél.
    ///
    ///
    /// Ha megtalálja az értéket, akkor az [`Result::Ok`] értéket adja vissza, amely tartalmazza a megfelelő elem indexét.Ha több mérkőzés van, akkor bármelyik mérkőzést vissza lehet adni.
    /// Ha az érték nem található, akkor az [`Result::Err`] kerül visszaadásra, amely tartalmazza azt az indexet, ahová a rendezett sorrend fenntartása mellett illeszthető elemet lehet beilleszteni.
    ///
    /// Lásd még: [`binary_search`], [`binary_search_by_key`] és [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Négy elemből álló sorozatot keres.Az első megtalálható, egyedileg meghatározott pozícióval;a második és a harmadik nem található;a negyedik bármelyik pozíciónak megfelelhet az `[1, 4]`-ben.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // BIZTONSÁG: A hívást a következő invariánsok teszik biztonságossá:
            // - `mid >= 0`
            // - `mid < size`: Az `mid`-et `[left; right)`-kötés korlátozza.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Azért használjuk az if/else vezérlő áramlást az egyezés helyett, mert a mérkőzés újrarendezi az összehasonlítási műveleteket, ami nagyon érzékeny.
            //
            // Ez x86 asm az u8 esetében: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// A bináris kulcs ebben a rendezett szeletben kulcsbontási funkcióval keres.
    ///
    /// Feltételezzük, hogy a szeletet a kulcs rendezi, például [`sort_by_key`] esetén ugyanaz a kulcs kinyerési funkció.
    ///
    /// Ha megtalálja az értéket, akkor az [`Result::Ok`] értéket adja vissza, amely tartalmazza a megfelelő elem indexét.
    /// Ha több mérkőzés van, akkor bármelyik mérkőzést vissza lehet adni.
    /// Ha az érték nem található, akkor az [`Result::Err`] kerül visszaadásra, amely tartalmazza azt az indexet, ahová a rendezett sorrend fenntartása mellett illeszthető elemet lehet beilleszteni.
    ///
    ///
    /// Lásd még: [`binary_search`], [`binary_search_by`] és [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Négy elem sorozatát keresi meg a második elemük szerint rendezett pár szeletben.
    /// Az első megtalálható, egyedileg meghatározott pozícióval;a második és a harmadik nem található;a negyedik bármelyik pozíciónak megfelelhet az `[1, 4]`-ben.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // A Lint rustdoc::broken_intra_doc_links megengedett, mivel az `slice::sort_by_key` a crate `alloc`-ben van, és mint ilyen még nem létezik az `core` felépítésekor.
    //
    // linkek a downstream crate: #74481-hez.Mivel a primitíveket csak az (#73423) libstd dokumentálja, ez a gyakorlatban soha nem vezet megszakadt kapcsolatokhoz.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Rendezi a szeletet, de nem biztos, hogy megőrzi az egyenlő elemek sorrendjét.
    ///
    /// Ez a fajta instabil (azaz átrendezheti az egyenlő elemeket), helyben van (azaz nem allokál) és *O*(*n*\*log(* n*)) legrosszabb esetben.
    ///
    /// # Jelenlegi megvalósítás
    ///
    /// A jelenlegi algoritmus Orson Peters [pattern-defeating quicksort][pdqsort]-en alapul, amely egyesíti a randomizált quicksort gyors átlagos esetét a leggyorsabb heapsort esettel, miközben lineáris időt ér el bizonyos mintázatú szeleteken.
    /// Némi randomizálást alkalmaz a degenerált esetek elkerülésére, de fix seed-vel mindig meghatározó viselkedést biztosít.
    ///
    /// Tipikusan gyorsabb, mint a stabil válogatás, kivéve néhány speciális esetet, például amikor a szelet több összefűzött rendezett szekvenciából áll.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// A szeletet összehasonlító funkcióval rendezi, de nem biztos, hogy megőrzi az egyenlő elemek sorrendjét.
    ///
    /// Ez a fajta instabil (azaz átrendezheti az egyenlő elemeket), helyben van (azaz nem allokál) és *O*(*n*\*log(* n*)) legrosszabb esetben.
    ///
    /// Az összehasonlító függvénynek meg kell határoznia a szelet elemeinek teljes sorrendjét.Ha a sorrend nem teljes, akkor az elemek sorrendje nincs megadva.A megrendelés teljes megrendelés, ha igen (az összes `a`, `b` és `c` esetében):
    ///
    /// * teljes és antiszimmetrikus: pontosan az `a < b`, `a == b` vagy `a > b` közül az egyik igaz, és
    /// * transzitív, az `a < b` és az `b < c` az `a < c`-et jelenti.Ugyanennek kell lennie az `==` és az `>` esetében is.
    ///
    /// Például, míg az [`f64`] nem valósítja meg az [`Ord`]-et, mert az `NaN != NaN`, az `partial_cmp`-et használhatjuk rendezési funkcióként, ha tudjuk, hogy a szelet nem tartalmaz `NaN`-et.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Jelenlegi megvalósítás
    ///
    /// A jelenlegi algoritmus Orson Peters [pattern-defeating quicksort][pdqsort]-en alapul, amely egyesíti a randomizált quicksort gyors átlagos esetét a leggyorsabb heapsort esettel, miközben lineáris időt ér el bizonyos mintázatú szeleteken.
    /// Némi randomizálást alkalmaz a degenerált esetek elkerülésére, de fix seed-vel mindig meghatározó viselkedést biztosít.
    ///
    /// Tipikusan gyorsabb, mint a stabil válogatás, kivéve néhány speciális esetet, például amikor a szelet több összefűzött rendezett szekvenciából áll.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // fordított rendezés
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Rendezi a szelet egy kulcs kinyerési funkcióval, de nem biztos, hogy megőrzi az egyenlő elemek sorrendjét.
    ///
    /// Ez a fajta instabil (azaz átrendezhet egyenlő elemeket), helyben van (azaz nem oszt le) és *O*(m\* * n *\* log(*n*)) legrosszabb esetben, ahol a kulcsfontosságú funkció *O*(*m*).
    ///
    /// # Jelenlegi megvalósítás
    ///
    /// A jelenlegi algoritmus Orson Peters [pattern-defeating quicksort][pdqsort]-en alapul, amely egyesíti a randomizált quicksort gyors átlagos esetét a leggyorsabb heapsort esettel, miközben lineáris időt ér el bizonyos mintázatú szeleteken.
    /// Némi randomizálást alkalmaz a degenerált esetek elkerülésére, de fix seed-vel mindig meghatározó viselkedést biztosít.
    ///
    /// Kulcsfontosságú hívási stratégiája miatt az [`sort_unstable_by_key`](#method.sort_unstable_by_key) valószínűleg lassabb, mint az [`sort_by_cached_key`](#method.sort_by_cached_key), olyan esetekben, amikor a kulcsfunkció drága.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Rendezze át a szeletet úgy, hogy az `index`-nél lévő elem a végső rendezett helyzetben legyen.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Rendezze át a szelet összehasonlító funkcióval úgy, hogy az `index`-nél lévő elem a végső rendezett helyzetben legyen.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Rendezze át a szelet egy kulcs kinyerési funkcióval úgy, hogy az `index` elem az utolsó rendezett helyzetben legyen.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Rendezze át a szeletet úgy, hogy az `index`-nél lévő elem a végső rendezett helyzetben legyen.
    ///
    /// Ennek az újrarendezésnek megvan az a további tulajdonsága, hogy az `i < index` pozíció bármely értéke kisebb vagy egyenlő, mint az `j > index` pozíció bármely értéke.
    /// Ezenkívül ez az átrendezés instabil (azaz
    /// tetszőleges számú egyenlő elem kerülhet az `index` pozícióba, a helyére (azaz
    /// nem oszt ki), és a *O*(*n*) legrosszabb esetben.
    /// Ez a függvény más könyvtárakban "kth element" néven is ismert.
    /// A következő értékek hármasát adja vissza: minden elem kevesebb, mint az adott indexnél, az adott index értéke, és minden elem nagyobb, mint az adott indexnél.
    ///
    ///
    /// # Jelenlegi megvalósítás
    ///
    /// A jelenlegi algoritmus ugyanazon quicksort algoritmus quickselect részén alapul, amelyet az [`sort_unstable`]-hez használtak.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics, amikor `index >= len()`, vagyis mindig panics üres szeleteken.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Keresse meg a mediánt
    /// v.select_nth_unstable(2);
    ///
    /// // Csak azt garantáljuk, hogy a szelet az alábbiak egyike lesz, a megadott index szerinti rendezés módja alapján.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Rendezze át a szelet összehasonlító funkcióval úgy, hogy az `index`-nél lévő elem a végső rendezett helyzetben legyen.
    ///
    /// Ennek az újrarendezésnek megvan az a további tulajdonsága, hogy az `i < index` pozíció bármely értéke kisebb vagy egyenlő, mint az összehasonlító függvény használatával az `j > index` pozíció bármely értéke.
    /// Ezenkívül ez az átrendezés instabil (azaz tetszőleges számú egyenlő elem kerülhet az `index` pozícióba), a helyén van (azaz nem allokál) és a legrosszabb esetben *O*(*n*).
    /// Ez a függvény más könyvtárakban "kth element" néven is ismert.
    /// A következő értékek hármasát adja vissza: a megadott összehasonlító függvény segítségével minden elem kevesebb, mint az adott indexnél, az adott index értéke, és minden elem nagyobb, mint az adott indexnél.
    ///
    ///
    /// # Jelenlegi megvalósítás
    ///
    /// A jelenlegi algoritmus ugyanazon quicksort algoritmus quickselect részén alapul, amelyet az [`sort_unstable`]-hez használtak.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics, amikor `index >= len()`, vagyis mindig panics üres szeleteken.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Keresse meg a mediánt, mintha a szelet csökkenő sorrendbe rendeződött volna.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Csak azt garantáljuk, hogy a szelet az alábbiak egyike lesz, a megadott index szerinti rendezés módja alapján.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Rendezze át a szelet egy kulcs kinyerési funkcióval úgy, hogy az `index` elem az utolsó rendezett helyzetben legyen.
    ///
    /// Ennek az újrarendezésnek megvan az a további tulajdonsága, hogy az `i < index` pozíció bármely értéke kisebb vagy egyenlő, mint az `j > index` pozíció bármely értéke, a kulcs kinyerési funkció használatával.
    /// Ezenkívül ez az átrendezés instabil (azaz tetszőleges számú egyenlő elem kerülhet az `index` pozícióba), a helyén van (azaz nem allokál) és a legrosszabb esetben *O*(*n*).
    /// Ez a függvény más könyvtárakban "kth element" néven is ismert.
    /// A következő értékek hármasát adja vissza: minden elem, amely kisebb, mint az adott index, az adott index értéke, és minden elem, amely nagyobb, mint az adott index, a megadott kulcs kinyerési függvény segítségével.
    ///
    ///
    /// # Jelenlegi megvalósítás
    ///
    /// A jelenlegi algoritmus ugyanazon quicksort algoritmus quickselect részén alapul, amelyet az [`sort_unstable`]-hez használtak.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics, amikor `index >= len()`, vagyis mindig panics üres szeleteken.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Adja vissza a mediánt, mintha a tömb abszolút érték szerint lenne rendezve.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Csak azt garantáljuk, hogy a szelet az alábbiak egyike lesz, a megadott index szerinti rendezés módja alapján.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Az összes egymást követő ismételt elemet a szelet végére helyezi az [`PartialEq`] trait megvalósításának megfelelően.
    ///
    ///
    /// Két szeletet ad vissza.Az első nem tartalmaz egymást követő ismétlődő elemeket.
    /// A második az összes másolatot tartalmazza, nem meghatározott sorrendben.
    ///
    /// Ha a szelet rendezve van, az első visszaküldött szelet nem tartalmaz duplikátumot.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Az egymást követő elemek közül az első kivételével az összes a szelet végére kerül, kielégítve az adott egyenlőségi viszonyt.
    ///
    /// Két szeletet ad vissza.Az első nem tartalmaz egymást követő ismétlődő elemeket.
    /// A második az összes másolatot tartalmazza, nem meghatározott sorrendben.
    ///
    /// Az `same_bucket` függvény a szelet két elemére hivatkozva kerül átadásra, és meg kell határoznia, hogy az elemek egyenlőek-e.
    /// Az elemeket a szelet sorrendjével ellentétes sorrendben adjuk át, így ha `same_bucket(a, b)` visszaadja az `true` értéket, akkor az `a` a szelet végén mozog.
    ///
    ///
    /// Ha a szelet rendezve van, az első visszaküldött szelet nem tartalmaz duplikátumot.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Bár van egy mutatható utalásunk az `self`-re, nem végezhetünk *önkényes* változtatásokat.Az `same_bucket` hívások panic-t hívhatnak, ezért biztosítanunk kell, hogy a szelet mindig érvényes állapotban legyen.
        //
        // Ezt úgy kezeljük, mint a csereügyleteket;az összes elemet iteráljuk, közben felcseréljük úgy, hogy a végén a megtartani kívánt elemek elöl vannak, és akiket el akarunk utasítani, hátul vannak.
        // Ezután fel tudjuk osztani a szeletet.
        // Ez a művelet továbbra is `O(n)`.
        //
        // Példa: Ebben az állapotban kezdjük, ahol az `r` a következőt jelöli
        // olvassa el az `w` pedig a" next_write "kifejezést.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Összehasonlítva az self[r]-et az én [w-1]-nel, ez nem duplikátum, ezért felcseréljük az self[r]-et és az self[w]-et (nincs hatás, mivel r==w), majd r-t és w-t is növekszünk, így:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Ha összehasonlítjuk az self[r]-et az én [w-1]-vel, ez az érték duplikátum, ezért növeljük az `r`-et, de minden mást változatlanul hagyunk:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Összehasonlítva az self[r]-et az én [w-1]-nel, ez nem duplikátum, ezért cserélje fel az self[r] és az self[w] elemeket, és lépjen előre r és w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Nem másolat, ismételje meg:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Másolat, advance r. End szelet.Osztott w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // BIZTONSÁG: az `while` feltétel garantálja az `next_read` és `next_write` értékeket
        // kisebbek, mint `len`, tehát az `self` belsejében vannak.
        // `prev_ptr_write` mutat egy elemre az `ptr_write` előtt, de az `next_write` 1-től kezdődik, így az `prev_ptr_write` soha nem kevesebb, mint 0, és a szelet belsejében van.
        // Ez megfelel az `ptr_read`, `prev_ptr_write` és `ptr_write` levezetés, valamint az `ptr.add(next_read)`, `ptr.add(next_write - 1)` és `prev_ptr_write.offset(1)` használatának követelményeinek.
        //
        //
        // `next_write` ciklusonként is legfeljebb egyszer növekszik, vagyis egyetlen elem sem kerül átugrásra, amikor esetleg cserélni kell.
        //
        // `ptr_read` és az `prev_ptr_write` soha nem mutat ugyanarra az elemre.Erre azért van szükség, hogy az `&mut *ptr_read`, `&mut* prev_ptr_write` biztonságos legyen.
        // A magyarázat egyszerűen az, hogy az `next_read >= next_write` mindig igaz, tehát az `next_read > next_write - 1` is.
        //
        //
        //
        //
        //
        unsafe {
            // Kerülje a határellenőrzéseket nyers mutatók használatával.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Az egymást követő elemek kivételével az összes, az első kivételével, a szelet végére kerül, amelyek azonos kulcsra oldódnak.
    ///
    ///
    /// Két szeletet ad vissza.Az első nem tartalmaz egymást követő ismétlődő elemeket.
    /// A második az összes másolatot tartalmazza, nem meghatározott sorrendben.
    ///
    /// Ha a szelet rendezve van, az első visszaküldött szelet nem tartalmaz duplikátumot.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Úgy forgatja a szelet a helyén, hogy a szelet első `mid` elemei a végére mozogjanak, míg az utolsó `self.len() - mid` elemei elöl mozogjanak.
    /// Az `rotate_left` hívása után az előzőleg az `mid` indexen lévő elem lesz a szelet első eleme.
    ///
    /// # Panics
    ///
    /// Ez a függvény akkor lesz panic, ha az `mid` nagyobb, mint a szelet hossza.Ne feledje, hogy az `mid == self.len()` elvégzi az _not_ panic funkciót, és nem működik.
    ///
    /// # Complexity
    ///
    /// Lineárisan veszi fel (`self.len()`) időben.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Alrész forgatása:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // BIZTONSÁG: Az `[p.add(mid) - mid, p.add(mid) + k)` tartomány triviális
        // olvasásra és írásra érvényes, az `ptr_rotate` előírása szerint.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Úgy forgatja a szelet a helyén, hogy a szelet első `self.len() - k` elemei a végére mozogjanak, míg az utolsó `k` elemei elöl mozogjanak.
    /// Az `rotate_right` hívása után az előzőleg az `self.len() - k` indexen lévő elem lesz a szelet első eleme.
    ///
    /// # Panics
    ///
    /// Ez a függvény akkor lesz panic, ha az `k` nagyobb, mint a szelet hossza.Ne feledje, hogy az `k == self.len()` elvégzi az _not_ panic funkciót, és nem működik.
    ///
    /// # Complexity
    ///
    /// Lineárisan veszi fel (`self.len()`) időben.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Alrész forgatása:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // BIZTONSÁG: Az `[p.add(mid) - mid, p.add(mid) + k)` tartomány triviális
        // olvasásra és írásra érvényes, az `ptr_rotate` előírása szerint.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Az `self` elemeket az `value` klónozásával tölti ki.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Az `self`-et olyan elemekkel tölti fel, amelyek ismételt lezárás felhívásával érkeznek.
    ///
    /// Ez a módszer bezárást használ új értékek létrehozásához.Ha inkább egy adott értéket szeretne [`Clone`]-re használni, használja az [`fill`]-et.
    /// Ha értékek előállításához az [`Default`] trait szolgáltatást szeretné használni, akkor az [`Default::default`] paramétert adja át argumentumként.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Másolja az elemeket az `src`-ből az `self`-be.
    ///
    /// Az `src` hosszának meg kell egyeznie az `self` hosszával.
    ///
    /// Ha az `T` megvalósítja az `Copy`-et, akkor jobban teljesíthet az [`copy_from_slice`] használata.
    ///
    /// # Panics
    ///
    /// Ez a funkció akkor lesz panic, ha a két szelet eltérő hosszúságú.
    ///
    /// # Examples
    ///
    /// Két elem klónozása egy szeletből egy másikba:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Mivel a szeleteknek azonos hosszúságúaknak kell lenniük, a forrásszeletet négy elemről kettőre szeleteljük.
    /// // panic lesz, ha ezt nem tesszük meg.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// A Rust kikényszeríti, hogy csak egy módosítható hivatkozás létezhet, változatlan hivatkozások nélkül, egy adott hatókörű adatra.
    /// Emiatt az `clone_from_slice` egyetlen szeleten történő használatának kísérlete fordítási hibát eredményez:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Ennek kiküszöbölésére az [`split_at_mut`] segítségével két külön alszeletet hozhatunk létre egy szeletből:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Másolja az összes elemet az `src`-ből az `self`-be egy memcpy segítségével.
    ///
    /// Az `src` hosszának meg kell egyeznie az `self` hosszával.
    ///
    /// Ha az `T` nem valósítja meg az `Copy`-et, akkor használja az [`clone_from_slice`]-et.
    ///
    /// # Panics
    ///
    /// Ez a funkció akkor lesz panic, ha a két szelet eltérő hosszúságú.
    ///
    /// # Examples
    ///
    /// Két elem másolása egy szeletből egy másikba:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Mivel a szeleteknek azonos hosszúságúaknak kell lenniük, a forrásszeletet négy elemről kettőre szeleteljük.
    /// // panic lesz, ha ezt nem tesszük meg.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// A Rust kikényszeríti, hogy csak egy módosítható hivatkozás létezhet, változatlan hivatkozások nélkül, egy adott hatókörű adatra.
    /// Emiatt az `copy_from_slice` egyetlen szeleten történő használatának kísérlete fordítási hibát eredményez:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Ennek kiküszöbölésére az [`split_at_mut`] segítségével két külön alszeletet hozhatunk létre egy szeletből:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // A panic kód elérési útját hideg funkcióba helyezték, hogy ne duzzadjon fel a hívás helye.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // BIZTONSÁG: Az `self` definíció szerint az `self.len()` elemekre érvényes, az `src` pedig az volt
        // ellenőrizte, hogy azonos hosszúságú-e.
        // A szeletek nem fedhetik egymást, mert a mutálható hivatkozások kizárólagosak.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Elemeket másol a szelet egyik részéből egy másik részébe egy memmove segítségével.
    ///
    /// `src` az `self`-en belüli tartomány, ahonnan másolni lehet.
    /// `dest` az `self` tartományon belüli másolási tartomány kezdő indexe, amelynek hossza megegyezik az `src` értékével.
    /// A két tartomány átfedhet.
    /// A két tartomány végének kisebbnek vagy egyenlőnek kell lennie, mint `self.len()`.
    ///
    /// # Panics
    ///
    /// Ez a funkció akkor lesz panic, ha bármelyik tartomány meghaladja a szelet végét, vagy ha az `src` vége a kezdet előtt van.
    ///
    ///
    /// # Examples
    ///
    /// Négy bájt másolása egy szeleten belül:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // BIZTONSÁG: az `ptr::copy` feltételeit fentebb ellenőriztük,
        // akárcsak az `ptr::add`-hez.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Az `self` összes elemét felcseréli az `other` elemével.
    ///
    /// Az `other` hosszának meg kell egyeznie az `self` hosszával.
    ///
    /// # Panics
    ///
    /// Ez a funkció akkor lesz panic, ha a két szelet eltérő hosszúságú.
    ///
    /// # Example
    ///
    /// Két elem cseréje a szeletek között:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// A Rust kikényszeríti, hogy csak egy módosítható hivatkozás lehet egy adott hatókörű adatra.
    ///
    /// Emiatt az `swap_with_slice` egyetlen szeleten történő használatának kísérlete fordítási hibát eredményez:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Ennek kiküszöbölésére az [`split_at_mut`] segítségével két különálló, módosítható alszeletet hozhatunk létre egy szeletből:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // BIZTONSÁG: Az `self` definíció szerint az `self.len()` elemekre érvényes, az `src` pedig az volt
        // ellenőrizte, hogy azonos hosszúságú-e.
        // A szeletek nem fedhetik egymást, mert a mutálható hivatkozások kizárólagosak.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Funkció az `align_to{,_mut}` középső és hátsó részének hosszának kiszámításához.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Mit fogunk tenni az `rest` kapcsán, az az, hogy kitaláljuk, hogy az "U"-ok hányszorosát tudjuk a legkisebb számú "T"-be tenni.
        //
        // És hány T-ra van szükségünk minden ilyen "multiple"-hez.
        //
        // Vegyük például T=u8 U=u16.Akkor 1 U-t tehetünk 2 Ts-be.Egyszerű.
        // Vegyünk például egy olyan esetet, amikor a size_of: :<T>=16, méret: <U>=24.</u>
        // Az `rest` szeletben minden 3 Ts helyére 2 Us-ot tehetünk.
        // Kicsit bonyolultabb.
        //
        // Képlet ennek kiszámításához:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Bővített és egyszerűsített:
        //
        // Us=méret: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=méret::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Szerencsére, mivel mindezt folyamatosan értékelik ... a teljesítmény itt nem számít!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // iteratív stein algoritmusa Ennek ellenére meg kell csinálnunk ezt az `const fn`-et (és vissza kell térnünk a rekurzív algoritmusra, ha ezt tesszük), mert mindezek megteremtésében az llvm-re támaszkodni…nos, ez kényelmetlenné tesz.
            //
            //

            // BIZTONSÁG: Az `a` és az `b` értéke nulla értékű.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // távolítsa el a 2 összes tényezőjét a b-ből
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // BIZTONSÁG: Az `b` értéke nulla.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Ezzel a tudással felfegyverkezve megtalálhatjuk, hogy hány "U" fér el!
        let us_len = self.len() / ts * us;
        // És hány T lesz a záró szeletben!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Átalakítsa a szeletet egy másik típusú szeletté, biztosítva a típusok összehangolását.
    ///
    /// Ez a módszer három különálló szeletre osztja a szeletet: előtag, új típusú helyesen igazított középső szelet és az utótag szelet.
    /// A módszer a középső szeletet a lehető legnagyobb hosszúsággá teheti egy adott típushoz és bemeneti szelethez, de ettől csak az algoritmus teljesítménye függhet, nem pedig a helyessége.
    ///
    /// Megengedett, hogy az összes bemeneti adat előtagként vagy utótagként kerüljön vissza.
    ///
    /// Ennek a módszernek nincs célja, ha az `T` bemeneti elem vagy az `U` kimeneti elem nulla méretű, és az eredeti szeletet semmiféle felosztás nélkül adja vissza.
    ///
    /// # Safety
    ///
    /// Ez a módszer lényegében egy `transmute` a visszaszolgáltatott középső szelet elemei tekintetében, így az `transmute::<T, U>`-re vonatkozó összes szokásos figyelmeztetés itt is érvényes.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Vegye figyelembe, hogy ennek a funkciónak a nagy részét állandóan értékelik,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // speciálisan kezelje a ZST-eket, vagyis egyáltalán ne kezelje őket.
            return (self, &[], &[]);
        }

        // Először keresse meg, hogy mikor osztunk szét az első és a második szelet között.
        // Könnyű az ptr.align_offset használatával.
        let ptr = self.as_ptr();
        // BIZTONSÁG: A részletes biztonsági megjegyzést lásd az `align_to_mut` módszerben.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // BIZTONSÁG: Most az `rest` határozottan illeszkedik, így az alábbi `from_raw_parts` rendben van,
            // mivel a hívó garantálja, hogy biztonságosan tudjuk az `T`-et átalakítani `U`-be.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Átalakítsa a szeletet egy másik típusú szeletté, biztosítva a típusok összehangolását.
    ///
    /// Ez a módszer három különálló szeletre osztja a szeletet: előtag, új típusú helyesen igazított középső szelet és az utótag szelet.
    /// A módszer a középső szeletet a lehető legnagyobb hosszúsággá teheti egy adott típushoz és bemeneti szelethez, de ettől csak az algoritmus teljesítménye függhet, nem pedig a helyessége.
    ///
    /// Megengedett, hogy az összes bemeneti adat előtagként vagy utótagként kerüljön vissza.
    ///
    /// Ennek a módszernek nincs célja, ha az `T` bemeneti elem vagy az `U` kimeneti elem nulla méretű, és az eredeti szeletet semmiféle felosztás nélkül adja vissza.
    ///
    /// # Safety
    ///
    /// Ez a módszer lényegében egy `transmute` a visszaszolgáltatott középső szelet elemei tekintetében, így az `transmute::<T, U>`-re vonatkozó összes szokásos figyelmeztetés itt is érvényes.
    ///
    /// # Examples
    ///
    /// Alapvető használat:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Vegye figyelembe, hogy ennek a funkciónak a nagy részét állandóan értékelik,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // speciálisan kezelje a ZST-eket, vagyis egyáltalán ne kezelje őket.
            return (self, &mut [], &mut []);
        }

        // Először keresse meg, hogy mikor osztunk szét az első és a második szelet között.
        // Könnyű az ptr.align_offset használatával.
        let ptr = self.as_ptr();
        // BIZTONSÁG: Itt biztosítjuk, hogy az U-hoz igazított mutatókat használjunk a
        // a módszer többi része.Ez úgy történik, hogy egy mutatót adunk az&[T]-re U-ra megcélzott igazítással.
        // `crate::ptr::align_offset` helyesen illesztett és érvényes `ptr` mutatóval hívják meg (az `self` hivatkozásból származik), és méretével, amely kettő hatványa (mivel U U igazításából származik), eleget téve annak biztonsági követelményeinek.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Ezek után nem használhatjuk újra az `rest`-et, ez érvénytelenítené az `mut_ptr` álnevét!BIZTONSÁG: lásd az `align_to` megjegyzéseit.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Ellenőrzi, hogy a szelet elemei rendezve vannak-e.
    ///
    /// Vagyis minden egyes `a` elemre és az azt követő `b` elemre az `a <= b`-nek tartania kell.Ha a szelet pontosan nulla vagy egy elemet eredményez, akkor az `true` értéket adja vissza.
    ///
    /// Vegye figyelembe, hogy ha `Self::Item` csak `PartialOrd`, de nem `Ord`, akkor a fenti definíció azt jelenti, hogy ez a függvény `false`-et ad vissza, ha bármely két egymást követő elem nem összehasonlítható.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Ellenőrzi, hogy a szelet elemei rendezve vannak-e a megadott összehasonlító függvény segítségével.
    ///
    /// Az `PartialOrd::partial_cmp` használata helyett ez a függvény az adott `compare` függvényt használja két elem sorrendjének meghatározásához.
    /// Ettől eltekintve egyenértékű az [`is_sorted`]-szel;további információkért lásd a dokumentációját.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Ellenőrzi, hogy ennek a szeletnek az elemei rendezve vannak-e a megadott kulcs kinyerési funkcióval.
    ///
    /// A szelet elemeinek közvetlen összehasonlítása helyett ez a függvény összehasonlítja az elemek kulcsait, az `f` által meghatározott módon.
    /// Ettől eltekintve egyenértékű az [`is_sorted`]-szel;további információkért lásd a dokumentációját.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Visszaadja a partíciós pont indexét az adott predikátumnak megfelelően (a második partíció első elemének indexét).
    ///
    /// Feltételezzük, hogy a szelet az adott predikátum szerint fel van osztva.
    /// Ez azt jelenti, hogy minden elem, amelyre az állítmány igaz, a szelet elején van, és minden elem, amelyre az állítmány hamis visszatér, a végén van.
    ///
    /// Például az [7, 15, 3, 5, 4, 12, 6] az x% 2!=0 állítmány partíciója (minden páratlan szám az elején van, még a végén is).
    ///
    /// Ha ez a szelet nincs particionálva, akkor a visszaküldött eredmény nem meghatározott és értelmetlen, mivel ez a módszer egyfajta bináris keresést hajt végre.
    ///
    /// Lásd még: [`binary_search`], [`binary_search_by`] és [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // BIZTONSÁG: Amikor az `left < right`, `left <= mid < right`.
            // Ezért az `left` mindig növekszik, és az `right` mindig csökken, és bármelyiket kiválasztják.Mindkét esetben az `left <= right` teljesül.Ezért ha `left < right` egy lépésben, akkor az `left <= right` a következő lépésben teljesül.
            //
            // Ezért mindaddig, amíg `left != right`, `0 <= left < right <= len` elégedett, és ha ebben az esetben az `0 <= mid < len` is teljesül.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Kifejezetten azonos hosszúságra kell szeletelnünk őket
        // hogy az optimalizáló könnyebben elkerülhesse a határellenőrzést.
        // De mivel nem lehet rá támaszkodni, ezért kifejezetten specializálódtunk a T: Copy-ra is.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Üres szeletet hoz létre.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Mutatható üres szeletet hoz létre.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// A szeletek mintáit jelenleg csak az `strip_prefix` és az `strip_suffix` használja.
/// Reméljük, hogy egy future ponton általánosítjuk az `core::str::Pattern`-et (amely az írás idején az `str`-re korlátozódik) szeletekre, majd ezt a trait-t kicserélik vagy megszüntetik.
///
pub trait SlicePattern {
    /// A szelet elemtípusa, amelyhez illeszkedik.
    type Item;

    /// Jelenleg az `SlicePattern` fogyasztóinak szeletre van szükségük.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}