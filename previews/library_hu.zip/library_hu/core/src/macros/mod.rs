#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // `$crate::panic::panic_2015`-re vagy `$crate::panic::panic_2021`-re bővül a hívó fél kiadásától függően.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Azt állítja, hogy két kifejezés egyenlő egymással ([`PartialEq`] használatával).
///
/// A panic rendszeren ez a makró kinyomtatja a kifejezések értékeit a hibakeresési reprezentációikkal.
///
///
/// Az [`assert!`]-hez hasonlóan ennek a makrónak is van egy második formája, ahol egyedi panic üzenetet lehet megadni.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Az alábbi visszavételek szándékosak.
                    // Nélkülük a kölcsön halmozási helyét még az értékek összehasonlítása előtt inicializálják, ami észrevehető lassuláshoz vezet.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Az alábbi visszavételek szándékosak.
                    // Nélkülük a kölcsön halmozási helyét még az értékek összehasonlítása előtt inicializálják, ami észrevehető lassuláshoz vezet.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Azt állítja, hogy két kifejezés nem egyenlő egymással ([`PartialEq`] használatával).
///
/// A panic rendszeren ez a makró kinyomtatja a kifejezések értékeit a hibakeresési reprezentációikkal.
///
///
/// Az [`assert!`]-hez hasonlóan ennek a makrónak is van egy második formája, ahol egyedi panic üzenetet lehet megadni.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Az alábbi visszavételek szándékosak.
                    // Nélkülük a kölcsön halmozási helyét még az értékek összehasonlítása előtt inicializálják, ami észrevehető lassuláshoz vezet.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Az alábbi visszavételek szándékosak.
                    // Nélkülük a kölcsön halmozási helyét még az értékek összehasonlítása előtt inicializálják, ami észrevehető lassuláshoz vezet.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Azt állítja, hogy a logikai kifejezés futás közben `true`.
///
/// Ez meghívja az [`panic!`] makrót, ha a megadott kifejezést futás közben nem lehet `true`-re értékelni.
///
/// Az [`assert!`]-hez hasonlóan ennek a makrónak is van egy második verziója, ahol egyedi panic üzenetet lehet megadni.
///
/// # Uses
///
/// Az [`assert!`]-től eltérően az `debug_assert!` utasítások alapértelmezés szerint csak nem optimalizált buildekben engedélyezettek.
/// Az optimalizált összeállítás csak akkor hajtja végre az `debug_assert!` utasításokat, ha az `-C debug-assertions`-et továbbítják a fordítónak.
/// Ez az `debug_assert!`-et hasznosnak tartja olyan ellenőrzéseknél, amelyek túl drágák ahhoz, hogy jelen legyenek egy kiadás összeállításában, de hasznosak lehetnek a fejlesztés során.
/// Az `debug_assert!` kibővítésének eredménye mindig típusellenőrzés alatt áll.
///
/// Az ellenőrizetlen állítás lehetővé teszi az inkonzisztens állapotban lévő program futtatását, amelynek váratlan következményei lehetnek, de nem vezet be biztonságtalanságot, amennyiben ez csak biztonságos kódban történik.
///
/// Az állítások teljesítményköltsége azonban általában nem mérhető.
/// Az [`assert!`] cseréje az `debug_assert!`-re tehát csak alapos profilalkotás után javasolt, és ami még fontosabb, csak biztonságos kódban!
///
/// # Examples
///
/// ```
/// // ezekhez az állításokhoz a panic üzenet a megadott kifejezés szigorúbb értéke.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // egy nagyon egyszerű funkció
/// debug_assert!(some_expensive_computation());
///
/// // állítson egyedi üzenettel
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Azt állítja, hogy két kifejezés egyenlő egymással.
///
/// A panic rendszeren ez a makró kinyomtatja a kifejezések értékeit a hibakeresési reprezentációikkal.
///
/// Az [`assert_eq!`]-től eltérően az `debug_assert_eq!` utasítások alapértelmezés szerint csak nem optimalizált buildekben engedélyezettek.
/// Az optimalizált összeállítás csak akkor hajtja végre az `debug_assert_eq!` utasításokat, ha az `-C debug-assertions`-et továbbítják a fordítónak.
/// Ez az `debug_assert_eq!`-et hasznosnak tartja olyan ellenőrzéseknél, amelyek túl drágák ahhoz, hogy jelen legyenek egy kiadás összeállításában, de hasznosak lehetnek a fejlesztés során.
///
/// Az `debug_assert_eq!` kibővítésének eredménye mindig típusellenőrzés alatt áll.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Azt állítja, hogy két kifejezés nem egyenlő egymással.
///
/// A panic rendszeren ez a makró kinyomtatja a kifejezések értékeit a hibakeresési reprezentációikkal.
///
/// Az [`assert_ne!`]-től eltérően az `debug_assert_ne!` utasítások alapértelmezés szerint csak nem optimalizált buildekben engedélyezettek.
/// Az optimalizált összeállítás csak akkor hajtja végre az `debug_assert_ne!` utasításokat, ha az `-C debug-assertions`-et továbbítják a fordítónak.
/// Ez az `debug_assert_ne!`-et hasznosnak tartja olyan ellenőrzéseknél, amelyek túl drágák ahhoz, hogy jelen legyenek egy kiadás összeállításában, de hasznosak lehetnek a fejlesztés során.
///
/// Az `debug_assert_ne!` kibővítésének eredménye mindig típusellenőrzés alatt áll.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Visszaadja, hogy az adott kifejezés megfelel-e az adott minták valamelyikének.
///
/// Az `match` kifejezéshez hasonlóan a mintát opcionálisan követheti az `if` és egy olyan őr kifejezés, amely hozzáférhet a minta által kötött nevekhez.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Kicsomagolja az eredményt, vagy továbbítja a hibáját.
///
/// Az `?` operátort felvették az `try!` helyére, és helyette azt kell használni.
/// Továbbá az `try` egy fenntartott szó a Rust 2018 alkalmazásban, így ha használni kell, akkor az [raw-identifier syntax][ris]-et kell használnia: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` megfelel az adott [`Result`]-nek.Az `Ok` variáns esetén a kifejezésnek megvan a becsomagolt értéke.
///
/// Az `Err` változat esetén visszakeresi a belső hibát.Az `try!` ezután az `From` használatával végrehajtja az átalakítást.
/// Ez biztosítja az automatikus átalakítást a speciális hibák és az általánosabb hibák között.
/// A kapott hibát ezután azonnal visszaküldi.
///
/// A korai visszatérés miatt az `try!` csak olyan funkciókban használható, amelyek visszaadják az [`Result`]-et.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // A hibák gyors visszaküldésének előnyben részesített módszere
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Az előző módszer a hibák gyors visszaadására
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Ez egyenértékű:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// A formázott adatokat pufferbe írja.
///
/// Ez a makró elfogad egy 'writer'-et, egy formátum-karakterláncot és egy argumentumlistát.
/// Az érveket a megadott formátum-karakterláncnak megfelelően formázzuk, és az eredményt továbbítjuk az írónak.
/// Az író bármely értéke lehet `write_fmt` módszerrel;általában ez az [`fmt::Write`] vagy az [`io::Write`] trait megvalósításából származik.
/// A makró az `write_fmt` metódus által adott eredményt adja vissza;általában [`fmt::Result`] vagy [`io::Result`].
///
/// A formátum karakterlánc szintaxisáról további információkat az [`std::fmt`] részben talál.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Egy modul importálhatja az `std::fmt::Write`-et és az `std::io::Write`-et, és meghívhatja az `write!`-et bármelyik objektumra, mivel az objektumok általában nem mindkettőt valósítják meg.
///
/// A modulnak azonban importálnia kell a traits minősítést, így a nevük nem ütközik:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt-et használ
///     write!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt-et használ
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Ez a makró az `no_std` beállításaiban is használható.
/// Az `no_std` beállításaiban Ön felelős az alkatrészek megvalósításának részleteiért.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Írjon formázott adatokat egy pufferbe, új sor hozzáadásával.
///
/// Minden platformon az új vonal egyedül a LINE FEED karakter (`\n`/`U+000A`) (nincs további CARRIAGE RETURN (`\r`/`U+000D`).
///
/// További információ: [`write!`].A formátum karakterlánc szintaxisáról az [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Egy modul importálhatja az `std::fmt::Write`-et és az `std::io::Write`-et, és meghívhatja az `write!`-et bármelyik objektumra, mivel az objektumok általában nem mindkettőt valósítják meg.
/// A modulnak azonban importálnia kell a traits minősítést, így a nevük nem ütközik:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt-et használ
///     writeln!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt-et használ
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Elérhetetlen kódot jelöl.
///
/// Ez bármikor hasznos, ha a fordító nem tudja megállapítani, hogy valamilyen kód elérhetetlen.Például:
///
/// * Párosítsd a fegyvereket az őr körülmények között.
/// * Dinamikusan végződő hurkok.
/// * Dinamikusan végződő iterátorok.
///
/// Ha a kód elérhetetlenségének megállapítása helytelennek bizonyul, a program azonnal leáll egy [`panic!`]-szel.
///
/// Ennek a makrónak nem biztonságos megfelelője az [`unreachable_unchecked`] függvény, amely meghatározatlan viselkedést okoz, ha eléri a kódot.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Ez mindig [`panic!`] lesz.
///
/// # Examples
///
/// Meccskarok:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // fordítási hiba, ha kommentálják
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // az x/3 egyik legszegényebb megvalósítása
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Az implementálatlan kódot jelzi, pánikba ejtve az "not implemented" üzenetet.
///
/// Ez lehetővé teszi a kód típusellenőrzését, ami akkor hasznos, ha prototípust készít vagy olyan trait-t valósít meg, amelyhez több olyan módszerre van szükség, amelyek nem tervezik az összes használatát.
///
/// Az a különbség az `unimplemented!` és az [`todo!`] között, hogy míg az `todo!` szándékát közvetíti a funkcionalitás későbbi megvalósítására, és az üzenet "not yet implemented", addig az `unimplemented!` nem állít ilyen igényt.
/// Az üzenete "not implemented".
/// Néhány IDE is bejelöli a "todo!"-kat.
///
/// # Panics
///
/// Ez mindig az [`panic!`] lesz, mert az `unimplemented!` csak rövidítés az `panic!`-hez, rögzített, specifikus üzenettel.
///
/// Az `panic!`-hez hasonlóan ennek a makrónak is van egy második formája az egyéni értékek megjelenítésére.
///
/// # Examples
///
/// Mondjuk, hogy van egy trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Az `Foo`-et az 'MyStruct'-hez szeretnénk megvalósítani, de valamilyen oknál fogva csak az `bar()`-függvénynek van értelme.
/// `baz()` és az `qux()`-et továbbra is meg kell határozni az `Foo` megvalósításakor, de definiálásukban használhatjuk az `unimplemented!`-et, hogy lehetővé tegyük kódunk fordítását.
///
/// Továbbra is azt akarjuk, hogy a programunk leálljon, ha a megvalósítatlan módszereket elérjük.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Nincs értelme az `baz` és az `MyStruct` számára, ezért itt egyáltalán nincs logikánk.
/////
///         // Ekkor megjelenik az "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Van itt némi logikánk, hozzáadhatunk egy üzenetet a megvalósítatlanokhoz!hogy kimutassuk a mulasztásunkat.
///         // Ez megjeleníti: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Befejezetlen kódot jelöl.
///
/// Ez hasznos lehet, ha prototípusokat készít, és csak arra törekszik, hogy ellenőrizze a kódot.
///
/// Az a különbség az [`unimplemented!`] és az `todo!` között, hogy míg az `todo!` szándékát közvetíti a funkcionalitás későbbi megvalósítására, és az üzenet "not yet implemented", addig az `unimplemented!` nem állít ilyen igényt.
/// Az üzenete "not implemented".
/// Néhány IDE is bejelöli a "todo!"-kat.
///
/// # Panics
///
/// Ez mindig [`panic!`] lesz.
///
/// # Examples
///
/// Itt van egy példa néhány folyamatban lévő kódra.Van egy trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Az `Foo`-et szeretnénk megvalósítani egyik típusunkon, de először is csak az `bar()`-en szeretnénk dolgozni.A kód összeállításához meg kell valósítanunk az `baz()`-et, így használhatjuk az `todo!`-et:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // a megvalósítás itt megy
///     }
///
///     fn baz(&self) {
///         // most ne aggódjunk az baz() bevezetése miatt
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // még az baz()-et sem használjuk, így ez rendben van.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// A beépített makrók meghatározása.
///
/// A legtöbb makrótulajdonság (stabilitás, láthatóság, stb.) Az itt szereplő forráskódból származik, a makró bemeneteket kimenetekké alakító bővítési függvények kivételével ezeket a függvényeket a fordító biztosítja.
///
///
pub(crate) mod builtin {

    /// A fordítás sikertelenségét okozza az adott hibaüzenettel, amikor találkoznak vele.
    ///
    /// Ezt a makrót akkor kell használni, ha egy crate feltételes fordítási stratégiát használ a jobb hibaüzenetek biztosításához téves körülmények között.
    ///
    /// Ez az [`panic!`] fordítószintű formája, de hibát ad ki a *fordítás* során, nem pedig a *futásidejű* alatt.
    ///
    /// # Examples
    ///
    /// Két ilyen példa a makrók és az `#[cfg]` környezetek.
    ///
    /// Jobb fordítói hibát bocsát ki, ha a makró érvénytelen értékeket ad át.
    /// A végleges branch nélkül a fordító továbbra is hibát bocsát ki, de a hibaüzenet nem említi a két érvényes értéket.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Fordítói hibát adhat ki, ha a számos szolgáltatás közül az egyik nem érhető el.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Paramétereket állít össze a többi karakterlánc-formázó makróhoz.
    ///
    /// Ez a makró úgy működik, hogy minden további átadott argumentumhoz `{}`-et tartalmazó formázási karakterláncot vesz.
    /// `format_args!` előkészíti a további paramétereket, hogy a kimenet karakterláncként értelmezhető legyen, és az argumentumokat egyetlen típusba kanonizálja.
    /// Bármely érték, amely megvalósítja az [`Display`] trait-t, átadható az `format_args!`-nek, akárcsak bármely [`Debug`]-megvalósítás egy `{:?}`-nek a formázási karaktersorozaton belül.
    ///
    ///
    /// Ez a makró [`fmt::Arguments`] típusú értéket állít elő.Ez az érték átadható az [`std::fmt`]-en belüli makróknak a hasznos átirányítás elvégzéséhez.
    /// Az összes többi formázási makrót ([`format!`], [`write!`], [`println!`] stb.) Ezen keresztül proxyzza.
    /// `format_args!`, a levezetett makróktól eltérően kerüli a halomallokációt.
    ///
    /// Használhatja azt az [`fmt::Arguments`] értéket, amelyet az `format_args!` visszaad `Debug` és `Display` kontextusban, az alábbiak szerint.
    /// A példa azt is megmutatja, hogy az `Debug` és az `Display` ugyanazra a formátumra formálódik: az interpolált formátum-karakterlánc `format_args!`-ben.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// További információ az [`std::fmt`] dokumentációjában található.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Ugyanaz, mint az `format_args`, de a végén új sort ad.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Környezeti változót fordításkor vizsgál.
    ///
    /// Ez a makró kibővül a megnevezett környezeti változó értékére fordításkor, így `&'static str` típusú kifejezést kap.
    ///
    ///
    /// Ha a környezeti változó nincs meghatározva, akkor fordítási hiba lép fel.
    /// Ha nem akar fordítási hibát kiadni, használja inkább az [`option_env!`] makrót.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Testreszabhatja a hibaüzenetet, ha egy második karakterláncot ad át:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Ha az `documentation` környezeti változó nincs meghatározva, a következő hibát kapja:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Opcionálisan fordít egy környezeti változót fordításkor.
    ///
    /// Ha a megnevezett környezeti változó a fordítás idején jelen van, akkor ez egy `Option<&'static str>` típusú kifejezéssé válik, amelynek értéke a környezeti változó értékének `Some`.
    /// Ha a környezeti változó nincs, akkor ez `None`-re bővül.
    /// Erről a típusról további információt az [`Option<T>`][Option] oldalon talál.
    ///
    /// A makró használatakor soha nem kerül kiadásra fordítási időhiba, függetlenül attól, hogy a környezeti változó jelen van-e vagy sem.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Összekapcsolja az azonosítókat egy azonosítóba.
    ///
    /// Ez a makró tetszőleges számú vesszővel elválasztott azonosítót vesz fel, és mindet egybe összefűzi, így egy új azonosító kifejezést kap.
    /// Ne feledje, hogy a higiénia miatt a makró nem képes rögzíteni a helyi változókat.
    /// Általános szabályként a makrók csak elem, utasítás vagy kifejezés pozíciójában engedélyezettek.
    /// Ez azt jelenti, hogy bár ezt a makrót meglévő változókra, függvényekre vagy modulokra stb. Hivatkozhatja, nem definiálhat vele újat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (új, szórakoztató, név) { }//nem használható így!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// A literálokat statikus húrszeletté összefűzi.
    ///
    /// Ez a makró tetszőleges számú vesszővel elválasztott literált vesz fel, így `&'static str` típusú kifejezést kap, amely az összes balról jobbra összefűzött literált ábrázolja.
    ///
    ///
    /// Az egész és a lebegőpontos literálok szigorodnak az összefűzés érdekében.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Kiterjed a sorszámra, amelyre hívták.
    ///
    /// Az [`column!`] és [`file!`] használatával ezek a makrók hibakeresési információkat nyújtanak a fejlesztőknek a forráson belüli helyről.
    ///
    /// A kibővített kifejezés `u32` típusú és 1-alapú, így az egyes fájlok első sora 1-re, a második 2-re stb.
    /// Ez összhangban van a közös fordítók vagy népszerű szerkesztők által küldött hibaüzenetekkel.
    /// A visszaadott sor *nem feltétlenül* maga az `line!` meghívás sora, hanem az első makróhívás, amely az `line!` makró meghívásához vezet.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Kiterjeszti az oszlop számát, amelyen meghívták.
    ///
    /// Az [`line!`] és [`file!`] használatával ezek a makrók hibakeresési információkat nyújtanak a fejlesztőknek a forráson belüli helyről.
    ///
    /// A kibővített kifejezés típusa `u32`, és 1 alapú, így az egyes sorok első oszlopa 1-re, a második 2-re stb.
    /// Ez összhangban van a közös fordítók vagy népszerű szerkesztők által küldött hibaüzenetekkel.
    /// A visszaadott oszlop *nem feltétlenül* maga az `column!` meghívás sora, hanem az első makróhívás, amely az `column!` makró meghívásához vezet.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Kiterjed a fájlnévre, amelyben meghívták.
    ///
    /// Az [`line!`] és [`column!`] használatával ezek a makrók hibakeresési információkat nyújtanak a fejlesztőknek a forráson belüli helyről.
    ///
    /// A kibővített kifejezés `&'static str` típusú, és a visszaküldött fájl nem maga az `file!` makró, hanem az első makró meghívás, amely az `file!` makró meghívásához vezet.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Meghatározza az érveit.
    ///
    /// Ez a makró egy `&'static str` típusú kifejezést eredményez, amely a makrónak átadott összes tokens karakterláncát jelenti.
    /// Magának a makróhívásnak a szintaxisát nem korlátozzák.
    ///
    /// Vegye figyelembe, hogy a tokens bemenet kibővített eredményei változhatnak a future-ben.Legyen óvatos, ha a kimenetre támaszkodik.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Karaktersorozatként tartalmaz egy UTF-8 kódolású fájlt.
    ///
    /// A fájl az aktuális fájlhoz képest helyezkedik el (hasonlóan a modulok megtalálási módjához).
    /// A megadott útvonalat platformspecifikus módon értelmezik a fordítás idején.
    /// Tehát például az `\` visszavágásokat tartalmazó Windows elérési utat tartalmazó meghívás nem fordul le helyesen az Unix eszközön.
    ///
    ///
    /// Ez a makró egy `&'static str` típusú kifejezést eredményez, amely a fájl tartalma.
    ///
    /// # Examples
    ///
    /// Tegyük fel, hogy ugyanabban a könyvtárban két fájl található a következő tartalommal:
    ///
    /// 'spanish.in' fájl:
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// 'main.rs' fájl:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Az 'main.rs' fordítása és az így kapott bináris fájl futtatása kinyomtatja az "adiós" fájlt.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Fájlt tartalmaz egy bájt tömb hivatkozásaként.
    ///
    /// A fájl az aktuális fájlhoz képest helyezkedik el (hasonlóan a modulok megtalálási módjához).
    /// A megadott útvonalat platformspecifikus módon értelmezik a fordítás idején.
    /// Tehát például az `\` visszavágásokat tartalmazó Windows elérési utat tartalmazó meghívás nem fordul le helyesen az Unix eszközön.
    ///
    ///
    /// Ez a makró egy `&'static [u8; N]` típusú kifejezést eredményez, amely a fájl tartalma.
    ///
    /// # Examples
    ///
    /// Tegyük fel, hogy ugyanabban a könyvtárban két fájl található a következő tartalommal:
    ///
    /// 'spanish.in' fájl:
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// 'main.rs' fájl:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Az 'main.rs' fordítása és az így kapott bináris fájl futtatása kinyomtatja az "adiós" fájlt.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Bővül egy karakterláncra, amely az aktuális modul elérési útját képviseli.
    ///
    /// Az aktuális modul elérési útja a crate root-re felfelé vezető modulok hierarchiájának tekinthető.
    /// A visszaadott út első összetevője a jelenleg összeállított crate neve.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Kiértékeli a konfigurációs zászlók logikai kombinációit fordítás idején.
    ///
    /// Az `#[cfg]` attribútum mellett ez a makró lehetővé teszi a konfigurációs zászlók logikai kifejezés kiértékelését.
    /// Ez gyakran kevesebb duplikált kódhoz vezet.
    ///
    /// Ennek a makrónak adott szintaxis megegyezik az [`cfg`] attribútum szintaxisával.
    ///
    /// `cfg!`, az `#[cfg]`-től eltérően nem távolít el egyetlen kódot sem, és csak igaznak vagy hamisnak értékeli.
    /// Például az if/else kifejezés minden blokkjának érvényesnek kell lennie, amikor az állapotra az `cfg!`-et használják, függetlenül attól, hogy az `cfg!` mit értékel.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// A fájlt kifejezésként vagy elemként elemzi a kontextusnak megfelelően.
    ///
    /// A fájl az aktuális fájlhoz képest helyezkedik el (hasonlóan a modulok megtalálási módjához).A megadott útvonalat platformspecifikus módon értelmezik a fordítás idején.
    /// Tehát például az `\` visszavágásokat tartalmazó Windows elérési utat tartalmazó meghívás nem fordul le helyesen az Unix eszközön.
    ///
    /// Ennek a makrónak a használata gyakran rossz ötlet, mert ha a fájlt kifejezésként értelmezik, akkor azt higiénikusan a környező kódba kell helyezni.
    /// Ez azt eredményezheti, hogy a változók vagy a függvények eltérnek a fájltól, ha az aktuális fájlban ugyanazok a változók vagy függvények vannak.
    ///
    ///
    /// # Examples
    ///
    /// Tegyük fel, hogy ugyanabban a könyvtárban két fájl található a következő tartalommal:
    ///
    /// 'monkeys.in' fájl:
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// 'main.rs' fájl:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Az 'main.rs' fordítása és az így kapott bináris fájl futtatása kinyomtatja az "🙈🙊🙉🙈🙊🙉" fájlt.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Azt állítja, hogy a logikai kifejezés futás közben `true`.
    ///
    /// Ez meghívja az [`panic!`] makrót, ha a megadott kifejezést futás közben nem lehet `true`-re értékelni.
    ///
    /// # Uses
    ///
    /// Az állításokat mind a hibakeresés, mind a kiadás buildjeiben mindig ellenőrizzük, és nem lehet letiltani.
    /// Lásd az [`debug_assert!`] azokat az állításokat, amelyek alapértelmezés szerint nincsenek engedélyezve a kiadás buildjeiben.
    ///
    /// A nem biztonságos kód az `assert!`-re támaszkodhat a futási idejű invariánsok kikényszerítésére, amelyek megsértése esetén nem biztonságos.
    ///
    /// Az `assert!` egyéb felhasználási esetei közé tartozik a futásidejű invariánsok biztonságos kódban történő tesztelése és végrehajtása (amelyek megsértése nem vezethet biztonságtalansághoz).
    ///
    ///
    /// # Egyéni üzenetek
    ///
    /// Ennek a makrónak van egy második formája, ahol egy egyéni panic üzenetet lehet megadni argumentummal vagy anélkül a formázáshoz.
    /// Az űrlap szintaxisát lásd az [`std::fmt`]-ben.
    /// A formátum argumentumként használt kifejezéseket csak akkor értékeljük ki, ha az állítás sikertelen.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // ezekhez az állításokhoz a panic üzenet a megadott kifejezés szigorúbb értéke.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // egy nagyon egyszerű funkció
    ///
    /// assert!(some_computation());
    ///
    /// // állítson egyedi üzenettel
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Inline szerelés.
    ///
    /// Olvassa el az [unstable book] alkalmazást.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM stílusú soros szerelés.
    ///
    /// Olvassa el az [unstable book] alkalmazást.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Modulszintű soros szerelés.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// A nyomatok átvitték a tokens-t a standard kimenetbe.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Engedélyezi vagy letiltja a más makrók hibakereséséhez használt nyomkövetési funkciókat.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// A származtatási makrók alkalmazásához használt attribútummakró.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Attribútum makró, amelyet egy függvényhez alkalmaztak, hogy egységtesztké alakítsa.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Attribútummakró, amelyet egy függvényhez alkalmaznak, hogy benchmark tesztké alakítsa.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Az `#[test]` és `#[bench]` makrók megvalósítási részletei.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Egy statikus attribútum makró globális lefoglalóként történő regisztrálásához.
    ///
    /// Lásd még: [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Megtartja az elemet, amelyre alkalmazzák, ha a továbbított elérési út elérhető, és másként eltávolítja.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Kibontja az összes `#[cfg]` és `#[cfg_attr]` attribútumot a kódrészletben, amelyre alkalmazzák.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Az `rustc` fordító instabil megvalósítási részletei, ne használja.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Az `rustc` fordító instabil megvalósítási részletei, ne használja.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}