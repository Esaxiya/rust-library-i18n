Panics az aktuális szál.

Ez lehetővé teszi a program azonnali befejezését és visszajelzést ad a program hívójának.
`panic!` akkor kell használni, ha egy program helyreállhatatlan állapotba kerül.

Ez a makró tökéletes módja a feltételek állításának a példakódban és a tesztekben.
`panic!` szorosan kötődik mind az [`Option`][ounwrap], mind az [`Result`][runwrap] listák `unwrap` módszeréhez.
Mindkét megvalósítás hívja az `panic!`-et, ha [`None`] vagy [`Err`] változatra van állítva.

Az `panic!()` használatakor megadhat egy karaktersorozatot, amely az [`format!`] szintaxisa alapján épül fel.
Ezt a hasznos terhet akkor használják, amikor a panic-t a hívó Rust szálba fecskendezik, és így a szál teljes egészében a panic-hez vezet.

Az alapértelmezett `std` hook viselkedése, azaz
a panic meghívása után közvetlenül futó kód az üzenet hasznos terhelésének nyomtatása az `stderr`-be az `panic!()`-hívás file/line/column-információival együtt.

Az [`std::panic::set_hook()`] használatával felülírhatja a panic hook alkalmazást.
A hook belsejében a panic elérhető `&dyn Any + Send` néven, amely vagy `&str`, vagy `String` rendszeres `panic!()` invokációkhoz.
Egy másik típusú panic-hez az [`panic_any`] használható.

[`Result`] Az enum gyakran jobb megoldás a hibák helyreállításához, mint az `panic!` makró használata.
Ezt a makrót kell használni, hogy elkerülje a helytelen értékek használatát, például külső forrásokból.
A hibakezelésről részletes információkat az [book] tartalmaz.

Lásd még az [`compile_error!`] makrót a hibák felvetéséről a fordítás során.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Jelenlegi megvalósítás

Ha a panics fő szál befejezi az összes szálat, és a programot `101` kóddal fejezi be.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





