#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// A future aszinkron számítást jelent.
///
/// A future olyan érték, amely valószínűleg még nem fejezte be a számítást.
/// Ez a fajta "asynchronous value" lehetővé teszi, hogy egy szál továbbra is hasznos munkát végezzen, miközben várja, amíg az érték elérhetővé válik.
///
///
/// # Az `poll` módszer
///
/// A future, `poll` alapvető módszere *megkísérli* a future végső értékre bontását.
/// Ez a módszer nem blokkolja, ha az érték nem áll készen.
/// Ehelyett az aktuális feladatot a tervek szerint fel kell ébreszteni, ha további előrehaladásra van lehetőség az újabb közvélemény-kutatással.
/// Az `poll` módszernek átadott `context` egy [`Waker`]-et nyújthat, amely egy fogantyú az aktuális feladat felébresztésére.
///
/// A future használatakor általában nem közvetlenül az `poll`-et hívja, hanem az `.await`-et.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// A befejezéskor keletkező érték típusa.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Próbálja meg feloldani a future értéket egy végső értékre, regisztrálva az aktuális feladatot ébresztésre, ha az érték még nem áll rendelkezésre.
    ///
    /// # Visszatérési érték
    ///
    /// Ez a függvény visszatér:
    ///
    /// - [`Poll::Pending`] ha a future még nem áll készen
    /// - [`Poll::Ready(val)`] ennek a future-nek az `val` eredményével, ha sikeresen befejeződött.
    ///
    /// Miután a future elkészült, az ügyfeleknek nem szabad újra `poll`-et használniuk.
    ///
    /// Ha egy future még nem áll készen, az `poll` visszaadja az `Poll::Pending` értéket, és eltárolja az aktuális [`Context`]-ből másolt [`Waker`] klónját.
    /// Ezt az [`Waker`]-et akkor ébresztik fel, ha a future képes haladni.
    /// Például egy future, amely arra vár, hogy egy foglalat olvashatóvá váljon, felhívja az `.clone()`-et az [`Waker`]-en és eltárolja.
    /// Amikor máshova érkezik egy jel, amely jelzi, hogy a foglalat olvasható, akkor az [`Waker::wake`] meghívásra kerül, és a future aljzat feladata felébred.
    /// Miután egy feladat felébredt, meg kell próbálnia újból `poll`-et adni a future-hez, ami előállíthat vagy nem hozhat létre végső értéket.
    ///
    /// Ne feledje, hogy az `poll`-hez intézett többszörös hívások esetén csak az [`Context`]-ből érkező [`Waker`]-et kell ütemezni az ébresztés fogadására.
    ///
    /// # Futásidejű jellemzők
    ///
    /// A Futures önmagában *inert*;*aktívan* közvélemény-kutatni kell őket az előrehaladás érdekében, vagyis minden alkalommal, amikor az aktuális feladatot felébresztik, aktívan újra meg kell kérdeznie a futures függvényében, amely iránt még mindig érdekelt.
    ///
    /// Az `poll` funkciót nem hívják meg ismételten szoros hurokban-ehelyett csak akkor szabad meghívni, ha a future jelzi, hogy készen áll az előrehaladásra (az `wake()`) hívásával.
    /// Ha ismeri az Unix rendszeren az `poll(2)` vagy `select(2)` rendszerhívásokat, érdemes megjegyezni, hogy a futures általában *nem* ugyanazokkal a problémákkal küzd, mint az "all wakeups must poll all events";inkább hasonlítanak az `epoll(4)`-re.
    ///
    /// Az `poll` megvalósításának törekednie kell a gyors visszatérésre, és nem szabad blokkolnia.A gyors visszatérés megakadályozza a szálak vagy eseményhurkok felesleges eltömődését.
    /// Ha idő előtt tudni lehet, hogy az `poll` hívása eltarthat egy ideig, a munkát le kell tölteni egy szálkészletre (vagy valami hasonlóra) annak biztosítása érdekében, hogy az `poll` gyorsan visszatérhessen.
    ///
    /// # Panics
    ///
    /// Miután a future elkészült (`Ready`-t adta vissza az `poll`-ből), az `poll`-módszer újbóli meghívása panic-t örökre blokkolhat, vagy más típusú problémákat okozhat;az `Future` trait nem támaszt követelményeket egy ilyen hívás hatásaival szemben.
    /// Mivel azonban az `poll` módszer nincs `unsafe` jelöléssel ellátva, a Rust szokásos szabályai érvényesek: a hívások soha nem okozhatnak meghatározatlan viselkedést (memória sérülést, az `unsafe` függvények helytelen használatát vagy hasonlókat), függetlenül a future állapotától.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}