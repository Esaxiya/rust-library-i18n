#![stable(feature = "futures_api", since = "1.36.0")]

//! Aszinkron értékek.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Erre a típusra azért van szükség, mert:
///
/// a) A generátorok nem tudják megvalósítani az `for<'a, 'b> Generator<&'a mut Context<'b>>`-et, ezért át kell adnunk egy nyers mutatót (lásd: <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) A nyers mutatók és az `NonNull` nem `Send` vagy `Sync`, tehát ezzel minden egyes future non-Send/Sync is elkészülne, és ezt nem akarjuk.
///
/// Egyszerűsíti az `.await` HIR süllyesztését is.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Csomagoljon egy generátort egy future-be.
///
/// Ez a függvény `GenFuture`-et ad vissza alatta, de elrejti az `impl Trait`-be, hogy jobb hibaüzeneteket kapjon (az `impl Future` helyett `GenFuture<[closure.....]>`).
///
// Ez az `const` az extra hibák elkerülése érdekében, miután helyreálltunk az `const async fn`-ből
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Bízunk abban, hogy az async/await futures mozdulatlan, hogy önreferenciális hitelt hozzunk létre az alapgenerátorban.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // BIZTONSÁG: Biztonságos, mert !Unpin + !Drop vagyunk, és ez csak egy terepi vetítés.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Folytassa a generátort, az `&mut Context`-et `NonNull`-nyers mutatóvá változtatva.
            // Az `.await` süllyesztés ezt biztonságosan visszadobja egy `&mut Context`-be.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // BIZTONSÁG: a hívónak garantálnia kell, hogy az `cx.0` érvényes mutató
    // amely megfelel a mutálható referencia összes követelményének.
    unsafe { &mut *cx.0.as_ptr().cast() }
}