use crate::future::Future;

/// Átalakítás `Future`-be.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Az a kimenet, amelyet a future a befejezéskor produkál.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Melyik future-vé alakítjuk ezt?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// future értéket hoz létre.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}