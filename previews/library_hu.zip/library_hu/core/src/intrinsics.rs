//! Összeállító fordítások.
//!
//! A megfelelő definíciók `compiler/rustc_codegen_llvm/src/intrinsic.rs`-ben vannak.
//! A megfelelő konst implementációk `compiler/rustc_mir/src/interpret/intrinsics.rs`-ben vannak
//!
//! # Const intrinsics
//!
//! Note: az intrinsics állandóságának bármilyen változását meg kell vitatni a nyelvi csapattal.
//! Ez magában foglalja a konstans stabilitásának változását.
//!
//! Annak érdekében, hogy az intrinsic fordítási időben használható legyen, át kell másolni a megvalósítást <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs>-ről `compiler/rustc_mir/src/interpret/intrinsics.rs`-re, és hozzá kell adni egy `#[rustc_const_unstable(feature = "foo", issue = "01234")]`-et az intrinsic-hez.
//!
//!
//! Ha állítólag intrinsicet kell használni egy `const fn`-ből, `rustc_const_stable` attribútummal, akkor az intrinsic attribútumának is `rustc_const_stable`-nek kell lennie.
//! Ilyen változtatás nem hajtható végre T-lang konzultáció nélkül, mert olyan funkciót süt be a nyelvbe, amelyet fordítói támogatás nélkül nem lehet megismételni a felhasználói kódban.
//!
//! # Volatiles
//!
//! Az illékony belső tulajdonságok olyan műveleteket kínálnak, amelyek az I/O memóriára hatnak, és garantált, hogy a fordító azokat nem rendezi át más illékony belső területeken.Lásd az LLVM dokumentációját az [[volatile]] készüléken.
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Az atom belső tulajdonságai közös atomi műveleteket biztosítanak a gépi szavakon, több lehetséges memória-sorrenddel.Ugyanazoknak a szemantikának engedelmeskednek, mint a C++ 11.Lásd az LLVM dokumentációját az [[atomics]] készüléken.
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Gyors frissítés a memória megrendeléséről:
//!
//! * Szerezzen be egy akadályt a zár megszerzéséhez.Az ezt követő olvasások és írások a korlát után következnek be.
//! * Kioldó, korlát a zár feloldásához.Az előző olvasások és írások a sorompó előtt zajlanak.
//! * A szekvenciálisan következetes, egymás után következetes műveletek garantáltan sorrendben történnek.Ez a szokásos mód az atomi típusokkal való munkavégzéshez, és egyenértékű a Java `volatile`-jével.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Ezeket az importokat a dokumentumon belüli kapcsolatok egyszerűsítésére használják
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // BIZTONSÁG: lásd `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // Megjegyzendő, hogy ezek az intrinsicek nyers mutatókat vesznek fel, mert mutánsan aliasizált memóriát mutatnak, ami nem érvényes sem az `&`, sem az `&mut` esetében.
    //

    /// Értéket tárol, ha az aktuális érték megegyezik az `old` értékével.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] típusoknál az `compare_exchange` módszerrel érhető el, az [`Ordering::SeqCst`] átadásával mind az `success`, mind az `failure` paraméterként.
    ///
    /// Például, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Értéket tárol, ha az aktuális érték megegyezik az `old` értékével.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] típusoknál az `compare_exchange` módszerrel érhető el, az [`Ordering::Acquire`] átadásával mind az `success`, mind az `failure` paraméterként.
    ///
    /// Például, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Értéket tárol, ha az aktuális érték megegyezik az `old` értékével.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] típusoknál az `compare_exchange` módszerrel érhető el, az [`Ordering::Release`]-t `success`-ként és [`Ordering::Relaxed`]-t adva `failure`-paraméterként.
    /// Például, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Értéket tárol, ha az aktuális érték megegyezik az `old` értékével.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] típusoknál az `compare_exchange` módszerrel érhető el, az [`Ordering::AcqRel`]-t `success`-ként és [`Ordering::Acquire`]-t adva `failure`-paraméterként.
    /// Például, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Értéket tárol, ha az aktuális érték megegyezik az `old` értékével.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] típusoknál az `compare_exchange` módszerrel érhető el, az [`Ordering::Relaxed`] átadásával mind az `success`, mind az `failure` paraméterként.
    ///
    /// Például, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Értéket tárol, ha az aktuális érték megegyezik az `old` értékével.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] típusoknál az `compare_exchange` módszerrel érhető el, az [`Ordering::SeqCst`]-t `success`-ként és [`Ordering::Relaxed`]-t adva `failure`-paraméterként.
    /// Például, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Értéket tárol, ha az aktuális érték megegyezik az `old` értékével.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] típusoknál az `compare_exchange` módszerrel érhető el, az [`Ordering::SeqCst`]-t `success`-ként és [`Ordering::Acquire`]-t adva `failure`-paraméterként.
    /// Például, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Értéket tárol, ha az aktuális érték megegyezik az `old` értékével.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] típusoknál az `compare_exchange` módszerrel érhető el, az [`Ordering::Acquire`]-t `success`-ként és [`Ordering::Relaxed`]-t adva `failure`-paraméterként.
    /// Például, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Értéket tárol, ha az aktuális érték megegyezik az `old` értékével.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] típusoknál az `compare_exchange` módszerrel érhető el, az [`Ordering::AcqRel`]-t `success`-ként és [`Ordering::Relaxed`]-t adva `failure`-paraméterként.
    /// Például, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Értéket tárol, ha az aktuális érték megegyezik az `old` értékével.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] típusoknál az `compare_exchange_weak` módszerrel érhető el, az [`Ordering::SeqCst`] átadásával mind az `success`, mind az `failure` paraméterként.
    ///
    /// Például, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Értéket tárol, ha az aktuális érték megegyezik az `old` értékével.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] típusoknál az `compare_exchange_weak` módszerrel érhető el, az [`Ordering::Acquire`] átadásával mind az `success`, mind az `failure` paraméterként.
    ///
    /// Például, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Értéket tárol, ha az aktuális érték megegyezik az `old` értékével.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] típusoknál az `compare_exchange_weak` módszerrel érhető el, az [`Ordering::Release`]-t `success`-ként és [`Ordering::Relaxed`]-t adva `failure`-paraméterként.
    /// Például, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Értéket tárol, ha az aktuális érték megegyezik az `old` értékével.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] típusoknál az `compare_exchange_weak` módszerrel érhető el, az [`Ordering::AcqRel`]-t `success`-ként és [`Ordering::Acquire`]-t adva `failure`-paraméterként.
    /// Például, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Értéket tárol, ha az aktuális érték megegyezik az `old` értékével.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] típusoknál az `compare_exchange_weak` módszerrel érhető el, az [`Ordering::Relaxed`] átadásával mind az `success`, mind az `failure` paraméterként.
    ///
    /// Például, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Értéket tárol, ha az aktuális érték megegyezik az `old` értékével.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] típusoknál az `compare_exchange_weak` módszerrel érhető el, az [`Ordering::SeqCst`]-t `success`-ként és [`Ordering::Relaxed`]-t adva `failure`-paraméterként.
    /// Például, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Értéket tárol, ha az aktuális érték megegyezik az `old` értékével.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] típusoknál az `compare_exchange_weak` módszerrel érhető el, az [`Ordering::SeqCst`]-t `success`-ként és [`Ordering::Acquire`]-t adva `failure`-paraméterként.
    /// Például, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Értéket tárol, ha az aktuális érték megegyezik az `old` értékével.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] típusoknál az `compare_exchange_weak` módszerrel érhető el, az [`Ordering::Acquire`]-t `success`-ként és [`Ordering::Relaxed`]-t adva `failure`-paraméterként.
    /// Például, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Értéket tárol, ha az aktuális érték megegyezik az `old` értékével.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] típusoknál az `compare_exchange_weak` módszerrel érhető el, az [`Ordering::AcqRel`]-t `success`-ként és [`Ordering::Relaxed`]-t adva `failure`-paraméterként.
    /// Például, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Betölti a mutató aktuális értékét.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `load` módszerrel, az [`Ordering::SeqCst`] átadásával `order` néven.
    /// Például, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Betölti a mutató aktuális értékét.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `load` módszerrel, az [`Ordering::Acquire`] átadásával `order` néven.
    /// Például, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Betölti a mutató aktuális értékét.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `load` módszerrel, az [`Ordering::Relaxed`] átadásával `order` néven.
    /// Például, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Az értéket a megadott memóriahelyen tárolja.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `store` módszerrel, az [`Ordering::SeqCst`] átadásával `order` néven.
    /// Például, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Az értéket a megadott memóriahelyen tárolja.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `store` módszerrel, az [`Ordering::Release`] átadásával `order` néven.
    /// Például, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Az értéket a megadott memóriahelyen tárolja.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `store` módszerrel, az [`Ordering::Relaxed`] átadásával `order` néven.
    /// Például, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Az értéket a megadott memóriahelyen tárolja, visszaadva a régi értéket.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `swap` módszerrel, az [`Ordering::SeqCst`] átadásával `order` néven.
    /// Például, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Az értéket a megadott memóriahelyen tárolja, visszaadva a régi értéket.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `swap` módszerrel, az [`Ordering::Acquire`] átadásával `order` néven.
    /// Például, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Az értéket a megadott memóriahelyen tárolja, visszaadva a régi értéket.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `swap` módszerrel, az [`Ordering::Release`] átadásával `order` néven.
    /// Például, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Az értéket a megadott memóriahelyen tárolja, visszaadva a régi értéket.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `swap` módszerrel, az [`Ordering::AcqRel`] átadásával `order` néven.
    /// Például, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Az értéket a megadott memóriahelyen tárolja, visszaadva a régi értéket.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `swap` módszerrel, az [`Ordering::Relaxed`] átadásával `order` néven.
    /// Például, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Hozzáadódik az aktuális értékhez, visszaadva az előző értéket.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `fetch_add` módszerrel, az [`Ordering::SeqCst`] átadásával `order` néven.
    /// Például, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hozzáadódik az aktuális értékhez, visszaadva az előző értéket.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `fetch_add` módszerrel, az [`Ordering::Acquire`] átadásával `order` néven.
    /// Például, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hozzáadódik az aktuális értékhez, visszaadva az előző értéket.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `fetch_add` módszerrel, az [`Ordering::Release`] átadásával `order` néven.
    /// Például, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hozzáadódik az aktuális értékhez, visszaadva az előző értéket.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `fetch_add` módszerrel, az [`Ordering::AcqRel`] átadásával `order` néven.
    /// Például, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hozzáadódik az aktuális értékhez, visszaadva az előző értéket.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `fetch_add` módszerrel, az [`Ordering::Relaxed`] átadásával `order` néven.
    /// Például, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Kivonva az aktuális értékből, visszaadva az előző értéket.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `fetch_sub` módszerrel, az [`Ordering::SeqCst`] átadásával `order` néven.
    /// Például, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kivonva az aktuális értékből, visszaadva az előző értéket.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `fetch_sub` módszerrel, az [`Ordering::Acquire`] átadásával `order` néven.
    /// Például, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kivonva az aktuális értékből, visszaadva az előző értéket.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `fetch_sub` módszerrel, az [`Ordering::Release`] átadásával `order` néven.
    /// Például, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kivonva az aktuális értékből, visszaadva az előző értéket.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `fetch_sub` módszerrel, az [`Ordering::AcqRel`] átadásával `order` néven.
    /// Például, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kivonva az aktuális értékből, visszaadva az előző értéket.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `fetch_sub` módszerrel, az [`Ordering::Relaxed`] átadásával `order` néven.
    /// Például, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitenként és az aktuális értékkel, az előző érték visszaadásával.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `fetch_and` módszerrel, az [`Ordering::SeqCst`] átadásával `order` néven.
    /// Például, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitenként és az aktuális értékkel, az előző érték visszaadásával.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `fetch_and` módszerrel, az [`Ordering::Acquire`] átadásával `order` néven.
    /// Például, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitenként és az aktuális értékkel, az előző érték visszaadásával.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `fetch_and` módszerrel, az [`Ordering::Release`] átadásával `order` néven.
    /// Például, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitenként és az aktuális értékkel, az előző érték visszaadásával.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `fetch_and` módszerrel, az [`Ordering::AcqRel`] átadásával `order` néven.
    /// Például, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitenként és az aktuális értékkel, az előző érték visszaadásával.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `fetch_and` módszerrel, az [`Ordering::Relaxed`] átadásával `order` néven.
    /// Például, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitenként nand az aktuális értékkel, az előző érték visszaadásával.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`AtomicBool`] típuson érhető el az `fetch_nand` módszerrel az [`Ordering::SeqCst`] néven `order` néven.
    /// Például, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitenként nand az aktuális értékkel, az előző érték visszaadásával.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`AtomicBool`] típuson érhető el az `fetch_nand` módszerrel az [`Ordering::Acquire`] néven `order` néven.
    /// Például, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitenként nand az aktuális értékkel, az előző érték visszaadásával.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`AtomicBool`] típuson érhető el az `fetch_nand` módszerrel az [`Ordering::Release`] néven `order` néven.
    /// Például, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitenként nand az aktuális értékkel, az előző érték visszaadásával.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`AtomicBool`] típuson érhető el az `fetch_nand` módszerrel az [`Ordering::AcqRel`] néven `order` néven.
    /// Például, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitenként nand az aktuális értékkel, az előző érték visszaadásával.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`AtomicBool`] típuson érhető el az `fetch_nand` módszerrel az [`Ordering::Relaxed`] néven `order` néven.
    /// Például, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitenként vagy az aktuális értékkel, az előző érték visszaadásával.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `fetch_or` módszerrel, az [`Ordering::SeqCst`] átadásával `order` néven.
    /// Például, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitenként vagy az aktuális értékkel, az előző érték visszaadásával.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `fetch_or` módszerrel, az [`Ordering::Acquire`] átadásával `order` néven.
    /// Például, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitenként vagy az aktuális értékkel, az előző érték visszaadásával.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `fetch_or` módszerrel, az [`Ordering::Release`] átadásával `order` néven.
    /// Például, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitenként vagy az aktuális értékkel, az előző érték visszaadásával.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `fetch_or` módszerrel, az [`Ordering::AcqRel`] átadásával `order` néven.
    /// Például, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitenként vagy az aktuális értékkel, az előző érték visszaadásával.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `fetch_or` módszerrel, az [`Ordering::Relaxed`] átadásával `order` néven.
    /// Például, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitenként vagy az aktuális értékkel, visszaadva az előző értéket.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `fetch_xor` módszerrel, az [`Ordering::SeqCst`] átadásával `order` néven.
    /// Például, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitenként vagy az aktuális értékkel, visszaadva az előző értéket.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `fetch_xor` módszerrel, az [`Ordering::Acquire`] átadásával `order` néven.
    /// Például, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitenként vagy az aktuális értékkel, visszaadva az előző értéket.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `fetch_xor` módszerrel, az [`Ordering::Release`] átadásával `order` néven.
    /// Például, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitenként vagy az aktuális értékkel, visszaadva az előző értéket.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `fetch_xor` módszerrel, az [`Ordering::AcqRel`] átadásával `order` néven.
    /// Például, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitenként vagy az aktuális értékkel, visszaadva az előző értéket.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] típusokon az `fetch_xor` módszerrel, az [`Ordering::Relaxed`] átadásával `order` néven.
    /// Például, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maximum az aktuális értékkel, aláírt összehasonlítással.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] aláírt egész típusú típusoknál az `fetch_max` módszerrel érhető el, az [`Ordering::SeqCst`] átadásával `order` néven.
    /// Például, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum az aktuális értékkel, aláírt összehasonlítással.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] aláírt egész típusú típusoknál az `fetch_max` módszerrel érhető el, az [`Ordering::Acquire`] átadásával `order` néven.
    /// Például, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum az aktuális értékkel, aláírt összehasonlítással.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] aláírt egész típusú típusoknál az `fetch_max` módszerrel érhető el, az [`Ordering::Release`] átadásával `order` néven.
    /// Például, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum az aktuális értékkel, aláírt összehasonlítással.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] aláírt egész típusú típusoknál az `fetch_max` módszerrel érhető el, az [`Ordering::AcqRel`] átadásával `order` néven.
    /// Például, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum az aktuális értékkel.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] aláírt egész típusú típusoknál az `fetch_max` módszerrel érhető el, az [`Ordering::Relaxed`] átadásával `order` néven.
    /// Például, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum az aktuális értékkel, aláírt összehasonlítással.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] aláírt egész típusú típusoknál az `fetch_min` módszerrel érhető el, az [`Ordering::SeqCst`] átadásával `order` néven.
    /// Például, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum az aktuális értékkel, aláírt összehasonlítással.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] aláírt egész típusú típusoknál az `fetch_min` módszerrel érhető el, az [`Ordering::Acquire`] átadásával `order` néven.
    /// Például, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum az aktuális értékkel, aláírt összehasonlítással.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] aláírt egész típusú típusoknál az `fetch_min` módszerrel érhető el, az [`Ordering::Release`] átadásával `order` néven.
    /// Például, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum az aktuális értékkel, aláírt összehasonlítással.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] aláírt egész típusú típusoknál az `fetch_min` módszerrel érhető el, az [`Ordering::AcqRel`] átadásával `order` néven.
    /// Például, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum az aktuális értékkel, aláírt összehasonlítással.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] aláírt egész típusú típusoknál az `fetch_min` módszerrel érhető el, az [`Ordering::Relaxed`] átadásával `order` néven.
    /// Például, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum az aktuális értékkel, aláíratlan összehasonlítással.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata elérhető az [`atomic`] előjel nélküli egész típusú típusoknál az `fetch_min` módszerrel, az [`Ordering::SeqCst`] átadásával `order` néven.
    /// Például, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum az aktuális értékkel, aláíratlan összehasonlítással.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] előjel nélküli egész típusú típusoknál az `fetch_min` módszerrel érhető el, az [`Ordering::Acquire`] átadásával `order` néven.
    /// Például, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum az aktuális értékkel, aláíratlan összehasonlítással.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] előjel nélküli egész típusú típusoknál az `fetch_min` módszerrel érhető el, az [`Ordering::Release`] átadásával `order` néven.
    /// Például, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum az aktuális értékkel, aláíratlan összehasonlítással.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] előjel nélküli egész típusú típusoknál az `fetch_min` módszerrel érhető el, az [`Ordering::AcqRel`] átadásával `order` néven.
    /// Például, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum az aktuális értékkel, aláíratlan összehasonlítással.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] előjel nélküli egész típusú típusoknál az `fetch_min` módszerrel érhető el, az [`Ordering::Relaxed`] átadásával `order` néven.
    /// Például, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maximum az aktuális értékkel, aláíratlan összehasonlítással.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] előjel nélküli egész típusú típusoknál az `fetch_max` módszerrel érhető el, az [`Ordering::SeqCst`] átadásával `order` néven.
    /// Például, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum az aktuális értékkel, aláíratlan összehasonlítással.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] előjel nélküli egész típusú típusoknál az `fetch_max` módszerrel érhető el, az [`Ordering::Acquire`] átadásával `order` néven.
    /// Például, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum az aktuális értékkel, aláíratlan összehasonlítással.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] előjel nélküli egész típusú típusoknál az `fetch_max` módszerrel érhető el, az [`Ordering::Release`] átadásával `order` néven.
    /// Például, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum az aktuális értékkel, aláíratlan összehasonlítással.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] előjel nélküli egész típusú típusoknál az `fetch_max` módszerrel érhető el, az [`Ordering::AcqRel`] átadásával `order` néven.
    /// Például, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum az aktuális értékkel, aláíratlan összehasonlítással.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`atomic`] előjel nélküli egész típusú típusoknál az `fetch_max` módszerrel érhető el, az [`Ordering::Relaxed`] átadásával `order` néven.
    /// Például, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Az `prefetch` intrinsic arra utal, hogy a kódgenerátor előretöltési utasítás beillesztésére szolgál, ha támogatott;különben ez nem op.
    /// Az előzetes letöltések nincsenek hatással a program viselkedésére, de megváltoztathatják annak teljesítményjellemzőit.
    ///
    /// Az `locality` argumentumnak állandó egész számnak kell lennie, és egy időbeli helymeghatározó, amely az (0), nincs helység, és az (3) tartományig terjed, rendkívül lokális megőrzés a gyorsítótárban.
    ///
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Az `prefetch` intrinsic arra utal, hogy a kódgenerátor előretöltési utasítás beillesztésére szolgál, ha támogatott;különben ez nem op.
    /// Az előzetes letöltések nincsenek hatással a program viselkedésére, de megváltoztathatják annak teljesítményjellemzőit.
    ///
    /// Az `locality` argumentumnak állandó egész számnak kell lennie, és egy időbeli helymeghatározó, amely az (0), nincs helység, és az (3) tartományig terjed, rendkívül lokális megőrzés a gyorsítótárban.
    ///
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Az `prefetch` intrinsic arra utal, hogy a kódgenerátor előretöltési utasítás beillesztésére szolgál, ha támogatott;különben ez nem op.
    /// Az előzetes letöltések nincsenek hatással a program viselkedésére, de megváltoztathatják annak teljesítményjellemzőit.
    ///
    /// Az `locality` argumentumnak állandó egész számnak kell lennie, és egy időbeli helymeghatározó, amely az (0), nincs helység, és az (3) tartományig terjed, rendkívül lokális megőrzés a gyorsítótárban.
    ///
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Az `prefetch` intrinsic arra utal, hogy a kódgenerátor előretöltési utasítás beillesztésére szolgál, ha támogatott;különben ez nem op.
    /// Az előzetes letöltések nincsenek hatással a program viselkedésére, de megváltoztathatják annak teljesítményjellemzőit.
    ///
    /// Az `locality` argumentumnak állandó egész számnak kell lennie, és egy időbeli helymeghatározó, amely az (0), nincs helység, és az (3) tartományig terjed, rendkívül lokális megőrzés a gyorsítótárban.
    ///
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Atomkerítés.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata [`atomic::fence`]-ben érhető el, ha az [`Ordering::SeqCst`]-et `order`-nek adja át.
    ///
    ///
    pub fn atomic_fence();
    /// Atomkerítés.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata [`atomic::fence`]-ben érhető el, ha az [`Ordering::Acquire`]-et `order`-nek adja át.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Atomkerítés.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata [`atomic::fence`]-ben érhető el, ha az [`Ordering::Release`]-et `order`-nek adja át.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Atomkerítés.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata [`atomic::fence`]-ben érhető el, ha az [`Ordering::AcqRel`]-et `order`-nek adja át.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Csak fordító számára elérhető memória akadály.
    ///
    /// A fordító soha nem rendezi át ezen a korláton a memória-hozzáféréseket, de nem adnak ki utasításokat hozzá.
    /// Ez megfelelő ugyanazon szálon végzett műveleteknél, amelyeket előzetesen meg lehet előzni, például amikor a jelkezelőkkel lépnek kapcsolatba.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata [`atomic::compiler_fence`]-ben érhető el, ha az [`Ordering::SeqCst`]-et `order`-nek adja át.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Csak fordító számára elérhető memória akadály.
    ///
    /// A fordító soha nem rendezi át ezen a korláton a memória-hozzáféréseket, de nem adnak ki utasításokat hozzá.
    /// Ez megfelelő ugyanazon szálon végzett műveleteknél, amelyeket előzetesen meg lehet előzni, például amikor a jelkezelőkkel lépnek kapcsolatba.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata [`atomic::compiler_fence`]-ben érhető el, ha az [`Ordering::Acquire`]-et `order`-nek adja át.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Csak fordító számára elérhető memória akadály.
    ///
    /// A fordító soha nem rendezi át ezen a korláton a memória-hozzáféréseket, de nem adnak ki utasításokat hozzá.
    /// Ez megfelelő ugyanazon szálon végzett műveleteknél, amelyeket előzetesen meg lehet előzni, például amikor a jelkezelőkkel lépnek kapcsolatba.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata [`atomic::compiler_fence`]-ben érhető el, ha az [`Ordering::Release`]-et `order`-nek adja át.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Csak fordító számára elérhető memória akadály.
    ///
    /// A fordító soha nem rendezi át ezen a korláton a memória-hozzáféréseket, de nem adnak ki utasításokat hozzá.
    /// Ez megfelelő ugyanazon szálon végzett műveleteknél, amelyeket előzetesen meg lehet előzni, például amikor a jelkezelőkkel lépnek kapcsolatba.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata [`atomic::compiler_fence`]-ben érhető el, ha az [`Ordering::AcqRel`]-et `order`-nek adja át.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Bűvös mágia, amely jelentését a függvényhez csatolt attribútumokból nyeri.
    ///
    /// Például az adatfolyam ezt használja statikus állítások injektálására, hogy az `rustc_peek(potentially_uninitialized)` valóban kétszer ellenőrizze, hogy az adatfolyam valóban kiszámítja-e, hogy az inicializálatlan a vezérlési folyamat ezen a pontján.
    ///
    ///
    /// Ez a belső nem használható a fordítón kívül.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Megszakítja a folyamat végrehajtását.
    ///
    /// A művelet felhasználóbarátabb és stabilabb változata az [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Tájékoztatja az optimalizálót, hogy a kódnak ez a pontja nem érhető el, lehetővé téve a további optimalizálást.
    ///
    /// Megjegyzés: ez nagyon különbözik az `unreachable!()` makrótól: Ellentétben a makróval, amelyet a panics végrehajtásakor végrehajtunk,*nem definiált viselkedés* elérni az ezzel a funkcióval jelölt kódot.
    ///
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Tájékoztatja az optimalizálót, hogy egy feltétel mindig igaz.
    /// Ha a feltétel hamis, a viselkedés nincs meghatározva.
    ///
    /// Ehhez az intrinzikhez nem jön létre kód, de az optimalizáló megpróbálja megőrizni (és állapotát) a passzok között, ami megzavarhatja a környező kód optimalizálását és csökkentheti a teljesítményt.
    /// Nem szabad használni, ha az invariantot az optimalizáló önmagában képes felfedezni, vagy ha ez nem tesz lehetővé jelentős optimalizálást.
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Tippek a fordítóhoz, hogy a branch feltétel valószínűleg igaz.
    /// Visszaadja a neki átadott értéket.
    ///
    /// Az `if` utasításoktól eltérő felhasználásnak valószínűleg nincs hatása.
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Tippek a fordítóhoz, hogy a branch feltétel valószínűleg hamis.
    /// Visszaadja a neki átadott értéket.
    ///
    /// Az `if` utasításoktól eltérő felhasználásnak valószínűleg nincs hatása.
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Töréspont-csapdát hajt végre, hibakereső általi ellenőrzés céljából.
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    pub fn breakpoint();

    /// A típus mérete bájtokban.
    ///
    /// Pontosabban, ez az egymást követő azonos típusú elemek közötti bájtok közötti eltolás, beleértve az igazítási párnázást is.
    ///
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// A típus minimális igazítása.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// A típus előnyben részesített igazítása.
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// A hivatkozott érték mérete bájtokban.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// A hivatkozott érték szükséges igazítása.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Statikus karakterlánc-szeletet kap, amely tartalmazza a típus nevét.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Olyan azonosítót kap, amely globálisan egyedi a megadott típushoz.
    /// Ez a függvény ugyanazt az értéket adja vissza egy típushoz, függetlenül attól, hogy melyik crate-re hivatkozik.
    ///
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Olyan nem biztonságos funkciók védelme, amelyek soha nem hajthatók végre, ha az `T` lakatlan:
    /// Ez statikusan vagy panic, vagy nem tesz semmit.
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Olyan nem biztonságos funkciók védelme, amelyek soha nem hajthatók végre, ha az `T` nem engedélyezi a nulla inicializálást: Ez statikusan vagy a panic-t fogja végrehajtani, vagy nem tesz semmit.
    ///
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    pub fn assert_zero_valid<T>();

    /// Olyan nem biztonságos funkciók védelme, amelyek soha nem hajthatók végre, ha az `T` érvénytelen bitmintákkal rendelkezik: Ez statikusan vagy panic-t fog tenni, vagy nem tesz semmit.
    ///
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    pub fn assert_uninit_valid<T>();

    /// Hivatkozást kap egy statikus `Location`-re, jelezve, hogy hol hívták.
    ///
    /// Fontolja meg inkább az [`core::panic::Location::caller`](crate::panic::Location::caller) használatát.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Kihúz egy értéket a hatókörből anélkül, hogy csepp ragasztó lenne.
    ///
    /// Ez kizárólag az [`mem::forget_unsized`] esetében létezik;a normál `forget` az `ManuallyDrop`-et használja.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Újraértelmezi az egyik típusú érték bitjeit másik típusként.
    ///
    /// Mindkét típusnak azonos méretűnek kell lennie.
    /// Sem az eredeti, sem az eredmény nem lehet [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` szemantikailag egyenértékű az egyik típus bitenkénti elmozdulásával a másikba.Másolja a biteket a forrásértékből a célértékbe, majd elfelejti az eredetit.
    /// Ez egyenértékű a C `memcpy` motorháztetővel, akárcsak az `transmute_copy`.
    ///
    /// Mivel az `transmute` érték szerinti művelet, maguk a *transzmutált értékek* összehangolása nem okoz gondot.
    /// Mint minden más funkcióhoz, a fordító már biztosítja, hogy az `T` és az `U` is megfelelően illeszkedjen.
    /// Azonban, ha *máshová mutat* értékeket (például mutatókat, referenciákat, dobozokat ...) transzmutál, a hívónak biztosítania kell a mutatott értékek megfelelő összehangolását.
    ///
    /// `transmute` hihetetlenül ** nem biztonságos.Nagyon sokféle módon okozhatja az [undefined behavior][ub]-et ezzel a funkcióval.Az `transmute` kell, hogy legyen a legvégső megoldás.
    ///
    /// Az [nomicon](../../nomicon/transmutes.html) kiegészítő dokumentációval rendelkezik.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Néhány dologban az `transmute` valóban hasznos.
    ///
    /// Mutató fordítása funkciómutatóvá.Ez *nem* hordozható olyan gépeknél, ahol a funkciómutatók és az adatmutatók különböző méretűek.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Egy élettartam meghosszabbítása vagy az invariáns élettartam lerövidítése.Ez fejlett, nagyon nem biztonságos Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Ne essen kétségbe: az `transmute` számos felhasználása elérhető más módszerekkel is.
    /// Az alábbiakban bemutatjuk az `transmute` általános alkalmazásait, amelyek biztonságosabb konstrukciókkal helyettesíthetők.
    ///
    /// A nyers bytes(`&[u8]`) átalakítása `u32`, `f64` stb.
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // használja helyette az `u32::from_ne_bytes`-et
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // vagy az `u32::from_le_bytes` vagy az `u32::from_be_bytes` segítségével adja meg a végességet
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Mutató átalakítása `usize`-be:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Használjon helyette `as` szereplőgárdát
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// `*mut T` átalakítása `&mut T`-be:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Használjon inkább egy hitelt
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// `&mut T` átalakítása `&mut U`-be:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Most az `as` összeszerelésével és az újbóli kölcsönzéssel vegye figyelembe, hogy az `as` láncolása nem tranzitív
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// `&str` átalakítása `&[u8]`-be:
    ///
    /// ```
    /// // ez nem jó módszer erre.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Használhatja az `str::as_bytes`-et
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Vagy használjon csak egy bájtos karakterláncot, ha rendelkezik a sztring literál felett
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// `Vec<&T>` átalakítása `Vec<Option<&T>>`-be.
    ///
    /// A tároló tartalmának belső típusának átalakításához ügyeljen arra, hogy ne sértse meg a tároló egyik invariánsát.
    /// Az `Vec` esetében ez azt jelenti, hogy a belső típusok méretének és az igazításnak * egyaránt meg kell egyeznie.
    /// Más tárolók támaszkodhatnak a típus méretére, az igazításra vagy akár az `TypeId`-re is, ebben az esetben a transzmutáció egyáltalán nem lehetséges a tároló invariánsainak megsértése nélkül.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // klónozza a vector-t, mivel később újra felhasználjuk őket
    /// let v_clone = v_orig.clone();
    ///
    /// // A transmute használata: ez az `Vec` nem meghatározott adatelrendezésére támaszkodik, ami rossz ötlet, és meghatározhatatlan viselkedést okozhat.
    /////
    /// // Ez azonban nem másolat.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Ez a javasolt, biztonságos módszer.
    /// // A teljes vector-t mégis új tömbbe másolja.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Ez az "transmuting" és `Vec` megfelelő másolás nélküli, nem biztonságos módja, anélkül, hogy az adatelrendezésre támaszkodna.
    /// // Ahelyett, hogy szó szerint meghívnánk az `transmute`-et, mutatós leadást hajtunk végre, de az eredeti belső (`&i32`) belső (`Option<&i32>`)-be való átalakítása szempontjából ugyanezek a figyelmeztetések vannak.
    /////
    /// // A fenti információk mellett olvassa el az [`from_raw_parts`] dokumentációját is.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Frissítse ezt, ha a vec_into_raw_parts stabilizálódik.
    ///     // Győződjön meg arról, hogy az eredeti vector nincs elejtve.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Az `split_at_mut` megvalósítása:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Ennek többféle módja van, és a következő (transmute) módszerrel több probléma is felmerül.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // első: a transzmutáció nem biztonságos;csak azt ellenőrzi, hogy T és
    ///         // U azonos méretűek.
    ///         // Másodszor, itt van két mutálható hivatkozás, amelyek ugyanarra a memóriára mutatnak.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Ez megszabadul a típusú biztonsági problémáktól;Az `&mut *`* csak *`&mut T`-et kap `&mut T`-ből vagy `* mut T`-ből.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // azonban még mindig van két ugyanazon memóriára mutató mutábilis hivatkozás.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // A standard könyvtár így csinálja.
    /// // Ez a legjobb módszer, ha ilyesmit kell tennie
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Ennek most három megváltoztatható hivatkozása van, ugyanazon a memórián mutatva.`slice`, az ret.0 érték és az ret.1 érték.
    ///         // `slice` soha nem használják az `let ptr = ...` után, ezért "dead"-ként kezelhetjük, és ezért csak két valódi módosítható szelete van.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Bár ezáltal a belső konst stabillá válik, van néhány egyéni kódunk az const fn-ben
    // ellenőrzések, amelyek megakadályozzák annak használatát az `const fn`-en belül.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Az `true` értéket adja vissza, ha az `T` néven megadott tényleges típus csepp ragasztót igényel;akkor adja vissza az `false` értéket, ha az `T` számára megadott tényleges típus végrehajtja az `Copy` értéket.
    ///
    ///
    /// Ha a tényleges típus nem igényel csepp ragasztót, és nem valósítja meg az `Copy`-et, akkor ennek a függvénynek a visszatérési értéke nincs meghatározva.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Kiszámítja az eltolást egy mutatóból.
    ///
    /// Ezt belső tényezőként valósítják meg, hogy elkerüljék az egész számra való konvertálást, mivel az átalakítás eldobja az álneves információkat.
    ///
    /// # Safety
    ///
    /// A kezdő és az eredményes mutatónak határok között kell lennie, vagy egy bájttal kell lennie a kiosztott objektum végének.
    /// Ha bármelyik mutató határon kívül esik, vagy számtani túlcsordulás következik be, akkor a visszatérített érték további felhasználása meghatározatlan viselkedést eredményez.
    ///
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Kiszámítja az eltolást egy mutatóból, potenciálisan becsomagolva.
    ///
    /// Ezt belső tényezőként valósítják meg, hogy elkerüljék az egész számra történő konvertálást, mivel a konverzió bizonyos optimalizálásokat gátol.
    ///
    /// # Safety
    ///
    /// Az `offset` intrinsic-től eltérően ez az intrinsic nem korlátozza a kapott mutatót arra, hogy a lefoglalt objektum végére mutasson, vagy egy byte-on túlmutasson, és kettő komplementaritmikájával burkol.
    /// Az így kapott érték nem feltétlenül érvényes a memória tényleges elérésére.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Megfelel a megfelelő `llvm.memcpy.p0i8.0i8.*` belső értéknek, `count`*`size_of::<T>()` méretű és
    ///
    /// `min_align_of::<T>()`
    ///
    /// Az illékony paraméter értéke `true`, így csak akkor optimalizálható, ha a méret egyenlő nulla értékkel.
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Megfelel a megfelelő `llvm.memmove.p0i8.0i8.*` belső értéknek, `count* size_of::<T>()` méretével és igazításával
    ///
    /// `min_align_of::<T>()`
    ///
    /// Az illékony paraméter értéke `true`, így csak akkor optimalizálható, ha a méret egyenlő nulla értékkel.
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Megfelel a megfelelő `llvm.memset.p0i8.*` belső értéknek, `count* size_of::<T>()` méretével és `min_align_of::<T>()` igazítással.
    ///
    ///
    /// Az illékony paraméter értéke `true`, így csak akkor optimalizálható, ha a méret egyenlő nulla értékkel.
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Illékony terhelést hajt végre az `src` mutatóból.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Folyékony tárolást hajt végre az `dst` mutatóval.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Illékony terhelést hajt végre az `src` mutatótól A mutatót nem kell igazítani.
    ///
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Folyékony tárolást hajt végre az `dst` mutatóval.
    /// A mutatót nem kell igazítani.
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Visszaadja az `f32` négyzetgyökét
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Visszaadja az `f64` négyzetgyökét
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// `f32` értéket egész hatványra emel.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// `f64` értéket egész hatványra emel.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Visszaadja az `f32` szinuszát.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Visszaadja az `f64` szinuszát.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Egy `f32` koszinuszát adja eredményül.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Egy `f64` koszinuszát adja eredményül.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// `f32`-et `f32`-hez emel.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// `f64`-et `f64`-hez emel.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Visszaadja az `f32` exponenciáját.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Visszaadja az `f64` exponenciáját.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Visszaadja a 2-et egy `f32` erejéig.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Visszaadja a 2-et egy `f64` erejéig.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Visszaadja az `f32` természetes logaritmusát.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Visszaadja az `f64` természetes logaritmusát.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Az `f32` 10 logaritmusát adja eredményül.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Az `f64` 10 logaritmusát adja eredményül.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Visszaadja az `f32` 2 alaplogaritmusát.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Visszaadja az `f64` 2 alaplogaritmusát.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// `a * b + c` értéket ad vissza az `f32` értékekhez.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// `a * b + c` értéket ad vissza az `f64` értékekhez.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Visszaadja az `f32` abszolút értékét.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Visszaadja az `f64` abszolút értékét.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Visszaadja a minimum két `f32` értéket.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Visszaadja a minimum két `f64` értéket.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Visszaadja a maximum két `f32` értéket.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Visszaadja a maximum két `f64` értéket.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Az előjelet `y`-ről `x`-re másolja az `f32` értékekhez.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Az előjelet `y`-ről `x`-re másolja az `f64` értékekhez.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Visszaadja a legnagyobb egész számot, amely kisebb vagy egyenlő, mint egy `f32`.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Visszaadja a legnagyobb egész számot, amely kisebb vagy egyenlő, mint egy `f64`.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Visszaadja a legkisebb egész számot, amely nagyobb vagy egyenlő egy `f32` értékkel.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Visszaadja a legkisebb egész számot, amely nagyobb vagy egyenlő egy `f64` értékkel.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Visszaadja az `f32` egész részét.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Visszaadja az `f64` egész részét.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Visszaadja a legközelebbi egész számot egy `f32` értékre.
    /// Pontatlan lebegőpontos kivételt vethet fel, ha az argumentum nem egész szám.
    pub fn rintf32(x: f32) -> f32;
    /// Visszaadja a legközelebbi egész számot egy `f64` értékre.
    /// Pontatlan lebegőpontos kivételt vethet fel, ha az argumentum nem egész szám.
    pub fn rintf64(x: f64) -> f64;

    /// Visszaadja a legközelebbi egész számot egy `f32` értékre.
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Visszaadja a legközelebbi egész számot egy `f64` értékre.
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Visszaadja a legközelebbi egész számot egy `f32` értékre.Félúton lekerekíti a nullától.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Visszaadja a legközelebbi egész számot egy `f64` értékre.Félúton lekerekíti a nullától.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Úszó hozzáadás, amely lehetővé teszi az algebrai szabályok alapján történő optimalizálást.
    /// Feltételezheti, hogy az inputok végesek.
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Float kivonás, amely lehetővé teszi az algebrai szabályok alapján történő optimalizálást.
    /// Feltételezheti, hogy az inputok végesek.
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Úszó szorzás, amely lehetővé teszi az algebrai szabályok alapján történő optimalizálást.
    /// Feltételezheti, hogy az inputok végesek.
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Float osztás, amely lehetővé teszi az algebrai szabályok alapján történő optimalizálást.
    /// Feltételezheti, hogy az inputok végesek.
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Float maradék, amely lehetővé teszi az algebrai szabályok alapján történő optimalizálást.
    /// Feltételezheti, hogy az inputok végesek.
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Konvertálás az LLVM fptoui/fptosi-szel, amely undef-et adhat a tartományon kívül eső értékekhez
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Stabilizálva [`f32::to_int_unchecked`] és [`f64::to_int_unchecked`] formátumban.
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Visszaadja az `T` típusú egész számban beállított bitek számát
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változatai az egész egész primitíveken elérhetők az `count_ones` módszerrel.
    /// Például,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Visszaadja az `T` vezető nullázatlan bitek számát egy `T` típusú egész számban.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változatai az egész egész primitíveken elérhetők az `leading_zeros` módszerrel.
    /// Például,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// Az `x` `0` értékkel adja vissza az `T` bitszélességét.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Mint az `ctlz`, de rendkívül veszélyes, mivel `undef` értéket ad vissza, ha `x` értéket kap `0` értékkel.
    ///
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Visszaadja az (zeroes) mögött levő, hatástalanított bitek számát egy `T` típusú egész számban.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változatai az egész egész primitíveken elérhetők az `trailing_zeros` módszerrel.
    /// Például,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// Az `x` `0` értékkel adja vissza az `T` bitszélességét:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Mint az `cttz`, de rendkívül veszélyes, mivel `undef` értéket ad vissza, ha `x` értéket kap `0` értékkel.
    ///
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Megfordítja a bájtokat egy `T` típusú egész számban.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változatai az egész egész primitíveken elérhetők az `swap_bytes` módszerrel.
    /// Például,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Megfordítja a biteket egy egész `T` típusban.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változatai az egész egész primitíveken elérhetők az `reverse_bits` módszerrel.
    /// Például,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Ellenőrzött egész szám összeadást hajt végre.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változatai az egész egész primitíveken elérhetők az `overflowing_add` módszerrel.
    /// Például,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Ellenőrzött egész kivonást hajt végre
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változatai az egész egész primitíveken elérhetők az `overflowing_sub` módszerrel.
    /// Például,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Ellenőrzött egész szám szorzást hajt végre
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változatai az egész egész primitíveken elérhetők az `overflowing_mul` módszerrel.
    /// Például,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Pontos osztást végez, amelynek meghatározatlan viselkedése van, ahol `x % y != 0` vagy `y == 0` vagy `x == T::MIN && y == -1`
    ///
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Ellenőrizetlen osztást hajt végre, ami meghatározatlan viselkedést eredményez, ahol az `y == 0` vagy `x == T::MIN && y == -1`
    ///
    ///
    /// Az `checked_div` módszerrel az eredeti primitíveken biztonságos burkolatok állnak rendelkezésre.
    /// Például,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Visszaadja egy nem ellenőrzött osztás fennmaradó részét, ami meghatározatlan viselkedést eredményez `y == 0` vagy `x == T::MIN && y == -1` esetén
    ///
    ///
    /// Az `checked_rem` módszerrel az eredeti primitíveken biztonságos burkolatok állnak rendelkezésre.
    /// Például,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Ellenőrizetlen bal eltolást hajt végre, ami meghatározatlan viselkedést eredményez, amikor `y < 0` vagy `y >= N`, ahol N a T szélessége bitekben.
    ///
    ///
    /// Az `checked_shl` módszerrel az eredeti primitíveken biztonságos burkolatok állnak rendelkezésre.
    /// Például,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Ellenőrizetlen jobb eltolást hajt végre, ami meghatározatlan viselkedést eredményez, amikor `y < 0` vagy `y >= N`, ahol N a T szélessége bitekben.
    ///
    ///
    /// Az `checked_shr` módszerrel az eredeti primitíveken biztonságos burkolatok állnak rendelkezésre.
    /// Például,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Egy nem ellenőrzött összeadás eredményét adja eredményül, ami meghatározatlan viselkedést eredményez `x + y > T::MAX` vagy `x + y < T::MIN` esetén.
    ///
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Egy nem ellenőrzött kivonás eredményét adja eredményül, ami meghatározatlan viselkedést eredményez `x - y > T::MAX` vagy `x - y < T::MIN` esetén.
    ///
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Visszaad egy nem ellenőrzött szorzás eredményét, ami meghatározatlan viselkedést eredményez `x *y > T::MAX` vagy `x* y < T::MIN` esetén.
    ///
    ///
    /// Ennek a belső tulajdonságnak nincs stabil megfelelője.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Balra forgat.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változatai az egész egész primitíveken elérhetők az `rotate_left` módszerrel.
    /// Például,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Jobbra forgat.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változatai az egész egész primitíveken elérhetők az `rotate_right` módszerrel.
    /// Például,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Visszaadja (a + b) mod 2 <sup>N-t</sup>, ahol N a T szélessége bitben.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változatai az egész egész primitíveken elérhetők az `wrapping_add` módszerrel.
    /// Például,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Visszaadja (a, b) mod 2 <sup>N értéket</sup>, ahol N a T szélessége bitekben.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változatai az egész egész primitíveken elérhetők az `wrapping_sub` módszerrel.
    /// Például,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Visszaadja (a * b) mod 2 <sup>N értéket</sup>, ahol N a T szélessége bitben.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változatai az egész egész primitíveken elérhetők az `wrapping_mul` módszerrel.
    /// Például,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Számítja az `a + b`-et, numerikus határokon át telítve.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változatai az egész egész primitíveken elérhetők az `saturating_add` módszerrel.
    /// Például,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Számítja az `a - b`-et, numerikus határokon át telítve.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változatai az egész egész primitíveken elérhetők az `saturating_sub` módszerrel.
    /// Például,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Visszaadja az 'v' változata megkülönböztető értékét;
    /// ha az `T`-nek nincs megkülönböztető értéke, akkor az `0`-et adja vissza.
    ///
    /// Ennek a belső tulajdonságnak a stabilizált változata az [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Visszaadja az `T` típusú változatok számát az `usize` értékre;
    /// ha az `T`-nek nincsenek változatai, akkor az `0`-et adja vissza.A lakatlan változatok megszámlálásra kerülnek.
    ///
    /// Ennek a belső tulajdonságnak a stabilizálható változata az [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// A Rust "try catch" konstrukciója, amely az `try_fn` függvénymutatót meghívja az `data` adatmutatóval.
    ///
    /// A harmadik argumentum egy függvény, amelyet akkor hívunk meg, ha panic történik.
    /// Ez a függvény az adatmutatót és egy mutatót a lefoglalt célspecifikus kivételobjektumhoz viszi.
    ///
    /// További információkért lásd a fordító forrását, valamint a std fogási megvalósítását.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Az LLVM szerint `!nontemporal` tárolót bocsát ki (lásd a dokumentumaikat).
    /// Valószínűleg soha nem lesz stabil.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// A részleteket lásd az `<*const T>::offset_from` dokumentációjában.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// A részleteket lásd az `<*const T>::guaranteed_eq` dokumentációjában.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// A részleteket lásd az `<*const T>::guaranteed_ne` dokumentációjában.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Kiosztás fordításkor.Nem szabad futás közben hívni.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Bizonyos funkciókat itt definiálunk, mert véletlenül elérhetőek lettek ebben a modulban stabilan.
// Lásd: <https://github.com/rust-lang/rust/issues/15702>.
// (Az `transmute` is ebbe a kategóriába tartozik, de nem csomagolható be annak ellenőrzése miatt, hogy az `T` és az `U` azonos méretűek-e.)
//

/// Ellenőrzi, hogy az `ptr` megfelelően illeszkedik-e az `align_of::<T>()`-hez.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Az `count *size_of::<T>()` bájtokat `src`-ről `dst`-re másolja.A forrás és a cél* nem * fedheti egymást.
///
/// Az esetlegesen átfedő memóriaterületekhez használja az [`copy`]-et.
///
/// `copy_nonoverlapping` szemantikailag egyenértékű C [`memcpy`] értékével, de az argumentum sorrendje felcserélődött.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// A viselkedés nincs meghatározva, ha az alábbi feltételek bármelyikét megsértik:
///
/// * `src` [valid] értéknek kell lennie az `count * size_of::<T>()` bájtok olvasásakor.
///
/// * `dst` [valid] értéknek kell lennie az `count * size_of::<T>()` bájtok írásához.
///
/// * Az `src`-et és az `dst`-et egyaránt megfelelően kell beállítani.
///
/// * Az `src`-től kezdődő memóriaterület, a `count méret *
///   mérete: :<T>Az () `bájtoknak * nem szabad átfedniük az azonos méretű `dst`-től kezdődő memóriaterülettel.
///
/// Az [`read`]-hez hasonlóan az `copy_nonoverlapping` létrehozza az `T` bitenkénti másolatát, függetlenül attól, hogy az `T` [`Copy`]-e.
/// Ha az `T` nem [`Copy`], akkor *mindkettő* használatával az `*src`-től kezdődő és az `* dst`-től kezdődő régió értékei [violate memory safety][read-ownership]-t is használhatnak.
///
///
/// Vegye figyelembe, hogy még akkor is, ha a ténylegesen másolt méret (`count * size_of: :<T>()`) értéke `0`, a mutatóknak nem NULL értékűeknek kell lenniük, és megfelelően igazodniuk kell.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Az [`Vec::append`] kézi megvalósítása:
///
/// ```
/// use std::ptr;
///
/// /// Az `src` összes elemét áthelyezi az `dst` fájlba, az `src` elemet üresen hagyja.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Győződjön meg arról, hogy az `dst` elegendő kapacitással rendelkezik az összes `src` tárolásához.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Az ellentételezésre való hívás mindig biztonságos, mert az `Vec` soha nem fog kiosztani többet, mint `isize::MAX` bájt.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Csonkolja meg az `src`-et anélkül, hogy ejtené a tartalmát.
///         // Először ezt tesszük, hogy elkerüljük a problémákat abban az esetben, ha valami lejjebb van a panics alatt.
///         src.set_len(0);
///
///         // A két régió nem fedheti egymást, mert a mutálható hivatkozások nem álnevek, és két különböző vektor nem birtokolhatja ugyanazt a memóriát.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Értesítse az `dst`-et, hogy mostantól tartalmazza az `src` tartalmát.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Ezeket az ellenőrzéseket csak futás közben hajtsa végre
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Nincs pánik, hogy kisebb legyen a kodegen hatása.
        abort();
    }*/

    // BIZTONSÁG: az `copy_nonoverlapping` biztonsági szerződésének meg kell lennie
    // a hívó fél fenntartja.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Az `count * size_of::<T>()` bájtokat `src`-ről `dst`-re másolja.A forrás és a cél átfedhetik egymást.
///
/// Ha a forrás és a cél nem fog soha átfedni, akkor az [`copy_nonoverlapping`] használható.
///
/// `copy` szemantikailag egyenértékű C [`memmove`] értékével, de az argumentum sorrendje felcserélődött.
/// A másolás úgy történik, mintha a bájtokat átmásolták volna az `src`-ből egy ideiglenes tömbbe, majd a tömbből az `dst`-be.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// A viselkedés nincs meghatározva, ha az alábbi feltételek bármelyikét megsértik:
///
/// * `src` [valid] értéknek kell lennie az `count * size_of::<T>()` bájtok olvasásakor.
///
/// * `dst` [valid] értéknek kell lennie az `count * size_of::<T>()` bájtok írásához.
///
/// * Az `src`-et és az `dst`-et egyaránt megfelelően kell beállítani.
///
/// Az [`read`]-hez hasonlóan az `copy` létrehozza az `T` bitenkénti másolatát, függetlenül attól, hogy az `T` [`Copy`]-e.
/// Ha az `T` nem [`Copy`], akkor mind az `*src`-től kezdődő, mind az `* dst`-től kezdődő régió értékeit használhatja az [violate memory safety][read-ownership].
///
///
/// Vegye figyelembe, hogy még akkor is, ha a ténylegesen másolt méret (`count * size_of: :<T>()`) értéke `0`, a mutatóknak nem NULL értékűeknek kell lenniük, és megfelelően igazodniuk kell.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Hatékonyan hozzon létre egy Rust vector nem biztonságos pufferből:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` helyesen kell igazítani a típusához, és nem nulla.
/// /// * `ptr` érvényesnek kell lennie az `elts` típusú összefüggő `T` típusú elemek olvasására.
/// /// * Ezeket az elemeket a funkció meghívása után nem szabad használni, kivéve az `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // BIZTONSÁG: Előfeltételünk biztosítja a forrás összehangolását és érvényességét,
///     // és az `Vec::with_capacity` biztosítja, hogy felhasználható hely áll rendelkezésünkre ezek megírásához.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // BIZTONSÁG: Ennél a kapacitásnál korábban hoztuk létre,
///     // és az előző `copy` inicializálta ezeket az elemeket.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Ezeket az ellenőrzéseket csak futás közben hajtsa végre
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Nincs pánik, hogy kisebb legyen a kodegen hatása.
        abort();
    }*/

    // BIZTONSÁG: az `copy` biztonsági szerződését a hívó félnek be kell tartania.
    unsafe { copy(src, dst, count) }
}

/// Az `count * size_of::<T>()` byte memóriát állítja be `dst`-től `val`-ig.
///
/// `write_bytes` hasonló a C [`memset`]-hez, de az `count * size_of::<T>()` bájtokat `val`-re állítja.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// A viselkedés nincs meghatározva, ha az alábbi feltételek bármelyikét megsértik:
///
/// * `dst` [valid] értéknek kell lennie az `count * size_of::<T>()` bájtok írásához.
///
/// * `dst` megfelelően kell beállítani.
///
/// Ezenkívül a hívónak biztosítania kell, hogy az `count * size_of::<T>()` bájtok beírása az adott memóriaterületre érvényes `T` értéket eredményezzen.
/// Az `T`-ként beírt memóriaterület használata, amely érvénytelen `T`-értéket tartalmaz, nem meghatározott viselkedés.
///
/// Vegye figyelembe, hogy még akkor is, ha a ténylegesen másolt méret (`count * size_of: :<T>()`) `0`, a mutatónak nem NULL értékűnek kell lennie, és megfelelően kell igazodnia.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Alapvető használat:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Érvénytelen érték létrehozása:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Szivárogtatja a korábban birtokolt értéket azáltal, hogy az `Box<T>`-et null mutatóval írja felül.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Ezen a ponton az `v` használata vagy eldobása meghatározatlan viselkedést eredményez.
/// // drop(v); // ERROR
///
/// // Még az `v` "uses" kiszivárogtatása is, ezért meghatározatlan viselkedés.
/// // mem::forget(v); // ERROR
///
/// // Valójában az `v` az alaptípus-elrendezés invariánsai szerint érvénytelen, ezért *minden* művelet, amely megérinti, nem meghatározott viselkedés.
/////
/// // legyen v2 =v;//HIBA
///
/// unsafe {
///     // Helyezzünk el inkább érvényes értéket
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Most a doboz rendben van
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // BIZTONSÁG: az `write_bytes` biztonsági szerződését a hívó félnek be kell tartania.
    unsafe { write_bytes(dst, val, count) }
}