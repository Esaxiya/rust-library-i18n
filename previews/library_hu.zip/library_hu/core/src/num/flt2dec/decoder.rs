//! A lebegőpontos értéket egyes részekre és hibatartományokra dekódolja.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Dekódolt aláíratlan véges érték, oly módon, hogy:
///
/// - Az eredeti érték megegyezik az `mant * 2^exp` értékkel.
///
/// - Az `(mant - minus)*2^exp` és az `(mant + plus)* 2^exp` közötti bármely szám az eredeti értékre kerekszik.
/// A tartomány csak akkor foglal magában, ha `inclusive` `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// A pikkelyes mantissa.
    pub mant: u64,
    /// Az alsó hibatartomány.
    pub minus: u64,
    /// A felső hibatartomány.
    pub plus: u64,
    /// A 2. bázis megosztott kitevője.
    pub exp: i16,
    /// Igaz, ha a hibatartomány befogadó.
    ///
    /// Az IEEE 754-ben ez igaz, amikor az eredeti mantissa egyenletes volt.
    pub inclusive: bool,
}

/// Dekódolt aláíratlan érték.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Végtelen, akár pozitív, akár negatív.
    Infinite,
    /// Nulla, akár pozitív, akár negatív.
    Zero,
    /// Véges számok további dekódolt mezőkkel.
    Finite(Decoded),
}

/// Lebegőpontos típus, amely `dekódolható`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// A minimális pozitív normalizált érték.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Visszaad egy előjelet (igaz, ha negatív) és az `FullDecoded` értéket a megadott lebegőpontos számból.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // szomszédok: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode mindig megőrzi a kitevőt, így a mantiszát alnormálokra méretezik.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // szomszédok: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // ahol maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // szomszédok: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}