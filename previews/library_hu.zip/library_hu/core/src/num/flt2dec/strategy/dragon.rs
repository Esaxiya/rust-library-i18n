//! Majdnem közvetlen (de kissé optimalizált) Rust fordítás a "Lebegőpontos számok gyors és pontos nyomtatása" [^ 1] 3. ábra.
//!
//!
//! [^1]: Burger, RG és Dybvig, RK 1996. Lebegőpontos számok nyomtatása
//!   gyorsan és pontosan.SIGPLAN Nem.31, 5 (1996. május), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// a "Digit" előre kiszámított tömbje 10 ^ (2 ^ n) számára
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// csak akkor használható, ha `x < 16 * scale`;`scaleN` legyen `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// A Dragon legrövidebb módú megvalósítása.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // a formázandó `v` szám ismert:
    // - egyenlő `mant * 2^exp`;
    // - előtte `(mant - 2 *minus)* 2^exp` az eredeti típusban;és
    // - amelyet `(mant + 2 *plus)* 2^exp` követ az eredeti típusban.
    //
    // nyilvánvaló, hogy az `minus` és az `plus` nem lehet nulla.(a végtelenségekhez tartományon kívüli értékeket használunk.) azt is feltételezzük, hogy legalább egy számjegy keletkezik, vagyis az `mant` sem lehet nulla.
    //
    // ez azt is jelenti, hogy az `low = (mant - minus)*2^exp` és `high = (mant + plus)* 2^exp` közötti bármelyik szám pontosan ehhez a lebegőpontos számhoz fog társulni, korlátokkal, ha az eredeti mantissa páros volt (azaz `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` az `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // becsülje meg az `k_0` értéket az `10^(k_0-1) < high <= 10^(k_0+1)`-nek megfelelő eredeti bemenetekről.
    // a szorosan kötött `k`, amely kielégíti az `10^(k-1) < high <= 10^k` értéket, később kiszámításra kerül.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // konvertálja az `{mant, plus, minus} * 2^exp`-et tört formába úgy, hogy:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // ossza `mant`-et `10^k`-re.most `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // javítás, amikor `mant + plus > scale` (vagy `>=`).
    // valójában nem módosítjuk az `scale`-et, mivel ehelyett kihagyhatjuk a kezdeti szorzást.
    // most az `scale < mant + plus <= scale * 10` és készen állunk a számjegyek előállítására.
    //
    // vegye figyelembe, hogy az `d[0]` * értéke nulla lehet, ha az `scale - plus < mant < scale`.
    // ebben az esetben a kerekítési feltétel (`up` lentebb) azonnal elindul.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // egyenértékű az `scale` 10-es méretarányával
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // `(2, 4, 8) * scale` gyorsítótár a számjegy előállításához.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // invariánsok, ahol az `d[0..n-1]` eddig generált számjegy:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (így `mant / scale < 10`), ahol `d[i..j]` a `d [i] * 10 ^ (ji) + rövidítése.
        // + d [j-1] * 10 + d[j]`.

        // egy számjegy generálása: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // ez a módosított Sárkány algoritmus leegyszerűsített leírása.
        // sok közbenső levezetés és teljességi érvelés a kényelem kedvéért elmarad.
        //
        // kezdje módosított invariánsokkal, mivel frissítettük az `n`-et:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // tegyük fel, hogy az `d[0..n-1]` a legrövidebb reprezentáció az `low` és az `high` között, azaz az `d[0..n-1]` kielégíti az alábbiakat, de az `d[0..n-2]` nem:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijektivitás: `v`-ig kerek számjegy);és
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (az utolsó számjegy helyes).
        //
        // a második feltétel leegyszerűsödik `2 * mant <= scale`-re.
        // az invariánsok megoldása `mant`, `low` és `high` szempontból az első feltétel egyszerűbb verzióját eredményezi: `-plus < mant < minus`.
        // `-plus < 0 <= mant` óta `mant < minus` és `2 * mant <= scale` esetén a legrövidebb a reprezentáció.
        // (az előbbi akkor lesz `mant <= minus`, ha az eredeti mantissa egyenletes.)
        //
        // amikor a második nem áll fenn ("2 * mant> skála"), meg kell növelnünk az utolsó számjegyet.
        // ez elég az állapot helyreállításához: már tudjuk, hogy a számjegy generálása garantálja az `0 <= v / 10^(k-n) - d[0..n-1] < 1`-et.
        // ebben az esetben az első feltétel `-plus < mant - scale < minus` lesz.
        // mivel a generáció után az `mant < scale`, nálunk van az `scale < mant + plus`.
        // (ez ismét `scale <= mant + plus` lesz, ha az eredeti mantissa egyenletes.)
        //
        // röviden:
        // - állítsa le és kerekítse az `down`-et (tartsa a számjegyeket), ha `mant < minus` (vagy `<=`).
        // - állítsa le és kerekítse az `up`-et (növelje az utolsó számjegyet), amikor `scale < mant + plus` (vagy `<=`).
        // - folyamatosan generáljon másképp.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // nekünk a legrövidebb az ábrázolásunk, folytassuk a kerekítéssel

        // állítsa helyre az invariánsokat.
        // ezáltal az algoritmus mindig véget ér: az `minus` és az `plus` mindig növekszik, de az `mant` a modulo `scale` és az `scale` rögzített.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // a felfelé kerekítés akkor történik, amikor i) csak a kerekítési feltételt váltották ki, vagy ii) mindkét feltételt kiváltották, és a nyakkendő feltörése a felfelé kerekítést részesíti előnyben.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // ha a felfelé kerekítés megváltoztatja a hosszt, akkor a kitevõnek is változnia kell.
        // úgy tűnik, hogy ezt a feltételt nagyon nehéz kielégíteni (esetleg lehetetlen), de itt csak biztonságban és következetesek vagyunk.
        //
        // BIZTONSÁG: ezt a memóriát fentebb inicializáltuk.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // BIZTONSÁG: ezt a memóriát fentebb inicializáltuk.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// A Dragon pontos és rögzített módú megvalósítása.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // becsülje meg az `k_0` értéket az `10^(k_0-1) < v <= 10^(k_0+1)`-nek megfelelő eredeti bemenetekről.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // ossza `mant`-et `10^k`-re.most `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // javítás, amikor `mant + plus >= scale`, ahol `plus / scale = 10^-buf.len() / 2`.
    // a rögzített méretű bignum megtartása érdekében valójában az `mant + floor(plus) >= scale`-et használjuk.
    // valójában nem módosítjuk az `scale`-et, mivel ehelyett kihagyhatjuk a kezdeti szorzást.
    // a legrövidebb algoritmus mellett az `d[0]` nulla lehet, de végül felfelé kerekít.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // egyenértékű az `scale` 10-es méretarányával
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // ha az utolsó számjegyű korlátozással dolgozunk, akkor a kettős kerekítés elkerülése érdekében le kell rövidítenünk a puffert a tényleges megjelenítés előtt.
    //
    // vegye figyelembe, hogy a felfelé kerekítéskor újra meg kell nagyítanunk a puffert!
    let mut len = if k < limit {
        // hoppá, még egy * számjegyet sem tudunk előállítani.
        // ez akkor lehetséges, ha mondjuk van valami hasonló, mint az 9.5, és 10-re kerekítjük.
        // üres puffert adunk vissza, kivéve a későbbi kerekítési esetet, amely akkor fordul elő, amikor `k == limit` és pontosan egy számjegyet kell előállítania.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // `(2, 4, 8) * scale` gyorsítótár a számjegy előállításához.
        // (ez drága lehet, ezért ne számolja ki őket, ha a puffer üres.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // a következő számjegyek mind nullák, itt megállunk, ne * próbálj meg kerekíteni!inkább töltse ki a fennmaradó számjegyeket.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // BIZTONSÁG: ezt a memóriát fentebb inicializáltuk.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // felfelé kerekítés, ha a számjegyek közepén állunk meg, ha a következő számjegyek pontosan 5000 ..., ellenőrizze az előző számjegyet, és próbáljon párosítani (azaz kerülje a felfelé kerekítést, ha az előző számjegy páros).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // BIZTONSÁG: Az `buf[len-1]` inicializálva van.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // ha a felfelé kerekítés megváltoztatja a hosszt, akkor a kitevõnek is változnia kell.
        // de fix számjegyet kértek tőlünk, ezért ne változtassa meg a puffert ...
        // BIZTONSÁG: ezt a memóriát fentebb inicializáltuk.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... hacsak nem a fix pontosságot kérték tőlünk.
            // azt is ellenőriznünk kell, hogy ha az eredeti puffer üres volt, akkor a további számjegy csak akkor adható hozzá, ha `k == limit` (edge eset).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // BIZTONSÁG: ezt a memóriát fentebb inicializáltuk.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}