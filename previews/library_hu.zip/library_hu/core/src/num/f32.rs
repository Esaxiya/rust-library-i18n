//! Az `f32` egypontos lebegőpontos típusra jellemző állandók.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! Matematikailag jelentős számok vannak megadva az `consts` almodulban.
//!
//! Az ebben a modulban közvetlenül definiált állandók esetében (az `consts` almodulban definiáltaktól eltérően) az új kódnak ehelyett a közvetlenül az `f32` típuson definiált társított állandókat kell használnia.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Az `f32` belső ábrázolásának radixja vagy alapja.
/// Használja helyette az [`f32::RADIX`]-et.
///
/// # Examples
///
/// ```rust
/// // elavult módon
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // szánt módon
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// Jelentős számjegyek száma a 2. alapban.
/// Használja helyette az [`f32::MANTISSA_DIGITS`]-et.
///
/// # Examples
///
/// ```rust
/// // elavult módon
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // szánt módon
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// A 10. számjegyben szereplő jelentős számjegyek hozzávetőleges száma.
/// Használja helyette az [`f32::DIGITS`]-et.
///
/// # Examples
///
/// ```rust
/// // elavult módon
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // szánt módon
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] `f32` értéke.
/// Használja helyette az [`f32::EPSILON`]-et.
///
/// Ez a különbség az `1.0` és a következő nagyobb ábrázolható szám között.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // elavult módon
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // szánt módon
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// A legkisebb véges `f32` érték.
/// Használja helyette az [`f32::MIN`]-et.
///
/// # Examples
///
/// ```rust
/// // elavult módon
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // szánt módon
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// A legkisebb pozitív normális `f32` érték.
/// Használja helyette az [`f32::MIN_POSITIVE`]-et.
///
/// # Examples
///
/// ```rust
/// // elavult módon
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // szánt módon
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// Legnagyobb véges `f32` érték.
/// Használja helyette az [`f32::MAX`]-et.
///
/// # Examples
///
/// ```rust
/// // elavult módon
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // szánt módon
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// Egy nagyobb, mint a 2 kitevő minimális lehetséges normál teljesítménye.
/// Használja helyette az [`f32::MIN_EXP`]-et.
///
/// # Examples
///
/// ```rust
/// // elavult módon
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // szánt módon
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// 2 exponens maximális lehetséges teljesítménye.
/// Használja helyette az [`f32::MAX_EXP`]-et.
///
/// # Examples
///
/// ```rust
/// // elavult módon
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // szánt módon
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// Minimális lehetséges normál teljesítmény 10 exponens.
/// Használja helyette az [`f32::MIN_10_EXP`]-et.
///
/// # Examples
///
/// ```rust
/// // elavult módon
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // szánt módon
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// 10 exponens maximális lehetséges teljesítménye.
/// Használja helyette az [`f32::MAX_10_EXP`]-et.
///
/// # Examples
///
/// ```rust
/// // elavult módon
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // szánt módon
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// Nem (NaN) szám.
/// Használja helyette az [`f32::NAN`]-et.
///
/// # Examples
///
/// ```rust
/// // elavult módon
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // szánt módon
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// Infinity (∞).
/// Használja helyette az [`f32::INFINITY`]-et.
///
/// # Examples
///
/// ```rust
/// // elavult módon
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // szánt módon
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// Negatív végtelen (−∞).
/// Használja helyette az [`f32::NEG_INFINITY`]-et.
///
/// # Examples
///
/// ```rust
/// // elavult módon
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // szánt módon
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// Alapvető matematikai állandók.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: helyett cmath matematikai állandók.

    /// Archimédész állandó (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// A teljes körállandó (τ)
    ///
    /// 2π-vel egyenlő.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// Euler száma (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// Az `f32` belső ábrázolásának radixja vagy alapja.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Jelentős számjegyek száma a 2. alapban.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// A 10. számjegyben szereplő jelentős számjegyek hozzávetőleges száma.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] `f32` értéke.
    ///
    /// Ez a különbség az `1.0` és a következő nagyobb ábrázolható szám között.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// A legkisebb véges `f32` érték.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// A legkisebb pozitív normális `f32` érték.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// Legnagyobb véges `f32` érték.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// Egy nagyobb, mint a 2 kitevő minimális lehetséges normál teljesítménye.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// 2 exponens maximális lehetséges teljesítménye.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// Minimális lehetséges normál teljesítmény 10 exponens.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// 10 exponens maximális lehetséges teljesítménye.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// Nem (NaN) szám.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// Negatív végtelen (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// `true` értéket ad vissza, ha ez az érték `NaN`.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): Az `abs` a hordozhatóság miatt nyilvánosan nem érhető el a libcore-ban, ezért ez a megvalósítás belső használatra készült.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// Visszaadja az `true` értéket, ha ez az érték pozitív végtelen vagy negatív végtelen, más esetben pedig az `false` értéket.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Visszaadja az `true` értéket, ha ez a szám nem végtelen és nem `NaN`.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Nem kell külön kezelni a NaN-ot: ha az én NaN, akkor az összehasonlítás nem igaz, pontosan a kívánt módon.
        //
        self.abs_private() < Self::INFINITY
    }

    /// `true` értéket ad vissza, ha a szám [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // Az `0` és `min` közötti értékek szokatlanok.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// `true` értéket ad vissza, ha a szám nem nulla, végtelen, [subnormal] vagy `NaN`.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // Az `0` és `min` közötti értékek szokatlanok.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Visszaadja a szám lebegőpontos kategóriáját.
    /// Ha csak egy tulajdonságot fogunk tesztelni, akkor általában gyorsabb az adott predikátumot használni.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Visszaadja az `true` értéket, ha az `self` pozitív előjelű, beleértve az `+0.0` értéket, a pozitív Na biteket és a végtelen pozitív NaN-okat.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// Visszaadja az `true` értéket, ha az `self` negatív előjellel rendelkezik, beleértve az `-0.0` értéket, a negatív előjel bitű és a végtelen negatív "NaN" értékeket.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // Az IEEE754 szerint: isSignMinus(x) akkor és akkor igaz, ha x-nek negatív előjele van.
        // Az isSignMinus a nullákra és a NaN-ekre is vonatkozik.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// Veszi a szám reciprok (inverse) értékét, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// A radiánokat fokokra konvertálja.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // A nagyobb pontosság érdekében használjon állandó értéket.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// A fokokat radiánokká konvertálja.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// Visszaadja a két szám maximumát.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Ha az egyik argumentum NaN, akkor a másik argumentum adódik vissza.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// Visszaadja a két szám minimumát.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Ha az egyik argumentum NaN, akkor a másik argumentum adódik vissza.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// Nulla felé fordul, és bármilyen primitív egész típusúvá konvertál, feltéve, hogy az érték véges és megfelel az adott típusnak.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Az értéknek:
    ///
    /// * Ne legyen `NaN`
    /// * Ne légy végtelen
    /// * Legyen reprezentálható az `Int` visszatérő típusban, miután levágta a törtrészét
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // BIZTONSÁG: a hívónak be kell tartania az `FloatToInt::to_int_unchecked` biztonsági szerződését.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Nyers transzmutáció `u32`-re.
    ///
    /// Ez jelenleg minden platformon megegyezik az `transmute::<f32, u32>(self)`-szel.
    ///
    /// A művelet hordozhatóságával kapcsolatban lásd az `from_bits` oldalt (szinte nincsenek problémák).
    ///
    /// Vegye figyelembe, hogy ez a függvény különbözik az `as` castingtól, amely a *numerikus* és nem a bitenkénti értéket próbálja megőrizni.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() nem casting!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // BIZTONSÁG: Az `u32` egy sima régi adattípus, így mindig átválthatunk rá
        unsafe { mem::transmute(self) }
    }

    /// Nyers transzmutáció az `u32`-ből.
    ///
    /// Ez jelenleg minden platformon megegyezik az `transmute::<u32, f32>(v)`-szel.
    /// Kiderült, hogy ez hihetetlenül hordozható, két okból:
    ///
    /// * Az úszóknak és az Ints-eknek minden támogatott platformon azonos az endánia.
    /// * Az IEEE-754 nagyon pontosan meghatározza az úszók bitkiosztását.
    ///
    /// Van azonban egy figyelmeztetés: az IEEE-754 2008-as verziója előtt a NaN jelzőbit értelmezésének valójában nem volt meghatározva.
    /// A legtöbb platform (nevezetesen az x86 és az ARM) a 2008-ban végül egységesített értelmezést választotta, de néhány nem (nevezetesen a MIPS).
    /// Ennek eredményeként az MIPS-en az összes jelző NaN csendes NaN az x86-en, és fordítva.
    ///
    /// Ahelyett, hogy megpróbálná megőrizni a jelátviteli cross-platformokat, ez a megvalósítás a pontos bitek megőrzését támogatja.
    /// Ez azt jelenti, hogy a NaN-okban kódolt hasznos terhelések akkor is megmaradnak, ha ennek a módszernek az eredményét a hálózaton keresztül egy x86 gépről egy MIPS gépre továbbítják.
    ///
    ///
    /// Ha ennek a módszernek az eredményeit csak ugyanaz az architektúra manipulálja, amely előállította őket, akkor nincs hordozhatósági aggály.
    ///
    /// Ha a bemenet nem NaN, akkor nincs hordozhatósági probléma.
    ///
    /// Ha nem érdekel a jelzés (nagyon valószínű), akkor nincs hordozhatósági gond.
    ///
    /// Vegye figyelembe, hogy ez a függvény különbözik az `as` castingtól, amely a *numerikus* és nem a bitenkénti értéket próbálja megőrizni.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // BIZTONSÁG: Az `u32` egy sima régi adattípus, így mindig átválthatunk belőle
        // Kiderült, hogy az sNaN biztonsági problémái túlfeszültek!Hurrá!
        unsafe { mem::transmute(v) }
    }

    /// Ennek a lebegőpontos számnak a memória-reprezentációját adja vissza byte tömbként nagy endián (network) bájt sorrendben.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// Visszaadja ennek a lebegőpontos memóriának a reprezentációját byte tömbként kis endián bájt sorrendben.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// Visszaadja ennek a lebegőpontnak a memóriáját a bájt tömbként natív bájt sorrendben.
    ///
    /// Mivel a célplatform natív endianitását használják, a hordozható kódnak helyette [`to_be_bytes`] vagy [`to_le_bytes`] kell használnia.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// Visszaadja ennek a lebegőpontnak a memóriáját a bájt tömbként natív bájt sorrendben.
    ///
    ///
    /// [`to_ne_bytes`] lehetőség szerint előnyben kell részesíteni.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // BIZTONSÁG: Az `f32` egy sima régi adattípus, így mindig átválthatunk rá
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Hozzon létre egy lebegőpontos értéket a reprezentációjából byte tömbként nagy endiánban.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// Hozzon létre egy lebegőpontos értéket a reprezentációjából byte tömbként kis endiánban.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// Hozzon létre egy lebegőpontos értéket az ábrázolásából bájt tömbként natív endiánban.
    ///
    /// Mivel a célplatform natív endianitását használják, a hordozható kód valószínűleg az [`from_be_bytes`]-et vagy az [`from_le_bytes`]-et akarja használni, helyette.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// Sorrendet ad vissza én és más értékek között.
    /// A lebegőpontos számok szokásos részleges összehasonlításától eltérően ez az összehasonlítás mindig az IEEE 754 (2008-as változat) lebegőpontos szabványban meghatározott totalOrder predikátumnak megfelelő rendezést hoz létre.
    /// Az értékek a következő sorrendben vannak:
    /// - Negatív csendes NaN
    /// - Negatív jelző NaN
    /// - Negatív végtelen
    /// - Negatív számok
    /// - Negatív szubnormális számok
    /// - Negatív nulla
    /// - Pozitív nulla
    /// - Pozitív szubnormális számok
    /// - Pozitív számok
    /// - Pozitív végtelen
    /// - Pozitív jelző NaN
    /// - Pozitív csendes NaN
    ///
    /// Vegye figyelembe, hogy ez a funkció nem mindig egyezik az `f32` [`PartialOrd`] és [`PartialEq`] megvalósításával.Különösen negatív és pozitív nullát tekintenek egyenlőnek, míg az `total_cmp` nem.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // Negatívumok esetén fordítsa az előjel kivételével az összes bitet, hogy hasonló elrendezést érjen el, mint a kettő egészének egésze
        //
        // Miért működik ez?Az IEEE 754 úszók három mezőből állnak:
        // Jel bit, kitevő és mantissa.Az exponens és a mantissza mezők halmazának egészében megvan az a tulajdonsága, hogy bitenkénti sorrendjük megegyezik a numerikus nagyságrenddel, ahol a nagyság meghatározva van.
        // A nagyságrendet általában nem a NaN-értékek határozzák meg, de az IEEE 754 totalOrder a NaN-értékeket a bitenkénti sorrend szerint is meghatározza.Ez a doki kommentárban kifejtett rendhez vezet.
        // A nagyság ábrázolása azonban megegyezik a negatív és a pozitív számok esetében is-csak az előjel bit különbözik.
        // Az úszók előjeles egész számok közötti egyszerű összehasonlításához negatív számok esetén meg kell fordítanunk az exponens és a mantissza biteket.
        // Hatékonyan konvertáljuk a számokat "two's complement" formába.
        //
        // A lapozáshoz maszkot és XOR-ot építünk rá.
        // Elágazás nélkül kiszámolunk egy "all-ones except for the sign bit" maszkot negatív előjellel ellátott értékekből: a jobbra toló előjel kiterjeszti az egész számot, tehát "fill" a maszkot előjel bitekkel, majd átalakítjuk előjel nélkülivé, hogy még egy nulla bitet toljunk.
        //
        // Pozitív értékeken a maszk nulla, tehát nem kötelező.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// Szűkítsen egy értéket egy bizonyos intervallumra, hacsak nem NaN.
    ///
    /// `max` értéket ad vissza, ha `self` nagyobb, mint `max`, és `min`, ha `self` kisebb, mint `min`.
    /// Ellenkező esetben ez az `self` értéket adja vissza.
    ///
    /// Vegye figyelembe, hogy ez a függvény NaN-értéket ad vissza, ha a kezdeti érték NaN is volt.
    ///
    /// # Panics
    ///
    /// Panics, ha `min > max`, `min` NaN, vagy `max` NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}