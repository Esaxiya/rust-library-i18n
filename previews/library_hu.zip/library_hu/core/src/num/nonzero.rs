//! Az egész szám definíciói, amelyekről ismert, hogy nem egyenlő nullával.

use crate::fmt;
use crate::ops::{BitOr, BitOrAssign, Div, Rem};
use crate::str::FromStr;

use super::from_str_radix;
use super::{IntErrorKind, ParseIntError};
use crate::intrinsics;

macro_rules! impl_nonzero_fmt {
    ( #[$stability: meta] ( $( $Trait: ident ),+ ) for $Ty: ident ) => {
        $(
            #[$stability]
            impl fmt::$Trait for $Ty {
                #[inline]
                fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                    self.get().fmt(f)
                }
            }
        )+
    }
}

macro_rules! nonzero_integers {
    ( $( #[$stability: meta] $Ty: ident($Int: ty); )+ ) => {
        $(
            /// Egész szám, amelyről ismert, hogy nem egyenlő nullával.
            ///
            /// Ez lehetővé teszi a memória elrendezésének néhány optimalizálását.
            #[doc = concat!("For example, `Option<", stringify!($Ty), ">` is the same size as `", stringify!($Int), "`:")]
            /// ```rust
            /// használja az std::mem::size_of-et;
            #[doc = concat!("assert_eq!(size_of::<Option<core::num::", stringify!($Ty), ">>(), size_of::<", stringify!($Int), ">());")]
            /// ```
            #[$stability]
            #[derive(Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
            #[repr(transparent)]
            #[rustc_layout_scalar_valid_range_start(1)]
            #[rustc_nonnull_optimization_guaranteed]
            pub struct $Ty($Int);

            impl $Ty {
                /// Nem nulla értéket hoz létre az érték ellenőrzése nélkül.
                ///
                /// # Safety
                ///
                /// Az érték nem lehet nulla.
                #[$stability]
                #[rustc_const_stable(feature = "nonzero", since = "1.34.0")]
                #[inline]
                pub const unsafe fn new_unchecked(n: $Int) -> Self {
                    // BIZTONSÁG: ezt a hívó garantálja.
                    unsafe { Self(n) }
                }

                /// Nem nullát hoz létre, ha az adott érték nem nulla.
                #[$stability]
                #[rustc_const_stable(feature = "const_nonzero_int_methods", since = "1.47.0")]
                #[inline]
                pub const fn new(n: $Int) -> Option<Self> {
                    if n != 0 {
                        // BIZTONSÁG: Most ellenőriztük, hogy nincs-e `0`
                        Some(unsafe { Self(n) })
                    } else {
                        None
                    }
                }

                /// Az értéket primitív típusként adja vissza.
                #[$stability]
                #[inline]
                #[rustc_const_stable(feature = "nonzero", since = "1.34.0")]
                pub const fn get(self) -> $Int {
                    self.0
                }

            }

            #[stable(feature = "from_nonzero", since = "1.31.0")]
            impl From<$Ty> for $Int {
                #[doc = concat!("Converts a `", stringify!($Ty), "` into an `", stringify!($Int), "`")]
                #[inline]
                fn from(nonzero: $Ty) -> Self {
                    nonzero.0
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOr for $Ty {
                type Output = Self;
                #[inline]
                fn bitor(self, rhs: Self) -> Self::Output {
                    // BIZTONSÁG: mivel az `self` és az `rhs` egyaránt nulla, az
                    // a bitenkénti eredménye, vagy nem lesz nulla.
                    unsafe { $Ty::new_unchecked(self.get() | rhs.get()) }
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOr<$Int> for $Ty {
                type Output = Self;
                #[inline]
                fn bitor(self, rhs: $Int) -> Self::Output {
                    // BIZTONSÁG: mivel az `self` nem nulla, a
                    // bitenként vagy nem nulla lesz, függetlenül az `rhs` értékétől.
                    //
                    unsafe { $Ty::new_unchecked(self.get() | rhs) }
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOr<$Ty> for $Int {
                type Output = $Ty;
                #[inline]
                fn bitor(self, rhs: $Ty) -> Self::Output {
                    // BIZTONSÁG: mivel az `rhs` nem nulla, a
                    // bitenként vagy nem nulla lesz, függetlenül az `self` értékétől.
                    //
                    unsafe { $Ty::new_unchecked(self | rhs.get()) }
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOrAssign for $Ty {
                #[inline]
                fn bitor_assign(&mut self, rhs: Self) {
                    *self = *self | rhs;
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOrAssign<$Int> for $Ty {
                #[inline]
                fn bitor_assign(&mut self, rhs: $Int) {
                    *self = *self | rhs;
                }
            }

            impl_nonzero_fmt! {
                #[$stability] (Debug, Display, Binary, Octal, LowerHex, UpperHex) for $Ty
            }
        )+
    }
}

nonzero_integers! {
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU8(u8);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU16(u16);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU32(u32);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU64(u64);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU128(u128);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroUsize(usize);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI8(i8);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI16(i16);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI32(i32);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI64(i64);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI128(i128);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroIsize(isize);
}

macro_rules! from_str_radix_nzint_impl {
    ($($t:ty)*) => {$(
        #[stable(feature = "nonzero_parse", since = "1.35.0")]
        impl FromStr for $t {
            type Err = ParseIntError;
            fn from_str(src: &str) -> Result<Self, Self::Err> {
                Self::new(from_str_radix(src, 10)?)
                    .ok_or(ParseIntError {
                        kind: IntErrorKind::Zero
                    })
            }
        }
    )*}
}

from_str_radix_nzint_impl! { NonZeroU8 NonZeroU16 NonZeroU32 NonZeroU64 NonZeroU128 NonZeroUsize
NonZeroI8 NonZeroI16 NonZeroI32 NonZeroI64 NonZeroI128 NonZeroIsize }

macro_rules! nonzero_leading_trailing_zeros {
    ( $( $Ty: ident($Uint: ty) , $LeadingTestExpr:expr ;)+ ) => {
        $(
            impl $Ty {
                /// Visszaadja a vezető nullák számát az `self` bináris ábrázolásában.
                ///
                /// Számos architektúrán ez a függvény jobban képes teljesíteni, mint az `leading_zeros()` az alapul szolgáló egész típusú típusnál, mivel elkerülhető a nulla speciális kezelése.
                ///
                /// # Examples
                ///
                /// Alapvető használat:
                ///
                /// ```
                /// #![feature(nonzero_leading_trailing_zeros)]
                #[doc = concat!("let n = std::num::", stringify!($Ty), "::new(", stringify!($LeadingTestExpr), ").unwrap();")]
                /// assert_eq!(n.leading_zeros(), 0);
                /// ```
                #[unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[rustc_const_unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[inline]
                pub const fn leading_zeros(self) -> u32 {
                    // BIZTONSÁG: mivel az `self` nem lehet nulla, biztonságos a ctlz_nonzero hívása
                    unsafe { intrinsics::ctlz_nonzero(self.0 as $Uint) as u32 }
                }

                /// Visszaadja a záró nullák számát az `self` bináris ábrázolásában.
                ///
                /// Számos architektúrán ez a függvény jobban képes teljesíteni, mint az `trailing_zeros()` az alapul szolgáló egész típusú típusnál, mivel elkerülhető a nulla speciális kezelése.
                ///
                ///
                /// # Examples
                ///
                /// Alapvető használat:
                ///
                /// ```
                /// #![feature(nonzero_leading_trailing_zeros)]
                #[doc = concat!("let n = std::num::", stringify!($Ty), "::new(0b0101000).unwrap();")]
                /// assert_eq!(n.trailing_zeros(), 3);
                /// ```
                #[unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[rustc_const_unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[inline]
                pub const fn trailing_zeros(self) -> u32 {
                    // BIZTONSÁG: mivel az `self` nem lehet nulla, biztonságos a cttz_nonzero hívása
                    unsafe { intrinsics::cttz_nonzero(self.0 as $Uint) as u32 }
                }

            }
        )+
    }
}

nonzero_leading_trailing_zeros! {
    NonZeroU8(u8), u8::MAX;
    NonZeroU16(u16), u16::MAX;
    NonZeroU32(u32), u32::MAX;
    NonZeroU64(u64), u64::MAX;
    NonZeroU128(u128), u128::MAX;
    NonZeroUsize(usize), usize::MAX;
    NonZeroI8(u8), -1i8;
    NonZeroI16(u16), -1i16;
    NonZeroI32(u32), -1i32;
    NonZeroI64(u64), -1i64;
    NonZeroI128(u128), -1i128;
    NonZeroIsize(usize), -1isize;
}

macro_rules! nonzero_integers_div {
    ( $( $Ty: ident($Int: ty); )+ ) => {
        $(
            #[stable(feature = "nonzero_div", since = "1.51.0")]
            impl Div<$Ty> for $Int {
                type Output = $Int;
                /// Ez a művelet nulla felé kerekszik, megcsonkítva a pontos eredmény bármely részét, és nem tudja panic.
                ///
                #[inline]
                fn div(self, other: $Ty) -> $Int {
                    // BIZTONSÁG: a nullával való osztás be van jelölve, mert az `other` nem nulla,
                    // és az MIN/-1 be van jelölve, mert az `self` előjel nélküli int.
                    unsafe { crate::intrinsics::unchecked_div(self, other.get()) }
                }
            }

            #[stable(feature = "nonzero_div", since = "1.51.0")]
            impl Rem<$Ty> for $Int {
                type Output = $Int;
                /// Ez a művelet kielégíti az `n % d == n - (n / d) * d`-et, és nem tudja a panic-t.
                #[inline]
                fn rem(self, other: $Ty) -> $Int {
                    // BIZTONSÁG: a nullával történő javítás be van jelölve, mert az `other` nem nulla,
                    // és az MIN/-1 be van jelölve, mert az `self` előjel nélküli int.
                    unsafe { crate::intrinsics::unchecked_rem(self, other.get()) }
                }
            }
        )+
    }
}

nonzero_integers_div! {
    NonZeroU8(u8);
    NonZeroU16(u16);
    NonZeroU32(u32);
    NonZeroU64(u64);
    NonZeroU128(u128);
    NonZeroUsize(usize);
}

macro_rules! nonzero_unsigned_is_power_of_two {
    ( $( $Ty: ident )+ ) => {
        $(
            impl $Ty {

                /// Csak akkor adja vissza az `true` értéket, ha `self == (1 << k)` néhány `k` esetén.
                ///
                /// Számos architektúrán ez a függvény jobban képes teljesíteni, mint az `is_power_of_two()` az alapul szolgáló egész típusú típusnál, mivel elkerülhető a nulla speciális kezelése.
                ///
                ///
                /// # Examples
                ///
                /// Alapvető használat:
                ///
                /// ```
                /// #![feature(nonzero_is_power_of_two)]
                ///
                #[doc = concat!("let eight = std::num::", stringify!($Ty), "::new(8).unwrap();")]
                /// assert!(eight.is_power_of_two());
                #[doc = concat!("let ten = std::num::", stringify!($Ty), "::new(10).unwrap();")]
                /// assert!(!ten.is_power_of_two());
                /// ```
                #[unstable(feature = "nonzero_is_power_of_two", issue = "81106")]
                #[inline]
                pub const fn is_power_of_two(self) -> bool {
                    // Az LLVM 11 normalizálja az `unchecked_sub(x, 1) & x == 0`-et az itt látható megvalósításhoz.
                    // Az alap x86-64 célnál ez 3 utasítást menti a nulla ellenőrzéshez.
                    // Az x86_64 és BMI1 kapcsolókon a nulla állapot lehetővé teszi az `BLSR` kódolását, amely az `POPCNT` megvalósításhoz képest utasítást menti az alapul szolgáló egész típusú típuson.
                    //

                    intrinsics::ctpop(self.get()) < 2
                }

            }
        )+
    }
}

nonzero_unsigned_is_power_of_two! { NonZeroU8 NonZeroU16 NonZeroU32 NonZeroU64 NonZeroU128 NonZeroUsize }