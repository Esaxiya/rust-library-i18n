//! Bit hegedülés a pozitív IEEE 754 úszókon.A negatív számokat nem kell kezelni.
//! A normál lebegőpontos számok kanonikus ábrázolása (frac, exp), így az érték 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)), ahol N a bitek száma.
//!
//! A normális normák kissé különböznek és furcsák, de ugyanaz az elv érvényesül.
//!
//! Itt azonban (sig, k) formában ábrázoljuk őket f pozitív értékkel, így az érték f *
//! 2 <sup>e</sup> .Az "hidden bit" egyértelművé tétele mellett ez megváltoztatja a kitevőt az úgynevezett mantissa-eltolással.
//!
//! Másképp fogalmazva: az úszókat általában (1)-nek írják, de itt (2)-nek írják:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Az (1)-et **frakcionális reprezentációnak**, az (2)-et pedig **integrális reprezentációnak** hívjuk.
//!
//! A modul számos funkciója csak normál számokat kezel.A dec2flt rutinok konzervatív módon járnak el az univerzálisan helyes lassú pályán (M algoritmus) nagyon kis és nagyon nagy számok esetén.
//! Ehhez az algoritmushoz csak az next_float() szükséges, amely kezeli a normálist és a nullákat.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Segítő trait, hogy elkerülje az `f32` és `f64` összes konverziós kódjának lényegében történő másolatát.
///
/// Lásd a szülő modul doc megjegyzését, hogy miért van erre szükség.
///
/// Soha nem szabad ** soha végrehajtani más típusoknál, vagy a dec2flt modulon kívül használni.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Az `to_bits` és az `from_bits` által használt típus.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Nyers transzmutációt hajt végre egész számra.
    fn to_bits(self) -> Self::Bits;

    /// Nyers transzmutációt hajt végre egész számból.
    fn from_bits(v: Self::Bits) -> Self;

    /// Visszaadja azt a kategóriát, amelybe ez a szám tartozik.
    fn classify(self) -> FpCategory;

    /// Visszaadja a mantissa, kitevő és előjel egész számokat.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Dekódolja az úszót.
    fn unpack(self) -> Unpacked;

    /// Kis egész számból önt, amely pontosan ábrázolható.
    /// Panic ha az egész szám nem ábrázolható, akkor a modul másik kódja gondoskodik róla, hogy soha ne történjen meg.
    fn from_int(x: u64) -> Self;

    /// Megkapja a 10 <sup>e</sup> értéket egy előre kiszámított táblázatból.
    /// Panics for `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Amit a név mond.
    /// Könnyebb a hardveres kódolás, mint az intrinsics zsonglőrködése és reménye, hogy az LLVM állandóan összehajtja.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Egy konzervatív a bemenetek tizedesjegyeire kötött, amelyek nem képesek túlcsordulást vagy nulla vagy
    /// alnormálisak.Valószínűleg a maximális normálérték decimális kitevője, innen a név.
    const MAX_NORMAL_DIGITS: usize;

    /// Ha a legjelentősebb tizedesjegynek ennél nagyobb a helyértéke, akkor a számot minden bizonnyal a végtelenre kerekítjük.
    ///
    const INF_CUTOFF: i64;

    /// Ha a legjelentősebb tizedesjegynek ennél kisebb a helyértéke, akkor a számot biztosan nullára kerekítjük.
    ///
    const ZERO_CUTOFF: i64;

    /// Az exponens bitjeinek száma.
    const EXP_BITS: u8;

    /// A szignifikáns bitek száma, * beleértve a rejtett bitet is.
    const SIG_BITS: u8;

    /// A szignifikáns bitek száma, * a rejtett bit kivételével.
    const EXPLICIT_SIG_BITS: u8;

    /// A törvényes reprezentáció maximális jogi kitevője.
    const MAX_EXP: i16;

    /// A törvényes reprezentáció minimális jogi kitevője, az alnormális értékek kivételével.
    const MIN_EXP: i16;

    /// `MAX_EXP` az integrált ábrázoláshoz, azaz az alkalmazott eltolással.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` kódolt (azaz ofszet elfogultsággal)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` az integrált ábrázoláshoz, azaz az alkalmazott eltolással.
    const MIN_EXP_INT: i16;

    /// A maximálisan normalizált szignifikancia integrált ábrázolásban.
    const MAX_SIG: u64;

    /// A minimális normalizált szignifikancia integrális ábrázolásban.
    const MIN_SIG: u64;
}

// Leginkább az #34344 megoldása.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Visszaadja a mantissa, kitevő és előjel egész számokat.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Exponens torzítás + mantissza váltás
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // Az rkruppe nem biztos abban, hogy az `as` minden platformon megfelelően kerek-e.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Visszaadja a mantissa, kitevő és előjel egész számokat.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Exponens torzítás + mantissza váltás
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // Az rkruppe nem biztos abban, hogy az `as` minden platformon megfelelően kerek-e.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Átalakítja az `Fp`-et a legközelebbi gépi úszó típusra.
/// Nem kezeli a szokatlan eredményeket.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 bites, tehát xe mantiszaváltása 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// A 64 bites szignifikont kerekítse T::SIG_BITS bitekre félig-egyenletesen.
/// Nem kezeli az exponens túlcsordulását.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Állítsa be a mantissza váltást
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Az `RawFloat::unpack()` fordított értéke normalizált számok esetén.
/// Panics, ha a szignifikáns vagy kitevő nem érvényes a normalizált számokra.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Távolítsa el a rejtett bitet
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Állítsa be a kitevőt az exponens torzításának és a mantissza elmozdulásának
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Hagyja az előjelbitet 0 ("+") értéken, számunk pozitív
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Konstrukció egy alnormális.A 0 mantissza megengedett és nullát konstruál.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // A kódolt kitevő 0, az előjel bit 0, ezért csak újra kell értelmeznünk a biteket.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Körülbelül egy bignumot Fp-vel.Körül az 0.5 ULP-n belül, félig egyenletes.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Az `start` index előtti összes bitet levágtuk, vagyis gyakorlatilag jobbra tolunk egy `start` összeggel, tehát ez az a kitevő is, amelyre szükségünk van.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Kerek (half-to-even) a csonka bitektől függően.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Megtalálja a legnagyobb lebegőpontos számot, amely szigorúan kisebb, mint az argumentum.
/// Nem kezeli a normálist, a nulla vagy az exponens alulfolyást.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Keresse meg a legkisebb lebegőpontos számot, amely szigorúan nagyobb, mint az argumentum.
// Ez a művelet telítődik, azaz next_float(inf) ==inf.
// A modul legtöbb kódjától eltérően ez a függvény nulla, alnormális és végtelen értékeket kezel.
// Ugyanakkor, mint minden más kód itt, ez sem foglalkozik a NaN és a negatív számokkal.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Ez túl jónak tűnik, hogy igaz legyen, de működik.
        // 0.0 mind-nulla szóként van kódolva.A normális értékek 0x000m ... m, ahol m a mantissza.
        // Különösen a legkisebb alnormális 0x0 ... 01, a legnagyobb pedig 0x000F ... F.
        // A legkisebb normál szám 0x0010 ... 0, tehát ez a sarok tok is működik.
        // Ha a növekmény túlcsordítja a mantissát, akkor a hordozó bit tetszés szerint növeli a kitevőt, és a mantiszta bitek nullává válnak.
        // A rejtett bitmegállapodás miatt ezt is pontosan szeretnénk!
        // Végül f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}