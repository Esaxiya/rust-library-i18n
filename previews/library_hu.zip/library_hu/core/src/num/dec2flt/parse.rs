//! Az űrlap tizedes karakterláncának ellenőrzése és bontása:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Más szavakkal, standard lebegőpontos szintaxis, két kivétellel: Nincs előjel, és nem kezelhető az "inf" és az "NaN".Ezeket az (super::dec2flt) illesztőprogram kezeli.
//!
//! Bár az érvényes bemenetek felismerése viszonylag egyszerű, ennek a modulnak el kell utasítania a számtalan érvénytelen változatot, soha nem a panic-t, és számos ellenőrzést kell végrehajtania, amelyekre a többi modul támaszkodik, nem pedig a panic (vagy túlcsordulás).
//!
//! A helyzetet tovább rontja, hogy mindez egyetlen lépésben történik a bemenet felett.
//! Tehát legyen óvatos, ha bármit módosít, és ellenőrizze még egyszer a többi modult.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// A tizedes karakterlánc érdekes részei.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// A tizedes kitevő, garantáltan kevesebb, mint 18 tizedesjegy.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Ellenőrzi, hogy a bemeneti karakterlánc érvényes lebegőpont-e, és ha igen, keresse meg benne az integrált részt, a tört részt és a kitevőt.
/// Nem kezeli a jeleket.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Nincs számjegy az 'e' előtt
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Legalább egy számjegyre van szükségünk a pont előtt vagy után.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // A hátsó szemét a törtrész után
            }
        }
        _ => Invalid, // Utolsó szemét az első számjegyű karakterlánc után
    }
}

/// Tizedesjegyeket vág le az első nem számjegyű karakterig.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Exponens kinyerése és a hibák ellenőrzése.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Utánhulló szemét kitevő után
    }
    if number.is_empty() {
        return Invalid; // Üres kitevő
    }
    // Ezen a ponton minden bizonnyal érvényes számjegysorunk van.Lehet, hogy túl hosszú az `i64`-be való beillesztés, de ha ilyen hatalmas, akkor a bemenet biztosan nulla vagy végtelen.
    // Mivel a tizedesjegyekben szereplő minden nulla csak +/-1-rel állítja be a kitevőt, exp=10 ^ 18 értéknél a bemenetnek 17 exabájt (!) nullának kell lennie ahhoz, hogy még távolról is közel kerüljön a végeshez.
    //
    // Ez nem éppen olyan felhasználási eset, amelyre szükségünk van.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}