//! Segédfunkciók a bignumok számára, amelyeknek nincs sok értelme módszerekké alakítani.

// FIXME Ennek a modulnak a neve kissé sajnálatos, mivel más modulok is importálják az `core::num`-et.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Tesztelje, hogy az `ones_place`-nél kisebb jelentőségű összes bit csonkolása relatív hibát eredményez-e, kisebb vagy egyenlő vagy nagyobb, mint az 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Ha az összes megmaradt bit nulla, akkor= 0.5 ULP, különben> 0.5 Ha nincs több bit (half_bit==0), az alábbiakban helyesen adja vissza az Equal értéket.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// A csak tizedesjegyeket tartalmazó ASCII karakterláncot `u64`-be konvertálja.
///
/// Nem ellenőrzi a túlcsordulást vagy az érvénytelen karaktereket, ezért ha a hívó fél nem vigyáz, az eredmény hamis és képes panic (bár nem `unsafe` lesz).
/// Ezenkívül az üres karakterláncokat nullának tekintjük.
/// Ez a funkció azért létezik, mert
///
/// 1. az `FromStr` használatához az `&[u8]`-en `from_utf8_unchecked` szükséges, ami rossz, és
/// 2. Az `integral.parse()` és az `fractional.parse()` eredményeinek összerakása bonyolultabb, mint ez a teljes funkció.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Az ASCII számjegyekből álló karakterláncot bignummá alakítja.
///
/// Az `from_str_unchecked`-hez hasonlóan ez a függvény is az elemzőre támaszkodik a nem számjegyek kiszűrésére.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Kicsomagolja a bignumot egy 64 bites egész számra.Panics, ha a szám túl nagy.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Kivonat egy sor bitet.

/// A 0 index a legkevésbé jelentős bit, és a tartomány a szokásos módon félig nyitott.
/// Panics, ha arra kérik, hogy nyerjen ki több bitet, mint amennyi a visszatérési típusba illeszkedik.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}