//! A cikk különböző algoritmusai.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Jelentésbitek száma Fp-ben
const P: u32 = 64;

// Egyszerűen a legjobb közelítést tároljuk az *összes* kitevőhöz, így az "h" változó és a hozzá tartozó feltételek elhagyhatók.
// Ez pár kilobájtos helyért üzemel.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// A legtöbb architektúrában a lebegőpontos műveletek kifejezett bitmérettel rendelkeznek, ezért a számítás pontosságát operációnként határozzák meg.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// x86 rendszeren az x87 FPU úszó műveletekhez használható, ha az SSE/SSE2 kiterjesztések nem állnak rendelkezésre.
// Az x87 FPU alapértelmezés szerint 80 bit pontossággal működik, ami azt jelenti, hogy a műveletek 80 bitre kerekítenek, ami kettős kerekítést eredményez, amikor az értékeket végül
//
// 32/64 bit lebegő értékek.Ennek kiküszöbölésére az FPU vezérlőszó beállítható úgy, hogy a számításokat a kívánt pontossággal hajtsák végre.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Az FPU vezérlőszó eredeti értékének megőrzésére használt szerkezet, amely visszaállítható a szerkezet eldobásakor.
    ///
    ///
    /// Az x87 FPU egy 16 bites regiszter, amelynek mezői a következők:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Az összes mező dokumentációja az IA-32 Architectures szoftverfejlesztői kézikönyvében található (1. kötet).
    ///
    /// Az egyetlen mező, amely a következő kódra vonatkozik, a PC, Precision Control.
    /// Ez a mező határozza meg az FPU által végrehajtott műveletek pontosságát.
    /// Beállítható:
    ///  - 0b00, egyetlen pontosságú, azaz 32 bites
    ///  - 0b10, dupla pontosságú, azaz 64 bites
    ///  - 0b11, dupla kiterjesztett pontosság, azaz 80 bit (alapértelmezett állapot) A 0b01 értéke fenntartva, ezért nem használható.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // BIZTONSÁG: Az `fldcw` utasítás ellenőrzése megtörtént, hogy megfelelően működjön
        // bármely `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: ATT szintaxist használunk az LLVM 8 és az LLVM 9 támogatására.
                options(att_syntax, nostack),
            )
        }
    }

    /// Az FPU precíziós mezőjét `T` értékre állítja, és `FPUControlWord` értéket ad vissza.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Számítsa ki a Precision Control mező értékét, amely megfelel az `T`-nek.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bit
            8 => 0x0200, // 64 bit
            _ => 0x0300, // alapértelmezés szerint 80 bit
        };

        // Szerezze be a vezérlő szó eredeti értékét a későbbi visszaállításhoz, amikor az `FPUControlWord` szerkezet eldől. BIZTONSÁG: Az `fnstcw` utasítást auditálták, hogy megfelelően működjön bármely `u16` eszközzel.
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: ATT szintaxist használunk az LLVM 8 és az LLVM 9 támogatására.
                options(att_syntax, nostack),
            )
        }

        // Állítsa be a vezérlő szót a kívánt pontosságra.
        // Ezt úgy érhetjük el, hogy elfedjük a régi pontosságot (8. és 9. bit, 0x300), és lecseréljük a fent kiszámított precíziós zászlóra.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// A Bellerophon gyors útja gépi egész számok és lebegők használatával.
///
/// Ezt külön funkcióba vonják ki, hogy megkíséreljék a bignum elkészítése előtt.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Összehasonlítjuk a pontos értéket a MAX_SIG értékével a vége közelében, ez csak egy gyors, olcsó elutasítás (és a kód többi részét is felszabadítja az alulcsordulástól való aggódástól).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // A gyors út döntően attól függ, hogy az aritmetikát közbenső kerekítés nélkül a megfelelő bitszámra kerekítik-e.
    // x86-en (SSE vagy SSE2 nélkül) ehhez meg kell változtatni az x87 FPU verem pontosságát, hogy az közvetlenül az 64/32 bitre kerekedjen.
    // Az `set_precision` funkció gondoskodik a pontosság beállításáról olyan architektúrákon, amelyek megkövetelik a globális állapot megváltoztatásával (például az x87 FPU vezérlőszava).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Az e <0 eset nem hajtható össze a másik ággal.
    // A negatív hatványok a binárisban ismétlődő törtrészeket eredményeznek, amelyek lekerekítettek, ami valós (és esetenként meglehetősen jelentős!) Hibákat okoz a végeredményben.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// A Bellerophon algoritmus triviális kód, amelyet nem triviális numerikus elemzés igazol.
///
/// Az "f"-et 64 bites jelentéssel rendelkező úszóra kerekíti, és megszorozza az `10^e` legjobb közelítésével (ugyanabban a lebegőpontos formátumban).Ez gyakran elegendő a helyes eredmény eléréséhez.
/// Ha azonban az eredmény közel van a két szomszédos (ordinary) úszó közötti félúthoz, akkor a két közelítés szorzatából adódó összetett kerekítési hiba azt jelenti, hogy az eredmény néhány bittel kikapcsolható.
/// Amikor ez megtörténik, az iteratív R algoritmus megoldja a dolgokat.
///
/// A kézzel hullámos "close to halfway"-et a cikkben szereplő numerikus elemzés pontosítja.
/// Clinger szavai szerint:
///
/// > A legkisebb jelentőségű bit egységeiben kifejezett lejtés inkluzívan kötődik a hibához
/// > az f * 10 ^ e közelítés lebegőpontos számításakor felhalmozódott.(Slop van
/// > nem kötött az igaz hibára, de korlátozza a z és a közelítés közötti különbséget
/// > a lehető legjobb közelítés, amely p szignifikáns biteket használ.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Az abs(e) <log5(2^N) esetek fast_path()-ben vannak
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Elég nagy a meredekség ahhoz, hogy különbséget tegyen, ha n bitre kerekít?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Iteratív algoritmus, amely javítja az `f * 10^e` lebegőpontos közelítését.
///
/// Minden iteráció egy egységet kap az utolsó helyen, közelebb, ami természetesen rettenetesen sokáig tart, míg az `z0` még enyhén ki van kapcsolva.
/// Szerencsére, ha a Bellerophon tartalékaként használjuk, akkor a kiindulási közelítést legfeljebb egy ULP kapcsolja ki.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Keresse meg az `x`, `y` pozitív egész számokat úgy, hogy `x / y` pontosan `(f *10^e) / (m* 2^k)` legyen.
        // Ezzel nemcsak elkerülhető az `e` és `k` előjeleinek kezelése, hanem kiküszöböljük az `10^e` és az `2^k` kettő közös erejét a számok kisebbé tételében.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Ezt kissé ügyetlenül írják, mert a bignumjaink nem támogatják a negatív számokat, ezért az abszolút érték + előjel információt használjuk.
        // Az m_digits számmal történő szorzás nem folyhat túl.
        // Ha az `x` vagy az `y` elég nagy ahhoz, hogy aggódnunk kell a túlcsordulás miatt, akkor elég nagyok ahhoz is, hogy az `make_ratio` 2 ^ 64 vagy annál nagyobb mértékben csökkentette a frakciót.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Nincs többé szüksége x-re, mentse el az clone()-et.
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Még mindig szükséged van y-re, készítsen másolatot.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Adott `x = f` és `y = m`, ahol az `f` a szokásos módon a bemeneti tizedesjegyeket képviseli, és `m` a lebegőpontos közelítés jelentősége, az `x / y` arányt egyenlítsük meg az `(f *10^e) / (m* 2^k)` értékkel, amelyet valószínűleg kettő hatványa csökkent.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, azzal a különbséggel, hogy valamilyen kettő hatványával csökkentjük a frakciót.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Ez nem tud túlcsordulni, mert ehhez pozitív `e` és negatív `k` szükséges, ami csak rendkívül 1-hez közeli értékeknél fordulhat elő, ami azt jelenti, hogy `e` és `k` viszonylag apró lesz.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Ez sem tud túlcsordulni, lásd fent.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), ismét kettő közös hatványával redukálva.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Fogalmilag az M algoritmus a legegyszerűbb módszer a tizedesjegy úszóvá alakítására.
///
/// Olyan arányt alakítunk ki, amely megegyezik az `f * 10^e` értékkel, majd kettőt dobunk be, amíg érvényes úszó szignifikanciát nem ad.
/// Az `k` bináris exponens az a szám, ahányszor megszoroztuk a számlálót vagy a nevezőt kettővel, azaz az `f *10^e` mindenkor megegyezik az `(u / v)* 2^k` értékkel.
/// Amikor megtudtuk a szignifikanciát, akkor csak az osztás fennmaradó részének ellenőrzésével kell kerekítenünk, amelyet a lenti segítő funkciókban végeznek.
///
///
/// Ez az algoritmus rendkívül lassú, még az `quick_start()`-ben leírt optimalizálás mellett is.
/// Azonban az algoritmusok közül a legegyszerűbb a túlcsordulás, az alulcsordulás és a normálistól eltérő eredményekhez alkalmazkodni.
/// Ez a megvalósítás veszi át, amikor a Bellerophon és az R algoritmus túlterheltek.
/// Az alul-és túlcsordulás kimutatása egyszerű: Az arány még mindig nem tartományon belüli szignifikáns, mégis elérte az minimum/maximum kitevőt.
/// Túlcsordulás esetén egyszerűen visszatérünk a végtelenbe.
///
/// Az alulcsordulás és az alnormálisok kezelése bonyolultabb.
/// Az egyik nagy probléma az, hogy a minimális kitevő mellett az arány még mindig túl nagy lehet egy szignifikánshoz.
/// További részletek: underflow().
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME lehetséges optimalizálás: általánosítsa a big_to_fp-t úgy, hogy itt megtehessük az fp_to_float(big_to_fp(u)) egyenértékét, csak kettős kerekítés nélkül.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Meg kell állnunk a minimális exponensnél, ha `k < T::MIN_EXP_INT`-ig várunk, akkor kétszeresen kikapcsolunk.
            // Sajnos ez azt jelenti, hogy a normál számokat a legkisebb kitevővel kell megkülönböztetnünk.
            // A FIXME talál egy elegánsabb készítményt, de futtassa az `tiny-pow10` tesztet, hogy megbizonyosodjon arról, hogy valóban helyes-e!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Átugorja a legtöbb M algoritmus iterációt a bithossz ellenőrzésével.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // A bithossz az alap két logaritmus becslése, és log(u / v) = log(u), log(v).
    // A becslés legfeljebb 1-rel van kikapcsolva, de mindig alulbecsül, így az log(u) és az log(v) hibája azonos előjelű és megszűnik (ha mindkettő nagy).
    // Ezért az log(u / v) hibája legfeljebb egy.
    // A célarány az, ahol az u/v tartományon belüli szignifikáns.Így a felmondási feltételünk az, hogy log2(u / v) a szignifikáns bit, az plus/minus egy.
    // FIXME A második bitet nézve javulhat a becslés, és elkerülhető néhány újabb felosztás.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Alulfolyó vagy szokatlan.Hagyja a fő funkcióra.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Túlcsordulás.Hagyja a fő funkcióra.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Az arány nem tartományon belüli szignifikáns a minimális kitevővel, ezért kerekítenünk kell a felesleges biteket, és ennek megfelelően kell beállítanunk a kitevőt.
    // A valódi érték most így néz ki:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q csonka.(képviseli rem)
    //
    // Ezért, ha a lekerekített bitek!= 0.5 ULP, akkor a kerekítést maguk döntik el.
    // Ha egyenlőek, és a maradék nem nulla, akkor az értéket felfelé kell kerekíteni.
    // Csak akkor, ha a lekerekített bitek értéke 1/2, a fennmaradó rész pedig nulla, akkor fél-egyenletes helyzet áll fenn.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Közönséges kerekítés-párosítás, eltakarta, hogy a maradék osztás alapján kell kerekíteni.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}