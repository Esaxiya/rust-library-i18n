//! A 16 bites előjelű egész szám konstansai.
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! Az új kódnak a társított konstansokat közvetlenül a primitív típusra kell használnia.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }