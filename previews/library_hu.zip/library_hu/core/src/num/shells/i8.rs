//! A 8 bites előjelű egész szám konstansai.
//!
//! *[See also the `i8` primitive type][i8].*
//!
//! Az új kódnak a társított konstansokat közvetlenül a primitív típusra kell használnia.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i8`"
)]

int_module! { i8 }