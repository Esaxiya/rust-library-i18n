//! Hibatípusok az integrált típusokká történő átalakításhoz

use crate::convert::Infallible;
use crate::fmt;

/// A hibatípus akkor jelenik meg, ha egy ellenőrzött integráltípus-átalakítás sikertelen.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Kényszerítés helyett egyezzen meg, hogy megbizonyosodjon arról, hogy a fenti `From<Infallible> for TryFromIntError`-hez hasonló kód továbbra is működik, ha az `Infallible` az `!` álneve lesz.
        //
        //
        match never {}
    }
}

/// Egy egész szám elemzésekor visszaadható hiba.
///
/// Ezt a hibát az `from_str_radix()` függvények hibatípusaként használják a primitív egész típusú típusokon, például az [`i8::from_str_radix`].
///
/// # Lehetséges okok
///
/// Többek között az `ParseIntError` dobható a karakterlánc elülső vagy hátsó szóköze miatt, például amikor a standard bemenetből nyerjük.
///
/// Az [`str::trim()`] módszer használata biztosítja, hogy az elemzés előtt ne maradjon szóköz.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum tárolja a különféle típusú hibákat, amelyek egy egész elemzés meghiúsulását okozhatják.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Az elemzett érték üres.
    ///
    /// Többek között ez a változat épül fel egy üres karakterlánc elemzésekor.
    Empty,
    /// Érvénytelen számjegyet tartalmaz a kontextusában.
    ///
    /// Többek között ezt a változatot kell létrehozni, amikor egy nem ASCII karaktert tartalmazó karakterláncot elemezünk.
    ///
    /// Ez a változat akkor is elkészül, ha egy `+` vagy `-` helytelenül helyezkedik el egy karakterláncban, akár önmagában, akár egy szám közepén.
    ///
    ///
    InvalidDigit,
    /// Az egész szám túl nagy ahhoz, hogy a cél egész szám típusában tárolható legyen.
    PosOverflow,
    /// Az egész szám túl kicsi ahhoz, hogy a cél egész számban tárolódjon.
    NegOverflow,
    /// Az érték nulla volt
    ///
    /// Ezt a változatot akkor bocsátjuk ki, ha az elemző karakterlánc értéke nulla, ami nem nulla típusok esetén illegális lenne.
    ///
    Zero,
}

impl ParseIntError {
    /// Kiadja az egész hibájának elemzésének részletes okát.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}