use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Memóriafoglaló, amely az `#[global_allocator]` attribútumon keresztül a standard könyvtár alapértelmezettjeként regisztrálható.
///
/// Néhány módszer megköveteli, hogy egy memóriablokkot *lefoglaljon* egy allokátoron keresztül.Ez azt jelenti:
///
/// * az adott memóriablokk kezdőcímét egy korábbi hívás visszaküldte egy kiosztási módszernek, például az `alloc`-nek, és
///
/// * a memóriablokkot nem osztották ki utólag, ahol a blokkokat úgy osztják el, hogy átadják egy olyan üzletkötési módszernek, mint az `dealloc`, vagy egy átcsoportosítási módszernek, amely nem null mutatót ad vissza.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// Az `GlobalAlloc` trait számos okból `unsafe` trait, és a kivitelezőknek biztosítaniuk kell, hogy betartsák ezeket a szerződéseket:
///
/// * Meghatározatlan viselkedés, ha a globális allokátorok kikapcsolnak.Ez a korlátozás feloldható a future-ben, de jelenleg a panic ezen funkciók bármelyikéből memóriabiztonsághoz vezethet.
///
/// * `Layout` a lekérdezéseknek és a számításoknak általában helyeseknek kell lenniük.A trait hívói támaszkodhatnak az egyes módszerekre meghatározott szerződésekre, és a kivitelezőknek biztosítaniuk kell, hogy az ilyen szerződések igazak maradjanak.
///
/// * Lehet, hogy nem támaszkodik a ténylegesen zajló kiosztásokra, még akkor sem, ha kifejezett halomallokációk vannak a forrásban.
/// Az optimalizáló észlelheti a fel nem használt allokációkat, amelyeket vagy teljesen megszüntethet, vagy áthelyezhet a verembe, és így soha nem hívhatja meg az allokátort.
/// Az optimalizáló azt is feltételezheti, hogy az allokáció tévedhetetlen, ezért az a kód, amely korábban az allokátor hibái miatt hibásodott meg, most hirtelen működhet, mert az optimalizáló körbejárta az allokáció szükségességét.
/// Konkrétabban: az alábbi kódpélda nem megbízható, függetlenül attól, hogy az egyéni elosztója megengedi-e számolni, hogy hány kiosztás történt.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Ne feledje, hogy a fent említett optimalizálások nem az egyetlen alkalmazható optimalizálási lehetőségek.Általában nem támaszkodhat a halomallokációkra, ha azok eltávolíthatók a program viselkedésének megváltoztatása nélkül.
///   Az, hogy a kiosztás megtörténik-e vagy sem, nem része a program viselkedésének, még akkor sem, ha azt egy kiosztón keresztül lehet felismerni, amely nyomon követi a kiosztásokat nyomtatással vagy más módon mellékhatásokkal jár.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Rendeljen memóriát az adott `layout` leírása szerint.
    ///
    /// Visszaad egy mutatót az újonnan kiosztott memóriába, vagy nullát a kiosztási hiba jelzésére.
    ///
    /// # Safety
    ///
    /// Ez a funkció nem biztonságos, mert meghatározhatatlan viselkedés következhet be, ha a hívó nem biztosítja, hogy az `layout` mérete nem nulla.
    ///
    /// (A kiterjesztéses altípusok konkrétabb korlátokat szabhatnak a viselkedéshez, például garantálhatnak egy őrszem címet vagy null mutatót válaszul egy nulla méretű kiosztási kérelemre.)
    ///
    /// A lefoglalt memóriablokk inicializálható vagy nem.
    ///
    /// # Errors
    ///
    /// A null mutató visszaadása azt jelzi, hogy vagy a memória kimerült, vagy az `layout` nem felel meg ennek a lefoglalónak a méretére vagy igazítására vonatkozó korlátozásoknak.
    ///
    /// A megvalósításokat arra ösztönzik, hogy a memória kimerülése helyett a megszakítás helyett visszatérjenek nullára, de ez nem szigorú követelmény.
    /// (Pontosabban:*törvényes* ezt a trait-t egy mögöttes natív allokációs könyvtár tetején megvalósítani, amely megszakítja a memória kimerülését.)
    ///
    /// Azokat a klienseket, akik elosztási hibára reagálva meg akarják szakítani a számítást, javasoljuk, hogy az `panic!` vagy hasonló szolgáltatás közvetlen meghívása helyett hívják meg az [`handle_alloc_error`] függvényt.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Dlokálja a memória blokkot az adott `ptr` mutatónál az adott `layout`-hez.
    ///
    /// # Safety
    ///
    /// Ez a funkció nem biztonságos, mert meghatározhatatlan viselkedés következhet be, ha a hívó nem biztosítja az alábbiak mindegyikét:
    ///
    ///
    /// * `ptr` jelölnie kell egy memória blokkot, amelyet jelenleg lefoglalnak ezen az elosztón keresztül,
    ///
    /// * `layout` ugyanannak az elrendezésnek kell lennie, amelyet a memóriablokk lefoglalásához használtak.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Úgy viselkedik, mint az `alloc`, de biztosítja azt is, hogy a tartalom nulla legyen, mielőtt visszaküldené.
    ///
    /// # Safety
    ///
    /// Ez a funkció ugyanazon okok miatt nem biztonságos, mint az `alloc`.
    /// A lefoglalt memóriablokk azonban garantáltan inicializálódik.
    ///
    /// # Errors
    ///
    /// A null mutató visszaadása azt jelzi, hogy vagy a memória kimerült, vagy az `layout` nem felel meg az allokátor méretének vagy igazításának korlátozásainak, csakúgy, mint az `alloc` esetében.
    ///
    /// Azokat a klienseket, akik elosztási hibára reagálva meg akarják szakítani a számítást, javasoljuk, hogy az `panic!` vagy hasonló szolgáltatás közvetlen meghívása helyett hívják meg az [`handle_alloc_error`] függvényt.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // BIZTONSÁG: az `alloc` biztonsági szerződését a hívó félnek be kell tartania.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // BIZTONSÁG: mivel a kiosztás sikerült, a régió `ptr`-től kezdődően
            // Az `size` méretű garantáltan érvényes az írásokra.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Csökkentse vagy növelje a memória blokkját az adott `new_size`-re.
    /// A blokkot az adott `ptr` mutató és `layout` írja le.
    ///
    /// Ha ez nem null mutatót ad vissza, akkor az `ptr` által hivatkozott memóriablokk tulajdonjoga átruházásra került erre az elosztóra.
    /// Lehetséges, hogy a memóriát lefoglalták, vagy nem, és használhatatlannak kell tekinteni (kivéve, ha természetesen a módszer visszatérési értékén keresztül újra visszaküldték a hívónak).
    /// Az új memóriablokkot az `layout`, de az `size` frissíti `new_size`-re.
    /// Ezt az új elrendezést kell használni, amikor az új memóriablokkot elosztja az `dealloc`-szel.
    /// Az új memóriablokk `0..min(layout.size(), new_size) `tartománya garantáltan ugyanazokkal az értékekkel rendelkezik, mint az eredeti blokk.
    ///
    /// Ha ez a módszer null értéket ad vissza, akkor a memóriablokk tulajdonjoga nem került átruházásra erre a lefoglalóra, és a memóriablokk tartalma nem változik.
    ///
    /// # Safety
    ///
    /// Ez a funkció nem biztonságos, mert meghatározhatatlan viselkedés következhet be, ha a hívó nem biztosítja az alábbiak mindegyikét:
    ///
    /// * `ptr` jelenleg ezen az elosztón keresztül kell kiosztani,
    ///
    /// * `layout` ugyanannak az elrendezésnek kell lennie, amelyet a memóriablokk lefoglalásához használtak,
    ///
    /// * `new_size` nagyobbnak kell lennie, mint nulla.
    ///
    /// * `new_size`, az `layout.align()` legközelebbi többszörösére kerekítve nem szabad túlcsordulnia (azaz a kerekített értéknek kisebbnek kell lennie, mint `usize::MAX`).
    ///
    /// (A kiterjesztéses altípusok konkrétabb korlátokat szabhatnak a viselkedéshez, például garantálhatnak egy őrszem címet vagy null mutatót válaszul egy nulla méretű kiosztási kérelemre.)
    ///
    /// # Errors
    ///
    /// Null értéket ad vissza, ha az új elrendezés nem felel meg a lefoglaló méretének és igazításának korlátozásainak, vagy ha az átcsoportosítás másképp nem sikerül.
    ///
    /// A megvalósításokat arra ösztönzik, hogy a memória kimerülése esetén a pánikba esés megszakítás helyett visszatérjenek nullára, de ez nem szigorú követelmény.
    /// (Pontosabban:*törvényes* ezt a trait-t egy mögöttes natív allokációs könyvtár tetején megvalósítani, amely megszakítja a memória kimerülését.)
    ///
    /// Azokat a klienseket, akik újraterjesztési hibára reagálva meg akarják szakítani a számítást, javasoljuk, hogy az `panic!` vagy hasonló szolgáltatás közvetlen meghívása helyett hívják meg az [`handle_alloc_error`] függvényt.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // BIZTONSÁG: A hívónak meg kell győződnie arról, hogy az `new_size` nem folyik túl.
        // `layout.align()` `Layout`-ről származik, és így garantáltan érvényes.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // BIZTONSÁG: a hívónak meg kell győződnie arról, hogy az `new_layout` nagyobb, mint nulla.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // BIZTONSÁG: az előzőleg lefoglalt blokk nem fedheti át az újonnan lefoglalt blokkot.
            // Az `dealloc` biztonsági szerződését a hívónak be kell tartania.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}