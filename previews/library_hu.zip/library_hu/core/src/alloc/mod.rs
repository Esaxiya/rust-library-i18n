//! Memóriaallokációs API-k

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Az `AllocError` hiba olyan kiosztási hibát jelez, amely az erőforrás kimerüléséből vagy valami hibából adódhat, amikor az adott bemeneti argumentumokat ezzel az allokátorral kombinálja.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (erre szükségünk van a trait hiba downstream implikációjához)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Az `Allocator` megvalósítása allokálhatja, növelheti, összezsugoríthatja és eloszthatja az [`Layout`][]-en keresztül leírt tetszőleges adatblokkokat.
///
/// `Allocator` úgy tervezték, hogy ZST-kön, referenciákon vagy intelligens mutatókon implementálható legyen, mivel az `MyAlloc([u8; N])`-hez hasonló allokátor birtoklása nem mozgatható anélkül, hogy frissítené a mutatókat a lefoglalt memóriában.
///
/// Az [`GlobalAlloc`][]-től eltérően az `Allocator`-ben nulla méretű kiosztás engedélyezett.
/// Ha egy mögöttes allokátor nem támogatja ezt (például a jemalloc), vagy nullpontot ad vissza (például `libc::malloc`), akkor ezt a megvalósításnak el kell kapnia.
///
/// ### Jelenleg lefoglalt memória
///
/// Néhány módszer megköveteli, hogy egy memóriablokkot *lefoglaljon* egy allokátoron keresztül.Ez azt jelenti:
///
/// * az adott memóriablokk kezdőcímét korábban [`allocate`], [`grow`] vagy [`shrink`] adta vissza, és
///
/// * a memóriablokkot nem osztották ki később, ahol a blokkokat vagy közvetlenül az [`deallocate`]-nek továbbítással osztják el, vagy az `Ok`-et visszaadó [`grow`]-nek vagy [`shrink`]-nek továbbítják.
///
/// Ha az `grow` vagy `shrink` visszaadta az `Err` értéket, a továbbított mutató érvényben marad.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Memóriaillesztés
///
/// Néhány módszer megköveteli, hogy az elrendezés *illesszen* egy memória blokkot.
/// Mit jelent az "fit" elrendezéshez a memória blokk (vagy egyenértékűen az "fit" memória blokkhoz egy elrendezés) azt jelenti, hogy a következő feltételeknek kell teljesülniük:
///
/// * A blokkot ugyanolyan igazítással kell lefoglalni, mint az [`layout.align()`], és
///
/// * A megadott [`layout.size()`]-nek az `min ..= max` tartományba kell esnie, ahol:
///   - `min` a blokk kiosztásához legutóbb használt elrendezés mérete, és
///   - `max` az [`allocate`], [`grow`] vagy [`shrink`] legújabb tényleges mérete.
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Az allokátorból visszaküldött memóriablokkoknak érvényes memóriára kell mutatniuk, és meg kell őrizniük érvényességüket mindaddig, amíg a példány és az összes klónja le nem esik
///
/// * az allokátor klónozása vagy áthelyezése nem érvénytelenítheti az ettől az osztótól visszaküldött memóriablokkokat.A klónozott allokátornak ugyanannak a lefoglalónak kell viselkednie, és
///
/// * az [*currently allocated*] méretű memóriablokk bármelyik mutatója átadható az allokátor bármely más módszerének.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Megpróbál kiosztani egy blokkot memóriának.
    ///
    /// Siker esetén [`NonNull<[u8]>`][NonNull]-et ad vissza, amely megfelel az `layout` méretének és igazítási garanciájának.
    ///
    /// A visszaküldött blokk mérete nagyobb lehet, mint azt az `layout.size()` előírja, és lehet, hogy nem inicializálják a tartalmát.
    ///
    /// # Errors
    ///
    /// Az `Err` visszatérése azt jelzi, hogy vagy a memória kimerült, vagy az `layout` nem felel meg az elosztó méretének vagy igazítási korlátozásainak.
    ///
    /// A megvalósításokat javasoljuk, hogy az `Err`-et a pánikba esés megszakítás helyett a memória kimerülésével térjék vissza, de ez nem szigorú követelmény.
    /// (Pontosabban:*törvényes* ezt a trait-t egy mögöttes natív allokációs könyvtár tetején megvalósítani, amely megszakítja a memória kimerülését.)
    ///
    /// Azokat a klienseket, akik elosztási hibára reagálva meg akarják szakítani a számítást, javasoljuk, hogy az `panic!` vagy hasonló szolgáltatás közvetlen meghívása helyett hívják meg az [`handle_alloc_error`] függvényt.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Úgy viselkedik, mint az `allocate`, de biztosítja a visszaadott memória inicializálását is.
    ///
    /// # Errors
    ///
    /// Az `Err` visszatérése azt jelzi, hogy vagy a memória kimerült, vagy az `layout` nem felel meg az elosztó méretének vagy igazítási korlátozásainak.
    ///
    /// A megvalósításokat javasoljuk, hogy az `Err`-et a pánikba esés megszakítás helyett a memória kimerülésével térjék vissza, de ez nem szigorú követelmény.
    /// (Pontosabban:*törvényes* ezt a trait-t egy mögöttes natív allokációs könyvtár tetején megvalósítani, amely megszakítja a memória kimerülését.)
    ///
    /// Azokat a klienseket, akik elosztási hibára reagálva meg akarják szakítani a számítást, javasoljuk, hogy az `panic!` vagy hasonló szolgáltatás közvetlen meghívása helyett hívják meg az [`handle_alloc_error`] függvényt.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // BIZTONSÁG: Az `alloc` érvényes memóriablokkot ad vissza
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Kiosztja az `ptr` által hivatkozott memóriát.
    ///
    /// # Safety
    ///
    /// * `ptr` meg kell jelölnie az [*currently allocated*] memóriablokkot ezen az elosztón keresztül, és
    /// * `layout` [*fit*]-nek kell lennie annak a memóriablokknak.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Megpróbálja meghosszabbítani a memória blokkot.
    ///
    /// Visszaad egy új [`NonNull<[u8]>`][NonNull]-et, amely mutatót és a lefoglalt memória tényleges méretét tartalmazza.A mutató alkalmas az `new_layout` által leírt adatok tárolására.
    /// Ennek elérése érdekében az allokátor kiterjesztheti az `ptr` által hivatkozott allokációt az új elrendezéshez.
    ///
    /// Ha ez visszaadja az `Ok` értéket, akkor az `ptr` által hivatkozott memóriablokk tulajdonjoga átruházásra került erre az elosztóra.
    /// Lehetséges, hogy a memória felszabadult vagy sem, és használhatatlannak kell tekinteni, kivéve, ha a módszer visszatérési értékén keresztül ismét visszahelyezték a hívó félhez.
    ///
    /// Ha ez a módszer `Err` értéket ad vissza, akkor a memóriablokk tulajdonjoga nem került átruházásra erre a lefoglalóra, és a memóriablokk tartalma nem változik.
    ///
    /// # Safety
    ///
    /// * `ptr` ezen az elosztón keresztül kell jelölnie az [*currently allocated*] memóriablokkot.
    /// * `old_layout` [*fit*]-nek kell lennie annak a memóriablokknak (az `new_layout` argumentumnak nem kell illeszkednie.).
    /// * `new_layout.size()` nagyobbnak vagy egyenlőnek kell lennie, mint `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Visszaadja az `Err` értéket, ha az új elrendezés nem felel meg a lefoglaló méretének és a lefoglaló korlátozásainak, vagy ha a növekedés másképp nem sikerül.
    ///
    /// A megvalósításokat javasoljuk, hogy az `Err`-et a pánikba esés megszakítás helyett a memória kimerülésével térjék vissza, de ez nem szigorú követelmény.
    /// (Pontosabban:*törvényes* ezt a trait-t egy mögöttes natív allokációs könyvtár tetején megvalósítani, amely megszakítja a memória kimerülését.)
    ///
    /// Azokat a klienseket, akik elosztási hibára reagálva meg akarják szakítani a számítást, javasoljuk, hogy az `panic!` vagy hasonló szolgáltatás közvetlen meghívása helyett hívják meg az [`handle_alloc_error`] függvényt.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // BIZTONSÁG: mert az `new_layout.size()`-nek nagyobbnak vagy egyenlőnek kell lennie
        // `old_layout.size()`, a régi és az új memória-allokáció egyaránt érvényes az `old_layout.size()` byte-ok olvasására és írására.
        // Továbbá, mivel a régi allokációt még nem osztották fel, nem fedheti át az `new_ptr`-et.
        // Így az `copy_nonoverlapping` hívása biztonságos.
        // Az `dealloc` biztonsági szerződését a hívónak be kell tartania.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Úgy viselkedik, mint az `grow`, de biztosítja azt is, hogy az új tartalom nulla legyen, mielőtt visszaküldi őket.
    ///
    /// A memória blokk a következő tartalmat tartalmazza a sikeres hívás után
    /// `grow_zeroed`:
    ///   * Az `0..old_layout.size()` bájtok megmaradnak az eredeti allokációtól.
    ///   * Az `old_layout.size()..old_size` bájt vagy megmarad, vagy nullázásra kerül, az allokátor megvalósításától függően.
    ///   `old_size` az `grow_zeroed` hívás előtti memóriablokk méretére vonatkozik, amely nagyobb lehet, mint az eredetileg kiosztáskor kért méret.
    ///   * Az `old_size..new_size` bájtokat nullázzuk.Az `new_size` az `grow_zeroed` hívás által visszaadott memóriablokk méretére utal.
    ///
    /// # Safety
    ///
    /// * `ptr` ezen az elosztón keresztül kell jelölnie az [*currently allocated*] memóriablokkot.
    /// * `old_layout` [*fit*]-nek kell lennie annak a memóriablokknak (az `new_layout` argumentumnak nem kell illeszkednie.).
    /// * `new_layout.size()` nagyobbnak vagy egyenlőnek kell lennie, mint `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Visszaadja az `Err` értéket, ha az új elrendezés nem felel meg a lefoglaló méretének és a lefoglaló korlátozásainak, vagy ha a növekedés másképp nem sikerül.
    ///
    /// A megvalósításokat javasoljuk, hogy az `Err`-et a pánikba esés megszakítás helyett a memória kimerülésével térjék vissza, de ez nem szigorú követelmény.
    /// (Pontosabban:*törvényes* ezt a trait-t egy mögöttes natív allokációs könyvtár tetején megvalósítani, amely megszakítja a memória kimerülését.)
    ///
    /// Azokat a klienseket, akik elosztási hibára reagálva meg akarják szakítani a számítást, javasoljuk, hogy az `panic!` vagy hasonló szolgáltatás közvetlen meghívása helyett hívják meg az [`handle_alloc_error`] függvényt.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // BIZTONSÁG: mert az `new_layout.size()`-nek nagyobbnak vagy egyenlőnek kell lennie
        // `old_layout.size()`, a régi és az új memória-allokáció egyaránt érvényes az `old_layout.size()` byte-ok olvasására és írására.
        // Továbbá, mivel a régi allokációt még nem osztották fel, nem fedheti át az `new_ptr`-et.
        // Így az `copy_nonoverlapping` hívása biztonságos.
        // Az `dealloc` biztonsági szerződését a hívónak be kell tartania.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Megpróbálja csökkenteni a memória blokkot.
    ///
    /// Visszaad egy új [`NonNull<[u8]>`][NonNull]-et, amely mutatót és a lefoglalt memória tényleges méretét tartalmazza.A mutató alkalmas az `new_layout` által leírt adatok tárolására.
    /// Ennek elérése érdekében az allokátor csökkentheti az `ptr` által hivatkozott allokációt az új elrendezésnek megfelelően.
    ///
    /// Ha ez visszaadja az `Ok` értéket, akkor az `ptr` által hivatkozott memóriablokk tulajdonjoga átruházásra került erre az elosztóra.
    /// Lehetséges, hogy a memória felszabadult vagy sem, és használhatatlannak kell tekinteni, kivéve, ha a módszer visszatérési értékén keresztül ismét visszahelyezték a hívó félhez.
    ///
    /// Ha ez a módszer `Err` értéket ad vissza, akkor a memóriablokk tulajdonjoga nem került átruházásra erre a lefoglalóra, és a memóriablokk tartalma nem változik.
    ///
    /// # Safety
    ///
    /// * `ptr` ezen az elosztón keresztül kell jelölnie az [*currently allocated*] memóriablokkot.
    /// * `old_layout` [*fit*]-nek kell lennie annak a memóriablokknak (az `new_layout` argumentumnak nem kell illeszkednie.).
    /// * `new_layout.size()` kisebbnek vagy egyenlőnek kell lennie, mint `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Visszaadja az `Err` értéket, ha az új elrendezés nem felel meg a lefoglaló méretének és a lefoglaló korlátozásainak, vagy ha a zsugorítás másképp nem sikerül.
    ///
    /// A megvalósításokat javasoljuk, hogy az `Err`-et a pánikba esés megszakítás helyett a memória kimerülésével térjék vissza, de ez nem szigorú követelmény.
    /// (Pontosabban:*törvényes* ezt a trait-t egy mögöttes natív allokációs könyvtár tetején megvalósítani, amely megszakítja a memória kimerülését.)
    ///
    /// Azokat a klienseket, akik elosztási hibára reagálva meg akarják szakítani a számítást, javasoljuk, hogy az `panic!` vagy hasonló szolgáltatás közvetlen meghívása helyett hívják meg az [`handle_alloc_error`] függvényt.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // BIZTONSÁG: mert az `new_layout.size()`-nek kisebbnek vagy egyenlőnek kell lennie
        // `old_layout.size()`, a régi és az új memória-allokáció egyaránt érvényes az `new_layout.size()` byte-ok olvasására és írására.
        // Továbbá, mivel a régi allokációt még nem osztották fel, nem fedheti át az `new_ptr`-et.
        // Így az `copy_nonoverlapping` hívása biztonságos.
        // Az `dealloc` biztonsági szerződését a hívónak be kell tartania.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Létrehoz egy "by reference" adaptert az `Allocator` ezen példányához.
    ///
    /// A visszaküldött adapter az `Allocator`-et is megvalósítja, és ezt egyszerűen kölcsön fogja adni.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // BIZTONSÁG: a biztonsági szerződést a hívó félnek be kell tartania
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // BIZTONSÁG: a biztonsági szerződést a hívó félnek be kell tartania
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // BIZTONSÁG: a biztonsági szerződést a hívó félnek be kell tartania
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // BIZTONSÁG: a biztonsági szerződést a hívó félnek be kell tartania
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}