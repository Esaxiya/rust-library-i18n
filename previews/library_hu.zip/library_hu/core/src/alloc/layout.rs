use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Míg ezt a funkciót egy helyen használják, és megvalósítását be lehetne vonni, a korábbi próbálkozások lassabbá tették a rustc-t:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// A memória blokkjának elrendezése.
///
/// Az `Layout` egy példánya a memória egy meghatározott elrendezését írja le.
/// `Layout`-t épít fel bemenetként, amelyet egy allokátornak adhat.
///
/// Az összes elrendezéshez társított méret és kettős teljesítmény igazítás tartozik.
///
/// (Ne feledje, hogy az elrendezések nem kötelezőek, hogy ne legyenek nulla méretűek, annak ellenére, hogy az `GlobalAlloc` megköveteli, hogy az összes memóriaigény ne nulla méretű legyen.
/// A hívónak vagy meg kell győződnie arról, hogy az ilyen feltételek teljesülnek-e, használnia kell-e specifikus kiosztókat, amelyeknek követelményei lazábbak, vagy használja az enyhébb `Allocator` interfészt.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // a kért memóriablokk mérete bájtban mérve.
    size_: usize,

    // a kért memóriablokk bájtokban mérése.
    // biztosítjuk, hogy ez mindig kettő ereje legyen, mert az API-k, mint az `posix_memalign`, ezt megkövetelik, ésszerű korlátozás a Layout konstruktorok számára.
    //
    //
    // (Azonban nincs szükségünk analóg módon az `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)-re
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// `Layout`-et szerkeszt egy adott `size`-ből és `align`-ből, vagy `LayoutError`-t ad vissza, ha az alábbi feltételek bármelyike nem teljesül:
    ///
    /// * `align` nem lehet nulla,
    ///
    /// * `align` kettő hatványának kell lennie,
    ///
    /// * `size`, az `align` legközelebbi többszörösére kerekítve nem szabad túlcsordulnia (azaz a kerekített értéknek kisebbnek vagy egyenlőnek kell lennie, mint `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (a kettő hatványa összehangolást jelent!=0.)

        // A kerekített méret a következő:
        //   size_rounded_up=(méret + igazítás, 1)&! (igazítás, 1);
        //
        // Fentről tudjuk, hogy igazodjon!=0.
        // Ha az (igazítás, 1) hozzáadása nem folyik túl, akkor a felfelé kerekítés rendben lesz.
        //
        // Ezzel szemben a&-maszkolás a (align, 1) segítségével csak alacsony sorrendű biteket von le.
        // Ha tehát az összeggel túlcsordulás történik, akkor a&-maszk nem tud annyit levonni, hogy visszavonja ezt a túlcsordulást.
        //
        //
        // A fentiek azt sugallják, hogy az összegzés túlcsordulásának ellenőrzése szükséges és elegendő.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // BIZTONSÁG: az `from_size_align_unchecked` feltételei teljesültek
        // fent ellenőrzött.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Elrendezést hoz létre, megkerülve az összes ellenőrzést.
    ///
    /// # Safety
    ///
    /// Ez a funkció nem biztonságos, mivel nem ellenőrzi az [`Layout::from_size_align`] előfeltételeit.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // BIZTONSÁG: a hívónak meg kell győződnie arról, hogy az `align` nagyobb, mint nulla.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Az ilyen elrendezésű memóriablokk minimális mérete bájtokban.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Az elrendezés memóriablokkjának minimális bájt igazítása.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// `Layout`-et készít, amely alkalmas egy `T` típusú érték tartására.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // BIZTONSÁG: az igazítást a Rust garantálja, hogy kettő és
        // a size + align kombináció garantáltan elfér a címterünkön.
        // Ennek eredményeként használja az itt nem ellenőrzött konstruktort, hogy elkerülje a panics kód beillesztését, ha az nincs megfelelően optimalizálva.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Elrendezést készít, amely leírja azt a rekordot, amely felhasználható az `T` háttérstruktúrájának kiosztására (amely lehet trait vagy más méret nélküli típus, például egy szelet).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // BIZTONSÁG: lásd az `new` indoklását, miért használja a nem biztonságos változatot
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Elrendezést készít, amely leírja azt a rekordot, amely felhasználható az `T` háttérstruktúrájának kiosztására (amely lehet trait vagy más méret nélküli típus, például egy szelet).
    ///
    /// # Safety
    ///
    /// Ez a funkció csak akkor biztonságos, ha a következő feltételek teljesülnek:
    ///
    /// - Ha az `T` `Sized`, akkor ezt a funkciót mindig biztonságos hívni.
    /// - Ha az `T` méret nélküli farka:
    ///     - egy [slice], akkor a szeletfarok hosszának intializált egész számnak kell lennie, és a *teljes érték* méretének (dinamikus farokhossz + statikus méretű előtag) meg kell felelnie az `isize`-nek.
    ///     - egy [trait object]-et, akkor a mutató vtable részének egy méret nélküli koerzióval megszerzett `T` típusra érvényes vtable-re kell mutatnia, és a * teljes érték méretének (dinamikus farokhossz + statikus méretű előtag) be kell illeszkednie az `isize`-be.
    ///
    ///     - (unstable) [extern type], akkor ezt a funkciót mindig biztonságos hívni, de előfordulhat, hogy a panic vagy más módon rossz értéket ad vissza, mivel a külső típus elrendezése nem ismert.
    ///     Ez megegyezik az [`Layout::for_value`] viselkedésével egy külső típusú farok hivatkozásakor.
    ///     - ellenkező esetben konzervatív módon nem szabad ezt a függvényt meghívni.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // BIZTONSÁG: ezen funkciók előfeltételeit átadjuk a hívónak
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // BIZTONSÁG: lásd az `new` indoklását, miért használja a nem biztonságos változatot
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Létrehoz egy lógó, de ehhez az elrendezéshez jól illeszkedő `NonNull`-et.
    ///
    /// Ne feledje, hogy a mutató értéke egy érvényes mutatót jelenthet, ami azt jelenti, hogy ezt nem szabad "not yet initialized" őrszem értékként használni.
    /// A lustán kiosztott típusoknak valamilyen más eszközzel kell követniük az inicializálást.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // BIZTONSÁG: az igazítás garantáltan nem nulla
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Létrehoz egy olyan elrendezést, amely leírja a rekordot, amely az `self`-lel megegyező elrendezésű értéket képes tárolni, ugyanakkor az `align` igazításhoz is igazodik (bájtban mérve).
    ///
    ///
    /// Ha az `self` már megfelel az előírt igazításnak, akkor az `self` értéket adja vissza.
    ///
    /// Vegye figyelembe, hogy ez a módszer nem ad hozzá párnázást a teljes mérethez, függetlenül attól, hogy a visszaküldött elrendezés más illesztéssel rendelkezik-e.
    /// Más szavakkal, ha az `K` 16-os méretű, akkor az `K.align_to(32)`*továbbra is* 16-os lesz.
    ///
    /// Hibát ad vissza, ha az `self.size()` és az adott `align` kombinációja megsérti az [`Layout::from_size_align`] listában felsorolt feltételeket.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Visszaadja az `self` után beillesztendő betét mennyiségét annak biztosítására, hogy a következő cím kielégítse az `align` értéket (bájtban mérve).
    ///
    /// pl. ha az `self.size()` értéke 9, akkor az `self.padding_needed_for(4)` 3-at ad vissza, mert ez a minimális bájtnyi kitöltés szükséges a 4 igazított cím megszerzéséhez (feltételezve, hogy a megfelelő memória blokk 4 igazított címről indul).
    ///
    ///
    /// Ennek a függvénynek a visszatérési értékének nincs jelentése, ha az `align` nem kettős hatvány.
    ///
    /// Vegye figyelembe, hogy a visszaadott érték hasznosságához az `align`-nek kisebbnek vagy egyenlőnek kell lennie a kiinduló cím igazításához az egész lefoglalt memóriablokkhoz.Ennek a megszorításnak az egyik módja az `align <= self.align()` biztosítása.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // A kerekített érték:
        //   len_rounded_up=(len + igazítás, 1)&! (igazítás, 1);
        // majd visszaadjuk a párnázási különbséget: `len_rounded_up - len`.
        //
        // Moduláris számtant alkalmazunk:
        //
        // 1. az igazítás garantáltan> 0, tehát az igazítás, az 1 mindig érvényes.
        //
        // 2.
        // `len + align - 1` legfeljebb `align - 1` képes túlcsordulni, így az `!(align - 1)`-szel ellátott&-maszk biztosítja, hogy túlcsordulás esetén az `len_rounded_up` maga 0 legyen.
        //
        //    Így az `len`-hez hozzáadva a visszatöltött párna 0-t eredményez, ami triviálisan kielégíti az `align` igazítást.
        //
        // (Természetesen azoknak a memóriablokkoknak a kiosztására tett kísérletek, amelyek mérete és kitöltése a fenti módon túlcsordul, az allokátornak egyébként is hibát kell eredményeznie.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Elrendezést hoz létre az elrendezés méretének az elrendezés igazításának többszörösére kerekítésével.
    ///
    ///
    /// Ez egyenértékű az `padding_needed_for` eredményének hozzáadásával az elrendezés jelenlegi méretéhez.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Ez nem tud túlcsordulni.Az Elrendezés invariánsából idézve:
        // > `size`, az `align` legközelebbi többszörösére kerekítve,
        // > nem szabad túlcsordulnia (azaz a kerekített értéknek kisebbnek kell lennie, mint
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Létrehoz egy elrendezést, amely leírja az `self` `n` példányainak rekordját, megfelelő mennyiségű kitöltéssel mindegyik között annak biztosítására, hogy az egyes példányok megkapják a kívánt méretet és igazítást.
    /// Siker esetén `(k, offs)`-et ad vissza, ahol `k` a tömb elrendezése, `offs` pedig a tömb egyes elemeinek kezdete közötti távolság.
    ///
    /// Számtani túlcsorduláskor az `LayoutError` értéket adja vissza.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Ez nem tud túlcsordulni.Az Elrendezés invariánsából idézve:
        // > `size`, az `align` legközelebbi többszörösére kerekítve,
        // > nem szabad túlcsordulnia (azaz a kerekített értéknek kisebbnek kell lennie, mint
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // BIZTONSÁG: Az self.align már ismeretes, hogy érvényes, és az allokáció_méret volt
        // párnázott már.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Létrehoz egy elrendezést, amely leírja az `self`, majd az `next` rekordját, beleértve az összes szükséges kitöltést annak biztosításához, hogy az `next` megfelelően illeszkedjen, de *nincs mögötte kitöltő*.
    ///
    /// Az `repr(C)` C ábrázolási elrendezésnek való megfelelés érdekében hívja az `pad_to_align`-et, miután kiterjesztette az elrendezést az összes mezővel.
    /// (Az `repr(Rust)`, as it is unspecified.) alapértelmezett Rust ábrázolási elrendezésnek nincs módja
    ///
    /// Vegye figyelembe, hogy a kapott elrendezés igazítása az `self` és az `next` maximálisé lesz, annak érdekében, hogy biztosítsa mindkét rész összehangolását.
    ///
    /// Visszaadja az `Ok((k, offset))` értéket, ahol `k` az összefűzött rekord elrendezése, `offset` pedig az összefűzött rekordba ágyazott `next` kezdetének relatív helye bájtokban (feltételezve, hogy maga a rekord a 0 eltolásnál kezdődik).
    ///
    ///
    /// Számtani túlcsorduláskor az `LayoutError` értéket adja vissza.
    ///
    /// # Examples
    ///
    /// Az `#[repr(C)]` szerkezet elrendezésének és a mezők eltolódásának kiszámításához a mezők elrendezéséből:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Ne felejtse el véglegesíteni az `pad_to_align`-szel!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // tesztelje, hogy működik-e
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Létrehoz egy elrendezést, amely leírja az `self` `n` példányainak rekordját, az egyes példányok között nincs kitöltés.
    ///
    /// Vegye figyelembe, hogy az `repeat`-től eltérően az `repeat_packed` nem garantálja, hogy az `self` ismétlődő példányai megfelelően lesznek összehangolva, még akkor is, ha az `self` adott példánya megfelelően igazodik.
    /// Más szóval, ha az `repeat_packed` által visszaküldött elrendezést tömb lefoglalására használjuk, akkor nem garantált, hogy a tömb összes eleme megfelelõen lesz igazítva.
    ///
    /// Számtani túlcsorduláskor az `LayoutError` értéket adja vissza.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Létrehoz egy elrendezést, amely leírja az `self`, majd az `next` rekordját, a kettő között nincs további kitöltés.
    /// Mivel nincs betöltött betét, az `next` igazítása lényegtelen, és egyáltalán nem épül be * a kapott elrendezésbe.
    ///
    ///
    /// Számtani túlcsorduláskor az `LayoutError` értéket adja vissza.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Létrehoz egy elrendezést, amely leírja az `[T; n]` rekordját.
    ///
    /// Számtani túlcsorduláskor az `LayoutError` értéket adja vissza.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Az `Layout::from_size_align` vagy más `Layout` konstruktor számára megadott paraméterek nem felelnek meg annak dokumentált korlátozásainak.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (erre szükségünk van a trait hiba downstream implikációjához)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}