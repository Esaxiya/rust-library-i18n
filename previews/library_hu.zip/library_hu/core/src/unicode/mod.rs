#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// Az [Unicode](http://www.unicode.org/) változata, amelyen az `char` és `str` módszer Unicode részei alapulnak.
///
/// Az Unicode új verzióit rendszeresen kiadják, és ezt követően az Unicode-tól függően a standard könyvtár összes módszere frissül.
/// Ezért egyes `char` és `str` módszerek viselkedése és ennek az állandónak az értéke idővel változik.
/// Ez *nem* tekinthető feltörő változásnak.
///
/// A verziószámozási sémát az [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) magyarázza.
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// Liballoc-ban történő felhasználásra, nem exportálható újra libstd-ben.
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;