//! Funkcionalitás megrendeléshez és összehasonlításhoz.
//!
//! Ez a modul különféle eszközöket tartalmaz az értékek rendezéséhez és összehasonlításához.Összefoglalva:
//!
//! * [`Eq`] és [`PartialEq`] olyan traits, amelyek lehetővé teszik az értékek közötti teljes, illetve részleges egyenlőség meghatározását.
//! Megvalósításuk túlterheli az `==` és `!=` operátorokat.
//! * [`Ord`] és [`PartialOrd`] olyan traits, amelyek lehetővé teszik az értékek közötti teljes és részleges sorrend meghatározását.
//!
//! Megvalósításuk túlterheli az `<`, `<=`, `>` és `>=` operátorokat.
//! * [`Ordering`] az [`Ord`] és [`PartialOrd`] fő funkciói által visszaküldött felsorolás, amely egy sorrendet ír le.
//! * [`Reverse`] egy olyan struktúra, amely lehetővé teszi a megrendelések egyszerű megfordítását.
//! * [`max`] és az [`min`] olyan funkciók, amelyek az [`Ord`] alapján épülnek fel, és lehetővé teszik, hogy megtalálja a két érték maximumát vagy minimumát.
//!
//! További részletekért lásd a lista egyes tételeinek megfelelő dokumentációját.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait az egyenlőség összehasonlításához, amelyek [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation).
///
/// Ez a trait részleges egyenlőséget tesz lehetővé olyan típusok esetében, amelyek nem rendelkeznek teljes ekvivalencia relációval.
/// Például az `NaN != NaN` lebegőpontos számokban, tehát a lebegőpontos típusok az `PartialEq`-et valósítják meg, az [`trait@Eq`]-et azonban nem.
///
/// Formálisan az egyenlőségnek meg kell lennie (minden `a`, `b`, `c` típushoz, `A`, `B`, `C` típusú):
///
/// - **Szimmetrikus**: ha `A: PartialEq<B>` és `B: PartialEq<A>`, akkor **`a==b` azt jelenti, hogy`b==a`**;és
///
/// - **Tranzitív**: ha `A: PartialEq<B>` és `B: PartialEq<C>` és `A:
///   RészlegesEq<C>`, akkor **` a==b`és `b == c` azt jelenti, hogy`a==c`**.
///
/// Vegye figyelembe, hogy az `B: PartialEq<A>` (symmetric) és `A: PartialEq<C>` (transitive) implikumok nem kénytelenek létezni, de ezek a követelmények mindig érvényesek.
///
/// ## Derivable
///
/// Ez a trait használható az `#[derive]` készülékkel.Amikor a "derive" d a struktúrákon két példány egyenlő, ha az összes mező egyenlő, és nem egyenlő, ha bármely mező nem egyenlő.Amikor a "deriváljuk" d a számlákra, akkor mindegyik variáns egyenlő önmagával és nem egyenlő a többi változattal.
///
/// ## Hogyan tudom megvalósítani az `PartialEq`-et?
///
/// `PartialEq` csak az [`eq`] módszer megvalósítását igényli;Az [`ne`] alapértelmezés szerint annak értelmében van megadva.Az [`ne`] * bármely kézi megvalósításakor tiszteletben kell tartania azt a szabályt, hogy az [`eq`] az [`ne`] szigorú inverze;vagyis `!(a == b)` akkor és csak akkor, ha `a != b`.
///
/// Az `PartialEq`, [`PartialOrd`] és [`Ord`]*megvalósításának* meg kell egyeznie egymással.Könnyű véletlenül ellentmondásba ejteni, ha levezetjük a traits egy részét, és másokat manuálisan implementálunk.
///
/// Példa egy olyan domain megvalósítására, amelyben két könyv ugyanaz a könyv, ha ISBN-je megegyezik, még akkor is, ha a formátumok eltérnek:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Hogyan lehet összehasonlítani két különböző típust?
///
/// Az összehasonlítható típust a `PartialEq 'típusú paramétere vezérli.
/// Például módosítsuk egy kicsit az előző kódunkat:
///
/// ```
/// // A levezetés megvalósítja<BookFormat>==<BookFormat>összehasonlítások
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Végrehajtás<Book>==<BookFormat>összehasonlítások
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Végrehajtás<BookFormat>==<Book>összehasonlítások
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Az `impl PartialEq for Book` `impl PartialEq<BookFormat> for Book`-re változtatásával lehetővé tesszük a " BookFormat`összehasonlítását a " Book`-okkal.
///
/// A fenti összehasonlítás, amely figyelmen kívül hagyja a struktúra egyes területeit, veszélyes lehet.Könnyen vezethet a részleges ekvivalencia-reláció követelményeinek nem szándékos megsértéséhez.
/// Például, ha megtartjuk az `PartialEq<Book>` fenti megvalósítását az `BookFormat`-hez, és hozzáadjuk az `PartialEq<Book>` implementációját az `Book`-hez (akár egy `#[derive]`-en keresztül, akár az első példa kézi megvalósításán keresztül), akkor az eredmény sérti a transzitivitást:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Ez a módszer az `self` és az `other` értékek egyenlőségét teszteli, és az `==` használja.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Ez a módszer teszteli az `!=`-et.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Származtasson makrót, amely a trait `PartialEq` implikációját generálja.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait az egyenlőség összehasonlításához, amelyek [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation).
///
/// Ez azt jelenti, hogy amellett, hogy az `a == b` és `a != b` szigorú inverzek, az egyenlőségnek meg kell lennie (minden `a`, `b` és `c` esetében):
///
/// - reflexive: `a == a`;
/// - szimmetrikus: `a == b` `b == a`;és
/// - transzitív: az `a == b` és az `b == c` az `a == c`-et jelenti.
///
/// Ezt a tulajdonságot a fordító nem tudja ellenőrizni, ezért az `Eq` magában foglalja az [`PartialEq`]-et is, és nincs extra metódusa.
///
/// ## Derivable
///
/// Ez a trait használható az `#[derive]` készülékkel.
/// Amikor a `derive`d, mivel az `Eq`-nek nincsenek extra metódusai, csak a fordítót tájékoztatja arról, hogy ez ekvivalencia-reláció, nem pedig részleges ekvivalencia-reláció.
///
/// Vegye figyelembe, hogy az `derive` stratégia megköveteli, hogy minden mező `Eq` legyen, ami nem mindig szükséges.
///
/// ## Hogyan tudom megvalósítani az `Eq`-et?
///
/// Ha nem tudja használni az `derive` stratégiát, adja meg, hogy a típusa az `Eq`-et valósítja meg, amelynek nincs metódusa:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // ezt a módszert kizárólag#[levezetés] használja annak megállapítására, hogy egy típus minden alkotóeleme megvalósítja magát a [levezetés], a jelenlegi levezetési infrastruktúra azt jelenti, hogy ezt az állítást úgy kell elvégezni, hogy ezen a trait-nél nem használunk módszert.
    //
    //
    // Ezt soha nem szabad kézzel végrehajtani.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Származtasson makrót, amely a trait `Eq` implikációját generálja.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: ezt a struktúrát kizárólag#[derive] to használja
// azt állítják, hogy egy típus minden alkotóeleme az Eq.
//
// Ez a struktúra soha nem jelenhet meg a felhasználói kódban.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Az `Ordering` két érték összehasonlításának eredménye.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// Olyan rendelés, ahol az összehasonlított érték kisebb, mint egy másik.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// Sorrend, ahol az összehasonlított érték megegyezik egy másikkal.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// Olyan rendelés, ahol az összehasonlított érték nagyobb, mint egy másik.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Visszaadja az `true` értéket, ha a sorrend az `Equal` változat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Az `true` értéket adja vissza, ha a megrendelés nem az `Equal` változat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Visszaadja az `true` értéket, ha a sorrend az `Less` változat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Visszaadja az `true` értéket, ha a sorrend az `Greater` változat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Visszaadja az `true` értéket, ha a sorrend az `Less` vagy az `Equal` változat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Visszaadja az `true` értéket, ha a sorrend az `Greater` vagy az `Equal` változat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Megfordítja az `Ordering`-et.
    ///
    /// * `Less` `Greater` lesz.
    /// * `Greater` `Less` lesz.
    /// * `Equal` `Equal` lesz.
    ///
    /// # Examples
    ///
    /// Alapvető viselkedés:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Ez a módszer felhasználható az összehasonlítás megfordítására:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // rendezze a tömböt a legnagyobbtól a legkisebbig.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Két rendelést láncol.
    ///
    /// Az `self` értéket adja vissza, ha az nem `Equal`.Ellenkező esetben az `other` értéket adja vissza.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Láncolja a sorrendet az adott függvénnyel.
    ///
    /// Az `self` értéket adja vissza, ha az nem `Equal`.
    /// Ellenkező esetben felhívja az `f`-et, és visszaadja az eredményt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Segítő struktúra a fordított sorrendhez.
///
/// Ez a struktúra olyan segítő, amelyet olyan funkciókkal lehet használni, mint az [`Vec::sort_by_key`], és felhasználható a kulcs egy részének sorrendjének megfordítására.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait az [total order](https://en.wikipedia.org/wiki/Total_order)-et alkotó típusokhoz.
///
/// A megrendelés teljes megrendelés, ha igen (az összes `a`, `b` és `c` esetében):
///
/// - teljes és aszimmetrikus: az `a < b`, `a == b` vagy `a > b` közül pontosan az egyik igaz;és
/// - transzitív, az `a < b` és az `b < c` az `a < c`-et jelenti.Ugyanennek kell lennie az `==` és az `>` esetében is.
///
/// ## Derivable
///
/// Ez a trait használható az `#[derive]` készülékkel.
/// Amikor a `derive`d a struktúrákon, akkor [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) sorrendet állít elő, a struktúra tagjai felülről lefelé deklarációs sorrendje alapján.
///
/// Amikor a "derive" d szerepel a számlákon, a variánsokat a fentről lefelé haladó diszkrimináns sorrend szerint rendezik.
///
/// ## Lexikográfiai összehasonlítás
///
/// A lexikográfiai összehasonlítás a következő tulajdonságokkal rendelkező művelet:
///  - Két szekvenciát elemenként összehasonlítunk.
///  - Az első nem egyező elem meghatározza, hogy melyik szekvencia lexikográfiailag kisebb vagy nagyobb, mint a másik.
///  - Ha az egyik szekvencia egy másik előtagja, akkor a rövidebb szekvencia lexikográfiailag kevesebb, mint a másik.
///  - Ha két szekvenciának egyenértékű elemei vannak és azonos hosszúságúak, akkor a szekvenciák lexikográfiailag egyenlőek.
///  - Az üres szekvencia lexikográfiailag kevesebb, mint bármelyik nem üres szekvencia.
///  - Két üres szekvencia lexikográfiailag egyenlő.
///
/// ## Hogyan tudom megvalósítani az `Ord`-et?
///
/// `Ord` megköveteli, hogy a típus legyen [`PartialOrd`] és [`Eq`] is (ehhez [`PartialEq`] szükséges).
///
/// Ezután meg kell határoznia az [`cmp`] megvalósítását.Hasznosnak találhatja az [`cmp`] használatát a típus mezőiben.
///
/// Az [`PartialEq`], [`PartialOrd`] és `Ord`*megvalósításának* meg kell egyeznie egymással.
/// Vagyis `a.cmp(b) == Ordering::Equal` csak akkor, ha `a == b` és `Some(a.cmp(b)) == a.partial_cmp(b)` az összes `a` és `b` esetében.
/// Könnyű véletlenül ellentmondásba ejteni, ha levezetjük a traits egy részét, és másokat manuálisan implementálunk.
///
/// Íme egy példa, ahol az embereket csak magasság szerint szeretné rendezni, figyelmen kívül hagyva az `id` és `name` elemeket:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Ez a módszer [`Ordering`]-et ad vissza `self` és `other` között.
    ///
    /// Megállapodás szerint az `self.cmp(&other)` visszaadja az `self <operator> other` kifejezésnek megfelelő sorrendet, ha igaz.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Összehasonlítja és visszaadja a két érték maximumát.
    ///
    /// Visszaadja a második argumentumot, ha az összehasonlítás egyenlőnek találja őket.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Összehasonlítja és visszaadja a két érték minimumát.
    ///
    /// Visszaadja az első argumentumot, ha az összehasonlítás egyenlőnek találja őket.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Szűkítsen egy értéket egy bizonyos intervallumra.
    ///
    /// `max` értéket ad vissza, ha `self` nagyobb, mint `max`, és `min`, ha `self` kisebb, mint `min`.
    /// Ellenkező esetben ez az `self` értéket adja vissza.
    ///
    /// # Panics
    ///
    /// Panics ha `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Származtasson makrót, amely a trait `Ord` implikációját generálja.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait azokhoz az értékekhez, amelyek összehasonlíthatók egy rendezési sorrendben.
///
/// Az összehasonlításnak minden `a`, `b` és `c` esetében meg kell felelnie:
///
/// - aszimmetria: ha `a < b`, akkor `!(a > b)`, valamint `a > b`, amely `!(a < b)`-et jelent;és
/// - transzitivitás: `a < b` és `b < c` `a < c`-et jelent.Ugyanennek kell lennie az `==` és az `>` esetében is.
///
/// Ne feledje, hogy ezek a követelmények azt jelentik, hogy magát a trait szimmetrikusan és átmenetileg kell megvalósítani: ha `T: PartialOrd<U>` és `U: PartialOrd<V>`, akkor `U: PartialOrd<T>` és `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// Ez a trait használható az `#[derive]` készülékkel.Amikor a "származtatja" a struktúrákat, lexikográfiai sorrendet készít, amely a struktúra tagjai felülről lefelé deklarációs sorrendje alapján készül.
/// Amikor a "derive" d szerepel a számlákon, a variánsokat a fentről lefelé haladó diszkrimináns sorrend szerint rendezik.
///
/// ## Hogyan tudom megvalósítani az `PartialOrd`-et?
///
/// `PartialOrd` csak az [`partial_cmp`] módszer megvalósítását igényli, a többi pedig az alapértelmezett megvalósításokból jön létre.
///
/// Azonban továbbra is lehetséges a többiek külön-külön megvalósítása olyan típusok esetében, amelyek nem rendelkeznek teljes sorrenddel.
/// Például lebegőpontos számok esetén az `NaN < 0 == false` és az `NaN >= 0 == false` (vö.
/// IEEE 754-2008 5.11 szakasz).
///
/// `PartialOrd` megköveteli, hogy a típusod [`PartialEq`] legyen.
///
/// Az [`PartialEq`], `PartialOrd` és [`Ord`]*megvalósításának* meg kell egyeznie egymással.
/// Könnyű véletlenül ellentmondásba ejteni, ha levezetjük a traits egy részét, és másokat manuálisan implementálunk.
///
/// Ha az Ön típusa [`Ord`], akkor az [`partial_cmp`]-et az [`cmp`] használatával valósíthatja meg:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Hasznos lehet az [`partial_cmp`] használata a típusa mezőiben is.
/// Íme egy példa azokra az `Person` típusokra, akik lebegőpontos `height` mezővel rendelkeznek, amely az egyetlen mező, amelyet rendezésre lehet használni:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Ez a módszer az `self` és az `other` értékek közötti sorrendet adja vissza, ha van ilyen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Ha lehetetlen összehasonlítani:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Ez a módszer kevesebb mint (`self` és `other` esetén) tesztel, és az `<` operátor használja.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Ez a módszer kisebb vagy egyenlő (`self` és `other` esetén) tesztel, és az `<=` operátor használja.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Ez a módszer nagyobb mint (`self` és `other` esetén) tesztel, és az `>` operátor használja.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Ez a módszer nagyobb vagy egyenlő (`self` és `other` esetén) tesztel, és az `>=` operátor használja.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Származtasson makrót, amely a trait `PartialOrd` implikációját generálja.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Összehasonlítja és visszaadja a két érték minimumát.
///
/// Visszaadja az első argumentumot, ha az összehasonlítás egyenlőnek találja őket.
///
/// Belsőleg használ egy álnevet az [`Ord::min`]-hez.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Visszaadja a minimum két értéket a megadott összehasonlító függvényhez képest.
///
/// Visszaadja az első argumentumot, ha az összehasonlítás egyenlőnek találja őket.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Visszaadja azt az elemet, amely megadja a minimális értéket a megadott függvényből.
///
/// Visszaadja az első argumentumot, ha az összehasonlítás egyenlőnek találja őket.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Összehasonlítja és visszaadja a két érték maximumát.
///
/// Visszaadja a második argumentumot, ha az összehasonlítás egyenlőnek találja őket.
///
/// Belsőleg használ egy álnevet az [`Ord::max`]-hez.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Visszaadja a két érték maximumát a megadott összehasonlító függvényhez képest.
///
/// Visszaadja a második argumentumot, ha az összehasonlítás egyenlőnek találja őket.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Visszaadja azt az elemet, amely megadja a maximális értéket a megadott függvényből.
///
/// Visszaadja a második argumentumot, ha az összehasonlítás egyenlőnek találja őket.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// PartialEq, Eq, PartialOrd és Ord megvalósítása primitív típusoknál
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // Az itteni sorrend fontos az optimálisabb összeállítás érdekében.
                    // További információ: <https://github.com/rust-lang/rust/issues/63758>.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // Az i8-as verzióra történő átküldés és a különbség megrendeléssé alakítása optimálisabb összeállítást eredményez.
            //
            // További információ: <https://github.com/rust-lang/rust/issues/66780>.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // BIZTONSÁG: A bool, mivel az i8 értéke 0 vagy 1, így a különbség nem lehet más
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &mutatók

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}