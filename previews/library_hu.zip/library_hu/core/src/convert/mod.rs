//! Traits a típusok közötti konverziókhoz.
//!
//! A modul traits módja az egyik típusból a másikba való átalakítás.
//! Minden trait más célt szolgál:
//!
//! - Az [`AsRef`] trait implementálása az olcsó referencia-referencia konverziók érdekében
//! - Vezesse be az [`AsMut`] trait-t az olcsó mutábilis-mutábilis konverziók érdekében
//! - Használja az [`From`] trait érték-érték konverziók fogyasztását
//! - Az [`Into`] trait megvalósítása az érték-érték konverziók fogyasztásához a jelenlegi crate-n kívüli típusokhoz
//! - Az [`TryFrom`] és [`TryInto`] traits úgy viselkednek, mint az [`From`] és [`Into`], de akkor kell végrehajtani, ha az átalakítás sikertelen lehet.
//!
//! Ebben a modulban a traits-t gyakran használják trait bounds-ként olyan általános funkciókhoz, amelyek többféle argumentumot támogatnak.Példákért tekintse meg az egyes trait dokumentációkat.
//!
//! Könyvtárszerzőként mindig inkább az [`From<T>`][`From`] vagy az [`TryFrom<T>`][`TryFrom`] megvalósítását részesítse előnyben az [`Into<U>`][`Into`] vagy az [`TryInto<U>`][`TryInto`] helyett, mivel az [`From`] és az [`TryFrom`] nagyobb rugalmasságot biztosít, és egyenértékű [`Into`] vagy [`TryInto`] megvalósításokat kínál ingyen, a standard könyvtárban található átfogó megvalósításnak köszönhetően.
//! A Rust 1.41 előtti verzió megcélzásakor szükség lehet az [`Into`] vagy [`TryInto`] közvetlen megvalósítására, amikor a jelenlegi crate-n kívüli típusra konvertálunk.
//!
//! # Általános megvalósítások
//!
//! - [`AsRef`] és [`AsMut`] auto-dereference, ha a belső típus referencia
//! - A ["From"] <U>a T számára azt jelenti, hogy [Into]]</u><T><U>U-ért</u>
//! - A [`TryFrom`] <U>a T esetében azt jelenti, hogy a``TryInto`]</u><T><U>U-ért</u>
//! - [`From`] és az [`Into`] reflexív, ami azt jelenti, hogy minden típus képes `into` magának és `from` magának is
//!
//! Az egyes trait felhasználási példákat lásd.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Az identitásfüggvény.
///
/// Két fontos megjegyezni ezt a funkciót:
///
/// - Ez nem mindig egyenértékű egy olyan zárással, mint az `|x| x`, mivel a lezárás más típusra kényszerítheti az `x`-et.
///
/// - A funkcióhoz továbbított `x` bemenetet mozgatja.
///
/// Bár furcsának tűnhet egy olyan funkció, amely csak visszaadja a bemenetet, van néhány érdekes felhasználás.
///
///
/// # Examples
///
/// Az `identity` használatával semmit nem tehet más érdekes funkciók sorozatában:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Tegyük fel, hogy az egyik hozzáadása érdekes funkció.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Az `identity` használata "do nothing" alap esetként feltételesen:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Csinálj több érdekes dolgot ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Az `identity` használatával megtartja az `Option<T>` iterátorának `Some` változatait:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Használt olcsó referencia-referencia konverzióra.
///
/// Ez a trait hasonló az [`AsMut`]-hez, amelyet konvertálásra használnak a mutábilis referenciák között.
/// Ha költséges átalakítást kell végrehajtania, akkor jobb, ha az [`From`]-et `&T`-es tipussal hajtja végre, vagy egyéni függvényt ír.
///
/// `AsRef` ugyanolyan aláírással rendelkezik, mint az [`Borrow`], de az [`Borrow`] néhány szempontból különbözik:
///
/// - Az `AsRef`-től eltérően az [`Borrow`] rendelkezik egy burkolattal bármely `T`-hez, és használható referencia vagy érték elfogadására.
/// - [`Borrow`] azt is előírja, hogy a kölcsönzött értékre vonatkozó [`Hash`], [`Eq`] és [`Ord`] egyenértékű legyen a tulajdonban lévő értékével.
/// Ezért, ha egy struktúra csak egy mezőjét akarja kölcsönadni, akkor az `AsRef`-et megvalósíthatja, az [`Borrow`]-et azonban nem.
///
/// **Note: Ez a trait nem hibásodhat meg **.Ha az átalakítás sikertelen lehet, használjon dedikált módszert, amely [`Option<T>`] vagy [`Result<T, E>`] értéket ad vissza.
///
/// # Általános megvalósítások
///
/// - `AsRef` automatikus hivatkozások, ha a belső típus referencia vagy módosítható referencia (pl .: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// A trait bounds használatával különböző típusú argumentumokat fogadhatunk el, amennyiben azok a megadott `T` típusra konvertálhatók.
///
/// Például: Egy olyan általános függvény létrehozásával, amely `AsRef<str>`-et vesz fel, kifejezzük, hogy argumentumként el akarunk fogadni minden olyan hivatkozást, amelyet [`&str`]-be lehet konvertálni.
/// Mivel mind az [`String`], mind az [`&str`] megvalósítja az `AsRef<str>`-et, mindkettőt elfogadhatjuk bemeneti argumentumként.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Végzi az átalakítást.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Használt olcsó mutábilis-mutábilis referencia konverzió elvégzésére.
///
/// Ez a trait hasonlít az [`AsRef`]-hez, de átalakítható hivatkozások közötti átalakításra szolgál.
/// Ha költséges átalakítást kell végrehajtania, akkor jobb, ha az [`From`]-et `&mut T`-es tipussal hajtja végre, vagy egyéni függvényt ír.
///
/// **Note: Ez a trait nem hibásodhat meg **.Ha az átalakítás sikertelen lehet, használjon dedikált módszert, amely [`Option<T>`] vagy [`Result<T, E>`] értéket ad vissza.
///
/// # Általános megvalósítások
///
/// - `AsMut` auto-dereferenciák, ha a belső típus mutábilis referencia (pl .: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Az `AsMut` használatával trait bound néven egy általános függvényként elfogadhatunk minden mutálható referenciát, amely `&mut T` típusra konvertálható.
/// Mivel az [`Box<T>`] megvalósítja az `AsMut<T>`-et, írhatunk egy `add_one` függvényt, amely az összes argumentumot átviheti `&mut u64`-be.
/// Mivel az [`Box<T>`] megvalósítja az `AsMut<T>`-et, az `add_one` elfogadja az `&mut Box<u64>` típusú argumentumokat is:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Végzi az átalakítást.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Érték-érték konverzió, amely felemészti a bemeneti értéket.Az [`From`] ellentéte.
///
/// Kerülni kell az [`Into`] és az [`From`] bevezetését.
/// Az [`From`] megvalósítása automatikusan biztosítja az [`Into`] megvalósítását, a szabványos könyvtár általános megvalósításának köszönhetően.
///
/// A trait bounds megadásakor egy általános függvénynél előnyösebb az [`Into`] használata az [`From`] helyett, annak biztosítása érdekében, hogy csak [`Into`] megvalósító típusok is használhatók legyenek.
///
/// **Note: Ez a trait nem hibásodhat meg **.Ha az átalakítás nem sikerül, használja az [`TryInto`] szoftvert.
///
/// # Általános megvalósítások
///
/// - ["From"]<T>mert U` `Into<U> for T`-et jelent
/// - [`Into`] reflexív, ami azt jelenti, hogy az `Into<T> for T` megvalósításra került
///
/// # Az [`Into`] megvalósítása külső típusú konverziókhoz a Rust régi verzióiban
///
/// A Rust 1.41 előtt, ha a céltípus nem volt a jelenlegi crate része, akkor az [`From`]-et nem tudta közvetlenül végrehajtani.
/// Vegyük például ezt a kódot:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Ezt nem lehet összeállítani a nyelv régebbi verzióiban, mert a Rust árva szabályai valamivel szigorúbbak voltak.
/// Ennek kikerüléséhez közvetlenül megvalósíthatja az [`Into`]-et:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Fontos megérteni, hogy az [`Into`] nem nyújt [`From`] megvalósítást (mint az [`From`] az [`Into`] esetében).
/// Ezért mindig meg kell próbálnia az [`From`] megvalósítását, majd vissza kell térnie az [`Into`]-re, ha az [`From`] nem valósítható meg.
///
/// # Examples
///
/// [`String`] megvalósítja a [`Into`]``` ```` ``Vec``` ```` ```` ```` ``>>``:
///
/// Annak kifejezésére, hogy egy általános függvénynek minden olyan argumentumot fel kell vennie, amelyet egy meghatározott `T` típusba lehet konvertálni, használhatunk egy trait bound értéket [Into] "<T>".
///
/// Például: Az `is_hello` függvény minden olyan argumentumot felvesz, amely átalakítható ["Vec"] "<" ["u8`]`>"jellé.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Végzi az átalakítást.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Érték-érték konverziók végrehajtására szolgál, miközben a bemeneti értéket elfogyasztja.Ez az [`Into`] reciproka.
///
/// Mindig előnyben kell részesíteni az `From` bevezetését az [`Into`] helyett, mert az `From` megvalósítása automatikusan biztosítja az [`Into`] megvalósítását, a szabványos könyvtár általános megvalósításának köszönhetően.
///
///
/// Csak akkor hajtsa végre az [`Into`]-et, ha a Rust 1.41 előtti verziót célozza meg, és a jelenlegi crate-n kívüli típusra konvertál.
/// `From` a Rust árva szabályai miatt nem volt képes ilyen típusú átalakításokra a korábbi verziókban.
/// További részletek: [`Into`].
///
/// A trait bounds megadásakor egy általános függvénynél előnyösebb az [`Into`] használata az `From` helyett.
/// Így az [`Into`]-et közvetlenül megvalósító típusok is használhatók argumentumként.
///
/// Az `From` a hibakezelés során is nagyon hasznos.A meghibásodásra képes függvény összeállításakor a visszatérési típus általában `Result<T, E>` alakú lesz.
/// Az `From` trait egyszerűsíti a hibakezelést azáltal, hogy lehetővé teszi egy funkció számára, hogy egyetlen hibatípust adjon vissza, amely több hibatípust foglal magában.További részletekért lásd az "Examples" és az [the book][book] szakaszokat.
///
/// **Note: Ez a trait nem hibásodhat meg **.Ha az átalakítás nem sikerül, használja az [`TryFrom`] szoftvert.
///
/// # Általános megvalósítások
///
/// - `From<T> for U` magában foglalja az "Into"-t <U>T-re</u>
/// - `From` reflexív, ami azt jelenti, hogy az `From<T> for T` megvalósításra került
///
/// # Examples
///
/// [`String`] eszköz `From<&str>`:
///
/// Az `&str`-ből egy String-be történő kifejezett átalakítás a következőképpen történik:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// A hibakezelés során gyakran hasznos az `From` telepítése saját hibatípusához.
/// Az alapul szolgáló hibatípusok konvertálásával saját hibatípusunkká, amely az alapul szolgáló hibatípust foglalja magában, egyetlen hibatípust adhatunk vissza anélkül, hogy elveszítenénk az alapjául szolgáló okról szóló információkat.
/// Az '?' operátor automatikusan átalakítja a mögöttes hibatípust az egyedi hibatípusunkká az `Into<CliError>::into` hívásával, amelyet az `From` megvalósításakor automatikusan megadunk.
/// Ezután a fordító arra következtet, hogy az `Into` melyik implementációját kell használni.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Végzi az átalakítást.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Megpróbált konverzió, amely `self`-et fogyaszt, ami drága vagy nem.
///
/// A könyvtári szerzőknek általában nem közvetlenül kell végrehajtaniuk ezt a trait-t, hanem inkább az [`TryFrom`] trait megvalósítását részesítik előnyben, amely nagyobb rugalmasságot kínál és egyenértékű `TryInto` megvalósítást biztosít ingyen, a standard könyvtárban található átfogó megvalósításnak köszönhetően.
/// További információ erről az [`Into`] dokumentációjában található.
///
/// # Az `TryInto` megvalósítása
///
/// Ezt ugyanazok a korlátozások és érvelés éri, mint az [`Into`] megvalósítását, a részletekért lásd ott.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Konverziós hiba esetén visszaadott típus.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Végzi az átalakítást.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Egyszerű és biztonságos típusú konverziók, amelyek ellenőrzött módon bizonyos körülmények között kudarcot vallhatnak.Ez az [`TryInto`] reciproka.
///
/// Ez akkor hasznos, ha olyan típusátalakítást végez, amely triviálisan sikeres lehet, de különleges kezelésre is szükség lehet.
/// Például nincs mód az [`i64`] átalakítására [`i32`] formátumra az [`From`] trait használatával, mert egy [`i64`] tartalmazhat olyan értéket, amelyet egy [`i32`] nem tud képviselni, és így az átalakítás elveszítené az adatokat.
///
/// Ezt úgy kezelhetjük, hogy az [`i64`]-et [`i32`]-szé csonkoljuk (lényegében megadva az [i64`] [`i32::MAX`] modulo értékét), vagy egyszerűen visszaadva az [`i32::MAX`]-et, vagy más módszerrel.
/// Az [`From`] trait tökéletes átalakításra készült, ezért az `TryFrom` trait tájékoztatja a programozót, ha a típusátalakítás rosszul alakulhat, és lehetővé teszi számukra, hogy miként kezeljék azt.
///
/// # Általános megvalósítások
///
/// - `TryFrom<T> for U` a [`TryInto`]`-t jelenti <U>T-re</u>
/// - [`try_from`] reflexív, ami azt jelenti, hogy az `TryFrom<T> for T` implementálva van, és nem tud kudarcot vallani-az `Error` típushoz tartozó `T::try_from()` hívásához [`Infallible`] a társított `Error` típus.
/// Az [`!`] típus stabilizálása esetén az [`Infallible`] és az [`!`] egyenértékű lesz.
///
/// `TryFrom<T>` az alábbiak szerint valósítható meg:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Amint leírtuk, az [`i32`] végrehajtja a " TryFrom <`[`i64`]`> `-t:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Csendesen csonkolja az `big_number`-et, megköveteli a csonkolás detektálását és kezelését.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Hibát ad vissza, mert az `big_number` túl nagy ahhoz, hogy elférjen az `i32`-ben.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Visszaadja az `Ok(3)` értéket.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Konverziós hiba esetén visszaadott típus.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Végzi az átalakítást.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// ÁLTALÁNOS VONATKOZÁSOK
////////////////////////////////////////////////////////////////////////////////

// Ahogy felemelkedik
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Ahogy az &mut felett felemelkedik
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): cserélje le a&/&mut fenti implicitjeit a következő általánosabbra:
// // Ahogy Deref fölé emelkedik
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Méretezett> AsRef <U>D-hez {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// Az AsMut felemeli az &mut-et
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): cserélje le az &mut fenti implicitjét a következő általánosabbra:
// // Az AsMut felemeli a DerefMutot
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Sized> AsMut <U>for D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// From-ból következik Into
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// From (és így Into) reflexív
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Stabilitási megjegyzés:** Ez az implikáció még nem létezik, de "reserving space"-en vagyunk, hogy hozzáadjuk a future-hez.
/// További részletek: [rust-lang/rust#64715][#64715].
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): csinálj helyette elvi javítást.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// A TryFrom a TryInto-t jelenti
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// A tévedhetetlen konverziók szemantikailag egyenértékűek a lakatlan hibatípussal rendelkező tévedésekkel.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// BETON IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// A HIBA NINCS HIBATÍPUS
////////////////////////////////////////////////////////////////////////////////

/// A hibák típusa, amelyek soha nem fordulhatnak elő.
///
/// Mivel ennek az enumnak nincs változata, egy ilyen típusú érték valójában soha nem létezhet.
/// Ez hasznos lehet olyan általános API-knál, amelyek [`Result`]-et használnak és paraméterezik a hibatípust, jelezve, hogy az eredmény mindig [`Ok`].
///
/// Például az [`TryFrom`] trait (konverzió, amely [`Result`]-t ad vissza) átfogó megvalósítással rendelkezik minden olyan típus esetében, ahol fordított [`Into`] megvalósítás létezik.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future kompatibilitás
///
/// Ennek az enumnak ugyanolyan szerepe van, mint az [the `!`“never”type][never]-nek, amely instabil a Rust ezen verziójában.
/// Ha az `!` stabilizálódik, azt tervezzük, hogy az `Infallible`-t típusaliassá tesszük:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …És végül elavul az `Infallible`.
///
/// Van azonban egy olyan eset, amikor az `!` szintaxisa használható, mielőtt az `!` teljes értékű típusként stabilizálódik: a függvény visszatérési típusának helyzetében.
/// Pontosabban lehetséges két különböző funkciómutatótípus megvalósítása:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Mivel az `Infallible` enum, ez a kód érvényes.
/// Ha azonban az `Infallible` a never type álnevévé válik, akkor a két implicit átfedésben van, ezért a nyelv trait koherenciaszabályai nem engedik meg.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}