//! Panic támogatás a libcore-hoz
//!
//! Az alapkönyvtár nem tudja meghatározni a pánikot, de * deklarálja a pánikolást.
//! Ez azt jelenti, hogy a libcore belsejében lévő funkciók engedélyezettek a panic számára, de ahhoz, hogy hasznos legyen, egy upstream crate-nek meg kell határoznia a pánikolást a libcore használatához.
//! A jelenlegi pánikfelület a következő:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Ez a meghatározás lehetővé teszi a pánikba kerülést bármely általános üzenettel, de nem teszi lehetővé az `Box<Any>` értékkel való kudarcot.
//! (Az `PanicInfo` csak tartalmaz egy `&(dyn Any + Send)`-et, amelyhez a "PanicInfo: : internal_constructor" mezőben kitöltünk egy dummy értéket.) Ennek az az oka, hogy a libcore nem allokálhat.
//!
//!
//! Ez a modul tartalmaz még néhány pánikfunkciót, de ezek csak a fordító szükséges lang elemei.Az összes panics csatornán keresztül ezen az egyetlen funkción keresztül lehet csatornázni.
//! A tényleges szimbólum az `#[panic_handler]` attribútumon keresztül deklarálható.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// A libcore `panic!` makrójának megvalósítása, ha nincs formázás.
#[cold]
// soha ne legyen inline, hacsak a panic_immediate_abort segítségével elkerülhető, hogy a telefonhívások a lehető legnagyobb mértékben felfújódjanak a hívóhelyeken
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // szükséges a codegen számára a panic számára a túlcsorduláson és más `Assert` MIR terminátorokon
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Használja az Arguments::new_v1-et a format_args! ("{}", Expr) helyett a méret általános csökkentéséhez.
    // A format_args!A makró az str Display trait parancsával írja az expr-t, amely az Formatter::pad-et hívja, amelynek be kell illesztenie a karakterlánc csonkolását és kitöltését (bár itt egyiket sem használjuk).
    //
    // Az Arguments::new_v1 használata lehetővé teheti a fordító számára, hogy kihagyja az Formatter::pad-et a kimeneti bináris fájlból, így akár néhány kilobájtot is megtakaríthat.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // szükséges a const-értékelt panics-hez
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // szükséges a codegen számára a panic számára az OOB array/slice hozzáférésnél
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Formázáskor a libcore `panic!` makrójának megvalósítása.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // MEGJEGYZÉS Ez a funkció soha nem lépi át az FFI határát;ez egy Rust-Rust hívás, amely megoldódik az `#[panic_handler]` funkcióra.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // BIZTONSÁG: Az `panic_impl` a biztonságos Rust kódban van meghatározva, így biztonságosan hívható.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Belső funkció `assert_eq!` és `assert_ne!` makrókhoz
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}