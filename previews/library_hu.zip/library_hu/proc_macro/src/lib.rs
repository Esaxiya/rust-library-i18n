//! Támogatási könyvtár makrók számára az új makrók definiálásakor.
//!
//! Ez a könyvtár, amelyet a szabványos disztribúció biztosít, biztosítja az eljárással meghatározott makródefiníciók interfészeiben elfogyasztott típusokat, például a függvényszerű makrókat `#[proc_macro]`, az `#[proc_macro_attribute]` makróattribútumokat és az egyéni derivált attribútumokat "#[proc_macro_derive]".
//!
//!
//! További információkért lásd: [the book].
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Meghatározza, hogy a proc_macro hozzáférhető-e a jelenleg futó program számára.
///
/// A proc_macro crate csak az eljárási makrók végrehajtására szolgál.A crate panic összes funkciója, ha egy eljárási makrón kívülről hívják meg, például egy build szkriptből vagy egység tesztből vagy a közönséges Rust binárisból.
///
/// Figyelembe véve a Rust könyvtárakat, amelyeket mind a makro, mind a nem makro felhasználási esetek támogatására terveztek, az `proc_macro::is_available()` pánikmentes módot kínál annak észlelésére, hogy a proc_macro API használatához szükséges infrastruktúra jelenleg rendelkezésre áll-e.
/// Igaz, ha egy eljárási makró belsejéből hívja meg, hamis, ha más binárisból hívják meg.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// A crate által biztosított fő típus, amely a tokens absztrakt áramát, vagy pontosabban a token fák sorozatát képviseli.
/// A típus biztosít interfészeket az említett token fák közötti iterációhoz, és fordítva, számos token fának egy patakba gyűjtéséhez.
///
///
/// Ez az `#[proc_macro]`, `#[proc_macro_attribute]` és `#[proc_macro_derive]` definíciók bemenete és kimenete egyaránt.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Hiba érkezett az `TokenStream::from_str` eszközről.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Visszaad egy üres `TokenStream`-et, amely nem tartalmaz token-fákat.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Ellenőrzi, hogy ez az `TokenStream` üres-e.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Megpróbálja feltörni a karakterláncot tokens-re és elemezni ezeket a tokens-t token folyamra.
/// Több okból is kudarcot vallhat, például ha a karakterlánc kiegyensúlyozatlan elválasztókat vagy a nyelvben nem létező karaktereket tartalmaz.
///
/// Az elemzett adatfolyam összes tokens-je `Span::call_site()`-tartományt kap.
///
/// NOTE: egyes hibák az `LexError` visszaadása helyett a panics-t okozhatják.Fenntartjuk a jogot arra, hogy ezeket a hibákat később "LexError"-okká változtassuk.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// Megjegyezzük, hogy a híd csak az `to_string` szolgáltatást nyújtja, ennek alapján valósítsa meg az `fmt::Display`-et (a kettő közötti szokásos viszony fordítottja).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// A token folyamot olyan karaktersorozatként nyomtatja ki, amely állítólag veszteségmentesen átalakítható vissza ugyanabba a token folyamba (modulo átívelés), kivéve az esetleges `TokenTree: : Group`-okat `Delimiter::None` elválasztókkal és negatív numerikus literálokkal.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Kinyomtatja a token hibakereséshez alkalmas formában.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// token folyamot hoz létre, amely egyetlen token fát tartalmaz.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Számos token fát gyűjt össze egyetlen folyamba.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Az "flattening" művelet a token folyamokon összegyűjti a token fákat több token adatfolyamból egyetlen adatfolyamba.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Használjon optimalizált if/when megvalósítást.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Az `TokenStream` típus nyilvános megvalósításának részletei, például az iterátorok.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Iterátor a " TokenStream` TokenTree-jén.
    /// Az iteráció "shallow", pl. Az iterátor nem tér vissza elválasztott csoportokba, és egész csoportokat ad vissza token fákként.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` elfogadja az önkényes tokens-t és kibővül a bemenetet leíró `TokenStream`-be.
/// Például az `quote!(a + b)` kifejezést hoz létre, amely kiértékeléskor elkészíti az `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Az ajánlattétel az `$` segítségével történik, és úgy működik, hogy az egyetlen következő azonosítót veszi fel nem idézett kifejezésként.
/// Magának az `$`-nek az idézéséhez használja az `$$`-et.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// A forráskód régiója, makróbővítési információkkal együtt.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Új `Diagnostic`-et hoz létre a megadott `message`-szel az `self` tartományban.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// A makródefiníciós helyen feloldódó tartomány.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// A jelenlegi eljárási makró meghívásának tartománya.
    /// Az ezzel az időtartammal létrehozott azonosítók úgy lesznek feloldva, mintha közvetlenül a makrohívás helyén írták volna őket (híváshelyi higiénia), és a makrohíváshely más kódjai is hivatkozni tudnának rájuk.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Olyan tartomány, amely az `macro_rules` higiéniát képviseli, és néha feloldódik a makródefiníciós helyen (helyi változók, címkék, `$crate`), és néha a makrohívás helyén (minden más).
    ///
    /// A fesztávolság helye a hívóhelyről származik.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Az eredeti forrásfájl, ahová ez a span mutat.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// A tokens `Span`-je az előző makrobővítésnél, amelyből az `self` keletkezett, ha van ilyen.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Az `self` származási forráskódjának tartománya.
    /// Ha ezt az `Span`-et nem más makróbővítésekből generálták, akkor a visszatérési érték megegyezik az `*self` értékével.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Megkapja a kezdő line/column-et a forrásfájlban ehhez a tartományhoz.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Megkapja az line/column végződést a forrásfájlban ehhez a tartományhoz.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Új tartományt hoz létre, amely magában foglalja az `self` és `other` elemeket.
    ///
    /// Az `None` értéket adja vissza, ha az `self` és az `other` különböző fájlokból származik.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Új tartományt hoz létre ugyanazzal az line/column információval, mint az `self`, de ez megoldja a szimbólumokat, mintha az `other`-nél lennének.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Új tartományt hoz létre ugyanazzal a névfeloldási viselkedéssel, mint az `self`, de az `other` line/column információival.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// A fesztávolságokkal összehasonlítva megnézzük, hogy egyenlőek-e.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// A forrásszöveget egy span mögött adja vissza.
    /// Ez megőrzi az eredeti forráskódot, beleértve a szóközöket és a megjegyzéseket.
    /// Csak akkor ad eredményt, ha a tartomány megfelel a valós forráskódnak.
    ///
    /// Note: A makró megfigyelhető eredménye csak a tokens-re támaszkodhat, és nem erre a forrásszövegre.
    ///
    /// Ennek a funkciónak az eredménye a legjobb erőfeszítés, amelyet csak diagnosztikára lehet használni.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Kiterjedést nyomtat a hibakereséshez megfelelő formában.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Az `Span` kezdetét vagy végét ábrázoló vonal-oszloppár.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Az 1 indexelt sor a forrásfájlban, amelyen a span kezdődik vagy végződik az (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// A 0-indexelt oszlop (UTF-8 karakterekkel) abban a forrásfájlban, amelyen a span kezdődik vagy végződik az (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Egy adott `Span` forrásfájlja.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Megkapja a forrásfájl elérési útját.
    ///
    /// ### Note
    /// Ha az `SourceFile`-hez társított kódtartományt egy külső makró hozta létre, akkor ez a makró nem biztos, hogy ez a fájlrendszer tényleges útvonala.
    /// Használja az [`is_real`]-et az ellenőrzéshez.
    ///
    /// Vegye figyelembe azt is, hogy még akkor is, ha az `is_real` visszaadja az `true` értéket, ha az `--remap-path-prefix` parancsot továbbította a parancssoron, akkor a megadott útvonal valószínűleg nem érvényes.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Visszaadja az `true` értéket, ha ez a forrásfájl valódi forrásfájl, és nem egy külső makró kiterjesztése hozta létre.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Ez egy feltörés mindaddig, amíg az interrátus tartományok be nem kerülnek, és valós forrásfájlokat állíthatunk rendelkezésre a külső makrókban létrehozott spanok számára.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Egyetlen token vagy a token fák elhatárolt szekvenciája (pl. `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// token folyam zárójel-elválasztókkal körülvéve.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Egy azonosító.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Egyetlen írásjel (`+`, `,`, `$` stb.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Egy szó szerinti karakter (`'a'`), (`"hello"`) karakterlánc, (`2.3`) szám stb.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Visszaadja ennek a fának a kiterjedését, a benne lévő token vagy egy elhatárolt adatfolyam `span` metódusára delegálva.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Konfigurálja a *csak a token* tartományát.
    ///
    /// Ne feledje, hogy ha ez a token `Group`, akkor ez a módszer nem konfigurálja a belső tokens mindegyikének tartományát, ez egyszerűen az egyes változatok `set_span` metódusát fogja delegálni.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// A token fát a hibakereséshez kényelmes formában nyomtatja ki.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Ezek mindegyikének megvan a neve a származtatott hibakeresésben a struktúra típusban, ezért ne zavarjon egy további indirekciós réteget
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// Megjegyezzük, hogy a híd csak az `to_string` szolgáltatást nyújtja, ennek alapján valósítsa meg az `fmt::Display`-et (a kettő közötti szokásos viszony fordítottja).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// A token fát karaktersorozatként nyomtatja ki, amely állítólag veszteségmentesen átalakítható vissza ugyanabba a token fába (modulo átívelés), kivéve az esetleges `TokenTree: : Group`-okat `Delimiter::None` elválasztókkal és negatív numerikus literálokkal.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Elhatárolt token folyam.
///
/// Az `Group` belsőleg tartalmaz egy `TokenStream`-et, amelyet `Delimiter` vesz körül.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Leírja, hogyan határolják el a token fák sorozatát.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Egy implicit határoló, amely például egy "macro variable" `$var`-ből származó tokens körül jelenhet meg.
    /// Fontos megőrizni a kezelő prioritásait olyan esetekben, mint az `$var * 3`, ahol az `$var` az `1 + 2`.
    /// Az implicit határolók nem biztos, hogy túlélik a token folyam körbefutását egy húron keresztül.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Új `Group`-et hoz létre a megadott elválasztóval és token folyammal.
    ///
    /// Ez a konstruktor ennek a csoportnak a tartományát `Span::call_site()`-re állítja.
    /// A tartomány megváltoztatásához használhatja az alábbi `set_span` módszert.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Visszaadja ennek az `Group` elválasztóját
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Visszaadja a tokens `TokenStream` értékét, amelyet ebben az `Group` határol.
    ///
    /// Ne feledje, hogy a visszaküldött token adatfolyam nem tartalmazza a fent megadott határolót.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Visszaadja ennek a token folyamnak a határolóinak a tartományát, amely az egész `Group`-et átíveli.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Visszaadja a tartományt, amely a csoport nyitó határolójára mutat.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Visszaadja a tartományt, amely a csoport záró határolójára mutat.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Konfigurálja a `Csoport 'elválasztóinak tartományát, de nem a belső tokens-t.
    ///
    /// Ez a módszer **nem** nem állítja be az összes belső tokens tartományát, amelyet e csoport lefed, hanem inkább csak a tokens elválasztó tartományát állítja be az `Group` szintjén.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// Megjegyezzük, hogy a híd csak az `to_string` szolgáltatást nyújtja, ennek alapján valósítsa meg az `fmt::Display`-et (a kettő közötti szokásos viszony fordítottja).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// A csoportot karaktersorozatként nyomtatja ki, amelyet veszteségmentesen vissza kell alakítani ugyanabba a csoportba (modulo span), kivéve az esetleges `TokenTree: : Group`-okat `Delimiter::None` elválasztókkal.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// Az `Punct` egyetlen írásjel, például `+`, `-` vagy `#`.
///
/// Az olyan több karakterből álló operátorok, mint az `+=`, az `Punct` két példányaként jelennek meg, az `Spacing` különböző formáival.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Akár egy `Punct`-et azonnal követ egy másik `Punct`, akár egy másik token vagy egy szóköz?
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// pl. `+` jelentése `Alone` `+ =`, `+ident` vagy `+()` formában.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// pl. `+` jelentése `Joint` `+=` vagy `'#` értékekben.
    /// Ezenkívül az `'` egyetlen idézet csatlakozhat azonosítókhoz az `'ident` élettartam kialakításához.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Új `Punct`-et hoz létre az adott karakterből és a szóközből.
    /// Az `ch` argumentumnak érvényes írásjelnek kell lennie, amelyet a nyelv engedélyez, különben a függvény panic lesz.
    ///
    /// A visszaküldött `Punct` alapértelmezett tartománya az `Span::call_site()` lesz, amely az alábbi `set_span` módszerrel tovább konfigurálható.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Ennek az írásjelnek `char` értéket ad vissza.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Visszaadja ennek az írásjelnek a szóközét, jelezve, hogy azonnal következik-e egy újabb `Punct` a token adatfolyamban, így potenciálisan kombinálhatók egy több karakteres (`Joint`) operátorrá, vagy ezt követheti más token vagy fehér szóköz (`Alone`), így az operátor minden bizonnyal vége lett.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Visszaadja ennek az írásjelnek az átmérőjét.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigurálja az intervallumot ennek az írásjelnek.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// Megjegyezzük, hogy a híd csak az `to_string` szolgáltatást nyújtja, ennek alapján valósítsa meg az `fmt::Display`-et (a kettő közötti szokásos viszony fordítottja).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Az írásjeleket karakterláncként nyomtatja ki, amelyet veszteségmentesen vissza kell alakítani ugyanabba a karakterbe.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// (`ident`) azonosító.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Létrehoz egy új `Ident`-et a megadott `string`-szel, valamint a megadott `span`-szel.
    /// Az `string` argumentumnak érvényes azonosítónak kell lennie, amelyet a nyelv engedélyez (beleértve a kulcsszavakat, pl. `self` vagy `fn`).Ellenkező esetben a függvény panic lesz.
    ///
    /// Vegye figyelembe, hogy az `span`, jelenleg a rustc fájlban van, konfigurálja az azonosító higiéniai adatait.
    ///
    /// Ettől az időponttól kezdve az `Span::call_site()` kifejezetten az "call-site" higiénia mellett dönt, ami azt jelenti, hogy az ebben a tartományban létrehozott azonosítók feloldódnak, mintha közvetlenül a makrohívás helyére írták volna őket, és a makrohívás helyén található egyéb kódok hivatkozni tudnának őket is.
    ///
    ///
    /// Az `Span::def_site()`-hez hasonló későbbi szakaszok lehetővé teszik az "definition-site" higiénia használatát, ami azt jelenti, hogy az ezzel az időtartammal létrehozott azonosítók fel lesznek oldva a makródefiníció helyén, és a makrohívás helyén található más kódok nem lesznek képesek hivatkozni rájuk.
    ///
    /// A higiénia jelenlegi fontossága miatt ez a kivitelező a többi tokens-től eltérően megköveteli az `Span` megadását az építkezés során.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Ugyanaz, mint az `Ident::new`, de létrehoz egy nyers (`r#ident`) azonosítót.
    /// Az `string` argumentum a nyelv által engedélyezett érvényes azonosító (beleértve a kulcsszavakat, pl. `fn`).
    /// Az útvonalszegmensekben használható kulcsszavak (pl
    /// `self`, "super") nem támogatottak, és panic-t okoznak.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Visszaadja ennek az `Ident`-nek a terjedelmét, felölelve az [`to_string`](Self::to_string) által visszaadott teljes karakterláncot.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigurálja ennek az `Ident`-nek a hatósugarát, esetleg megváltoztatva annak higiéniai környezetét.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// Megjegyezzük, hogy a híd csak az `to_string` szolgáltatást nyújtja, ennek alapján valósítsa meg az `fmt::Display`-et (a kettő közötti szokásos viszony fordítottja).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Az azonosítót karaktersorozatként nyomtatja ki, amelyet veszteségmentesen vissza kell alakítani ugyanabba az azonosítóba.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Egy szó szerinti (`"hello"`) karakterlánc, (`b"hello"`) bájtos karakterlánc, (`'a'`) karakter, (`b'a'`) bájtos karakter, egész-vagy lebegőpontos szám utótaggal vagy nélkül ("1", `1u8`, `2.3`, `2.3f32`).
///
/// Az olyan logikai literálok, mint az `true` és az `false`, nem tartoznak ide, ők `Ident`-ék.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Új utótagú egész szám literált hoz létre a megadott értékkel.
        ///
        /// Ez a függvény olyan egész számot hoz létre, mint az `1u32`, ahol a megadott egész érték a token első része, és az integrál is a végén utótag.
        /// A negatív számokból létrehozott literálok nem biztos, hogy túlélik az oda-vissza meneteket az `TokenStream`-en vagy a karakterláncokon keresztül, és két tokens-re (`-` és pozitív literál) oszthatók fel.
        ///
        ///
        /// Az ezzel a módszerrel létrehozott literálok alapértelmezés szerint az `Span::call_site()` span-tal rendelkeznek, amelyet az alábbi `set_span` módszerrel lehet konfigurálni.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Új, utótag nélküli egész szám literált hoz létre a megadott értékkel.
        ///
        /// Ez a függvény olyan egész számot hoz létre, mint az `1`, ahol a megadott egész érték a token első része.
        /// Ezen a token-n nincs megadva utótag, vagyis az `Literal::i8_unsuffixed(1)`-hez hasonló invokációk egyenértékűek az `Literal::u32_unsuffixed(1)`-kel.
        /// A negatív számokból létrehozott literálok nem biztos, hogy túlélik az `TokenStream` vagy húrok közötti rriptippeket, és két tokens-re (`-` és pozitív literál) oszthatók fel.
        ///
        ///
        /// Az ezzel a módszerrel létrehozott literálok alapértelmezés szerint az `Span::call_site()` span-tal rendelkeznek, amelyet az alábbi `set_span` módszerrel lehet konfigurálni.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Új, nem rögzített lebegőpontos szó szerinti szót hoz létre.
    ///
    /// Ez a konstruktor hasonlít azokhoz, mint az `Literal::i8_unsuffixed`, ahol az úszó értéke közvetlenül a token-ba kerül, de utótagot nem használnak, ezért később a fordítóban `f64`-re lehet következtetni.
    ///
    /// A negatív számokból létrehozott literálok nem biztos, hogy túlélik az `TokenStream` vagy húrok közötti rriptippeket, és két tokens-re (`-` és pozitív literál) oszthatók fel.
    ///
    /// # Panics
    ///
    /// Ez a funkció megköveteli, hogy a megadott úszó véges legyen, például ha végtelen vagy NaN, akkor ez a függvény panic lesz.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Új utótagú lebegőpontos szó szerinti szót hoz létre.
    ///
    /// Ez a konstruktor létrehoz egy olyan literált, mint az `1.0f32`, ahol a megadott érték a token előző része, az `f32` pedig a token utótagja.
    /// Erre a token-re mindig `f32`-re következtetnek a fordítóban.
    /// A negatív számokból létrehozott literálok nem biztos, hogy túlélik az `TokenStream` vagy húrok közötti rriptippeket, és két tokens-re (`-` és pozitív literál) oszthatók fel.
    ///
    ///
    /// # Panics
    ///
    /// Ez a funkció megköveteli, hogy a megadott úszó véges legyen, például ha végtelen vagy NaN, akkor ez a függvény panic lesz.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Új, nem rögzített lebegőpontos szó szerinti szót hoz létre.
    ///
    /// Ez a konstruktor hasonlít azokhoz, mint az `Literal::i8_unsuffixed`, ahol az úszó értéke közvetlenül a token-ba kerül, de utótagot nem használnak, ezért később a fordítóban `f64`-re lehet következtetni.
    ///
    /// A negatív számokból létrehozott literálok nem biztos, hogy túlélik az `TokenStream` vagy húrok közötti rriptippeket, és két tokens-re (`-` és pozitív literál) oszthatók fel.
    ///
    /// # Panics
    ///
    /// Ez a funkció megköveteli, hogy a megadott úszó véges legyen, például ha végtelen vagy NaN, akkor ez a függvény panic lesz.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Új utótagú lebegőpontos szó szerinti szót hoz létre.
    ///
    /// Ez a konstruktor létrehoz egy olyan literált, mint az `1.0f64`, ahol a megadott érték a token előző része, az `f64` pedig a token utótagja.
    /// Erről a token-ről mindig `f64`-re következtetnek a fordítóban.
    /// A negatív számokból létrehozott literálok nem biztos, hogy túlélik az `TokenStream` vagy húrok közötti rriptippeket, és két tokens-re (`-` és pozitív literál) oszthatók fel.
    ///
    ///
    /// # Panics
    ///
    /// Ez a funkció megköveteli, hogy a megadott úszó véges legyen, például ha végtelen vagy NaN, akkor ez a függvény panic lesz.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Húr szó szerint.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Karakter szó szerinti.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Bájt karakterlánc szó szerinti.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Visszaadja ezt a szó szerinti szót.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigurálja az ehhez a literálhoz tartozó tartományt.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Visszaad egy `Span`-et, amely az `self.span()` részhalmaza, amely csak az `range` tartományban lévő forrásbájtokat tartalmazza.
    /// Visszaadja az `None` értéket, ha a leírt vágási tartomány az `self` határain kívül esik.
    ///
    // FIXME(SergioBenitez): ellenőrizze, hogy a bájt tartomány a forrás UTF-8 határán kezdődik és végződik.
    // különben valószínű, hogy a forrásszöveg kinyomtatásakor máshol is előfordul majd panic.
    // FIXME(SergioBenitez): a felhasználónak nincs módja tudni, hogy valójában mihez térképez az `self.span()`, ezért ez a módszer jelenleg csak vakon hívható meg.
    // Például az `to_string()` az 'c' karakterhez "'\u{63}'"-et ad vissza;a felhasználó semmilyen módon nem tudja megtudni, hogy a forrásszöveg 'c' vagy '\u{63}' volt-e.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) valami hasonló az `Option::cloned`-hez, de az `Bound<&T>`-hez.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// Megjegyezzük, hogy a híd csak az `to_string` szolgáltatást nyújtja, ennek alapján valósítsa meg az `fmt::Display`-et (a kettő közötti szokásos viszony fordítottja).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// A literált olyan karaktersorozatként nyomtatja ki, amelyet veszteségmentesen vissza kell alakítani ugyanabba a literálba (kivéve a lebegőpontos literálok esetleges kerekítését).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Nyomon követhető hozzáférés a környezeti változókhoz.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Szerezzen be egy környezeti változót, és adja hozzá a függőségi információk összeállításához.
    /// A fordítót végrehajtó Build rendszer tudni fogja, hogy a változóhoz a fordítás során kerültek hozzá, és képes lesz újra futtatni a buildet, amikor a változó értéke megváltozik.
    ///
    /// A függőségkövetés mellett ennek a függvénynek egyenértékűnek kell lennie a standard könyvtár `env::var` értékével, azzal a különbséggel, hogy az argumentumnak UTF-8-nek kell lennie.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}