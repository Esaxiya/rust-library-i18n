//! Windows SEH
//!
//! Windows-en (jelenleg csak MSVC-n) az alapértelmezett kivételkezelési mechanizmus a Strukturált kivételkezelés (SEH).
//! Ez egészen más, mint a törpe-alapú kivételkezelés (pl. Amit más unix platformok használnak) a fordító belső részeit tekintve, ezért az LLVM-nek nagy mennyiségű extra támogatást kell nyújtania az SEH számára.
//!
//! Dióhéjban az történik itt:
//!
//! 1. Az `panic` függvény az Windows szabványos `_CxxThrowException` függvényt hívja meg egy C++ -szerű kivétel kiváltására, ami elindítja a letekercselési folyamatot.
//! 2.
//! A fordító által létrehozott összes leszállópanel az `__CxxFrameHandler3` személyiségfüggvényt használja, a CRT egyik funkcióját, az Windows-ben lévő letekercselő kód pedig ezt a személyiségfüggvényt használja a verem összes tisztítási kódjának végrehajtására.
//!
//! 3. Az `invoke`-hez fordított összes fordító által generált hívásnak van egy leszállópadja, amely `cleanuppad` LLVM utasításként van beállítva, amely jelzi a tisztítási rutin kezdetét.
//! A személyiség (a CRT-ben meghatározott 2. lépésben) felelős a tisztítási rutinok futtatásáért.
//! 4. Végül az `try` belső (a fordító által generált) "catch" kód végrehajtásra kerül, és jelzi, hogy a vezérlésnek vissza kell térnie a Rust-re.
//! Ez egy `catchswitch` plusz egy `catchpad` utasítással történik LLVM IR kifejezéssel, végül egy `catchret` utasítással visszatér a normál vezérlés a programhoz.
//!
//! Néhány konkrét különbség a gcc alapú kivételkezeléssel szemben:
//!
//! * A Rust nem rendelkezik egyéni személyiségfunkciókkal, ehelyett *mindig*`__CxxFrameHandler3`.Ezenkívül semmilyen extra szűrést nem hajtanak végre, így végül elkapunk minden olyan C++ kivételt, amely történetesen úgy néz ki, mint amit dobunk.
//! Vegye figyelembe, hogy a kivétel dobása a Rust-be egyébként nem meghatározott viselkedés, ezért ennek rendben kell lennie.
//! * Van néhány adatunk, amelyeket tovább lehet továbbítani a kikapcsolódási határon, nevezetesen egy `Box<dyn Any + Send>`.Hasonlóan a törpe kivételekhez, ez a két mutató hasznos terhelésként tárolódik magában a kivételben.
//! Az MSVC-n azonban nincs szükség további kupac kiosztásra, mert a hívásverem megmarad, miközben a szűrőfunkciókat végrehajtják.
//! Ez azt jelenti, hogy a mutatókat közvetlenül az `_CxxThrowException`-nek továbbítják, amelyeket aztán a szűrőfunkcióban visszaállítanak, és az `try` belső veremkeretébe írják.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Ennek opciónak kell lennie, mert hivatkozással elkapjuk a kivételt, és annak rombolóját a C++ futásideje hajtja végre.
    // Amikor kivesszük a Dobozt a kivételből, akkor a kivételt érvényes állapotban kell hagynunk, hogy a destruktora a Doboz kettős ledobása nélkül futhasson.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Először egy csomó típusú definíció.Van itt néhány platformspecifikus furcsaság, és sok mindent csak szemlátomást másol az LLVM.Mindezek célja az alábbi `panic` funkció megvalósítása az `_CxxThrowException` hívásával.
//
// Ennek a függvénynek két argumentuma van.Az első egy mutató az általunk továbbított adatokra, amely ebben az esetben a trait objektumunk.Nagyon könnyű megtalálni!A következő azonban bonyolultabb.
// Ez egy mutató egy `_ThrowInfo` szerkezetre, és általában csak a dobott kivétel leírására szolgál.
//
// Jelenleg az [1] típus meghatározása kissé szőrös, és a legfőbb furcsaság (és eltérés az online cikktől) az, hogy a 32 biteseken a mutatók mutatók, a 64 biteseken azonban a mutatók 32 bites eltolásokként vannak kifejezve. `__ImageBase` szimbólum.
//
// Ennek kifejezésére az alábbi modulokban található `ptr_t` és `ptr!` makrókat használják.
//
// A típusdefiníciók útvesztője szorosan követi azt is, amit az LLVM kibocsát az ilyen műveletekhez.Például, ha ezt a C++ kódot fordítja le az MSVC-n, és kiadja az LLVM IR-t:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      érvénytelen foo() { rust_panic a = {0, 1};
//          dob egy;}
//
// Lényegében ezt próbáljuk utánozni.Az alábbi állandó értékek többségét csak átmásoltuk az LLVM-ből,
//
// Mindenesetre ezek a struktúrák mind hasonló módon vannak felépítve, és ez csak némileg bőbeszédű számunkra.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Vegye figyelembe, hogy itt szándékosan figyelmen kívül hagyjuk a névelhárítási szabályokat: nem akarjuk, hogy a C++ képes legyen elkapni a Rust panics-t, ha egyszerűen deklarál egy `struct rust_panic`-et.
//
//
// A módosítás során győződjön meg arról, hogy a típusnév karakterlánc pontosan megegyezik az `compiler/rustc_codegen_llvm/src/intrinsic.rs`-ben használtal.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // A vezető `\x01` bájt itt valójában mágikus jel az LLVM számára, hogy *ne* alkalmazzon más rendetlenséget, mint például az `_` karakter előtagja.
    //
    //
    // Ez a szimbólum a C++ `std::type_info` által használt képe.
    // Az `std::type_info` típusú objektumoknak, a típusleíróknak mutatójuk van erre a táblára.
    // A típusleírókra a fent definiált C++ EH struktúrák hivatkoznak, amelyeket az alábbiakban építünk fel.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Ezt a típusleírót csak kivétel kivetésekor használják.
// A fogási részt a try intrinsic kezeli, amely saját TypeDescriptort generál.
//
// Ez rendben van, mivel az MSVC futásideje a típusnév karakterlánc-összehasonlítását használja a TypeDescriptorok megfeleltetésére, nem pedig a mutató egyenlőségére.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destructor, ha a C++ kód úgy dönt, hogy elfogja a kivételt, és elveti anélkül, hogy tovább terjesztené.
// A try intrinsic elkapási része a kivétel objektum első szavát 0-ra állítja, így a destruktor kihagyja.
//
// Ne feledje, hogy az x86 Windows az "thiscall" hívási konvenciót használja a C++ tagfüggvényekhez az alapértelmezett "C" hívási megállapodás helyett.
//
// A kivétel_másolás funkció itt kissé különleges: az MSVC futásideje meghívja egy try/catch blokk alatt, és az itt létrehozott panic-t a kivételes másolat eredményeként fogjuk használni.
//
// Ezt használja a C++ futásideje a kivételek rögzítésének támogatására az std::exception_ptr segítségével, amelyet a Box miatt nem tudunk támogatni<dyn Any>nem klónozható.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // A_CxxThrowException teljes egészében ezen a veremkereten hajt végre, így nincs szükség különben az `data` átvitelére a kupacba.
    // Csak továbbítunk egy veremmutatót ehhez a funkcióhoz.
    //
    // A ManuallyDrop-ra itt van szükség, mivel nem akarjuk, hogy a Kivétel eldobódjon a kikapcsoláskor.
    // Ehelyett a kivétel_tisztítás által dobja le, amelyre a C++ futásideje hivatkozik.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Ez ... meglepőnek tűnhet, és igazolhatóan.A 32 bites MSVC-n ezek a struktúrák közötti mutatók pont ilyenek, mutatók.
    // A 64 bites MSVC-n azonban a struktúrák közötti mutatók inkább az `__ImageBase` 32 bites eltolásaként vannak kifejezve.
    //
    // Következésképpen a 32 bites MSVC-n ezeket a mutatókat deklarálhatjuk a fenti "statikus"-okban.
    // 64 bites MSVC esetén a statikus mutatók kivonását kellene kifejeznünk, amit a Rust jelenleg nem engedélyez, így ezt valójában nem tehetjük meg.
    //
    // A következő legjobb dolog az, ha futás közben tölti ki ezeket a struktúrákat (a pánik már amúgy is az "slow path").
    // Tehát itt újraértelmezzük ezeket a mutató mezőket 32 bites egész számokként, majd eltároljuk benne a releváns értéket (atomi szempontból, mivel egyidejűleg előfordulhat panics).
    //
    // Technikailag a futás valószínűleg nem atomikusan fogja olvasni ezeket a mezőket, de elméletileg soha nem olvassák el a *rossz* értéket, ezért nem lehet túl rossz ...
    //
    // Mindenesetre alapvetően ilyesmit kell tennünk, amíg több műveletet nem tudunk kifejezni a statikában (és lehet, hogy soha nem leszünk képesek).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // A NULL hasznos teher itt azt jelenti, hogy a __rust_try (...) fogásából érkeztünk ide.
    // Ez akkor történik, ha egy nem Rust külföldi kivételt elkapunk.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Erre a fordítónak léteznie kell (pl. Ez egy lang elem), de a fordító soha nem hívja meg, mert a __C_specific_handler vagy a_except_handler3 a mindig használt személyiségfüggvény.
//
// Ezért ez csak egy elvetélt csonk.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}