//! Lazító panics Miri számára.
use alloc::boxed::Box;
use core::any::Any;

// Az a hasznos teher típusa, amelyet a Miri motor továbbterjeszt számunkra.
// Mutató méretűnek kell lennie.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// A Miri által biztosított külső funkció a kikapcsolás megkezdéséhez.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Az `miri_start_panic`-nek átadott hasznos teher pontosan az az érv lesz, amelyet az alábbi `cleanup`-ben kapunk.
    // Tehát egyszer csak bepakoljuk, hogy valami mutató méretű legyen.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Helyezze vissza az alapul szolgáló `Box`-et.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}