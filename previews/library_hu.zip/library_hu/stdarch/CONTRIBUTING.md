# Hozzájárulás az stdarchához

Az `stdarch` crate több mint hajlandó elfogadni a hozzájárulásokat!Először valószínűleg meg szeretné nézni az adattárat, és győződjön meg arról, hogy a tesztek megfelelnek-e Önnek:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Ahol `<your-target-arch>` a célhármas, az `rustup` alkalmazásával, pl. `x86_x64-unknown-linux-gnu` (megelőző `nightly-` vagy hasonló nélkül).
Ne felejtsük el, hogy ehhez a tárhoz a Rust éjszakai csatornája szükséges!
A fenti tesztek valójában megkövetelik, hogy az éjszakai rust legyen az alapértelmezett rendszer, annak beállításához, hogy használja az `rustup default nightly`-et (és az `rustup default stable`-et a visszatéréshez).

Ha a fenti lépések bármelyike nem működik, [please let us know][new]!

Ezután az [find an issue][issues] segítségével segíthet, kiválasztottunk néhányat az [`help wanted`][help] és [`impl-period`][impl] címkékkel, amelyek különösen segítséget tudnak igénybe venni. 
Az [#40][vendor] érdekelheti a legjobban, az összes szállítói belső megvalósítása az x86-en.Ez a kérdés jó útmutatásokat tartalmaz arról, hogy hol is kezdjünk!

Ha általános kérdései vannak, nyugodtan vegye fel a kapcsolatot az [join us on gitter][gitter]-szel, és kérdezzen körül!Nyugodtan kérdezzen a@BurntSushi vagy az@alexcrichton közül.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Hogyan írjunk példákat az stdarch intrinsicsre

Néhány funkciót engedélyezni kell, hogy az adott belső működés megfelelően működjön, és a példát az `cargo test --doc` csak akkor futtathatja, ha a szolgáltatást a CPU támogatja.

Ennek eredményeként az `rustdoc` által létrehozott alapértelmezett `fn main` nem fog működni (a legtöbb esetben).
Fontolja meg az alábbiak használatát útmutatóként annak biztosítására, hogy példája a várt módon működjön.

```rust
/// # // Szükségünk van a cfg_target_feature elemre, hogy a példa csak az legyen
/// # // az `cargo test --doc` futtatja, amikor a CPU támogatja ezt a funkciót
/// # #![feature(cfg_target_feature)]
/// # // Szükségünk van a target_feature-ra, hogy a belső működés működjön
/// # #![feature(target_feature)]
/// #
/// # // A rustdoc alapértelmezés szerint az `extern crate stdarch`-et használja, de szükségünk van rá
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // Az igazi fő funkció
/// # fn main() {
/// #     // Csak akkor futtassa ezt, ha az `<target feature>` támogatott
/// #     ha cfg_feature_enabled! ("<target feature>"){
/// #         // Hozzon létre egy `worker` függvényt, amely csak akkor futtatható, ha a cél szolgáltatás
/// #         // támogatott, és győződjön meg arról, hogy az `target_feature` engedélyezve van a munkavállaló számára
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         nem biztonságos fn worker() {
/// // Írja ide a példáját.A funkcióspecifikus tulajdonságok itt működnek!Megvadulni!
///
/// #         }
///
/// #         nem biztonságos { worker(); }
/// #     }
/// # }
```

Ha a fenti szintaxis némelyike nem tűnik ismerősnek, az [Rust Book] [Documentation as tests] szakasza elég jól leírja az `rustdoc` szintaxist.
Mint mindig, nyugodtan vegye fel a kapcsolatot az [join us on gitter][gitter]-szel, és kérdezzen meg minket, ha eltalált valamilyen csapdát, és köszönjük, hogy hozzájárult az `stdarch` dokumentációjának fejlesztéséhez!

# Alternatív tesztelési utasítások

Általában az `ci/run.sh` használatát javasoljuk a tesztek futtatásához.
Ez azonban nem biztos, hogy működik az Ön számára, pl. Ha Windows rendszert futtat.

Ebben az esetben visszatérhet az `cargo +nightly test` és az `cargo +nightly test --release -p core_arch` futtatásához a kódgenerálás teszteléséhez.
Ne feledje, hogy ezekhez szükség van az éjszakai szerszámlánc telepítésére, és az `rustc`-nek tudnia kell a cél hármasáról és annak CPU-járól.
Különösen az `TARGET` környezeti változót kell beállítania, mint az `ci/run.sh` esetén.
Ezenkívül be kell állítania az `RUSTCFLAGS`-et (szükség van az `C`-re), hogy jelezze a céltulajdonságokat, pl `RUSTCFLAGS="-C -target-features=+avx2"`.
Beállíthatja az `-C -target-cpu=native`-et is, ha az "just" a jelenlegi CPU-jához képest fejleszt.

Figyelmeztetni kell, hogy ezen alternatív utasítások használatakor az [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], pl
az utasításgeneráló tesztek meghiúsulhatnak, mert a szétszerelő másképp nevezte el őket, pl
az `aesenc` utasítások helyett `vaesenc`-et generálhat annak ellenére, hogy ugyanúgy viselkednek.
Ezen utasítások is kevesebb tesztet hajtanak végre, mint általában, ezért ne csodálkozzon azon, hogy amikor végül kérelmez, kérhet néhány hibát az itt nem szereplő teszteknél.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






