`core::arch` - A Rust központi könyvtár-architektúra-specifikus belső elemei
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Az `core::arch` modul architektúrától függő belső tulajdonságokat (pl. SIMD) valósít meg.

# Usage 

`core::arch` az `libcore` részeként érhető el, és az `libstd` exportálja újra.Inkább használja az `core::arch` vagy az `std::arch`, mint ezen a crate keresztül.
Az instabil funkciók gyakran elérhetők az éjszakai Rust-ben az `feature(stdsimd)`-en keresztül.

Az `core::arch` ezen a crate keresztül történő használatához éjszakai Rust szükséges, és gyakran megszakadhat (és nem is).Az egyetlen eset, amikor meg kell fontolnia a crate használatát, a következők:

* ha magának újra kell fordítania az `core::arch`-et, pl. olyan engedélyezett cél-funkciókkal, amelyek nem engedélyezettek az `libcore`/`libstd` számára.
Note: ha újra kell fordítania egy nem szabványos célhoz, akkor ennek a crate helyett inkább az `xargo` és az `libcore`/`libstd` fordítását használja.
  
* néhány olyan funkció használata, amelyek még az instabil Rust funkciók mögött sem érhetők el.Igyekszünk ezeket minimálisra csökkenteni.
Ha ezeknek a funkcióknak a használatára van szüksége, kérjük, nyisson meg egy problémát, hogy az éjszakai Rust-ben leleplezhessük őket, és onnan használhatja őket.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` elsősorban az MIT licenc és a Apache licenc (2.0 verzió) feltételei szerint terjesztik, a részeket különféle BSD-szerű licencek fedik le.

A részletekért lásd: LICENC-APACHE és LICENC-MIT.

# Contribution

Hacsak kifejezetten másként nem állítja, az Ön által az `core_arch`-be való felvételre szándékosan benyújtott hozzájárulás-a Apache-2.0 licencben meghatározottak szerint-kettős licencű, a fentiek szerint, további feltételek és feltételek nélkül.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












