use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Az `#[assert_instr]` kommentárjaink elmondására használták, hogy az összes simd belső elem elérhető a kódegen tesztelésére, mivel egyesek egy extra `-Ctarget-feature=+unimplemented-simd128` mögött vannak, amelynek jelenleg nincs megfelelője az `#[target_feature]`-ben.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}