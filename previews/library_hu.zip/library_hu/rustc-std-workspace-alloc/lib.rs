#![feature(no_core)]
#![no_core]

// Lásd a rustc-std-munkaterület-magot, hogy miért van szükség erre a crate-re.

// Nevezze át a crate-t, hogy elkerülje az ütközést a liballoc allokációs moduljával.
extern crate alloc as foo;

pub use foo::*;