#![feature(no_core)]
#![no_core]

// Onani rustc-std-malo ogwirira ntchito chifukwa chake crate ikufunika.

// Sinthani dzina crate kuti mupewe kutsutsana ndi gawo logawika mu liballoc.
extern crate alloc as foo;

pub use foo::*;