//! Zida zogawana zosinthika.
//!
//! Rust kukumbukira chitetezo kutengera lamuloli: Popeza chinthu `T`, ndizotheka kukhala ndi izi:
//!
//! - Kukhala ndi maumboni angapo osasinthika (`&T`) pachinthucho (chomwe chimadziwikanso kuti **aliasing**).
//! - Kukhala ndi gawo limodzi losinthika (`&&mut T`) ku chinthucho (chotchedwanso **mutability**).
//!
//! Izi zimalimbikitsidwa ndi wopanga Rust.Komabe, pamakhala zochitika zina pomwe lamuloli silisintha mokwanira.Nthawi zina pamafunika kukhala ndi maumboni angapo achinthu ndikusintha.
//!
//! Zida zogawana zomwe zilipo zololeza kusinthika mosasunthika, ngakhale pali kutayikira.Zonse [`Cell<T>`] ndi [`RefCell<T>`] zimalola kuchita izi m'njira imodzi.
//! Komabe, ngakhale `Cell<T>` kapena `RefCell<T>` sizomwe zili zotetezeka (sizigwiritsa ntchito [`Sync`]).
//! Ngati mukufunikira kusinthasintha ndikusintha pakati pa ulusi zingapo ndizotheka kugwiritsa ntchito mitundu ya [`Mutex<T>`], [`RwLock<T>`] kapena [`atomic`].
//!
//! Makhalidwe amtundu wa `Cell<T>` ndi `RefCell<T>` atha kusinthidwa kudzera pamafotokozedwe omwe agawidwa (mwachitsanzo
//! mtundu wamba wa `&T`), pomwe mitundu yambiri ya Rust imatha kusinthidwa kudzera mumaumboni apadera (`&&T T).
//! Tikunena kuti `Cell<T>` ndi `RefCell<T>` zimapereka 'kusintha kwa mkati', mosiyana ndi mitundu ya Rust yomwe imawonetsa 'kusintha kwa cholowa'.
//!
//! Mitundu yama cell imabwera m'mitundu iwiri: `Cell<T>` ndi `RefCell<T>`.`Cell<T>` imagwiritsa ntchito kusintha kwamkati mwa kusunthira mitengo mkati ndi kunja kwa `Cell<T>`.
//! Kuti mugwiritse ntchito mafotokozedwe m'malo mwa mfundo, munthu ayenera kugwiritsa ntchito mtundu wa `RefCell<T>`, kuti apeze cholembera asanasinthe.`Cell<T>` imapereka njira zobwezera ndikusintha mtengo wamkati wapano:
//!
//!  - Kwa mitundu yomwe imagwiritsa ntchito [`Copy`], njira ya [`get`](Cell::get) imapezanso mtengo wamkati wapano.
//!  - Kwa mitundu yomwe imagwiritsa ntchito [`Default`], njira ya [`take`](Cell::take) imalowetsa mtengo wamkati wapano ndi [`Default::default()`] ndikubwezeretsanso mtengo wake.
//!  - Mwa mitundu yonse, njira ya [`replace`](Cell::replace) imalowetsa mtengo wamkati wapano ndikubwezera mtengo wake ndipo njira ya [`into_inner`](Cell::into_inner) imagwiritsa ntchito `Cell<T>` ndikubwezera mtengo wamkati.
//!  Kuphatikiza apo, njira ya [`set`](Cell::set) imalowetsa mtengo wamkati, ndikutsitsa mtengo wake.
//!
//! `RefCell<T>` imagwiritsa ntchito nthawi yamoyo wa Rust kukhazikitsa 'ngongole zazikulu', njira yomwe munthu angafunire kufikira kwakanthawi, kosasunthika, kosinthika kwamkati.
//! Kubwereka kwa `RefCell<T>`` s amatsatiridwa 'pa nthawi yothamanga', mosiyana ndi mitundu ya Rust yomwe imatsatiridwa kwathunthu, panthawi yolemba.
//! Chifukwa chakuti `RefCell<T>` imabwereka ndiyotheka ndiyotheka kuyesa kubwereketsa mtengo womwe wabwereka kale;izi zikachitika zimabweretsa ulusi panic.
//!
//! # Nthawi yosankha kusintha kwamkati
//!
//! Kusintha kofala kwambiri komwe munthu amabadwa nako, komwe munthu ayenera kukhala nako mwayi wosintha phindu, ndi chimodzi mwazinthu zofunikira kwambiri zomwe zimathandizira Rust kulingalira mwamphamvu za pointer aliasing, polepheretsa kuwonongeka kwa nsikidzi.
//! Chifukwa cha ichi, kusintha kwa chibadwa kumakonda, ndipo kusinthika kwamkati ndi njira yomaliza.
//! Popeza mitundu yamaselo imathandizira kusintha komwe sikungaloledwe, pamakhala nthawi zina pomwe kusintha kwa mkati kungakhale koyenera, kapena ngakhale * kuyenera kugwiritsidwa ntchito, mwachitsanzo
//!
//! * Kuyambitsa kusintha kwa 'inside' kwa chinthu chosasinthika
//! * Kukhazikitsa kwa njira zosasinthika.
//! * Kusintha kukhazikitsa kwa [`Clone`].
//!
//! ## Kuyambitsa kusintha kwa 'inside' kwa chinthu chosasinthika
//!
//! Ambiri amagawana mitundu yama pointer anzeru, kuphatikiza [`Rc<T>`] ndi [`Arc<T>`], amapereka zotengera zomwe zitha kupangika ndikugawana pakati pa magulu angapo.
//! Chifukwa zomwe zili nazo zitha kuchulukitsidwa, zitha kubwereka ndi `&`, osati `&mut`.
//! Popanda maselo sizingatheke kusinthitsa deta mkati mwazizindikiro izi.
//!
//! Ndizofala kwambiri kuyika `RefCell<T>` mkati mwa mitundu ya pointer yogawana nawo kuti mubwezeretsenso kusintha:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Pangani chipika chatsopano kuti muchepetse kuchuluka kwa zomwe mungabweretse
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Dziwani kuti ngati sitinalole kuti kubwereka kwa cache kusadabwerenso ndiye kuti kubwereketsa komweku kumatha kuyambitsa ulusi wamphamvu panic.
//!     //
//!     // Ili ndiye vuto lalikulu kugwiritsa ntchito `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Dziwani kuti chitsanzo ichi chimagwiritsa ntchito `Rc<T>` osati `Arc<T>`.RefCell<T>`s ndi za ulusi umodzi.Ganizirani kugwiritsa ntchito [`RwLock<T>`] kapena [`Mutex<T>`] ngati mukufuna kugawana magawano munyengo zingapo.
//!
//! ## Kukhazikitsa kwa njira zosasinthika
//!
//! Nthawi zina kungakhale kofunika kuti usawonetse mu API kuti pali kusintha komwe kumachitika "under the hood".
//! Izi zitha kukhala chifukwa choti ntchitoyi siyimasinthika, koma mwachitsanzo, kusungitsa zomwe zimapangitsa kuti zisinthe;kapena chifukwa muyenera kugwiritsa ntchito kusintha kuti mugwiritse ntchito njira ya trait yomwe poyamba idatengera `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Kuwerengera kwamtengo wapatali kumapita apa
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Kusintha kukhazikitsa kwa `Clone`
//!
//! Imeneyi ndi nkhani yapadera, koma yofala, yam'mbuyomu: kubisalira kusintha kwa magwiridwe omwe akuwoneka kuti sangasinthe.
//! Njira ya [`clone`](Clone::clone) ikuyembekezeka kusintha mtengo woyambira, ndipo akuti itenga `&self`, osati `&mut self`.
//! Chifukwa chake, kusintha kulikonse komwe kumachitika mu njira ya `clone` kuyenera kugwiritsa ntchito mitundu yama cell.
//! Mwachitsanzo, [`Rc<T>`] imakhala ndi ziwerengero zake mkati mwa `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Malo osinthika okumbukira.
///
/// # Examples
///
/// Pachitsanzo ichi, mutha kuwona kuti `Cell<T>` imathandizira kusintha mkati mwa chosasintha struct.
/// Mwanjira ina, imathandizira "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ZALAKWITSA: `my_struct` sichingasinthe
/// // my_struct.regular_field =yatsopano_mtengo;
///
/// // NTCHITO: ngakhale `my_struct` singasinthe, `special_field` ndi `Cell`,
/// // zomwe zimatha kusinthidwa nthawi zonse
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Onani [module-level documentation](self) kuti mumve zambiri.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Amapanga `Cell<T>`, ndi mtengo wa `Default` wa T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Pangani `Cell` yatsopano yomwe ili ndi mtengo wopatsidwa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Ikani mtengo womwe uli nawo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Amasintha malingaliro a Maselo awiri.
    /// Kusiyana kwa `std::mem::swap` ndikuti ntchitoyi sikutanthauza kutchulidwa kwa `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // CHITETEZO: Izi zitha kukhala zowopsa ngati zingayitanidwe kuchokera ku ulusi wosiyana, koma `Cell`
        // ndi `!Sync` kotero izi sizingachitike.
        // Izi sizingasokoneze zolozera zilizonse popeza `Cell` ikuwonetsetsa kuti palibe chomwe chingaloze mu ma Cell awa.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Ikusintha mtengo wake ndi `val`, ndikubwezera mtengo wake wakale.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // CHITETEZO: Izi zitha kuyambitsa mitundu ya data ngati itayitanidwa kuchokera ulusi wina,
        // koma `Cell` ndi `!Sync` kotero izi sizingachitike.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Chotsegula mtengo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Imabwezeretsa mtundu wamtengo womwe ulipo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // CHITETEZO: Izi zitha kuyambitsa mitundu ya data ngati itayitanidwa kuchokera ulusi wina,
        // koma `Cell` ndi `!Sync` kotero izi sizingachitike.
        unsafe { *self.value.get() }
    }

    /// Imasinthira mtengo womwe ulipo pogwiritsa ntchito ntchito ndikubwezeretsanso mtengo watsopano.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Kubwezeretsa pointer yaiwisi kuzidziwitso zomwe zili mchipindachi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Imabwezeretsa kutanthauzira kosinthika pamtundu wachinsinsi.
    ///
    /// Kuyitanaku kumabwereka `Cell` mosasinthasintha (panthawi yophatikiza) zomwe zimatsimikizira kuti tili ndi zomwe tikutchulazo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Kubwezeretsa `&Cell<T>` kuchokera ku `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // CHITETEZO: `&mut` imatsimikizira kufikira kwina.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Zimatenga mtengo wa selo, ndikusiya `Default::default()` m'malo mwake.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Kubwezeretsa `&[Cell<T>]` kuchokera ku `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // CHITETEZO: `Cell<T>` ili ndi mawonekedwe ofanana ndi `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Malo osinthika osinthika omwe ali ndi malamulo owunika obwereketsa
///
/// Onani [module-level documentation](self) kuti mumve zambiri.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Cholakwika chomwe chidabwezedwa ndi [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Cholakwika chomwe chidabwezedwa ndi [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Makhalidwe abwino amaimira kuchuluka kwa `Ref` yogwira.Makhalidwe oyipa amayimira kuchuluka kwa `RefMut` yogwira.
// Ma `RefMut` angapo amatha kugwira ntchito panthawi imodzi ngati atchula zigawo zosiyanasiyananso za `RefCell` (mwachitsanzo, magawo osiyanasiyana a kagawo).
//
// `Ref` ndipo `RefMut` onse ndi mawu awiri kukula kwake, motero sipadzakhalanso zokwanira `Ref`s kapena`RefMut`s zomwe zikupezeka kuti zikusefukira theka la `usize`.
// Chifukwa chake, `BorrowFlag` mwina siyikusefukira kapena kusefukira.
// Komabe, ichi sichitsimikizo, popeza pulogalamu yamatenda imatha kupanga mobwerezabwereza kenako mem::forget `Ref`s kapena`RefMut`s.
// Chifukwa chake, ma code onse ayenera kuyang'anitsitsa kuti akusefukira ndi kusefukira kuti apewe chitetezo, kapena azichita bwino pakachitika kusefukira kapena kusefukira (mwachitsanzo, onani BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Pangani `RefCell` yatsopano yomwe ili ndi `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Idya `RefCell`, ndikubwezera mtengo wokutidwa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Popeza ntchitoyi imatenga `self` (`RefCell`) pamtengo, wophatikizira amatsimikizira kuti sikubwerekedwa pano.
        //
        self.value.into_inner()
    }

    /// Ikusintha mtengo wokutidwa ndi yatsopano, ndikubweza mtengo wakale, osachotsapo chimodzi.
    ///
    ///
    /// Ntchitoyi imagwirizana ndi [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics ngati mtengo wake wabwerekedwa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Ikusintha mtengo wokutidwa ndi yatsopano yolembedwa kuchokera ku `f`, ndikubwezeretsanso mtengo wakale, osachotsapo chimodzi.
    ///
    ///
    /// # Panics
    ///
    /// Panics ngati mtengo wake wabwerekedwa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Sinthani mtengo wokutidwa wa `self` ndi wokutidwa wa `other`, osachotsapo umodzi.
    ///
    ///
    /// Ntchitoyi imagwirizana ndi [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics ngati mtengo mu `RefCell` wabwereka pakadali pano.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Amabwereka mtengo wokutidwawo.
    ///
    /// Ngongole zimatenga mpaka `Ref` yomwe yabwerera itatha.
    /// Ngongole zingapo zosasinthika zitha kutengedwa nthawi yomweyo.
    ///
    /// # Panics
    ///
    /// Panics ngati mtengowo tsopano wabwereka.
    /// Pazosiyana zopanda mantha, gwiritsani ntchito [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Chitsanzo cha panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Amabwereka mosavutikira mtengo wokutidwawo, ndikubwezera cholakwika ngati mtengowo wabwerekedwa.
    ///
    ///
    /// Ngongole zimatenga mpaka `Ref` yomwe yabwerera itatha.
    /// Ngongole zingapo zosasinthika zitha kutengedwa nthawi yomweyo.
    ///
    /// Uku ndi kusiyanasiyana kwa [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // CHITETEZO: `BorrowRef` imawonetsetsa kuti pali mwayi wosasintha
            // ku mtengo wobwerekedwa.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Mofanana imabwereka mtengo wokutidwa.
    ///
    /// Ngongole zimatenga mpaka `RefMut` yomwe yabwerera kapena `RefMut`s yonse yochokera pamenepo.
    ///
    /// Mtengo sungabwereke uku kubwereka uku ukugwira ntchito.
    ///
    /// # Panics
    ///
    /// Panics ngati mtengo wake wabwerekedwa.
    /// Pazosiyana zopanda mantha, gwiritsani ntchito [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Chitsanzo cha panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Pamodzi imabwereka mtengo wokutidwawo, ndikubwezera cholakwika ngati mtengowo wabwerekedwa.
    ///
    ///
    /// Ngongole zimatenga mpaka `RefMut` yomwe yabwerera kapena `RefMut`s yonse yochokera pamenepo.
    /// Mtengo sungabwereke uku kubwereka uku ukugwira ntchito.
    ///
    /// Uku ndi kusiyanasiyana kwa [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // CHITETEZO: `BorrowRef` imatsimikizira mwayi wapadera.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Kubwezeretsa pointer yaiwisi kuzidziwitso zomwe zili mchipindachi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Imabwezeretsa kutanthauzira kosinthika pamtundu wachinsinsi.
    ///
    /// Kuyitanaku kumabwereka `RefCell` mosasinthasintha (panthawi yophatikiza) kotero palibe chifukwa chofufuzira mwamphamvu.
    ///
    /// Komabe samalani: njirayi ikuyembekeza kuti `self` itha kusintha, zomwe sizikhala choncho mukamagwiritsa ntchito `RefCell`.
    ///
    /// Onani njira ya [`borrow_mut`] m'malo mwake ngati `self` singasinthe.
    ///
    /// Komanso, chonde dziwani kuti njirayi ndi ya zochitika zapadera zokha ndipo nthawi zambiri sizomwe mukufuna.
    /// Ngati mukukayika, gwiritsani ntchito [`borrow_mut`] m'malo mwake.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Sinthani zotsatira za alonda omwe adatayirapo ngongole ya `RefCell`.
    ///
    /// Kuyimbaku ndikofanana ndi [`get_mut`] koma kodziwika kwambiri.
    /// Imabwereka `RefCell` mosasinthasintha kuti iwonetsetse kuti palibe ngongole zomwe zilipo kenako ndikukhazikitsanso momwe maboma amagwirira ntchito limodzi.
    /// Izi ndizofunikira ngati `Ref` kapena `RefMut` yobwereka idatulutsidwa.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Amabwereka mosavutikira mtengo wokutidwawo, ndikubwezera cholakwika ngati mtengowo wabwerekedwa.
    ///
    /// # Safety
    ///
    /// Mosiyana ndi `RefCell::borrow`, njirayi ndiyotetezeka chifukwa siyibweza `Ref`, motero imasiya mbendera yobwereka isakhudzidwe.
    /// Kubwereketsa `RefCell` chimodzimodzi pomwe buku lomwe limabwezeredwa ndi njira yamoyo ndilosadziwika.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // CHITETEZO: Tikuwona kuti palibe amene akulemba mwachangu tsopano, koma ndizo
            // udindo wa woyimbirayo kuti awonetsetse kuti palibe amene alemba mpaka zomwe wabwezera sakugwiritsanso ntchito.
            // Komanso, `self.value.get()` imafotokoza za mtengo wa `self` motero umatsimikizika kuti ndiwothandiza pa nthawi yonse ya `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Zimatenga mtengo wokutidwa, ndikusiya `Default::default()` m'malo mwake.
    ///
    /// # Panics
    ///
    /// Panics ngati mtengo wake wabwerekedwa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics ngati mtengowo tsopano wabwereka.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Amapanga `RefCell<T>`, ndi mtengo wa `Default` wa T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics ngati mtengo mu `RefCell` wabwereka pakadali pano.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics ngati mtengo mu `RefCell` wabwereka pakadali pano.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics ngati mtengo mu `RefCell` wabwereka pakadali pano.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ngati mtengo mu `RefCell` wabwereka pakadali pano.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ngati mtengo mu `RefCell` wabwereka pakadali pano.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ngati mtengo mu `RefCell` wabwereka pakadali pano.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics ngati mtengo mu `RefCell` wabwereka pakadali pano.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Kuchulukitsa kubwereketsa kumatha kubweretsa kufunika kosakhala kuwerengera (<=0) munthawi izi:
            // 1. Zinali <0, kutanthauza kuti pali zokopa zolembedwa, chifukwa chake sitingalole kuwerengedwa chifukwa cha malamulo a Rust
            // 2.
            // Anali isize::MAX (kuchuluka kwa kuchuluka kwa owerenga kubwereka) ndipo adasefukira mu isize::MIN (kuchuluka kwakubwereka kolemba) kotero sitingalole kuti kuwerenga kwina kungobwereka chifukwa isize singaimire obwereka ambiri (izi zitha kuchitika ngati inu mem::forget kuposa kuchuluka kwakanthawi kochepa kwa `Ref, zomwe sizabwino)
            //
            //
            //
            //
            None
        } else {
            // Kuchulukitsa kubwereketsa kumatha kubweretsa kuwerenga (> 0) munthawi izi:
            // 1. Unali=0, kutanthauza kuti sunabwereke, ndipo tikutenga owerenga oyamba
            // 2. Zinali> 0 ndi <isize::MAX, mwachitsanzo
            // adawerengedwa ngongole, ndipo isize ndi yayikulu mokwanira kuyimira kuti wina awerengenso kubwereka
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Popeza Ref iyi ilipo, tikudziwa kuti mbendera yokongola ndi yobwereka yowerengera.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Pewani kontrakitala yobwereka kuti isafikire pakulemba.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Kukutira cholembedwa chobwerekedwa pamtengo mu bokosi la `RefCell`.
/// Mtundu wokutira wamtengo wosasinthika kuchokera ku `RefCell<T>`.
///
/// Onani [module-level documentation](self) kuti mumve zambiri.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Amakopera `Ref`.
    ///
    /// `RefCell` idabwereka kale, kotero izi sizingalephereke.
    ///
    /// Izi ndizogwirizana zomwe zimayenera kugwiritsidwa ntchito ngati `Ref::clone(...)`.
    /// Kukhazikitsa `Clone` kapena njira ingasokoneze kugwiritsidwa ntchito kwa `r.borrow().clone()` kuti ifotokozere zomwe zili mu `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Amapanga `Ref` yatsopano kukhala gawo la zomwe zidabwereka.
    ///
    /// `RefCell` idabwereka kale, kotero izi sizingalephereke.
    ///
    /// Izi ndizogwirizana zomwe zimayenera kugwiritsidwa ntchito ngati `Ref::map(...)`.
    /// Njira ingasokoneze njira zofananira ndi zomwe zili mu `RefCell` yogwiritsidwa ntchito kudzera pa `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Amapanga `Ref` yatsopano posankha zinthu zomwe abwereke.
    /// Mulonda woyambayo amabwezedwa ngati `Err(..)` ngati kutseka kubwezera `None`.
    ///
    /// `RefCell` idabwereka kale, kotero izi sizingalephereke.
    ///
    /// Izi ndizogwirizana zomwe zimayenera kugwiritsidwa ntchito ngati `Ref::filter_map(...)`.
    /// Njira ingasokoneze njira zofananira ndi zomwe zili mu `RefCell` yogwiritsidwa ntchito kudzera pa `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Kugawa `Ref` kukhala ma `Ref angapo pamagawo osiyanasiyana azidziwitso zomwe zidabwereka.
    ///
    /// `RefCell` idabwereka kale, kotero izi sizingalephereke.
    ///
    /// Izi ndizogwirizana zomwe zimayenera kugwiritsidwa ntchito ngati `Ref::map_split(...)`.
    /// Njira ingasokoneze njira zofananira ndi zomwe zili mu `RefCell` yogwiritsidwa ntchito kudzera pa `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Sinthani kutanthauzira kuzomwe zimayambira.
    ///
    /// Zomwe zimayambira `RefCell` sizingabwerekedwe mosinthasintha ndipo ziziwoneka kuti zasungidwa kale.
    ///
    /// Si lingaliro labwino kudontha kuposa zowerengetsa zingapo.
    /// `RefCell` itha kubwerekanso mosadukiza ngati kungochoka pang'ono kungachitike kwathunthu.
    ///
    /// Izi ndizogwirizana zomwe zimayenera kugwiritsidwa ntchito ngati `Ref::leak(...)`.
    /// Njira ingasokoneze njira zofananira ndi zomwe zili mu `RefCell` yogwiritsidwa ntchito kudzera pa `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Poiwala Ref iyi tikuwonetsetsa kuti wobwereketsa mu RefCell sangabwerere ku UNUSED mkati mwa nthawi ya `'b`.
        // Kukhazikitsanso momwe boma likutsatirira kungafune kulozera kwa RefCell wobwerekedwa.
        // Palibe mafotokozedwe ena omwe angasinthidwe kuchokera ku selo loyambirira.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Amapanga `RefMut` yatsopano kukhala gawo limodzi la zomwe zidabwerekedwa, mwachitsanzo, mtundu wa enum.
    ///
    /// `RefCell` idalandiridwa kale, chifukwa izi sizingalephereke.
    ///
    /// Izi ndizogwirizana zomwe zimayenera kugwiritsidwa ntchito ngati `RefMut::map(...)`.
    /// Njira ingasokoneze njira zofananira ndi zomwe zili mu `RefCell` yogwiritsidwa ntchito kudzera pa `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): konzani cheke-cheke
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Amapanga `RefMut` yatsopano posankha zinthu zomwe abwereke.
    /// Mulonda woyambayo amabwezedwa ngati `Err(..)` ngati kutseka kubwezera `None`.
    ///
    /// `RefCell` idalandiridwa kale, chifukwa izi sizingalephereke.
    ///
    /// Izi ndizogwirizana zomwe zimayenera kugwiritsidwa ntchito ngati `RefMut::filter_map(...)`.
    /// Njira ingasokoneze njira zofananira ndi zomwe zili mu `RefCell` yogwiritsidwa ntchito kudzera pa `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): konzani cheke-cheke
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // CHITETEZO: ntchito imagwira ntchito yongotchulidwapo kwakanthawi
        // kuyitanidwa kwake kudzera ku `orig`, ndipo cholozera chimangotchulidwapo mkati mwa kuyimbirako ntchito osalola kutchulidwa kokha kuthawa.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // CHITETEZO: monga pamwambapa.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Kugawa `RefMut` kukhala ma `RefMut` angapo pamagawo osiyanasiyana azidziwitso zomwe abwereka.
    ///
    /// Zomwe zimayambira `RefCell` zidzabwerekedwa mosasunthika mpaka onse abwerera `RefMut`s atachoka.
    ///
    /// `RefCell` idalandiridwa kale, chifukwa izi sizingalephereke.
    ///
    /// Izi ndizogwirizana zomwe zimayenera kugwiritsidwa ntchito ngati `RefMut::map_split(...)`.
    /// Njira ingasokoneze njira zofananira ndi zomwe zili mu `RefCell` yogwiritsidwa ntchito kudzera pa `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Sinthani kutanthauzira kosinthika kuzomwe zimayambira.
    ///
    /// Zomwe zimayambira `RefCell` sizingabwerekenso ndipo ziziwoneka kuti zabwerekedwa kale, ndikupangitsa kuti zomwe zidabwezedwazo zikhale zokhazokha.
    ///
    ///
    /// Izi ndizogwirizana zomwe zimayenera kugwiritsidwa ntchito ngati `RefMut::leak(...)`.
    /// Njira ingasokoneze njira zofananira ndi zomwe zili mu `RefCell` yogwiritsidwa ntchito kudzera pa `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Poiwala izi BorrowRefMut timaonetsetsa kuti wobwereketsa mu RefCell sangabwerere ku UNUSED mkati mwa nthawi ya `'b`.
        // Kukhazikitsanso momwe boma likutsatirira kungafune kulozera kwa RefCell wobwerekedwa.
        // Palibe mafotokozedwe enanso omwe angapangidwe kuchokera ku selo loyambirira mkati mwa nthawiyo, ndikupangitsa kuti zomwe zikuchitika pakalipano zibwereke zokhazokha za moyo wonse womwe watsala.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Mosiyana ndi BorrowRefMut::clone, yatsopano imayitanidwa kuti ipange yoyamba
        // zosinthika zosintha, motero sipangakhale zofunikira zomwe zilipo pakadali pano.
        // Chifukwa chake, pomwe mawonekedwe amawonjezera kuwerengera kosinthika, apa ife timangololeza kuchoka ku UNUSED kupita ku UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Zimasintha `BorrowRefMut`.
    //
    // Izi ndizovomerezeka ngati `BorrowRefMut` iliyonse imagwiritsidwa ntchito kutsata kutanthauzira kosunthika pamitundu yosiyana, yopanda tanthauzo la chinthu choyambirira.
    //
    // Izi sizili mu Clone impl kuti code isatchule izi kwathunthu.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Pewani kauntala yobwereka kuti isasefukire.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Mtundu wokutira wamtengo wobwerekedwa kuchokera ku `RefCell<T>`.
///
/// Onani [module-level documentation](self) kuti mumve zambiri.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Pachimake koyambira pakusintha kwamkati mwa Rust.
///
/// Ngati muli ndi `&T` yolozera, ndiye kuti mu Rust wopanga makinawo amakonza bwino kutengera kudziwa kuti `&T` imaloza kuzidziwitso zosasinthika.Kusintha tsambalo, mwachitsanzo kudzera pagulu kapena kusamutsa `&T` kukhala `&mut T`, kumawerengedwa kuti ndi machitidwe osadziwika.
/// `UnsafeCell<T>` Kutulutsa chitsimikizo cha kusasinthika kwa `&T`: gawo logawidwa `&UnsafeCell<T>` litha kuloza ku data yomwe yasinthidwa.Izi zimatchedwa "interior mutability".
///
/// Mitundu ina yonse yomwe imalola kusintha kwamkati, monga `Cell<T>` ndi `RefCell<T>`, imagwiritsa ntchito `UnsafeCell` mkati kuti ikwaniritse zambiri zawo.
///
/// Dziwani kuti kungokhala chitsimikizo chosasinthika chamabuku omwe akugawana ndi omwe amakhudzidwa ndi `UnsafeCell`.Chitsimikizo chapaderadera chazosinthika zosasinthika sichikukhudzidwa.Palibe *njira* yovomerezeka yokhazikitsira `&mut`, ngakhale ndi `UnsafeCell<T>`.
///
/// `UnsafeCell` API palokha ndiyosavuta kwambiri: [`.get()`] imakupatsani pointer yaiwisi `*mut T` pazomwe zili.Zafika mpaka _you_ monga wopanga kuti agwiritse ntchito cholozera chopyikacho molondola.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Malamulo enieni a Rust ali pang'ono akusintha, koma mfundo zazikuluzikulu sizitsutsana:
///
/// - Ngati mungapange zolemba zotetezeka ndi `'a` yamoyo wonse (mwina `&T` kapena `&mut T`) yomwe imapezeka ndi nambala yachitetezo (mwachitsanzo, chifukwa mudabweza), ndiye kuti simuyenera kulumikizana ndi njira iliyonse yomwe ikutsutsana ndi zomwe zatsala wa `'a`.
/// Mwachitsanzo, izi zikutanthauza kuti ngati mutenga `*mut T` kuchokera ku `UnsafeCell<T>` ndikuyiponya ku `&T`, ndiye kuti zomwe zili mu `T` ziyenera kukhala zosasunthika (modulo chilichonse `UnsafeCell` chopezeka mkati mwa `T`, inde) mpaka nthawi yolembedwayo itatha.
/// Mofananamo, ngati mupanga zolemba za `&mut T` zomwe zimatulutsidwa kuti zikhale zodalirika, ndiye kuti simuyenera kupeza zidziwitso mkati mwa `UnsafeCell` mpaka cholembedwacho chitatha.
///
/// - Nthawi zonse, muyenera kupewa mitundu yama data.Ngati ulusi wambiri umakhala ndi `UnsafeCell` yofananira, ndiye kuti zolembera zilizonse ziyenera kukhala ndizomwe zimachitika musanayanjanitsidwe ndi zina zonse (kapena gwiritsani ntchito ma atomiki).
///
/// Kuti muthandizire pakupanga moyenera, zochitika zotsatirazi zikufotokozedweratu kuti ndizovomerezeka pamakhodi amtundu umodzi:
///
/// 1. Buku la `&T` limatha kutulutsidwa kuti likhale lotetezeka ndipo pamenepo limatha kupezeka ndi ma `&T` ena, koma osati ndi `&mut T`
///
/// 2. Zofotokozera za `&mut T` zitha kutulutsidwa kuti zizikhazikika pokhapokha ngati `&mut T` kapena `&T` sizikhalapo.`&mut T` iyenera kukhala yapadera nthawi zonse.
///
/// Dziwani kuti ngakhale mutasintha zomwe zili mu `&UnsafeCell<T>` (ngakhale zina `&UnsafeCell<T>` zikufotokozera za seloyo) zili bwino (bola ngati mungakakamize olowa pamwambapa mwanjira ina), sichimadziwika kuti mungakhale ndi ma `&mut UnsafeCell<T>` angapo.
/// Ndiye kuti, `UnsafeCell` ndichokulunga chomwe chimapangidwa kuti chikhale ndi kulumikizana kwapadera ndi _shared_ accesses (_i.e._, kudzera pakuwunika kwa `&UnsafeCell<_>`);palibe matsenga alionse pochita ndi _exclusive_ accesses (_e.g._, kudzera pa `&mut UnsafeCell<_>`): ngakhale khungu kapena mtengo wokutidwa sangakhale woyerekedwa panthawi yonse yomwe `&mut` imabwereka.
///
/// Izi zikuwonetsedwa ndi [`.get_mut()`] yofikira, yomwe ndi _safe_ getter yomwe imapereka `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Nachi chitsanzo chowonetsa momwe mungasinthire bwino zomwe zili mu `UnsafeCell<_>` ngakhale panali maumboni angapo onena za selo:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Pezani zolemba zingapo/zofananira ku `x` yomweyo.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // CHITETEZO: mkati mwazomwezi mulibe zonena zina za zomwe zili `x,
///     // kotero zathu ndizopadera.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- kongoza-+
///     *p1_exclusive += 27; // |
/// } // <---------- sindingathe kupitirira apa -------------------+
///
/// unsafe {
///     // CHITETEZO: pamtunduwu palibe amene akuyembekeza kukhala ndi mwayi wopezeka pazomwe zili `x,
///     // kotero tikhoza kukhala ndi maulendo angapo ogawana nawo nthawi yomweyo.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Chitsanzo chotsatirachi chikuwonetsa kuti kupezeka kokha kwa `UnsafeCell<T>` kumatanthauza kufikira kokha ku `T` yake:
///
/// ```rust
/// #![forbid(unsafe_code)] // ndizofikira kokha,
///                         // `UnsafeCell` ndichowonekera mosabisa, kotero palibe chifukwa cha `unsafe` apa.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Pezani nthawi yowunika yapadera ya `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Pongotchulapo zokhazokha, titha kusintha zomwe zalembedwazi kwaulere.
/// *p_unique.get_mut() = 0;
/// // Kapena, chimodzimodzi:
/// x = UnsafeCell::new(0);
///
/// // Tikakhala ndi mtengo wake, titha kuchotsa zomwe zalembedwazo kwaulere.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Amapanga gawo latsopano la `UnsafeCell` lomwe lidzakulunga mtengo wake.
    ///
    ///
    /// Kufikira konse kwamtengo wamkati kudzera munjira ndi `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Chotsegula mtengo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Imapeza cholozera chosinthika pamtengo wokutidwa.
    ///
    /// Izi zitha kuponyedwa kwa cholozera chamtundu uliwonse.
    /// Onetsetsani kuti kufikako ndikosiyana (osagwiritsa ntchito, osasinthika kapena ayi) poponya `&mut T`, ndikuwonetsetsa kuti palibe zosintha zomwe zingachitike mukamapereka `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Titha kungotayira pointer kuchokera ku `UnsafeCell<T>` mpaka `T` chifukwa cha #[repr(transparent)].
        // Izi zikuwononga kutchuka kwa libstd, palibe chitsimikizo cha nambala yogwiritsa ntchito kuti izi zigwira ntchito mu future mitundu ya wopanga!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Imabwezeretsa kutanthauzira kosinthika pamtundu wachinsinsi.
    ///
    /// Kuyimbaku kumabwereka `UnsafeCell` mosasinthasintha (panthawi yophatikiza) zomwe zimatsimikizira kuti tili ndi zomwe tikutchulazo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Imapeza cholozera chosinthika pamtengo wokutidwa.
    /// Kusiyanitsa kwa [`get`] ndikuti ntchitoyi imalandira cholozera chosaphika, chomwe ndi chothandiza kupewa kupangika kwa maumboni osakhalitsa.
    ///
    /// Zotsatira zake zitha kuponyedwa kwa cholozera chamtundu uliwonse.
    /// Onetsetsani kuti kufikaku ndikosiyana (osagwiritsa ntchito, osasinthika kapena ayi) poponya `&mut T`, ndikuwonetsetsa kuti palibe zosintha zomwe zingachitike mukamapereka `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Kuyambitsa pang'onopang'ono kwa `UnsafeCell` kumafunikira `raw_get`, popeza kuyimbira `get` kungafune kupanga kutanthauzira kuzidziwitso zosadziwika:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Titha kungotayira pointer kuchokera ku `UnsafeCell<T>` mpaka `T` chifukwa cha #[repr(transparent)].
        // Izi zikuwononga kutchuka kwa libstd, palibe chitsimikizo cha nambala yogwiritsa ntchito kuti izi zigwira ntchito mu future mitundu ya wopanga!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Amapanga `UnsafeCell`, yokhala ndi mtengo wa `Default` wa T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}