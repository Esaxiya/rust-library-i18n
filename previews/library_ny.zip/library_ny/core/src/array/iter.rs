//! Imatanthauzira XerX yomwe ili ndi iterator yamagulu.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Wolemba mtengo wa [array].
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Izi ndizomwe tikulemba.
    ///
    /// Zinthu zomwe zili ndi index `i` pomwe `alive.start <= i < alive.end` sizinaperekedwebe ndipo ndizovomerezeka.
    /// Zinthu zokhala ndi ma XICX kapena `i >= alive.end` zidaperekedwa kale ndipo siziyenera kufikiridwanso!Zinthu zakufa zija zitha kukhala zosafotokozedwanso!
    ///
    ///
    /// Chifukwa chake obwerawo ndi:
    /// - `data[alive]` ali moyo (mwachitsanzo, ali ndi zinthu zomveka)
    /// - `data[..alive.start]` ndipo `data[alive.end..]` yafa (mwachitsanzo, zinthuzo zinali zitawerengedwa kale ndipo siziyenera kukhudzidwanso!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Zomwe zili mu `data` zomwe sizinaperekedwebe.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Pangani cholembera chatsopano pa `array` yomwe yapatsidwa.
    ///
    /// *Dziwani*: njirayi ikhoza kuchepetsedwa mu future, pambuyo pa [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Mtundu wa `value` ndi `i32` pano, m'malo mwa `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // CHITETEZO: Mauthenga apa ndi otetezeka.Maofesi a `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` akutsimikiziridwa kuti ali ndi kukula komweko ndi mayikidwe
        // > monga `T`.
        //
        // Ma docs amawonetsanso transmute kuchokera pagulu la `MaybeUninit<T>` kupita ku gulu la `T`.
        //
        //
        // Ndi izi, kuyambitsa kumeneku kumakhutiritsa osasinthawo.

        // FIXME(LukasKalbertodt): gwiritsani ntchito `mem::transmute` apa, ikangogwira ntchito ndi ma generic:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Mpaka nthawiyo, titha kugwiritsa ntchito `mem::transmute_copy` kupanga mtundu wopepuka ngati mtundu wina, kenako nkuyiwala `array` kuti isaponyedwe.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Kubwezeretsa chidutswa chosasinthika cha zinthu zonse zomwe sizinaperekedwebe.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // CHITETEZO: Tikudziwa kuti zinthu zonse mkati mwa `alive` zimayambitsidwa bwino.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Imabwezera kagawo kosinthika ka zinthu zonse zomwe sizinaperekedwebe.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // CHITETEZO: Tikudziwa kuti zinthu zonse mkati mwa `alive` zimayambitsidwa bwino.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Pezani index yotsatira kuchokera kutsogolo.
        //
        // Kuchulukitsa `alive.start` ndi 1 kumakhala kosasunthika ponena za `alive`.
        // Komabe, chifukwa cha kusinthaku, kwakanthawi kochepa, zone yamoyo siyinso `data[alive]`, koma `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Werengani chinthucho kuchokera pagulu.
            // CHITETEZO: `idx` ndi cholozera kudera lakale la "alive" la
            // mndandanda.Kuwerenga izi kumatanthauza kuti `data[idx]` imawonedwa ngati yakufa tsopano (mwachitsanzo musakhudze).
            // Popeza `idx` inali chiyambi cha malo amoyo, malo amoyo tsopano ndi `data[alive]`, kubwezeretsanso onse omwe abwera.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Pezani index yotsatira kuchokera kumbuyo.
        //
        // Kuchepetsa `alive.end` ndi 1 kumakhala kosasunthika ponena za `alive`.
        // Komabe, chifukwa cha kusinthaku, kwakanthawi kochepa, zone yamoyo siyinso `data[alive]`, koma `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Werengani chinthucho kuchokera pagulu.
            // CHITETEZO: `idx` ndi cholozera kudera lakale la "alive" la
            // mndandanda.Kuwerenga izi kumatanthauza kuti `data[idx]` imawonedwa ngati yakufa tsopano (mwachitsanzo musakhudze).
            // Popeza `idx` inali kumapeto kwa malo amoyo, malo amoyo tsopano ndi `data[alive]`, kubwezeretsanso onse omwe abwera.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // CHITETEZO: Izi ndizotetezeka: `as_mut_slice` imabwezeretsanso chidutswacho
        // za zinthu zomwe sizinasunthidwe panobe zomwe zikutsalira.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Sichidzasefukira chifukwa cha `` alive.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Wolemba mawuyo amafotokozadi kutalika kolondola.
// Chiwerengero cha zinthu "alive" (chomwe chidzaperekedwe) ndi kutalika kwa mtundu wa `alive`.
// Mtunduwu umachepetsedwa kutalika mu `next` kapena `next_back`.
// Nthawi zonse imachepetsedwa ndi 1 munjira izi, koma pokhapokha `Some(_)` ikabwezedwa.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Tawonani, sitifunikiranso kufanana ndendende momwemo, chifukwa chake titha kungolumikizana ndi 0 posatengera kuti `self` ili kuti.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Yendetsani zinthu zonse zamoyo.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Lembani choyerekeza m'gulu latsopanolo, ndikusintha mtundu wake wamoyo.
            // Ngati titapanga panics, tisiya molondola zinthu zam'mbuyomu.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Ingosindikizani zinthu zomwe sizinaperekedwebe: sitingathe kulumikizanso zinthu zomwe zatulukazo.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}