//! Ntchito zoyambira kuthana ndi kukumbukira.
//!
//! Gawoli lili ndi ntchito zofunsira kukula ndi mayikidwe amitundu, kuyambitsa ndikuwongolera kukumbukira.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Imatenga umwini ndi "forgets" yokhudza phindu **osagwiritsa ntchito zowononga**.
///
/// Zida zilizonse zomwe mtengo wake umayang'anira, monga kukumbukira mulu kapena chogwirizira mafayilo, zizikhala kwamuyaya m'malo osafikirika.Komabe, sizikutsimikizira kuti zolozera pamakumbukidwezi zizikhala zofunikira.
///
/// * Ngati mukufuna kutulutsa kukumbukira, onani [`Box::leak`].
/// * Ngati mukufuna kupeza pointer yaiwisi yokumbukira, onani [`Box::into_raw`].
/// * Ngati mukufuna kutaya mtengo moyenera, ndikuyendetsa wowonongera, onani [`mem::drop`].
///
/// # Safety
///
/// `forget` sichidziwika kuti `unsafe`, chifukwa chitetezo cha Rust sichiphatikizapo chitsimikizo kuti owononga nthawi zonse azithamanga.
/// Mwachitsanzo, pulogalamu imatha kupanga pulogalamu yogwiritsira ntchito [`Rc`][rc], kapena kuyimbira [`process::exit`][exit] kuti ituluke popanda kuwononga owononga.
/// Chifukwa chake, kulola `mem::forget` kukhala ndi chitetezo sichimasinthiratu chitetezo cha Rust.
///
/// Izi zati, kutulutsa zinthu monga kukumbukira kapena zinthu I/O nthawi zambiri kumakhala kosafunikira.
/// Chosowacho chimabwera muzochitika zina zapadera za FFI kapena nambala yosatetezeka, koma ngakhale apo, [`ManuallyDrop`] imakonda.
///
/// Chifukwa kuyiwala mtengo ndikololedwa, nambala iliyonse ya `unsafe` yomwe mumalemba iyenera kuloleza kuthekera uku.Simungabwezeretse mtengo ndikuyembekezera kuti woyimbirayo ayendetsanso wowononga phindu.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Kugwiritsa ntchito mosavomerezeka kwa `mem::forget` ndikuchepetsa kuwononga kwamtengo koyendetsedwa ndi `Drop` trait.Mwachitsanzo, izi zidzatulutsa `File`, mwachitsanzo
/// tengani malo omwe adasinthidwa koma osatseka gwero lazomwe zikuyambitsa:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Izi ndizothandiza pomwe umwini wazomwe zidasamutsidwazo zidasamutsidwa kale kupita kuzikhomo kunja kwa Rust, mwachitsanzo potumiza fayilo yaiwisi ku C code.
///
/// # Ubale ndi `ManuallyDrop`
///
/// Ngakhale `mem::forget` itha kugwiritsidwanso ntchito kusamutsa umwini wa * chikumbukiro, kutero ndicholakwika.
/// [`ManuallyDrop`] ziyenera kugwiritsidwa ntchito m'malo mwake.Mwachitsanzo, taganizirani za code iyi:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Pangani `String` pogwiritsa ntchito zomwe zili mu `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // leak `v` chifukwa kukumbukira kwake tsopano kumayang'aniridwa ndi `s`
/// mem::forget(v);  // ZOSAKHALA, v ndi zosavomerezeka ndipo siziyenera kupititsidwa ku ntchito
/// assert_eq!(s, "Az");
/// // `s` imagwetsedwa kwathunthu ndipo kukumbukira kwake kudasinthidwa.
/// ```
///
/// Pali zinthu ziwiri zomwe zili pamwambapa:
///
/// * Ngati ma code ena awonjezedwa pakati pakupanga `String` ndikupempha `mem::forget()`, panic mkati mwake imatha kubweretsa ufulu wowirikiza chifukwa kukumbukira komweku kumayendetsedwa ndi `v` ndi `s`.
/// * Pambuyo poyimbira `v.as_mut_ptr()` ndikusamutsa umwini wa zidziwitsozo ku `s`, mtengo wa `v` ndiwosavomerezeka.
/// Ngakhale mtengo utasinthidwa kupita ku `mem::forget` (yomwe singayang'anire), mitundu ina imakhala ndi zofunikira pamitengo yawo zomwe zimawapangitsa kukhala osaloledwa akulendewera kapena kulibenso.
/// Kugwiritsa ntchito zinthu zosayenera mwanjira iliyonse, kuphatikiza kuzipereka kapena kuzibwezera kuchokera kuntchito, zimapanga machitidwe osadziwika ndipo zitha kusokoneza malingaliro omwe wopanga adalemba.
///
/// Kusinthira ku `ManuallyDrop` kumapewa zovuta zonsezi:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Tisanasanjitse `v` m'malo ake opangira, onetsetsani kuti siyikugwa!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Tsopano disassemble `v`.Ntchitozi sizingakhale panic, chifukwa chake sipangakhale kutayikira.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Pomaliza, pangani `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` imagwetsedwa kwathunthu ndipo kukumbukira kwake kudasinthidwa.
/// ```
///
/// `ManuallyDrop` zimateteza mwamphamvu kukhala opanda mfulu kawiri chifukwa timalepheretsa owononga a v asanachite china chilichonse.
/// `mem::forget()` salola izi chifukwa imagwiritsa ntchito mfundo zake, kutikakamiza kuti tiziziyimbira pokhapokha titatulutsa chilichonse chomwe tikufuna kuchokera ku `v`.
/// Ngakhale panic itayambitsidwa pakati pakupanga `ManuallyDrop` ndikupanga chingwe (chomwe sichingachitike mu code yomwe ikuwonetsedwa), zimatha kubwereka osati mfulu kawiri.
/// Mwanjira ina, `ManuallyDrop` imalakwitsa kumbali yakudontha m'malo molakwitsa mbali ya (iwiri-) kugwa.
///
/// Komanso, `ManuallyDrop` imatilepheretsa kukhala ndi "touch" `v` titasamutsira umwini ku `s`-sitepe yomaliza yolumikizana ndi `v` kuti iitaye popanda kuyiyendetsa idaipeweratu.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Monga [`forget`], komanso amavomereza malingaliro osayenerera.
///
/// Ntchitoyi ndi shim chabe yomwe ikuyenera kuchotsedwa pomwe gawo la `unsized_locals` likhazikika.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Kubwezeretsa kukula kwa mtundu wa mabayiti.
///
/// Makamaka, izi ndizolembedwa pamabatani pakati pazinthu zotsatizana motsatana ndi mtundu wa chinthucho kuphatikiza kulumikizana.
///
/// Chifukwa chake, pamtundu uliwonse `T` ndi kutalika `n`, `[T; n]` imakhala ndi kukula kwa `n * size_of::<T>()`.
///
/// Mwambiri, kukula kwa mtundu sikukhazikika pamitundu yonse, koma mitundu yapadera monga ma primitives ndi.
///
/// Tebulo lotsatirali limapereka kukula kwa zoyambira.
///
/// Mtundu |kukula_kwa: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Kuphatikiza apo, `usize` ndi `isize` ali ndi kukula kofanana.
///
/// Mitundu `*const T`, `&T`, `Box<T>`, `Option<&T>`, ndi `Option<Box<T>>` yonse ili ndi kukula kofanana.
/// Ngati `T` ndi Sized, mitundu yonseyi imakhala yofanana ndi `usize`.
///
/// Kusintha kwa cholozera sikusintha kukula kwake.Mwakutero, `&T` ndi `&mut T` ali ndi kukula kofanana.
/// Momwemonso kwa `*const T` ndi `* mut T`.
///
/// # Kukula kwa zinthu `#[repr(C)]`
///
/// Chiwonetsero cha `C` pazinthu chimakhala ndi mawonekedwe.
/// Ndikapangidwe kameneka, kukula kwa zinthu kumakhala kolimba bola ngati minda yonse ili ndi khola lokhazikika.
///
/// ## Kukula kwa Kumanga
///
/// Kwa `structs`, kukula kumatsimikiziridwa ndi ma aligorivimu otsatirawa.
///
/// Pa gawo lirilonse mu struct lolamulidwa ndi dongosolo la kulengeza:
///
/// 1. Onjezani kukula kwa munda.
/// 2. Zungulirani kukula kwake pakapita nthawi yapafupi pa [alignment] yotsatira.
///
/// Pomaliza, zungulirani kukula kwa fomuyi kupita ku angapo omwe ali pafupi ndi [alignment].
/// Kuyanjana kwa struct nthawi zambiri kumakhala kwakukulu kwambiri paminda yake yonse;izi zingasinthidwe pogwiritsa ntchito `repr(align(N))`.
///
/// Mosiyana ndi `C`, ma zero osanjikiza sanapangidwe mpaka kukula kamodzi.
///
/// ## Kukula kwa Enum
///
/// Ma enum omwe alibe data kupatula osankhana ali ndi kukula kofanana ndi ma enum a C papulatifomu yomwe adapangira.
///
/// ## Kukula kwa Mabungwe
///
/// Kukula kwa mgwirizano ndikukula kwa gawo lalikulu kwambiri.
///
/// Mosiyana ndi `C`, mabungwe azithunzi zazikulu sanakwane mpaka kukula kwake.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Zakale zina
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Zida zina
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Kukula kwa cholowa
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Kugwiritsa ntchito `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Kukula kwa gawo loyamba ndi 1, onjezerani 1 kukula.Kukula ndi 1.
/// // Kuyanjana kwa gawo lachiwiri ndi 2, chifukwa chake onjezani 1 kukula kwa padding.Kukula ndi 2.
/// // Kukula kwa gawo lachiwiri ndi 2, onjezerani 2 kukula kwake.Kukula ndi 4.
/// // Kuyanjana kwa gawo lachitatu ndi 1, chifukwa chake onjezani 0 kukula kwa padding.Kukula ndi 4.
/// // Kukula kwa gawo lachitatu ndi 1, onjezerani 1 kukula.Kukula ndi 5.
/// // Pomaliza, mayendedwe a struct ndi 2 (chifukwa mayikidwe akulu kwambiri pakati paminda yake ndi 2), onjezerani 1 kukula kwa padding.
/// // Kukula ndi 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple structs amatsatira malamulo omwewo.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Dziwani kuti kukonzanso minda kumatha kutsitsa kukula.
/// // Titha kuchotsa ma padding byte poyika `third` patsogolo pa `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Kukula kwa mgwirizano ndikukula kwa gawo lalikulu kwambiri.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Imabwezeretsa kukula kwa mtengo wosimbidwa ndi ma byte.
///
/// Izi nthawi zambiri zimakhala zofanana ndi `size_of::<T>()`.
/// Komabe, pamene `T`*ilibe* kukula kodziwika, mwachitsanzo, kagawo ka [`[T]`][slice] kapena [trait object], ndiye kuti `size_of_val` itha kugwiritsidwa ntchito kupeza kukula kodziwika bwino.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // CHITETEZO: `val` ndi cholozera, chifukwa chake ndi cholozera chovomerezeka
    unsafe { intrinsics::size_of_val(val) }
}

/// Imabwezeretsa kukula kwa mtengo wosimbidwa ndi ma byte.
///
/// Izi nthawi zambiri zimakhala zofanana ndi `size_of::<T>()`.Komabe, pamene `T`*ilibe* kukula kodziwika, mwachitsanzo, kagawo ka [`[T]`][slice] kapena [trait object], ndiye kuti `size_of_val_raw` itha kugwiritsidwa ntchito kupeza kukula kodziwika bwino.
///
/// # Safety
///
/// Ntchitoyi ndiyabwino kuyitanitsa ngati zinthu izi zikugwira:
///
/// - Ngati `T` ndi `Sized`, ntchitoyi imakhala yotetezeka nthawi zonse.
/// - Ngati mchira wosakwanira wa `T` ndi:
///     - [slice], ndiye kutalika kwa mchira wa chidutswacho kuyenera kukhala nambala yoyamba, ndipo kukula kwa *mtengo wonse*(mphamvu yayitali mchira + choyambirira) chiyenera kukwana `isize`.
///     - [trait object], ndiye kuti gawo loyenera la pointer liyenera kuloza ku vtable yolondola yomwe imapezeka ndi kukakamiza kosafunikira, ndipo kukula kwa *mtengo wonse*(kutalika kwa mchira kutalika + koyambirira koyenera) kuyenera kukhala mu `isize`.
///
///     - (unstable) [extern type], ndiye kuti ntchitoyi imakhala yotetezeka nthawi zonse, koma mwina panic kapena mwina ibwezeretse mtengo wolakwika, popeza mawonekedwe akunja sakudziwika.
///     Izi ndizofanana ndi [`size_of_val`] potengera mtundu wokhala ndi mchira wakunja.
///     - Kupanda kutero, sikuloledwa mwalamulo kuyitanitsa ntchitoyi.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // CHITETEZO: woyimbayo ayenera kupereka cholozera chovomerezeka
    unsafe { intrinsics::size_of_val(val) }
}

/// Kubwezeretsa mayikidwe ochepera amtundu wa [ABI].
///
/// Kutchulidwa kulikonse pamtengo wamtundu wa `T` kuyenera kukhala kochulukirapo pa nambala iyi.
///
/// Uku ndiko kulumikizana komwe kumagwiritsidwa ntchito popanga magawo.Itha kukhala yaying'ono kuposa mayikidwe okondedwa.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Kubwezeretsa mayendedwe osakwanira a [ABI] amtundu wamtengo womwe `val` imalozera.
///
/// Kutchulidwa kulikonse pamtengo wamtundu wa `T` kuyenera kukhala kochulukirapo pa nambala iyi.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // CHITETEZO: val ndi chofotokozera, chifukwa chake ndi cholozera chovomerezeka
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Kubwezeretsa mayikidwe ochepera amtundu wa [ABI].
///
/// Kutchulidwa kulikonse pamtengo wamtundu wa `T` kuyenera kukhala kochulukirapo pa nambala iyi.
///
/// Uku ndiko kulumikizana komwe kumagwiritsidwa ntchito popanga magawo.Itha kukhala yaying'ono kuposa mayikidwe okondedwa.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Kubwezeretsa mayendedwe osakwanira a [ABI] amtundu wamtengo womwe `val` imalozera.
///
/// Kutchulidwa kulikonse pamtengo wamtundu wa `T` kuyenera kukhala kochulukirapo pa nambala iyi.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // CHITETEZO: val ndi chofotokozera, chifukwa chake ndi cholozera chovomerezeka
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Kubwezeretsa mayendedwe osakwanira a [ABI] amtundu wamtengo womwe `val` imalozera.
///
/// Kutchulidwa kulikonse pamtengo wamtundu wa `T` kuyenera kukhala kochulukirapo pa nambala iyi.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Ntchitoyi ndiyabwino kuyitanitsa ngati zinthu izi zikugwira:
///
/// - Ngati `T` ndi `Sized`, ntchitoyi imakhala yotetezeka nthawi zonse.
/// - Ngati mchira wosakwanira wa `T` ndi:
///     - [slice], ndiye kutalika kwa mchira wa chidutswacho kuyenera kukhala nambala yoyamba, ndipo kukula kwa *mtengo wonse*(mphamvu yayitali mchira + choyambirira) chiyenera kukwana `isize`.
///     - [trait object], ndiye kuti gawo loyenera la pointer liyenera kuloza ku vtable yolondola yomwe imapezeka ndi kukakamiza kosafunikira, ndipo kukula kwa *mtengo wonse*(kutalika kwa mchira kutalika + koyambirira koyenera) kuyenera kukhala mu `isize`.
///
///     - (unstable) [extern type], ndiye kuti ntchitoyi imakhala yotetezeka nthawi zonse, koma mwina panic kapena mwina ibwezeretse mtengo wolakwika, popeza mawonekedwe akunja sakudziwika.
///     Izi ndizofanana ndi [`align_of_val`] potengera mtundu wokhala ndi mchira wakunja.
///     - Kupanda kutero, sikuloledwa mwalamulo kuyitanitsa ntchitoyi.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // CHITETEZO: woyimbayo ayenera kupereka cholozera chovomerezeka
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Kubwezeretsa `true` ngati kutaya zinthu zamtundu wa `T`.
///
/// Ili ndiye lingaliro lokhathamiritsa, ndipo litha kuchitidwa mosamala:
/// itha kubweza `true` yamitundu yomwe siyikusowa kuti iponyedwe.
/// Momwemonso kubwerera `true` ndikofunikira kukhazikitsa ntchitoyi.Komabe ngati ntchitoyi ibwezeretsanso `false`, ndiye kuti mutha kutsimikiza kuti `T` ilibe vuto lililonse.
///
/// Kukhazikitsa kotsika kwa zinthu monga zopereka, zomwe zimayenera kusiya pamanja zidziwitso zawo, ziyenera kugwiritsa ntchito ntchitoyi kupewa kuyesayesa kusiya zonse zomwe zawonongedwa zikawonongedwa.
///
/// Izi sizingapangitse kuti pakhale kumasulidwa komwe kumamangidwa (komwe kuzungulira komwe kulibe zovuta kumawonekeratu ndikuchotsedwa), koma nthawi zambiri kumakhala kopambana kwakukulu pakumanga zolakwika.
///
/// Dziwani kuti [`drop_in_place`] idachita kale chekechi, chifukwa chake ngati ntchito yanu ichepetsedwa kukhala kuyimbira pang'ono kwa [`drop_in_place`], kugwiritsa ntchito izi sikofunikira.
/// Makamaka zindikirani kuti mutha kutsitsa [`drop_in_place`] kagawo, ndipo izi zichita limodzi pofufuza zofunikira zonse.
///
/// Mitundu ngati Vec motero ndi `drop_in_place(&mut self[..])` osagwiritsa ntchito `needs_drop` momveka bwino.
/// Mitundu ngati [`HashMap`], mbali inayo, imayenera kusiya mfundo imodzi ndipo iyenera kugwiritsa ntchito API iyi.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Nachi chitsanzo cha momwe ndalama zingagwiritsire ntchito `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // kusiya deta
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Imabwezeretsa mtengo wamtundu `T` woyimiridwa ndi mtundu wa zero-byte.
///
/// Izi zikutanthauza kuti, mwachitsanzo, padding byte mu `(u8, u16)` siyofunika kwenikweni.
///
/// Palibe chitsimikizo kuti mtundu wa zero-zero umayimira phindu lenileni la mtundu wina wa `T`.
/// Mwachitsanzo, mtundu wa zero-byte siwofunika pamitundu yotsatsira (`&T`, `&mut T`) ndi zolozera za ntchito.
/// Kugwiritsa ntchito `zeroed` pamitundu yotere kumayambitsa [undefined behavior][ub] chifukwa [the Rust compiler assumes][inv] kuti nthawi zonse pamakhala phindu pamasinthidwe omwe amawona kuti adayambitsidwa.
///
///
/// Izi zimakhala ndi zotsatira zofanana ndi [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Imathandiza pa FFI nthawi zina, koma nthawi zambiri imayenera kuzipewa.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Konzani bwino ntchitoyi: kuyambitsa nambala yonse ndi zero.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// Kugwiritsa ntchito molakwika * kwa ntchitoyi: kuyambitsa kutchula ndi zero.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Khalidwe losadziwika!
/// let _y: fn() = unsafe { mem::zeroed() }; // Ndiponso!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // CHITETEZO: woyimbirayo akuyenera kutsimikizira kuti phindu la zero lonse ndi lovomerezeka pa `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Mawonekedwe olowera a Rust amafufuza poyeserera poyesezera kuti apange mtengo wamtundu wa `T`, osachita chilichonse.
///
/// **Ntchitoyi yachotsedwa.** Gwiritsani ntchito [`MaybeUninit<T>`] m'malo mwake.
///
/// Chifukwa chakuchepa ndikuti ntchitoyi siyingagwiritsidwe ntchito moyenera: ili ndi zotsatira zofanana ndi [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Monga momwe [`assume_init` documentation][assume_init] ikufotokozera, [the Rust compiler assumes][inv] mfundozo zimayambitsidwa bwino.
/// Zotsatira zake, kuyitanira mwachitsanzo
/// `mem::uninitialized::<bool>()` zimayambitsa machitidwe osasinthika pakubwezeretsa `bool` yomwe siyotsimikizika kuti ndi `true` kapena `false`.
/// Choyipa chachikulu, kukumbukira kosazindikirika kwenikweni monga zomwe zimabweretsedwera pano ndizapadera chifukwa choti wopanga amadziwa kuti alibe phindu lokhazikika.
/// Izi zimapangitsa kukhala kosazolowereka kukhala ndi chidziwitso chosasinthika mosasinthasintha ngakhale chosinthacho chili ndi mitundu yonse.
/// (Zindikirani kuti malamulo oyandikira manambala osakwaniritsidwa sanamalizidwebe, koma mpaka atakwaniritsidwa, ndibwino kuwapewa.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // CHITETEZO: woyimbirayo akuyenera kutsimikizira kuti mtengo wosavomerezeka ndiwothandiza pa `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Amasintha malingaliro m'malo awiri osinthika, osachotsapo chimodzi.
///
/// * Ngati mukufuna kusinthana ndi kusasintha kapena mtengo wamtengo wapatali, onani [`take`].
/// * Ngati mukufuna kusinthana ndi mtengo wopitilira, ndikubwezeretsanso mtengo wakale, onani [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // CHITETEZO: zolembera zosaphika zidapangidwa kuchokera kuzosungika zotheka zomwe zingakhutiritse zonse
    // zopinga pa `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// M'malo `dest` ndi mtengo wosasintha wa `T`, ndikubwezeretsanso mtengo wa `dest` wakale.
///
/// * Ngati mukufuna kusintha malingaliro amitundu iwiri, onani [`swap`].
/// * Ngati mukufuna kusintha ndi mtengo wopitilira m'malo mwa mtengo wosasintha, onani [`replace`].
///
/// # Examples
///
/// Chitsanzo chosavuta:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` imalola kutenga gawo lamasamba poyikapo ndi mtengo wa "empty".
/// Popanda `take` mutha kuthana ndi mavuto ngati awa:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Dziwani kuti `T` sikuti imagwiritsa ntchito [`Clone`], chifukwa sichingafanane ndi kukhazikitsanso `self.buf`.
/// Koma `take` itha kugwiritsidwa ntchito kupatula phindu loyambirira la `self.buf` kuchokera ku `self`, kulola kuti libwezeretsedwe:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Imasuntha `src` kulowa mu `dest` yomwe yatchulidwa, ndikubwezera mtengo wam'mbuyo wa `dest`.
///
/// Palibe phindu lomwe limatsitsidwa.
///
/// * Ngati mukufuna kusintha malingaliro amitundu iwiri, onani [`swap`].
/// * Ngati mukufuna kusintha ndi mtengo wosasintha, onani [`take`].
///
/// # Examples
///
/// Chitsanzo chosavuta:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` imalola kugwiritsidwa ntchito kwa gawo lamalimba polisintha ndi phindu lina.
/// Popanda `replace` mutha kuthana ndi mavuto ngati awa:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Dziwani kuti `T` sikuti imagwiritsa ntchito [`Clone`], chifukwa chake sitingathe kuphatikiza `self.buf[i]` kuti tipewe kusunthaku.
/// Koma `replace` itha kugwiritsidwa ntchito kusiyanitsa mtengo wapachiyambi pa index kuchokera ku `self`, kulola kuti ibwezeretsedwe:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // CHITETEZO: Timawerenga kuchokera ku `dest` koma timangolemba `src` pambuyo pake,
    // kotero kuti phindu lakale silinapangidwe.
    // Palibe chomwe chaponyedwa ndipo palibe chilichonse pano chomwe chingathe panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Kutaya mtengo.
///
/// Izi zimatero poyitanira kutsutsana kwa [`Drop`][drop].
///
/// Izi sizichita chilichonse pamitundu yomwe imagwiritsa ntchito `Copy`, mwachitsanzo
/// integers.
/// Zoterezi zimakopedwa ndipo _then_ imasunthidwa kuti igwire ntchito, chifukwa chake kulimbikira kupitiriza ntchitoyi.
///
///
/// Ntchitoyi si matsenga;limatanthauziridwa kwenikweni ngati
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Chifukwa `_x` imasunthidwira mu ntchitoyi, imangoponyedwa ntchitoyi isanabwerere.
///
/// [drop]: Drop
///
/// # Examples
///
/// Kagwiritsidwe:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // Ikani vector
/// ```
///
/// Popeza [`RefCell`] imalimbikitsa malamulo obwereka nthawi yothamanga, `drop` imatha kumasula [`RefCell`] yobwereka:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // Siyani ngongole yosinthika pamalowo
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Ma integer ndi mitundu ina yokhazikitsa [`Copy`] samakhudzidwa ndi `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // buku la `x` limasunthidwa ndikuponyedwa
/// drop(y); // buku la `y` limasunthidwa ndikuponyedwa
///
/// println!("x: {}, y: {}", x, y.0); // akadakalipo
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Amamasulira `src` kukhala ndi mtundu `&U`, kenako amawerenga `src` osasuntha mtengo wake.
///
/// Ntchitoyi idzaganiza kuti pointer `src` ndi yolondola pa [`size_of::<U>`][size_of] byte posamutsa `&T` mpaka `&U` kenako ndikuwerenga `&U` (kupatula kuti izi zimachitika m'njira yolondola ngakhale `&U` ipange zofunikira kwambiri kuposa `&T`).
/// Zikhazikitsanso mosavomerezeka kope la mtengo wake m'malo mochoka pa `src`.
///
/// Sikovuta kwakanthawi ngati `T` ndi `U` ali ndi kukula kosiyanasiyana, koma tikulimbikitsidwa kuti tizingoyitanitsa ntchitoyi pomwe `T` ndi `U` ali ndi kukula kofanana.Ntchitoyi imayambitsa [undefined behavior][ub] ngati `U` ili yayikulu kuposa `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Lembani zochokera ku 'foo_array' ndikuziwona ngati 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Sinthani zomwe zakopera
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Zomwe zili mu 'foo_array' siziyenera kusintha
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Ngati U ili ndi mayikidwe apamwamba kwambiri, src mwina sizingafanane bwino.
    if align_of::<U>() > align_of::<T>() {
        // CHITETEZO: `src` ndizofotokozera zomwe zimatsimikizika kuti ndizovomerezeka pakuwerenga.
        // Woyimbirayo akuyenera kutsimikizira kuti kutumizira kwenikweni ndikotetezeka.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // CHITETEZO: `src` ndizofotokozera zomwe zimatsimikizika kuti ndizovomerezeka pakuwerenga.
        // Tidangowunika kuti `src as *const U` idalumikizidwa bwino.
        // Woyimbirayo akuyenera kutsimikizira kuti kutumizira kwenikweni ndikotetezeka.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Mtundu wa Opaque woimira omwe amasankha enum.
///
/// Onani ntchito ya [`discriminant`] mu gawo ili kuti mumve zambiri.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Kukhazikitsa kwa trait sikungachokere chifukwa sitikufuna malire aliwonse pa T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Kubwezeretsa mtengo wozindikiritsa mwapadera mtundu wa enum mu `v`.
///
/// Ngati `T` si enum, kuyitanitsa ntchitoyi sikungapangitse kukhala ndi khalidwe losafotokozedwa, koma phindu lobwezera silikudziwika.
///
///
/// # Stability
///
/// Kusankha kosiyanasiyana kwa enum kumasintha ngati tanthauzo la enum lisintha.
/// Kusankhana kwamitundu ina sikungasinthe pakati pakuphatikizika ndi wopanga womwewo.
///
/// # Examples
///
/// Izi zitha kugwiritsidwa ntchito kufananizira ma enum omwe amakhala ndi zambiri, osanyalanyaza zomwe zidalipo:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Imabwezeretsa kuchuluka kwa mitundu ya enum `T`.
///
/// Ngati `T` si enum, kuyitanitsa ntchitoyi sikungapangitse kukhala ndi khalidwe losafotokozedwa, koma phindu lobwezera silikudziwika.
/// Mofananamo, ngati `T` ndi enum yokhala ndi mitundu yambiri kuposa `usize::MAX` phindu lobwezera silikudziwika.
/// Mitundu yopanda anthu idzawerengedwa.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}