use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Mtundu wokutira kuti apange zochitika zosadziwika za `T`.
///
/// # Kuyambitsa kosasintha
///
/// Wopangirayo, ambiri, amaganiza kuti kusiyanasiyana kumayambitsidwa bwino kutengera mtundu wa zosinthazo.Mwachitsanzo, mtundu wosinthira uyenera kulumikizidwa komanso osakhala NULL.
/// Izi ndizomwe zimasinthasintha zomwe ziyenera kuti nthawi zonse zizitsimikizidwa, ngakhale zili munjira yosatetezeka.
/// Zotsatira zake, zero-kuyambitsa mtundu wosinthika kumayambitsa [undefined behavior][ub] yomweyo, ziribe kanthu kaya kutchulidwako kungagwiritsidwe ntchito kufikira kukumbukira:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // khalidwe losadziwika!Alireza
/// // Nambala yofanana ndi `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // khalidwe losadziwika!Alireza
/// ```
///
/// Izi zikugwiritsidwa ntchito ndi wopangirayo pazokhathamiritsa zosiyanasiyana, monga kuthamangitsa macheke othamanga ndikukhazikitsa mawonekedwe a `enum`.
///
/// Mofananamo, kukumbukira kwathunthu kosakhazikika kumatha kukhala ndi chilichonse, pomwe `bool` iyenera kukhala `true` kapena `false` nthawi zonse.Chifukwa chake, kupanga `bool` yosadziwika ndi machitidwe osadziwika:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // khalidwe losadziwika!Alireza
/// // Nambala yofanana ndi `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // khalidwe losadziwika!Alireza
/// ```
///
/// Kuphatikiza apo, kukumbukira kosadziwika ndi kwapadera chifukwa kulibe phindu lokhazikika ("fixed" kutanthauza "it won't change without being written to").Kuwerenga chimodzimodzi chomwe sichinatchulidwe kangapo kangapereke zotsatira zosiyana.
/// Izi zimapangitsa kukhala kosazolowereka kukhala ndi chidziwitso chosasinthika mosasunthika ngakhale chosinthacho chili ndi mtundu wochuluka, womwe ungatenge mtundu uliwonse wa * osasunthika:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // khalidwe losadziwika!Alireza
/// // Nambala yofanana ndi `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // khalidwe losadziwika!Alireza
/// ```
/// (Zindikirani kuti malamulo oyandikira manambala osakwaniritsidwa sanamalizidwebe, koma mpaka atakwaniritsidwa, ndibwino kuwapewa.)
///
/// Pamwamba pa izo, kumbukirani kuti mitundu yambiri imakhala ndi zowonjezera zowonjezera zomwe sizingangotengedwa kuti zayambitsidwa pamlingo wamtunduwo.
/// Mwachitsanzo, `1`-initialized [`Vec<T>`] imawerengedwa kuti idayambitsidwa (pakukhazikitsa pano; izi sizikhala chitsimikizo chokhazikika) chifukwa chofunikira chokhacho chomwe wopangirayo amadziwa ndikuti cholozera deta sichiyenera kukhala chopanda pake.
/// Kupanga `Vec<T>` yotere sikuyambitsa machitidwe * osakhazikika, koma kumadzetsa machitidwe osadziwika ndi ntchito zotetezeka (kuphatikizapo kuzisiya).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` imagwira ntchito kuti iwonetse nambala yosatetezeka kuti ithe kuthana ndi chidziwitso chosadziwika.
/// Ndi chizindikiritso kwa wopanga zomwe zikusonyeza kuti zomwe zili pano sizingayambike:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Pangani chikalata chosamveka bwino.
/// // Wosonkhanitsayo amadziwa kuti deta mkati mwa `MaybeUninit<T>` itha kukhala yosavomerezeka, chifukwa chake ichi si UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Ikani pamtengo woyenera.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Chotsani zomwe zayambitsidwa-izi zimaloledwa *pambuyo* poyambitsa `x` bwino!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Wolembetsayo adziwa kuti asapangire zolakwika kapena kukhathamiritsa pa code iyi.
///
/// Mutha kuganiza za `MaybeUninit<T>` kukhala ngati `Option<T>` koma popanda nthawi yotsatira komanso osafufuza chilichonse.
///
/// ## out-pointers
///
/// Mutha kugwiritsa ntchito `MaybeUninit<T>` kukhazikitsa "out-pointers": m'malo mongobwezera deta kuchokera kuntchito, ipatseni cholozera ku kukumbukira kwa (uninitialized) kuti muyikemo zotsatira zake.
/// Izi zitha kukhala zothandiza pakakhala kofunikira kuti woyimbirayo awongolere momwe kukumbukira komwe zotsatira zake zimasungidwira kumagawidwira, ndipo mukufuna kupewa mayendedwe osafunikira.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` sikutaya zomwe zili mkatimo, zomwe ndizofunikira.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Tsopano tikudziwa kuti `v` idayambitsidwa!Izi zikuwonetsetsanso kuti vector igwetsedwa bwino.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Kuyambitsa gulu lazinthu-ndi-chinthu
///
/// `MaybeUninit<T>` itha kugwiritsidwa ntchito kuyambitsa gulu lalikulu-ndi-chinthu:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Pangani gulu la `MaybeUninit` losadziwika.
///     // `assume_init` ndiyotetezeka chifukwa mtundu womwe tikunena kuti tidayambitsa pano ndi gulu la `MaybeUninit`s, lomwe silikufuna kuyambitsidwa.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Kutaya `MaybeUninit` sikungachite chilichonse.
///     // Chifukwa chake kugwiritsa ntchito pointer yaiwisi m'malo mwa `ptr::write` sikuyambitsa mtengo wakale wosatsitsidwa kuti ugwetsedwe.
/////
///     // Komanso ngati pali panic panthawiyi, timakumbukira, koma palibe vuto lokumbukira kukumbukira.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Chilichonse chimayambitsidwa.
///     // Sungani mtunduwo kukhala mtundu woyambitsidwa.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Muthanso kugwira ntchito ndi zida zoyambira pang'ono, zomwe zimatha kupezeka m'madongosolo otsika.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Pangani gulu la `MaybeUninit` losadziwika.
/// // `assume_init` ndiyotetezeka chifukwa mtundu womwe tikunena kuti tidayambitsa pano ndi gulu la `MaybeUninit`s, lomwe silikufuna kuyambitsidwa.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Werengani kuchuluka kwa zinthu zomwe tapatsa.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Pa chilichonse chomwe chili mgulu, tisiyeni ngati tidachigawa.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Kukhazikitsa gawo ndi gawo
///
/// Mutha kugwiritsa ntchito `MaybeUninit<T>`, ndi [`std::ptr::addr_of_mut`] macro, kuti muyambitse magawo ndi magawo:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Kuyambitsa gawo la `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Kuyambitsa gawo la `list` Ngati pali panic apa, ndiye kuti `String` yomwe ili mu `name` ikudontha.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Masamba onse adayambitsidwa, chifukwa chake timayitanitsa `assume_init` kuti tipeze Foo yoyambira.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` akutsimikiziridwa kukhala ndi kukula kofanana, mayikidwe, ndi ABI monga `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Komabe kumbukirani kuti mtundu * wokhala ndi `MaybeUninit<T>` sindiwo mawonekedwe omwewo;Rust sikutsimikizira kwenikweni kuti magawo a `Foo<T>` ali ndi dongosolo lofanana ndi `Foo<U>` ngakhale `T` ndi `U` ali ndi kukula komanso kufanana komweku.
///
/// Kuphatikiza apo chifukwa mtengo uliwonse wovomerezeka wa `MaybeUninit<T>` wopanga sungagwiritse ntchito kukhathamiritsa kwa non-zero/niche-filling, zomwe zingapangitse kukula kwakukulu:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Ngati `T` ndi FFI-safe, ndiye `MaybeUninit<T>`.
///
/// Pomwe `MaybeUninit` ndi `#[repr(transparent)]` (kuwonetsa kuti kumatsimikizira kukula, mayikidwe, ndi ABI ngati `T`), izi * sizisintha zina mwazomwe zidapezekapo kale.
/// `Option<T>` ndipo `Option<MaybeUninit<T>>` itha kukhala ndi kukula kosiyanasiyana, ndipo mitundu yokhala ndi gawo la mtundu wa `T` itha kuyalidwa (ndi kukula) mosiyana kuposa ngati mundawo unali `MaybeUninit<T>`.
/// `MaybeUninit` ndi mtundu wamgwirizano, ndipo `#[repr(transparent)]` pamabungwe osakhazikika (onani [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Popita nthawi, zotsimikizira zenizeni za `#[repr(transparent)]` pamabungwe zimatha kusintha, ndipo `MaybeUninit` itha kukhala kapena isakhalebe `#[repr(transparent)]`.
/// Izi zati, `MaybeUninit<T>` * nthawi zonse izitsimikizira kuti ili ndi kukula, mayendedwe, ndi ABI ngati `T`;Kungoti momwe `MaybeUninit` imagwiritsira ntchito chitsimikizo chimatha kusintha.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang chinthu kuti titha kukulunga mitundu ina.Izi ndizothandiza kwa ma jenereta.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Osati kuyitana `T::clone()`, sitingadziwe ngati tidayambitsidwa zokwanira.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Kupanga `MaybeUninit<T>` yatsopano yoyambitsidwa ndi mtengo womwe wapatsidwa.
    /// Ndikwabwino kuyimbira [`assume_init`] pamtengo wobwerenso wa ntchitoyi.
    ///
    /// Dziwani kuti kutaya `MaybeUninit<T>` sikungatchule kachidindo ka `T '.
    /// Ndiudindo wanu kuwonetsetsa kuti `T` igwetsedwa ikangoyamba kumene.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Amapanga `MaybeUninit<T>` yatsopano m'malo osadziwika.
    ///
    /// Dziwani kuti kutaya `MaybeUninit<T>` sikungatchule kachidindo ka `T '.
    /// Ndiudindo wanu kuwonetsetsa kuti `T` igwetsedwa ikangoyamba kumene.
    ///
    /// Onani [type-level documentation][MaybeUninit] pazitsanzo zina.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Pangani gulu latsopano la zinthu `MaybeUninit<T>`, mosavomerezeka.
    ///
    /// Note: mu mtundu wa future Rust njirayi itha kukhala yosafunikira pomwe ma syntax enieni amalola [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Chitsanzo pansipa chikhoza kugwiritsa ntchito `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Kubwezera kachidutswa ka data (mwina kocheperako) komwe amawerengadi
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // CHITETEZO: `[MaybeUninit<_>; LEN]` yosadziwika ndi yolondola.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Imapanga `MaybeUninit<T>` yatsopano m'malo osadziwika, kukumbukira kukudzazidwa ndi ma `0` byte.Zimatengera `T` ngati izi zikupanga kale kuyambitsa koyenera.
    ///
    /// Mwachitsanzo, `MaybeUninit<usize>::zeroed()` imayambitsidwa, koma `MaybeUninit<&'static i32>::zeroed()` sichifukwa choti maumboni sayenera kukhala opanda pake.
    ///
    /// Dziwani kuti kutaya `MaybeUninit<T>` sikungatchule kachidindo ka `T '.
    /// Ndiudindo wanu kuwonetsetsa kuti `T` igwetsedwa ikangoyamba kumene.
    ///
    /// # Example
    ///
    /// Kugwiritsa ntchito bwino ntchitoyi: kuyambitsa struct ndi zero, pomwe magawo onse a struct amatha kukhala ndi mtundu wa 0 ngati phindu.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// Kugwiritsa ntchito molakwika * kwa ntchitoyi: kuyimbira `x.zeroed().assume_init()` pomwe `0` siyomwe ili yolondola pamtunduwu:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Mkati mwa awiriwa, timapanga `NotZero` yomwe ilibe tsankho.
    /// // Izi sizodziwika bwino.@Alirezatalischioriginal
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // CHITETEZO: `u.as_mut_ptr()` imalongosola zomwe zidapatsidwa kukumbukira.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Ikani mtengo wa `MaybeUninit<T>`.
    /// Izi zimalemba pamtengo uliwonse wam'mbuyomu osachisiya, chifukwa chake samalani kuti musagwiritse ntchito izi kawiri pokhapokha ngati mukufuna kudumpha pakuwononga.
    ///
    /// Kuti zinthu zikuyendereni bwino, izi zimabweretsanso zosinthika zomwe zingasinthidwe (zomwe tsopano zayambitsidwa bwino) za `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // CHITETEZO: Tangoyambitsa mtengo uwu.
        unsafe { self.assume_init_mut() }
    }

    /// Imapeza cholozera pamtengo womwe ulipo.
    /// Kuwerenga kuchokera pa cholozera ichi kapena kuchisintha kukhala chizindikiritso sichimadziwika pokhapokha `MaybeUninit<T>` itayambitsidwa.
    /// Kulemba kukumbukira kuti pointer iyi ya (non-transitively) imalozera pamakhalidwe osadziwika (kupatula mkati mwa `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Kugwiritsa ntchito bwino njirayi:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Pangani zolemba mu `MaybeUninit<T>`.Izi zili bwino chifukwa tidaziyambitsa.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// Kugwiritsa ntchito njirayi molakwika:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Takhazikitsa kutanthauzira kwa vector yosakhazikika!Izi sizodziwika bwino.@Alirezatalischioriginal
    /// ```
    ///
    /// (Zindikirani kuti malamulo okhudzana ndi zomwe sanatchulidwe sanamalizidwebe, koma mpaka atero, ndibwino kuti muzipewe.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` ndipo `ManuallyDrop` onse ndi `repr(transparent)` kuti titha kupanga pointer.
        self as *const _ as *const T
    }

    /// Imapeza cholozera chosinthika pamtengo womwe ulipo.
    /// Kuwerenga kuchokera pa cholozera ichi kapena kuchisintha kukhala chizindikiritso sichimadziwika pokhapokha `MaybeUninit<T>` itayambitsidwa.
    ///
    /// # Examples
    ///
    /// Kugwiritsa ntchito bwino njirayi:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Pangani zolemba mu `MaybeUninit<Vec<u32>>`.
    /// // Izi zili bwino chifukwa tidaziyambitsa.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// Kugwiritsa ntchito njirayi molakwika:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Takhazikitsa kutanthauzira kwa vector yosakhazikika!Izi sizodziwika bwino.@Alirezatalischioriginal
    /// ```
    ///
    /// (Zindikirani kuti malamulo okhudzana ndi zomwe sanatchulidwe sanamalizidwebe, koma mpaka atero, ndibwino kuti muzipewe.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` ndipo `ManuallyDrop` onse ndi `repr(transparent)` kuti titha kupanga pointer.
        self as *mut _ as *mut T
    }

    /// Amachotsa mtengo kuchokera pachidebe cha `MaybeUninit<T>`.Imeneyi ndi njira yabwino kwambiri yowonetsetsa kuti zidziwitso zatsika, chifukwa `T` yomwe ikutsatiridwayo imagwiritsidwa ntchito nthawi zonse.
    ///
    /// # Safety
    ///
    /// Zili kwa woyimbirayo kuti atsimikizire kuti `MaybeUninit<T>` ilidi yoyambira.Kuyimbira izi pomwe zomwe zili pano sizinayambitsidwe bwino kumayambitsa machitidwe osadziwika bwino.
    /// [type-level documentation][inv] ili ndi zambiri zokhudzana ndi kuyambitsa kumeneku.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Pamwamba pa izo, kumbukirani kuti mitundu yambiri imakhala ndi zowonjezera zowonjezera zomwe sizingangotengedwa kuti zayambitsidwa pamlingo wamtunduwo.
    /// Mwachitsanzo, `1`-initialized [`Vec<T>`] imawerengedwa kuti idayambitsidwa (pakukhazikitsa pano; izi sizikhala chitsimikizo chokhazikika) chifukwa chofunikira chokhacho chomwe wopangirayo amadziwa ndikuti cholozera deta sichiyenera kukhala chopanda pake.
    ///
    /// Kupanga `Vec<T>` yotere sikuyambitsa machitidwe * osakhazikika, koma kumadzetsa machitidwe osadziwika ndi ntchito zotetezeka (kuphatikizapo kuzisiya).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Kugwiritsa ntchito bwino njirayi:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// Kugwiritsa ntchito njirayi molakwika:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` anali asanayambitsidwebe, chifukwa chake mzere womalizawu udadzetsa mawonekedwe osadziwika.Alireza
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // CHITETEZO: woyimbayo ayenera kutsimikizira kuti `self` ndiyoyambitsidwa.
        // Izi zikutanthauzanso kuti `self` iyenera kukhala yosiyana ndi `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Iwerenga mtengo kuchokera pachidebe cha `MaybeUninit<T>`.Zotsatira za `T` zimayang'aniridwa ndikuwonongeka kwanthawi zonse.
    ///
    /// Pomwe zingatheke, ndibwino kugwiritsa ntchito [`assume_init`] m'malo mwake, zomwe zimalepheretsa kubwereza zomwe zili mu `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Zili kwa woyimbirayo kuti atsimikizire kuti `MaybeUninit<T>` ilidi yoyambira.Kuyimbira izi pomwe zomwe zili pano sizinayambitsidwe bwino kumayambitsa machitidwe osadziwika.
    /// [type-level documentation][inv] ili ndi zambiri zokhudzana ndi kuyambitsa kumeneku.
    ///
    /// Kuphatikiza apo, izi zimasiya zolemba zomwezo kumbuyo kwa `MaybeUninit<T>`.
    /// Mukamagwiritsa ntchito ma data angapo (poyimbira `assume_init_read` kangapo, kapena kuyimbira koyamba `assume_init_read` kenako [`assume_init`]), ndiudindo wanu kuwonetsetsa kuti zidziwitsozo zitha kubwerezedwa.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Kugwiritsa ntchito bwino njirayi:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` ndi `Copy`, chifukwa chake titha kuwerenga kangapo.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Kubwereza mtengo wa `None` kuli bwino, chifukwa chake titha kuwerenga kangapo.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// Kugwiritsa ntchito njirayi molakwika:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Tidapanga makope awiri a vector omwewo, ndikupangitsa kuti akhale opanda double️ onse atagwa!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // CHITETEZO: woyimbayo ayenera kutsimikizira kuti `self` ndiyoyambitsidwa.
        // Kuwerenga kuchokera ku `self.as_ptr()` ndikotetezeka popeza `self` iyenera kuyambitsidwa.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Imatsitsa mtengo womwe ulipo.
    ///
    /// Ngati muli ndi `MaybeUninit`, mutha kugwiritsa ntchito [`assume_init`] m'malo mwake.
    ///
    /// # Safety
    ///
    /// Zili kwa woyimbirayo kuti atsimikizire kuti `MaybeUninit<T>` ilidi yoyambira.Kuyimbira izi pomwe zomwe zili pano sizinayambitsidwe bwino kumayambitsa machitidwe osadziwika.
    ///
    /// Pamwamba pa izo, zowonjezera zonse za mtundu wa `T` ziyenera kukhutitsidwa, popeza kukhazikitsidwa kwa `Drop` kwa `T` (kapena mamembala ake) kungadalire izi.
    /// Mwachitsanzo, `1`-initialized [`Vec<T>`] imawerengedwa kuti idayambitsidwa (pakukhazikitsa pano; izi sizikhala chitsimikizo chokhazikika) chifukwa chofunikira chokhacho chomwe wopangirayo amadziwa ndikuti cholozera deta sichiyenera kukhala chopanda pake.
    ///
    /// Kutaya `Vec<T>` yotereyi komabe kumayambitsa machitidwe osadziwika.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // CHITETEZO: woyimbayo ayenera kutsimikizira kuti `self` ndiyoyambitsidwa ndipo
        // imakwaniritsa zosasintha zonse za `T`.
        // Kutaya mtengo m'malo mwake ndikotetezeka ngati ndi choncho.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Ikupeza zomwe zagawidwa pamtengo womwe ulipo.
    ///
    /// Izi zitha kukhala zofunikira tikamafuna kupeza `MaybeUninit` yomwe idayambitsidwa koma mulibe umwini wa `MaybeUninit` (kuletsa kugwiritsa ntchito `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Kuyimbira izi pomwe zomwe zili pano sizinayambitsidwe bwino kumayambitsa machitidwe osadziwika: zili kwa woyimbirayo kuti atsimikizire kuti `MaybeUninit<T>` ili pachiyambi.
    ///
    ///
    /// # Examples
    ///
    /// ### Kugwiritsa ntchito bwino njirayi:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Yambitsani `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Tsopano `MaybeUninit<_>` yathu ikudziwika kuti iyambike, ndibwino kuti tifotokozere zomwezo:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // CHITETEZO: `x` yakhazikitsidwa.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### Kugwiritsa ntchito njirayi molakwika:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Takhazikitsa kutanthauzira kwa vector yosakhazikika!Izi sizodziwika bwino.@Alirezatalischioriginal
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Yambitsani `MaybeUninit` pogwiritsa ntchito `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Kutchula za `Cell<bool>` yosadziwika: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // CHITETEZO: woyimbayo ayenera kutsimikizira kuti `self` ndiyoyambitsidwa.
        // Izi zikutanthauzanso kuti `self` iyenera kukhala yosiyana ndi `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Ikupeza chosinthika chosinthika cha (unique) pamtengo womwe ulipo.
    ///
    /// Izi zitha kukhala zofunikira tikamafuna kupeza `MaybeUninit` yomwe idayambitsidwa koma mulibe umwini wa `MaybeUninit` (kuletsa kugwiritsa ntchito `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Kuyimbira izi pomwe zomwe zili pano sizinayambitsidwe bwino kumayambitsa machitidwe osadziwika: zili kwa woyimbirayo kuti atsimikizire kuti `MaybeUninit<T>` ili pachiyambi.
    /// Mwachitsanzo, `.assume_init_mut()` singagwiritsidwe ntchito kuyambitsa `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Kugwiritsa ntchito bwino njirayi:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Imayambitsa * ma byte onse a cholembera cholowera.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Yambitsani `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Tsopano tikudziwa kuti `buf` idayambitsidwa, chifukwa chake titha kuzichita `.assume_init()`.
    /// // Komabe, kugwiritsa ntchito `.assume_init()` kumatha kuyambitsa `memcpy` ya ma 2048 byte.
    /// // Kuti tiwonetse kuti buffer yathu idayambitsidwa osakopera, timakweza `&mut MaybeUninit<[u8; 2048]>` kukhala `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // CHITETEZO: `buf` yakhazikitsidwa.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Tsopano titha kugwiritsa ntchito `buf` ngati kagawo kakang'ono:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### Kugwiritsa ntchito njirayi molakwika:
    ///
    /// Simungagwiritse ntchito `.assume_init_mut()` kuyambitsa mtengo:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Takhazikitsa kutanthauzira kwa (mutable) kwa `bool` yopanda tanthauzo!
    ///     // Izi sizodziwika bwino.@Alirezatalischioriginal
    /// }
    /// ```
    ///
    /// Mwachitsanzo, simungathe [`Read`] kulowa mu buffer yosadziwika:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) ponena za kukumbukira kosayambika!
    ///                             // Izi sizodziwika bwino.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Kapena simungagwiritse ntchito mwayi wolowera kumunda kuti muchite pang'onopang'ono:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ponena za kukumbukira kosayambika!
    ///                  // Izi sizodziwika bwino.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ponena za kukumbukira kosayambika!
    ///                  // Izi sizodziwika bwino.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Pakadali pano timadalira kuti zomwe tafotokozazi sizolondola, mwachitsanzo, tili ndi zidziwitso zosadziwika (mwachitsanzo, mu `libcore/fmt/float.rs`).
    // Tiyenera kupanga chisankho chomaliza chokhudza malamulowa tisanakhazikike.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // CHITETEZO: woyimbayo ayenera kutsimikizira kuti `self` ndiyoyambitsidwa.
        // Izi zikutanthauzanso kuti `self` iyenera kukhala yosiyana ndi `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Amachotsa malingaliro kuchokera pazinthu zingapo za `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Zili kwa woyimbirayo kuti atsimikizire kuti zinthu zonse zomwe zili mgululi zili pachiyambi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // CHITETEZO: Tsopano tili otetezeka pamene tinayambitsa zinthu zonse
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Woyimbirayo akutsimikizira kuti zinthu zonse zomwe zili mgululi ndizoyambitsidwa
        // * `MaybeUninit<T>` ndipo T akutsimikiziridwa kukhala ndi mawonekedwe omwewo
        // * MwinaUnint siyigwera, chifukwa chake palibe omasulidwa kawiri Ndipo potero kutembenuka kuli kotetezeka
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Poganiza kuti zinthu zonse zimayambitsidwa, pezani chidutswa kwa iwo.
    ///
    /// # Safety
    ///
    /// Zili kwa woyimbirayo kuti atsimikizire kuti zinthu za `MaybeUninit<T>` zili pachiyambi.
    ///
    /// Kuyimbira izi pomwe zomwe zili pano sizinayambitsidwe bwino kumayambitsa machitidwe osadziwika.
    ///
    /// Onani [`assume_init_ref`] kuti mumve zambiri komanso zitsanzo.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // CHITETEZO: Kuponyera kagawo pa `*const [T]` ndikotetezeka popeza amene akukuyimbirani akutsimikizira kuti
        // `slice` imayambitsidwa, ndipo`MwinamwakeUninit` imatsimikiziridwa kukhala ndi mawonekedwe ofanana ndi `T`.
        // Cholozera chopezeka ndicholondola chifukwa chimatanthauza kukumbukira kwa `slice` komwe ndikofotokozera ndipo motero kumatsimikizika kuti ndikofunikira kuwerengera.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Poganiza kuti zinthu zonse zimayambitsidwa, pezani gawo losinthika kwa iwo.
    ///
    /// # Safety
    ///
    /// Zili kwa woyimbirayo kuti atsimikizire kuti zinthu za `MaybeUninit<T>` zili pachiyambi.
    ///
    /// Kuyimbira izi pomwe zomwe zili pano sizinayambitsidwe bwino kumayambitsa machitidwe osadziwika.
    ///
    /// Onani [`assume_init_mut`] kuti mumve zambiri komanso zitsanzo.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // CHITETEZO: zofananira ndi zolemba za `slice_get_ref`, koma tili ndi
        // zosinthika zomwe zimatsimikizidwanso kuti ndizovomerezeka kuti zilembedwe.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Amapeza cholozera ku chinthu choyamba pamndandanda.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Imapeza cholozera chosinthika pachigawo choyamba cha gulu.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Imakopera zinthu kuchokera ku `src` mpaka `this`, ndikubwezeretsanso kusintha kwa zomwe zili mu `this`.
    ///
    /// Ngati `T` silingagwiritse ntchito `Copy`, gwiritsani ntchito [`write_slice_cloned`]
    ///
    /// Izi zikufanana ndi [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Ntchitoyi idzakhala panic ngati magawo awiriwa ali ndi kutalika kosiyana.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // CHITETEZO: tangokopera zinthu zonse za len mu mphamvu zina
    /// // Zinthu zoyambirira za src.len() za vec ndizovomerezeka tsopano.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // CHITETEZO: &[T] ndi&[MaybeUninit<T>] ali ndi chimodzimodzi
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // CHITETEZO: Zinthu zofunikira zangokopedwa kumene mu `this` kotero ndizosavomerezeka
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Imajambula zinthu kuchokera ku `src` mpaka `this`, ndikubwezeretsanso kusintha kwa zomwe zili mu `this`.
    /// Zinthu zilizonse zolowetsedwa sizingachotsedwe.
    ///
    /// Ngati `T` imagwiritsa ntchito `Copy`, gwiritsani ntchito [`write_slice`]
    ///
    /// Izi ndizofanana ndi [`slice::clone_from_slice`] koma sizigwetsa zomwe zidalipo.
    ///
    /// # Panics
    ///
    /// Ntchitoyi idzakhala panic ngati magawo awiriwa ali ndi kutalika kosiyana, kapena ngati kukhazikitsa `Clone` panics.
    ///
    /// Ngati pali panic, zinthu zomwe zapangidwa kale zidzagwetsedwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // CHITETEZO: tangopanga zinthu zonse za len mu mphamvu zopumira
    /// // Zinthu zoyambirira za src.len() za vec ndizovomerezeka tsopano.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // Mosiyana ndi copy_from_slice izi sizitcha clone_from_slice pagawuni ichi ndichifukwa `MaybeUninit<T: Clone>` siyigwiritsa ntchito Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // CHITETEZO: kagawo kakang'ono aka kali ndi zinthu zoyambira zokha
                // ndichifukwa chake, amaloledwa kusiya.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Tiyenera kuwadula momveka mofanana
        // kuti malire awonongeke kuti atuluke, ndipo chowongolera chidzapanga memcpy pamilandu yosavuta (mwachitsanzo T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // Guard amafunika b/c panic itha kuchitika nthawi yoyerekeza
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // CHITETEZO: Zinthu zofunikira zangolembedwa mu `this` chifukwa chake ndizosavomerezeka
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}