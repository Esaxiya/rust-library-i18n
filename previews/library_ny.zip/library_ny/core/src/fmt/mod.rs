//! Zida zopangira ndi kusindikiza zingwe.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// Kusintha komwe kutha kubwerezedwa ndi `Formatter::align`
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Zikuwonetsa kuti zomwe zikuyenerazo ziziyanjanitsidwa kumanzere.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Zikuwonetsa kuti zomwe zikuwonetsedwa zikuyenera kulumikizidwa molondola.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Zikuwonetsa kuti zomwe zikuwonetsedwa ziyenera kulumikizidwa pakatikati.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// Mtunduwo umabwezedwa ndi njira za fomati.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// Mtundu wolakwika womwe umabwezedwa kuchokera pakupanga uthenga kukhala mtsinje.
///
/// Mtunduwu sugwirizana ndikufalitsa cholakwika china kupatula kuti vuto lidachitika.
/// Zambiri zowonjezera ziyenera kukonzedwa kuti zifalitsidwe kudzera munjira zina.
///
/// Chofunika kukumbukira ndikuti mtundu wa `fmt::Error` sayenera kusokonezedwa ndi [`std::io::Error`] kapena [`std::error::Error`], womwe mungakhale nawonso.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// trait yolemba kapena kupangika mu buffers kapena mitsinje yolandila Unicode.
///
/// trait iyi imangovomereza zokhoma zosungidwa za UTF-8 ndipo si [flushable].
/// Ngati mukungofuna kulandira Unicode ndipo simukusowa kukankha, muyenera kugwiritsa ntchito trait;
/// apo ayi muyenera kukhazikitsa [`std::io::Write`].
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// Amalemba chidutswa cha chingwe mwa wolemba uyu, ndikubwezeretsanso ngati kulembako kwachita bwino.
    ///
    /// Njirayi imatha kuchita bwino ngati chidutswa chonse cha chingwe chidalembedwa bwino, ndipo njirayi siyingabwerere kufikira pomwe zonse zalembedwa kapena vuto litachitika.
    ///
    ///
    /// # Errors
    ///
    /// Ntchitoyi ibwezeretsanso [`Error`] yolakwika.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// Amalemba [`char`] mwa wolemba uyu, ndikubwezera ngati kulembako kwapambana.
    ///
    /// [`char`] imodzi imatha kulembedwa ngati ma byte angapo.
    /// Njirayi imatha kuchita bwino pokhapokha momwe zolembedwazo zidalembedwera bwino, ndipo njirayi siyingabwerere kufikira pomwe zonse zalembedwa kapena vuto litachitika.
    ///
    ///
    /// # Errors
    ///
    /// Ntchitoyi ibwezeretsanso [`Error`] yolakwika.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// Guluu wogwiritsa ntchito [`write!`] macro ndi omwe akuyambitsa trait iyi.
    ///
    /// Njirayi sikuyenera kuyitanidwa pamanja, koma kudzera pa [`write!`] macro yomwe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// Kusintha kwamapangidwe.
///
/// `Formatter` imayimira zosankha zingapo zokhudzana ndi kupanga.
/// Ogwiritsa ntchito samapanga `Formatter`s mwachindunji;kutanthauzira kosinthika kumodzi kwadutsa njira ya `fmt` yopanga traits, monga [`Debug`] ndi [`Display`].
///
///
/// Kuti mulumikizane ndi `Formatter`, mudzayimba njira zosiyanasiyana kuti musinthe zosankha zingapo zokhudzana ndi kupanga.
/// Kwa zitsanzo, chonde onani zolemba za njira zomwe zafotokozedwa pa `Formatter` pansipa.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// Kutsutsana ndiko ntchito yokometsera pang'ono, yofanana ndi `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result`.

extern "C" {
    type Opaque;
}

/// Izi zikuyimira generic "argument" yomwe imatengedwa ndi banja la Xprintf la ntchito.Lili ndi ntchito yosanja mtengo womwe wapatsidwa.
/// Pakukonzekera nthawi kumatsimikiziridwa kuti ntchito ndi phindu zimakhala ndi mitundu yolondola, kenako izi zimagwiritsidwa ntchito pokonza zotsutsana ndi mtundu umodzi.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// Izi zimatsimikizira phindu limodzi lokhazikika pa pointer yogwirira ntchito yolumikizidwa ndi indices/counts muzomangamanga.
//
// Dziwani kuti ntchito yotanthauziridwa motere siyingakhale yolondola popeza nthawi zonse ntchito imadziwika kuti sanatchulidwe dzina_addr ndikutsitsidwa kwa LLVM IR, chifukwa chake adilesi yawo sikuwoneka ngati yofunikira kwa LLVM motero as_usize cast akanatha kusokonezedwa.
//
// Mwachizoloŵezi, sitimayitanitsa as_usize pazosagwiritsa ntchito zomwe zili ndi data (monga m'badwo wokhazikika wazokambirana), kotero ichi ndi cheke chowonjezera.
//
// Tikufuna makamaka kuwonetsetsa kuti pointer ya ntchito ku `USIZE_MARKER` ili ndi adilesi yofanana ndi *yokha* kuntchito zomwe zimatengera `&usize` ngati mkangano wawo woyamba.
// Read_volatile pano ikuwonetsetsa kuti titha kukonza bwino ndalama kuchokera pazomwe tadutsazo ndikuti adilesi iyi sikuloza kuchitapo kanthu kosagwiritsa ntchito usize.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // CHITETEZO: ptr ndikulozera
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // CHITETEZO: `mem::transmute(x)` ndiyabwino chifukwa
        //     1. `&'b T` amasunga nthawi yonse yomwe adayamba ndi `'b` (kuti asakhale ndi moyo wopanda malire)
        //     2.
        //     `&'b T` ndipo `&'b Opaque` ali ndi chikumbukiro chimodzimodzi (pomwe `T` ndi `Sized`, monga ilili pano) `mem::transmute(f)` ndiyotetezeka popeza `fn(&T, &mut Formatter<'_>) -> Result` ndi `fn(&Opaque, &mut Formatter<'_>) -> Result` ali ndi ABI omwewo (bola `T` ndi `Sized`)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // CHITETEZO: Munda wa `formatter` umangokhazikitsidwa ku USIZE_MARKER ngati
            // Mtengowo ndi usize, chifukwa chake izi ndi zotetezeka
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// mbendera zomwe zilipo mu mtundu wa v1 wa format_args
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// Mukamagwiritsa ntchito mtundu wa format_args! (), Ntchitoyi imagwiritsidwa ntchito popanga zokangana.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// Ntchitoyi imagwiritsidwa ntchito kufotokozera magawo osasanjidwa.
    /// Gulu la `pieces` liyenera kukhala lokulirapo ngati `fmt` kuti likhale ndi zomangika zoyenera.
    /// Komanso, `Count` iliyonse mkati mwa `fmt` yomwe ndi `CountIsParam` kapena `CountIsNextParam` iyenera kuloza kutsutsana komwe kudapangidwa ndi `argumentusize`.
    ///
    /// Komabe, kulephera kutero sikuyambitsa chitetezo, koma kunyalanyaza zosayenera.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// Kuyerekeza kutalika kwa zomwe zalembedwa.
    ///
    /// Izi zapangidwa kuti zigwiritsidwe ntchito kukhazikitsa mphamvu yoyamba ya `String` mukamagwiritsa ntchito `format!`.
    /// Note: awa siam'munsi kapena apamwamba.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // Ngati chingwecho chikuyamba ndikutsutsana, osakhazikitsanso chilichonse, pokhapokha kutalika kwa zidutswa ndikofunikira.
            //
            //
            0
        } else {
            // Pali zotsutsana, chifukwa chowonjezera chilichonse chitha kusinthanso chingwe.
            //
            // Pofuna kupewa izi, ndife "pre-doubling" mphamvu pano.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// Kapangidwe kameneka kakuyimira mtundu wa chingwe cholinganizidwa bwino ndi zifukwa zake.
/// Izi sizingapangidwe nthawi yothamanga chifukwa sizingachitike mosamala, chifukwa chake palibe omanga omwe amapatsidwa ndipo minda ndiyokha kuti isasinthe.
///
///
/// Macro [`format_args!`] ipanga bwino mawonekedwe amtunduwu.
/// Macro amatsimikizira mtundu wa fomati panthawi yakusonkhanitsa kuti kugwiritsidwa ntchito kwa ntchito za [`write()`] ndi [`format()`] zitha kuchitidwa bwino.
///
/// Mutha kugwiritsa ntchito `Arguments<'a>` yomwe [`format_args!`] imabwerera mu `Debug` ndi `Display` momwe tawonera pansipa.
/// Chitsanzocho chikuwonetsanso kuti `Debug` ndi `Display` zimapangira chinthu chomwecho: chingwe cholumikizidwa mu `format_args!`.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // Sinthani zidutswa zazingwe kuti musindikize.
    pieces: &'a [&'static str],

    // Ma specsholder, kapena `None` ngati ma specs onse ali osasintha (monga "{}{}").
    fmt: Option<&'a [rt::v1::Argument]>,

    // Zoyeserera zamphamvu pakuphatikizira, kuti zilumikizidwe ndi zingwe zazingwe.
    // (Kutsutsana kulikonse kumayendetsedwa ndi kachingwe.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// Pezani chingwecho, ngati chilibe zifukwa zoti musinthe.
    ///
    /// Izi zitha kugwiritsidwa ntchito popewa kugawa pazinthu zazing'ono kwambiri.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` iyenera kupanga mtundu wazomwe zikuwonetsedwa poyang'ana pulogalamu, ndikuwonetsetsa.
///
/// Nthawi zambiri, muyenera kungokhala `derive` kukhazikitsa `Debug`.
///
/// Pogwiritsidwa ntchito ndi mtundu wina wa mtundu wa `#?`, zotulukazo ndizosindikizidwa bwino.
///
/// Kuti mumve zambiri zamapangidwe, onani [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// trait iyi itha kugwiritsidwa ntchito ndi `#[derive]` ngati magawo onse agwiritsa ntchito `Debug`.
/// Pomwe `derive`d for structs, idzagwiritsa ntchito dzina la `struct`, kenako `{`, kenako mndandanda wosiyanitsidwa ndi koma wa dzina lililonse lamundawu ndi mtengo wa `Debug`, kenako `}`.
/// Kwa `enum`s, idzagwiritsa ntchito dzina la zosinthazo ndipo, ngati zingatheke, `(`, ndiye ma `Debug` aminda, kenako `)`.
///
/// # Stability
///
/// Zithunzi zochokera `Debug` sizakhazikika, ndipo zimatha kusintha ndi mitundu ya future Rust.
/// Kuphatikiza apo, kukhazikitsa kwa `Debug` kwamitundu yoperekedwa ndi laibulale yanthawi zonse (`libstd`, `libcore`, `liballoc`, etc.) sikukhazikika, ndipo kumatha kusintha ndi mitundu ya future Rust.
///
///
/// # Examples
///
/// Kupeza kukhazikitsa:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Kukhazikitsa:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Pali njira zingapo zothandizira pa [`Formatter`] struct kuti zikuthandizireni pakukhazikitsa, monga [`debug_struct`].
///
/// `Debug` Kukhazikitsa pogwiritsa ntchito `derive` kapena debug builder API pa [`Formatter`] kuthandizira kusindikiza bwino pogwiritsa ntchito mbendera ina: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// Kusindikiza kokongola ndi `#?`:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// Imapanga mtengo pogwiritsa ntchito mtundu wopatsidwa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// Gawani gawo kuti mutumizenso macro `Debug` kuchokera ku prelude popanda trait `Debug`.
pub(crate) mod macros {
    /// Pezani zazikulu zomwe zikupanga trait `Debug`.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// Pangani trait za mtundu wopanda kanthu, `{}`.
///
/// `Display` ndi ofanana ndi [`Debug`], koma `Display` ndiyotulutsa komwe kumayang'ana ogwiritsa ntchito, motero sikungachokere.
///
///
/// Kuti mumve zambiri zamapangidwe, onani [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Kukhazikitsa `Display` pamtundu:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// Imapanga mtengo pogwiritsa ntchito mtundu wopatsidwa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` trait iyenera kupanga mtundu wake ngati nambala mu base-8.
///
/// Kwa manambala akale osainidwa (`i8` mpaka `i128`, ndi `isize`), zoyipa zoyipa zimapangidwa monga mawonekedwe oyenerana.
///
///
/// Mbendera ina, `#`, imaphatikiza `0o` patsogolo pazotulutsa.
///
/// Kuti mumve zambiri zamapangidwe, onani [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Kugwiritsa ntchito kwenikweni ndi `i32`:
///
/// ```
/// let x = 42; // 42 ndi '52' mu octal
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// Kukhazikitsa `Octal` pamtundu:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // nthumwi kuti ikwaniritse i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// Imapanga mtengo pogwiritsa ntchito mtundu wopatsidwa.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait iyenera kupanga mtundu wazotsatira zake ngati nambala yabwinoko.
///
/// Kwa manambala akale osainidwa ([`i8`] mpaka [`i128`], ndi [`isize`]), zoyipa zoyipa zimapangidwa monga mawonekedwe oyenerana.
///
///
/// Mbendera ina, `#`, imaphatikiza `0b` patsogolo pazotulutsa.
///
/// Kuti mumve zambiri zamapangidwe, onani [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Kugwiritsa ntchito kwenikweni ndi [`i32`]:
///
/// ```
/// let x = 42; // 42 ndi '101010' posankha
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// Kukhazikitsa `Binary` pamtundu:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // nthumwi kuti ikwaniritse i32
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// Imapanga mtengo pogwiritsa ntchito mtundu wopatsidwa.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` trait iyenera kupanga mtundu wake ngati nambala mu hexadecimal, ndi `a` kudzera `f` pamunsi.
///
/// Kwa manambala akale osainidwa (`i8` mpaka `i128`, ndi `isize`), zoyipa zoyipa zimapangidwa monga mawonekedwe oyenerana.
///
///
/// Mbendera ina, `#`, imaphatikiza `0x` patsogolo pazotulutsa.
///
/// Kuti mumve zambiri zamapangidwe, onani [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Kugwiritsa ntchito kwenikweni ndi `i32`:
///
/// ```
/// let x = 42; // 42 ndi '2a' mu hex
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// Kukhazikitsa `LowerHex` pamtundu:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // nthumwi kuti ikwaniritse i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// Imapanga mtengo pogwiritsa ntchito mtundu wopatsidwa.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait iyenera kupanga mtundu wake ngati nambala mu hexadecimal, ndi `A` kudzera `F` pamwambapa.
///
/// Kwa manambala akale osainidwa (`i8` mpaka `i128`, ndi `isize`), zoyipa zoyipa zimapangidwa monga mawonekedwe oyenerana.
///
///
/// Mbendera ina, `#`, imaphatikiza `0x` patsogolo pazotulutsa.
///
/// Kuti mumve zambiri zamapangidwe, onani [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Kugwiritsa ntchito kwenikweni ndi `i32`:
///
/// ```
/// let x = 42; // 42 ndi '2A' mu hex
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// Kukhazikitsa `UpperHex` pamtundu:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // nthumwi kuti ikwaniritse i32
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// Imapanga mtengo pogwiritsa ntchito mtundu wopatsidwa.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait iyenera kupanga zojambula zake ngati malo okumbukira.
/// Izi zimawonetsedwa ngati hexadecimal.
///
/// Kuti mumve zambiri zamapangidwe, onani [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Kugwiritsa ntchito kwenikweni ndi `&i32`:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // izi zimapanga china chonga '0x7f06092ac6d0'
/// ```
///
/// Kukhazikitsa `Pointer` pamtundu:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // gwiritsani ntchito `as` kuti musinthe kukhala `*const T`, yomwe imagwiritsa ntchito Pointer, yomwe titha kugwiritsa ntchito
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// Imapanga mtengo pogwiritsa ntchito mtundu wopatsidwa.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// `LowerExp` trait iyenera kupanga zolemba zake musayansi ndi `e` yocheperako.
///
/// Kuti mumve zambiri zamapangidwe, onani [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Kugwiritsa ntchito kwenikweni ndi `f64`:
///
/// ```
/// let x = 42.0; // 42.0 ndi '4.2e1' mu notation yasayansi
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// Kukhazikitsa `LowerExp` pamtundu:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // nthumwi ku kukhazikitsidwa kwa f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// Imapanga mtengo pogwiritsa ntchito mtundu wopatsidwa.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` trait iyenera kupanga zolemba zake mwasayansi ndi `E` wapamwamba.
///
/// Kuti mumve zambiri zamapangidwe, onani [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Kugwiritsa ntchito kwenikweni ndi `f64`:
///
/// ```
/// let x = 42.0; // 42.0 ndi '4.2E1' pamalemba asayansi
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// Kukhazikitsa `UpperExp` pamtundu:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // nthumwi ku kukhazikitsidwa kwa f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// Imapanga mtengo pogwiritsa ntchito mtundu wopatsidwa.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// Ntchito ya `write` imatenga njira yotulutsa, ndi `Arguments` struct yomwe imatha kupangika ndi `format_args!` macro.
///
///
/// Zotsutsanazo zitha kupangidwa molingana ndi chingwe chomwe chafotokozedwacho mumtsinje womwe waperekedwa.
///
/// # Examples
///
/// Kagwiritsidwe:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// Chonde dziwani kuti kugwiritsa ntchito [`write!`] kungakhale kotheka.Chitsanzo:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // Titha kugwiritsa ntchito mafomati osasintha pazokambirana zonse.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // Chilichonse chimakhala ndi mfundo yofananira yomwe idatsogoleredwa ndi chingwe.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // CHITETEZO: arg ndi args.args zimachokera kuzifukwa zomwezo,
                // zomwe zimatsimikizira kuti ma index nthawi zonse amakhala m'malire.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // Pakhoza kukhala chidutswa chimodzi chachingwe chotsalira.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // CHITETEZO: Arg ndi args amachokera ku Mlandu womwewo,
    // zomwe zimatsimikizira kuti ma index nthawi zonse amakhala m'malire.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // Chotsani mkangano wolondola
    debug_assert!(arg.position < args.len());
    // CHITETEZO: Arg ndi args amachokera ku Mlandu womwewo,
    // zomwe zimatsimikizira kuti index yake nthawi zonse imakhala m'malire.
    let value = unsafe { args.get_unchecked(arg.position) };

    // Ndiye kusindikiza
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // CHITETEZO: cnt ndi args zimachokera ku Mlandu womwewo,
            // zomwe zimatsimikizira kuti index iyi nthawi zonse imakhala m'malire.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// Kuyenda kumapeto kwa china chake.Kubwezeredwa ndi `Formatter::padding`.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// Lembani izi positi padding.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // Tikufuna kusintha izi
            buf: wrap(self.buf),

            // Ndipo sungani izi
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // Njira zothandizira zomwe zimagwiritsidwa ntchito popanga ndikusintha zokongoletsa zomwe mitundu yonse ya traits ingagwiritse ntchito.
    //

    /// Imapanga padding yolondola pamanambala omwe atulutsidwa kale mu str.
    /// The str sayenera * kukhala ndi chikwangwani chokwanira, chomwe chiziwonjezedwa ndi njirayi.
    ///
    /// # Arguments
    ///
    /// * ndi_osatsutsika, ngakhale kuchuluka kwathunthu koyambirira kunali koyenera kapena kotheka.
    /// * manambala oyamba, ngati chilembo cha '#' (Alternate) chaperekedwa, ichi ndiye chiyambi choyikapo kutsogolo kwa nambala.
    ///
    /// * buf, mndandanda wazomwe nambala idapangidwira
    ///
    /// Ntchitoyi idzawerengera bwino mbendera zomwe zaperekedwa komanso m'lifupi mwake.
    /// Sizingatenge mwatsatanetsatane.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // Tiyenera kuchotsa "-" kuchokera pamanambala.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // Amalemba chizindikirocho ngati chilipo, ndiyeno manambala oyamba ngati angafunike
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // Munda wa `width` ndiwowonjezera wa `min-width` pano.
        match self.width {
            // Ngati palibe zofunikira zazitali kutalika ndiye kuti titha kungolemba ma byte.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Onetsetsani ngati tapitilira m'lifupi, ngati ndi choncho titha kungolemba ma byte.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Chizindikiro ndi choyambirira chimapita patsogolo pa padding ngati mawonekedwe akudzaza ndi zero
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // Kupanda kutero, chikwangwani ndi choyambirira zimatsata padding
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Ntchitoyi imatenga chidutswa cha zingwe ndikuchipereka kubotolo lamkati mutagwiritsa ntchito mbendera zoyenera.
    /// Mbendera zomwe zimadziwika ndi zingwe zodziwika bwino ndi izi:
    ///
    /// * m'lifupi, m'lifupi mwake pazomwe muyenera kutulutsa
    /// * fill/align - choti mutulutse komanso kuti mutulutse kuti chingwe chomwe chaperekedwa chikufunika kuti chikwere
    /// * molondola, kutalika kwakutali kuti atulutse, chingwecho chimadulidwa ngati chachitali kuposa kutalika uku
    ///
    /// Makamaka ntchitoyi imanyalanyaza magawo a `flag`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // Onetsetsani kuti pali njira yachangu kutsogolo
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // Munda wa `precision` ukhoza kutanthauziridwa ngati `max-width` pa chingwe chomwe chidapangidwa.
        //
        let s = if let Some(max) = self.precision {
            // Ngati zingwe zathu ndizotalika molingana, ndiye kuti tiyenera kukhala ndi truncation.
            // Komabe mbendera zina monga `fill`, `width` ndi `align` ziyenera kuchita monga nthawi zonse.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // LLVM pano sichingatsimikizire kuti `..i` sichichita panic `&s[..i]`, koma tikudziwa kuti sichingakhale panic.
                // Gwiritsani ntchito `get` + `unwrap_or` kupewa `unsafe` ndipo ngati simutulutsa nambala iliyonse yokhudzana ndi panic apa.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // Munda wa `width` ndiwowonjezera wa `min-width` pano.
        match self.width {
            // Ngati tili pansi pazitali zazitali, ndipo palibe zosowa zazitali, ndiye kuti titha kungotulutsa chingwe
            //
            None => self.buf.write_str(s),
            // Ngati tili m'lifupi kwambiri, onetsetsani ngati tapitirira m'lifupi, ngati ndizosavuta ndikungotulutsa chingwecho.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // Ngati tili pansi pazitali komanso zazitali m'lifupi, ndiye lembani m'lifupi ndi chingwe chofotokozedwacho + mayikidwe ena.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Lembani zisanachitike ndikubwezeretsani zosalemba pambuyo pake.
    /// Oyimbira ali ndi udindo wowonetsetsa kuti zolembedwako zalembedwa pambuyo pazinthu zomwe zikudulidwa.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// Imatenga magawo omwe asinthidwa ndikugwiritsa ntchito padding.
    /// Kungoganiza kuti woyimbirayo wapereka kale ziwalozo molondola, kuti `self.precision` isanyalanyazidwe.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // pa zero padding yozindikira, timapereka chizindikirocho poyamba ndikukhala ngati tilibe chizindikiro kuyambira pachiyambi.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // chizindikiro nthawi zonse chimapita poyamba
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // chotsani chizindikirocho pazinthu zosanjidwa
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // Magawo otsala amapyola pamachitidwe wamba.
            let len = formatted.len();
            let ret = if width <= len {
                // palibe padding
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // Izi ndizofala ndipo timatenga njira yachidule
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // CHITETEZO: Izi zimagwiritsidwa ntchito pa `flt2dec::Part::Num` ndi `flt2dec::Part::Copy`.
            // Ndizotetezeka kugwiritsa ntchito `flt2dec::Part::Num` popeza char `c` iliyonse ili pakati pa `b'0'` ndi `b'9'`, zomwe zikutanthauza kuti `s` ndi UTF-8 yoyenera.
            // Ndizothekanso kugwiritsa ntchito `flt2dec::Part::Copy(buf)` popeza `buf` iyenera kukhala yomveka bwino ASCII, koma ndizotheka kuti wina adutse `buf` kukhala `flt2dec::to_shortest_str` popeza ndi ntchito yapagulu.
            //
            // FIXME: Sankhani ngati izi zitha kubweretsa UB.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // Zero 64
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// Amalemba zina pamtundu wazomwe zili mufomuyi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // Izi ndizofanana ndi:
    ///         // lembani! (mtundu, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// Amalemba zambiri zosanjidwa panthawiyi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// Mbendera zopangira mawonekedwe
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// Khalidwe logwiritsidwa ntchito ngati 'fill' paliponse pali mayendedwe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // Timakhazikika kumanja ndi ">".
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// Mbendera yosonyeza mtundu wamayendedwe omwe adapemphedwa.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// Kutanthauzira kosankha mwanjira zonse zomwe ziyenera kutulutsidwa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // Ngati talandila m'lifupi, timagwiritsa ntchito
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // Kupanda kutero sitimachita chilichonse chapadera
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// Makonda osankhidwa mwanjira zosiyanasiyana.
    /// Kapenanso, m'lifupi mwake pazingwe zamtundu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // Ngati talandira molondola, timagwiritsa ntchito.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // Kupanda kutero timasinthira 2.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// Ikuwona ngati mbendera ya `+` idatchulidwa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// Ikuwona ngati mbendera ya `-` idatchulidwa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // Mukufuna chizindikiro chochotsera?Khalani ndi imodzi!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// Ikuwona ngati mbendera ya `#` idatchulidwa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// Ikuwona ngati mbendera ya `0` idatchulidwa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // Timanyalanyaza zomwe mtunduwo ungasankhe.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: Sankhani mtundu wa API womwe tikufuna pa mbendera ziwirizi.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// Amapanga zomangamanga [`DebugStruct`] zopangidwa kuti zithandizire pakupanga kukhazikitsa kwa [`fmt::Debug`] kwa ma structs.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// Amapanga zomangamanga `DebugTuple` zopangidwa kuti zithandizire pakupanga kukhazikitsa kwa `fmt::Debug` kwa ma tuple structs.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// Amapanga zomangamanga `DebugList` zopangidwa kuti zithandizire pakupanga kukhazikitsa kwa `fmt::Debug` kwamitundu yofanana ndindandanda.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// Zimapanga zomangamanga `DebugSet` zopangidwa kuti zithandizire pakupanga kukhazikitsa kwa `fmt::Debug` kwa zinthu zofananira.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// Mu chitsanzo chovuta kwambiri, timagwiritsa ntchito [`format_args!`] ndi `.debug_set()` kupanga mndandanda wazida zofananira:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// Amapanga zomangamanga `DebugMap` zopangidwa kuti zithandizire pakupanga kukhazikitsa kwa `fmt::Debug` kwa mapangidwe ofanana ndi mapu.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// Kukhazikitsa kwa mtundu wapamwamba wa traits

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // Ngati char ikufunika kuthawa, kubwerera kumbuyo mpaka pano ndikulemba, apo ayi tulukani
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // Mbendera ina yothandizidwa kale ndi LowerHex ngati yapadera-imatanthauzira ngati kuyika patsogolo ndi 0x.
        // Timagwiritsa ntchito kuti tidziwe ngati tikufutukula zero kapena ayi, kenako nkuzikhazikitsa mwamwayi kuti tipeze choyambirira.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// Kukhazikitsa kwa Display/Debug yamitundu yosiyanasiyana

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // RefCell imalandiridwa kotero kuti sitingayang'ane phindu lake apa.
                // Onetsani chotengera m'malo.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// Ngati mukuyembekeza kuti mayesero abwera pano, osayang'ana fayilo ya core/tests/fmt.rs, ndizosavuta kuposa kupangira zida zonse za rt::Piece pano.
//
// Palinso mayeso mgawo la crate, kwa iwo omwe amafunikira magawo.