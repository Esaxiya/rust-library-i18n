//! Iyi ndi gawo lamkati logwiritsidwa ntchito ndi ifmt!nthawi yothamanga.Nyumbazi zimatumizidwa kuzinthu zosanjikiza kuti zikhazikitse zingwe zamtundu pasadakhale.
//!
//! Matanthauzowa ndi ofanana ndi ma `ct` ofanana nawo, koma amasiyana chifukwa awa amatha kugawidwa mofananamo ndipo amakwaniritsidwa pang'ono panthawi yothamanga
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Zosintha zomwe zingapemphedwe ngati gawo la malangizo.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Zikuwonetsa kuti zomwe zikuyenerazo ziziyanjanitsidwa kumanzere.
    Left,
    /// Zikuwonetsa kuti zomwe zikuwonetsedwa zikuyenera kulumikizidwa molondola.
    Right,
    /// Zikuwonetsa kuti zomwe zikuwonetsedwa ziyenera kulumikizidwa pakatikati.
    Center,
    /// Palibe mayikidwe omwe adafunsidwa.
    Unknown,
}

/// Amagwiritsidwa ntchito ndi [width](https://doc.rust-lang.org/std/fmt/#width) ndi [precision](https://doc.rust-lang.org/std/fmt/#precision) otchulira.
#[derive(Copy, Clone)]
pub enum Count {
    /// Yotchulidwa ndi nambala yeniyeni, imasunga mtengo
    Is(usize),
    /// Yotchulidwa pogwiritsa ntchito ma syntax a `$` ndi `*`, imasunga index mu `args`
    Param(usize),
    /// Zomwe sizinafotokozedwe
    Implied,
}