#![stable(feature = "futures_api", since = "1.36.0")]

//! Makhalidwe asynchronous.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Mtundu uwu ukufunika chifukwa:
///
/// a) Makina opanga sangagwiritse ntchito `for<'a, 'b> Generator<&'a mut Context<'b>>`, chifukwa chake tiyenera kudutsa pointer yaiwisi (onani <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Zoyimira zazikulu ndi `NonNull` sizili `Send` kapena `Sync`, kotero izi zitha kupanganso future non-Send/Sync iliyonse, ndipo sitikufuna.
///
/// Zimathandizanso kutsitsa kwa HIR kwa `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Manga jenereta mu future.
///
/// Ntchitoyi imabweza `GenFuture` pansi, koma imabisa mu `impl Trait` kuti ipereke mauthenga olakwika (`impl Future` osati `GenFuture<[closure.....]>`).
///
// Izi ndi `const` kuti tipewe zolakwika zina titachira ku `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Timadalira kuti async/await futures ndiyosunthika kuti ipange ngongole zodziyimira pawokha mu jenereta yoyambira.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // CHITETEZO: Ndife otetezeka chifukwa ndife !Unpin + !Drop, ndipo awa ndi malingaliro chabe pamunda.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Yambitsaninso jenereta, ndikusintha `&mut Context` kukhala cholembera cha `NonNull` yaiwisi.
            // Kutsika kwa `.await` kudzabwezeretsa bwinobwino ku `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // CHITETEZO: woyimbayo ayenera kutsimikizira kuti `cx.0` ndi cholozera chovomerezeka
    // zomwe zimakwaniritsa zofunikira zonse kuti muthe kusintha.
    unsafe { &mut *cx.0.as_ptr().cast() }
}