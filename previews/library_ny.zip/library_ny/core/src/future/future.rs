#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future imayimira kuwerengera kofananira.
///
/// future ndi mtengo womwe mwina sunamalize kugwiritsa ntchito kompyuta pano.
/// "asynchronous value" yamtunduwu imapangitsa kuti ulusi upitilize kugwira ntchito yothandiza podikirira kuti mtengo upezeke.
///
///
/// # Njira ya `poll`
///
/// Njira yayikulu ya future, `poll`,*kuyesa* kuthana ndi future kukhala mtengo womaliza.
/// Njirayi siyimitsa ngati mtengowo sunakonzekere.
/// M'malo mwake, ntchito yomwe ilipo pakadali pano iyenera kudzutsidwa ngati kuli kotheka kupita patsogolo mwa 'kuvotanso.
/// `context` yodutsa njira ya `poll` itha kupereka [`Waker`], yomwe ndi chogwirira chodzutsa ntchito yomwe ilipo.
///
/// Mukamagwiritsa ntchito future, simumayimbira `poll` mwachindunji, koma m'malo mwake `.await` mtengo.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Mtundu wamtengo womwe umapangidwa pomaliza.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Yesetsani kuthetsa future pamtengo wotsiriza, kulembetsa ntchito yomwe ilipo pakudzuka ngati mtengo ulibe.
    ///
    /// # Bweretsani mtengo
    ///
    /// Ntchitoyi ibwerera:
    ///
    /// - [`Poll::Pending`] ngati future sinakonzekerebe
    /// - [`Poll::Ready(val)`] ndi zotsatira `val` za future ngati zatha bwino.
    ///
    /// future ikangomaliza, makasitomala sayenera `poll` kachiwiri.
    ///
    /// future ikadakonzeka, `poll` imabwezeretsa `Poll::Pending` ndikusunga choyerekeza cha [`Waker`] chojambulidwa kuchokera ku [`Context`] yapano.
    /// [`Waker`] iyi imadzutsidwa kamodzi future itatha kupita patsogolo.
    /// Mwachitsanzo, future yodikirira kuti socket izitha kuwerengedwa imatha kuyimbira `.clone()` pa [`Waker`] ndikuisunga.
    /// Chizindikiro chikabwera kwinakwake chosonyeza kuti sokosayo ndi yowerengeka, [`Waker::wake`] imayitanidwa ndipo ntchito ya future imadzutsidwa.
    /// Ntchito ikadzutsidwa, iyenera kuyesa `poll` future kachiwiri, yomwe ikhoza kutulutsa mtengo womaliza.
    ///
    /// Dziwani kuti pama foni angapo kupita ku `poll`, ndi [`Waker`] yokha kuchokera ku [`Context`] yomwe idadutsa pa foni yaposachedwa kwambiri yomwe iyenera kukonzekeredwa.
    ///
    /// # Makhalidwe oyendetsa nthawi
    ///
    /// Futures zokha ndi *inert*;Ayenera kufufuzidwa *mwachangu* kuti apite patsogolo, kutanthauza kuti nthawi iliyonse yomwe ntchitoyi ikuwukitsidwa, iyenera kubwezeretsanso ``posankha`0 podikira futures yomwe ikadali ndi chidwi nayo.
    ///
    /// Ntchito ya `poll` siyimayitanidwa mobwerezabwereza mozungulira-m'malo mwake, imayenera kuyitanidwa pokhapokha future ikuwonetsa kuti yakonzeka kupita patsogolo (poyimbira `wake()`).
    /// Ngati mumadziwa bwino za `poll(2)` kapena `select(2)` pa Unix ndikuyenera kudziwa kuti futures nthawi zambiri samachita nawo zovuta za "all wakeups must poll all events";ali ngati `epoll(4)`.
    ///
    /// Kukhazikitsa `poll` kuyenera kuyesetsa kubwerera mwachangu, ndipo sikuyenera kutseka.Kubwerera mwachangu kumateteza kutchinga ulusi kapena zolakwika mosafunikira.
    /// Ngati zikudziwikiratu kuti kuyimbira `poll` kumatha kutenga kanthawi, ntchitoyi iyenera kuperekedwera padziwe la ulusi (kapena zina zofananira) kuti zitsimikizire kuti `poll` ikhoza kubwerera mwachangu.
    ///
    /// # Panics
    ///
    /// future ikamaliza (kubweza `Ready` kuchokera ku `poll`), kuyitanitsa njira yake ya `poll` mwina panic, kutchinga kwamuyaya, kapena kuyambitsa mavuto ena;`Future` trait siyikaika zofunikira pazakuyimba koteroko.
    /// Komabe, popeza njira ya `poll` sinatchulidwe `unsafe`, malamulo abwinobwino a Rust amagwiranso ntchito: mayimbidwe sayenera kuyambitsa machitidwe osadziwika (chikumbukiro chakumbuyo, kugwiritsa ntchito molakwika ntchito za `unsafe`, kapena zina zotero), mosasamala kanthu za dziko la future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}