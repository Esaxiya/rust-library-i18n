//! Zolemba za prelude
//!
//! Gawoli lithandizira ogwiritsa ntchito libcore omwe samalumikizanso ndi libstd.
//! Gawoli limatumizidwa mwachisawawa `#![no_std]` ikagwiritsidwa ntchito chimodzimodzi ndi laibulale ya prelude.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Mtundu wa 2015 wa prelude.
///
/// Onani [module-level documentation](self) kuti mumve zambiri.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Mtundu wa 2018 wa pachimake prelude.
///
/// Onani [module-level documentation](self) kuti mumve zambiri.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Mtundu wa 2021 wachimake prelude.
///
/// Onani [module-level documentation](self) kuti mumve zambiri.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Onjezani zinthu zina.
}