//! Ntchito zaulere kuti apange `&[T]` ndi `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Pangani kagawo kuchokera pa pointer ndi kutalika.
///
/// Mtsutso wa `len` ndi chiwerengero cha **zinthu**, osati kuchuluka kwa mabayiti.
///
/// # Safety
///
/// Khalidwe silimadziwika ngati izi zikuphwanyidwa:
///
/// * `data` iyenera kukhala [valid] yowerengera ma `len * mem::size_of::<T>()` ma byte ambiri, ndipo iyenera kulumikizidwa bwino.Izi zikutanthauza makamaka:
///
///     * Kukumbukira konse kwa chidutswa ichi kuyenera kukhala mkati mwa chinthu chimodzi chogawa!
///       Magawo sangadutse pazinthu zingapo zomwe zapatsidwa.Onani [below](#incorrect-usage) mwachitsanzo molakwika osaganizira izi.
///     * `data` sayenera kukhala yopanda tanthauzo komanso yolumikizana ngakhale ndi magawo a zero-kutalika.
///     Chimodzi mwazifukwa za izi ndikuti kukhathamiritsa kwa enum kumatha kudalira mafotokozedwe (kuphatikiza magawo amtundu uliwonse) osakanikirana komanso osachita kusiyanitsa ndi zina.
///     Mutha kupeza pointer yomwe imagwiritsidwa ntchito ngati `data` yamagawo otalika zero pogwiritsa ntchito [`NonNull::dangling()`].
///
/// * `data` iyenera kuloza ku `len` motsatizana motsatizana koyenera kwamtundu wa `T`.
///
/// * Kukumbukira kotchulidwa ndi kagawo komwe kubwezedwa sikuyenera kusinthidwa nthawi yayitali ya `'a`, kupatula mkati mwa `UnsafeCell`.
///
/// * Kukula kwathunthu kwa `len * mem::size_of::<T>()` kwa kagawo sikuyenera kukhala kokulirapo kuposa `isize::MAX`.
///   Onani zolemba zachitetezo za [`pointer::offset`].
///
/// # Caveat
///
/// Nthawi yonse ya chidutswa chobwezeredwa imachokera pakugwiritsa ntchito kwake.
/// Pofuna kupewa kugwiritsa ntchito molakwika mwangozi, akuti tikulumikizani moyo wonsewo kukhala pachitsimikizo chilichonse, monga kupereka ntchito yothandizira kutenga phindu lanyumbayo, kapena ndi tanthauzo lofotokozera.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // onetsani kagawo ka chinthu chimodzi
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Kugwiritsa ntchito molakwika
///
/// Ntchito yotsatira ya `join_slices` ndi **yopanda tanthauzo** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Zomwe zanenedwa pamwambapa zimatsimikizira kuti `fst` ndi `snd` ndizophatikiza, koma atha kukhalabe mkati mwa _different allocated objects_, chifukwa chake kupanga chidutswachi ndichikhalidwe chosadziwika.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` ndipo `b` ndi zinthu zosiyanasiyana zomwe zapatsidwa ...
///     let a = 42;
///     let b = 27;
///     // ... zomwe zitha kuyikidwanso mozungulira pokumbukira: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Imagwira chimodzimodzi ndi [`from_raw_parts`], kupatula kuti chidutswa chosinthika chimabwezedwa.
///
/// # Safety
///
/// Khalidwe silimadziwika ngati izi zikuphwanyidwa:
///
/// * `data` iyenera kukhala [valid] yowerengera onse ndikulembera `len * mem::size_of::<T>()` ma byte ambiri, ndipo iyenera kulumikizidwa bwino.Izi zikutanthauza makamaka:
///
///     * Kukumbukira konse kwa chidutswa ichi kuyenera kukhala mkati mwa chinthu chimodzi chogawa!
///       Magawo sangadutse pazinthu zingapo zomwe zapatsidwa.
///     * `data` sayenera kukhala yopanda tanthauzo komanso yolumikizana ngakhale ndi magawo a zero-kutalika.
///     Chimodzi mwazifukwa za izi ndikuti kukhathamiritsa kwa enum kumatha kudalira mafotokozedwe (kuphatikiza magawo amtundu uliwonse) osakanikirana komanso osachita kusiyanitsa ndi zina.
///
///     Mutha kupeza pointer yomwe imagwiritsidwa ntchito ngati `data` yamagawo otalika zero pogwiritsa ntchito [`NonNull::dangling()`].
///
/// * `data` iyenera kuloza ku `len` motsatizana motsatizana koyenera kwamtundu wa `T`.
///
/// * Kukumbukira kotchulidwa ndi kagawo komwe kubwezedwa sikuyenera kupezeka kudzera pa cholembera china (chosachokera ku mtengo wobwezera) kwa nthawi yonse ya moyo `'a`.
///   Zonse zolembera ndi kulemba ndizoletsedwa.
///
/// * Kukula kwathunthu kwa `len * mem::size_of::<T>()` kwa kagawo sikuyenera kukhala kokulirapo kuposa `isize::MAX`.
///   Onani zolemba zachitetezo za [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Imatembenuza dzina la T kukhala chidutswa cha kutalika 1 (osakopera).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Imatembenuza dzina la T kukhala chidutswa cha kutalika 1 (osakopera).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}