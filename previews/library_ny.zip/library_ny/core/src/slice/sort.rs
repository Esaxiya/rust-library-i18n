//! Kagawo kosanja
//!
//! Gawoli lili ndi masanjidwe osanja potengera mtundu wa Orson Peters-wotsogola msanga, wofalitsidwa ku: <https://github.com/orlp/pdqsort>
//!
//!
//! Kusanja kosakhazikika kumagwirizana ndi libcore chifukwa sikugawana kukumbukira, mosiyana ndi kukhazikitsa kwathu mosakhazikika.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Mukatsitsidwa, makope ochokera ku `src` kupita ku `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // CHITETEZO: Ili ndi gulu la othandizira.
        //          Chonde onani kugwiritsa ntchito kwake molondola.
        //          Momwemonso, wina ayenera kukhala wotsimikiza kuti `src` ndi `dst` sizigwirana mogwirizana ndi `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Kusunthira chinthu choyamba kumanja mpaka chikakumane ndi chinthu chokulirapo kapena chofanana.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // CHITETEZO: Ntchito zosatetezedwa pansipa zikuphatikiza kulozera popanda cheke chomangika (`get_unchecked` ndi `get_unchecked_mut`)
    // ndi kukopera kukumbukira (`ptr::copy_nonoverlapping`).
    //
    // a.Kuwonetsa:
    //  1. Tidayang'ana kukula kwa gulu mpaka>=2.
    //  2. Zolemba zonse zomwe tidzachite nthawi zonse zimakhala pakati pa {0 <= index < len} koposa.
    //
    // b.Kukopera pamtima
    //  1. Tikupeza zolozera za maumboni omwe akutsimikiziridwa kuti ndi ovomerezeka.
    //  2. Sangakwaniritsane chifukwa timalandila malembedwe amitundu yosiyanasiyana ya kagawo.
    //     Momwemonso, `i` ndi `i-1`.
    //  3. Ngati chidutswacho chikugwirizana bwino, zinthuzo zimayenderana.
    //     Ndiudindo wa yemwe akuyimbirayo kuti awonetsetse kuti chidutswacho chikugwirizana bwino.
    //
    // Onani ndemanga pansipa kuti mumve zambiri.
    unsafe {
        // Ngati zinthu ziwiri zoyambirira sizichitike ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Werengani gawo loyambalo kuti likhale logawika.
            // Ngati ntchito yofananayi yotsatirayi panics, `hole` idzagwetsedwa ndikulembanso chinthucho pagawolo.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Sunthani `i-th gawo limodzi kumanzere, potero ndikusunthira bowo kumanja.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` imagwetsedwa motero imakopera `tmp` mu dzenje lotsala mu `v`.
        }
    }
}

/// Kusunthira chinthu chomaliza kumanzere mpaka chikakumana ndi chaching'ono kapena chofanana.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // CHITETEZO: Ntchito zosatetezedwa pansipa zikuphatikiza kulozera popanda cheke chomangika (`get_unchecked` ndi `get_unchecked_mut`)
    // ndi kukopera kukumbukira (`ptr::copy_nonoverlapping`).
    //
    // a.Kuwonetsa:
    //  1. Tidayang'ana kukula kwa gulu mpaka>=2.
    //  2. Zolemba zonse zomwe tidzachite nthawi zonse zimakhala pakati pa `0 <= index < len-1` koposa.
    //
    // b.Kukopera pamtima
    //  1. Tikupeza zolozera za maumboni omwe akutsimikiziridwa kuti ndi ovomerezeka.
    //  2. Sangakwaniritsane chifukwa timalandila malembedwe amitundu yosiyanasiyana ya kagawo.
    //     Momwemonso, `i` ndi `i+1`.
    //  3. Ngati chidutswacho chikugwirizana bwino, zinthuzo zimayenderana.
    //     Ndiudindo wa yemwe akuyimbirayo kuti awonetsetse kuti chidutswacho chikugwirizana bwino.
    //
    // Onani ndemanga pansipa kuti mumve zambiri.
    unsafe {
        // Ngati zinthu ziwiri zomaliza zachikale ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Werengani gawo lomaliza kuti likhale losanjikiza.
            // Ngati ntchito yofananayi yotsatirayi panics, `hole` idzagwetsedwa ndikulembanso chinthucho pagawolo.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Sunthani `i-th gawo limodzi kumanja, potero ndikusunthira bowo kumanzere.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` imagwetsedwa motero imakopera `tmp` mu dzenje lotsala mu `v`.
        }
    }
}

/// Pang'ono pang'ono pangani kagawo posuntha zinthu zingapo zomwe sizinalembedwe mozungulira.
///
/// Kubwezeretsa `true` ngati kagawo kamasankhidwa kumapeto.Ntchitoyi ndi yoopsa kwambiri *O*(*n*).
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Ziwerengero zoyandikana zapakati pazomwe zidayendetsedwa zomwe zisinthe.
    const MAX_STEPS: usize = 5;
    // Ngati kagawo kali kofupikirapo kuposa kameneka, musasinthe zinthu zilizonse.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // CHITETEZO: Tinafufuza kale momveka bwino ndi `i < len`.
        // Kukhazikitsa kwathu konse komwe kuli pambuyo pake kumangokhala mu `0 <= index < len`
        unsafe {
            // Pezani zigawo ziwiri zoyandikana zomwe sizinayitanidwe.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Tatha?
        if i == len {
            return true;
        }

        // Osasinthitsa zinthu pazifupi zazifupi, zomwe zimakhala ndi mtengo wogwira.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Sinthani zinthu zomwe zapezeka.Izi zimawayika molondola.
        v.swap(i - 1, i);

        // Sungani chinthu chaching'ono kumanzere.
        shift_tail(&mut v[..i], is_less);
        // Sinthani chinthu chachikulu kumanja.
        shift_head(&mut v[i..], is_less);
    }

    // Sanathe kusanja kagawo pamayendedwe ochepa.
    false
}

/// Imasanja kagawo pogwiritsa ntchito mtundu wolowetsera, womwe ndi vuto *O*(*n*^ 2).
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Imasanja `v` pogwiritsa ntchito heapsort, yomwe imatsimikizira *O*(*n*\*log(* n*)) vuto lalikulu.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Mulu wowerengeka uwu umalemekeza `parent >= child` wosasintha.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Ana a `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Sankhani mwana wamkulu.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Imani ngati wosinthirayo agwira `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Sinthanani ndi `node` ndi mwana wamkulu, sinthani gawo limodzi, ndikupitiliza kusefa.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Mangani muluwo munthawi yofanana.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Zithunzi zazikulu kwambiri kuchokera pamulu.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Magawo `v` m'magawo ang'onoang'ono kuposa `pivot`, otsatiridwa ndi zinthu zazikulu kuposa kapena zofanana ndi `pivot`.
///
///
/// Kubwezeretsa chiwerengero cha zinthu zing'onozing'ono kuposa `pivot`.
///
/// Kugawa magawo kumachitika ndi block-by-block kuti muchepetse mtengo wamaofesi.
/// Lingaliro ili laperekedwa mu pepala la [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Chiwerengero cha zinthu m'bokosi lenileni.
    const BLOCK: usize = 128;

    // Kugawa magawo kumabwereza izi mpaka kumaliza:
    //
    // 1. Tsatirani choyala kuchokera kumanzere kuti mupeze zinthu zazikulu kapena zofanana ndi pivot.
    // 2. Tsatirani choyala kuchokera kumanja kuti muzindikire zinthu zazing'ono kuposa pivot.
    // 3. Sinthani zinthu zomwe zadziwika pakati kumanzere ndi kumanja.
    //
    // Timasunga mitundu yotsatirayi pamndandanda wazinthu:
    //
    // 1. `block` - Chiwerengero cha zinthu zomwe zili m'bwaloli.
    // 2. `start` - Yambitsani kulozera mu gulu la `offsets`.
    // 3. `end` - Cholozera chomaliza mu gulu la `offsets`.
    // 4. `zolakwika, ziwonetsero zazinthu zomwe sizinachitike mu block.

    // Malo apano kumanzere (kuyambira `l` mpaka `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Malo apano kumanja (kuchokera ku `r.sub(block_r)` to `r`).
    // CHITETEZO: Zolemba za .add() zimatchula kuti `vec.as_ptr().add(vec.len())` imakhala yotetezeka nthawi zonse`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Tikapeza ma VLA, yesetsani kupanga kutalika kwa `min(v.len(), 2 * BLOCK) `m'malo mwake
    // kuposa magawo awiri okhazikika a `BLOCK`.Ma VLA atha kukhala osavuta kugwiritsa ntchito posungira.

    // Imabwezera kuchuluka kwa zinthu pakati pazolozera `l` (inclusive) ndi `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Tatsiriza kugawa-block-block pomwe `l` ndi `r` ayandikira kwambiri.
        // Kenako timachita ntchito yolumikizira ena kuti tigawe zinthu zotsalazo.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Chiwerengero cha zinthu zomwe zatsala (osafananizidwa ndi chikho).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Sinthani kukula kwake kuti mabatani akumanzere ndi kumanja asadutsane, koma mugwirizane bwino kuti mutseke zotsalazo.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Tsatani zinthu `block_l` kuchokera kumanzere.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // CHITETEZO: Ntchito zosatetezeka pansipa zikuphatikiza kugwiritsa ntchito `offset`.
                //         Malinga ndi momwe ntchitoyo ikufunira, timawakhutitsa chifukwa:
                //         1. `offsets_l` imagawidwa mokwanira, motero imagawidwa ngati chinthu chopatsidwa.
                //         2. Ntchito `is_less` imabwezeretsa `bool`.
                //            Kuponya `bool` sikudzasefukira `isize`.
                //         3. Tatsimikizira kuti `block_l` idzakhala `<= BLOCK`.
                //            Kuphatikiza apo, `end_l` idakhazikitsidwa poyambira poyambitsa `offsets_` yomwe idalengezedwa pamtanda.
                //            Chifukwa chake, tikudziwa kuti ngakhale zili zovuta kwambiri (mapembedzero onse a `is_less` amabwerera abodza) tidzakhala titangodutsa kamodzi kokha kumapeto.
                //        Ntchito ina yosatetezeka pano ndikuchotsa `elem`.
                //        Komabe, `elem` poyambirira inali poyambira poyika chidutswa chomwe chimakhala chovomerezeka nthawi zonse.
                unsafe {
                    // Kuyerekeza kopanda nthambi.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Tsatani zinthu `block_r` kuchokera kumanja.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // CHITETEZO: Ntchito zosatetezeka pansipa zikuphatikiza kugwiritsa ntchito `offset`.
                //         Malinga ndi momwe ntchitoyo ikufunira, timawakhutitsa chifukwa:
                //         1. `offsets_r` imagawidwa mokwanira, motero imagawidwa ngati chinthu chopatsidwa.
                //         2. Ntchito `is_less` imabwezeretsa `bool`.
                //            Kuponya `bool` sikudzasefukira `isize`.
                //         3. Tatsimikizira kuti `block_r` idzakhala `<= BLOCK`.
                //            Kuphatikiza apo, `end_r` idakhazikitsidwa poyambira poyambitsa `offsets_` yomwe idalengezedwa pamtanda.
                //            Chifukwa chake, tikudziwa kuti ngakhale zili zovuta kwambiri (mapembedzero onse a `is_less` abwerera moona) tidzangokhala ochepa pokhapokha titadutsa kumapeto.
                //        Ntchito ina yosatetezeka pano ndikuchotsa `elem`.
                //        Komabe, `elem` poyamba inali `1 *sizeof(T)` kumapeto komaliza ndipo tidachepetsa ndi `1* sizeof(T)` tisanayipeze.
                //        Kuphatikiza apo, `block_r` idanenedwa kuti ndi yochepera `BLOCK` ndipo `elem` chifukwa chake ikuloza poyambira kagawo.
                unsafe {
                    // Kuyerekeza kopanda nthambi.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Chiwerengero cha zinthu zomwe sizinachitike mwa njira zosinthira pakati kumanzere ndi kumanja.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // M'malo mosinthanitsa gulu limodzi panthawiyo, zimakhala bwino kwambiri kuchita zovomerezeka mozungulira.
            // Izi sizofanana kwenikweni ndi kusinthana, koma zimatulutsa zotsatira zofananira pogwiritsa ntchito zokumbukira zochepa.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Zinthu zonse zodula zomwe zili kumanzere zidasunthidwa.Pitani ku block yotsatira.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Zinthu zonse zomwe zinali kunja kwa dongosolo lomwe lili mndende yoyenera zidasunthidwa.Pitani ku block yapita.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Zomwe zatsala pano ndizomwe zimakhala chimodzi (kaya kumanzere kapena kumanja) ndi zinthu zosakhalitsa zomwe zimafunikira kusunthidwa.
    // Zinthu zotsalazo zitha kusunthidwa mpaka kumapeto kwake.
    //

    if start_l < end_l {
        // Mzere wakumanzere utsalira.
        // Sungani zotsalira zake zosanjidwa kumanja.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Malo olondola amakhalabe.
        // Sunthani zinthu zake zotsalira kupita kumanzere.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Palibe china choti tichite, tamaliza.
        width(v.as_mut_ptr(), l)
    }
}

/// Magawo `v` m'magawo ang'onoang'ono kuposa `v[pivot]`, otsatiridwa ndi zinthu zazikulu kuposa kapena zofanana ndi `v[pivot]`.
///
///
/// Kubweza Tuple ya:
///
/// 1. Chiwerengero cha zinthu zazing'ono kuposa `v[pivot]`.
/// 2. Zowona ngati `v` idagawidwa kale.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Ikani chikwangwani kumayambiriro kwa kagawo.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Werengani pivotyo kuti ikhale yosanjikizana kuti igwire bwino ntchito.
        // Ngati ntchito yofananayi yotsatirayi panics, pivot imangolembedwanso pagawolo.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Pezani zinthu ziwiri zoyambirira.
        let mut l = 0;
        let mut r = v.len();

        // CHITETEZO: Zosatetezeka pansipa zikuphatikiza kulozera mndandanda.
        // Koyamba: Tachita kale malire oyang'ana pano ndi `l < r`.
        // Kachiwiri: Poyamba timakhala ndi `l == 0` ndi `r == v.len()` ndipo tidayang'ana `l < r` pamalo aliwonse olembetsa.
        //                     Kuchokera apa tikudziwa kuti `r` iyenera kukhala yosachepera `r == l` yomwe idawonetsedwa kuti ndiyovomerezeka kuyambira koyambirira.
        unsafe {
            // Pezani chinthu choyamba kuposa kapena chofanana ndi chikwangwani.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Pezani chinthu chomaliza chochepa kwambiri.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` imachoka ndikulemba pivot (yomwe ndi magawo osanjikiza omwe amagawanika) kubwerera m'gawo lomwe idalipo poyamba.
        // Gawo ili ndilofunikira pakuwonetsetsa chitetezo!
        //
    };

    // Ikani pivot pakati pa magawo awiriwo.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Magawo `v` kukhala zinthu zofanana ndi `v[pivot]` motsatiridwa ndi zinthu zazikulu kuposa `v[pivot]`.
///
/// Kubwezeretsa chiwerengero cha zinthu zofanana ndi chikwangwani.
/// Zimaganiziridwa kuti `v` ilibe zinthu zazing'ono kuposa pivot.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Ikani chikwangwani kumayambiriro kwa kagawo.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Werengani pivotyo kuti ikhale yosanjikizana kuti igwire bwino ntchito.
    // Ngati ntchito yofananayi yotsatirayi panics, pivot imangolembedwanso pagawolo.
    // CHITETEZO: Cholozera apa ndi chovomerezeka chifukwa chimapezeka potengera kagawo.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Tsopano gawani kagawo.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // CHITETEZO: Zosatetezeka pansipa zikuphatikiza kulozera mndandanda.
        // Koyamba: Tachita kale malire oyang'ana pano ndi `l < r`.
        // Kachiwiri: Poyamba timakhala ndi `l == 0` ndi `r == v.len()` ndipo tidayang'ana `l < r` pamalo aliwonse olembetsa.
        //                     Kuchokera apa tikudziwa kuti `r` iyenera kukhala yosachepera `r == l` yomwe idawonetsedwa kuti ndiyovomerezeka kuyambira koyambirira.
        unsafe {
            // Pezani chinthu choyamba chachikulu kuposa chikhocho.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Pezani chinthu chomaliza chofanana ndi pivot.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Tatha?
            if l >= r {
                break;
            }

            // Sinthani zinthu zomwe zatulukazo.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Tapeza zinthu za `l` zofanana ndi pivot.Onjezani 1 kuti muwerengere pachokha.
    l + 1

    // `_pivot_guard` imachoka ndikulemba pivot (yomwe ndi magawo osanjikiza omwe amagawanika) kubwerera m'gawo lomwe idalipo poyamba.
    // Gawo ili ndilofunikira pakuwonetsetsa chitetezo!
}

/// Amabalalitsa zinthu zina moyesera kuti athyole njira zomwe zingayambitse magawano osakhazikika mwachangu.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Pseudorandom nambala jenereta yochokera papepala la "Xorshift RNGs" lolembedwa ndi George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Tengani manambala osasintha modulo nambala iyi.
        // Chiwerengerocho chikukwanira `usize` chifukwa `len` siyaposa `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Otsatira ena apadera adzakhala pafupi ndi index iyi.Tiyeni tiwasinthe mwachisawawa.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Pangani nambala yosasintha modulo `len`.
            // Komabe, kuti tipewe ntchito zotsika mtengo timayamba timatenga modulo mphamvu ya awiri, kenako ndikuchepetsa ndi `len` mpaka itakwanira `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` akutsimikiziridwa kukhala ochepera `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Amasankha pivot mu `v` ndikubwezeretsanso index ndi `true` ngati chidutswacho mwina chakonzedwa kale.
///
/// Zinthu mu `v` zitha kukonzedweratu pakadali pano.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Kutalika kocheperako kuti musankhe njira yamankhwala yapakatikati.
    // Magawo afupikitsa amagwiritsa ntchito njira yosavuta yapakatikati mwa atatu.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Zolemba zambiri zosintha zomwe zingagwire ntchitoyi.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Zizindikiro zitatu pafupi ndi zomwe tidzasankhe chikwangwani.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Imawerengera kuchuluka kwathunthu kosinthana komwe tatsala pang'ono kuchita posankha ma indices.
    let mut swaps = 0;

    if len >= 8 {
        // Sinthana indices kuti `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Sinthana indices kuti `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Amapeza apakatikati a `v[a - 1], v[a], v[a + 1]` ndikusunga index mu `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Pezani amzungu m'madera oyandikana ndi `a`, `b`, ndi `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Pezani apakatikati pa `a`, `b`, ndi `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Chiwerengero chachikulu cha swaps chidachitika.
        // Mwayi womwe chidutswacho chikutsika kapena makamaka chikutsika, kotero kusinthanso mwina kumathandizira kuthetsa msanga.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Mitundu `v` mobwerezabwereza.
///
/// Ngati kagawo kanakonzedweratu m'gulu loyambirira, limatchedwa `pred`.
///
/// `limit` ndi chiwerengero chazigawo zosaloledwa musanapite ku `heapsort`.
/// Ngati zero, ntchitoyi nthawi yomweyo imasamukira ku heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Magawo mpaka kutalika kwake amasankhidwa pogwiritsa ntchito mitundu yolowetsera.
    const MAX_INSERTION: usize = 20;

    // Zowona ngati kugawa komaliza kunali koyenera.
    let mut was_balanced = true;
    // Zowona ngati kugawa komaliza sikunasokoneze zinthu (kagawo kanali katagawidwa kale).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Magawo afupikitsa kwambiri amasankhidwa pogwiritsa ntchito njira yolowetsera.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Ngati zisankho zambiri zoyipa zidapangidwa, ingobwererani ku heapsort kuti mutsimikizire kuti `O(n * log(n))` ndi yoyipa kwambiri.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Ngati kugawa kotsirizira kunali kosafunikira, yesani kuswa kagawidwe ndikusintha zinthu zina mozungulira.
        // Tikukhulupirira kuti tisankha pivot yabwinoko nthawi ino.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Sankhani pivot ndikuyesa kuyerekeza ngati kagawo kakonzedwa kale.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Ngati kugawa komaliza kunali koyenera komanso kosasokoneza zinthu, ndipo ngati kusankha kwa pivot kumaneneratu kuti kagawo kali kadzakonzedwa kale ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Yesetsani kuzindikira zinthu zingapo zomwe zawonongeka ndikuzisintha kuti zikonze malo.
            // Ngati chidutswacho chitha kusankhidwa kwathunthu, tatha.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Ngati pivot yomwe yasankhidwa ndiyofanana ndi yomwe idakonzedweratu, ndiye chinthu chaching'ono kwambiri pagawo.
        // Gawani chidutswacho muzinthu zofanana ndi zinthu zazikulu kuposa chikhocho.
        // Mlanduwu umagunda pomwe kagawo kali ndi zinthu zambiri zobwereza.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Pitirizani kusanja zinthu zazikulu kuposa chikho.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Gawani kagawo.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Gawani kagawo mu `left`, `pivot`, ndi `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Bwererani kumbali yocheperako kuti muchepetse kuchuluka kwamafoni obwereza ndikudya malo ochepa.
        // Kenako ingopitilizani ndi mbali yayitali (izi zikufanana ndi kubwereza mchira).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Imasanja `v` pogwiritsa ntchito mtundu wogonjetsa quicksort, womwe ndi *O*(*n*\*log(* n*)) vuto lalikulu.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Kusanja kulibe tanthauzo lililonse pamitundu yazero.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Chepetsani kuchuluka kwa magawo osagwirizana mpaka `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Kwa magawo mpaka kutalika kwake mwina mwachangu kuti musankhe.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Sankhani pivot
        let (pivot, _) = choose_pivot(v, is_less);

        // Ngati pivot yomwe yasankhidwa ndiyofanana ndi yomwe idakonzedweratu, ndiye chinthu chaching'ono kwambiri pagawo.
        // Gawani chidutswacho muzinthu zofanana ndi zinthu zazikulu kuposa chikhocho.
        // Mlanduwu umagunda pomwe kagawo kali ndi zinthu zambiri zobwereza.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Ngati tadutsa index yathu, ndiye kuti tili bwino.
                if mid > index {
                    return;
                }

                // Kupanda kutero, pitirizani kusanja zinthu zazikulu kuposa chikho.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Gawani kagawo mu `left`, `pivot`, ndi `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Ngati mid==index, ndiye kuti tamaliza, popeza partition() idatsimikizira kuti zinthu zonse pambuyo pakatikati ndizapamwamba kapena zofanana ndi mid.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Kusanja kulibe tanthauzo lililonse pamitundu yazero.Osachita chilichonse.
    } else if index == v.len() - 1 {
        // Pezani zinthu zazikulu ndikuziyika pomaliza.
        // Ndife omasuka kugwiritsa ntchito `unwrap()` pano chifukwa tikudziwa v sayenera kukhala opanda kanthu.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Pezani min element ndikuyiyika pamalo oyambawo.
        // Ndife omasuka kugwiritsa ntchito `unwrap()` pano chifukwa tikudziwa v sayenera kukhala opanda kanthu.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}