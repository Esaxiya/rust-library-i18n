//! Ma Macro omwe amagwiritsidwa ntchito ndi owerenga kagawo.

// Kulowetsa is_empty ndipo len amapanga kusiyana kwakukulu magwiridwe antchito
macro_rules! is_empty {
    // Momwe timakhalira kutalika kwa ZST iterator, izi zimagwirira ntchito ZST komanso non-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Kuti tichotse malire ena (onani `position`), timatha kuwerengera kutalika m'njira yosayembekezereka.
// (Kuyesedwa ndi `codegen/kagawo-malire-malire-cheke`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // nthawi zina timagwiritsidwa ntchito m'malo otetezeka

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // _cannot_ iyi imagwiritsa ntchito `unchecked_sub` chifukwa timadalira kukulunga kuti tiimire kutalika kwa ma ZER.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Tikudziwa kuti `start <= end`, itha kuchita bwino kuposa `offset_from`, yomwe imafunikira kuthana ndi sign.
            // Mwa kukhazikitsa mbendera zoyenera apa titha kuuza LLVM izi, zomwe zimawathandiza kuchotsa macheke malire.
            // CHITETEZO: Mwa mtundu wosasintha, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Powuzanso LLVM kuti zolembazo ndizosiyana ndi kukula kwamtunduwu, zimatha kukhathamiritsa `len() == 0` mpaka `start == end` m'malo mwa `(end - start) < size`.
            //
            // CHITETEZO: Mwa mtundu wosasintha, zolozera zimayenderana kotero
            //         Mtunda pakati pawo uyenera kukhala wochulukirapo kukula kwa pointee
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Kutanthauzira kogawana kwa owerenga `Iter` ndi `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Imabwezeretsa chinthu choyambirira ndikusunthira koyambira kwa 1 itapita.
        // Zimakulitsa magwiridwe antchito kwambiri poyerekeza ndi ntchito yosanja.
        // Wolembayo sayenera kukhala wopanda kanthu.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Imabwezeretsa chinthu chomaliza ndikusunthira kumapeto kwa iterator chammbuyo ndi 1.
        // Zimakulitsa magwiridwe antchito kwambiri poyerekeza ndi ntchito yosanja.
        // Wolembayo sayenera kukhala wopanda kanthu.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Imachepetsa iterator pomwe T ndi ZST, posunthira kumapeto kwa iterator chammbuyo ndi `n`.
        // `n` sayenera kupitirira `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Ntchito yothandizira popanga kagawo kuchokera pa iterator.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // CHITETEZO: iterator idapangidwa kuchokera pagawo ndi pointer
                // `self.ptr` ndi kutalika `len!(self)`.
                // Izi zimatsimikizira kuti zofunikira zonse za `from_raw_parts` zakwaniritsidwa.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Ntchito yothandizira kusunthira koyambira kwa iterator kutsogolo ndi zinthu `offset`, ndikubwezeretsanso koyambira koyambirira.
            //
            // Zosatetezeka chifukwa zolipiritsa siziyenera kupitirira `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // CHITETEZO: woyimbayo akutsimikizira kuti `offset` siyodutsa `self.len()`,
                    // cholozera chatsopanochi chili mkati mwa `self` motero chimatsimikizika kuti sichikhala chopanda pake.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Ntchito yothandizira yosunthira kumapeto kwa iterator kumbuyo ndi zinthu `offset`, ndikubwezeretsanso kumapeto kwatsopano.
            //
            // Zosatetezeka chifukwa zolipiritsa siziyenera kupitirira `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // CHITETEZO: woyimbayo akutsimikizira kuti `offset` siyodutsa `self.len()`,
                    // zomwe zimatsimikizika kuti sizikusefukira `isize`.
                    // Komanso, cholozera chotsatiracho chili m'malire a `slice`, yomwe imakwaniritsa zofunikira zina za `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // itha kukhazikitsidwa ndi magawo, koma izi zimapewa malire

                // CHITETEZO: Maitanidwe a `assume` ndiotetezeka kuyambira pomwe pointer yayambira
                // sayenera kukhala yopanda pake, ndipo magawo osakhala a ZSTs amayeneranso kukhala ndi cholozera chosakwanira.
                // Kuyimbira ku `next_unchecked!` ndikotetezeka popeza timawona ngati wogwiritsa ntchitoyo alibe chilichonse.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Cholemba ichi tsopano chilibe kanthu.
                    if mem::size_of::<T>() == 0 {
                        // Tiyenera kuchita motere monga `ptr` sangakhale 0, koma `end` itha kukhala (chifukwa chokutira).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // CHITETEZO: mapeto sangakhale 0 ngati T si ZST chifukwa ptr si 0 ndi kutha>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // CHITETEZO: Tili m'malire.`post_inc_start` imachita zabwino ngakhale kwa ma ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Timaposa kukhazikitsa kosasintha, komwe kumagwiritsa ntchito `try_fold`, chifukwa kukhazikitsa kosavuta kumeneku kumapangitsa LLVM IR yocheperako ndipo ndikosavuta kusonkhanitsa.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Timaposa kukhazikitsa kosasintha, komwe kumagwiritsa ntchito `try_fold`, chifukwa kukhazikitsa kosavuta kumeneku kumapangitsa LLVM IR yocheperako ndipo ndikosavuta kusonkhanitsa.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Timaposa kukhazikitsa kosasintha, komwe kumagwiritsa ntchito `try_fold`, chifukwa kukhazikitsa kosavuta kumeneku kumapangitsa LLVM IR yocheperako ndipo ndikosavuta kusonkhanitsa.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Timaposa kukhazikitsa kosasintha, komwe kumagwiritsa ntchito `try_fold`, chifukwa kukhazikitsa kosavuta kumeneku kumapangitsa LLVM IR yocheperako ndipo ndikosavuta kusonkhanitsa.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Timaposa kukhazikitsa kosasintha, komwe kumagwiritsa ntchito `try_fold`, chifukwa kukhazikitsa kosavuta kumeneku kumapangitsa LLVM IR yocheperako ndipo ndikosavuta kusonkhanitsa.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Timaposa kukhazikitsa kosasintha, komwe kumagwiritsa ntchito `try_fold`, chifukwa kukhazikitsa kosavuta kumeneku kumapangitsa LLVM IR yocheperako ndipo ndikosavuta kusonkhanitsa.
            // Komanso, `assume` imapewa kuwunika malire.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // CHITETEZO: tatsimikizika kuti tidzakhala m'malire ndi osasintha:
                        // `i >= n`, `self.next()` ikamabweza `None` ndikutuluka kotuluka.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Timaposa kukhazikitsa kosasintha, komwe kumagwiritsa ntchito `try_fold`, chifukwa kukhazikitsa kosavuta kumeneku kumapangitsa LLVM IR yocheperako ndipo ndikosavuta kusonkhanitsa.
            // Komanso, `assume` imapewa kuwunika malire.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // CHITETEZO: `i` iyenera kukhala yotsika kuposa `n` kuyambira pomwe imayamba pa `n`
                        // ndipo akungotsika.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // CHITETEZO: woyimbayo ayenera kutsimikizira kuti `i` ili m'malire a
                // chidutswa choyambira, kotero `i` sichitha kusefukira `isize`, ndipo zomwe zalembedwazo zimatsimikizika kuti zizitanthauza chinthu chidutsacho ndipo chotsimikizika kuti ndicholondola.
                //
                // Onaninso kuti woyimbirayo akutsimikiziranso kuti sitidayitanidwanso ndi index yomweyi, komanso kuti palibe njira zina zomwe zingapezere cholandilachi chomwe chimayitanidwa, chifukwa chake ndizovomerezeka kuti zomwe abweza zitha kusinthidwa ngati
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // itha kukhazikitsidwa ndi magawo, koma izi zimapewa malire

                // CHITETEZO: Maitanidwe a `assume` ndiotetezeka popeza choyilozera cha chidutswa sichiyenera kukhala chopanda pake,
                // ndipo magawo osakhala a ZSTs amayeneranso kukhala ndi cholozera chopanda pake.
                // Kuyimbira ku `next_back_unchecked!` ndikotetezeka popeza timawona ngati wogwiritsa ntchitoyo alibe chilichonse.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Cholemba ichi tsopano chilibe kanthu.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // CHITETEZO: Tili m'malire.`pre_dec_end` imachita zabwino ngakhale kwa ma ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}