// Kukhazikitsa koyambirira kutengedwa kuchokera ku rust-memchr.
// Copyright 2015 Andrew Gallant, bluss ndi Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Gwiritsani ntchito truncation.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Kubwezeretsa `true` ngati `x` ili ndi zero byte.
///
/// Kuchokera ku *Nkhani Zakuwerengera*, J. Arndt:
///
/// "Lingaliro ndikuti achotse imodzi pamabatani aliwonse kenako ndikuyang'ana mabayiti pomwe kubwereketsa kudafikira mpaka pachimake
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Kubwezeretsa index yoyamba yofanana ndi byte `x` mu `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Njira yachangu yamagawo ang'onoang'ono
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Sakani mtengo umodzi wokha powerenga mawu awiri a `usize` nthawi imodzi.
    //
    // Gawani `text` m'magawo atatu
    // - unaligned gawo loyambirira, asanafike liwu loyanjana ndi adilesi yomwe ili pamanja
    // - thupi, jambulani ndi mawu awiri nthawi imodzi
    // - gawo lotsala, <2 kukula kwa mawu

    // fufuzani mpaka kumalire ogwirizana
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // fufuzani thupi lonse la lembalo
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // CHITETEZO: wolosera zakanthawi akutsimikizira mtunda wosachepera 2 * usize_bytes
        // pakati pa zolipirira ndi kutha kwa kagawo.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // kuswa ngati pali ofananira mamvekedwe
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Pezani chodutsa pambuyo poti chikhomo cha thupi chidayima.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Kubwezeretsa index yomaliza yofananira ndi byte `x` mu `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Sakani mtengo umodzi wokha powerenga mawu awiri a `usize` nthawi imodzi.
    //
    // Gawani `text` m'magawo atatu:
    // - - osakhazikika mchira, atatha kulumikizana ndi mawu omaliza,
    // - thupi, loyesedwa ndi mawu awiri nthawi,
    // - mabayiti oyamba otsala, <2 kukula kwa mawu.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Tikuyitanitsa izi kuti tipeze kutalika kwa manambala oyamba ndi mawu okuluwika.
        // Pakatikati nthawi zonse timakonza zidutswa ziwiri nthawi imodzi.
        // CHITETEZO: kusamutsa `[u8]` kupita ku `[usize]` ndikotetezeka kupatula kusiyanasiyana komwe kumayendetsedwa ndi `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Fufuzani thupi lonse la mawuwo, onetsetsani kuti sitidutsa min_aligned_offset.
    // offset imagwirizana nthawi zonse, chifukwa chake kungoyesa `>` ndikwanira ndikupewa kusefukira kotheka.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // CHITETEZO: offset imayamba pa len, suffix.len(), bola ikaposa
        // min_aligned_offset (prefix.len()) mtunda wotsalawo ndi osachepera 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Idyani ngati pali ofanana.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Pezani chodutsa chisanafike nthawi yomwe thupi linayima.
    text[..offset].iter().rposition(|elt| *elt == x)
}