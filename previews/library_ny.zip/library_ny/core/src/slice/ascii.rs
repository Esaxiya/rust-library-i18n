//! Ntchito pa ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Kufufuza ngati mabayiti onse pagawoli ali mkati mwa ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Kufufuza kuti magawo awiri ndi machesi osaganizira a ASCII.
    ///
    /// Zofanana ndi `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, koma osagawa ndi kukopera kwakanthawi.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Imatembenuza kagawo kameneka kukhala ASCII mulingo wofanana.
    ///
    /// Makalata a ASCII 'a' mpaka 'z' ajambulidwa ku 'A' mpaka 'Z', koma zilembo zosakhala ASCII sizikusintha.
    ///
    /// Kuti mubwezere mtengo watsopano osasintha womwe ulipo, gwiritsani ntchito [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Imatembenuza kagawo kameneka kukhala ASCII kakang'ono kofanana m'malo mwake.
    ///
    /// Makalata a ASCII 'A' mpaka 'Z' ajambulidwa ku 'a' mpaka 'z', koma zilembo zosakhala ASCII sizikusintha.
    ///
    /// Kuti mubwezere mtengo watsopano wotsika popanda kusintha womwe ulipo, gwiritsani ntchito [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Kubwezeretsa `true` ngati mulibe mawu mu `v` ndi nonascii (>=128).
/// Snarfed kuchokera ku `../str/mod.rs`, yomwe imachita zofanana ndi kutsimikizika kwa utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Kuyesa kwabwino kwa ASCII komwe kumagwiritsa ntchito usize-a-a-time m'malo mwa ntchito za byte-at-a-time (ngati zingatheke).
///
/// Ma algorithm omwe timagwiritsa ntchito pano ndiosavuta.Ngati `s` ndi yayifupi kwambiri, timangoyang'ana chilichonse ndikumaliza nayo.Kupanda kutero:
///
/// - Werengani mawu oyamba ndi katundu wosagwirizana.
/// - Gwirizanitsani cholozera, werengani mawu otsatira mpaka kumapeto ndi katundu wofanana.
/// - Werengani `usize` yomaliza kuchokera ku `s` ndi katundu wosagwirizana.
///
/// Ngati iliyonse ya mitunduyi ipanga china chomwe `contains_nonascii` (above) ibwerera, ndiye tikudziwa kuti yankho lake ndi labodza.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Ngati sitingapindule chilichonse kuchokera pakukhazikitsa mawu-pa-nthawi, tibwerere ku scalar loop.
    //
    // Timachitanso izi pazomangamanga pomwe `size_of::<usize>()` siyokwanira mokwanira ndi `usize`, chifukwa ndi mlandu wodabwitsa wa edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Nthawi zonse timawerenga mawu oyamba osasanjika, zomwe zikutanthauza kuti `align_offset` ndi
    // 0, titha kuwerengeranso mtengo womwewo pakuwerenga kofananira.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // CHITETEZO: Timatsimikizira `len < USIZE_SIZE` pamwambapa.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Tasanthula izi pamwambapa, mwanjira zonse.
    // Dziwani kuti `offset_to_aligned` mwina ndi `align_offset` kapena `USIZE_SIZE`, zonsezi zimayang'aniridwa pamwambapa.
    //
    debug_assert!(offset_to_aligned <= len);

    // CHITETEZO: word_ptr ndiye (yolumikizidwa bwino) pize yomwe timagwiritsa ntchito kuwerenga
    // chidutswa chapakati cha kagawo.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` ndi index ya byte ya `word_ptr`, yogwiritsidwa ntchito poyang'ana kumapeto.
    let mut byte_pos = offset_to_aligned;

    // Paranoia yang'anani za mayikidwe, popeza tatsala pang'ono kupanga katundu wambiri wosagwirizana.
    // Pochita izi siziyenera kuthana ndi kachilombo mu `align_offset` ngakhale.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Werengani mawu otsatirawa mpaka mawu omaliza omaliza, osagwiritsa ntchito mawu omaliza omwe akuyenera kuchitika mchira mtsogolo, kuti muwonetsetse kuti mchira nthawi zonse umakhala `usize` umodzi kupita ku branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Onetsetsani kuti kuwerenga kuli malire
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Ndipo malingaliro athu onena za `byte_pos`.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // CHITETEZO: Tikudziwa kuti `word_ptr` imagwirizana bwino (chifukwa cha
        // `align_offset`), ndipo tikudziwa kuti tili ndi ma byte okwanira pakati pa `word_ptr` ndi kutha
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // CHITETEZO: Tikudziwa `byte_pos <= len - USIZE_SIZE`, zomwe zikutanthauza
        // zitatha izi `add`, `word_ptr` idzakhala yopitilira kumapeto.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Kuwunika kwaukhondo kuonetsetsa kuti kuli `usize` imodzi yokha yomwe yatsala.
    // Izi ziyenera kutsimikiziridwa ndi momwe timakhalira.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // CHITETEZO: Izi zimadalira `len >= USIZE_SIZE`, zomwe timaziyang'ana koyambirira.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}