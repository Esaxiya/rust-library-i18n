//! Mitundu ya atomiki
//!
//! Mitundu ya atomiki imapereka kulumikizana kwakanthawi kofananira pakati pa ulusi, ndipo ndizomwe zimamanga za mitundu ina yamtundu umodzi.
//!
//! Gawoli limatanthauzira mitundu ya ma atomiki amitundu yoyambira, kuphatikiza [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], ndi zina zambiri.
//! Mitundu ya atomiki imagwira ntchito zomwe, zikagwiritsidwa ntchito molondola, zimagwirizanitsa zosintha pakati pa ulusi.
//!
//! Njira iliyonse imatenga [`Ordering`] yomwe imayimira kulimba kwa cholepheretsa kukumbukira ntchitoyi.Malamulowa ndi ofanana ndi [C++20 atomic orderings][1].Kuti mumve zambiri onani [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Mitundu ya atomiki ndiyotetezeka kugawana pakati pa ulusi (imagwiritsa ntchito [`Sync`]) koma sindiwo okha omwe amapereka njira yogawana ndikutsatira [threading model](../../../std/thread/index.html#the-threading-model) ya Rust.
//!
//! Njira yodziwika kwambiri yogawana kusinthasintha kwa ma atomiki ndikuyiyika mu [`Arc`][arc] (cholozera cholozera cha-atomiki).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Mitundu ya atomiki imatha kusungidwa mosiyanasiyana, yoyambira kugwiritsa ntchito oyambitsa nthawi zonse ngati [`AtomicBool::new`].Zithunzi za atomiki nthawi zambiri zimagwiritsidwa ntchito poyambitsa dziko lonse lapansi.
//!
//! # Portability
//!
//! Mitundu yonse ya ma atomiki mugawoli ndiyotsimikizika kuti ndi [lock-free] ngati ipezeka.Izi zikutanthauza kuti samapeza mkati mwawo mutex.Mitundu ya atomiki ndi magwiridwe antchito sizotsimikizika kuti zidzakhala zopanda chiyembekezo.
//! Izi zikutanthauza kuti ntchito ngati `fetch_or` itha kugwiritsidwa ntchito ndi chingwe chofanizira komanso chosinthana.
//!
//! Ntchito za atomiki zitha kukhazikitsidwa pagawo la malangizo ndi ma atomiki akulu akulu.Mwachitsanzo, mapulatifomu ena amagwiritsa ntchito malangizo amtundu wa 4-byte kuti akwaniritse `AtomicI8`.
//! Dziwani kuti kutengera uku sikuyenera kukhala ndi vuto pakulondola kwa nambala, ndichinthu choti mudziwe.
//!
//! Mitundu ya atomiki mu gawo ili mwina sangapezeke pamapulatifomu onse.Mitundu ya atomiki pano yonse imapezeka kwambiri, komabe, ndipo imatha kudaliridwa ndi zomwe zilipo kale.Zina mwazodziwika ndi izi:
//!
//! * PowerPC ndipo nsanja za MIPS zokhala ndi 32-bit pointers zilibe mitundu ya `AtomicU64` kapena `AtomicI64`.
//! * ARM nsanja monga `armv5te` zomwe sizili za Linux zimangopereka ntchito za `load` ndi `store`, ndipo sizigwirizana ndi Kuyerekeza ndi Kusinthana kwa (CAS), monga `swap`, `fetch_add`, ndi zina zambiri.
//! Kuphatikiza apo pa Linux, ntchito za CAS zimayendetsedwa kudzera pa [operating system support], zomwe zimatha kubwera ndi chilango chantchito.
//! * ARM Zolinga ndi `thumbv6m` zimangopereka ntchito za `load` ndi `store`, ndipo sizigwirizana ndi Kuyerekeza ndi Kusinthana kwa (CAS), monga `swap`, `fetch_add`, ndi zina zambiri.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Tawonani kuti nsanja za future zitha kuwonjezedwa zomwe zilibe chithandizo cha ma atomiki ena.Nambala yotsogola kwambiri iyenera kusamala ndi mitundu iti ya atomiki yomwe imagwiritsidwa ntchito.
//! `AtomicUsize` ndipo `AtomicIsize` nthawi zambiri imakhala yotsogola kwambiri, komabe ngakhale sikupezeka kulikonse.
//! Kuti muwone, laibulale ya `std` imafuna ma atomiki ofananirana ndi ma pointer, ngakhale `core` satero.
//!
//! Pakadali pano muyenera kugwiritsa ntchito `#[cfg(target_arch)]` makamaka kuti muzisunga ma code ndi ma atomiki.Pali `#[cfg(target_has_atomic)]` yosakhazikika yomwe ingakhazikike mu future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Kutsegula kosavuta:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Yembekezani ulusi wina kuti mutulutse loko
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Sungani ulusi wapadziko lonse lapansi wa ulusi wamoyo:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Mtundu wa boolean womwe ungathe kugawidwa bwino pakati pa ulusi.
///
/// Mtundu uwu uli ndi mawonekedwe ofanana ndi kukumbukira monga [`bool`].
///
/// **Zindikirani**: Mtundu uwu umangopezeka pamapulatifomu omwe amathandizira katundu wa atomiki ndi malo ogulitsa `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Amapanga `AtomicBool` yoyambitsidwa kukhala `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Kutumiza kumayendetsedwa kwathunthu ku AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Mtundu wa pointer yaiwisi yomwe ingathe kugawidwa bwino pakati pa ulusi.
///
/// Mtundu uwu uli ndi mawonekedwe ofanana ndi kukumbukira monga `*mut T`.
///
/// **Dziwani**: Mtundu uwu umangopezeka pamapulatifomu omwe amathandizira katundu wa atomiki ndi malo ogulitsira.
/// Kukula kwake kumadalira kukula kwa cholembera.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Pangani null `AtomicPtr<T>`.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Kukonzekera kwa kukumbukira kwa atomiki
///
/// Kukonzekera kwa kukumbukira kumatanthauzira momwe ntchito za atomiki zimagwirizanitsira kukumbukira.
/// Mu [`Ordering::Relaxed`] yake yofooka, kukumbukira kokha komwe kumakhudzidwa ndi ntchitoyi ndi komwe kumagwirizana.
/// Kumbali inayi, magulu awiri ogulitsa [`Ordering::SeqCst`] amalunzanitsa kukumbukira kwinaku akusunganso dongosolo lonse lantchito zonsezi ulusi wonse.
///
///
/// Zolemba za Rust ndi [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Kuti mumve zambiri onani [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Palibe zovuta, koma ma atomiki okha.
    ///
    /// Imafanana ndi [`memory_order_relaxed`] mu C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Pamodzi ndi malo ogulitsira, zochitika zonse zam'mbuyomu zimalamulidwa musanapatsidwe mtengo uliwonse ndi kuyitanitsa [`Acquire`] (kapena kwamphamvu).
    ///
    /// Makamaka, zolemba zonse zam'mbuyomu zimawonekera kuzingwe zonse zomwe zimapanga katundu wa [`Acquire`] (kapena wamphamvu) wa mtengowu.
    ///
    /// Zindikirani kuti kugwiritsa ntchito kuyitanitsa kumeneku kwa ophatikiza katundu ndi masitolo kumabweretsa kugwirira ntchito kwa [`Relaxed`]!
    ///
    /// Kuyitanitsa uku kumangogwira ntchito zomwe zingagulitse.
    ///
    /// Imafanana ndi [`memory_order_release`] mu C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Kuphatikizidwa ndi katundu, ngati mtengo wojambulidwa udalembedwa ndi malo ogulitsira ndi [`Release`] (kapena wamphamvu) kuyitanitsa, ndiye kuti ntchito zonse zotsatila zimalamulidwa pambuyo pa sitoloyo.
    /// Makamaka, katundu yense wotsatira adzawona zambiri zolembedwa pamaso pa sitolo.
    ///
    /// Zindikirani kuti kugwiritsa ntchito kuyitanitsa kumeneku kwa ophatikiza katundu ndi masitolo kumabweretsa kugulitsa kwa [`Relaxed`]!
    ///
    /// Kulamula uku kumangogwira ntchito zomwe zingatengeke.
    ///
    /// Imafanana ndi [`memory_order_acquire`] mu C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Zili ndi zotsatira za [`Acquire`] ndi [`Release`] palimodzi:
    /// Katundu imagwiritsa ntchito kuyitanitsa [`Acquire`].Kwa masitolo imagwiritsa ntchito kuyitanitsa kwa [`Release`].
    ///
    /// Onani kuti pankhani ya `compare_and_swap`, nkutheka kuti opareshoniyo singathe kugulitsa sitolo iliyonse motero ili ndi kuyitanitsa kwa [`Acquire`] kokha.
    ///
    /// Komabe, `AcqRel` sidzachita mwayi wa [`Relaxed`].
    ///
    /// Kuitanitsa uku kumangogwira ntchito zomwe zimaphatikiza katundu ndi masitolo.
    ///
    /// Imafanana ndi [`memory_order_acq_rel`] mu C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Monga [`Pezani`]/[`Kutulutsa`]/[`AcqRel`](katundu, sitolo, ndi katundu wogulitsa m'sitolo, motsatana) ndi chitsimikizo chowonjezera chakuti ulusi wonse umawona ntchito zonse mosasinthasintha munjira yomweyo .
    ///
    ///
    /// Imafanana ndi [`memory_order_seq_cst`] mu C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// [`AtomicBool`] idayambitsidwa ku `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Amapanga `AtomicBool` yatsopano.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Imabwezeretsa kutanthauzira kosinthika kwa [`bool`] yoyambira.
    ///
    /// Izi ndizotetezeka chifukwa zomwe zimasinthidwa zimatsimikizira kuti palibe ulusi wina womwe umafikira nthawi yomweyo ku data ya atomiki.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // CHITETEZO: zomwe zimasinthidwa zimatsimikizira umwini wapadera.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Pezani mwayi wa atomiki ku `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // CHITETEZO: zomwe zimasinthidwa zimatsimikizira umwini wapadera, ndipo
        // mayikidwe a `bool` ndi `Self` ndi 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Amagwiritsa ntchito atomiki ndikubwezeretsanso zomwe zilipo.
    ///
    /// Izi ndizotetezeka chifukwa kupititsa `self` pamtengo kumatsimikizira kuti palibe ulusi wina womwe ukupeza nthawi yomweyo ma data a atomiki.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Kutenga mtengo kuchokera ku bool.
    ///
    /// `load` amatenga mkangano wa [`Ordering`] womwe umafotokoza zakumbukidwe kwa ntchitoyi.
    /// Zomwe zingatheke ndi [`SeqCst`], [`Acquire`] ndi [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ngati `order` ndi [`Release`] kapena [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // CHITETEZO: mitundu iliyonse yamtunduwu imapewedwa ndi zida za atomiki ndi zosaphika
        // cholozera chololedwa ndicholondola chifukwa tidachipeza kuchokera pakuwunika.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Imasunga mtengo mu bool.
    ///
    /// `store` amatenga mkangano wa [`Ordering`] womwe umafotokoza zakumbukidwe kwa ntchitoyi.
    /// Zomwe zingatheke ndi [`SeqCst`], [`Release`] ndi [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ngati `order` ndi [`Acquire`] kapena [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // CHITETEZO: mitundu iliyonse yamtunduwu imapewedwa ndi zida za atomiki ndi zosaphika
        // cholozera chololedwa ndicholondola chifukwa tidachipeza kuchokera pakuwunika.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Imasunga mtengo mu bool, ndikubwezeretsanso mtengo wapitawo.
    ///
    /// `swap` amatenga mkangano wa [`Ordering`] womwe umafotokoza zakumbukidwe kwa ntchitoyi.Mitundu yonse yoyitanitsa ndiyotheka.
    /// Dziwani kuti kugwiritsa ntchito [`Acquire`] kumapangitsa sitolo kukhala gawo la ntchitoyi [`Relaxed`], ndipo kugwiritsa ntchito [`Release`] kumapangitsa kuti katunduyo akhale gawo la [`Relaxed`].
    ///
    ///
    /// **Note:** Njirayi imapezeka pamapulatifomu omwe amathandizira ma atomiki pa `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // CHITETEZO: Mitundu yazidziwitso imapewedwa ndi ma atomiki amkati.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Imasunga mtengo mu [`bool`] ngati mtengo wapano ndi wofanana ndi `current`.
    ///
    /// Mtengo wobwerera nthawi zonse umakhala wamtengo wapatali.Ngati ndi ofanana ndi `current`, ndiye kuti mtengo udasinthidwa.
    ///
    /// `compare_and_swap` imatenganso mkangano wa [`Ordering`] womwe umafotokoza za kukumbukira kukumbukira kwa ntchitoyi.
    /// Zindikirani kuti ngakhale mutagwiritsa ntchito [`AcqRel`], opareshoniyo ikhoza kulephera motero ingoyesani `Acquire`, koma mulibe `Release` semantics.
    /// Kugwiritsa ntchito [`Acquire`] kumapangitsa sitolo kukhala gawo la ntchitoyi [`Relaxed`] ngati zichitika, ndipo kugwiritsa ntchito [`Release`] kumapangitsa kuti katunduyo akhale gawo la [`Relaxed`].
    ///
    /// **Note:** Njirayi imapezeka pamapulatifomu omwe amathandizira ma atomiki pa `u8`.
    ///
    /// # Kusamukira ku `compare_exchange` ndi `compare_exchange_weak`
    ///
    /// `compare_and_swap` ndiyofanana ndi `compare_exchange` yokhala ndi mapu otsatirawa kuti akumbukire kukumbukira:
    ///
    /// Choyambirira |Kupambana |Kulephera
    /// -------- | ------- | -------
    /// Omasulidwa |Omasulidwa |Khalani OmasukaPezani |Pezani Kumasulidwa |Tulutsani |Omasuka AcqRel |AcqRel |Pezani SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` amaloledwa kulephera mochititsa chidwi ngakhale kufananako kukupambana, komwe kumalola wopanga kuti apange code yabwino pamsonkhano pamene kufananiza ndi kusinthana kumagwiritsidwa ntchito mozungulira.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Imasunga mtengo mu [`bool`] ngati mtengo wapano ndi wofanana ndi `current`.
    ///
    /// Mtengo wobwezera ndi zotsatira zosonyeza ngati mtengo watsopanowo udalembedwa ndikukhala ndi mtengo wakale.
    /// Pakuchita bwino mtengowu ukutsimikizika kuti ungafanane ndi `current`.
    ///
    /// `compare_exchange` Zimatengera zifukwa ziwiri za [`Ordering`] kuti zifotokozere momwe ntchitoyo imagwirira ntchito.
    /// `success` imalongosola kuyitanitsa kofunikira kwa ntchito yowerenga-kusintha-kulemba yomwe imachitika ngati kuyerekezera ndi `current` kwapambana.
    /// `failure` ikufotokozera kuyitanitsa koyenera kwa ntchito yamagalimoto yomwe imachitika kufananizira kukulephera.
    /// Kugwiritsa ntchito [`Acquire`] pakulamula bwino kumapangitsa sitolo kukhala gawo la ntchitoyi [`Relaxed`], ndipo kugwiritsa ntchito [`Release`] kumapangitsa kuti katundu akhale [`Relaxed`] wopambana.
    ///
    /// Kulephera kulamula kumangokhala [`SeqCst`], [`Acquire`] kapena [`Relaxed`] ndipo kuyenera kukhala kofanana kapena kofooka kuposa kuyitanitsa bwino.
    ///
    /// **Note:** Njirayi imapezeka pamapulatifomu omwe amathandizira ma atomiki pa `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // CHITETEZO: Mitundu yazidziwitso imapewedwa ndi ma atomiki amkati.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Imasunga mtengo mu [`bool`] ngati mtengo wapano ndi wofanana ndi `current`.
    ///
    /// Mosiyana ndi [`AtomicBool::compare_exchange`], ntchitoyi imaloledwa kulephera modabwitsa ngakhale kufananizira kukupambana, komwe kumatha kubweretsa code yabwino pamapulatifomu ena.
    ///
    /// Mtengo wobwezera ndi zotsatira zosonyeza ngati mtengo watsopanowo udalembedwa ndikukhala ndi mtengo wakale.
    ///
    /// `compare_exchange_weak` Zimatengera zifukwa ziwiri za [`Ordering`] kuti zifotokozere momwe ntchitoyo imagwirira ntchito.
    /// `success` imalongosola kuyitanitsa kofunikira kwa ntchito yowerenga-kusintha-kulemba yomwe imachitika ngati kuyerekezera ndi `current` kwapambana.
    /// `failure` ikufotokozera kuyitanitsa koyenera kwa ntchito yamagalimoto yomwe imachitika kufananizira kukulephera.
    /// Kugwiritsa ntchito [`Acquire`] pakulamula bwino kumapangitsa sitolo kukhala gawo la ntchitoyi [`Relaxed`], ndipo kugwiritsa ntchito [`Release`] kumapangitsa kuti katundu akhale [`Relaxed`] wopambana.
    /// Kulephera kulamula kumangokhala [`SeqCst`], [`Acquire`] kapena [`Relaxed`] ndipo kuyenera kukhala kofanana kapena kofooka kuposa kuyitanitsa bwino.
    ///
    /// **Note:** Njirayi imapezeka pamapulatifomu omwe amathandizira ma atomiki pa `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // CHITETEZO: Mitundu yazidziwitso imapewedwa ndi ma atomiki amkati.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Logical "and" yokhala ndi mtengo wa boolean.
    ///
    /// Imagwira ntchito zomveka za "and" pamtengo wapano ndi kutsutsana `val`, ndikukhazikitsa mtengo watsopano pazotsatira.
    ///
    /// Kubwezeretsa mtengo wakale.
    ///
    /// `fetch_and` amatenga mkangano wa [`Ordering`] womwe umafotokoza zakumbukidwe kwa ntchitoyi.Mitundu yonse yoyitanitsa ndiyotheka.
    /// Dziwani kuti kugwiritsa ntchito [`Acquire`] kumapangitsa sitolo kukhala gawo la ntchitoyi [`Relaxed`], ndipo kugwiritsa ntchito [`Release`] kumapangitsa kuti katunduyo akhale gawo la [`Relaxed`].
    ///
    ///
    /// **Note:** Njirayi imapezeka pamapulatifomu omwe amathandizira ma atomiki pa `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // CHITETEZO: Mitundu yazidziwitso imapewedwa ndi ma atomiki amkati.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Logical "nand" yokhala ndi mtengo wa boolean.
    ///
    /// Imagwira ntchito zomveka za "nand" pamtengo wapano ndi kutsutsana `val`, ndikukhazikitsa mtengo watsopano pazotsatira.
    ///
    /// Kubwezeretsa mtengo wakale.
    ///
    /// `fetch_nand` amatenga mkangano wa [`Ordering`] womwe umafotokoza zakumbukidwe kwa ntchitoyi.Mitundu yonse yoyitanitsa ndiyotheka.
    /// Dziwani kuti kugwiritsa ntchito [`Acquire`] kumapangitsa sitolo kukhala gawo la ntchitoyi [`Relaxed`], ndipo kugwiritsa ntchito [`Release`] kumapangitsa kuti katunduyo akhale gawo la [`Relaxed`].
    ///
    ///
    /// **Note:** Njirayi imapezeka pamapulatifomu omwe amathandizira ma atomiki pa `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Sitingagwiritse ntchito atomic_nand pano chifukwa zitha kubweretsa bool ndi mtengo wosavomerezeka.
        // Izi zimachitika chifukwa ntchito ya atomiki imachitika ndi 8-bit integer mkati, zomwe zingapangitse mabatani 7 apamwamba.
        //
        // Chifukwa chake timangogwiritsa ntchito fetch_xor kapena swap m'malo mwake.
        if val {
            // (x&zoona)== !x Tiyenera kutembenuza bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&zabodza)==zowona Tiyenera kukhazikitsa bool kukhala zowona.
            //
            self.swap(true, order)
        }
    }

    /// Logical "or" yokhala ndi mtengo wa boolean.
    ///
    /// Imagwira ntchito zomveka za "or" pamtengo wapano ndi kutsutsana `val`, ndikukhazikitsa mtengo watsopano pazotsatira.
    ///
    /// Kubwezeretsa mtengo wakale.
    ///
    /// `fetch_or` amatenga mkangano wa [`Ordering`] womwe umafotokoza zakumbukidwe kwa ntchitoyi.Mitundu yonse yoyitanitsa ndiyotheka.
    /// Dziwani kuti kugwiritsa ntchito [`Acquire`] kumapangitsa sitolo kukhala gawo la ntchitoyi [`Relaxed`], ndipo kugwiritsa ntchito [`Release`] kumapangitsa kuti katunduyo akhale gawo la [`Relaxed`].
    ///
    ///
    /// **Note:** Njirayi imapezeka pamapulatifomu omwe amathandizira ma atomiki pa `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // CHITETEZO: Mitundu yazidziwitso imapewedwa ndi ma atomiki amkati.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Logical "xor" yokhala ndi mtengo wa boolean.
    ///
    /// Imagwira ntchito zomveka za "xor" pamtengo wapano ndi kutsutsana `val`, ndikukhazikitsa mtengo watsopano pazotsatira.
    ///
    /// Kubwezeretsa mtengo wakale.
    ///
    /// `fetch_xor` amatenga mkangano wa [`Ordering`] womwe umafotokoza zakumbukidwe kwa ntchitoyi.Mitundu yonse yoyitanitsa ndiyotheka.
    /// Dziwani kuti kugwiritsa ntchito [`Acquire`] kumapangitsa sitolo kukhala gawo la ntchitoyi [`Relaxed`], ndipo kugwiritsa ntchito [`Release`] kumapangitsa kuti katunduyo akhale gawo la [`Relaxed`].
    ///
    ///
    /// **Note:** Njirayi imapezeka pamapulatifomu omwe amathandizira ma atomiki pa `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // CHITETEZO: Mitundu yazidziwitso imapewedwa ndi ma atomiki amkati.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Kubwezeretsa chosinthira chosinthika ku [`bool`] yoyambira.
    ///
    /// Kuwerenga zomwe siziri za atomiki ndikulemba pazotsatira zonse zitha kukhala mpikisano wamtundu.
    /// Njirayi ndi yothandiza kwambiri pa FFI, pomwe siginecha ya ntchito ingagwiritse ntchito `*mut bool` m'malo mwa `&AtomicBool`.
    ///
    /// Kubwezeretsa pointer ya `*mut` kuchokera pamawu omwe agawana za atomiki iyi ndi kotetezeka chifukwa mitundu ya ma atomiki imagwira ntchito ndi kusinthika kwamkati.
    /// Zosintha zonse za atomiki zimasinthiratu mtengo wake pogwiritsa ntchito zomwe zagawidwa, ndipo zimatha kutero mosamala bola ngati zikugwiritsa ntchito ma atomiki.
    /// Kugwiritsa ntchito kwa pointer yaiwisi yobwezedwa kumafunikira cholembera `unsafe` ndipo kuyenerabe kutsatira zoletsa zomwezo: kuyigwiritsa ntchito kuyenera kukhala atomiki.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Imatenga phindu, ndikugwiritsa ntchito ntchito pamenepo yomwe imabwezeretsa mtengo watsopano.Kubwezeretsa `Result` ya `Ok(previous_value)` ngati ntchitoyo ibwezeretsa `Some(_)`, china `Err(previous_value)`.
    ///
    /// Note: Izi zitha kuyitanitsa ntchitoyi kangapo ngati mtengowo usinthidwa kuchokera ku ulusi wina pakadali pano, bola ntchitoyo ibwerere `Some(_)`, koma ntchitoyi idzagwiritsidwa ntchito kamodzi kokha pamtengo wosungidwa.
    ///
    ///
    /// `fetch_update` Zimatengera zifukwa ziwiri za [`Ordering`] kuti zifotokozere momwe ntchitoyo imagwirira ntchito.
    /// Yoyamba imafotokoza kuyitanitsa kofunikirako pomwe ntchitoyo ipambana pomwe yachiwiri ikufotokoza za kuyitanitsa katundu.
    /// Izi zikugwirizana ndi magwiridwe antchito ndi kulephera kwa [`AtomicBool::compare_exchange`] motsatana.
    ///
    /// Kugwiritsa ntchito [`Acquire`] monga kuyitanitsa bwino kumapangitsa sitolo kukhala gawo la ntchitoyi [`Relaxed`], ndipo kugwiritsa ntchito [`Release`] kumapangitsa kukhala komaliza kupambana [`Relaxed`].
    /// Kuitanitsa kwa (failed) kumatha kukhala [`SeqCst`], [`Acquire`] kapena [`Relaxed`] ndipo kuyenera kukhala kofanana kapena kofooka kuposa kuyitanitsa bwino.
    ///
    /// **Note:** Njirayi imapezeka pamapulatifomu omwe amathandizira ma atomiki pa `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Amapanga `AtomicPtr` yatsopano.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Kubwezeretsa kutanthauzira kosinthika kwa cholozera.
    ///
    /// Izi ndizotetezeka chifukwa zomwe zimasinthidwa zimatsimikizira kuti palibe ulusi wina womwe umafikira nthawi yomweyo ku data ya atomiki.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Pezani kulowa kwa atomiki pa cholozera.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - kusintha komwe kumatsimikizika kumatsimikizira umwini wapadera.
        //  - mayikidwe a `*mut T` ndi `Self` ndi ofanana pamapulatifomu onse othandizidwa ndi rust, monga zatsimikiziridwa pamwambapa.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Amagwiritsa ntchito atomiki ndikubwezeretsanso zomwe zilipo.
    ///
    /// Izi ndizotetezeka chifukwa kupititsa `self` pamtengo kumatsimikizira kuti palibe ulusi wina womwe ukupeza nthawi yomweyo ma data a atomiki.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Imanyamula mtengo kuchokera pacholozera.
    ///
    /// `load` amatenga mkangano wa [`Ordering`] womwe umafotokoza zakumbukidwe kwa ntchitoyi.
    /// Zomwe zingatheke ndi [`SeqCst`], [`Acquire`] ndi [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ngati `order` ndi [`Release`] kapena [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // CHITETEZO: Mitundu yazidziwitso imapewedwa ndi ma atomiki amkati.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Amasunga mtengo mu pointer.
    ///
    /// `store` amatenga mkangano wa [`Ordering`] womwe umafotokoza zakumbukidwe kwa ntchitoyi.
    /// Zomwe zingatheke ndi [`SeqCst`], [`Release`] ndi [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ngati `order` ndi [`Acquire`] kapena [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // CHITETEZO: Mitundu yazidziwitso imapewedwa ndi ma atomiki amkati.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Amasunga mtengo mu pointer, ndikubwezeretsanso mtengo wakale.
    ///
    /// `swap` amatenga mkangano wa [`Ordering`] womwe umafotokoza zakumbukidwe kwa ntchitoyi.Mitundu yonse yoyitanitsa ndiyotheka.
    /// Dziwani kuti kugwiritsa ntchito [`Acquire`] kumapangitsa sitolo kukhala gawo la ntchitoyi [`Relaxed`], ndipo kugwiritsa ntchito [`Release`] kumapangitsa kuti katunduyo akhale gawo la [`Relaxed`].
    ///
    ///
    /// **Note:** Njirayi imangopezeka papulatifomu yomwe imathandizira ma atomiki pama pointers.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // CHITETEZO: Mitundu yazidziwitso imapewedwa ndi ma atomiki amkati.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Imasungira mtengo mu pointer ngati mtengo wapano ndi wofanana ndi `current`.
    ///
    /// Mtengo wobwerera nthawi zonse umakhala wamtengo wapatali.Ngati ndi ofanana ndi `current`, ndiye kuti mtengo udasinthidwa.
    ///
    /// `compare_and_swap` imatenganso mkangano wa [`Ordering`] womwe umafotokoza za kukumbukira kukumbukira kwa ntchitoyi.
    /// Zindikirani kuti ngakhale mutagwiritsa ntchito [`AcqRel`], opareshoniyo ikhoza kulephera motero ingoyesani `Acquire`, koma mulibe `Release` semantics.
    /// Kugwiritsa ntchito [`Acquire`] kumapangitsa sitolo kukhala gawo la ntchitoyi [`Relaxed`] ngati zichitika, ndipo kugwiritsa ntchito [`Release`] kumapangitsa kuti katunduyo akhale gawo la [`Relaxed`].
    ///
    /// **Note:** Njirayi imangopezeka papulatifomu yomwe imathandizira ma atomiki pama pointers.
    ///
    /// # Kusamukira ku `compare_exchange` ndi `compare_exchange_weak`
    ///
    /// `compare_and_swap` ndiyofanana ndi `compare_exchange` yokhala ndi mapu otsatirawa kuti akumbukire kukumbukira:
    ///
    /// Choyambirira |Kupambana |Kulephera
    /// -------- | ------- | -------
    /// Omasulidwa |Omasulidwa |Khalani OmasukaPezani |Pezani Kumasulidwa |Tulutsani |Omasuka AcqRel |AcqRel |Pezani SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` amaloledwa kulephera mochititsa chidwi ngakhale kufananako kukupambana, komwe kumalola wopanga kuti apange code yabwino pamsonkhano pamene kufananiza ndi kusinthana kumagwiritsidwa ntchito mozungulira.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Imasungira mtengo mu pointer ngati mtengo wapano ndi wofanana ndi `current`.
    ///
    /// Mtengo wobwezera ndi zotsatira zosonyeza ngati mtengo watsopanowo udalembedwa ndikukhala ndi mtengo wakale.
    /// Pakuchita bwino mtengowu ukutsimikizika kuti ungafanane ndi `current`.
    ///
    /// `compare_exchange` Zimatengera zifukwa ziwiri za [`Ordering`] kuti zifotokozere momwe ntchitoyo imagwirira ntchito.
    /// `success` imalongosola kuyitanitsa kofunikira kwa ntchito yowerenga-kusintha-kulemba yomwe imachitika ngati kuyerekezera ndi `current` kwapambana.
    /// `failure` ikufotokozera kuyitanitsa koyenera kwa ntchito yamagalimoto yomwe imachitika kufananizira kukulephera.
    /// Kugwiritsa ntchito [`Acquire`] pakulamula bwino kumapangitsa sitolo kukhala gawo la ntchitoyi [`Relaxed`], ndipo kugwiritsa ntchito [`Release`] kumapangitsa kuti katundu akhale [`Relaxed`] wopambana.
    ///
    /// Kulephera kulamula kumangokhala [`SeqCst`], [`Acquire`] kapena [`Relaxed`] ndipo kuyenera kukhala kofanana kapena kofooka kuposa kuyitanitsa bwino.
    ///
    /// **Note:** Njirayi imangopezeka papulatifomu yomwe imathandizira ma atomiki pama pointers.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // CHITETEZO: Mitundu yazidziwitso imapewedwa ndi ma atomiki amkati.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Imasungira mtengo mu pointer ngati mtengo wapano ndi wofanana ndi `current`.
    ///
    /// Mosiyana ndi [`AtomicPtr::compare_exchange`], ntchitoyi imaloledwa kulephera modabwitsa ngakhale kufananizira kukupambana, komwe kumatha kubweretsa code yabwino pamapulatifomu ena.
    ///
    /// Mtengo wobwezera ndi zotsatira zosonyeza ngati mtengo watsopanowo udalembedwa ndikukhala ndi mtengo wakale.
    ///
    /// `compare_exchange_weak` Zimatengera zifukwa ziwiri za [`Ordering`] kuti zifotokozere momwe ntchitoyo imagwirira ntchito.
    /// `success` imalongosola kuyitanitsa kofunikira kwa ntchito yowerenga-kusintha-kulemba yomwe imachitika ngati kuyerekezera ndi `current` kwapambana.
    /// `failure` ikufotokozera kuyitanitsa koyenera kwa ntchito yamagalimoto yomwe imachitika kufananizira kukulephera.
    /// Kugwiritsa ntchito [`Acquire`] pakulamula bwino kumapangitsa sitolo kukhala gawo la ntchitoyi [`Relaxed`], ndipo kugwiritsa ntchito [`Release`] kumapangitsa kuti katundu akhale [`Relaxed`] wopambana.
    /// Kulephera kulamula kumangokhala [`SeqCst`], [`Acquire`] kapena [`Relaxed`] ndipo kuyenera kukhala kofanana kapena kofooka kuposa kuyitanitsa bwino.
    ///
    /// **Note:** Njirayi imangopezeka papulatifomu yomwe imathandizira ma atomiki pama pointers.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // CHITETEZO: Izi ndizosavomerezeka chifukwa zimagwira cholozera chosaphika
        // koma tikudziwa motsimikiza kuti cholozera ndi chovomerezeka (tachipeza kuchokera ku `UnsafeCell` yomwe tili nayo) ndipo ntchito ya atomiki yomwe ikutilola kuti tisinthe mosamala zomwe zili mu `UnsafeCell`.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Imatenga phindu, ndikugwiritsa ntchito ntchito pamenepo yomwe imabwezeretsa mtengo watsopano.Kubwezeretsa `Result` ya `Ok(previous_value)` ngati ntchitoyo ibwezeretsa `Some(_)`, china `Err(previous_value)`.
    ///
    /// Note: Izi zitha kuyitanitsa ntchitoyi kangapo ngati mtengowo usinthidwa kuchokera ku ulusi wina pakadali pano, bola ntchitoyo ibwerere `Some(_)`, koma ntchitoyi idzagwiritsidwa ntchito kamodzi kokha pamtengo wosungidwa.
    ///
    ///
    /// `fetch_update` Zimatengera zifukwa ziwiri za [`Ordering`] kuti zifotokozere momwe ntchitoyo imagwirira ntchito.
    /// Yoyamba imafotokoza kuyitanitsa kofunikirako pomwe ntchitoyo ipambana pomwe yachiwiri ikufotokoza za kuyitanitsa katundu.
    /// Izi zikugwirizana ndi magwiridwe antchito ndi kulephera kwa [`AtomicPtr::compare_exchange`] motsatana.
    ///
    /// Kugwiritsa ntchito [`Acquire`] monga kuyitanitsa bwino kumapangitsa sitolo kukhala gawo la ntchitoyi [`Relaxed`], ndipo kugwiritsa ntchito [`Release`] kumapangitsa kukhala komaliza kupambana [`Relaxed`].
    /// Kuitanitsa kwa (failed) kumatha kukhala [`SeqCst`], [`Acquire`] kapena [`Relaxed`] ndipo kuyenera kukhala kofanana kapena kofooka kuposa kuyitanitsa bwino.
    ///
    /// **Note:** Njirayi imangopezeka papulatifomu yomwe imathandizira ma atomiki pama pointers.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Imatembenuza `bool` kukhala `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Izi zimatha kugwiritsidwa ntchito pazinthu zina zomangamanga.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Mtundu wochulukirapo womwe ungathe kugawidwa bwino pakati pa ulusi.
        ///
        /// Mtundu uwu uli ndi chiwonetsero chofananira chakumbukiro monga mtundu waukulu wa integer, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Kuti mumve zambiri zakusiyana pakati pa mitundu ya ma atomiki ndi mitundu yopanda ma atomiki komanso chidziwitso chokhudzidwa kwa mtundu uwu, chonde onani [module-level documentation].
        ///
        ///
        /// **Note:** Mtundu uwu umangopezeka pamapulatifomu omwe amathandizira katundu wa atomiki ndi malo ogulitsira a [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Chiwerengero chokwanira cha atomiki choyambitsidwa ku `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Kutumiza kumayendetsedwa kwathunthu.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Amapanga nambala yatsopano ya atomiki.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Kubwezeretsa kutanthauzira kosinthika kwa nambala yonseyo.
            ///
            /// Izi ndizotetezeka chifukwa zomwe zimasinthidwa zimatsimikizira kuti palibe ulusi wina womwe umafikira nthawi yomweyo ku data ya atomiki.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// lolani ena_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// onetsetsani_eq! (ena_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - kusintha komwe kumatsimikizika kumatsimikizira umwini wapadera.
                //  - mayendedwe a `$int_type` ndi `Self` ndi ofanana, monga analonjezera $cfg_align ndi kutsimikiziridwa pamwambapa.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Amagwiritsa ntchito atomiki ndikubwezeretsanso zomwe zilipo.
            ///
            /// Izi ndizotetezeka chifukwa kupititsa `self` pamtengo kumatsimikizira kuti palibe ulusi wina womwe ukupeza nthawi yomweyo ma data a atomiki.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Kutenga mtengo kuchokera ku nambala ya atomiki.
            ///
            /// `load` amatenga mkangano wa [`Ordering`] womwe umafotokoza zakumbukidwe kwa ntchitoyi.
            /// Zomwe zingatheke ndi [`SeqCst`], [`Acquire`] ndi [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics ngati `order` ndi [`Release`] kapena [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // CHITETEZO: Mitundu yazidziwitso imapewedwa ndi ma atomiki amkati.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Imasungira mtengo mu nambala ya atomiki.
            ///
            /// `store` amatenga mkangano wa [`Ordering`] womwe umafotokoza zakumbukidwe kwa ntchitoyi.
            ///  Zomwe zingatheke ndi [`SeqCst`], [`Release`] ndi [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics ngati `order` ndi [`Acquire`] kapena [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // CHITETEZO: Mitundu yazidziwitso imapewedwa ndi ma atomiki amkati.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Amasunga mtengo mu nambala ya atomiki, ndikubwezera mtengo wake wakale.
            ///
            /// `swap` amatenga mkangano wa [`Ordering`] womwe umafotokoza zakumbukidwe kwa ntchitoyi.Mitundu yonse yoyitanitsa ndiyotheka.
            /// Dziwani kuti kugwiritsa ntchito [`Acquire`] kumapangitsa sitolo kukhala gawo la ntchitoyi [`Relaxed`], ndipo kugwiritsa ntchito [`Release`] kumapangitsa kuti katunduyo akhale gawo la [`Relaxed`].
            ///
            ///
            /// **Dziwani**: Njirayi imangopezeka papulatifomu yomwe imathandizira ma atomiki
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // CHITETEZO: Mitundu yazidziwitso imapewedwa ndi ma atomiki amkati.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Imasunga mtengo mu nambala yonse ya atomiki ngati phindu lake ndilofanana ndi mtengo wa `current`.
            ///
            /// Mtengo wobwerera nthawi zonse umakhala wamtengo wapatali.Ngati ndi ofanana ndi `current`, ndiye kuti mtengo udasinthidwa.
            ///
            /// `compare_and_swap` imatenganso mkangano wa [`Ordering`] womwe umafotokoza za kukumbukira kukumbukira kwa ntchitoyi.
            /// Zindikirani kuti ngakhale mutagwiritsa ntchito [`AcqRel`], opareshoniyo ikhoza kulephera motero ingoyesani `Acquire`, koma mulibe `Release` semantics.
            ///
            /// Kugwiritsa ntchito [`Acquire`] kumapangitsa sitolo kukhala gawo la ntchitoyi [`Relaxed`] ngati zichitika, ndipo kugwiritsa ntchito [`Release`] kumapangitsa kuti katunduyo akhale gawo la [`Relaxed`].
            ///
            /// **Dziwani**: Njirayi imangopezeka papulatifomu yomwe imathandizira ma atomiki
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Kusamukira ku `compare_exchange` ndi `compare_exchange_weak`
            ///
            /// `compare_and_swap` ndiyofanana ndi `compare_exchange` yokhala ndi mapu otsatirawa kuti akumbukire kukumbukira:
            ///
            /// Choyambirira |Kupambana |Kulephera
            /// -------- | ------- | -------
            /// Omasulidwa |Omasulidwa |Khalani OmasukaPezani |Pezani Kumasulidwa |Tulutsani |Omasuka AcqRel |AcqRel |Pezani SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` amaloledwa kulephera mochititsa chidwi ngakhale kufananako kukupambana, komwe kumalola wopanga kuti apange code yabwino pamsonkhano pamene kufananiza ndi kusinthana kumagwiritsidwa ntchito mozungulira.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Imasunga mtengo mu nambala yonse ya atomiki ngati phindu lake ndilofanana ndi mtengo wa `current`.
            ///
            /// Mtengo wobwezera ndi zotsatira zosonyeza ngati mtengo watsopanowo udalembedwa ndikukhala ndi mtengo wakale.
            /// Pakuchita bwino mtengowu ukutsimikizika kuti ungafanane ndi `current`.
            ///
            /// `compare_exchange` Zimatengera zifukwa ziwiri za [`Ordering`] kuti zifotokozere momwe ntchitoyo imagwirira ntchito.
            /// `success` imalongosola kuyitanitsa kofunikira kwa ntchito yowerenga-kusintha-kulemba yomwe imachitika ngati kuyerekezera ndi `current` kwapambana.
            /// `failure` ikufotokozera kuyitanitsa koyenera kwa ntchito yamagalimoto yomwe imachitika kufananizira kukulephera.
            /// Kugwiritsa ntchito [`Acquire`] pakulamula bwino kumapangitsa sitolo kukhala gawo la ntchitoyi [`Relaxed`], ndipo kugwiritsa ntchito [`Release`] kumapangitsa kuti katundu akhale [`Relaxed`] wopambana.
            ///
            /// Kulephera kulamula kumangokhala [`SeqCst`], [`Acquire`] kapena [`Relaxed`] ndipo kuyenera kukhala kofanana kapena kofooka kuposa kuyitanitsa bwino.
            ///
            /// **Dziwani**: Njirayi imangopezeka papulatifomu yomwe imathandizira ma atomiki
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // CHITETEZO: Mitundu yazidziwitso imapewedwa ndi ma atomiki amkati.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Imasunga mtengo mu nambala yonse ya atomiki ngati phindu lake ndilofanana ndi mtengo wa `current`.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// Ntchitoyi imaloledwa kulephera mochititsa chidwi ngakhale kufananako kukapambana, zomwe zitha kupangitsa kuti pakhale malamulo oyenera pamapulatifomu ena.
            /// Mtengo wobwezera ndi zotsatira zosonyeza ngati mtengo watsopanowo udalembedwa ndikukhala ndi mtengo wakale.
            ///
            /// `compare_exchange_weak` Zimatengera zifukwa ziwiri za [`Ordering`] kuti zifotokozere momwe ntchitoyo imagwirira ntchito.
            /// `success` imalongosola kuyitanitsa kofunikira kwa ntchito yowerenga-kusintha-kulemba yomwe imachitika ngati kuyerekezera ndi `current` kwapambana.
            /// `failure` ikufotokozera kuyitanitsa koyenera kwa ntchito yamagalimoto yomwe imachitika kufananizira kukulephera.
            /// Kugwiritsa ntchito [`Acquire`] pakulamula bwino kumapangitsa sitolo kukhala gawo la ntchitoyi [`Relaxed`], ndipo kugwiritsa ntchito [`Release`] kumapangitsa kuti katundu akhale [`Relaxed`] wopambana.
            ///
            /// Kulephera kulamula kumangokhala [`SeqCst`], [`Acquire`] kapena [`Relaxed`] ndipo kuyenera kukhala kofanana kapena kofooka kuposa kuyitanitsa bwino.
            ///
            /// **Dziwani**: Njirayi imangopezeka papulatifomu yomwe imathandizira ma atomiki
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// lolani zakale= val.load(Ordering::Relaxed);
            /// kuzungulira {let new=old * 2;
            ///     fananizani val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // CHITETEZO: Mitundu yazidziwitso imapewedwa ndi ma atomiki amkati.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Ikuwonjezera pamtengo wapano, ndikubwezeretsanso mtengo wam'mbuyomu.
            ///
            /// Ntchitoyi imazungulira pakusefukira.
            ///
            /// `fetch_add` amatenga mkangano wa [`Ordering`] womwe umafotokoza zakumbukidwe kwa ntchitoyi.Mitundu yonse yoyitanitsa ndiyotheka.
            /// Dziwani kuti kugwiritsa ntchito [`Acquire`] kumapangitsa sitolo kukhala gawo la ntchitoyi [`Relaxed`], ndipo kugwiritsa ntchito [`Release`] kumapangitsa kuti katunduyo akhale gawo la [`Relaxed`].
            ///
            ///
            /// **Dziwani**: Njirayi imangopezeka papulatifomu yomwe imathandizira ma atomiki
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // CHITETEZO: Mitundu yazidziwitso imapewedwa ndi ma atomiki amkati.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Kuchotsa pamtengo wapano, kubweza mtengo wam'mbuyomu.
            ///
            /// Ntchitoyi imazungulira pakusefukira.
            ///
            /// `fetch_sub` amatenga mkangano wa [`Ordering`] womwe umafotokoza zakumbukidwe kwa ntchitoyi.Mitundu yonse yoyitanitsa ndiyotheka.
            /// Dziwani kuti kugwiritsa ntchito [`Acquire`] kumapangitsa sitolo kukhala gawo la ntchitoyi [`Relaxed`], ndipo kugwiritsa ntchito [`Release`] kumapangitsa kuti katunduyo akhale gawo la [`Relaxed`].
            ///
            ///
            /// **Dziwani**: Njirayi imangopezeka papulatifomu yomwe imathandizira ma atomiki
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // CHITETEZO: Mitundu yazidziwitso imapewedwa ndi ma atomiki amkati.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Pang'ono pang'ono "and" ndimtengo wapano.
            ///
            /// Imagwira pang'ono pang'ono "and" pamtengo wapano ndi `val`, ndikukhazikitsa mtengo watsopano pazotsatira.
            ///
            /// Kubwezeretsa mtengo wakale.
            ///
            /// `fetch_and` amatenga mkangano wa [`Ordering`] womwe umafotokoza zakumbukidwe kwa ntchitoyi.Mitundu yonse yoyitanitsa ndiyotheka.
            /// Dziwani kuti kugwiritsa ntchito [`Acquire`] kumapangitsa sitolo kukhala gawo la ntchitoyi [`Relaxed`], ndipo kugwiritsa ntchito [`Release`] kumapangitsa kuti katunduyo akhale gawo la [`Relaxed`].
            ///
            ///
            /// **Dziwani**: Njirayi imangopezeka papulatifomu yomwe imathandizira ma atomiki
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // CHITETEZO: Mitundu yazidziwitso imapewedwa ndi ma atomiki amkati.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Pang'ono pang'ono "nand" ndimtengo wapano.
            ///
            /// Imagwira pang'ono pang'ono "nand" pamtengo wapano ndi `val`, ndikukhazikitsa mtengo watsopano pazotsatira.
            ///
            /// Kubwezeretsa mtengo wakale.
            ///
            /// `fetch_nand` amatenga mkangano wa [`Ordering`] womwe umafotokoza zakumbukidwe kwa ntchitoyi.Mitundu yonse yoyitanitsa ndiyotheka.
            /// Dziwani kuti kugwiritsa ntchito [`Acquire`] kumapangitsa sitolo kukhala gawo la ntchitoyi [`Relaxed`], ndipo kugwiritsa ntchito [`Release`] kumapangitsa kuti katunduyo akhale gawo la [`Relaxed`].
            ///
            ///
            /// **Dziwani**: Njirayi imangopezeka papulatifomu yomwe imathandizira ma atomiki
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // CHITETEZO: Mitundu yazidziwitso imapewedwa ndi ma atomiki amkati.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Pang'ono pang'ono "or" ndimtengo wapano.
            ///
            /// Imagwira pang'ono pang'ono "or" pamtengo wapano ndi `val` yotsutsana, ndikukhazikitsa mtengo watsopano pazotsatira.
            ///
            /// Kubwezeretsa mtengo wakale.
            ///
            /// `fetch_or` amatenga mkangano wa [`Ordering`] womwe umafotokoza zakumbukidwe kwa ntchitoyi.Mitundu yonse yoyitanitsa ndiyotheka.
            /// Dziwani kuti kugwiritsa ntchito [`Acquire`] kumapangitsa sitolo kukhala gawo la ntchitoyi [`Relaxed`], ndipo kugwiritsa ntchito [`Release`] kumapangitsa kuti katunduyo akhale gawo la [`Relaxed`].
            ///
            ///
            /// **Dziwani**: Njirayi imangopezeka papulatifomu yomwe imathandizira ma atomiki
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // CHITETEZO: Mitundu yazidziwitso imapewedwa ndi ma atomiki amkati.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Pang'ono pang'ono "xor" ndimtengo wapano.
            ///
            /// Imagwira pang'ono pang'ono "xor" pamtengo wapano ndi `val`, ndikukhazikitsa mtengo watsopano pazotsatira.
            ///
            /// Kubwezeretsa mtengo wakale.
            ///
            /// `fetch_xor` amatenga mkangano wa [`Ordering`] womwe umafotokoza zakumbukidwe kwa ntchitoyi.Mitundu yonse yoyitanitsa ndiyotheka.
            /// Dziwani kuti kugwiritsa ntchito [`Acquire`] kumapangitsa sitolo kukhala gawo la ntchitoyi [`Relaxed`], ndipo kugwiritsa ntchito [`Release`] kumapangitsa kuti katunduyo akhale gawo la [`Relaxed`].
            ///
            ///
            /// **Dziwani**: Njirayi imangopezeka papulatifomu yomwe imathandizira ma atomiki
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // CHITETEZO: Mitundu yazidziwitso imapewedwa ndi ma atomiki amkati.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Imatenga phindu, ndikugwiritsa ntchito ntchito pamenepo yomwe imabwezeretsa mtengo watsopano.Kubwezeretsa `Result` ya `Ok(previous_value)` ngati ntchitoyo ibwezeretsa `Some(_)`, china `Err(previous_value)`.
            ///
            /// Note: Izi zitha kuyitanitsa ntchitoyi kangapo ngati mtengowo usinthidwa kuchokera ku ulusi wina pakadali pano, bola ntchitoyo ibwerere `Some(_)`, koma ntchitoyi idzagwiritsidwa ntchito kamodzi kokha pamtengo wosungidwa.
            ///
            ///
            /// `fetch_update` Zimatengera zifukwa ziwiri za [`Ordering`] kuti zifotokozere momwe ntchitoyo imagwirira ntchito.
            /// Yoyamba imafotokoza kuyitanitsa kofunikirako pomwe ntchitoyo ipambana pomwe yachiwiri ikufotokoza za kuyitanitsa katundu.Izi zikugwirizana ndi magwiridwe antchito ndi kulephera kwa
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Kugwiritsa ntchito [`Acquire`] monga kuyitanitsa bwino kumapangitsa sitolo kukhala gawo la ntchitoyi [`Relaxed`], ndipo kugwiritsa ntchito [`Release`] kumapangitsa kukhala komaliza kupambana [`Relaxed`].
            /// Kuitanitsa kwa (failed) kumatha kukhala [`SeqCst`], [`Acquire`] kapena [`Relaxed`] ndipo kuyenera kukhala kofanana kapena kofooka kuposa kuyitanitsa bwino.
            ///
            /// **Dziwani**: Njirayi imangopezeka papulatifomu yomwe imathandizira ma atomiki
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Kulamula: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Kulamula: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Zolemba malire ndi phindu panopa.
            ///
            /// Imapeza kuchuluka kwa mtengo wapano ndi kutsutsana `val`, ndikukhazikitsa mtengo watsopano pazotsatira.
            ///
            /// Kubwezeretsa mtengo wakale.
            ///
            /// `fetch_max` amatenga mkangano wa [`Ordering`] womwe umafotokoza zakumbukidwe kwa ntchitoyi.Mitundu yonse yoyitanitsa ndiyotheka.
            /// Dziwani kuti kugwiritsa ntchito [`Acquire`] kumapangitsa sitolo kukhala gawo la ntchitoyi [`Relaxed`], ndipo kugwiritsa ntchito [`Release`] kumapangitsa kuti katunduyo akhale gawo la [`Relaxed`].
            ///
            ///
            /// **Dziwani**: Njirayi imangopezeka papulatifomu yomwe imathandizira ma atomiki
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// lolani bala=42;
            /// lolani max_foo=foo.fetch_max (bar, Ordering::SeqCst).max(bar);
            /// onetsetsani! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // CHITETEZO: Mitundu yazidziwitso imapewedwa ndi ma atomiki amkati.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Zochepa ndi mtengo wapano.
            ///
            /// Ikupeza kuchepa kwa mtengo wapano ndi kutsutsana `val`, ndikuyika mtengo watsopano pazotsatira.
            ///
            /// Kubwezeretsa mtengo wakale.
            ///
            /// `fetch_min` amatenga mkangano wa [`Ordering`] womwe umafotokoza zakumbukidwe kwa ntchitoyi.Mitundu yonse yoyitanitsa ndiyotheka.
            /// Dziwani kuti kugwiritsa ntchito [`Acquire`] kumapangitsa sitolo kukhala gawo la ntchitoyi [`Relaxed`], ndipo kugwiritsa ntchito [`Release`] kumapangitsa kuti katunduyo akhale gawo la [`Relaxed`].
            ///
            ///
            /// **Dziwani**: Njirayi imangopezeka papulatifomu yomwe imathandizira ma atomiki
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// lolani bala=12;
            /// lolani min_foo=foo.fetch_min (bar, Ordering::SeqCst).min(bar);
            /// onetsetsani_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // CHITETEZO: Mitundu yazidziwitso imapewedwa ndi ma atomiki amkati.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Kubwezeretsa chosinthira chosinthika ku nambala yoyamba.
            ///
            /// Kuwerenga zomwe siziri za atomiki ndikulemba pazotsatira zonse zitha kukhala mpikisano wamtundu.
            /// Njirayi imathandiza kwambiri pa FFI, pomwe siginecha ya ntchito ingagwiritse ntchito
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Kubwezeretsa pointer ya `*mut` kuchokera pamawu omwe agawana za atomiki iyi ndi kotetezeka chifukwa mitundu ya ma atomiki imagwira ntchito ndi kusinthika kwamkati.
            /// Zosintha zonse za atomiki zimasinthiratu mtengo wake pogwiritsa ntchito zomwe zagawidwa, ndipo zimatha kutero mosamala bola ngati zikugwiritsa ntchito ma atomiki.
            /// Kugwiritsa ntchito kwa pointer yaiwisi yobwezedwa kumafunikira cholembera `unsafe` ndipo kuyenerabe kutsatira zoletsa zomwezo: kuyigwiritsa ntchito kuyenera kukhala atomiki.
            ///
            ///
            /// # Examples
            ///
            /// `` samanyalanyaza (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// kunja "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // CHITETEZO: Otetezeka malinga ngati `my_atomic_op` ili atomiki.
            /// osatetezeka {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Kubwezeretsa mtengo wakale (monga __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Kubwezeretsa mtengo wakale (monga __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// imabweza mtengo wa max (kuyerekezera kusaina)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// imabweza mtengo wa min (kuyerekezera kusaina)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// imabwezeretsa mtengo wamtengo wapatali (kufananizira kosainidwa)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// imabweza mtengo wa min (kuyerekezera kosainidwa)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Mpanda wa atomiki.
///
/// Kutengera dongosolo lomwe latchulidwalo, mpanda umalepheretsa wopanga makina ndi CPU kuti asanjenso mitundu ina yazokumbukira mozungulira.
/// Izi zimapanga kulumikizana-ndi maubale pakati pake ndi machitidwe a atomiki kapena mipanda mu ulusi wina.
///
/// Fence 'A' yomwe ili ndi (osachepera) [`Release`] yoyitanitsa semantics, imagwirizana ndi mpanda 'B' ndi (osachepera) [`Acquire`] semantics, ngati pokhapokha ngati pali X ndi Y, zonse zikugwira ntchito pa chinthu china cha atomiki 'M' kotero kuti A idasungidwa kale X, Y imagwirizanitsidwa pamaso pa B ndi Y atawona kusintha kwa M.
/// Izi zimapereka kudalira musanadalire pakati pa A ndi B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Ntchito za atomiki ndi [`Release`] kapena [`Acquire`] semantics itha kugwirizananso ndi mpanda.
///
/// Mpanda womwe uli ndi kuyitanitsa kwa [`SeqCst`], kuphatikiza pakupanga semantics ya [`Acquire`] ndi [`Release`], umagwira nawo ntchito pulogalamu yapadziko lonse lapansi yama [`SeqCst`] ena ndi/kapena mipanda.
///
/// Amalandira [`Acquire`], [`Release`], [`AcqRel`] ndi [`SeqCst`].
///
/// # Panics
///
/// Panics ngati `order` ndi [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Kuchotserana koyambirira koyambira pa spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Dikirani mpaka phindu lakale ndi `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Mpanda uwu umalumikizana-ndi sitolo ku `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // CHITETEZO: kugwiritsa ntchito mpanda wa atomiki ndikotetezeka.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Mpanda wokumbukira.
///
/// `compiler_fence` sikutulutsa makina aliwonse, koma imaletsa mitundu yonse yakukumbutsanso komwe wolemba amaloledwa kuchita.Makamaka, kutengera ma semantics a [`Ordering`], wopanga akhoza kuloledwa kusuntha kuwerenga kapena kulemba kuchokera kusanachitike kapena pambuyo poyitanitsa mbali inayo ya `compiler_fence`.Dziwani kuti sikuteteza **hardware* kuti isapangire kuyitanitsanso koteroko.
///
/// Ili si vuto pamtundu umodzi, kupha, koma ulusi wina ukasintha kukumbukira nthawi yomweyo, zofunikira zoyanjanitsa zolimba monga [`fence`] zimafunikira.
///
/// Kubwezeretsanso kotetezedwa ndi ma semantics osiyanasiyana ndi:
///
///  - ndi [`SeqCst`], palibe kuyitanitsanso kowerengera ndikulemba pamfundo iyi kumaloledwa.
///  - ndi [`Release`], kuwerenga koyambirira ndikulemba sikungasunthidwe kalekale.
///  - ndi [`Acquire`], zomwe zimawerengedwa ndikulemba pambuyo pake sizingasunthidwe kuposa kuwerenga koyambirira.
///  - ndi [`AcqRel`], malamulo onsewa ali pamwamba.
///
/// `compiler_fence` Nthawi zambiri imakhala yothandiza popewa ulusi wothamanga ndi iwowo *.Ndiye kuti, ngati ulusi wopatsidwa ukugwiritsa ntchito kachidindo kamodzi, kenako ndikusokonezedwa, ndikuyamba kupanga nambala kwina (mukadali mu ulusi womwewo, ndikuganiza chimodzimodzi).M'mapulogalamu achikhalidwe, izi zimatha kuchitika pokhapokha ngati cholembetsa chizindikiritso chalembetsedwa.
/// M'makhodi otsika kwambiri, zinthu ngati izi zitha kuchitika mukamagwiritsa ntchito zosokoneza, mukamagwiritsa ulusi wobiriwira musanadule, etc.
/// Owerenga chidwi amalimbikitsidwa kuti awerenge zokambirana za Linux za [memory barriers].
///
/// # Panics
///
/// Panics ngati `order` ndi [`Relaxed`].
///
/// # Examples
///
/// Popanda `compiler_fence`, `assert_eq!` pakutsatira nambala * siyotsimikizika kuti ichita bwino, ngakhale chilichonse chikuchitika mu ulusi umodzi.
/// Kuti muwone chifukwa chake, kumbukirani kuti wopanga ndiwosintha masitolo kukhala `IMPORTANT_VARIABLE` ndi `IS_READ` popeza onse ndi `Ordering::Relaxed`.Ngati zingatero, ndipo cholembera chizindikirocho apemphedwa atangomaliza `IS_READY`, ndiye kuti wothandizira mbalayo awona `IS_READY=1`, koma `IMPORTANT_VARIABLE=0`.
/// Kugwiritsa ntchito mankhwala a `compiler_fence` izi.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // pewani kalembera kuti asasunthike kupitilira apa
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // CHITETEZO: kugwiritsa ntchito mpanda wa atomiki ndikotetezeka.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Amadziwitsa purosesa kuti ili mkati modikirira kozungulira ("spin loko").
///
/// Ntchitoyi idachotsedwa m'malo mwa [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}