//! `Clone` trait yamitundu yomwe sangathe 'kukopera kwathunthu'.
//!
//! Mu Rust, mitundu ina yosavuta ndi "implicitly copyable" ndipo mukawagawira kapena kuwapatsa ngati zotsutsana, wolandirayo adzalandira kope, ndikusiya mtengo woyambirira.
//! Mitundu iyi sikufuna kugawidwa kuti ikopeke ndipo ilibe omaliza (mwachitsanzo, alibe mabokosi omwe ali nawo kapena kukhazikitsa [`Drop`]), chifukwa chake wopanga amawona kuti ndiotsika mtengo komanso otetezeka kutengera.
//!
//! Kwa mitundu ina makope ayenera kufotokozedwa momveka bwino, pokonzekera msonkhano [`Clone`] trait ndikuyitanitsa njira ya [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Chitsanzo chogwiritsira ntchito:
//!
//! ```
//! let s = String::new(); // Zingwe zamtundu wazingwe Clone
//! let copy = s.clone(); // kotero ife tikhoza kuchiyerekeza icho
//! ```
//!
//! Kuti mugwiritse ntchito Clone trait mosavuta, mutha kugwiritsanso ntchito `#[derive(Clone)]`.Chitsanzo:
//!
//! ```
//! #[derive(Clone)] // timawonjezera Clone trait ku Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // ndipo tsopano titha kuzipanga!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// trait wamba yokhoza kutengera chinthu mwatsatanetsatane.
///
/// Zimasiyana ndi [`Copy`] chifukwa [`Copy`] ndiyopanda tanthauzo komanso yotsika mtengo kwambiri, pomwe `Clone` imakhala yowonekera nthawi zonse ndipo itha kukhala kapena yotsika mtengo.
/// Pofuna kutsimikizira izi, Rust siyikulolani kuti mupatsenso [`Copy`], koma mutha kuyambiranso `Clone` ndikuyendetsa nambala yanu mosasinthasintha.
///
/// Popeza `Clone` ndiyoposa [`Copy`], mutha kupanga chilichonse [`Copy`] kukhala `Clone`.
///
/// ## Derivable
///
/// trait itha kugwiritsidwa ntchito ndi `#[derive]` ngati magawo onse ali `Clone`.Kukhazikitsidwa kwa `derive`d kwa [`Clone`] kuyimbira [`clone`] pamunda uliwonse.
///
/// [`clone`]: Clone::clone
///
/// Pogwiritsa ntchito generic, `#[derive]` imagwiritsa ntchito `Clone` pokhapokha powonjezera `Clone` pamiyeso yabwinobwino.
///
/// ```
/// // `derive` imathandizira Clone for Reading<T>pamene T ndi Clone.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Kodi ndingagwiritse ntchito bwanji `Clone`?
///
/// Mitundu yomwe ili [`Copy`] iyenera kukhala ndi kukhazikitsa kochepa kwa `Clone`.Zowonjezera:
/// ngati `T: Copy`, `x: T`, ndi `y: &T`, ndiye kuti `let x = y.clone();` ndiyofanana ndi `let x = *y;`.
/// Kukhazikitsa pamanja kuyenera kusamala kuti zithandizire izi;komabe, nambala yosatetezeka sayenera kudalira kuti iwonetsetse kukumbukira kukumbukira.
///
/// Chitsanzo ndi generic struct yokhala ndi cholozera ntchito.Poterepa, kukhazikitsidwa kwa `Clone` sikungatengeredwe, koma kungachitike ngati:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Otsatira owonjezera
///
/// Kuphatikiza pa [implementors listed below][impls], mitundu yotsatirayi imagwiritsanso ntchito `Clone`:
///
/// * Mitundu yazinthu zogwirira ntchito (mwachitsanzo, mitundu yosiyanitsidwa ndi ntchito iliyonse)
/// * Mitundu yolozera (monga, `fn() -> i32`)
/// * Mitundu yazingwe zamitundu yonse, ngati mtunduwo ukugwiritsanso ntchito `Clone` (mwachitsanzo, `[i32; 123456]`)
/// * Mitundu yamitundumitundu, ngati chilichonse chimagwiritsanso ntchito `Clone` (mwachitsanzo, `()`, `(i32, bool)`)
/// * Mitundu yotsekedwa, ngati ilibe phindu lililonse kuchokera kuzachilengedwe kapena ngati malingaliro onse oterewa amatsatira `Clone` iwowo.
///   Dziwani kuti zosintha zomwe zimagawidwa nthawi zonse zimagwiritsa ntchito `Clone` (ngakhale zosiyanazo sizitero), pomwe zosintha zomwe zimasinthidwa sizigwiritsa ntchito `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Bweretsani kopi yamtengo.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str zida Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Amachita zokopera kuchokera ku `source`.
    ///
    /// `a.clone_from(&b)` ndiyofanana ndi `a = b.clone()` mu magwiridwe antchito, koma itha kulembedwa kuti mugwiritsenso ntchito zida za `a` kupewa magawidwe osafunikira.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Pezani zazikulu zomwe zikupanga trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): zomangazi zimagwiritsidwa ntchito ndi#[derive] kutsimikizira kuti gawo lililonse lamtunduwu limagwiritsa ntchito Clone kapena Copy.
//
//
// Zomangazi siziyenera kuwonetsedwa mu nambala yogwiritsa ntchito.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Kukhazikitsa kwa `Clone` yamitundu yakale.
///
/// Zotsatira zomwe sizingafotokozedwe mu Rust zimayendetsedwa mu `traits::SelectionContext::copy_clone_conditions()` mu `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Zolemba zogawana zitha kupangidwa, koma zosinthika zosinthika *sizingathe*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Zolemba zogawana zitha kupangidwa, koma zosinthika zosinthika *sizingathe*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}