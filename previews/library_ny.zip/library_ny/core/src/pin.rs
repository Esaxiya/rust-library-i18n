//! Mitundu yomwe imayika deta kumalo ake kukumbukira.
//!
//! Nthawi zina kumakhala kofunika kukhala ndi zinthu zomwe zimatsimikizika kuti sizingasunthe, mwakuti kusungidwa kwawo kukumbukira sikusintha, motero kungadaliridwe.
//! Chitsanzo chabwino cha zochitika ngati izi ndikumanga nyumba zodziyimira pawokha, popeza kusunthira chinthu cholozera chokha chitha kuzisokoneza, zomwe zimatha kuyambitsa machitidwe osadziwika.
//!
//! Pamwambamwamba, [`Pin<P>`] imatsimikizira kuti pointee yamtundu uliwonse wa pointer `P` ili ndi malo okhazikika okumbukira, kutanthauza kuti sitha kusunthidwa kwina ndipo kukumbukira kwake sikungasunthidwe mpaka kugwa.Tikuti pointee ndi "pinned".Zinthu zimakhala zobisika kwambiri mukamakambirana za mitundu yomwe imaphatikizana ndi zikhomo ndi zosalemba;[see below](#projections-and-structural-pinning) kuti mumve zambiri.
//!
//! Pokhapokha, mitundu yonse mu Rust imasunthika.
//! Rust imalola kupititsa mitundu yonse pamtengo, ndipo mitundu yodziwika bwino ya pointer monga [`Box<T>`] ndi `&mut T` imalola kusintha ndikusunthira zomwe zili nazo: mutha kutuluka mu [`Box<T>`], kapena mutha kugwiritsa ntchito [`mem::swap`].
//! [`Pin<P>`] kukulunga mtundu wa pointer `P`, chifukwa chake [`Pin`]`<<([`Box`]`<T>> `imagwira ntchito ngati wamba
//!
//! [`Box<T>`]: when a [`Pin`]`<<[`Bokosi`]`<T>> `imagwetsedwa, momwemonso zomwe zili mkati mwake, ndipo kukumbukira kumayamba
//!
//! anasamutsidwa.Momwemonso, [`Pin`]`<&mut T>`ili ngati `&mut T`.Komabe, [`Pin<P>`] salola kuti makasitomala azipeza [`Box<T>`] kapena `&mut T` kuti adziwe zambiri, zomwe zikutanthauza kuti simungagwiritse ntchito monga [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` amafunikira `&mut T`, koma sitingathe kuyipeza.
//!     // Takhazikika, sitingasinthanitse zomwe zanenedwa.
//!     // Titha kugwiritsa ntchito `Pin::get_unchecked_mut`, koma sizowopsa pazifukwa:
//!     // sitiloledwa kuigwiritsa ntchito posuntha zinthu mu `Pin`.
//! }
//! ```
//!
//! Ndikoyenera kubwereza kuti [`Pin<P>`]*siyisintha* kuti wopanga Rust amawona mitundu yonse yosunthika.[`mem::swap`] imakhala yotheka ku `T` iliyonse.M'malo mwake, [`Pin<P>`] imalepheretsa ma *mfundo* ena (otsogozedwa ndi ma pointer okutidwa mu [`Pin<P>`]) kuti asasunthike popanga njira zothetsera njira zomwe zimafunikira `&mut T` pa iwo (monga [`mem::swap`]).
//!
//! [`Pin<P>`] itha kugwiritsidwa ntchito kukulunga mtundu uliwonse wa pointer `P`, chifukwa chake imagwirizana ndi [`Deref`] ndi [`DerefMut`].[`Pin<P>`] pomwe `P: Deref` iyenera kuonedwa ngati "`P`-style pointer" mpaka `P::Target` yotsekedwa-kotero, [`Pin`]`<<[[Box`] ``<T>>`ndi cholozera chomwe chili ndi `T`, ndi [`Pin`] `<<[` Rc`]`<T>> `ndi cholozera chowerengera chomwe chimawerengedwa ku `T` yomata.
//! Kuti zikhale zolondola, [`Pin<P>`] imadalira kukhazikitsidwa kwa [`Deref`] ndi [`DerefMut`] kuti isatuluke mu gawo lawo la `self`, ndipo imangobwezera cholozera ku data yomwe yapinidwa akaitanidwa pa cholembera.
//!
//! # `Unpin`
//!
//! Mitundu yambiri nthawi zonse imasunthika momasuka, ngakhale itapinidwa, chifukwa sichidalira kukhala ndi adilesi yokhazikika.Izi zikuphatikiza mitundu yonse yayikulu (monga [`bool`], [`i32`], ndi maumboni) komanso mitundu yonse yamitundu iyi.Mitundu yosasamala zakusinkhasinkha imagwiritsa ntchito [`Unpin`] auto-trait, yomwe imafafaniza zotsatira za [`Pin<P>`].
//! Za `T: Unpin`, [`Pin`]`<<["Box`]`<T>> `ndi [`Box<T>`] zimagwira ntchito mofananamo, monganso [` Pin`]`<&mut T>` ndi `&mut T`.
//!
//! Dziwani kuti pinning ndi [`Unpin`] zimangokhudza mtundu wa `P::Target`, osati mtundu wa pointer `P` womwewo wokutidwa ndi [`Pin<P>`].Mwachitsanzo, kaya [`Box<T>`] ndi [`Unpin`] ilibe vuto lililonse pamachitidwe a [`Pin`]`<<([Box Box]]`<T>> `(apa, `T` ndiye mtundu wakalozera).
//!
//! # Chitsanzo: kudziyimira pawokha
//!
//! Tisanapange tsatanetsatane kuti tifotokozere zotsimikizira ndi zisankho zomwe zikugwirizana ndi `Pin<T>`, timakambirana zitsanzo za momwe zingagwiritsidwe ntchito.
//! Khalani omasuka ku [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Izi ndizodzisankhira nokha chifukwa gawo lomwe limadutsa limaloza gawo la deta.
//! // Sitingadziwitse wopangitsayo za izi ndi chizolowezi chabwinobwino, popeza kuti ndondomekoyi silingathe kufotokozedwa ndi malamulo abwerekedwe wamba.
//! //
//! // M'malo mwake timagwiritsa ntchito pointer yaiwisi, ngakhale imodzi yomwe imadziwika kuti siyabwino, monga tikudziwa ikuloza chingwe.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Kuonetsetsa kuti dongosololi silimasuntha ntchitoyo ikabwerera, timayiyika pamulu pomwe izikhala nthawi yonse ya chinthucho, ndipo njira yokhayo yomwe mungapezere izi ndi kudzera pacholozera.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // timangopanga cholozera pokhapokha deta ikadakhala kuti ikupezeka apo ayi ikadasunthira kale tisadayambe
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // tikudziwa kuti izi ndi zotetezeka chifukwa kusintha gawo sikusuntha dongosolo lonse
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Cholozera chikuyenera kuloza komwe kuli malo olondola, bola ngati struct isasunthe.
//! //
//! // Pakadali pano, tili ndi ufulu kusuntha pointer mozungulira.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Popeza mtundu wathu sukugwiritsa ntchito Unpin, izi zitha kulephera:
//! // lolani mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Chitsanzo: mndandanda wosakanikirana wambiri
//!
//! Mndandanda wosakanikirana wolumikizana kawiri, kusonkhanako sikungapereke kukumbukira kwa zinthu zomwe.
//! Kugawa kumayang'aniridwa ndi makasitomala, ndipo zinthu zimatha kukhala pamatumba omwe amakhala afupikitsa kuposa momwe amatolera.
//!
//! Kuti apange ntchitoyi, chinthu chilichonse chimakhala ndi zolozera kwa omwe adalowererapo komanso omwe adzalowa m'malo mwawo.Zinthu zimatha kungowonjezedwa zikapanikizidwa, chifukwa kusunthira zinthu mozungulira kumatha kuyimitsa zolozera.Kuphatikiza apo, kukhazikitsa kwa [`Drop`] kwa mndandanda wazinthu zolumikizidwa kudzalemba ziganizo za omwe adamutsatira ndi womulowa m'malo kuti adzichotse pandandanda.
//!
//! Crucially, tikuyenera kudalira [`drop`] kuyitanidwa.Ngati chinthu chikhoza kusamutsidwa kapena kusokonekera popanda kuyitanitsa [`drop`], zolembedwamo kuchokera kuzinthu zoyandikana nazo zitha kukhala zosavomerezeka, zomwe zitha kusokoneza kapangidwe kake.
//!
//! Chifukwa chake, kukanikiza kumabweranso ndi chitsimikizo chokhudzana ndi [`dontho"].
//!
//! # `Drop` guarantee
//!
//! Cholinga cha kupinikiza ndikuti muthe kudalira kuyika kwamtundu wina kukumbukira.
//! Kuti ntchitoyi isagwire ntchito, sikuti kungosuntha tsokalo kuli koletsedwa;kusunthira, kubwereza, kapena kusokoneza kukumbukira komwe kumagwiritsidwa ntchito kusungako ndizoletsedwanso.
//! Mwachidziwikire, pazosungidwa zomwe muyenera kuzisunga mosasunthika kuti *kukumbukira kwake sikudzasinthidwa kapena kuwomboledwa kuyambira pomwe imakankhidwa mpaka [`drop`] itadziwika*.Kamodzi kokha [`drop`] ikabwerera kapena panics, kukumbukira kumatha kugwiritsidwanso ntchito.
//!
//! Kukumbukira kumatha kukhala "invalidated" posinthana, komanso m'malo mwa [`Some(v)`] ndi [`None`], kapena kuyimbira [`Vec::set_len`] kupita ku "kill" zinthu zina kuchokera ku vector.Ikhoza kubwereranso pogwiritsira ntchito [`ptr::write`] kuti iilembere popanda kuyitanitsa wowonongayo poyamba.Palibe chilichonse chololedwa pazosindikiza popanda kuyimba [`drop`].
//!
//! Uwu ndiye mtundu wa chitsimikizo kuti mndandanda wolumikizana ndi zovuta kuchokera m'gawo lapitalo uyenera kugwira ntchito molondola.
//!
//! Tawonani kuti chitsimikizo ichi sichitanthauza kuti kukumbukira sikutuluka!Palibe vuto konse kuti muyimbire [`drop`] pachinthu chokhazikitsidwa (mwachitsanzo, mutha kuyimbirabe [`mem::forget`] pa [`Pin`]`<<([`Box`]` `<T>> ').Mu chitsanzo cha mndandanda wolumikizidwa kawiri, chinthucho chimangokhala pamndandanda.Komabe simungathe kumasula kapena kugwiritsanso ntchito yosungayi *osayimba [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Ngati mtundu wanu umagwiritsa ntchito pinning (monga zitsanzo ziwiri pamwambapa), muyenera kukhala osamala mukamayendetsa [`Drop`].Ntchito ya [`drop`] imatenga `&mut self`, koma izi zimatchedwa *ngakhale mtundu wanu kale unkakanikizidwa*!Zili ngati wopanga makinawo amatchedwa [`Pin::get_unchecked_mut`].
//!
//! Izi sizingayambitse vuto pachitetezo chifukwa kukhazikitsa mtundu womwe umadalira kukanikiza kumafunikira khodi yosatetezeka, koma dziwani kuti kusankha kugwiritsa ntchito pinning mumtundu wanu (mwachitsanzo pokhazikitsa ntchito pa [`Pin`]`<<&Self>`kapena [`Pin`] `&&Self Self` `) ili ndi zotsatirapo pakukhazikitsa kwanu kwa [`Drop`]: ngati chinthu chamtundu wanu chikadapachikidwa, muyenera kutenga [`Drop`] ngati mukungotenga [` Pin`]`<<&mut Kudzikonda> `.
//!
//!
//! Mwachitsanzo, mutha kugwiritsa ntchito `Drop` motere:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` zili bwino chifukwa tikudziwa kuti mtengowu sukugwiritsidwanso ntchito utagwetsedwa.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Makhodi enieni akupita apa.
//!         }
//!     }
//! }
//! ```
//!
//! Ntchito `inner_drop` ili ndi mtundu womwe [`drop`] * uyenera kukhala nawo, chifukwa chake izi zimatsimikizira kuti simugwiritsa ntchito `self`/`this` mwanjira yosemphana ndi pinning.
//!
//! Kuphatikiza apo, ngati mtundu wanu ndi `#[repr(packed)]`, wopanga makinawo amangoyendetsa magawo kuti athe kuwagwetsa.Itha ngakhale kuchita izi m'minda yomwe ikulumikizana mokwanira.Zotsatira zake, simungagwiritse ntchito pinning ndi mtundu wa `#[repr(packed)]`.
//!
//! # Kulingalira ndi Kupanga Kapangidwe
//!
//! Mukamagwira ntchito yolumikizidwa, funso limakhala kuti munthu angapeze bwanji magawo a struct m'njira yomwe ingotenga [`Pin`]`<&mut Struct>`.
//! Njira yozolowereka ndiyo kulemba njira zothandizira (zotchedwa *ziyerekezo*) zomwe zimasinthira [`Pin`]`<&mut Struct>`kutanthauzira kumunda, koma kodi bukulo liyenera kukhala lotani?Kodi ndi [`Pin`]`<&mut Field>`kapena `&mut Field`?
//! Funso lomwelo limabuka ndi magawo a `enum`, komanso mukaganizira mitundu ya container/wrapper monga [`Vec<T>`], [`Box<T>`], kapena [`RefCell<T>`].
//! (Funsoli limagwira pamafotokozedwe osinthika komanso ogawana, timangogwiritsa ntchito mafotokozedwe osinthika pano monga fanizo.)
//!
//! Zikukhala kuti ndi kwa wolemba madongosolowo kuti asankhe ngati ziwonetsero zomwe zapinidwa za gawo linalake zisintha [`Pin`]`<&mut Struct>`into [[Pin`]" <&mut Field> `` or `&mut Field`.Pali zovuta zina komabe, choletsa chofunikira kwambiri ndi kusasinthasintha *:
//! Munda uliwonse ukhoza kufotokozedweratu,*kapena* kuchotsedwa pini ngati gawo la chiyerekezo.
//! Ngati zonsezi zichitidwira gawo limodzi, ndiye kuti sizingakhale zomveka!
//!
//! Monga wolemba zadongosolo muyenera kusankha pamunda uliwonse kaya kupinikiza "propagates" pamunda uno kapena ayi.
//! Kupaka zomwe zimafalitsa kumatchedwanso "structural", chifukwa zimatsata kapangidwe kake.
//! M'magawo otsatirawa, tikufotokozera zomwe ziyenera kupangidwa posankha chilichonse.
//!
//! ## Kutsina * sikumangidwe kwa `field`
//!
//! Zitha kuwoneka ngati zotsutsana kuti gawo lamapangidwe osakhomedwa, koma ndiye chisankho chosavuta kwambiri: ngati [`Pin`]`&<&mut Field>`sapangidwa konse, palibe chomwe chingalakwika!Chifukwa chake, ngati mungaganize kuti gawo linalake silikhala ndi zolembera, zonse zomwe mukuyenera kuwonetsetsa ndikuti simunapanganso dzina lomwelo.
//!
//! Minda yopanda zikwangwani zapangidwe imatha kukhala ndi njira yoyerekeza yomwe ingasinthe [`Pin`]`<&mut Struct>`kukhala `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Izi zili bwino chifukwa `field` silingaganiziridwe konse kuti yakanidwa.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Muthanso `impl Unpin for Struct`*ngakhale* mtundu wa `field` si [`Unpin`].Zomwe mtundu uwu umaganizira pakupina sizofunikira ngati palibe [`Pin`]`<&mut Field>`` idapangidwapo.
//!
//! ## Kupinikiza * ndipangidwe kwa `field`
//!
//! Njira ina ndikusankha kuti pinning ndi "structural" ya `field`, kutanthauza kuti ngati struct ikakanikizidwa ndiye momwemonso mundawo.
//!
//! Izi zimalola kulemba chiyerekezo chomwe chimapanga [`Pin`]`<&mut Field>``, kuchitira umboni kuti mundawo wakanidwa:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Izi zili bwino chifukwa `field` imapanikizidwa pomwe `self` ili.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Komabe, kupanga pinning kumabwera ndi zofunikira zochepa:
//!
//! 1. Dongosolo liyenera kukhala [`Unpin`] pokhapokha magawo onse ali [`Unpin`].Izi ndizosasintha, koma [`Unpin`] ndi trait yotetezeka, kuti wolemba wa struct ndiudindo wanu *osati* kuwonjezera china chonga `impl<T> Unpin for Struct<T>`.
//! (Zindikirani kuti kuwonjezera ntchito yoyerekeza kumafunikira nambala yosatetezeka, chifukwa chakuti [`Unpin`] ndi trait yotetezeka sikuphwanya mfundo yoti muyenera kuda nkhawa ndi izi ngati mutagwiritsa ntchito `zosatetezeka`.)
//! 2. Wowononga nyumbayo sayenera kusuntha magawo azinthu pamkangano wake.Iyi ndiye mfundo yomwe idakwezedwa mu [previous section][drop-impl]: `drop` imatenga `&mut self`, koma struct (ndi chifukwa chake minda yake) mwina idakanikizidwapo kale.
//!     Muyenera kutsimikizira kuti simusuntha gawo mkati mwanu kukhazikitsa [`Drop`].
//!     Makamaka, monga tafotokozera kale, izi zikutanthauza kuti anu struct sayenera *osati* kukhala `#[repr(packed)]`.
//!     Onani gawolo momwe mungalembe [`drop`] m'njira yomwe wopangirayo angakuthandizireni kuti musaphonye pinning mwangozi.
//! 3. Muyenera kuwonetsetsa kuti mukutsatira [`Drop` guarantee][drop-guarantee]:
//!     Mukangomanga zolemba zanu, zokumbukira zomwe zili ndizomwe sizilembedwe kapena kutumizidwa popanda kuyitanitsa owononga.
//!     Izi zitha kukhala zovuta, monga [`VecDeque<T>`] idawonetsera: wowononga [`VecDeque<T>`] atha kulephera kuyimbira [`drop`] pazinthu zonse ngati m'modzi wowononga panics.Izi zikuphwanya chitsimikizo cha [`Drop`], chifukwa zitha kupangitsa kuti zinthu zizichotsedwa popanda kuwononga wowononga.([`VecDeque<T>`] ilibe ziyerekezo, kotero izi sizimayambitsa kupanda nzeru.)
//! 4. Simuyenera kupereka ntchito zina zilizonse zomwe zingapangitse kuti deta isunthidwe kunja kwa mtundu wanu mukapanikizidwa.Mwachitsanzo, ngati struct ili ndi [`Option<T>`] ndipo pali `` kutenga '' ngati mtundu wa `fn(Pin<&mut Struct<T>>) -> Option<T>`, opaleshoniyi itha kugwiritsidwa ntchito kutulutsa `T` kuchoka pa `Struct<T>` yomata-zomwe zikutanthauza kuti kupinikiza sikungakhale koyenera pamunda womwe ukugwira izi deta.
//!
//!     Kuti mupeze chitsanzo chovuta kwambiri chosunthira deta kuchokera mu mtundu wopinidwa, taganizirani ngati [`RefCell<T>`] ili ndi njira `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Kenako titha kuchita izi:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Izi ndizowopsa, zikutanthauza kuti titha kupinikiza zomwe zili mu [`RefCell<T>`] (pogwiritsa ntchito `RefCell::get_pin_mut`) ndikusunthanso zomwezo pogwiritsa ntchito zomwe tingasinthe pambuyo pake.
//!
//! ## Examples
//!
//! Kwa mtundu ngati [`Vec<T>`], kuthekera konse (kapangidwe kake kapena ayi) ndizomveka.
//! [`Vec<T>`] yokhala ndi zikwangwani zomangamanga imatha kukhala ndi njira za `get_pin`/`get_pin_mut` zolozera zolemba pazinthu.Komabe, sakanalola * kuyitanitsa [`pop`][Vec::pop] pa [`Vec<T>`] yolumikizidwa chifukwa izi zitha kusunthira zomwe zili (zomata)!Komanso sichingalole [`push`][Vec::push], yomwe itha kusamutsidwa ndikupangitsanso zomwe zili mkatimo.
//!
//! [`Vec<T>`] yopanda mapinidwe omanga imatha kukhala `impl<T> Unpin for Vec<T>`, chifukwa zomwe zidalembedwapo sizinapikidwe ndipo [`Vec<T>`] yomwe ili bwino ndiyosunthidwanso.
//! Pakadali pano kukanikiza sikungakhudze vector konse.
//!
//! Mu laibulale yanthawi zonse, mitundu ya pointer nthawi zambiri imakhala yopanda mapangidwe, motero samapereka ziwonetsero.Ichi ndichifukwa chake `Box<T>: Unpin` imagwirizira `T` yonse.
//! Ndizomveka kuchita izi pamitundu yama pointer, chifukwa kusuntha `Box<T>` sikungasunthi `T`: [`Box<T>`] imatha kusunthidwa mwaulere (aka `Unpin`) ngakhale `T` siyili.M'malo mwake, ngakhale [`Pin`]`<<[[Box]]`<T>> `ndi [` Pin`]`<&mut T>` nthawi zonse amakhala [`Unpin`] iwowo, pachifukwa chomwecho: zomwe zili (`T`) zimapachikidwa, koma zolozera zomwezo zitha kusunthidwa popanda kusuntha zomwe zaposedwa.
//! Kwa onse [`Box<T>`] ndi [`Pin`]`<<["Box`]`<T>> `, ngakhale zolembedwazo sizikudziwika ngati cholozera chalembedwacho, kutanthauza kuti kupinikiza * sikumangidwe.
//!
//! Mukamapanga chophatikiza cha [`Future`], nthawi zambiri mudzafunika kupinimbira kwam'malo mwa futures, popeza muyenera kutchulidwapo komwe angatchule [`poll`].
//! Koma ngati chophatikizira chanu chili ndi zina zilizonse zomwe siziyenera kupinidwa, mutha kupangitsa kuti malowa asakhale omanga ndipo chifukwa chake mungawafikire mosazungulika ngakhale mutakhala ndi [`Pin`]`<&mut Self>`` (such monga momwe mukugwiritsira ntchito [`poll`]).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Cholozera chomata.
///
/// Ichi ndi cholumikizira mozungulira mtundu wa cholozera chomwe chimapangitsa cholozera "pin" kukhala mtengo wake m'malo mwake, kuletsa mtengo womwe pointeryo isasunthidwe pokhapokha itagwiritsa ntchito [`Unpin`].
///
///
/// *Onani zolemba za [`pin` module] kuti mumve zambiri za pinning.*
///
/// [`pin` module]: self
///
// Note: `Clone` yomwe ili pansipa imayambitsa kusamvana monga momwe zingathere kukhazikitsa
// `Clone` kwa mafotokozedwe osinthika.
// Onani <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> kuti mumve zambiri.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Njira zotsatirazi sizinachitike pofuna kupewa zovuta.
// `&self.pointer` sayenera kupezeka kuzinthu zosadalirika za trait.
//
// Onani <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> kuti mumve zambiri.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Pangani `Pin<P>` yatsopano mozungulira cholozera ku deta yamtundu wina yomwe imagwiritsa ntchito [`Unpin`].
    ///
    /// Mosiyana ndi `Pin::new_unchecked`, njirayi ndi yotetezeka chifukwa cholozera `P` chimafotokoza mtundu wa [`Unpin`], womwe umafafaniza kutsimikizira kwa pinning.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // CHITETEZO: mtengo womwe watchulidwa ndi `Unpin`, motero ulibe zofunikira
        // kuzungulira pinning.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Chotsegula `Pin<P>` iyi ndikubwezera cholembapo.
    ///
    /// Izi zimafunikira kuti zomwe zili mkati mwa `Pin` ndi [`Unpin`] kuti titha kunyalanyaza zolembera zomwe tikupukutira tikamatsegula.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Pangani `Pin<P>` yatsopano potengera zidziwitso zamtundu wina zomwe zingathe kapena sizigwiritsa ntchito `Unpin`.
    ///
    /// Ngati kutulutsa kwa `pointer` pamtundu wa `Unpin`, `Pin::new` iyenera kugwiritsidwa ntchito m'malo mwake.
    ///
    /// # Safety
    ///
    /// Womanga uyu ndiwosatetezeka chifukwa sitingatsimikizire kuti zomwe adalongosola `pointer` zidayikidwa, kutanthauza kuti zomwezo sizisunthidwa kapena kusungidwa kwake kudzawonongeka mpaka kugwera.
    /// Ngati zomangidwazo `Pin<P>` sizikutsimikizira kuti zomwe `P` imaloza zikanikizidwa, kumeneko ndikuphwanya mgwirizano wa API ndipo kumatha kubweretsa machitidwe osadziwika m'machitidwe ena a (safe).
    ///
    /// Pogwiritsa ntchito njirayi, mukupanga promise pazokambirana za `P::Deref` ndi `P::DerefMut`, ngati zilipo.
    /// Chofunika kwambiri, sayenera kuchoka pazokambirana zawo za `self`: `Pin::as_mut` ndi `Pin::as_ref` ayimbira `DerefMut::deref_mut` ndi `Deref::deref`*pa cholembera cholozera* ndipo akuyembekeza kuti njirazi zithandizira otsogola.
    /// Kuphatikiza apo, poyitanitsa njirayi inu promise kuti ma `P` omwe sanatchulidwewo sadzachokeranso;makamaka, siziyenera kukhala zotheka kupeza `&mut P::Target` ndikusunthira kwina (pogwiritsa ntchito, mwachitsanzo [`mem::swap`]).
    ///
    ///
    /// Mwachitsanzo, kuyimbira `Pin::new_unchecked` pa `&'a mut T` sikutetezeka chifukwa ngakhale mutha kuyiyika pa nthawi ya moyo `'a`, mulibe mphamvu yoti isungidwe ikangoyikidwa kamodzi `'a` itatha:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Izi zikutanthauza kuti pointee `a` singasunthenso.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Adilesi ya `a` idasinthidwa kukhala `b`'s stack slot, kotero `a` idasunthidwa ngakhale tidalemba kale!Taphwanya pangano la pinning API.
    /////
    /// }
    /// ```
    ///
    /// Mtengo, ukapanikizidwa, uyenera kukhala wopinidwa kosatha (pokhapokha mtundu wake utagwiritsa ntchito `Unpin`).
    ///
    /// Mofananamo, kuyimbira `Pin::new_unchecked` pa `Rc<T>` sikungatetezedwe chifukwa pakhoza kukhala zotsutsana ndi zomwezo zomwe sizikutsutsana ndi zoletsa izi:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Izi zikutanthauza kuti pointee sangasunthenso.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Tsopano, ngati `x` inali yokhayo yomwe ikunena, tili ndi tanthauzo losinthika ku data yomwe tidalemba pamwambapa, yomwe titha kugwiritsa ntchito kuyisuntha monga tidawonera m'mbuyomu.
    ///     // Taphwanya pangano la pinning API.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Ikupeza zolemba zomwe zagawidwa kuchokera pacholozera ichi.
    ///
    /// Iyi ndi njira yodziwika bwino yochokera ku `&Pin<Pointer<T>>` mpaka `Pin<&T>`.
    /// Ndizotetezeka chifukwa, monga gawo la mgwirizano wa `Pin::new_unchecked`, pointee sangasunthe `Pin<Pointer<T>>` itapangidwa.
    ///
    /// "Malicious" Kukhazikitsa `Pointer::Deref` kumatsutsidwanso ndi mgwirizano wa `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // CHITETEZO: onani zolemba pantchitoyi
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Chotsegula `Pin<P>` iyi ndikubwezera cholembapo.
    ///
    /// # Safety
    ///
    /// Ntchitoyi ndi yosatetezeka.Muyenera kutsimikizira kuti mupitiliza kugwiritsa ntchito pointer `P` monga momwe adapangira mutayitanitsa ntchitoyi, kuti olowa pamtundu wa `Pin` athe kuthandizidwa.
    /// Ngati nambala yogwiritsa ntchito `P` siyikupitilizabe kusungabe zolembera zomwe zikuphwanya pangano la API ndipo zitha kubweretsanso zosadziwika muntchito za (safe).
    ///
    ///
    /// Ngati zoyikirazo ndi [`Unpin`], [`Pin::into_inner`] iyenera kugwiritsidwa ntchito m'malo mwake.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Ikupeza zolemba zomwe zingasinthidwe kuchokera pachotsegula ichi.
    ///
    /// Iyi ndi njira yodziwika bwino yochokera ku `&mut Pin<Pointer<T>>` mpaka `Pin<&mut T>`.
    /// Ndizotetezeka chifukwa, monga gawo la mgwirizano wa `Pin::new_unchecked`, pointee sangasunthe `Pin<Pointer<T>>` itapangidwa.
    ///
    /// "Malicious" Kukhazikitsa `Pointer::DerefMut` kumatsutsidwanso ndi mgwirizano wa `Pin::new_unchecked`.
    ///
    /// Njirayi ndiyothandiza pakuyimba kangapo kuntchito zomwe zimawononga mtundu wopinidwa.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // chitani kena kake
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` imagwiritsa ntchito `self`, ndiye pangani `Pin<&mut Self>` kudzera pa `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // CHITETEZO: onani zolemba pantchitoyi
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Kugawa mtengo watsopano pamtima kumbuyo kwa zomwe zidatchulidwazo.
    ///
    /// Izi zimasindikiza zomwe zidatchulidwazo, koma sizabwino: owononga ake amayamba kuthamanga asanalembedwe, chifukwa chake kutsimikizika kwa pinning sikuphwanyidwa.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Amapanga pini yatsopano polemba mtengo wamkati.
    ///
    /// Mwachitsanzo, ngati mukufuna kupeza `Pin` ya gawo la china chake, mutha kugwiritsa ntchito izi kuti mupeze gawo limenelo pamzere umodzi.
    /// Komabe, pali ma Getchas angapo omwe ali ndi "pinning projections";
    /// onani zolemba za [`pin` module] kuti mumve zambiri pamutuwu.
    ///
    /// # Safety
    ///
    /// Ntchitoyi ndi yosatetezeka.
    /// Muyenera kutsimikizira kuti zomwe mumabwezera sizingasunthe bola ngati mfundo zotsutsana sizikusuntha (mwachitsanzo, chifukwa ndi imodzi mwazinthu zamtengo wapatali), komanso kuti simukuchoka pazokangana zomwe mumalandira ntchito zamkati.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // CHITETEZO: mgwirizano wachitetezo wa `new_unchecked` uyenera kukhala
        // zothandizidwa ndi woyimbirayo.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Amapeza zomwe amagawana nawo pini.
    ///
    /// Izi ndizotetezeka chifukwa sikutheka kuti musachokere mu zomwe mudagawana nawo.
    /// Zitha kuwoneka kuti pali vuto pano ndi kusintha kwamkati: M'malo mwake, ndi * zotheka kusamutsa `T` kuchoka ku `&RefCell<T>`.
    /// Komabe, ili si vuto bola sipangakhalenso `Pin<&T>` yomwe ikuloza ku zomwezo, ndipo `RefCell<T>` sikukulolani kuti mupange zolemba zomwe zikuphatikizidwa.
    ///
    /// Onani zokambirana pa ["pinning projections"] kuti mumve zambiri.
    ///
    /// Note: `Pin` imagwiritsanso ntchito `Deref` pa chandamale, chomwe chitha kugwiritsidwa ntchito kupeza phindu lamkati.
    /// Komabe, `Deref` imangopereka chisonyezo chomwe chimangokhala kwa nthawi yayitali ngati kubwereketsa kwa `Pin`, osati nthawi ya `Pin` yokha.
    /// Njira iyi imalola kutembenuza `Pin` kukhala yofanana ndi nthawi yofanana ndi `Pin` yapachiyambi.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Imatembenuza `Pin<&mut T>` iyi kukhala `Pin<&T>` ndi moyo womwewo.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Amapeza zosinthika zosunthika zamkati mwa `Pin` iyi.
    ///
    /// Izi zimafuna kuti zomwe zili mkati mwa `Pin` ndi `Unpin`.
    ///
    /// Note: `Pin` imagwiritsanso ntchito `DerefMut` pamasamba, omwe atha kugwiritsidwa ntchito kupeza phindu lamkati.
    /// Komabe, `DerefMut` imangopereka chisonyezo chomwe chimangokhala kwa nthawi yayitali ngati kubwereketsa kwa `Pin`, osati nthawi ya `Pin` yokha.
    ///
    /// Njira iyi imalola kutembenuza `Pin` kukhala yofanana ndi nthawi yofanana ndi `Pin` yapachiyambi.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Amapeza zosinthika zosunthika zamkati mwa `Pin` iyi.
    ///
    /// # Safety
    ///
    /// Ntchitoyi ndi yosatetezeka.
    /// Muyenera kutsimikizira kuti simudzasunthira deta yonse kuchokera pazomwe mungasinthe mukamayitanitsa ntchitoyi, kuti olowa pamtundu wa `Pin` athe kuthandizidwa.
    ///
    ///
    /// Ngati zoyikirazo ndi `Unpin`, `Pin::get_mut` iyenera kugwiritsidwa ntchito m'malo mwake.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Pangani pini yatsopano pojambula mapangidwe amkati.
    ///
    /// Mwachitsanzo, ngati mukufuna kupeza `Pin` ya gawo la china chake, mutha kugwiritsa ntchito izi kuti mupeze gawo limenelo pamzere umodzi.
    /// Komabe, pali ma Getchas angapo omwe ali ndi "pinning projections";
    /// onani zolemba za [`pin` module] kuti mumve zambiri pamutuwu.
    ///
    /// # Safety
    ///
    /// Ntchitoyi ndi yosatetezeka.
    /// Muyenera kutsimikizira kuti zomwe mumabwezera sizingasunthe bola ngati mfundo zotsutsana sizikusuntha (mwachitsanzo, chifukwa ndi imodzi mwazinthu zamtengo wapatali), komanso kuti simukuchoka pazokangana zomwe mumalandira ntchito zamkati.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // CHITETEZO: woyimbirayo ali ndi udindo wosasuntha
        // phindu kuchokera patsamba lino.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // CHITETEZO: monga mtengo wa `this` umatsimikiziridwa kuti mulibe
        // Kutulutsidwa kunja, kuyitanidwa ku `new_unchecked` ndikotetezeka.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Pezani zolembedwera kuchokera ku malo osasunthika.
    ///
    /// Izi ndizotetezeka, chifukwa `T` imabwerekedwa nthawi yonse ya `'static`, yomwe simatha.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // CHITETEZO: Kubwereketsa kwa 'static kumatsimikizira kuti sipadzakhalanso
        // moved/invalidated mpaka igwetsedwe (zomwe sizinachitikepo).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Pezani zolemba zomwe zingasinthidwe kuchokera ku malo osinthika osasinthika.
    ///
    /// Izi ndizotetezeka, chifukwa `T` imabwerekedwa nthawi yonse ya `'static`, yomwe simatha.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // CHITETEZO: Kubwereketsa kwa 'static kumatsimikizira kuti sipadzakhalanso
        // moved/invalidated mpaka igwetsedwe (zomwe sizinachitikepo).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: izi zikutanthauza kuti kuyika kulikonse kwa `CoerceUnsized` komwe kumalola kukakamiza kuchokera
// Mtundu womwe umakhazikitsa `Deref<Target=impl !Unpin>` ku mtundu womwe umayambitsa `Deref<Target=Unpin>` ndiwosazindikira.
// Zoyeserera zilizonsezi mwina sizingakhale zomveka pazifukwa zina, komabe, tikungoyenera kusamala kuti tisalole kuti ma implamuwo atere ku std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}