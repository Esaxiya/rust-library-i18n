//! Makina amtundu wa pointer saizi yayikulu osalemba.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! Khodi yatsopano iyenera kugwiritsa ntchito zovuta zomwe zimagwirizanitsidwa mwachindunji pa mtundu wakale.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }