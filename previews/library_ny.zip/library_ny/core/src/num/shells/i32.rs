//! Zoyikika zamtundu wa 32-bit zosayina zonse.
//!
//! *[See also the `i32` primitive type][i32].*
//!
//! Khodi yatsopano iyenera kugwiritsa ntchito zovuta zomwe zimagwirizanitsidwa mwachindunji pa mtundu wakale.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i32`"
)]

int_module! { i32 }