//! Makina osanjikiza amtundu wa pointer osainidwa.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! Khodi yatsopano iyenera kugwiritsa ntchito zovuta zomwe zimagwirizanitsidwa mwachindunji pa mtundu wakale.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }