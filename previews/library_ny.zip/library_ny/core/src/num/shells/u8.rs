//! Zoyikika zamtundu wa 8-bit zosalemba zomwe sizinalembedwe.
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! Khodi yatsopano iyenera kugwiritsa ntchito zovuta zomwe zimagwirizanitsidwa mwachindunji pa mtundu wakale.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }