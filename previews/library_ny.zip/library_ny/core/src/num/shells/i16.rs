//! Zoyikika zamtundu wa 16-bit zosayina zonse.
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! Khodi yatsopano iyenera kugwiritsa ntchito zovuta zomwe zimagwirizanitsidwa mwachindunji pa mtundu wakale.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }