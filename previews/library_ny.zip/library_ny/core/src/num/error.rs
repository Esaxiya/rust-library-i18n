//! Mitundu yolakwika pakusintha kukhala mitundu yofunikira.

use crate::convert::Infallible;
use crate::fmt;

/// Mtundu wolakwika udabwereranso pomwe kutembenuka kwamtundu woyang'aniridwa sikulephera.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Fananizani m'malo mokakamiza kuti muwonetsetse kuti nambala ngati `From<Infallible> for TryFromIntError` pamwambapa ikugwirabe ntchito `Infallible` ikadzakhala dzina la `!`.
        //
        //
        match never {}
    }
}

/// Cholakwika chomwe chitha kubwezeredwa posanthula nambala.
///
/// Vutoli limagwiritsidwa ntchito ngati mtundu wolakwika wa ntchito za `from_str_radix()` pamitundu yoyambira, monga [`i8::from_str_radix`].
///
/// # Zomwe zingayambitse
///
/// Mwa zina zoyambitsa, `ParseIntError` ikhoza kuponyedwa chifukwa chotsogolera kapena kutsata whitespace mu chingwe mwachitsanzo, ikapezeka pazowonjezera zonse.
///
/// Kugwiritsa ntchito njira ya [`str::trim()`] kumatsimikizira kuti palibe bwalo loyera lomwe latsala lisanachitike.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum kuti musunge zolakwika zosiyanasiyana zomwe zingayambitse kuchuluka kwa manambala kulephera.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Mtengo wofufuzidwa ulibe kanthu.
    ///
    /// Mwa zina, zosinthazi zimamangidwa polemba chingwe chopanda kanthu.
    Empty,
    /// Ili ndi manambala osavomerezeka pamalingaliro ake.
    ///
    /// Zina mwazifukwa zina, kusiyanaku kumapangidwa polemba chingwe chomwe chili ndi non-ASCII char.
    ///
    /// Zosinthazi zimapangidwanso `+` kapena `-` ikasungidwa mu chingwe mwina payokha kapena pakati pa nambala.
    ///
    ///
    InvalidDigit,
    /// Nambala yayikulu kwambiri kuti isasungidwe pamtundu wazambiri.
    PosOverflow,
    /// Integer ndi yaying'ono kwambiri kuti isungidwe mumtundu wamitundu yonse.
    NegOverflow,
    /// Mtengo unali Zero
    ///
    /// Zosiyanazi zidzatulutsidwa pamene chingwe chowerengera chili ndi phindu la zero, zomwe zingakhale zosaloledwa kwa mitundu yopanda zero.
    ///
    Zero,
}

impl ParseIntError {
    /// Kutulutsa komwe kumafotokoza mwatsatanetsatane kulephera kwa nambala yonse kulephera.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}