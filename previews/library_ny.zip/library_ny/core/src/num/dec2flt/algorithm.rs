//! Ma algorithms osiyanasiyana ochokera papepala.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Chiwerengero cha ma bits ofunikira mu Fp
const P: u32 = 64;

// Timangosunga kuyerekezera koyenera kwa zotulutsa zonse *, kotero "h" yosinthika ndi zomwe zikugwirizana zimatha kusiidwa.
// Izi zimagulitsa magwiridwe antchito a ma kilobyte angapo.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// M'makonzedwe ambiri, malo oyandama amakhala ndi kukula kocheperako, chifukwa chake kulondola kwa kuwerengera kumatsimikizika mogwirizana ndi ntchito iliyonse.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Pa x86, x87 FPU imagwiritsidwa ntchito poyandama ngati zowonjezera za SSE/SSE2 sizipezeka.
// x87 FPU imagwira ntchito ndi ma bits 80 molondola mwachisawawa, zomwe zikutanthauza kuti magwiridwe antchito azungulira mpaka mabatani 80 kuchititsa kuzungulira kawiri kuchitika pomwe mfundo zimayimiriridwa
//
// 32/64 mfundo zoyandama pang'ono.Pofuna kuthana ndi izi, mawu olamulira a FPU amatha kukhazikitsidwa kotero kuti kuwerengera kumachitika molondola.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Kapangidwe kosungira mtengo woyambirira wa mawu olamulira a FPU, kuti athe kubwezeretsanso dongosolo likaponyedwa.
    ///
    ///
    /// x87 FPU ndi kaundula wa ma bits 16 omwe minda yake ili motere:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Zolemba za madera onse zikupezeka mu IA-32 Architecture Software Developer's Manual (Volume 1).
    ///
    /// Munda wokhawo womwe ungagwirizane ndi nambala iyi ndi PC, Precision Control.
    /// Dera ili limatsimikizira kulondola kwa ntchito zomwe FPU imagwira.
    /// Ikhoza kukhazikitsidwa ku:
    ///  - 0b00, kulondola kumodzi, 32-bits
    ///  - 0b10, kulunjika kawiri, 64-bits
    ///  - 0b11, kuwonjezeredwa kwachindunji, 80-bits (boma losasintha) Mtengo wa 0b01 umasungidwa ndipo sukuyenera kugwiritsidwa ntchito.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // CHITETEZO: malangizo a `fldcw` awunikidwa kuti athe kugwira bwino ntchito ndi
        // `u16` iliyonse
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Tikugwiritsa ntchito syntax ya ATT kuthandiza LLVM 8 ndi LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Ikani gawo lolondola la FPU ku `T` ndikubwezera `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Fananizani mtengo wa gawo la Precision Control lomwe ndi loyenera `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // Mabedi 32
            8 => 0x0200, // 64 ma bits
            _ => 0x0300, // chosasintha, ma bits 80
        };

        // Pezani phindu lenileni la mawu olamulira kuti mulibwezeretse pambuyo pake, pomwe mawonekedwe a `FPUControlWord` agwetsedwa KUTETEZA: malangizo a `fnstcw` awunikidwa kuti athe kugwira bwino ntchito ndi `u16` iliyonse
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Tikugwiritsa ntchito syntax ya ATT kuthandiza LLVM 8 ndi LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Ikani mawu olamulira molondola.
        // Izi zimatheka potseka zolondola zakale (bits 8 ndi 9, 0x300) ndikuzisintha ndi mbendera yolondola yomwe yalembedwa pamwambapa.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Njira yachangu ya Bellerophon yogwiritsa ntchito masanjidwe oyika makina ndikuyandama.
///
/// Izi zimachotsedwa mu ntchito yapadera kuti ziyesedwe musanapange bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Timayerekezera phindu lenileni ndi MAX_SIG pafupi ndi kutha, uku ndikungokana mwachangu, zotsika mtengo (komanso kumasula nambala yonseyo kuti isadandaule za kusefukira).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Njira yachangu imadalira masamu omwe azunguliridwa mpaka kuchuluka koyenera popanda kuzungulira kwapakati.
    // Pa x86 (yopanda SSE kapena SSE2) izi zimafunikira kuti kusungika kwa x87 FPU kusinthidwe kuti kuzungulire mpaka 64/32 pang'ono.
    // Ntchito ya `set_precision` imasamalira kuyika molondola pazomangamanga zomwe zimafunikira kuti zisinthe posintha dziko lonse lapansi (monga mawu olamulira a x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Mlanduwu e <0 sungapangidwe kulowa mu branch ina.
    // Mphamvu zoyipa zimabweretsa magawo obwereza pamabinawo, omwe amakhala ozungulira, omwe amachititsa zolakwika zenizeni (ndipo nthawi zina zimakhala zofunikira kwambiri) pamapeto pake.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algorithm Bellerophon ndi nambala yaing'ono yolungamitsidwa ndikuwunika kosafunikira.
///
/// Imazungulira `` f '' kuyandama yokhala ndi tanthauzo pang'ono la 64 ndikuichulukitsa ndi kuyerekezera kwabwino kwa `10^e` (munjira yomweyo yoyandama).Izi nthawi zambiri zimakhala zokwanira kuti mupeze zotsatira zolondola.
/// Komabe, zotsatira zake zikakhala pafupi pakati pa zoyandama ziwiri zoyandikira za (ordinary), cholakwika chomwe chimakhalapo pakuchulukitsa kuyerekezera kumatanthauza kuti zotsatira zake zitha kuzimiririka pang'ono.
/// Izi zikachitika, kusintha kwa Algorithm R kumakonza zinthu.
///
/// Hand-wavy "close to halfway" imapangidwa molondola ndi kusanthula kwa manambala papepala.
/// M'mawu a Clinger:
///
/// > Kutsetsereka, komwe kumafotokozedwa mgawo zazing'ono kwambiri, ndikumaphatikizira zolakwikazo
/// > anasonkhanitsa panthawi yoyandikira powerengera moyerekeza ndi f * 10 ^ e.(Kutsetsereka ndi
/// > osamangirira cholakwika chenicheni, koma malire malire pakati pa kuyerekezera z ndi
/// > kuyerekezera kwabwino kwambiri komwe kumagwiritsa ntchito ma pents ofunikira.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Milandu abs(e) <log5(2^N) ili mu fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Kodi malo otsetserekawo ndi okwanira kubweretsa kusiyana pakamazungulira ma bits?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Algorithm yotsogola yomwe imathandizira kuyerekezera kwa poyandikira kwa `f * 10^e`.
///
/// Iteration iliyonse imapeza gawo limodzi lomaliza pafupi, lomwe limatenga nthawi yayitali kuti lisinthe ngati `z0` ili pang'ono pang'ono.
/// Mwamwayi, ikagwiritsidwa ntchito ngati kubwerera kwa Bellerophon, kuyerekezera koyambira kumachotsedwa ndi ULP imodzi.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Pezani manambala abwino `x`, `y` kotero kuti `x / y` ndi `(f *10^e) / (m* 2^k)` ndendende.
        // Izi sizimangopewa kuthana ndi zizindikilo za `e` ndi `k`, timathenso kuthana ndi mphamvu ziwiri zofanana ku `10^e` ndi `2^k` kuti manambalawo akhale ochepa.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Izi zalembedwa mochititsa manyazi chifukwa ma bignums athu samathandizira manambala olakwika, chifukwa chake timagwiritsa ntchito chidziwitso chazizindikiro +.
        // Kuchulukitsa ndi m_digits sikungasefuke.
        // Ngati `x` kapena `y` ndi zazikulu mokwanira kotero kuti tifunika kuda nkhawa za kusefukira, ndiye kuti ndizokwanira mokwanira kuti `make_ratio` yachepetsa kachigawo ka 2 ^ 64 kapena kupitilira apo.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Simufunanso x, koma sungani clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Tikufunikirabe y, pangani kope.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Popeza `x = f` ndi `y = m` pomwe `f` imayimira manambala ophatikizira monga mwachizolowezi ndipo `m` ndikutanthauzira kwa kuyerekezera kwa malo oyandama, zimapangitsa kuti chiŵerengero cha `x / y` chikhale chofanana ndi `(f *10^e) / (m* 2^k)`, mwina chochepetsedwa ndi mphamvu ziwiri zonse zimagwirizana.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, kupatula kuti timachepetsa kagawidweko ndi mphamvu ziwiri.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Izi sizingasefukire chifukwa zimafunikira `e` ndi `k` yoyipa, zomwe zimangochitika pazikhalidwe zoyandikira kwambiri 1, zomwe zikutanthauza kuti `e` ndi `k` zidzakhala zochepa kwambiri.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Izi sizingasefukire mwina, onani pamwambapa.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), ndikuchepetsanso ndi mphamvu yofanana ya awiri.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Mwachidziwitso, Algorithm M ndiyo njira yosavuta yosinthira decimal kukhala choyandama.
///
/// Timapanga chiŵerengero chofanana ndi `f * 10^e`, kenako ndikuponya mphamvu ziwiri mpaka ipereke tanthauzo loyenerera.
/// Chotsitsa cha binary `k` ndiye kuchuluka kwakanthawi komwe tidachulukitsa manambala kapena ziwerengero ziwiri, mwachitsanzo, nthawi zonse `f *10^e` ikufanana ndi `(u / v)* 2^k`.
/// Tikazindikira tanthauzo lake, tifunikira kuzungulira ndikuwunika gawo lotsalalo, lomwe limachitika mothandizanso pansipa.
///
///
/// Ma algorithm awa ndi ocheperako, ngakhale ndi kukhathamiritsa komwe kwafotokozedwa mu `quick_start()`.
/// Komabe, ndiyo njira yosavuta kwambiri yosinthira kusefukira, kusefukira, ndi zotsatira zosazolowereka.
/// Kukhazikitsa kumeneku kumatenga pomwe Bellerophon ndi Algorithm R atadzazidwa.
/// Kuzindikira kusefukira ndi kusefukira ndikosavuta: Chiwerengero sichingakhale chofunikira pakatikati, komabe kutulutsa kwa minimum/maximum kwachitika.
/// Pankhani yakusefukira, timangobwerera zopanda malire.
///
/// Kusamalira kusefukira kwazinthu zachilendo ndizovuta.
/// Vuto limodzi lalikulu ndiloti, ndikutulutsa kocheperako, kuchuluka kwake kumatha kukhalabe kokulirapo kwambiri.
/// Onani underflow() kuti mumve zambiri.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME kukhathamiritsa kotheka: pangani big_to_fp kuti tithe kuchita zofanana ndi fp_to_float(big_to_fp(u)) pano, pokhapokha titazunguliza kawiri.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Tiyenera kuyimilira pang'onopang'ono, ngati tingodikirira `k < T::MIN_EXP_INT`, ndiye kuti tizingokhala awiri.
            // Tsoka ilo zikutanthauza kuti tiyenera kukhala ndi manambala apadera omwe amatulutsa zochepa.
            // FIXME ipeza kapangidwe kokongola kwambiri, koma yesani mayeso a `tiny-pow10` kuti muwonetsetse kuti ndi zolondola!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Imadumpha mayendedwe ambiri a Algorithm M poyang'ana kutalika kwake.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Kutalika pang'ono ndikulingalira kwa logarithm yoyambira, ndi log(u / v) = log(u), log(v).
    // Chiyerekezo chimachotsedwa ndi 1, koma nthawi zonse samayerekezera, chifukwa chake zolakwika za log(u) ndi log(v) ndizachizindikiro chimodzimodzi ndipo zimatha (ngati zonse zili zazikulu).
    // Chifukwa chake vuto la log(u / v) lilinso chimodzimodzi.
    // Chiwerengero chake ndi pomwe u/v ili mukutanthauzira kwapakatikati.Chifukwa chake kutha kwathu ndi log2(u / v) kukhala tanthauzo, plus/minus imodzi.
    // FIXME Kuyang'ana pang'ono kwachiwiri kumatha kusintha kuyerekezera ndikupewa magawano ena.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Yoyenda pansi kapena yachilendo.Siyani kuti ntchito yaikulu.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Kusefukira.Siyani kuti ntchito yaikulu.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Chiwerengero sichinthu chofunikira pakatikati ndi kutulutsa kocheperako, chifukwa chake tifunika kuzungulira zochulukirapo ndikusintha zomwezo molondola.
    // Mtengo weniweni tsopano ukuwoneka motere:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(kuyimiriridwa ndi rem)
    //
    // Chifukwa chake, ma bits omwe adazunguliridwa ali!= 0.5 ULP, amasankha kuzungulira okha.
    // Akakhala ofanana ndipo otsalawo alibe zero, mtengowo umafunikabe kuzunguliridwa.
    // Pokhapokha ndalama zomwe zidazunguliridwa ndi 1/2 ndipo zotsalazo ndi zero, timakhala ndi theka mpaka-vuto.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Kawirikawiri kuzungulira-ngakhale, kutengeka pochita zozungulira potengera gawo lomwe latsala.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}