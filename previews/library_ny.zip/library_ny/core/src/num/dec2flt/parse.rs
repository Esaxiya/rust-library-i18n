//! Kutsimikizira ndikuwononga chingwe cha decimal cha mawonekedwe:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Mwanjira ina, ma syntax oyandama-oyandikira, kupatula ziwiri: Palibe chizindikiro, ndipo osasamalira "inf" ndi "NaN".Izi zimayendetsedwa ndi driver driver (super::dec2flt).
//!
//! Ngakhale kuzindikira zolowetsa zofunikira ndizosavuta, gawoli liyeneranso kukana kusiyanasiyana kosavomerezeka, konse panic, ndikuchita macheke angapo omwe ma module ena amadalira osati panic (kapena kusefukira) nawonso.
//!
//! Zowonjezerapo, zonse zomwe zimachitika podutsa kamodzi kokha.
//! Chifukwa chake samalani pakusintha chilichonse, ndipo fufuzani kawiri ndi ma module ena.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Zida zosangalatsa za chingwe cha decimal.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Chiwonetsero cha decimal, chotsimikizika kukhala ndi ochepera 18 manambala.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Imafufuza ngati chingwe cholowereracho ndi nambala yovomerezeka yoyandama ndipo ngati ndi choncho, pezani gawo logwirizana, gawo lachigawo, ndi cholankhulira.
/// Sigwira zikwangwani.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Palibe manambala 'e' isanachitike
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Timafunikira manambala osachepera kapena pambuyo pake.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Kutsata zopanda pake pambuyo pamagawo ochepa
            }
        }
        _ => Invalid, // Kutsata zopanda pake pambuyo pachingwe choyamba manambala
    }
}

/// Amachotsa manambala mpaka koyamba kosakhala manambala.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Kutulutsa komanso kutulutsa zolakwika.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Kutsata zopanda pake pambuyo pofotokozera
    }
    if number.is_empty() {
        return Invalid; // Chotulutsa chopanda kanthu
    }
    // Pakadali pano, tili ndi zingwe zenizeni.Itha kukhala yayitali kwambiri kuyika mu `i64`, koma ngati ndi yayikulu chonchi, kulowetsako kulibe zero kapena kopanda malire.
    // Popeza zero zilizonse pamasamba a decimal zimangosintha zotulutsazo ndi +/-1, pa exp=10 ^ 18 zolowetsazo ziyenera kukhala 17 exabyte (!) ya zeros kuti ifike patali pang'ono kuti ithe.
    //
    // Izi sizomwe timagwiritsa ntchito zomwe timafunikira.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}