//! Ntchito zama bignums zomwe sizimveka bwino kuti zisanduke njira.

// FIXME Dzina la gawoli ndichachisoni, popeza ma module ena amalowetsanso `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Yesani ngati kudula zidutswa zonse zochepa kuposa `ones_place` kumabweretsa vuto lochepa, lofanana, kapena lalikulu kuposa 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Ngati ma bits onse otsala ndi zero, ndi= 0.5 ULP, apo ayi> 0.5 Ngati kulibenso ma bits (half_bit==0), zomwe zili pansipa zibwezeretsanso Mofanana.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Imatembenuza chingwe cha ASCII chokhala ndi manambala okha ku `u64`.
///
/// Sichichita cheke kuti chikusefukira kapena zilembo zosavomerezeka, chifukwa chake ngati amene akukuyimbirani samasamala, zotsatira zake ndizabodza ndipo panic (ngakhale siyikhala `unsafe`).
/// Kuphatikiza apo, zingwe zopanda kanthu zimatengedwa ngati zero.
/// Ntchitoyi ilipo chifukwa
///
/// 1. kugwiritsa ntchito `FromStr` pa `&[u8]` kumafuna `from_utf8_unchecked`, zomwe zili zoyipa, ndipo
/// 2. kuphatikiza zotsatira za `integral.parse()` ndi `fractional.parse()` ndizovuta kwambiri kuposa ntchito yonseyi.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Imatembenuza chingwe cha manambala a ASCII kukhala bignum.
///
/// Monga `from_str_unchecked`, ntchitoyi imadalira woyeserera kuti achotse zosakhala manambala.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Tsegulani bignum mu integer 64.Panics ngati nambala ndi yayikulu kwambiri.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Amachotsa zingwe zingapo.

/// Index 0 ndi yaying'ono kwambiri ndipo mtunduwo ndi theka lotseguka mwachizolowezi.
/// Panics ngati atafunsidwa kuti atenge zochulukirapo kuposa zoyenera mtundu wobwerera.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}