macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Mtengo wocheperako womwe ungayimiliridwe ndi mtundu wathunthuwu.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// Mtengo waukulu kwambiri womwe ungayimiliridwe ndi mtundu wochulukirapo.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// Kukula kwa mtundu wathunthuwo mu zidutswa.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Imatembenuza chidutswa chachingwe m'munsi mwake kuti chikhale chokwanira.
        ///
        /// Chingwechi chikuyembekezeka kukhala chizindikiro chosankha cha `+` chotsatira manambala.
        ///
        /// Azungu akutsogolera ndikutsata akuimira cholakwika.
        /// Manambala ndi gawo la zilembozi, kutengera `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Ntchitoyi panics ngati `radix` siyiyambira 2 mpaka 36.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Imabwezeretsa kuchuluka kwa omwe akuyimira pa `self`.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Imabwezeretsa chiwerengero cha zeros pakuyimira kwa `self`.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Imabwezeretsa chiwerengero cha zeros wotsogola pakuyimira kwa `self`.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Imabwezeretsa kuchuluka kwama zero m'mizere yoyimira `self`.
        ///
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Imabwezeretsa kuchuluka kwa omwe akutsogolera pakuyimira kwa `self`.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Imabwezeretsa kuchuluka kwa omwe akutsatira pakuyimira kwa `self`.
        ///
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Amasunthira mabatani kumanzere ndi kuchuluka kwake, `n`, kukulunga zidutswa zazing'ono kumapeto kwa chiwerengerocho.
        ///
        ///
        /// Chonde dziwani kuti izi sizofanana ndi zomwe zimasinthidwa ndi `<<`!
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Amasunthira mabatani kumanja ndi kuchuluka kwake, `n`, kukulunga zidutswa zazing'ono kumayambiriro kwa chiwerengerocho.
        ///
        ///
        /// Chonde dziwani kuti izi sizofanana ndi zomwe zimasinthidwa ndi `>>`!
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Imasinthira dongosolo lamtundu wa manambala onse.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// lolani m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Imasinthiratu dongosolo la mabwinja mu nambala yonse.
        /// Chofunika kwambiri chimakhala chofunikira kwambiri, chachiwiri chofunikira kwambiri chimakhala chachiwiri kwambiri, ndi zina zambiri.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// lolani m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Imatembenuza chiwerewere kuchokera ku endianness kupita ku endianness ya chandamale.
        ///
        /// Pamapeto akulu awa ndiop-op.
        /// Ma endian ang'onoang'ono amasinthidwa.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ngati cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } wina {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Imatembenuza kuchuluka kwathunthu kuchokera ku endian pang'ono kupita ku endianness ya chandamale.
        ///
        /// Pa endian yaying'ono iyi siyopanda.
        /// Pa main endian ma byte amasinthana.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ngati cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } wina {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Imatembenuza `self` kukhala endian wamkulu kuchokera ku endianness ya chandamale.
        ///
        /// Pamapeto akulu awa ndiop-op.
        /// Ma endian ang'onoang'ono amasinthidwa.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ngati cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } china { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // kapena ayi?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Amatembenuza `self` kukhala endian pang'ono kuchokera kumapeto kwa chandamale.
        ///
        /// Pa endian yaying'ono iyi siyopanda.
        /// Pa main endian ma byte amasinthana.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ngati cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } china { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Kuwonjezeka kuwonjezera.
        /// Ma compute `self + rhs`, obwezera `None` ngati kusefukira kunachitika.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Kusakanikirana kosasintha.Amapanga `self + rhs`, poganiza kuti kusefukira sikungachitike.
        /// Izi zimabweretsa machitidwe osadziwika pomwe
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Kuyang'ana kuchotsa kwathunthu.
        /// Ma compute `self - rhs`, obwezera `None` ngati kusefukira kunachitika.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Kuchotsa kosasinthika.Amapanga `self - rhs`, poganiza kuti kusefukira sikungachitike.
        /// Izi zimabweretsa machitidwe osadziwika pomwe
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Kufufuza kuchulukitsa
        /// Ma compute `self * rhs`, obwezera `None` ngati kusefukira kunachitika.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Kuchulukitsa kosasinthidwa.Amapanga `self * rhs`, poganiza kuti kusefukira sikungachitike.
        /// Izi zimabweretsa machitidwe osadziwika pomwe
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Kufufuza magawo ochuluka.
        /// Imawerengera `self / rhs`, ikubwezera `None` ngati `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // CHITETEZO: div ndi zero yawonedwa pamwambapa ndipo mitundu yosainidwa ilibe ina
                // Njira zolephera zogawika
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Kufufuza magawano a Euclidean.
        /// Imawerengera `self.div_euclid(rhs)`, ikubwezera `None` ngati `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Chotsalira chatsalira chokwanira
        /// Imawerengera `self % rhs`, ikubwezera `None` ngati `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // CHITETEZO: div ndi zero yawonedwa pamwambapa ndipo mitundu yosainidwa ilibe ina
                // Njira zolephera zogawika
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Kuyendera Euclidean modulo.
        /// Imawerengera `self.rem_euclid(rhs)`, ikubwezera `None` ngati `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Kuyang'anitsitsa.Imawerengera `-self`, ikubwezera `None` pokhapokha `self==
        /// 0`.
        ///
        /// Dziwani kuti kunyalanyaza nambala iliyonse yabwino kudzasefukira.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Kuyang'ana kosinthana kumanzere.
        /// Amapanga `self << rhs`, kubweza `None` ngati `rhs` ndi yayikulupo kapena yofanana ndi kuchuluka kwa ma bits mu `self`.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Afufuza kosinthana kumanja.
        /// Amapanga `self >> rhs`, kubweza `None` ngati `rhs` ndi yayikulupo kapena yofanana ndi kuchuluka kwa ma bits mu `self`.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Kuyendera kutuluka.
        /// Ma compute `self.pow(exp)`, obwezera `None` ngati kusefukira kunachitika.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // kuyambira exp!=0, pamapeto pake exp iyenera kukhala 1.
            // Kuthana ndi chomaliza cha chotulutsa padera, popeza kusanja maziko pambuyo pake sikofunikira ndipo kumatha kubweretsa kusefukira kosafunikira.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Kukwaniritsa kuwonjezera kwathunthu.
        /// Ma compute `self + rhs`, akukhuta pamalire am'malo m'malo mokhala osefukira.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Kuchotsa kwathunthu.
        /// Ma compute `self - rhs`, akukhuta pamalire am'malo m'malo mokhala osefukira.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Kuchulukitsa kwamitundu yonse.
        /// Ma compute `self * rhs`, akukhuta pamalire am'malo m'malo mokhala osefukira.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Kutsitsa kwathunthu.
        /// Ma compute `self.pow(exp)`, akukhuta pamalire am'malo m'malo mokhala osefukira.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Kukutira (modular) kuwonjezera.
        /// Amapanga `self + rhs`, kukulunga pamalire amtunduwo.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Kukutira kuchotsa (modular).
        /// Amapanga `self - rhs`, kukulunga pamalire amtunduwo.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Kukutira kuchulukitsa (modular).
        /// Amapanga `self * rhs`, kukulunga pamalire amtunduwo.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// Chonde dziwani kuti chitsanzochi chagawidwa pakati pa mitundu yonse.
        /// Zomwe zikufotokozera chifukwa chake `u8` imagwiritsidwa ntchito pano.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Kukulunga magawano a (modular).Amalemba `self / rhs`.
        /// Magawo okutidwa pamitundu yosainidwa ndi magawano wamba.
        /// Palibe njira zokutira zomwe zingachitike.
        /// Ntchitoyi ilipo, kotero kuti ntchito zonse zimawerengedwa pakuwombera.
        ///
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Kukutira magawano a Euclidean.Amalemba `self.div_euclid(rhs)`.
        /// Magawo okutidwa pamitundu yosainidwa ndi magawano wamba.
        /// Palibe njira zokutira zomwe zingachitike.
        /// Ntchitoyi ilipo, kotero kuti ntchito zonse zimawerengedwa pakuwombera.
        /// Popeza, kwa manambala athunthu, matanthauzidwe onse wamba amagawidwe ndi ofanana, izi ndizofanana ndendende ndi `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Kukutira zotsalira za (modular).Amalemba `self % rhs`.
        /// Kuwerengera kotsalira pamitundu yosatumizidwa ndi kuwerengera kotsalira kotsalira.
        ///
        /// Palibe njira zokutira zomwe zingachitike.
        /// Ntchitoyi ilipo, kotero kuti ntchito zonse zimawerengedwa pakuwombera.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Kukutira Euclidean modulo.Amalemba `self.rem_euclid(rhs)`.
        /// Kuwerengera kwa modulo pamitundu yosainidwa ndi kuwerengera kotsalira kokhazikika.
        /// Palibe njira zokutira zomwe zingachitike.
        /// Ntchitoyi ilipo, kotero kuti ntchito zonse zimawerengedwa pakuwombera.
        /// Popeza, kwa manambala abwino, matanthauzidwe onse wamba amagawidwe ndi ofanana, izi ndizofanana ndendende ndi `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Kukulunga kunyalanyaza (modular).
        /// Amapanga `-self`, kukulunga pamalire amtunduwo.
        ///
        /// Popeza mitundu yosainidwa ilibe zofanana ndi zonse ntchito za ntchitoyi zidzakulungidwa (kupatula `-0`).
        /// Pazinthu zochepa kuposa mtundu womwe udasainidwa pazotsatira zake ndizofanana ndi kuponya mtengo womwe wasainidwa.
        ///
        /// Zinthu zazikuluzikulu zilizonse ndizofanana ndi `MAX + 1 - (val - MAX - 1)` pomwe `MAX` ndiye mtundu wofananira womwe udasainidwa.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// Chonde dziwani kuti chitsanzochi chagawidwa pakati pa mitundu yonse.
        /// Zomwe zikufotokozera chifukwa chake `i8` imagwiritsidwa ntchito pano.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic yopanda pang'ono kusunthira kumanzere;
        /// imatulutsa `self << mask(rhs)`, pomwe `mask` imachotsa mabatani apamwamba a `rhs` omwe angapangitse kuti kusunthaku kupitirire kuchuluka kwa mtunduwo.
        ///
        /// Onani kuti izi sizofanana ndi kuzungulira mozungulira;RHS yokhotakhota kosunthira kumanzere imangolekera pamtundu wamtunduwo, m'malo mongotulutsa ma LHS obwezeredwa kumapeto ena.
        /// Mitundu yonse yoyambilira yonse imagwiritsa ntchito [`rotate_left`](Self::rotate_left), zomwe zitha kukhala zomwe mukufuna m'malo mwake.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // CHITETEZO: kubisa ndi mtundu wa bitsize kumatsimikizira kuti sitisuntha
            // kunja kwa malire
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic yopanda pang'ono kusuntha-kumanja;
        /// imatulutsa `self >> mask(rhs)`, pomwe `mask` imachotsa mabatani apamwamba a `rhs` omwe angapangitse kuti kusunthaku kupitirire kuchuluka kwa mtunduwo.
        ///
        /// Onani kuti izi sizofanana ndi kuzungulira mozungulira;RHS yakusunthira-kumanja kumangolozera pamtundu wamtunduwo, m'malo mongotulutsa ma LHS obwezeredwa kumapeto ena.
        /// Mitundu yonse yoyambilira yonse imagwiritsa ntchito [`rotate_right`](Self::rotate_right), zomwe zitha kukhala zomwe mukufuna m'malo mwake.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // CHITETEZO: kubisa ndi mtundu wa bitsize kumatsimikizira kuti sitisuntha
            // kunja kwa malire
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Kukulunga kufotokoza kwa (modular).
        /// Amapanga `self.pow(exp)`, kukulunga pamalire amtunduwo.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // kuyambira exp!=0, pamapeto pake exp iyenera kukhala 1.
            // Kuthana ndi chomaliza cha chotulutsa padera, popeza kusanja maziko pambuyo pake sikofunikira ndipo kumatha kubweretsa kusefukira kosafunikira.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Ikuwerengetsa `self` + `rhs`
        ///
        /// Kubwezera kachidindo kowonjezerako limodzi ndi boolean yosonyeza ngati kuchuluka kwa masamu kungachitike.
        /// Ngati kusefukira kukadachitika ndiye kuti mtengo wokutidwawo umabwezedwa.
        ///
        /// # Examples
        ///
        /// Kugwiritsa ntchito kwenikweni
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Ikuwerengetsa `self`, `rhs`
        ///
        /// Kubwezeretsa kachidutswa kochotsera limodzi ndi boolean yosonyeza ngati masamu akusefukira angachitike.
        /// Ngati kusefukira kukadachitika ndiye kuti mtengo wokutidwawo umabwezedwa.
        ///
        /// # Examples
        ///
        /// Kugwiritsa ntchito kwenikweni
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Kuwerengetsa kuchulukitsa kwa `self` ndi `rhs`.
        ///
        /// Kubwezera kachilombo kochulukitsa limodzi ndi boolean yosonyeza ngati kuchuluka kwa masamu kungachitike.
        /// Ngati kusefukira kukadachitika ndiye kuti mtengo wokutidwawo umabwezedwa.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// Chonde dziwani kuti chitsanzochi chagawidwa pakati pa mitundu yonse.
        /// Zomwe zikufotokozera chifukwa chake `u32` imagwiritsidwa ntchito pano.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Kuwerengetsa wogawa pamene `self` igawidwa ndi `rhs`.
        ///
        /// Kubwezera kachidutswa kagawuniyo limodzi ndi boolean yosonyeza ngati kuchuluka kwa masamu kungachitike.
        /// Dziwani kuti kuzinthu zosayina zomwe zikusefukira sizimachitika, chifukwa chake mtengo wachiwiri nthawi zonse umakhala `false`.
        ///
        /// # Panics
        ///
        /// Ntchitoyi idzachita panic ngati `rhs` ili 0.
        ///
        /// # Examples
        ///
        /// Kugwiritsa ntchito kwenikweni
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Ikuwerengetsa kuchuluka kwa magawano a Euclidean `self.div_euclid(rhs)`.
        ///
        /// Kubwezera kachidutswa kagawuniyo limodzi ndi boolean yosonyeza ngati kuchuluka kwa masamu kungachitike.
        /// Dziwani kuti kuzinthu zosayina zomwe zikusefukira sizimachitika, chifukwa chake mtengo wachiwiri nthawi zonse umakhala `false`.
        /// Popeza, kwa manambala athunthu, matanthauzidwe onse wamba amagawidwe ndi ofanana, izi ndizofanana ndendende ndi `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Ntchitoyi idzachita panic ngati `rhs` ili 0.
        ///
        /// # Examples
        ///
        /// Kugwiritsa ntchito kwenikweni
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Kuwerengetsa zotsalazo `self` igawidwa ndi `rhs`.
        ///
        /// Kubwezera kachidutswa kotsalira pambuyo pogawa limodzi ndi boolean posonyeza ngati masamu osefukira angachitike.
        /// Dziwani kuti kuzinthu zosayina zomwe zikusefukira sizimachitika, chifukwa chake mtengo wachiwiri nthawi zonse umakhala `false`.
        ///
        /// # Panics
        ///
        /// Ntchitoyi idzachita panic ngati `rhs` ili 0.
        ///
        /// # Examples
        ///
        /// Kugwiritsa ntchito kwenikweni
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Ikuwerengera zotsala `self.rem_euclid(rhs)` ngati kuti zidagawidwa ndi Euclidean.
        ///
        /// Kubwezeretsa phokoso la modulo mutagawika limodzi ndi boolean yosonyeza ngati masamu akusefukira atha.
        /// Dziwani kuti kuzinthu zosayina zomwe zikusefukira sizimachitika, chifukwa chake mtengo wachiwiri nthawi zonse umakhala `false`.
        /// Popeza, kwa manambala abwino, matanthauzidwe onse wamba amagawidwe ndi ofanana, ntchitoyi ndiyofanana ndendende ndi `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Ntchitoyi idzachita panic ngati `rhs` ili 0.
        ///
        /// # Examples
        ///
        /// Kugwiritsa ntchito kwenikweni
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Kudzisamalira nokha modzaza.
        ///
        /// Kubwezeretsa `!self + 1` pogwiritsa ntchito ntchito zokutira kuti ibwezeretse mtengo womwe ukuimira kunyalanyaza kwa mtengo wosainidwawu.
        /// Dziwani kuti pazabwino zomwe sizinalembedwe zikusefukira nthawi zonse, koma kunyalanyaza 0 sikusefukira.
        ///
        /// # Examples
        ///
        /// Kugwiritsa ntchito kwenikweni
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Kusintha komwe kumatsalira ndi ma `rhs` bits.
        ///
        /// Kubwezeretsa tuple tomwe tasinthira tokha komanso boolean yosonyeza ngati mtengo wosinthira udali wokulirapo kapena wofanana ndi kuchuluka kwa ma bits.
        /// Ngati kusinthaku kuli kokulirapo, ndiye kuti mtengo umasungidwa (N-1) pomwe N ndiye kuchuluka kwa ma bits, ndipo mtengowu umagwiritsidwa ntchito pochita kusintha.
        ///
        /// # Examples
        ///
        /// Kugwiritsa ntchito kwenikweni
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Amadzisunthira yekha ndi ma `rhs` bits.
        ///
        /// Kubwezeretsa tuple tomwe tasinthira tokha komanso boolean yosonyeza ngati mtengo wosinthira udali wokulirapo kapena wofanana ndi kuchuluka kwa ma bits.
        /// Ngati kusinthaku kuli kokulirapo, ndiye kuti mtengo umasungidwa (N-1) pomwe N ndiye kuchuluka kwa ma bits, ndipo mtengowu umagwiritsidwa ntchito pochita kusintha.
        ///
        /// # Examples
        ///
        /// Kugwiritsa ntchito kwenikweni
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Lidzikweza lokha mphamvu ya `exp`, pogwiritsa ntchito kuwonekera powonera.
        ///
        /// Imabwezeretsa tuple of the exponentiationation ndi bool kuwonetsa ngati kusefukira kudachitika.
        ///
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, zoona));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Tsegulani malo osungira zotsatira za kusefukira_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // kuyambira exp!=0, pamapeto pake exp iyenera kukhala 1.
            // Kuthana ndi chomaliza cha chotulutsa padera, popeza kusanja maziko pambuyo pake sikofunikira ndipo kumatha kubweretsa kusefukira kosafunikira.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Lidzikweza lokha mphamvu ya `exp`, pogwiritsa ntchito kuwonekera powonera.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // kuyambira exp!=0, pamapeto pake exp iyenera kukhala 1.
            // Kuthana ndi chomaliza cha chotulutsa padera, popeza kusanja maziko pambuyo pake sikofunikira ndipo kumatha kubweretsa kusefukira kosafunikira.
            //
            //
            acc * base
        }

        /// Amachita magawano a Euclidean.
        ///
        /// Popeza, kwa manambala athunthu, matanthauzidwe onse wamba amagawidwe ndi ofanana, izi ndizofanana ndendende ndi `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Ntchitoyi idzachita panic ngati `rhs` ili 0.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Kuwerengetsa zotsala zochepa za `self (mod rhs)`.
        ///
        /// Popeza, kwa manambala athunthu, matanthauzidwe onse wamba amagawidwe ndi ofanana, izi ndizofanana ndendende ndi `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Ntchitoyi idzachita panic ngati `rhs` ili 0.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Kubwezera `true` ngati kungakhale `self == 2^k` kwa `k` ina.
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Imabwezeretsa ochepera mphamvu yotsatira yamawiri.
        // (Pa 8u8 mphamvu yotsatira iwiri ndi 8u8 ndipo ya 6u8 ndi 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Njirayi siyingasefukire, monga momwe zimakhalira mu `next_power_of_two` yomwe imasefukira koma imangobweza mtengo wake wamtunduwu, ndipo imatha kubwezera 0 kwa 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // CHITETEZO: Chifukwa `p > 0`, siyingakhale ndi zero zokha zotsogolera.
            // Izi zikutanthauza kuti kusunthaku kumakhala kopanda malire, ndipo ma processor ena (monga intel pre-haswell) amakhala ndi ma ctlz opambana kwambiri pomwe kukangana kulibe zero.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Kubwezeretsa mphamvu yaying'ono kwambiri yoposa kapena yofanana ndi `self`.
        ///
        /// Mtengo wobwerera ukasefukira (mwachitsanzo, `self > (1 << (N-1))` yamtundu wa `uN`), ndi panics mumayendedwe olakwika ndikubwezeretsa mtengo wokutidwa ndi 0 pamachitidwe otulutsira (njira yokhayo njira yobweretsera 0).
        ///
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Kubwezeretsa mphamvu yaying'ono kwambiri yoposa kapena yofanana ndi `n`.
        /// Ngati mphamvu yotsatira ikuluikulu kuposa mtundu wake, `None` imabwezedwa, apo ayi mphamvu ya awiri imakulungidwa mu `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Kubwezeretsa mphamvu yaying'ono kwambiri yoposa kapena yofanana ndi `n`.
        /// Ngati mphamvu yotsatira iwiri ikulu kuposa mtengo wake, mtengo wobwezera umakulungidwa ku `0`.
        ///
        ///
        /// # Examples
        ///
        /// Kagwiritsidwe:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Bweretsani chiwonetsero chokumbukira cha manambalawa ngati dongosolo la byte mu big-endian (network) byte.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Bweretsani chiwonetsero chokumbukira cha manambalawa ngati gulu la mamvekedwe a dongosolo la ma-endian byte.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Bweretsani chiwonetsero chokumbukira cha manambalawa ngati mayimbidwe am'mbuyomu.
        ///
        /// Momwe kugwiritsa ntchito papulatifomu yogwiritsidwa ntchito imagwiritsidwa ntchito, nambala yonyamula iyenera kugwiritsa ntchito [`to_be_bytes`] kapena [`to_le_bytes`], koyenera, m'malo mwake.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     byte, ngati cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } wina {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // CHITETEZO: phokoso limamveka chifukwa manambala onse ndiosavuta kuti tithe kuchita zonse
        // azisunthira kuzipangizo za mabayiti
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // CHITETEZO: manambala onse ndiosavuta kuti titha kuwatumizira
            // magulu a mabayiti
            unsafe { mem::transmute(self) }
        }

        /// Bweretsani chiwonetsero chokumbukira cha manambalawa ngati mayimbidwe am'mbuyomu.
        ///
        ///
        /// [`to_ne_bytes`] ziyenera kukondedwa kuposa izi ngati zingatheke.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// lettes= num.as_ne_bytes();
        /// assert_eq!(
        ///     byte, ngati cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } wina {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // CHITETEZO: manambala onse ndiosavuta kuti titha kuwatumizira
            // magulu a mabayiti
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Pangani mtengo wamtundu wamkati wamkati wamtunduwu kuchokera pakuyimira kwake ngati gulu la byte mu endian yayikulu.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// gwiritsani ntchito std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * kulowetsa=kupumula;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Pangani mtengo wamtundu wamkati wamkati wamtunduwu kuchokera pakuyimira kwake ngati kanyumba kakang'ono ka ma endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// gwiritsani ntchito std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * kulowetsa=kupumula;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Pangani mtengo wamtundu wamtundu wa endian wochuluka kuchokera pamakumbukiro ake monga zolemba zazing'ono zam'mbuyomu.
        ///
        /// Pomwe kugwiritsidwa ntchito kwa pulatifomu yakomwe akugwiritsa ntchito, nambala yosunthika iyenera kugwiritsa ntchito [`from_be_bytes`] kapena [`from_le_bytes`], koyenera m'malo mwake.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } wina {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// gwiritsani ntchito std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * kulowetsa=kupumula;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // CHITETEZO: phokoso limamveka chifukwa manambala onse ndiosavuta kuti tithe kuchita zonse
        // tumizani kwa iwo
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // CHITETEZO: manambala ali ndi mbiri yakale kuti titha kuwatumizira
            unsafe { mem::transmute(bytes) }
        }

        /// Nambala yatsopano iyenera kugwiritsa ntchito
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Imabweza mtengo wocheperako womwe ungayimiliridwe ndi mtundu wathunthuwu.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Nambala yatsopano iyenera kugwiritsa ntchito
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Imabweza mtengo waukulu kwambiri womwe ungayimiliridwe ndi mtundu wochulukirapo.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}