//! Kugawidwa kwa kukumbukira APIs

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Vuto la `AllocError` likuwonetsa kulephera kwa magawidwe komwe kumatha kukhala chifukwa chakutha chuma kapena china chake cholakwika pophatikiza zomwe zaperekedwa ndi woperekayo.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (tikufuna izi kuti tipeze cholakwika cha trait)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Kukhazikitsa kwa `Allocator` kumatha kugawa, kukulitsa, kunyinyirika, ndikugawa zosokoneza zomwe zafotokozedwa kudzera pa [`Layout`][].
///
/// `Allocator` lakonzedwa kuti ligwiritsidwe ntchito pa ZSTs, maumboni, kapena maupangiri anzeru chifukwa kukhala ndi ogawa monga `MyAlloc([u8; N])` sangathe kusunthidwa, osasinthanso zolozera kuti zizikumbukiridwa.
///
/// Mosiyana ndi [`GlobalAlloc`][], magawo osachepera zero amaloledwa mu `Allocator`.
/// Ngati woperekayo sakugwirizana ndi izi (monga jemalloc) kapena kubwezera cholozera chopanda pake (monga `libc::malloc`), izi ziyenera kugwidwa ndi kukhazikitsa.
///
/// ### Zomwe zapatsidwa pano
///
/// Zina mwa njirazi zimafuna kuti memori yolandila *ipatsidwe* kudzera mwa ogawa.Izi zikutanthauza kuti:
///
/// * adilesi yoyambira ya memory memory idabwezedwa kale ndi [`allocate`], [`grow`], kapena [`shrink`], ndi
///
/// * chikumbukiro sichinasamutsidwe pambuyo pake, pomwe mabulogu amatha kutumizidwa mwachindunji ndikupita ku [`deallocate`] kapena adasinthidwa ndikudutsa [`grow`] kapena [`shrink`] yomwe imabwezeretsa `Ok`.
///
/// Ngati `grow` kapena `shrink` abweza `Err`, cholozera chodutsacho sichikhala chovomerezeka.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Kuyenera kukumbukira
///
/// Zina mwa njirazi zimafuna kuti mawonekedwe *akwaniritse* chosungira kukumbukira.
/// Zomwe zikutanthauza kukhazikitsidwa kwa "fit" memory memory kumatanthauza (kapena chimodzimodzi, pamakumbukidwe mpaka "fit" mawonekedwe) ndikuti zinthu zotsatirazi ziyenera kugwira:
///
/// * Chipikacho chiyenera kuperekedwa mogwirizana ndi [`layout.align()`], ndi
///
/// * [`layout.size()`] yomwe yaperekedwa iyenera kugwera pamtundu wa `min ..= max`, pomwe:
///   - `min` ndi kukula kwa mawonekedwe omwe agwiritsidwa ntchito posachedwa kupatula block, ndipo
///   - `max` kukula kwenikweni kwaposachedwa kubwezedwa kuchokera ku [`allocate`], [`grow`], kapena [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Zolemba pamtima zomwe zimabweretsedwanso kuchokera kwa ogawa ziyenera kuloza kukumbukira kukumbukira ndikusunga magwiridwe ake mpaka chithunzicho chigwetsedwa,
///
/// * Kupanga kapena kusunthira wogawira sikuyenera kulepheretsa zikumbukiro zomwe abweza kuchokera kwa woperekayo.Wopatsa omwe akuyenera kukhala ngati wogawana omwewo, ndipo
///
/// * cholozera chilichonse ku memory block chomwe ndi [*currently allocated*] chitha kuperekedwa njira ina iliyonse yogawa.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Kuyesera kupereka gawo lokumbukira.
    ///
    /// Mukachita bwino, mubwezera msonkhano wa [`NonNull<[u8]>`][NonNull] kukula ndi mayikidwe a `layout`.
    ///
    /// Malo obwezeretsedwayo atha kukhala ndi kukula kokulirapo kuposa kutchulidwa ndi `layout.size()`, ndipo atha kuyamba kapena sangakhale ndi zomwe zili mkati.
    ///
    /// # Errors
    ///
    /// Kubwezera `Err` kukuwonetsa kuti kukumbukira konse kwatha kapena `layout` sikukukumana ndi kukula kwa wopatsa kapena zovuta zomwe zikugwirizana.
    ///
    /// Zoyeserera zikulimbikitsidwa kuti zibwezeretse `Err` pakutha kwa kukumbukira m'malo mochita mantha kapena kuchotsa mimba, koma izi sizofunikira kwenikweni.
    /// (Makamaka: ndizovomerezeka * kukhazikitsa trait pamwamba pa library yomwe imagawilidwa kale yomwe imatha kukumbukira kukumbukira.)
    ///
    /// Otsatsa omwe akufuna kuchotsa kuwerengera poyankha vuto la kagawidwe amalimbikitsidwa kuyimbira ntchito [`handle_alloc_error`], m'malo moyitanitsa `panic!` kapena zina zotere.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Amakhala ngati `allocate`, komanso amaonetsetsa kuti kukumbukira komwe kubwezedwa sikunayambike zero.
    ///
    /// # Errors
    ///
    /// Kubwezera `Err` kukuwonetsa kuti kukumbukira konse kwatha kapena `layout` sikukukumana ndi kukula kwa wopatsa kapena zovuta zomwe zikugwirizana.
    ///
    /// Zoyeserera zikulimbikitsidwa kuti zibwezeretse `Err` pakutha kwa kukumbukira m'malo mochita mantha kapena kuchotsa mimba, koma izi sizofunikira kwenikweni.
    /// (Makamaka: ndizovomerezeka * kukhazikitsa trait pamwamba pa library yomwe imagawilidwa kale yomwe imatha kukumbukira kukumbukira.)
    ///
    /// Otsatsa omwe akufuna kuchotsa kuwerengera poyankha vuto la kagawidwe amalimbikitsidwa kuyimbira ntchito [`handle_alloc_error`], m'malo moyitanitsa `panic!` kapena zina zotere.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // CHITETEZO: `alloc` imabwezeretsa chikumbukiro chomveka
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Kuchotsa kukumbukira komwe kutchulidwa ndi `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` zikuyenera kutanthauza kukumbukira [*currently allocated*] kudzera pagawoli, ndipo
    /// * `layout` ayenera [*fit*] chikumbukiro chimenecho.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Kuyesera kukulitsa chikumbukiro.
    ///
    /// Kubwezeretsa [`NonNull<[u8]>`][NonNull] yatsopano yokhala ndi cholozera ndi kukula kwenikweni kwa kukumbukira komwe kwapatsidwa.Cholozera ndi choyenera kukhala ndi chidziwitso chofotokozedwa ndi `new_layout`.
    /// Kuti akwaniritse izi, woperekayo atha kuwonjezera magawidwe omwe akutchulidwa ndi `ptr` kuti agwirizane ndi mawonekedwe atsopanowo.
    ///
    /// Ngati izi zibwezeretsa `Ok`, ndiye kuti umwini wa memory block womwe `ptr` idasamutsidwa upatsidwe kwa wogawa.
    /// Kukumbukiraku mwina kumasulidwa kapena kusamasulidwa, ndipo kuyenera kuwonedwa ngati kosagwiritsidwa ntchito pokhapokha kukabwezeretsedwanso kwa woyimbayo kudzera pakubweza kwa njirayi.
    ///
    /// Ngati njirayi ibwerera `Err`, ndiye kuti umwini wa memory block sunasamutsidwe kwa woperekayo, ndipo zomwe zili mu memory block sizinasinthidwe.
    ///
    /// # Safety
    ///
    /// * `ptr` zikuyenera kutanthauza kukumbukira [*currently allocated*] kudzera pagawoli.
    /// * `old_layout` Muyenera [*fit*] chikumbukiro chimenecho (Mtsutso wa `new_layout` sikuyenera kuyenerana nawo.).
    /// * `new_layout.size()` iyenera kukhala yayikulu kuposa kapena yofanana ndi `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Imabwezeretsa `Err` ngati mawonekedwe atsopanowo sakugwirizana ndi kukula kwa woperekayo ndi zovuta zomwe wopatsa akugawana, kapena ngati kukula kwina kulephera.
    ///
    /// Zoyeserera zikulimbikitsidwa kuti zibwezeretse `Err` pakutha kwa kukumbukira m'malo mochita mantha kapena kuchotsa mimba, koma izi sizofunikira kwenikweni.
    /// (Makamaka: ndizovomerezeka * kukhazikitsa trait pamwamba pa library yomwe imagawilidwa kale yomwe imatha kukumbukira kukumbukira.)
    ///
    /// Otsatsa omwe akufuna kuchotsa kuwerengera poyankha vuto la kagawidwe amalimbikitsidwa kuyimbira ntchito [`handle_alloc_error`], m'malo moyitanitsa `panic!` kapena zina zotere.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // CHITETEZO: chifukwa `new_layout.size()` iyenera kukhala yayikulupo kapena yofanana
        // `old_layout.size()`, kugawa kwakale komanso kwatsopano kumakhala koyenera kuwerengedwa ndikulembera ma `old_layout.size()` byte.
        // Komanso, chifukwa gawo lakale silinaperekedwe, silingagwirizane ndi `new_ptr`.
        // Chifukwa chake, kuyitanidwa ku `copy_nonoverlapping` ndikotetezeka.
        // Mgwirizano wachitetezo wa `dealloc` uyenera kusungidwa ndi woyimbirayo.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Zimakhala ngati `grow`, komanso zimawonetsetsa kuti zomwe zikusungidwazo zasungidwa zero zisanabwezeretsedwe.
    ///
    /// Malo okumbukira adzakhala ndi zotsatirazi mutayitanitsa bwino
    /// `grow_zeroed`:
    ///   * Ma Byte `0..old_layout.size()` amasungidwa kuchokera kumagawidwe oyamba.
    ///   * Ma Byte `old_layout.size()..old_size` atha kusungidwa kapena kuthetsedwa, kutengera kukhazikitsidwa kwa wogawira.
    ///   `old_size` amatanthauza kukula kwa chikumbukiro chisanafike kuyimbira kwa `grow_zeroed`, komwe kumatha kukhala kokulirapo kuposa kukula komwe kudafunsidwa koyambirira pomwe idaperekedwa.
    ///   * Ma Byte `old_size..new_size` adasinthidwa.`new_size` imatanthawuza kukula kwa memory memory yomwe yabwezeredwa ndi foni ya `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` zikuyenera kutanthauza kukumbukira [*currently allocated*] kudzera pagawoli.
    /// * `old_layout` Muyenera [*fit*] chikumbukiro chimenecho (Mtsutso wa `new_layout` sikuyenera kuyenerana nawo.).
    /// * `new_layout.size()` iyenera kukhala yayikulu kuposa kapena yofanana ndi `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Imabwezeretsa `Err` ngati mawonekedwe atsopanowo sakugwirizana ndi kukula kwa woperekayo ndi zovuta zomwe wopatsa akugawana, kapena ngati kukula kwina kulephera.
    ///
    /// Zoyeserera zikulimbikitsidwa kuti zibwezeretse `Err` pakutha kwa kukumbukira m'malo mochita mantha kapena kuchotsa mimba, koma izi sizofunikira kwenikweni.
    /// (Makamaka: ndizovomerezeka * kukhazikitsa trait pamwamba pa library yomwe imagawilidwa kale yomwe imatha kukumbukira kukumbukira.)
    ///
    /// Otsatsa omwe akufuna kuchotsa kuwerengera poyankha vuto la kagawidwe amalimbikitsidwa kuyimbira ntchito [`handle_alloc_error`], m'malo moyitanitsa `panic!` kapena zina zotere.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // CHITETEZO: chifukwa `new_layout.size()` iyenera kukhala yayikulupo kapena yofanana
        // `old_layout.size()`, kugawa kwakale komanso kwatsopano kumakhala koyenera kuwerengedwa ndikulembera ma `old_layout.size()` byte.
        // Komanso, chifukwa gawo lakale silinaperekedwe, silingagwirizane ndi `new_ptr`.
        // Chifukwa chake, kuyitanidwa ku `copy_nonoverlapping` ndikotetezeka.
        // Mgwirizano wachitetezo wa `dealloc` uyenera kusungidwa ndi woyimbirayo.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Kuyesera kuchepetsa kukumbukira.
    ///
    /// Kubwezeretsa [`NonNull<[u8]>`][NonNull] yatsopano yokhala ndi cholozera ndi kukula kwenikweni kwa kukumbukira komwe kwapatsidwa.Cholozera ndi choyenera kukhala ndi chidziwitso chofotokozedwa ndi `new_layout`.
    /// Kuti akwaniritse izi, woperekayo atha kuchepetsa gawo lomwe limatchulidwa ndi `ptr` kuti likwaniritse mawonekedwe atsopanowo.
    ///
    /// Ngati izi zibwezeretsa `Ok`, ndiye kuti umwini wa memory block womwe `ptr` idasamutsidwa upatsidwe kwa wogawa.
    /// Kukumbukiraku mwina kumasulidwa kapena kusamasulidwa, ndipo kuyenera kuwonedwa ngati kosagwiritsidwa ntchito pokhapokha kukabwezeretsedwanso kwa woyimbayo kudzera pakubweza kwa njirayi.
    ///
    /// Ngati njirayi ibwerera `Err`, ndiye kuti umwini wa memory block sunasamutsidwe kwa woperekayo, ndipo zomwe zili mu memory block sizinasinthidwe.
    ///
    /// # Safety
    ///
    /// * `ptr` zikuyenera kutanthauza kukumbukira [*currently allocated*] kudzera pagawoli.
    /// * `old_layout` Muyenera [*fit*] chikumbukiro chimenecho (Mtsutso wa `new_layout` sikuyenera kuyenerana nawo.).
    /// * `new_layout.size()` iyenera kukhala yocheperako kapena yofanana ndi `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Imabwezeretsa `Err` ngati mawonekedwe atsopanowo sakugwirizana ndi kukula kwa woperekera ndi zovuta zomwe woperekayo akugawana, kapena ngati kuchepa mwina sikulephera.
    ///
    /// Zoyeserera zikulimbikitsidwa kuti zibwezeretse `Err` pakutha kwa kukumbukira m'malo mochita mantha kapena kuchotsa mimba, koma izi sizofunikira kwenikweni.
    /// (Makamaka: ndizovomerezeka * kukhazikitsa trait pamwamba pa library yomwe imagawilidwa kale yomwe imatha kukumbukira kukumbukira.)
    ///
    /// Otsatsa omwe akufuna kuchotsa kuwerengera poyankha vuto la kagawidwe amalimbikitsidwa kuyimbira ntchito [`handle_alloc_error`], m'malo moyitanitsa `panic!` kapena zina zotere.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // CHITETEZO: chifukwa `new_layout.size()` iyenera kukhala yocheperako kapena yofanana ndi
        // `old_layout.size()`, kugawa kwakale komanso kwatsopano kumakhala koyenera kuwerengedwa ndikulembera ma `new_layout.size()` byte.
        // Komanso, chifukwa gawo lakale silinaperekedwe, silingagwirizane ndi `new_ptr`.
        // Chifukwa chake, kuyitanidwa ku `copy_nonoverlapping` ndikotetezeka.
        // Mgwirizano wachitetezo wa `dealloc` uyenera kusungidwa ndi woyimbirayo.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Amapanga adaputala ya "by reference" pamtundu uwu wa `Allocator`.
    ///
    /// Adapter yobwezeretsanso imagwiritsanso ntchito `Allocator` ndipo ingobwereka izi.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // CHITETEZO: mgwirizano wachitetezo uyenera kusungidwa ndi woyimbirayo
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // CHITETEZO: mgwirizano wachitetezo uyenera kusungidwa ndi woyimbirayo
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // CHITETEZO: mgwirizano wachitetezo uyenera kusungidwa ndi woyimbirayo
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // CHITETEZO: mgwirizano wachitetezo uyenera kusungidwa ndi woyimbirayo
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}