use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Ogawa kukumbukira omwe amatha kulembetsa ngati laibulale yokhazikika pamtundu wa `#[global_allocator]`.
///
/// Zina mwa njirazi zimafuna kuti memori yolandila *ipatsidwe* kudzera mwa ogawa.Izi zikutanthauza kuti:
///
/// * adilesi yoyambira ya memory memoryyo idabwezedwa kale ndi mayitanidwe am'mbuyomu ku njira yogawa monga `alloc`, ndi
///
/// * chikumbukiro sichinasamutsidwe pambuyo pake, pomwe mabulogu amapititsidwa mwina popititsidwa ku njira yolozera monga `dealloc` kapena kuperekedwa njira yokhazikitsanso yomwe imabwezeretsanso chosakira.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` trait ndi `unsafe` trait pazifukwa zingapo, ndipo oyambitsa akuyenera kuwonetsetsa kuti amatsatira mapanganowa:
///
/// * Khalidwe losadziwika ngati omwe akugawana padziko lonse akupumula.Kuletsa uku kumatha kukwezedwa mu future, koma pakadali pano panic kuchokera kuzinthu izi zitha kubweretsa kukumbukira kukumbukira.
///
/// * `Layout` mafunso ndi kuwerengera kwakukulu kuyenera kukhala kolondola.Oyimbira trait amaloledwa kudalira mapangano omwe afotokozedwa munjira iliyonse, ndipo oyambitsa akuyenera kuwonetsetsa kuti mapanganowo akwaniritsidwa.
///
/// * Simungadalire magawidwe omwe akuchitikadi, ngakhale atakhala kuti pali milu yambiri.
/// Optimizer itha kuzindikira magawo omwe sagwiritsidwe ntchito omwe amatha kuthetseratu kapena kusunthira muluwo motero osapempha ogawa.
/// Wowonjezerayo angaganizirenso kuti kugawa sikungalephereke, ndiye kuti nambala yomwe imalephera chifukwa chakulephera kwa omwe akugawa tsopano itha kugwira ntchito mwadzidzidzi chifukwa chowongolera chinagwira ntchito posowa gawo.
/// Mwachidule, zitsanzo zotsatirazi ndizolondola, mosasamala kanthu kuti woperekayo amalola kuwerengera kuchuluka kwa magawo omwe achitika.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Dziwani kuti kukhathamiritsa kotchulidwa pamwambapa sindiko kukhathamiritsa kokha komwe kungagwiritsidwe ntchito.Nthawi zambiri simungadalire kugawa milu ngati kungachotsedwe osasintha machitidwe a pulogalamu.
///   Kaya magawidwe akupezeka kapena ayi sindiwo gawo la pulogalamuyi, ngakhale atha kupezeka kudzera mwa owapatsa omwe amatsata magawidwe posindikiza kapena kukhala ndi zotsatirapo zina.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Gawani kukumbukira monga momwe tafotokozera ndi `layout`.
    ///
    /// Kubwezeretsa cholozera kukumbukira kumene mwangopatsidwa kumene, kapena null kuti muwonetse kulephera kwa kugawa.
    ///
    /// # Safety
    ///
    /// Ntchitoyi ndi yosatetezeka chifukwa chikhalidwe chosadziwika chitha kubwera ngati woyimbirayo sakuwonetsetsa kuti `layout` ilibe zero kukula.
    ///
    /// (Zowonjezera zowonjezera zitha kupereka malire pamakhalidwe, mwachitsanzo, kutsimikizira adilesi ya sentinel kapena cholozera chopanda tanthauzo poyankha pempho la kukula kwa zero.)
    ///
    /// Malo omwe amakumbukiridwa atha kuyambitsidwa kapena sangayambitsidwe.
    ///
    /// # Errors
    ///
    /// Kubwezeretsa pointer yopanda tanthauzo kukuwonetsa kuti kukumbukira konse kutha kapena `layout` siyikumana ndi kukula kwa woperekayo kapena zovuta zomwe zikugwirizana.
    ///
    /// Zoyeserera zimalimbikitsidwa kuti zibwererenso kutopa pokumbukira m'malo motaya mimba, koma izi sizofunikira kwenikweni.
    /// (Makamaka: ndizovomerezeka * kukhazikitsa trait pamwamba pa library yomwe imagawilidwa kale yomwe imatha kukumbukira kukumbukira.)
    ///
    /// Otsatsa omwe akufuna kuchotsa kuwerengera poyankha vuto la kagawidwe amalimbikitsidwa kuyimbira ntchito [`handle_alloc_error`], m'malo moyitanitsa `panic!` kapena zina zotere.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Sanjani malo okumbukira pa cholembera cha `ptr` ndi `layout` yopatsidwa.
    ///
    /// # Safety
    ///
    /// Ntchitoyi ndiyotetezeka chifukwa machitidwe osadziwika angachitike ngati woyimbirayo sakuwonetsetsa zotsatirazi:
    ///
    ///
    /// * `ptr` ziyenera kutanthauza chikumbukiro chomwe chikugawidwa kudzera mwa ogawa,
    ///
    /// * `layout` iyenera kukhala yofanana yomwe idagwiritsidwa ntchito kugawa chikumbukirocho.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Amakhala ngati `alloc`, komanso amaonetsetsa kuti zomwe zalembedwazo zidasinthidwa kukhala ziro zisanabwezeretsedwe.
    ///
    /// # Safety
    ///
    /// Ntchitoyi ndi yosatetezeka pazifukwa zomwe `alloc` ili.
    /// Komabe gawo lokumbukira lomwe tapatsidwa limatsimikiziridwa kuti liyambe kuyambika.
    ///
    /// # Errors
    ///
    /// Kubwezeretsa pointer yopanda tanthauzo kukuwonetsa kuti kukumbukira konse kwatha kapena `layout` siyikumana ndi kukula kwa ogawa kapena zovuta, monga `alloc`.
    ///
    /// Otsatsa omwe akufuna kuchotsa kuwerengera poyankha vuto la kagawidwe amalimbikitsidwa kuyimbira ntchito [`handle_alloc_error`], m'malo moyitanitsa `panic!` kapena zina zotere.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // CHITETEZO: mgwirizano wachitetezo wa `alloc` uyenera kusungidwa ndi woyimbirayo.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // CHITETEZO: momwe gawo lidakwanitsira, dera kuchokera ku `ptr`
            // za kukula `size` zimatsimikiziridwa kuti ndizovomerezeka pazolemba.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Chepetsani kapena kukulitsa chikumbukiro kwa omwe adapatsidwa `new_size`.
    /// Chipikacho chimafotokozedwa ndi cholembera `ptr` ndi `layout`.
    ///
    /// Ngati izi zibwezeretsanso chosakira, ndiye kuti umwini wa memory block womwe `ptr` idasamutsidwa ugawike.
    /// Kukumbukiraku mwina sikadasunthidwe, ndipo kuyenera kuwonedwa ngati kosagwiritsidwa ntchito (pokhapokha ngati idasinthidwa kubwerera kwa woyimbirayo kudzera pakubweza kwa njirayi).
    /// Chikumbutso chatsopano chimaperekedwa ndi `layout`, koma ndi `size` yasinthidwa kukhala `new_size`.
    /// Kapangidwe katsopano kameneka kagwiritsidwe ntchito posamutsa chikumbukiro chatsopano ndi `dealloc`.
    /// Mtundu wa `0..min(layout.size(), new_size) `wa memory memory yatsopano umatsimikiziridwa kukhala ndi zikhalidwe zofanana ndi chipika choyambirira.
    ///
    /// Ngati njirayi ibwerera, ndiye kuti umwini wa memory block sunasamutsidwe kwa woperekayo, ndipo zomwe zili mu memory block sizinasinthidwe.
    ///
    /// # Safety
    ///
    /// Ntchitoyi ndiyotetezeka chifukwa machitidwe osadziwika angachitike ngati woyimbirayo sakuwonetsetsa zotsatirazi:
    ///
    /// * `ptr` iyenera kuperekedwa kudzera pano,
    ///
    /// * `layout` iyenera kukhala yofanana yomwe idagwiritsidwa ntchito kupatula kukumbukira,
    ///
    /// * `new_size` ayenera kukhala wamkulu kuposa ziro.
    ///
    /// * `new_size`, ikazunguliridwa ndi ma `layout.align()` oyandikira kwambiri, sayenera kusefukira (mwachitsanzo, mtengo wozungulira uyenera kukhala wochepera `usize::MAX`).
    ///
    /// (Zowonjezera zowonjezera zitha kupereka malire pamakhalidwe, mwachitsanzo, kutsimikizira adilesi ya sentinel kapena cholozera chopanda tanthauzo poyankha pempho la kukula kwa zero.)
    ///
    /// # Errors
    ///
    /// Kubwezeretsa zopanda pake ngati mawonekedwe atsopanowo sakukumana ndi zovuta ndi mayikidwe a wopatsa, kapena ngati kusamutsanso kwina sikulephera.
    ///
    /// Zoyeserera zimalimbikitsidwa kuti zibwererenso kuzotopa pokumbukira m'malo mochita mantha kapena kuchotsa mimba, koma izi sizofunikira kwenikweni.
    /// (Makamaka: ndizovomerezeka * kukhazikitsa trait pamwamba pa library yomwe imagawilidwa kale yomwe imatha kukumbukira kukumbukira.)
    ///
    /// Makasitomala omwe akufuna kuchotsa kuwerengera poyankha cholakwika chakusamutsidwa amalimbikitsidwa kuyimbira ntchito [`handle_alloc_error`], m'malo moyitanitsa `panic!` kapena zina zotere.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // CHITETEZO: woyimbayo ayenera kuwonetsetsa kuti `new_size` sikusefukira.
        // `layout.align()` imachokera ku `Layout` ndipo motero imatsimikiziridwa kuti ndiyovomerezeka.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // CHITETEZO: woyimbayo ayenera kuwonetsetsa kuti `new_layout` iposa zero.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // CHITETEZO: malo omwe adapatsidwa kale sangadutse gawo lomwe angopatsidwa kumene.
            // Mgwirizano wachitetezo wa `dealloc` uyenera kusungidwa ndi woyimbirayo.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}