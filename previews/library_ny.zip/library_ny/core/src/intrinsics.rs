//! Kupanga zamkati.
//!
//! Malingaliro ofananawo ali mu `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Kukhazikitsidwa kofananira kwa const kuli mu `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Zamkati mwa Const
//!
//! Note: zosintha zilizonse pakukonzekera kwazinthu ziyenera kukambirana ndi gulu lazilankhulo.
//! Izi zikuphatikiza kusintha pakukhazikika kwa bwaloli.
//!
//! Kuti tithe kugwiritsa ntchito nthawi yolemba, munthu ayenera kukopera kukhazikitsa kuchokera ku <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> mpaka `compiler/rustc_mir/src/interpret/intrinsics.rs` ndikuwonjezera `#[rustc_const_unstable(feature = "foo", issue = "01234")]` ku intrinsic.
//!
//!
//! Ngati chinthu choyambirira chikuyenera kugwiritsidwa ntchito kuchokera ku `const fn` yokhala ndi malingaliro a `rustc_const_stable`, malingaliro amkati ayenera kukhala `rustc_const_stable`, nawonso.
//! Kusintha koteroko sikuyenera kuchitika popanda kufunsa kwa T-lang, chifukwa kumaphika china chake mchilankhulo chomwe sichingafanane ndi nambala ya ogwiritsa popanda kuthandizira kophatikiza.
//!
//! # Volatiles
//!
//! Zoyipa zosasinthika zimapereka zochitika zomwe zimapangidwira kukumbukira kwa I/O, zomwe zimatsimikizika kuti sizingakonzedwenso ndi wopanga zinthu zina zamkati mosakhazikika.Onani zolemba za LLVM pa [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Zomwe ma atomiki amapangitsa kuti ma atomiki azigwiritsa ntchito pamawu amakanema, ndizotheka kukumbukira zambiri.Amamvera semantics yofanana ndi C++ 11.Onani zolemba za LLVM pa [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Kubwezeretsa mwachangu pakukonzekera kukumbukira:
//!
//! * Pezani, cholepheretsa kupeza loko.Kuwerenga ndi kulemba komwe kumachitika pambuyo pake.
//! * Kutulutsidwa, chotchinga potulutsa loko.Kuwerenga ndi kulemba koyambirira kumachitika chisanachitike chotchinga.
//! * Ntchito mofananira, motsatizana zimatsimikizika kuti zidzachitika mwadongosolo.Iyi ndiyo njira yoyenera yogwirira ntchito ndi mitundu ya atomiki ndipo ndi yofanana ndi `volatile` ya Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Zogulitsa izi zimagwiritsidwa ntchito pokonza maulalo a intra-doc
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // CHITETEZO: onani `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, ma intrinsics awa amatenga zolemba zosaphika chifukwa amasintha kukumbukira kosasunthika, komwe sikofunikira kwa `&` kapena `&mut`.
    //

    /// Imasunga mtengo ngati mtengo wapano ndi wofanana ndi mtengo wa `old`.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `compare_exchange` podutsa [`Ordering::SeqCst`] monga magawo a `success` ndi `failure`.
    ///
    /// Mwachitsanzo, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Imasunga mtengo ngati mtengo wapano ndi wofanana ndi mtengo wa `old`.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `compare_exchange` podutsa [`Ordering::Acquire`] monga magawo a `success` ndi `failure`.
    ///
    /// Mwachitsanzo, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Imasunga mtengo ngati mtengo wapano ndi wofanana ndi mtengo wa `old`.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `compare_exchange` podutsa [`Ordering::Release`] ngati `success` ndi [`Ordering::Relaxed`] ngati magawo a `failure`.
    /// Mwachitsanzo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Imasunga mtengo ngati mtengo wapano ndi wofanana ndi mtengo wa `old`.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `compare_exchange` podutsa [`Ordering::AcqRel`] ngati `success` ndi [`Ordering::Acquire`] ngati magawo a `failure`.
    /// Mwachitsanzo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Imasunga mtengo ngati mtengo wapano ndi wofanana ndi mtengo wa `old`.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `compare_exchange` podutsa [`Ordering::Relaxed`] monga magawo a `success` ndi `failure`.
    ///
    /// Mwachitsanzo, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Imasunga mtengo ngati mtengo wapano ndi wofanana ndi mtengo wa `old`.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `compare_exchange` podutsa [`Ordering::SeqCst`] ngati `success` ndi [`Ordering::Relaxed`] ngati magawo a `failure`.
    /// Mwachitsanzo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Imasunga mtengo ngati mtengo wapano ndi wofanana ndi mtengo wa `old`.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `compare_exchange` podutsa [`Ordering::SeqCst`] ngati `success` ndi [`Ordering::Acquire`] ngati magawo a `failure`.
    /// Mwachitsanzo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Imasunga mtengo ngati mtengo wapano ndi wofanana ndi mtengo wa `old`.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `compare_exchange` podutsa [`Ordering::Acquire`] ngati `success` ndi [`Ordering::Relaxed`] ngati magawo a `failure`.
    /// Mwachitsanzo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Imasunga mtengo ngati mtengo wapano ndi wofanana ndi mtengo wa `old`.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `compare_exchange` podutsa [`Ordering::AcqRel`] ngati `success` ndi [`Ordering::Relaxed`] ngati magawo a `failure`.
    /// Mwachitsanzo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Imasunga mtengo ngati mtengo wapano ndi wofanana ndi mtengo wa `old`.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `compare_exchange_weak` podutsa [`Ordering::SeqCst`] monga magawo a `success` ndi `failure`.
    ///
    /// Mwachitsanzo, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Imasunga mtengo ngati mtengo wapano ndi wofanana ndi mtengo wa `old`.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `compare_exchange_weak` podutsa [`Ordering::Acquire`] monga magawo a `success` ndi `failure`.
    ///
    /// Mwachitsanzo, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Imasunga mtengo ngati mtengo wapano ndi wofanana ndi mtengo wa `old`.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `compare_exchange_weak` podutsa [`Ordering::Release`] ngati `success` ndi [`Ordering::Relaxed`] ngati magawo a `failure`.
    /// Mwachitsanzo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Imasunga mtengo ngati mtengo wapano ndi wofanana ndi mtengo wa `old`.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `compare_exchange_weak` podutsa [`Ordering::AcqRel`] ngati `success` ndi [`Ordering::Acquire`] ngati magawo a `failure`.
    /// Mwachitsanzo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Imasunga mtengo ngati mtengo wapano ndi wofanana ndi mtengo wa `old`.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `compare_exchange_weak` podutsa [`Ordering::Relaxed`] monga magawo a `success` ndi `failure`.
    ///
    /// Mwachitsanzo, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Imasunga mtengo ngati mtengo wapano ndi wofanana ndi mtengo wa `old`.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `compare_exchange_weak` podutsa [`Ordering::SeqCst`] ngati `success` ndi [`Ordering::Relaxed`] ngati magawo a `failure`.
    /// Mwachitsanzo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Imasunga mtengo ngati mtengo wapano ndi wofanana ndi mtengo wa `old`.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `compare_exchange_weak` podutsa [`Ordering::SeqCst`] ngati `success` ndi [`Ordering::Acquire`] ngati magawo a `failure`.
    /// Mwachitsanzo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Imasunga mtengo ngati mtengo wapano ndi wofanana ndi mtengo wa `old`.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `compare_exchange_weak` podutsa [`Ordering::Acquire`] ngati `success` ndi [`Ordering::Relaxed`] ngati magawo a `failure`.
    /// Mwachitsanzo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Imasunga mtengo ngati mtengo wapano ndi wofanana ndi mtengo wa `old`.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `compare_exchange_weak` podutsa [`Ordering::AcqRel`] ngati `success` ndi [`Ordering::Relaxed`] ngati magawo a `failure`.
    /// Mwachitsanzo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Imadzaza mtengo wapano wa cholozera.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `load` podutsa [`Ordering::SeqCst`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Imadzaza mtengo wapano wa cholozera.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `load` podutsa [`Ordering::Acquire`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Imadzaza mtengo wapano wa cholozera.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `load` podutsa [`Ordering::Relaxed`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Imasunga mtengo pamalo omwe mwakumbukiridwako.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `store` podutsa [`Ordering::SeqCst`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Imasunga mtengo pamalo omwe mwakumbukiridwako.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `store` podutsa [`Ordering::Release`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Imasunga mtengo pamalo omwe mwakumbukiridwako.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `store` podutsa [`Ordering::Relaxed`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Imasunga mtengo pamalo omwe adakumbukiridwa, ndikubwezera mtengo wakale.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `swap` podutsa [`Ordering::SeqCst`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Imasunga mtengo pamalo omwe adakumbukiridwa, ndikubwezera mtengo wakale.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `swap` podutsa [`Ordering::Acquire`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Imasunga mtengo pamalo omwe adakumbukiridwa, ndikubwezera mtengo wakale.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `swap` podutsa [`Ordering::Release`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Imasunga mtengo pamalo omwe adakumbukiridwa, ndikubwezera mtengo wakale.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `swap` podutsa [`Ordering::AcqRel`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Imasunga mtengo pamalo omwe adakumbukiridwa, ndikubwezera mtengo wakale.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `swap` podutsa [`Ordering::Relaxed`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ikuwonjezera pamtengo wapano, ndikubwezeretsanso mtengo wam'mbuyomu.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `fetch_add` podutsa [`Ordering::SeqCst`] ngati `order`.
    /// Mwachitsanzo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ikuwonjezera pamtengo wapano, ndikubwezeretsanso mtengo wam'mbuyomu.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `fetch_add` podutsa [`Ordering::Acquire`] ngati `order`.
    /// Mwachitsanzo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ikuwonjezera pamtengo wapano, ndikubwezeretsanso mtengo wam'mbuyomu.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `fetch_add` podutsa [`Ordering::Release`] ngati `order`.
    /// Mwachitsanzo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ikuwonjezera pamtengo wapano, ndikubwezeretsanso mtengo wam'mbuyomu.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `fetch_add` podutsa [`Ordering::AcqRel`] ngati `order`.
    /// Mwachitsanzo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ikuwonjezera pamtengo wapano, ndikubwezeretsanso mtengo wam'mbuyomu.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `fetch_add` podutsa [`Ordering::Relaxed`] ngati `order`.
    /// Mwachitsanzo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Chotsani pamtengo wapano, ndikubwezeretsani mtengo wapitawo.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `fetch_sub` podutsa [`Ordering::SeqCst`] ngati `order`.
    /// Mwachitsanzo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Chotsani pamtengo wapano, ndikubwezeretsani mtengo wapitawo.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `fetch_sub` podutsa [`Ordering::Acquire`] ngati `order`.
    /// Mwachitsanzo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Chotsani pamtengo wapano, ndikubwezeretsani mtengo wapitawo.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `fetch_sub` podutsa [`Ordering::Release`] ngati `order`.
    /// Mwachitsanzo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Chotsani pamtengo wapano, ndikubwezeretsani mtengo wapitawo.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `fetch_sub` podutsa [`Ordering::AcqRel`] ngati `order`.
    /// Mwachitsanzo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Chotsani pamtengo wapano, ndikubwezeretsani mtengo wapitawo.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `fetch_sub` podutsa [`Ordering::Relaxed`] ngati `order`.
    /// Mwachitsanzo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Pang'ono pang'ono komanso ndi mtengo wapano, kubwezera mtengo wam'mbuyomu.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `fetch_and` podutsa [`Ordering::SeqCst`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pang'ono pang'ono komanso ndi mtengo wapano, kubwezera mtengo wam'mbuyomu.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `fetch_and` podutsa [`Ordering::Acquire`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pang'ono pang'ono komanso ndi mtengo wapano, kubwezera mtengo wam'mbuyomu.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `fetch_and` podutsa [`Ordering::Release`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pang'ono pang'ono komanso ndi mtengo wapano, kubwezera mtengo wam'mbuyomu.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `fetch_and` podutsa [`Ordering::AcqRel`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pang'ono pang'ono komanso ndi mtengo wapano, kubwezera mtengo wam'mbuyomu.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `fetch_and` podutsa [`Ordering::Relaxed`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Pang'ono pang'ono nand ndi mtengo wapano, ndikubwezeretsanso mtengo wapitawo.
    ///
    /// Mtundu wokhazikika wa zamkatiwu umapezeka pamtundu wa [`AtomicBool`] kudzera pa njira ya `fetch_nand` podutsa [`Ordering::SeqCst`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pang'ono pang'ono nand ndi mtengo wapano, ndikubwezeretsanso mtengo wapitawo.
    ///
    /// Mtundu wokhazikika wa zamkatiwu umapezeka pamtundu wa [`AtomicBool`] kudzera pa njira ya `fetch_nand` podutsa [`Ordering::Acquire`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pang'ono pang'ono nand ndi mtengo wapano, ndikubwezeretsanso mtengo wapitawo.
    ///
    /// Mtundu wokhazikika wa zamkatiwu umapezeka pamtundu wa [`AtomicBool`] kudzera pa njira ya `fetch_nand` podutsa [`Ordering::Release`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pang'ono pang'ono nand ndi mtengo wapano, ndikubwezeretsanso mtengo wapitawo.
    ///
    /// Mtundu wokhazikika wa zamkatiwu umapezeka pamtundu wa [`AtomicBool`] kudzera pa njira ya `fetch_nand` podutsa [`Ordering::AcqRel`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pang'ono pang'ono nand ndi mtengo wapano, ndikubwezeretsanso mtengo wapitawo.
    ///
    /// Mtundu wokhazikika wa zamkatiwu umapezeka pamtundu wa [`AtomicBool`] kudzera pa njira ya `fetch_nand` podutsa [`Ordering::Relaxed`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Pang'ono pang'ono kapena ndi mtengo wapano, kubwezera mtengo wam'mbuyomu.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `fetch_or` podutsa [`Ordering::SeqCst`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pang'ono pang'ono kapena ndi mtengo wapano, kubwezera mtengo wam'mbuyomu.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `fetch_or` podutsa [`Ordering::Acquire`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pang'ono pang'ono kapena ndi mtengo wapano, kubwezera mtengo wam'mbuyomu.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `fetch_or` podutsa [`Ordering::Release`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pang'ono pang'ono kapena ndi mtengo wapano, kubwezera mtengo wam'mbuyomu.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `fetch_or` podutsa [`Ordering::AcqRel`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pang'ono pang'ono kapena ndi mtengo wapano, kubwezera mtengo wam'mbuyomu.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `fetch_or` podutsa [`Ordering::Relaxed`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Pang'ono pang'ono xor ndi mtengo wapano, ndikubwezeretsanso mtengo wapitawo.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `fetch_xor` podutsa [`Ordering::SeqCst`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pang'ono pang'ono xor ndi mtengo wapano, ndikubwezeretsanso mtengo wapitawo.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `fetch_xor` podutsa [`Ordering::Acquire`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pang'ono pang'ono xor ndi mtengo wapano, ndikubwezeretsanso mtengo wapitawo.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `fetch_xor` podutsa [`Ordering::Release`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pang'ono pang'ono xor ndi mtengo wapano, ndikubwezeretsanso mtengo wapitawo.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `fetch_xor` podutsa [`Ordering::AcqRel`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pang'ono pang'ono xor ndi mtengo wapano, ndikubwezeretsanso mtengo wapitawo.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu ya [`atomic`] kudzera pa njira ya `fetch_xor` podutsa [`Ordering::Relaxed`] ngati `order`.
    /// Mwachitsanzo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Zolemba malire ndi phindu panopa ntchito poyerekeza anasaina.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu yosayina ya [`atomic`] kudzera pa njira ya `fetch_max` podutsa [`Ordering::SeqCst`] ngati `order`.
    /// Mwachitsanzo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zolemba malire ndi phindu panopa ntchito poyerekeza anasaina.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu yosayina ya [`atomic`] kudzera pa njira ya `fetch_max` podutsa [`Ordering::Acquire`] ngati `order`.
    /// Mwachitsanzo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zolemba malire ndi phindu panopa ntchito poyerekeza anasaina.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu yosayina ya [`atomic`] kudzera pa njira ya `fetch_max` podutsa [`Ordering::Release`] ngati `order`.
    /// Mwachitsanzo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zolemba malire ndi phindu panopa ntchito poyerekeza anasaina.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu yosayina ya [`atomic`] kudzera pa njira ya `fetch_max` podutsa [`Ordering::AcqRel`] ngati `order`.
    /// Mwachitsanzo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zolemba malire ndi phindu panopa.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu yosayina ya [`atomic`] kudzera pa njira ya `fetch_max` podutsa [`Ordering::Relaxed`] ngati `order`.
    /// Mwachitsanzo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Kuchepera ndi mtengo wapano pogwiritsa ntchito kufananiza kosainidwa.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu yosayina ya [`atomic`] kudzera pa njira ya `fetch_min` podutsa [`Ordering::SeqCst`] ngati `order`.
    /// Mwachitsanzo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kuchepera ndi mtengo wapano pogwiritsa ntchito kufananiza kosainidwa.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu yosayina ya [`atomic`] kudzera pa njira ya `fetch_min` podutsa [`Ordering::Acquire`] ngati `order`.
    /// Mwachitsanzo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kuchepera ndi mtengo wapano pogwiritsa ntchito kufananiza kosainidwa.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu yosayina ya [`atomic`] kudzera pa njira ya `fetch_min` podutsa [`Ordering::Release`] ngati `order`.
    /// Mwachitsanzo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kuchepera ndi mtengo wapano pogwiritsa ntchito kufananiza kosainidwa.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu yosayina ya [`atomic`] kudzera pa njira ya `fetch_min` podutsa [`Ordering::AcqRel`] ngati `order`.
    /// Mwachitsanzo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kuchepera ndi mtengo wapano pogwiritsa ntchito kufananiza kosainidwa.
    ///
    /// Mtundu wolimba wa izi zimapezeka pamitundu yosayina ya [`atomic`] kudzera pa njira ya `fetch_min` podutsa [`Ordering::Relaxed`] ngati `order`.
    /// Mwachitsanzo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Zochepa ndi mtengo wapano pogwiritsa ntchito kufananizidwa kosainidwa.
    ///
    /// Mtundu wokhazikika wa zamkatiwu umapezeka pamitundu yosasintha ya [`atomic`] yosagwiritsidwa ntchito kudzera pa njira ya `fetch_min` podutsa [`Ordering::SeqCst`] ngati `order`.
    /// Mwachitsanzo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zochepa ndi mtengo wapano pogwiritsa ntchito kufananizidwa kosainidwa.
    ///
    /// Mtundu wokhazikika wa zamkatiwu umapezeka pamitundu yosasintha ya [`atomic`] yosagwiritsidwa ntchito kudzera pa njira ya `fetch_min` podutsa [`Ordering::Acquire`] ngati `order`.
    /// Mwachitsanzo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zochepa ndi mtengo wapano pogwiritsa ntchito kufananizidwa kosainidwa.
    ///
    /// Mtundu wokhazikika wa zamkatiwu umapezeka pamitundu yosasintha ya [`atomic`] yosagwiritsidwa ntchito kudzera pa njira ya `fetch_min` podutsa [`Ordering::Release`] ngati `order`.
    /// Mwachitsanzo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zochepa ndi mtengo wapano pogwiritsa ntchito kufananizidwa kosainidwa.
    ///
    /// Mtundu wokhazikika wa zamkatiwu umapezeka pamitundu yosasintha ya [`atomic`] yosagwiritsidwa ntchito kudzera pa njira ya `fetch_min` podutsa [`Ordering::AcqRel`] ngati `order`.
    /// Mwachitsanzo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zochepa ndi mtengo wapano pogwiritsa ntchito kufananizidwa kosainidwa.
    ///
    /// Mtundu wokhazikika wa zamkatiwu umapezeka pamitundu yosalemba ya [`atomic`] yosayina kudzera pa njira ya `fetch_min` podutsa [`Ordering::Relaxed`] ngati `order`.
    /// Mwachitsanzo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Zolemba malire ndi mtengo wamakono pogwiritsa ntchito kufananizidwa kosainidwa.
    ///
    /// Mtundu wokhazikika wa zamkatiwu umapezeka pamitundu yosasintha ya [`atomic`] yosagwiritsidwa ntchito kudzera pa njira ya `fetch_max` podutsa [`Ordering::SeqCst`] ngati `order`.
    /// Mwachitsanzo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zolemba malire ndi mtengo wamakono pogwiritsa ntchito kufananizidwa kosainidwa.
    ///
    /// Mtundu wokhazikika wa zamkatiwu umapezeka pamitundu yosasintha ya [`atomic`] yosagwiritsidwa ntchito kudzera pa njira ya `fetch_max` podutsa [`Ordering::Acquire`] ngati `order`.
    /// Mwachitsanzo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zolemba malire ndi mtengo wamakono pogwiritsa ntchito kufananizidwa kosainidwa.
    ///
    /// Mtundu wokhazikika wa zamkatiwu umapezeka pamitundu yosasintha ya [`atomic`] yosagwiritsidwa ntchito kudzera pa njira ya `fetch_max` podutsa [`Ordering::Release`] ngati `order`.
    /// Mwachitsanzo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zolemba malire ndi mtengo wamakono pogwiritsa ntchito kufananizidwa kosainidwa.
    ///
    /// Mtundu wokhazikika wa zamkatiwu umapezeka pamitundu yosasintha ya [`atomic`] yosagwiritsidwa ntchito kudzera pa njira ya `fetch_max` podutsa [`Ordering::AcqRel`] ngati `order`.
    /// Mwachitsanzo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zolemba malire ndi mtengo wamakono pogwiritsa ntchito kufananizidwa kosainidwa.
    ///
    /// Mtundu wokhazikika wa zamkatiwu umapezeka pamitundu yosalemba ya [`atomic`] yosayina kudzera pa njira ya `fetch_max` podutsa [`Ordering::Relaxed`] ngati `order`.
    /// Mwachitsanzo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Zamkatimu za `prefetch` ndikulingalira kwa wopanga code kuti ayike malangizo asanafike ngati atathandizidwa;Kupanda kutero, sikuti ndi op.
    /// Zotsogola sizikhala ndi vuto lililonse pamachitidwe a pulogalamuyi koma zimatha kusintha magwiridwe antchito.
    ///
    /// Mtsutso wa `locality` uyenera kukhala wochuluka nthawi zonse ndipo ndikutanthauzira kwakanthawi kochepa kuchokera ku (0), palibe malo, mpaka (3), komwe kumakhala kosungidwa kwambiri.
    ///
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Zamkatimu za `prefetch` ndikulingalira kwa wopanga code kuti ayike malangizo asanafike ngati atathandizidwa;Kupanda kutero, sikuti ndi op.
    /// Zotsogola sizikhala ndi vuto lililonse pamachitidwe a pulogalamuyi koma zimatha kusintha magwiridwe antchito.
    ///
    /// Mtsutso wa `locality` uyenera kukhala wochuluka nthawi zonse ndipo ndikutanthauzira kwakanthawi kochepa kuchokera ku (0), palibe malo, mpaka (3), komwe kumakhala kosungidwa kwambiri.
    ///
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Zamkatimu za `prefetch` ndikulingalira kwa wopanga code kuti ayike malangizo asanafike ngati atathandizidwa;Kupanda kutero, sikuti ndi op.
    /// Zotsogola sizikhala ndi vuto lililonse pamachitidwe a pulogalamuyi koma zimatha kusintha magwiridwe antchito.
    ///
    /// Mtsutso wa `locality` uyenera kukhala wochuluka nthawi zonse ndipo ndikutanthauzira kwakanthawi kochepa kuchokera ku (0), palibe malo, mpaka (3), komwe kumakhala kosungidwa kwambiri.
    ///
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Zamkatimu za `prefetch` ndikulingalira kwa wopanga code kuti ayike malangizo asanafike ngati atathandizidwa;Kupanda kutero, sikuti ndi op.
    /// Zotsogola sizikhala ndi vuto lililonse pamachitidwe a pulogalamuyi koma zimatha kusintha magwiridwe antchito.
    ///
    /// Mtsutso wa `locality` uyenera kukhala wochuluka nthawi zonse ndipo ndikutanthauzira kwakanthawi kochepa kuchokera ku (0), palibe malo, mpaka (3), komwe kumakhala kosungidwa kwambiri.
    ///
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Mpanda wa atomiki.
    ///
    /// Mtundu wabwinowu umapezeka mu [`atomic::fence`] podutsa [`Ordering::SeqCst`] ngati `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Mpanda wa atomiki.
    ///
    /// Mtundu wabwinowu umapezeka mu [`atomic::fence`] podutsa [`Ordering::Acquire`] ngati `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Mpanda wa atomiki.
    ///
    /// Mtundu wabwinowu umapezeka mu [`atomic::fence`] podutsa [`Ordering::Release`] ngati `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Mpanda wa atomiki.
    ///
    /// Mtundu wabwinowu umapezeka mu [`atomic::fence`] podutsa [`Ordering::AcqRel`] ngati `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Cholepheretsa kukumbukira chokhazikitsa.
    ///
    /// Kulowa pokumbukira sikungakonzedwenso chopingasa ndi wolemba, koma palibe malangizo omwe angatulutsidwe.
    /// Izi ndizoyenera kugwiranso ntchito pa ulusi womwewo womwe ungakonzedwenso, monga polumikizana ndi omwe amagwiritsa ntchito ma siginolo.
    ///
    /// Mtundu wabwinowu umapezeka mu [`atomic::compiler_fence`] podutsa [`Ordering::SeqCst`] ngati `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Cholepheretsa kukumbukira chokhazikitsa.
    ///
    /// Kulowa pokumbukira sikungakonzedwenso chopingasa ndi wolemba, koma palibe malangizo omwe angatulutsidwe.
    /// Izi ndizoyenera kugwiranso ntchito pa ulusi womwewo womwe ungakonzedwenso, monga polumikizana ndi omwe amagwiritsa ntchito ma siginolo.
    ///
    /// Mtundu wabwinowu umapezeka mu [`atomic::compiler_fence`] podutsa [`Ordering::Acquire`] ngati `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Cholepheretsa kukumbukira chokhazikitsa.
    ///
    /// Kulowa pokumbukira sikungakonzedwenso chopingasa ndi wolemba, koma palibe malangizo omwe angatulutsidwe.
    /// Izi ndizoyenera kugwiranso ntchito pa ulusi womwewo womwe ungakonzedwenso, monga polumikizana ndi omwe amagwiritsa ntchito ma siginolo.
    ///
    /// Mtundu wabwinowu umapezeka mu [`atomic::compiler_fence`] podutsa [`Ordering::Release`] ngati `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Cholepheretsa kukumbukira chokhazikitsa.
    ///
    /// Kulowa pokumbukira sikungakonzedwenso chopingasa ndi wolemba, koma palibe malangizo omwe angatulutsidwe.
    /// Izi ndizoyenera kugwiranso ntchito pa ulusi womwewo womwe ungakonzedwenso, monga polumikizana ndi omwe amagwiritsa ntchito ma siginolo.
    ///
    /// Mtundu wabwinowu umapezeka mu [`atomic::compiler_fence`] podutsa [`Ordering::AcqRel`] ngati `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Zamatsenga zamkati zomwe zimapeza tanthauzo lake kuchokera kuzinthu zogwirizana ndi ntchitoyi.
    ///
    /// Mwachitsanzo, kusefukira kwa data kumagwiritsa ntchito izi kupangira zonena kuti `rustc_peek(potentially_uninitialized)` iwunikenso kawiri kuti kutsata kwa data kudanenadi kuti sikunayambike panthawiyo pakuwongolera.
    ///
    ///
    /// Izi siziyenera kugwiritsidwa ntchito kunja kwa wopanga.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Amachotsa ntchitoyo.
    ///
    /// Njira yosavuta kugwiritsa ntchito komanso yosasunthika ya ntchitoyi ndi [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Ikuwuza optimizer kuti mfundoyi siyingatheke, ndikupangitsa kukhathamiritsa kwina.
    ///
    /// NB, izi ndizosiyana kwambiri ndi `unreachable!()` macro: Mosiyana ndi zazikulu, zomwe panics ikachitika, ndi *mawonekedwe osadziwika* kuti mufikire nambala yodziwika ndi ntchitoyi.
    ///
    ///
    /// Mtundu wokhazikika wa izi zamkati ndi [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Ikuwuza opatsa chiyembekezo kuti vuto limakhala loona nthawi zonse.
    /// Ngati vutoli ndi labodza, khalidweli silimadziwika.
    ///
    /// Palibe kachidindo kamene kamapangidwa chifukwa cha izi, koma optimizer iyesetsa kuyisunga (ndi momwe imakhalira) pakati pamaulendo, omwe angasokoneze kukhathamiritsa kwa nambala yoyandikira ndikuchepetsa magwiridwe antchito.
    /// Sichiyenera kugwiritsidwa ntchito ngati chosinthira chitha kupezeka ndi chowongolera chokha, kapena ngati sichingathandize kukhathamiritsa kulikonse.
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Malangizo kwa wopanga kuti z0branch0Z zitha kukhala zowona.
    /// Kubwezeretsa mtengo woperekedwa kwa iwo.
    ///
    /// Kugwiritsa ntchito kulikonse kupatula ndi mawu a `if` mwina sikungakhudze.
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Malangizo kwa wopanga kuti z0branch0Z zitha kukhala zabodza.
    /// Kubwezeretsa mtengo woperekedwa kwa iwo.
    ///
    /// Kugwiritsa ntchito kulikonse kupatula ndi mawu a `if` mwina sikungakhudze.
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Amapereka msampha wophulika, kuti awunikidwe ndi wolakwika.
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    pub fn breakpoint();

    /// Kukula kwa mtundu wa mabayiti.
    ///
    /// Makamaka, izi ndizomwe zimapangidwira pakati pamitundu yotsatizana yamtundu womwewo, kuphatikiza kulumikizana.
    ///
    ///
    /// Mtundu wokhazikika wa izi zamkati ndi [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Makulidwe ochepera amtundu.
    ///
    /// Mtundu wokhazikika wa izi zamkati ndi [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Mayikidwe okondedwa amtundu wina.
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Kukula kwa mtengo wofotokozedwayo m'ma byte.
    ///
    /// Mtundu wokhazikika wa izi zamkati ndi [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Kuyanjana kofunikira kwa mtengo wotchulidwa.
    ///
    /// Mtundu wokhazikika wa izi zamkati ndi [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Amapeza chingwe chokhazikika chomwe chili ndi dzina lamtundu.
    ///
    /// Mtundu wokhazikika wa izi zamkati ndi [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Amapeza chizindikiritso chomwe chili chapadziko lonse lapansi ndi mtundu womwe watchulidwa.
    /// Ntchitoyi ibweza mtengo womwewo pamtundu uliwonse mosasamala kanthu za crate yomwe imayitanitsidwa.
    ///
    ///
    /// Mtundu wokhazikika wa izi zamkati ndi [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Woyang'anira ntchito zosatetezeka zomwe sizingachitike ngati `T` mulibe anthu:
    /// Izi zitha kukhala panic, kapena osachita chilichonse.
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Woyang'anira ntchito zosatetezeka zomwe sizingachitike ngati `T` siyikuloleza kuyambitsa zero: Izi zitha kukhala panic, kapena osachita chilichonse.
    ///
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    pub fn assert_zero_valid<T>();

    /// Woyang'anira ntchito zosatetezeka zomwe sizingachitike ngati `T` ili ndi mitundu yolakwika: Izi zitha kukhala panic, kapena osachita chilichonse.
    ///
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    pub fn assert_uninit_valid<T>();

    /// Amapeza kutanthauzira kwa static `Location` yosonyeza komwe adayitanidwira.
    ///
    /// Ganizirani kugwiritsa ntchito [`core::panic::Location::caller`](crate::panic::Location::caller) m'malo mwake.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Imachotsa mtengo kunja popanda kutulutsa guluu.
    ///
    /// Izi zimangokhala za [`mem::forget_unsized`];`forget` yachibadwa imagwiritsa ntchito `ManuallyDrop` m'malo mwake.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Timatanthauziranso mtengo wamtundu wina ngati mtundu wina.
    ///
    /// Mitundu yonseyi iyenera kukhala yofanana.
    /// Ngakhale choyambirira, kapena zotsatira zake, sizingakhale [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` ndiyofanana ndi kusuntha pang'ono kwamtundu wina kupita ku wina.Imasindikiza ma bits kuchokera pamtengo woyambira kupita ku mtengo wopita, kenako amaiwala choyambirira.
    /// Ndizofanana ndi C's `memcpy` pansi pa hood, monga `transmute_copy`.
    ///
    /// Chifukwa `transmute` ndi ntchito yamtengo wapatali, mayikidwe azikhalidwe zawo * sizovuta.
    /// Monga ntchito ina iliyonse, wopanga makinawo amatsimikizira kuti `T` ndi `U` ndizogwirizana bwino.
    /// Komabe, potumiza mfundo zomwe zimaloza kwinakwake * (monga zolozera, maumboni, mabokosi…), woyimbirayo ayenera kuwonetsetsa kuti mfundozo zikugwirizana bwino.
    ///
    /// `transmute` ndi **osatetezeka** osatetezeka.Pali njira zambiri zopangira [undefined behavior][ub] ndi ntchitoyi.`transmute` iyenera kukhala njira yomaliza yomaliza.
    ///
    /// [nomicon](../../nomicon/transmutes.html) ili ndi zolemba zina.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Pali zinthu zingapo zomwe `transmute` imathandizira.
    ///
    /// Kutembenuza cholozera kukhala cholembera chantchito.Izi sizitheka kunyamula makina omwe ma pointers ogwira ntchito ndi zolozera za deta zimakhala zazikulu mosiyanasiyana.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Kutalikitsa moyo wonse, kapena kufupikitsa moyo wosasintha.Izi ndizotsogola, zosatetezeka kwambiri Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Osataya mtima: ntchito zambiri za `transmute` zitha kupezeka kudzera munjira zina.
    /// Pansipa pali ntchito zodziwika bwino za `transmute` zomwe zitha kusinthidwa ndikumanga kotetezeka.
    ///
    /// Kutembenuza yaiwisi bytes(`&[u8]`) kukhala `u32`, `f64`, ndi zina.:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // gwiritsani ntchito `u32::from_ne_bytes` m'malo mwake
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // kapena gwiritsani ntchito `u32::from_le_bytes` kapena `u32::from_be_bytes` kuti mufotokozere za endianness
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Kutembenuza cholozera kukhala `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Gwiritsani ntchito kuponya `as` m'malo mwake
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Kutembenuza `*mut T` kukhala `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Gwiritsani ntchito kubweza m'malo mwake
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Kutembenuza `&mut T` kukhala `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Tsopano, phatikizani `as` ndikubwezeretsanso, zindikirani kuti kumangirizidwa kwa `as` `as` sikusintha
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Kutembenuza `&str` kukhala `&[u8]`:
    ///
    /// ```
    /// // iyi si njira yabwino yochitira izi.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Mutha kugwiritsa ntchito `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Kapena, ingogwiritsani ntchito chingwe chachitsulo, ngati muli ndi mphamvu yolamulira chingwecho
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Kutembenuza `Vec<&T>` kukhala `Vec<Option<&T>>`.
    ///
    /// Kuti mutumize mtundu wamkati wazomwe zili muchidebe, muyenera kuwonetsetsa kuti musaphwanye chilichonse chazomwe zimayandikira.
    /// Kwa `Vec`, izi zikutanthauza kuti kukula *ndi mayikidwe* amtundu wamkati amayenera kufanana.
    /// Zida zina zimatha kudalira kukula kwa mtundu, mayikidwe, kapena `TypeId`, momwe zimasinthira sizingachitike popanda kuphwanya zonyamula.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // sakanizani vector pamene tiwagwiritsanso ntchito mtsogolo
    /// let v_clone = v_orig.clone();
    ///
    /// // Kugwiritsa ntchito transmute: izi zimadalira mtundu wosadziwika wa `Vec`, lomwe ndi lingaliro loipa ndipo limatha kuyambitsa Undefined Behaeve.
    /////
    /// // Komabe, palibe kopi.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Iyi ndiye njira yabwino, yotetezeka.
    /// // Imakopera vector yonse, komabe, mwanjira yatsopano.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Imeneyi ndi njira yokhayokha, yotetezeka ya "transmuting" ndi `Vec`, osadalira momwe masanjidwewo akukhalira.
    /// // M'malo moyimbira `transmute`, timapanga pointer, koma potembenuza mtundu wamkati wa (`&i32`) kukhala watsopano (`Option<&i32>`), izi zili ndi mapanga ofanana.
    /////
    /// // Kupatula zomwe zatchulidwa pamwambapa, onaninso zolemba za [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Sinthani izi pamene vec_into_raw_parts ikhazikika.
    ///     // Onetsetsani kuti choyambirira vector sichikutsitsidwa.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Kukhazikitsa `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Pali njira zingapo zochitira izi, ndipo pali zovuta zingapo ndi njira yotsatira ya (transmute).
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // choyamba: kutumiza sikutetezeka;zonse zomwe amafufuza ndikuti T ndi
    ///         // U ndi ofanana kukula.
    ///         // Chachiwiri, pomwe pano, muli ndi maumboni awiri osinthika omwe akulozera kukumbukira komweko.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Izi zimachotsa mavuto amtundu woteteza;`&mut *`* ingokupatsirani `&mut T` kuchokera pa `&mut T` kapena `*mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // komabe, muli ndi maumboni awiri osinthika omwe akuloza kukumbukira komweko.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Umu ndi momwe laibulale wamba imachitira.
    /// // Imeneyi ndi njira yabwino kwambiri, ngati mukufuna kuchita izi
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Izi tsopano zili ndi maumboni atatu osinthika omwe akuloza kukumbukira komweko.`slice`, rvalue ret.0, ndi rvalue ret.1.
    ///         // `slice` sagwiritsidwanso ntchito pambuyo pa `let ptr = ...`, chifukwa chake munthu akhoza kuyitenga ngati "dead", chifukwa chake, muli ndi magawo awiri enieni osinthika.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Ngakhale izi zimapangitsa kuti chibwibwi chikhale chokhazikika, tili ndi nambala yachikhalidwe mu const fn
    // macheke omwe amalepheretsa kugwiritsa ntchito `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Kubwezeretsa `true` ngati mtundu weniweni woperekedwa monga `T` umafuna guluu woponya;imabweza `false` ngati mtundu weniweni woperekedwa wa `T` umagwiritsa ntchito `Copy`.
    ///
    ///
    /// Ngati mtundu weniweniwo sufuna guluu kapena kugwiritsa ntchito `Copy`, ndiye kuti phindu lobwezera ntchitoyi silikudziwika.
    ///
    /// Mtundu wokhazikika wa izi zamkati ndi [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Kuwerengetsa zolowa kuchokera pacholozera.
    ///
    /// Izi zimayendetsedwa ngati chinthu chofunikira kuti tipewe kutembenukira ndikuchokera ku nambala, popeza kutembenuka kumatha kutaya zidziwitso.
    ///
    /// # Safety
    ///
    /// Cholozera choyambira ndi chotsatira chimayenera kukhala m'malire kapena chodutsa chimodzi kumapeto kwa chinthu chomwe mwapatsidwa.
    /// Ngati cholozera chilichonse sichichokera m'malire kapena kusefukira kwamasamba kumachitika ndiye kuti kugwiritsanso ntchito phindu lomwe labwezedwa kumabweretsa chizolowezi chosadziwika.
    ///
    ///
    /// Mtundu wokhazikika wa izi zamkati ndi [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Kuwerengetsa zolowa kuchokera pacholozera, chomwe chingathe kukulunga.
    ///
    /// Izi zimayendetsedwa ngati chinthu chofunikira kuti musatembenukire kochokera ku manambala, popeza kutembenuka kumalepheretsa kukhathamiritsa kwina.
    ///
    /// # Safety
    ///
    /// Mosiyana ndi zamkati mwa `offset`, chidwi ichi sichimalepheretsa cholozera kuti chizilozera kapena chodutsa chimodzi kumapeto kwa chinthu chomwe chapatsidwa, ndipo chimakulungidwa ndi masamu owonjezera awiri.
    /// Chotsatira chake sichikhala chovomerezeka kuti chingagwiritsidwe ntchito kufikira kwenikweni kukumbukira.
    ///
    /// Mtundu wokhazikika wa izi zamkati ndi [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Zofanana ndi zofunikira za `llvm.memcpy.p0i8.0i8.*`, kukula kwa `count`*`size_of::<T>()` ndi mayendedwe a
    ///
    /// `min_align_of::<T>()`
    ///
    /// Parameter yosakhazikika yayikidwa ku `true`, chifukwa chake siyimakwaniritsidwa pokhapokha kukula kuli kofanana ndi zero.
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Zofanana ndi zofunikira za `llvm.memmove.p0i8.0i8.*`, zokula `count* size_of::<T>()` ndi mayikidwe a
    ///
    /// `min_align_of::<T>()`
    ///
    /// Parameter yosakhazikika yayikidwa ku `true`, chifukwa chake siyimakwaniritsidwa pokhapokha kukula kuli kofanana ndi zero.
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Zofanana ndi zofunikira za `llvm.memset.p0i8.*`, zokula `count* size_of::<T>()` ndi mayikidwe a `min_align_of::<T>()`.
    ///
    ///
    /// Parameter yosakhazikika yayikidwa ku `true`, chifukwa chake siyimakwaniritsidwa pokhapokha kukula kuli kofanana ndi zero.
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Imagwira katundu wosakhazikika kuchokera pa pointer ya `src`.
    ///
    /// Mtundu wokhazikika wa izi zamkati ndi [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Amakhala ndi sitolo yosakhazikika ku pointer ya `dst`.
    ///
    /// Mtundu wokhazikika wa izi zamkati ndi [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Imagwira katundu wovuta kuchokera pa cholembera cha `src` Cholozera sichiyenera kuti chizigwirizana.
    ///
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Amakhala ndi sitolo yosakhazikika ku pointer ya `dst`.
    /// Cholozera sikofunikira kuti zigwirizane.
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Kubwezeretsa mizu yaying'ono ya `f32`
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Kubwezeretsa mizu yaying'ono ya `f64`
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Imakweza `f32` kukhala mphamvu yayikulu.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Imakweza `f64` kukhala mphamvu yayikulu.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Kubwezeretsa sine ya `f32`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Kubwezeretsa sine ya `f64`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Kubwezeretsa cosine ya `f32`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Kubwezeretsa cosine ya `f64`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Imakweza `f32` kupita ku `f32` mphamvu.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Imakweza `f64` kupita ku `f64` mphamvu.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Kubwezeretsa kuwonetseredwa kwa `f32`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Kubwezeretsa kuwonetseredwa kwa `f64`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Kubwezeretsa 2 kukwezedwa ku mphamvu ya `f32`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Kubwezeretsa 2 kukwezedwa ku mphamvu ya `f64`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Kubwezeretsa logarithm yachilengedwe ya `f32`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Kubwezeretsa logarithm yachilengedwe ya `f64`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Imabwezeretsa logarithm yoyambira ya `f32`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Imabwezeretsa logarithm yoyambira ya `f64`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Kubwezeretsa maziko 2 logarithm ya `f32`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Kubwezeretsa maziko 2 logarithm ya `f64`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Kubwezeretsa `a * b + c` pamiyeso ya `f32`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Kubwezeretsa `a * b + c` pamiyeso ya `f64`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Kubwezeretsa mtheradi wa `f32`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Kubwezeretsa mtheradi wa `f64`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Kubwezeretsa osachepera awiri `f32`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Kubwezeretsa osachepera awiri `f64`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Imabwezeretsa kuchuluka kwama `f32`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Imabwezeretsa kuchuluka kwama `f64`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Zimakopera chikwangwani kuchokera ku `y` mpaka `x` pamiyeso ya `f32`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Zimakopera chikwangwani kuchokera ku `y` mpaka `x` pamiyeso ya `f64`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Imabweza nambala yocheperako yochepera kapena yofanana ndi `f32`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Imabweza nambala yocheperako yochepera kapena yofanana ndi `f64`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Imabweza nambala yocheperako kuposa kapena yofanana ndi `f32`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Imabweza nambala yocheperako kuposa kapena yofanana ndi `f64`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Kubwezeretsa gawo lonse la `f32`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Kubwezeretsa gawo lonse la `f64`.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Kubwezeretsa nambala yonse yapafupi ku `f32`.
    /// Titha kutulutsa chiwonetsero chosasunthika ngati mkangano siwambiri.
    pub fn rintf32(x: f32) -> f32;
    /// Kubwezeretsa nambala yonse yapafupi ku `f64`.
    /// Titha kutulutsa chiwonetsero chosasunthika ngati mkangano siwambiri.
    pub fn rintf64(x: f64) -> f64;

    /// Kubwezeretsa nambala yonse yapafupi ku `f32`.
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Kubwezeretsa nambala yonse yapafupi ku `f64`.
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Kubwezeretsa nambala yonse yapafupi ku `f32`.Imazungulira milingo ya theka kuchoka pa zero.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Kubwezeretsa nambala yonse yapafupi ku `f64`.Imazungulira milanduyi kuchokera ku zero.
    ///
    /// Mtundu wokhazikika wa zamkati ndi
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Zowonjezera zomwe zimalola kukhathamiritsa kutengera malamulo a algebraic.
    /// Mungaganize kuti zolowetsa ndizochepa.
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Kuchotsa pamadzi komwe kumalola kukhathamiritsa kutengera malamulo a algebraic.
    /// Mungaganize kuti zolowetsa ndizochepa.
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Kuchulukitsa koyenda komwe kumalola kukhathamiritsa kutengera malamulo a algebraic.
    /// Mungaganize kuti zolowetsa ndizochepa.
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Magulu oyandama omwe amalola kukhathamiritsa kutengera malamulo a algebraic.
    /// Mungaganize kuti zolowetsa ndizochepa.
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Zotsalira zotsalira zomwe zimalola kukhathamiritsa kutengera malamulo a algebraic.
    /// Mungaganize kuti zolowetsa ndizochepa.
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Sinthani ndi XLUMU ya LLVM, yomwe imatha kubwezera undef yazikhalidwe zosafunikira
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Kukhazikika monga [`f32::to_int_unchecked`] ndi [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Imabwezeretsa kuchuluka kwa mabatani omwe amakhala mumtundu waukulu wa `T`
    ///
    /// Mitundu yokhazikika iyi yamkati imapezeka pamitengo yoyamba kudzera pa njira ya `count_ones`.
    /// Mwachitsanzo,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Imabwezeretsa nambala yazotsogola zosakhazikika (zeroes) mumtundu wa `T`.
    ///
    /// Mitundu yokhazikika iyi yamkati imapezeka pamitengo yoyamba kudzera pa njira ya `leading_zeros`.
    /// Mwachitsanzo,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x` yokhala ndi mtengo `0` ibwezeretsa pang'ono `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Monga `ctlz`, koma osatetezeka pamene amabweza `undef` mukapatsidwa `x` yokhala ndi mtengo `0`.
    ///
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Kubwezeretsa kuchuluka kwa ma trailing osasintha ma bits (zeroes) mumtundu wa `T`.
    ///
    /// Mitundu yokhazikika iyi yamkati imapezeka pamitengo yoyamba kudzera pa njira ya `trailing_zeros`.
    /// Mwachitsanzo,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `x` yokhala ndi mtengo `0` ibwezeretsa pang'ono `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Monga `cttz`, koma osatetezeka pamene amabweza `undef` mukapatsidwa `x` yokhala ndi mtengo `0`.
    ///
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Imasinthira mabatani pamtundu waukulu wa `T`.
    ///
    /// Mitundu yokhazikika iyi yamkati imapezeka pamitengo yoyamba kudzera pa njira ya `swap_bytes`.
    /// Mwachitsanzo,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Imasinthira zidutswa zamtundu wa `T`.
    ///
    /// Mitundu yokhazikika iyi yamkati imapezeka pamitengo yoyamba kudzera pa njira ya `reverse_bits`.
    /// Mwachitsanzo,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Amachita kuwonjezera kosakanikirana.
    ///
    /// Mitundu yokhazikika iyi yamkati imapezeka pamitengo yoyamba kudzera pa njira ya `overflowing_add`.
    /// Mwachitsanzo,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Amachita kuchotsera kwathunthu
    ///
    /// Mitundu yokhazikika iyi yamkati imapezeka pamitengo yoyamba kudzera pa njira ya `overflowing_sub`.
    /// Mwachitsanzo,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Amachita kubwereza kuchulukitsa
    ///
    /// Mitundu yokhazikika iyi yamkati imapezeka pamitengo yoyamba kudzera pa njira ya `overflowing_mul`.
    /// Mwachitsanzo,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Amagawika ndendende, zomwe zimapangitsa kuti munthu akhale wopanda mbiri pomwe `x % y != 0` kapena `y == 0` kapena `x == T::MIN && y == -1`
    ///
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Amachita magawano osayang'aniridwa, zomwe zimabweretsa machitidwe osadziwika pomwe `y == 0` kapena `x == T::MIN && y == -1`
    ///
    ///
    /// Zotchinga zotetezedwa zamkatizi zimapezeka pamitengo yoyamba kudzera pa njira ya `checked_div`.
    /// Mwachitsanzo,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Kubwezeretsa magawidwe otsala omwe sanasunthe, zomwe zimapangitsa kuti munthu akhale ndi khalidwe losadziwika pomwe `y == 0` kapena `x == T::MIN && y == -1`
    ///
    ///
    /// Zotchinga zotetezedwa zamkatizi zimapezeka pamitengo yoyamba kudzera pa njira ya `checked_rem`.
    /// Mwachitsanzo,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Amachita kusintha kosasunthika kumanzere, komwe kumabweretsa machitidwe osadziwika pomwe `y < 0` kapena `y >= N`, pomwe N ndi mulifupi wa T muzitsulo.
    ///
    ///
    /// Zotchinga zotetezedwa zamkatizi zimapezeka pamitengo yoyamba kudzera pa njira ya `checked_shl`.
    /// Mwachitsanzo,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Amachita kusintha kosasunthika komwe kumayang'aniridwa, komwe kumabweretsa machitidwe osadziwika pomwe `y < 0` kapena `y >= N`, pomwe N ndi mulifupi wa T m'mizere.
    ///
    ///
    /// Zotchinga zotetezedwa zamkatizi zimapezeka pamitengo yoyamba kudzera pa njira ya `checked_shr`.
    /// Mwachitsanzo,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Imabwezera zotsatira za kuwonjezera kosasunthika, komwe kumabweretsa machitidwe osadziwika pomwe `x + y > T::MAX` kapena `x + y < T::MIN`.
    ///
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Kubwezeretsa zotsatira za kuchotsedwa kosayang'aniridwa, komwe kumabweretsa machitidwe osadziwika pomwe `x - y > T::MAX` kapena `x - y < T::MIN`.
    ///
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Kubwezeretsa zotsatira za kuchulukitsa kosasinthidwa, kumabweretsa machitidwe osadziwika pomwe `x *y > T::MAX` kapena `x* y < T::MIN`.
    ///
    ///
    /// Wachilengedweyu alibe mnzake wokhazikika.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Amachita atembenuza kumanzere.
    ///
    /// Mitundu yokhazikika iyi yamkati imapezeka pamitengo yoyamba kudzera pa njira ya `rotate_left`.
    /// Mwachitsanzo,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Amachita atembenuza bwino.
    ///
    /// Mitundu yokhazikika iyi yamkati imapezeka pamitengo yoyamba kudzera pa njira ya `rotate_right`.
    /// Mwachitsanzo,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Returns (a + b) modemu 2 <sup>N</sup>, pomwe N ndiyokulimba kwa T m'mayendedwe.
    ///
    /// Mitundu yokhazikika iyi yamkati imapezeka pamitengo yoyamba kudzera pa njira ya `wrapping_add`.
    /// Mwachitsanzo,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Returns (a, b) modemu 2 <sup>N</sup>, pomwe N ndi mulifupi wa T mumayendedwe.
    ///
    /// Mitundu yokhazikika iyi yamkati imapezeka pamitengo yoyamba kudzera pa njira ya `wrapping_sub`.
    /// Mwachitsanzo,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Returns (a * b) modemu 2 <sup>N</sup>, pomwe N ndiyokulimba kwa T m'mayendedwe.
    ///
    /// Mitundu yokhazikika iyi yamkati imapezeka pamitengo yoyamba kudzera pa njira ya `wrapping_mul`.
    /// Mwachitsanzo,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Ma compute `a + b`, akukhuta pamalire amitundu.
    ///
    /// Mitundu yokhazikika iyi yamkati imapezeka pamitengo yoyamba kudzera pa njira ya `saturating_add`.
    /// Mwachitsanzo,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Ma compute `a - b`, akukhuta pamalire amitundu.
    ///
    /// Mitundu yokhazikika iyi yamkati imapezeka pamitengo yoyamba kudzera pa njira ya `saturating_sub`.
    /// Mwachitsanzo,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Kubwezeretsa mtengo wa tsankho wosiyanasiyana mu 'v';
    /// ngati `T` ilibe tsankho, imabweza `0`.
    ///
    /// Mtundu wokhazikika wa izi zamkati ndi [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Kubwezeretsa kuchuluka kwa mitundu ya `T` kuponyera ku `usize`;
    /// ngati `T` ilibe mitundu, imabweza `0`.Mitundu yopanda anthu idzawerengedwa.
    ///
    /// Mtundu wokhazikika pa izi wamkati ndi [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust's "try catch" yomanga yomwe imayitanitsa pointer ya ntchito `try_fn` ndi pointer ya data `data`.
    ///
    /// Mtsutso wachitatu ndi ntchito yotchedwa ngati panic imachitika.
    /// Ntchitoyi imatenga cholozera cha data ndi cholozera ku chinthu chokhacho chomwe chinagwidwa.
    ///
    /// Kuti mumve zambiri onani gwero la wophatikizira komanso kukhazikitsa kwa std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Imatulutsa sitolo ya `!nontemporal` malinga ndi LLVM (onani zolemba zawo).
    /// Mwina sichidzakhazikika.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Onani zolemba za `<*const T>::offset_from` kuti mumve zambiri.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Onani zolemba za `<*const T>::guaranteed_eq` kuti mumve zambiri.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Onani zolemba za `<*const T>::guaranteed_ne` kuti mumve zambiri.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Gawani nthawi yolemba.Sitiyenera kuyitanidwa nthawi yothamanga.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Ntchito zina zimafotokozedwa pano chifukwa mwangozi zidapezeka mgawoli pa khola.
// Onani <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` imalowanso mgululi, koma siyingakulungidwa chifukwa cha cheke kuti `T` ndi `U` ali ndi kukula kofanana.)
//

/// Imafufuza ngati `ptr` ikugwirizana moyenera ndi `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Zimakopera ma `count * size_of::<T>()` byte kuchokera ku `src` mpaka `dst`.Gwero ndi kopita siziyenera kudutsana.
///
/// Kwa madera okumbukira omwe atha kubwera, gwiritsani ntchito [`copy`] m'malo mwake.
///
/// `copy_nonoverlapping` ndiyofanana ndi C's [`memcpy`], koma ndi mfundo zotsutsana.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Khalidwe silimadziwika ngati izi zikuphwanyidwa:
///
/// * `src` iyenera kukhala [valid] yowerengera ma `count * size_of::<T>()` byte.
///
/// * `dst` iyenera kukhala [valid] yolemba za `count * size_of::<T>()` byte.
///
/// * Zonse `src` ndi `dst` ziyenera kulumikizidwa bwino.
///
/// * Dera lokumbukira kuyambira `src` ndi kukula kwa `count *
///   kukula_kwa: :<T>() `byte sayenera * kudutsana ndi dera lokumbukira kuyambira `dst` ndi kukula komweko.
///
/// Monga [`read`], `copy_nonoverlapping` imapanga mtundu wa `T`, mosasamala kanthu kuti `T` ndi [`Copy`].
/// Ngati `T` si [`Copy`], kugwiritsa ntchito *zonse zofunikira m'chigawo kuyambira pa `* src` ndipo dera loyambira `*dst` lingathe [violate memory safety][read-ownership].
///
///
/// Dziwani kuti ngakhale kukula koyenera kutengera (`count * size_of: :<T>()`) ndi `0`, zolembazo ziyenera kukhala zosakhala za NULL komanso zogwirizana bwino.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Gwiritsani ntchito mwakhama [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Imasuntha zinthu zonse za `src` kupita ku `dst`, ndikusiya `src` yopanda kanthu.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Onetsetsani kuti `dst` ili ndi mphamvu zokwanira `src` yonse.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Kuyitanitsa zolipiritsa kumakhala kotetezeka nthawi zonse chifukwa `Vec` silingapereke zoposa ma `isize::MAX` byte.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Truncate `src` osasiya zomwe zili mkatimo.
///         // Timachita izi koyamba, kuti tipewe mavuto kuti mwina china chingapitirirebe panics.
///         src.set_len(0);
///
///         // Madera awiriwa sangadutsane chifukwa maumboni osinthika sakhala alias, ndipo vectors ziwiri zosiyana sizingakhale ndi chikumbukiro chimodzimodzi.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Dziwitsani `dst` kuti tsopano ili ndi zomwe zili mu `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Chitani cheke ichi nthawi yothamanga
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Osadandaula kuti zotsatira za codegen zikhale zochepa.
        abort();
    }*/

    // CHITETEZO: mgwirizano wachitetezo wa `copy_nonoverlapping` uyenera kukhala
    // zothandizidwa ndi woyimbirayo.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Zimakopera ma `count * size_of::<T>()` byte kuchokera ku `src` mpaka `dst`.Gwero ndi komwe akupita atha kupezeka.
///
/// Ngati gwero ndi kopita sizingagwirizane, [`copy_nonoverlapping`] itha kugwiritsidwa ntchito m'malo mwake.
///
/// `copy` ndiyofanana ndi C's [`memmove`], koma ndi mfundo zotsutsana.
/// Kujambula kumachitika ngati kuti mabotolo adakopedwa kuchokera ku `src` kupita kwakanthawi kochepa kenako amakopera kuchokera pagulu mpaka `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Khalidwe silimadziwika ngati izi zikuphwanyidwa:
///
/// * `src` iyenera kukhala [valid] yowerengera ma `count * size_of::<T>()` byte.
///
/// * `dst` iyenera kukhala [valid] yolemba za `count * size_of::<T>()` byte.
///
/// * Zonse `src` ndi `dst` ziyenera kulumikizidwa bwino.
///
/// Monga [`read`], `copy` imapanga mtundu wa `T`, mosasamala kanthu kuti `T` ndi [`Copy`].
/// Ngati `T` si [`Copy`], kugwiritsa ntchito mfundo zonse m'chigawo kuyambira pa `*src` ndipo dera loyambira `* dst` lingathe [violate memory safety][read-ownership].
///
///
/// Dziwani kuti ngakhale kukula koyenera kutengera (`count * size_of: :<T>()`) ndi `0`, zolembazo ziyenera kukhala zosakhala za NULL komanso zogwirizana bwino.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Pangani bwino Rust vector kuchokera pa chosungira chosatetezeka:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` ziyenera kukhala zogwirizana bwino ndi mtundu wake komanso zopanda zero.
/// /// * `ptr` iyenera kukhala yoyenera pakuwerenga za `elts` zophatikizika zamtundu wa `T`.
/// /// * Zinthu izi siziyenera kugwiritsidwa ntchito pokhapokha mutayitanitsa ntchitoyi pokhapokha `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // CHITETEZO: Chikhazikitso chathu chimatsimikizira kuti gwero lake limayenderana
///     // ndipo `Vec::with_capacity` imatsimikizira kuti tili ndi malo oti tigwiritse ntchito.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // CHITETEZO: Tidazipanga ndimphamvu izi kale,
///     // ndipo `copy` yapitayi yayambitsa izi.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Chitani cheke ichi nthawi yothamanga
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Osadandaula kuti zotsatira za codegen zikhale zochepa.
        abort();
    }*/

    // CHITETEZO: mgwirizano wachitetezo wa `copy` uyenera kusungidwa ndi woyimbirayo.
    unsafe { copy(src, dst, count) }
}

/// Ikani kukumbukira kwa `count * size_of::<T>()` kuyambira `dst` mpaka `val`.
///
/// `write_bytes` ndi ofanana ndi C's [`memset`], koma imayika ma `count * size_of::<T>()` byte ku `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Khalidwe silimadziwika ngati izi zikuphwanyidwa:
///
/// * `dst` iyenera kukhala [valid] yolemba za `count * size_of::<T>()` byte.
///
/// * `dst` ziyenera kulumikizidwa bwino.
///
/// Kuphatikiza apo, woyimbirayo ayenera kuwonetsetsa kuti kulemba ma `count * size_of::<T>()` byte kudera lomwe mwapatsidwa kukumbukira kumabweretsa phindu la `T`.
/// Kugwiritsa ntchito gawo lokumbukira lojambulidwa ngati `T` lomwe lili ndi mtengo wosavomerezeka wa `T` ndichikhalidwe chosadziwika.
///
/// Dziwani kuti ngakhale kukula koyenera kutengera (`count * size_of: :<T>()`) ndi `0`, cholozera chikuyenera kukhala chosakhala cha NULL komanso chofananira bwino.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Kagwiritsidwe:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Kupanga phindu losavomerezeka:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Kutulutsa mtengo womwe udalipo kale polemba `Box<T>` ndi cholozera chopanda pake.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Pakadali pano, kugwiritsa ntchito kapena kusiya `v` kumabweretsa zosadziwika.
/// // drop(v); // ERROR
///
/// // Ngakhale ikudontha `v` "uses" iyo, chifukwa chake sichimadziwika.
/// // mem::forget(v); // ERROR
///
/// // M'malo mwake, `v` ndiyosavomerezeka kutengera mitundu yoyambira ya mitundu, kotero * ntchito iliyonse yomwe ikukhudza sizodziwika bwino.
/////
/// // lolani v2 =v;//ZOLAKWITSA
///
/// unsafe {
///     // Tiyeni m'malo mwake tiike mtengo woyenera
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Tsopano bokosilo liri bwino
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // CHITETEZO: mgwirizano wachitetezo wa `write_bytes` uyenera kusungidwa ndi woyimbirayo.
    unsafe { write_bytes(dst, val, count) }
}