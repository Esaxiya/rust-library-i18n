use crate::iter::{FusedIterator, TrustedLen};

/// Pangani cholembera chatsopano chomwe chimabwereza zinthu zamtundu wa `A` mosagwiritsa ntchito kutseka komwe kwaperekedwa, wobwereza, `F: FnMut() -> A`.
///
/// Ntchito ya `repeat_with()` imayimba wobwereza mobwerezabwereza.
///
/// Ma Iterator osatha monga `repeat_with()` amagwiritsidwa ntchito nthawi zambiri ndi ma adapter monga [`Iterator::take()`], kuti athe kumaliza.
///
/// Ngati mtundu wa iterator yomwe mukufuna kugwiritsa ntchito [`Clone`], ndipo zili bwino kuti muzikumbukira zomwe zimayambira, muyenera kugwiritsa ntchito [`repeat()`].
///
///
/// Iterator yopangidwa ndi `repeat_with()` si [`DoubleEndedIterator`].
/// Ngati mukufuna `repeat_with()` kuti mubweretse [`DoubleEndedIterator`], chonde tsegulani nkhani ya GitHub yofotokozera zomwe mukugwiritsa ntchito.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Kagwiritsidwe:
///
/// ```
/// use std::iter;
///
/// // tiyeni tiganizire kuti tili ndi mtundu winawake womwe si `Clone` kapena womwe sukufuna kukumbukira chifukwa ndiokwera mtengo:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // mtengo winawake kwamuyaya:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Kugwiritsa ntchito masinthidwe ndikupita kumapeto:
///
/// ```rust
/// use std::iter;
///
/// // Kuchokera ku zeroth kupita ku mphamvu yachitatu ya awiri:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... ndipo tsopano tatha
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Iterator yomwe imabwereza zinthu zamtundu wa `A` kwamuyaya pogwiritsa ntchito kutseka komwe kwaperekedwa `F: FnMut() -> A`.
///
///
/// `struct` iyi imapangidwa ndi ntchito ya [`repeat_with()`].
/// Onani zolemba zake kuti mumve zambiri.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}