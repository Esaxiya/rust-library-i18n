use crate::iter::{FusedIterator, TrustedLen};

/// Amapanga cholembera chomwe chimapereka chinthu chimodzimodzi kamodzi.
///
/// Izi zimagwiritsidwa ntchito kusinthira mtengo umodzi kukhala [`chain()`] yamitundu ina iteration.
/// Mwina muli ndi iterator yomwe imakhudza pafupifupi chilichonse, koma mumafunikira china chapadera.
/// Mwina muli ndi ntchito yomwe imagwira ntchito pama iterator, koma mumangofunika kukonza mtengo umodzi.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Kagwiritsidwe:
///
/// ```
/// use std::iter;
///
/// // imodzi ndi nambala yosungulumwa kwambiri
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // chimodzi chokha, ndizo zonse zomwe timapeza
/// assert_eq!(None, one.next());
/// ```
///
/// Kumangirira pamodzi ndi iterator ina.
/// Tiyerekeze kuti tikufuna kuyendetsa fayilo iliyonse ya chikwatu cha `.foo`, komanso fayilo yosinthira,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // tikufunika kusintha kuchokera ku iterator ya DirEntry-s kukhala iterator ya PathBufs, chifukwa chake timagwiritsa ntchito map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // tsopano, iterator yathu ya fayilo yathu yosintha
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // onjezerani ma iterator awiriwo mu Iterator imodzi yayikulu
/// let files = dirs.chain(config);
///
/// // izi zitipatsa mafayilo onse mu .foo komanso .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Iterator yomwe imatulutsa chinthu chimodzimodzi kamodzi.
///
/// `struct` iyi imapangidwa ndi ntchito ya [`once()`].Onani zolemba zake kuti mumve zambiri.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}