use crate::iter::{FusedIterator, TrustedLen};

/// Pangani cholembera chatsopano chomwe chimangobwereza chinthu chimodzi.
///
/// Ntchito ya `repeat()` imabwereza mtengo umodzi mobwerezabwereza.
///
/// Ma Iterator osatha monga `repeat()` amagwiritsidwa ntchito nthawi zambiri ndi ma adapter monga [`Iterator::take()`], kuti athe kumaliza.
///
/// Ngati mtundu wa iterator yomwe mukufuna simukugwiritsa ntchito `Clone`, kapena ngati simukufuna kukumbukira zomwe zikubwerezedwazo, mutha kugwiritsa ntchito [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Kagwiritsidwe:
///
/// ```
/// use std::iter;
///
/// // nambala inayi 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // Ee, akadali anayi
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Kupita kumapeto ndi [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // chitsanzo chomaliza chija chinali chachinayi kwambiri.Tiyeni tikhale ndi zinayi zokha.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... ndipo tsopano tatha
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Iterator yomwe imabwereza chinthu mosatha.
///
/// `struct` iyi imapangidwa ndi ntchito ya [`repeat()`].Onani zolemba zake kuti mumve zambiri.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}