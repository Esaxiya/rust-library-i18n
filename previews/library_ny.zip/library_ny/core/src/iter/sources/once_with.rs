use crate::iter::{FusedIterator, TrustedLen};

/// Amapanga cholembera chomwe chimapanga phindu kamodzi mwa kuyitanitsa kutsekedwa komwe kwaperekedwa.
///
/// Izi zimagwiritsidwa ntchito posinthira jenereta imodzi yamtengo wapatali kukhala [`chain()`] yamitundu ina iteration.
/// Mwina muli ndi iterator yomwe imakhudza pafupifupi chilichonse, koma mumafunikira china chapadera.
/// Mwina muli ndi ntchito yomwe imagwira ntchito pama iterator, koma mumangofunika kukonza mtengo umodzi.
///
/// Mosiyana ndi [`once()`], ntchitoyi ipanga phindu mwa pempho.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Kagwiritsidwe:
///
/// ```
/// use std::iter;
///
/// // imodzi ndi nambala yosungulumwa kwambiri
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // chimodzi chokha, ndizo zonse zomwe timapeza
/// assert_eq!(None, one.next());
/// ```
///
/// Kumangirira pamodzi ndi iterator ina.
/// Tiyerekeze kuti tikufuna kuyendetsa fayilo iliyonse ya chikwatu cha `.foo`, komanso fayilo yosinthira,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // tikufunika kusintha kuchokera ku iterator ya DirEntry-s kukhala iterator ya PathBufs, chifukwa chake timagwiritsa ntchito map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // tsopano, iterator yathu ya fayilo yathu yosintha
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // onjezerani ma iterator awiriwo mu Iterator imodzi yayikulu
/// let files = dirs.chain(config);
///
/// // izi zitipatsa mafayilo onse mu .foo komanso .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Iterator yomwe imatulutsa chinthu chimodzi cha mtundu wa `A` pogwiritsa ntchito kutsekedwa kwa `F: FnOnce() -> A`.
///
///
/// `struct` iyi imapangidwa ndi ntchito ya [`once_with()`].
/// Onani zolemba zake kuti mumve zambiri.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}