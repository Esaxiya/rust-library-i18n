use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable, TrustedLen};
use crate::ops::Try;

/// Iterator yokhala ndi `peek()` yomwe imabwezeretsa kutanthauzira kwina kwa chinthu chotsatira.
///
///
/// `struct` iyi imapangidwa ndi njira ya [`peekable`] pa [`Iterator`].
/// Onani zolemba zake kuti mumve zambiri.
///
/// [`peekable`]: Iterator::peekable
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Peekable<I: Iterator> {
    iter: I,
    /// Kumbukirani mtengo wowoneka, ngakhale utakhala kuti palibe.
    peeked: Option<Option<I::Item>>,
}

impl<I: Iterator> Peekable<I> {
    pub(in crate::iter) fn new(iter: I) -> Peekable<I> {
        Peekable { iter, peeked: None }
    }
}

// Peekable akuyenera kukumbukira ngati Palibe amene wawonedwa mu njira ya `.peek()`.
// Zimatsimikizira kuti `.peek();.peek();` kapena `.peek();.next();` imangopititsa patsogolo woyang'anira nthawi imodzi.
// Izi sizimangopangitsa kuti iterator isakanikirane.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> Iterator for Peekable<I> {
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        match self.peeked.take() {
            Some(v) => v,
            None => self.iter.next(),
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn count(mut self) -> usize {
        match self.peeked.take() {
            Some(None) => 0,
            Some(Some(_)) => 1 + self.iter.count(),
            None => self.iter.count(),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        match self.peeked.take() {
            Some(None) => None,
            Some(v @ Some(_)) if n == 0 => v,
            Some(Some(_)) => self.iter.nth(n - 1),
            None => self.iter.nth(n),
        }
    }

    #[inline]
    fn last(mut self) -> Option<I::Item> {
        let peek_opt = match self.peeked.take() {
            Some(None) => return None,
            Some(v) => v,
            None => None,
        };
        self.iter.last().or(peek_opt)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let peek_len = match self.peeked {
            Some(None) => return (0, Some(0)),
            Some(Some(_)) => 1,
            None => 0,
        };
        let (lo, hi) = self.iter.size_hint();
        let lo = lo.saturating_add(peek_len);
        let hi = match hi {
            Some(x) => x.checked_add(peek_len),
            None => None,
        };
        (lo, hi)
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let acc = match self.peeked.take() {
            Some(None) => return try { init },
            Some(Some(v)) => f(init, v)?,
            None => init,
        };
        self.iter.try_fold(acc, f)
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let acc = match self.peeked {
            Some(None) => return init,
            Some(Some(v)) => fold(init, v),
            None => init,
        };
        self.iter.fold(acc, fold)
    }
}

#[stable(feature = "double_ended_peek_iterator", since = "1.38.0")]
impl<I> DoubleEndedIterator for Peekable<I>
where
    I: DoubleEndedIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        match self.peeked.as_mut() {
            Some(v @ Some(_)) => self.iter.next_back().or_else(|| v.take()),
            Some(None) => None,
            None => self.iter.next_back(),
        }
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        match self.peeked.take() {
            Some(None) => try { init },
            Some(Some(v)) => match self.iter.try_rfold(init, &mut f).into_result() {
                Ok(acc) => f(acc, v),
                Err(e) => {
                    self.peeked = Some(Some(v));
                    Try::from_error(e)
                }
            },
            None => self.iter.try_rfold(init, f),
        }
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        match self.peeked {
            Some(None) => init,
            Some(Some(v)) => {
                let acc = self.iter.rfold(init, &mut fold);
                fold(acc, v)
            }
            None => self.iter.rfold(init, fold),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator> ExactSizeIterator for Peekable<I> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator> FusedIterator for Peekable<I> {}

impl<I: Iterator> Peekable<I> {
    /// Imabwezeretsa kutanthauzira kwa mtengo wa next() popanda kupititsa patsogolo iterator.
    ///
    /// Monga [`next`], ngati pali phindu, imakulungidwa mu `Some(T)`.
    /// Koma ngati kuyesa kwatha, `None` imabwezedwa.
    ///
    /// [`next`]: Iterator::next
    ///
    /// Chifukwa `peek()` imabwezeretsanso buku, ndipo ma iterator ambiri amayesa kutanthauzira, pakhoza kukhala zosokoneza pomwe mtengo wobwezera umatchulidwanso kawiri.
    /// Mutha kuwona izi pazitsanzo zili pansipa.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() tiwoneni mu future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // Iterator siyopita patsogolo ngakhale titakhala `peek` kangapo
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Iterator ikamalizidwa, momwemonso `peek()`
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&mut self) -> Option<&I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_ref()
    }

    /// Imabwezeretsa kutanthauzira kosinthika pamtengo wa next() popanda kupititsa patsogolo iterator.
    ///
    /// Monga [`next`], ngati pali phindu, imakulungidwa mu `Some(T)`.
    /// Koma ngati kuyesa kwatha, `None` imabwezedwa.
    ///
    /// Chifukwa `peek_mut()` imabwezeretsanso buku, ndipo ma iterator ambiri amayesa kutanthauzira, pakhoza kukhala zosokoneza pomwe mtengo wobwezera umatchulidwanso kawiri.
    /// Mutha kuwona izi pazitsanzo zili pansipa.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// #![feature(peekable_peek_mut)]
    /// let mut iter = [1, 2, 3].iter().peekable();
    ///
    /// // Monga `peek()`, titha kuwona mu future popanda kupititsa patsogolo iterator.
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // Pitani mu iterator ndikukhazikitsa mtengo womwe ungasinthidwe.
    /// if let Some(p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     *p = &5;
    /// }
    ///
    /// // Mtengo womwe tidayikanso ukuwonekeranso pamene woperekayo akupitiliza.
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&5, &3]);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "peekable_peek_mut", issue = "78302")]
    pub fn peek_mut(&mut self) -> Option<&mut I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_mut()
    }

    /// Gwiritsani ntchito ndikubwezeretsanso mtengo wotsatira wa iterator ngati mkhalidwe uli wowona.
    /// Ngati `func` ibweza `true` pamtengo wotsatira wa iterator iyi, idyani ndikuibweza.
    /// Apo ayi, bwererani `None`.
    /// # Examples
    /// Gwiritsani ntchito nambala ngati ili yofanana ndi 0.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Chinthu choyamba cha iterator ndi 0;ziwononga.
    /// assert_eq!(iter.next_if(|&x| x == 0), Some(0));
    /// // Katundu wotsatira yemwe wabwerera tsopano ndi 1, chifukwa chake `consume` ibwerera `false`.
    /// assert_eq!(iter.next_if(|&x| x == 0), None);
    /// // `next_if` imasunga mtengo wa chinthu chotsatira ngati sichinali chofanana ndi `expected`.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    ///
    /// Gwiritsani nambala iliyonse yochepera 10.
    ///
    /// ```
    /// let mut iter = (1..20).peekable();
    /// // Gwiritsani manambala onse osakwana 10
    /// while iter.next_if(|&x| x < 10).is_some() {}
    /// // Mtengo wotsatira wobwezedwa udzakhala 10
    /// assert_eq!(iter.next(), Some(10));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if(&mut self, func: impl FnOnce(&I::Item) -> bool) -> Option<I::Item> {
        match self.next() {
            Some(matched) if func(&matched) => Some(matched),
            other => {
                // Popeza tidatcha `self.next()`, tidadya `self.peeked`.
                assert!(self.peeked.is_none());
                self.peeked = Some(other);
                None
            }
        }
    }

    /// Gwiritsani ntchito ndikubwezera chinthu chotsatira ngati chikufanana ndi `expected`.
    /// # Example
    /// Gwiritsani ntchito nambala ngati ili yofanana ndi 0.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Chinthu choyamba cha iterator ndi 0;ziwononga.
    /// assert_eq!(iter.next_if_eq(&0), Some(0));
    /// // Katundu wotsatira yemwe wabwerera tsopano ndi 1, chifukwa chake `consume` ibwerera `false`.
    /// assert_eq!(iter.next_if_eq(&0), None);
    /// // `next_if_eq` imasunga mtengo wa chinthu chotsatira ngati sichinali chofanana ndi `expected`.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if_eq<T>(&mut self, expected: &T) -> Option<I::Item>
    where
        T: ?Sized,
        I::Item: PartialEq<T>,
    {
        self.next_if(|next| next == expected)
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I> TrustedLen for Peekable<I> where I: TrustedLen {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I: Iterator> SourceIter for Peekable<I>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // CHITETEZO: ntchito yosatetezeka yotumiza ku ntchito yosatetezeka ndi zofunikira zomwezo
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable> InPlaceIterable for Peekable<I> {}