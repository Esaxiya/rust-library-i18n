//! Kuphatikiza kwakunja kosakanikirana.
//!
//! Ngati mwapezeka kuti muli ndi mtundu winawake, ndipo mukufunika kuti muchitepo kanthu pazomwe mwapeza, mutha kuthamanga 'iterators'.
//! Ma Iterator amagwiritsidwa ntchito kwambiri mu kachidindo ka Rust, chifukwa chake muyenera kudziwa bwino.
//!
//! Tisanalongosole zambiri, tiyeni tikambirane momwe gawo ili lidapangidwira:
//!
//! # Organization
//!
//! Gawo ili limakonzedwa makamaka ndi mtundu:
//!
//! * [Traits] ndiye gawo lalikulu: traits izi zimatanthauzira mtundu wa ma iterator omwe alipo komanso zomwe mungachite nawo.Njira za traits zi ndizoyenera kuyikapo nthawi yowonjezera yowerengera.
//! * [Functions] perekani njira zothandiza zopangira ma iterator oyambira.
//! * [Structs] Nthawi zambiri mitundu yobwereranso ya njira zosiyanasiyana pa traits ya module iyi.Muyenera kuyang'ana njira yomwe imapanga `struct`, osati `struct` yomwe.
//! Kuti mumve zambiri za chifukwa chake, onani '[Kukhazikitsa Iterator](#kukhazikitsa-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Ndichoncho!Tiyeni tikumbe ma iterator.
//!
//! # Iterator
//!
//! Mtima ndi mzimu wa gawo ili ndi [`Iterator`] trait.Phata la [`Iterator`] likuwoneka motere:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Iterator ili ndi njira, [`next`], yomwe ikaitanidwa, imabweza [`Option`]`<Item>`.
//! [`next`] ibwerera [`Some(Item)`] bola pali zinthu, ndipo zonse zikatha, zibwerera `None` kuwonetsa kuti iteration yatha.
//! Omwe akuyendetsa mwina angasankhe kuyambiranso kuyambiranso, motero kuyimbira [`next`] kungayambitsenso kapena sikungayambitsenso [`Some(Item)`] nthawi ina (mwachitsanzo, onani [`TryIter`]).
//!
//!
//! Kutanthauzira kwathunthu kwa [`Iterator`] kumaphatikizanso njira zina zingapo, koma ndi njira zosakhazikika, zomangidwa pamwamba pa [`next`], chifukwa chake mumazipeza kwaulere.
//!
//! Ma Iterator amakhalanso osakanikirana, ndipo ndizofala kuwamangirira kuti achite mitundu ina yambiri yokonzanso.Onani gawo la [Adapters](#adapters) pansipa kuti mumve zambiri.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Mitundu itatu yoyeserera
//!
//! Pali njira zitatu zodziwika zomwe zingapangitse owerenga kuchokera pagulu:
//!
//! * `iter()`, yomwe imayendera pa `&T`.
//! * `iter_mut()`, yomwe imayendera pa `&mut T`.
//! * `into_iter()`, yomwe imayendera pa `T`.
//!
//! Zinthu zosiyanasiyana mulaibulale yanthawi zonse zitha kukhazikitsa chimodzi kapena zingapo mwazinthu zitatuzi, ngati kuli kofunikira.
//!
//! # Kukhazikitsa Iterator
//!
//! Kupanga iterator yanu kumakhudza njira ziwiri: kupanga `struct` kuti mugwire boma, kenako ndikukhazikitsa [`Iterator`] ya `struct` ija.
//! Ichi ndichifukwa chake pali ma `` struct '' ambiri mu gawo ili: pali imodzi ya iterator ndi aderator adapter.
//!
//! Tiyeni tipange iterator yotchedwa `Counter` yomwe imawerengera kuyambira `1` mpaka `5`:
//!
//! ```
//! // Choyamba, struct:
//!
//! /// Iterator yomwe imawerengeka kuyambira 1 mpaka 5
//! struct Counter {
//!     count: usize,
//! }
//!
//! // tikufuna kuti kuwerenga kwathu kuyambire chimodzi, kotero tiyeni tiwonjezere njira ya new() yothandizira.
//! // Izi sizofunikira kwenikweni, koma ndizosavuta.
//! // Dziwani kuti timayamba `count` pa zero, tiwona chifukwa chake kukhazikitsa `next()`'s pansipa.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Kenako, timakhazikitsa `Iterator` pa `Counter` yathu:
//!
//! impl Iterator for Counter {
//!     // tikhala tikuwerengera ndi usize
//!     type Item = usize;
//!
//!     // next() ndiyo njira yokhayo yofunikira
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Lonjezerani kuchuluka kwathu.Ichi ndichifukwa chake tidayamba ziro.
//!         self.count += 1;
//!
//!         // Onani ngati tatsiriza kuwerengera kapena ayi.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Ndipo tsopano titha kugwiritsa ntchito!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Kuyimbira [`next`] mwanjira iyi kumabwerezedwa.Rust ili ndi kapangidwe kamene kangayitane [`next`] pa iterator yanu, mpaka ikafika ku `None`.Tiyeni tipitirire izi.
//!
//! Onaninso kuti `Iterator` imapereka njira zosasinthira monga `nth` ndi `fold` yomwe imayimba `next` mkati.
//! Komabe, ndizotheka kulemba njira zokhazikitsira njira monga `nth` ndi `fold` ngati iterator ikhoza kuziwerenga bwino osayimba `next`.
//!
//! # `for` malupu ndi `IntoIterator`
//!
//! Rust's `for` loop syntax kwenikweni ndi shuga kwa oyeserera.Nachi chitsanzo choyambirira cha `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Izi zisindikiza manambala kuyambira asanu, iliyonse pamzere wawo.Koma muwona china apa: sitinayitane kalikonse pa vector yathu kuti ipange iterator.Nchiyani chimapereka?
//!
//! Pali trait mu laibulale yanthawi zonse yosinthira china kukhala iterator: [`IntoIterator`].
//! trait ili ndi njira imodzi, [`into_iter`], yomwe imasintha chinthu chokhazikitsa [`IntoIterator`] kukhala iterator.
//! Tiyeni tiwone cholumikizira cha `for` chija, ndi zomwe wopangirayo amasintha kukhala:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust imachotsa izi mu:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Choyamba, timayitanitsa `into_iter()` pamtengo.Kenako, timayenderana ndi iterator yomwe imabwerera, kuyimba [`next`] mobwerezabwereza mpaka titawona `None`.
//! Panthawiyo, ife `break` titachoka, ndipo tatha kuyeserera.
//!
//! Pali chinthu china chobisika apa: laibulale yovomerezeka ili ndi kukhazikitsa kosangalatsa kwa [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Mwanjira ina, onse [`Iterator`] amatsatira [`IntoIterator`], pongobwerera okha.Izi zikutanthauza zinthu ziwiri:
//!
//! 1. Ngati mukulemba [`Iterator`], mutha kuyigwiritsa ntchito ndi `for` loop.
//! 2. Ngati mukupanga chopereka, kugwiritsa ntchito [`IntoIterator`] chifukwa chilolera zosonkhanitsa zanu kuti mugwiritse ntchito ndi `for` loop.
//!
//! # Kuyambitsa potengera
//!
//! Popeza [`into_iter()`] imatenga `self` pamtengo, kugwiritsa ntchito kulumikizana kwa `for` kuti ichepetse pamsonkhanowu kumawononga kusonkhanitsa kumeneko.Nthawi zambiri, mungafune kuwongolera pamsonkhanowu osawadya.
//! Zosonkhanitsa zambiri zimapereka njira zomwe zimaperekera oyang'anira m'malo owerengera, omwe amatchedwa `iter()` ndi `iter_mut()` motsatana:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` akadali ndi ntchitoyi.
//! ```
//!
//! Ngati gulu losonkhanitsa `C` limapereka `iter()`, nthawi zambiri limagwiritsanso ntchito `IntoIterator` ya `&C`, ndikukhazikitsa komwe kumangoyitana `iter()`.
//! Momwemonso, chopereka `C` chomwe chimapereka `iter_mut()` chimagwiritsa ntchito `IntoIterator` ya `&mut C` potumiza `iter_mut()`.Izi zimathandizira kufupikitsa kosavuta:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // chimodzimodzi ndi `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // chimodzimodzi ndi `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Ngakhale magulu ambiri amapereka `iter()`, si onse omwe amapereka `iter_mut()`.
//! Mwachitsanzo, kusintha makiyi a [`HashSet<T>`] kapena [`HashMap<K, V>`] kumatha kuyika choperekacho kukhala chosagwirizana ngati fungulo likusintha, chifukwa chake zopereka izi zimangopereka `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Ntchito zomwe zimatenga [`Iterator`] ndikubwezera [`Iterator`] zina nthawi zambiri zimatchedwa 'iterator adapters', chifukwa ndi mawonekedwe a 'adapter
//! pattern'.
//!
//! Ma adapter amtundu wamba amaphatikizapo [`map`], [`take`], ndi [`filter`].
//! Kuti mumve zambiri, onani zolemba zawo.
//!
//! Ngati chosinthira cha iterator panics, iterator idzakhala yosadziwika (koma kukumbukira kukumbukira).
//! Dzikoli silitsimikizidwanso kuti lidzakhala chimodzimodzi pamitundu yonse ya Rust, chifukwa chake muyenera kupewa kudalira mitengo yomwe abwerera nayo iterator yomwe idachita mantha.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Ma Iterator (ndi iterator [adapters](#adapters)) ndi *aulesi*. Izi zikutanthauza kuti kungopanga iterator sikumakhala _do_ kwathunthu. Palibe chomwe chimachitika mpaka mutayitanitsa [`next`].
//! Izi nthawi zina zimakhala zosokoneza popanga iterator pazotsatira zake zokha.
//! Mwachitsanzo, njira ya [`map`] imayitanitsa kutsekedwa pachinthu chilichonse chomwe chimayenda motere:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Izi sizisindikiza zofunikira zilizonse, popeza tidangopanga iterator, m'malo moigwiritsa ntchito.Wolembetsayo atichenjeza za izi:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Njira yanzeru yolemba [`map`] pazotsatira zake ndikugwiritsa ntchito kuzungulira kwa `for` kapena kuyimba njira ya [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Njira ina yodziwika poyesa iterator ndikugwiritsa ntchito njira ya [`collect`] kuti mupange chopereka chatsopano.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Ma Iterator sayenera kukhala amalire.Mwachitsanzo, malo otseguka ndiwowerengera wopanda malire:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Sizachilendo kugwiritsa ntchito adaputala ya [`take`] iterator kutembenuza iterator yopanda malire kukhala yomaliza:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Izi zisindikiza manambala `0` kudzera `4`, iliyonse pamzere wawo.
//!
//! Kumbukirani kuti njira zamagetsi zomwe sizingathe, ngakhale zomwe zotsatira zake zitha kutsimikiziridwa masamu munthawi yochepa, sizingathe.
//! Makamaka, njira monga [`min`], zomwe nthawi zambiri zimafuna kudutsa chinthu chilichonse mu iterator, mwina sizingabwerenso moyenera kwa owerenga opanda malire.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // O ayi!Mzere wopanda malire!
//! // `ones.min()` zimayambitsa kuzungulira kopanda malire, chifukwa chake sitingafikire pano!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;