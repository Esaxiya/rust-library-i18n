// kunyalanyaza-kuyeretsa-kutalika kwa fayiloyi Fayiloyi pafupifupi ili ndi tanthauzo la `Iterator`.
// Sitingathe kuzigawa m'mafayilo angapo.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Mawonekedwe olimbana ndi owongolera.
///
/// Ichi ndiye cholembera chachikulu trait.
/// Kuti mumve zambiri zamalingaliro owongolera nthawi zambiri, chonde onani [module-level documentation].
/// Makamaka, mungafune kudziwa momwe mungakhalire [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Mtundu wazinthu zomwe zikuyendetsedweratu.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Kupititsa patsogolo iterator ndikubwezeretsanso mtengo wotsatira.
    ///
    /// Kubwezeretsa [`None`] ikamaliza iteration.
    /// Kukhazikitsa kwa aliyense payekhapayekha atha kusankha kuyambiranso, motero kuyimbiranso `next()` mwina kutha kuyambiranso kubweza [`Some(Item)`] nthawi ina.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Kuyimbira next() kumabweza mtengo wotsatira ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... ndiyeno Palibe kamodzi zitatha.
    /// assert_eq!(None, iter.next());
    ///
    /// // Mafoni ena atha kubwerera kapena osabweza `None`.Apa, nthawi zonse azichita.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Kubwezeretsa malire kumtunda wotsalira wa iterator.
    ///
    /// Makamaka, `size_hint()` imabwezeretsa Tuple pomwe choyambirira ndichotsika, ndipo chinthu chachiwiri ndichapamwamba.
    ///
    /// Hafu yachiwiri ya Tuple yomwe imabwezedwa ndi [`Option`]`<`[usize`]`> `.
    /// A [`None`] apa amatanthauza kuti mwina palibenso gulu lina lodziwika, kapena chapamwamba chimakhala chachikulu kuposa [`usize`].
    ///
    /// # Zolemba pokwaniritsa
    ///
    /// Sikukakamizidwa kuti kukhazikitsa kwa iterator kumapereka kuchuluka kwa zinthu.Choyendetsa ngolo chimatha kutulutsa zocheperako poyerekeza ndi zomangira zapansi kapena zochulukirapo kuposa zomangira zakumtunda.
    ///
    /// `size_hint()` cholinga chake makamaka kuti chizigwiritsidwa ntchito pokhathamiritsa monga kusungitsa malo pazomwe zimayambira, koma siziyenera kudaliridwa mwachitsanzo, kusiya malire osakhazikika.
    /// Kukhazikitsa kolakwika kwa `size_hint()` sikuyenera kuyambitsa kuphwanya chitetezo cha kukumbukira.
    ///
    /// Izi zati, kukhazikitsidwa kuyenera kupereka kuyerekezera kolondola, chifukwa apo ayi kukanakhala kuphwanya lamulo la trait.
    ///
    /// Kukhazikitsa kosasintha kumabwezeretsanso `(0,` [`None`]`)`zomwe zili zolondola kwa aliyense wogwiritsa ntchito.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Chitsanzo chovuta kwambiri:
    ///
    /// ```
    /// // Manambala ngakhale kuyambira ziro mpaka teni.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Titha kuchuluka kuchokera kuziro mpaka khumi.
    /// // Kudziwa kuti ndi zisanu ndendende sizingatheke popanda filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Tiyeni tiwonjezere manambala ena asanu ndi chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // tsopano malire onse awonjezeredwa ndi asanu
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Kubwezeretsa `None` pamalire apamwamba:
    ///
    /// ```
    /// // cholembera chosatha sichikhala chomenyera kumtunda komanso chimaliziro chomaliza chotheka
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Amagwiritsa ntchito iterator, kuwerengera kuchuluka kwa mayendedwe ndi kubwezera.
    ///
    /// Njira iyi idzaimbira [`next`] mobwerezabwereza mpaka [`None`] ikakumana, ndikubwezera kuchuluka komwe idawona [`Some`].
    /// Dziwani kuti [`next`] iyenera kuyitanidwapo kamodzi ngakhale iterator ilibe chilichonse.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Khalidwe Losefukira
    ///
    /// Njirayo siyiteteza kukusefukira, chifukwa chake kuwerengera kwa iterator yokhala ndi zinthu zoposa [`usize::MAX`] kumatha kubweretsa zotsatira zolakwika kapena panics.
    ///
    /// Ngati malingaliro olakwika akwaniritsidwa, panic ndiyotsimikizika.
    ///
    /// # Panics
    ///
    /// Ntchitoyi itha kukhala panic ngati iterator ili ndi zinthu zoposa [`usize::MAX`].
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Amagwiritsa ntchito iterator, ndikubwezera chinthu chomaliza.
    ///
    /// Njirayi iwunika owongolera mpaka abwerere [`None`].
    /// Pochita izi, imasunga zomwe zikupezeka pano.
    /// [`None`] ikabwezedwa, `last()` idzabwezeretsa chinthu chomaliza chomwe idachiwona.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Kupititsa patsogolo iterator ndi zinthu `n`.
    ///
    /// Njirayi idumpha mwachidwi zinthu za `n` poyimbira [`next`] mpaka `n` mpaka [`None`] itakumana.
    ///
    /// `advance_by(n)` idzabwezera [`Ok(())`][Ok] ngati iterator itapambana bwino ndi zinthu `n`, kapena [`Err(k)`][Err] ngati [`None`] ikukumana nayo, pomwe `k` ndiye chiwerengero cha zinthu zomwe iterator idachita isanathe zinthu zina (ie.
    /// kutalika kwa iterator).
    /// Dziwani kuti `k` nthawi zonse imakhala yocheperako `n`.
    ///
    /// Kuyimba `advance_by(0)` sikumatha chilichonse ndipo kumangobweza [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // `&4` yokha ndi yomwe idadumpha
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Imabwezeretsa `n`th element ya iterator.
    ///
    /// Monga ntchito zambiri zolozera, kuwerengera kumayambira pa zero, kotero `nth(0)` imabweza mtengo woyamba, `nth(1)` wachiwiri, ndi zina zambiri.
    ///
    /// Dziwani kuti zinthu zonse zam'mbuyomu, komanso zomwe zidabwezedwa, zidzawonongedwa kuchokera ku iterator.
    /// Izi zikutanthauza kuti zinthu zam'mbuyomu zitayidwa, komanso kuyimba `nth(0)` kangapo pa iterator yomweyo kudzabwezera zinthu zosiyanasiyana.
    ///
    ///
    /// `nth()` ibwerera [`None`] ngati `n` ili yayikulu kuposa kapena yofanana ndi kutalika kwa iterator.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Kuyimbira `nth()` kangapo sikubwezeretsanso iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Kubwezera `None` ngati pali zinthu zosakwana `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Amapanga iterator kuyambira nthawi yomweyo, koma kutsata ndi kuchuluka komwe kumapatsidwa nthawi iliyonse.
    ///
    /// Chidziwitso 1: Choyamba cha iterator chimabwezedwa nthawi zonse, mosaganizira sitepe yomwe yapatsidwa.
    ///
    /// Chidziwitso 2: Nthawi yomwe zinthu zosasamalidwa zimakokedwa sinakhazikike.
    /// `StepBy` imakhala ngati momwe `next(), nth(step-1), nth(step-1),…` idayendera, komanso ndiyofunitsitsa kuti izichita mofanana
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Njira iti yomwe imagwiritsidwa ntchito ingasinthe kwa ena owongolera pazifukwa zogwirira ntchito.
    /// Njira yachiwiri ipititsa patsogolo iterator koyambirira ndipo itha kudya zinthu zina.
    ///
    /// `advance_n_and_return_first` ndizofanana ndi:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Njirayo izichita panic ngati gawo lomwe lapatsidwa ndi `0`.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Imatenga ma iterator awiri ndikupanga iterator yatsopano potsatira zonsezi.
    ///
    /// `chain()` ibwezeretsanso iterator yatsopano yomwe imayamba kuyambiranso pamitengo yoyambira kenako ndikuwongolera mfundo kuchokera kwa wachiwiri woyamba.
    ///
    /// Mwanjira ina, imagwirizanitsa ma iterator awiri pamodzi, mu unyolo.🔗
    ///
    /// [`once`] imagwiritsidwa ntchito nthawi zambiri kusinthira mtengo umodzi kukhala tcheni cha mitundu ina yazoyeserera.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Popeza kukangana kwa `chain()` kumagwiritsa ntchito [`IntoIterator`], titha kudutsa chilichonse chomwe chingasandulike kukhala [`Iterator`], osati [`Iterator`] yokha.
    /// Mwachitsanzo, magawo (`&[T]`) amatsatira [`IntoIterator`], ndipo atha kupititsidwa ku `chain()` mwachindunji:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ngati mukugwira ntchito ndi Windows API, mungafune kusintha [`OsStr`] kukhala `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Zips up' iterators awiri kukhala iterator imodzi ya awiriawiri.
    ///
    /// `zip()` imabweretsanso iterator yatsopano yomwe ingayendetse bwino ma iterator ena awiri, ndikubwezeretsanso Tuple pomwe choyambira choyamba chimachokera kwa woyambitsa woyamba, ndipo chinthu chachiwiri chimachokera ku iterator yachiwiri.
    ///
    ///
    /// Mwanjira ina, imagwiranso ntchito ma iterator awiri, kukhala amodzi.
    ///
    /// Ngati iterator ibwezera [`None`], [`next`] kuchokera pa iterator yozungulirayo ibwerera [`None`].
    /// Ngati iterator yoyamba ibwezera [`None`], `zip` ifupikitsa ndipo `next` sidzayitanidwa pa iterator yachiwiri.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Popeza kukangana kwa `zip()` kumagwiritsa ntchito [`IntoIterator`], titha kudutsa chilichonse chomwe chingasandulike kukhala [`Iterator`], osati [`Iterator`] yokha.
    /// Mwachitsanzo, magawo (`&[T]`) amatsatira [`IntoIterator`], ndipo atha kupititsidwa ku `zip()` mwachindunji:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` imagwiritsidwa ntchito kupopera chizindikirocho chopanda malire mpaka kumapeto.
    /// Izi zimagwira ntchito chifukwa owongolera amathera [`None`], akumaliza zipper.Kutumiza ndi `(0..)` kumawoneka ngati [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Pangani cholembera chatsopano chomwe chimayika kopi ya `separator` pakati pazinthu zoyandikana ndi iterator yoyambayo.
    ///
    /// Ngati `separator` sigwiritsa ntchito [`Clone`] kapena ikufunika kuwerengedwa nthawi zonse, gwiritsani ntchito [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Choyamba kuchokera ku `a`.
    /// assert_eq!(a.next(), Some(&100)); // Wopatukana.
    /// assert_eq!(a.next(), Some(&1));   // Chotsatira chotsatira kuchokera ku `a`.
    /// assert_eq!(a.next(), Some(&100)); // Wopatukana.
    /// assert_eq!(a.next(), Some(&2));   // Gawo lomaliza kuchokera ku `a`.
    /// assert_eq!(a.next(), None);       // Iterator yatha.
    /// ```
    ///
    /// `intersperse` itha kukhala yothandiza kwambiri kujowina zinthu za iterator pogwiritsa ntchito chinthu wamba:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Pangani cholembera chatsopano chomwe chimayika chinthu chomwe chimapangidwa ndi `separator` pakati pazinthu zoyandikana ndi iterator yoyambayo.
    ///
    /// Kutsekako kudzatchedwa chimodzimodzi kamodzi chinthu chilichonse chikayikidwa pakati pazinthu ziwiri zoyandikana ndi zomwe zimayambira;
    /// makamaka, kutsekerako sikumayitanidwa ngati woyikirayo akutulutsa zinthu zosakwana ziwiri ndipo chinthu chomaliza chikaperekedwa.
    ///
    ///
    /// Ngati chinthu cha iterator chikugwiritsa ntchito [`Clone`], kungakhale kosavuta kugwiritsa ntchito [`intersperse`].
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Choyamba kuchokera ku `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Wopatukana.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Chotsatira chotsatira kuchokera ku `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Wopatukana.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Gawo lomaliza kuchokera ku `v`.
    /// assert_eq!(it.next(), None);               // Iterator yatha.
    /// ```
    ///
    /// `intersperse_with` itha kugwiritsidwa ntchito m'malo omwe olekanitsa amafunika kuwerengedwa:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Kutseka kumabwereka mozungulira momwe amapangira chinthu.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Kutsekedwa ndikupanga cholembera chomwe chimatcha kutsekedwa pachinthu chilichonse.
    ///
    /// `map()` amasintha iterator imodzi kukhala ina, pogwiritsa ntchito mfundo yake:
    /// china chomwe chimagwiritsa ntchito [`FnMut`].Imapanga iterator yatsopano yomwe imayitanitsa kutsekedwa uku pachinthu chilichonse choyambitsa choyambirira.
    ///
    /// Ngati mukuganiza bwino pamitundu, mutha kuganizira za `map()` motere:
    /// Ngati muli ndi iterator yomwe imakupatsani zinthu zamtundu wina `A`, ndipo mukufuna iterator yamtundu wina `B`, mutha kugwiritsa ntchito `map()`, kudutsa kutseka komwe kumatenga `A` ndikubwezera `B`.
    ///
    ///
    /// `map()` ndiyofanana mofanana ndi [`for`] loop.Komabe, popeza `map()` ndi yaulesi, imagwiritsidwa ntchito bwino mukamagwira kale ntchito ndi ena owerenga.
    /// Ngati mukusewera pamtundu winawake, zimawerengedwa kuti ndi zanzeru kugwiritsa ntchito [`for`] kuposa `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ngati mukuchita zina zoyipa, sankhani [`for`] mpaka `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // osachita izi:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // sichingachititse, chifukwa ndi yaulesi.Rust ikuchenjezani za izi.
    ///
    /// // M'malo mwake, gwiritsani ntchito:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Imayimba kutsekedwa pachinthu chilichonse cha iterator.
    ///
    /// Izi ndizofanana ndikugwiritsa ntchito [`for`] kuzungulira pa iterator, ngakhale `break` ndi `continue` sizingatheke kutsekedwa.
    /// Ndizodziwika bwino kugwiritsa ntchito `for` loop, koma `for_each` itha kukhala yowoneka bwino mukamakonza zinthu kumapeto kwa maunyolo akutali.
    ///
    /// Nthawi zina `for_each` amathanso kuthamanga kuposa kuzungulira, chifukwa imagwiritsa ntchito kuyeserera kwamkati pama adapters ngati `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Pachitsanzo chaching'ono chotere, kuzungulira kwa `for` kumatha kukhala koyeretsa, koma `for_each` itha kukhala yosavuta kuti musunge kalembedwe kogwiritsira ntchito ma iterator aatali:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Amapanga cholembera chomwe chimagwiritsa ntchito kutseka kuti mudziwe ngati chinthucho chiyenera kutsegulidwa.
    ///
    /// Popeza chinthu kutsekedwa kuyenera kubwerera `true` kapena `false`.Iterator yobwezeretsayo ipereka kokha zinthu zomwe kutsekako kumabweradi koona.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Chifukwa kutsekedwa kwa `filter()` kumatengera kutanthauzira, ndipo owerenga ambiri amayesa kutanthauzira, izi zimabweretsa chisokonezo, pomwe kutsekedwa kukutchulidwa kawiri:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // mukufuna ma * s awiri!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ndizofala kuti m'malo mwake mugwiritse ntchito kuwonongeka pamtsutsano kuti muchotse chimodzi:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // onse&ndi *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// kapena onse:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // &s iwiri
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// mwa zigawozi.
    ///
    /// Dziwani kuti `iter.filter(f).next()` ndiyofanana ndi `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Amapanga cholembera chomwe chimasefa ndi mapu onse.
    ///
    /// Iterator yobwezeretsayo imangopereka `ma value` okhawo omwe kutsekedwa komwe kumaperekedwa kumabwezeretsa `Some(value)`.
    ///
    /// `filter_map` itha kugwiritsidwa ntchito kupanga unyolo wa [`filter`] ndi [`map`] mwachidule.
    /// Chitsanzo chili pansipa chikuwonetsa momwe `map().filter().map()` ingafupikitsire kuyimbira kamodzi ku `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Nachi chitsanzo chomwecho, koma ndi [`filter`] ndi [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Amapanga cholembera chomwe chimapereka kuwerengera kwamakono komanso mtengo wotsatira.
    ///
    /// Iterator idabweretsanso zokolola `(i, val)`, pomwe `i` ndiye index ya iteration ndipo `val` ndiye mtengo wobwezedwa ndi iterator.
    ///
    ///
    /// `enumerate()` imasunga kuchuluka kwake ngati [`usize`].
    /// Ngati mukufuna kuwerengera ndi kuchuluka kosiyanasiyana, ntchito ya [`zip`] imapereka magwiridwe antchito ofanana.
    ///
    /// # Khalidwe Losefukira
    ///
    /// Njirayo siyiteteza kukusefukira, motero kuwerengera zinthu zoposa [`usize::MAX`] mwina kumatulutsa zotsatira zolakwika kapena panics.
    /// Ngati malingaliro olakwika akwaniritsidwa, panic ndiyotsimikizika.
    ///
    /// # Panics
    ///
    /// Iterator yobwezeretsayo itha kukhala panic ngati index yomwe ikabwezeredwe ikasefukira [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Amapanga iterator yomwe ingagwiritse ntchito [`peek`] kuti ayang'ane chinthu chotsatira cha iterator osachidya.
    ///
    /// Ikuwonjezera njira ya [`peek`] kwa iterator.Onani zolemba zake kuti mumve zambiri.
    ///
    /// Dziwani kuti woyambitsa iterator akadali patsogolo pomwe [`peek`] imayitanidwa koyamba: Kuti mupeze chinthu chotsatira, [`next`] imayitanidwa pa theerator yoyambilira, chifukwa chake zovuta zina (ie
    ///
    /// china chilichonse kupatula kutenga mtengo wotsatira) wa njira ya [`next`] ichitika.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() tiwoneni mu future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // titha peek() kangapo, woyeserera sangapite patsogolo
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // iterator ikamalizidwa, momwemonso peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Imapanga cholembera chomwe [`skip`] zinthu kutengera ndi dzina.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` amatenga kutseka ngati mkangano.Imaitana kutsekedwa uku pachinthu chilichonse cha iterator, ndikunyalanyaza zinthu mpaka zibwerere `false`.
    ///
    /// `false` ikabwezedwa, ntchito ya `skip_while()`'s yatha, ndipo zinthu zina zonse zimaperekedwa.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Chifukwa kutsekedwa kwa `skip_while()` kumatengera kutanthauzira, ndipo owerenga ambiri amayesa kutanthauzira, izi zimabweretsa chisokonezo, pomwe mtundu wazokambirana umatchulidwanso:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // mukufuna ma * s awiri!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kuyimira pambuyo pa `false` yoyamba:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // pomwe izi zikadakhala zabodza, popeza tili kale ndi zabodza, skip_while() sigwiritsidwanso ntchito
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Amapanga cholembera chomwe chimapereka zinthu kutengera ndi mawu.
    ///
    /// `take_while()` amatenga kutseka ngati mkangano.Idzayitanitsa kutsekedwa uku pachinthu chilichonse cha iterator, ndikupanga zinthu ikamabwezeretsa `true`.
    ///
    /// `false` ikabwezedwa, ntchito ya `take_while()`'s yatha, ndipo zina zonse sizinyalanyazidwa.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Chifukwa kutsekedwa kwa `take_while()` kumatengera kutanthauzira, ndipo owerenga ambiri amayesa kutanthauzira, izi zimabweretsa chisokonezo, pomwe kutsekedwa kukutchulidwa kawiri:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // mukufuna ma * s awiri!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kuyimira pambuyo pa `false` yoyamba:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Tili ndi zinthu zambiri zosakwana zero, koma popeza tili kale ndi zabodza, take_while() siyikugwiritsidwanso ntchito
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Chifukwa `take_while()` iyenera kuyang'ana pamtengo kuti iwone ngati iyenera kuphatikizidwa kapena ayi, owononga owonera adzawona kuti yachotsedwa:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` kulibenso, chifukwa idadyedwa kuti awone ngati kuyimitsa kuyenera kuyima, koma sikubwezeretsedwanso mu iterator.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Amapanga cholembera chomwe chimapereka zinthu zonse kutengera chidule ndi mamapu.
    ///
    /// `map_while()` amatenga kutseka ngati mkangano.
    /// Idzayitanitsa kutsekedwa uku pachinthu chilichonse cha iterator, ndikupanga zinthu ikamabwezeretsa [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Nachi chitsanzo chomwecho, koma ndi [`take_while`] ndi [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kuyimira pambuyo pa [`None`] yoyamba:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Tili ndi zinthu zambiri zomwe zingakwaniritse u32 (4, 5), koma `map_while` idabwezeretsa `None` ya `-3` (pomwe `predicate` idabwezeretsa `None`) ndipo `collect` imayima koyamba `None`.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Chifukwa `map_while()` iyenera kuyang'ana pamtengo kuti iwone ngati iyenera kuphatikizidwa kapena ayi, owononga owonera adzawona kuti yachotsedwa:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` kulibenso, chifukwa idadyedwa kuti awone ngati kuyimitsa kuyenera kuyima, koma sikubwezeretsedwanso mu iterator.
    ///
    /// Dziwani kuti mosiyana ndi [`take_while`] iterator iyi **si** yosakanikirana.
    /// Sizikudziwikanso kuti izi zimabwezeretsanso [`None`] yoyamba itabwezedwa.
    /// Ngati mukufuna iterator yosakaniza, gwiritsani ntchito [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Kupanga cholembera chomwe chimadumpha zinthu zoyambirira za `n`.
    ///
    /// Akatha, zina zonse zimaperekedwa.
    /// M'malo mopitilira njirayi mwachindunji, m'malo mopitilira njira ya `nth`.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Amapanga iterator yomwe imapereka zinthu zake zoyambirira za `n`.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` imagwiritsidwa ntchito nthawi zambiri ndi iterator yopanda malire, kuti ikwaniritse:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ngati zosakwana `n` zilipo, `take` imadzichepetsa kukula kwa woyambitsa:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Adapter adapter yofanana ndi [`fold`] yomwe imakhala ndi mawonekedwe amkati ndikupanga iterator yatsopano.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` amatenga zifukwa ziwiri: mtengo woyambirira womwe umabzala dziko lamkati, ndi kutsekedwa ndi zifukwa ziwiri, woyamba kukhala mawu osinthika amkati mwa dziko ndipo wachiwiri chinthu cholemba.
    ///
    /// Kutsekedwa kumeneku kumatha kuyika boma lamkati kuti ligawane boma pakati pamaulendo.
    ///
    /// Pakuchulukitsa, kutseka kudzagwiritsidwa ntchito pachinthu chilichonse cha iterator ndipo mtengo wobwezera kuchokera pakutsekedwa, [`Option`], umaperekedwa ndi wolemba nkhaniyo.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // kuyesa kulikonse, tidzachulukitsa boma ndi chinthucho
    ///     *state = *state * x;
    ///
    ///     // ndiye, tidzapereka kunyalanyaza kwa boma
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Amapanga iterator yomwe imagwira ntchito ngati mapu, koma imakhala yopanda pake.
    ///
    /// Adaputala [`map`] imathandiza kwambiri, koma pokhapokha kukangana kotseka kutulutsa mfundo.
    /// Ngati ipanga iterator m'malo mwake, pali zina zowonjezera.
    /// `flat_map()` ichotsa chokhachokha chokha.
    ///
    /// Mutha kuganiza za `flat_map(f)` ngati semantic yofanana ndi [`map`] ping, kenako [`flatten`] monga `map(f).flatten()`.
    ///
    /// Njira ina yoganizira za `flat_map()`: Kutsekedwa kwa [`map`] kumabweretsanso chinthu chilichonse, ndipo kutsekedwa kwa `flat_map()`'s kumabwezeretsa iterator pachinthu chilichonse.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() imabweza iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Amapanga chojambulira chomwe chimasanja chinyumba.
    ///
    /// Izi ndizothandiza mukakhala ndi iterator ya iterators kapena iterator ya zinthu zomwe zingasandulike owerengera ndipo mukufuna kuchotsa mulingo umodzi wowonera.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Kujambula kenako ndikuwongolera:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() imabweza iterator
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Muthanso kulembanso izi molingana ndi [`flat_map()`], yomwe ndi yabwino pankhaniyi chifukwa imafotokoza momveka bwino:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() imabweza iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Kukhazikika kumangochotsa chisa chimodzi nthawi imodzi:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Apa tikuwona kuti `flatten()` siyichita bwino "deep".
    /// M'malo mwake, mulingo umodzi wokha wa kukaikira mazira umachotsedwa.Ndiye kuti, ngati mungapange `flatten()` yazithunzi zitatu, zotsatirazo zimakhala zoyang'ana mbali ziwiri osati mbali imodzi.
    /// Kuti mupeze mawonekedwe amodzi, muyenera `flatten()` kachiwiri.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Kupanga cholembera chomwe chimatha pambuyo pa [`None`] yoyamba.
    ///
    /// Iterator ikabweza [`None`], kuyimba kwa future kumatha kapena sikungaperekenso [`Some(T)`].
    /// `fuse()` imasinthira iterator, kuwonetsetsa kuti [`None`] ikaperekedwa, imabwereranso [`None`] kwamuyaya.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// // cholembera chomwe chimasinthasintha pakati pa Ena ndi Palibe
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // ngati ndi, Some(i32), kwina Palibe
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // Titha kuwona woyendetsa wathu akuyenda chammbuyo ndi mtsogolo
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // komabe, tikazisakaniza ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // nthawi zonse imabwerera `None` itatha nthawi yoyamba.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Chimachita china chilichonse ndi iterator, ndikudutsa mtengo.
    ///
    /// Mukamagwiritsa ntchito ma iterator, nthawi zambiri mumamangirira angapo pamodzi.
    /// Mukamagwira ntchito ngati code iyi, mungafune kuwona zomwe zikuchitika m'malo osiyanasiyana payipi.Kuti muchite izi, lembani foni ku `inspect()`.
    ///
    /// Ndizofala kwambiri kuti `inspect()` igwiritsidwe ntchito ngati chida chothanirana ndi vuto kusiyana ndi kupezeka mu nambala yanu yomaliza, koma mapulogalamu atha kukhala othandiza nthawi zina pomwe zolakwika zimayenera kutayidwa musanatayidwe.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // dongosolo la iterator ili lovuta.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // tiyeni tiwonjezere ma foni a inspect() kuti tifufuze zomwe zikuchitika
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Izi zisindikiza:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Zolakwitsa mitengo musanazitaye:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Izi zisindikiza:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Imabwereka iterator, m'malo moidya.
    ///
    /// Izi ndizothandiza kulola kugwiritsa ntchito ma adapter a iterator kwinaku mukusungabe umwini wa iterator yoyambayo.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // ngati tiyesa kuigwiritsanso ntchito, sigwira.
    /// // Mzere wotsatira ukupatsa "cholakwika: kugwiritsa ntchito mtengo wosunthika: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // tiyeni tiyesenso izo
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // m'malo mwake, timawonjezera mu .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // tsopano izi ndi zabwino:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Kusintha iterator kukhala chosonkhanitsa.
    ///
    /// `collect()` Ikhoza kutenga chilichonse cholephereka, ndikusandutsa chopereka choyenera.
    /// Iyi ndi imodzi mwanjira zamphamvu kwambiri mulaibulale yanthawi zonse, yogwiritsidwa ntchito m'malo osiyanasiyana.
    ///
    /// Njira yofunikira kwambiri yomwe `collect()` imagwiritsidwira ntchito ndikusintha chopereka chimodzi kukhala china.
    /// Mumatenga chopereka, muyimbire [`iter`] pa icho, musinthe gulu, kenako `collect()` kumapeto.
    ///
    /// `collect()` itha kupanganso mitundu ya mitundu yomwe siokopera kwenikweni.
    /// Mwachitsanzo, [`String`] itha kumangidwa kuchokera ku [`char`] s, ndipo iterator yazinthu [`Result<T, E>`][`Result`] itha kusonkhanitsidwa mu `Result<Collection<T>, E>`.
    ///
    /// Onani zitsanzo pansipa kuti mumve zambiri.
    ///
    /// Chifukwa `collect()` ndiyofala kwambiri, imatha kuyambitsa mavuto ndi kutengera mtundu.
    /// Mwakutero, `collect()` ndi imodzi mwanthawi zochepa pomwe mudzawona malembedwe mwachikondi otchedwa 'turbofish': `::<>`.
    /// Izi zimathandizira kulingalira kwa ma algorithm kuti mumvetsetse bwino mndandanda womwe mukuyesera kusonkhanitsa.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Dziwani kuti timafunikira `: Vec<i32>` kumanzere.Izi ndichifukwa choti titha kusonkhanitsa, mwachitsanzo, [`VecDeque<T>`] m'malo mwake:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Kugwiritsa ntchito 'turbofish' m'malo mofotokozera `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Chifukwa `collect()` imangosamala zomwe mukusonkhaniramo, mutha kugwiritsabe ntchito lingaliro laling'ono, `_`, ndi turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Kugwiritsa ntchito `collect()` kupanga [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Ngati muli ndi mndandanda wa [`Zotsatira<T, E>`][`Zotsatira`] s, mutha kugwiritsa ntchito `collect()` kuti muwone ngati ena mwa iwo alephera:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // amatipatsa cholakwika choyamba
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // amatipatsa mndandanda wa mayankho
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Amagwiritsa ntchito iterator, ndikupanga magulu awiri kuchokera pamenepo.
    ///
    /// Wotchulidwayo adapita ku `partition()` atha kubwerera `true`, kapena `false`.
    /// `partition()` imabweza peyala, zinthu zonse zomwe idabwezera `true`, ndi zinthu zonse zomwe idabwezeretsa `false`.
    ///
    ///
    /// Onaninso [`is_partitioned()`] ndi [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Imasinthanso zomwe zili mu iterator * m'malo mwake malinga ndi cholembedwera, kuti onse omwe abwezera `true` azitsogolera onse omwe abwezera `false`.
    ///
    /// Kubwezeretsa chiwerengero cha zinthu `true` zapezeka.
    ///
    /// Dongosolo laling'ono lazinthu zomwe zidagawika silisungidwa.
    ///
    /// Onaninso [`is_partitioned()`] ndi [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Kugawika pakati pakati pa evens ndi zovuta
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: kodi tiyenera kuda nkhawa zakuchulukirachulukira?Njira yokhayo yokhala ndi zoposa
        // `usize::MAX` Zosintha zosinthika zili ndi ZSTs, zomwe sizothandiza kugawa ...

        // Kutseka kwa "factory" kumeneku kulipo kuti mupewe kukhala wamba mu `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Mobwerezabwereza pezani `false` yoyamba ndikusinthana ndi `true` yomaliza.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Kufufuza ngati zinthu za iterator iyi zidagawika malinga ndi zomwe zidaperekedwa, kuti onse omwe abweretse `true` atsogola onse omwe abwezera `false`.
    ///
    ///
    /// Onaninso [`partition()`] ndi [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Zomwe zinthu zonse zimayesa `true`, kapena gawo loyambirira liyimira ku `false` ndipo timawona kuti kulibenso zinthu `true` pambuyo pake.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Njira ya iterator yomwe imagwira ntchito bola ngati ibwerera bwino, ndikupanga mtengo umodzi, womaliza.
    ///
    /// `try_fold()` amatenga zifukwa ziwiri: mtengo woyambirira, ndi kutseka ndi mfundo ziwiri: 'accumulator', ndi chinthu.
    /// Kutsekedwa kumabwereranso bwino, ndi mtengo womwe accumulator ayenera kukhala nawo pakutsata kwotsatira, kapena ikubwezeretsanso kulephera, ndi mtengo wolakwika womwe umafalitsidwanso kwa woyimba pomwepo (short-circuiting).
    ///
    ///
    /// Mtengo woyambirira ndi mtengo womwe accumulator adzakhala nawo pa foni yoyamba.Ngati kugwiritsa ntchito kutsekako kwapambana motsutsana ndi chilichonse cha iterator, `try_fold()` imabwezeretsa chosungira chomaliza kukhala chopambana.
    ///
    /// Kupinda kumathandiza nthawi iliyonse mukakhala ndi chinthu china, ndipo mukufuna kutulutsa mtengo umodzi kuchokera pamenepo.
    ///
    /// # Chidziwitso kwa Okwaniritsa
    ///
    /// Njira zingapo za (forward) zimakhala zosakwanira malinga ndi iyi, chifukwa chake yesetsani kukhazikitsa izi momveka bwino ngati ingachite bwino kuposa kukhazikitsidwa kwa `for` loop.
    ///
    /// Makamaka, yesetsani kuyimbira `try_fold()` mkati mwazomwe idapangidwiratu izi.
    /// Ngati pamafunika mafoni angapo, wothandizira wa `?` atha kukhala wosavuta kumangirira phindu lakuunjikirako, koma samalani ndi zinthu zonse zomwe zingafunike zisanabwerere.
    /// Iyi ndi njira ya `&mut self`, chifukwa chake kuyeserera kuyenera kuyambiranso mutagunda cholakwika apa.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // kuchuluka komwe kumayang'aniridwa pazinthu zonsezo
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Chiwerengerochi chimasefukira powonjezera chinthu 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Chifukwa idazungulira mwachidule, zotsalazo zidapezekabe kudzera pa iterator.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Njira ya iterator yomwe imagwira ntchito yolakwika pachinthu chilichonse mu iterator, kuyimilira pakulakwitsa koyamba ndikubwezeretsanso cholakwikacho.
    ///
    ///
    /// Izi zitha kuganizidwanso ngati zolakwika za [`for_each()`] kapena ngati mtundu wopanda X wa [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Idazungulira mwachidule, chifukwa chake zinthu zotsalazo zidakali mu iterator:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Pindani chilichonse kukhala chosakanikirana pogwiritsa ntchito opareshoni, ndikubwezera zotsatira zomaliza.
    ///
    /// `fold()` amatenga zifukwa ziwiri: mtengo woyambirira, ndi kutseka ndi mfundo ziwiri: 'accumulator', ndi chinthu.
    /// Kutseka kumabwezeretsa mtengo womwe accumulator ayenera kukhala nawo pakubwereza kotsatira.
    ///
    /// Mtengo woyambirira ndi mtengo womwe accumulator adzakhala nawo pa foni yoyamba.
    ///
    /// Pambuyo poyika kutseka uku pachinthu chilichonse cha iterator, `fold()` ibwezeretsanso chosanjikiza.
    ///
    /// Ntchitoyi nthawi zina imatchedwa 'reduce' kapena 'inject'.
    ///
    /// Kupinda kumathandiza nthawi iliyonse mukakhala ndi chinthu china, ndipo mukufuna kutulutsa mtengo umodzi kuchokera pamenepo.
    ///
    /// Note: `fold()`, ndi njira zofananira zomwe zimadutsa iterator yonse, sizingathere kwa ma iterator osatha, ngakhale pa traits zomwe zotsatira zake zimadziwika pakanthawi kochepa.
    ///
    /// Note: [`reduce()`] itha kugwiritsidwa ntchito kugwiritsa ntchito chinthu choyambirira monga mtengo woyambirira, ngati mtundu wa chosunga ndi mtundu wachinthu chimodzimodzi.
    ///
    /// # Chidziwitso kwa Okwaniritsa
    ///
    /// Njira zingapo za (forward) zimakhala zosakwanira malinga ndi iyi, chifukwa chake yesetsani kukhazikitsa izi momveka bwino ngati ingachite bwino kuposa kukhazikitsidwa kwa `for` loop.
    ///
    ///
    /// Makamaka, yesetsani kuyimbira `fold()` mkati mwazomwe idapangidwiratu izi.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // Chiwerengero cha zinthu zonse zomwe zili pagulu
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Tiyeni tidutse gawo lililonse lazoyeserera apa:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Chifukwa chake, zotsatira zathu zomaliza, `6`.
    ///
    /// Ndizofala kwa anthu omwe sanawagwiritse ntchito kwambiri iterators kuti agwiritse ntchito `for` kuzungulira ndi mndandanda wazinthu kuti apange zotsatira.Izi zimatha kusinthidwa kukhala `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // kuzungulira:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // iwo ndi ofanana
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Imachepetsa zinthuzo kukhala imodzi, poyeserera mobwerezabwereza ntchito yochepetsa.
    ///
    /// Ngati iterator ilibe kanthu, imabweza [`None`];apo ayi, zimabwezera zotsatira zakuchepetsa.
    ///
    /// Kwa owongolera omwe ali ndi chinthu chimodzi, izi ndizofanana ndi [`fold()`] ndi chinthu choyamba cha iterator ngati mtengo woyambirira, ndikupinda chilichonse chotsatira.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Pezani mtengo wapatali:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Kuyesa ngati chinthu chilichonse cha iterator chikufanana ndi cholembedwera.
    ///
    /// `all()` kutseka komwe kumabwezeretsa `true` kapena `false`.Ikugwiritsa ntchito kutsekedwa uku pachinthu chilichonse cha iterator, ndipo ngati onse abwerera `true`, momwemonso `all()`.
    /// Ngati aliyense wa iwo abweza `false`, imabweza `false`.
    ///
    /// `all()` kuchepa kwa nthawi yayitali;mwa kuyankhula kwina, idzaleka kugwira ntchito ikangopeza `false`, popeza kuti zivute zitani, zotsatira zake zidzakhalanso `false`.
    ///
    ///
    /// Iterator yopanda kanthu imabweza `true`.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Kuyimira pa `false` yoyamba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // titha kugwiritsabe ntchito `iter`, popeza pali zinthu zambiri.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Kuyesa ngati chinthu chilichonse cha iterator chikufanana ndi cholozera.
    ///
    /// `any()` kutseka komwe kumabwezeretsa `true` kapena `false`.Ikugwiritsa ntchito kutsekedwa uku pachinthu chilichonse cha iterator, ndipo ngati aliyense wa iwo abweza `true`, momwemonso `any()`.
    /// Ngati onse abwerera `false`, imabweza `false`.
    ///
    /// `any()` kuchepa kwa nthawi yayitali;mwa kuyankhula kwina, idzaleka kugwira ntchito ikangopeza `true`, popeza kuti zivute zitani, zotsatira zake zidzakhalanso `true`.
    ///
    ///
    /// Iterator yopanda kanthu imabweza `false`.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Kuyimira pa `true` yoyamba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // titha kugwiritsabe ntchito `iter`, popeza pali zinthu zambiri.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Kusaka chinthu cha iterator chomwe chimakwaniritsa choyimira.
    ///
    /// `find()` kutseka komwe kumabwezeretsa `true` kapena `false`.
    /// Ikugwiritsa ntchito kutsekedwa uku pachinthu chilichonse cha iterator, ndipo ngati aliyense wa iwo abweza `true`, ndiye kuti `find()` imabwezera [`Some(element)`].
    /// Ngati onse abwerera `false`, imabweza [`None`].
    ///
    /// `find()` kuchepa kwa nthawi yayitali;mwa kuyankhula kwina, idzaleka kugwira ntchito akangotseka kutseka `true`.
    ///
    /// Chifukwa `find()` imagwiritsa ntchito kutanthauzira, ndipo ma iterator ambiri amayesa kutanthauzira, izi zimabweretsa chisokonezo pomwe mkanganowo umatchulidwanso kawiri.
    ///
    /// Mutha kuwona izi mu zitsanzo pansipa, ndi `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Kuyimira pa `true` yoyamba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // titha kugwiritsabe ntchito `iter`, popeza pali zinthu zambiri.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Dziwani kuti `iter.find(f)` ndiyofanana ndi `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Imagwira ntchito pazinthu za iterator ndikubwezera zotsatira zoyambirira zopanda.
    ///
    ///
    /// `iter.find_map(f)` ndi ofanana ndi `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Imagwira ntchito pazinthu za iterator ndikubwezera zotsatira zoyambirira kapena zolakwika zoyambirira.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Kusaka chinthu mu iterator, ndikubwezera index yake.
    ///
    /// `position()` kutseka komwe kumabwezeretsa `true` kapena `false`.
    /// Ikugwiritsa ntchito kutsekedwa uku pachinthu chilichonse cha iterator, ndipo ngati mmodzi wa iwo abweza `true`, ndiye kuti `position()` imabwezera [`Some(index)`].
    /// Ngati onse abwerera `false`, imabweza [`None`].
    ///
    /// `position()` kuchepa kwa nthawi yayitali;mwa kuyankhula kwina, idzaleka kugwira ntchito ikangopeza `true`.
    ///
    /// # Khalidwe Losefukira
    ///
    /// Njirayo siyiteteza kukusefukira, chifukwa chake ngati pali zinthu zoposa [`usize::MAX`] zosagwirizana, zimatha kupanga zotsatira zolakwika kapena panics.
    ///
    /// Ngati malingaliro olakwika akwaniritsidwa, panic ndiyotsimikizika.
    ///
    /// # Panics
    ///
    /// Ntchitoyi itha kukhala panic ngati iterator ili ndi zinthu zoposa `usize::MAX` zosagwirizana.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Kuyimira pa `true` yoyamba:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // titha kugwiritsabe ntchito `iter`, popeza pali zinthu zambiri.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Mndandanda wobwezera umadalira boma la iterator
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Kusaka chinthu mu iterator kuchokera kumanja, ndikubwezera index yake.
    ///
    /// `rposition()` kutseka komwe kumabwezeretsa `true` kapena `false`.
    /// Ikugwiritsa ntchito kutsekedwa uku pachinthu chilichonse cha iterator, kuyambira kumapeto, ndipo ngati m'modzi wa iwo abweza `true`, `rposition()` imabwezeretsanso [`Some(index)`].
    ///
    /// Ngati onse abwerera `false`, imabweza [`None`].
    ///
    /// `rposition()` kuchepa kwa nthawi yayitali;mwa kuyankhula kwina, idzaleka kugwira ntchito ikangopeza `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Kuyimira pa `true` yoyamba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // titha kugwiritsabe ntchito `iter`, popeza pali zinthu zambiri.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Palibe chifukwa chofufuzira apa, chifukwa `ExactSizeIterator` ikutanthauza kuti kuchuluka kwa zinthu kumakwanira `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Imabwezeretsa chinthu chachikulu cha iterator.
    ///
    /// Ngati zinthu zingapo ndizofanana, chinthu chomaliza chimabwezedwa.
    /// Ngati iterator ilibe kanthu, [`None`] imabwezedwa.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Kubwezeretsa chinthu chocheperako cha iterator.
    ///
    /// Ngati zinthu zingapo ndizocheperako, choyambacho chimabwezedwa.
    /// Ngati iterator ilibe kanthu, [`None`] imabwezedwa.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Kubwezeretsa chinthu chomwe chimapereka mtengo wokwanira kuchokera pantchito yake.
    ///
    ///
    /// Ngati zinthu zingapo ndizofanana, chinthu chomaliza chimabwezedwa.
    /// Ngati iterator ilibe kanthu, [`None`] imabwezedwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Kubwezeretsa chinthu chomwe chimapereka mtengo wokwanira mokhudzana ndi kufananizidwa komwe kwachitika.
    ///
    ///
    /// Ngati zinthu zingapo ndizofanana, chinthu chomaliza chimabwezedwa.
    /// Ngati iterator ilibe kanthu, [`None`] imabwezedwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Kubwezeretsa chinthu chomwe chimapereka mtengo wocheperako kuchokera pantchito yomwe yatchulidwa.
    ///
    ///
    /// Ngati zinthu zingapo ndizocheperako, choyambacho chimabwezedwa.
    /// Ngati iterator ilibe kanthu, [`None`] imabwezedwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Kubwezeretsa chinthu chomwe chimapereka mtengo wocheperako pokhudzana ndi kufananizira komwe kwachitika.
    ///
    ///
    /// Ngati zinthu zingapo ndizocheperako, choyambacho chimabwezedwa.
    /// Ngati iterator ilibe kanthu, [`None`] imabwezedwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Imasinthira komwe woyendetsa amatsogolera.
    ///
    /// Nthawi zambiri, ma iterator amayenda kuchokera kumanzere kupita kumanja.
    /// Mutatha kugwiritsa ntchito `rev()`, iterator m'malo mwake imangoyenda kuchokera kumanja kupita kumanzere.
    ///
    /// Izi ndizotheka ngati iterator ili ndi kutha, kotero `rev()` imangogwira pa [`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Amatembenuza oyendetsa awiriawiri kuti akhale awiri azidebe.
    ///
    /// `unzip()` imagwiritsa ntchito iterator yonse iwiri, ndikupanga magulu awiri: imodzi kuchokera kumanzere kwa awiriawiri, ndipo imodzi kuchokera kuzinthu zolondola.
    ///
    ///
    /// Ntchitoyi, mwanjira ina, ndiyotsutsana ndi [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Amapanga cholembera chomwe chimasindikiza zinthu zake zonse.
    ///
    /// Izi ndizothandiza mukakhala ndi iterator yopitilira `&T`, koma mukufuna iterator pa `T`.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // zokopera ndizofanana ndi .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Amapanga cholembera chomwe [`choyerekeza`] chimafotokozera zonse.
    ///
    /// Izi ndizothandiza mukakhala ndi iterator yopitilira `&T`, koma mukufuna iterator pa `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // opangidwa ndi ofanana ndi .map(|&x| x), ya manambala
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Imabwereza iterator kosatha.
    ///
    /// M'malo moyimira pa [`None`], woyimitsirayo ayambiranso, kuyambira koyambirira.Pambuyo poyambiranso, iyambanso koyambanso.Ndipo kachiwiri.
    /// Ndipo kachiwiri.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Awerengera zinthu za iterator.
    ///
    /// Amatenga chinthu chilichonse, nachiwonjezera pamodzi, ndikubwezera zotsatira.
    ///
    /// Iterator yopanda kanthu imabwezeretsa zero mtengo wamtunduwo.
    ///
    /// # Panics
    ///
    /// Mukamaimbira `sum()` ndipo mtundu wachikale kwambiri ukubwezedwa, njirayi idzakhala panic ngati kuwerengetsa kukusefukira ndikutsimikiza kwa zolakwika kumathandizidwa.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Iterates pa iterator yonse, ndikuchulukitsa zinthu zonse
    ///
    /// Iterator yopanda kanthu imabwezeretsa mtengo umodzi wamtunduwo.
    ///
    /// # Panics
    ///
    /// Mukamaimbira `product()` ndipo mtundu wachikale kwambiri ukubwezedwa, njira idzakhala panic ngati kuwerengetsa kukusefukira ndikutsimikizira zolakwika.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) akufanizira zinthu za [`Iterator`] ndi zija za wina.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) akufanizira zinthu za [`Iterator`] ndi zija za munthu wina pokhudzana ndi kufananizira kumeneku.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) akufanizira zinthu za [`Iterator`] ndi zija za wina.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) akufanizira zinthu za [`Iterator`] ndi zija za munthu wina pokhudzana ndi kufananizira kumeneku.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Iwona ngati zinthu za [`Iterator`] ndizofanana ndi zina.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Ikuwona ngati zinthu za [`Iterator`] zi ndizofanana ndi za wina pankhani yofanana.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Ikuwona ngati zinthu za [`Iterator`] sizifanana ndi za wina.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Iwona ngati zinthu za [`Iterator`] zili [lexicographically](Ord#lexicographical-comparison) zosakwana zina.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Ikuwona ngati zinthu za [`Iterator`] zili [lexicographically](Ord#lexicographical-comparison) zochepa kapena zofanana ndi zina.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Ikuwona ngati zinthu za [`Iterator`] izi ndi [lexicographically](Ord#lexicographical-comparison) zazikulu kuposa zina.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Ikuwona ngati zinthu za [`Iterator`] izi ndi [lexicographically](Ord#lexicographical-comparison) zazikulu kapena zofanana ndi zina.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Kufufuza ngati zinthu za iterator izi zasanjidwa.
    ///
    /// Ndiye kuti, pachinthu chilichonse `a` ndizotsatira zake `b`, `a <= b` ziyenera kugwira.Ngati iterator ipereka zero kapena chinthu chimodzi, `true` imabwezedwa.
    ///
    /// Dziwani kuti ngati `Self::Item` ili `PartialOrd` yokha, koma osati `Ord`, tanthauzo pamwambapa limatanthauza kuti ntchitoyi ibwezeretsa `false` ngati zinthu ziwiri zotsatizana sizifanana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Kufufuza ngati zinthu za iterator izi zasankhidwa pogwiritsa ntchito poyerekeza.
    ///
    /// M'malo mogwiritsa ntchito `PartialOrd::partial_cmp`, ntchitoyi imagwiritsa ntchito `compare` yopatsidwa kuti izindikire dongosolo lazinthu ziwiri.
    /// Kupatula apo, ndizofanana ndi [`is_sorted`];onani zolemba zake kuti mumve zambiri.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Kufufuza ngati zinthu za iterator izi zasankhidwa pogwiritsa ntchito chinsinsi chopatsidwa.
    ///
    /// M'malo moyerekeza zinthu za iterator mwachindunji, ntchitoyi ikufanizira makiyi azinthu, monga atsimikiziridwa ndi `f`.
    /// Kupatula apo, ndizofanana ndi [`is_sorted`];onani zolemba zake kuti mumve zambiri.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Onani [TrustedRandomAccess]
    // Dzina losazolowereka ndikuti mupewe kugundana kwamaina pakusintha kwa njira onani #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}