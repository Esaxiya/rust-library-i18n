/// Iterator yomwe imadziwa kutalika kwake.
///
/// Ambiri [`Iterator`] sadziwa kuti azingowerengera kangati, koma ena amadziwa.
/// Ngati iterator ikudziwa kangapo momwe ingathere, kupereka mwayi wazambiri zitha kukhala zothandiza.
/// Mwachitsanzo, ngati mukufuna kubwerera kumbuyo, chiyambi chabwino ndikudziwa komwe mathero ali.
///
/// Mukamayendetsa `ExactSizeIterator`, muyeneranso kukhazikitsa [`Iterator`].
/// Mukamachita izi, kukhazikitsa [`Iterator::size_hint`] * kuyenera kubweretsanso kukula kwa iterator.
///
/// Njira ya [`len`] imakhala ndi kukhazikitsa kosasintha, chifukwa chake simukuyenera kuyigwiritsa ntchito.
/// Komabe, mutha kupereka kuchitapo kanthu mochulukirapo kuposa kusakhulupirika, chifukwa chake kuposa izi ndizomveka.
///
///
/// Dziwani kuti trait ndi trait yotetezeka ndipo chifukwa chake *si* ndipo * silingathe kutsimikizira kuti utali wobwezeredwa ndi wolondola.
/// Izi zikutanthauza kuti `unsafe` code **sayenera** kudalira kulondola kwa [`Iterator::size_hint`].
/// [`TrustedLen`](super::marker::TrustedLen) trait yosakhazikika komanso yosatetezeka imapereka chitsimikizo ichi.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Kagwiritsidwe:
///
/// ```
/// // malire ochepa amadziwa bwino momwe angabwezeretsere kangati
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Mu [module-level docs], tidakhazikitsa [`Iterator`], `Counter`.
/// Tiyeni tichitenso `ExactSizeIterator` kwa iyo:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Titha kuwerengera mosavuta kuchuluka komwe kwatsala.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Ndipo tsopano titha kugwiritsa ntchito!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Imabwezera kutalika kwenikweni kwa iterator.
    ///
    /// Kukhazikitsa kumatsimikizira kuti iterator ibwerera ndendende `len()` kangapo ndi [`Some(T)`], isanabwerere [`None`].
    ///
    /// Njirayi ili ndi kukhazikitsa kosasintha, chifukwa chake nthawi zambiri simuyenera kuyigwiritsa ntchito mwachindunji.
    /// Komabe, ngati mungakwanitse kukhazikitsa bwino, mutha kutero.
    /// Onani zolemba za [trait-level] mwachitsanzo.
    ///
    /// Ntchitoyi imakhala ndi chitetezo chofanana ndi [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// // malire ochepa amadziwa bwino momwe angabwezeretsere kangati
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Izi zikudzitchinjiriza kwambiri, koma zimawunika osasintha
        // wotsimikizika ndi trait.
        // Ngati trait iyi inali rust-mkati, titha kugwiritsa ntchito debug_assert !;tsimikizani!iwunikanso magwiridwe onse a Rust.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Kubwezeretsa `true` ngati iterator ilibe kanthu.
    ///
    /// Njirayi imagwiritsidwa ntchito mosasintha pogwiritsa ntchito [`ExactSizeIterator::len()`], chifukwa chake simuyenera kuyigwiritsa ntchito nokha.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}