/// Iterator yomwe imapitilizabe kutulutsa `None` ikatopa.
///
/// Kuyimbiranso kenako pa chosakanizira chomwe chabwezeretsa `None` kamodzi kutsimikizika kuti chibwezeretsanso [`None`].
/// trait iyi iyenera kugwiritsidwa ntchito ndi onse owerenga omwe amachita motere chifukwa amalola kukhathamiritsa [`Iterator::fuse()`].
///
///
/// Note: Mwambiri, simuyenera kugwiritsa ntchito `FusedIterator` m'mizere generic ngati mukufuna chosanjikiza.
/// M'malo mwake, muyenera kungoyimbira [`Iterator::fuse()`] pa iterator.
/// Ngati iterator yasakanizidwa kale, chowonjezera cha [`Fuse`] sichidzakhala chopanda chilango.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Iterator yomwe imafotokoza kutalika kolondola pogwiritsa ntchito size_hint.
///
/// Wolembayo amafotokoza za kukula kwake pomwe kuli kwenikweni (kumunsi kuli kofanana ndi kumtunda), kapena kumtunda ndi [`None`].
///
/// Bwalo lakumtunda liyenera kukhala [`None`] ngati kutalika kwake kwenikweni ndikokulirapo kuposa [`usize::MAX`].
/// Zikatero, m'munsi ayenera kukhala [`usize::MAX`], zomwe zimapangitsa [`Iterator::size_hint()`] ya `(usize::MAX, None)`.
///
/// Iterator iyenera kutulutsa ndendende kuchuluka kwa zinthu zomwe inanena kapena kusokonekera isanafike kumapeto.
///
/// # Safety
///
/// trait iyi iyenera kugwiritsidwa ntchito pokhapokha mgwirizano ukasungidwa.
/// Ogwiritsa ntchito a trait ayenera kuyendera [`Iterator::size_hint()`]’s kumtunda.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Wolemba kuti popereka chinthu atenga chinthu chimodzi kuchokera ku [`SourceIter`] yoyambira.
///
/// Kuyimbira njira iliyonse yomwe ingalimbikitsire otsogolera, mwachitsanzo
/// [`next()`] kapena [`try_fold()`], zimatsimikizira kuti sitepe iliyonse phindu limodzi la gwero la iterator lachotsedwa ndipo zotsatira zake zitha kulowetsedwa m'malo mwake, poganiza kuti zovuta za gwero zimaloleza kulowetsa koteroko.
///
/// Mwanjira ina trait ikuwonetsa kuti payipi ya iterator itha kusonkhanitsidwa m'malo mwake.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}