use crate::ops::{ControlFlow, Try};

/// Iterator yokhoza kutulutsa zinthu kuchokera kumapeto onse.
///
/// China chake chomwe chimagwiritsa ntchito `DoubleEndedIterator` chimakhala ndi kuthekera kwina pachinthu china chomwe chimagwiritsa ntchito [`Iterator`]: kuthekanso kutenga `Item`s kumbuyo, komanso kutsogolo.
///
///
/// Ndikofunikira kudziwa kuti mmbuyo ndi mtsogolo imagwira ntchito pamtundu umodzi, ndipo musawoloke: iteration yatha akakumana pakati.
///
/// Mofananamo ndi [`Iterator`] protocol, `DoubleEndedIterator` ikabweza [`None`] kuchokera ku [`next_back()`], kuyiyimbanso itha kubwereranso [`Some`].
/// [`next()`] ndipo [`next_back()`] ndizosinthana ndi cholinga ichi.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Kagwiritsidwe:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Imachotsa ndikubwezeretsa chinthu kumapeto kwa iterator.
    ///
    /// Kubwezeretsa `None` pakalibe zinthu zina.
    ///
    /// Zolemba za [trait-level] zili ndi zambiri.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Zinthu zomwe zimaperekedwa ndi njira za `DoubleEndedIterator` zitha kukhala zosiyana ndi zomwe zidaperekedwa ndi njira za [`Iterator`]:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Ikuyendetsa iterator kumbuyo ndi zinthu `n`.
    ///
    /// `advance_back_by` ndiye mtundu wosinthika wa [`advance_by`].Njirayi idumpha mwachidwi zinthu za `n` kuyambira kumbuyo poyimba [`next_back`] mpaka `n` mpaka [`None`] itakumana.
    ///
    /// `advance_back_by(n)` idzabwezera [`Ok(())`] ngati iterator itapambana bwino ndi zinthu `n`, kapena [`Err(k)`] ngati [`None`] ikukumana nayo, pomwe `k` ndiye chiwerengero cha zinthu zomwe iterator idachita isanathe zinthu zina (ie.
    /// kutalika kwa iterator).
    /// Dziwani kuti `k` nthawi zonse imakhala yocheperako `n`.
    ///
    /// Kuyimba `advance_back_by(0)` sikumatha chilichonse ndipo kumangobweza [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // `&3` yokha ndi yomwe idadumpha
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Imabwezeretsa `n`th element kuchokera kumapeto kwa iterator.
    ///
    /// Uwu ndiye mtundu wosinthidwa wa [`Iterator::nth()`].
    /// Ngakhale monga ntchito zambiri zolozera, kuwerengera kumayambira pa zero, kotero `nth_back(0)` imabweza mtengo woyamba kuyambira kumapeto, `nth_back(1)` wachiwiri, ndi zina zotero.
    ///
    ///
    /// Dziwani kuti zinthu zonse pakati pa mapeto ndi zomwe zidabwezedwa zidzawonongedwa, kuphatikiza zomwe zidabwezedwa.
    /// Izi zikutanthauzanso kuti kuyimbira `nth_back(0)` kangapo pa iterator yomweyo kumabwezera zinthu zosiyanasiyana.
    ///
    /// `nth_back()` ibwerera [`None`] ngati `n` ili yayikulu kuposa kapena yofanana ndi kutalika kwa iterator.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Kuyimbira `nth_back()` kangapo sikubwezeretsanso iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Kubwezera `None` ngati pali zinthu zosakwana `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Ili ndiye mtundu wosinthika wa [`Iterator::try_fold()`]: zimatengera zinthu kuyambira kumbuyo kwa woyeserera.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Chifukwa idazungulira mwachidule, zotsalazo zidapezekabe kudzera pa iterator.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Njira ya iterator yomwe imachepetsa zinthu za iterator kukhala mtengo umodzi, womaliza, kuyambira kumbuyo.
    ///
    /// Ili ndiye mtundu wosinthika wa [`Iterator::fold()`]: zimatengera zinthu kuyambira kumbuyo kwa woyeserera.
    ///
    /// `rfold()` amatenga zifukwa ziwiri: mtengo woyambirira, ndi kutseka ndi mfundo ziwiri: 'accumulator', ndi chinthu.
    /// Kutseka kumabwezeretsa mtengo womwe accumulator ayenera kukhala nawo pakubwereza kotsatira.
    ///
    /// Mtengo woyambirira ndi mtengo womwe accumulator adzakhala nawo pa foni yoyamba.
    ///
    /// Pambuyo poyika kutseka uku pachinthu chilichonse cha iterator, `rfold()` ibwezeretsanso chosanjikiza.
    ///
    /// Ntchitoyi nthawi zina imatchedwa 'reduce' kapena 'inject'.
    ///
    /// Kupinda kumathandiza nthawi iliyonse mukakhala ndi chinthu china, ndipo mukufuna kutulutsa mtengo umodzi kuchokera pamenepo.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // Chiwerengero cha zinthu zonse za a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Chitsanzo ichi chimamanga chingwe, kuyambira pamtengo woyamba ndikupitilira ndi chilichonse kuyambira kumbuyo mpaka kutsogolo:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Kufufuza chinthu cholemba iterator kuchokera kumbuyo chomwe chimakwaniritsa munthu.
    ///
    /// `rfind()` kutseka komwe kumabwezeretsa `true` kapena `false`.
    /// Ikugwiritsa ntchito kutsekedwa uku pachinthu chilichonse cha iterator, kuyambira kumapeto, ndipo ngati aliyense wa iwo abweza `true`, ndiye kuti `rfind()` imabwezera [`Some(element)`].
    /// Ngati onse abwerera `false`, imabweza [`None`].
    ///
    /// `rfind()` kuchepa kwa nthawi yayitali;mwa kuyankhula kwina, idzaleka kugwira ntchito akangotseka kutseka `true`.
    ///
    /// Chifukwa `rfind()` imagwiritsa ntchito kutanthauzira, ndipo ma iterator ambiri amayesa kutanthauzira, izi zimabweretsa chisokonezo pomwe mkanganowo umatchulidwanso kawiri.
    ///
    /// Mutha kuwona izi mu zitsanzo pansipa, ndi `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Kuyimira pa `true` yoyamba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // titha kugwiritsabe ntchito `iter`, popeza pali zinthu zambiri.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}