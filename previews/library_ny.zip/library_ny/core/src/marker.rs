//! Zakale traits ndi mitundu yoyimira mitundu yayikulu yazinthu.
//!
//! Mitundu ya Rust imatha kugawidwa m'njira zosiyanasiyana kutengera momwe zimakhalira.
//! Magulu awa akuyimiridwa ngati traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Mitundu yomwe imatha kusamutsidwa kudutsa malire amtundu.
///
/// trait imangowonongedwa pokhapokha pomwe wopangirayo awona kuti ndi koyenera.
///
/// Chitsanzo cha mtundu wosakhala wa `Send` ndi cholembera chowerengera [`rc::Rc`][`Rc`].
/// Ngati zingwe ziwiri zikuyesera kuti zigwirizane [`Rc`] zomwe zikulozera pamtengo womwewo, atha kuyesa kusinthanso kuchuluka kwake nthawi yomweyo, yomwe ndi [undefined behavior][ub] chifukwa [`Rc`] sigwiritsa ntchito ma atomiki.
///
/// Msuweni wake [`sync::Arc`][arc] amagwiritsa ntchito ma atomiki (kubweretsa zina pamwamba) motero ndi `Send`.
///
/// Onani [the Nomicon](../../nomicon/send-and-sync.html) kuti mumve zambiri.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Mitundu yokhala ndi kukula kosasintha komwe kumadziwika nthawi yakusonkhanitsa.
///
/// Mitundu yamitundu yonse ili ndi zomangika za `Sized`.Syntax yapadera `?Sized` itha kugwiritsidwa ntchito kuchotsa chomangachi ngati sichiri choyenera.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // ndondomeko FooUse(Foo<[i32]>);//cholakwika: Kukula sikunachitike pa [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Kupatula kumodzi ndi mtundu wa `Self` wa trait.
/// trait ilibe `Sized` yomangidwa chifukwa izi sizigwirizana ndi [trait object] s komwe, mwakutanthauzira, trait imayenera kugwira ntchito ndi onse omwe angathe kukhazikitsa, motero akhoza kukhala kukula kulikonse.
///
///
/// Ngakhale Rust ikulolani kuti mumangirire `Sized` ku trait, simungagwiritse ntchito kupanga chinthu cha trait pambuyo pake:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // let y: &dyn Bar= &Impl;//cholakwika: trait `Bar` sichingapangidwe kukhala chinthu
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // mwa Chosintha, mwachitsanzo, chomwe chimafuna kuti `[T]: !Default` iwunikiridwe
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Mitundu yomwe imatha kukhala "unsized" yamtundu wamphamvu kwambiri.
///
/// Mwachitsanzo, mtundu waukulu wa `[i8; 2]` umagwiritsa ntchito `Unsize<[i8]>` ndi `Unsize<dyn fmt::Debug>`.
///
/// Kukhazikitsa konse kwa `Unsize` kumangoperekedwa ndi wopanga.
///
/// `Unsize` yakhazikitsidwa pa:
///
/// - `[T; N]` ndi `Unsize<[T]>`
/// - `T` ndi `Unsize<dyn Trait>` pomwe `T: Trait`
/// - `Foo<..., T, ...>` ndi `Unsize<Foo<..., U, ...>>` ngati:
///   - `T: Unsize<U>`
///   - Foo ndi struct
///   - Gawo lomaliza la `Foo` lokhala ndi mtundu wophatikiza `T`
///   - `T` sili gawo la mtundu wina uliwonse waminda
///   - `Bar<T>: Unsize<Bar<U>>`, ngati gawo lomaliza la `Foo` lili ndi mtundu `Bar<T>`
///
/// `Unsize` imagwiritsidwa ntchito limodzi ndi [`ops::CoerceUnsized`] kuloleza zotengera za "user-defined" monga [`Rc`] kuti zikhale ndi mitundu yayikulu kwambiri.
/// Onani [DST coercion RFC][RFC982] ndi [the nomicon entry on coercion][nomicon-coerce] kuti mumve zambiri.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Chofunika trait cha zokhazikika zomwe zimagwiritsidwa ntchito mofananira.
///
/// Mtundu uliwonse womwe umapezeka `PartialEq` umangogwiritsa ntchito trait, * mosasamala kanthu kuti mitundu yake imagwiritsa ntchito `Eq`.
///
/// Ngati chinthu cha `const` chili ndi mtundu wina wosagwiritsa ntchito trait, ndiye kuti mtunduwo mwina (1.) suligwiritsa ntchito `PartialEq` (zomwe zikutanthauza kuti nthawi zonse sapereka njira yofananirayi, yomwe mibadwo imalingalira ilipo), kapena (2.) imagwiritsa ntchito yake * Mtundu wa `PartialEq` (womwe timaganiza kuti sukugwirizana ndi kufananiza kofanana).
///
///
/// Pa zochitika ziwirizi pamwambapa, timakana kugwiritsa ntchito chizolowezi chofananira.
///
/// Onaninso [structural match RFC][RFC1445], ndi [issue 63438] yomwe idalimbikitsa kusamuka kuchoka pamapangidwe okhudzana ndi malingaliro kupita ku trait iyi.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Chofunika trait cha zokhazikika zomwe zimagwiritsidwa ntchito mofananira.
///
/// Mtundu uliwonse womwe umapeza `Eq` umangogwiritsa ntchito trait, * mosasamala kanthu kuti mtundu wake umagwiritsa ntchito `Eq`.
///
/// Uku ndikubera kuti mugwire ntchito mozungulira malire amtundu wathu.
///
/// # Background
///
/// Tikufuna mitundu yamtundu wa ma const yomwe imagwiritsidwa ntchito pamasewera omwe ali ndi malingaliro `#[derive(PartialEq, Eq)]`.
///
/// M'dziko labwino kwambiri, titha kuwona zofunikira izi pongowona kuti mtundu womwe wapatsidwa ukugwiritsa ntchito `StructuralPartialEq` trait *ndi*`Eq` trait.
/// Komabe, mutha kukhala ndi ma ADTs omwe *amachita*`derive(PartialEq, Eq)`, ndikukhala mlandu womwe tikufuna wopanga kuti avomereze, koma mtundu wanthawi zonse walephera kukhazikitsa `Eq`.
///
/// Momwemonso, mlandu ngati uwu:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Vuto lomwe lili pamwambapa ndiloti `Wrap<fn(&())>` siyigwiritsa ntchito `PartialEq`, kapena `Eq`, chifukwa `for <'a> fn(&'a _)` does not implement those traits.)
///
/// Chifukwa chake, sitingadalire cheke cha `StructuralPartialEq` ndi `Eq` wamba.
///
/// Monga kubera kuti tigwire ntchito mozungulira izi, timagwiritsa ntchito traits ziwiri zobayidwa ndi chilichonse mwazomwe zimachokera ku (`#[derive(PartialEq)]` ndi `#[derive(Eq)]`) ndikuwona kuti onsewa alipo ngati gawo lowunika machesi.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Mitundu yomwe zikhalidwe zawo zitha kubwerezedwa mongokopera ma bits.
///
/// Pokhapokha, zomangira zosinthika zimakhala ndi 'semantics yosuntha.'Mwanjira ina:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` yasamukira ku `y`, ndipo silingagwiritsidwe ntchito
///
/// // println! ("{: ?}", x);//cholakwika: kugwiritsa ntchito mtengo wosunthika
/// ```
///
/// Komabe, ngati mtundu wina ukugwiritsa ntchito `Copy`, m'malo mwake uli ndi 'copy semantics':
///
/// ```
/// // Titha kupeza kukhazikitsa kwa `Copy`.
/// // `Clone` imafunikanso, popeza ndimalo apamwamba a `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` ndi buku la `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Ndikofunika kuzindikira kuti mu zitsanzo ziwirizi, kusiyana kokha ndikuti mukuloledwa kulowa `x` mutapatsidwa ntchitoyi.
/// Pansi pa nyumbayi, zonse zomwe zimasindikizidwa komanso kusuntha kumatha kuchititsa kuti zikopizo zikoperedwe kukumbukira, ngakhale kuti nthawi zina zimatheka.
///
/// ## Kodi ndingagwiritse ntchito bwanji `Copy`?
///
/// Pali njira ziwiri zokhazikitsira `Copy` pamtundu wanu.Chophweka ndicho kugwiritsa ntchito `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Muthanso kugwiritsa ntchito `Copy` ndi `Clone` pamanja:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Pali kusiyana kochepa pakati pa ziwirizi: malingaliro a `derive` adzaikanso `Copy` yomangidwa pamitundu yamitundu, yomwe sikufunidwa nthawi zonse.
///
/// ## Kodi pali kusiyana kotani pakati pa `Copy` ndi `Clone`?
///
/// Zolemba zimachitika kwathunthu, mwachitsanzo ngati gawo la gawo `y = x`.Khalidwe la `Copy` silowonjezera;nthawi zonse imakhala yophweka mwanzeru.
///
/// Cloning ndichinthu chowonekera, `x.clone()`.Kukhazikitsa [`Clone`] kumatha kukupatsirani mtundu uliwonse wamakhalidwe oyenera kutsata mfundo mosamala.
/// Mwachitsanzo, kukhazikitsidwa kwa [`Clone`] kwa [`String`] kuyenera kukopera cholumikizira choloza chingwe pamulu.
/// Kope losavuta pang'ono lamitengo ya [`String`] limangokopera cholozera, ndikupangitsa kuti pakhale mfulu pamzere.
/// Pachifukwa ichi, [`String`] ndi [`Clone`] koma osati `Copy`.
///
/// [`Clone`] ndi supertrait ya `Copy`, chifukwa chake zonse zomwe zili `Copy` ziyeneranso kukhazikitsa [`Clone`].
/// Ngati mtundu uli `Copy` ndiye kuti kukhazikitsa kwake [`Clone`] kumangofunika kubwezera `*self` (onani chitsanzo pamwambapa).
///
/// ## Kodi mtundu wanga ungakhale `Copy` liti?
///
/// Mtundu ukhoza kukhazikitsa `Copy` ngati zida zake zonse zikanakhazikitsa `Copy`.Mwachitsanzo, izi zitha kukhala `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Makina akhoza kukhala `Copy`, ndipo [`i32`] ndi `Copy`, chifukwa chake `Point` ikuyenera kukhala `Copy`.
/// Mosiyana ndi izi, lingalirani
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Dongosolo `PointList` silingagwiritse ntchito `Copy`, chifukwa [`Vec<T>`] si `Copy`.Tikayesa kupeza `Copy` kukhazikitsa, tikhala ndi vuto:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Mafotokozedwe ogawana nawo (`&T`) alinso `Copy`, chifukwa chake mtundu umatha kukhala `Copy`, ngakhale utakhala ndi mafotokozedwe amtundu wa `T` omwe si * `Copy`.
/// Talingalirani dongosolo lotsatirali, lomwe lingagwiritse ntchito `Copy`, chifukwa limangokhala ndi gawo logawana nawo * ku mtundu wathu wosakhala wa `
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Kodi * mtundu wanga sungakhale `Copy` liti?
///
/// Mitundu ina singakopedwe bwino.Mwachitsanzo, kukopera `&mut T` kungapangitse kusintha kosasinthika.
/// Kukopera [`String`] kungafanane ndi udindo woyang'anira gawo la ["String"], zomwe zingapangitse kuti mukhale mfulu kawiri.
///
/// Kuphatikiza izi, mtundu uliwonse wokhazikitsa [`Drop`] sungakhale `Copy`, chifukwa ukuyang'anira zina mwazinthu kupatula ma [`size_of::<T>`] byte ake.
///
/// Mukayesa kukhazikitsa `Copy` pa struct kapena enum yomwe ili ndi data yosakhala ya`Copy`, mupeza cholakwika [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Kodi * mtundu wanga uyenera kukhala `Copy` liti?
///
/// Nthawi zambiri, ngati mtundu wanu _can_ ukhazikitsa `Copy`, uyenera kutero.
/// Kumbukirani, komabe, kuti kukhazikitsa `Copy` ndi gawo la API yapagulu yamtundu wanu.
/// Ngati mtunduwo ungakhale wosakhala`Copy` mu future, kungakhale kwanzeru kusiya kukhazikitsidwa kwa `Copy` tsopano, kuti tipewe kusintha kwa API.
///
/// ## Otsatira owonjezera
///
/// Kuphatikiza pa [implementors listed below][impls], mitundu yotsatirayi imagwiritsanso ntchito `Copy`:
///
/// * Mitundu yazinthu zogwirira ntchito (mwachitsanzo, mitundu yosiyanitsidwa ndi ntchito iliyonse)
/// * Mitundu yolozera (monga, `fn() -> i32`)
/// * Mitundu yazithunzi, zamitundu yonse, ngati mtunduwo ukugwiritsanso ntchito `Copy` (mwachitsanzo, `[i32; 123456]`)
/// * Mitundu yamitundumitundu, ngati chilichonse chimagwiritsanso ntchito `Copy` (mwachitsanzo, `()`, `(i32, bool)`)
/// * Mitundu yotsekedwa, ngati ilibe phindu lililonse m'chilengedwe kapena ngati malingaliro onsewa atsegulidwa `Copy` iwowo.
///   Dziwani kuti zosintha zomwe zimagawidwa nthawi zonse zimagwiritsa ntchito `Copy` (ngakhale zosiyanazo sizitero), pomwe zosintha zomwe zimasinthidwa sizigwiritsa ntchito `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Izi zimalola kukopera mtundu womwe sukhazikitsa `Copy` chifukwa cha malire osakwanira nthawi zonse (kukopera `A<'_>` pokhapokha `A<'static>: Copy` ndi `A<'_>: Clone`).
// Tili ndi malingaliro pano pakadali pano chifukwa pali ukadaulo wambiri womwe ulipo pa `Copy` womwe ulipo kale mulaibulale yanthawi zonse, ndipo palibe njira yoti tingakhalire ndi khalidweli pakadali pano.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Pezani zazikulu zomwe zikupanga trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Mitundu yomwe ndiyotetezeka kugawana zofananira pakati pa ulusi.
///
/// trait imangowonongedwa pokhapokha pomwe wopangirayo awona kuti ndi koyenera.
///
/// Kutanthauzira kolondola ndi: mtundu `T` ndi [`Sync`] ngati pokhapokha `&T` ndi [`Send`].
/// Mwanjira ina, ngati palibe kuthekera kwa [undefined behavior][ub] (kuphatikiza mitundu yama data) potumiza ma `&T` pakati pa ulusi.
///
/// Monga momwe munthu angayembekezere, mitundu yakale monga [`u8`] ndi [`f64`] yonse ndi [`Sync`], momwemonso mitundu yosakanikirana yosavuta yomwe ili nayo, monga tuples, structs ndi enums.
/// Zitsanzo zambiri zamitundu yoyambirira ya [`Sync`] imaphatikizapo mitundu ya "immutable" monga `&T`, ndi omwe ali ndi kusintha kosavomerezeka, monga [`Box<T>`][box], [`Vec<T>`][vec] ndi mitundu ina yambiri yosonkhanitsa.
///
/// (Ma generic amafunika kukhala [`Sync`] kuti chidebe chawo chikhale [`Sync`].)
///
/// Chotsatira chodabwitsa cha tanthauzo ndikuti `&mut T` ndi `Sync` (ngati `T` ndi `Sync`) ngakhale zikuwoneka ngati izi zitha kupatsa kusintha kosagwirizana.
/// Chinyengo chake ndikuti kusinthika kosunthika kumbuyo kwa zomwe zagawidwa (ndiye kuti, `& &mut T`) kumangowerengedwa kokha, ngati kuti ndi `& &T`.
/// Chifukwa chake palibe chiopsezo cha mpikisano wama data.
///
/// Mitundu yomwe si `Sync` ndi yomwe ili ndi "interior mutability" m'njira yopanda ulusi, monga [`Cell`][cell] ndi [`RefCell`][refcell].
/// Mitunduyi imalola kusintha kwa zomwe zili mkatimo ngakhale mutasinthika, kugawana nawo.
/// Mwachitsanzo, njira ya `set` pa [`Cell<T>`][cell] imatenga `&self`, chifukwa chake imangofunika kutchulapo [`&Cell<T>`][cell].
/// Njirayo siyigwirizana, motero [`Cell`][cell] sangakhale `Sync`.
///
/// Chitsanzo china cha mtundu wosakhala wa `Sync` ndi pointer yowerengera [`Rc`][rc].
/// Popeza kutchulidwa kulikonse [`&Rc<T>`][rc], mutha kuyika [`Rc<T>`][rc] yatsopano, ndikusintha kuwerengera kosakhala kwa atomiki.
///
/// Zikakhala kuti wina angafunike kusinthika kwamkati mosamala, Rust imapereka [atomic data types], komanso kutseka momveka bwino kudzera pa [`sync::Mutex`][mutex] ndi [`sync::RwLock`][rwlock].
/// Mitunduyi imawonetsetsa kuti kusintha kulikonse sikungayambitse mitundu ya data, chifukwa chake mitundu ndi `Sync`.
/// Momwemonso, [`sync::Arc`][arc] imapereka analogue yolimba ya [`Rc`][rc].
///
/// Mitundu iliyonse yosinthika kwamkati iyeneranso kugwiritsa ntchito zokutira za [`cell::UnsafeCell`][unsafecell] mozungulira value(s) zomwe zimatha kusinthidwa kudzera pakuwunikiranso.
/// Kulephera kuchita izi ndi [undefined behavior][ub].
/// Mwachitsanzo, [`transmute`][transmute]-ing kuchokera ku `&T` mpaka `&mut T` ndizosavomerezeka.
///
/// Onani [the Nomicon][nomicon-send-and-sync] kuti mumve zambiri za `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): kamodzi kuthandizira kuwonjezera zolemba m'maiko a `rustc_on_unimplemented` mu beta, ndipo kwatambasulidwa kuti muwone ngati kutsekedwa kuli kulikonse munthawi yofunikira, yonjezerani monga (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Mtundu wa zero-size womwe umagwiritsidwa ntchito kuwunikira zinthu kuti "act like" ali ndi `T`.
///
/// Kuphatikiza gawo la `PhantomData<T>` pamtundu wanu kumamuwuza wopanga kuti mtundu wanu umakhala ngati umasunga mtundu wa `T`, ngakhale ulibe.
/// Izi zimagwiritsidwa ntchito mukamagwiritsa ntchito chitetezo china.
///
/// Kuti mumve tsatanetsatane wa momwe mungagwiritsire ntchito `PhantomData<T>`, chonde onani [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Chidziwitso chowopsa 👻👻👻
///
/// Ngakhale onse ali ndi mayina owopsa, `PhantomData` ndi 'phantom mitundu' ndizofanana, koma sizofanana.Phantom mtundu wa parameter ndi mtundu wamtundu womwe sugwiritsidwa ntchito konse.
/// Mu Rust, izi nthawi zambiri zimapangitsa wopangirayo kudandaula, ndipo yankho ndikowonjezera kugwiritsa ntchito "dummy" kudzera pa `PhantomData`.
///
/// # Examples
///
/// ## Zosagwiritsidwa ntchito nthawi zonse
///
/// Mwinanso vuto lalikulu la `PhantomData` ndi struct yomwe ili ndi gawo losagwiritsidwa ntchito nthawi zonse, makamaka ngati gawo la nambala ina yosatetezeka.
/// Mwachitsanzo, nayi pulatifomu `Slice` yomwe ili ndi zolozera ziwiri zamtundu wa `*const T`, mwina zikuloza m'magulu kwinakwake:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Cholinga chake ndikuti zomwe zikuyikidwazo ndizovomerezeka pamoyo wa `'a`, chifukwa chake `Slice` siyiyenera kupitilira `'a`.
/// Komabe, cholinga ichi sichinafotokozeredwe ndi kachidindo, popeza palibe kugwiritsa ntchito nthawi ya `'a` ndipo motero sizikudziwika kuti ndi chidziwitso chiti.
/// Titha kukonza izi pouza wopangirayo kuti azichita * ngati kuti `Slice` struct ili ndi `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Izi zimafunikanso kutanthauzira `T: 'a`, kuwonetsa kuti mafotokozedwe aliwonse mu `T` ndiwothandiza pa nthawi yonse ya `'a`.
///
/// Mukamayambitsa `Slice` mumangopereka phindu `PhantomData` pamunda `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Magulu amtundu wosagwiritsidwa ntchito
///
/// Nthawi zina zimachitika kuti mulibe mitundu yamtundu wosagwiritsidwa ntchito yomwe imawonetsa kuti ndi "tied" yamtundu wanji, ngakhale kuti zambirizo sizipezeka mu struct mwawo.
/// Nachi chitsanzo pomwe izi zimayamba ndi [FFI].
/// Maonekedwe akunja amagwiritsa ntchito mitundu ya `*mut ()` potengera z0Rust0Z zamitundu yosiyanasiyana.
/// Timatsata mtundu wa Rust pogwiritsa ntchito mtundu wa phantom pa struct `ExternalResource` yomwe imakutira chogwirira.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Umwini ndi cheke chotsitsa
///
/// Kuphatikiza gawo lamtundu wa `PhantomData<T>` kukuwonetsa kuti mtundu wanu uli ndi chidziwitso cha mtundu wa `T`.Izi zikutanthawuza kuti mtundu wanu ukaponyedwa, utha kusiya gawo limodzi kapena angapo amtundu wa `T`.
/// Izi zikukhudza kuwunika kwa Rust kophatikiza [drop check].
///
/// Ngati struct yanu ilibe *chidziwitso* cha mtundu wa `T`, ndibwino kuti mugwiritse ntchito mtundu wa zolembedwera, monga `PhantomData<&'a T>` (ideally) kapena `PhantomData<*const T>` (ngati palibe nthawi yamoyo), kuti musawonetse umwini.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Makina-mkati trait amagwiritsidwa ntchito posonyeza mtundu wa omwe amasankha enum.
///
/// trait imangogwiritsidwa ntchito pamtundu uliwonse ndipo siziwonjezera ku [`mem::Discriminant`].
/// Ndi **zosadziwika bwino** kuti mutumizire pakati pa `DiscriminantKind::Discriminant` ndi `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Mtundu wachisankho, womwe uyenera kukwaniritsa trait bounds zofunikira ndi `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Makina-mkati trait amagwiritsidwa ntchito kuti adziwe ngati mtundu uli ndi `UnsafeCell` iliyonse mkati, koma osati kudzera pakulowera.
///
/// Izi zimakhudza, mwachitsanzo, ngati `static` yamtunduwu imayikidwa mu memory-static memory yokha kapena kukumbukira kukumbukira.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Mitundu yomwe imatha kusunthidwa bwinobwino itapinidwa.
///
/// Rust palokha ilibe lingaliro la mitundu yosasunthika, ndipo imawona mayendedwe (mwachitsanzo, kudzera pakupatsidwa kapena [`mem::replace`]) kukhala otetezeka nthawi zonse.
///
/// Mtundu wa [`Pin`][Pin] umagwiritsidwa ntchito m'malo mopewera mayendedwe amtunduwo.Zolembera `P<T>` zokutidwa ndi zokutira [`Pin<P<T>>`][Pin] sizingachotsedwe.
/// Onani zolemba za [`pin` module] kuti mumve zambiri pa pinning.
///
/// Kukhazikitsa `Unpin` trait ya `T` kumachotsa zoletsa zothina mtundu, zomwe zimaloleza `T` kuchoka ku [`Pin<P<T>>`][Pin] ndi ntchito monga [`mem::replace`].
///
///
/// `Unpin` alibe zotsatira konse chifukwa deta sanali pini.
/// Makamaka, [`mem::replace`] imasuntha deta ya `!Unpin` mosangalala (imagwirira ntchito `&mut T` iliyonse, osati nthawi ya `T: Unpin` yokha).
/// Komabe, simungagwiritse ntchito [`mem::replace`] pamtundu wokutidwa mkati mwa [`Pin<P<T>>`][Pin] chifukwa simungathe kupeza `&mut T` yomwe mumafunikira, ndipo ndi * zomwe zimapangitsa kuti dongosololi ligwire ntchito.
///
/// Chifukwa chake, mwachitsanzo, zitha kuchitika pamitundu yokhazikitsa `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Tikufuna kutanthauzira kosinthika kuti titchule `mem::replace`.
/// // Titha kupeza kutanthauzira koteroko ndi (implicitly) yopempha `Pin::deref_mut`, koma izi ndizotheka chifukwa `String` imagwiritsa ntchito `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// trait iyi imayendetsedwa pafupifupi pafupifupi mtundu uliwonse.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Chikhomo chomwe sichikugwiritsa ntchito `Unpin`.
///
/// Ngati mtundu uli ndi `PhantomPinned`, sigwiritsa ntchito `Unpin` mwachisawawa.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Kukhazikitsa kwa `Copy` yamitundu yakale.
///
/// Zotsatira zomwe sizingafotokozedwe mu Rust zimayendetsedwa mu `traits::SelectionContext::copy_clone_conditions()` mu `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Zolemba zogawana zitha kukopedwa, koma maumboni osinthika *sangathe*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}