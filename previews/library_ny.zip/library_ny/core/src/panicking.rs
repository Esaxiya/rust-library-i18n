//! Panic kuthandizira libcore
//!
//! Laibulale yoyambira siyingatanthauze kuda nkhawa, koma imafotokoza * mantha.
//! Izi zikutanthauza kuti ntchito zomwe zili mkati mwa libcore zimaloledwa ku panic, koma kuti zikhale zothandiza kumtunda kwa crate ziyenera kufotokozera kuda nkhawa kuti libcore ligwiritse ntchito.
//! Mawonekedwe apano owopsa ndi awa:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Kutanthauzira uku kumalola mantha ndi uthenga uliwonse, koma salola kulephera ndi mtengo wa `Box<Any>`.
//! (`PanicInfo` imangokhala ndi `&(dyn Any + Send)`, yomwe timadzaza mtengo mu `PanicInfo: : internal_constructor`.) Chifukwa cha ichi ndikuti libcore siloledwa kugawa.
//!
//!
//! Gawoli lili ndi ntchito zina zochepa zowopsa, koma izi ndi zinthu zofunika zokha za wopanga.panics zonse zimakonzedwa kudzera muntchito imodziyi.
//! Chizindikiro chenicheni chimalengezedwa kudzera mu malingaliro a `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Kukhazikitsa koyambirira kwa libcore's `panic!` macro pomwe palibe mawonekedwe omwe amagwiritsidwa ntchito.
#[cold]
// musakhale pamzere pokhapokha mutakhala ndi mantha_mediate_abort kuti mupewe kufalikira kwa ma code pamalo oyimbiramo momwe mungathere
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // yofunikira ndi codegen ya panic yomwe ikusefukira komanso ma terminator ena a `Assert` MIR
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Gwiritsani ntchito Arguments::new_v1 m'malo mwa format_args! ("{}", Expr) kuti muchepetse kukula pamwamba.
    // Maonekedwe_args!Macro amagwiritsa ntchito Str's Display trait kuti alembe expr, yomwe imati Formatter::pad, yomwe imayenera kukhala ndi chingwe chachingwe ndi padding (ngakhale palibe yomwe ikugwiritsidwa ntchito pano).
    //
    // Kugwiritsa ntchito Arguments::new_v1 kumatha kuloleza wophatikizira kuti atulutse Formatter::pad pazotulutsa za binary, kupulumutsa ma kilobytes angapo.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // zofunikira pakuyesa kwa panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // yofunikira ndi codegen ya panic pakupezeka kwa OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Kukhazikitsa koyambirira kwa libcore's `panic!` macro mukamagwiritsa ntchito fomati.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Dziwani kuti ntchitoyi siyidutsa malire a FFI;ndi kuyimba kwa Rust-to-Rust komwe kumatsimikizika ku ntchito ya `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // CHITETEZO: `panic_impl` imafotokozedwa mu nambala ya Rust yotetezeka motero ndiyabwino kuyimba.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Ntchito yamkati ya `assert_eq!` ndi `assert_ne!` macros
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}