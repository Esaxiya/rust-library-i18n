//! Kukhazikitsa kwa Trait kwa `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Imagwiritsa ntchito kuyitanitsa zingwe.
///
/// Zingwe zimalamulidwa [lexicographically](Ord#lexicographical-comparison) malinga ndi malingaliro awo.
/// Izi zimaitanitsa ma code a Unicode potengera malo omwe ali ma chart.
/// Izi sizofanana kwenikweni ndi dongosolo la "alphabetical", lomwe limasiyanasiyana malinga ndi chilankhulo ndi malo.
/// Kusanja zingwe molingana ndi chikhalidwe chovomerezedwa ndi chikhalidwe kumafunikira zidziwitso zapaderadera zomwe sizingafanane ndi mtundu wa `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Zimagwira poyerekeza ntchito pa zingwe.
///
/// Zingwe amafanizidwa ndi [lexicographically](Ord#lexicographical-comparison) malinga ndi malingaliro awo.
/// Izi zikufanizira ma code a Unicode potengera malo omwe ali ma chart.
/// Izi sizofanana kwenikweni ndi dongosolo la "alphabetical", lomwe limasiyanasiyana malinga ndi chilankhulo ndi malo.
/// Kuyerekeza zingwe molingana ndi chikhalidwe chovomerezedwa ndi chikhalidwe kumafunikira zidziwitso zakomweko zomwe sizingafanane ndi mtundu wa `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Zimagwira substring slicing ndi syntax `&self[..]` kapena `&mut self[..]`.
///
/// Kubwezeretsa chidutswa cha chingwe chonse, mwachitsanzo, chimabweza `&self` kapena `&mut self`.Zofanana ndi `&self [0 ..
/// len] `kapena`&mut mut [0 ..
/// len]`.
/// Mosiyana ndi ntchito zina zolozera, izi sizingakhale panic.
///
/// Ntchitoyi ndi *O*(1).
///
/// 1.20.0 isanachitike, ntchito zolembazi zidathandizidwabe ndikukhazikitsidwa kwa `Index` ndi `IndexMut`.
///
/// Zofanana ndi `&self[0 .. len]` kapena `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Zimagwira substring slicing ndi syntax `&self[begin .. end]` kapena `&mut self[begin .. end]`.
///
/// Kubwezeretsa chidutswa cha chingwe chomwe chapatsidwa kuchokera pa byte range [`start`, `end`).
///
/// Ntchitoyi ndi *O*(1).
///
/// 1.20.0 isanachitike, ntchito zolembazi zidathandizidwabe ndikukhazikitsidwa kwa `Index` ndi `IndexMut`.
///
/// # Panics
///
/// Panics ngati `begin` kapena `end` sizikuloza pamtundu woyambira wamakhalidwe (monga `is_char_boundary`), ngati `begin > end`, kapena `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // izi panic:
/// // byte 2 ili mkati mwa `ö`:
/// // &s [2 ..3];
///
/// // byte 8 ili mkati mwa `老`&s [1 ..
/// // 8];
///
/// // byte 100 ili kunja kwa chingwe&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // CHITETEZO: tangowunika kuti `start` ndi `end` ali pamalire a char,
            // ndipo tikudutsa motetezedwa, kotero kuti phindu lobwezera lidzakhalanso limodzi.
            // Tidawunikiranso malire a char, kotero iyi ndi UTF-8 yoyenera.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // CHITETEZO: tangowunika kuti `start` ndi `end` ali pamalire a char.
            // Tikudziwa kuti cholozera ndichapadera chifukwa tidachipeza kuchokera ku `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // CHITETEZO: woyimbayo akutsimikizira kuti `self` ili m'malire a `slice`
        // zomwe zimakwaniritsa zofunikira zonse za `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // CHITETEZO: onani ndemanga za `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary imafufuza kuti index ili mu [0, .len()] singagwiritsenso ntchito `get` monga pamwambapa, chifukwa cha vuto la NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // CHITETEZO: tangowunika kuti `start` ndi `end` ali pamalire a char,
            // ndipo tikudutsa motetezedwa, kotero kuti phindu lobwezera lidzakhalanso limodzi.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Zimagwira substring slicing ndi syntax `&self[.. end]` kapena `&mut self[.. end]`.
///
/// Kubwezeretsa chidutswa cha chingwe chomwe chapatsidwa kuchokera pa byte range [`0`, `end`).
/// Zofanana ndi `&self[0 .. end]` kapena `&mut self[0 .. end]`.
///
/// Ntchitoyi ndi *O*(1).
///
/// 1.20.0 isanachitike, ntchito zolembazi zidathandizidwabe ndikukhazikitsidwa kwa `Index` ndi `IndexMut`.
///
/// # Panics
///
/// Panics ngati `end` siyikulozera pamtundu woyambira wamakhalidwe (monga tafotokozera `is_char_boundary`), kapena ngati `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // CHITETEZO: tangowona kuti `end` ili pamalire a char,
            // ndipo tikudutsa motetezedwa, kotero kuti phindu lobwezera lidzakhalanso limodzi.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // CHITETEZO: tangowona kuti `end` ili pamalire a char,
            // ndipo tikudutsa motetezedwa, kotero kuti phindu lobwezera lidzakhalanso limodzi.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // CHITETEZO: tangowona kuti `end` ili pamalire a char,
            // ndipo tikudutsa motetezedwa, kotero kuti phindu lobwezera lidzakhalanso limodzi.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Zimagwira substring slicing ndi syntax `&self[begin ..]` kapena `&mut self[begin ..]`.
///
/// Kubwezeretsa chidutswa cha chingwe chomwe chapatsidwa kuchokera pa byte range [`start`, `len`).Zofanana ndi `&self [yambani ..
/// len] `kapena`&mut mut [yambani ..
/// len]`.
///
/// Ntchitoyi ndi *O*(1).
///
/// 1.20.0 isanachitike, ntchito zolembazi zidathandizidwabe ndikukhazikitsidwa kwa `Index` ndi `IndexMut`.
///
/// # Panics
///
/// Panics ngati `begin` siyikulozera pamtundu woyambira wamakhalidwe (monga tafotokozera `is_char_boundary`), kapena ngati `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // CHITETEZO: tangowona kuti `start` ili pamalire a char,
            // ndipo tikudutsa motetezedwa, kotero kuti phindu lobwezera lidzakhalanso limodzi.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // CHITETEZO: tangowona kuti `start` ili pamalire a char,
            // ndipo tikudutsa motetezedwa, kotero kuti phindu lobwezera lidzakhalanso limodzi.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // CHITETEZO: woyimbayo akutsimikizira kuti `self` ili m'malire a `slice`
        // zomwe zimakwaniritsa zofunikira zonse za `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // CHITETEZO: zofanana ndi `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // CHITETEZO: tangowona kuti `start` ili pamalire a char,
            // ndipo tikudutsa motetezedwa, kotero kuti phindu lobwezera lidzakhalanso limodzi.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Zimagwira substring slicing ndi syntax `&self[begin ..= end]` kapena `&mut self[begin ..= end]`.
///
/// Kubwezeretsa chidutswa cha chingwe chomwe chaperekedwa kuchokera pa byte range [`begin`, `end`].Chofanana ndi `&self [begin .. end + 1]` kapena `&mut self[begin .. end + 1]`, kupatula ngati `end` ili ndi mtengo wokwanira `usize`.
///
/// Ntchitoyi ndi *O*(1).
///
/// # Panics
///
/// Panics ngati `begin` siyikulozera pamtundu woyambira wamakhalidwe (monga tafotokozera ndi `is_char_boundary`), ngati `end` siyikuloza kumapeto kwa mtundu wamakhalidwe (`end + 1` mwina ndi poyambira poyambira kapena yofanana ndi `len`), ngati `begin > end`, kapena ngati `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Zimagwira substring slicing ndi syntax `&self[..= end]` kapena `&mut self[..= end]`.
///
/// Kubwezeretsa chidutswa cha chingwe chomwe chapatsidwa kuchokera pamtundu wa [0, `end`].
/// Chofanana ndi `&self [0 .. end + 1]`, kupatula ngati `end` ili ndi mtengo wokwanira `usize`.
///
/// Ntchitoyi ndi *O*(1).
///
/// # Panics
///
/// Panics ngati `end` sichikulozera kumapeto kwa mtundu wamakhalidwe (`end + 1` mwina ndiyotengera poyambira malinga ndi `is_char_boundary`, kapena yofanana ndi `len`), kapena ngati `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Fananizani mtengo kuchokera pachingwe
///
/// Njira yochokera kuStr's [`from_str`] imagwiritsidwa ntchito moyenera, kudzera mu njira ya [`str`] ya [`parse`].
/// Onani zolemba [`parse`] za zitsanzo.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` ilibe parameter yamoyo wonse, chifukwa chake mutha kungowerengera mitundu yomwe ilibe gawo lokhala moyo wawo wonse.
///
/// Mwanjira ina, mutha kuwerengera `i32` ndi `FromStr`, koma osati `&i32`.
/// Mutha kuwona zolemba zomwe zili ndi `i32`, koma osati imodzi yomwe ili ndi `&i32`.
///
/// # Examples
///
/// Kukhazikitsa koyambirira kwa `FromStr` pa mtundu wa `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Cholakwika chomwe chikugwirizana chomwe chitha kubwezedwa kuchokera pakuwunika.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Ikani chingwe `s` kuti ibwezeretse mtengo wamtunduwu.
    ///
    /// Ngati kuyerekezera kwapambana, bweretsani mtengo mkati mwa [`Ok`], apo ayi chingwecho chikakhala kuti sichinapangidwe bwino chimabweza cholakwika mkati mwa [`Err`].
    /// Mtundu wolakwikawo ndiwokhazikitsa trait.
    ///
    /// # Examples
    ///
    /// Kugwiritsa ntchito kwenikweni ndi [`i32`], mtundu womwe umagwiritsa ntchito `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Yerekezerani `bool` ndi chingwe.
    ///
    /// Amapereka `Result<bool, ParseBoolError>`, chifukwa `s` itha kukhala yosawoneka.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Tawonani, nthawi zambiri, njira ya `.parse()` pa `str` ndiyabwino kwambiri.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}