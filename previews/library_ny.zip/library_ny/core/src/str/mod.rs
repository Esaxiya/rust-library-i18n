//! Kugwiritsa ntchito zingwe.
//!
//! Kuti mumve zambiri, onani gawo la [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. kunja kwa malire
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. yambani <=end
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. malire a chikhalidwe
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // pezani khalidwelo
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` iyenera kukhala yochepera len ndi malire a char
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Imabwezeretsa kutalika kwa `self`.
    ///
    /// Kutalika kumeneku kumakhala ndi ma byte, osati [`char`] s kapena graphemes.
    /// Mwanjira ina, sizingakhale zomwe munthu amawona kutalika kwa chingwecho.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // zapamwamba f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Kubwezeretsa `true` ngati `self` ili ndi kutalika kwa zero byte.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Macheke kuti `index`-th byte ndiye woyamba mwa mndandanda wa UTF-8 kapena kumapeto kwa chingwe.
    ///
    ///
    /// Kuyamba ndi kutha kwa chingwe (pamene `index== self.len()`) imawerengedwa kuti ndi malire.
    ///
    /// Kubwezeretsa `false` ngati `index` ili yayikulu kuposa `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // kuyamba kwa `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // byte yachiwiri ya `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // byte wachitatu wa `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 ndi len nthawi zonse amakhala bwino.
        // Yesani 0 momveka bwino kuti athe kukonza cheke mosavuta ndikudumpha zowerengera zingwe za choncho.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Awa ndimatsenga pang'ono ofanana ndi: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Imatembenuza chidutswa chachingwe kuti chidule pang'ono.
    /// Kuti mutembenuzire chidutswacho kukhala chidutswa cha zingwe, gwiritsani ntchito ntchito ya [`from_utf8`].
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // CHITETEZO: mawu a const chifukwa timasinthitsa mitundu iwiri chimodzimodzi
        unsafe { mem::transmute(self) }
    }

    /// Imatembenuza chidutswa chachingwe chosinthika kukhala kagawo kakang'ono kosinthidwa.
    ///
    /// # Safety
    ///
    /// Woyimbirayo akuyenera kuwonetsetsa kuti zomwe zili pagawolo ndizovomerezeka UTF-8 ngongole isanathe komanso `str` yoyambira isanagwiritsidwe ntchito.
    ///
    ///
    /// Kugwiritsa ntchito `str` yomwe zolemba zake sizolondola UTF-8 ndizosadziwika.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // CHITETEZO: osewera kuchokera ku `&str` mpaka `&[u8]` ndiotetezeka kuyambira `str`
        // ili ndi mawonekedwe ofanana ndi `&[u8]` (ndi libstd okha omwe angapangitse chitsimikizo ichi).
        // Kufufuzira kwa pointer ndikotetezeka chifukwa kumachokera kuzosinthika zomwe zimatsimikizika kuti ndizovomerezeka polemba.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Imatembenuza kagawo ka chingwe kupita pa pointer yaiwisi.
    ///
    /// Monga zingwe zazingwe ndi chidutswa cha mabayiti, cholozera chobiriwira chimaloza ku [`u8`].
    /// Cholozera ichi chikhala chikulozera pachidole choyamba cha chidacho.
    ///
    /// Woyimbirayo ayenera kuwonetsetsa kuti cholembera chomwe chabwezedwacho sichinalembedwe.
    /// Ngati mukufuna kusintha zomwe zili mchingwe, gwiritsani ntchito [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Imatembenuza chidutswa chachingwe chosunthika kukhala cholembera chosaphika.
    ///
    /// Monga zingwe zazingwe ndi chidutswa cha mabayiti, cholozera chobiriwira chimaloza ku [`u8`].
    /// Cholozera ichi chikhala chikulozera pachidole choyamba cha chidacho.
    ///
    /// Ndiudindo wanu kuwonetsetsa kuti chidutswa chachingwe chimangosinthidwa m'njira yoti ikhalebe yovomerezeka UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Kubwezeretsa subslice ya `str`.
    ///
    /// Imeneyi ndi njira yosadandaula pakulemba `str`.
    /// Kubwezeretsa [`None`] nthawi iliyonse momwe indexing ingagwiritsire ntchito panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // ma indices osati pamalire a UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // kunja kwa malire
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Kubwezeretsa kusintha kosinthika kwa `str`.
    ///
    /// Imeneyi ndi njira yosadandaula pakulemba `str`.
    /// Kubwezeretsa [`None`] nthawi iliyonse momwe indexing ingagwiritsire ntchito panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // kutalika kolondola
    /// assert!(v.get_mut(0..5).is_some());
    /// // kunja kwa malire
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Kubwezeretsa subschice yosasinthidwa ya `str`.
    ///
    /// Imeneyi ndiyo njira yosatsimikizika yolozera `str`.
    ///
    /// # Safety
    ///
    /// Oyimbira ntchitoyi ali ndi udindo woti izi zakwaniritsidwa:
    ///
    /// * Mndandanda woyambira sayenera kupitirira index;
    /// * Zolemba ziyenera kukhala m'malire a kagawo koyambirira;
    /// * Ma index akuyenera kukhala pamalire a UTF-8.
    ///
    /// Polephera izi, chidutswa chachingwe chomwe chabwezedwacho chitha kutanthauza kukumbukira kosayenera kapena kuphwanya zinthu zonse zomwe zimafotokozedwa ndi mtundu wa `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wachitetezo wa `get_unchecked`;
        // chidutswacho sichingasinthidwe chifukwa `self` ndiyotetezedwa.
        // Cholozera chobwezeretsedwacho ndichabwino chifukwa ma impls a `SliceIndex` akuyenera kutsimikizira kuti ndi.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Kubwezera gawo losinthika, losasunthika la `str`.
    ///
    /// Imeneyi ndiyo njira yosatsimikizika yolozera `str`.
    ///
    /// # Safety
    ///
    /// Oyimbira ntchitoyi ali ndi udindo woti izi zakwaniritsidwa:
    ///
    /// * Mndandanda woyambira sayenera kupitirira index;
    /// * Zolemba ziyenera kukhala m'malire a kagawo koyambirira;
    /// * Ma index akuyenera kukhala pamalire a UTF-8.
    ///
    /// Polephera izi, chidutswa chachingwe chomwe chabwezedwacho chitha kutanthauza kukumbukira kosayenera kapena kuphwanya zinthu zonse zomwe zimafotokozedwa ndi mtundu wa `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wachitetezo wa `get_unchecked_mut`;
        // chidutswacho sichingasinthidwe chifukwa `self` ndiyotetezedwa.
        // Cholozera chobwezeretsedwacho ndichabwino chifukwa ma impls a `SliceIndex` akuyenera kutsimikizira kuti ndi.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Pangani kagawo ka zingwe kuchokera pagawo lina la chingwe, ndikudutsa macheke achitetezo.
    ///
    /// Izi sizikulimbikitsidwa, gwiritsani ntchito mosamala!Kuti mupeze njira ina yotetezeka onani [`str`] ndi [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Kagawo katsopanoka kamachokera ku `begin` kupita ku `end`, kuphatikiza `begin` koma kupatula `end`.
    ///
    /// Kuti mutenge chingwe chosinthika m'malo mwake, onani njira ya [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Oyimbira ntchitoyi ali ndi udindo woti zinthu zitatu zoyambilira zikwaniritsidwe:
    ///
    /// * `begin` sayenera kupitirira `end`.
    /// * `begin` ndipo `end` iyenera kukhala yolowa mkati mwa chingwecho.
    /// * `begin` ndipo `end` iyenera kukhala pamalire a UTF-8.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wachitetezo wa `get_unchecked`;
        // chidutswacho sichingasinthidwe chifukwa `self` ndiyotetezedwa.
        // Cholozera chobwezeretsedwacho ndichabwino chifukwa ma impls a `SliceIndex` akuyenera kutsimikizira kuti ndi.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Pangani kagawo ka zingwe kuchokera pagawo lina la chingwe, ndikudutsa macheke achitetezo.
    /// Izi sizikulimbikitsidwa, gwiritsani ntchito mosamala!Kuti mupeze njira ina yotetezeka onani [`str`] ndi [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Kagawo katsopanoka kamachokera ku `begin` kupita ku `end`, kuphatikiza `begin` koma kupatula `end`.
    ///
    /// Kuti mutenge chingwe chosasinthika m'malo mwake, onani njira ya [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Oyimbira ntchitoyi ali ndi udindo woti zinthu zitatu zoyambilira zikwaniritsidwe:
    ///
    /// * `begin` sayenera kupitirira `end`.
    /// * `begin` ndipo `end` iyenera kukhala yolowa mkati mwa chingwecho.
    /// * `begin` ndipo `end` iyenera kukhala pamalire a UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wachitetezo wa `get_unchecked_mut`;
        // chidutswacho sichingasinthidwe chifukwa `self` ndiyotetezedwa.
        // Cholozera chobwezeretsedwacho ndichabwino chifukwa ma impls a `SliceIndex` akuyenera kutsimikizira kuti ndi.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Gawani chidutswa chimodzi cha chingwe muwiri pa index.
    ///
    /// Chotsutsanacho, `mid`, chikuyenera kukhala cholandila poyambira chingwe.
    /// Iyeneranso kukhala pamalire a UTF-8 code point.
    ///
    /// Magawo awiri abwerera amapita kuyambira koyambira kwa chingwe kupita ku `mid`, komanso kuchokera ku `mid` mpaka kumapeto kwa chingwecho.
    ///
    /// Kuti mutenge zingwe zosinthika m'malo mwake, onani njira ya [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics ngati `mid` sichili pamalire a UTF-8, kapena ngati yatha kumapeto kwa mfundo yomaliza ya chingwecho.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary imafufuza kuti index ili mu [0, .len()]
        if self.is_char_boundary(mid) {
            // CHITETEZO: tangowona kuti `mid` ili pamalire a char.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Gawani chidutswa chimodzi cha chingwe chosinthika muwiri pa index.
    ///
    /// Chotsutsanacho, `mid`, chikuyenera kukhala cholandila poyambira chingwe.
    /// Iyeneranso kukhala pamalire a UTF-8 code point.
    ///
    /// Magawo awiri abwerera amapita kuyambira koyambira kwa chingwe kupita ku `mid`, komanso kuchokera ku `mid` mpaka kumapeto kwa chingwecho.
    ///
    /// Kuti mupeze zingwe zosasinthika m'malo mwake, onani njira ya [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics ngati `mid` sichili pamalire a UTF-8, kapena ngati yatha kumapeto kwa mfundo yomaliza ya chingwecho.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary imafufuza kuti index ili mu [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // CHITETEZO: tangowona kuti `mid` ili pamalire a char.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Imabwezeretsa chojambulira pamagawo a [`char`] a chingwe.
    ///
    /// Monga kagawo ka zingwe kali ndi UTF-8 yovomerezeka, titha kuyendetsa pakati pa chingwe ndi [`char`].
    /// Njirayi imabwezeretsa oterewa.
    ///
    /// Ndikofunika kukumbukira kuti [`char`] imayimira Unicode Scalar Value, ndipo siyingafanane ndi malingaliro anu a 'character'.
    ///
    /// Kusintha pamitundu yama grapheme kungakhale zomwe mukufunadi.
    /// Ntchitoyi siyoperekedwa ndi laibulale ya Rust, onani crates.io m'malo mwake.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Kumbukirani, ["char"] sangafanane ndi chidziwitso chanu chokhudza otchulidwa:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // osati 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Kubwezeretsa chojambulira pa [`char`] za chingwe, ndi malo awo.
    ///
    /// Monga kagawo ka zingwe kali ndi UTF-8 yovomerezeka, titha kuyendetsa pakati pa chingwe ndi [`char`].
    /// Njirayi imabwezeretsa owerengera onsewa [`char`] s, komanso maudindo awo.
    ///
    /// Iterator imatulutsa zochulukira.Udindo ndi woyamba, [`char`] ndiyachiwiri.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Kumbukirani, ["char"] sangafanane ndi chidziwitso chanu chokhudza otchulidwa:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // osati (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // zindikirani 3 apa, munthu womaliza adatenga ma byte awiri
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Cholemba pamatayala a chingwe.
    ///
    /// Monga chidutswa cha zingwe chimakhala ndi mabatani angapo, titha kuyendetsa pang'onopang'ono.
    /// Njirayi imabwezeretsa oterewa.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Kugawa chidutswa cha chingwe ndi whitespace.
    ///
    /// Iterator yobwezeretsanso idzabwezera zingwe zazingwe zomwe zili zing'onozing'ono za chidutswa choyambirira cha zingwe, zolekanitsidwa ndi whitespace iliyonse.
    ///
    ///
    /// 'Whitespace' imafotokozedwa molingana ndi Unicode Derives Core Property `White_Space`.
    /// Ngati mukungofuna kugawanika pa whitespace ya ASCII m'malo mwake, gwiritsani ntchito [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Mitundu yonse yoyera imaganiziridwa:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Kugawanitsa chidutswa cha chingwe ndi malo oyera a ASCII.
    ///
    /// Iterator yobwerera idzabwezera zingwe zazingwe zomwe zili zing'onozing'ono za chidutswa choyambirira cha chingwe, chosiyanitsidwa ndi whitespace iliyonse ya ASCII.
    ///
    ///
    /// Kuti mugawane ndi Unicode `Whitespace` m'malo mwake, gwiritsani ntchito [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Mitundu yonse ya malo oyera a ASCII amawerengedwa:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Cholemba pamizere ya zingwe, ngati zingwe zazingwe.
    ///
    /// Mizere imamalizidwa ndi XlineUM (`\n`) yatsopano kapena kubwerera kwa chonyamulira ndi chakudya chamizere (`\r\n`).
    ///
    /// Kutha komaliza komaliza ndikosankha.
    /// Chingwe chomwe chimatha ndikumaliza komaliza chimabwezeretsa mizere yofanana ndi chingwe chofananira popanda mzere womaliza.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Kutha komaliza sikofunikira:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Cholemba pamizere ya chingwe.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Imabwezeretsa iterator ya `u16` pa chingwe chomwe chidasungidwa ngati UTF-16.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Kubwezeretsa `true` ngati mtundu womwe wapatsidwa ukugwirizana ndi kagawo kakang'ono ka chingwechi.
    ///
    /// Kubwezeretsa `false` ngati sikutero.
    ///
    /// [pattern] ikhoza kukhala `&str`, [`char`], kagawo ka [`char`] s, kapena ntchito kapena kutseka komwe kumatsimikizira ngati mawonekedwe amafanana.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Kubwezeretsa `true` ngati mtundu womwe wapatsidwa ukugwirizana ndi choyambirira cha kagawo aka.
    ///
    /// Kubwezeretsa `false` ngati sikutero.
    ///
    /// [pattern] ikhoza kukhala `&str`, [`char`], kagawo ka [`char`] s, kapena ntchito kapena kutseka komwe kumatsimikizira ngati mawonekedwe amafanana.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Kubwezeretsa `true` ngati mtundu womwe wapatsidwa ukugwirizana ndi chokwanira cha kagawo aka.
    ///
    /// Kubwezeretsa `false` ngati sikutero.
    ///
    /// [pattern] ikhoza kukhala `&str`, [`char`], kagawo ka [`char`] s, kapena ntchito kapena kutseka komwe kumatsimikizira ngati mawonekedwe amafanana.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Kubwezeretsa index ya byte yamtundu woyamba wa chingwe ichi chomwe chikufanana ndi ndondomekoyi.
    ///
    /// Kubwezeretsa [`None`] ngati mawonekedwe sakugwirizana.
    ///
    /// [pattern] ikhoza kukhala `&str`, [`char`], kagawo ka [`char`] s, kapena ntchito kapena kutseka komwe kumatsimikizira ngati mawonekedwe amafanana.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Zitsanzo zosavuta:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Njira zovuta kugwiritsa ntchito kalembedwe kosatsekera komanso kutseka:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Osapeza chitsanzocho:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Kubwezeretsa cholozera cha byte pamtundu woyamba wamasewera oyenerera kwambiri pazingwe zazingwe izi.
    ///
    /// Kubwezeretsa [`None`] ngati mawonekedwe sakugwirizana.
    ///
    /// [pattern] ikhoza kukhala `&str`, [`char`], kagawo ka [`char`] s, kapena ntchito kapena kutseka komwe kumatsimikizira ngati mawonekedwe amafanana.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Zitsanzo zosavuta:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Mitundu yovuta kwambiri ndikutseka:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Osapeza chitsanzocho:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Chojambulira pazingwe zazingwe zazingwe izi, zolekanitsidwa ndi zilembo zofananira ndi pulogalamu.
    ///
    /// [pattern] ikhoza kukhala `&str`, [`char`], kagawo ka [`char`] s, kapena ntchito kapena kutseka komwe kumatsimikizira ngati mawonekedwe amafanana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Khalidwe la Iterator
    ///
    /// Iterator yobwezeretsayo idzakhala [`DoubleEndedIterator`] ngati pulogalamuyo ikuloleza kusaka ndikusaka forward/reverse kumabweretsa zinthu zomwezo.
    /// Izi ndizowona, mwachitsanzo, [`char`], koma osati `&str`.
    ///
    /// Ngati pulogalamuyo imalola kusakanso koma zotsatira zake zitha kukhala zosiyana ndi kafukufuku wakutsogolo, njira ya [`rsplit`] itha kugwiritsidwa ntchito.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Zitsanzo zosavuta:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Ngati pulogalamuyo ndi kagawidwe kazitsulo, gawanikani nthawi iliyonse ya otchulidwa:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Njira yovuta kwambiri, pogwiritsa ntchito kutseka:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Ngati chingwe chili ndi olekanitsa angapo, mutha kukhala ndi zingwe zopanda kanthu:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Olekanitsa omwe amadziwika amasiyana ndi chingwe chopanda kanthu.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Olekanitsa poyambira kapena kumapeto kwa chingwe amakhala moyandikana ndi zingwe zopanda kanthu.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Chingwe chopanda kanthu chikamagwiritsidwa ntchito ngati cholekanitsa, chimasiyanitsa mtundu uliwonse wazingwezo, komanso poyambira ndi kumapeto kwa chingwecho.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Odzipatula modzidzimutsa atha kubweretsa zodabwitsa pamene whitespace imagwiritsidwa ntchito ngati olekanitsa.Nambala iyi ndi yolondola:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Zimakupatsani _not_:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Gwiritsani ntchito [`split_whitespace`] pamakhalidwe awa.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Chojambulira pazingwe zazingwe zazingwe izi, zolekanitsidwa ndi zilembo zofananira ndi pulogalamu.
    /// Zosiyana ndi iterator yopangidwa ndi `split` mu `split_inclusive` imasiya gawo lofananalo ngati terminator ya gawo.
    ///
    ///
    /// [pattern] ikhoza kukhala `&str`, [`char`], kagawo ka [`char`] s, kapena ntchito kapena kutseka komwe kumatsimikizira ngati mawonekedwe amafanana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Ngati chinthu chomaliza cha chingwe chikufanana, chinthucho chidzawerengedwa ngati chomaliza cha gawo lapitalo.
    /// Substring imeneyo ndiye chinthu chomaliza chomwe wobwezeretsayo adzabwezeretse.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Chojambulira pamizere yaying'ono ya chingwe chomwe chapatsidwa, chosiyanitsidwa ndi zilembo zofananira ndi pulogalamu ndikupereka dongosolo lotsatizana.
    ///
    /// [pattern] ikhoza kukhala `&str`, [`char`], kagawo ka [`char`] s, kapena ntchito kapena kutseka komwe kumatsimikizira ngati mawonekedwe amafanana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Khalidwe la Iterator
    ///
    /// Iterator yobwezeretsedwayo imafunikira kuti pulogalamuyo igwirizane ndi kusakanso, ndipo ikhala [`DoubleEndedIterator`] ngati kusaka kwa forward/reverse kumatulutsa zomwezo.
    ///
    ///
    /// Poyendetsa kutsogolo, njira ya [`split`] itha kugwiritsidwa ntchito.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Zitsanzo zosavuta:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Njira yovuta kwambiri, pogwiritsa ntchito kutseka:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Cholemba pamizere yaying'ono ya chingwe chomwe chapatsidwa, chosiyanitsidwa ndi zilembo zofananira ndi pulogalamu.
    ///
    /// [pattern] ikhoza kukhala `&str`, [`char`], kagawo ka [`char`] s, kapena ntchito kapena kutseka komwe kumatsimikizira ngati mawonekedwe amafanana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Zofanana ndi [`split`], kupatula kuti mzere wotsata umadumpha ngati ulibe kanthu.
    ///
    /// [`split`]: str::split
    ///
    /// Njirayi itha kugwiritsidwa ntchito pazosanja zomwe ndi _terminated_, m'malo mwa _separated_ ndi pulogalamu.
    ///
    /// # Khalidwe la Iterator
    ///
    /// Iterator yobwezeretsayo idzakhala [`DoubleEndedIterator`] ngati pulogalamuyo ikuloleza kusaka ndikusaka forward/reverse kumabweretsa zinthu zomwezo.
    /// Izi ndizowona, mwachitsanzo, [`char`], koma osati `&str`.
    ///
    /// Ngati pulogalamuyo imalola kusakanso koma zotsatira zake zitha kukhala zosiyana ndi kafukufuku wakutsogolo, njira ya [`rsplit_terminator`] itha kugwiritsidwa ntchito.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Cholemba pamasamba a `self`, olekanitsidwa ndi zilembo zofananira ndi pulogalamu ndikupereka dongosolo lotsatizana.
    ///
    /// [pattern] ikhoza kukhala `&str`, [`char`], kagawo ka [`char`] s, kapena ntchito kapena kutseka komwe kumatsimikizira ngati mawonekedwe amafanana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Zofanana ndi [`split`], kupatula kuti mzere wotsata umadumpha ngati ulibe kanthu.
    ///
    /// [`split`]: str::split
    ///
    /// Njirayi itha kugwiritsidwa ntchito pazosanja zomwe ndi _terminated_, m'malo mwa _separated_ ndi pulogalamu.
    ///
    /// # Khalidwe la Iterator
    ///
    /// Iterator yobwezeretsedwayo imafunikira kuti pulogalamuyo igwirizane ndi kusaka kosinthika, ndipo idzatha kawiri ngati kusaka kwa forward/reverse kutulutsa zinthu zomwezo.
    ///
    ///
    /// Poyendetsa kutsogolo, njira ya [`split_terminator`] itha kugwiritsidwa ntchito.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Chojambulira pazingwe zazingwe zazingwe zomwe zapatsidwa, zolekanitsidwa ndi pulogalamu, zimangolekezera kubwerera kuzinthu zambiri za `n`.
    ///
    /// Ngati zingwe za `n` zibwezeredwa, gawo lomaliza (`n`th substring) lidzakhala ndi chingwe chotsalacho.
    ///
    /// [pattern] ikhoza kukhala `&str`, [`char`], kagawo ka [`char`] s, kapena ntchito kapena kutseka komwe kumatsimikizira ngati mawonekedwe amafanana.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Khalidwe la Iterator
    ///
    /// Iterator yobwezeretsedwayo sidzatha kawiri, chifukwa siyothandiza kuthandizira.
    ///
    /// Ngati pulogalamuyo imalola kusakanso, njira ya [`rsplitn`] itha kugwiritsidwa ntchito.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Zitsanzo zosavuta:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Njira yovuta kwambiri, pogwiritsa ntchito kutseka:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Chojambulira pazingwe zazingwe zazingwe izi, zolekanitsidwa ndi dongosolo, kuyambira kumapeto kwa chingwe, choletsa kubwerera pazinthu zambiri za `n`.
    ///
    ///
    /// Ngati zingwe za `n` zibwezeredwa, gawo lomaliza (`n`th substring) lidzakhala ndi chingwe chotsalacho.
    ///
    /// [pattern] ikhoza kukhala `&str`, [`char`], kagawo ka [`char`] s, kapena ntchito kapena kutseka komwe kumatsimikizira ngati mawonekedwe amafanana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Khalidwe la Iterator
    ///
    /// Iterator yobwezeretsedwayo sidzatha kawiri, chifukwa siyothandiza kuthandizira.
    ///
    /// Pogawanika kuchokera kutsogolo, njira ya [`splitn`] ingagwiritsidwe ntchito.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Zitsanzo zosavuta:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Njira yovuta kwambiri, pogwiritsa ntchito kutseka:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Amagawaniza chingwecho poyambira koyamba kwa delimiter ndikubwezera choyambirira patsogolo pa delimiter ndi suffix pambuyo pa delimiter.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Amagawa chingwe kumapeto komaliza kwa delimiter ndikubwezera choyambirira patsogolo pa delimiter ndi suffix pambuyo pa delimiter.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Chojambulira pamasewera osalumikizana amtundu wa chingwe chomwe chapatsidwa.
    ///
    /// [pattern] ikhoza kukhala `&str`, [`char`], kagawo ka [`char`] s, kapena ntchito kapena kutseka komwe kumatsimikizira ngati mawonekedwe amafanana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Khalidwe la Iterator
    ///
    /// Iterator yobwezeretsayo idzakhala [`DoubleEndedIterator`] ngati pulogalamuyo ikuloleza kusaka ndikusaka forward/reverse kumabweretsa zinthu zomwezo.
    /// Izi ndizowona, mwachitsanzo, [`char`], koma osati `&str`.
    ///
    /// Ngati pulogalamuyo imalola kusakanso koma zotsatira zake zitha kukhala zosiyana ndi kafukufuku wakutsogolo, njira ya [`rmatches`] itha kugwiritsidwa ntchito.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Chojambulira pamasewera osalumikizana amtundu wa chingwechi, adapereka motsutsana.
    ///
    /// [pattern] ikhoza kukhala `&str`, [`char`], kagawo ka [`char`] s, kapena ntchito kapena kutseka komwe kumatsimikizira ngati mawonekedwe amafanana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Khalidwe la Iterator
    ///
    /// Iterator yobwezeretsedwayo imafunikira kuti pulogalamuyo igwirizane ndi kusakanso, ndipo ikhala [`DoubleEndedIterator`] ngati kusaka kwa forward/reverse kumatulutsa zomwezo.
    ///
    ///
    /// Poyendetsa kutsogolo, njira ya [`matches`] itha kugwiritsidwa ntchito.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Chojambulira pamasewera osalumikizana amtundu wa chingwechi komanso index yomwe machesi amayamba.
    ///
    /// Kwa machesi a `pat` mkati mwa `self` omwe amapezeka, ma indices okhawo ofanana ndi masewera oyamba amabwezedwa.
    ///
    /// [pattern] ikhoza kukhala `&str`, [`char`], kagawo ka [`char`] s, kapena ntchito kapena kutseka komwe kumatsimikizira ngati mawonekedwe amafanana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Khalidwe la Iterator
    ///
    /// Iterator yobwezeretsayo idzakhala [`DoubleEndedIterator`] ngati pulogalamuyo ikuloleza kusaka ndikusaka forward/reverse kumabweretsa zinthu zomwezo.
    /// Izi ndizowona, mwachitsanzo, [`char`], koma osati `&str`.
    ///
    /// Ngati pulogalamuyo imalola kusakanso koma zotsatira zake zitha kukhala zosiyana ndi kafukufuku wakutsogolo, njira ya [`rmatch_indices`] itha kugwiritsidwa ntchito.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // `aba` yoyamba yokha
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Iterator pamasewera osalumikizana amkati mwa `self`, adatsatiridwa motsutsana ndi index ya machesi.
    ///
    /// Kwa machesi a `pat` mkati mwa `self` omwe amapezeka, ma indices okha ofanana ndi masewera omaliza amabwezedwa.
    ///
    /// [pattern] ikhoza kukhala `&str`, [`char`], kagawo ka [`char`] s, kapena ntchito kapena kutseka komwe kumatsimikizira ngati mawonekedwe amafanana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Khalidwe la Iterator
    ///
    /// Iterator yobwezeretsedwayo imafunikira kuti pulogalamuyo igwirizane ndi kusakanso, ndipo ikhala [`DoubleEndedIterator`] ngati kusaka kwa forward/reverse kumatulutsa zomwezo.
    ///
    ///
    /// Poyendetsa kutsogolo, njira ya [`match_indices`] itha kugwiritsidwa ntchito.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // `aba` yomaliza yokha
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Kubwezeretsa chidutswa cha chingwe ndikuchotsa choyera komanso kutsogolera.
    ///
    /// 'Whitespace' imafotokozedwa molingana ndi Unicode Derives Core Property `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Kubwezeretsa chidutswa cha chingwe ndikutulutsa bwalo loyera.
    ///
    /// 'Whitespace' imafotokozedwa molingana ndi Unicode Derives Core Property `White_Space`.
    ///
    /// # Kutsata mawu
    ///
    /// Chingwe ndi mndandanda wa mabayiti.
    /// `start` potanthauza izi amatanthauza malo oyamba amtunduwu;kwa chilankhulo chakumanzere kumanja ngati Chingerezi kapena Chirasha, ili lidzakhala lamanzere, ndipo zilankhulo zakumanja kumanzere ngati Chiarabu kapena Chiheberi, ili lidzakhala lamanja.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Kubwezeretsa chidutswa cha chingwe ndikuchotsa whitespace.
    ///
    /// 'Whitespace' imafotokozedwa molingana ndi Unicode Derives Core Property `White_Space`.
    ///
    /// # Kutsata mawu
    ///
    /// Chingwe ndi mndandanda wa mabayiti.
    /// `end` potanthauza izi amatanthauza malo omaliza a chingwecho;kwa chilankhulo chakumanzere kupita kumanja ngati Chingerezi kapena Chirasha, uku kudzakhala mbali yakumanja, ndipo zilankhulo zakumanja kumanzere ngati Chiarabu kapena Chiheberi, ili lidzakhala lamanzere.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Kubwezeretsa chidutswa cha chingwe ndikutulutsa bwalo loyera.
    ///
    /// 'Whitespace' imafotokozedwa molingana ndi Unicode Derives Core Property `White_Space`.
    ///
    /// # Kutsata mawu
    ///
    /// Chingwe ndi mndandanda wa mabayiti.
    /// 'Left' potanthauza izi amatanthauza malo oyamba amtunduwu;pachilankhulo ngati Chiarabu kapena Chiheberi chomwe chiri 'kumanja kumanzere' osati 'kumanzere kupita kumanja', ili lidzakhala mbali ya _right_, osati kumanzere.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Kubwezeretsa chidutswa cha chingwe ndikuchotsa whitespace.
    ///
    /// 'Whitespace' imafotokozedwa molingana ndi Unicode Derives Core Property `White_Space`.
    ///
    /// # Kutsata mawu
    ///
    /// Chingwe ndi mndandanda wa mabayiti.
    /// 'Right' potanthauza izi amatanthauza malo omaliza a chingwecho;pachilankhulo ngati Chiarabu kapena Chiheberi chomwe chiri 'kumanja kumanzere' osati 'kumanzere kupita kumanja', ili lidzakhala mbali ya _left_, osati kumanja.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Imabwezera chidutswa chachingwe chokhala ndi zoyambira zonse ndi zomasulira zomwe zimagwirizana ndi mtundu womwe wachotsedwa mobwerezabwereza.
    ///
    /// [pattern] ikhoza kukhala [`char`], kagawo ka [`char`] s, kapena ntchito kapena kutseka komwe kumatsimikizira ngati mawonekedwe amafanana.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Zitsanzo zosavuta:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Njira yovuta kwambiri, pogwiritsa ntchito kutseka:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Kumbukirani machesi akale kwambiri, konzani pansipa ngati
            // masewera omaliza ndi osiyana
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // CHITETEZO: `Searcher` imadziwika kuti ikubwezeretsanso magawo oyenera.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Imabwezera chidutswa chachingwe chokhala ndi zoyambira zonse zomwe zimagwirizana ndi mtundu womwe wachotsedwa mobwerezabwereza.
    ///
    /// [pattern] ikhoza kukhala `&str`, [`char`], kagawo ka [`char`] s, kapena ntchito kapena kutseka komwe kumatsimikizira ngati mawonekedwe amafanana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Kutsata mawu
    ///
    /// Chingwe ndi mndandanda wa mabayiti.
    /// `start` potanthauza izi amatanthauza malo oyamba amtunduwu;kwa chilankhulo chakumanzere kumanja ngati Chingerezi kapena Chirasha, ili lidzakhala lamanzere, ndipo zilankhulo zakumanja kumanzere ngati Chiarabu kapena Chiheberi, ili lidzakhala lamanja.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // CHITETEZO: `Searcher` imadziwika kuti ikubwezeretsanso magawo oyenera.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Kubwezeretsa chidutswa cha chingwe ndikutulutsa koyambirira.
    ///
    /// Ngati chingwecho chimayamba ndi mtundu `prefix`, chimabweretsanso gawo limodzi pambuyo pa manambala oyamba, wokutidwa ndi `Some`.
    /// Mosiyana ndi `trim_start_matches`, njirayi imachotsa koyambirira kamodzi chimodzimodzi.
    ///
    /// Ngati chingwe sichimayamba ndi `prefix`, chimabwezeretsa `None`.
    ///
    /// [pattern] ikhoza kukhala `&str`, [`char`], kagawo ka [`char`] s, kapena ntchito kapena kutseka komwe kumatsimikizira ngati mawonekedwe amafanana.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Kubwezera chidutswa cha chingwe ndikumachotsa chinacho.
    ///
    /// Ngati chingwecho chimatha ndi mtundu wa `suffix`, chimabweza chingwecho chisanafike chokwanira, chokutidwa ndi `Some`.
    /// Mosiyana ndi `trim_end_matches`, njirayi imachotsa cholembacho kamodzi.
    ///
    /// Ngati chingwe sichitha ndi `suffix`, chimabwezeretsa `None`.
    ///
    /// [pattern] ikhoza kukhala `&str`, [`char`], kagawo ka [`char`] s, kapena ntchito kapena kutseka komwe kumatsimikizira ngati mawonekedwe amafanana.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Imabwezeretsa chidutswa chachingwe chokhala ndi zolemetsa zonse zomwe zimagwirizana ndi mtundu womwe wachotsedwa mobwerezabwereza.
    ///
    /// [pattern] ikhoza kukhala `&str`, [`char`], kagawo ka [`char`] s, kapena ntchito kapena kutseka komwe kumatsimikizira ngati mawonekedwe amafanana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Kutsata mawu
    ///
    /// Chingwe ndi mndandanda wa mabayiti.
    /// `end` potanthauza izi amatanthauza malo omaliza a chingwecho;kwa chilankhulo chakumanzere kupita kumanja ngati Chingerezi kapena Chirasha, uku kudzakhala mbali yakumanja, ndipo zilankhulo zakumanja kumanzere ngati Chiarabu kapena Chiheberi, ili lidzakhala lamanzere.
    ///
    ///
    /// # Examples
    ///
    /// Zitsanzo zosavuta:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Njira yovuta kwambiri, pogwiritsa ntchito kutseka:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // CHITETEZO: `Searcher` imadziwika kuti ikubwezeretsanso magawo oyenera.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Imabwezera chidutswa chachingwe chokhala ndi zoyambira zonse zomwe zimagwirizana ndi mtundu womwe wachotsedwa mobwerezabwereza.
    ///
    /// [pattern] ikhoza kukhala `&str`, [`char`], kagawo ka [`char`] s, kapena ntchito kapena kutseka komwe kumatsimikizira ngati mawonekedwe amafanana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Kutsata mawu
    ///
    /// Chingwe ndi mndandanda wa mabayiti.
    /// 'Left' potanthauza izi amatanthauza malo oyamba amtunduwu;pachilankhulo ngati Chiarabu kapena Chiheberi chomwe chiri 'kumanja kumanzere' osati 'kumanzere kupita kumanja', ili lidzakhala mbali ya _right_, osati kumanzere.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Imabwezeretsa chidutswa chachingwe chokhala ndi zolemetsa zonse zomwe zimagwirizana ndi mtundu womwe wachotsedwa mobwerezabwereza.
    ///
    /// [pattern] ikhoza kukhala `&str`, [`char`], kagawo ka [`char`] s, kapena ntchito kapena kutseka komwe kumatsimikizira ngati mawonekedwe amafanana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Kutsata mawu
    ///
    /// Chingwe ndi mndandanda wa mabayiti.
    /// 'Right' potanthauza izi amatanthauza malo omaliza a chingwecho;pachilankhulo ngati Chiarabu kapena Chiheberi chomwe chiri 'kumanja kumanzere' osati 'kumanzere kupita kumanja', ili lidzakhala mbali ya _left_, osati kumanja.
    ///
    ///
    /// # Examples
    ///
    /// Zitsanzo zosavuta:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Njira yovuta kwambiri, pogwiritsa ntchito kutseka:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Amagwiritsa ntchito chingwechi mu mtundu wina.
    ///
    /// Chifukwa `parse` ndiyofala kwambiri, imatha kuyambitsa mavuto ndi kutengera mtundu.
    /// Mwakutero, `parse` ndi imodzi mwanthawi zochepa pomwe mudzawona malembedwe mwachikondi otchedwa 'turbofish': `::<>`.
    ///
    /// Izi zimathandizira kulingalira kwamalingaliro kuti mumvetsetse mtundu womwe mukuyesera kuti mulowemo.
    ///
    /// `parse` Ikhoza kufotokozera mtundu uliwonse womwe ungagwiritse ntchito [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// Ndibweza [`Err`] ngati sizingatheke kuwerengera kagawo kakang'ono kamtundu womwe mukufuna.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Kugwiritsa ntchito kwenikweni
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Kugwiritsa ntchito 'turbofish' m'malo mofotokozera `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Kulephera kuwerengera:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Kufufuza ngati zilembo zonse zomwe zili mu chingwechi zili mkati mwa ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Titha kuchitapo kanthu pamtundu uliwonse ngati mawonekedwe apa: zilembo zonse zama multibyte zimayamba ndi byte yomwe sikupezeka mu ascii, chifukwa chake tiimilira pamenepo kale.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Kufufuza kuti zingwe ziwiri ndimasewera osaganizira a ASCII.
    ///
    /// Zofanana ndi `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, koma osagawa ndi kukopera kwakanthawi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Imatembenuza chingwechi kukhala cholowa chake cha ASCII.
    ///
    /// Makalata a ASCII 'a' mpaka 'z' ajambulidwa ku 'A' mpaka 'Z', koma zilembo zosakhala ASCII sizikusintha.
    ///
    /// Kuti mubwezere mtengo watsopano osasintha womwe ulipo, gwiritsani ntchito [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // CHITETEZO: otetezeka chifukwa timasindikiza mitundu iwiri ndi chimodzimodzi.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Imatembenuza chingwe ichi kukhala ASCII yotsika pang'ono m'malo mwake.
    ///
    /// Makalata a ASCII 'A' mpaka 'Z' ajambulidwa ku 'a' mpaka 'z', koma zilembo zosakhala ASCII sizikusintha.
    ///
    /// Kuti mubwezere mtengo watsopano wotsika popanda kusintha womwe ulipo, gwiritsani ntchito [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // CHITETEZO: otetezeka chifukwa timasindikiza mitundu iwiri ndi chimodzimodzi.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Bweretsani iterator yomwe imathawa char iliyonse mu `self` ndi [`char::escape_debug`].
    ///
    ///
    /// Note: Zowonjezera zokha za grapheme zomwe zimayambira chingwe zidzathawa.
    ///
    /// # Examples
    ///
    /// Monga iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Kugwiritsa ntchito `println!` mwachindunji:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Zonsezi ndizofanana ndi:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Kugwiritsa ntchito `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Bweretsani iterator yomwe imathawa char iliyonse mu `self` ndi [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Monga iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Kugwiritsa ntchito `println!` mwachindunji:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Zonsezi ndizofanana ndi:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Kugwiritsa ntchito `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Bweretsani iterator yomwe imathawa char iliyonse mu `self` ndi [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Monga iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Kugwiritsa ntchito `println!` mwachindunji:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Zonsezi ndizofanana ndi:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Kugwiritsa ntchito `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Pangani chingwe chopanda kanthu
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Pangani chingwe chosasinthika chopanda kanthu
    #[inline]
    fn default() -> Self {
        // CHITETEZO: Chingwe chopanda kanthu ndi chovomerezeka UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Mtundu wodziwika wa fn
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // CHITETEZO: osakhala bwino
        unsafe { from_utf8_unchecked(bytes) }
    };
}