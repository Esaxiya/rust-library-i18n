//! Njira zopangira `str` kuchokera pagawo la mabayiti.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Imatembenuza chidutswa cha mabatani kukhala chidutswa cha chingwe.
///
/// Chingwe chachingwe ([`&str`]) chimapangidwa ndi ma byte ([`u8`]), ndipo chidutswa cha byte ([`&[u8]`][byteslice]) chimapangidwa ndi ma byte, kotero ntchitoyi imasintha pakati pa ziwirizi.
/// Osati magawo onse amtundu ndi zingwe zomata, komabe: [`&str`] imafuna kuti ikhale yovomerezeka UTF-8.
/// `from_utf8()` macheke kuonetsetsa kuti mabayiti ndi ovomerezeka UTF-8, kenako amatembenuka.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Ngati mukutsimikiza kuti kagawo kakang'ono ndi kovomerezeka UTF-8, ndipo simukufuna kuti mukhale ndi chitsimikizo chotsimikizika, pali mtundu wina wosatetezeka wa ntchitoyi, [`from_utf8_unchecked`], yomwe ili ndi machitidwe omwewo koma idumpha cheke.
///
///
/// Ngati mukufuna `String` m'malo mwa `&str`, ganizirani [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Chifukwa mutha kupatula `[u8; N]`, ndipo mutha kutenga [`&[u8]`][byteslice] yake, ntchitoyi ndi njira imodzi yokhala ndi chingwe chomwe mwapatsidwa.Pali chitsanzo cha izi m'gawo lazitsanzo pansipa.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Imabwezeretsa `Err` ngati kagawo sikali UTF-8 ndikufotokozera chifukwa chake kagawo kameneka sikali UTF-8.
///
/// # Examples
///
/// Kagwiritsidwe:
///
/// ```
/// use std::str;
///
/// // ma byte ena, mu vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Tikudziwa kuti mabayiti awa ndi ovomerezeka, chifukwa chake ingogwiritsani ntchito `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Mabayiti olakwika:
///
/// ```
/// use std::str;
///
/// // ma bafa ena osavomerezeka, mu vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Onani zolemba za [`Utf8Error`] kuti mumve zambiri zamtundu wa zolakwika zomwe zingabwezeretsedwe.
///
/// "stack allocated string":
///
/// ```
/// use std::str;
///
/// // ma byte ena, mgulu logawika okwanira
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Tikudziwa kuti mabayiti awa ndi ovomerezeka, chifukwa chake ingogwiritsani ntchito `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // CHITETEZO: Kungoyendetsa kutsimikizika.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Imatembenuza chidutswa chosinthika cha mabayiti kukhala chingwe chosinthika.
///
/// # Examples
///
/// Kagwiritsidwe:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" monga chosinthika vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Monga tikudziwa kuti mabayiti awa ndi ovomerezeka, titha kugwiritsa ntchito `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Mabayiti olakwika:
///
/// ```
/// use std::str;
///
/// // Ma bafa ena osavomerezeka mu vector yosinthika
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Onani zolemba za [`Utf8Error`] kuti mumve zambiri zamtundu wa zolakwika zomwe zingabwezeretsedwe.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // CHITETEZO: Kungoyendetsa kutsimikizika.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Imatembenuza chidutswa cha mabatani kukhala chidutswa cha chingwe osayang'ana ngati chingwecho chili ndi UTF-8 yoyenera.
///
/// Onani mtundu wotetezeka, [`from_utf8`], kuti mumve zambiri.
///
/// # Safety
///
/// Ntchitoyi ndi yosatetezeka chifukwa sikuwunika ngati mabayiti omwe adadutsamo ndi UTF-8.
/// Ngati choletsedwachi chikuphwanyidwa, zotsatira zosadziwika, monga momwe Rust yonse imaganizira kuti [`&str`] s ndi UTF-8 yoyenera.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Kagwiritsidwe:
///
/// ```
/// use std::str;
///
/// // ma byte ena, mu vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // CHITETEZO: woyimbayo akuyenera kutsimikizira kuti ma byte `v` ndi UTF-8 ovomerezeka.
    // Zimadaliranso `&str` ndi `&[u8]` kukhala ndi chimodzimodzi.
    unsafe { mem::transmute(v) }
}

/// Imatembenuza chidutswa cha mabatani kukhala chidutswa cha chingwe osayang'ana ngati chingwecho chili ndi UTF-8 yoyenera;Mtundu wosinthika.
///
///
/// Onani mtundu wosasinthika, [`from_utf8_unchecked()`] kuti mumve zambiri.
///
/// # Examples
///
/// Kagwiritsidwe:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // CHITETEZO: woyimbayo akuyenera kutsimikizira kuti ma byte `v`
    // ndizovomerezeka UTF-8, chifukwa chake oponya `*mut str` ndiotetezeka.
    // Komanso, poyerekeza ndi pointer ndiyotetezeka chifukwa cholozera chimachokera pakuwunika komwe kumatsimikizika kuti ndikofunikira kulemba.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}