//! Chingwe Pattern API.
//!
//! Pattern API imapereka njira zofananira zogwiritsira ntchito mitundu yosiyanasiyana ya mapangidwe posaka chingwe.
//!
//! Kuti mumve zambiri, onani traits [`Pattern`], [`Searcher`], [`ReverseSearcher`], ndi [`DoubleEndedSearcher`].
//!
//! Ngakhale API iyi ndiyosakhazikika, imawululidwa kudzera pa APIs okhazikika pamtundu wa [`str`].
//!
//! # Examples
//!
//! [`Pattern`] ndi [implemented][pattern-impls] mu API yokhazikika ya [`&str`][`str`], [`char`], magawo a [`char`], ndikugwira ntchito ndikutseka kukhazikitsa `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // char chitsanzo
//! assert_eq!(s.find('n'), Some(2));
//! // Kagawo ka chars kachitidwe
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // kutseka kachitidwe
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Chingwe cha chingwe.
///
/// `Pattern<'a>` imafotokoza kuti mtundu wokhazikitsira utha kugwiritsidwa ntchito ngati chingwe chofufuzira mu [`&'a str`][str].
///
/// Mwachitsanzo, `'a'` ndi `"aa"` ndi mitundu yomwe ingafanane ndi index `1` mu chingwe `"baaaab"`.
///
/// trait yokha imakhala ngati womanga wa mtundu wa [`Searcher`] wogwirizana, womwe umagwira ntchito yeniyeni kuti upeze zomwe zachitika mchitsanzo.
///
///
/// Kutengera mtundu wa mawonekedwe, machitidwe amachitidwe monga [`str::find`] ndi [`str::contains`] amatha kusintha.
/// Gome ili m'munsi likufotokozera zina mwazikhalidwezi.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Wofufuza wothandizirana ndi pulogalamu iyi
    type Searcher: Searcher<'a>;

    /// Amapanga osaka omwe amagwirizana nawo kuchokera ku `self` ndi `haystack` kuti afufuze.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Ikufufuza ngati pulogalamuyo ikufanana paliponse ndi udzu
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Imafufuza ngati mtunduwo ukugwirizana kutsogolo kwa khola
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Imafufuza ngati mtunduwo ukugwirizana kumbuyo kwa udzu
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Imachotsa chitsanzocho kutsogolo kwa udzu, ngati chikufanana.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // CHITETEZO: `Searcher` imadziwika kuti ikubwezeretsanso magawo oyenera.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Imachotsa chitsanzocho kumbuyo kwa udzu, ngati chikufanana.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // CHITETEZO: `Searcher` imadziwika kuti ikubwezeretsanso magawo oyenera.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Zotsatira zoyimbira [`Searcher::next()`] kapena [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Akuwonetsa kuti machesi amtunduwu apezeka ku `haystack[a..b]`.
    ///
    Match(usize, usize),
    /// Akuwonetsa kuti `haystack[a..b]` yakanidwa ngati kuthekera kofananira kwa mtunduwo.
    ///
    /// Dziwani kuti pakhoza kukhala `Reject` yopitilira imodzi pakati pa `Match`es awiri, palibe chifukwa choti aphatikizidwe akhale amodzi.
    ///
    ///
    Reject(usize, usize),
    /// Akunena kuti aliyense wa nyumba yodyerayo adayendera, ndikumaliza kuyimba kwake.
    ///
    Done,
}

/// Wosaka patelefoni.
///
/// trait iyi imapereka njira zosaka machesi osakanikirana a mtundu kuyambira kutsogolo kwa (left) kwa chingwe.
///
/// Idzakwaniritsidwa ndi mitundu ya `Searcher` yogwirizana ya [`Pattern`] trait.
///
/// trait imadziwika kuti ndi yosatetezeka chifukwa ma indices omwe amabwezedwa ndi njira za [`next()`][Searcher::next] amafunika kuti agone pamalire a utf8 pakhomopo.
/// Izi zimathandizira ogula a trait kuti agawire udzuwo popanda kuwunikiranso nthawi yothamanga.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter kuti chingwe choyambira chifufuzidwe
    ///
    /// Nthawi zonse ndibweza [`&str`][str] yomweyo.
    fn haystack(&self) -> &'a str;

    /// Imachita chosaka chotsatira kuyambira kutsogolo.
    ///
    /// - Kubwezeretsa [`Match(a, b)`][SearchStep::Match] ngati `haystack[a..b]` ikufanana ndi ndondomekoyi.
    /// - Kubwezeretsa [`Reject(a, b)`][SearchStep::Reject] ngati `haystack[a..b]` silingafanane ndi ndondomekoyi, ngakhale pang'ono.
    /// - Imabwezeretsa [`Done`][SearchStep::Done] ngati mabowo aliwonse obwera ndi udzu adayendera.
    ///
    /// Mtsinje wa [`Match`][SearchStep::Match] ndi [`Reject`][SearchStep::Reject] wokwanira mpaka [`Done`][SearchStep::Done] ukhala ndi magawo amndandanda omwe ali moyandikana, osalumikizana, ophimba udzu wonse, ndikukhazikitsa malire a utf8.
    ///
    ///
    /// Chotsatira cha [`Match`][SearchStep::Match] chimayenera kukhala ndi mawonekedwe onse ofananirako, komabe zotsatira za [`Reject`][SearchStep::Reject] zitha kugawidwa m'magawo angapo oyandikana nawo.Magawo onse awiriwa akhoza kukhala ndi zero kutalika.
    ///
    /// Mwachitsanzo, mtundu `"aaa"` ndi haystack `"cbaaaaab"` zitha kupanga mtsinjewo
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Ikupeza zotsatira zotsatira za [`Match`][SearchStep::Match].Onani [`next()`][Searcher::next].
    ///
    /// Mosiyana ndi [`next()`][Searcher::next], palibe chitsimikizo kuti magulu omwe abwererawa ndi [`next_reject`][Searcher::next_reject] adzakwaniritsidwa.
    /// Izi zibwerera `(start_match, end_match)`, pomwe start_match ndi mndandandanda wa komwe machesi ayambira, ndipo end_match ndiye cholozera kumapeto kwa masewerawo.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Ikupeza zotsatira zotsatira za [`Reject`][SearchStep::Reject].Onani [`next()`][Searcher::next] ndi [`next_match()`][Searcher::next_match].
    ///
    /// Mosiyana ndi [`next()`][Searcher::next], palibe chitsimikizo kuti magulu omwe abwererawa ndi [`next_match`][Searcher::next_match] adzakwaniritsidwa.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Wosaka posaka patelefoni.
///
/// trait iyi imapereka njira zosaka machesi osakanikirana a mtundu kuyambira kumbuyo kwa (right) ya chingwe.
///
/// Idzakwaniritsidwa ndi mitundu ya [`Searcher`] yogwirizana ya [`Pattern`] trait ngati pulogalamuyo ikuthandizira kuyisaka kumbuyo.
///
///
/// Magawo amndandanda omwe abwezeretsedwanso ndi trait sakukakamizidwa kuti agwirizane ndendende ndi omwe amafufuza kutsogolo.
///
/// Pazifukwa zomwe trait imadziwika kuti ndi yotetezeka, onani kholo lawo trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Imachita chosaka chotsatira kuyambira kumbuyo.
    ///
    /// - Kubwezeretsa [`Match(a, b)`][SearchStep::Match] ngati `haystack[a..b]` ikufanana ndi ndondomekoyi.
    /// - Kubwezeretsa [`Reject(a, b)`][SearchStep::Reject] ngati `haystack[a..b]` silingafanane ndi ndondomekoyi, ngakhale pang'ono.
    /// - Imabwezeretsa [`Done`][SearchStep::Done] ngati mabowo aliwonse obwera ndi udzu adayendera
    ///
    /// Mtsinje wa [`Match`][SearchStep::Match] ndi [`Reject`][SearchStep::Reject] wokwanira mpaka [`Done`][SearchStep::Done] ukhala ndi magawo amndandanda omwe ali moyandikana, osalumikizana, ophimba udzu wonse, ndikukhazikitsa malire a utf8.
    ///
    ///
    /// Chotsatira cha [`Match`][SearchStep::Match] chimayenera kukhala ndi mawonekedwe onse ofananirako, komabe zotsatira za [`Reject`][SearchStep::Reject] zitha kugawidwa m'magawo angapo oyandikana nawo.Magawo onse awiriwa akhoza kukhala ndi zero kutalika.
    ///
    /// Mwachitsanzo, mtundu `"aaa"` ndi haystack `"cbaaaaab"` atha kupanga mtsinje `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Ikupeza zotsatira zotsatira za [`Match`][SearchStep::Match].
    /// Onani [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Ikupeza zotsatira zotsatira za [`Reject`][SearchStep::Reject].
    /// Onani [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Chizindikiro trait chofotokozera kuti [`ReverseSearcher`] itha kugwiritsidwa ntchito poyambitsa [`DoubleEndedIterator`].
///
/// Pachifukwa ichi, kuyika kwa [`Searcher`] ndi [`ReverseSearcher`] kuyenera kutsatira izi:
///
/// - Zotsatira zonse za `next()` zikuyenera kufanana ndi zotsatira za `next_back()` motsatizana.
/// - `next()` ndipo `next_back()` iyenera kukhala ngati malekezero awiri amitengo, ndiye kuti sangathe "walk past each other".
///
/// # Examples
///
/// `char::Searcher` ndi `DoubleEndedSearcher` chifukwa kufunafuna [`char`] kumangofunika kuyang'ana kamodzi, zomwe zimakhala chimodzimodzi kumapeto onse awiri.
///
/// `(&str)::Searcher` si `DoubleEndedSearcher` chifukwa mawonekedwe `"aa"` mu haystack `"aaa"` amafanana ngati `"[aa]a"` kapena `"a[aa]"`, kutengera mbali yomwe yasakidwa.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl ya char
/////////////////////////////////////////////////////////////////////////////

/// Mtundu wolumikizidwa wa `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // otetezera chitetezo: `finger`/`finger_back` iyenera kukhala yolondola utf8 byte index ya `haystack` Chosinthachi chitha kusweka *mkati mwa* next_match ndi next_match_back, komabe ayenera kutuluka ndi zala pamalire olondola.
    //
    //
    /// `finger` ndi index ya byte yapano pakusaka kwakatsogolo.
    /// Ingoganizirani kuti idalipo kale byte pa index yake, mwachitsanzo
    /// `haystack[finger]` ndiye chidutswa choyamba cha kagawo kamene tiyenera kuwunika tikamafufuza m'tsogolo
    ///
    finger: usize,
    /// `finger_back` ndi index ya byte yaposachedwa yakusaka kumbuyo.
    /// Ingoganizirani kuti ilipo pambuyo pa byte pa index yake, mwachitsanzo
    /// haystack [finger_back, 1] ndiye chidutswa chomaliza cha kagawo kamene tiyenera kuyang'anitsitsa posaka patsogolo (motero kotenga koyamba kuyang'aniridwa poyimba next_back()).
    ///
    finger_back: usize,
    /// Khalidwe lomwe likufufuzidwa
    needle: char,

    // chosasokoneza chitetezo: `utf8_size` iyenera kukhala yochepera 5
    /// Chiwerengero cha mabayiti `needle` chimakwera mukamatumizidwa mu utf8.
    utf8_size: usize,
    /// utf8 yolemba `needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // CHITETEZO: 1-4 chitsimikiziro cha chitetezo cha `get_unchecked`
        // 1. `self.finger` ndipo `self.finger_back` imasungidwa pamalire a unicode (izi ndizosasintha)
        // 2. `self.finger >= 0` popeza imayamba pa 0 ndipo imangowonjezeka
        // 3. `self.finger < self.finger_back` chifukwa apo ayi char `iter` ibwerera `SearchStep::Done`
        // 4.
        // `self.finger` amabwera kumapeto kwa udzu chifukwa `self.finger_back` imayamba kumapeto ndipo imangotsika
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // onjezerani zolakwika zamunthu wapano popanda kukonzanso monga utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // pezani msipu pambuyo poti munthu womaliza wapezeka
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // chomaliza chomaliza cha utf8 chosungira singano SAFETY: tili ndi chosasintha kuti `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Chala chatsopano ndi index ya byte yomwe tidapeza, kuphatikiza imodzi, popeza tidakumbukira gawo lomaliza la khalidweli.
                //
                // Dziwani kuti izi sizimatipatsa chala nthawi zonse pamalire a UTF8.
                // Ngati sitinapeze chikhalidwe chathu titha kukhala kuti tidayitanitsa cholembera chosakhala chomaliza cha 3-byte kapena 4-byte.
                // Sitingangodumpha ku cholowera chotsatira chotsatira chifukwa munthu ngati ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` atipangitsa kuti nthawi zonse tizipeza gawo lachiwiri posaka lachitatu.
                //
                //
                // Komabe, izi ndi zabwino kwambiri.
                // Ngakhale tili ndi zosasintha kuti self.finger ili pamalire a UTF8, osinthasinthawa samadaliridwa mwa njirayi (imadaliranso mu CharSearcher::next()).
                //
                // Timangotuluka munjira iyi titafika kumapeto kwa chingwe, kapena ngati tapeza china chake.Tikapeza china chake `finger` idzakhazikitsidwa pamalire a UTF8.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // sanapeze kalikonse, tulukani
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // lolani lotsatira_kukana kugwiritsa ntchito kosakhazikika kuchokera ku Searcher trait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // CHITETEZO: onani ndemanga ya next() pamwambapa
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // chotsani chotsitsa chamakhalidwe apano osakonzanso monga utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // pezani udzu mpaka osaphatikizaponso munthu womaliza yemwe wasaka
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // chomaliza chomaliza cha utf8 chosungira singano SAFETY: tili ndi chosasintha kuti `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // tafufuza chidutswa chomwe chidasinthidwa ndi self.finger, onjezerani self.finger kuti mupeze index yoyamba
                //
                let index = self.finger + index;
                // memrchr ibwezera index ya byte yomwe tikufuna kuti tipeze.
                // Pankhani ya mawonekedwe a ASCII, izi zikadakhala kuti tikulakalaka chala chathu chatsopano chikhale ("after" char char in paradigm of reverse iteration).
                //
                // Kwa mayendedwe amtundu wa multibyte tifunika kudumpha pansi ndi kuchuluka kwamabay omwe ali nawo kuposa ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // suntha chala kuti munthuyo asanapezeke (mwachitsanzo, poyambira)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Sitingagwiritse ntchito finger_back=index, size + 1 apa.
                // Ngati tapeza char yomaliza yamtundu wosiyana (kapena chapakati chapakati cha munthu wina) tifunika kugundana chala_kubwerera ku `index`.
                // Izi zimapangitsanso kuti `finger_back` isakhalenso pamalire, koma izi zili bwino popeza timangotuluka pamalirewa kapena pomwe fodyayo yafufuzidwa kwathunthu.
                //
                //
                // Mosiyana ndi next_match izi zilibe vuto lobwereza mabatire mu utf-8 chifukwa tikufufuza byte yomaliza, ndipo titha kungopeza gawo lomaliza tikamafufuza mobwerezabwereza.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // sanapeze kalikonse, tulukani
                return None;
            }
        }
    }

    // lolani next_reject_back agwiritse ntchito kukhazikitsa kosasintha kuchokera ku Searcher trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Kusaka kwazitsulo zomwe zikufanana ndi [`char`] yapatsidwa.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Impl ya kukulunga kwa MultiCharEq
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Yerekezerani kutalika kwa kagawo kakang'ono ka mkati mwa byte kuti mupeze kutalika kwa char
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Yerekezerani kutalika kwa kagawo kakang'ono ka mkati mwa byte kuti mupeze kutalika kwa char
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl ya&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Sintha/Chotsani chifukwa chosazindikirika tanthauzo.

/// Mtundu wolumikizidwa wa `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Kusaka ma chars omwe ali ofanana ndi iliyonse ya "ma char" pagawo.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl ya F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Mtundu wolumikizidwa wa `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Kusaka kwa [`char`] komwe kumagwirizana ndi chiganizo chopatsidwa.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl ya&&str
/////////////////////////////////////////////////////////////////////////////

/// Nthumwi ku `&str` impl.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl ya &str
/////////////////////////////////////////////////////////////////////////////

/// Kusaka kosagawika kwa substring.
///
/// Tidzakhala ndi mtundu wa `""` ngati wobwezera machesi opanda kanthu pamalire amtundu uliwonse.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Imafufuza ngati mtunduwo ukugwirizana kutsogolo kwa khola.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Imachotsa chitsanzocho kutsogolo kwa udzu, ngati chikufanana.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // CHITETEZO: manambala oyamba adangotsimikiziridwa kuti alipo.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Imafufuza ngati mtunduwo ukugwirizana kumbuyo kwa udzu.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Imachotsa chitsanzocho kumbuyo kwa udzu, ngati chikufanana.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // CHITETEZO: suffix idangotsimikiziridwa kuti ilipo.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Wofufuza wama Way awiri
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Mtundu wolumikizidwa wa `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // singano yopanda kanthu imakana char iliyonse ndikufanana ndi chingwe chilichonse chopanda kanthu pakati pawo
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher imapanga zovomerezeka za *Match* zomwe zimagawika m'malire malinga ngati zikugwirizana bwino ndikuti haystack ndi singano ndizovomerezeka UTF-8 *Zokana* kuchokera ku algorithm zitha kugwera pazinthu zilizonse, koma tiziwayenda pamanja kupita kumalire amtundu wotsatira, kotero kuti ali otetezeka utf-8.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // pitani kumalire otsatira char
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // lembani milandu ya `true` ndi `false` kuti mulimbikitse wophatikizira kuti apange milandu iwiri payokha.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // pitani kumalire otsatira char
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // lembani `true` ndi `false`, monga `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Mkhalidwe wamkati wazinthu ziwiri zofufuzira zosanjikiza.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// ndondomeko yofunikira kwambiri
    crit_pos: usize,
    /// cholozera chofunikira kwambiri cha singano yosinthidwa
    crit_pos_back: usize,
    period: usize,
    /// `byteset` ndikulumikiza (osati gawo la njira ziwiri);
    /// ndi 64-bit "fingerprint" pomwe chidutswa chilichonse `j` chimafanana ndi (byte&63)==j kupezeka mu singano.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// cholozera mu singano zomwe tidafanana kale
    memory: usize,
    /// index mu singano pambuyo pake yomwe takhala tikufananira kale
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Kufotokozera kosavuta kuwerengera zomwe zikuchitika pano zitha kupezeka m'buku la Crochemore ndi Rytter "Text Algorithms", mutu 13.
        // Makamaka onani nambala ya "Algorithm CP" pa p.
        // 323.
        //
        // Zomwe zikuchitika ndikuti tili ndi vuto lina lalikulu (u, v) la singano, ndipo tikufuna kudziwa ngati ndinu cholembera cha&v [.. nthawi].
        // Ngati ndi choncho, timagwiritsa ntchito "Algorithm CP1".
        // Kupanda kutero timagwiritsa ntchito "Algorithm CP2", yomwe imakwaniritsidwa nthawi ya singano ikakhala yayikulu.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // Mlandu wa nthawi yayifupi-nthawi ndiyowerengera bwino chinthu china chofunikira cha singano yosinthidwa x=u 'v' komwe | v '|<period(x).
            //
            // Izi zimathamangitsidwa ndi nthawi yomwe ikudziwika kale.
            // Dziwani kuti mulandu ngati x= "acba" utha kutumizidwa patsogolo kwenikweni (crit_pos=1, period=3) pomwe akukhala ndi nthawi yoyeserera (crit_pos=2, period=2).
            // Timagwiritsa ntchito zomwe takambiranazi koma timasunga nthawi yake.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // nthawi yayitali-tili ndi kuyerekezera nthawi yeniyeni, ndipo osagwiritsa ntchito pamtima.
            //
            //
            // Pafupifupi nthawi yonseyi mwakuchepetsa max(|u|, |v|) + 1.
            // Chofunikira kwambiri ndichofunikira kuti mugwiritse ntchito posaka komanso kutsogolo.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Dummy kufunika kutanthauza kuti nthawi yayitali
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Limodzi mwa malingaliro akulu a Two-Way ndikuti timayika singano m'magawo awiri, (u, v), ndikuyamba kuyesa kupeza v pakhomopo posanthula kumanzere kupita kumanja.
    // Ngati v ikufanana, timayesa kukufananizani ndikusanthula kumanja kupita kumanzere.
    // Kutalika kotani komwe tingadumphe tikakumana ndi zosagwirizana zonse zimadalira kuti (u, v) ndichofunikira kwambiri pa singano.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` imagwiritsa ntchito `self.position` ngati cholozera chake
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Onetsetsani kuti tili ndi malo oti tifufuze pamalo + singano_last sichitha kusefukira ngati tingaganize kuti magawo azunguliridwa ndi mtundu wa isize.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Pitani mwachangu ndi magawo akulu osagwirizana ndi gawo lathu
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Onani ngati mbali yoyenera ya singano ikugwirizana
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Onani ngati mbali yakumanzere ya singano ikugwirizana
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Tapeza machesi!
            let match_pos = self.position;

            // Note: onjezani self.period m'malo mwa needle.len() kuti mukhale ndi machesi olumikizana
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // yakhazikitsidwa ku needle.len(), self.period pamasewera olimbirana
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Ikutsatira malingaliro mu `next()`.
    //
    // Malongosoledwe ake ndi ofanana, ndi period(x) = period(reverse(x)) ndi local_period(u, v) = local_period(reverse(v), reverse(u)), ndiye ngati (u, v) ndichofunikira kwambiri, chimodzimodzi ndi (reverse(v), reverse(u)).
    //
    //
    // Kumbuyo komwe talemba zofunikira za x=u 'v' (munda `crit_pos_back`).Tifunika | u |<period(x) ya mlandu wakutsogolo motero | v '|<period(x) motsutsana.
    //
    // Kuti tifufuze mobwerezabwereza kudzera mu udzu, timayang'ana kutsogolo kudzera pa sitayala yosinthidwa ndi singano yosinthidwa, yofanana ndi u 'kenako v'.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` imagwiritsa ntchito `self.end` ngati cholozera chake-kuti `next()` ndi `next_back()` ziziyimira pawokha.
        //
        let old_end = self.end;
        'search: loop {
            // Onetsetsani kuti tili ndi malo oti tifufuze, needle.len() idzazunguliza palibenso malo, koma chifukwa cha malire a magawo satha kukulunga mpaka kutalika kwa udzu.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Pitani mwachangu ndi magawo akulu osagwirizana ndi gawo lathu
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Onani ngati mbali yakumanzere ya singano ikugwirizana
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Onani ngati mbali yoyenera ya singano ikugwirizana
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Tapeza machesi!
            let match_pos = self.end - needle.len();
            // Note: sub self.period m'malo mwa needle.len() kuti mukhale ndi masewera ofanana
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Phatikizani cholumikizira chachikulu cha `arr`.
    //
    // Chokwanira chachikulu ndichotheka kwambiri (u, v) cha `arr`.
    //
    // Returns (`i`, `p`) pomwe `i` ndiye mndandanda woyambira wa v ndi `p` ndi nyengo ya v.
    //
    // `order_greater` Ikuwona ngati dongosolo la lexical ndi `<` kapena `>`.
    // Malamulo onsewa ayenera kuwerengedwa-kuyitanitsa ndi `i` yayikulu kumapereka chofunikira kwambiri.
    //
    //
    // Kwa nthawi yayitali, nthawi yotsatirayi siyolondola (ndi yayifupi kwambiri).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Imafanana ndi i mu pepala
        let mut right = 1; // Imafanana ndi j papepalalo
        let mut offset = 0; // Imafanana ndi k papepala, koma kuyambira pa 0
        // kuti mufanane ndi indexing 0-based.
        let mut period = 1; // Imafanana ndi p papepalalo

        while let Some(&a) = arr.get(right + offset) {
            // `left` zidzakhala zowonjezereka `right` ili.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Suffix ndi yaying'ono, nthawi ndi chiyambi chonse mpaka pano.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Patsogolo pobwereza nyengo yapano.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Suffix ndi yayikulu, yambirani kuchokera pomwe pano.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Phatikizani cholumikizira chachikulu cha kumbuyo kwa `arr`.
    //
    // Chokwanira chachikulu ndichotheka kwambiri (u ', v') cha `arr`.
    //
    // Kubwezeretsa `i` pomwe `i` ndiye index yoyambira ya v ', kuchokera kumbuyo;
    // imabwerera nthawi yomweyo ikafika nthawi ya `known_period`.
    //
    // `order_greater` Ikuwona ngati dongosolo la lexical ndi `<` kapena `>`.
    // Malamulo onsewa ayenera kuwerengedwa-kuyitanitsa ndi `i` yayikulu kumapereka chofunikira kwambiri.
    //
    //
    // Kwa nthawi yayitali, nthawi yotsatirayi siyolondola (ndi yayifupi kwambiri).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Imafanana ndi i mu pepala
        let mut right = 1; // Imafanana ndi j papepalalo
        let mut offset = 0; // Imafanana ndi k papepala, koma kuyambira pa 0
        // kuti mufanane ndi indexing 0-based.
        let mut period = 1; // Imafanana ndi p papepalalo
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Suffix ndi yaying'ono, nthawi ndi chiyambi chonse mpaka pano.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Patsogolo pobwereza nyengo yapano.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Suffix ndi yayikulu, yambirani kuchokera pomwe pano.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrource imalola kuti ma algorithmwo adumphe zosagwirizana mwachangu, kapena kuti azigwira ntchito momwe imatulutsira Zokana mwachangu.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Dumphani kuti mufanane ndi nthawi mofulumira
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Emit Amakana nthawi zonse
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}