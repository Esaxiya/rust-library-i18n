use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// Kubwezeretsa `true` ngati pointer ilibe ntchito.
    ///
    /// Dziwani kuti mitundu yosafupika ili ndi zolozera zambiri zopanda tanthauzo, chifukwa cholozera chokhacho chomwe chimawerengedwa, osati kutalika kwake, vtable, ndi zina zambiri.
    /// Chifukwa chake, zolemba ziwiri zomwe sizingafanane sizingafanane mofanana.
    ///
    /// ## Khalidwe pakuwunika kwa const
    ///
    /// Ntchitoyi ikagwiritsidwa ntchito pakuwunika kwa const, itha kubweretsanso `false` kwa ma pointer omwe amakhala opanda ntchito nthawi yothamanga.
    /// Makamaka, pomwe cholozera chokumbukira china sichingafanane ndi malire ake kotero kuti cholozera chotsatira sichingachitike, ntchitoyi ibwereranso `false`.
    ///
    /// Palibe njira yoti CTFE idziwe bwino lomwe kukumbukira, chifukwa chake sitingadziwe ngati cholozera sichingachitike kapena ayi.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Yerekezerani kudzera pa cholembera kuti nizilozera pocheperako, kotero zolemba zamafuta zimangoganiza gawo lawo la "data" posachita chilichonse.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// Imatengera cholozera chamtundu wina.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// Sungani cholozera (mwina chachikulu) kukhala adilesi ndi metadata.
    ///
    /// Cholozera chitha kumangidwanso pambuyo pake ndi [`from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// Kubwezeretsa `None` ngati cholozera sichichitika, kapena ngati abwezera zomwe zagawidwa pamtengo wokutidwa ndi `Some`.Ngati mtengowo sunakhazikitsidwe, [`as_uninit_ref`] iyenera kugwiritsidwa ntchito m'malo mwake.
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// Mukamatchula njirayi, muyenera kuwonetsetsa kuti *cholozera ndi NULL* kapena * zonsezi ndi zoona:
    ///
    /// * Cholozera chiyenera kukhala chogwirizana bwino.
    ///
    /// * Iyenera kukhala "dereferencable" malinga ndi tanthauzo la [the module documentation].
    ///
    /// * Cholozera chikuyenera kuloza poyambirira cha `T`.
    ///
    /// * Muyenera kutsatira malamulo osasunthika a Rust, popeza nthawi yobwezera `'a` imasankhidwa mokha ndipo sizitanthauza nthawi yeniyeniyo ya tsambalo.
    ///   Makamaka, kwakanthawi kamoyo uno, kukumbukira komwe cholozera sikuyenera kusintha (kupatula mkati mwa `UnsafeCell`).
    ///
    /// Izi zikugwira ntchito ngakhale zotsatira za njirayi sigwiritsidwa ntchito!
    /// (Gawo loyambitsidwa silinafotokozeredwe bwino, koma mpaka lithe, njira yokhayo yotetezeka ndikuwonetsetsa kuti akhazikitsidwa.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Mtundu wosasinthidwa
    ///
    /// Ngati mukutsimikiza kuti cholozera sichingakhale chopanda pake ndipo mukuyang'ana mtundu wina wa `as_ref_unchecked` womwe umabwezeretsa `&T` m'malo mwa `Option<&T>`, dziwani kuti mutha kutanthauzira cholozera molunjika.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // CHITETEZO: woyimbayo akuyenera kutsimikizira kuti `self` ndiyovomerezeka
        // kuti muwone ngati sichingachitike.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Imabwezeretsa `None` ngati cholozera sichichitika, kapena ikabwezera zomwe zagawidwa pamtengo wokutidwa ndi `Some`.
    /// Mosiyana ndi [`as_ref`], izi sizikutanthauza kuti mtengowo uyenera kuyambitsidwa.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Mukamatchula njirayi, muyenera kuwonetsetsa kuti *cholozera ndi NULL* kapena * zonsezi ndi zoona:
    ///
    /// * Cholozera chiyenera kukhala chogwirizana bwino.
    ///
    /// * Iyenera kukhala "dereferencable" malinga ndi tanthauzo la [the module documentation].
    ///
    /// * Muyenera kutsatira malamulo osasunthika a Rust, popeza nthawi yobwezera `'a` imasankhidwa mokha ndipo sizitanthauza nthawi yeniyeniyo ya tsambalo.
    ///
    ///   Makamaka, kwakanthawi kamoyo uno, kukumbukira komwe cholozera sikuyenera kusintha (kupatula mkati mwa `UnsafeCell`).
    ///
    /// Izi zikugwira ntchito ngakhale zotsatira za njirayi sigwiritsidwa ntchito!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // CHITETEZO: woyimbayo ayenera kutsimikizira kuti `self` ikwaniritsa zonse
        // zofunikira pakuwunika.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Kuwerengetsa zolowa kuchokera pacholozera.
    ///
    /// `count` ali mgulu la T;Mwachitsanzo, `count` ya 3 imayimira cholozera cha ma `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Ngati izi zikuphwanyidwa, zotsatira zake ndizosadziwika:
    ///
    /// * Cholozera choyambira ndi chotsatira chimayenera kukhala m'malire kapena podutsa kamodzi kumapeto kwa chinthu chomwecho.
    /// Dziwani kuti mu Rust, kusinthasintha kulikonse kwa (stack-allocated) kumawerengedwa kuti ndi chinthu chosiyana.
    ///
    /// * Makompyuta omwe adasinthidwa,**m'mabayiti**, sangathe kusefukira `isize`.
    ///
    /// * Zomwe zili m'malire sizingadalire "wrapping around" malo adilesi.Ndiye kuti, chopanda malire-chopanda malire,**m'mabayiti** chiyenera kukwana mu usize.
    ///
    /// Wopanga ndi laibulale yanthawi zonse amayesetsa kuwonetsetsa kuti magawidwewo sangafike kukula komwe kulibe vuto.
    /// Mwachitsanzo, `Vec` ndi `Box` zimawonetsetsa kuti samagawa zoposa ma `isize::MAX` byte, chifukwa chake `vec.as_ptr().add(vec.len())` imakhala yotetezeka nthawi zonse.
    ///
    /// Ma pulatifomu ambiri sangakwanitse kukhazikitsa gawo lotere.
    /// Mwachitsanzo, palibe nsanja yodziwika ya 64-bit yomwe ingatumizirepo pempho la 2 <sup>63</sup> byte chifukwa chakuchepa kwama tebulo kapena kugawaniza malo adilesi.
    /// Komabe, ma pulatifomu ena a 32-bit ndi 16-bit atha kukwanitsa kufunsa zopitilira `isize::MAX` byte ndi zinthu monga Physical Address Extension.
    ///
    /// Mwakutero, kukumbukira komwe kumapezeka mwachindunji kuchokera kwa omwe amagawa kapena mafayilo amajambulidwa ndi chikumbutso * atha kukhala wokulirapo kuti ungagwire ntchitoyi.
    ///
    /// Ganizirani kugwiritsa ntchito [`wrapping_offset`] m'malo mwake ngati zovuta izi ndizovuta kuzikwaniritsa.
    /// Ubwino wokha wa njirayi ndikuti imathandizira kukhathamiritsa kophatikiza kwamphamvu kwambiri.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `offset`.
        unsafe { intrinsics::offset(self, count) }
    }

    /// Kuwerengetsa zolowa kuchokera pacholozera pogwiritsa ntchito masamu okutira.
    ///
    /// `count` ali mgulu la T;Mwachitsanzo, `count` ya 3 imayimira cholozera cha ma `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Ntchitoyi imakhala yotetezeka nthawi zonse, koma kugwiritsa ntchito cholozera chotsatira sichoncho.
    ///
    /// Cholozera chotsatira chimakhalabe cholumikizidwa ndi chinthu chomwecho chomwe `self` imaloza.
    /// Itha * * isagwiritsidwe ntchito kupeza chinthu china chogawidwa.Dziwani kuti mu Rust, kusinthasintha kulikonse kwa (stack-allocated) kumawerengedwa kuti ndi chinthu chosiyana.
    ///
    /// Mwanjira ina, `let z = x.wrapping_offset((y as isize) - (x as isize))` sikuti * ipange `z` yofanana ndi `y` ngakhale titaganiza kuti `T` ili ndi kukula `1` ndipo palibe kusefukira: `z` idalumikizidwabe ndi chinthu `x` cholumikizidwa, ndikuchichotsa ndichikhalidwe chosadziwika pokhapokha `x` ndi `y` yalowetsani chinthu chomwecho.
    ///
    /// Poyerekeza ndi [`offset`], njirayi imachedwetsa kufunikira kokhala mu chinthu chomwecho: [`offset`] ndi Undefined Behaeve pomwe mukuwoloka malire azinthu;`wrapping_offset` imapanga cholozera koma imangobweretsabe ku Undefined Behaeve ngati cholozera sichimafotokozedwanso chikakhala kuti sichili pamalire a chinthu chomwe amamangirirapo.
    /// [`offset`] itha kukonzedweratu bwino ndipo chifukwa chake imasankhidwa mu nambala yosazindikira magwiridwe antchito.
    ///
    /// Kuchedwa kochedwa kumangowona kufunika kwa cholozera chomwe sichinatchulidwepo, osati malingaliro apakatikati omwe amagwiritsidwa ntchito pakuwerengera zotsatira zomaliza.
    /// Mwachitsanzo, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` nthawi zonse imakhala yofanana ndi `x`.Mwanjira ina, kusiya chinthu chomwe mwapatsidwacho ndikulowanso pambuyo pake ndikololedwa.
    ///
    /// Ngati mukufuna kudutsa malire azinthu, ponyani cholozera ku nambala yonse ndikuwerengera pamenepo.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// // Iterate pogwiritsa ntchito pointer yaiwisi powonjezerapo zinthu ziwiri
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // Chingwe ichi chimasindikiza "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // CHITETEZO: the `arith_offset` intrinsic has no prerequisites to be called.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// Kuwerengetsa mtunda pakati pa nsonga ziwiri.Mtengo wobwezedwa uli m'mayunitsi a T: mtunda wama byte wagawidwa ndi `mem::size_of::<T>()`.
    ///
    /// Ntchitoyi ndi yotsutsana ndi [`offset`].
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// Ngati izi zikuphwanyidwa, zotsatira zake ndizosadziwika:
    ///
    /// * Cholozera choyamba ndi china chilichonse chiyenera kukhala m'malire kapena kamodzi kamodzi kumapeto kwa chinthu chomwecho.
    /// Dziwani kuti mu Rust, kusinthasintha kulikonse kwa (stack-allocated) kumawerengedwa kuti ndi chinthu chosiyana.
    ///
    /// * Malangizo onsewa ayenera kuti amachokera ku * cholozera ku chinthu chomwecho.
    ///   (Onani pansipa chitsanzo.)
    ///
    /// * Mtunda wapakati pazolozera, m'mabayiti, uyenera kukhala wofanana ndendende kukula kwa `T`.
    ///
    /// * Mtunda wapakati pazolozera,**m'mabayiti**, sungasefukire `isize`.
    ///
    /// * Mtunda wokhala m'malire sungadalire "wrapping around" malo adilesi.
    ///
    /// Mitundu ya Rust siyokulirapo kuposa `isize::MAX` ndi magawo a Rust samazunguliza malo a adilesi, kotero ma point awiri pamtengo wina uliwonse wa Rust mtundu `T` nthawi zonse amakwaniritsa zofunikira ziwiri zapitazi.
    ///
    /// Laibulale yanthawi zonse imatsimikiziranso kuti kugawa sikufikira kukula komwe kulipira kuli kovuta.
    /// Mwachitsanzo, `Vec` ndi `Box` zimawonetsetsa kuti samagawa zoposa ma `isize::MAX` byte, chifukwa chake `ptr_into_vec.offset_from(vec.as_ptr())` imakwaniritsa zochitika ziwiri zapitazi.
    ///
    /// Ma pulatifomu ambiri sangathe kupanga gawo lalikulu chonchi.
    /// Mwachitsanzo, palibe nsanja yodziwika ya 64-bit yomwe ingatumizirepo pempho la 2 <sup>63</sup> byte chifukwa chakuchepa kwama tebulo kapena kugawaniza malo adilesi.
    /// Komabe, ma pulatifomu ena a 32-bit ndi 16-bit atha kukwanitsa kufunsa zopitilira `isize::MAX` byte ndi zinthu monga Physical Address Extension.
    /// Mwakutero, kukumbukira komwe kumapezeka mwachindunji kuchokera kwa omwe amagawa kapena mafayilo amajambulidwa ndi chikumbutso * atha kukhala wokulirapo kuti ungagwire ntchitoyi.
    /// (Dziwani kuti [`offset`] ndi [`add`] alinso ndi malire ofanana chifukwa chake sangathe kugwiritsidwa ntchito pamagawo akulu ngati awa.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Ntchitoyi panics ngati `T` ndi Zero-Sized Type ("ZST").
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// Kugwiritsa ntchito kosayenera:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Pangani ptr2_other "alias" of ptr2, koma yochokera ku ptr1.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Popeza ptr2_other ndi ptr2 amachokera kuzolembera kuzinthu zosiyanasiyana, kuwerengera zomwe adachita ndizosadziwika, ngakhale akunena za adilesi yomweyo!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Khalidwe Losadziwika
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `ptr_offset_from`.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// Kubwezera ngati zolemba ziwiri zatsimikiziridwa kuti ndizofanana.
    ///
    /// Nthawi yothamanga ntchitoyi imakhala ngati `self == other`.
    /// Komabe, m'malo ena (mwachitsanzo, kuwerengera nthawi), sizotheka nthawi zonse kudziwa kufanana kwa zolozera ziwiri, chifukwa chake ntchitoyi imatha kubwezera `false` mopangira ma pointer omwe pambuyo pake amakhala ofanana.
    ///
    /// Koma ikabwerera `true`, ma pointer atsimikiziridwa kuti ndi ofanana.
    ///
    /// Ntchitoyi ndi galasi la [`guaranteed_ne`], koma osati mosiyana.Pali kuyerekezera kwa pointer komwe ntchito zonse zimabweza `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Mtengo wobwezera ungasinthe kutengera mtundu wopanga ndi nambala yosatetezeka mwina singadalire zotsatira za ntchitoyi kuti ikhale yabwinoko.
    /// Tikulimbikitsidwa kuti tigwiritse ntchito ntchitoyi pakukonzekera magwiridwe antchito pomwe `false` yobweza mitengo ndi ntchitoyi sikukhudza zotsatira zake, koma magwiridwe antchito okha.
    /// Zotsatira zogwiritsa ntchito njirayi kuti nthawi yothamanga komanso nthawi yolemba nthawi zizikhala mosiyana sizinafufuzidwe.
    /// Njirayi siyiyenera kugwiritsidwa ntchito kuyambitsa kusiyana kumeneku, komanso sikuyenera kukhazikika tisanamvetsetse bwino nkhaniyi.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// Kubwezera ngati zolemba ziwiri zatsimikizika kuti sizingafanane.
    ///
    /// Nthawi yothamanga ntchitoyi imakhala ngati `self != other`.
    /// Komabe, m'malo ena (mwachitsanzo, kuwerengera nthawi), sizotheka nthawi zonse kutsimikizira kusalingana kwa zolozera ziwiri, chifukwa chake ntchitoyi imatha kubwezera `false` mopangira ma pointer omwe pambuyo pake amakhala osagwirizana.
    ///
    /// Koma ikabwerera `true`, zolozera zimatsimikizika kuti sizikhala zofanana.
    ///
    /// Ntchitoyi ndi galasi la [`guaranteed_eq`], koma osati mosiyana.Pali kuyerekezera kwa pointer komwe ntchito zonse zimabweza `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Mtengo wobwezera ungasinthe kutengera mtundu wopanga ndi nambala yosatetezeka mwina singadalire zotsatira za ntchitoyi kuti ikhale yabwinoko.
    /// Tikulimbikitsidwa kuti tigwiritse ntchito ntchitoyi pakukonzekera magwiridwe antchito pomwe `false` yobweza mitengo ndi ntchitoyi sikukhudza zotsatira zake, koma magwiridwe antchito okha.
    /// Zotsatira zogwiritsa ntchito njirayi kuti nthawi yothamanga komanso nthawi yolemba nthawi zizikhala mosiyana sizinafufuzidwe.
    /// Njirayi siyiyenera kugwiritsidwa ntchito kuyambitsa kusiyana kumeneku, komanso sikuyenera kukhazikika tisanamvetsetse bwino nkhaniyi.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// Kuwerengetsa zolowa kuchokera pa cholembera (chosavuta cha `.offset(count as isize)`).
    ///
    /// `count` ali mgulu la T;Mwachitsanzo, `count` ya 3 imayimira cholozera cha ma `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Ngati izi zikuphwanyidwa, zotsatira zake ndizosadziwika:
    ///
    /// * Cholozera choyambira ndi chotsatira chimayenera kukhala m'malire kapena podutsa kamodzi kumapeto kwa chinthu chomwecho.
    /// Dziwani kuti mu Rust, kusinthasintha kulikonse kwa (stack-allocated) kumawerengedwa kuti ndi chinthu chosiyana.
    ///
    /// * Makompyuta omwe adasinthidwa,**m'mabayiti**, sangathe kusefukira `isize`.
    ///
    /// * Zomwe zili m'malire sizingadalire "wrapping around" malo adilesi.Ndiye kuti, ndalama zopanda malire ziyenera kukhala mu `usize`.
    ///
    /// Wopanga ndi laibulale yanthawi zonse amayesetsa kuwonetsetsa kuti magawidwewo sangafike kukula komwe kulibe vuto.
    /// Mwachitsanzo, `Vec` ndi `Box` zimawonetsetsa kuti samagawa zoposa ma `isize::MAX` byte, chifukwa chake `vec.as_ptr().add(vec.len())` imakhala yotetezeka nthawi zonse.
    ///
    /// Ma pulatifomu ambiri sangakwanitse kukhazikitsa gawo lotere.
    /// Mwachitsanzo, palibe nsanja yodziwika ya 64-bit yomwe ingatumizirepo pempho la 2 <sup>63</sup> byte chifukwa chakuchepa kwama tebulo kapena kugawaniza malo adilesi.
    /// Komabe, ma pulatifomu ena a 32-bit ndi 16-bit atha kukwanitsa kufunsa zopitilira `isize::MAX` byte ndi zinthu monga Physical Address Extension.
    ///
    /// Mwakutero, kukumbukira komwe kumapezeka mwachindunji kuchokera kwa omwe amagawa kapena mafayilo amajambulidwa ndi chikumbutso * atha kukhala wokulirapo kuti ungagwire ntchitoyi.
    ///
    /// Ganizirani kugwiritsa ntchito [`wrapping_add`] m'malo mwake ngati zovuta izi ndizovuta kuzikwaniritsa.
    /// Ubwino wokha wa njirayi ndikuti imathandizira kukhathamiritsa kophatikiza kwamphamvu kwambiri.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Kuwerengetsa zolowa kuchokera pa pointer (kuthekera kwa `.offset ((kuwerengera monga isize).wrapping_neg())`).
    ///
    /// `count` ali mgulu la T;Mwachitsanzo, `count` ya 3 imayimira cholozera cha ma `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Ngati izi zikuphwanyidwa, zotsatira zake ndizosadziwika:
    ///
    /// * Cholozera choyambira ndi chotsatira chimayenera kukhala m'malire kapena podutsa kamodzi kumapeto kwa chinthu chomwecho.
    /// Dziwani kuti mu Rust, kusinthasintha kulikonse kwa (stack-allocated) kumawerengedwa kuti ndi chinthu chosiyana.
    ///
    /// * Zoyeserera zomwe zidapangidwa sizingadutse `isize::MAX`**byte**.
    ///
    /// * Zomwe zili m'malire sizingadalire "wrapping around" malo adilesi.Ndiye kuti, chopanda malire-chotsimikizika chiyenera kulumikizana ndi usize.
    ///
    /// Wopanga ndi laibulale yanthawi zonse amayesetsa kuwonetsetsa kuti magawidwewo sangafike kukula komwe kulibe vuto.
    /// Mwachitsanzo, `Vec` ndi `Box` zimawonetsetsa kuti samagawa zoposa ma `isize::MAX` byte, chifukwa chake `vec.as_ptr().add(vec.len()).sub(vec.len())` imakhala yotetezeka nthawi zonse.
    ///
    /// Ma pulatifomu ambiri sangakwanitse kukhazikitsa gawo lotere.
    /// Mwachitsanzo, palibe nsanja yodziwika ya 64-bit yomwe ingatumizirepo pempho la 2 <sup>63</sup> byte chifukwa chakuchepa kwama tebulo kapena kugawaniza malo adilesi.
    /// Komabe, ma pulatifomu ena a 32-bit ndi 16-bit atha kukwanitsa kufunsa zopitilira `isize::MAX` byte ndi zinthu monga Physical Address Extension.
    ///
    /// Mwakutero, kukumbukira komwe kumapezeka mwachindunji kuchokera kwa omwe amagawa kapena mafayilo amajambulidwa ndi chikumbutso * atha kukhala wokulirapo kuti ungagwire ntchitoyi.
    ///
    /// Ganizirani kugwiritsa ntchito [`wrapping_sub`] m'malo mwake ngati zovuta izi ndizovuta kuzikwaniritsa.
    /// Ubwino wokha wa njirayi ndikuti imathandizira kukhathamiritsa kophatikiza kwamphamvu kwambiri.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Kuwerengetsa zolowa kuchokera pacholozera pogwiritsa ntchito masamu okutira.
    /// (zosavuta za `.wrapping_offset(count as isize)`)
    ///
    /// `count` ali mgulu la T;Mwachitsanzo, `count` ya 3 imayimira cholozera cha ma `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Ntchitoyi imakhala yotetezeka nthawi zonse, koma kugwiritsa ntchito cholozera chotsatira sichoncho.
    ///
    /// Cholozera chotsatira chimakhalabe cholumikizidwa ndi chinthu chomwecho chomwe `self` imaloza.
    /// Itha * * isagwiritsidwe ntchito kupeza chinthu china chogawidwa.Dziwani kuti mu Rust, kusinthasintha kulikonse kwa (stack-allocated) kumawerengedwa kuti ndi chinthu chosiyana.
    ///
    /// Mwanjira ina, `let z = x.wrapping_add((y as usize) - (x as usize))` sikuti * ipange `z` yofanana ndi `y` ngakhale titaganiza kuti `T` ili ndi kukula `1` ndipo palibe kusefukira: `z` idalumikizidwabe ndi chinthu `x` cholumikizidwa, ndikuchichotsa ndichikhalidwe chosadziwika pokhapokha `x` ndi `y` yalowetsani chinthu chomwecho.
    ///
    /// Poyerekeza ndi [`add`], njirayi imachedwetsa kufunikira kokhala mu chinthu chomwecho: [`add`] ndi Undefined Behaeve pomwe mukuwoloka malire azinthu;`wrapping_add` imapanga cholozera koma imangobweretsabe ku Undefined Behaeve ngati cholozera sichimafotokozedwanso chikakhala kuti sichili pamalire a chinthu chomwe amamangirirapo.
    /// [`add`] itha kukonzedweratu bwino ndipo chifukwa chake imasankhidwa mu nambala yosazindikira magwiridwe antchito.
    ///
    /// Kuchedwa kochedwa kumangowona kufunika kwa cholozera chomwe sichinatchulidwepo, osati malingaliro apakatikati omwe amagwiritsidwa ntchito pakuwerengera zotsatira zomaliza.
    /// Mwachitsanzo, `x.wrapping_add(o).wrapping_sub(o)` nthawi zonse imakhala yofanana ndi `x`.Mwanjira ina, kusiya chinthu chomwe mwapatsidwacho ndikulowanso pambuyo pake ndikololedwa.
    ///
    /// Ngati mukufuna kudutsa malire azinthu, ponyani cholozera ku nambala yonse ndikuwerengera pamenepo.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// // Iterate pogwiritsa ntchito pointer yaiwisi powonjezerapo zinthu ziwiri
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Chingwe ichi chimasindikiza "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Kuwerengetsa zolowa kuchokera pacholozera pogwiritsa ntchito masamu okutira.
    /// (chosavuta cha `.kuchotsa_offset ((kuwerengera monga isize).wrapping_neg())`)
    ///
    /// `count` ali mgulu la T;Mwachitsanzo, `count` ya 3 imayimira cholozera cha ma `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Ntchitoyi imakhala yotetezeka nthawi zonse, koma kugwiritsa ntchito cholozera chotsatira sichoncho.
    ///
    /// Cholozera chotsatira chimakhalabe cholumikizidwa ndi chinthu chomwecho chomwe `self` imaloza.
    /// Itha * * isagwiritsidwe ntchito kupeza chinthu china chogawidwa.Dziwani kuti mu Rust, kusinthasintha kulikonse kwa (stack-allocated) kumawerengedwa kuti ndi chinthu chosiyana.
    ///
    /// Mwanjira ina, `let z = x.wrapping_sub((x as usize) - (y as usize))` sikuti * ipange `z` yofanana ndi `y` ngakhale titaganiza kuti `T` ili ndi kukula `1` ndipo palibe kusefukira: `z` idalumikizidwabe ndi chinthu `x` cholumikizidwa, ndikuchichotsa ndi Khalidwe Lopanda tanthauzo pokhapokha `x` ndi `y` yalowetsani chinthu chomwecho.
    ///
    /// Poyerekeza ndi [`sub`], njirayi imachedwetsa kufunikira kokhala mu chinthu chomwecho: [`sub`] ndi Undefined Behaeve pomwe mukuwoloka malire;`wrapping_sub` imapanga cholozera koma imangobweretsabe ku Undefined Behaeve ngati cholozera sichimafotokozedwanso chikakhala kuti sichili pamalire a chinthu chomwe amamangirirapo.
    /// [`sub`] itha kukonzedweratu bwino ndipo chifukwa chake imasankhidwa mu nambala yosazindikira magwiridwe antchito.
    ///
    /// Kuchedwa kochedwa kumangowona kufunika kwa cholozera chomwe sichinatchulidwepo, osati malingaliro apakatikati omwe amagwiritsidwa ntchito pakuwerengera zotsatira zomaliza.
    /// Mwachitsanzo, `x.wrapping_add(o).wrapping_sub(o)` nthawi zonse imakhala yofanana ndi `x`.Mwanjira ina, kusiya chinthu chomwe mwapatsidwacho ndikulowanso pambuyo pake ndikololedwa.
    ///
    /// Ngati mukufuna kudutsa malire azinthu, ponyani cholozera ku nambala yonse ndikuwerengera pamenepo.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// // Iterate pogwiritsa ntchito pointer yaiwisi powonjezerapo zinthu ziwiri (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Chingwe ichi chimasindikiza "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Ikani mtengo wa pointer ku `ptr`.
    ///
    /// Ngati `self` ili cholozera (fat) ku mtundu wosasinthidwa, opaleshoniyi imangokhudza gawo la pointer, pomwe ma (thin) amitundu yayikulu, izi zimakhala ndi gawo lofanana ndi gawo losavuta.
    ///
    /// Cholozera chotsatira chidzakhala ndi chiyambi cha `val`, mwachitsanzo, cholozera mafuta, opaleshoniyi ndiyofanana ndikupanga cholembera chamafuta chatsopano chokhala ndi mtengo wolozera wa `val` koma metadata ya `self`.
    ///
    ///
    /// # Examples
    ///
    /// Ntchitoyi ndi yofunika kwambiri pakulola masamu a pointer-point on-pointer on mafuta:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // tidzasindikiza "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // CHITETEZO: Ngati cholozera chochepa, izi zimafanana
        // ku gawo losavuta.
        // Pankhani ya choloza mafuta, ndikukhazikitsa kwa kolowera kwamafuta, gawo loyamba la cholozera chotere nthawi zonse limakhala cholozera, chomwe chimaperekedwanso.
        //
        unsafe { *thin = val };
        self
    }

    /// Iwerenga mtengo kuchokera ku `self` osasuntha.
    /// Izi zimasiya kukumbukira `self` osasintha.
    ///
    /// Onani [`ptr::read`] pazokhudza chitetezo ndi zitsanzo.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `read`.
        unsafe { read(self) }
    }

    /// Amawerenga mosasunthika pamtengo kuchokera ku `self` osasuntha.Izi zimasiya kukumbukira `self` osasintha.
    ///
    /// Ntchito zosunthika zimapangidwa kuti zikumbukire I/O, ndipo zimatsimikizika kuti sizingafanane kapena kupangidwanso ndi wophatikizira pantchito zina zosakhazikika.
    ///
    ///
    /// Onani [`ptr::read_volatile`] pazokhudza chitetezo ndi zitsanzo.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Iwerenga mtengo kuchokera ku `self` osasuntha.
    /// Izi zimasiya kukumbukira `self` osasintha.
    ///
    /// Mosiyana ndi `read`, cholozera sichingafanane.
    ///
    /// Onani [`ptr::read_unaligned`] pazokhudza chitetezo ndi zitsanzo.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Zimakopera ma `count * size_of<T>` byte kuchokera ku `self` mpaka `dest`.
    /// Gwero ndi komwe akupita atha kupezeka.
    ///
    /// NOTE: ili ndi dongosolo lofanana * la [`ptr::copy`].
    ///
    /// Onani [`ptr::copy`] pazokhudza chitetezo ndi zitsanzo.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Zimakopera ma `count * size_of<T>` byte kuchokera ku `self` mpaka `dest`.
    /// Gwero ndi komwe tikupita mwina * sizingakwane.
    ///
    /// NOTE: ili ndi dongosolo lofanana * la [`ptr::copy_nonoverlapping`].
    ///
    /// Onani [`ptr::copy_nonoverlapping`] pazokhudza chitetezo ndi zitsanzo.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Ikuwerengera zolakwika zomwe ziyenera kugwiritsidwa ntchito pa cholozera kuti zizigwirizana ndi `align`.
    ///
    /// Ngati sizingatheke kulumikiza pointer, kukhazikitsa kumabwezeretsa `usize::MAX`.
    /// Ndikololedwa kukhazikitsa kuti *nthawi zonse* zibwerere `usize::MAX`.
    /// Magwiridwe anu a algorithm okha ndi omwe angadalire pakupeza zovuta pano, osati kulondola kwake.
    ///
    /// Chotsatiracho chikuwonetsedwa pazinthu za `T`, osati ma byte.Mtengo wobwezeredwa ungagwiritsidwe ntchito ndi njira ya `wrapping_add`.
    ///
    /// Palibe chitsimikizo chilichonse chokhazikitsa cholozera sichidzasefukira kapena kupitirira gawo lomwe pointer imalozera.
    ///
    /// Zili kwa yemwe akuyimbirayo kuti awonetsetse kuti zomwe zabwezedwazo ndizolondola munjira zina zonse kupatula mayendedwe.
    ///
    /// # Panics
    ///
    /// Ntchito panics ngati `align` siyamphamvu ziwiri.
    ///
    /// # Examples
    ///
    /// Kufikira pafupi ndi `u8` monga `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // pomwe cholozera chitha kulumikizidwa kudzera pa `offset`, chitha kuloza kunja kwa magawidwewo
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // CHITETEZO: `align` yafufuzidwa kuti ikhale mphamvu ya 2 pamwambapa
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// Kubwezeretsa kutalika kwa kagawo yaiwisi.
    ///
    /// Mtengo wobwezeredwa ndi chiwerengero cha **zinthu**, osati kuchuluka kwa mabayiti.
    ///
    /// Ntchitoyi ndi yotetezeka, ngakhale kagawo kakang'ono kameneka sikangaponyedwe pamndandanda wa chidutswa chifukwa cholozera sichingachitike kapena sichinagwirizane.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // CHITETEZO: izi ndi zotetezeka chifukwa `*const [T]` ndi `FatPtr<T>` ali ndi chimodzimodzi.
            // `std` yokha ndi yomwe ingapangitse chitsimikizo ichi.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Kubwezeretsa pointer yaiwisi pachidutswa cha chidutswacho.
    ///
    /// Izi ndizofanana ndi kuponyera `self` mpaka `*const T`, koma zotetezeka kwambiri.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// Kubwezera cholozera chaiwisi ku chinthu kapena subslice, osachita malire.
    ///
    /// Kuyimbira njirayi ndi cholozera chakunja kapena pomwe `self` sichingafanane ndi *[undefined behaviour]* ngakhale cholembera chotsatira sichinagwiritsidwe ntchito.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // CHITETEZO: woyimbirayo amaonetsetsa kuti `self` ndiyosasinthika ndipo `index` ili m'malire.
        unsafe { index.get_unchecked(self) }
    }

    /// Imabwezeretsa `None` ngati pointer ilibe ntchito, kapena ikabweza chidutswa chogawana pamtengo wokutidwa ndi `Some`.
    /// Mosiyana ndi [`as_ref`], izi sizikutanthauza kuti mtengowo uyenera kuyambitsidwa.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Mukamatchula njirayi, muyenera kuwonetsetsa kuti *cholozera ndi NULL* kapena * zonsezi ndi zoona:
    ///
    /// * Cholozera chikuyenera kukhala [valid] kuti chiwerengedwe pamasamba ambiri a `ptr.len() * mem::size_of::<T>()`, ndipo chikuyenera kulumikizidwa bwino.Izi zikutanthauza makamaka:
    ///
    ///     * Kukumbukira konse kwa chidutswa ichi kuyenera kukhala mkati mwa chinthu chimodzi chogawa!
    ///       Magawo sangadutse pazinthu zingapo zomwe zapatsidwa.
    ///
    ///     * Cholozera chiyenera kulumikizidwa ngakhale ndi magawo a zero-kutalika.
    ///     Chimodzi mwazifukwa za izi ndikuti kukhathamiritsa kwa enum kumatha kudalira mafotokozedwe (kuphatikiza magawo amtundu uliwonse) osakanikirana komanso osachita kusiyanitsa ndi zina.
    ///
    ///     Mutha kupeza pointer yomwe imagwiritsidwa ntchito ngati `data` yamagawo otalika zero pogwiritsa ntchito [`NonNull::dangling()`].
    ///
    /// * Kukula kwathunthu kwa `ptr.len() * mem::size_of::<T>()` kwa kagawo sikuyenera kukhala kokulirapo kuposa `isize::MAX`.
    ///   Onani zolemba zachitetezo za [`pointer::offset`].
    ///
    /// * Muyenera kutsatira malamulo osasunthika a Rust, popeza nthawi yobwezera `'a` imasankhidwa mokha ndipo sizitanthauza nthawi yeniyeniyo ya tsambalo.
    ///   Makamaka, kwakanthawi kamoyo uno, kukumbukira komwe cholozera sikuyenera kusintha (kupatula mkati mwa `UnsafeCell`).
    ///
    /// Izi zikugwira ntchito ngakhale zotsatira za njirayi sigwiritsidwa ntchito!
    ///
    /// Onaninso [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Kufanana kwa zolozera
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Kuyerekeza zolemba
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}