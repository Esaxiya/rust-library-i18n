//! Sungani pamanja kukumbukira kudzera pazolembera zosaphika.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Ntchito zambiri mu gawo ili zimatenga zolemba zosaphika ngati zifukwa ndikuziwerenga kapena kuzilembera.Kuti izi zitheke, zolemba izi ziyenera kukhala * zovomerezeka.
//! Kaya cholozera chovomerezeka ndichotengera momwe amagwiritsidwira ntchito (kuwerenga kapena kulemba), komanso kukumbukira komwe kumapezeka (mwachitsanzo, read/written ndi ma byte angati).
//! Ntchito zambiri zimagwiritsa ntchito `*mut T` ndi `* const T` kuti zipeze phindu limodzi, momwemo zolembedwazo zimasiya kukula kwake ndikuyerekeza kuti ndi ma `size_of::<T>()` byte.
//!
//! Malamulo enieni ovomerezeka sanatsimikizidwebe.Zomwe zimaperekedwa panthawiyi ndizochepa kwambiri:
//!
//! * Cholozera [null] sichikhala * chovomerezeka, ngakhale chofikira [size zero][zst].
//! * Kuti cholozera chizikhala chovomerezeka, ndikofunikira, koma sikokwanira nthawi zonse, kuti cholozera chizikhala *chosasinthika*: kukumbukira kukula kwa kukula komwe kumayambira pa cholozera kuyenera konse kukhala m'malire a chinthu chomwe chapatsidwa.
//!
//! Dziwani kuti mu Rust, kusinthasintha kulikonse kwa (stack-allocated) kumawerengedwa kuti ndi chinthu chosiyana.
//! * Ngakhale pakuyenda kwa [size zero][zst], cholozera sichimayenera kuloza kukumbukira kukumbukira, mwachitsanzo, kusuntha kumapangitsa kuti ma pointer akhale osavomerezeka ngakhale atachita zero-size.
//! Komabe, kuponyera nambala ya zero *yeniyeni* ku pointer kumakhala koyenera kufikira ma zero, ngakhale kukumbukira kwina kungakhaleko ku adilesiyo ndikulandidwa.
//! Izi zikugwirizana ndikulemba kwanu omwe amagawa anu: kugawa zinthu za zero sizovuta kwambiri.
//! Njira yovomerezeka yopezera pointer yomwe ili yoyenera kwa zero-size ndi [`NonNull::dangling`].
//! * Kufikira konse komwe kumachitika ndi gawo ili ndi *non-atomic* m'lingaliro la [atomic operations] yogwiritsidwa ntchito kulunzanitsa pakati pa ulusi.
//! Izi zikutanthauza kuti sichodziwika bwino kuti munthu azitha kulowa m'malo amodzi kuchokera ulusi wosiyanasiyana pokhapokha onse atangowerenga kuchokera pamtima.
//! Tawonani kuti izi zikuphatikiza [`read_volatile`] ndi [`write_volatile`]: Kufikira kosavuta sikungagwiritsidwe ntchito polumikizira ulusi wapakati.
//! * Zotsatira zakuponya kwa cholozera ndizovomerezeka malinga ngati chinthucho chikukhalabe moyo ndipo osatchulapo (zolozera zosaphika) amagwiritsidwanso ntchito kukumbukira chimodzimodzi.
//!
//! Ma axioms awa, komanso kugwiritsa ntchito mosamalitsa [`offset`] pama pointer arithmetic, ndizokwanira kukhazikitsa zinthu zambiri zothandiza pamakhodi osatetezeka.
//! Zitsimikiziro zolimba zidzaperekedwa pamapeto pake, popeza malamulo a [aliasing] akutsimikizidwa.
//! Kuti mumve zambiri, onani [book] komanso gawo lomwe likupezeka ku [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Zolemba zosavomerezeka monga tafotokozera pamwambapa sizogwirizana bwino (pomwe kulumikizana kwa X01 kumafotokozedwa ndi mtundu wa pointee, mwachitsanzo, `*const T` iyenera kulumikizidwa ndi `mem::align_of::<T>()`).
//! Komabe, ntchito zambiri zimafuna kuti zifukwa zawo zigwirizane bwino, ndipo zidzafotokoza momveka bwino izi muzolemba zawo.
//! Kupatula kotchuka pa izi ndi [`read_unaligned`] ndi [`write_unaligned`].
//!
//! Ntchito ikamafuna kuyanjana moyenera, imatero ngakhale mwayi ukakhala ndi 0, mwachitsanzo, ngakhale kukumbukira sikukhudzidwa kwenikweni.Ganizirani kugwiritsa ntchito [`NonNull::dangling`] ngati izi.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Ikuwononga wowonongera (ngati alipo) amalo omwe adalozera.
///
/// Izi ndizofanana ndi kuyitana [`ptr::read`] ndikutaya zotsatira, koma zili ndi izi:
///
/// * Pakufunika * kugwiritsa ntchito `drop_in_place` kugwetsa mitundu yosafanana ngati zinthu za trait, chifukwa sizingathe kuwerengedwa muluwo ndikutsika mwachizolowezi.
///
/// * Ndizosangalatsa kwa optimizer kuchita izi kupitilira [`ptr::read`] mukamasiya kukumbukira pamanja (mwachitsanzo, pakukhazikitsa `Box`/`Rc`/`Vec`), popeza wopanga safunikira kutsimikizira kuti ndizomveka kuti agwiritse ntchito kope.
///
///
/// * Ikhoza kugwiritsidwa ntchito kutaya deta ya [pinned] pomwe `T` si `repr(packed)` (zomwe zidatchulidwa siziyenera kusunthidwa zisadatsike).
///
/// Zosagwirizana sizingagwetsedwe m'malo, ziyenera kukopera kumalo olumikizidwa poyamba pogwiritsa ntchito [`ptr::read_unaligned`].Pazodzaza zambiri, kusunthaku kumachitika zokha ndi wopanga.
/// Izi zikutanthauza kuti minda yodzaza sikugwetsedwa m'malo.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Khalidwe silimadziwika ngati izi zikuphwanyidwa:
///
/// * `to_drop` iyenera kukhala [valid] pakuwerenga ndi kulemba.
///
/// * `to_drop` ziyenera kulumikizidwa bwino.
///
/// * Mtengo wa `to_drop` uyenera kukhala wovomerezeka posiya, zomwe zitha kutanthauza kuti ziyenera kuthandizira zowonjezera zowonjezera, izi zimadalira mtundu.
///
/// Kuphatikiza apo, ngati `T` si [`Copy`], kugwiritsa ntchito mtengo womwe mwaloza mutayimba `drop_in_place` kumatha kuyambitsa machitidwe osadziwika.Dziwani kuti `*to_drop = foo` imawerengedwa ngati yogwiritsa ntchito chifukwa ipangitsa kuti mtengowo ugwetsedwenso.
/// [`write()`] itha kugwiritsidwa ntchito kulembetsa deta popanda kuyipangitsa kuti iponyedwe.
///
/// Dziwani kuti ngakhale `T` ili ndi kukula kwa `0`, cholozera chikuyenera kukhala chosakhala cha NULL ndikugwirizana bwino.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Chotsani nokha chinthu chomaliza kuchokera ku vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Pezani cholozera chosaphika chomaliza ku `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Fupikitsani `v` kuti muteteze chinthu chomaliza kuti chisaponyedwe.
///     // Timachita izi poyamba, kupewa zovuta ngati `drop_in_place` pansipa panics.
///     v.set_len(1);
///     // Popanda kuyimbira `drop_in_place`, chinthu chomaliza sichingagwetsedwe, ndipo kukumbukira komwe amakwanitsa kudzawululidwa.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Onetsetsani kuti chinthu chomaliza chidaponyedwa.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Tawonani kuti wopangirayo amachita izi pokhapokha ataponya zodzaza, mwachitsanzo, simukuyenera kuda nkhawa ndi izi pokhapokha mutayimba `drop_in_place` pamanja.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Code apa zilibe kanthu, izi zimalowetsedwa ndi gulu lenileni lokhala ndi wolemba.
    //

    // CHITETEZO: onani ndemanga pamwambapa
    unsafe { drop_in_place(to_drop) }
}

/// Pangani cholozera chopanda pake.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Pangani cholozera chosasinthika chosaphika.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Kuyika pamanja kumafunika kupewa `T: Clone` yomangidwa.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Kuyika pamanja kumafunika kupewa `T: Copy` yomangidwa.
impl<T> Copy for FatPtr<T> {}

/// Pangani kagawo kakang'ono kuchokera pa cholembera ndi kutalika.
///
/// Mtsutso wa `len` ndi chiwerengero cha **zinthu**, osati kuchuluka kwa mabayiti.
///
/// Ntchitoyi ndi yotetezeka, koma kugwiritsa ntchito mtengo wobwezera sikutetezeka.
/// Onani zolemba za [`slice::from_raw_parts`] kuti mupeze chitetezo.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // pangani pointer yamagawo mukamayamba ndi cholozera ku chinthu choyamba
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // CHITETEZO: Kupeza phindu kuchokera ku mgwirizano wa `Repr` ndikotetezeka kuyambira * const [T]
        //
        // ndi FatPtr ali ndi mawonekedwe ofanana okumbukira.std yokha ndi yomwe ingapange izi.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Imagwira chimodzimodzi ndi [`slice_from_raw_parts`], kupatula kuti kagawo kakang'ono kosinthika kamabweza, mosiyana ndi kagawo kakang'ono kosasinthika.
///
///
/// Onani zolemba za [`slice_from_raw_parts`] kuti mumve zambiri.
///
/// Ntchitoyi ndi yotetezeka, koma kugwiritsa ntchito mtengo wobwezera sikutetezeka.
/// Onani zolemba za [`slice::from_raw_parts_mut`] kuti mupeze chitetezo.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // perekani mtengo pa index mu kagawo
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // CHITETEZO: Kupeza phindu kuchokera ku mgwirizano wa `Repr` ndikotetezeka kuyambira * mut [T]
        // ndi FatPtr ali ndi mawonekedwe ofanana okumbukira
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Amasintha malingaliro m'malo awiri osinthika amtundu womwewo, osachotsanso chimodzi.
///
/// Koma kupatula zotsalira ziwiri izi, ntchitoyi ndiyofanana ndi [`mem::swap`]:
///
///
/// * Imagwira pazolemba zosaphika m'malo mojambulidwa.
/// Maumboni akapezeka, [`mem::swap`] iyenera kusankhidwa.
///
/// * Mfundo ziwirizi zitha kulozerana.
/// Ngati mikhalidwe ikuchulukira, ndiye kuti gawo lokumbukirana lokumbukirana kuchokera ku `x` lidzagwiritsidwa ntchito.
/// Izi zikuwonetsedwa muchitsanzo chachiwiri pansipa.
///
/// # Safety
///
/// Khalidwe silimadziwika ngati izi zikuphwanyidwa:
///
/// * Zonse `x` ndi `y` ziyenera kukhala [valid] pakuwerenga komanso kulemba.
///
/// * Zonse `x` ndi `y` ziyenera kulumikizidwa bwino.
///
/// Dziwani kuti ngakhale `T` ili ndi kukula kwa `0`, ma pointerwo ayenera kukhala osakhala a NULL komanso ogwirizana bwino.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Kusinthana zigawo ziwiri zosadukizana:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // iyi ndi `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // iyi ndi `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Kusintha zigawo ziwiri zomwe zikulumikizana:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // iyi ndi `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // iyi ndi `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Zolemba za `1..3` zamagawo zimadutsana pakati pa `x` ndi `y`.
///     // Zotsatira zomveka zingakhale kwa iwo kukhala `[2, 3]`, kotero kuti ma index `0..3` ndi `[1, 2, 3]` (ofanana `y` pamaso pa `swap`);kapena kuti akhale `[0, 1]` kotero ma indices `1..4` ndi `[0, 1, 2]` (ofanana `x` pamaso pa `swap`).
/////
///     // Kukhazikitsa kumeneku kumatanthauzidwa kuti apange chisankho chomaliza.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Tidzipatseni malo ena oti tigwire nawo ntchito.
    // Sitiyenera kuda nkhawa ndi madontho: `MaybeUninit` sichichita chilichonse ikagwetsedwa.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Sinthani CHITETEZO: woyimbayo akuyenera kutsimikizira kuti `x` ndi `y` ndizovomerezeka polemba komanso zogwirizana moyenera.
    // `tmp` Sangathe kulumikizana ndi `x` kapena `y` chifukwa `tmp` idangogawika pamtengo ngati chinthu chogawanika.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` ndipo `y` imatha kupezeka
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Sinthana ma `count * size_of::<T>()` byte pakati pa zigawo ziwiri zokumbukira kuyambira `x` ndi `y`.
/// Madera awiriwa sayenera kudutsana.
///
/// # Safety
///
/// Khalidwe silimadziwika ngati izi zikuphwanyidwa:
///
/// * Zonse `x` ndi `y` ziyenera kukhala [valid] pakuwerenga zonse ndikulemba za `count *
///   kukula_kwa: :<T>() `mabayiti.
///
/// * Zonse `x` ndi `y` ziyenera kulumikizidwa bwino.
///
/// * Dera lokumbukira kuyambira `x` ndi kukula kwa `count *
///   kukula_kwa: :<T>() `byte sayenera * kudutsana ndi dera lokumbukira kuyambira `y` ndi kukula komweko.
///
/// Dziwani kuti ngakhale kukula koyenera kutengera (`count * size_of: :<T>()`) ndi `0`, zolembazo ziyenera kukhala zosakhala za NULL komanso zogwirizana bwino.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Kagwiritsidwe:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // CHITETEZO: woyimbayo ayenera kutsimikizira kuti `x` ndi `y` ali
    // Zovomerezeka polemba komanso zogwirizana moyenera.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Kwa mitundu yaying'ono kuposa kukhathamiritsa komwe kuli pansipa, ingosinthani mwachindunji kuti mupewe kukhumudwitsa codegen.
    //
    if mem::size_of::<T>() < 32 {
        // CHITETEZO: woyimbayo akuyenera kutsimikizira kuti `x` ndi `y` ndizovomerezeka
        // Kulemba, kulumikizana bwino, komanso osakondana.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Njira pano ndikugwiritsa ntchito simd kusinthana x&y moyenera.
    // Kuyesa kumawululira kuti kusinthana ma 32 byte kapena ma 64 ma byte nthawi imodzi kumakhala kothandiza kwambiri kwa ma processor a Intel Haswell E.
    // LLVM imatha kuthekera bwino tikamapereka #[repr(simd)], ngakhale sitigwiritsa ntchito fomuyi molunjika.
    //
    //
    // FIXME repr(simd) yosweka pa emscripten ndi redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Loop through x&y, copy them `Block` at a time The optimizer should unroll the loop fully for most types NB
    // Sitingagwiritse ntchito lupu pomwe `range` imalimbikitsa kuyitanitsa `mem::swap` mobwerezabwereza
    //
    let mut i = 0;
    while i + block_size <= len {
        // Pangani chikumbutso chomwe sichinayambitsidwe ngati danga loyambira Kulengeza `t` apa popewa kulumikiza okwanira pomwe malowo sakugwiritsidwa ntchito
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // CHITETEZO: Monga `i < len`, komanso momwe woyimbirayo akuyenera kutsimikizira kuti `x` ndi `y` ndizovomerezeka
        // ma `len` byte, `x + i` ndi `y + i` ayenera kukhala ma adilesi ovomerezeka, omwe amakwaniritsa mgwirizano wachitetezo wa `add`.
        //
        // Komanso, woyimbirayo akuyenera kutsimikizira kuti `x` ndi `y` ndizovomerezeka polemba, zoyanjanitsidwa bwino, komanso zosaphatikizana, zomwe zimakwaniritsa mgwirizano wachitetezo wa `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Sinthanitsani mabatani a x&y, pogwiritsa ntchito t ngati chosungira kwakanthawi Izi ziyenera kukonzedwa kuti zizigwira bwino ntchito za SIMD pomwe zingapezeke
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Sinthanitsani mabayiti otsala
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // CHITETEZO: onani ndemanga zam'mbuyomu zachitetezo.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Imasuntha `src` kulowa mu `dst`, ndikubweza mtengo wam'mbuyo wa `dst`.
///
/// Palibe phindu lomwe limatsitsidwa.
///
/// Ntchitoyi ndiyofanana ndi [`mem::replace`] kupatula kuti imagwira zolemba zotsalira m'malo mwakutanthauzira.
/// Maumboni akapezeka, [`mem::replace`] iyenera kusankhidwa.
///
/// # Safety
///
/// Khalidwe silimadziwika ngati izi zikuphwanyidwa:
///
/// * `dst` iyenera kukhala [valid] pakuwerenga ndi kulemba.
///
/// * `dst` ziyenera kulumikizidwa bwino.
///
/// * `dst` ziyenera kuloza pamtengo woyambitsidwa bwino wa mtundu `T`.
///
/// Dziwani kuti ngakhale `T` ili ndi kukula kwa `0`, cholozera chikuyenera kukhala chosakhala cha NULL ndikugwirizana bwino.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` zingakhale ndi zotsatira zofananira popanda kufunikira malo osatetezeka.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // CHITETEZO: woyimbayo akuyenera kutsimikizira kuti `dst` ndiyotheka kukhala
    // pezani pamtundu wosinthika (woyenera kulemba, kulumikiza, kuyambitsa), ndipo sungaphatikizepo `src` popeza `dst` iyenera kuloza ku chinthu chomwe chapatsidwa.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // sizingagwirizane
    }
    src
}

/// Iwerenga mtengo kuchokera ku `src` osasuntha.Izi zimasiya kukumbukira `src` osasintha.
///
/// # Safety
///
/// Khalidwe silimadziwika ngati izi zikuphwanyidwa:
///
/// * `src` iyenera kukhala [valid] yowerengera.
///
/// * `src` ziyenera kulumikizidwa bwino.Gwiritsani ntchito [`read_unaligned`] ngati sizili choncho.
///
/// * `src` ziyenera kuloza pamtengo woyambitsidwa bwino wa mtundu `T`.
///
/// Dziwani kuti ngakhale `T` ili ndi kukula kwa `0`, cholozera chikuyenera kukhala chosakhala cha NULL ndikugwirizana bwino.
///
/// # Examples
///
/// Kagwiritsidwe:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Gwiritsani ntchito mwakhama [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Pangani kope pang'ono pamtengo pa `a` mu `tmp`.
///         let tmp = ptr::read(a);
///
///         // Kutuluka panthawiyi (mwina pobwerera mwachangu kapena poyitanitsa ntchito yomwe panics) ingapangitse kuti mtengo wa `tmp` ugwetsedwe pomwe mtengo womwewo ukutchulidwabe ndi `a`.
///         // Izi zitha kuyambitsa machitidwe osadziwika ngati `T` si `Copy`.
/////
/////
///
///         // Pangani kope pang'ono pamtengo pa `b` mu `a`.
///         // Izi ndizotetezeka chifukwa maumboni osinthika sangathenso kudziwika.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Monga tafotokozera pamwambapa, kutuluka pano kumatha kuyambitsa machitidwe osadziwika chifukwa mtengo womwewo umatchulidwanso ndi `a` ndi `b`.
/////
///
///         // Sungani `tmp` mu `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` yasunthidwa (`write` imatenga mfundo yachiwiri), kotero palibe chomwe chimaponyedwa pano.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Umwini Wa Mtengo Wobwezeredwa
///
/// `read` imapanga mtundu wa `T`, mosasamala kanthu kuti `T` ndi [`Copy`].
/// Ngati `T` si [`Copy`], kugwiritsa ntchito phindu lobwezeredwa komanso mtengo wa `*src` kumatha kuphwanya kukumbukira kukumbukira.
/// Dziwani kuti kugawa `*src` kuwerengera ngati ntchito chifukwa kuyesera kutaya mtengo ku `* src`.
///
/// [`write()`] itha kugwiritsidwa ntchito kulembetsa deta popanda kuyipangitsa kuti iponyedwe.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` tsopano ikuloza chikumbukiro chofanana ndi `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Kugawana `s2` kumapangitsa kuti mtengo wake woyambirira ugwetsedwe.
///     // Kupitilira apa, `s` siyeneranso kugwiritsidwanso ntchito, chifukwa chokumbukira chamasulidwa.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Kugawana `s` kungapangitse kuti mtengo wakale ugwetsedwe, zomwe zimapangitsa kuti munthu akhale wopanda tanthauzo.
/////
///     // s= String::from("bar");//ZOLAKWITSA
///
///     // `ptr::write` itha kugwiritsidwa ntchito kulembetsa mtengo popanda kuusiya.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // CHITETEZO: woyimbirayo akuyenera kutsimikizira kuti `src` ndiyotheka kuwerenga.
    // `src` sichingagwirizane `tmp` chifukwa `tmp` idangogawika pamtanda ngati chinthu chogawanika.
    //
    //
    // Komanso, popeza tangolemba mtengo wokwanira mu `tmp`, zimatsimikizika kuti ziyambitsidwe bwino.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Iwerenga mtengo kuchokera ku `src` osasuntha.Izi zimasiya kukumbukira `src` osasintha.
///
/// Mosiyana ndi [`read`], `read_unaligned` imagwira ntchito ndi maupangiri osagwirizana.
///
/// # Safety
///
/// Khalidwe silimadziwika ngati izi zikuphwanyidwa:
///
/// * `src` iyenera kukhala [valid] yowerengera.
///
/// * `src` ziyenera kuloza pamtengo woyambitsidwa bwino wa mtundu `T`.
///
/// Monga [`read`], `read_unaligned` imapanga mtundu wa `T`, mosasamala kanthu kuti `T` ndi [`Copy`].
/// Ngati `T` si [`Copy`], kugwiritsa ntchito phindu lobwezeredwa komanso mtengo wa `*src` utha kukhala [violate memory safety][read-ownership].
///
/// Dziwani kuti ngakhale `T` ili ndi kukula `0`, cholozera sikuyenera kukhala chosakhala NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Pa `packed` imakhazikika
///
/// Pakadali pano ndizosatheka kupanga zolozera zosaphika kuminda yopanda zolumikizika.
///
/// Kuyesera kupanga pointer yaiwisi ku gawo la `unaligned` lokhala ndi mawu monga `&packed.unaligned as *const FieldType` limapanga cholozera chapakatikati chosasinthidwa musanatembenuzire ku cholembera chosaphika.
///
/// Kuti kutchulidwaku ndi kwakanthawi ndipo kuponyedwa nthawi yomweyo sikofunikira chifukwa wopanga nthawi zonse amayembekezera kuti zolembedwazo zizigwirizana bwino.
/// Zotsatira zake, kugwiritsa ntchito `&packed.unaligned as *const FieldType` kumayambitsa machitidwe osadziwika kale* pulogalamu yanu.
///
/// Chitsanzo cha zomwe simuyenera kuchita komanso momwe zimakhudzira `read_unaligned` ndi izi:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Apa tikuyesera kutenga adilesi ya nambala 32-bit yomwe siyofanana.
///     let unaligned =
///         // Buku losavomerezeka laling'ono limapangidwa pano lomwe limabweretsa machitidwe osasankhidwa mosasamala kanthu kuti zolembazo zagwiritsidwa ntchito kapena ayi.
/////
///         &packed.unaligned
///         // Kuponyera cholozera chosaphika sikuthandiza;kulakwitsa kunachitika kale.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Kufikira magawo osalumikizidwa mwachindunji ndi mwachitsanzo `packed.unaligned` ndikotetezeka komabe.
///
///
///
///
///
///
// FIXME: Sinthani ma doc potengera zotsatira za RFC #2582 ndi abwenzi.
/// # Examples
///
/// Werengani mtengo wamagwiritsidwe kuchokera pa cholembera cha byte:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // CHITETEZO: woyimbirayo akuyenera kutsimikizira kuti `src` ndiyotheka kuwerenga.
    // `src` sichingagwirizane `tmp` chifukwa `tmp` idangogawika pamtanda ngati chinthu chogawanika.
    //
    //
    // Komanso, popeza tangolemba mtengo wokwanira mu `tmp`, zimatsimikizika kuti ziyambitsidwe bwino.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Amalemba malo okumbukira ndi mtengo womwe wapatsidwa popanda kuwerenga kapena kutaya mtengo wakale.
///
/// `write` sichisiya zomwe zili mu `dst`.
/// Izi ndizotetezeka, koma zitha kutulutsa ndalama kapena zinthu zina, chifukwa chake chisamaliro chiyenera kutengedwa kuti chisalembe chinthu chomwe chiyenera kuponyedwa.
///
///
/// Kuphatikiza apo, siyigwetsa `src`.Mofananamo, `src` imasunthidwira kumalo omwe `dst` idaloza.
///
/// Izi ndizoyenera kuyambitsa kukumbukira kosakhazikika, kapena kulembetsa kukumbukira komwe [`read`] idachokerako.
///
/// # Safety
///
/// Khalidwe silimadziwika ngati izi zikuphwanyidwa:
///
/// * `dst` iyenera kukhala [valid] yolemba.
///
/// * `dst` ziyenera kulumikizidwa bwino.Gwiritsani ntchito [`write_unaligned`] ngati sizili choncho.
///
/// Dziwani kuti ngakhale `T` ili ndi kukula kwa `0`, cholozera chikuyenera kukhala chosakhala cha NULL ndikugwirizana bwino.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Kagwiritsidwe:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Gwiritsani ntchito mwakhama [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Pangani kope pang'ono pamtengo pa `a` mu `tmp`.
///         let tmp = ptr::read(a);
///
///         // Kutuluka panthawiyi (mwina pobwerera mwachangu kapena poyitanitsa ntchito yomwe panics) ingapangitse kuti mtengo wa `tmp` ugwetsedwe pomwe mtengo womwewo ukutchulidwabe ndi `a`.
///         // Izi zitha kuyambitsa machitidwe osadziwika ngati `T` si `Copy`.
/////
/////
///
///         // Pangani kope pang'ono pamtengo pa `b` mu `a`.
///         // Izi ndizotetezeka chifukwa maumboni osinthika sangathenso kudziwika.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Monga tafotokozera pamwambapa, kutuluka pano kumatha kuyambitsa machitidwe osadziwika chifukwa mtengo womwewo umatchulidwanso ndi `a` ndi `b`.
/////
///
///         // Sungani `tmp` mu `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` yasunthidwa (`write` imatenga mfundo yachiwiri), kotero palibe chomwe chimaponyedwa pano.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Tikuyitanitsa ma intrinsics mwachindunji kuti tipewe kuyitanitsa magwiridwe antchito momwe `intrinsics::copy_nonoverlapping` imagwirira ntchito.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // CHITETEZO: woyimbayo ayenera kutsimikizira kuti `dst` ndiyotheka kulemba.
    // `dst` sangaphatikizire `src` chifukwa woyimbayo ali ndi mwayi wopeza `dst` pomwe `src` ili ndi ntchitoyi.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Amalemba malo okumbukira ndi mtengo womwe wapatsidwa popanda kuwerenga kapena kutaya mtengo wakale.
///
/// Mosiyana ndi [`write()`], cholozera sichingafanane.
///
/// `write_unaligned` sichisiya zomwe zili mu `dst`.Izi ndizotetezeka, koma zitha kutulutsa ndalama kapena zinthu zina, chifukwa chake chisamaliro chiyenera kutengedwa kuti chisalembe chinthu chomwe chiyenera kuponyedwa.
///
/// Kuphatikiza apo, siyigwetsa `src`.Mofananamo, `src` imasunthidwira kumalo omwe `dst` idaloza.
///
/// Izi ndizoyenera kuyambitsa kukumbukira kosalemba, kapena kulembetsa kukumbukira komwe kumawerengedwa kale ndi [`read_unaligned`].
///
/// # Safety
///
/// Khalidwe silimadziwika ngati izi zikuphwanyidwa:
///
/// * `dst` iyenera kukhala [valid] yolemba.
///
/// Dziwani kuti ngakhale `T` ili ndi kukula `0`, cholozera sikuyenera kukhala chosakhala NULL.
///
/// [valid]: self#safety
///
/// ## Pa `packed` imakhazikika
///
/// Pakadali pano ndizosatheka kupanga zolozera zosaphika kuminda yopanda zolumikizika.
///
/// Kuyesera kupanga pointer yaiwisi ku gawo la `unaligned` lokhala ndi mawu monga `&packed.unaligned as *const FieldType` limapanga cholozera chapakatikati chosasinthidwa musanatembenuzire ku cholembera chosaphika.
///
/// Kuti kutchulidwaku ndi kwakanthawi ndipo kuponyedwa nthawi yomweyo sikofunikira chifukwa wopanga nthawi zonse amayembekezera kuti zolembedwazo zizigwirizana bwino.
/// Zotsatira zake, kugwiritsa ntchito `&packed.unaligned as *const FieldType` kumayambitsa machitidwe osadziwika kale* pulogalamu yanu.
///
/// Chitsanzo cha zomwe simuyenera kuchita komanso momwe zimakhudzira `write_unaligned` ndi izi:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Apa tikuyesera kutenga adilesi ya nambala 32-bit yomwe siyofanana.
///     let unaligned =
///         // Buku losavomerezeka laling'ono limapangidwa pano lomwe limabweretsa machitidwe osasankhidwa mosasamala kanthu kuti zolembazo zagwiritsidwa ntchito kapena ayi.
/////
///         &mut packed.unaligned
///         // Kuponyera cholozera chosaphika sikuthandiza;kulakwitsa kunachitika kale.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Kufikira magawo osalumikizidwa mwachindunji ndi mwachitsanzo `packed.unaligned` ndikotetezeka komabe.
///
///
///
///
///
///
///
///
///
// FIXME: Sinthani ma doc potengera zotsatira za RFC #2582 ndi abwenzi.
/// # Examples
///
/// Lembani mtengo wamagwiritsidwe ntchito pa cholembera chomenyera:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // CHITETEZO: woyimbayo ayenera kutsimikizira kuti `dst` ndiyotheka kulemba.
    // `dst` sangaphatikizire `src` chifukwa woyimbayo ali ndi mwayi wopeza `dst` pomwe `src` ili ndi ntchitoyi.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Tikuyitanitsa zamkati mwachindunji kuti tipewe kuyimba kwama foni mu code yomwe idapangidwa.
        intrinsics::forget(src);
    }
}

/// Amawerenga mosasunthika pamtengo kuchokera ku `src` osasuntha.Izi zimasiya kukumbukira `src` osasintha.
///
/// Ntchito zosunthika zimapangidwa kuti zikumbukire I/O, ndipo zimatsimikizika kuti sizingafanane kapena kupangidwanso ndi wophatikizira pantchito zina zosakhazikika.
///
/// # Notes
///
/// Rust pakadali pano sichikhala ndi chikumbutso chokhwima komanso chodziwika bwino, chifukwa chake semantics yeniyeni ya zomwe "volatile" imatanthauza pano imatha kusintha pakapita nthawi.
/// Izi zikunenedwa, ma semantics nthawi zonse amakhala ofanana kwambiri ndi [C11's definition of volatile][c11].
///
/// Wolembetsayo sayenera kusintha dongosolo kapena kuchuluka kwa kukumbukira kosasintha.
/// Komabe, kukumbukira kosakhazikika pamitundu yayikulu-zero (mwachitsanzo, ngati mtundu wa zero-zero wapititsidwa ku `read_volatile`) ndi ma noops ndipo akhoza kunyalanyazidwa.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Khalidwe silimadziwika ngati izi zikuphwanyidwa:
///
/// * `src` iyenera kukhala [valid] yowerengera.
///
/// * `src` ziyenera kulumikizidwa bwino.
///
/// * `src` ziyenera kuloza pamtengo woyambitsidwa bwino wa mtundu `T`.
///
/// Monga [`read`], `read_volatile` imapanga mtundu wa `T`, mosasamala kanthu kuti `T` ndi [`Copy`].
/// Ngati `T` si [`Copy`], kugwiritsa ntchito phindu lobwezeredwa komanso mtengo wa `*src` utha kukhala [violate memory safety][read-ownership].
/// Komabe, kusungira mitundu yosakhala ya [`Copy`] pamakumbukiro osakhazikika sikulondola.
///
/// Dziwani kuti ngakhale `T` ili ndi kukula kwa `0`, cholozera chikuyenera kukhala chosakhala cha NULL ndikugwirizana bwino.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Monga C, ngati opareshoni ndiyosintha palibenso chifukwa chilichonse pamafunso okhudzana ndi kulumikizana nthawi imodzi kuchokera ulusi angapo.Kufikira kosakhazikika kumakhala ngati kutengera komwe kulibe ma atomiki pankhaniyi.
///
/// Makamaka, mpikisano pakati pa `read_volatile` ndi ntchito iliyonse yolembera pamalo omwewo ndi wopanda tanthauzo.
///
/// # Examples
///
/// Kagwiritsidwe:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Osadandaula kuti zotsatira za codegen zikhale zochepa.
        abort();
    }
    // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Amalemba zolemba zosasunthika za malo okumbukira ndi mtengo womwe wapatsidwa popanda kuwerenga kapena kusiya mtengo wakale.
///
/// Ntchito zosunthika zimapangidwa kuti zikumbukire I/O, ndipo zimatsimikizika kuti sizingafanane kapena kupangidwanso ndi wophatikizira pantchito zina zosakhazikika.
///
/// `write_volatile` sichisiya zomwe zili mu `dst`.Izi ndizotetezeka, koma zitha kutulutsa ndalama kapena zinthu zina, chifukwa chake chisamaliro chiyenera kutengedwa kuti chisalembe chinthu chomwe chiyenera kuponyedwa.
///
/// Kuphatikiza apo, siyigwetsa `src`.Mofananamo, `src` imasunthidwira kumalo omwe `dst` idaloza.
///
/// # Notes
///
/// Rust pakadali pano sichikhala ndi chikumbutso chokhwima komanso chodziwika bwino, chifukwa chake semantics yeniyeni ya zomwe "volatile" imatanthauza pano imatha kusintha pakapita nthawi.
/// Izi zikunenedwa, ma semantics nthawi zonse amakhala ofanana kwambiri ndi [C11's definition of volatile][c11].
///
/// Wolembetsayo sayenera kusintha dongosolo kapena kuchuluka kwa kukumbukira kosasintha.
/// Komabe, kukumbukira kosakhazikika pamitundu yayikulu-zero (mwachitsanzo, ngati mtundu wa zero-zero wapititsidwa ku `write_volatile`) ndi ma noops ndipo akhoza kunyalanyazidwa.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Khalidwe silimadziwika ngati izi zikuphwanyidwa:
///
/// * `dst` iyenera kukhala [valid] yolemba.
///
/// * `dst` ziyenera kulumikizidwa bwino.
///
/// Dziwani kuti ngakhale `T` ili ndi kukula kwa `0`, cholozera chikuyenera kukhala chosakhala cha NULL ndikugwirizana bwino.
///
/// [valid]: self#safety
///
/// Monga C, ngati opareshoni ndiyosintha palibenso chifukwa chilichonse pamafunso okhudzana ndi kulumikizana nthawi imodzi kuchokera ulusi angapo.Kufikira kosakhazikika kumakhala ngati kutengera komwe kulibe ma atomiki pankhaniyi.
///
/// Makamaka, mpikisano pakati pa `write_volatile` ndi ntchito ina iliyonse (kuwerenga kapena kulemba) pamalo omwewo ndi khalidwe losadziwika.
///
/// # Examples
///
/// Kagwiritsidwe:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Osadandaula kuti zotsatira za codegen zikhale zochepa.
        abort();
    }
    // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Gwirizanani cholozera `p`.
///
/// Sungani zolakwika (potengera zinthu za `stride` stride) zomwe ziyenera kugwiritsidwa ntchito kulozera `p` kuti pointer `p` igwirizane ndi `a`.
///
/// Note: Kukhazikitsa kumeneku kwapangidwa kuti kusakhale panic.Ndi UB wa izi mpaka panic.
/// Kusintha kokha kokha komwe kungapangidwe pano ndikusintha kwa `INV_TABLE_MOD_16` ndi zovuta zina zogwirizana.
///
/// Ngati tingapange lingaliro lotha kuyitanitsa zamkati ndi `a` yomwe siili yamphamvu-yawiri, mwina kungakhale kwanzeru kusinthiratu kuti tikwaniritse zopanda pake m'malo moyesera kusintha izi kuti zigwirizane ndi kusinthako.
///
///
/// Mafunso aliwonse apita kwa@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Kugwiritsa ntchito mwachindunji izi zamkati kumakulitsa codegen kwambiri pamlingo wosankha <=
    // 1, pomwe njira zamachitidwezi sizinalembedwe.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Kuwerengetsa multiplicative modular inverse ya `x` modulo `m`.
    ///
    /// Kukhazikitsa kumeneku kumapangidwira `align_offset` ndipo ili ndi zotsatirazi:
    ///
    /// * `m` ndi mphamvu ya awiri;
    /// * `x < m`; (ngati `x ≥ m`, ikani `x % m` m'malo mwake)
    ///
    /// Kukhazikitsa ntchitoyi sikungakhale panic.Nthawi zonse.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Multiplicative modular inverse tebulo modulo 2⁴=16.
        ///
        /// Tawonani, kuti tebulo ili mulibe mfundo zomwe kulibe kulowera (mwachitsanzo, kwa `0⁻¹ mod 16`, `2⁻¹ mod 16`, ndi zina zambiri)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo yomwe `INV_TABLE_MOD_16` imapangidwira.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // CHITETEZO: `m` imafunika kukhala yamphamvu ziwiri, motero osakhala zero.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Timayeserera "up" pogwiritsa ntchito njira zotsatirazi:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // mpaka 2²ⁿ ≥ m.Kenako titha kuchepetsa ku `m` yomwe timafuna titatenga zotsatira `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) yamakono n
                //
                // Zindikirani, kuti timagwiritsa ntchito zokutira pano mwadala-njira yoyambayo imagwiritsa ntchito mwachitsanzo, kuchotsa `mod n`.
                // Ndizabwino kuzichita `mod usize::MAX` m'malo mwake, chifukwa timatenga zotsatira `mod n` kumapeto kwake.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // CHITETEZO: `a` ndi mphamvu-yawiri, chifukwa chake si zero.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` Mlandu ungathe kuwerengedwa mosavuta kudzera mu `-p (mod a)`, koma kuchita izi kumalepheretsa LLVM kutha kusankha malangizo ngati `lea`.M'malo mwake timawerengera
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // yomwe imagawa ntchito mozungulira katundu wonyamula, koma osaganizira `and` mokwanira kuti LLVM itha kugwiritsa ntchito kukhathamiritsa kosiyanasiyana komwe ikudziwa.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Zalumikizidwa kale.Pamenepo!
        return 0;
    } else if stride == 0 {
        // Ngati cholozera sichinagwirizane, ndipo chipangizocho chimakhala chofanana ndi zero, ndiye kuti palibe zinthu zomwe zingafanane ndi cholozera.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // CHITETEZO: mphamvu ya awiri motero sizero.stride==0 imagwiridwa pamwambapa.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // CHITETEZO: gcdpow ili ndi malire omaliza omwe ndi ochulukirapo kuchuluka kwa ma bits mu usize.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // CHITETEZO: gcd nthawi zonse imakhala yayikulu kapena yofanana ndi 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // branch iyi ithetsa mavutowa:
        //
        // ` p + so = 0 mod a `
        //
        // `p` nayi pointer value, `s`, stride of `T`, `o` offset in `T`s, and `a`, the alignment alignment.
        //
        // Ndi `g = gcd(a, s)`, komanso zomwe zili pamwambapa zotsimikizira kuti `p` imagawidwanso ndi `g`, titha kutanthauza `a' = a/g`, `s' = s/g`, `p' = p/g`, ndiye izi zikufanana ndi:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Nthawi yoyamba ndi "the relative alignment of `p` to `a`" (yogawidwa ndi `g`), nthawi yachiwiri ndi "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (yogawikidwanso ndi `g`).
        //
        // Kugawikana ndi `g` ndikofunikira kuti zolembedwazo zipangidwe bwino ngati `a` ndi `s` sizogwirizana.
        //
        // Kuphatikiza apo, zotsatira zopangidwa ndi yankho ili si "minimal", chifukwa chake ndikofunikira kutenga zotsatira `o mod lcm(s, a)`.Titha kusintha `lcm(s, a)` ndi `a'` yokha.
        //
        //
        //
        //
        //

        // CHITETEZO: `gcdpow` ili ndi malire apamwamba osaposa kuchuluka kwa ma 0-bits mu `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // CHITETEZO: `a2` si zero.Kusuntha `a` ndi `gcdpow` sikungasinthe chilichonse mwazinthu zomwe zidakhazikitsidwa
        // mu `a` (yomwe ili nayo chimodzimodzi).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // CHITETEZO: `gcdpow` ili ndi malire apamwamba osaposa kuchuluka kwa ma 0-bits mu `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // CHITETEZO: `gcdpow` ili ndi malire apamwamba osaposa kuchuluka kwa ma 0-bits mkati
        // `a`.
        // Kuphatikiza apo, kuchotsako sikungasefuke, chifukwa `a2 = a >> gcdpow` nthawi zonse imakhala yayikulu kuposa `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // CHITETEZO: `a2` ndi mphamvu ziwiri, monga zatsimikizidwira pamwambapa.`s2` ndi yochepera `a2`
        // chifukwa `(s % a) >> gcdpow` ndi yochepera `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Sangafanane konse.
    usize::MAX
}

/// Kuyerekeza zolemba zosaphika kuti zigwirizane.
///
/// Izi ndizofanana ndikugwiritsa ntchito `==`, koma zochepa:
/// zonena ziyenera kukhala zolemba za `*const T` zosaphika, osati chilichonse chomwe chimagwiritsa ntchito `PartialEq`.
///
/// Izi zitha kugwiritsidwa ntchito kuyerekezera zolemba za `&T` (zomwe zimakakamiza `*const T` kwathunthu) ndi adilesi yawo m'malo mofanizira zomwe amalozera (zomwe ndi zomwe `PartialEq for &T` imachita).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Magawo amafananitsidwanso ndi kutalika kwake (mafuta amalozera):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits amafananidwanso ndi kukhazikitsa kwawo:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Olozera ali ndi ma adilesi ofanana.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Zinthu zili ndi ma adilesi ofanana, koma `Trait` imakhala ndimachitidwe osiyanasiyana.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Kusintha kutchulidwa kwa `*const u8` kuyerekezera ndi adilesi.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Chotsani pointer yaiwisi.
///
/// Izi zitha kugwiritsidwa ntchito pofotokozera `&T` (yomwe imakakamiza `*const T` kwathunthu) ndi adilesi yake m'malo mofikira mtengo womwe umaloza (ndizomwe kukhazikitsa `Hash for &T` kumachita).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls ya zolozera ntchito
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Makina apakatikati monga usize amafunika pa AVR
                // kotero kuti malo a adilesi ya source function pointer amasungidwa kumapeto kwa pointer.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Makina apakatikati monga usize amafunika pa AVR
                // kotero kuti malo a adilesi ya source function pointer amasungidwa kumapeto kwa pointer.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Palibe ntchito zosiyanasiyana ndi magawo 0
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Pangani pointer ya `const` yaiwisi pamalo, popanda kupanga mawonekedwe apakatikati.
///
/// Kupanga zolemba ndi `&`/`&mut` kumangololedwa ngati cholozera chikugwirizana bwino ndikuwonetsa zidziwitso zoyambitsidwa.
/// Nthawi zomwe zofunikirazo sizigwira, zikhomo zosaphika ziyenera kugwiritsidwa ntchito m'malo mwake.
/// Komabe, `&expr as *const _` imapanga kutanthauzira isanaponyedwe pa pointer yaiwisi, ndipo kutchulidwako kumatsatira malamulo omwewo monga maumboni ena onse.
///
/// Izi zazikulu zimatha kupanga pointer yaiwisi *popanda* kupanga poyambira.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` itha kupanga cholozera chosagwirizana, motero kukhala Undefined Behaeve!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Pangani pointer ya `mut` yaiwisi pamalo, popanda kupanga mawonekedwe apakatikati.
///
/// Kupanga zolemba ndi `&`/`&mut` kumangololedwa ngati cholozera chikugwirizana bwino ndikuwonetsa zidziwitso zoyambitsidwa.
/// Nthawi zomwe zofunikirazo sizigwira, zikhomo zosaphika ziyenera kugwiritsidwa ntchito m'malo mwake.
/// Komabe, `&mut expr as *mut _` imapanga kutanthauzira isanaponyedwe pa pointer yaiwisi, ndipo kutchulidwako kumatsatira malamulo omwewo monga maumboni ena onse.
///
/// Izi zazikulu zimatha kupanga pointer yaiwisi *popanda* kupanga poyambira.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` itha kupanga cholozera chosagwirizana, motero kukhala Undefined Behaeve!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` amakopa kutengera mundawo m'malo mopanga zolemba.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}