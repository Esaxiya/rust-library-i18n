use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Chozungulirira mozungulira `*mut T` yaiwisi yaiwisi yosonyeza kuti mwini chovundikirachi ndiye mwini wake.
/// Zothandiza popanga zinthu monga `Box<T>`, `Vec<T>`, `String`, ndi `HashMap<K, V>`.
///
/// Mosiyana ndi `*mut T`, `Unique<T>` imakhala "as if" zinali zitsanzo za `T`.
/// Imagwiritsa ntchito `Send`/`Sync` ngati `T` ndi `Send`/`Sync`.
/// Zimatanthauzanso mtundu wa zotsimikizika zamphamvu zomwe zimatsimikizira kuti `T` ingayembekezere:
/// choyimira cha cholozera sayenera kusinthidwa popanda njira yapadera yokhala ndi Chopadera.
///
/// Ngati simukudziwa ngati zili zolondola kugwiritsa ntchito `Unique` pazolinga zanu, lingalirani kugwiritsa ntchito `NonNull`, yomwe ili ndi semantics yofooka.
///
///
/// Mosiyana ndi `*mut T`, cholozera chiyenera kukhala chosasamala, ngakhale cholozera sichingatchulidwenso.
/// Izi ndichifukwa choti ma enum angagwiritse ntchito mtengo woletsedwa ngati tsankho-`Option<Unique<T>>` ili ndi kukula kofanana ndi `Unique<T>`.
/// Komabe cholozera chikhozabe kugwedezeka ngati sichinafotokozeredwe.
///
/// Mosiyana ndi `*mut T`, `Unique<T>` imagwirizana pa `T`.
/// Izi ziyenera kukhala zolondola pamtundu uliwonse womwe umakwaniritsa zofunikira zapadera.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: chikhomo sichikhala ndi zotsatirapo zakusiyana, koma ndikofunikira
    // kuti tileke kumvetsetsa kuti tili ndi `T`.
    //
    // Kuti mumve zambiri, onani:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` zolozera ndi `Send` ngati `T` ndi `Send` chifukwa zomwe amatchulazi zidachotsedwa.
/// Dziwani kuti chosasinthika ichi sichikulimbikitsidwa ndi mtundu wamtunduwu;Kuchotsa pogwiritsa ntchito `Unique` kuyenera kuyikakamiza.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` zolozera ndi `Sync` ngati `T` ndi `Sync` chifukwa zomwe amatchulazi zidachotsedwa.
/// Dziwani kuti chosasinthika ichi sichikulimbikitsidwa ndi mtundu wamtunduwu;Kuchotsa pogwiritsa ntchito `Unique` kuyenera kuyikakamiza.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Amapanga `Unique` yatsopano yomwe ikulendewera, koma yolumikizana bwino.
    ///
    /// Izi ndizothandiza poyambitsa mitundu yomwe imapatsa ulesi, monga `Vec::new` imachitira.
    ///
    /// Dziwani kuti mtengo wa pointer utha kuyimira pointer yoyenera ya `T`, zomwe zikutanthauza kuti izi siziyenera kugwiritsidwa ntchito ngati mtengo wa sentiel "not yet initialized".
    /// Mitundu yomwe imapatsa ulesi iyenera kutsata kuyambitsa ndi njira zina.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // CHITETEZO: mem::align_of() imabwezera cholozera chovomerezeka, chosachita chilichonse.Pulogalamu ya
        // zikhalidwe zoyitanitsa new_unchecked() zimalemekezedwa motero.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Amapanga `Unique` yatsopano.
    ///
    /// # Safety
    ///
    /// `ptr` sayenera kukhala yopanda pake.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // CHITETEZO: woyimbayo akuyenera kutsimikizira kuti `ptr` siyabwino.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Amapanga `Unique` yatsopano ngati `ptr` siyopanda pake.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // CHITETEZO: Cholozera chayang'aniridwa kale ndipo sichiri chopanda pake.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Imapeza cholozera cha `*mut`.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Kutengera zomwe zili.
    ///
    /// Zomwe zimakhalapo nthawi yonseyi zimakhala zaumwini kotero izi zimakhala "as if" zinali zenizeni za T zomwe zikubwerekedwa.
    /// Ngati pakufunika nthawi yayitali ya (unbound), gwiritsani ntchito `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // CHITETEZO: woyimbayo ayenera kutsimikizira kuti `self` ikwaniritsa zonse
        // zofunikira pakuwunika.
        unsafe { &*self.as_ptr() }
    }

    /// Mosagwirizana amawonetsa zomwe zili.
    ///
    /// Zomwe zimakhalapo nthawi yonseyi zimakhala zaumwini kotero izi zimakhala "as if" zinali zenizeni za T zomwe zikubwerekedwa.
    /// Ngati pakufunika nthawi yayitali ya (unbound), gwiritsani ntchito `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // CHITETEZO: woyimbayo ayenera kutsimikizira kuti `self` ikwaniritsa zonse
        // zofunikira pakuwunika kosinthika.
        unsafe { &mut *self.as_ptr() }
    }

    /// Imatengera cholozera chamtundu wina.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // CHITETEZO: Unique::new_unchecked() imapanga zatsopano komanso zosowa zatsopano
        // cholozera chopatsidwa kuti chisakhale chopanda pake.
        // Popeza tikudziyesa tokha ngati cholozera, sichingakhale chopanda pake.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // CHITETEZO: Buku lomwe lingasinthidwe silingakhale lopanda pake
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}