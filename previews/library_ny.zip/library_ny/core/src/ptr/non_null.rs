use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` koma osakhala zero komanso osakanikirana.
///
/// Izi nthawi zambiri zimakhala zolondola pakagwiritsidwe ntchito popanga ma data pogwiritsa ntchito zopangira zosaphika, koma ndizowopsa kugwiritsa ntchito chifukwa cha zina zake.Ngati simukudziwa ngati mukugwiritsa ntchito `NonNull<T>`, ingogwiritsani ntchito `*mut T`!
///
/// Mosiyana ndi `*mut T`, cholozera chiyenera kukhala chosasamala, ngakhale cholozera sichingatchulidwenso.Izi ndichifukwa choti ma enum angagwiritse ntchito mtengo woletsedwa ngati tsankho-`Option<NonNull<T>>` ili ndi kukula kofanana ndi `* mut T`.
/// Komabe cholozera chikhozabe kugwedezeka ngati sichinafotokozeredwe.
///
/// Mosiyana ndi `*mut T`, `NonNull<T>` idasankhidwa kuti ikhale yothandizana ndi `T`.Izi zimapangitsa kuti mugwiritse ntchito `NonNull<T>` popanga mitundu ina, koma zimabweretsa chiopsezo chosagwirizana ngati zigwiritsidwa ntchito mumtundu womwe suyenera kukhala wosakanikirana.
/// (Kusankha kosiyanako kudapangidwira `*mut T` ngakhale kuthekera kwakuti kusakhulupirika kumatha kubwera chifukwa chodzitcha ntchito zosatetezeka.)
///
/// Covariance ndiyolondola pazotetezedwa zambiri, monga `Box`, `Rc`, `Arc`, `Vec`, ndi `LinkedList`.Izi zili choncho chifukwa amapereka API yapagulu yomwe imatsatira malamulo abwinobwino a XOR osinthasintha a Rust.
///
/// Ngati mtundu wanu sungakhale woyenda bwino, muyenera kuonetsetsa kuti uli ndi gawo lina loti lithandizire.Nthawi zambiri mundawu umakhala wa [`PhantomData`] ngati `PhantomData<Cell<T>>` kapena `PhantomData<&'a mut T>`.
///
/// Zindikirani kuti `NonNull<T>` ili ndi `From` Mwachitsanzo ya `&T`.Komabe, izi sizisintha mfundo yoti kusintha kudzera (pointer yochokera ku) kutanthauzira kogawana sikumadziwika pokhapokha ngati kusintha kumachitika mkati mwa [`UnsafeCell<T>`].Zomwezo zimapangidwanso kuti zitheke kusinthidwa kuchokera pagulu limodzi.
///
/// Mukamagwiritsa ntchito `From` yopanda `UnsafeCell<T>`, ndiudindo wanu kuwonetsetsa kuti `as_mut` siyitanidwa, ndipo `as_ptr` siyigwiritsidwe ntchito posintha.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` zolozera siziri `Send` chifukwa zomwe amatchulazi zitha kusinthidwa.
// NB, izi sizofunikira, koma zikuyenera kupereka mauthenga olakwika.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` zolozera siziri `Sync` chifukwa zomwe amatchulazi zitha kusinthidwa.
// NB, izi sizofunikira, koma zikuyenera kupereka mauthenga olakwika.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Amapanga `NonNull` yatsopano yomwe ikulendewera, koma yolumikizana bwino.
    ///
    /// Izi ndizothandiza poyambitsa mitundu yomwe imapatsa ulesi, monga `Vec::new` imachitira.
    ///
    /// Dziwani kuti mtengo wa pointer utha kuyimira pointer yoyenera ya `T`, zomwe zikutanthauza kuti izi siziyenera kugwiritsidwa ntchito ngati mtengo wa sentiel "not yet initialized".
    /// Mitundu yomwe imapatsa ulesi iyenera kutsata kuyambitsa ndi njira zina.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // CHITETEZO: mem::align_of() imabwezeretsa usize wosakhala zero womwe umaponyedwa
        // kwa * mut T.
        // Chifukwa chake, `ptr` siyachabe ndipo zoyitanitsa new_unchecked() zimalemekezedwa.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Imabwezera zomwe zagawidwa pamtengo.Mosiyana ndi [`as_ref`], izi sizikutanthauza kuti mtengowo uyenera kuyambitsidwa.
    ///
    /// Kwa mnzake wosinthika onani [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Mukayitanitsa njirayi, muyenera kuwonetsetsa kuti izi ndi zoona:
    ///
    /// * Cholozera chiyenera kukhala chogwirizana bwino.
    ///
    /// * Iyenera kukhala "dereferencable" malinga ndi tanthauzo la [the module documentation].
    ///
    /// * Muyenera kutsatira malamulo osasunthika a Rust, popeza nthawi yobwezera `'a` imasankhidwa mokha ndipo sizitanthauza nthawi yeniyeniyo ya tsambalo.
    ///
    ///   Makamaka, kwakanthawi kamoyo uno, kukumbukira komwe cholozera sikuyenera kusintha (kupatula mkati mwa `UnsafeCell`).
    ///
    /// Izi zikugwira ntchito ngakhale zotsatira za njirayi sigwiritsidwa ntchito!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // CHITETEZO: woyimbayo ayenera kutsimikizira kuti `self` ikwaniritsa zonse
        // zofunikira pakuwunika.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Imabwezeretsa mafotokozedwe apadera pamtengo.Mosiyana ndi [`as_mut`], izi sizikutanthauza kuti mtengowo uyenera kuyambitsidwa.
    ///
    /// Kwa mnzake wogawana naye [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Mukayitanitsa njirayi, muyenera kuwonetsetsa kuti izi ndi zoona:
    ///
    /// * Cholozera chiyenera kukhala chogwirizana bwino.
    ///
    /// * Iyenera kukhala "dereferencable" malinga ndi tanthauzo la [the module documentation].
    ///
    /// * Muyenera kutsatira malamulo osasunthika a Rust, popeza nthawi yobwezera `'a` imasankhidwa mokha ndipo sizitanthauza nthawi yeniyeniyo ya tsambalo.
    ///
    ///   Makamaka, kwakanthawi kamoyo uno, kukumbukira komwe cholozera sikukuyenera kufikira (kuwerenga kapena kulemba) kudzera pacholozera china chilichonse.
    ///
    /// Izi zikugwira ntchito ngakhale zotsatira za njirayi sigwiritsidwa ntchito!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // CHITETEZO: woyimbayo ayenera kutsimikizira kuti `self` ikwaniritsa zonse
        // zofunikira pakuwunika.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Amapanga `NonNull` yatsopano.
    ///
    /// # Safety
    ///
    /// `ptr` sayenera kukhala yopanda pake.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // CHITETEZO: woyimbayo akuyenera kutsimikizira kuti `ptr` siyabwino.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Amapanga `NonNull` yatsopano ngati `ptr` siyopanda pake.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // CHITETEZO: Cholozera chayang'aniridwa kale ndipo sichiri chopanda pake
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Imagwira chimodzimodzi ndi [`std::ptr::from_raw_parts`], kupatula kuti pointer ya `NonNull` imabwezedwa, mosiyana ndi cholembera cha `*const` yaiwisi.
    ///
    ///
    /// Onani zolemba za [`std::ptr::from_raw_parts`] kuti mumve zambiri.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // CHITETEZO: Zotsatira za `ptr::from::raw_parts_mut` sizothandiza chifukwa `data_address` ndi.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Sungani cholozera (mwina chachikulu) kukhala adilesi ndi metadata.
    ///
    /// Cholozera chitha kumangidwanso pambuyo pake ndi [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Imapeza cholozera cha `*mut`.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Imabwezera zomwe zagawidwa pamtengo.Ngati mtengowo sunakhazikitsidwe, [`as_uninit_ref`] iyenera kugwiritsidwa ntchito m'malo mwake.
    ///
    /// Kwa mnzake wosinthika onani [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Mukayitanitsa njirayi, muyenera kuwonetsetsa kuti izi ndi zoona:
    ///
    /// * Cholozera chiyenera kukhala chogwirizana bwino.
    ///
    /// * Iyenera kukhala "dereferencable" malinga ndi tanthauzo la [the module documentation].
    ///
    /// * Cholozera chikuyenera kuloza poyambirira cha `T`.
    ///
    /// * Muyenera kutsatira malamulo osasunthika a Rust, popeza nthawi yobwezera `'a` imasankhidwa mokha ndipo sizitanthauza nthawi yeniyeniyo ya tsambalo.
    ///
    ///   Makamaka, kwakanthawi kamoyo uno, kukumbukira komwe cholozera sikuyenera kusintha (kupatula mkati mwa `UnsafeCell`).
    ///
    /// Izi zikugwira ntchito ngakhale zotsatira za njirayi sigwiritsidwa ntchito!
    /// (Gawo loyambitsidwa silinafotokozeredwe bwino, koma mpaka lithe, njira yokhayo yotetezeka ndikuwonetsetsa kuti akhazikitsidwa.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // CHITETEZO: woyimbayo ayenera kutsimikizira kuti `self` ikwaniritsa zonse
        // zofunikira pakuwunika.
        unsafe { &*self.as_ptr() }
    }

    /// Imabwezeretsa kutanthauzira kwapadera pamtengo.Ngati mtengowo sunakhazikitsidwe, [`as_uninit_mut`] iyenera kugwiritsidwa ntchito m'malo mwake.
    ///
    /// Kwa mnzake wogawana naye [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Mukayitanitsa njirayi, muyenera kuwonetsetsa kuti izi ndi zoona:
    ///
    /// * Cholozera chiyenera kukhala chogwirizana bwino.
    ///
    /// * Iyenera kukhala "dereferencable" malinga ndi tanthauzo la [the module documentation].
    ///
    /// * Cholozera chikuyenera kuloza poyambirira cha `T`.
    ///
    /// * Muyenera kutsatira malamulo osasunthika a Rust, popeza nthawi yobwezera `'a` imasankhidwa mokha ndipo sizitanthauza nthawi yeniyeniyo ya tsambalo.
    ///
    ///   Makamaka, kwakanthawi kamoyo uno, kukumbukira komwe cholozera sikukuyenera kufikira (kuwerenga kapena kulemba) kudzera pacholozera china chilichonse.
    ///
    /// Izi zikugwira ntchito ngakhale zotsatira za njirayi sigwiritsidwa ntchito!
    /// (Gawo loyambitsidwa silinafotokozeredwe bwino, koma mpaka lithe, njira yokhayo yotetezeka ndikuwonetsetsa kuti akhazikitsidwa.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // CHITETEZO: woyimbayo ayenera kutsimikizira kuti `self` ikwaniritsa zonse
        // zofunikira pakuwunika kosinthika.
        unsafe { &mut *self.as_ptr() }
    }

    /// Imatengera cholozera chamtundu wina.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // CHITETEZO: `self` ndi cholozera cha `NonNull` chomwe sichikhala chopanda pake
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Pangani kagawo kakang'ono kopanda kanthu kochokera pa cholembera chochepa komanso kutalika.
    ///
    /// Mtsutso wa `len` ndi chiwerengero cha **zinthu**, osati kuchuluka kwa mabayiti.
    ///
    /// Ntchitoyi ndi yotetezeka, koma kufotokozera za kubwerera kwake sikutetezeka.
    /// Onani zolemba za [`slice::from_raw_parts`] kuti mupeze chitetezo.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // pangani pointer yamagawo mukamayamba ndi cholozera ku chinthu choyamba
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Dziwani kuti chitsanzochi chikuwonetsa kugwiritsa ntchito njirayi, koma let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // CHITETEZO: `data` ndi cholozera cha `NonNull` chomwe sichikhala chopanda pake
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Imabwezeretsa kutalika kwa kagawo kakang'ono kopanda kanthu.
    ///
    /// Mtengo wobwezeredwa ndi chiwerengero cha **zinthu**, osati kuchuluka kwa mabayiti.
    ///
    /// Ntchitoyi ndi yotetezeka, ngakhale kagawo kakang'ono kopanda kanthu sikangatchulidwenso pagawo chifukwa cholozera sichikhala ndi adilesi yoyenera.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Kubwezeretsa pointer yopanda kanthu pachidutswa cha chidutswacho.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // CHITETEZO: Tikudziwa kuti `self` siyopanda pake.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Kubwezeretsa pointer yaiwisi pachidutswa cha chidutswacho.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Kubwezeretsa kutanthauzira kogawidwa pagawo lazomwe mwina sizinatchulidweko.Mosiyana ndi [`as_ref`], izi sizikutanthauza kuti mtengowo uyenera kuyambitsidwa.
    ///
    /// Kwa mnzake wosinthika onani [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Mukayitanitsa njirayi, muyenera kuwonetsetsa kuti izi ndi zoona:
    ///
    /// * Cholozera chikuyenera kukhala [valid] kuti chiwerengedwe pamasamba ambiri a `ptr.len() * mem::size_of::<T>()`, ndipo chikuyenera kulumikizidwa bwino.Izi zikutanthauza makamaka:
    ///
    ///     * Kukumbukira konse kwa chidutswa ichi kuyenera kukhala mkati mwa chinthu chimodzi chogawa!
    ///       Magawo sangadutse pazinthu zingapo zomwe zapatsidwa.
    ///
    ///     * Cholozera chiyenera kulumikizidwa ngakhale ndi magawo a zero-kutalika.
    ///     Chimodzi mwazifukwa za izi ndikuti kukhathamiritsa kwa enum kumatha kudalira mafotokozedwe (kuphatikiza magawo amtundu uliwonse) osakanikirana komanso osachita kusiyanitsa ndi zina.
    ///
    ///     Mutha kupeza pointer yomwe imagwiritsidwa ntchito ngati `data` yamagawo otalika zero pogwiritsa ntchito [`NonNull::dangling()`].
    ///
    /// * Kukula kwathunthu kwa `ptr.len() * mem::size_of::<T>()` kwa kagawo sikuyenera kukhala kokulirapo kuposa `isize::MAX`.
    ///   Onani zolemba zachitetezo za [`pointer::offset`].
    ///
    /// * Muyenera kutsatira malamulo osasunthika a Rust, popeza nthawi yobwezera `'a` imasankhidwa mokha ndipo sizitanthauza nthawi yeniyeniyo ya tsambalo.
    ///   Makamaka, kwakanthawi kamoyo uno, kukumbukira komwe cholozera sikuyenera kusintha (kupatula mkati mwa `UnsafeCell`).
    ///
    /// Izi zikugwira ntchito ngakhale zotsatira za njirayi sigwiritsidwa ntchito!
    ///
    /// Onaninso [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Imabwezeretsa kutanthauzira kwapadera ku kagawo kazinthu zomwe mwina sizinayambike.Mosiyana ndi [`as_mut`], izi sizikutanthauza kuti mtengowo uyenera kuyambitsidwa.
    ///
    /// Kwa mnzake wogawana naye [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Mukayitanitsa njirayi, muyenera kuwonetsetsa kuti izi ndi zoona:
    ///
    /// * Cholozera chikuyenera kukhala [valid] yowerengera ndikulembera `ptr.len() * mem::size_of::<T>()` ma byte ambiri, ndipo chikuyenera kulumikizidwa bwino.Izi zikutanthauza makamaka:
    ///
    ///     * Kukumbukira konse kwa chidutswa ichi kuyenera kukhala mkati mwa chinthu chimodzi chogawa!
    ///       Magawo sangadutse pazinthu zingapo zomwe zapatsidwa.
    ///
    ///     * Cholozera chiyenera kulumikizidwa ngakhale ndi magawo a zero-kutalika.
    ///     Chimodzi mwazifukwa za izi ndikuti kukhathamiritsa kwa enum kumatha kudalira mafotokozedwe (kuphatikiza magawo amtundu uliwonse) osakanikirana komanso osachita kusiyanitsa ndi zina.
    ///
    ///     Mutha kupeza pointer yomwe imagwiritsidwa ntchito ngati `data` yamagawo otalika zero pogwiritsa ntchito [`NonNull::dangling()`].
    ///
    /// * Kukula kwathunthu kwa `ptr.len() * mem::size_of::<T>()` kwa kagawo sikuyenera kukhala kokulirapo kuposa `isize::MAX`.
    ///   Onani zolemba zachitetezo za [`pointer::offset`].
    ///
    /// * Muyenera kutsatira malamulo osasunthika a Rust, popeza nthawi yobwezera `'a` imasankhidwa mokha ndipo sizitanthauza nthawi yeniyeniyo ya tsambalo.
    ///   Makamaka, kwakanthawi kamoyo uno, kukumbukira komwe cholozera sikukuyenera kufikira (kuwerenga kapena kulemba) kudzera pacholozera china chilichonse.
    ///
    /// Izi zikugwira ntchito ngakhale zotsatira za njirayi sigwiritsidwa ntchito!
    ///
    /// Onaninso [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Izi ndizotetezeka popeza `memory` ndiyotheka kuwerengera ndikulembera ma `memory.len()` ma byte ambiri.
    /// // Dziwani kuti kuyimbira `memory.as_mut()` sikuloledwa pano chifukwa zomwe zanenedwa sizingayambike.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // CHITETEZO: woyimbayo ayenera kutsatira mgwirizano wa chitetezo cha `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Kubwezera cholozera chaiwisi ku chinthu kapena subslice, osachita malire.
    ///
    /// Kuyimbira njirayi ndi cholozera chakunja kapena pomwe `self` sichingafanane ndi *[undefined behaviour]* ngakhale cholembera chotsatira sichinagwiritsidwe ntchito.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // CHITETEZO: woyimbirayo amaonetsetsa kuti `self` ndiyosasinthika ndipo `index` ili m'malire.
        // Zotsatira zake, cholozera chotsatira sichingakhale NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // CHITETEZO: Cholozera chapadera sichingakhale chopanda pake, chifukwa chake zikhalidwe za
        // new_unchecked() amalemekezedwa.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // CHITETEZO: Buku lomwe lingasinthidwe silingakhale lopanda pake.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // CHITETEZO: Buku silingakhale lopanda pake, chifukwa chake zikhalidwe za
        // new_unchecked() amalemekezedwa.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}