#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Amapereka mtundu wa metadata wolozera wa mtundu uliwonse wakalozera.
///
/// # Metadata yolozera
///
/// Mitundu ya pointer yaiwisi ndi mitundu yofotokozera mu Rust imatha kuganiziridwa kuti idapangidwa ndi magawo awiri:
/// cholozera chazidziwitso chomwe chimakhala ndi adilesi yakumbukiro yamtengo, ndi metadata ina.
///
/// Kwa mitundu yosawerengeka (yomwe imagwiritsa ntchito `Sized` traits) komanso mitundu ya `extern`, zolembera zimanenedwa kuti ndi "zopyapyala": metadata ndi yayikulu-zero ndipo mtundu wake ndi `()`.
///
///
/// Zolozera ku [dynamically-sized types][dst] akuti ndi "zokulirapo" kapena "mafuta", ali ndi metadata yopanda zero:
///
/// * Kwa omanga omwe gawo lawo lomaliza ndi DST, metadata ndiye metadata yamunda womaliza
/// * Kwa mtundu wa `str`, metadata ndiye kutalika kwa mabatani ngati `usize`
/// * Mitundu yamagawo ngati `[T]`, metadata ndiye kutalika kwa zinthu monga `usize`
/// * Kwa zinthu trait monga `dyn SomeTrait`, metadata ndi [`DynMetadata<Self>`][DynMetadata] (mwachitsanzo `DynMetadata<dyn SomeTrait>`)
///
/// Mu future, chilankhulo cha Rust chitha kupeza mitundu yatsopano yamitundu yomwe imakhala ndi metadata yosiyanako.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Mfundo ya trait ndi mtundu wake wa `Metadata`, womwe ndi `()` kapena `usize` kapena `DynMetadata<_>` monga tafotokozera pamwambapa.
/// Amasinthidwa mokha pamtundu uliwonse.
/// Titha kuganiza kuti tingayigwiritse ntchito popanga, ngakhale popanda malire ofanana.
///
/// # Usage
///
/// Zolemba zazikulu zitha kuwonongeka mu adilesi yama data ndi metadata yamagawo ndi njira yawo ya [`to_raw_parts`].
///
/// Kapenanso, metadata yokha imatha kuchotsedwa ndi ntchito ya [`metadata`].
/// Buku lina lingaperekedwe ku [`metadata`] ndikukakamizidwa kwathunthu.
///
/// Cholozera (possibly-wide) chitha kuyikidwanso palimodzi kuchokera ku adilesi yake ndi metadata yokhala ndi [`from_raw_parts`] kapena [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Mtundu wa metadata muzolemba ndi maumboni a `Self`.
    #[lang = "metadata_type"]
    // NOTE: Sungani trait bounds mu `static_assert_expected_bounds_for_metadata`
    //
    // mu `library/core/src/ptr/metadata.rs` mogwirizana ndi omwe ali pano:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Zoyimira zamitundu ikukhazikitsa dzina la trait ndi "oonda".
///
/// Izi zikuphatikiza mitundu ya `Sized` ndi mitundu ya `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: osakhazikika izi zisanakhazikike pamalingaliro a trait mchilankhulo?
pub trait Thin = Pointee<Metadata = ()>;

/// Chotsani gawo la metadata la pointer.
///
/// Makhalidwe amtundu wa `*mut T`, `&T`, kapena `&mut T` amatha kupitilizidwa mwachindunji ku ntchitoyi momwe akukakamira ku `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // CHITETEZO: Kupeza phindu kuchokera ku mgwirizano wa `PtrRepr` ndikotetezeka kuyambira * const T
    // ndi PtrComponents<T>khalani ndi mawonekedwe ofanana okumbukira.
    // std yokha ndi yomwe ingapange izi.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Amapanga pointer yaiwisi ya (possibly-wide) kuchokera ku adilesi ya data ndi metadata.
///
/// Ntchitoyi ndi yotetezeka koma cholozera chobwezeredwa sichikhala chotetezeka kuti chisasankhidwe.
/// Kwa magawo, onani zolemba za [`slice::from_raw_parts`] pazofunikira zachitetezo.
/// Pazinthu za trait, metadata iyenera kuchokera pacholozera kupita kumtundu womwewo wotsika.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // CHITETEZO: Kupeza phindu kuchokera ku mgwirizano wa `PtrRepr` ndikotetezeka kuyambira * const T
    // ndi PtrComponents<T>khalani ndi mawonekedwe ofanana okumbukira.
    // std yokha ndi yomwe ingapange izi.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Imagwira ntchito yofanana ndi [`from_raw_parts`], kupatula kuti pointer yaiwisi ya `*mut` imabwezedwa, mosiyana ndi cholembera cha `* const` yaiwisi.
///
///
/// Onani zolemba za [`from_raw_parts`] kuti mumve zambiri.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // CHITETEZO: Kupeza phindu kuchokera ku mgwirizano wa `PtrRepr` ndikotetezeka kuyambira * const T
    // ndi PtrComponents<T>khalani ndi mawonekedwe ofanana okumbukira.
    // std yokha ndi yomwe ingapange izi.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Kuyika pamanja kumafunika kupewa `T: Copy` yomangidwa.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Kuyika pamanja kumafunika kupewa `T: Clone` yomangidwa.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Metadata yamtundu wa chinthu `Dyn = dyn SomeTrait` trait.
///
/// Ndi cholozera ku vtable (pafupifupi foni tebulo) yomwe imayimira zonse zofunikira kuti mugwiritse ntchito konkriti yosungidwa mkati mwa chinthu cha trait.
/// Chofunika kwambiri kuti:
///
/// * kukula kwamtundu
/// * mayikidwe amtundu
/// * cholozera ku mtundu wa `drop_in_place` impl (itha kukhala yopanda chidziwitso chodziwika bwino)
/// * akulozera njira zonse zokhazikitsira mtundu wa trait
///
/// Dziwani kuti atatu oyamba ndi apadera chifukwa amafunikira kugawa, kusiya, ndi kusamutsa chilichonse cha trait.
///
/// Ndizotheka kutchula izi ndi mtundu wamtundu womwe si `dyn` trait chinthu (mwachitsanzo `DynMetadata<u64>`) koma osapeza phindu lantchitoyo.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Choyambirira chodziwika cha zida zonse.Imatsatiridwa ndi zolemba za ntchito za njira za trait.
///
/// Kukhazikitsa kwachinsinsi kwa `DynMetadata::size_of` etc.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Kubwezeretsa kukula kwa mtundu wogwirizana ndi vtable iyi.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Kubwezeretsa mayendedwe amtundu wogwirizana ndi vtable iyi.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Kubwezeretsa kukula ndi mayikidwe pamodzi ngati `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // CHITETEZO: wopangirayo adatulutsa vtable iyi ya konkriti Rust mtundu womwe
        // amadziwika kuti ali ndi mawonekedwe ovomerezeka.Malingaliro omwewo monga `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Zolemba pamanja zimafunika kupewa malire a `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}