Panics ulusi wapano.

Izi zimalola pulogalamu kutha nthawi yomweyo ndikupereka mayankho kwa omwe akuyimba pulogalamuyo.
`panic!` iyenera kugwiritsidwa ntchito pulogalamu ikafika poti sichingalandire.

Macro iyi ndiyo njira yabwino kwambiri yotsimikizirira momwe zinthu zilili komanso mayeso.
`panic!` imagwirizana kwambiri ndi njira ya `unwrap` ya ma enum a [`Option`][ounwrap] ndi [`Result`][runwrap].
Kukhazikitsa konseku kumayitanitsa `panic!` ikaikidwa ku [`None`] kapena [`Err`] mitundu.

Mukamagwiritsa ntchito `panic!()` mutha kutchulira kulipira kwa zingwe, zomwe zimamangidwa pogwiritsa ntchito malembedwe a [`format!`].
Kulipira kumeneku kumagwiritsidwa ntchito pobayira panic mu ulusi wotchedwa Rust, ndikupangitsa ulusi ku panic kwathunthu.

Makhalidwe a `std` hook osasintha, mwachitsanzo
nambala yomwe imayendetsa molunjika panic itayambika, ndikusindikiza uthenga wolipira ku `stderr` limodzi ndi chidziwitso cha file/line/column cha kuyimbira `panic!()`.

Mutha kupitilira panic hook pogwiritsa ntchito [`std::panic::set_hook()`].
Mkati mwa hook a panic atha kupezeka ngati `&dyn Any + Send`, yomwe imakhala ndi `&str` kapena `String` yopempherera pafupipafupi `panic!()`.
Kwa panic wokhala ndi mtundu wina, [`panic_any`] itha kugwiritsidwa ntchito.

[`Result`] enum nthawi zambiri imakhala yankho labwino pobwezeretsa zolakwika kuposa kugwiritsa ntchito `panic!` macro.
Macro awa ayenera kugwiritsidwa ntchito popewa kupitiliza kugwiritsa ntchito zolakwika, monga zochokera kwina.
Zambiri pazokhudza kusamalira zolakwika zikupezeka mu [book].

Onaninso macro [`compile_error!`], pakukweza zolakwika pakuphatikiza.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Kukonzekera kwatsopano

Ngati ulusi waukulu panics uthetsa ulusi wanu wonse ndikumaliza pulogalamu yanu ndi code `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





