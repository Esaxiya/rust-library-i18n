//! Kugwira ntchito kolamula ndikuyerekeza.
//!
//! Gawoli lili ndi zida zosiyanasiyana zoyitanitsa ndikuyerekeza mfundo.Powombetsa mkota:
//!
//! * [`Eq`] ndipo [`PartialEq`] ndi traits zomwe zimakupatsani mwayi wofotokozera kufanana kwathunthu ndi pang'ono pakati pamikhalidwe, motsatana.
//! Kukhazikitsa iwo kumadzaza kwambiri ma `==` ndi `!=`.
//! * [`Ord`] ndi [`PartialOrd`] ndi traits zomwe zimakupatsani mwayi wofotokozera dongosolo lathunthu komanso pang'ono pang'ono pakati pamikhalidwe, motsatana.
//!
//! Kukhazikitsa iwo kumadzaza ma `<`, `<=`, `>`, ndi `>=`.
//! * [`Ordering`] enum imabwezedwa ndi ntchito zazikulu za [`Ord`] ndi [`PartialOrd`], ndipo imalongosola dongosolo.
//! * [`Reverse`] ndi struct yomwe imakupatsani mwayi wosintha dongosolo.
//! * [`max`] ndipo [`min`] ndi ntchito zomwe zimapangidwa kuchokera ku [`Ord`] ndipo zimakupatsani mwayi wopeza miyezo iwiri kapena yocheperako.
//!
//! Kuti mumve zambiri, onani zolemba zonse zomwe zili mundandandawo.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait yofananizira kufanana komwe kuli [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation).
///
/// trait iyi imalola kufanana pang'ono, pamitundu yomwe ilibe ubale wofanana.
/// Mwachitsanzo, pamiyeso yoyandama `NaN != NaN`, mitundu yazoyandama imagwiritsa ntchito `PartialEq` koma osati [`trait@Eq`].
///
/// Momwemo, kufanana kuyenera kukhala (kwa onse `a`, `b`, `c` amtundu wa `A`, `B`, `C`):
///
/// - **Symmetric**: ngati `A: PartialEq<B>` ndi `B: PartialEq<A>`, ndiye **`a==b` amatanthauza`b==a`**;ndipo
///
/// - **Zosintha**: ngati `A: PartialEq<B>` ndi `B: PartialEq<C>` ndi `A:
///   TsankhoEq<C>`, ndiye **` a==b`ndi `b == c` amatanthauza`a==c`**.
///
/// Dziwani kuti ma `B: PartialEq<A>` (symmetric) ndi `A: PartialEq<C>` (transitive) ma impls sakakamizidwa kukhalapo, koma zofunika izi zimagwiranso ntchito zikakhala zilipo.
///
/// ## Derivable
///
/// trait itha kugwiritsidwa ntchito ndi `#[derive]`.Pamene `derive`d pa structs, zochitika ziwiri ndizofanana ngati magawo onse ali ofanana, ndipo osafanana ngati magawo ena sali ofanana.Pomwe `derive`d pa enums, mtundu uliwonse umakhala wofanana wokha osati wofanana ndi mitundu ina.
///
/// ## Kodi ndingagwiritse ntchito bwanji `PartialEq`?
///
/// `PartialEq` imangofuna njira ya [`eq`] kuti ikhazikitsidwe;[`ne`] imafotokozedwa malinga ndi iyo mwachinsinsi.Kukhazikitsa kulikonse kwa [`ne`]*kuyenera* kulemekeza lamulo loti [`eq`] ndiyosiyana kwambiri ndi [`ne`];ndiye kuti, `!(a == b)` ngati ndi `a != b` yokha.
///
/// Kukhazikitsa kwa `PartialEq`, [`PartialOrd`], ndi [`Ord`]*kuyenera* kuvomerezana.Ndikosavuta kuwapangitsa kuti asagwirizane mwadala potenga zina mwa traits ndikugwiritsa ntchito zina mwanjira.
///
/// Kukhazikitsa kwachitsanzo kwa madera omwe mabuku awiri amawerengedwa kuti ndi ofanana ngati ISBN yawo ikugwirizana, ngakhale mawonekedwe ake atasiyana:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Ndingafananize bwanji mitundu iwiri yosiyana?
///
/// Mtundu womwe mungafanane nawo umayang'aniridwa ndi mtundu wa `PartialEq`.
/// Mwachitsanzo, tiyeni tigwiritse ntchito nambala yathu yapitayi pang'ono:
///
/// ```
/// // Zomwe zimachokera<BookFormat>==<BookFormat>kufananitsa
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Kukhazikitsa<Book>==<BookFormat>kufananitsa
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Kukhazikitsa<BookFormat>==<Book>kufananitsa
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Posintha `impl PartialEq for Book` kukhala `impl PartialEq<BookFormat> for Book`, timalola `BookFormat` kufananizidwa ndi`Book`s.
///
/// Kufanizira ngati pamwambapa, komwe kumanyalanyaza magawo ena a struct, kungakhale koopsa.Zitha kubweretsa kuphwanya kosafunikira kwa zofunikira za ubale wofanana.
/// Mwachitsanzo, ngati titasunga kukhazikitsidwa kwa `PartialEq<Book>` kwa `BookFormat` ndikuwonjezera kukhazikitsidwa kwa `PartialEq<Book>` kwa `Book` (mwina kudzera pa `#[derive]` kapena kudzera pakukhazikitsa koyambirira kuchokera pachitsanzo choyamba) ndiye zotsatira zake zitha kuphwanya kusintha:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Njirayi imayesa `self` ndi `other` kuti ikhale yofanana, ndipo imagwiritsidwa ntchito ndi `==`.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Njira iyi imayesa `!=`.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Pezani zazikulu zomwe zikupanga trait `PartialEq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait yofananizira kufanana komwe kuli [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation).
///
/// Izi zikutanthauza kuti, kuwonjezera pa `a == b` ndi `a != b` pokhala zosintha mosamalitsa, kufanana kuyenera kukhala (kwa onse `a`, `b` ndi `c`):
///
/// - reflexive: `a == a`;
/// - zofanana: `a == b` imatanthawuza `b == a`;ndipo
/// - Zosintha: `a == b` ndi `b == c` zimatanthauza `a == c`.
///
/// Malowa sangayang'anitsidwe ndi wolemba, motero `Eq` amatanthauza [`PartialEq`], ndipo alibe njira zowonjezera.
///
/// ## Derivable
///
/// trait itha kugwiritsidwa ntchito ndi `#[derive]`.
/// Pamene `derive`d, chifukwa `Eq` ilibe njira zowonjezera, zimangodziwitsa wopangirayo kuti ichi ndi ubale wofananira osati ubale wofanana.
///
/// Dziwani kuti njira ya `derive` imafuna kuti magawo onse akhale `Eq`, zomwe sizifunidwa nthawi zonse.
///
/// ## Kodi ndingagwiritse ntchito bwanji `Eq`?
///
/// Ngati simungagwiritse ntchito njira ya `derive`, nena kuti mtundu wanu umagwiritsa ntchito `Eq`, yomwe ilibe njira:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // njirayi imagwiritsidwa ntchito ndi#[kutengera] kunena kuti chilichonse chazinthu zamtunduwu chimadzipangira chokha, [zomangamanga zomwe zikupezeka pano zikutanthauza kutanthauza kuchita izi popanda kugwiritsa ntchito njira pa trait iyi ndizosatheka.
    //
    //
    // Izi siziyenera kukhazikitsidwa ndi dzanja.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Pezani zazikulu zomwe zikupanga trait `Eq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: dongosolo limagwiritsidwa ntchito ndi#[derive] ku
// onetsetsani kuti gawo lililonse lamtundu limagwiritsa ntchito Eq.
//
// Izi siziyenera kuwonekera pamakina ogwiritsa ntchito.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Ordering` ndi zotsatira za kufananiza pakati pa mfundo ziwiri.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// Kuyitanitsa komwe mtengo woyerekeza ndi wocheperapo wina.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// Kuyitanitsa komwe mtengo woyerekeza uli wofanana ndi wina.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// Kuyitanitsa komwe mtengo woyerekeza ndi wamkulu kuposa wina.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Kubwezeretsa `true` ngati kuyitanitsa kuli mtundu wa `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Kubwezeretsa `true` ngati kuyitanitsa sikosiyana ndi `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Kubwezeretsa `true` ngati kuyitanitsa kuli mtundu wa `Less`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Kubwezeretsa `true` ngati kuyitanitsa kuli mtundu wa `Greater`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Kubwezeretsa `true` ngati kuyitanitsa mwina ndi `Less` kapena `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Kubwezeretsa `true` ngati kuyitanitsa mwina ndi `Greater` kapena `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Imasintha `Ordering`.
    ///
    /// * `Less` amakhala `Greater`.
    /// * `Greater` amakhala `Less`.
    /// * `Equal` amakhala `Equal`.
    ///
    /// # Examples
    ///
    /// Makhalidwe oyambira:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Njirayi itha kugwiritsidwa ntchito kusintha kufananiza:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // sanjani mitundu kuyambira yayikulu mpaka yaying'ono kwambiri.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Mndende maoda awiri.
    ///
    /// Kubwezeretsa `self` ngati si `Equal`.Kupanda kutero imabweza `other`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Amangirira kuyitanitsa ndi ntchito yomwe yapatsidwa.
    ///
    /// Kubwezeretsa `self` ngati si `Equal`.
    /// Kupanda kutero imayitanitsa `f` ndikubwezera zotsatira.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Wothandizira wopanga kuyitanitsa mobwerezabwereza.
///
/// Izi ndi mthandizi wogwiritsidwa ntchito ndi [`Vec::sort_by_key`] ndipo itha kugwiritsidwa ntchito kusinthira kuyitanitsa gawo la kiyi.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait yamitundu yomwe imapanga [total order](https://en.wikipedia.org/wiki/Total_order).
///
/// Lamulo ndi dongosolo lathunthu ngati lili (kwa onse `a`, `b` ndi `c`):
///
/// - okwana komanso osakanikirana: chimodzimodzi chimodzi mwa `a < b`, `a == b` kapena `a > b` ndichowona;ndipo
/// - transitive, `a < b` and `b < c` amatanthauza `a < c`.Zomwezo ziyenera kugwira zonse za `==` ndi `>`.
///
/// ## Derivable
///
/// trait itha kugwiritsidwa ntchito ndi `#[derive]`.
/// Mukatuluka`d pa structs, ipanga kuyitanitsa kwa [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) kutengera momwe chilengezo chapamwamba mpaka pansi cha mamembala a struct.
///
/// Mukalandira `d pa ma enum, mitundu yosiyanasiyana imalamulidwa ndi kusankha kwawo kotsika mpaka pansi.
///
/// ## Kuyerekeza kwa lexicographical
///
/// Kuyerekeza kwa lexicographical ndi ntchito ndi izi:
///  - Zotsatira ziwiri zimafanizidwa ndi chinthu.
///  - Choyamba chosalongosoka chimatanthawuza kuti ndi mndandanda wanji womwe ndi lexicographically wochepa kapena woposa winayo.
///  - Ngati mndandanda umodzi ndi chiyambi cha wina, chidule chake chimakhala chocheperako poyerekeza ndi chimzake.
///  - Ngati magawo awiri ali ndi zinthu zofananira ndipo ali ofanana, ndiye kuti matchulidwe ake ndi ofanana.
///  - Zotsatira zopanda kanthu ndizochepera pang'ono kuposa zomwe zimachitika zopanda kanthu.
///  - Zotsatira ziwiri zopanda kanthu ndizofanana ndi lexicographically.
///
/// ## Kodi ndingagwiritse ntchito bwanji `Ord`?
///
/// `Ord` imafuna kuti mtunduwo ukhale [`PartialOrd`] ndi [`Eq`] (zomwe zimafuna [`PartialEq`]).
///
/// Kenako muyenera kufotokozera kukhazikitsidwa kwa [`cmp`].Mutha kupeza zothandiza kugwiritsa ntchito [`cmp`] m'minda yamtundu wanu.
///
/// Kukhazikitsa kwa [`PartialEq`], [`PartialOrd`], ndi `Ord`*kuyenera* kuvomerezana.
/// Ndiye kuti, `a.cmp(b) == Ordering::Equal` ngati ndi `a == b` ndi `Some(a.cmp(b)) == a.partial_cmp(b)` yokha pa `a` ndi `b`.
/// Ndikosavuta kuwapangitsa kuti asagwirizane mwadala potenga zina mwa traits ndikugwiritsa ntchito zina mwanjira.
///
/// Nachi chitsanzo pomwe mukufuna kusiyanitsa anthu ndi kutalika kokha, osanyalanyaza `id` ndi `name`:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Njira iyi imabweza [`Ordering`] pakati pa `self` ndi `other`.
    ///
    /// Pamsonkhano, `self.cmp(&other)` imabwezeretsanso kuyitanitsa kofanana ndi mawu akuti `self <operator> other` ngati ndi zoona.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Kuyerekeza ndikubwezeretsa pazikhalidwe ziwiri.
    ///
    /// Kubwezeretsa kukangana kwachiwiri ngati kufananizira kumawatsimikizira kuti akhale ofanana.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Kuyerekeza ndikubwezera zosachepera ziwiri.
    ///
    /// Kubwezeretsa kukangana koyamba ngati kuyerekezera kumawatsimikizira kuti akhale ofanana.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Chepetsani mtengo kwakanthawi.
    ///
    /// Kubwezeretsa `max` ngati `self` ili yayikulu kuposa `max`, ndipo `min` ngati `self` ndi yochepera `min`.
    /// Kupanda kutero izi zimabweza `self`.
    ///
    /// # Panics
    ///
    /// Panics ngati `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Pezani zazikulu zomwe zikupanga trait `Ord`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait yamitengo yomwe ingafanane ndi dongosolo-mtundu.
///
/// Kufanizira kuyenera kukhutiritsa, pa zonse `a`, `b` ndi `c`:
///
/// - asymmetry: ngati `a < b` ndiye `!(a > b)`, komanso `a > b` kutanthauza `!(a < b)`;ndipo
/// - kusintha: `a < b` ndi `b < c` kumatanthauza `a < c`.Zomwezo ziyenera kugwira zonse za `==` ndi `>`.
///
/// Dziwani kuti zofunikira izi zikutanthauza kuti trait palokha iyenera kuchitidwa mozungulira komanso mozungulira: ngati `T: PartialOrd<U>` ndi `U: PartialOrd<V>` ndiye `U: PartialOrd<T>` ndi `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// trait itha kugwiritsidwa ntchito ndi `#[derive]`.Ikuti `derive`d pa structs, ipanga kutanthauzira mawu kutanthauzira kumamveka kuchokera pamwamba mpaka pansi kwa mamembala a struct.
/// Mukalandira `d pa ma enum, mitundu yosiyanasiyana imalamulidwa ndi kusankha kwawo kotsika mpaka pansi.
///
/// ## Kodi ndingagwiritse ntchito bwanji `PartialOrd`?
///
/// `PartialOrd` kumangofunika kukhazikitsidwa kwa njira ya [`partial_cmp`], ndi enawo omwe amachokera pakukhazikitsa kosakhazikika.
///
/// Komabe zimakhalabe zotheka kukhazikitsa enawo padera pamitundu yomwe ilibe dongosolo lathunthu.
/// Mwachitsanzo, manambala oyandama, `NaN < 0 == false` ndi `NaN >= 0 == false` (cf.
/// IEEE 754-2008 gawo 5.11).
///
/// `PartialOrd` imafuna kuti mtundu wanu ukhale [`PartialEq`].
///
/// Kukhazikitsa kwa [`PartialEq`], `PartialOrd`, ndi [`Ord`]*kuyenera* kuvomerezana.
/// Ndikosavuta kuwapangitsa kuti asagwirizane mwadala potenga zina mwa traits ndikugwiritsa ntchito zina mwanjira.
///
/// Ngati mtundu wanu ndi [`Ord`], mutha kugwiritsa ntchito [`partial_cmp`] pogwiritsa ntchito [`cmp`]:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Muthanso kugwiritsa ntchito [`partial_cmp`] paminda yamtundu wanu.
/// Nachi chitsanzo cha mitundu ya `Person` yomwe ili ndi malo oyandama `height` ndiye gawo lokhalo lomwe lingagwiritsidwe ntchito kupatula:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Njirayi imabwezeretsa kuyitanitsa pakati pa `self` ndi `other` ngati wina alipo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Pomwe kufananiza sikutheka:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Njirayi imayesa zochepa kuposa (ya `self` ndi `other`) ndipo imagwiritsidwa ntchito ndi woyendetsa `<`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Njirayi imayesa zochepera kapena zofanana ndi (za `self` ndi `other`) ndipo imagwiritsidwa ntchito ndi woyendetsa `<=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Njirayi imayesa kwambiri kuposa (ya `self` ndi `other`) ndipo imagwiritsidwa ntchito ndi woyendetsa `>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Njirayi imayesa kuposa kapena yofanana (kwa `self` ndi `other`) ndipo imagwiritsidwa ntchito ndi woyendetsa `>=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Pezani zazikulu zomwe zikupanga trait `PartialOrd`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Kuyerekeza ndikubwezera zosachepera ziwiri.
///
/// Kubwezeretsa kukangana koyamba ngati kuyerekezera kumawatsimikizira kuti akhale ofanana.
///
/// Pakatikati imagwiritsa ntchito dzina la [`Ord::min`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Kubwezeretsa osachepera awiri pamalingaliro a ntchito yofananayi.
///
/// Kubwezeretsa kukangana koyamba ngati kuyerekezera kumawatsimikizira kuti akhale ofanana.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Kubwezeretsa chinthu chomwe chimapereka mtengo wocheperako kuchokera pantchito yomwe yatchulidwa.
///
/// Kubwezeretsa kukangana koyamba ngati kuyerekezera kumawatsimikizira kuti akhale ofanana.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Kuyerekeza ndikubwezeretsa pazikhalidwe ziwiri.
///
/// Kubwezeretsa kukangana kwachiwiri ngati kufananizira kumawatsimikizira kuti akhale ofanana.
///
/// Pakatikati imagwiritsa ntchito dzina la [`Ord::max`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Kubwezeretsa pazokwera kwambiri ziwiri pokhudzana ndi kufananizira komwe kwachitika.
///
/// Kubwezeretsa kukangana kwachiwiri ngati kufananizira kumawatsimikizira kuti akhale ofanana.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Kubwezeretsa chinthu chomwe chimapereka mtengo wokwanira kuchokera pantchito yake.
///
/// Kubwezeretsa kukangana kwachiwiri ngati kufananizira kumawatsimikizira kuti akhale ofanana.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Kukhazikitsidwa kwa PartialEq, Eq, PartialOrd ndi Ord yamitundu yakale
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // Dongosolo pano ndikofunikira kuti pakhale msonkhano wabwino kwambiri.
                    // Onani <https://github.com/rust-lang/rust/issues/63758> kuti mumve zambiri.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // Kuponya ma i8 ndikusintha kusiyanasiyana kuti kuitanitse kumabweretsa msonkhano wabwino kwambiri.
            //
            // Onani <https://github.com/rust-lang/rust/issues/66780> kuti mumve zambiri.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // CHITETEZO: bool monga i8 imabwezera 0 kapena 1, chifukwa chake kusiyana sikungakhale china chilichonse
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &zolozera

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}