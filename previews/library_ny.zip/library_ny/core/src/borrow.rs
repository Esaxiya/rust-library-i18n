//! Gawo logwirira ntchito ndi mbiri yobwereka.

#![stable(feature = "rust1", since = "1.0.0")]

/// trait yokhudzana ndi kubwereka.
///
/// Mu Rust, ndizofala kupereka mitundu yosiyanasiyana yamitundu yosiyanasiyana.
/// Mwachitsanzo, malo osungira ndi kasamalidwe ka mtengo akhoza kusankhidwa mwachindunji ngati koyenera kugwiritsa ntchito mitundu yazosanja monga [`Box<T>`] kapena [`Rc<T>`].
/// Kupatula zokutira izi zomwe zitha kugwiritsidwa ntchito ndi mtundu uliwonse, mitundu ina imapereka zinthu zina zomwe zingapangitse kuti zitha kukhala zodula.
/// Chitsanzo cha mtundu wotere ndi [`String`] yomwe imawonjezera kuthekera kokulitsa chingwe ku [`str`] yoyambira.
/// Izi zimafuna kusunga zina zowonjezera zosafunikira pa chingwe chosavuta, chosasinthika.
///
/// Mitunduyi imapereka mwayi wopeza zomwe zatchulidwazo potengera mtundu wa zomwezo.Amati 'amabwerekedwa ngati' mtunduwo.
/// Mwachitsanzo, [`Box<T>`] ikhoza kubwerekedwa ngati `T` pomwe [`String`] ikhoza kubwerekedwa ngati `str`.
///
/// Mitundu imafotokoza kuti imatha kubwerekedwa ngati mtundu wina wa `T` pogwiritsa ntchito `Borrow<T>`, kutchula `T` munjira ya trait ya [`borrow`].Mtundu ndiufulu kubwereka monga mitundu ingapo.
/// Ngati ikufuna kubwerekana ngati mtunduwo-kulola kuti zidziwitsozo zisinthidwe, itha kukhazikitsa [`BorrowMut<T>`].
///
/// Kuphatikiza apo, popereka njira zowonjezera traits, ziyenera kuganiziridwa ngati akuyenera kukhala mofananamo ndi mtundu womwewo chifukwa chokhala ngati choyimira mtunduwo.
/// Code generic imagwiritsa ntchito `Borrow<T>` ikadalira momwe zimakhalira ndi zoonjezera za trait.
/// traits izi zikuwoneka ngati zowonjezera trait bounds.
///
/// Makamaka `Eq`, `Ord` ndi `Hash` ayenera kukhala ofanana ndi zomwe abwereka ndi zomwe ali nazo: `x.borrow() == y.borrow()` iyenera kupereka zotsatira zofananira ndi `x == y`.
///
/// Ngati nambala yachibadwa imangofunika kugwirira ntchito mitundu yonse yomwe ingafotokozere za mtundu wina wa `T`, ndibwino kugwiritsa ntchito [`AsRef<T>`] popeza mitundu yambiri ingayigwiritse ntchito mosamala.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Monga kusonkhanitsa deta, [`HashMap<K, V>`] ili ndi makiyi ndi zofunikira zonse.Ngati makiyi enieni adakulungidwa mu mtundu woyang'anira wamtundu wina, ziyenera kukhalabe zotheka kufunafuna mtengo pogwiritsa ntchito zomwe zili mu kiyiyo.
/// Mwachitsanzo, ngati kiyi ndi chingwe, ndiye kuti mwina imasungidwa ndi mapu a hashi ngati [`String`], pomwe kuyenera kusaka pogwiritsa ntchito [`&str`][`str`].
/// Chifukwa chake, `insert` iyenera kugwira ntchito pa `String` pomwe `get` iyenera kugwiritsa ntchito `&str`.
///
/// Chophweka pang'ono, magawo oyenera a `HashMap<K, V>` amawoneka motere:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // magawo sanatchulidwe
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Mapu onse a hashi ndi generic pamtundu wofunikira `K`.Chifukwa mafungulo awa amasungidwa ndi mapu a hashi, mtundu uwu umayenera kukhala ndi zinsinsi za kiyi.
/// Mukamayika awiri amtengo wapatali, mapuwa amapatsidwa `K` ndipo amafunika kupeza chidebe cholondola cha hashi ndikuwona ngati kiyi ilipo kale kutengera `K`.Chifukwa chake imafuna `K: Hash + Eq`.
///
/// Pofunafuna phindu pamapu, komabe, kutchula `K` monga chinsinsi chofufuzira kungafune kuti nthawi zonse mukhale ndi mtengo womwewo.
/// Pazingwe zamagetsi, izi zikutanthauza kuti mtengo wa `String` uyenera kupangidwira kungofufuza milandu yomwe `str` yokha imapezeka.
///
/// M'malo mwake, njira ya `get` ndiyotengera mtundu wachinsinsi, chotchedwa `Q` mu siginecha ya njirayo pamwambapa.Ikuti `K` imabwereka ngati `Q` pakufuna `K: Borrow<Q>`.
/// Powonjezeranso `Q: Hash + Eq`, zikuwonetsa kufunikira kuti `K` ndi `Q` akhazikitse `Hash` ndi `Eq` traits zomwe zimatulutsa zotsatira zofananira.
///
/// Kukhazikitsidwa kwa `get` kumadalira makamaka kukhazikitsidwa kwa `Hash` pozindikira chidebe cha hashi mwachinsinsi poyimbira `Hash::hash` pamtengo wa `Q` ngakhale idayika fungulo kutengera mtengo wa hash wowerengedwa kuchokera ku mtengo wa `K`.
///
///
/// Zotsatira zake, mapu a hashi amathyola ngati `K` wokutira mtengo wa `Q` ipanga hashi ina kuposa `Q`.Mwachitsanzo, taganizirani kuti muli ndi mtundu wokutira chingwe koma mukuyerekeza makalata a ASCII osanyalanyaza mlandu wawo:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Chifukwa mitengo iwiri yofanana iyenera kutulutsa mtengo wofanana wa hashi, kukhazikitsidwa kwa `Hash` kuyenera kunyalanyaza mlandu wa ASCII, nawonso:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Kodi `CaseInsensitiveString` ingagwiritse ntchito `Borrow<str>`?Itha kutanthauzira chidutswa cha zingwe kudzera pachingwe chake.
/// Koma chifukwa kukhazikitsa kwake `Hash` kumasiyana, kumachita mosiyana ndi `str` motero sikuyenera kukhazikitsa `Borrow<str>`.
/// Ngati ikufuna kulola kuti ena athe kupeza `str`, imatha kuchita izi kudzera pa `AsRef<str>` yomwe siyikhala ndi zofunikira zina.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Amabwereka kuchokera pamtengo wake.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// trait yaimfa yobwereketsa.
///
/// Monga mnzake wa [`Borrow<T>`] trait iyi imalola mtundu kubwereka ngati mtundu wina mwa kupereka zomwe zingasinthe.
/// Onani [`Borrow<T>`] kuti mumve zambiri pankhani yobwereka monga mtundu wina.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Onse amabwereka kuchokera pamtengo wake.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}