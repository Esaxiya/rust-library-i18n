//! Kuphatikiza kosakanikirana kwambiri.
//!
//! Ngati futures ndizosinthasintha, ndiye kuti mitsinje ndi yoyeserera modabwitsa.
//! Ngati mwadzipeza nokha ndi mndandanda wazosangalatsa zamtundu wina, ndipo mukufunika kuti muchitepo kanthu pazomwe mwasonkhanitsa, mudzathamangira ku 'streams'.
//! Mitsinje imagwiritsidwa ntchito kwambiri mu code ya Rust yodziwika bwino, chifukwa chake muyenera kudziwa bwino.
//!
//! Tisanalongosole zambiri, tiyeni tikambirane momwe gawo ili lidapangidwira:
//!
//! # Organization
//!
//! Gawo ili limakonzedwa makamaka ndi mtundu:
//!
//! * [Traits] ndiye gawo lalikulu: traits izi zimatanthauzira mtundu wa mitsinje yomwe ilipo ndi zomwe mungachite nayo.Njira za traits zi ndizoyenera kuyikapo nthawi yowonjezera yowerengera.
//! * Ntchito zimapereka njira zina zopangira mitsinje yoyambira.
//! * Olimba nthawi zambiri amakhala mitundu yobwererera ya njira zosiyanasiyana pa traits ya module iyi.Muyenera kuyang'ana njira yomwe imapanga `struct`, osati `struct` yomwe.
//! Kuti mumve zambiri za chifukwa chake, onani '[Implementing Stream](#implement-stream)'.
//!
//! [Traits]: #traits
//!
//! Ndichoncho!Tiyeni tikumbe m'mitsinje.
//!
//! # Stream
//!
//! Mtima ndi mzimu wa gawo ili ndi [`Stream`] trait.Phata la [`Stream`] likuwoneka motere:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Mosiyana ndi `Iterator`, `Stream` imasiyanitsa njira ya [`poll_next`] yomwe imagwiritsidwa ntchito popanga `Stream`, ndi njira ya (to-be-implemented) `next` yomwe imagwiritsidwa ntchito potentha mtsinje.
//!
//! Ogwiritsa ntchito `Stream` amangofunika kulingalira `next`, yomwe ikaitanidwa, imabweza future yomwe imatulutsa `Option<Stream::Item>`.
//!
//! future yobwezedwa ndi `next` ipereka `Some(Item)` bola pali zinthu, ndipo zonse zikatha, zipereka `None` kuwonetsa kuti iteration yatha.
//! Ngati tikuyembekezera china chake chovuta kuti tithetse, future idikirira mpaka mtsinjewo utakonzeka kubwereranso.
//!
//! Mitsinje yamunthu aliyense ingasankhe kuyambiranso kuyambiranso, motero kuyimbira `next` kumatha kutulutsa `Some(Item)` kapena nthawi ina.
//!
//! Kutanthauzira kwathunthu kwa [`Stream`] kumaphatikizanso njira zina zingapo, koma ndi njira zosakhazikika, zomangidwa pamwamba pa [`poll_next`], chifukwa chake mumazipeza kwaulere.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Kukhazikitsa Mtsinje
//!
//! Kupanga mtsinje wanu kumatengera njira ziwiri: kupanga `struct` kuti mugwire boma, ndikukhazikitsa [`Stream`] ya `struct` imeneyo.
//!
//! Tiyeni tipange mtsinje wotchedwa `Counter` womwe umakhala wochokera ku `1` mpaka `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Choyamba, struct:
//!
//! /// Mtsinje womwe amawerengedwa kuyambira wani mpaka isanu
//! struct Counter {
//!     count: usize,
//! }
//!
//! // tikufuna kuti kuwerenga kwathu kuyambire chimodzi, kotero tiyeni tiwonjezere njira ya new() yothandizira.
//! // Izi sizofunikira kwenikweni, koma ndizosavuta.
//! // Dziwani kuti timayamba `count` pa zero, tiwona chifukwa chake kukhazikitsa `poll_next()`'s pansipa.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Kenako, timakhazikitsa `Stream` pa `Counter` yathu:
//!
//! impl Stream for Counter {
//!     // tikhala tikuwerengera ndi usize
//!     type Item = usize;
//!
//!     // poll_next() ndiyo njira yokhayo yofunikira
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Lonjezerani kuchuluka kwathu.Ichi ndichifukwa chake tidayamba ziro.
//!         self.count += 1;
//!
//!         // Onani ngati tatsiriza kuwerengera kapena ayi.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Mitsinje ndi yaulesi *.Izi zikutanthauza kuti kungopanga mtsinje sikutanthauza _do_ kwathunthu.Palibe chomwe chimachitikadi mpaka mutayitana `next`.
//! Izi nthawi zina zimakhala zosokoneza mukamapanga mtsinje wokhawo chifukwa cha zovuta zake.
//! Wolembetsayo atichenjeza za izi:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;