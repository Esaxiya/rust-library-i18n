use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Mawonekedwe olimbana ndi ma asynchronous iterators.
///
/// Uwu ndiye mtsinje waukulu trait.
/// Kuti mumve zambiri zamalingaliro amitsinje nthawi zambiri, chonde onani [module-level documentation].
/// Makamaka, mungafune kudziwa momwe mungakhalire [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Mtundu wazinthu zomwe zatulutsidwa ndi mtsinjewo.
    type Item;

    /// Yesetsani kutulutsa mtengo wotsatira wamtsinjewu, kulembetsa ntchito yomwe ilipo kuti mudzuke ngati mtengowo sunapezeke, ndikubwezera `None` ngati mtsinjewo watopa.
    ///
    /// # Bweretsani mtengo
    ///
    /// Pali mitundu ingapo yobwereza yomwe ingabwerere, iliyonse yomwe ikusonyeza dera losiyana:
    ///
    /// - `Poll::Pending` zikutanthauza kuti mtengo wotsatira wamtsinjewu sunakonzekebe.Kukhazikitsa kudzaonetsetsa kuti ntchito yapano idzadziwitsidwa phindu lotsatira likakhala litakonzeka.
    ///
    /// - `Poll::Ready(Some(val))` zikutanthauza kuti mtsinje wakwanitsa kutulutsa mtengo, `val`, ndipo utha kubweretsanso zina pazotsatira za `poll_next`.
    ///
    /// - `Poll::Ready(None)` zikutanthauza kuti mtsinje watha, ndipo `poll_next` sayenera kuyitanidwanso.
    ///
    /// # Panics
    ///
    /// Mtsinje ukangomaliza (kubweza `Ready(None)` from `poll_next`), kuyitanitsa njira yake ya `poll_next` mwina panic, kutsekereza kwamuyaya, kapena kuyambitsa mavuto ena; `Stream` trait siyikufuna zofunikira pakayitanidwe koteroko.
    ///
    /// Komabe, popeza njira ya `poll_next` sinatchulidwe `unsafe`, malamulo abwinobwino a Rust amagwiranso ntchito: mayimbidwe sayenera kuyambitsa machitidwe osadziwika (chikumbukiro chakumbuyo, kugwiritsa ntchito molakwika ntchito za `unsafe`, kapena zina zotero), mosasamala kanthu za mtsinjewo.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Kubwezeretsa malire kumtunda wotsalira wa mtsinjewo.
    ///
    /// Makamaka, `size_hint()` imabwezeretsa Tuple pomwe choyambirira ndichotsika, ndipo chinthu chachiwiri ndichapamwamba.
    ///
    /// Hafu yachiwiri ya Tuple yomwe imabwezedwa ndi [`Option`]`<`[usize`]`> `.
    /// A [`None`] apa amatanthauza kuti mwina palibenso gulu lina lodziwika, kapena chapamwamba chimakhala chachikulu kuposa [`usize`].
    ///
    /// # Zolemba pokwaniritsa
    ///
    /// Sikukakamizidwa kuti kukhazikitsa kwamtsinje kumapereka kuchuluka kwa zinthu.Ngolo yamagalimoto imatha kutulutsa zocheperako poyerekeza ndi zam'munsi kapena zochulukirapo kuposa zakumtunda.
    ///
    /// `size_hint()` cholinga chake makamaka chimagwiritsidwa ntchito pokhathamiritsa monga kusungitsa malo azomwe zili mumtsinje, koma siziyenera kudaliridwa mwachitsanzo, siyani malire pamakhodi osatetezeka.
    /// Kukhazikitsa kolakwika kwa `size_hint()` sikuyenera kuyambitsa kuphwanya chitetezo cha kukumbukira.
    ///
    /// Izi zati, kukhazikitsidwa kuyenera kupereka kuyerekezera kolondola, chifukwa apo ayi kukanakhala kuphwanya lamulo la trait.
    ///
    /// Kukhazikitsa kosasintha kumabwezeretsanso `(0,` [`None`]`)`zomwe zili zolondola pamtsinje uliwonse.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}