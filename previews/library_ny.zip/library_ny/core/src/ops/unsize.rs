use crate::marker::Unsize;

/// Trait yomwe imawonetsa kuti ichi ndi cholozera kapena chokulirapo chimodzi, pomwe osasunthika atha kuchitidwa pa pointee.
///
/// Onani [DST coercion RFC][dst-coerce] ndi [the nomicon entry on coercion][nomicon-coerce] kuti mumve zambiri.
///
/// Kwa mitundu ya pointer ya pointin, zolozera ku `T` zizikakamira kulozera ku `U` ngati `T: Unsize<U>` potembenuza kuchokera pa pointer yopyapyala kukhala cholozera mafuta.
///
/// Kwa mitundu yazikhalidwe, kukakamiza komweku kumagwira ntchito pokakamiza `Foo<T>` mpaka `Foo<U>` kuperekera kwa `CoerceUnsized<Foo<U>> for Foo<T>` kulipo.
/// Zolemba zoterezi zitha kulembedwa ngati `Foo<T>` ili ndi gawo limodzi lokha lomwe silili la phantomdata lokhudza `T`.
/// Ngati mtundu wa mundawu ndi `Bar<T>`, kukhazikitsa `CoerceUnsized<Bar<U>> for Bar<T>` kuyenera kukhalapo.
/// Kukakamiza kudzagwira ntchito pokakamiza gawo la `Bar<T>` kukhala `Bar<U>` ndikudzaza magawo ena onse kuchokera ku `Foo<T>` kuti apange `Foo<U>`.
/// Izi zitha kubwereranso kumunda wa pointer ndikukakamiza kuti.
///
/// Nthawi zambiri, kwa maupangiri anzeru mudzakhazikitsa `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, ndi `?Sized` yokhazikitsidwa ndi `T` yomwe.
/// Mitundu yolunga yomwe imayika `T` mwachindunji monga `Cell<T>` ndi `RefCell<T>`, mutha kugwiritsa ntchito `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` mwachindunji.
///
/// Izi zithandizira mitundu ingapo ya `Cell<Box<T>>` kuti igwire ntchito.
///
/// [`Unsize`][unsize] amagwiritsidwa ntchito polemba mitundu yomwe itha kukakamizidwa ku DSTs ngati zili kumbuyo kwa zilozera.Zimayendetsedwa zokha ndi wolemba.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* gulu U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Izi zimagwiritsidwa ntchito poteteza zinthu, kuti muwone ngati njira yolandirira njira ingatumizidwe.
///
/// Chitsanzo chokhazikitsa trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* gulu U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}