/// Khodi yachikhalidwe mkati mwawonongayo.
///
/// Mtengo ukakhala wosafunikanso, Rust imayendetsa "destructor" pamtengowo.
/// Njira yofala kwambiri yomwe kufunikiranso sikofunika ndikoti imatha.Zowononga zitha kuyendabe munthawi zina, koma tiwunikiranso za zitsanzo apa.
/// Kuti mudziwe zina mwa izi, chonde onani gawo la [the reference] pa owononga.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Wowononga uyu ali ndi zinthu ziwiri:
/// - Kuyimbira `Drop::drop` pamtengo umenewu, ngati `Drop` trait yapaderayi ikukhazikitsidwa pamtundu wake.
/// - "drop glue" yomwe imadzipangira yokha yomwe imayitanitsa mobwerezabwereza owononga magawo onse amtengo uwu.
///
/// Monga Rust imangoyitanitsa owononga madera onse omwe ali nawo, simuyenera kukhazikitsa `Drop` nthawi zambiri.
/// Koma pali zochitika zina zomwe zimakhala zothandiza, mwachitsanzo pamitundu yomwe imayang'anira zowunikira mwachindunji.
/// Zomwezo zitha kukhala zokumbukira, zitha kukhala zotanthauzira mafayilo, mwina zokhazikapo netiweki.
/// Mtengo wamtunduwu sudzagwiritsidwanso ntchito, uyenera kukhala "clean up" chida chake potulutsa kukumbukira kapena kutseka fayilo kapena socket.
/// Iyi ndi ntchito yowononga, chifukwa chake ntchito ya `Drop::drop`.
///
/// ## Examples
///
/// Kuti tiwone zowononga zikuchitika, tiyeni tiwone pulogalamu yotsatirayi:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust iyimbira `Drop::drop` ya `_x` kenako kwa onse `_x.one` ndi `_x.two`, kutanthauza kuti kuyendetsa izi kudzasindikiza
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Ngakhale titachotsa kukhazikitsidwa kwa `Drop` kwa `HasTwoDrop`, owononga minda yake amatchulidwabe.
/// Izi zitha kubweretsa
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Simungayitane `Drop::drop` nokha
///
/// Chifukwa `Drop::drop` imagwiritsidwa ntchito kuyeretsa mtengo, zitha kukhala zowopsa kugwiritsa ntchito mtengowu njirayi itadziwika kale.
/// Popeza `Drop::drop` sikhala yake yakeyake, Rust imaletsa kugwiritsa ntchito molakwika posakulolani kuyimbira `Drop::drop` mwachindunji.
///
/// Mwanjira ina, ngati mungayesere kuyitanitsa `Drop::drop` muchitsanzo pamwambapa, mupeza cholakwika pakuphatikizira.
///
/// Ngati mungafune kuyitanitsa wowononga phindu, [`mem::drop`] itha kugwiritsidwa ntchito m'malo mwake.
///
/// [`mem::drop`]: drop
///
/// ## Ikani dongosolo
///
/// Ndi iti mwa ma `HasDrop` athu awiri omwe akutsikira poyamba, komabe?Kwa structs, ndi momwemonso momwe amalengezedwera: woyamba `one`, kenako `two`.
/// Ngati mukufuna kuyesa nokha, mutha kusintha `HasDrop` pamwambapa kuti mukhale ndi zambiri, monga nambala yonse, kenako nkumazigwiritsa ntchito mu `println!` mkati mwa `Drop`.
/// Khalidwe ili limatsimikizika ndi chilankhulo.
///
/// Mosiyana ndi zomanga, zosintha zakomweko zimatsitsidwa motsata:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Izi zisindikiza
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Chonde onani [the reference] kuti mumve malamulo onse.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` ndipo `Drop` ndizapadera
///
/// Simungagwiritse ntchito [`Copy`] ndi `Drop` pamtundu womwewo.Mitundu yomwe ili `Copy` imasindikizidwa kotheratu ndi wopanga, zomwe zimapangitsa kuti zikhale zovuta kwambiri kuneneratu kuti ndi liti, ndipo owononga adzaphedwa kangati.
///
/// Mwakutero, mitundu iyi singakhale ndi owononga.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Ikuwononga wowononga wamtunduwu.
    ///
    /// Njirayi imatchedwa kotheratu mtengo ukachoka, ndipo sungatchulidwe momveka bwino (uku ndiko kulakwitsa kophatikiza [E0040]).
    /// Komabe, ntchito ya [`mem::drop`] mu prelude itha kugwiritsidwa ntchito kuyitanitsa kukhazikitsa kwa `Drop`.
    ///
    /// Njirayi itatchedwa, `self` sinayendetsedwebe.
    /// Izi zimangochitika njira itatha.
    /// Ngati sizinali choncho, `self` ikanakhala yowongoka.
    ///
    /// # Panics
    ///
    /// Popeza [`panic!`] idzaitana `drop` ikamamasulidwa, [`panic!`] iliyonse mukamayendetsa `drop` itha kutaya.
    ///
    /// Dziwani kuti ngakhale panics iyi, mtengowo umawerengedwa kuti waponyedwa;
    /// simuyenera kuyambitsa `drop` kuyitanidwanso.
    /// Izi nthawi zambiri zimangoyendetsedwa ndi wopanga, koma mukamagwiritsa ntchito nambala yosatetezeka, nthawi zina zimachitika mosazindikira, makamaka mukamagwiritsa ntchito [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}