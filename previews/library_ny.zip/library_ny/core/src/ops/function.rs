/// Mtundu wa woyimba foni yemwe amatenga wolandila wosasinthika.
///
/// Nthawi za `Fn` zitha kuyitanidwa mobwerezabwereza osasintha dziko.
///
/// *trait (`Fn`) siyiyenera kusokonezedwa ndi [function pointers] (`fn`).*
///
/// `Fn` imayendetsedwa zokha ndikutseka komwe kumangotenga zosintha zosasinthika zazomwe zajambulidwa kapena osagwiranso chilichonse, komanso (safe) [function pointers] (yokhala ndi mapanga ena, onani zolemba zawo kuti mumve zambiri).
///
/// Kuphatikiza apo, pamtundu uliwonse `F` womwe umagwiritsa ntchito `Fn`, `&F` imagwiritsa ntchito `Fn`, nawonso.
///
/// Popeza [`FnMut`] ndi [`FnOnce`] ndizopambana kwambiri za `Fn`, chilichonse cha `Fn` chitha kugwiritsidwa ntchito ngati gawo lomwe [`FnMut`] kapena [`FnOnce`] likuyembekezeka.
///
/// Gwiritsani ntchito `Fn` ngati chomangiriza pamene mukufuna kulandira gawo lamtundu wofanana ndi ntchito ndipo muyenera kuyitchula mobwerezabwereza komanso osasintha dziko (mwachitsanzo, mukamaitanira nthawi yomweyo).
/// Ngati simukufuna zofunikira izi, gwiritsani ntchito [`FnMut`] kapena [`FnOnce`] ngati malire.
///
/// Onani [chapter on closures in *The Rust Programming Language*][book] kuti mumve zambiri pamutuwu.
///
/// Chodziwikiranso ndich syntax yapadera ya `Fn` traits (mwachitsanzo
/// `Fn(usize, bool) -> usize`).Omwe akufuna kudziwa zambiri za izi atha kunena za [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Kuyimbira kutseka
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Kugwiritsa ntchito `Fn` parameter
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // kuti regex idalire `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Amachita kuyimba foni.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Mtundu wa woyimba foni yemwe amatenga wolandila wosinthika.
///
/// Nthawi za `FnMut` zitha kuyimbidwa mobwerezabwereza ndipo zimatha kusintha boma.
///
/// `FnMut` imagwiritsidwa ntchito pokhapokha potseka komwe kumatenga zosunthika zosunthika za mitundu yojambulidwa, komanso mitundu yonse yomwe imagwiritsa ntchito [`Fn`], mwachitsanzo, (safe) [function pointers] (popeza `FnMut` ndi supertrait ya [`Fn`]).
/// Kuphatikiza apo, pamtundu uliwonse `F` womwe umagwiritsa ntchito `FnMut`, `&mut F` imagwiritsa ntchito `FnMut`, nawonso.
///
/// Popeza [`FnOnce`] ndiyotsogola kwambiri ya `FnMut`, zochitika zilizonse za `FnMut` zitha kugwiritsidwa ntchito pomwe [`FnOnce`] ikuyembekezeredwa, ndipo popeza [`Fn`] ndichoperekera `FnMut`, chilichonse cha [`Fn`] chitha kugwiritsidwa ntchito pomwe `FnMut` ikuyembekezeredwa.
///
/// Gwiritsani ntchito `FnMut` ngati chomangiriza pamene mukufuna kulandira gawo lamtundu wofanana ndi ntchito ndipo muyenera kuyitanira mobwerezabwereza, polola kuti isinthe boma.
/// Ngati simukufuna kuti parameter isinthe boma, gwiritsani ntchito [`Fn`] ngati chomangiriza;ngati simukufunika kuyitchula mobwerezabwereza, gwiritsani ntchito [`FnOnce`].
///
/// Onani [chapter on closures in *The Rust Programming Language*][book] kuti mumve zambiri pamutuwu.
///
/// Chodziwikiranso ndich syntax yapadera ya `Fn` traits (mwachitsanzo
/// `Fn(usize, bool) -> usize`).Omwe akufuna kudziwa zambiri za izi atha kunena za [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Kuyimbira kutsekedwa kosintha mosintha
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Kugwiritsa ntchito `FnMut` parameter
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // kuti regex idalire `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Amachita kuyimba foni.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Mtundu wa woyimba foni yemwe amatenga wolandila ndi phindu lake.
///
/// Nthawi za `FnOnce` zitha kuyimbidwa, koma mwina sizingayimitsidwe kangapo.Chifukwa cha izi, ngati chinthu chokhacho chodziwika pamtundu ndikuti chimagwiritsa ntchito `FnOnce`, chitha kungotchedwa kamodzi.
///
/// `FnOnce` imagwiritsidwa ntchito mongotseka omwe atha kugwiritsa ntchito mitundu yojambulidwa, komanso mitundu yonse yomwe imagwiritsa ntchito [`FnMut`], mwachitsanzo, (safe) [function pointers] (popeza `FnOnce` ndi supertrait ya [`FnMut`]).
///
///
/// Popeza [`Fn`] ndi [`FnMut`] ndizotsitsa za `FnOnce`, chilichonse cha [`Fn`] kapena [`FnMut`] chitha kugwiritsidwa ntchito pomwe `FnOnce` ikuyembekezeredwa.
///
/// Gwiritsani ntchito `FnOnce` ngati chomangiriza pamene mukufuna kulandira gawo lamtundu wofanana ndi ntchito ndipo muyenera kungoyitchula kamodzi.
/// Ngati mukufuna kuyimbira parameter mobwerezabwereza, gwiritsani ntchito [`FnMut`] ngati chomangiriza;ngati mukufuna kuti musasinthe boma, gwiritsani ntchito [`Fn`].
///
/// Onani [chapter on closures in *The Rust Programming Language*][book] kuti mumve zambiri pamutuwu.
///
/// Chodziwikiranso ndich syntax yapadera ya `Fn` traits (mwachitsanzo
/// `Fn(usize, bool) -> usize`).Omwe akufuna kudziwa zambiri za izi atha kunena za [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Kugwiritsa ntchito `FnOnce` parameter
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` imagwiritsa ntchito zosintha zake, chifukwa sizingayendetsedwe kangapo.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Kuyesera kuyitanitsa `func()` kachiwiri kutaya cholakwika cha `use of moved value` cha `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` sangapemphedwenso pakadali pano
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // kuti regex idalire `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Mtundu wobwezeredwa pambuyo poyitanitsa woyimbayo.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Amachita kuyimba foni.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}