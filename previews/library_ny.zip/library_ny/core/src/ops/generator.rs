use crate::marker::Unpin;
use crate::pin::Pin;

/// Zotsatira zakubwezeretsanso kwa jenereta.
///
/// Enum iyi imabwezedwa kuchokera ku njira ya `Generator::resume` ndipo imawonetsa kuthekera kobwerera kwa jenereta.
/// Pakadali pano izi zikufanana ndi poyimitsidwa (`Yielded`) kapena malo othetsera (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Jenereta imayimitsidwa ndi mtengo.
    ///
    /// Dzikoli likuwonetsa kuti jenereta wayimitsidwa, ndipo imafanana ndi mawu a `yield`.
    /// Mtengo woperekedwa munthawiyi umafanana ndi mawu omwe adaperekedwa ku `yield` ndipo amalola ma jenereta kuti apereke mtengo nthawi iliyonse yomwe apereka.
    ///
    ///
    Yielded(Y),

    /// Jenereta yomalizidwa ndi mtengo wobwezera.
    ///
    /// Dzikoli likuwonetsa kuti jenereta yamaliza kumaliza kugwiritsa ntchito mtengo womwe wapatsidwa.
    /// Jenereta akabweza `Complete` zimawerengedwa kuti ndi vuto la mapulogalamu kuyimbiranso `resume`.
    ///
    Complete(R),
}

/// trait imayendetsedwa ndi mitundu ya mainjini opangidwa.
///
/// Ma jenereta, omwe amatchedwanso coroutines, pakadali pano ali chilankhulo choyesera ku Rust.
/// Zowonjezeredwa m'ma [RFC 2033] jenereta pakadali pano cholinga chake ndi kungopangira zomangamanga za async/await koma zikuwonjezekeranso pakupereka tanthauzo la ergonomic kwa omwe akuyambitsa ndi zina zoyambira.
///
///
/// Ma syntax ndi semantics yama jenereta sakhazikika ndipo adzafunika RFC ina kuti ikhazikike.Pakadali pano, syntax ndiyotseka ngati:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Zolemba zambiri za majenereta zitha kupezeka m'buku losakhazikika.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Mtundu wamtengo wapatali wopanga uyu umatulutsa.
    ///
    /// Mtundu wofananirawu umafanana ndi mawu a `yield` ndi mfundo zomwe zimaloledwa kubwezedwa nthawi iliyonse yomwe jenereta ikukolola.
    ///
    /// Mwachitsanzo iterator-as-a-generator itha kukhala ndi `T`, mtundu womwe umayendetsedwa.
    ///
    type Yield;

    /// Mtundu wamtengo womwe jenereta uyu amabwerera.
    ///
    /// Izi zikugwirizana ndi mtundu womwe wabwerera kuchokera ku jenereta mwina ndi mawu a `return` kapena kwathunthu ngati mawu omaliza a jenereta weniweni.
    /// Mwachitsanzo futures itha kugwiritsa ntchito iyi ngati `Result<T, E>` chifukwa imayimira future yomalizidwa.
    ///
    ///
    type Return;

    /// Iyambanso kugwiritsa ntchito wopanga uyu.
    ///
    /// Ntchitoyi iyambiranso kupangidwanso kwa jenereta kapena iyambe kuyambitsa ngati sinatero.
    /// Kuyimbaku kubwereranso kumapeto komaliza kwa kuyimitsidwa kwa jenereta, kuyambiranso kuphedwa kuchokera ku `yield` yaposachedwa.
    /// Jeneretayo ipitiliza kugwira ntchito mpaka itabereka kapena kubwerera, pomwe ntchitoyi ibwerera.
    ///
    /// # Bweretsani mtengo
    ///
    /// Enum ya `GeneratorState` yomwe idabwerera kuchokera ku ntchitoyi ikuwonetsa momwe jenereta akukhalira akubwerera.
    /// Ngati mtundu wa `Yielded` ubwezedwa ndiye kuti jenereta wafika pakayimitsidwa ndipo phindu laperekedwa.
    /// Ma jenereta mdziko lino amapezeka kuti ayambenso nthawi ina.
    ///
    /// Ngati `Complete` ibwezedwa ndiye kuti jenereta watha kumaliza ndi mtengo womwe waperekedwa.Ndizosavomerezeka kuti jenereta iyambitsidwenso.
    ///
    /// # Panics
    ///
    /// Ntchitoyi itha kukhala panic ngati itayitanidwa pambuyo poti mtundu wa `Complete` wabwezeredwa kale.
    /// Pomwe zolembera zamagetsi mchilankhulozi zimatsimikiziridwa kuti panic poyambiranso pambuyo pa `Complete`, izi sizotsimikizika pakuchitika konse kwa `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}