/// Amagwiritsidwa ntchito pochotsa zosasintha, monga `*v`.
///
/// Kuphatikiza pa kugwiritsidwa ntchito pochita kufotokozera mwatsatanetsatane ndi (unary) `*` woyendetsa m'malo osasinthika, `Deref` imagwiritsidwanso ntchito mophatikizira ndi wophatikiza m'malo ambiri.
/// Makinawa amatchedwa ['`Deref` coercion'][more].
/// M'mikhalidwe yosinthika, [`DerefMut`] imagwiritsidwa ntchito.
///
/// Kukhazikitsa `Deref` kwa maupangiri anzeru kumakupatsani mwayi wopeza zomwe zili kumbuyo kwawo, ndichifukwa chake amagwiritsa `Deref`.
/// Kumbali inayi, malamulo okhudzana ndi `Deref` ndi [`DerefMut`] adapangidwa kuti azikhala ndi maupangiri anzeru.
/// Chifukwa cha ichi,**`Deref` iyenera kukhazikitsidwa kokha kwa ma pointer anzeru** kupewa chisokonezo.
///
/// Pazifukwa zofananira,**trait iyi sayenera kulephera**.Kulephera panthawi yoletsedwera kumatha kukhala kosokoneza kwambiri `Deref` ikalembedweratu.
///
/// # Zambiri pakukakamizidwa kwa `Deref`
///
/// Ngati `T` imagwiritsa ntchito `Deref<Target = U>`, ndipo `x` ndiyofunika pamtundu wa `T`, ndiye:
///
/// * M'mikhalidwe yosasintha, `*x` (pomwe `T` siyotchulidwapo kapena cholozera chobiriwira) ndiyofanana ndi `* Deref::deref(&x)`.
/// * Makhalidwe amtundu wa `&T` amakakamizidwa pamitundu yamtundu wa `&U`
/// * `T` imagwiritsa ntchito njira zonse za (immutable) zamtundu wa `U`.
///
/// Kuti mumve zambiri, pitani ku [the chapter in *The Rust Programming Language*][book] komanso magawo owunikira pa [the dereference operator][ref-deref-op], [method resolution] ndi [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Makina omwe ali ndi gawo limodzi lomwe limafikirika posachotsa struct.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Mtundu womwe umatsatira pambuyo pochotsa.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Imafotokozera mtengo.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Amagwiritsidwa ntchito pochotsa ntchito mosasinthika, monga `*v = 1;`.
///
/// Kuphatikiza pa kugwiritsidwa ntchito pochita kufotokozera mwatsatanetsatane ndi (unary) `*` woyendetsa m'malo osinthika, `DerefMut` imagwiritsidwanso ntchito ndi wophatikizira nthawi zambiri.
/// Makinawa amatchedwa ['`Deref` coercion'][more].
/// M'mikhalidwe yosasintha, [`Deref`] imagwiritsidwa ntchito.
///
/// Kukhazikitsa `DerefMut` kwa maupangiri anzeru kumapangitsa kuti kusinthaku kuzikhala kosavuta, ndichifukwa chake amagwiritsa `DerefMut`.
/// Kumbali inayi, malamulo okhudzana ndi [`Deref`] ndi `DerefMut` adapangidwa kuti azikhala ndi maupangiri anzeru.
/// Chifukwa cha ichi,**`DerefMut` iyenera kukhazikitsidwa kokha kwa ma pointer anzeru** kupewa chisokonezo.
///
/// Pazifukwa zofananira,**iyi trait sayenera kulephera konse**.Kulephera panthawi yoletsedwera kumatha kukhala kosokoneza kwambiri `DerefMut` ikalembedweratu.
///
/// # Zambiri pakukakamizidwa kwa `Deref`
///
/// Ngati `T` imagwiritsa ntchito `DerefMut<Target = U>`, ndipo `x` ndiyofunika pamtundu wa `T`, ndiye:
///
/// * M'mikhalidwe yosinthika, `*x` (pomwe `T` sikulozera kapena cholembera chosaphika) ikufanana ndi `* DerefMut::deref_mut(&mut x)`.
/// * Makhalidwe amtundu wa `&mut T` amakakamizidwa pamitundu yamtundu wa `&mut U`
/// * `T` imagwiritsa ntchito njira zonse za (mutable) zamtundu wa `U`.
///
/// Kuti mumve zambiri, pitani ku [the chapter in *The Rust Programming Language*][book] komanso magawo owunikira pa [the dereference operator][ref-deref-op], [method resolution] ndi [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Makina omwe ali ndi gawo limodzi lomwe lingasinthidwe ndikuwonetserako.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Mofanana zimafotokozera mtengo.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Ikuwonetsa kuti struct itha kugwiritsidwa ntchito ngati njira yolandirira, popanda mawonekedwe a `arbitrary_self_types`.
///
/// Izi zimayendetsedwa ndi mitundu ya stdlib pointer monga `Box<T>`, `Rc<T>`, `&T`, ndi `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}