//! Ogwiritsa ntchito zochulukirapo.
//!
//! Kukhazikitsa izi traits kumakupatsani mwayi wokulirapo ogwiritsa ntchito ena.
//!
//! Zina mwa traits zimatumizidwa ndi prelude, chifukwa chake zimapezeka mu pulogalamu iliyonse ya Rust.Ogwira ntchito okha omwe amathandizidwa ndi traits ndiomwe angadzazidwe kwambiri.
//! Mwachitsanzo, wowonjezera (`+`) atha kuseweredwa kudzera mu [`Add`] trait, koma popeza woyang'anira (`=`) alibe othandizira trait, palibe njira yochulukitsira masemic ake.
//! Kuphatikiza apo, gawo ili silipereka njira iliyonse yopangira ogwiritsa ntchito atsopano.
//! Ngati pakufunika kuti musavutike kwambiri kapena ogwiritsa ntchito mwakhama, muyenera kuyang'ana kuma macro kapena mapulagini ophatikizira kuti mutambasulire mawu a Rust.
//!
//! Kukhazikitsa kwa traits kuyenera kukhala kosadabwitsa m'malo awo, pokumbukira tanthauzo lawo komanso [operator precedence].
//! Mwachitsanzo, mukamayendetsa [`Mul`], opaleshoniyi iyenera kufanana ndi kuchulukitsa (ndikugawana zinthu zomwe zikuyembekezeredwa monga mgwirizano).
//!
//! Dziwani kuti oyendetsa `&&` ndi `||` amafupikitsa, mwachitsanzo, amangoyesa ntchito yawo yachiwiri ngati ikuthandizira.Popeza khalidweli silikakamizidwa ndi traits, `&&` ndi `||` sizothandizidwa ngati ogwiritsa ntchito ochulukirapo.
//!
//! Ogwira ntchito ambiri amatenga ma opareshoni awo pamtengo.M'machitidwe omwe siabwinobwino okhudzana ndi mitundu yokhazikika, izi sizikhala vuto.
//! Komabe, kugwiritsa ntchito oyendetsa makinawa mu generic code, kumafuna chisamaliro ngati mfundo ziyenera kugwiritsidwanso ntchito m'malo molola ogwiritsa ntchito kuzidya.Njira imodzi ndikugwiritsa ntchito [`clone`] nthawi zina.
//! Njira ina ndikudalira mitundu yomwe ikukhudzidwa ndikupatsanso ena owonjezera pazowunikira.
//! Mwachitsanzo, pamtundu wogwiritsa ntchito `T` womwe umayenera kuthandizira kuwonjezera, mwina ndibwino kuti onse `T` ndi `&T` akhazikitse traits [`Add<T>`][`Add`] ndi [`Add<&T>`][`Add`] kuti nambala yolembedwera ingalembedwe popanda kupanga kosafunikira.
//!
//!
//! # Examples
//!
//! Chitsanzo ichi chimapanga `Point` struct yomwe imagwiritsa ntchito [`Add`] ndi [`Sub`], kenako ndikuwonetsa kuwonjezera ndikuchotsa ma `Point` awiri.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Onani zolemba za trait iliyonse kuti mugwiritse ntchito mwachitsanzo.
//!
//! [`Fn`], [`FnMut`], ndi [`FnOnce`] traits zimayendetsedwa ndi mitundu yomwe ingapangidwe ngati ntchito.Dziwani kuti [`Fn`] imatenga `&self`, [`FnMut`] imatenga `&mut self` ndipo [`FnOnce`] imatenga `self`.
//! Izi zikugwirizana ndi mitundu itatu ya njira zomwe zingagwiritsidwe ntchito mwanjira inayake: kuyimba-ndi-kulozera, kuyitanitsa-posintha-kutanthauzira, ndi kuyitanitsa-ndi-phindu.
//! Kugwiritsa ntchito kwambiri kwa traits ndikumagwirira ntchito zapamwamba zomwe zimagwira kapena kutsekedwa ngati zotsutsana.
//!
//! Kutenga [`Fn`] ngati parameter:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Kutenga [`FnMut`] ngati parameter:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Kutenga [`FnOnce`] ngati parameter:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` imagwiritsa ntchito zosintha zake, chifukwa sizingayendetsedwe kangapo
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Kuyesera kuyitanitsa `func()` kachiwiri kutaya cholakwika cha `use of moved value` cha `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` sangapemphedwenso pakadali pano
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;