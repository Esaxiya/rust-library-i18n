//! Gawoli limagwiritsa ntchito `Any` trait, yomwe imathandizira kuyimba kwamphamvu kwa mtundu uliwonse wa `'static` panthawi yowunikira nthawi.
//!
//! `Any` yokha itha kugwiritsidwa ntchito kupeza `TypeId`, ndipo ili ndi zina zambiri ikagwiritsidwa ntchito ngati chinthu cha trait.
//! Monga `&dyn Any` (chinthu chobwerekedwa cha trait), ili ndi njira za `is` ndi `downcast_ref`, kuyesa ngati mtengo uli nawo ndi mtundu winawake, ndikutchulanso mtengo wamkati ngati mtundu.
//! Monga `&mut dyn Any`, palinso njira ya `downcast_mut`, yoti titha kutchula zosinthika zamkati mwake.
//! `Box<dyn Any>` imawonjezera njira ya `downcast`, yomwe imayesa kusintha kukhala `Box<T>`.
//! Onani zolemba za [`Box`] kuti mumve zonse.
//!
//! Dziwani kuti `&dyn Any` imangokhala kuyesa ngati mtengo uli wa konkriti, ndipo sungagwiritsidwe ntchito kuyesa ngati mtunduwo ukugwiritsa ntchito trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Zolemba zanzeru ndi `dyn Any`
//!
//! Khalidwe limodzi lomwe muyenera kukumbukira mukamagwiritsa ntchito `Any` ngati chinthu cha trait, makamaka ndi mitundu ngati `Box<dyn Any>` kapena `Arc<dyn Any>`, ndikuti kungoyitana `.type_id()` pamtengo kudzatulutsa `TypeId` ya chidebe *, osati chinthu choyambirira cha trait.
//!
//! Izi zitha kupewedwa potembenuza pointer yanzeru kukhala `&dyn Any` m'malo mwake, yomwe ibweretse `TypeId` ya chinthucho.
//! Mwachitsanzo:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Muyenera kuti mufune izi:
//! let actual_id = (&*boxed).type_id();
//! // ... kuposa izi:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Talingalirani zomwe tikufuna kuti tione phindu lomwe laperekedwa kuntchito.
//! Tikudziwa kufunika komwe tikugwiritsa ntchito popanga Debug, koma sitikudziwa mtundu wake wa konkriti.Tikufuna kupereka chithandizo chapadera ku mitundu ina: potero timasindikiza kutalika kwa zingwe za chingwe zisanachitike.
//! Sitikudziwa mtundu wa konkriti wamtengo wathu panthawi yophatikiza, chifukwa chake tiyenera kugwiritsa ntchito nthawi yowunikira nthawi.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Logger imagwira ntchito yamtundu uliwonse yomwe imagwiritsa ntchito Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Yesetsani kusintha mtengo wathu kukhala `String`.
//!     // Ngati tapambana, tikufuna kutulutsa kutalika kwa String`` komanso mtengo wake.
//!     // Ngati sichoncho, ndi mtundu wina: ingosindikizani osakongoletsa.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Ntchitoyi ikufuna kutulutsa mawonekedwe ake isanakwane kugwira nawo ntchito.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... gwirani ntchito ina
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// trait iliyonse
///////////////////////////////////////////////////////////////////////////////

/// trait kuti muwonetse kuyimba kwamphamvu.
///
/// Mitundu yambiri imagwiritsa ntchito `Any`.Komabe, mtundu uliwonse womwe uli ndi chikhazikitso chosakhala cha `` static '' satero.
/// Onani [module-level documentation][mod] kuti mumve zambiri.
///
/// [mod]: crate::any
// trait siyotetezeka, ngakhale timadalira zenizeni za ntchito yokhayo ya `type_id` mu code yosatetezeka (mwachitsanzo, `downcast`).Nthawi zambiri, limakhala vuto, koma chifukwa chokhacho cha `Any` ndichokhazikitsa bulangeti, palibe nambala ina iliyonse yomwe ingagwiritse ntchito `Any`.
//
// Titha kupangitsa kuti trait izi zisatetezeke-sizingayambitse mavuto, popeza timayang'anira zonse zomwe zikuchitika-koma timasankha kuti zonse sizofunikira kwenikweni ndipo zitha kusokoneza ogwiritsa ntchito kusiyanitsa kwa traits komanso njira zosatetezedwa (mwachitsanzo, `type_id` ikadali yotetezeka kuyimba, koma titha kufunanso kutero.
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Ikupeza `TypeId` ya `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Njira zowonjezera pazinthu zilizonse za trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Onetsetsani kuti zotsatira za mwachitsanzo, kujowina ulusi kumatha kusindikizidwa ndikugwiritsidwa ntchito ndi `unwrap`.
// Sipangakhale kufunikanso pamapeto pake ngati kutumizira kumagwira ntchito mokweza.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Kubwezeretsa `true` ngati mtundu wokhazikitsidwa uli wofanana ndi `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Pezani `TypeId` yamtunduwu yomwe ntchitoyi imalimbikitsidwa.
        let t = TypeId::of::<T>();

        // Pezani `TypeId` yamtundu mu trait chinthu (`self`).
        let concrete = self.type_id();

        // Fananizani onse a `TypeId`s pa kufanana.
        t == concrete
    }

    /// Imabweza zomwe zalembedwazo ngati zili za mtundu `T`, kapena `None` ngati sichoncho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // CHITETEZO: tangowunika ngati tikuloza mtundu woyenera, ndipo titha kudalira
            // kuwunika chitetezo chakumbukiro chifukwa takhazikitsa Chilichonse pamitundu yonse;palibe ma implina ena omwe angakhalepo momwe angatsutsane ndi athu.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Imabwezeretsa kutanthauzira kosinthika pamtengo wokhazikitsidwa ngati uli wa mtundu `T`, kapena `None` ngati sichoncho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // CHITETEZO: tangowunika ngati tikuloza mtundu woyenera, ndipo titha kudalira
            // kuwunika chitetezo chakumbukiro chifukwa takhazikitsa Chilichonse pamitundu yonse;palibe ma implina ena omwe angakhalepo momwe angatsutsane ndi athu.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Pitani patsogolo ku njira yofotokozedwera `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Pitani patsogolo ku njira yofotokozedwera `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Pitani patsogolo ku njira yofotokozedwera `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Pitani patsogolo ku njira yofotokozedwera `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Pitani patsogolo ku njira yofotokozedwera `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Pitani patsogolo ku njira yofotokozedwera `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID ndi njira zake
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` imayimira chizindikiritso chapadera padziko lonse lapansi.
///
/// `TypeId` iliyonse ndichinthu chowoneka bwino chomwe sichimalola kuyang'anitsitsa mkatimo koma chimalola zochitika zoyambira monga kuphatikizira, kuyerekezera, kusindikiza, ndikuwonetsa.
///
///
/// `TypeId` imangopezeka pamitundu yomwe imaperekedwa kwa `'static`, koma malire awa atha kuchotsedwa mu future.
///
/// Pomwe `TypeId` imagwiritsa ntchito `Hash`, `PartialOrd`, ndi `Ord`, tiyenera kudziwa kuti hashes ndi kuyitanitsa kudzasiyana pakati pa Rust.
/// Chenjerani ndi kudalira pa iwo mkati mwa nambala yanu!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Kubwezeretsa `TypeId` yamtundu wamtunduwu wopangidwayo udalimbikitsidwa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Imabwezeretsa dzina la mtundu ngati chingwe chidutswa.
///
/// # Note
///
/// Izi zimapangidwira kuti azigwiritsa ntchito matenda.
/// Zomwe zili mkati ndi mtundu wa zingwe zomwe zidabwezedwazo sizinafotokozeredwe, kupatula kuti ndikulongosola bwino za mtunduwo.
/// Mwachitsanzo, pakati pa zingwe zomwe `type_name::<Option<String>>()` ikhoza kubwerera ndi `"Option<String>"` ndi `"std::option::Option<std::string::String>"`.
///
///
/// Chingwe chobwezeretsedwacho sichiyenera kuwonedwa ngati chodziwikiratu cha mtunduwo popeza mitundu ingapo ingapangire mapu amtundu womwewo.
/// Mofananamo, palibe chitsimikizo kuti magawo onse amtunduwu adzawoneka mu chingwe chomwe chabwezedwacho: mwachitsanzo, zomwe zikuwonetsa moyo wanu wonse sizikuphatikizidwa.
/// Kuphatikiza apo, zotulutsa zimatha kusintha pakati pamitundu ya wopanga.
///
/// Kukhazikitsa kumeneku kumagwiritsa ntchito zomangamanga zomwe zimaphatikizira diagnostics ndi debuginfo, koma izi sizotsimikizika.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Imabwezeretsa dzina la mtundu wa choloza-choloza ngati chidutswa cha chingwe.
/// Izi ndizofanana ndi `type_name::<T>()`, koma zitha kugwiritsidwa ntchito pomwe mtundu wosinthika sapezeka mosavuta.
///
/// # Note
///
/// Izi zimapangidwira kuti azigwiritsa ntchito matenda.Zomwe zilipo ndi mtundu wa chingwe sizinafotokozeredwe, kupatula kuti ndikulongosola kwamtundu wa mtunduwo.
/// Mwachitsanzo, `type_name_of_val::<Option<String>>(None)` imatha kubwerera `"Option<String>"` kapena `"std::option::Option<std::string::String>"`, koma osati `"foobar"`.
///
/// Kuphatikiza apo, zotulutsa zimatha kusintha pakati pamitundu ya wopanga.
///
/// Ntchitoyi siyithetsa zinthu za trait, kutanthauza kuti `type_name_of_val(&7u32 as &dyn Debug)` ikhoza kubwerera `"dyn Debug"`, koma osati `"u32"`.
///
/// Dzinalo siliyenera kuonedwa ngati chizindikiritso chapadera cha mtundu;
/// Mitundu ingapo itha kugawana dzina lomwelo.
///
/// Kukhazikitsa kumeneku kumagwiritsa ntchito zomangamanga zomwe zimaphatikizira diagnostics ndi debuginfo, koma izi sizotsimikizika.
///
/// # Examples
///
/// Sindikizani mitundu yonse yosasintha ndi yoyandama.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}