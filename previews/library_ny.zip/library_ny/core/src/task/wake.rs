#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// A `RawWaker` imalola wokhazikitsa ntchito kuti apange [`Waker`] yomwe imapereka machitidwe okhathamira.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Ili ndi pointer ya data ndi [virtual function pointer table (vtable)][vtable] yomwe imasinthira machitidwe a `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Cholozera chazidziwitso, chomwe chingagwiritsidwe ntchito kusungira zomwe sizingafanane ndi zomwe wakonza.
    /// Izi zitha kukhala mwachitsanzo
    /// chojambulira chofufutira ku `Arc` chomwe chimalumikizidwa ndi ntchitoyi.
    /// Mtengo wamundawu umadutsa pantchito zonse zomwe ndi gawo la vtable ngati gawo loyambirira.
    ///
    data: *const (),
    /// Tebulo la pointer logwira ntchito lomwe limasinthasintha machitidwe a waker.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Pangani `RawWaker` yatsopano kuchokera pa pointer ya `data` ndi `vtable`.
    ///
    /// Cholozera cha `data` chitha kugwiritsidwa ntchito kusungira zomwe sizingafanane ndi zomwe wakonza.Izi zitha kukhala mwachitsanzo
    /// chojambulira chofufutira ku `Arc` chomwe chimalumikizidwa ndi ntchitoyi.
    /// Mtengo wa cholozera ichi udutsa pantchito zonse zomwe zili gawo la `vtable` ngati gawo loyambirira.
    ///
    /// `vtable` imasintha machitidwe a `Waker` omwe amapangidwa kuchokera ku `RawWaker`.
    /// Pa ntchito iliyonse pa `Waker`, ntchito yolumikizidwa mu `vtable` ya `RawWaker` yoyambira idzatchedwa.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Tebulo lolozera la ntchito (vtable) lomwe limatanthauzira machitidwe a [`RawWaker`].
///
/// Cholozera chodutsa pantchito zonse mkati mwa vtable ndi cholozera cha `data` kuchokera pachinthu cha [`RawWaker`] chomwe chili mkati.
///
/// Ntchito zomwe zili mkati mwa pulatifomu zimangoyenera kutchulidwa pa pointer ya `data` ya chinthu chopangidwa bwino cha [`RawWaker`] kuchokera mkati mwa kukhazikitsidwa kwa [`RawWaker`].
/// Kuyimbira chimodzi mwazomwe zilipo pogwiritsa ntchito cholembera china cha `data` kumatha kuyambitsa machitidwe osadziwika.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Ntchitoyi idzatchedwa [`RawWaker`] ikaumbidwa, mwachitsanzo, pamene [`Waker`] momwe [`RawWaker`] imasungidwa imapangidwira.
    ///
    /// Kukhazikitsidwa kwa ntchitoyi kuyenera kusunga zonse zomwe zingafunike pakuwonjezera kwa [`RawWaker`] ndi ntchito yofananira.
    /// Kuyimbira `wake` pazotsatira za [`RawWaker`] kuyenera kuyambitsa kudzutsidwa kwa ntchito yomweyo yomwe ikadadzutsidwa ndi [`RawWaker`] yoyambirira.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Ntchitoyi idzatchedwa `wake` itayitanidwa pa [`Waker`].
    /// Iyenera kudzutsa ntchito yomwe ikukhudzana ndi [`RawWaker`] iyi.
    ///
    /// Kukhazikitsidwa kwa ntchitoyi kuyenera kuwonetsetsa kuti kumasula zomwe zikugwirizana ndi zochitika za [`RawWaker`] ndi ntchito yofananira.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Ntchitoyi idzatchedwa `wake_by_ref` itayitanidwa pa [`Waker`].
    /// Iyenera kudzutsa ntchito yomwe ikukhudzana ndi [`RawWaker`] iyi.
    ///
    /// Ntchitoyi ikufanana ndi `wake`, koma siyiyenera kugwiritsa ntchito cholozera choperekedwacho.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Ntchitoyi imayitanidwa [`RawWaker`] ikagwa.
    ///
    /// Kukhazikitsidwa kwa ntchitoyi kuyenera kuwonetsetsa kuti kumasula zomwe zikugwirizana ndi zochitika za [`RawWaker`] ndi ntchito yofananira.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Pangani `RawWakerVTable` yatsopano kuchokera ku ntchito za `clone`, `wake`, `wake_by_ref`, ndi `drop`.
    ///
    /// # `clone`
    ///
    /// Ntchitoyi idzatchedwa [`RawWaker`] ikaumbidwa, mwachitsanzo, pamene [`Waker`] momwe [`RawWaker`] imasungidwa imapangidwira.
    ///
    /// Kukhazikitsidwa kwa ntchitoyi kuyenera kusunga zonse zomwe zingafunike pakuwonjezera kwa [`RawWaker`] ndi ntchito yofananira.
    /// Kuyimbira `wake` pazotsatira za [`RawWaker`] kuyenera kuyambitsa kudzutsidwa kwa ntchito yomweyo yomwe ikadadzutsidwa ndi [`RawWaker`] yoyambirira.
    ///
    /// # `wake`
    ///
    /// Ntchitoyi idzatchedwa `wake` itayitanidwa pa [`Waker`].
    /// Iyenera kudzutsa ntchito yomwe ikukhudzana ndi [`RawWaker`] iyi.
    ///
    /// Kukhazikitsidwa kwa ntchitoyi kuyenera kuwonetsetsa kuti kumasula zomwe zikugwirizana ndi zochitika za [`RawWaker`] ndi ntchito yofananira.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Ntchitoyi idzatchedwa `wake_by_ref` itayitanidwa pa [`Waker`].
    /// Iyenera kudzutsa ntchito yomwe ikukhudzana ndi [`RawWaker`] iyi.
    ///
    /// Ntchitoyi ikufanana ndi `wake`, koma siyiyenera kugwiritsa ntchito cholozera choperekedwacho.
    ///
    /// # `drop`
    ///
    /// Ntchitoyi imayitanidwa [`RawWaker`] ikagwa.
    ///
    /// Kukhazikitsidwa kwa ntchitoyi kuyenera kuwonetsetsa kuti kumasula zomwe zikugwirizana ndi zochitika za [`RawWaker`] ndi ntchito yofananira.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// `Context` ya ntchito yolimbikitsa.
///
/// Pakadali pano, `Context` imangopereka mwayi wopeza `&Waker` yomwe itha kugwiritsidwa ntchito kudzutsa ntchito yomwe ilipo.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Onetsetsani kuti tili ndi umboni wa future motsutsana ndi kusintha kosintha mwa kukakamiza moyo wonse kukhala wosasinthasintha (nthawi zotsutsana ndi nthawi zotsutsana pomwe nthawi yobwerera-moyo ndiyosiyana).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Pangani `Context` yatsopano kuchokera ku `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Kubwezeretsa kutanthauzira kwa `Waker` pantchito yapano.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` ndi chogwirira chodzutsa ntchito podziwitsa omwe akuyigwira kuti ndiokonzeka kuyendetsedwa.
///
/// Chophimbachi chimaphatikizapo chitsanzo cha [`RawWaker`], chomwe chimatanthawuza machitidwe omwe akudzuka.
///
///
/// Amagwiritsa ntchito [`Clone`], [`Send`], ndi [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Dzutsani ntchito yokhudzana ndi `Waker` iyi.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Kuyitana kwenikweni kwadzuka kumaperekedwa kudzera muntchito yoyitanira ku kukhazikitsa yomwe ikufotokozedwa ndi woperekayo.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Osayimba `drop`-waker adzadyedwa ndi `wake`.
        crate::mem::forget(self);

        // CHITETEZO: Izi ndizabwino chifukwa `Waker::from_raw` ndiyo njira yokhayo
        // kuyambitsa `wake` ndi `data` yofuna wogwiritsa ntchito kuvomereza kuti mgwirizano wa `RawWaker` umasungidwa.
        //
        unsafe { (wake)(data) };
    }

    /// Dzutsani ntchito yokhudzana ndi `Waker` iyi osagwiritsa ntchito `Waker`.
    ///
    /// Izi ndizofanana ndi `wake`, koma zitha kukhala zosafunikira kwenikweni ngati kuli kwake `Waker`.
    /// Njirayi iyenera kukondedwa poyitana `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Kuyitana kwenikweni kwadzuka kumaperekedwa kudzera muntchito yoyitanira ku kukhazikitsa yomwe ikufotokozedwa ndi woperekayo.
        //

        // CHITETEZO: onani `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Imabwezeretsa `true` ngati `Waker` iyi ndi `Waker` ina ayambanso ntchito yomweyo.
    ///
    /// Ntchitoyi imagwira ntchito mwakhama kwambiri, ndipo imatha kubwereranso yabodza ngakhale a `Waker 'atadzutsa ntchito yomweyo.
    /// Komabe, ngati ntchitoyi ibwerera `true`, zimatsimikizika kuti `Waker` adzadzutsa ntchito yomweyo.
    ///
    /// Ntchitoyi imagwiritsidwa ntchito makamaka pokhathamiritsa.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Amapanga `Waker` yatsopano kuchokera ku [`RawWaker`].
    ///
    /// Khalidwe la `Waker` lomwe labwezedwa silinafotokozedwe ngati mgwirizano womwe wafotokozedwa mu zolemba za ["RawWaker"] ndi ["RawWakerVTable"] sunasungidwe.
    ///
    /// Chifukwa chake njirayi siyabwino.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // CHITETEZO: Izi ndizabwino chifukwa `Waker::from_raw` ndiyo njira yokhayo
            // kuyambitsa `clone` ndi `data` yofuna wogwiritsa ntchito kuvomereza kuti mgwirizano wa [`RawWaker`] umasungidwa.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // CHITETEZO: Izi ndizabwino chifukwa `Waker::from_raw` ndiyo njira yokhayo
        // kuyambitsa `drop` ndi `data` yofuna wogwiritsa ntchito kuvomereza kuti mgwirizano wa `RawWaker` umasungidwa.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}