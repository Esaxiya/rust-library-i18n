//! Traits pakusintha pakati pamitundu.
//!
//! traits mu gawo ili zimapereka njira yosinthira kuchokera mtundu wina kupita mtundu wina.
//! trait iliyonse imagwira ntchito yosiyana:
//!
//! - Tsatirani [`AsRef`] trait posinthira kutsika mtengo
//! - Tsatirani [`AsMut`] trait pazosintha zotsika mtengo zosintha
//! - Tsatirani [`From`] trait pakugwiritsa ntchito kutembenuka kwamtengo wapatali
//! - Tsatirani [`Into`] trait pakugwiritsa ntchito kutembenuka kwamtengo wapatali pamitundu yakunja kwa crate
//! - [`TryFrom`] ndi [`TryInto`] traits zimakhala ngati [`From`] ndi [`Into`], koma ziyenera kukhazikitsidwa pomwe kutembenuka kulephera.
//!
//! traits mu gawo ili nthawi zambiri zimagwiritsidwa ntchito ngati trait bound pazantchito zofananira kotero kuti kutsutsana kwamitundu ingapo kumathandizidwa.Onani zolemba za trait iliyonse pazitsanzo.
//!
//! Monga wolemba mulaibulale, nthawi zonse muyenera kukonda kugwiritsa ntchito [`From<T>`][`From`] kapena [`TryFrom<T>`][`TryFrom`] m'malo mwa [`Into<U>`][`Into`] kapena [`TryInto<U>`][`TryInto`], popeza [`From`] ndi [`TryFrom`] zimapereka kusinthasintha kwakukulu ndikupereka kukhazikitsa kofanana kwa [`Into`] kapena [`TryInto`] kwaulere, chifukwa chakuchita bulangeti mulaibulale yanthawi zonse.
//! Mukamayang'ana mtundu usanachitike Rust 1.41, kungakhale kofunikira kukhazikitsa [`Into`] kapena [`TryInto`] mwachindunji mukasinthira mtundu wina kunja kwa crate wapano.
//!
//! # Kukwaniritsa Kwachibadwa
//!
//! - [`AsRef`] ndi [`AsMut`] yodziyimira payokha ngati mtundu wamkati uli wolozera
//! - [``Kuchokera`] `<U>chifukwa T` amatanthauza [`Into"]`</u><T><U>za U`</u>
//! - [`TryFrom`]`<U>for T` amatanthauza [`TryInto`]`</u><T><U>za U`</u>
//! - [`From`] ndipo [`Into`] ndizosinkhasinkha, zomwe zikutanthauza kuti mitundu yonse imatha kukhala ndi `into` iwowo komanso `from` iwowo
//!
//! Onani trait iliyonse pazitsanzo zogwiritsa ntchito.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Kudziwika.
///
/// Zinthu ziwiri ndizofunikira kuzindikira za ntchitoyi:
///
/// - Sikuti nthawi zonse zimakhala zofanana ndi kutseka ngati `|x| x`, popeza kutsekako kumatha kukakamiza `x` kukhala mtundu wina.
///
/// - Imasunthira zolowetsa `x` zopititsa ku ntchitoyi.
///
/// Ngakhale zitha kuwoneka zachilendo kukhala ndi ntchito yomwe imangobwezeretsanso cholowacho, pali zina zosangalatsa.
///
///
/// # Examples
///
/// Kugwiritsa ntchito `identity` osachita chilichonse motsatana ndi zina, zosangalatsa, ntchito:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Tiyeni tiyerekeze kuti kuwonjezera chimodzi ndichinthu chosangalatsa.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Kugwiritsa ntchito `identity` ngati "do nothing" base kesi pamikhalidwe:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Chitani zinthu zosangalatsa ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Kugwiritsa ntchito `identity` kusunga `Some` mitundu ya iterator ya `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Mumakonda kuchita zotchipa zotsika mtengo.
///
/// trait iyi ndi yofanana ndi [`AsMut`] yomwe imagwiritsidwa ntchito potembenuza pakati pazosinthika.
/// Ngati mukufuna kutembenuka kwamtengo wapatali ndibwino kuti mugwiritse ntchito [`From`] ndi mtundu `&T` kapena lembani ntchito yanu.
///
/// `AsRef` ili ndi siginecha yofanana ndi [`Borrow`], koma [`Borrow`] ndiyosiyana pang'ono:
///
/// - Mosiyana ndi `AsRef`, [`Borrow`] ili ndi bulangeti yoyikira `T` iliyonse, ndipo itha kugwiritsidwa ntchito kuvomereza kutanthauzira kapena mtengo.
/// - [`Borrow`] imafunanso kuti [`Hash`], [`Eq`] ndi [`Ord`] pamtengo wobwereka zikufanana ndi mtengo wake.
/// Pazifukwa izi, ngati mukufuna kubwereka gawo limodzi lokhalo la struct mutha kukhazikitsa `AsRef`, koma osati [`Borrow`].
///
/// **Note: trait iyi siyiyenera kulephera **.Ngati kutembenuka kwalephera, gwiritsani ntchito njira yodzipereka yomwe imabweza [`Option<T>`] kapena [`Result<T, E>`].
///
/// # Kukwaniritsa Kwachibadwa
///
/// - `AsRef` zosintha zokha ngati mtundu wamkati uli cholozera kapena chosinthika (mwachitsanzo: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Pogwiritsira ntchito trait bound titha kuvomereza zotsutsana zamitundu yosiyanasiyana bola atha kusandutsidwa mtundu wa `T`.
///
/// Mwachitsanzo: Pogwiritsa ntchito generic yomwe imatenga `AsRef<str>` timawonetsa kuti tikufuna kuvomereza zolemba zonse zomwe zingasinthidwe kukhala [`&str`] ngati mkangano.
/// Popeza onse [`String`] ndi [`&str`] amatsatira `AsRef<str>` titha kuvomereza zonsezo ngati mfundo yolowera.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Amachita kutembenuka.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Tinkakonda kuchita zosintha zotsika mtengo zosinthira.
///
/// trait iyi ndi yofanana ndi [`AsRef`] koma imagwiritsidwa ntchito potembenuza pakati pa zosinthika zosinthika.
/// Ngati mukufuna kutembenuka kwamtengo wapatali ndibwino kuti mugwiritse ntchito [`From`] ndi mtundu `&mut T` kapena lembani ntchito yanu.
///
/// **Note: trait iyi siyiyenera kulephera **.Ngati kutembenuka kwalephera, gwiritsani ntchito njira yodzipereka yomwe imabweza [`Option<T>`] kapena [`Result<T, E>`].
///
/// # Kukwaniritsa Kwachibadwa
///
/// - `AsMut` zosintha zokha ngati mtundu wamkati uli wosinthika (mwachitsanzo: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Pogwiritsa ntchito `AsMut` ngati trait bound pogwira ntchito generic titha kuvomereza zonse zomwe zingasinthidwe kuti zilembere `&mut T`.
/// Chifukwa [`Box<T>`] imagwiritsa ntchito `AsMut<T>` titha kulemba ntchito `add_one` yomwe imatenga zifukwa zonse zomwe zingasinthidwe kukhala `&mut u64`.
/// Chifukwa [`Box<T>`] imagwiritsa ntchito `AsMut<T>`, `add_one` imavomerezanso zotsutsana zamtundu wa `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Amachita kutembenuka.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Kutembenuka kwamtengo wapatali komwe kumadya mtengo wolowetsera.Chosiyana ndi [`From`].
///
/// Mmodzi ayenera kupewa kukhazikitsa [`Into`] ndikugwiritsa ntchito [`From`] m'malo mwake.
/// Kukhazikitsa [`From`] kumapangitsa kuti wina akhazikitse [`Into`] chifukwa chakuchita bwino kwa bulangeti mulaibulale yanthawi zonse.
///
/// Sankhani kugwiritsa ntchito [`Into`] kupitilira [`From`] mukamafotokozera trait bound pa ntchito yofananira kuti muwonetsetse kuti mitundu yokhayo yomwe imagwiritsa ntchito [`Into`] itha kugwiritsidwanso ntchito.
///
/// **Note: trait iyi siyiyenera kulephera **.Ngati kutembenuka kwalephera, gwiritsani ntchito [`TryInto`].
///
/// # Kukwaniritsa Kwachibadwa
///
/// - [`Kuchokera`]`<T>za U` zikutanthauza `Into<U> for T`
/// - [`Into`] ndizosinkhasinkha, zomwe zikutanthauza kuti `Into<T> for T` imayendetsedwa
///
/// # Kukhazikitsa [`Into`] posintha mitundu yakunja muma Rust akale
///
/// Rust 1.41 isanachitike, ngati komwe amapita sikunali mbali ya crate yomwe simunagwiritse ntchito [`From`] mwachindunji.
/// Mwachitsanzo, tengani nambala iyi:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Izi zidzalephera kuphatikiza m'zinenero zakale chifukwa malamulo amasiye a Rust kale anali okhwima pang'ono.
/// Kuti mudutse izi, mutha kugwiritsa ntchito [`Into`] mwachindunji:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Ndikofunikira kudziwa kuti [`Into`] siyimapereka kukhazikitsidwa kwa [`From`] (monga [`From`] imachitira ndi [`Into`]).
/// Chifukwa chake, muyenera kuyesetsa kukhazikitsa [`From`] kenako ndikubwerera ku [`Into`] ngati [`From`] singakwaniritsidwe.
///
/// # Examples
///
/// [`String`] zida [`Into`]`<`(`Vec`] `<` [`u8`]` >> >>:
///
/// Kuti tifotokozere kuti tikufuna ntchito yachibadwa kuti itenge zifukwa zonse zomwe zingasinthidwe kukhala mtundu wa `T`, titha kugwiritsa ntchito trait bound ya [`Into`]`<T>`.
///
/// Mwachitsanzo: Ntchito `is_hello` imatenga mfundo zonse zomwe zingasinthidwe kukhala [`Vec`]`<<[[u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Amachita kutembenuka.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Mukugwiritsa ntchito kutembenuka kwamtengo wapatali mukamadya phindu.Ndikubwezeretsanso [`Into`].
///
/// Mmodzi nthawi zonse ayenera kukonda kukhazikitsa `From` kuposa [`Into`] chifukwa kukhazikitsa `From` kumangopatsa munthu kukhazikitsa [`Into`] chifukwa chakuchita bwino kwa bulangeti mulaibulale yanthawi zonse.
///
///
/// Ingogwiritsani ntchito [`Into`] mukamaloza mtundu usanachitike Rust 1.41 ndikusintha kukhala mtundu wakunja kwa crate wapano.
/// `From` sanathe kutembenuza mitundu iyi m'mitundu yoyamba chifukwa cha malamulo amasiye a Rust.
/// Onani [`Into`] kuti mumve zambiri.
///
/// Sankhani kugwiritsa ntchito [`Into`] pogwiritsa ntchito `From` mukamanena trait bound pa ntchito yachibadwa.
/// Mwanjira iyi, mitundu yomwe imagwiritsa ntchito [`Into`] mwachindunji itha kugwiritsidwanso ntchito ngati zotsutsana.
///
/// `From` imathandizanso pochita zolakwika.Mukamapanga ntchito yomwe ingalephereke, mtundu wobwereranso nthawi zambiri umakhala wa `Result<T, E>`.
/// `From` trait imachepetsa kuthana ndi zolakwika polola kuti ntchito ibwezeretse cholakwika chimodzi chomwe chimaphatikizapo zolakwika zingapo.Onani gawo la "Examples" ndi [the book][book] kuti mumve zambiri.
///
/// **Note: trait iyi siyiyenera kulephera **.Ngati kutembenuka kwalephera, gwiritsani ntchito [`TryFrom`].
///
/// # Kukwaniritsa Kwachibadwa
///
/// - `From<T> for U` amatanthauza ["Into`] <U>pa T`</u>
/// - `From` ndizosinkhasinkha, zomwe zikutanthauza kuti `From<T> for T` imayendetsedwa
///
/// # Examples
///
/// [`String`] zida `From<&str>`:
///
/// Kutembenuka komveka kuchokera ku `&str` kupita ku String kumachitika motere:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Pomwe mukuchita zolakwika nthawi zambiri zimakhala zothandiza kukhazikitsa `From` yamtundu wanu wolakwika.
/// Potembenuza mitundu yazolakwika kukhala yathu yolakwitsa yomwe imafotokoza zolakwika, titha kubwezera cholakwika chimodzi osataya chidziwitso pazomwe zikuyambitsa.
/// Wogwiritsa ntchito '?' amatembenuza mtundu wazolakwika kukhala mtundu wathu wolakwitsa poyimbira `Into<CliError>::into` yomwe imaperekedwa pokhapokha mukamayambitsa `From`.
/// Wolembetsayo ndiye kuti kutsata kwa `Into` kuyenera kugwiritsidwa ntchito.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Amachita kutembenuka.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Kutembenuka koyesera komwe kumadya `self`, komwe kumatha kukhala kapena kotsika mtengo.
///
/// Olemba laibulale sayenera kugwiritsa ntchito trait mwachindunji, koma ayenera kusankha kugwiritsa ntchito [`TryFrom`] trait, yomwe imapereka kusinthasintha kwakukulu ndikupereka kukhazikitsidwa kofanana kwa `TryInto` kwaulere, chifukwa cha kukhazikitsa bulangeti mulaibulale yanthawi zonse.
/// Kuti mumve zambiri pankhaniyi, onani zolemba za [`Into`].
///
/// # Kukhazikitsa `TryInto`
///
/// Izi zikukumana ndi zoletsa komanso kulingalira komweko monga kukhazikitsa [`Into`], onani pamenepo kuti mumve zambiri.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Mtunduwo umabwereranso pakakhala vuto lakutembenuka.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Amachita kutembenuka.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Kutembenuka kosavuta komanso kotetezeka komwe kumatha kulephera mwanjira zina.Ndikubwezeretsanso [`TryInto`].
///
/// Izi ndizothandiza mukamasintha mtundu womwe ungachite bwino pang'ono koma mungafunenso kuwongolera mwapadera.
/// Mwachitsanzo, palibe njira yosinthira [`i64`] kukhala [`i32`] pogwiritsa ntchito [`From`] trait, chifukwa [`i64`] ikhoza kukhala ndi phindu lomwe [`i32`] silingayimire motero kutembenuka kungataye deta.
///
/// Izi zitha kuchitidwa ndikuchepetsa [`i64`] kukhala [`i32`] (makamaka kupereka mtengo wa [`i64`] modulo [`i32::MAX`]) kapena pongobweza [`i32::MAX`], kapena njira ina.
/// [`From`] trait idapangidwa kuti isinthe mwangwiro, kotero `TryFrom` trait imadziwitsa wopanga mapulogalamuwo ngati kutembenuka kwamtundu wina kumatha kukhala koipa ndikuwalola kusankha momwe angachitire.
///
/// # Kukwaniritsa Kwachibadwa
///
/// - `TryFrom<T> for U` amatanthauza [`YesaniInto`] <U>kwa T`</u>
/// - [`try_from`] ndiyosinkhasinkha, zomwe zikutanthauza kuti `TryFrom<T> for T` imayendetsedwa ndipo siyingalephereke-mtundu wa `Error` wogwirizana woyimbira `T::try_from()` pamtengo wamtundu wa `T` ndi [`Infallible`].
/// Mtundu wa [`!`] ukakhazikika [`Infallible`] ndipo [`!`] zikhala zofanana.
///
/// `TryFrom<T>` itha kukhazikitsidwa motere:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Monga tafotokozera, [`i32`] imagwiritsa ntchito `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Chete truncates `big_number`, imafuna kuzindikira ndi kuyendetsa truncation pambuyo pake.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Kubwezeretsa cholakwika chifukwa `big_number` ndi yayikulu kwambiri kuti singafanane ndi `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Kubwezeretsa `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Mtunduwo umabwereranso pakakhala vuto lakutembenuka.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Amachita kutembenuka.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// KUSINTHA KWAMBIRI
////////////////////////////////////////////////////////////////////////////////

// Pamene akukwera&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Pokweza &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): sinthanitsani ma impls omwe ali pamwambapa a&/&mut ndi awa ena ambiri:
// // Monga akukweza Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>for D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut imakweza &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): sinthanitsani zomwe zili pamwambapa za &mut ndi izi:
// // AsMut imakweza DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Kukulitsa> AsMut <U>ya D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Kuchokera kumatanthauza Into
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Kuchokera (motero kulowa) ndikosintha
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Kukhazikika kokhazikika:** Kuyika uku kulibe, koma ndife "reserving space" kuti tiwonjezere mu future.
/// Onani [rust-lang/rust#64715][#64715] kuti mumve zambiri.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): konzani mfundo m'malo mwake.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom amatanthauza TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Kutembenuka kosalephera kumakhala kofanana ndi kutembenuka kolakwika ndi mtundu wolakwika wopanda anthu.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// KUSINTHA KWA CRCRETE
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// MTUNDU WOSALAKWITSA
////////////////////////////////////////////////////////////////////////////////

/// Mtundu wolakwika wa zolakwika zomwe sizingachitike.
///
/// Popeza enum iyi ilibe zosiyana, mtengo wamtunduwu sungakhalepodi.
/// Izi zitha kukhala zothandiza pama API achibadwa omwe amagwiritsa ntchito [`Result`] ndikusintha mtundu wolakwika, kuwonetsa kuti zotsatira zake nthawi zonse zimakhala [`Ok`].
///
/// Mwachitsanzo, [`TryFrom`] trait (kutembenuka komwe kumabwezeretsa [`Result`]) ili ndi kukhazikitsa bulangeti kwamitundu yonse komwe kukhazikitsidwa kwa [`Into`] kulipo.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Kugwirizana kwa Future
///
/// Enum iyi ili ndi gawo lofanana ndi [the `!`“never”type][never], lomwe silinakhazikike mu mtundu uwu wa Rust.
/// `!` ikakhazikika, tikukonzekera kupanga `Infallible` ngati mtundu winawake:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Ndipo pamapeto pake achotsa `Infallible`.
///
/// Komabe pali vuto limodzi pomwe syntax ya `!` ingagwiritsidwe ntchito `!` isanakhazikike ngati mtundu wathunthu: pamtundu wobwerera ntchito.
/// Makamaka, ndizotheka kukhazikitsa mitundu iwiri yosiyana ya pointer:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Ndi `Infallible` pokhala enum, code iyi ndi yolondola.
/// Komabe `Infallible` ikadzakhala dzina la never type, `ma impl` awiriwo ayamba kudutsana ndipo chifukwa chake adzaletsedwa ndi malamulo azolumikizana a trait.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}