#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Muli matanthauzidwe amtundu wamakonzedwe amitundu yophatikizira.
//!
//! Zitha kugwiritsidwa ntchito ngati chandamale chamatumizidwe osakhala achitetezo chogwiritsa ntchito zowonekera mwachindunji.
//!
//!
//! Kutanthauzira kwawo kuyenera kufanana nthawi zonse ndi ABI yofotokozedwa mu `rustc_middle::ty::layout`.
//!

/// Chiwonetsero cha chinthu cha trait ngati `&dyn SomeTrait`.
///
/// Kapangidwe kameneka kali ndi mawonekedwe ofanana ndi mitundu ngati `&dyn SomeTrait` ndi `Box<dyn AnotherTrait>`.
///
/// `TraitObject` chotsimikizika kuti chikufanana ndi masanjidwe, koma si mtundu wa zinthu za trait (mwachitsanzo, minda siyikupezeka mwachindunji pa `&dyn SomeTrait`) komanso siziwongolera masanjidwewo (kusintha tanthauzo sikungasinthe mawonekedwe a `&dyn SomeTrait`).
///
/// Zangopangidwa kuti zizigwiritsidwa ntchito ndi nambala yosatetezeka yomwe imafunikira kuti ichite zinthu zotsika.
///
/// Palibe njira yodziwira zinthu zonse za trait mwanjira zambiri, chifukwa chake njira yokhayo yopangira zofunikira zamtunduwu ndi ntchito ngati [`std::mem::transmute`][transmute].
/// Momwemonso, njira yokhayo yopangira chinthu chowona cha trait kuchokera pamtengo wa `TraitObject` ili ndi `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Kuphatikiza chinthu cha trait ndi mitundu yosagwirizana-imodzi yomwe vtable silingafanane ndi mtundu wamtengo womwe cholozera cha data-imatha kuchititsa kuti munthu akhale wopanda tanthauzo.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // chitsanzo trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // lolani wopanga kuti apange chinthu cha trait
/// let object: &dyn Foo = &value;
///
/// // yang'anani kuyimira kofiira
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // cholozera deta ndi adilesi ya `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // pangani chinthu chatsopano, kulozera ku `i32` yosiyana, kukhala osamala kugwiritsa ntchito `i32` vtable kuchokera ku `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // Iyenera kugwira ntchito ngati kuti tidapanga chinthu cha trait kuchokera ku `other_value` molunjika
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}