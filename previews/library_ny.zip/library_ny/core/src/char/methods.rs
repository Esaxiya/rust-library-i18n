//! impl char char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Nambala yovomerezeka kwambiri yomwe `char` ingakhale nayo.
    ///
    /// `char` ndi [Unicode Scalar Value], zomwe zikutanthauza kuti ndi [Code Point], koma okhawo amtundu wina.
    /// `MAX` ndiye nambala yovomerezeka kwambiri yomwe ndi [Unicode Scalar Value] yoyenera.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () imagwiritsidwa ntchito mu Unicode kuyimira cholakwika chododometsa.
    ///
    /// Zitha kuchitika, mwachitsanzo, popereka ma UTF-8 byte opangidwa ndi [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Mtundu wa [Unicode](http://www.unicode.org/) womwe magawo a Unicode amachitidwe a `char` ndi `str` adakhazikitsidwa.
    ///
    /// Mitundu yatsopano ya Unicode imamasulidwa pafupipafupi ndipo pambuyo pake njira zonse mulaibulale yanthawi zonse kutengera Unicode zimasinthidwa.
    /// Chifukwa chake machitidwe a njira zina za `char` ndi `str` komanso kufunika kwa kusinthaku kosasintha pakapita nthawi.
    /// Izi sizikuwoneka ngati kusintha kwakanthawi.
    ///
    /// Makina owerengera manambala amafotokozedwa mu [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Imapanga iterator pamalingaliro a UTF-16 omwe ali ndi ma code mu `iter`, ndikubwezeretsa omwe sanalandire ntchito ngati `Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Chododometsa chotayika chitha kupezeka posintha zotsatira za `Err` ndikusintha munthu:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Imatembenuza `u32` kukhala `char`.
    ///
    /// Dziwani kuti ma `char onse ndi ovomerezeka [` u32`] s, ndipo atha kuponyedwa kumodzi ndi
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Komabe, kusinthaku sikuli koona: sizovomerezeka zonse [`u32`] s ndizovomerezeka`char`s.
    /// `from_u32()` idzabwezera `None` ngati kulowetsa sikofunika kwa `char`.
    ///
    /// Kuti mumve bwino za ntchitoyi yomwe imanyalanyaza cheke ichi, onani [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Kubwezeretsa `None` pomwe kulowetsa sikuli `char` yovomerezeka:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Imatembenuza `u32` kukhala `char`, ikunyalanyaza kuvomerezeka.
    ///
    /// Dziwani kuti ma `char onse ndi ovomerezeka [` u32`] s, ndipo atha kuponyedwa kumodzi ndi
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Komabe, kusinthaku sikuli koona: sizovomerezeka zonse [`u32`] s ndizovomerezeka`char`s.
    /// `from_u32_unchecked()` anyalanyaza izi, ndikuponyera ku `char` mwakachetechete, mwina atha kupanga zosavomerezeka.
    ///
    ///
    /// # Safety
    ///
    /// Ntchitoyi ndi yosatetezeka, chifukwa itha kupanga zolakwika za `char`.
    ///
    /// Kuti muwone bwino ntchitoyi, onani ntchito ya [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // CHITETEZO: mgwirizano wachitetezo uyenera kusungidwa ndi woyimbirayo.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Imatembenuza manambala mu radix yomwe yapatsidwa kukhala `char`.
    ///
    /// 'radix' apa nthawi zina amatchedwanso 'base'.
    /// Radix ya awiri imawonetsa nambala ya binary, radix ya ten, decimal, ndi radix ya khumi ndi zisanu ndi chimodzi, hexadecimal, kuti ipereke zofunikira zofananira.
    ///
    /// Ma radic osasinthika amathandizidwa.
    ///
    /// `from_digit()` ibwerera `None` ngati cholowacho sichili nambala mu radix yomwe yapatsidwa.
    ///
    /// # Panics
    ///
    /// Panics ngati yapatsidwa radix yoposa 36.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Decimal 11 ndi nambala imodzi m'munsi 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Kubwezeretsa `None` pomwe kulowetsa sikunambala:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Kupititsa radix yayikulu, kuyambitsa panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Macheke ngati `char` ndi manambala mu radix yomwe yapatsidwa.
    ///
    /// 'radix' apa nthawi zina amatchedwanso 'base'.
    /// Radix ya awiri imawonetsa nambala ya binary, radix ya ten, decimal, ndi radix ya khumi ndi zisanu ndi chimodzi, hexadecimal, kuti ipereke zofunikira zofananira.
    ///
    /// Ma radic osasinthika amathandizidwa.
    ///
    /// Poyerekeza ndi [`is_numeric()`], ntchitoyi imangodziwa zilembo `0-9`, `a-z` ndi `A-Z`.
    ///
    /// 'Digit' amatanthauzidwa kuti ndi okhawo olemba:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Kuti mumvetsetse bwino 'digit', onani [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics ngati yapatsidwa radix yoposa 36.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Kupititsa radix yayikulu, kuyambitsa panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Imatembenuza `char` kukhala manambala mu radix yomwe yapatsidwa.
    ///
    /// 'radix' apa nthawi zina amatchedwanso 'base'.
    /// Radix ya awiri imawonetsa nambala ya binary, radix ya ten, decimal, ndi radix ya khumi ndi zisanu ndi chimodzi, hexadecimal, kuti ipereke zofunikira zofananira.
    ///
    /// Ma radic osasinthika amathandizidwa.
    ///
    /// 'Digit' amatanthauzidwa kuti ndi okhawo olemba:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Kubwezeretsa `None` ngati `char` sikukutanthauza manambala mu radix yomwe yapatsidwa.
    ///
    /// # Panics
    ///
    /// Panics ngati yapatsidwa radix yoposa 36.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Kupereka zotsatira zopanda manambala kulephera:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Kupititsa radix yayikulu, kuyambitsa panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // codeyo imagawanika apa kuti ipititse patsogolo kuthamanga kwa milandu pomwe `radix` ndiyokhazikika komanso 10 kapena yaying'ono
        //
        let val = if likely(radix <= 10) {
            // Ngati sichingakhale nambala, nambala yochulukirapo kuposa radix ipangidwa.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Kubwezeretsa iterator yomwe imapereka hexadecimal Unicode kuthawa kwa munthu ngati `char`s.
    ///
    /// Izi zidzathawa zilembo ndi Rust zomasulira za fomu `\u{NNNNNN}` pomwe `NNNNNN` ndi hexadecimal.
    ///
    ///
    /// # Examples
    ///
    /// Monga iterator:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Kugwiritsa ntchito `println!` mwachindunji:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Zonsezi ndizofanana ndi:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Kugwiritsa ntchito `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // kapena-1 ikuwonetsetsa kuti pa c==0 malamulowo amawerengera kuti nambala imodzi iyenera kusindikizidwa ndipo (yemweyo) imapewa kusefukira kwa (31, 32)
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // mndandanda wa manambala ofunika kwambiri a hex
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Mtundu wowonjezera wa `escape_debug` womwe ungaloleze kuthawa ma codepoints a Extended Grapheme.
    /// Izi zimatilola kupanga mtundu wazithunzi ngati zilembo zosasunthika bwino zikamayamba chingwe.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Imabwezeretsa iterator yomwe imapereka nambala yothawirako ya munthu ngati `char`s.
    ///
    /// Izi zipulumuka zilembo zomwe zikufanana ndi kukhazikitsa kwa `Debug` kwa `str` kapena `char`.
    ///
    ///
    /// # Examples
    ///
    /// Monga iterator:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Kugwiritsa ntchito `println!` mwachindunji:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Zonsezi ndizofanana ndi:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Kugwiritsa ntchito `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Imabwezeretsa iterator yomwe imapereka nambala yothawirako ya munthu ngati `char`s.
    ///
    /// Zosasankhidwazo zimasankhidwa ndi kukondera popanga zolemba zomwe zili zovomerezeka m'zilankhulo zosiyanasiyana, kuphatikiza C++ 11 ndi zilankhulo zina za C-banja.
    /// Malamulo ake ndi awa:
    ///
    /// * Tab yathawa monga `\t`.
    /// * Kubwerera kwa ngolo kwathawa monga `\r`.
    /// * Chakudya chamizere chimathawa ngati `\n`.
    /// * Ndemanga imodzi yapulumuka ngati `\'`.
    /// * Kubwereza kawiri kuthawa monga `\"`.
    /// * Kubwerera m'mbuyo kuthawa monga `\\`.
    /// * Khalidwe lirilonse mu 'chosindikizika ASCII' mulingo `0x20` .. `0x7e` kuphatikiza sikuthawidwa.
    /// * Anthu ena onse amapatsidwa hexadecimal Unicode kuthawa;onani [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Monga iterator:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Kugwiritsa ntchito `println!` mwachindunji:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Zonsezi ndizofanana ndi:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Kugwiritsa ntchito `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Kubwezeretsa kuchuluka kwa mabayiti `char` angafunike ngati atayikidwa mu UTF-8.
    ///
    /// Chiwerengero cha mabayiti nthawi zonse chimakhala pakati pa 1 ndi 4, kuphatikiza.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Mtundu wa `&str` umatsimikizira kuti zomwe zili m'kati mwake ndi UTF-8, chifukwa chake titha kufananiza kutalika komwe zingatenge ngati mfundo iliyonse ikayimiriridwa ngati `char` vs `&str` yomwe:
    ///
    ///
    /// ```
    /// // monga chars
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // Zonsezi zitha kuyimiridwa ngati ma byte atatu
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // monga &str, awiriwa amalembedwa mu UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // Titha kuwona kuti amatenga mabayiti asanu ndi limodzi ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... monga &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Imabwezeretsa kuchuluka kwa ma 16-bit code unit omwe `char` angafune ngati atayikidwa mu UTF-16.
    ///
    ///
    /// Onani zolemba za [`len_utf8()`] kuti mumve zambiri za mfundoyi.
    /// Ntchitoyi ndi galasi, koma ya UTF-16 m'malo mwa UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Imasunga khalidweli ngati UTF-8 mu buffer yomwe yaperekedwa, kenako ndikubwezeretsanso gawo la buffer lomwe lili ndi cholembedwacho.
    ///
    ///
    /// # Panics
    ///
    /// Panics ngati buffer siyokwanira mokwanira.
    /// Chida chophatikizira cha kutalika zinayi ndikokwanira kuthana ndi `char` iliyonse.
    ///
    /// # Examples
    ///
    /// Mu zitsanzo zonsezi, 'ß' imatenga ma byte awiri kuti izungulira.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Chikhomo chomwe ndi chaching'ono kwambiri:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // CHITETEZO: `char` siwololedwa, choncho iyi ndi UTF-8 yoyenera.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Imayika khalidweli ngati UTF-16 mu choyikapo cha `u16`, kenako ndikubwezeretsanso gawo la buffer lomwe lili ndi cholembedwacho.
    ///
    ///
    /// # Panics
    ///
    /// Panics ngati buffer siyokwanira mokwanira.
    /// Chopondera cha kutalika 2 ndikokwanira kuthana ndi `char` iliyonse.
    ///
    /// # Examples
    ///
    /// Mu zitsanzo zonsezi, '𝕊' imatenga ma `u16 awiri kuti asungire.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Chikhomo chomwe ndi chaching'ono kwambiri:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Imabwezeretsa `true` ngati `char` iyi ili ndi katundu wa `Alphabetic`.
    ///
    /// `Alphabetic` yafotokozedwa mu Chaputala 4 (Makhalidwe Abwino) a [Unicode Standard] ndikufotokozedwa mu [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // chikondi ndizinthu zambiri, koma sizitengera zilembo
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Imabwezeretsa `true` ngati `char` iyi ili ndi katundu wa `Lowercase`.
    ///
    /// `Lowercase` yafotokozedwa mu Chaputala 4 (Makhalidwe Abwino) a [Unicode Standard] ndikufotokozedwa mu [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Zolemba zosiyanasiyana zaku China zilibe zolembera, choncho:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Imabwezeretsa `true` ngati `char` iyi ili ndi katundu wa `Uppercase`.
    ///
    /// `Uppercase` yafotokozedwa mu Chaputala 4 (Makhalidwe Abwino) a [Unicode Standard] ndikufotokozedwa mu [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Zolemba zosiyanasiyana zaku China zilibe zolembera, choncho:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Imabwezeretsa `true` ngati `char` iyi ili ndi katundu wa `White_Space`.
    ///
    /// `White_Space` zafotokozedwa mu [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // malo osaphulika
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Imabwezeretsa `true` ngati `char` iyi ikwaniritsa [`is_alphabetic()`] kapena [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Imabwezeretsa `true` ngati `char` iyi ili ndi gulu la ma code olamulira.
    ///
    /// Ma code olamulira (ma code okhala ndi gulu la `Cc`) amafotokozedwa mu Chaputala 4 (Makhalidwe Abwino) a [Unicode Standard] ndikufotokozedwa mu [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// // U + 009C, STRING WOYIMBITSA
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Imabwezeretsa `true` ngati `char` iyi ili ndi katundu wa `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` ikufotokozedwa mu [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] ndikufotokozedwa mu [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Imabwezeretsa `true` ngati `char` iyi ili ndi gulu limodzi lamanambala.
    ///
    /// Magulu onse a manambala (`Nd` ya manambala a decimal, `Nl` ya zilembo zofananira ndi zilembo, ndi `No` yamitundu ina) afotokozedwa mu [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Imabwezeretsa iterator yomwe imapereka mapu otsika a `char` ngati imodzi kapena zingapo
    /// `char`s.
    ///
    /// Ngati `char` iyi ilibe mapu ochepera, iterator imatulutsanso `char` yomweyo.
    ///
    /// Ngati `char` iyi ili ndi mapu a m'munsi mwa m'modzi operekedwa ndi [Unicode Character Database][ucd] [`UnicodeData.txt`], iterator imatulutsa `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Ngati `char` iyi ikufunika kulingalira mwapadera (mwachitsanzo ma `char`s angapo) theerator ipereka ma`char` (m) operekedwa ndi [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Ntchitoyi imapanga mapu osasunthika popanda kutengera.Ndiye kuti, kutembenuka kumangodziyimira pawokha ndi chilankhulo.
    ///
    /// Mu [Unicode Standard], Chaputala 4 (Character Properties) chikufotokoza mapu amilandu yonse ndipo Chaputala 3 (Conformance) chimakambirana za kusinthidwa kosasintha kwa kutembenuka kwamilandu.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Monga iterator:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Kugwiritsa ntchito `println!` mwachindunji:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Zonsezi ndizofanana ndi:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Kugwiritsa ntchito `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Nthawi zina zotsatira zake zimakhala zopitilira umodzi:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Makhalidwe omwe alibe zilembo zazikuluzikulu amatembenukira mwa iwo okha.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Imabwezeretsa iterator yomwe imapereka mapu akulu a `char` ngati imodzi kapena zingapo
    /// `char`s.
    ///
    /// Ngati `char` iyi ilibe mapu akuluakulu, iterator imaperekanso `char` yomweyo.
    ///
    /// Ngati `char` iyi ili ndi mapu akuluakulu opangidwa ndi [Unicode Character Database][ucd] [`UnicodeData.txt`], iterator imatulutsa `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Ngati `char` iyi ikufunika kulingalira mwapadera (mwachitsanzo ma `char`s angapo) theerator ipereka ma`char` (m) operekedwa ndi [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Ntchitoyi imapanga mapu osasunthika popanda kutengera.Ndiye kuti, kutembenuka kumangodziyimira pawokha ndi chilankhulo.
    ///
    /// Mu [Unicode Standard], Chaputala 4 (Character Properties) chikufotokoza mapu amilandu yonse ndipo Chaputala 3 (Conformance) chimakambirana za kusinthidwa kosasintha kwa kutembenuka kwamilandu.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Monga iterator:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Kugwiritsa ntchito `println!` mwachindunji:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Zonsezi ndizofanana ndi:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Kugwiritsa ntchito `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Nthawi zina zotsatira zake zimakhala zopitilira umodzi:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Makhalidwe omwe alibe zilembo zazikuluzikulu amatembenukira mwa iwo okha.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Chidziwitso pamalopo
    ///
    /// Mu Turkish, 'i' yofanana ndi Chilatini ili ndi mitundu isanu m'malo mwa iwiri:
    ///
    /// * 'Dotless': I/ı, nthawi zina amalembedwa ï
    /// * 'Dotted': İ/i
    ///
    /// Dziwani kuti kachidutswa kakang'ono kamene kali ndi 'i' ndi kofanana ndi Chilatini.Chifukwa chake:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Mtengo wa `upper_i` pano umadalira chilankhulo: ngati tili mu `en-US`, iyenera kukhala `"I"`, koma ngati tili mu `tr_TR`, iyenera kukhala `"İ"`.
    /// `to_uppercase()` saganizira izi, motero:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// akugwira m'zinenero.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Imafufuza ngati mtengo uli mkati mwa ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Amapanga mtengo wake mu ASCII mulingo wofanana.
    ///
    /// Makalata a ASCII 'a' mpaka 'z' ajambulidwa ku 'A' mpaka 'Z', koma zilembo zosakhala ASCII sizikusintha.
    ///
    /// Kuti muwonjeze mtengo womwe muli, gwiritsani ntchito [`make_ascii_uppercase()`].
    ///
    /// Kuti mukhale ndi zilembo zazikulu za ASCII kuphatikiza pamanambala omwe si a ASCII, gwiritsani ntchito [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Amapanga mtengo wamtengo mu ASCII m'makalata ochepa ofanana.
    ///
    /// Makalata a ASCII 'A' mpaka 'Z' ajambulidwa ku 'a' mpaka 'z', koma zilembo zosakhala ASCII sizikusintha.
    ///
    /// Kuti muchepetse mtengo womwe ulipo, gwiritsani ntchito [`make_ascii_lowercase()`].
    ///
    /// Kuti muchepetse zilembo za ASCII kuphatikiza zilembo zosakhala ASCII, gwiritsani ntchito [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Kufufuza kuti miyezo iwiri ndi machesi osaganizira a ASCII.
    ///
    /// Zofanana ndi `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Imatembenuza mtundu uwu kukhala ASCII mulingo wofanana m'malo mwake.
    ///
    /// Makalata a ASCII 'a' mpaka 'z' ajambulidwa ku 'A' mpaka 'Z', koma zilembo zosakhala ASCII sizikusintha.
    ///
    /// Kuti mubwezere mtengo watsopano osasintha womwe ulipo, gwiritsani ntchito [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Imatembenuza mtundu uwu kukhala ASCII yotsika pang'ono m'malo mwake.
    ///
    /// Makalata a ASCII 'A' mpaka 'Z' ajambulidwa ku 'a' mpaka 'z', koma zilembo zosakhala ASCII sizikusintha.
    ///
    /// Kuti mubwezere mtengo watsopano wotsika popanda kusintha womwe ulipo, gwiritsani ntchito [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Imafufuza ngati kufunikira kwake ndi zilembo za ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', kapena
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Imafufuza ngati mtengowu ndi chilembo chachikulu cha ASCII:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Macheke ngati mtengo ndi ASCII lowercase khalidwe:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Macheke ngati mtengo ndi ASCII alphanumeric khalidwe:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', kapena
    /// - U + 0061 'a' ..=U + 007A 'z', kapena
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Macheke ngati mtengo ndi manambala ASCII decimal:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Macheke ngati mtengo ndi ASCII hexadecimal manambala:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', kapena
    /// - U + 0041 'A' ..=U + 0046 'F', kapena
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Imafufuza ngati kufunikirako ndi mawonekedwe a ASCII:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, kapena
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, kapena
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, kapena
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Imafufuza ngati mtengo ndi chithunzi cha ASCII:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Imafufuza ngati mtengowo ndi chikhalidwe cha malo oyera a ASCII:
    /// U + 0020 SPACE, U + 0009 HORIZONTAL TAB, U + 000A LINE FEED, U + 000C FORM FEED, kapena U + 000D CARRIAGE RETURN.
    ///
    /// Rust imagwiritsa ntchito [definition of ASCII whitespace][infra-aw] ya WhatWG Infra Standard.Palinso matanthauzo ena angapo omwe amagwiritsidwa ntchito kwambiri.
    /// Mwachitsanzo, [the POSIX locale][pct] imaphatikizira U + 000B VERTICAL TAB komanso zilembo zonse zomwe zili pamwambapa, koma-kuchokera pamalingaliro omwewo-[lamulo lokhazikika la "field splitting" mu Bourne shell][bfs] limangowona * SPACE, HORIZONTAL TAB, ndi MBIRI ZOPHUNZITSA ngati malo oyera.
    ///
    ///
    /// Ngati mukulemba pulogalamu yomwe idzakonze mafayilo omwe alipo kale, onetsetsani tanthauzo la whitespace musanagwiritse ntchito ntchitoyi.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Imafufuza ngati kufunikira kwake ndi mawonekedwe owongolera a ASCII:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR, kapena U + 007F DELETE.
    /// Dziwani kuti ambiri azithunzi za ASCII ndi omwe amawongolera, koma SPACE sichoncho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Imayika mtengo wa u32 waiwisi ngati UTF-8 mu buffer yomwe yaperekedwa, kenako ndikubwezeretsanso gawo la buffer lomwe lili ndi cholembedwacho.
///
///
/// Mosiyana ndi `char::encode_utf8`, njirayi imagwiritsanso ntchito ma codepoints omwe ali m'malo mwa surrogate.
/// (Kupanga `char` pamndandanda wobwereza ndi UB.) Zotsatira zake ndi [generalized UTF-8] koma si UTF-8 yoyenera.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics ngati buffer siyokwanira mokwanira.
/// Chida chophatikizira cha kutalika zinayi ndikokwanira kuthana ndi `char` iliyonse.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Imayika mtengo wa u32 waiwisi ngati UTF-16 mu buffer ya `u16`, kenako ndikubwezeretsanso gawo la buffer lomwe lili ndi cholembedwacho.
///
///
/// Mosiyana ndi `char::encode_utf16`, njirayi imagwiritsanso ntchito ma codepoints omwe ali m'malo mwa surrogate.
/// (Kupanga `char` pamndandanda woyeserera ndi UB.)
///
/// # Panics
///
/// Panics ngati buffer siyokwanira mokwanira.
/// Chopondera cha kutalika 2 ndikokwanira kuthana ndi `char` iliyonse.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // CHITETEZO: mkono uliwonse umafufuza ngati pali zidutswa zokwanira zolembedweramo
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP imagwera
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Ndege zowonjezera zimawonongeka.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}