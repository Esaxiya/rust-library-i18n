//! Kutembenuka kwamakhalidwe.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Imatembenuza `u32` kukhala `char`.
///
/// Dziwani kuti onse [`char`] s ali olondola [`u32`] s, ndipo atha kuponyedwa kumodzi ndi
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Komabe, kusinthaku sikuli koona: sizovomerezeka zonse [`u32`] s ndizolondola [`char`] s.
/// `from_u32()` idzabwezera `None` ngati kulowetsa sikofunika kwa [`char`].
///
/// Kuti mumve bwino za ntchitoyi yomwe imanyalanyaza cheke ichi, onani [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Kagwiritsidwe:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Kubwezeretsa `None` pomwe kulowetsa sikuli [`char`] yovomerezeka:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Imatembenuza `u32` kukhala `char`, ikunyalanyaza kuvomerezeka.
///
/// Dziwani kuti onse [`char`] s ali olondola [`u32`] s, ndipo atha kuponyedwa kumodzi ndi
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Komabe, kusinthaku sikuli koona: sizovomerezeka zonse [`u32`] s ndizolondola [`char`] s.
/// `from_u32_unchecked()` anyalanyaza izi, ndikuponyera ku [`char`] mwakachetechete, mwina atha kupanga zosavomerezeka.
///
///
/// # Safety
///
/// Ntchitoyi ndi yosatetezeka, chifukwa itha kupanga zolakwika za `char`.
///
/// Kuti muwone bwino ntchitoyi, onani ntchito ya [`from_u32`].
///
/// # Examples
///
/// Kagwiritsidwe:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // CHITETEZO: woyimbayo akuyenera kutsimikizira kuti `i` ndiyofunika pamtengo.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Imatembenuza [`char`] kukhala [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Imatembenuza [`char`] kukhala [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Chojambulacho chimaponyedwa pamtengo wamakhodi, kenako chimakwezedwa mpaka 64 pokha.
        // Onani [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Imatembenuza [`char`] kukhala [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Chojambulacho chimaponyedwa pamtengo wamakhodi, kenako chimakwezedwa mpaka 128.
        // Onani [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Tikuyika mapu mu 0x00 ..=0xFF mpaka `char` yomwe nambala yake yachinsinsi ili ndi mtengo wofanana, mu U + 0000 ..=U + 00FF.
///
/// Unicode yapangidwa kuti izi zidziwitse bwino mabatani omwe ali ndi zilembo zomwe IANA amatcha ISO-8859-1.
/// Kulemba kumeneku kumagwirizana ndi ASCII.
///
/// Dziwani kuti izi ndizosiyana ndi ISO/IEC 8859-1 aka
/// ISO 8859-1 (yokhala ndi hyphen imodzi yocheperako), yomwe imasiya zina za "blanks", byte zomwe sizinapatsidwe kwa munthu aliyense.
/// ISO-8859-1 (ya IANA) imawapatsa ma C0 ndi C1 ma code olamulira.
///
/// Dziwani kuti izi * ndizosiyana ndi Windows-1252 aka
/// tsamba 1252, lomwe ndi superset ISO/IEC 8859-1 yomwe imapatsa zina (osati zonse!) zopumira ndi zilembo zosiyanasiyana zachi Latin.
///
/// Pofuna kusokoneza zinthu, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1`, ndi `windows-1252` ndi mipata yonse ya Windows-1252 yomwe imadzaza zotsalazo ndi ma C0 ndi C1.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Imatembenuza [`u8`] kukhala [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Vuto lomwe lingabwezeredwe polemba char.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // CHITETEZO: adawonetsetsa kuti ndi mtengo wovomerezeka wa unicode
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Mtundu wolakwika udabwerera pomwe kutembenuka kuchokera ku u32 kupita ku char kulephera.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Imatembenuza manambala mu radix yomwe yapatsidwa kukhala `char`.
///
/// 'radix' apa nthawi zina amatchedwanso 'base'.
/// Radix ya awiri imawonetsa nambala ya binary, radix ya ten, decimal, ndi radix ya khumi ndi zisanu ndi chimodzi, hexadecimal, kuti ipereke zofunikira zofananira.
///
/// Ma radic osasinthika amathandizidwa.
///
/// `from_digit()` ibwerera `None` ngati cholowacho sichili nambala mu radix yomwe yapatsidwa.
///
/// # Panics
///
/// Panics ngati yapatsidwa radix yoposa 36.
///
/// # Examples
///
/// Kagwiritsidwe:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Decimal 11 ndi nambala imodzi m'munsi 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Kubwezeretsa `None` pomwe kulowetsa sikunambala:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Kupititsa radix yayikulu, kuyambitsa panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}