use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri akuchedwa kwambiri
fn exact_sanity_test() {
    // Kuyesaku kumatha kuthamanga zomwe ndikungoganiza kuti ndi vuto lina la `exp2` laibulale, lofotokozedwera munthawi yonse yomwe timagwiritsa ntchito C.
    // Mu VS 2013 ntchitoyi mwachiwonekere inali ndi cholakwika popeza mayesowa amalephera akagwirizanitsidwa, koma ndi VS 2015 kachilomboka kamawoneka kokhazikika pomwe mayeso amayenda bwino.
    //
    // Chimbalangondo chikuwoneka ngati kusiyana pakubweza kwa `exp2(-1057)`, pomwe mu VS 2013 imabweza kawiri ndi mtundu wa 0x2 ndipo mu VS 2015 imabweza 0x20000.
    //
    //
    // Pakadali pano ingonyalanyazani mayesowa pa MSVC momwe amayesedwera kwina kulikonse ndipo sitili ndi chidwi chofuna kuyesa kukhazikitsa kwa exp2 papulatifomu iliyonse.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}