# `rustc-std-workspace-std` crate

Onani zolemba za `rustc-std-workspace-core` crate.