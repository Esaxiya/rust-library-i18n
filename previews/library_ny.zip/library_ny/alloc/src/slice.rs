//! Mawonekedwe owoneka bwino motsatizana, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Magawo ndi mawonekedwe mu chikumbukiro choyimiridwa ngati cholozera ndi kutalika.
//!
//! ```
//! // kudula Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // kukakamiza gulu pagawo
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Magawo amatha kusintha kapena kugawidwa.
//! Gawo logawidwa ndi `&[T]`, pomwe mtundu wosinthika ndi `&mut [T]`, pomwe `T` imayimira mtunduwo.
//! Mwachitsanzo, mutha kusintha gawo lokumbukira lomwe kagawo kosinthika kalozera ku:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Nazi zina mwazomwe gawo ili lili:
//!
//! ## Structs
//!
//! Pali ma structs angapo omwe ndi othandiza pamitundu, monga [`Iter`], yomwe imayimira kuyimilira kachigawo kakang'ono.
//!
//! ## Trait Kukhazikitsa
//!
//! Pali zochitika zingapo za traits wamba za magawo.Zitsanzo zina ndi izi:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], yamagawo omwe mtundu wawo ndi [`Eq`] kapena [`Ord`].
//! * [`Hash`] - kwa magawo omwe mtundu wawo ndi [`Hash`].
//!
//! ## Iteration
//!
//! Magawo amatsatira `IntoIterator`.Iterator imafotokoza zomwe zidagawika.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Chidutswa chosinthika chimapereka mayendedwe osinthika kuzinthu:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Iterator iyi imapereka kutanthauzira kosinthika pazinthu za kagawo, ndiye kuti mtundu wa chidutswacho ndi `i32`, mtundu wa iterator ndi `&mut i32`.
//!
//!
//! * [`.iter`] ndipo [`.iter_mut`] ndiye njira zomveka zobwezera otchera osasintha.
//! * Njira zinanso zomwe zimabwezeretsa oyeserera ndi [`.split`], [`.splitn`], [`.chunks`], [`.windows`] ndi ena ambiri.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Zambiri mwazomwe zimagwiritsidwa ntchito mgululi zimagwiritsidwa ntchito pakusintha kwamayeso.
// Ndizosavuta kuzimitsa chenjezo losagwiritsidwa ntchito_kulandira kuposa kukonza.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Njira zoyambira zowonjezera
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) zofunikira pakukhazikitsa `vec!` macro pakuyesa NB, onani gawo la `hack` mufayilayi kuti mumve zambiri.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) zofunikira pakukhazikitsa `Vec::clone` poyesa NB, onani gawo la `hack` mufayilayi kuti mumve zambiri.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Popeza cfg(test) `impl [T]` sichikupezeka, ntchito zitatuzi ndi njira zomwe zili mu `impl [T]` koma osati mu `core::slice::SliceExt`, tikufunika kupereka ntchitoyi poyesa `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Sitiyenera kuwonjezera malingaliro okhala pakati pa izi popeza izi zimagwiritsidwa ntchito mu `vec!` macro makamaka ndipo zimayambitsa kufooka kwa mafuta.
    // Onani #71204 kuti mukambirane ndi zotsatira za mafuta.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // zinthu zidalembedwa kuyambitsidwa pamalopo pansipa
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) Ndikofunikira kuti LLVM ichotse malire ndipo ili ndi codegen yabwinoko kuposa zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec idapatsidwa ndikukhazikitsidwa pamwambapa mpaka kutalika kotere.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // yoperekedwa pamwambapa ndi mphamvu ya `s`, ndikuyambitsa mpaka `s.len()` mu ptr::copy_to_non_overlapping pansipa.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Sanjani kagawo.
    ///
    /// Mtundu uwu ndiwokhazikika (mwachitsanzo, sukukonzanso zinthu zofanana) ndi *O*(*n*\*log(* n*)) vuto lalikulu.
    ///
    /// Ngati zingachitike, kusanja kosakhazikika kumakondedwa chifukwa nthawi zambiri kumakhala kofulumira kuposa kusanja mosakhazikika ndipo sikumapereka chikumbutso chothandizira.
    /// Onani [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Kukonzekera kwatsopano
    ///
    /// Ma algorithm apano ndi osinthika, ophatikizika amtundu wouziridwa ndi [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Amapangidwa kuti azithamanga kwambiri pomwe kagawo kali pafupi kusanjidwa, kapena kumakhala ndi magawo awiri kapena angapo osankhidwa motsatana.
    ///
    ///
    /// Komanso imagawa zosungira kwakanthawi theka la kukula kwa `self`, koma pazigawo zazifupi mtundu wosayika womwe umagwiritsidwa ntchito m'malo mwake.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Imasanja kagawo kali ndi choyerekeza.
    ///
    /// Mtundu uwu ndiwokhazikika (mwachitsanzo, sukukonzanso zinthu zofanana) ndi *O*(*n*\*log(* n*)) vuto lalikulu.
    ///
    /// Ntchito yofananirayo iyenera kufotokozera kuyitanitsa kwathunthu kwa zomwe zidagawika.Ngati kulamula sikokwanira, dongosolo lazinthu sizikudziwika.
    /// Lamulo ndi dongosolo lathunthu ngati lili (kwa onse `a`, `b` ndi `c`):
    ///
    /// * okwanira ndi antisymmetric: chimodzimodzi chimodzi mwa `a < b`, `a == b` kapena `a > b` ndichowona, ndipo
    /// * transitive, `a < b` and `b < c` amatanthauza `a < c`.Zomwezo ziyenera kugwira zonse za `==` ndi `>`.
    ///
    /// Mwachitsanzo, pomwe [`f64`] siyigwiritsa ntchito [`Ord`] chifukwa `NaN != NaN`, titha kugwiritsa ntchito `partial_cmp` ngati mtundu wathu wogwira ntchito tikadziwa kuti chidutswacho chilibe `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Ngati zingachitike, kusanja kosakhazikika kumakondedwa chifukwa nthawi zambiri kumakhala kofulumira kuposa kusanja mosakhazikika ndipo sikumapereka chikumbutso chothandizira.
    /// Onani [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Kukonzekera kwatsopano
    ///
    /// Ma algorithm apano ndi osinthika, ophatikizika amtundu wouziridwa ndi [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Amapangidwa kuti azithamanga kwambiri pomwe kagawo kali pafupi kusanjidwa, kapena kumakhala ndi magawo awiri kapena angapo osankhidwa motsatana.
    ///
    /// Komanso imagawa zosungira kwakanthawi theka la kukula kwa `self`, koma pazigawo zazifupi mtundu wosayika womwe umagwiritsidwa ntchito m'malo mwake.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // kusintha kusanja
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Imasanja kagawo kakang'ono ndi ntchito yochulukirapo.
    ///
    /// Mtundu uwu ndiwokhazikika (mwachitsanzo, sukukonzanso zinthu zofananira) ndi *O*(*m*\*n*\*log(* n *)) choyipa kwambiri, pomwe ntchito yayikulu ndi* O *(* m *).
    ///
    /// Pazinthu zofunikira kwambiri (mwachitsanzo
    /// ntchito zomwe sizopezekera mosavuta kapena zofunikira), [`sort_by_cached_key`](slice::sort_by_cached_key) ikuyenera kukhala yofulumira kwambiri, popeza siyibwezera makiyi azinthu.
    ///
    ///
    /// Ngati zingachitike, kusanja kosakhazikika kumakondedwa chifukwa nthawi zambiri kumakhala kofulumira kuposa kusanja mosakhazikika ndipo sikumapereka chikumbutso chothandizira.
    /// Onani [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Kukonzekera kwatsopano
    ///
    /// Ma algorithm apano ndi osinthika, ophatikizika amtundu wouziridwa ndi [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Amapangidwa kuti azithamanga kwambiri pomwe kagawo kali pafupi kusanjidwa, kapena kumakhala ndi magawo awiri kapena angapo osankhidwa motsatana.
    ///
    /// Komanso imagawa zosungira kwakanthawi theka la kukula kwa `self`, koma pazigawo zazifupi mtundu wosayika womwe umagwiritsidwa ntchito m'malo mwake.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Imasanja kagawo kakang'ono ndi ntchito yochulukirapo.
    ///
    /// Mukamasanja, ntchito yofunika imangotchedwa kamodzi pachinthu chilichonse.
    ///
    /// Mtundu uwu ndiwokhazikika (mwachitsanzo, sukukonzanso zinthu zofanana) ndi *O*(*m*\*n* + *n* log(*n*)) vuto lalikulu, pomwe ntchito yayikulu ndi *O*(*m*) .
    ///
    /// Pazinthu zofunikira zosavuta (mwachitsanzo, ntchito zomwe zimafikira katundu kapena zofunikira), [`sort_by_key`](slice::sort_by_key) ikuyenera kukhala yofulumira.
    ///
    /// # Kukonzekera kwatsopano
    ///
    /// Ma algorithm apano amatengera [pattern-defeating quicksort][pdqsort] wolemba Orson Peters, yemwe amaphatikiza milandu yofulumira mwachangu mwachisawawa ndi vuto lalikulu kwambiri la heapsort, ndikukwaniritsa nthawi yolumikizana ndi magawo okhala ndi mitundu ina.
    /// Zimagwiritsa ntchito njira zina kuti zisawonongeke, koma ndi seed yokhazikika kuti izikhala ndi zikhalidwe nthawi zonse.
    ///
    /// Pazovuta kwambiri, ma algorithm amapatsa zosungira kwakanthawi mu `Vec<(K, usize)>` kutalika kwa kagawo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Mthandizi wamkulu wolozera vector yathu ndi mtundu wawung'ono kwambiri, kuti muchepetse kugawa.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Zinthu za `indices` ndizapadera, chifukwa zidalembedwa, chifukwa chake mtundu uliwonse umakhala wolimba polemekeza chidutswa choyambirira.
                // Timagwiritsa ntchito `sort_unstable` pano chifukwa zimafuna kugawa pang'ono kukumbukira.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Zimakopera `self` kulowa `Vec` yatsopano.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Pano, `s` ndi `x` zimatha kusinthidwa mosadalira.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Amakopera `self` kulowa `Vec` yatsopano ndi yogawa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Pano, `s` ndi `x` zimatha kusinthidwa mosadalira.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, onani gawo la `hack` mufayilayi kuti mumve zambiri.
        hack::to_vec(self, alloc)
    }

    /// Imatembenuza `self` kukhala vector popanda zoyeserera kapena magawidwe.
    ///
    /// Zotsatira zake vector zitha kusinthidwa kukhala bokosi kudzera pa `Vec<T>Njira ya `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` sungagwiritsidwenso ntchito chifukwa yasinthidwa kukhala `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, onani gawo la `hack` mufayilayi kuti mumve zambiri.
        hack::into_vec(self)
    }

    /// Pangani vector pobwereza kagawo kakang'ono ka `n`.
    ///
    /// # Panics
    ///
    /// Ntchitoyi idzagwira ntchito panic ngati kuthekera kukusefukira.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// panic ikusefukira:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Ngati `n` ndi yayikulu kuposa zero, itha kugawanika ngati `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` nambala ndiyoyimiridwa ndi '1' yotsalira ya `n`, ndipo `rem` ndiye gawo lotsala la `n`.
        //
        //

        // Kugwiritsa ntchito `Vec` kupeza `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` kubwereza kumachitika mwa kuwirikiza kawiri nthawi za `buf` `expn`.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Ngati `m > 0`, pali zotsalira mpaka kumanzere kwa '1'.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` ili ndi mphamvu ya `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) kubwereza kumachitika potengera kubwereza koyamba kwa `rem` kuchokera ku `buf` yomwe.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Izi sizikuchulukira kuyambira `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` ofanana ndi `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Flattens chidutswa cha `T` mu mtengo umodzi `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Lembani kagawo ka `T` pamtengo umodzi `Self::Output`, ndikuyika chopatula pakati pa chilichonse.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Lembani kagawo ka `T` pamtengo umodzi `Self::Output`, ndikuyika chopatula pakati pa chilichonse.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Imabwezeretsa vector yomwe ili ndi chidutswa cha chidutswachi pomwe mapu aliwonse amapangidwira ku ASCII yake yofanana.
    ///
    ///
    /// Makalata a ASCII 'a' mpaka 'z' ajambulidwa ku 'A' mpaka 'Z', koma zilembo zosakhala ASCII sizikusintha.
    ///
    /// Kuti muwonjeze mtengo womwe muli, gwiritsani ntchito [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Imabwezeretsa vector yokhala ndi chidutswa cha chidutswachi pomwe mapu aliwonse amapangidwira ku ASCII yake yofanana.
    ///
    ///
    /// Makalata a ASCII 'A' mpaka 'Z' ajambulidwa ku 'a' mpaka 'z', koma zilembo zosakhala ASCII sizikusintha.
    ///
    /// Kuti muchepetse mtengo womwe ulipo, gwiritsani ntchito [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Extension traits ya magawo amitundu yosiyanasiyana
////////////////////////////////////////////////////////////////////////////////

/// Mthandizi trait wa [`[T]: : concat`](kagawo::concat).
///
/// Note: mtundu wa `Item` sunagwiritsidwe ntchito mu trait iyi, koma umalola ma impls kuti azikhala achibadwa.
/// Popanda izi, timapeza vuto ili:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Izi ndichifukwa choti pakhoza kukhala mitundu `V` yokhala ndi ma `Borrow<[_]>` angapo, kotero kuti mitundu ingapo ya `T` itha kugwiritsidwa ntchito:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Mtundu womwe umatsatira pambuyo pa concatenation
    type Output;

    /// Kukhazikitsa kwa [`[T]: : concat`](kagawo::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Mthandizi trait wa [`[T]: : join`](kagawo::lowani)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Mtundu womwe umatsatira pambuyo pa concatenation
    type Output;

    /// Kukhazikitsa kwa [`[T]: : join`](kagawo::kujowina)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Kukhazikitsa muyezo kwa trait kwa magawo
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // gwetsani chilichonse chomwe sichingalembedwe
        target.truncate(self.len());

        // target.len <= self.len chifukwa cha truncate pamwambapa, chifukwa chake magawo pano nthawi zonse amakhala m'malire.
        //
        let (init, tail) = self.split_at(target.len());

        // gwiritsaninso ntchito zomwe zilipo allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Imaika `v[0]` muzokonzekera `v[1..]` kuti `v[..]` yonse isankhidwe.
///
/// Ili ndiye gawo lofunikira la mtundu wolowetsa.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Pali njira zitatu zokhazikitsira kuyika apa:
            //
            // 1. Sinthanitsani zinthu zoyandikana mpaka yoyamba ikafika komwe ikupita.
            //    Komabe, motere timakopera deta mozungulira zomwe sizofunikira.
            //    Ngati zinthu zili zazikulu (zotsika mtengo kutengera), njirayi ichedwa.
            //
            // 2. Iterate mpaka malo oyenera a chinthu choyamba atapezeka.
            // Kenako sinthanitsani zinthu zomwe zikutsatira kuti mupeze malo ake ndikumayika mu dzenje lotsala.
            // Iyi ndi njira yabwino.
            //
            // 3. Lembani chinthu choyamba kukhala chosintha kwakanthawi.Kusintha mpaka malo oyenera atapezeka.
            // Pamene tikupitiliza, lembani chilichonse chomwe chadutsa patsamba loyambirira.
            // Pomaliza, lembani zidziwitso kuchokera pakusintha kwakanthawi kulowa mdzenje lotsalira.
            // Njirayi ndi yabwino kwambiri.
            // Zikwangwani zikuwonetsa magwiridwe antchito pang'ono kuposa njira yachiwiri.
            //
            // Njira zonse zinali zofanana, ndipo chachitatu chidawonetsa zotsatira zabwino.Kotero ife tinasankha iyo.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Njira yapakatikati yolowetsa nthawi zonse imatsatiridwa ndi `hole`, yomwe imagwira ntchito ziwiri:
            // 1. Kuteteza kukhulupirika kwa `v` kuchokera ku panics mu `is_less`.
            // 2. Amadzaza dzenje lotsalira mu `v` kumapeto.
            //
            // Panic chitetezo:
            //
            // Ngati `is_less` panics nthawi iliyonse panthawiyi, `hole` idzagwetsedwa ndikudzaza dzenje mu `v` ndi `tmp`, ndikuwonetsetsa kuti `v` ikugwiritsabe chinthu chilichonse chomwe chimagwira kamodzi koyambirira.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` imagwetsedwa motero imakopera `tmp` mu dzenje lotsala mu `v`.
        }
    }

    // Mukatsitsidwa, makope ochokera ku `src` kupita ku `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Kuphatikiza ma `v[..mid]` osachepetsedwa ndi `v[mid..]` pogwiritsa ntchito `buf` ngati chosungira kwakanthawi, ndikusunga zotsatirazo kukhala `v[..]`.
///
/// # Safety
///
/// Magawo awiriwo ayenera kukhala opanda kanthu ndipo `mid` iyenera kukhala m'malire.
/// Buffer `buf` iyenera kukhala yayitali kuti mukhale ndi chidutswa chachifupi.
/// Komanso, `T` siyiyenera kukhala yayikulu-zero.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Njira yolumikizira imakopera kofupikitsa kulowa `buf`.
    // Kenako imatsata kuthamanga komwe kwakopedwa kumene komanso kuthamanga kwakanthawi kwakutsogolo (kapena chammbuyo), kuyerekezera zinthu zina zomwe sanatengeko ndikumakopera zazing'ono (kapena zazikulu) mu `v`.
    //
    // Mwamsanga pamene kuthamanga kochepa kumatha, ndondomeko yatha.Ngati kuthamanga kumayambika koyamba, ndiye kuti tiyenera kukopera chilichonse chomwe chatsala pang'ono kufupikirako mu dzenje la `v`.
    //
    // Zomwe zili pakatikati pa njirayi nthawi zonse zimatsatiridwa ndi `hole`, yomwe imagwira ntchito ziwiri:
    // 1. Kuteteza kukhulupirika kwa `v` kuchokera ku panics mu `is_less`.
    // 2. Amadzaza bowo lotsalira mu `v` ngati kuthamanga kwanthawi yayitali kumayamba.
    //
    // Panic chitetezo:
    //
    // Ngati `is_less` panics nthawi iliyonse panthawiyi, `hole` idzagwetsedwa ndikudzaza dzenje mu `v` ndi magawo osaganiziridwa mu `buf`, ndikuwonetsetsa kuti `v` imagwirabe chilichonse chomwe idagwira kamodzi koyambirira.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Kuthamanga kumanzere ndikofupikitsa.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Poyambirira, zolemba izi zimaloza kumayambira azigawo zawo.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Gwiritsani mbali yocheperako.
            // Ngati ofanana, sankhani kumanzere kuti mukhale bata.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Kuthamanga koyenera ndikofupikitsa.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Poyambirira, zolemba izi zimaloza kumapeto kwa magulu awo.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Gwiritsani mbali yayikulu.
            // Ngati ofanana, sankhani kuthamanga koyenera kuti mukhale okhazikika.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Pomaliza, `hole` imagwa.
    // Ngati kuthamanga kwakanthawi kochepa sikunathe kwathunthu, zotsalira zake zonse zitha kukopedwa mu dzenje la `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Mukatsitsidwa, lembani `start..end` mu `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` si mtundu wa zero-size, kotero ndibwino kugawa ndi kukula kwake.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Kuphatikiza kumeneku kumabwereka malingaliro ena (koma osati onse) ochokera ku TimSort, omwe amafotokozedwa mwatsatanetsatane [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Ma algorithm amadziwika kuti ndi otsika osatsika, omwe amatchedwa kuthamanga kwachilengedwe.Pali mitolo ya zinthu zomwe zikuyembekezeka kuphatikizidwa.
/// Kuthamanga kulikonse kumene kumangopezekedwa kumakankhidwira pamtanda, kenako ma peyala oyandikana nawo amaphatikizidwa mpaka owukira awiriwa atakhutira:
///
/// 1. pa `i` iliyonse mu `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. pa `i` iliyonse mu `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Zowonjezera zimaonetsetsa kuti nthawi yonse yomwe ikupezeka ndi *O*(*n*\*log(* n*)) yovuta kwambiri.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Magawo mpaka kutalika kwake amasankhidwa pogwiritsa ntchito mitundu yolowetsera.
    const MAX_INSERTION: usize = 20;
    // Kuthamanga kwakanthawi kochepa kumakwezedwa pogwiritsa ntchito mtundu wa mayikidwe kuti mutambasule zinthu zambiri izi.
    const MIN_RUN: usize = 10;

    // Kusanja kulibe tanthauzo lililonse pamitundu yazero.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Zida zazifupi zimasankhidwa m'malo mwa mtundu wa mayikidwe kuti mupewe kugawa.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Gawani cholembera kuti mugwiritse ntchito poyambira.Timasunga kutalika kwa 0 kuti titha kusungabe zomwe zili mu `v` osayika pachiwopsezo ma dtors omwe akuyenda ngati `is_less` panics.
    //
    // Mukaphatikiza ma run awiri omwe asankhidwa, cholumikizira ichi chimakhala ndi kofupikitsa, komwe kumakhala ndi kutalika kwa `len / 2` nthawi zonse.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Kuti tipeze kuthamanga kwachilengedwe mu `v`, timayendetsa chammbuyo.
    // Izi zitha kuwoneka ngati chisankho chachilendo, koma taganizirani kuti kuphatikiza nthawi zambiri kumatsata (forwards).
    // Malinga ndi ziwonetsero, kuphatikiza patsogolo ndikuthamangira pang'ono kuposa kuphatikizira kumbuyo.
    // Kuti ndimalize, kuzindikira komwe kumayenda ndikubwerera mmbuyo kumakulitsa magwiridwe antchito.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Pezani njira yotsatira yachilengedwe, ndikusintha ngati ikutsika.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Ikani zina zowonjezera kuti zitheke ngati ndi zazifupi kwambiri.
        // Mtundu wowonjezera umathamanga kuposa kuphatikizika kwakanthawi kochepa, chifukwa chake izi zimathandizira magwiridwe antchito.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Sakanizani izi pamtunda.
        runs.push(Run { start, len: end - start });
        end = start;

        // Phatikizani mitundu iwiri yoyandikana pafupi kuti mukwaniritse zosasintha.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Pomaliza, kuthamanga kumodzi kumayenera kutsalira.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Imasanthula mulu wothamanga ndikuzindikira kuthamanga kotsatira kuti iphatikize.
    // Makamaka, ngati `Some(r)` ibwezedwa, zikutanthauza kuti `runs[r]` ndi `runs[r + 1]` ziyenera kuphatikizidwa kenako.
    // Ngati ma aligorivimu apitiliza kupanga njira yatsopano m'malo mwake, `None` imabwezedwa.
    //
    // TimSort ndiyotchuka pakuyendetsa kwake, monga tafotokozera apa:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Mitu ya nkhaniyi ndi iyi: Tiyenera kukakamiza obwerawo pamayendedwe anayi apamwamba pamtengo.
    // Kuwapangitsa kuti akhale atatu okha pamwamba sikokwanira kuonetsetsa kuti omwe akubwerawo azigwirabe zonse * mothamanga.
    //
    // Ntchitoyi imayang'ana molondola zosintha pamayendedwe anayi apamwamba.
    // Kuphatikiza apo, ngati kuthamanga kwakukulu kumayambira pa index 0, nthawi zonse kumafunikira mgwirizano kufikira pomwe muluwo udakomoka, kuti amalize mtunduwo.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}