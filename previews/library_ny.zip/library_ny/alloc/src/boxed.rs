//! Mtundu wa pointer wogawa mulu.
//!
//! [`Box<T>`], yotchedwa 'box', imapereka njira yosavuta kwambiri yogawa mulu ku Rust.Mabokosi amakhala ndi umwini wagawoli, ndipo amasiya zomwe zili mkati pomwe sizingachitike.Mabokosi amaonetsetsanso kuti samagawana zoposa ma `isize::MAX` byte.
//!
//! # Examples
//!
//! Sungani mtengo kuchokera pakatundu kupita pamulu pakupanga [`Box`]:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! Sunthani mtengo kuchokera ku [`Box`] kubwerera ku okwana ndi [dereferencing]:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! Kupanga dongosolo lobwerezabwereza:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! Izi zisindikiza `Cons (1, Cons(2, Nil))`.
//!
//! Zobwezeretsa ziyenera kukhazikitsidwa, chifukwa ngati tanthauzo la `Cons` limawoneka motere:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! Sizingagwire ntchito.Izi ndichifukwa choti kukula kwa `List` kumadalira kuchuluka kwa zinthu zomwe zili mundandandawo, motero sitikudziwa kuchuluka kwa kukumbukira kwa `Cons`.Poyambitsa [`Box<T>`], yomwe ili ndi kukula kwake, tikudziwa kukula kwa `Cons`.
//!
//! # Kamangidwe ka kukumbukira
//!
//! Pazinthu zosakhala zero-zero, [`Box`] idzagwiritsa ntchito sharex ya [`Global`] kuti igawidwe.Ndizovomerezeka kutembenuza njira zonse pakati pa [`Box`] ndi cholembera chosakanikirana chomwe chidaperekedwa ndi [`Global`] allocator, popeza [`Layout`] yomwe imagwiritsidwa ntchito ndi woperekayo ndiyolondola pamtunduwo.
//!
//! Makamaka, `value:*mut T` yomwe idapatsidwa X XUMUM [`Global`] yopatsa ndi `Layout::for_value(&* value)` itha kusinthidwa kukhala bokosi logwiritsa ntchito [`Box::<T>::from_raw(value)`].
//! Mofananamo, kukumbukira kukumbukira `value:*mut T` kochokera ku [`Box::<T>::into_raw`] kumatha kutumizidwa pogwiritsa ntchito [`Global`] yogawa ndi [`Layout::for_value(&* value)`].
//!
//! Pazithunzi zazikulu, zero `Box` X pointer iyenerabe kukhala [valid] yowerengera ndikulemba ndikugwirizana mokwanira.
//! Makamaka, kuponya chiwerengerocho chilichonse chosagwirizana ndi zero kwenikweni pa cholozera chosaphika kumatulutsa cholozera chovomerezeka, koma cholozera choloza m'makumbukidwe omwe anapatsidwa kale kuti kumasulidwa sikulondola.
//! Njira yolimbikitsira kupanga Bokosi ku ZST ngati `Box::new` singagwiritsidwe ntchito ndikugwiritsa ntchito [`ptr::NonNull::dangling`].
//!
//! Malingana ngati `T: Sized`, `Box<T>` ndiyotsimikizika kuti idzaimiridwa ngati cholozera chimodzi komanso imagwirizana ndi ABI ndi C pointers (mwachitsanzo C mtundu `T*`).
//! Izi zikutanthauza kuti ngati muli ndi ntchito zakunja za "C" Rust zomwe zingatchulidwe kuchokera ku C, mutha kufotokozera ntchito za Rust pogwiritsa ntchito mitundu ya `Box<T>`, ndikugwiritsa ntchito `T*` ngati mtundu wofanana pa mbali ya C.
//! Mwachitsanzo, taganizirani mutu wa C womwe umafotokoza ntchito zomwe zimapanga ndikuwononga mtundu wina wa `Foo`:
//!
//! ```c
//! /* C chamutu */
//!
//! /* Kubwezera umwini wa amene wayimbirayo */
//! struct Foo* foo_new(void);
//!
//! /* Amatenga umwini wa woyimbirayo;osayimba akaitanidwa ndi NULL */
//! void foo_delete(struct Foo*);
//! ```
//!
//! Ntchito ziwirizi zitha kuchitidwa mu Rust motere.Apa, mtundu wa `struct Foo*` kuchokera ku C umamasuliridwa ku `Box<Foo>`, womwe umakhala ndi zovuta za umwini.
//! Onaninso kuti kukangana kosatheka kwa `foo_delete` kumayimiriridwa mu Rust ngati `Option<Box<Foo>>`, popeza `Box<Foo>` siyingakhale yopanda pake.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! Ngakhale `Box<T>` ili ndi chifanizo chofananira ndi C ABI ngati C pointer, izi sizitanthauza kuti mutha kusintha `T*` kukhala `Box<T>` ndikuyembekeza kuti zinthu zigwire ntchito.
//! `Box<T>` mfundo zidzakhala zogwirizana nthawi zonse, zolozera zopanda pake.Kuphatikiza apo, wowononga `Box<T>` ayesa kumasula mtengowo ndi omwe amagawa padziko lonse lapansi.Mwambiri, machitidwe abwino ndikungogwiritsa ntchito `Box<T>` pazolozera zomwe zidachokera kwa omwe amagawa padziko lonse lapansi.
//!
//! **Chofunika.** Pakadali pano, muyenera kupewa kugwiritsa ntchito mitundu ya `Box<T>` pazantchito zomwe zimafotokozedwa mu C koma zopangidwa kuchokera ku Rust.Zikatero, muyenera kuwonetsa mitundu ya C mwachindunji momwe mungathere.
//! Kugwiritsa ntchito mitundu ngati `Box<T>` pomwe tanthauzo la C likungogwiritsa ntchito `T*` kumatha kubweretsa machitidwe osadziwika, monga tafotokozera mu [rust-lang/unsafe-code-guidelines#198][ucg#198].
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// Mtundu wa pointer wogawa mulu.
///
/// Onani [module-level documentation](../../std/boxed/index.html) kuti mumve zambiri.
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// Kugawa kukumbukira pamulu ndikuyika `x` mmenemo.
    ///
    /// Izi sizimagawana kwenikweni ngati `T` ndi yaying'ono.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// Amapanga bokosi latsopano lokhala ndi zinthu zosadziwika.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Kukhazikitsidwa kokhazikika:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// Amapanga `Box` yatsopano yokhala ndi zomwe sizinalembedwe, kukumbukira kukudzazidwa ndi ma `0` byte.
    ///
    ///
    /// Onani [`MaybeUninit::zeroed`][zeroed] pa zitsanzo za kagwiritsidwe molondola ndi kolakwika ka njirayi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// Amapanga `Pin<Box<T>>` yatsopano.
    /// Ngati `T` silingagwiritse ntchito `Unpin`, ndiye kuti `x` idzakanikizidwa kukumbukira ndikulephera kusunthidwa.
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// Kugawa kukumbukira pamulu ndikuyika `x` mmenemo, ndikubwezeretsanso vuto ngati magawowo alephera
    ///
    ///
    /// Izi sizimagawana kwenikweni ngati `T` ndi yaying'ono.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// Amapanga bokosi latsopano lokhala ndi zomwe sizinatchulidwe pamuluwo, ndikubwezera vuto ngati magawowo alephera
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Kukhazikitsidwa kokhazikika:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// Amapanga `Box` yatsopano yokhala ndi zomwe sizinayambike, kukumbukira kukudzazidwa ndi ma `0` byte pamuluwo
    ///
    ///
    /// Onani [`MaybeUninit::zeroed`][zeroed] pa zitsanzo za kagwiritsidwe molondola ndi kolakwika ka njirayi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// Kugawaniza kukumbukira komwe wopatsidwa wapatsidwa ndikuyika `x` mmenemo.
    ///
    /// Izi sizimagawana kwenikweni ngati `T` ndi yaying'ono.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// Kugawa kukumbukira kwa omwe amagawana ndikuyika `x` mmenemo, ndikubwezera cholakwika ngati gawolo lalephera
    ///
    ///
    /// Izi sizimagawana kwenikweni ngati `T` ndi yaying'ono.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// Amapanga bokosi latsopano lokhala ndi zinthu zomwe sizinatchulidwe kale mwa omwe akupatsidwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // Kukhazikitsidwa kokhazikika:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Sankhani machesi pa unwrap_or_else popeza kutsekedwa nthawi zina sikungakhale koyenera.
        // Izi zingapangitse kukula kwama code kukhala kokulirapo.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Amapanga bokosi latsopano lokhala ndi zinthu zomwe sizinatchulidwenso zomwe zili mgawoli, ndikubwezeretsanso vuto ngati gawolo lalephera
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // Kukhazikitsidwa kokhazikika:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Amapanga `Box` yatsopano yokhala ndi zomwe sizinatchulidwepo, kukumbukira kukudzazidwa ndi ma `0` byte mu omwe apatsidwa.
    ///
    ///
    /// Onani [`MaybeUninit::zeroed`][zeroed] pa zitsanzo za kagwiritsidwe molondola ndi kolakwika ka njirayi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Sankhani machesi pa unwrap_or_else popeza kutsekedwa nthawi zina sikungakhale koyenera.
        // Izi zingapangitse kukula kwama code kukhala kokulirapo.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Amapanga `Box` yatsopano yokhala ndi zomwe sizinatchulidwepo, kukumbukira kukudzazidwa ndi ma `0` mwa omwe amapereka, ndikubwezeretsa cholakwika ngati malowo alephera,
    ///
    ///
    /// Onani [`MaybeUninit::zeroed`][zeroed] pa zitsanzo za kagwiritsidwe molondola ndi kolakwika ka njirayi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Amapanga `Pin<Box<T, A>>` yatsopano.
    /// Ngati `T` silingagwiritse ntchito `Unpin`, ndiye kuti `x` idzakanikizidwa kukumbukira ndikulephera kusunthidwa.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// Imatembenuza `Box<T>` kukhala `Box<[T]>`
    ///
    /// Kutembenuka kumeneku sikukhala pamulu ndipo kumachitika m'malo mwake.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// Idya `Box`, ndikubwezera mtengo wokutidwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// Amapanga kagawo kakang'ono kabokosi kokhala ndi zomwe sizinatchulidwepo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Kukhazikitsidwa kokhazikika:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// Amapanga kagawo kakang'ono kabokosi kokhala ndi zinthu zomwe sizinalembedwe, kukumbukira kukudzazidwa ndi ma `0` byte.
    ///
    ///
    /// Onani [`MaybeUninit::zeroed`][zeroed] pa zitsanzo za kagwiritsidwe molondola ndi kolakwika ka njirayi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// Amapanga kagawo kakang'ono kabokosi kamene kali ndi zomwe sizinatchulidwe kale mwa omwe akupereka.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // Kukhazikitsidwa kokhazikika:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// Amapanga kagawo kakang'ono kabokosi kamene kali ndi zomwe sizinatchulidwe kale mwa omwe apatsidwa, kukumbukira kukudzazidwa ndi ma `0` byte.
    ///
    ///
    /// Onani [`MaybeUninit::zeroed`][zeroed] pa zitsanzo za kagwiritsidwe molondola ndi kolakwika ka njirayi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// Amatembenukira ku `Box<T, A>`.
    ///
    /// # Safety
    ///
    /// Monga ndi [`MaybeUninit::assume_init`], zili kwa woyimbirayo kuti atsimikizire kuti mtengowo ulidi woyamba.
    ///
    /// Kuyimbira izi pomwe zomwe zili pano sizinayambitsidwe bwino kumayambitsa machitidwe osadziwika bwino.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // Kukhazikitsidwa kokhazikika:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// Amatembenukira ku `Box<[T], A>`.
    ///
    /// # Safety
    ///
    /// Monga ndi [`MaybeUninit::assume_init`], zili kwa woyimbirayo kuti atsimikizire kuti mfundozo zili pachiyambi.
    ///
    /// Kuyimbira izi pomwe zomwe zili pano sizinayambitsidwe bwino kumayambitsa machitidwe osadziwika bwino.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Kukhazikitsidwa kokhazikika:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// Amapanga bokosi kuchokera pa pointer yaiwisi.
    ///
    /// Pambuyo poyitanitsa ntchitoyi, pointer yaiwisi ndi yake chifukwa cha `Box`.
    /// Makamaka, wowononga `Box` adzaitana wowononga `T` ndikumasula kukumbukira komwe adapatsidwa.
    /// Kuti izi zitheke, kukumbukira kuyenera kuti kunagawidwa molingana ndi [memory layout] yogwiritsidwa ntchito ndi `Box`.
    ///
    ///
    /// # Safety
    ///
    /// Ntchitoyi ndi yosatetezeka chifukwa kugwiritsa ntchito molakwika kumatha kubweretsa zovuta zokumbukira.
    /// Mwachitsanzo, kumasuka kawiri kawiri kumatha kuchitika ngati ntchitoyi imayitanidwa kawiri pacholozera chimodzimodzi.
    ///
    /// Zachitetezo zikufotokozedwa mgawo la [memory layout].
    ///
    /// # Examples
    ///
    /// Pangani `Box` yomwe kale idasinthidwa kukhala pointer yaiwisi pogwiritsa ntchito [`Box::into_raw`]:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Pangani nokha `Box` kuchokera pachiyambi pogwiritsa ntchito ogawa padziko lonse lapansi:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // Mwambiri .write imafunika kupewa kupewa kuyesa kuwononga (uninitialized) zam'mbuyomu za `ptr`, ngakhale pachitsanzo chosavuta ichi `*ptr = 5` ikadagwiranso ntchito.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// Amapanga bokosi kuchokera pa cholozera chakuda mu omwe wapatsidwa.
    ///
    /// Pambuyo poyitanitsa ntchitoyi, pointer yaiwisi ndi yake chifukwa cha `Box`.
    /// Makamaka, wowononga `Box` adzaitana wowononga `T` ndikumasula kukumbukira komwe adapatsidwa.
    /// Kuti izi zitheke, kukumbukira kuyenera kuti kunagawidwa molingana ndi [memory layout] yogwiritsidwa ntchito ndi `Box`.
    ///
    ///
    /// # Safety
    ///
    /// Ntchitoyi ndi yosatetezeka chifukwa kugwiritsa ntchito molakwika kumatha kubweretsa zovuta zokumbukira.
    /// Mwachitsanzo, kumasuka kawiri kawiri kumatha kuchitika ngati ntchitoyi imayitanidwa kawiri pacholozera chimodzimodzi.
    ///
    /// # Examples
    ///
    /// Pangani `Box` yomwe kale idasinthidwa kukhala pointer yaiwisi pogwiritsa ntchito [`Box::into_raw_with_allocator`]:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Pangani nokha `Box` kuchokera pachiyambi pogwiritsa ntchito pulogalamuyo:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // Mwambiri .write imafunika kupewa kupewa kuyesa kuwononga (uninitialized) zam'mbuyomu za `ptr`, ngakhale pachitsanzo chosavuta ichi `*ptr = 5` ikadagwiranso ntchito.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// Imagwiritsa ntchito `Box`, ndikubwezeretsanso cholembera chosaphika.
    ///
    /// Cholozeracho chidzagwirizana bwino ndipo sichikhala chopanda pake.
    ///
    /// Pambuyo poyitanitsa ntchitoyi, woyimbayo ndi amene amachititsa kuti kukumbukira kumayendetsedwa kale ndi `Box`.
    /// Makamaka, woyimbayo ayenera kuwononga `T` moyenera ndikumasula kukumbukira, poganizira [memory layout] yogwiritsidwa ntchito ndi `Box`.
    /// Njira yosavuta yochitira izi ndikusintha pointer yaiwisi kukhala `Box` ndi ntchito ya [`Box::from_raw`], kulola wowononga `Box` kuti ayeretse.
    ///
    ///
    /// Note: Izi ndizogwirizana, zomwe zikutanthauza kuti muyenera kuzitcha `Box::into_raw(b)` m'malo mwa `b.into_raw()`.
    /// Izi ndichifukwa choti palibe kutsutsana ndi njira yamkati yamkati.
    ///
    /// # Examples
    /// Kutembenuza cholembera chobwereranso ku `Box` ndi [`Box::from_raw`] kuti chiyeretsedwe:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Kuyeretsa pamanja poyendetsa zowonongera ndikuwononga kukumbukira:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// Imagwiritsa ntchito `Box`, ndikubwezeretsanso cholembera chofiira ndi wopatsa.
    ///
    /// Cholozeracho chidzagwirizana bwino ndipo sichikhala chopanda pake.
    ///
    /// Pambuyo poyitanitsa ntchitoyi, woyimbayo ndi amene amachititsa kuti kukumbukira kumayendetsedwa kale ndi `Box`.
    /// Makamaka, woyimbayo ayenera kuwononga `T` moyenera ndikumasula kukumbukira, poganizira [memory layout] yogwiritsidwa ntchito ndi `Box`.
    /// Njira yosavuta yochitira izi ndikusintha pointer yaiwisi kukhala `Box` ndi ntchito ya [`Box::from_raw_in`], kulola wowononga `Box` kuti ayeretse.
    ///
    ///
    /// Note: Izi ndizogwirizana, zomwe zikutanthauza kuti muyenera kuzitcha `Box::into_raw_with_allocator(b)` m'malo mwa `b.into_raw_with_allocator()`.
    /// Izi ndichifukwa choti palibe kutsutsana ndi njira yamkati yamkati.
    ///
    /// # Examples
    /// Kutembenuza cholembera chobwereranso ku `Box` ndi [`Box::from_raw_in`] kuti chiyeretsedwe:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Kuyeretsa pamanja poyendetsa zowonongera ndikuwononga kukumbukira:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // Bokosi limadziwika kuti "unique pointer" ndi Stacked Borrows, koma mkati mwake ndi cholozera chosakira cha mtundu wamtunduwu.
        // Kuisintha molunjika mu pointer yaiwisi sikungazindikiridwe kuti "releasing" cholozera chapadera chololeza kufikira kosavuta, kotero njira zonse za pointer zosaphika zimayenera kudutsa `Box::leak`.
        //
        // Kutembenuzira * icho ku pointer yaiwisi kumachita bwino.
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// Kubwezeretsa kutanthauzira kwa wopatsa amene akuyambitsa.
    ///
    /// Note: Izi ndizogwirizana, zomwe zikutanthauza kuti muyenera kuzitcha `Box::allocator(&b)` m'malo mwa `b.allocator()`.
    /// Izi ndichifukwa choti palibe kutsutsana ndi njira yamkati yamkati.
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// Amagwiritsa ntchito ndikutulutsa `Box`, ndikubwezeretsanso zosinthika, `&'a mut T`.
    /// Dziwani kuti mtundu wa `T` uyenera kupitilira nthawi yosankhidwa ya `'a`.
    /// Ngati mtunduwo umangokhala ndi zongonena zokha, kapena palibe, ndiye kuti mutha kusankha `'static`.
    ///
    /// Ntchitoyi ndi yofunika kwambiri pa deta yomwe imakhala moyo wonse wa pulogalamuyi.
    /// Kutaya zomwe zalembedwazo kudzapangitsa kukumbukira kukumbukira.
    /// Ngati izi sizilandiridwa, chofunikiracho chiyenera kukulungidwa ndi [`Box::from_raw`] ndikupanga `Box`.
    ///
    /// `Box` iyi itha kugwetsedwa yomwe idzawonongeratu `T` ndikumasula kukumbukira komwe kunaperekedwa.
    ///
    /// Note: Izi ndizogwirizana, zomwe zikutanthauza kuti muyenera kuzitcha `Box::leak(b)` m'malo mwa `b.leak()`.
    /// Izi ndichifukwa choti palibe kutsutsana ndi njira yamkati yamkati.
    ///
    /// # Examples
    ///
    /// Ntchito yosavuta:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// Zambiri zosasintha:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// Imatembenuza `Box<T>` kukhala `Pin<Box<T>>`
    ///
    /// Kutembenuka kumeneku sikukhala pamulu ndipo kumachitika m'malo mwake.
    ///
    /// Izi zimapezekanso kudzera pa [`From`].
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // Sizingatheke kusunthira kapena kulowa m'malo amkati mwa `Pin<Box<T>>` pomwe `T: !Unpin`, chifukwa chake ndibwino kuyiyika mwachindunji popanda zofunikira zina.
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: Osachita chilichonse, kuponya kumachitidwa ndi wopanga.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// Amapanga `Box<T>`, ndi mtengo wa `Default` wa T.
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// Imabwezeretsa bokosi latsopano lomwe lili ndi `clone()` yazomwe zili m'bokosili.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // Mtengo ndi chimodzimodzi
    /// assert_eq!(x, y);
    ///
    /// // Koma ndi zinthu zapadera
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // Peletsani chikumbukiro kuti mulole kulembetsa mtengo wokhazikika mwachindunji.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// Zolemba zam'katikati mwa `self` osapanga gawo latsopano.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // Mtengo ndi chimodzimodzi
    /// assert_eq!(x, y);
    ///
    /// // Ndipo palibe kugawa komwe kudachitika
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // izi zimapanga kopi ya deta
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// Imatembenuza mtundu wa `T` kukhala `Box<T>`
    ///
    /// Kutembenuka kumagawana pamulu ndikusuntha `t` kuchokera muluwo kulowa mmenemo.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// Imatembenuza `Box<T>` kukhala `Pin<Box<T>>`
    ///
    /// Kutembenuka kumeneku sikukhala pamulu ndipo kumachitika m'malo mwake.
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// Imatembenuza `&[T]` kukhala `Box<[T]>`
    ///
    /// Kutembenuka kumeneku kumagawana pamulu ndikujambula `slice`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // pangani&[u8] yomwe idzagwiritsidwe ntchito kupanga Bokosi <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// Imatembenuza `&str` kukhala `Box<str>`
    ///
    /// Kutembenuka kumeneku kumagawana pamulu ndikujambula `s`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// Imatembenuza `Box<str>` kukhala `Box<[u8]>`
    /// Kutembenuka kumeneku sikukhala pamulu ndipo kumachitika m'malo mwake.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // pangani Bokosi<str>yomwe idzagwiritsidwe ntchito popanga Bokosi <[u8]>
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // pangani&[u8] yomwe idzagwiritsidwe ntchito kupanga Bokosi <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// Imatembenuza `[T; N]` kukhala `Box<[T]>`
    /// Kutembenuka kumeneku kumapangitsa gulu kuti likumbukire kumene kwasungidwa mulu.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Kuyesera kugwetsa bokosi pamtundu wa konkriti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Kuyesera kugwetsa bokosi pamtundu wa konkriti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// Kuyesera kugwetsa bokosi pamtundu wa konkriti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Sizingatheke kuchotsa Uniq wamkati mwachindunji kuchokera mu Bokosi, m'malo mwake timayiponya ku * const yomwe imasiyanitsa Wapaderayo
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// Katswiri wamitundu yayikulu yomwe imagwiritsa ntchito kukhazikitsa kwa `last()` m'malo mofikira.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}