/// Pangani [`Vec`] yokhala ndi zotsutsanazo.
///
/// `vec!` imalola `Vec` kutanthauziridwa ndi mawu ofanana mofananira ndi mafotokozedwe osiyanasiyana.
/// Pali mitundu iwiri ya izi:
///
/// - Pangani [`Vec`] yokhala ndi mndandanda wazinthu:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Pangani [`Vec`] kuchokera pazomwe mwapatsidwa ndi kukula kwake:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Dziwani kuti mosiyana ndi malingaliro amtunduwu syntax iyi imathandizira zinthu zonse zomwe zimakhazikitsa [`Clone`] ndipo kuchuluka kwa zinthu sikuyenera kukhala kosasintha.
///
/// Izi zidzagwiritsa ntchito `clone` kubwereza mawu, chifukwa chake munthu ayenera kusamala pogwiritsa ntchito mitundu yokhala ndi kukhazikitsidwa kosavomerezeka kwa `Clone`.
/// Mwachitsanzo, `vec![Rc::new(1);5] `ipanga vector yamafotokozedwe asanu pamtengo wofananawo wokhala ndi mabokosi omwewo, osati maumboni asanu omwe akuwongolera manambala omwe amangodziyimira pawokha.
///
///
/// Komanso, zindikirani kuti `vec![expr; 0]` imaloledwa, ndikupanga vector yopanda kanthu.
/// Izi ziwunikiranso `expr`, komabe, ndikuwononga phindu lake, chifukwa chake kumbukirani zovuta zina.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): ndi cfg(test) njira yachibadwidwe ya `[T]::into_vec`, yomwe imafunikira kutanthauzira kwakukulu, sikupezeka.
// M'malo mwake gwiritsani ntchito ntchito ya `slice::into_vec` yomwe imangopezeka ndi cfg(test) NB onani slice::hack module mu slice.rs kuti mumve zambiri
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Pangani `String` pogwiritsa ntchito mawu omasulira nthawi yothamanga.
///
/// Mtsutso woyamba `format!` umalandira ndi chingwe cha mtundu.Ichi chiyenera kukhala chingwe chenicheni.Mphamvu yazosanja zomwe zili mu ``{}`s zili mkati.
///
/// Zowonjezera zomwe zidaperekedwa ku `format!` zimasinthira `{}` s mkati mwa chingwe chojambulitsa mu dongosolo lomwe laperekedwa pokhapokha atagwiritsa ntchito magawo ena kapena mawonekedwe;onani [`std::fmt`] kuti mumve zambiri.
///
///
/// Ntchito wamba ya `format!` ndikuphatikiza ndi zingwe.
/// Msonkhano womwewo umagwiritsidwa ntchito ndi [`print!`] ndi [`write!`] macros, kutengera komwe akufuna chingwecho.
///
/// Kuti musinthe mtengo umodzi kukhala chingwe, gwiritsani ntchito njira ya [`to_string`].Izi zidzagwiritsa ntchito [`Display`] yopanga trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics ngati kukhazikitsa trait kukhazikitsa kumabwezeretsa vuto.
/// Izi zikuwonetsa kukhazikitsa kolakwika popeza `fmt::Write for String` siyibweza cholakwika chokha.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Limbikitsani mfundo ya AST pamawu kuti musinthe mawonekedwe amachitidwe.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}