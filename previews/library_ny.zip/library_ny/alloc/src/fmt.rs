//! Zida zopangira ndi kusindikiza `String`s.
//!
//! Gawoli lili ndi pulogalamu yothamanga pakuwonjezera mawu a [`format!`].
//! Izi zazikulu zimayendetsedwa pakuphatikizira kuti zizitulutsa mayankho ku gawoli kuti zithandizire kupanga mfundo nthawi yothamangitsa zingwe.
//!
//! # Usage
//!
//! The [`format!`] macro cholinga chake ndikudziwika kwa iwo ochokera ku ntchito za C's `printf`/`fprintf` kapena Python's `str.format`.
//!
//! Zitsanzo zina zowonjezera [`format!`] ndi izi:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" ndi zero zotsogolera
//! ```
//!
//! Kuchokera pa izi, mutha kuwona kuti mtsutso woyamba ndi chingwe cha mtundu.Amayenera wolemba kuti akhale chingwe chenicheni;sipangakhale kusinthasintha kosinthidwa (kuti muwone ngati kuli koyenera).
//! Wolembayo adzawongolera chingwecho kuti awone ngati mndandanda wazomwe zaperekedwa ndizoyenera kupitako chingwechi.
//!
//! Kuti musinthe mtengo umodzi kukhala chingwe, gwiritsani ntchito njira ya [`to_string`].Izi zidzagwiritsa ntchito [`Display`] yopanga trait.
//!
//! ## Zigawo zina
//!
//! Kutsutsana kulikonse kumaloledwa kufotokozera kuti ndi mfundo yanji yomwe ikufotokozera, ndipo ngati siyiyimilira akuti ndi "the next argument".
//! Mwachitsanzo, chingwe cha `{} {} {}` chimatha kutenga magawo atatu, ndipo amakhoza kupangika momwemo momwe amaperekedwera.
//! Chingwe cha mtundu `{2} {1} {0}`, komabe, chitha kupangira zokambirana motsutsana.
//!
//! Zinthu zimatha kukhala zosokoneza mukangoyamba kusakanikirana ndi mitundu iwiri ya zotsogola.Chowonera "next argument" chitha kuganiziridwa ngati cholembera pamkangano.
//! Nthawi iliyonse yowunikira "next argument" ikawonedwa, owongolera amapita patsogolo.Izi zimabweretsa machitidwe ngati awa:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Woyendetsa mkati wazokangana sanapite patsogolo pomwe `{}` yoyamba imawoneka, ndiye imasindikiza mkangano woyamba.Kenako pofika pa `{}` yachiwiri, iterator idapita patsogolo kutsutsana kwachiwiri.
//! Kwenikweni, magawo omwe amafotokoza momveka bwino kutsutsana kwawo samakhudza magawo omwe satchula mkangano malinga ndi zomwe akutchulazi.
//!
//! Chingwe chamtundu chimafunikira kuti mugwiritse ntchito mfundo zake zonse, apo ayi ndi vuto la nthawi yopanga.Mutha kulozera kutsutsana komweko kangapo mu chingwe cha mtunduwo.
//!
//! ## Anatchula magawo
//!
//! Rust palokha ilibe Python yofanana ndi magawo omwe atchulidwa kuti agwire ntchito, koma macro [`format!`] ndikulumikiza kwama syntax komwe kumalola kuti igwiritse ntchito magawo omwe atchulidwa.
//! Maina omwe atchulidwa adatchulidwa kumapeto kwa mndandanda wazokambirana ndipo ali ndi syntax:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Mwachitsanzo, mawu otsatirawa a [`format!`] amagwiritsa ntchito mkangano:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Sizovomerezeka kuyika magawo ena (omwe alibe mayina) pambuyo pamikangano yomwe ili ndi mayina.Monga momwe zilili ndi magawo ena, sizovomerezeka kupereka magawo omwe sanathenso kugwiritsidwa ntchito ndi chingwecho.
//!
//! # Kupanga Magawo
//!
//! Kutsutsana kulikonse komwe kumapangidwa kumatha kusinthidwa ndimitundu ingapo yamitundu (yolingana ndi `format_spec` mu [the syntax](#syntax)). Magawo awa amakhudza kuyimira kwa chingwe cha zomwe zikupangidwa.
//!
//! ## Width
//!
//! ```
//! // Zonsezi zimasindikiza "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Ichi ndi gawo la "minimum width" lomwe mtunduwo uyenera kutengedwa.
//! Chingwe cha mtengowo ngati sichikwaniritsa zilembozi, ndiye kuti padding yotchulidwa ndi fill/alignment idzagwiritsidwa ntchito kutenga malo ofunikira (onani pansipa).
//!
//! Mtengo wa m'lifupi ungaperekedwenso ngati [`usize`] pamndandanda wa magawo powonjezera postfix `$`, kuwonetsa kuti kukangana kwachiwiri ndi [`usize`] komwe kumatanthauza m'lifupi.
//!
//! Kutchula mkangano ndi syntax ya dollar sikukhudza cholembera "next argument", chifukwa chake nthawi zambiri ndibwino kutchula zotsutsana ndi malo, kapena kugwiritsa ntchito zifukwa zomwe zatchulidwa.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Khalidwe lodzaza ndikusanja limaperekedwa bwino molumikizana ndi [`width`](#width) parameter.Iyenera kufotokozedwa `width` isanachitike, pambuyo pa `:` yokha.
//! Izi zikuwonetsa kuti ngati mtengo womwe ukukonzedwa uli wocheperako `width` zilembo zina zowonjezera zidzasindikizidwa mozungulira.
//! Kudzaza kumabwera m'mitundu yotsatizana mosiyanasiyana:
//!
//! * `[fill]<` - kukangana kumalumikizidwa kumanzere m'mizati ya `width`
//! * `[fill]^` - mkanganowo waphatikizidwa pakati pazithunzi za `width`
//! * `[fill]>` - mkanganowo ndi wolondola m'mizere ya `width`
//!
//! [fill/alignment](#fillalignment) yosasinthika ya osakhala manambala ndi danga ndikumanzere kumanzere.Chosintha pamitundu yamitundu chimakhalanso ndi mawonekedwe amlengalenga koma molondola.
//! Ngati mbendera ya `0` (onani m'munsimu) yatchulidwa manambala, ndiye kuti kudzazidwa ndi `0`.
//!
//! Dziwani kuti mayikidwe sangapangidwe ndi mitundu ina.Makamaka, sikuti imagwiritsidwa ntchito kawirikawiri pa `Debug` trait.
//! Njira yabwino yowonetsetsa kuti padding ikugwiritsidwa ntchito ndikupanga zolemba zanu, kenako ndikulumikiza chingwechi kuti mupeze zomwe mwatulutsa:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Moni Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Izi zonse ndi mbendera zosintha machitidwe a wopanga.
//!
//! * `+` - Izi zapangidwira mitundu yamitundu ndipo zikuwonetsa kuti chizindikirocho chizisindikizidwa nthawi zonse.Zizindikiro zabwino sizimasindikizidwa mwachisawawa, ndipo chizindikirocho chimangosindikizidwa ndi `Signed` trait.
//! Mbendera imasonyeza kuti chizindikiro cholondola (`+` kapena `-`) chiyenera kusindikizidwa nthawi zonse.
//! * `-` - Sigwiritsidwe ntchito pano
//! * `#` - Mbendera ikuwonetsa kuti mtundu wa "alternate" wosindikiza uyenera kugwiritsidwa ntchito.Mitundu ina ndi iyi:
//!     * `#?` - sindikizani mtundu wa [`Debug`]
//!     * `#x` - imayambitsa mkangano ndi `0x`
//!     * `#X` - imayambitsa mkangano ndi `0x`
//!     * `#b` - imayambitsa mkangano ndi `0b`
//!     * `#o` - imayambitsa mkangano ndi `0o`
//! * `0` - Izi zimagwiritsidwa ntchito kuwonetsa mitundu yonse kuti padding yopita ku `width` iyenera kuchitidwa ndi `0` komanso kukhala ozindikira.
//! Mtundu ngati `{:08}` ungatulutse `00000001` pa nambala ya `1`, pomwe mtundu womwewo ungapereke `-0000001` ya nambala yonse ya `-1`.
//! Zindikirani kuti mtundu woyipa uli ndi zero zochepa kuposa mtundu wabwino.
//!         Dziwani kuti ma padding omwe amaikidwa nthawi zonse amaikidwa pambuyo pa chizindikirocho (ngati alipo) komanso manambala asanafikeMukagwiritsidwa ntchito limodzi ndi mbendera ya `#`, lamulo lofananalo limagwira ntchito: zero padding imayikidwanso pambuyo pa manambala oyamba koma manambala asanafike.
//!         Choyambirira chimaphatikizidwa m'lifupi lonse.
//!
//! ## Precision
//!
//! Kwa mitundu yopanda manambala, izi zitha kuonedwa ngati "maximum width".
//! Ngati chingwecho chimakhala chotalikirapo kuposa m'lifupi mwake, ndiye kuti chimachotsedwera pamanambala ambiriwo ndipo phindu locheperako limatulutsidwa ndi `fill`, `alignment` ndi `width` yoyenera ngati magawo amenewo akhazikitsidwa.
//!
//! Kwa mitundu yonse, izi sizinyalanyazidwa.
//!
//! Kwa mitundu yazoyandama, izi zikuwonetsa kuchuluka kwa manambala pambuyo poti decimal iyenera kusindikizidwa.
//!
//! Pali njira zitatu zotchulira `precision` yomwe mukufuna:
//!
//! 1. Chiwerengero cha `.N`:
//!
//!    manambala onse a `N` ndiwo molondola.
//!
//! 2. Nambala kapena dzina lotsatiridwa ndi chizindikiro cha dollar `.N$`:
//!
//!    gwiritsani ntchito mtundu *mtsutso*`N` (yomwe iyenera kukhala `usize`) molondola.
//!
//! 3. Nyenyezi `.*`:
//!
//!    `.*` zikutanthauza kuti `{...}` iyi imagwirizanitsidwa ndi zolowetsera *ziwiri* m'malo mochita chimodzi: cholowacho choyamba chimagwira molondola `usize`, ndipo chachiwiri chimakhala ndi mtengo wosindikiza.
//!    Dziwani kuti pamenepa, ngati wina agwiritsa ntchito chingwe cha `{<arg>:<spec>.*}`, ndiye kuti gawo la `<arg>` limatanthauza* value * kuti musindikize, ndipo `precision` iyenera kubwera mu zomwe zidalipo `<arg>`.
//!
//! Mwachitsanzo, zotsatirazi zikuyitanitsa onse kusindikiza zomwezo `Hello x is 0.01000`:
//!
//! ```
//! // Moni {arg 0 ("x")} ndi {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Moni {arg 1 ("x")} ndi {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Moni {arg 0 ("x")} ndi {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Moni {next arg ("x")} ndi {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Moni {next arg ("x")} ndi {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Moni {next arg ("x")} ndi {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Ngakhale izi:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! sindikizani zinthu zitatu zosiyana:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! M'zinenero zina zamapulogalamu, machitidwe azinthu zopanga zingwe zimadalira kakhazikitsidwe ka kachitidwe kake.
//! Maonekedwe omwe amaperekedwa ndi laibulale yovomerezeka ya Rust alibe malingaliro amtundu uliwonse ndipo apanga zotsatira zomwezo pamakina onse mosasamala momwe ogwiritsa ntchito amasinthira.
//!
//! Mwachitsanzo, nambala yotsatirayi nthawi zonse imasindikiza `1.5` ngakhale makinawo atagwiritsa ntchito chosiyanitsa china kupatula kadontho.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Zolemba zenizeni `{` ndi `}` zitha kuphatikizidwa ndi chingwe powatsogolera ndi chikhalidwe chomwecho.Mwachitsanzo, `{` wathawa ndi `{{` ndipo `}` wathawa ndi `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Mwachidule, apa mungapeze galamala yathunthu yazingwe zamtundu.
//! Mawu omasulira a chilankhulo chogwiritsa ntchito amachokera kuzilankhulo zina, chifukwa chake sichiyenera kukhala chachilendo.Mikangano imapangidwa ndi syntax ya Python, kutanthauza kuti mikangano yazunguliridwa ndi `{}` m'malo mwa C-ngati `%`.
//! Galamala yeniyeni yopanga mawuwa ndi:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Mu galamala ili pamwambapa, `text` mwina siyikhala ndi zilembo za `'{'` kapena `'}'`.
//!
//! # Kupanga traits
//!
//! Mukapempha kuti mkangano usinthidwe ndi mtundu winawake, mukupemphadi kuti mkangano ugwirizane ndi trait inayake.
//! Izi zimalola mitundu ingapo kuti ipangidwe kudzera pa `{:x}` (monga [`i8`] komanso [`isize`]).Mapu amitundu yamtundu wa traits ndi:
//!
//! * *palibe* ⇒ [`Display`]
//! * `?` 00 [`Debug`]
//! * `x?` ⇒ [`Debug`] yokhala ndi manambala ochepa a hexadecimal
//! * `X?` ⇒ [`Debug`] yokhala ndi manambala akuluakulu a hexadecimal
//! * `o` 00 [`Octal`]
//! * `x` 00 [`LowerHex`]
//! * `X` 00 [`UpperHex`]
//! * `p` 00 [`Pointer`]
//! * `b` 00 [`Binary`]
//! * `e` 00 [`LowerExp`]
//! * `E` 00 [`UpperExp`]
//!
//! Izi zikutanthawuza kuti mtundu uliwonse wazokambirana zomwe zimagwiritsa ntchito [`fmt::Binary`][`Binary`] trait zitha kupangidwa ndi `{:b}`.Kukhazikitsa kumaperekedwera ma traits amitundu ingapo yakale ndi laibulale yanthawi zonse.
//!
//! Ngati palibe mtundu womwe watchulidwa (monga `{}` kapena `{:6}`), ndiye kuti mtundu wa trait womwe wagwiritsidwa ntchito ndi [`Display`] trait.
//!
//! Mukamapanga mtundu wa trait wamtundu wanu, muyenera kugwiritsa ntchito siginecha:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // mtundu wathu wachikhalidwe
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Mtundu wanu udutsa ngati `self` potengera, kenako ntchitoyo iyenera kutulutsa zotulutsa mumtsinje wa `f.buf`.Zili pamtundu uliwonse kukhazikitsidwa kwa trait kuti zizitsatira moyenera zomwe zafunsidwa.
//! Makhalidwe azikhalidwezi adzalembedwa mndime za [`Formatter`] struct.Pofuna kuthandizira pa izi, [`Formatter`] struct imaperekanso njira zina zothandizira.
//!
//! Kuphatikiza apo, phindu lobwezera ntchitoyi ndi [`fmt::Result`] yomwe ndi mtundu wina wa [`Zotsatira`]`<(),`[`std: : fmt::Error`] `>`.
//! Kukhazikitsa makonzedwe kuyenera kuwonetsetsa kuti amafalitsa zolakwika kuchokera ku [`Formatter`] (mwachitsanzo, poyimbira [`write!`]).
//! Komabe, sayenera kubwezera zolakwika mwachinyengo.
//! Ndiye kuti, kukhazikitsa kwamitundu kuyenera ndipo kungangobweza cholakwika ngati X-X yemwe adalowererayo abweza cholakwika.
//! Izi ndichifukwa choti, mosiyana ndi zomwe siginecha ya ntchitoyo ingatanthauzire, kapangidwe kazingwe sikungalephereke.
//! Ntchitoyi imangobweretsanso zotsatira chifukwa kulembera kutsinjewo kumatha kulephera ndipo kuyenera kupereka njira yofalitsira kuti kulakwitsa kwachitika ndikubwezeretsanso.
//!
//! Chitsanzo chokhazikitsa zojambula traits zingawoneke ngati:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Mtengo wa `f` umagwiritsa ntchito `Write` trait, zomwe ndizolemba!zazikulu zikuyembekezera.
//!         // Dziwani kuti mawonekedwe awa amanyalanyaza mbendera zosiyanasiyana zomwe zimaperekedwa pakupanga zingwe.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // traits zosiyanasiyana zimalola mitundu ina yazotulutsa zamtundu wina.
//! // Tanthauzo la mtundu uwu ndikusindikiza ukulu wa vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Lemekezani mbendera zojambulazo pogwiritsa ntchito njira yothandizira `pad_integral` pachinthu cha Formatter.
//!         // Onani njira zolembedwera mwatsatanetsatane, ndipo ntchito `pad` itha kugwiritsidwa ntchito kupangira zingwe.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` ndi `fmt::Debug`
//!
//! traits ziwirizi zimakhala ndi zolinga zosiyana:
//!
//! - [`fmt::Display`][`Display`] kukhazikitsa akuti mtunduwo ukhoza kuyimiridwa mokhulupirika ngati chingwe cha UTF-8 nthawi zonse.Siziyembekezeredwa kuti mitundu yonse igwiritse ntchito [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] kukhazikitsa kuyenera kukhazikitsidwa pamitundu yonse ya anthu **.
//!   Zotsatira ziziyimira boma lamkati mokhulupirika momwe zingathere.
//!   Cholinga cha [`Debug`] trait ndikuthandizira kukonza kachidindo ka Rust.Nthawi zambiri, kugwiritsa ntchito `#[derive(Debug)]` ndikwanira ndikulimbikitsidwa.
//!
//! Zitsanzo zina za zotuluka kuchokera ku traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Ma macro okhudzana
//!
//! Pali ma macro angapo okhudzana mu banja la [`format!`].Zomwe zikugwiritsidwa ntchito pano ndi izi:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Izi ndi [`writeln!`] ndi ma macro awiri omwe amagwiritsidwa ntchito kutulutsa chingwecho pamtundu wina.Izi zimagwiritsidwa ntchito popewa magawidwe apakatikati amtundu wazingwe m'malo mwake lembani zomwe zatulutsidwa.
//! Pansi pa hood, ntchitoyi ikuyitanitsa ntchito ya [`write_fmt`] yofotokozedwa pa [`std::io::Write`] trait.
//! Kugwiritsa ntchito mwachitsanzo ndi:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Izi ndi [`println!`] zimatulutsa zotsatira zawo ku stdout.Mofananamo ndi [`write!`] macro, cholinga cha macro amenewa ndikupewa magawidwe apakatikati mukasindikiza zomwe zatulutsidwa.Kugwiritsa ntchito mwachitsanzo ndi:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Ma [`eprint!`] ndi [`eprintln!`] macros ali ofanana ndi [`print!`] ndi [`println!`], motsatana, pokhapokha atapereka zotsatira zawo ku stderr.
//!
//! ### `format_args!`
//!
//! Awa ndi macro owoneka bwino omwe amagwiritsidwa ntchito pozungulira chinthu chopanda tanthauzo pofotokozera chingwecho.Izi sizifunikira kuti zigawidwe mulu uliwonse, ndipo zimangotchulanso zambiri pamuluwo.
//! Pansi pa hood, ma macro onse okhudzana amagwiritsidwa ntchito potengera izi.
//! Choyamba, zitsanzo zina ndi izi:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Zotsatira za [`format_args!`] macro ndi mtengo wamtundu wa [`fmt::Arguments`].
//! Kapangidwe kameneka kangaperekedwe ku ntchito za [`write`] ndi [`format`] mkati mwa gawo ili kuti mugwiritse ntchito chingwecho.
//! Cholinga cha macro ndikutetezanso kupewa magawidwe apakatikati polimbana ndi zingwe zopanga.
//!
//! Mwachitsanzo, laibulale yodula mitengo imatha kugwiritsa ntchito malembedwe ofananirako, koma imadutsa mkatimo mpaka itadziwitsidwa komwe ikuyenera kupita.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Ntchito ya `format` imatenga [`Arguments`] struct ndikubwezeretsanso chingwe chomwe chidapangidwa.
///
///
/// Chitsanzo cha [`Arguments`] chitha kupangidwa ndi [`format_args!`] macro.
///
/// # Examples
///
/// Kagwiritsidwe:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Chonde dziwani kuti kugwiritsa ntchito [`format!`] kungakhale kotheka.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}