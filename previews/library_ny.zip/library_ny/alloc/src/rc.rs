//! Zolembera za ulusi umodzi wokha.'Rc' imayimira 'Reference
//! Counted'.
//!
//! Mtundu [`Rc<T>`][`Rc`] umakhala ndi umwini wofanana wamtundu wa `T`, woperekedwa pamuluwo.
//! Kuyitanitsa [`clone`][clone] pa [`Rc`] kumatulutsa cholozera chatsopano kumagawo omwewo pamuluwo.
//! Cholozera chomaliza cha [`Rc`] mukagawe chomwe chapatsidwa chikuwonongedwa, mtengo womwe umasungidwa mgawolo (womwe umatchedwa "inner value") umatsikidwanso.
//!
//! Mafotokozedwe ogawana mu Rust salola kusintha kosasintha, ndipo [`Rc`] sichimodzimodzi: simungathe kutchula chinthu china mkati mwa [`Rc`].
//! Ngati mukufuna kusintha, ikani [`Cell`] kapena [`RefCell`] mkati mwa [`Rc`];onani [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] imagwiritsa ntchito kuwerengera kosafanana ndi atomiki.
//! Izi zikutanthauza kuti pamwamba pake pamakhala kotsika kwambiri, koma [`Rc`] siyingatumizedwe pakati pa ulusi, chifukwa chake [`Rc`] siyigwiritsa ntchito [`Send`][send].
//! Zotsatira zake, wolemba Rust awunika *nthawi yolemba* yomwe simukutumiza [`Rc`] pakati pa ulusi.
//! Ngati mukufuna zingwe zingapo, kuwerengera ma atomiki, gwiritsani ntchito [`sync::Arc`][arc].
//!
//! Njira ya [`downgrade`][downgrade] itha kugwiritsidwa ntchito kupanga cholembera [`Weak`] chosakhala nacho.
//! Cholozera [`Weak`] chikhoza kukhala [`upgrade"][sinthani] d kufika pa [`Rc`], koma izi zibwezeretsa [`None`] ngati phindu lomwe lasungidwa mgawoli lidatsitsidwa kale.
//! Mwanjira ina, zilozera za `Weak` sizisunga phindu lomwe lili mgawoli;komabe, iwo * amasunga gawolo (malo ogulitsira amtengo wamkati) amoyo.
//!
//! Kuzungulira pakati pa zikhomo za [`Rc`] sikudzasinthidwa.
//! Pachifukwa ichi, [`Weak`] imagwiritsidwa ntchito kuswa nthawi.
//! Mwachitsanzo, mtengo umatha kukhala ndi zokumbutsa zolimba za [`Rc`] kuchokera kuma mfundo a kholo kupita kwa ana, ndi zokumbutsa za [`Weak`] kuchokera kwa ana kubwerera kwa makolo awo.
//!
//! `Rc<T>` zimangotengera `T` (kudzera pa [`Deref`] trait), kuti muthe kuyimba njira za `T` pamtengo wamtundu wa [`Rc<T>`][`Rc`].
//! Pofuna kupewa kusamvana kwamaina ndi njira za `T, njira za [`Rc<T>`][`Rc`] palokha ndizogwirizana, zotchedwa kugwiritsa ntchito [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `` Rc<T>Kukhazikitsa kwa traits ngati `Clone` kungathenso kutchedwa kugwiritsa ntchito ma syntax oyenerera.
//! Anthu ena amakonda kugwiritsa ntchito mawu omasulira bwino, pomwe ena amakonda kugwiritsa ntchito njira yolankhulirana.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Ma syntax oyimbira
//! let rc2 = rc.clone();
//! // Ma syntax oyenerera
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] sichimangodzipangira nokha ku `T`, chifukwa mtengo wamkati ukhoza kuti udagwetsedwa kale.
//!
//! # Maumboni opangira
//!
//! Kupanga kutanthauzira kwatsopano pamalingaliro omwewo monga cholembera chomwe chidalipo kale chachitika pogwiritsa ntchito `Clone` trait yoyendetsedwa ndi [`Rc<T>`][`Rc`] ndi [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Ma syntax awiriwa pansipa ndi ofanana.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a ndi b zonsezo zikulozera komwe kumakhala kukumbukira.
//! ```
//!
//! Syntax ya `Rc::clone(&from)` ndiyotanthauzira kwambiri chifukwa imafotokoza momveka bwino tanthauzo la code.
//! Mu chitsanzo pamwambapa, mawu omasulirawa amachititsa kuti zikhale zosavuta kuwona kuti code iyi ikupanga chatsopano m'malo mokopera zonse za foo.
//!
//! # Examples
//!
//! Taganizirani za momwe ma ``Gadget`s amakhala a `Owner` yopatsidwa.
//! Tikufuna kuti gawo lathu la `` Gadget '' liloze ku `Owner` yawo.Sitingachite izi ndi umwini wapadera, chifukwa zida zingapo zimatha kukhala za `Owner` yomweyo.
//! [`Rc`] amatilola kugawana `Owner` pakati pa ma `Gadget` angapo, ndikukhala ndi `Owner` kuti igawidwe malinga ngati pali `Gadget` iliyonse.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... minda ina
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... minda ina
//! }
//!
//! fn main() {
//!     // Pangani `Owner` yowerengedwa.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Pangani ma gadget a `gadget_owner`.
//!     // Kuphatikiza `Rc<Owner>` kumatipatsa cholozera chatsopano kumagawo omwewo a `Owner`, ndikuwonjezera kuchuluka kwa zomwe zikuchitika.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Chotsani `gadget_owner` yathu yakomweko.
//!     drop(gadget_owner);
//!
//!     // Ngakhale tidasiya `gadget_owner`, tikadali okhoza kusindikiza dzina la `Owner` la `Gadget`s.
//!     // Izi ndichifukwa choti tangotsala `Rc<Owner>` imodzi, osati `Owner` yomwe ikulozera.
//!     // Malingana ngati pali ma `Rc<Owner>` ena omwe akulozera gawo lomwelo la `Owner`, amakhalabe amoyo.
//!     // Kuyerekeza kwa m'munda `gadget1.owner.name` kumagwira ntchito chifukwa `Rc<Owner>` imangotengera `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Pamapeto pa ntchitoyi, `gadget1` ndi `gadget2` ziwonongedwa, ndipo ndizomaliza zowerengera za `Owner` yathu.
//!     // Gadget Man tsopano awonongedwa.
//!     //
//! }
//! ```
//!
//! Ngati zofunikira zathu zisintha, ndipo tikufunikiranso kuchoka ku `Owner` kupita ku `Gadget`, tidzakumana ndi mavuto.
//! Cholozera [`Rc`] kuchokera ku `Owner` mpaka `Gadget` chimayambitsa kuzungulira.
//! Izi zikutanthauza kuti kuchuluka kwawo sikungafikire 0, ndipo magawowo sadzawonongedwa:
//! kukumbukira kukumbukira.Kuti titha kuzungulira izi, titha kugwiritsa ntchito zolemba za [`Weak`].
//!
//! Rust zimapangitsa kuti zikhale zovuta kuti apange malowo poyamba.Kuti tithe kukhala ndi mfundo ziwiri zomwe zimalozerana, chimodzi mwazomwe ziyenera kusintha.
//! Izi ndizovuta chifukwa [`Rc`] imalimbikitsa chitetezo chakumbukidwe popereka zogawana zokhazokha za mtengo womwe umakulunga, ndipo izi sizimalola kusintha kwachindunji.
//! Tiyenera kukulunga gawo lamtengo womwe tikufuna kusinthana mu [`RefCell`], yomwe imapereka *kusintha kwamkati*: njira yokwaniritsira kusinthika pogwiritsa ntchito zomwe tagawana.
//! [`RefCell`] imalimbikitsa malamulo obwereketsa a Rust panthawi yothamanga.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... minda ina
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... minda ina
//! }
//!
//! fn main() {
//!     // Pangani `Owner` yowerengedwa.
//!     // Dziwani kuti taika vector ya `Owner'Z ya`Gadget`s mkati mwa `RefCell` kuti titha kuyisintha pogwiritsa ntchito zomwe tagawana.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Pangani ma Gadget a `gadget_owner`, monga kale.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Onjezerani `Gadget`s ku `Owner` yawo.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` Kubwereka kwamphamvu kumathera apa.
//!     }
//!
//!     // Sinthani ma Gadget athu, ndikusindikiza zambiri zawo.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` ndi `Weak<Gadget>`.
//!         // Popeza zolemba za `Weak` sizingatsimikizire kuti magawowa alipobe, tifunika kuyimbira `upgrade`, yomwe imabweza `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // Poterepa tikudziwa kuti magawowa alipobe, chifukwa chake timangokhala `unwrap` `Option`.
//!         // Mu pulogalamu yovuta kwambiri, mungafunike kusamalira mwanzeru pazotsatira za `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Pamapeto pa ntchitoyi, `gadget_owner`, `gadget1`, ndi `gadget2` ziwonongedwa.
//!     // Tsopano palibe zida zolimba za (`Rc`) zamagetsi, chifukwa chake zimawonongeka.
//!     // Izi ndizowerengera zowerengera za Gadget Man, kotero amawonongedwanso.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Uwu ndi umboni wa repr(C) mpaka future motsutsana ndi kuthekera kosintha kwaminda, komwe kungasokoneze [into|from]_raw() yotetezedwa yamitundu yamkati yosunthika.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Cholozera chowerengera cha ulusi umodzi.'Rc' imayimira 'Reference
/// Counted'.
///
/// Onani [module-level documentation](./index.html) kuti mumve zambiri.
///
/// Njira zodziwika bwino za `Rc` zonse ndizogwirizana, zomwe zikutanthauza kuti muyenera kuwatcha monga, [`Rc::get_mut(&mut value)`][get_mut] m'malo mwa `value.get_mut()`.
/// Izi zimapewa kusamvana ndi njira zamkati `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Kusatetezeka kumeneku kuli bwino chifukwa Rc uyu ali moyo tikutsimikiziridwa kuti cholozera chamkati ndichovomerezeka.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Amapanga `Rc<T>` yatsopano.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Pali cholozera chofooka chomwe chili ndi zida zonse zamphamvu, zomwe zimatsimikizira kuti wowononga wopanda mphamvu samamasula magawowo pomwe wowononga wamphamvu akuthamanga, ngakhale cholozera chofooka chikasungidwa mkati mwamphamvu.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Amapanga `Rc<T>` yatsopano pogwiritsa ntchito dzina lofooka lokha.
    /// Kuyesera kukweza mawu ofooka ntchitoyi isanabwerere kudzabweretsa phindu la `None`.
    ///
    /// Komabe, mawu ofookawo amatha kupangidwa mwaulere ndikusungidwa kuti adzagwiritsidwe ntchito nthawi ina.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... minda yambiri
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Pangani zamkati mdziko la "uninitialized" ndikungokhala kofooka kamodzi.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Ndikofunika kuti tisataye umwini wa cholozera chofookacho, apo ayi chikumbukiro chimatha kumasulidwa nthawi yomwe `data_fn` ibwerera.
        // Ngati tikufunadi kukhala ndi umwini, titha kudzipangira tokha chofufuzira, koma izi zitha kubweretsa zosintha zina ku ziwerengero zochepa zomwe sizingakhale zofunikira kwina.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Maumboni olimba amayenera kukhala ndi gawo limodzi lofooka, chifukwa chake musayese kuwononga tsamba lathu lofooka lakale.
        //
        mem::forget(weak);
        strong
    }

    /// Amapanga `Rc` yatsopano yokhala ndi zomwe sizinayambitsidwe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Kukhazikitsidwa kokhazikika:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Amapanga `Rc` yatsopano yokhala ndi zomwe sizinalembedwe, kukumbukira kukudzazidwa ndi ma `0` byte.
    ///
    ///
    /// Onani [`MaybeUninit::zeroed`][zeroed] pa zitsanzo za kagwiritsidwe molondola ndi kolakwika ka njirayi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Amapanga `Rc<T>` yatsopano, ndikubwezeretsanso vuto ngati magawowo alephera
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Pali cholozera chofooka chomwe chili ndi zida zonse zamphamvu, zomwe zimatsimikizira kuti wowononga wopanda mphamvu samamasula magawowo pomwe wowononga wamphamvu akuthamanga, ngakhale cholozera chofooka chikasungidwa mkati mwamphamvu.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Amapanga `Rc` yatsopano yokhala ndi zomwe sizinatchulidweko, ndikubweza cholakwika ngati magawowo alephera
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Kukhazikitsidwa kokhazikika:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Amapanga `Rc` yatsopano yokhala ndi zomwe sizinatchulidwepo, kukumbukira kukudzazidwa ndi ma `0` byte, ndikubwezera cholakwika ngati magawowo alephera
    ///
    ///
    /// Onani [`MaybeUninit::zeroed`][zeroed] pa zitsanzo za kagwiritsidwe molondola ndi kolakwika ka njirayi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Amapanga `Pin<Rc<T>>` yatsopano.
    /// Ngati `T` silingagwiritse ntchito `Unpin`, ndiye kuti `value` idzakanikizidwa kukumbukira ndikulephera kusunthidwa.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Kubwezeretsa mtengo wamkati, ngati `Rc` ili ndi tanthauzo limodzi lamphamvu.
    ///
    /// Kupanda kutero, [`Err`] imabwezedwa ndi `Rc` yomwe idalowetsedwa.
    ///
    ///
    /// Izi zipambana ngakhale pali maumboni ochepa ofooka.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // lembani chinthucho

                // Sonyezani kwa Ofooka kuti sangalimbikitsidwe pochepetsa kuchuluka, kenako ndikuchotsani cholozera cha "strong weak" kwinaku mukugwiritsa ntchito mfundo zomveka pongopanga Zofooka zabodza.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Amapanga kagawo kakang'ono kokhala ndi zolembedwera ndi zomwe sizinayambitsidwe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Kukhazikitsidwa kokhazikika:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Amapanga kagawo kakang'ono kokhala ndi zolembedwera ndi zomwe sizinalembedwe, kukumbukira kukudzazidwa ndi ma `0` byte.
    ///
    ///
    /// Onani [`MaybeUninit::zeroed`][zeroed] pa zitsanzo za kagwiritsidwe molondola ndi kolakwika ka njirayi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Amatembenukira ku `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Monga ndi [`MaybeUninit::assume_init`], zili kwa woyimbirayo kuti atsimikizire kuti mtengo wamkati ulidi pachiyambi.
    ///
    /// Kuyimbira izi pomwe zomwe zili pano sizinayambitsidwe bwino kumayambitsa machitidwe osadziwika bwino.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Kukhazikitsidwa kokhazikika:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Amatembenukira ku `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Monga ndi [`MaybeUninit::assume_init`], zili kwa woyimbirayo kuti atsimikizire kuti mtengo wamkati ulidi pachiyambi.
    ///
    /// Kuyimbira izi pomwe zomwe zili pano sizinayambitsidwe bwino kumayambitsa machitidwe osadziwika bwino.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Kukhazikitsidwa kokhazikika:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Idya `Rc`, ndikubwezeretsanso cholembera chokutidwa.
    ///
    /// Pofuna kupewa kukumbukira kukumbukira pointer iyenera kusinthidwa kukhala `Rc` pogwiritsa ntchito [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Amapereka cholozera chosaphika ku data.
    ///
    /// Mawerengedwe samakhudzidwa mwanjira iliyonse ndipo `Rc` sichiwonongedwa.
    /// Cholozera ndi chovomerezeka malinga ngati pali ziwerengero zazikulu mu `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // CHITETEZO: Izi sizingadutse Deref::deref kapena Rc::inner chifukwa
        // izi zimafunika kuti tisunge ziwonetsero za raw/mut monga mwachitsanzo
        // `get_mut` mutha kulemba kudzera pa cholembera Rc ikapezedwa kudzera mu `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Amapanga `Rc<T>` kuchokera pa pointer yaiwisi.
    ///
    /// Pojambula yaiwisi iyenera kuti idabwezedwa kale poyimbira ku [`Rc<U>::into_raw`][into_raw] pomwe `U` iyenera kukhala ndi kukula komanso kufanana kofanana ndi `T`.
    /// Izi ndizowona ngati `U` ndi `T`.
    /// Dziwani kuti ngati `U` si `T` koma ili ndi kukula ndi mayendedwe ofanana, izi ndizofanana ndi kufalitsa maumboni amitundu yosiyanasiyana.
    /// Onani [`mem::transmute`][transmute] kuti mumve zambiri pazoletsa zomwe zikugwiritsidwa ntchito pankhaniyi.
    ///
    /// Wogwiritsa ntchito `from_raw` ayenera kuwonetsetsa kuti phindu la `T` limangoponyedwa kamodzi.
    ///
    /// Ntchitoyi ndi yosatetezeka chifukwa kugwiritsa ntchito molakwika kumatha kubweretsa kukumbukira kukumbukira, ngakhale `Rc<T>` yobwezerezedwayo singapezeke.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Sinthani kubwerera ku `Rc` kuti mupewe kutuluka.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Kuyitananso ku `Rc::from_raw(x_ptr)` kungakhale kosatetezeka pokumbukira.
    /// }
    ///
    /// // Kukumbukirako kunamasulidwa pomwe `x` idatuluka pamwambapa, ndiye `x_ptr` tsopano ikulendewera!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Sinthani zomwe mwapeza kuti mupeze RcBox yoyambirira.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Pangani cholozera chatsopano cha [`Weak`] pagawoli.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Onetsetsani kuti sitipanga Zofooka zolendewera
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Imapeza kuchuluka kwa zolozera za [`Weak`] pagawoli.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Ikupeza kuchuluka kwa zikhomo za (`Rc`) zolimba ku gawoli.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Imabwezeretsa `true` ngati palibe zolemba zina za `Rc` kapena [`Weak`] pagawoli.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Imabwezeretsa zosintha zomwe zingasinthidwe mu `Rc` yomwe yapatsidwa, ngati palibe zolemba zina za `Rc` kapena [`Weak`] pagawo lomwelo.
    ///
    ///
    /// Imabwezeretsa [`None`] mwanjira ina, chifukwa sikuli kotheka kusinthira mtengo wogawana.
    ///
    /// Onaninso [`make_mut`][make_mut], yomwe idzafanane ndi [`clone`][clone] mtengo wamkati pakakhala zolozera zina.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Imabwezeretsa zosinthika zomwe zingasinthidwe mu `Rc` yopatsidwa, popanda cheke chilichonse.
    ///
    /// Onaninso [`get_mut`], yomwe ndi yotetezeka komanso imachita macheke oyenera.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Zolemba zina zilizonse za `Rc` kapena [`Weak`] zomwe zimagawidwa chimodzimodzi siziyenera kufotokozedwanso panthawi yonse yobwereketsa.
    ///
    /// Izi ndizotheka ngati kulibe zolemba zoterezi, mwachitsanzo atangotha `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Tili osamala kuti * tisapangitse zolemba zapa "count", chifukwa izi zingatsutsane ndi mwayi wamawerengero owerengedwa (mwachitsanzo.
        // ndi `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Imabwezeretsa `true` ngati ma `Rc` awiriwo akulozera kugawa komweku (mumtsinje wofanana ndi [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Imatanthauzira zosinthika mu `Rc` yomwe yapatsidwa.
    ///
    /// Ngati pali ma `Rc` ena omwe amagawana gawo lomwelo, ndiye kuti `make_mut` idzapatsa [`clone`] mtengo wamkati wogawika watsopano kuti awonetsetse umwini wapadera.
    /// Izi zimatchedwanso clone-on-write.
    ///
    /// Ngati kulibe zolozera zina za `Rc` ku gawoli, ndiye kuti zotsatsira [`Weak`] za gawoli sizidzaphatikizidwa.
    ///
    /// Onaninso [`get_mut`], yomwe idzalephereke m'malo mophatikiza.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Simungapangitse chilichonse
    /// let mut other_data = Rc::clone(&data);    // Sangapangitse deta yamkati
    /// *Rc::make_mut(&mut data) += 1;        // Zimasintha deta zamkati
    /// *Rc::make_mut(&mut data) += 1;        // Simungapangitse chilichonse
    /// *Rc::make_mut(&mut other_data) *= 2;  // Simungapangitse chilichonse
    ///
    /// // Tsopano `data` ndi `other_data` zikuwonetsa magawidwe osiyanasiyana.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] zolembera zidzasiyanitsidwa:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Muyenera kudziwa tsatanetsatane, pali ma Rcs ena.
            // Peletsani chikumbukiro kuti mulole kulembetsa mtengo wokhazikika mwachindunji.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Titha kungoba deta, zomwe zatsala ndi Ofooka
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Chotsani chofooka champhamvu (osafunikira kupanga Zofooka zabodza pano-tikudziwa Zofooka zina zitha kutitsuka)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Kusatetezeka kumeneku kuli bwino chifukwa tili ndi chitsimikizo kuti cholozera chobwerezedwacho ndiye chokhacho * chomwe chiti chibwezeretsedwe ku T.
        // Chiwerengero chathu chatsimikiziridwa kukhala 1 pakadali pano, ndipo timafuna kuti `Rc<T>` yokha ikhale `mut`, chifukwa chake tikubwezera zokhazo zomwe zingatchulidwe pagawolo.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Kuyesera kutsitsa `Rc<dyn Any>` pamtundu wa konkriti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Imapatsa `RcBox<T>` yokhala ndi malo okwanira pamtengo wamkati mwake womwe mtengo wake wapatsidwa.
    ///
    /// Ntchitoyi `mem_to_rcbox` imayitanidwa ndi cholozera cha data ndipo iyenera kubwezera cholembera (chotheka mafuta) cha `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Sungani masanjidwe pogwiritsa ntchito mawonekedwe amtengo wapatali.
        // M'mbuyomu, masanjidwe anali kuwerengedwa pamawu a `&*(ptr as* const RcBox<T>)`, koma izi zidapanga chinyengo (onani #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Kugawa `RcBox<T>` yokhala ndi malo okwanira pamtengo wamkati mwanjira ina pomwe pamakhala cholozera, ndikubwezeretsanso vuto ngati magawidwe alephera.
    ///
    ///
    /// Ntchitoyi `mem_to_rcbox` imayitanidwa ndi cholozera cha data ndipo iyenera kubwezera cholembera (chotheka mafuta) cha `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Sungani masanjidwe pogwiritsa ntchito mawonekedwe amtengo wapatali.
        // M'mbuyomu, masanjidwe anali kuwerengedwa pamawu a `&*(ptr as* const RcBox<T>)`, koma izi zidapanga chinyengo (onani #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Gawani masanjidwewo.
        let ptr = allocate(layout)?;

        // Yambitsani RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Kugawa `RcBox<T>` yokhala ndi malo okwanira osakwanira kukula kwamkati
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Gawani `RcBox<T>` pogwiritsa ntchito mtengo womwe wapatsidwa.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Lembani mtengo monga ma byte
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Limbitsani magawidwewo osataya zomwe zili mkatimo
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Kugawa `RcBox<[T]>` ndi kutalika komwe kwapatsidwa.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Koperani zinthu kuchokera pagawo kupita ku Rc <\[T\]> yatsopano
    ///
    /// Zosatetezeka chifukwa woyimbayo ayenera kukhala ndi umwini wake kapena amange `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Amapanga `Rc<[T]>` kuchokera pa iterator yodziwika kuti ndi yayikulu.
    ///
    /// Khalidwe silimadziwika ngati kukula kwake kulakwitsa.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic amasamala popanga zinthu za T.
        // Pakakhala panic, zomwe zidalembedwa mu RcBox yatsopano zidzagwetsedwa, kenako kukumbukira kumamasulidwa.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Onetsani ku chinthu choyamba
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Zonse zomveka.Iwalani mlonda kuti asamasule RcBox yatsopano.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specialization trait yogwiritsidwa ntchito pa `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Akutsitsa `Rc`.
    ///
    /// Izi zithandizira kuwerengera kwamphamvu.
    /// Ngati kuwerengetsa kwamphamvu kudzafika zero ndiye maumboni ena okha (ngati alipo) ndi [`Weak`], ndiye kuti ife tili ndi mtengo wamkati.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Sakusindikiza chilichonse
    /// drop(foo2);   // Zosindikiza "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // kuwononga zomwe zilipo
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // chotsani cholozera cha "strong weak" tsopano popeza tawononga zomwe zili mkatimo.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Amapanga choyerekeza cha `Rc` cholozera.
    ///
    /// Izi zimapanga cholozera china pakugawana komweku, ndikuwonjezera kuwerengera kwamphamvu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Amapanga `Rc<T>` yatsopano, ndi mtengo wa `Default` wa `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Kuthyolako kuti alole okhazikika pa `Eq` ngakhale `Eq` ili ndi njira.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Tikuchita ukadaulo pano, osati monga kukhathamiritsa kwa `&T`, chifukwa zitha kuwonjezera mtengo pama cheke onse olingana pa ma Ref.
/// Timaganiza kuti `Rc`s amagwiritsidwa ntchito posungira zinthu zazikulu, zomwe sizichedwa kuchitika, komanso zolemetsa kuti tione ngati pali kufanana, zomwe zimapangitsa kuti ndalamazi ziperekedwe mosavuta.
///
/// Ndikothekanso kukhala ndi ma clone awiri a `Rc`, omwe amaloza pamtengo wofanana, kuposa ma `&T`s awiri.
///
/// Titha kuchita izi pokhapokha `T: Eq` ngati `PartialEq` itha kukhala yosasinthika mwadala.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Kufanana kwa ma `Rc`s awiri.
    ///
    /// Ma `Rc` awiri ndi ofanana ngati malingaliro awo amkati ali ofanana, ngakhale atasungidwa mosiyanasiyana.
    ///
    /// Ngati `T` imagwiritsanso ntchito `Eq` (kutanthauza kusinthasintha kwa kufanana), ma `R 'awiri omwe akunena za kugawa komweko amakhala ofanana nthawi zonse.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Kusagwirizana kwa `Rc`s awiri.
    ///
    /// Ma `Rc`s awiri ndiosalingana ngati malingaliro awo amkati sali ofanana.
    ///
    /// Ngati `T` imagwiritsanso ntchito `Eq` (kutanthauza kusinthasintha kwa kufanana), ma `R 'awiri omwe akunena za magawidwe omwewo sakhala ofanana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Kuyerekeza pang'ono kwa ma `Rc`s awiri.
    ///
    /// Awiriwa amafanizidwa ndikuyitanitsa `partial_cmp()` pamitengo yawo yamkati.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Ochepera poyerekeza kuyerekeza `Rc`s awiri.
    ///
    /// Awiriwa amafanizidwa ndikuyitanitsa `<` pamitengo yawo yamkati.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Zochepera kapena zofanana ndi 'kuyerekezera ma Rc`s awiri.
    ///
    /// Awiriwa amafanizidwa ndikuyitanitsa `<=` pamitengo yawo yamkati.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Kukulirapo poyerekeza ma `Rc`s awiri.
    ///
    /// Awiriwa amafanizidwa ndikuyitanitsa `>` pamitengo yawo yamkati.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'Wamkulu kuposa kapena wofanana' poyerekeza ma `Rc`s awiri.
    ///
    /// Awiriwa amafanizidwa ndikuyitanitsa `>=` pamitengo yawo yamkati.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Kuyerekeza ma `Rc`s awiri.
    ///
    /// Awiriwa amafanizidwa ndikuyitanitsa `cmp()` pamitengo yawo yamkati.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Gawani chidutswa chowerengera ndi kudzaza polemba zinthu za `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Gawani chidutswa chowerengera chingwe ndikujambula `v` mmenemo.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Gawani chidutswa chowerengera chingwe ndikujambula `v` mmenemo.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Sunthani chinthu chabokosi munjira yatsopano, yowerengedwa,
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Gawani chidutswa chowerengera ndikusunthira zinthu za `v 'mmenemo.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Lolani Vec kumasula kukumbukira kwake, koma osawononga zomwe zili mkatimo
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Imatenga chilichonse mu `Iterator` ndikuchisonkhanitsa kukhala `Rc<[T]>`.
    ///
    /// # Makhalidwe ogwirira ntchito
    ///
    /// ## Nkhani yonse
    ///
    /// Mwambiri, kusonkhanitsa mu `Rc<[T]>` kumachitika poyamba kusonkhanitsa mu `Vec<T>`.Ndiye kuti, polemba izi:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// izi zimakhala ngati tidalemba:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Gawo loyamba la magawidwe limachitika apa.
    ///     .into(); // Gawo lachiwiri la `Rc<[T]>` limachitika apa.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Izi zipereka kangapo pakumanga `Vec<T>` ndipo iperekanso kamodzi posinthira `Vec<T>` kukhala `Rc<[T]>`.
    ///
    ///
    /// ## Iterators a kutalika kodziwika
    ///
    /// `Iterator` yanu ikagwiritsa ntchito `TrustedLen` ndipo ili ndi kukula kwake, gawo limodzi lidzaperekedwa kwa `Rc<[T]>`.Mwachitsanzo:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Gawo limodzi lokha limachitika apa.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Specialization trait yogwiritsidwa ntchito kutolera mu `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Umu ndi momwe ziliri ndi `TrustedLen` iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // CHITETEZO: Tiyenera kuwonetsetsa kuti theerator ili ndi kutalika kwenikweni ndipo tili nawo.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Bwererani ku kukhazikitsidwa kwachilendo.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` ndi mtundu wa [`Rc`] womwe umakhala ndi chiphaso chosagwirizana ndi magawidwe omwe adayang'aniridwa.Gawolo limapezeka poyimbira [`upgrade`] pa pointer ya `Weak`, yomwe imabwezera [`Option`]`<<[`Rc`]`<T>> `.
///
/// Popeza kutanthauzira kwa `Weak` sikuwerengera za umwini, sikungalepheretse phindu lomwe lidasungidwa mgawoli kuti lisiyidwe, ndipo `Weak` yokha siyitsimikizira za phindu lomwe likadalipo.
/// Chifukwa chake imatha kubwerera [`None`] pomwe [`upgrade"] d.
/// Tawonani komabe kuti `Weak` yowunikira * imalepheretsa kugawa komweko (malo ogulitsira) kuti asagulitsidwe.
///
/// Cholozera `Weak` ndichothandiza posungitsa kagawidwe kamene kamayendetsedwa ndi [`Rc`] osateteza kuti mtengo wake wamkati usagwidwe.
/// Amagwiritsidwanso ntchito popewera zozungulira pakati pa zilozera za [`Rc`], popeza kukhala ndi maumboni ogwirizana sikungalole kuti [`Rc`] iponyedwe.
/// Mwachitsanzo, mtengo umatha kukhala ndi zokumbutsa zolimba za [`Rc`] kuchokera kuma mfundo a kholo kupita kwa ana, ndi zokumbutsa za `Weak` kuchokera kwa ana kubwerera kwa makolo awo.
///
/// Njira yodziwika yopezera pointer ya `Weak` ndikuyimbira [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Iyi ndi `NonNull` yololeza kukhathamiritsa kukula kwa mtundu uwu m'ma enum, koma sikuti ndi cholozera chovomerezeka.
    //
    // `Weak::new` set this to `usize::MAX` so that it does not need to allocate space on the mulu.
    // Ichi si mtengo wolozera weniweni womwe ungakhale nawo chifukwa RcBox imagwirizana ndi 2.
    // Izi ndizotheka pokhapokha `T: Sized`;`T` yopanda tanthauzo sichitha konse.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Amapanga `Weak<T>` yatsopano, osapatula kukumbukira kulikonse.
    /// Kuimbira [`upgrade`] pamtengo wobwezera nthawi zonse kumapereka [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Mtundu wothandizira kuloleza kufikira kuwerengetsa osanenapo chilichonse chokhudza zomwe zalembedwa.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Kubwezera cholozera chosaphika ku chinthu `T` cholozeredwa ndi `Weak<T>` iyi.
    ///
    /// Cholozera chimagwira pokhapokha ngati pali maumboni ena amphamvu.
    /// Cholozera chitha kukhala chikulendewera, osayanjana kapena ngakhale [`null`] mwanjira ina.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Zonsezi zikuloza ku chinthu chomwecho
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Olimba apa amawasunga amoyo, kotero titha kufikira chinthucho.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Koma osatinso.
    /// // Titha kuchita weak.as_ptr(), koma kulowa mu pointer kumatha kubweretsa machitidwe osadziwika.
    /// // assert_eq! ("moni", osatetezeka {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Cholozera chikangokhala, timabwezera sentinel molunjika.
            // Awa sangakhale adilesi yolipira yolondola, chifukwa zolipiritsa ndizofanana ndi RcBox (usize).
            ptr as *const T
        } else {
            // CHITETEZO: ngati_kulengika kumabwerera zabodza, ndiye kuti cholozera sichingafanane.
            // Malipiro atha kutayidwa pakadali pano, ndipo tiyenera kusungabe dongosolo, choncho gwiritsani ntchito chizolowezi chazosavuta.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Amagwiritsa ntchito `Weak<T>` ndikusandutsa pointer yaiwisi.
    ///
    /// Izi zimasinthira cholozera chofooka kukhala cholozera chosaphika, kwinaku tikusungabe umwini wa chinthu chimodzi chofooka (kuchuluka kofooka sikusinthidwa ndi ntchitoyi).
    /// Itha kubwereranso ku `Weak<T>` ndi [`from_raw`].
    ///
    /// Zoletsa zomwezo zofikira pa chandamale monga [`as_ptr`] zimagwiranso ntchito.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Imatembenuza pointer yaiwisi yomwe idapangidwa kale ndi [`into_raw`] kubwerera ku `Weak<T>`.
    ///
    /// Izi zitha kugwiritsidwa ntchito kupeza chidziwitso cholimba (poyimbira [`upgrade`] pambuyo pake) kapena kusamutsa kuchuluka kofooka posiya `Weak<T>`.
    ///
    /// Zimatengera umwini wolozera umodzi (kupatula zolemba zomwe zidapangidwa ndi [`new`], popeza izi sizikhala ndi chilichonse; njirayo imagwirabe ntchito pa iwo).
    ///
    /// # Safety
    ///
    /// Cholozera chiyenera kuti chinachokera ku [`into_raw`] ndipo chiyenera kukhalabe ndi mbiri yake yofooka.
    ///
    /// Amaloledwa kuti chiwerengerochi chikhale 0 pa nthawi yoitanira izi.
    /// Ngakhale zili choncho, izi zimatenga cholozera chimodzi chofooka chomwe chikuyimiridwa ngati cholozera chobiriwira (chiwerengero chofooka sichinasinthidwe ndi ntchitoyi) chifukwa chake chiyenera kuphatikizidwa ndi kuyimbira foni kwa [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Pewani chiwerengero chofooka chomaliza.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Onani Weak::as_ptr pamalingaliro amomwe cholozera cholowera chimachokera.

        let ptr = if is_dangling(ptr as *mut T) {
            // Uku ndikulephera Kofooka.
            ptr as *mut RcBox<T>
        } else {
            // Kupanda kutero, tatsimikizika kuti cholozera chimachokera ku Ofooka osasunthika.
            // CHITETEZO: data_offset ndiyotheka kuyimba, monga ptr imafotokozera za T.
            let offset = unsafe { data_offset(ptr) };
            // Chifukwa chake, timasintha zomwe tapeza kuti tipeze RcBox yonse.
            // CHITETEZO: chojambuliracho chimachokera ku Zofooka, chifukwa chake izi ndizotetezeka.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // CHITETEZO: tsopano tapeza cholozera chofooka choyambirira, chifukwa chake titha kupanga Ofooka.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Kuyesera kukweza pointer ya `Weak` kukhala [`Rc`], kuchedwetsa kutsitsa mtengo wamkati ngati zapambana.
    ///
    ///
    /// Kubwezeretsa [`None`] ngati mtengo wamkati wachotsedwa kale.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Onetsani zolemba zonse zamphamvu.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Ikupeza kuchuluka kwa zikhomo za (`Rc`) zomwe zikuloza gawo ili.
    ///
    /// Ngati `self` idapangidwa pogwiritsa ntchito [`Weak::new`], izi zibwerera 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Imapeza kuchuluka kwa zolozera za `Weak` zomwe zikulozera ku gawoli.
    ///
    /// Ngati palibe zotsatsira zolimba zomwe zatsala, izi zibwerera zero.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // chotsani chofooka ptr
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Imabwezeretsa `None` pomwe cholozera chagona ndipo palibe `RcBox`, (mwachitsanzo, pamene `Weak` iyi idapangidwa ndi `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Tili osamala kuti * tisapangitse zolembera za gawo la "data", chifukwa mundawo ungasinthidwe nthawi yomweyo (mwachitsanzo, ngati `Rc` yomaliza yagwetsedwa, gawo la deta liponyedwa m'malo).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Kubwezera `true` ngati awiri `Ofooka 'akulozera gawo lomwelo (lofanana ndi [`ptr::eq`]), kapena ngati onse saloza kugawa kulikonse (chifukwa adapangidwa ndi `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Popeza izi zikufanizira zolemba zimatanthauza kuti `Weak::new()` idzafanana wina ndi mnzake, ngakhale sakulongosola kugawa kulikonse.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Poyerekeza `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Akutsitsa cholozera cha `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Sakusindikiza chilichonse
    /// drop(foo);        // Zosindikiza "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // chiwerengero chofooka chimayamba pa 1, ndipo chimangopita ku zero ngati zolemba zonse zamphamvu zatha.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Zimapanga choyerekeza cha `Weak` cholozera chomwe chimalozera kugawa komweko.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Amapanga `Weak<T>` yatsopano, ndikugawa `T` osayiyambitsa.
    /// Kuimbira [`upgrade`] pamtengo wobwezera nthawi zonse kumapereka [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Tidayang'ana_akuwonjezera apa kuti athane ndi mem::forget bwinobwino.Makamaka
// ngati inu mem::forget Rcs (kapena Ofooka), kuwerengera kumatha kusefukira, kenako mutha kumasula magawowo pomwe ma Rcs (kapena Ofooka) alipo.
//
// Timachotsa mimba chifukwa izi ndizowonongeka zomwe sitimasamala nazo zomwe zimachitika-palibe pulogalamu yeniyeni yomwe iyenera kukumana ndi izi.
//
// Izi zikuyenera kukhala ndizonyalanyaza pamutu popeza simufunikiranso kuyika izi mu Rust chifukwa cha umwini ndi ma semantics osuntha.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Tikufuna kuchotsa kusefukira m'malo motaya mtengo.
        // Ziwerengero zowerengera sizidzakhala zero pamene izi zatchedwa;
        // komabe, timayika kuchotsa pano kuti tipeze LLVM pakukonzekera kwina kwina.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Tikufuna kuchotsa kusefukira m'malo motaya mtengo.
        // Ziwerengero zowerengera sizidzakhala zero pamene izi zatchedwa;
        // komabe, timayika kuchotsa pano kuti tipeze LLVM pakukonzekera kwina kwina.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Pezani zolowa mkati mwa `RcBox` pamalipiro kumbuyo kwa pointer.
///
/// # Safety
///
/// Cholozera chikuyenera kuloza (ndikukhala ndi metadata yoyenera) ya T, koma T imaloledwa kuponyedwa.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Gwirizanitsani mtengo wosasunthika kumapeto kwa RcBox.
    // Chifukwa RcBox ndi repr(C), idzakhala gawo lomaliza lokumbukira.
    // CHITETEZO: popeza mitundu yokhayo yosakwanira yotheka ndi magawo, zinthu trait,
    // ndi mitundu yakunja, zofunikira pakulowererapo pakadali pano ndizokwanira kukwaniritsa zofunikira za align_of_val_raw;uku ndikofunikira kukhazikitsa chilankhulo chomwe sichingadaliridwe kunja kwa std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}