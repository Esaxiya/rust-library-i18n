//! Mtundu wowoneka bwino wokulirapo wokhala ndi milu yomwe idapatsidwa, yolembedwa `Vec<T>`.
//!
//! Vectors ali ndi indexing `O(1)`, amortized `O(1)` push (mpaka kumapeto) ndi `O(1)` pop (kuchokera kumapeto).
//!
//!
//! Vectors amaonetsetsa kuti samagawa kuposa ma `isize::MAX` byte.
//!
//! # Examples
//!
//! Mutha kupanga [`Vec`] momveka bwino ndi [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... kapena pogwiritsa ntchito [`vec!`] macro:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // Zero khumi
//! ```
//!
//! Mutha kuwerengera [`push`] kumapeto kwa vector (yomwe ikulitse vector pakufunika):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Kupanga mfundo kumagwirira ntchito chimodzimodzi:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors imathandizanso kuwerengera (kudzera mu [`Index`] ndi [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Mtundu wowoneka bwino wokulirapo, wolemba `Vec<T>` ndikutchula 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Macro [`vec!`] imaperekedwa kuti kuyambitsa kukhale kosavuta:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Itha kuyambitsanso chilichonse cha `Vec<T>` ndi mtengo wopatsidwa.
/// Izi zitha kukhala zothandiza kuposa magawidwe ndi kuyambitsa magawo osiyanasiyana, makamaka poyambitsa vector ya zeros:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Zotsatirazi ndizofanana, koma pang'onopang'ono:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Kuti mumve zambiri, onani [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Gwiritsani ntchito `Vec<T>` ngati stack yokwanira:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Zolemba 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Mtundu wa `Vec` umalola kupeza zikhalidwe ndi index, chifukwa imagwiritsa ntchito [`Index`] trait.Chitsanzo chikhala chomveka bwino:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // iwonetsa '2'
/// ```
///
/// Komabe samalani: ngati mungayese kupeza index yomwe simuli mu `Vec`, pulogalamu yanu idzatero panic!Simungachite izi:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Gwiritsani ntchito [`get`] ndi [`get_mut`] ngati mukufuna kuwona ngati index ili mu `Vec`.
///
/// # Slicing
///
/// `Vec` itha kusintha.Mbali inayi, magawo ndi zinthu zowerenga zokha.
/// Kuti mupeze [slice][prim@slice], gwiritsani ntchito [`&`].Chitsanzo:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... ndipo ndizo zonse!
/// // mutha kuzichita motere:
/// let u: &[usize] = &v;
/// // kapena chonchi:
/// let u: &[_] = &v;
/// ```
///
/// Mu Rust, ndizofala kwambiri kupititsa magawo ngati zotsutsana m'malo mwa vectors mukangofuna kuti mupeze mwayi wowerenga.Zomwezo zimapita ku [`String`] ndi [`&str`].
///
/// # Mphamvu ndi kusinthanso
///
/// Mphamvu ya vector ndi kuchuluka kwa malo omwe future iliyonse ipatsidwe pa vector.Izi siziyenera kusokonezedwa ndi *kutalika* kwa vector, komwe kumatchula kuchuluka kwa zinthu zenizeni mkati mwa vector.
/// Ngati kutalika kwa vector kukuposa mphamvu yake, mphamvu yake imangowonjezedwa, koma zinthu zake ziyenera kukhazikitsidwanso.
///
/// Mwachitsanzo, vector yokhala ndi mphamvu 10 ndi kutalika 0 ikhoza kukhala yopanda vector yokhala ndi malo azinthu zina 10.Kukankhira zinthu 10 kapena zochepa pa vector sikungasinthe mphamvu yake kapena kuyambitsa kusinthanso.
/// Komabe, ngati kutalika kwa vector kudakulitsidwa mpaka 11, kuyenera kusamukanso, komwe kungachedwe.Pachifukwa ichi, tikulimbikitsidwa kuti mugwiritse ntchito [`Vec::with_capacity`] momwe zingathere kuti mufotokozere kukula kwa vector.
///
/// # Guarantees
///
/// Chifukwa chamakhalidwe ake osaneneka, `Vec` imapereka chitsimikizo chambiri pamapangidwe ake.Izi zimatsimikizira kuti ndizokwera kwambiri momwe zingathere, ndipo zitha kusinthidwa moyenera m'njira zachikale ndi nambala yosatetezeka.Dziwani kuti izi zimatsimikizira za `Vec<T>` yopanda tanthauzo.
/// Ngati mitundu yowonjezerapo yawonjezedwa (mwachitsanzo, kuthandizira omwe amapereka mwambo), kunyalanyaza zolakwikazo kungasinthe mchitidwewo.
///
/// Kwenikweni, `Vec` imakhala (pointer, mphamvu, kutalika) katatu.Osatinso, osachepera.Dongosolo la minda iyi silikudziwika, ndipo muyenera kugwiritsa ntchito njira zoyenera kusintha izi.
/// Cholozera sichidzakhalanso chopanda pake, chifukwa chake mtunduwu umakonzedwa bwino.
///
/// Komabe, cholozera sichingatanthauze kukumbukira komwe kwapatsidwa.
/// Makamaka, ngati mupanga `Vec` yokhala ndi mphamvu 0 kudzera pa [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], kapena poyimbira [`shrink_to_fit`] pa Vec yopanda kanthu, siyingakupatseni kukumbukira.Momwemonso, ngati mutasunga mitundu yayikulu-zero mkati mwa `Vec`, siyingapatse malo awo.
/// *Dziwani kuti pankhaniyi `Vec` mwina singanene [`capacity`] ya 0*.
/// `Vec` adzagawa pokhapokha ngati [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Mwambiri, zambiri za gawo la `Vec` ndizochenjera kwambiri-ngati mukufuna kugawa kukumbukira pogwiritsa ntchito `Vec` ndikuigwiritsa ntchito popanga china (mwina kuti mupereke nambala yosatetezeka, kapena kuti mupange zosunga zanu zomwe mukukumbukira), onetsetsani kusunthira kukumbukira uku pogwiritsa ntchito `from_raw_parts` kuti mubwezeretse `Vec` ndikuisiya.
///
/// Ngati `Vec` * yapatsa kukumbukira, kukumbukira komwe kukulozera kuli pamulu (monga wofotokozera Rust amakonzera kuti azigwiritsa ntchito mosasinthika), ndipo cholozera chake chimalozera ku [`len`] zoyambira, zophatikizika kuti zitheke (zomwe mungafune muwone ngati mudakakamiza kuti mudutse), kenako [`mphamvu`]`,`[`len`] mosavomerezeka, zinthu zophatikizika.
///
///
/// vector yokhala ndi zinthu `'a'` ndi `'b'` yokhala ndi mphamvu 4 imatha kuwonetsedwa monga pansipa.Gawo lapamwamba ndi `Vec` struct, lili ndi cholozera kumutu kwa magawidwewo pamulu, kutalika ndi mphamvu.
/// Gawo lakumunsi ndikugawana pamulu, zokumbukira zingapo.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** ikuyimira kukumbukira komwe sikunayambike, onani [`MaybeUninit`].
/// - Note: ABI sinakhazikike ndipo `Vec` siyitsimikiziranso za kukumbukira kwake (kuphatikiza dongosolo la minda).
///
/// `Vec` sichidzachita "small optimization" pomwe zinthu zimasungidwa pamtanda pazifukwa ziwiri:
///
/// * Zingapangitse kuti zikhale zovuta kwambiri kuti nambala yosatetezeka igwiritse bwino ntchito `Vec`.Zomwe zili mu `Vec` sizikhala ndi adilesi yokhazikika ngati zingasunthidwe, ndipo zingakhale zovuta kudziwa ngati `Vec` idaperekadi kukumbukira.
///
/// * Ikhoza kulanga mlanduwu, ndikupangitsa branch yowonjezerapo mwayi uliwonse.
///
/// `Vec` sichidzadzichepetsera zokha, ngakhale zitakhala zopanda kanthu.Izi zimatsimikizira kuti palibe magawidwe osafunikira kapena kusamvana komwe kumachitika.Kutulutsa `Vec` kenako ndikudzaza [`len`] yomweyo sikuyenera kuyitanitsa woperekayo.Ngati mukufuna kumasula kukumbukira komwe sikugwiritsidwe ntchito, gwiritsani ntchito [`shrink_to_fit`] kapena [`shrink_to`].
///
/// [`push`] ndipo [`insert`] sichidzaperekanso ngati mphamvu zomwe zanenedwa ndizokwanira.[`push`] ndi [`insert`]* *(re) adzagawa ngati [`len`]`=`` ``capacity`].Ndiye kuti, zomwe zafotokozedwazo ndizolondola kwathunthu, ndipo titha kuzidalira.Itha kugwiritsidwanso ntchito kumasula pamanja kukumbukira komwe kwaperekedwa ndi `Vec` ngati mukufuna.
/// Njira zolowetsera zochuluka * zitha kusamukirananso, ngakhale zikafunika.
///
/// `Vec` sichikutsimikizira njira yakukula ikamakhazikikanso kwathunthu, kapenanso [`reserve`] ikaitanidwa.Njira yomwe ilipo pakadali pano ndiyofunikira ndipo itha kukhala yosangalatsa kugwiritsa ntchito chinthu chomwe sichikukula nthawi zonse.Njira iliyonse yomwe ingagwiritsidwe ntchito ingatsimikizire kuti *O*(1) amortized [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]`, ndi [`Vec::with_capacity(n)`][`Vec::with_capacity`], zonse zitulutsa `Vec` ndendende mphamvu yofunsidwa.
/// Ngati [`len`]`==`[`capacity`], (monga momwe ziliri ndi [`vec!`] macro), ndiye kuti `Vec<T>` itha kusinthidwa kupita ku [`Box<[T]>`][owned slice] popanda kusunthanso kapena kusuntha mawonekedwe.
///
/// `Vec` sichidzachotsa pamtundu uliwonse zomwe zachotsedwa, komanso sizisunga mwachindunji.Kukumbukira kwake kosazindikirika ndi malo omwe angagwiritse ntchito momwe angafunire.Nthawi zambiri imangochita zilizonse zabwino kapena zosavuta kuzitsatira.Osadalira zomwe zachotsedwa kuti zichotsedwe kuti muteteze.
/// Ngakhale mutasiya `Vec`, buffer yake itha kugwiritsidwanso ntchito ndi `Vec` ina.
/// Ngakhale mutakhala kuti mukukumbukira `Vec` poyamba, sizingachitike chifukwa chowongolera sichiwona izi ngati zoyipa zomwe ziyenera kusungidwa.
/// Pali vuto limodzi lomwe sitidzaphwanya, komabe: kugwiritsa ntchito nambala ya `unsafe` kuti mulembe mopitilira muyeso, ndikuwonjezera kutalika kuti igwirizane, kumakhala kovomerezeka nthawi zonse.
///
/// Pakadali pano, `Vec` siyitsimikiziranso dongosolo lomwe zinthu zaponyedwa.
/// Dongosololi lasintha m'mbuyomu ndipo litha kusinthanso.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Njira zachilengedwe
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Amapanga `Vec<T>` yatsopano, yopanda kanthu.
    ///
    /// vector sidzagawa mpaka zinthu zitakankhidwira.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Amapanga `Vec<T>` yatsopano, yopanda kanthu ndi kuthekera kwake.
    ///
    /// vector izitha kugwira chimodzimodzi zinthu za `capacity` popanda kusinthanso.
    /// Ngati `capacity` ndi 0, vector sidzagawa.
    ///
    /// Ndikofunikira kudziwa kuti ngakhale vector yomwe idabwezedwa ili ndi *mphamvu* yotchulidwa, vector idzakhala ndi zero *kutalika*.
    ///
    /// Kuti mumve kusiyana pakati pa kutalika ndi mphamvu, onani *[Kutha ndi kusinthanso]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector ilibe zinthu, ngakhale ili ndi mphamvu zowonjezera
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Izi zonse zimachitika popanda kusinthanso malo ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... koma izi zitha kupangitsa vector kusunthidwanso
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Amapanga `Vec<T>` mwachindunji kuchokera kuzinthu zosaphika za vector ina.
    ///
    /// # Safety
    ///
    /// Izi ndizosatetezeka kwambiri, chifukwa cha kuchuluka kwa osasintha omwe sanayang'anidwe:
    ///
    /// * `ptr` Iyenera kuti idagawidwapo kale kudzera pa [`String`]/`Vec<T>`(osachepera, ndizotheka kuti sizingakhale zolondola zikadapanda kukhala).
    /// * `T` Iyenera kukhala ndi kukula komanso kufanana komwe `ptr` idapatsidwa.
    ///   (`T` yokhala ndi mayikidwe ocheperako siyokwanira, mayikidwewo amafunika kuti akhale ofanana kuti akwaniritse zofunikira za [`dealloc`] kuti kukumbukira kuyenera kugawidwa ndikugawidwa chimodzimodzi.)
    ///
    /// * `length` iyenera kukhala yochepera kapena yofanana ndi `capacity`.
    /// * `capacity` Iyenera kukhala luso lomwe pointer idapatsidwa nayo.
    ///
    /// Kuphwanya izi kumatha kubweretsa mavuto monga kuwononga zomwe zili mkati mwa woperekayo.Mwachitsanzo ndi **not** safe to make a `Vec<u8>` from a pointer to a C `char` array with `size_t`.
    /// Sizotetezeka kuti mumange imodzi kuchokera ku `Vec<u16>` ndi kutalika kwake, chifukwa woperekayo amasamala za mayikidwewo, ndipo mitundu iwiriyi ndiyofanana.
    /// Buffer idapatsidwa mayikidwe a 2 (a `u16`), koma itasandulika `Vec<u8>` ithandizidwa ndi mayendedwe 1.
    ///
    /// Umwini wa `ptr` umasamutsidwa bwino kupita ku `Vec<T>` yomwe imatha kusamutsa, kusinthanso kapena kusintha zomwe zili m'makumbukiro omwe cholozera cholozera chikuchita mwakufuna kwawo.
    /// Onetsetsani kuti palibenso china chomwe chimagwiritsa ntchito cholozera pambuyo poyitanitsa ntchitoyi.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Sinthani izi pamene vec_into_raw_parts ikhazikika.
    ///     // Pewani owononga `v` kuti tiwongolere magawowo.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Chotsani zidziwitso zingapo zofunika kudziwa za `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Lembetsani kukumbukira ndi 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Ikani zonse pamodzi mu Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Amapanga `Vec<T, A>` yatsopano, yopanda kanthu.
    ///
    /// vector sidzagawa mpaka zinthu zitakankhidwira.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Amapanga `Vec<T, A>` yatsopano yopanda kanthu yokhala ndi mphamvu zomwe zatchulidwa ndi owapatsa omwe apatsidwa.
    ///
    /// vector izitha kugwira chimodzimodzi zinthu za `capacity` popanda kusinthanso.
    /// Ngati `capacity` ndi 0, vector sidzagawa.
    ///
    /// Ndikofunikira kudziwa kuti ngakhale vector yomwe idabwezedwa ili ndi *mphamvu* yotchulidwa, vector idzakhala ndi zero *kutalika*.
    ///
    /// Kuti mumve kusiyana pakati pa kutalika ndi mphamvu, onani *[Kutha ndi kusinthanso]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector ilibe zinthu, ngakhale ili ndi mphamvu zowonjezera
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Izi zonse zimachitika popanda kusinthanso malo ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... koma izi zitha kupangitsa vector kusunthidwanso
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Amapanga `Vec<T, A>` mwachindunji kuchokera kuzinthu zosaphika za vector ina.
    ///
    /// # Safety
    ///
    /// Izi ndizosatetezeka kwambiri, chifukwa cha kuchuluka kwa osasintha omwe sanayang'anidwe:
    ///
    /// * `ptr` Iyenera kuti idagawidwapo kale kudzera pa [`String`]/`Vec<T>`(osachepera, ndizotheka kuti sizingakhale zolondola zikadapanda kukhala).
    /// * `T` Iyenera kukhala ndi kukula komanso kufanana komwe `ptr` idapatsidwa.
    ///   (`T` yokhala ndi mayikidwe ocheperako siyokwanira, mayikidwewo amafunika kuti akhale ofanana kuti akwaniritse zofunikira za [`dealloc`] kuti kukumbukira kuyenera kugawidwa ndikugawidwa chimodzimodzi.)
    ///
    /// * `length` iyenera kukhala yochepera kapena yofanana ndi `capacity`.
    /// * `capacity` Iyenera kukhala luso lomwe pointer idapatsidwa nayo.
    ///
    /// Kuphwanya izi kumatha kubweretsa mavuto monga kuwononga zomwe zili mkati mwa woperekayo.Mwachitsanzo ndi **not** safe to make a `Vec<u8>` from a pointer to a C `char` array with `size_t`.
    /// Sizotetezeka kuti mumange imodzi kuchokera ku `Vec<u16>` ndi kutalika kwake, chifukwa woperekayo amasamala za mayikidwewo, ndipo mitundu iwiriyi ndiyofanana.
    /// Buffer idapatsidwa mayikidwe a 2 (a `u16`), koma itasandulika `Vec<u8>` ithandizidwa ndi mayendedwe 1.
    ///
    /// Umwini wa `ptr` umasamutsidwa bwino kupita ku `Vec<T>` yomwe imatha kusamutsa, kusinthanso kapena kusintha zomwe zili m'makumbukiro omwe cholozera cholozera chikuchita mwakufuna kwawo.
    /// Onetsetsani kuti palibenso china chomwe chimagwiritsa ntchito cholozera pambuyo poyitanitsa ntchitoyi.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Sinthani izi pamene vec_into_raw_parts ikhazikika.
    ///     // Pewani owononga `v` kuti tiwongolere magawowo.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Chotsani zidziwitso zingapo zofunika kudziwa za `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Lembetsani kukumbukira ndi 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Ikani zonse pamodzi mu Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Imasokoneza `Vec<T>` m'zigawo zake zosaphika.
    ///
    /// Kubwezeretsa pointer yaiwisi kuzomwe zimayambira, kutalika kwa vector (muzinthu), ndi kuchuluka kwa zomwe zalembedwa (muzinthu).
    /// Izi ndi zifukwa zofananira chimodzimodzi monga zotsutsana ndi [`from_raw_parts`].
    ///
    /// Pambuyo poyitanitsa ntchitoyi, woyimbayo ndi amene amachititsa kuti kukumbukira kumayendetsedwa kale ndi `Vec`.
    /// Njira yokhayo yochitira izi ndikutembenuza cholembera, kutalika, ndi mphamvu kubwerera ku `Vec` ndi ntchito ya [`from_raw_parts`], kulola wowonongekayo kuti ayeretse.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Tsopano titha kusintha zinthu, monga kusinthira cholozera chosakanikirana ndi mtundu woyenerera.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Imasokoneza `Vec<T>` m'zigawo zake zosaphika.
    ///
    /// Kubwezeretsa pointer yaiwisi kuzomwe zimayambira, kutalika kwa vector (muzinthu), kuchuluka kwa deta (m'zinthu), ndi ogawa.
    /// Izi ndi zifukwa zofananira chimodzimodzi monga zotsutsana ndi [`from_raw_parts_in`].
    ///
    /// Pambuyo poyitanitsa ntchitoyi, woyimbayo ndi amene amachititsa kuti kukumbukira kumayendetsedwa kale ndi `Vec`.
    /// Njira yokhayo yochitira izi ndikutembenuza cholembera, kutalika, ndi mphamvu kubwerera ku `Vec` ndi ntchito ya [`from_raw_parts_in`], kulola wowonongekayo kuti ayeretse.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Tsopano titha kusintha zinthu, monga kusinthira cholozera chosakanikirana ndi mtundu woyenerera.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Imabwezeretsa kuchuluka kwa zinthu zomwe vector imatha kugwira osasinthanso.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Kusunga kuthekera kwa zinthu zosachepera `additional` kuti ziyikidwe mu `Vec<T>` yopatsidwa.
    /// Zosonkhanitsazo zitha kusunga malo ambiri kuti zisawonongeke pafupipafupi.
    /// Pambuyo poyimba `reserve`, kuthekera kumakhala kwakukulu kuposa kapena kofanana ndi `self.len() + additional`.
    /// Sichichita chilichonse ngati kuthekera ndikwanira kale.
    ///
    /// # Panics
    ///
    /// Panics ngati mphamvu yatsopano iposa ma `isize::MAX` byte.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Imasunga mphamvu yocheperako yazinthu zina `additional` zoti ziyikidwe mu `Vec<T>` yomwe yapatsidwa.
    ///
    /// Pambuyo poyimba `reserve_exact`, kuthekera kumakhala kwakukulu kuposa kapena kofanana ndi `self.len() + additional`.
    /// Sichichita chilichonse ngati kuthekera kuli kokwanira kale.
    ///
    /// Dziwani kuti woperekayo atha kupatsa malo osonkhanitsa malo ochulukirapo kuposa momwe amafunsira.
    /// Chifukwa chake, kuthekera sikungadaliridwe kukhala kocheperako kwenikweni.
    /// Sankhani `reserve` ngati future akuyembekezeredwa.
    ///
    /// # Panics
    ///
    /// Panics ngati mphamvu yatsopano ikusefukira `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Imayesetsa kusunga mphamvu zosachepera `additional` zowonjezera kuti ziyikidwe mu `Vec<T>` yomwe yapatsidwa.
    /// Zosonkhanitsazo zitha kusunga malo ambiri kuti zisawonongeke pafupipafupi.
    /// Pambuyo poyimba `try_reserve`, kuthekera kumakhala kwakukulu kuposa kapena kofanana ndi `self.len() + additional`.
    /// Sichichita chilichonse ngati kuthekera ndikwanira kale.
    ///
    /// # Errors
    ///
    /// Ngati mphamvu ikusefukira, kapena woperekayo akuti walephera, ndiye kuti cholakwika chimabwezedwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Sungitsani kukumbukira, kutuluka ngati sitingathe
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Tsopano tikudziwa kuti izi sizingatheke OOM pakati pa ntchito yathu yovuta
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // zovuta kwambiri
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Imayesetsa kusunga mphamvu zochepa pazinthu za `additional` zoti ziyikidwe mu `Vec<T>` yomwe yapatsidwa.
    /// Pambuyo poyimbira `try_reserve_exact`, kuchuluka kumakhala kwakukulu kuposa kapena kofanana ndi `self.len() + additional` ikabweza `Ok(())`.
    ///
    /// Sichichita chilichonse ngati kuthekera kuli kokwanira kale.
    ///
    /// Dziwani kuti woperekayo atha kupatsa malo osonkhanitsa malo ochulukirapo kuposa momwe amafunsira.
    /// Chifukwa chake, kuthekera sikungadaliridwe kukhala kocheperako kwenikweni.
    /// Sankhani `reserve` ngati future akuyembekezeredwa.
    ///
    /// # Errors
    ///
    /// Ngati mphamvu ikusefukira, kapena woperekayo akuti walephera, ndiye kuti cholakwika chimabwezedwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Sungitsani kukumbukira, kutuluka ngati sitingathe
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Tsopano tikudziwa kuti izi sizingatheke OOM pakati pa ntchito yathu yovuta
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // zovuta kwambiri
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Imachepetsa mphamvu ya vector momwe ingathere.
    ///
    /// Idzagwa pafupi kwambiri mpaka kutalika koma wopatsa akhoza kudziwitsa vector kuti pali malo azinthu zina zochepa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Kukula kwake sikungochepera kutalika, ndipo palibe choti tichite ngati ali ofanana, chifukwa chake titha kupewa vuto la panic ku `RawVec::shrink_to_fit` mwa kungoyitchula ndi kuthekera kwakukulu.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Imachepetsa mphamvu ya vector yokhala ndi malire ochepa.
    ///
    /// Mphamvuyo idzakhalabe yocheperako ngati kutalika kwake ndi mtengo womwe waperekedwa.
    ///
    ///
    /// Ngati mphamvu zomwe zilipo pakadali pano ndizochepera malire, ndiye kuti palibe-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Imatembenuza vector kukhala [`Box<[T]>`][owned slice].
    ///
    /// Dziwani kuti izi zitaya mphamvu iliyonse yochulukirapo.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Kuchulukitsa kulikonse kumachotsedwa:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Imafupikitsa vector, kusunga zoyambirira za `len` ndikuponya zina zonse.
    ///
    /// Ngati `len` ndi yayikulu kuposa kutalika kwa vector, izi sizikhala ndi zotsatirapo.
    ///
    /// Njira ya [`drain`] imatha kutsanzira `truncate`, koma imapangitsa kuti zinthu zowonjezera zibwezeretsedwe m'malo mwaziponya.
    ///
    ///
    /// Dziwani kuti njirayi ilibe mphamvu pazogawa za vector.
    ///
    /// # Examples
    ///
    /// Kudula zinthu zisanu vector kukhala zinthu ziwiri:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Palibe truncation yomwe imachitika `len` ikakhala yayikulu kuposa kutalika kwa vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Kudula pamene `len == 0` ikufanana ndi kuyitanitsa njira ya [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Izi ndizabwino chifukwa:
        //
        // * chidutswa chopitilira `drop_in_place` ndichovomerezeka;mulandu wa `len > self.len` umapewa kupanga kagawo kosayenera, ndipo
        // * `len` ya vector yagwedezeka musanayitane `drop_in_place`, kotero kuti phindu lililonse lidzagwetsedwa kawiri ngati `drop_in_place` itakhala panic kamodzi (ngati panics kawiri, pulogalamuyo imatha).
        //
        //
        //
        unsafe {
            // Note: Ndicholinga kuti iyi ndi `>` osati `>=`.
            //       Kusintha kukhala `>=` kumakhudzanso magwiridwe antchito nthawi zina.
            //       Onani #78884 kuti mumve zambiri.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Amachotsa kagawo kamene kali ndi vector yonse.
    ///
    /// Zofanana ndi `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Amachotsa chidutswa chosinthika cha vector yonse.
    ///
    /// Zofanana ndi `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Kubwezeretsa pointer yaiwisi ku buffer ya vector.
    ///
    /// Woyimbirayo akuyenera kuwonetsetsa kuti vector ipitilira poyerekeza ndi ntchitoyi, apo ayi ingaloze zinyalala.
    /// Kusintha vector kungapangitse kuti buffer yake ikhazikitsidwenso, zomwe zingapangitsenso kuti malangizowo akhale opanda pake.
    ///
    /// Woyimbirayo ayeneranso kuonetsetsa kuti kukumbukira zomwe pointer (non-transitively) imalemba sikulembedwera (kupatula mkati mwa `UnsafeCell`) pogwiritsa ntchito cholozera ichi kapena cholozera chilichonse chochokera pamenepo.
    /// Ngati mukufuna kusintha zomwe zili pagawolo, gwiritsani ntchito [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Timaphimba njira yamagawo omwewo kuti tipewe kudutsa `deref`, yomwe imapanga kutanthauzira kwapakatikati.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Kubwezeretsa cholumikizira chosatetezeka chosungira buffet ya vector.
    ///
    /// Woyimbirayo akuyenera kuwonetsetsa kuti vector ipitilira poyerekeza ndi ntchitoyi, apo ayi ingaloze zinyalala.
    ///
    /// Kusintha vector kungapangitse kuti buffer yake ikhazikitsidwenso, zomwe zingapangitsenso kuti malangizowo akhale opanda pake.
    ///
    /// # Examples
    ///
    /// ```
    /// // Gawani vector zazikulu zokwanira pazinthu 4.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Yambitsani zinthu kudzera pa pointer yaiwisi akulemba, kenako ikani kutalika.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Timaphimba njira yamagawo omwewo kuti tipewe kudutsa `deref_mut`, yomwe imapanga kutanthauzira kwapakatikati.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Kubwezeretsa kutanthauzira kwa wopatsa amene akuyambitsa.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Imakakamiza kutalika kwa vector mpaka `new_len`.
    ///
    /// Uwu ndi ntchito yotsika kwambiri yomwe imasunga chilichonse chazomwe zimakhalapo pamtunduwo.
    /// Kusintha kutalika kwa vector kumachitika pogwiritsa ntchito njira yotetezeka m'malo mwake, monga [`truncate`], [`resize`], [`extend`], kapena [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` iyenera kukhala yochepera kapena yofanana ndi [`capacity()`].
    /// - Zinthu za `old_len..new_len` ziyenera kuyambitsidwa.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Njirayi itha kukhala yothandiza m'malo omwe vector imagwirira ntchito ngati cholembera china, makamaka pa FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Awa ndi mafupa ochepa chabe a chitsanzo cha doc;
    /// # // osagwiritsa ntchito izi ngati poyambira laibulale yeniyeni.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Malinga ndi njira za FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // CHITETEZO: `deflateGetDictionary` ikabweza `Z_OK`, imanena kuti:
    ///     // 1. `dict_length` zinthu zidayambitsidwa.
    ///     // 2.
    ///     // `dict_length` <=mphamvu (32_768) yomwe imapangitsa `set_len` kukhala yotetezeka kuyimba.
    ///     unsafe {
    ///         // FFI imbani ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... ndikusinthira kutalika kuzomwe zidayambitsidwa.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Ngakhale chitsanzo chotsatirachi ndichabwino, pamakhala kukumbukira kutulutsa popeza amkati vectors sanamasulidwe foni ya `set_len` isanachitike:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` ilibe kanthu kotero palibe zinthu zomwe ziyenera kuyambitsidwa.
    /// // 2. `0 <= capacity` nthawi zonse amakhala ndi chilichonse chomwe `capacity` ili.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Nthawi zambiri, apa, munthu amatha kugwiritsa ntchito [`clear`] m'malo mwake kuti agwetse zomwe zili mkatimo osakumbukira.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Imachotsa chinthu kuchokera ku vector ndikubwezeretsanso.
    ///
    /// Chachotsedwa chimachotsedwa m'malo ndi chomaliza cha vector.
    ///
    /// Izi sizikusunga kuyitanitsa, koma ndi O(1).
    ///
    /// # Panics
    ///
    /// Panics ngati `index` ilibe malire.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Timalowetsa tokha [index] ndi chinthu chomaliza.
            // Dziwani kuti ngati malire omwe ali pamwambapa apambana payenera kukhala chinthu chomaliza (chomwe chingakhale chokha [index] chokha).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Kuyika chinthu pamalo `index` mkati mwa vector, kusunthira zinthu zonse pambuyo pake kumanja.
    ///
    ///
    /// # Panics
    ///
    /// Panics ngati `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // danga lazinthu zatsopano
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // osalephera Malowa oti ayike phindu latsopano
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Sinthani zonse kuti mupange danga.
                // (Kubwereza chinthu cha `index`th m'malo awiri motsatizana.)
                ptr::copy(p, p.offset(1), len - index);
                // Lilembeni, ndikulemba kopi yoyamba ya `index`th element.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Imachotsa ndikubwezeretsanso pamalo `index` mkati mwa vector, ndikusunthira zinthu zonse pambuyo pake kumanzere.
    ///
    ///
    /// # Panics
    ///
    /// Panics ngati `index` ilibe malire.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // malo omwe tikuchokerako.
                let ptr = self.as_mut_ptr().add(index);
                // lembani izi, mosatetezeka mutakhala ndi mtengo pamtengo komanso mu vector nthawi yomweyo.
                //
                ret = ptr::read(ptr);

                // Sinthani chilichonse kuti mudzaze malowa.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Imasunga zinthu zokhazokha zotchulidwa ndi wotsogolera.
    ///
    /// Mwanjira ina, chotsani zonse `e` kotero kuti `f(&e)` ibweretse `false`.
    /// Njirayi imagwira ntchito m'malo mwake, kuyendera chinthu chilichonse chimodzimodzi kamodzi koyambirira, ndikusunga dongosolo lazomwe zidasungidwa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Chifukwa chakuti zinthu zimayendera chimodzimodzi kamodzi koyambirira, dziko lakunja lingagwiritsidwe ntchito kusankha zomwe angasunge.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Pewani kuponya kawiri ngati woponya sanaphedwe, popeza titha kupanga zibowo panthawiyi.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-kukonzedwa len-> |^-pafupi kuti muwone
        //                  | <-zachotsedwa cnt-> |
        //      | <-choyambirira_len-> |Kusungidwa: Zinthu zomwe zonenerazi zimabwereranso.
        //
        // Khola: Kuthamangitsidwa kapena kutsitsidwa.
        // Zosasinthidwa: Zosasinthidwa zomwe zili zovomerezeka.
        //
        // Otetezera awa adzaitanidwa pamene adaneneratu kapena `drop` wazinthu atachita mantha.
        // Imasunthira zinthu zomwe sizinawonedwe kuti ziphimbe mabowo ndi `set_len` mpaka kutalika kolondola.
        // Zikakhala kuti predicate ndi `drop` sachita mantha, zidzakonzedweratu.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // CHITETEZO: Kutsata zinthu zosasunthidwa kuyenera kukhala kovomerezeka popeza sitikukhudza konse.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // CHITETEZO: Mukadzaza mabowo, zinthu zonse zimakhala zokumbukira.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // CHITETEZO: Zinthu zosasankhidwa ziyenera kukhala zenizeni.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Pitani pasadakhale kuti mupewe kugwa kawiri ngati `drop_in_place` idachita mantha.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // CHITETEZO: Sitigwiranso kanthu akagwa.
                unsafe { ptr::drop_in_place(cur) };
                // Ife tapititsa patsogolo kauntala.
                continue;
            }
            if g.deleted_cnt > 0 {
                // CHITETEZO: `deleted_cnt`> 0, chifukwa chake bowo loyenera siliyenera kudutsana ndi zomwe zilipo pano.
                // Timagwiritsa ntchito kope poyenda, ndipo osakhudzanso izi.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Zinthu zonse zimasinthidwa.Izi zitha kupangidwira `set_len` ndi LLVM.
        drop(g);
    }

    /// Imachotsa zonse kupatula zoyambira zotsatizana mu vector zomwe zimatsimikiza ku kiyi yemweyo.
    ///
    ///
    /// Ngati vector yasankhidwa, izi zimachotsa zobwereza zonse.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Imachotsa zonse koma zoyambirira motsatizana mu vector kukhutiritsa chiyanjano chomwe chapatsidwa.
    ///
    /// Ntchito ya `same_bucket` idasinthidwa kutengera zinthu ziwiri kuchokera ku vector ndipo imayenera kudziwa ngati zinthuzo zikufanana.
    /// Zomwe zimapangidwazo zimadutsa motsutsana ndi dongosolo lawo pagawo, chifukwa chake `same_bucket(a, b)` ikabwezera `true`, `a` imachotsedwa.
    ///
    ///
    /// Ngati vector yasankhidwa, izi zimachotsa zobwereza zonse.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Amagwiritsa ntchito chinthu kumbuyo kusonkhanitsa.
    ///
    /// # Panics
    ///
    /// Panics ngati mphamvu yatsopano iposa ma `isize::MAX` byte.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Izi panic kapena kuchotsa mimba ngati titha kugawa> isize::MAX byte kapena ngati kutalika kutalikirana kwa mitundu yayikulu-zero.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Imachotsa chomaliza kuchokera ku vector ndikuibweza, kapena [`None`] ngati ilibe kanthu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Imasuntha zinthu zonse za `other` kupita ku `Self`, ndikusiya `other` yopanda kanthu.
    ///
    /// # Panics
    ///
    /// Panics ngati kuchuluka kwa zinthu mu vector kusefukira `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Amagwiritsa ntchito zinthu ku `Self` kuchokera ku gawo lina.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Pangani chojambulira chotulutsa chomwe chimachotsa mtundu wa vector ndikupereka zinthu zochotsedwa.
    ///
    /// Iterator **ikakhala** itatsika, zinthu zonse pamtunduwu zimachotsedwa mu vector, ngakhale iterator sinatheretu.
    /// Ngati iterator **si** yaponyedwa (ndi [`mem::forget`] mwachitsanzo), sizikudziwika kuti ndi zinthu zingati zomwe zachotsedwa.
    ///
    /// # Panics
    ///
    /// Panics ngati poyambira ndi wamkulu kuposa malekezero kapena ngati malekezero ndi akulu kuposa kutalika kwa vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Mtundu wathunthu umachotsa vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Chitetezo chokumbukira
        //
        // Drain ikayamba kupangidwa, imachepetsa kutalika kwa gwero vector kuti iwonetsetse kuti palibe zinthu zomwe sizinayambitsidwe kapena zosunthidwa zomwe zingafikiridwe konse ngati wowononga Drain sadzathamanga konse.
        //
        //
        // Drain idzatulutsa ptr::read zomwe achotse.
        // Mukamaliza, mchira wotsalira wa vec umakopedwa kumbuyo kuti uphimbe dzenje, ndipo kutalika kwa vector kumabwezeretsedwanso kutalika kwatsopano.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // khazikitsani kutalika kwa self.vec, kuti mukhale otetezeka ngati Drain idatuluka
            self.set_len(start);
            // Gwiritsani ntchito yobwereketsa mu IterMut kuti muwonetse kubwereka kwa Drain iterator yonse (monga &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Iyeretsani vector, ndikuchotsa malingaliro onse.
    ///
    /// Dziwani kuti njirayi ilibe mphamvu pazogawa za vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Imabwezeretsa kuchuluka kwa zinthu mu vector, yotchedwanso 'length' yake.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Bweretsani `true` ngati vector ilibe zinthu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Amagawaniza zosonkhanitsa kukhala ziwiri pa index yomwe yapatsidwa.
    ///
    /// Kubwezeretsa vector yomwe yangopatsidwa kumene yomwe ili ndi zinthu mu `[at, len)`.
    /// Pambuyo poyimbira, vector yapachiyambi idzasiyidwa yokhala ndi zinthu `[0, at)` ndimphamvu yake yam'mbuyomu isasinthe.
    ///
    ///
    /// # Panics
    ///
    /// Panics ngati `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // vector yatsopano imatha kutenga gawo loyambirira ndikupewa kutengera
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Zosavomerezeka `set_len` ndikusindikiza zinthu ku `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Kukulitsa kukula kwa `Vec` m'malo mwake kuti `len` ikhale yofanana ndi `new_len`.
    ///
    /// Ngati `new_len` ndi yayikulu kuposa `len`, `Vec` imakwezedwa ndi kusiyana, ndikulowetsamo kwina kulikonse kodzaza ndi zotsatira zakuyitanitsa kutseka `f`.
    ///
    /// Mitengo yobwerera kuchokera ku `f` idzathera mu `Vec` momwe adapangidwira.
    ///
    /// Ngati X01 ndi yochepera `len`, `Vec` imangodulidwa.
    ///
    /// Njirayi imagwiritsa ntchito kutseka kuti apange malingaliro atsopano pakukankha kulikonse.Ngati mungafune [`Clone`] mtengo wopatsidwa, gwiritsani ntchito [`Vec::resize`].
    /// Ngati mukufuna kugwiritsa ntchito [`Default`] trait kuti mupange zofunikira, mutha kupititsa [`Default::default`] ngati mkangano wachiwiri.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Amagwiritsa ntchito ndikutulutsa `Vec`, ndikubwezera zomwe zingasinthidwe, `&'a mut [T]`.
    /// Dziwani kuti mtundu wa `T` uyenera kupitilira nthawi yosankhidwa ya `'a`.
    /// Ngati mtunduwo umangokhala ndi zongonena zokha, kapena palibe, ndiye kuti mutha kusankha `'static`.
    ///
    /// Ntchitoyi ikufanana ndi ntchito ya [`leak`][Box::leak] pa [`Box`] kupatula kuti palibe njira yobwezera kukumbukira komwe kudatuluka.
    ///
    ///
    /// Ntchitoyi ndi yofunika kwambiri pa deta yomwe imakhala moyo wonse wa pulogalamuyi.
    /// Kutaya zomwe zalembedwazo kudzapangitsa kukumbukira kukumbukira.
    ///
    /// # Examples
    ///
    /// Ntchito yosavuta:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Kubwezeretsa zotsalira zotsalira za vector ngati chidutswa cha `MaybeUninit<T>`.
    ///
    /// Kagawo kobwezedwa kangagwiritsidwe ntchito kudzaza vector ndi data (mwachitsanzo
    /// powerenga kuchokera fayilo) musanatchule tsambalo monga loyambitsira pogwiritsa ntchito njira ya [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Gawani vector zazikulu zokwanira pazinthu 10.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Lembani zinthu zitatu zoyambirira.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Chongani zinthu zitatu zoyambirira za vector kukhala zoyambitsidwa.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Njirayi siyikukhazikitsidwa malinga ndi `split_at_spare_mut`, kuti iteteze kuyika kwa zilozera ku buffer.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Imabwezeretsa vector ngati chidutswa cha `T`, pamodzi ndi zotsalira zotsalira za vector ngati chidutswa cha `MaybeUninit<T>`.
    ///
    /// Chidutswa chobwezera chobwezeretsanso chitha kugwiritsidwa ntchito kudzaza vector ndi zidziwitso (mwachitsanzo powerenga kuchokera pafayilo) musanayimire deta yomwe idayambitsidwa pogwiritsa ntchito njira ya [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Dziwani kuti iyi ndi API yotsika, yomwe iyenera kugwiritsidwa ntchito mosamala pazokhathamiritsa.
    /// Ngati mukufuna kuwonjezera deta ku `Vec` mutha kugwiritsa ntchito [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] kapena [`resize_with`], kutengera zosowa zanu zenizeni.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Sungani malo owonjezera okwanira pazinthu 10.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Lembani zinthu 4 zotsatira.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Chongani zinthu 4 za vector kukhala zoyambitsidwa.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len amanyalanyazidwa ndipo sasintha
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Chitetezo: kusintha kubwerera .2 (&mut usize) kumawerengedwa chimodzimodzi kuyimba `.set_len(_)`.
    ///
    /// Njirayi imagwiritsidwa ntchito kukhala ndi mwayi wopezeka kuzinthu zonse zamatumba nthawi imodzi ku `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` ndikutsimikizika kukhala kovomerezeka pazinthu za `len`
        // - `spare_ptr` ikuloza chinthu chimodzi chadutsa pa buffer, chifukwa chake sichikhala ndi `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Kukulitsa kukula kwa `Vec` m'malo mwake kuti `len` ikhale yofanana ndi `new_len`.
    ///
    /// Ngati `new_len` ndi yayikulu kuposa `len`, `Vec` imakwezedwa ndi kusiyana, ndikulowetsamo kwina kulikonse kodzaza ndi `value`.
    ///
    /// Ngati X01 ndi yochepera `len`, `Vec` imangodulidwa.
    ///
    /// Njirayi imafuna kuti `T` ikhazikitse [`Clone`], kuti ikwaniritse phindu lomwe laperekedwa.
    /// Ngati mukufuna kusinthasintha (kapena mukufuna kudalira [`Default`] m'malo mwa [`Clone`]), gwiritsani ntchito [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Amagwiritsa ntchito ndikuyika zinthu zonse pang'onopang'ono ndi `Vec`.
    ///
    /// Iterates pa kagawo ka `other`, amamangirira chinthu chilichonse, kenako nachiphatika ku `Vec` iyi.
    /// `other` vector imadutsa mu dongosolo.
    ///
    /// Dziwani kuti ntchitoyi ndiyofanana ndi [`extend`] kupatula kuti ndiyodziwika bwino kuti igwire ntchito ndi magawo m'malo mwake.
    ///
    /// Ngati Rust ipanga ukatswiri, ntchitoyi itha kuchepetsedwa (koma ipezekabe).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Zimakopera zinthu kuchokera ku `src` kuchokera kumapeto kwa vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` imatsimikizira kuti mtundu womwe wapatsidwa ndiwovomerezeka pakuwunika nokha
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Khodi iyi imapanga `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Lonjezani vector ndi `n`, pogwiritsa ntchito jenereta yomwe yapatsidwa.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Gwiritsani ntchito SetLenOnDrop kuti mugwire ntchito mozungulira cholumikizira pomwe wopanga sangathe kuzindikira sitolo kudzera pa `ptr` kudzera pa self.set_len() osadziwika.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Lembani zinthu zonse kupatula chomaliza
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Onjezani kutalika mu sitepe iliyonse ngati next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Titha kulemba chinthu chomaliza popanda kupanga zinthu mosafunikira
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len yokhazikitsidwa ndi guard guard
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Imachotsa zinthu mobwerezabwereza mu vector malinga ndi kukhazikitsa kwa [`PartialEq`] trait.
    ///
    ///
    /// Ngati vector yasankhidwa, izi zimachotsa zobwereza zonse.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Njira zamkati ndi ntchito
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` iyenera kukhala index yoyenera
    /// - `self.capacity() - self.len()` iyenera kukhala `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len imawonjezeka pokhapokha kuyambitsa zinthu
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - oyimbira oyimba kuti src ndi index yolondola
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Element idangoyambitsidwa ndi `MaybeUninit::write`, chifukwa chake zili bwino kuti muwonjezere len
            // - len imakulitsidwa pambuyo pachinthu chilichonse kuti zisawonongeke (onani nkhani #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - oyimbira oyimba kuti `src` ndi index yolondola
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Malangizo onsewa amapangidwa kuchokera kuzowonjezera zapadera (`&&mut [_]`) chifukwa chake ndizovomerezeka ndipo sizidutsana.
            //
            // - Zida ndi izi: Koperani kotero ndibwino kuti muzitsanzira, osachita chilichonse ndi zoyambirira
            // - `count` ikufanana ndi len wa `source`, chifukwa chake chitsimikizo ndichachidziwikire kwa `count`
            // - `.reserve(count)` imatsimikizira kuti `spare.len() >= count` yopuma ndiyotheka `count` imalemba
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Zinthuzo zidangoyambitsidwa ndi `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Kukhazikitsa kwa trait wamba kwa Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): ndi cfg(test) njira yodziwika ya `[T]::to_vec`, yomwe imafunikira pakutanthauzira njirayi, sikupezeka.
    // M'malo mwake gwiritsani ntchito ntchito ya `slice::to_vec` yomwe imangopezeka ndi cfg(test) NB onani slice::hack module mu slice.rs kuti mumve zambiri
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // kusiya chilichonse chomwe sichidzalembedwe
        self.truncate(other.len());

        // self.len <= other.len chifukwa cha truncate pamwambapa, chifukwa chake magawo pano nthawi zonse amakhala m'malire.
        //
        let (init, tail) = other.split_at(self.len());

        // gwiritsaninso ntchito zomwe zilipo allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Imapanga cholembera chowononga, ndiye kuti, chomwe chimachotsa phindu lililonse kuchokera ku vector (kuyambira koyambirira mpaka kumapeto).
    /// vector singagwiritsidwe ntchito mutayimba izi.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // Ali ndi chingwe, osati &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // leaf njira yomwe machitidwe angapo a SpecFrom/SpecExtend amaperekera ngati alibe zowonjezeranso
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Izi ndi zomwe zimachitika kwa owerenga ambiri.
        //
        // Ntchitoyi iyenera kukhala yofanana ndi:
        //
        //      pachinthu mu iterator {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB sichitha kusefukira popeza tikadayenera kugawa malo adilesi
                self.set_len(len + 1);
            }
        }
    }

    /// Pangani cholembera chomwe chimalowetsa m'malo osiyanasiyana mu vector ndi `replace_with` iterator ndikupereka zinthu zochotsedwa.
    ///
    /// `replace_with` sayenera kukhala wofanana `range`.
    ///
    /// `range` amachotsedwa ngakhale iterator sichiwonongedwa mpaka kumapeto.
    ///
    /// Sizikudziwika kuti ndi zinthu zingati zomwe zachotsedwa mu vector ngati mtengo wa `Splice` watulutsidwa.
    ///
    /// Chowonjezera iterator `replace_with` chimangodyedwa pokhapokha mtengo wa `Splice` utatsitsidwa.
    ///
    /// Izi ndizotheka ngati:
    ///
    /// * Mchira (zinthu mu vector pambuyo pa `range`) mulibe kanthu,
    /// * kapena `replace_with` imatulutsa zochepa kapena zofanana kuposa kutalika kwa `osiyanasiyana`
    /// * kapena kumunsi kwake kwa `size_hint()` ndikulondola.
    ///
    /// Kupanda kutero, vector yakanthawi imagawidwa ndipo mchira umasunthidwa kawiri.
    ///
    /// # Panics
    ///
    /// Panics ngati poyambira ndi wamkulu kuposa malekezero kapena ngati malekezero ndi akulu kuposa kutalika kwa vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Amapanga cholembera chomwe chimagwiritsa ntchito kutseka kuti mudziwe ngati chinthucho chiyenera kuchotsedwa.
    ///
    /// Ngati kutsekako kubwereradi, ndiye kuti chinthucho chimachotsedwa ndikuperekedwa.
    /// Ngati kutsekako kumabwerera kwachinyengo, chinthucho chidzakhalabe mu vector ndipo sichidzaperekedwa ndi owongolera.
    ///
    /// Kugwiritsa ntchito njirayi ndikofanana ndi nambala iyi:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // nambala yanu apa
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Koma `drain_filter` ndiyosavuta kugwiritsa ntchito.
    /// `drain_filter` imagwiranso ntchito kwambiri, chifukwa imatha kubweza zinthu zomwe zidakwaniritsidwa zambiri.
    ///
    /// Dziwani kuti `drain_filter` imakulolani kuti musinthe chilichonse chomwe chimatsekedwa mufyuluta, mosasamala kanthu kuti mungasunge kapena kuchotsa.
    ///
    ///
    /// # Examples
    ///
    /// Kugawa magawo mofanana ngakhale pang'ono, kugwiritsanso ntchito gawo loyambirira:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Samalani kuti ife tisatulukemo (leak amplification)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Onjezani kukhazikitsa komwe kumakopera zinthu zomwe sizinafotokozeredwe musanazikankhire ku Vec.
///
/// Kukhazikitsa kumeneku ndi kwapadera kwa ma iterators, pomwe imagwiritsa ntchito [`copy_from_slice`] kuyika chidutswa chonse nthawi imodzi.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Kugwiritsa ntchito kuyerekezera kwa vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Imagwiritsa ntchito kuyitanitsa kwa vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // gwiritsani ntchito dontho la [T] gwiritsani ntchito kagawo kakang'ono kuti muwonetse zinthu za vector ngati mtundu wofooka wofunikira;
            //
            // angapewe mafunso ovomerezeka nthawi zina
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec imagwiritsa ntchito kusamutsidwa
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Amapanga `Vec<T>` yopanda kanthu.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: test imakoka mu libstd, zomwe zimayambitsa zolakwika apa
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: test imakoka mu libstd, zomwe zimayambitsa zolakwika apa
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Imapeza zonse zomwe zili mu `Vec<T>` ngati gulu, ngati kukula kwake kukufanana ndendende ndi zomwe mwapempha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Ngati kutalika sikugwirizana, zolowetsazo zimabwereranso ku `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Ngati muli bwino mukangopeza chiyambi cha `Vec<T>`, mutha kuyimbira [`.truncate(N)`](Vec::truncate) poyamba.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // CHITETEZO: `.set_len(0)` imakhala yomveka nthawi zonse.
        unsafe { vec.set_len(0) };

        // CHITETEZO: Cholozera cha `Vec` nthawi zonse chimagwirizana moyenera, ndipo
        // mayendedwe omwe gulu likufunikira ali chimodzimodzi ndi zinthuzo.
        // Tinayang'ana koyambirira kuti tili ndi zinthu zokwanira.
        // Zinthuzo sizigwera kawiri pomwe `set_len` imauza `Vec` kuti isaziponyenso.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}