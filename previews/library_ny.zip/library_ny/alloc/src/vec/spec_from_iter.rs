use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Specialization trait yogwiritsidwa ntchito pa Vec::from_iter
///
/// ## Gulu la nthumwi:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Nkhani yodziwika ikudutsa vector kuti igwire ntchito yomwe imangosonkhanitsanso mu vector.
        // Titha kufupikitsa izi ngati IntoIter sinapite patsogolo konse.
        // Ikapita patsogolo Titha kugwiritsanso ntchito kukumbukira ndikusunthira deta kutsogolo.
        // Koma timangochita izi pokhapokha Vec yomwe ikubwera ikadakhala ndi mwayi wogwiritsa ntchito kuposa kuyipanga kudzera mukugwiritsa ntchito generic FromIterator.
        //
        // Zochepazo sizofunikira kwenikweni chifukwa momwe magawidwe a Vec sadziwika mwadala.
        // Koma ndichisankho chosamala.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // Iyenera kuperekanso ku spec_extend() popeza extend() yomwe imatumiza nthumwi zapadera kwa ma Vec opanda kanthu
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Izi zimagwiritsa ntchito `iterator.as_slice().to_vec()` popeza spec_extend iyenera kuchitapo kanthu kuti muganizire za kutalika komaliza + ndikupanga ntchito yambiri.
// `to_vec()` amatipatsa mwachindunji ndalama zolondola ndikudzaza ndendende.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): ndi cfg(test) njira yodziwika ya `[T]::to_vec`, yomwe imafunikira pakutanthauzira njirayi, sikupezeka.
    // M'malo mwake gwiritsani ntchito ntchito ya `slice::to_vec` yomwe imangopezeka ndi cfg(test) NB onani slice::hack module mu slice.rs kuti mumve zambiri
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}