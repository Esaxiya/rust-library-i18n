// Ikani kutalika kwa vec pamene mtengo wa `SetLenOnDrop` utachoka.
//
// Lingaliro ndilakuti: Kutalika kwa gawo mu SetLenOnDrop ndikosintha kwakomwe komwe optimizer iwona sikugwirizana ndi malo aliwonse kudzera pa pointer ya Vec.
// Uku ndi kukonzanso kusanthula kwa ma Xas #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}