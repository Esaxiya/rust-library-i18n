use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Chizindikiro chapadera pakusonkhanitsa payipi ya iterator mu Vec pomwe mukugwiritsanso ntchito magawidwewo, mwachitsanzo
/// kukonza mapaipi m'malo mwake.
///
/// SourceIter kholo trait ndilofunikira kuti ntchito yodziwika bwino ipeze gawo lomwe lidzagwiritsidwenso ntchito.
/// Koma sikokwanira kuti kusankhaku kungakhale kovomerezeka.
/// Onani malire ena pa impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-mkati SourceIter/InPlaceIterable traits zimangogwiritsidwa ntchito ndi maunyolo a Adapter <Adapter<Adapter<IntoIter>>> (zonse za core/std).
// Malire owonjezera pakukonzekera kwa adapter (kupitirira `impl<I: Trait> Trait for Adapter<I>`) amangodalira traits zina zomwe zadziwika kale kuti traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. chikhomo sichidalira nthawi yamoyo yamitundu yoperekedwa ndi ogwiritsa ntchito.Modulo dzenje la Copy, lomwe maukadaulo ena angapo amadalira kale.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Zowonjezera zofunika zomwe sizingathe kufotokozedwa kudzera pa trait bounds.Timadalira const eval m'malo mwake:
        // a) palibe ma ZST popeza sipangakhale gawo logwiritsiranso ntchito ndi kuwerengera masamu panic b) kukula kofananira malinga ndi mgwirizano wa Alloc c) mayikidwe olingana mogwirizana ndi mgwirizano wa Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // kubwereranso kuzinthu zina zowonjezera
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // gwiritsani ntchito kuyesa kuyambira
        // - imagwiritsa ntchito bwino ma adap ena a iterator
        // - mosiyana ndi njira zambiri zamkati zobweretsera, zimangotengera kudzikonda kwa &mut
        // - zimatilola kulumikiza cholembera kudzera mkati mwake ndikubwezeretsanso kumapeto
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // Kuwongolera kunachita bwino, osataya mutu
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // onetsetsani ngati mgwirizano wa SourceIter udasungidwa: ngati akanapanda kutero mwina sitingafike mpaka pano
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // fufuzani InPlaceIterable contract.Izi ndizotheka ngati iterator itakulitsa cholozera.
        // Ngati imagwiritsa ntchito mwayi wosasinthidwa kudzera pa TrustedRandomAccess ndiye kuti cholozera chimakhalabe pomwepo ndipo sitingathe kuchigwiritsa ntchito
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // gwetsani zotsalira zilizonse kumchira kwa gwero koma pewani kugawika komweko pokhapokha IntoIter itachoka ngati dontho la panics tithandizanso kutulutsa zinthu zilizonse zosonkhanitsidwa ku dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // mgwirizano wa InPlaceIterable sungatsimikizidwe ndendende pano popeza try_fold ili ndi cholozera chokha cholozera pomwe zonse zomwe tingachite ndikuwona ngati akadalipo
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}