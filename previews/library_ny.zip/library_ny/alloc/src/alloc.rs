//! Kugawidwa kwa kukumbukira APIs

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Izi ndi zizindikiro zamatsenga zoyimbira omwe amagawa dziko lonse lapansi.rustc imawapangitsa kuti aziyimbira `__rg_alloc` ndi zina zambiri.
    // ngati pali lingaliro la `#[global_allocator]` (nambala yomwe ikukulitsa chizindikirocho imapanga ntchitozo), kapena kuyitanitsa kukhazikitsa kosasintha mu libstd (`__rdl_alloc` etc.
    //
    // mu `library/std/src/alloc.rs`) mwinamwake.
    // rustc fork ya LLVM imasankhanso mwapadera mayinawa kuti athe kuwakwaniritsa monga `malloc`, `realloc`, ndi `free`, motsatana.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Wogawira kukumbukira padziko lonse lapansi.
///
/// Mtundu uwu umagwiritsa ntchito [`Allocator`] trait potumiza mafoni kwa wopatsa omwe adalembetsa ndi `#[global_allocator]` ngati alipo, kapena `std` crate.
///
///
/// Note: pamene mtundu uwu ndi wosakhazikika, magwiridwe antchito omwe angapezeke kudzera mu [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Gawani kukumbukira ndi ogawa padziko lonse lapansi.
///
/// Ntchitoyi ikupita kuyitanitsa njira ya [`GlobalAlloc::alloc`] yopatsa omwe adalembetsa ndi `#[global_allocator]` ngati ilipo, kapena kusasintha kwa `std` crate.
///
///
/// Ntchitoyi ikuyembekezeka kuchepetsedwa mokomera njira ya `alloc` yamtundu wa [`Global`] pomwe iyo ndi [`Allocator`] trait izikhala yolimba.
///
/// # Safety
///
/// Onani [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Gawani zokumbukira ndi omwe amagawa padziko lonse lapansi.
///
/// Ntchitoyi ikupita kuyitanitsa njira ya [`GlobalAlloc::dealloc`] yopatsa omwe adalembetsa ndi `#[global_allocator]` ngati ilipo, kapena kusasintha kwa `std` crate.
///
///
/// Ntchitoyi ikuyembekezeka kuchepetsedwa mokomera njira ya `dealloc` yamtundu wa [`Global`] pomwe iyo ndi [`Allocator`] trait izikhala yolimba.
///
/// # Safety
///
/// Onani [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Sinthanitsani kukumbukira ndi omwe amagawa padziko lonse lapansi.
///
/// Ntchitoyi ikupita kuyitanitsa njira ya [`GlobalAlloc::realloc`] yopatsa omwe adalembetsa ndi `#[global_allocator]` ngati ilipo, kapena kusasintha kwa `std` crate.
///
///
/// Ntchitoyi ikuyembekezeka kuchepetsedwa mokomera njira ya `realloc` yamtundu wa [`Global`] pomwe iyo ndi [`Allocator`] trait izikhala yolimba.
///
/// # Safety
///
/// Onani [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Gawani chikumbukiro choyambira pa zero ndi ogawa padziko lonse lapansi.
///
/// Ntchitoyi ikupita kuyitanitsa njira ya [`GlobalAlloc::alloc_zeroed`] yopatsa omwe adalembetsa ndi `#[global_allocator]` ngati ilipo, kapena kusasintha kwa `std` crate.
///
///
/// Ntchitoyi ikuyembekezeka kuchepetsedwa mokomera njira ya `alloc_zeroed` yamtundu wa [`Global`] pomwe iyo ndi [`Allocator`] trait izikhala yolimba.
///
/// # Safety
///
/// Onani [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // CHITETEZO: `layout` ilibe zero kukula,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // CHITETEZO: Zofanana ndi `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // CHITETEZO: `new_size` si zero chifukwa `old_size` ndi yayikulu kuposa kapena yofanana ndi `new_size`
            // mogwirizana ndi chitetezo.Zinthu zina ziyenera kutsatiridwa ndi woyimbirayo
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` mwina amayang'ana `new_size >= old_layout.size()` kapena zina zofananira.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // CHITETEZO: chifukwa `new_layout.size()` iyenera kukhala yayikulupo kapena yofanana ndi `old_size`,
            // kugawa kwakale komanso kwatsopano kumakhala koyenera kuwerengedwa ndikulembera ma `old_size` byte.
            // Komanso, chifukwa gawo lakale silinaperekedwe, silingagwirizane ndi `new_ptr`.
            // Chifukwa chake, kuyitanidwa ku `copy_nonoverlapping` ndikotetezeka.
            // Mgwirizano wachitetezo wa `dealloc` uyenera kusungidwa ndi woyimbirayo.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // CHITETEZO: `layout` ilibe zero kukula,
            // zinthu zina ziyenera kutsatiridwa ndi woyimbirayo
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // CHITETEZO: zikhalidwe zonse ziyenera kutsatiridwa ndi woyimbirayo
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // CHITETEZO: zikhalidwe zonse ziyenera kutsatiridwa ndi woyimbirayo
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // CHITETEZO: woyenera kuyitanitsa zinthu
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // CHITETEZO: `new_size` si zero.Zinthu zina ziyenera kutsatiridwa ndi woyimbirayo
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` mwina amayang'ana `new_size <= old_layout.size()` kapena zina zofananira.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // CHITETEZO: chifukwa `new_size` iyenera kukhala yocheperako kapena yofanana ndi `old_layout.size()`,
            // kugawa kwakale komanso kwatsopano kumakhala koyenera kuwerengedwa ndikulembera ma `new_size` byte.
            // Komanso, chifukwa gawo lakale silinaperekedwe, silingagwirizane ndi `new_ptr`.
            // Chifukwa chake, kuyitanidwa ku `copy_nonoverlapping` ndikotetezeka.
            // Mgwirizano wachitetezo wa `dealloc` uyenera kusungidwa ndi woyimbirayo.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Wogawa maupangiri apadera.
// Ntchitoyi siyenera kumasula.Ngati izo zitero, MIR codegen idzalephera.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Siginecha iyi iyenera kukhala yofanana ndi `Box`, apo ayi ICE ichitika.
// Pomwe gawo lina la `Box` limawonjezedwa (monga `A: Allocator`), izi zikuyenera kuwonjezedwanso pano.
// Mwachitsanzo ngati `Box` yasinthidwa kukhala `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, ntchitoyi iyenera kusinthidwa kukhala `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)`.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Chogawa cholakwitsa

extern "Rust" {
    // Ichi ndiye chizindikiro chamatsenga choyimbira wolakwitsa padziko lonse lapansi.
    // rustc imapangitsa kuti izitcha `__rg_oom` ngati pali `#[alloc_error_handler]`, kapena kuyitanitsa kukhazikitsa kosasintha pansi pa (`__rdl_oom`) mwanjira ina.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Kutaya zolakwika zakugawana kukumbukira kapena kulephera.
///
/// Omwe akuyitanitsa ma API omwe amakumbukira kukumbukira omwe akufuna kuchotsera chiwerengerocho potengera cholakwika ndi kagawidwe amalimbikitsidwa kuyitanitsa ntchitoyi, m'malo moyitanitsa `panic!` kapena zina zotere.
///
///
/// Khalidwe losasintha la ntchitoyi ndikusindikiza uthenga wolakwika ndikuchotsa ndondomekoyi.
/// Ikhoza kusinthidwa ndi [`set_alloc_error_hook`] ndi [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Pakuyesa mayeso `std::alloc::handle_alloc_error` itha kugwiritsidwa ntchito mwachindunji.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // yotchedwa kudzera pa `__rust_alloc_error_handler`

    // ngati palibe `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // ngati pali `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Phatikizani ma clones muzomwe zidapatsidwa kale, zomwe sizinayambike kukumbukira.
/// Yogwiritsidwa ntchito ndi `Box::clone` ndi `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Popeza mwapatsa *choyamba* mutha kuloleza chopanga kuti chikhale ndi mtengo m'malo mwake, kudumpha kwanuko ndikusuntha.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Titha kukopera m'malo mwake, osatinso phindu lakomweko.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}