//! Zingwe za Unicode.
//!
//! *[See also the `str` primitive type](str).*
//!
//! Mtundu wa `&str` ndi imodzi mwazingwe zazikuluzikulu, inayo ndi `String`.
//! Mosiyana ndi mnzake wa `String`, zolemba zake zimabwerekedwa.
//!
//! # Kagwiritsidwe
//!
//! Chidziwitso choyambirira cha chingwe cha `&str`:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Apa talengeza chingwe chenicheni, chomwe chimadziwikanso kuti chidutswa cha zingwe.
//! Zolemba zazingwe zimakhala ndi moyo wosasunthika, zomwe zikutanthauza kuti chingwe `hello_world` chimatsimikizika kuti chizikhala chovomerezeka nthawi yonse ya pulogalamuyi.
//!
//! Titha kutchulanso momveka bwino za nthawi ya `hello_world ':
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Zambiri mwazomwe zimagwiritsidwa ntchito mgululi zimagwiritsidwa ntchito pakusintha kwamayeso.
// Ndizosavuta kuzimitsa chenjezo losagwiritsidwa ntchito_kulandira kuposa kukonza.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `str` mu `Concat<str>` sizothandiza pano.
/// Mtundu wamtundu wa trait umangopezeka kuti umuthandizenso wina.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // malupu okhala ndi zolembedwa zolimba amathamanga mwachangu kwambiri amakhazikika pamilandu ndi kutalika kwakanthawi kosiyanitsa
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // kusakhazikika kosafunikira kukula kwa zero
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Kukhazikitsa kolumikizana koyenera komwe kumagwirira ntchito Vec yonse<T>(T: Copy) ndi vest wamkati wa String Pakadali pano (2018-05-13) pali cholakwika chomwe chimayang'ana mtundu (onani nkhani #36262) Pachifukwa ichi SliceConcat<T>siyodziwika bwino pa T: Copy ndi SliceConcat<str>ndiye yekhayo wogwiritsa ntchito ntchitoyi.
// Zimasiyidwa m'malo kuti zitheke.
//
// malire a chingwe-kujowina ndi S: Bwerekani<str>ndi Vec-Join Borrow <[T]> [T] and str both impl AsRef <[T]> for some T
// => s.borrow().as_ref() ndipo timakhala ndi magawo nthawi zonse
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // kagawo koyamba ndi kokhako kopatula osapatula kale
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // kuwerengera kutalika kwathunthu kwa Vec yomwe idalumikizidwa ngati kuwerengera kwa `len` kusefukira, tidzakhala panic tikadatha kukumbukira chilichonse ndipo ntchito yonseyo imafunikira kuti Vec yonse idakonzedweratu chitetezo
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // konzani chosungira chosakhazikika
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // lembani zolekanitsa ndi magawo opanda malire macheke amapanga malupu okhala ndi zolimba zolembedwera zazolekanitsa zazing'ono kusintha kwakukulu kotheka (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Kukhazikitsa modabwitsa kumatha kubwezera magawo osiyanasiyana pakuwerengera kutalika ndi mtundu wakewo.
        //
        // Onetsetsani kuti sitikuwululira omwe sanatchulidwe kale.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Njira zopangira zingwe.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// Imatembenuza `Box<str>` kukhala `Box<[u8]>` popanda kukopera kapena kugawa.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// M'malo machesi onse a patani ndi chingwe china.
    ///
    /// `replace` imapanga [`String`] yatsopano, ndikukopera zomwe zidutsidwazo kuchokera pachingwe ichi.
    /// Pochita izi, imayesa kupeza machesi amachitidwe.
    /// Ngati apeza chilichonse, amawalowetsa m'malo mwake ndi chidutswa chachingwe m'malo mwake.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Pamene chitsanzocho sichikugwirizana:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Ikubwezeretsani machesi oyamba a N ndi chingwe china.
    ///
    /// `replacen` imapanga [`String`] yatsopano, ndikukopera zomwe zidutsidwazo kuchokera pachingwe ichi.
    /// Pochita izi, imayesa kupeza machesi amachitidwe.
    /// Ngati apeza chilichonse, amawalowetsa m'malo mwake ndi chidutswa cha zingwe m'malo mwa `count` nthawi zambiri.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Pamene chitsanzocho sichikugwirizana:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Tikuyembekeza kuchepetsa nthawi zoperekanso ntchito
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Imabwezeretsa zochepa zotsika zazingwe zazingwezi, ngati [`String`] yatsopano.
    ///
    /// 'Lowercase' imafotokozedwa molingana ndi Unicode Derives Core Property `Lowercase`.
    ///
    /// Popeza otchulidwa ena amatha kukulira m'mitundu ingapo posintha mulanduyo, ntchitoyi imabweza [`String`] m'malo mosintha chizindikiro m'malo mwake.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Chitsanzo chonyenga, ndi sigma:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // koma kumapeto kwa mawu, ndi ς, osati σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Ziyankhulo zopanda mlandu sizisinthidwa:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ mamapu ku σ, kupatula kumapeto kwa mawu pomwe amalemba kuti ς.
                // Izi ndiye zokhazokha za (contextual) koma mamapu oyimira palokha mu `SpecialCasing.txt`, ndizovuta kwambiri kuti azikhala ndi makina a "condition".
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // pakutanthauzira kwa `Final_Sigma`.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Kubwezeretsa chimodzimodzi ndi chidutswa cha chingwechi, ngati [`String`] yatsopano.
    ///
    /// 'Uppercase' imafotokozedwa molingana ndi Unicode Derives Core Property `Uppercase`.
    ///
    /// Popeza otchulidwa ena amatha kukulira m'mitundu ingapo posintha mulanduyo, ntchitoyi imabweza [`String`] m'malo mosintha chizindikiro m'malo mwake.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Zolemba popanda mlandu sizisinthidwa:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Khalidwe limodzi limatha kuchuluka:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// Imatembenuza [`Box<str>`] kukhala [`String`] popanda kukopera kapena kugawa.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Pangani [`String`] yatsopano pobwereza chingwe `n` nthawi.
    ///
    /// # Panics
    ///
    /// Ntchitoyi idzagwira ntchito panic ngati kuthekera kukusefukira.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// panic ikusefukira:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Imabwezeretsa mtundu wa chingwe ichi pomwe mawonekedwe aliwonse amapangidwira ku ASCII yake yofanana.
    ///
    ///
    /// Makalata a ASCII 'a' mpaka 'z' ajambulidwa ku 'A' mpaka 'Z', koma zilembo zosakhala ASCII sizikusintha.
    ///
    /// Kuti muwonjeze mtengo womwe muli, gwiritsani ntchito [`make_ascii_uppercase`].
    ///
    /// Kuti mukhale ndi zilembo zazikulu za ASCII kuphatikiza pamanambala omwe si a ASCII, gwiritsani ntchito [`to_uppercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() amateteza UTF-8 osasintha.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Imabwezeretsa mtundu wa chingwe ichi pomwe mawonekedwe aliwonse amapangidwira ku ASCII yake yofanana.
    ///
    ///
    /// Makalata a ASCII 'A' mpaka 'Z' ajambulidwa ku 'a' mpaka 'z', koma zilembo zosakhala ASCII sizikusintha.
    ///
    /// Kuti muchepetse mtengo womwe ulipo, gwiritsani ntchito [`make_ascii_lowercase`].
    ///
    /// Kuti muchepetse zilembo za ASCII kuphatikiza zilembo zosakhala ASCII, gwiritsani ntchito [`to_lowercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() amateteza UTF-8 osasintha.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Imatembenuza kagawo kakang'ono ka mabatani kukhala kachingwe kopanda mabokosi osawona ngati chingwecho chili ndi UTF-8 yoyenera.
///
///
/// # Examples
///
/// Kagwiritsidwe:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}