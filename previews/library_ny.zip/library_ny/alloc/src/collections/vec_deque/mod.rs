//! Mzere wokhazikika kawiri wokhazikitsidwa ndi cholembera chachitsulo chokulirapo.
//!
//! Mzerewu uli ndi ma *O*(1) oyikapo ndikuchotsa pamitengo yonse iwiri ya chidebecho.
//! Ilinso ndi zolemba za *O*(1) ngati vector.
//! Zomwe zilipo siziyenera kutengera, ndipo mzerewo uzitumizidwa ngati mtunduwo ungatumizidwe.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // Mphamvu yayikulu kwambiri iwiri

/// Mzere wokhazikika kawiri wokhazikitsidwa ndi cholembera chachitsulo chokulirapo.
///
/// Kugwiritsa ntchito kwa "default" kwamtunduwu pamzera ndikugwiritsa ntchito [`push_back`] kuwonjezera pamzerewu, ndipo [`pop_front`] kuti ichotse pamzerewu.
///
/// [`extend`] ndipo [`append`] imakankhira kumbuyo motere, ndikuyendetsa `VecDeque` kupita kutsogolo kupita kumbuyo.
///
/// Popeza `VecDeque` ndi cholumikizira mphete, zinthu zake sizoyenera kukumbukira.
/// Ngati mukufuna kulumikiza zinthuzo ngati kagawo kamodzi, monga kusanja bwino, mutha kugwiritsa ntchito [`make_contiguous`].
/// Imasinthasintha `VecDeque` kuti zinthu zake sizikulunga, ndikubwezera kagawidwe kosinthika motsatira zomwe zikuphatikizika tsopano.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // mchira ndi mutu ndizolozera mu buffer.
    // Mchira nthawi zonse umaloza ku chinthu choyamba chomwe chingawerengedwe, Mutu nthawi zonse umaloza komwe deta iyenera kulembedwa.
    //
    // Ngati mchira==mutu buffer ilibe kanthu.Kutalika kwa cholebuffer kumatanthauzidwa ngati mtunda pakati pa ziwirizi.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// Imayendetsa zowonongera pazinthu zonse mutagwetsa (nthawi zambiri kapena panthawi yopumula).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // gwiritsani ntchito dontho la [T]
            ptr::drop_in_place(front);
        }
        // RawVec imagwiritsa ntchito kusamutsidwa
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// Amapanga `VecDeque<T>` yopanda kanthu.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// Pangakhale kosavuta
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Pangakhale kosavuta
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // Kwa mitundu yayikulu kwambiri, nthawi zonse timakhala ndi mphamvu zambiri
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Sinthani ptr kukhala kagawo
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Sinthani ptr kukhala kagawo kakang'ono
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Imachotsa chinthu kuchokera mu chosungira
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Amalemba chinthu mu buffer, ndikuyisuntha.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// Kubwezeretsa `true` ngati buffer ili ndi mphamvu zonse.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// Kubwezeretsa index mu choyimira gawo lotetezedwa kwa anapatsidwa logical element index.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// Kubwezeretsa index mu choyimira gawo lotetezedwa kwa anapatsidwa logical element index + addend.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// Imabwezeretsa cholozera pachithunzithunzi choyambira pamndandanda wazinthu zomveka, kuchotsera.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// Zimakopa chikumbukiro chokumbukira cha lensi kuyambira src mpaka dst
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Zimakopa chikumbukiro chokumbukira cha lensi kuyambira src mpaka dst
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Zimakopera chikumbukiro chokumbukira cha lensi kutalika kuchokera ku src mpaka dest.
    /// (abs(dst - src) + len) sayenera kukhala yokulirapo kuposa cap() (Payenera kukhala pafupifupi dera limodzi lopitilira pakati pa src ndi dest).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src sichikulunga, dst sichikulunga
                //
                //        S...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // dst pamaso pa src, src sichikulunga, dst wraps
                //
                //
                //    S...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src isanafike dst, src sichikulunga, dst wraps
                //
                //
                //              S...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst src, src zisanachitike, dst sikukulunga
                //
                //
                //    .. S.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src isanafike dst, src kukulunga, dst sikukulunga
                //
                //
                //    .. S.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst pamaso pa src, src zokutira, dst wraps
                //
                //
                //    ... S.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src isanachitike dst, src zokutira, zokutira za dst
                //
                //
                //    .. S..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... D.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Mapiko a mutu ndi mchira mozungulira kuthana ndi vuto lomwe tangogawananso.
    /// Zosatetezeka chifukwa zimakhulupirira kukalamba kwakale.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // Sunthani gawo lalifupi kwambiri lamphete TH
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooo......
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // Pulogalamu ya Nop
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// Amapanga `VecDeque` yopanda kanthu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// Pangani `VecDeque` yopanda kanthu yokhala ndi malo osachepera `capacity`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 popeza woyeserera nthawi zonse amasiya malo opanda kanthu
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// Amapereka kutanthauzira kwa chinthucho pa index yomwe yapatsidwa.
    ///
    /// Zomwe zili pa index 0 ndizakutsogolo kwa mzerewu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Amapereka kutanthauzira kosinthika kwa chinthucho pa index yomwe yapatsidwa.
    ///
    /// Zomwe zili pa index 0 ndizakutsogolo kwa mzerewu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Sinthana zinthu kuma indices `i` ndi `j`.
    ///
    /// `i` ndipo `j` itha kukhala yofanana.
    ///
    /// Zomwe zili pa index 0 ndizakutsogolo kwa mzerewu.
    ///
    /// # Panics
    ///
    /// Panics ngati index iliyonse ilibe malire.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// Imabwezeretsa kuchuluka kwa zinthu zomwe `VecDeque` imatha kugwira osasinthanso.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// Imasunga mphamvu yocheperako yazinthu zina `additional` zoti ziyikidwe mu `VecDeque` yomwe yapatsidwa.
    /// Sichichita chilichonse ngati kuthekera kuli kokwanira kale.
    ///
    /// Dziwani kuti woperekayo atha kupatsa malo osonkhanitsa malo ochulukirapo kuposa momwe amafunsira.
    /// Chifukwa chake mphamvu sizingadaliridwe kukhala zochepa kwenikweni.
    /// Sankhani [`reserve`] ngati future akuyembekezeredwa.
    ///
    /// # Panics
    ///
    /// Panics ngati mphamvu yatsopano ikusefukira `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// Kusunga kuthekera kwa zinthu zosachepera `additional` kuti ziyikidwe mu `VecDeque` yopatsidwa.
    /// Zosonkhanitsazo zitha kusunga malo ambiri kuti zisawonongeke pafupipafupi.
    ///
    /// # Panics
    ///
    /// Panics ngati mphamvu yatsopano ikusefukira `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Imayesetsa kusunga mphamvu zochepa pazinthu zina `additional` kuti ziyikidwe mu `VecDeque<T>` yomwe yapatsidwa.
    ///
    /// Pambuyo poyimba `try_reserve_exact`, kuthekera kumakhala kwakukulu kuposa kapena kofanana ndi `self.len() + additional`.
    /// Sichichita chilichonse ngati kuthekera kuli kokwanira kale.
    ///
    /// Dziwani kuti woperekayo atha kupatsa malo osonkhanitsa malo ochulukirapo kuposa momwe amafunsira.
    /// Chifukwa chake, kuthekera sikungadaliridwe kukhala kocheperako kwenikweni.
    /// Sankhani `reserve` ngati future akuyembekezeredwa.
    ///
    /// # Errors
    ///
    /// Mphamvu ikasefukira `usize`, kapena woperekayo akuti walephera, ndiye kuti cholakwika chimabwezedwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Sungitsani kukumbukira, kutuluka ngati sitingathe
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Tsopano tikudziwa kuti izi sizingatheke OOM(Out-Of-Memory) pakati pa ntchito yathu yovuta
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // zovuta kwambiri
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// Imayesetsa kusunga mphamvu zosachepera `additional` zowonjezera kuti ziyikidwe mu `VecDeque<T>` yomwe yapatsidwa.
    /// Zosonkhanitsazo zitha kusunga malo ambiri kuti zisawonongeke pafupipafupi.
    /// Pambuyo poyimba `try_reserve`, kuthekera kumakhala kwakukulu kuposa kapena kofanana ndi `self.len() + additional`.
    /// Sichichita chilichonse ngati kuthekera ndikwanira kale.
    ///
    /// # Errors
    ///
    /// Mphamvu ikasefukira `usize`, kapena woperekayo akuti walephera, ndiye kuti cholakwika chimabwezedwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Sungitsani kukumbukira, kutuluka ngati sitingathe
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Tsopano tikudziwa kuti izi sizingatheke OOM pakati pa ntchito yathu yovuta
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // zovuta kwambiri
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// Imachepetsa mphamvu ya `VecDeque` momwe ingathere.
    ///
    /// Idzagwa pafupi kwambiri mpaka kutalika koma wopatsa akhoza kudziwitsa `VecDeque` kuti pali malo azinthu zina zochepa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// Imachepetsa mphamvu ya `VecDeque` yokhala ndi malire ochepa.
    ///
    /// Mphamvuyo idzakhalabe yocheperako ngati kutalika kwake ndi mtengo womwe waperekedwa.
    ///
    ///
    /// Ngati mphamvu zomwe zilipo pakadali pano ndizochepera malire, ndiye kuti palibe-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // Sitiyenera kuda nkhawa zakusefukira chifukwa `self.len()` kapena `self.capacity()` sangakhale `usize::MAX`.
        // +1 pomwe wolemba nthawi zonse amasiya malo amodzi opanda kanthu.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // Pali milandu itatu yosangalatsa:
            //   Zinthu zonse sizili pamalire omwe amafunikira Zinthuzo ndizophatikizika, ndipo mutu uli kunja kwa malire omwe mukufuna Zinthu zimatuluka, ndipo mchira ulibe malire omwe mukufuna
            //
            //
            // Nthawi zina, maudindo azinthu samakhudzidwa.
            //
            // Ikuwonetsa kuti zinthu zomwe zili kumutu ziyenera kusunthidwa.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Sungani zinthu kuchokera pamalire osafunikira (malo pambuyo pa target_cap)
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// Imafupikitsa `VecDeque`, kusunga zinthu zoyambirira za `len` ndikuponya zina zonse.
    ///
    ///
    /// Ngati `len` ili yayikulu kuposa kutalika kwa `VecDeque`, izi sizikhala ndi zotsatirapo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Imayendetsa zowonongera pazinthu zonse mutagwetsa (nthawi zambiri kapena panthawi yopumula).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Zotetezeka chifukwa:
        //
        // * Kagawo kalikonse kamene kamadutsa ku `drop_in_place` ndikoyenera;mlandu wachiwiri uli ndi `len <= front.len()` ndipo kubwerera pa `len > self.len()` kumatsimikizira `begin <= back.len()` koyambirira
        //
        // * Mutu wa VecDeque wasunthidwa asanaitane `drop_in_place`, chifukwa chake palibe phindu lomwe limatsitsidwa kawiri ngati `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Onetsetsani kuti theka lachiwiri lagwetsedwa ngakhale wowonongera woyamba panics.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Imabwezeretsa choyerekeza kutsogolo ndi kumbuyo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// Ikubwezeretsanso chojambulira chakumbuyo chomwe chimabwezeretsa zomwe zingasinthe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // CHITETEZO: Zosintha zachitetezo za `IterMut` zamkati zimakhazikitsidwa chifukwa
        // `ring` timapanga ndi kagawo kosasunthika kwanthawi yonse '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Kubwezeretsa magawo awiri omwe ali ndi, mwatsatanetsatane, zomwe zili mu `VecDeque`.
    ///
    /// Ngati [`make_contiguous`] idatchedwa kale, zinthu zonse za `VecDeque` zidzakhala pagawo loyamba ndipo chidutswa chachiwiri sichikhala chopanda kanthu.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// Kubwezeretsa magawo awiri omwe ali ndi, mwatsatanetsatane, zomwe zili mu `VecDeque`.
    ///
    /// Ngati [`make_contiguous`] idatchedwa kale, zinthu zonse za `VecDeque` zidzakhala pagawo loyamba ndipo chidutswa chachiwiri sichikhala chopanda kanthu.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// Kubwezeretsa chiwerengero cha zinthu mu `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// Kubwezeretsa `true` ngati `VecDeque` ilibe kanthu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// Pangani iterator yomwe imakhudza mtundu womwe watchulidwa mu `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics ngati poyambira ndi wamkulu kuposa malekezero kapena ngati malekezero ndi akulu kuposa kutalika kwa vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // Mtundu wathunthu umakhudza zonse zomwe zili
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // Buku lomwe tili nalo mu &self limasungidwa mu '_ wa Iter.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// Pangani iterator yomwe imakhudza mtundu womwe ungasinthidwe mu `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics ngati poyambira ndi wamkulu kuposa malekezero kapena ngati malekezero ndi akulu kuposa kutalika kwa vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // Mtundu wathunthu umakhudza zonse zomwe zili
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // CHITETEZO: Zosintha zachitetezo za `IterMut` zamkati zimakhazikitsidwa chifukwa
        // `ring` timapanga ndi kagawo kosasunthika kwanthawi yonse '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Pangani chojambulira chotulutsa chomwe chimachotsa mtundu wa `VecDeque` ndikupereka zinthu zochotsedwa.
    ///
    /// Chidziwitso 1: The range range imachotsedwa ngakhale iterator sichiwonongedwa mpaka kumapeto.
    ///
    /// Chidziwitso 2: Sizikudziwika kuti ndi zinthu zingati zomwe zimachotsedwa pagululi, ngati mtengo wa `Drain` sunatsikidwe, koma kubwereka kumatha (mwachitsanzo, chifukwa cha `mem::forget`).
    ///
    ///
    /// # Panics
    ///
    /// Panics ngati poyambira ndi wamkulu kuposa malekezero kapena ngati malekezero ndi akulu kuposa kutalika kwa vector.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // Makonda athunthu amachotsa zonse zomwe zili mkatimo
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Chitetezo chokumbukira
        //
        // Drain ikangopangidwa koyamba, gululi limafupikitsidwa kuti liwonetsetse kuti palibe zinthu zomwe sizinayambitsidwe kapena zosunthidwa zomwe zingapezeke ngati wowononga Drain sadzayendetsanso.
        //
        //
        // Drain idzatulutsa ptr::read zomwe achotse.
        // Mukamaliza, zomwe zatsala zidzatetezedwa kuti ziphimbe dzenje, ndipo malingaliro a head/tail abwezeretsedwanso molondola.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // Zinthu za deque zidagawika m'magulu atatu:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;H= self.head;T=drain_tail;h=drain_mutu
        //
        // Timasunga drain_tail ngati self.head, ndi drain_head ndi self.head monga after_tail komanso pambuyo_mutu motsatana pa Drain.
        // Izi zimachepetsanso gulu logwira bwino ntchito kotero kuti ngati Drain idatuluka, tayiwala za zomwe zingasunthidwe pambuyo pa kuyamba kwa drain.
        //
        //
        //        T H H
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" za zikhulupiriro pambuyo pa kuyamba kwa drain mpaka drain itatha ndipo wowononga Drain akuyendetsedwa.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // Mwakhama, timangopanga zolemba kuchokera ku `self` apa ndikuwerenga kuchokera pamenepo.
                // Sitilembera `self` kapena kubwereranso kuzinthu zosinthika.
                // Chifukwa chake cholozera chopangira chomwe tidapanga pamwambapa, cha `deque`, sichikhala chovomerezeka.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// Amatsitsa `VecDeque`, ndikuchotsa malingaliro onse.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// Kubwezeretsa `true` ngati `VecDeque` ili ndi chinthu chofanana ndi mtengo womwe wapatsidwa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Amapereka cholozera cha kutsogolo, kapena `None` ngati `VecDeque` ilibe kanthu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Amapereka kutanthauzira kosinthika kwa chinthu chakutsogolo, kapena `None` ngati `VecDeque` ilibe kanthu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Amapereka cholozera kumbuyo, kapena `None` ngati `VecDeque` ilibe kanthu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// Amapereka kutanthauzira kosinthika kumbuyo, kapena `None` ngati `VecDeque` ilibe kanthu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Imachotsa chinthu choyambayo ndikuyibwezera, kapena `None` ngati `VecDeque` ilibe kanthu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// Imachotsa chomaliza kuchokera ku `VecDeque` ndikubwezeretsa, kapena `None` ngati ilibe kanthu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// Kukonzekera chinthu ku `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// Amagwiritsa ntchito chinthu kumbuyo kwa `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: Kodi tiyenera kulingalira `head == 0` kutanthauza
        // kuti `self` ndiyophatikiza?
        self.tail <= self.head
    }

    /// Imachotsa chinthu kulikonse mu `VecDeque` ndikubwezeretsanso, ndikuikapo chinthu choyambirira.
    ///
    ///
    /// Izi sizikusunga dongosolo, koma ndi *O*(1).
    ///
    /// Kubwezeretsa `None` ngati `index` ilibe malire.
    ///
    /// Zomwe zili pa index 0 ndizakutsogolo kwa mzerewu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Imachotsa chinthu kulikonse mu `VecDeque` ndikubwezeretsanso, ndikuikapo chomaliza.
    ///
    ///
    /// Izi sizikusunga dongosolo, koma ndi *O*(1).
    ///
    /// Kubwezeretsa `None` ngati `index` ilibe malire.
    ///
    /// Zomwe zili pa index 0 ndizakutsogolo kwa mzerewu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Kuyika chinthu pa `index` mkati mwa `VecDeque`, kusunthira zinthu zonse ndi ma indices okulirapo kuposa kapena ofanana ndi `index` kumbuyo.
    ///
    ///
    /// Zomwe zili pa index 0 ndizakutsogolo kwa mzerewu.
    ///
    /// # Panics
    ///
    /// Panics ngati `index` ili yayikulu kuposa kutalika kwa `VecDeque`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Sunthani zinthu zochepa pazomata ndikuyika chinthu chomwe mwapatsidwa
        //
        // Pafupifupi len/2, zinthu 1 zimasunthidwa. O(min(n, n-i))
        //
        // Pali milandu itatu yayikulu:
        //  Zinthu ndizophatikiza
        //      - chochitika chapadera pamene mchira uli 0 Elements sadziwika ndipo cholowacho chili mgawo la mchira Zinthuzo ndizopanda tanthauzo ndipo cholowacho chili mgawo lamutu
        //
        //
        // Pa iliyonse ya izi pali milandu iwiri:
        //  Ikani ili pafupi ndi mchira Ikani pafupi ndi mutu
        //
        // Chinsinsi: H, self.head
        //      T, self.tail o, elementi Yoyenera I, Kuika element A, Zomwe ziyenera kukhala pambuyo poyikapo M, Zikuwonetsa chinthucho chidasunthidwa
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [Oooooo.......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // zozungulira, ikani pafupi ndi mchira:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // zovuta, ikani pafupi ndi mchira ndi mchira ndi 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       MM

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // Tasuntha kale mchira, chifukwa chake timangotsanzira `index - 1`.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // zozungulira, ikani pafupi ndi mutu:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // zosamveka, ikani pafupi ndi mchira, gawo la mchira:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // discontiguous, ikani pafupi ndi mutu, mchira gawo:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // zofanizira mpaka mutu watsopano
                    self.copy(1, 0, self.head);

                    // lembani chinthu chomaliza m'malo opanda kanthu pansi pa buffer
                    self.copy(0, self.cap() - 1, 1);

                    // suntha zinthu kuchokera ku idx kupita kumapeto osaphatikizanso ^ element
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // discontiguous, insert ili pafupi ndi mchira, mutu wagawo, ndipo ili pa index zero mu buffer yamkati:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // lembani zinthu mpaka mchira watsopano
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // lembani chinthu chomaliza m'malo opanda kanthu pansi pa buffer
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // discontiguous, ikani pafupi ndi mchira, gawo lamutu:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // lembani zinthu mpaka mchira watsopano
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // lembani chinthu chomaliza m'malo opanda kanthu pansi pa buffer
                    self.copy(self.cap() - 1, 0, 1);

                    // suntha zinthu kuchokera ku idx-1 mpaka kumapeto osaphatikizanso ^ element
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // discontiguous, ikani pafupi ndi mutu, mutu wamutu:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // mchira mwina ukadasinthidwa kotero tifunika kuwerengeranso
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// Imachotsa ndikubwezeretsanso `index` kuchokera ku `VecDeque`.
    /// Mapeto aliwonse omwe ali pafupi ndi malo ochotserawo amasunthidwa kuti apange mpata, ndipo zinthu zonse zomwe zakhudzidwa zidzasunthidwa kumaudindo atsopano.
    ///
    /// Kubwezeretsa `None` ngati `index` ilibe malire.
    ///
    /// Zomwe zili pa index 0 ndizakutsogolo kwa mzerewu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // Pali milandu itatu yayikulu:
        //  Zinthu ndizophatikizika Zinthu ndizosazindikira ndipo kuchotsedwa kwake kuli mgawo la mchira Zinthuzo ndizopanda tanthauzo ndipo kuchotsedwa kuli pamutu wamutu
        //
        //      - chochitika chapadera pomwe zinthu zimakhala zophatikizika, koma self.head =0
        //
        // Pa iliyonse ya izi pali milandu iwiri:
        //  Ikani ili pafupi ndi mchira Ikani pafupi ndi mutu
        //
        // Chinsinsi: H, self.head
        //      T, self.tail o, Zinthu zofunikira x, Zomwe zidalembedwa kuti zichotsedwe R, Zikuwonetsa chinthu chomwe chikuchotsedwa M, Chikuwonetsa chinthu chosunthidwa
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // zozungulira, chotsani pafupi ndi mchira:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // zovuta, chotsani pafupi ndi mutu:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // zosamveka, chotsani mchira, gawo la mchira:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // discontiguous, chotsani pafupi ndi mutu, mutu wa mutu:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // discontiguous, chotsani pafupi ndi mutu, gawo la mchira:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // kapena zosamveka bwino, chotsani pafupi ndi mutu, gawo la mchira:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // jambulani zinthu zomwe zili mchira
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // Imaletsa kusefukira.
                    if self.head != 0 {
                        // lembani chinthu choyamba pamalo opanda kanthu
                        self.copy(self.cap() - 1, 0, 1);

                        // kusuntha zinthu mu mutu mutu chammbuyo
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // zosamveka, chotsani mchira, mutu wamutu:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // jambulani zinthu mpaka idx
                    self.copy(1, 0, idx);

                    // lembani chinthu chomaliza m'malo opanda kanthu
                    self.copy(0, self.cap() - 1, 1);

                    // suntha zinthu kuyambira kumchira mpaka kumapeto, kupatula chomaliza
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// Amagawa `VecDeque` muwiri pa index yomwe yapatsidwa.
    ///
    /// Kubwezeretsa `VecDeque` yomwe yangoperekedwa kumene.
    /// `self` muli zinthu `[0, at)`, ndipo `VecDeque` yobwezeretsedwayo ili ndi zinthu `[at, len)`.
    ///
    /// Dziwani kuti kuchuluka kwa `self` sikusintha.
    ///
    /// Zomwe zili pa index 0 ndizakutsogolo kwa mzerewu.
    ///
    /// # Panics
    ///
    /// Panics ngati `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` lagona mu theka loyamba.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // ingotenga theka lachiwiri lonse.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` wagona theka lachiwiri, akuyenera kudziwa zomwe tidalumpha theka loyamba.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Sambani komwe malekezero a buffers ali
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// Imasuntha zinthu zonse za `other` kupita ku `self`, ndikusiya `other` yopanda kanthu.
    ///
    /// # Panics
    ///
    /// Panics ngati nambala yatsopano yazinthu zikusefukira `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // zopanda nzeru impl
        self.extend(other.drain(..));
    }

    /// Imasunga zinthu zokhazokha zotchulidwa ndi wotsogolera.
    ///
    /// Mwanjira ina, chotsani zonse `e` kotero kuti `f(&e)` ibwerere zabodza.
    /// Njirayi imagwira ntchito m'malo mwake, kuyendera chinthu chilichonse chimodzimodzi kamodzi koyambirira, ndikusunga dongosolo lazomwe zidasungidwa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// Dongosolo lenileni lingakhale lothandiza kutsatira zakunja, monga index.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Izi zitha kukhala panic kapena kutaya mimba
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // Onjezani kukula kwa buffer.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// Sinthani `VecDeque` m'malo mwake kuti `len()` ifanane ndi `new_len`, mwina pochotsa zinthu zowonjezera kumbuyo kapena poyika zinthu zomwe zidapangidwa poyitanitsa `generator` kumbuyo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Imakonzanso kusungidwa kwamkati kwa phokosoli kotero ndi chidutswa chimodzi, chomwe chimabwezedwa.
    ///
    /// Njirayi siyikugawa ndipo siyimasintha momwe zinthu ziliri.Ikamabwezeretsa kagawidwe kosinthika, itha kugwiritsidwa ntchito kusanja mwala.
    ///
    /// Mukangosunga mkati, njira za [`as_slices`] ndi [`as_mut_slices`] zibwezeretsa zonse zomwe zili mu `VecDeque` mu kagawo kamodzi.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Kusanja zomwe zili mu deque.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // kusanja deque
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // kuyisanja motsutsana
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Kupeza mwayi wosasunthika ku kagawo kakang'ono.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // Tsopano tikhoza kukhala otsimikiza kuti `slice` ili ndi zinthu zonse za chipilalacho, tikadali ndi mwayi wopeza `buf`.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // pali malo okwanira omasulira mchira umodzi, izi zikutanthauza kuti timasunthira mutu kumbuyo, kenako ndikutsitsa mchirawo molondola.
            //
            //
            // kuchokera: DEFGH .... ABC
            // kuti: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: Sitikuganizira .... ABCDEFGH
            // kukhala wophatikiza chifukwa `head` ikhala `0` pankhaniyi.
            // Ngakhale tikufuna kusintha izi sizachilendo chifukwa malo ochepa amayembekezera kuti `is_contiguous` itanthauza kuti titha kungogwiritsa ntchito `buf[tail..head]`.
            //
            //

            // pali malo okwanira omasulira mutu umodzi, izi zikutanthauza kuti timasunthira mchira mtsogolo, kenako ndikutengera mutu pamalo oyenera.
            //
            //
            // kuchokera: FGH .... ABCDE
            // kuti: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // zaulere ndizocheperako kuposa mutu ndi mchira, izi zikutanthauza kuti tiyenera kuyendetsa pang'onopang'ono mchira ndi mutu.
            //
            //
            // kuchokera: EFGHI ... ABCD kapena HIJK.ABCDEFG
            // kuti: ABCDEFGHI ... kapena ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // Vuto lalikulu limawoneka ngati GHIJKLM ... ABCDEF, asanasinthire ABCDEFM ... GHIJKL, mutadutsa 1 swaps ABCDEFGHIJM ... KL, sinthanani mpaka kumanzere edge ifike mu sitolo yogulitsa
                //                  - ndiye kuyambitsanso algorithm ndi sitolo yatsopano ya (smaller) Nthawi zina sitolo yogulitsira imafika pomwe edge yoyenera ili kumapeto kwa buffer, izi zikutanthauza kuti tagunda dongosolo loyenera ndi ma swaps ochepa!
                //
                // E.g
                // EF..ABCD ABCDEF .., titangomaliza kusinthana anayi
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// Imazungulira malo omaliza omaliza a `mid` kumanzere.
    ///
    /// Equivalently,
    /// - Imasinthira chinthu `mid` pamalo oyamba.
    /// - Akuphwanya zinthu zoyambirira za `mid` ndikuziwakankhira mpaka kumapeto.
    /// - Imazungulira malo a `len() - mid` kumanja.
    ///
    /// # Panics
    ///
    /// Ngati `mid` iposa `len()`.
    /// Dziwani kuti `mid == len()` imachita _not_ panic ndipo siyizunguliratu.
    ///
    /// # Complexity
    ///
    /// Imatenga nthawi ya `*O*(min(mid, len() - mid))` ndipo palibe malo owonjezera.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// Imazungulira malo omaliza omaliza a `k` kumanja.
    ///
    /// Equivalently,
    /// - Imazungulira chinthu choyamba kupita pamalo `k`.
    /// - Amagwedeza zinthu zomaliza za `k` ndikuziwombera kutsogolo.
    /// - Imazungulira malo `len() - k` kumanzere.
    ///
    /// # Panics
    ///
    /// Ngati `k` iposa `len()`.
    /// Dziwani kuti `k == len()` imachita _not_ panic ndipo siyizunguliratu.
    ///
    /// # Complexity
    ///
    /// Imatenga nthawi ya `*O*(min(k, len() - k))` ndipo palibe malo owonjezera.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // CHITETEZO: Njira ziwiri zotsatirazi zimafunikira kuchuluka kosinthasintha
    // osachepera theka la kutalika kwa mwalawo.
    //
    // `wrap_copy` imafuna kuti `min(x, cap() - x) + copy_len <= cap()`, koma kuposa `min` isapitirire theka lantchitoyo, mosasamala kanthu za x, chifukwa chake ndizomveka kuyimba pano chifukwa tikuyitanitsa ndi china chochepera theka cha kutalika, chomwe sichiposa theka lantchitoyo.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Zosankha za Binary za `VecDeque` zosankhidwa ndi chinthu chomwe chapatsidwa.
    ///
    /// Ngati mtengo wapezeka ndiye kuti [`Result::Ok`] imabwezedwa, yokhala ndi index ya zomwe zikufanana.
    /// Ngati pali machesi angapo, ndiye kuti machesi onse akhoza kubwezedwa.
    /// Mtengo ukapanda kupezeka ndiye kuti [`Result::Err`] imabwezedwa, yokhala ndi cholozera chomwe chofananira chitha kuikidwa posunga dongosolo.
    ///
    ///
    /// # Examples
    ///
    /// Imayang'ana mndandanda wazinthu zinayi.
    /// Yoyamba imapezeka, yokhala ndi malo apadera;wachiwiri ndi wachitatu sapezeka;chachinayi chikhoza kufanana ndi malo aliwonse mu `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// Ngati mukufuna kuyika chinthu ku `VecDeque` yosankhidwa, pokonzekera dongosolo:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Zosaka za Binary za `VecDeque` zosankhidwa ndi ntchito yofananizira.
    ///
    /// Ntchito yofananizira iyenera kukhazikitsa dongosolo logwirizana ndi mtundu wa `VecDeque`, ndikubwezeretsanso nambala yolongosola yomwe ikuwonetsa ngati kutsutsana kwake kuli `Less`, `Equal` kapena `Greater` kuposa zomwe mukufuna.
    ///
    ///
    /// Ngati mtengo wapezeka ndiye kuti [`Result::Ok`] imabwezedwa, yokhala ndi index ya zomwe zikufanana.Ngati pali machesi angapo, ndiye kuti machesi onse akhoza kubwezedwa.
    /// Mtengo ukapanda kupezeka ndiye kuti [`Result::Err`] imabwezedwa, yokhala ndi cholozera chomwe chofananira chitha kuikidwa posunga dongosolo.
    ///
    /// # Examples
    ///
    /// Imayang'ana mndandanda wazinthu zinayi.Yoyamba imapezeka, yokhala ndi malo apadera;wachiwiri ndi wachitatu sapezeka;chachinayi chikhoza kufanana ndi malo aliwonse mu `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Kusaka kwa Binary pa `VecDeque` yosankhidwayo ndichinthu chofunikira kwambiri m'zigawo.
    ///
    /// Kungoganiza kuti `VecDeque` imasankhidwa ndi kiyi, mwachitsanzo ndi [`make_contiguous().sort_by_key()`](#method.make_contiguous) pogwiritsa ntchito chimodzimodzi chotsegula.
    ///
    ///
    /// Ngati mtengo wapezeka ndiye kuti [`Result::Ok`] imabwezedwa, yokhala ndi index ya zomwe zikufanana.
    /// Ngati pali machesi angapo, ndiye kuti machesi onse akhoza kubwezedwa.
    /// Mtengo ukapanda kupezeka ndiye kuti [`Result::Err`] imabwezedwa, yokhala ndi cholozera chomwe chofananira chitha kuikidwa posunga dongosolo.
    ///
    /// # Examples
    ///
    /// Imayang'ana mndandanda wazinthu zinayi pagulu la awiriawiri omwe asankhidwa ndi zinthu zawo zachiwiri.
    /// Yoyamba imapezeka, yokhala ndi malo apadera;wachiwiri ndi wachitatu sapezeka;chachinayi chikhoza kufanana ndi malo aliwonse mu `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// Sinthani `VecDeque` m'malo mwake kuti `len()` ikhale yofanana ndi new_len, mwina pochotsa zinthu zowonjezera kumbuyo kapena mwa kuyika miyala ya `value` kumbuyo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// Kubwezeretsa index mu choyimira gawo lotetezedwa kwa anapatsidwa logical element index.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // kukula kumakhala mphamvu ya 2
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Terengani kuchuluka kwa zinthu zomwe zatsala kuti ziwerengedwe mu buffer
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // kukula kumakhala mphamvu ya 2
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // Zogawana nthawi zonse m'magawo atatu, mwachitsanzo: kudzikonda: [a b c|d e f] ina: [0 1 2 3|4 5] kutsogolo=3, mid=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // Sizingatheke kugwiritsa ntchito Hash::hash_slice pa magawo obwezedwa ndi as_slices njira popeza kutalika kwawo kumatha kusiyanasiyana m'mipikisano yofananira.
        //
        //
        // Hasher amangotsimikizira kufanana kwa mayendedwe omwewo munjira zake.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Imagwiritsa ntchito `VecDeque` kukhala iterator yakutsogolo ndi kumbuyo yopereka zinthu pamtengo.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Ntchitoyi iyenera kukhala yofanana ndi:
        //
        //      pachinthu mu iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// Sinthani [`Vec<T>`] kukhala [`VecDeque<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Izi zimapewa kukhazikitsanso komwe zingatheke, koma mikhalidwe yake ndiyokhwima, ndipo imatha kusintha, motero sayenera kudaliridwa pokhapokha `Vec<T>` itachokera ku `From<VecDeque<T>>` ndipo sinaperekedwe kwina.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // Palibe magawidwe enieni a ma ZST oti azidandaula za kuchuluka, koma `VecDeque` sichitha kutalika ngati `Vec`.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // Tiyenera kusinthanso ngati kuthekera sikuli mphamvu ziwiri, zochepa kwambiri kapena alibe malo amodzi.
            // Timachita izi akadali mu `Vec` kotero zinthuzo zidzagwera pa panic.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// Sinthani [`VecDeque<T>`] kukhala [`Vec<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Izi sizifunikanso kugawananso, koma zikuyenera kuchita *O*(*n*) kusuntha kwa data ngati buffer yozungulira sichikhala koyambirira kwa kagawidwe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // Ameneyo ndi *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // Izi zimafunikira kukonzanso deta.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}