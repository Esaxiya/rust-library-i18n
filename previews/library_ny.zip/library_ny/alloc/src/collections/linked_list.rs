//! Mndandanda wolumikizidwa kawiri wokhala ndi ma node omwe ali nawo.
//!
//! `LinkedList` imalola kukankha ndi kutuluka kwa zinthu kumapeto kumapeto nthawi zonse.
//!
//! NOTE: Nthawi zonse kumakhala bwino kugwiritsa ntchito [`Vec`] kapena [`VecDeque`] chifukwa zotengera zomwe zili ndimitundu yambiri zimakhala zothamanga, zokumbukira bwino, komanso kugwiritsa ntchito bwino cache ya CPU.
//!
//!
//! [`Vec`]: crate::vec::Vec
//! [`VecDeque`]: super::vec_deque::VecDeque
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::Ordering;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem;
use core::ptr::NonNull;

use super::SpecExtend;
use crate::boxed::Box;

#[cfg(test)]
mod tests;

/// Mndandanda wolumikizidwa kawiri wokhala ndi ma node omwe ali nawo.
///
/// `LinkedList` imalola kukankha ndi kutuluka kwa zinthu kumapeto kumapeto nthawi zonse.
///
/// NOTE: Nthawi zonse kumakhala bwino kugwiritsa ntchito `Vec` kapena `VecDeque` chifukwa zotengera zomwe zili ndimitundu yambiri zimakhala zothamanga, zokumbukira bwino, komanso kugwiritsa ntchito bwino cache ya CPU.
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "LinkedList")]
pub struct LinkedList<T> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<Box<Node<T>>>,
}

struct Node<T> {
    next: Option<NonNull<Node<T>>>,
    prev: Option<NonNull<Node<T>>>,
    element: T,
}

/// Cholemba pazinthu za `LinkedList`.
///
/// `struct` iyi idapangidwa ndi [`LinkedList::iter()`].
/// Onani zolemba zake kuti mumve zambiri.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<&'a Node<T>>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.len).finish()
    }
}

// FIXME(#26925) Chotsani mokomera `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ..*self }
    }
}

/// Iterator yosinthika pazinthu za `LinkedList`.
///
/// `struct` iyi idapangidwa ndi [`LinkedList::iter_mut()`].
/// Onani zolemba zake kuti mumve zambiri.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    // Tilibe * mndandanda wathunthu pano, maumboni a `element` a node aperekedwa ndi wolemba nawo!Chifukwa chake samalani mukamagwiritsa ntchito izi;Njira zomwe akuyitanitsa ziyenera kudziwa kuti pakhoza kukhala zolemba za `element`.
    //
    //
    list: &'a mut LinkedList<T>,
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IterMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IterMut").field(&self.list).field(&self.len).finish()
    }
}

/// Iterator yokhala ndi zinthu za `LinkedList`.
///
/// `struct` iyi imapangidwa ndi njira ya [`into_iter`] pa [`LinkedList`] (yoperekedwa ndi `IntoIterator` trait).
/// Onani zolemba zake kuti mumve zambiri.
///
/// [`into_iter`]: LinkedList::into_iter
#[derive(Clone)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    list: LinkedList<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.list).finish()
    }
}

impl<T> Node<T> {
    fn new(element: T) -> Self {
        Node { next: None, prev: None, element }
    }

    fn into_element(self: Box<Self>) -> T {
        self.element
    }
}

// njira zachinsinsi
impl<T> LinkedList<T> {
    /// Ikuwonjezera mfundo yomwe yapatsidwa kutsogolo kwa mndandanda.
    #[inline]
    fn push_front_node(&mut self, mut node: Box<Node<T>>) {
        // Njirayi imasamala kuti isapangitse mayendedwe osunthika kuzinthu zonse, kuti zikhale zowoneka bwino mu `element`.
        //
        unsafe {
            node.next = self.head;
            node.prev = None;
            let node = Some(Box::leak(node).into());

            match self.head {
                None => self.tail = node,
                // Osapanga zatsopano zosinthika za (unique!) zikulumikizana `element`.
                Some(head) => (*head.as_ptr()).prev = node,
            }

            self.head = node;
            self.len += 1;
        }
    }

    /// Imachotsa ndikubwezeretsanso mfundozo patsogolo pamndandanda.
    #[inline]
    fn pop_front_node(&mut self) -> Option<Box<Node<T>>> {
        // Njirayi imasamala kuti isapangitse mayendedwe osunthika kuzinthu zonse, kuti zikhale zowoneka bwino mu `element`.
        //
        self.head.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.head = node.next;

            match self.head {
                None => self.tail = None,
                // Osapanga zatsopano zosinthika za (unique!) zikulumikizana `element`.
                Some(head) => (*head.as_ptr()).prev = None,
            }

            self.len -= 1;
            node
        })
    }

    /// Ikuwonjezera mfundo yomwe yapatsidwa kumbuyo kwa mndandanda.
    #[inline]
    fn push_back_node(&mut self, mut node: Box<Node<T>>) {
        // Njirayi imasamala kuti isapangitse mayendedwe osunthika kuzinthu zonse, kuti zikhale zowoneka bwino mu `element`.
        //
        unsafe {
            node.next = None;
            node.prev = self.tail;
            let node = Some(Box::leak(node).into());

            match self.tail {
                None => self.head = node,
                // Osapanga zatsopano zosinthika za (unique!) zikulumikizana `element`.
                Some(tail) => (*tail.as_ptr()).next = node,
            }

            self.tail = node;
            self.len += 1;
        }
    }

    /// Imachotsa ndikubwezeretsanso mfundo kumbuyo kwa mndandanda.
    #[inline]
    fn pop_back_node(&mut self) -> Option<Box<Node<T>>> {
        // Njirayi imasamala kuti isapangitse mayendedwe osunthika kuzinthu zonse, kuti zikhale zowoneka bwino mu `element`.
        //
        self.tail.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.tail = node.prev;

            match self.tail {
                None => self.head = None,
                // Osapanga zatsopano zosinthika za (unique!) zikulumikizana `element`.
                Some(tail) => (*tail.as_ptr()).next = None,
            }

            self.len -= 1;
            node
        })
    }

    /// Imasiyanitsa mfundo zomwe zatchulidwazi pamndandanda wapano.
    ///
    /// Chenjezo: izi siziyang'ana ngati mfundo zomwe zaperekedwa zili m'ndandanda wapano.
    ///
    /// Njirayi imasamalira kuti isapangitse kusintha kosinthika kwa `element`, kuti zisunge zowunikira.
    ///
    #[inline]
    unsafe fn unlink_node(&mut self, mut node: NonNull<Node<T>>) {
        let node = unsafe { node.as_mut() }; // iyi ndi yathu tsopano, titha kupanga &mut.

        // Osapanga zatsopano zosinthika za (unique!) zikulumikizana `element`.
        match node.prev {
            Some(prev) => unsafe { (*prev.as_ptr()).next = node.next },
            // mfundo iyi ndi mfundo mutu
            None => self.head = node.next,
        };

        match node.next {
            Some(next) => unsafe { (*next.as_ptr()).prev = node.prev },
            // mfundo iyi ndiyo mfundo ya mchira
            None => self.tail = node.prev,
        };

        self.len -= 1;
    }

    /// Amagwiritsa ntchito mfundo zingapo pakati pamiyeso iwiri yomwe ilipo.
    ///
    /// Chenjezo: izi siziyang'ana ngati mfundo zomwe zaperekedwa zili m'ndandanda wazomwe zilipo.
    #[inline]
    unsafe fn splice_nodes(
        &mut self,
        existing_prev: Option<NonNull<Node<T>>>,
        existing_next: Option<NonNull<Node<T>>>,
        mut splice_start: NonNull<Node<T>>,
        mut splice_end: NonNull<Node<T>>,
        splice_length: usize,
    ) {
        // Njirayi imasamala kuti isapangitse mayendedwe angapo osinthika amitundu yonse nthawi imodzi, kuti akhalebe ovomerezeka mu `element`.
        //
        if let Some(mut existing_prev) = existing_prev {
            unsafe {
                existing_prev.as_mut().next = Some(splice_start);
            }
        } else {
            self.head = Some(splice_start);
        }
        if let Some(mut existing_next) = existing_next {
            unsafe {
                existing_next.as_mut().prev = Some(splice_end);
            }
        } else {
            self.tail = Some(splice_end);
        }
        unsafe {
            splice_start.as_mut().prev = existing_prev;
            splice_end.as_mut().next = existing_next;
        }

        self.len += splice_length;
    }

    /// Imachotsa ma node onse pamndandanda wolumikizidwa monga zingapo zingapo.
    #[inline]
    fn detach_all_nodes(mut self) -> Option<(NonNull<Node<T>>, NonNull<Node<T>>, usize)> {
        let head = self.head.take();
        let tail = self.tail.take();
        let len = mem::replace(&mut self.len, 0);
        if let Some(head) = head {
            let tail = tail.unwrap_or_else(|| unsafe { core::hint::unreachable_unchecked() });
            Some((head, tail, len))
        } else {
            None
        }
    }

    #[inline]
    unsafe fn split_off_before_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // Gawo logawanika ndiye mutu watsopano wamutu wachigawo chachiwiri
        if let Some(mut split_node) = split_node {
            let first_part_head;
            let first_part_tail;
            unsafe {
                first_part_tail = split_node.as_mut().prev.take();
            }
            if let Some(mut tail) = first_part_tail {
                unsafe {
                    tail.as_mut().next = None;
                }
                first_part_head = self.head;
            } else {
                first_part_head = None;
            }

            let first_part = LinkedList {
                head: first_part_head,
                tail: first_part_tail,
                len: at,
                marker: PhantomData,
            };

            // Konzani mutu ptr wa gawo lachiwiri
            self.head = Some(split_node);
            self.len = self.len - at;

            first_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }

    #[inline]
    unsafe fn split_off_after_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // Gawo logawanika ndiye mfundo yatsopano ya mchira wagawo loyambirira ndipo ili ndi mutu wa gawo lachiwiri.
        //
        if let Some(mut split_node) = split_node {
            let second_part_head;
            let second_part_tail;
            unsafe {
                second_part_head = split_node.as_mut().next.take();
            }
            if let Some(mut head) = second_part_head {
                unsafe {
                    head.as_mut().prev = None;
                }
                second_part_tail = self.tail;
            } else {
                second_part_tail = None;
            }

            let second_part = LinkedList {
                head: second_part_head,
                tail: second_part_tail,
                len: self.len - at,
                marker: PhantomData,
            };

            // Konzani mchira ptr wa gawo loyamba
            self.tail = Some(split_node);
            self.len = at;

            second_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for LinkedList<T> {
    /// Amapanga `LinkedList<T>` yopanda kanthu.
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

impl<T> LinkedList<T> {
    /// Amapanga `LinkedList` yopanda kanthu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let list: LinkedList<u32> = LinkedList::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_linked_list_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        LinkedList { head: None, tail: None, len: 0, marker: PhantomData }
    }

    /// Imasuntha zinthu zonse kuchokera ku `other` mpaka kumapeto kwa mndandanda.
    ///
    /// Izi zimagwiritsanso ntchito mfundo zonse kuchokera ku `other` ndikuzisunthira ku `self`.
    /// Pambuyo pa opaleshoniyi, `other` imakhala yopanda kanthu.
    ///
    /// Ntchitoyi iyenera kuwerengedwa mu *O*(1) nthawi ndi *O*(1) kukumbukira.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list1 = LinkedList::new();
    /// list1.push_back('a');
    ///
    /// let mut list2 = LinkedList::new();
    /// list2.push_back('b');
    /// list2.push_back('c');
    ///
    /// list1.append(&mut list2);
    ///
    /// let mut iter = list1.iter();
    /// assert_eq!(iter.next(), Some(&'a'));
    /// assert_eq!(iter.next(), Some(&'b'));
    /// assert_eq!(iter.next(), Some(&'c'));
    /// assert!(iter.next().is_none());
    ///
    /// assert!(list2.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn append(&mut self, other: &mut Self) {
        match self.tail {
            None => mem::swap(self, other),
            Some(mut tail) => {
                // `as_mut` zili bwino pano chifukwa tili ndi mwayi wopezeka pamndandanda wonsewo.
                //
                if let Some(mut other_head) = other.head.take() {
                    unsafe {
                        tail.as_mut().next = Some(other_head);
                        other_head.as_mut().prev = Some(tail);
                    }

                    self.tail = other.tail.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// Imasuntha zinthu zonse kuchokera ku `other` mpaka koyambirira kwa mndandanda.
    #[unstable(feature = "linked_list_prepend", issue = "none")]
    pub fn prepend(&mut self, other: &mut Self) {
        match self.head {
            None => mem::swap(self, other),
            Some(mut head) => {
                // `as_mut` zili bwino pano chifukwa tili ndi mwayi wopezeka pamndandanda wonsewo.
                //
                if let Some(mut other_tail) = other.tail.take() {
                    unsafe {
                        head.as_mut().prev = Some(other_tail);
                        other_tail.as_mut().next = Some(head);
                    }

                    self.head = other.head.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// Amapereka cholembera kutsogolo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { head: self.head, tail: self.tail, len: self.len, marker: PhantomData }
    }

    /// Amapereka cholembera chakutsogolo chomwe chimasinthidwa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// for element in list.iter_mut() {
    ///     *element += 10;
    /// }
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&10));
    /// assert_eq!(iter.next(), Some(&11));
    /// assert_eq!(iter.next(), Some(&12));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { head: self.head, tail: self.tail, len: self.len, list: self }
    }

    /// Amapereka cholozera kutsogolo.
    ///
    /// Cholozeracho chikulozera ku "ghost" yosakhala chinthu ngati mndandanda mulibe kanthu.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front(&self) -> Cursor<'_, T> {
        Cursor { index: 0, current: self.head, list: self }
    }

    /// Amapereka chithunzithunzi ndi zochitika zosintha kutsogolo.
    ///
    /// Cholozeracho chikulozera ku "ghost" yosakhala chinthu ngati mndandanda mulibe kanthu.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: 0, current: self.head, list: self }
    }

    /// Amapereka cholozera kumbuyo.
    ///
    /// Cholozeracho chikulozera ku "ghost" yosakhala chinthu ngati mndandanda mulibe kanthu.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back(&self) -> Cursor<'_, T> {
        Cursor { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// Amapereka chithunzithunzi ndi ntchito zosintha kumbuyo kwake.
    ///
    /// Cholozeracho chikulozera ku "ghost" yosakhala chinthu ngati mndandanda mulibe kanthu.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// Kubwezeretsa `true` ngati `LinkedList` ilibe kanthu.
    ///
    /// Ntchitoyi iyenera kuwerengedwa mu *O*(1) nthawi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert!(dl.is_empty());
    ///
    /// dl.push_front("foo");
    /// assert!(!dl.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.head.is_none()
    }

    /// Imabwezeretsa kutalika kwa `LinkedList`.
    ///
    /// Ntchitoyi iyenera kuwerengedwa mu *O*(1) nthawi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.len(), 1);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    ///
    /// dl.push_back(3);
    /// assert_eq!(dl.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Imachotsa zinthu zonse ku `LinkedList`.
    ///
    /// Ntchitoyi iyenera kuwerengedwa mu *O*(*n*) nthawi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// dl.clear();
    /// assert_eq!(dl.len(), 0);
    /// assert_eq!(dl.front(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = Self::new();
    }

    /// Kubwezeretsa `true` ngati `LinkedList` ili ndi chinthu chofanana ndi mtengo womwe wapatsidwa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// assert_eq!(list.contains(&0), true);
    /// assert_eq!(list.contains(&10), false);
    /// ```
    #[stable(feature = "linked_list_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        self.iter().any(|e| e == x)
    }

    /// Amapereka cholozera chakutsogolo, kapena `None` ngati mndandanda mulibe kanthu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        unsafe { self.head.as_ref().map(|node| &node.as_ref().element) }
    }

    /// Amapereka kutanthauzira kosunthika kuzinthu zakutsogolo, kapena `None` ngati mndandanda ulibe kanthu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// match dl.front_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.front(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        unsafe { self.head.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// Amapereka cholozera kumbuyo, kapena `None` ngati mndandanda mulibe kanthu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        unsafe { self.tail.as_ref().map(|node| &node.as_ref().element) }
    }

    /// Amapereka kutanthauzira kosinthika kuzinthu zakumbuyo, kapena `None` ngati mndandanda mulibe kanthu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    ///
    /// match dl.back_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.back(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        unsafe { self.tail.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// Ikuwonjezera chinthu choyamba pamndandanda.
    ///
    /// Ntchitoyi iyenera kuwerengedwa mu *O*(1) nthawi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.front().unwrap(), &2);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front().unwrap(), &1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, elt: T) {
        self.push_front_node(box Node::new(elt));
    }

    /// Imachotsa chinthu choyambayo ndikuyibwezera, kapena `None` ngati mndandanda mulibe kanthu.
    ///
    ///
    /// Ntchitoyi iyenera kuwerengedwa mu *O*(1) nthawi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_front(), None);
    ///
    /// d.push_front(1);
    /// d.push_front(3);
    /// assert_eq!(d.pop_front(), Some(3));
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        self.pop_front_node().map(Node::into_element)
    }

    /// Amagwiritsa ntchito chinthu kumbuyo kwa mndandanda.
    ///
    /// Ntchitoyi iyenera kuwerengedwa mu *O*(1) nthawi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(3, *d.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, elt: T) {
        self.push_back_node(box Node::new(elt));
    }

    /// Imachotsa chomaliza pamndandanda ndikuibweza, kapena `None` ngati ilibe kanthu.
    ///
    ///
    /// Ntchitoyi iyenera kuwerengedwa mu *O*(1) nthawi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_back(), None);
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(d.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        self.pop_back_node().map(Node::into_element)
    }

    /// Amagawa mndandanda kukhala awiri pa index yomwe yapatsidwa.
    /// Kubwezeretsa chilichonse pambuyo pa index yomwe yapatsidwa, kuphatikiza index.
    ///
    /// Ntchitoyi iyenera kuwerengedwa mu *O*(*n*) nthawi.
    ///
    /// # Panics
    ///
    /// Panics ngati `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// let mut split = d.split_off(2);
    ///
    /// assert_eq!(split.pop_front(), Some(1));
    /// assert_eq!(split.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn split_off(&mut self, at: usize) -> LinkedList<T> {
        let len = self.len();
        assert!(at <= len, "Cannot split off at a nonexistent index");
        if at == 0 {
            return mem::take(self);
        } else if at == len {
            return Self::new();
        }

        // Pansipa, timayandikira kulowera kwa `i-1`th, mwina kuyambira koyambirira kapena kumapeto, kutengera zomwe zingakhale zachangu.
        //
        let split_node = if at - 1 <= len - 1 - (at - 1) {
            let mut iter = self.iter_mut();
            // mmalo modumpha pogwiritsa ntchito .skip() (yomwe imapanga chatsopano), timadumpha pamanja kuti tithe kufikira gawo lamutu popanda kutengera tsatanetsatane wa Skip
            //
            //
            for _ in 0..at - 1 {
                iter.next();
            }
            iter.head
        } else {
            // kulibwino kuyambira kumapeto
            let mut iter = self.iter_mut();
            for _ in 0..len - 1 - (at - 1) {
                iter.next_back();
            }
            iter.tail
        };
        unsafe { self.split_off_after_node(split_node, at) }
    }

    /// Imachotsa chinthucho pa index yomwe yapatsidwa ndikuibweza.
    ///
    /// Ntchitoyi iyenera kuwerengedwa mu *O*(*n*) nthawi.
    ///
    /// # Panics
    /// Panics ngati uli>=len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(linked_list_remove)]
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// assert_eq!(d.remove(1), 2);
    /// assert_eq!(d.remove(0), 3);
    /// assert_eq!(d.remove(0), 1);
    /// ```
    #[unstable(feature = "linked_list_remove", issue = "69210")]
    pub fn remove(&mut self, at: usize) -> T {
        let len = self.len();
        assert!(at < len, "Cannot remove at an index outside of the list bounds");

        // Pansipa, timangoyenda molunjika pamndandandanda womwe wapatsidwa, mwina kuyambira koyambirira kapena kumapeto, kutengera zomwe zingakhale zachangu.
        //
        let offset_from_end = len - at - 1;
        if at <= offset_from_end {
            let mut cursor = self.cursor_front_mut();
            for _ in 0..at {
                cursor.move_next();
            }
            cursor.remove_current().unwrap()
        } else {
            let mut cursor = self.cursor_back_mut();
            for _ in 0..offset_from_end {
                cursor.move_prev();
            }
            cursor.remove_current().unwrap()
        }
    }

    /// Amapanga cholembera chomwe chimagwiritsa ntchito kutseka kuti mudziwe ngati chinthucho chiyenera kuchotsedwa.
    ///
    /// Ngati kutsekako kubwereradi, ndiye kuti chinthucho chimachotsedwa ndikuperekedwa.
    /// Kutsekeka kukabwerera konyenga, chinthucho chidzakhalabe mundandanda ndipo sichidzaperekedwa ndi wolemba.
    ///
    /// Dziwani kuti `drain_filter` imakulolani kuti musinthe chilichonse chomwe chimatsekedwa mu fyuluta, ngakhale mutasankha kapena kuchotsa.
    ///
    ///
    /// # Examples
    ///
    /// Kugawa mndandanda mofanana ngakhale pang'ono, ndikugwiritsanso ntchito mndandanda woyambirira:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// use std::collections::LinkedList;
    ///
    /// let mut numbers: LinkedList<u32> = LinkedList::new();
    /// numbers.extend(&[1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15]);
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<LinkedList<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens.into_iter().collect::<Vec<_>>(), vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds.into_iter().collect::<Vec<_>>(), vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F>
    where
        F: FnMut(&mut T) -> bool,
    {
        // pewani zobwereka.
        let it = self.head;
        let old_len = self.len;

        DrainFilter { list: self, it, pred: filter, idx: 0, old_len }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        struct DropGuard<'a, T>(&'a mut LinkedList<T>);

        impl<'a, T> Drop for DropGuard<'a, T> {
            fn drop(&mut self) {
                // Pitirizani chimodzimodzi chomwe timachita pansipa.Izi zimangoyenda pomwe wowononga wachita mantha.
                // Ngati wina panics izi zidzachotsa.
                while self.0.pop_front_node().is_some() {}
            }
        }

        while let Some(node) = self.pop_front_node() {
            let guard = DropGuard(self);
            drop(node);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // Mukufuna nthawi yopanda malire kuti mupeze 'a
                let node = &*node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // Mukufuna nthawi yopanda malire kuti mupeze 'a
                let node = &*node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // Mukufuna nthawi yopanda malire kuti mupeze 'a
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &mut node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a mut T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // Mukufuna nthawi yopanda malire kuti mupeze 'a
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &mut node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

/// Cholozera pa `LinkedList`.
///
/// `Cursor` ili ngati iterator, kupatula kuti imatha kufunafuna mobwerezabwereza.
///
/// Otemberera nthawi zonse amapuma pakati pazinthu ziwiri zomwe zili mndandandandawo, ndikuwongolera mozungulira mozungulira.
/// Kuti mukwaniritse izi, pali "ghost" yopanda chinthu yomwe imatulutsa `None` pakati pamutu ndi mchira pamndandanda.
///
///
/// Akapangidwa, otemberera amayamba kutsogolo pamndandanda, kapena "ghost" yosakhala chinthu ngati mndandanda mulibe kanthu.
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct Cursor<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T> Clone for Cursor<'_, T> {
    fn clone(&self) -> Self {
        let Cursor { index, current, list } = *self;
        Cursor { index, current, list }
    }
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for Cursor<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Cursor").field(&self.list).field(&self.index()).finish()
    }
}

/// Cholozera `LinkedList` chosintha ntchito.
///
/// `Cursor` ili ngati iterator, kupatula kuti imatha kufunafuna mobwerezabwereza, ndipo imatha kusintha mndandanda nthawi yayitali.
/// Izi ndichifukwa choti nthawi yomwe mayikidwe ake adakwaniritsidwa imalumikizidwa ndi nthawi yokhayo, m'malo mongolemba mndandandawo.
/// Izi zikutanthauza kuti otemberera sangathe kutulutsa zinthu zingapo nthawi imodzi.
///
/// Otemberera nthawi zonse amapuma pakati pazinthu ziwiri zomwe zili mndandandandawo, ndikuwongolera mozungulira mozungulira.
/// Kuti mukwaniritse izi, pali "ghost" yopanda chinthu yomwe imatulutsa `None` pakati pamutu ndi mchira pamndandanda.
///
///
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct CursorMut<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a mut LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for CursorMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("CursorMut").field(&self.list).field(&self.index()).finish()
    }
}

impl<'a, T> Cursor<'a, T> {
    /// Ikubwezeretsani cholozera cholozera mkati mwa `LinkedList`.
    ///
    /// Izi zimabwezeretsa `None` ngati cholozeracho chikulozera ku "ghost" yosakhala chinthu.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// Imasuntha cholozeracho kupita ku chinthu chotsatira cha `LinkedList`.
    ///
    /// Ngati cholozeracho chikulozera ku "ghost" yosakhala chinthu ndiye izi zidzasunthira ku chinthu choyamba cha `LinkedList`.
    /// Ngati ikuloza kumapeto kwa `LinkedList` ndiye kuti ipita ku "ghost" yopanda chinthu.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // Tinalibe chilichonse chamakono;wololera uja anali atakhala poyambira pomwepo Next element iyenera kukhala mutu wazndandanda
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // Tidali ndi chinthu cham'mbuyomu, chifukwa chake tiyeni tipite ku chotsatira
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// Imasuntha cholozeracho kupita ku chinthu cham'mbuyomu cha `LinkedList`.
    ///
    /// Ngati cholozeracho chikulozera ku "ghost" yosakhala chinthu ndiye izi zidzasunthira kumapeto kwa `LinkedList`.
    /// Ngati ikuloza chinthu choyamba cha `LinkedList` ndiye kuti ipita ku "ghost" yosakhala chinthu.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // Palibe zamakono.Tili pachiyambi pamndandanda.Perekani Palibe ndikudumpha mpaka kumapeto.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // Khalani ndi prev.Dziperekeni ndikupita ku chinthu choyambirira.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// Kubwezeretsa kutanthauzira ku chinthu chomwe cholozeracho chikuloza pano.
    ///
    /// Izi zimabwezeretsa `None` ngati cholozeracho chikulozera ku "ghost" yosakhala chinthu.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&self) -> Option<&'a T> {
        unsafe { self.current.map(|current| &(*current.as_ptr()).element) }
    }

    /// Kubwezeretsa kutanthauzira ku chinthu chotsatira.
    ///
    /// Ngati cholozeracho chikulozera ku "ghost" yosakhala chinthu ndiye izi zimabweza chinthu choyamba cha `LinkedList`.
    /// Ngati ikuloza kumapeto komaliza kwa `LinkedList` ndiye kuti izi zimabweza `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&self) -> Option<&'a T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &(*next.as_ptr()).element)
        }
    }

    /// Kubwezeretsa kutanthauzira kuzinthu zam'mbuyomu.
    ///
    /// Ngati cholozeracho chikulozera ku "ghost" yosakhala chinthu ndiye izi zimabweza chinthu chomaliza cha `LinkedList`.
    /// Ngati ikuloza ku chinthu choyamba cha `LinkedList` ndiye izi zimabweza `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&self) -> Option<&'a T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &(*prev.as_ptr()).element)
        }
    }
}

impl<'a, T> CursorMut<'a, T> {
    /// Ikubwezeretsani cholozera cholozera mkati mwa `LinkedList`.
    ///
    /// Izi zimabwezeretsa `None` ngati cholozeracho chikulozera ku "ghost" yosakhala chinthu.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// Imasuntha cholozeracho kupita ku chinthu chotsatira cha `LinkedList`.
    ///
    /// Ngati cholozeracho chikulozera ku "ghost" yosakhala chinthu ndiye izi zidzasunthira ku chinthu choyamba cha `LinkedList`.
    /// Ngati ikuloza kumapeto kwa `LinkedList` ndiye kuti ipita ku "ghost" yopanda chinthu.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // Tinalibe chilichonse chamakono;wololera uja anali atakhala poyambira pomwepo Next element iyenera kukhala mutu wazndandanda
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // Tidali ndi chinthu cham'mbuyomu, chifukwa chake tiyeni tipite ku chotsatira
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// Imasuntha cholozeracho kupita ku chinthu cham'mbuyomu cha `LinkedList`.
    ///
    /// Ngati cholozeracho chikulozera ku "ghost" yosakhala chinthu ndiye izi zidzasunthira kumapeto kwa `LinkedList`.
    /// Ngati ikuloza chinthu choyamba cha `LinkedList` ndiye kuti ipita ku "ghost" yosakhala chinthu.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // Palibe zamakono.Tili pachiyambi pamndandanda.Perekani Palibe ndikudumpha mpaka kumapeto.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // Khalani ndi prev.Dziperekeni ndikupita ku chinthu choyambirira.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// Kubwezeretsa kutanthauzira ku chinthu chomwe cholozeracho chikuloza pano.
    ///
    /// Izi zimabwezeretsa `None` ngati cholozeracho chikulozera ku "ghost" yosakhala chinthu.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&mut self) -> Option<&mut T> {
        unsafe { self.current.map(|current| &mut (*current.as_ptr()).element) }
    }

    /// Kubwezeretsa kutanthauzira ku chinthu chotsatira.
    ///
    /// Ngati cholozeracho chikulozera ku "ghost" yosakhala chinthu ndiye izi zimabweza chinthu choyamba cha `LinkedList`.
    /// Ngati ikuloza kumapeto komaliza kwa `LinkedList` ndiye kuti izi zimabweza `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&mut self) -> Option<&mut T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &mut (*next.as_ptr()).element)
        }
    }

    /// Kubwezeretsa kutanthauzira kuzinthu zam'mbuyomu.
    ///
    /// Ngati cholozeracho chikulozera ku "ghost" yosakhala chinthu ndiye izi zimabweza chinthu chomaliza cha `LinkedList`.
    /// Ngati ikuloza ku chinthu choyamba cha `LinkedList` ndiye izi zimabweza `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&mut self) -> Option<&mut T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &mut (*prev.as_ptr()).element)
        }
    }

    /// Kubwezeretsa cholozera chokhacho chowerenga zomwe zikupezeka pano.
    ///
    /// Nthawi yonse ya `Cursor` yobwezeretsedwayo ndiyotengera ya `CursorMut`, zomwe zikutanthauza kuti sizingathe kukhala ndi `CursorMut` ndikuti `CursorMut` ili yozizira nthawi yonse ya `Cursor`.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn as_cursor(&self) -> Cursor<'_, T> {
        Cursor { list: self.list, current: self.current, index: self.index }
    }
}

// Tsopano mndandanda wazosintha

impl<'a, T> CursorMut<'a, T> {
    /// Kuyika chinthu chatsopano mu `LinkedList` pambuyo pa pano.
    ///
    /// Ngati cholozeracho chikuloza pa "ghost" yopanda chinthu ndiye kuti chinthu chatsopano chimayikidwa kutsogolo kwa `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_after(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, spliced_node, spliced_node, 1);
            if self.current.is_none() {
                // Index ya "ghost" non-element yasintha.
                self.index = self.list.len;
            }
        }
    }

    /// Kuyika chinthu chatsopano mu `LinkedList` isanachitike.
    ///
    /// Ngati cholozeracho chikuloza pa "ghost" yopanda chinthu ndiye kuti chinthu chatsopano chimayikidwa kumapeto kwa `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_before(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, spliced_node, spliced_node, 1);
            self.index += 1;
        }
    }

    /// Imachotsa zomwe zilipo kuchokera ku `LinkedList`.
    ///
    /// Chochotsedwacho chimabwezeretsedwanso, ndipo cholozeracho chimasunthidwa kuloza ku chinthu chotsatira mu `LinkedList`.
    ///
    ///
    /// Ngati chithunzicho chikuloza ku "ghost" yopanda chinthu ndiye kuti palibe chinthu chomwe chimachotsedwa ndipo `None` imabwezedwa.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current(&mut self) -> Option<T> {
        let unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);
            let unlinked_node = Box::from_raw(unlinked_node.as_ptr());
            Some(unlinked_node.element)
        }
    }

    /// Imachotsa zomwe zilipo kuchokera ku `LinkedList` popanda kusanja node.
    ///
    /// Node yomwe idachotsedwa imabwezedwa ngati `LinkedList` yatsopano yomwe ili ndi mfundo iyi yokha.
    /// Cholozeracho chasunthidwa kuloza ku chinthu chotsatira mu `LinkedList` yapano.
    ///
    /// Ngati chithunzicho chikuloza ku "ghost" yopanda chinthu ndiye kuti palibe chinthu chomwe chimachotsedwa ndipo `None` imabwezedwa.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current_as_list(&mut self) -> Option<LinkedList<T>> {
        let mut unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);

            unlinked_node.as_mut().prev = None;
            unlinked_node.as_mut().next = None;
            Some(LinkedList {
                head: Some(unlinked_node),
                tail: Some(unlinked_node),
                len: 1,
                marker: PhantomData,
            })
        }
    }

    /// Kuyika zinthu kuchokera ku `LinkedList` yomwe yapatsidwa pambuyo pake.
    ///
    /// Ngati cholozeracho chikuloza pa "ghost" yopanda chinthu ndiye kuti zinthu zatsopano zimayikidwa koyambirira kwa `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_after(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, splice_head, splice_tail, splice_len);
            if self.current.is_none() {
                // Index ya "ghost" non-element yasintha.
                self.index = self.list.len;
            }
        }
    }

    /// Kuyika zinthu kuchokera ku `LinkedList` yoperekedwa isanachitike.
    ///
    /// Ngati cholozeracho chikuloza pa "ghost" yopanda chinthu ndiye kuti zinthu zatsopano zimayikidwa kumapeto kwa `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_before(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, splice_head, splice_tail, splice_len);
            self.index += splice_len;
        }
    }

    /// Amagawaniza mndandandawo pambuyo pazomwe zilipo.
    /// Izi zibwezera mndandanda watsopano wokhala ndi chilichonse pambuyo pa cholozeracho, pomwe mndandanda woyambirira umasunga zonse kale.
    ///
    ///
    /// Ngati cholozeracho chikuloza pa "ghost" yosakhala chinthu ndiye kuti zonse zomwe zili mu `LinkedList` zasunthidwa.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_after(&mut self) -> LinkedList<T> {
        let split_off_idx = if self.index == self.list.len { 0 } else { self.index + 1 };
        if self.index == self.list.len {
            // Index ya "ghost" non-element yasintha kukhala 0.
            self.index = 0;
        }
        unsafe { self.list.split_off_after_node(self.current, split_off_idx) }
    }

    /// Gawani mndandanda kukhala awiri zinthu zisanachitike.
    /// Izi zibwezera mndandanda watsopano wokhala ndi chilichonse chisanachitike cholozeracho, pomwe mndandanda woyambirira umasunga chilichonse pambuyo pake.
    ///
    ///
    /// Ngati cholozeracho chikuloza pa "ghost" yosakhala chinthu ndiye kuti zonse zomwe zili mu `LinkedList` zasunthidwa.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_before(&mut self) -> LinkedList<T> {
        let split_off_idx = self.index;
        self.index = 0;
        unsafe { self.list.split_off_before_node(self.current, split_off_idx) }
    }
}

/// Iterator yopangidwa poyimba `drain_filter` pa LinkedList.
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub struct DrainFilter<'a, T: 'a, F: 'a>
where
    F: FnMut(&mut T) -> bool,
{
    list: &'a mut LinkedList<T>,
    it: Option<NonNull<Node<T>>>,
    pred: F,
    idx: usize,
    old_len: usize,
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Iterator for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        while let Some(mut node) = self.it {
            unsafe {
                self.it = node.as_ref().next;
                self.idx += 1;

                if (self.pred)(&mut node.as_mut().element) {
                    // `unlink_node` Zili bwino ndi kutchula maumboni a `element`.
                    self.list.unlink_node(node);
                    return Some(Box::from_raw(node.as_ptr()).element);
                }
            }
        }

        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Drop for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T, F>(&'r mut DrainFilter<'a, T, F>)
        where
            F: FnMut(&mut T) -> bool;

        impl<'r, 'a, T, F> Drop for DropGuard<'r, 'a, T, F>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                self.0.for_each(drop);
            }
        }

        while let Some(item) = self.next() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T: fmt::Debug, F> fmt::Debug for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.list).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.list.pop_front()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.list.len, Some(self.list.len))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.list.pop_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for LinkedList<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        let mut list = Self::new();
        list.extend(iter);
        list
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for LinkedList<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Ikugwiritsa ntchito mndandandawo kukhala woperekera zinthu mopatsa phindu.
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { list: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a LinkedList<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut LinkedList<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Extend<T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.push_back(elem);
    }
}

impl<I: IntoIterator> SpecExtend<I> for LinkedList<I::Item> {
    default fn spec_extend(&mut self, iter: I) {
        iter.into_iter().for_each(move |elt| self.push_back(elt));
    }
}

impl<T> SpecExtend<LinkedList<T>> for LinkedList<T> {
    fn spec_extend(&mut self, ref mut other: LinkedList<T>) {
        self.append(other);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &'a T) {
        self.push_back(elem);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq> PartialEq for LinkedList<T> {
    fn eq(&self, other: &Self) -> bool {
        self.len() == other.len() && self.iter().eq(other)
    }

    fn ne(&self, other: &Self) -> bool {
        self.len() != other.len() || self.iter().ne(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for LinkedList<T> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.iter().partial_cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for LinkedList<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.iter().cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for LinkedList<T> {
    fn clone(&self) -> Self {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        let mut iter_other = other.iter();
        if self.len() > other.len() {
            self.split_off(other.len());
        }
        for (elem, elem_other) in self.iter_mut().zip(&mut iter_other) {
            elem.clone_from(elem_other);
        }
        if !iter_other.is_empty() {
            self.extend(iter_other.cloned());
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for LinkedList<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash> Hash for LinkedList<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        for elt in self {
            elt.hash(state);
        }
    }
}

// Onetsetsani kuti `LinkedList` ndi owerenga ake owerengera okha ndiosiyanasiyana pamitundu yawo.
#[allow(dead_code)]
fn assert_covariance() {
    fn a<'a>(x: LinkedList<&'static str>) -> LinkedList<&'a str> {
        x
    }
    fn b<'i, 'a>(x: Iter<'i, &'static str>) -> Iter<'i, &'a str> {
        x
    }
    fn c<'a>(x: IntoIter<&'static str>) -> IntoIter<&'a str> {
        x
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Send for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for IterMut<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for IterMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Send for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Send> Send for CursorMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for CursorMut<'_, T> {}