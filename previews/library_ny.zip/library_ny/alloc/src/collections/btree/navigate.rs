use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Kutenga kwakanthawi kofanana, kosasinthika kofanana.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Amapeza masamba amtundu wosiyanasiyananso mumtengo.
    /// Kubwezeretsanso zigwiri zosiyana mumtengo womwewo kapena zosankha zopanda kanthu.
    ///
    /// # Safety
    ///
    /// Pokhapokha `BorrowType` ikakhala `Immut`, musagwiritse ntchito zowerengera kuti mupite ku KV yomweyo kawiri.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Zofanana ndi `(root1.first_leaf_edge(), root2.last_leaf_edge())` koma zothandiza kwambiri.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Amapeza masamba awiri amtundu womwe amakonza mzere wina mumtengo.
    ///
    /// Zotsatira zake ndizothandiza pokhapokha ngati mtengo walamulidwa ndi kiyi, monga mtengo womwe uli mu `BTreeMap` uli.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // CHITETEZO: mtundu wathu wobwereka sungasinthe.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Amapeza masamba awiri akuchepetsa mtengo wonse.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Amagawa zolembedwera zapadera m'masamba awiri opatula malire.
    /// Zotsatira zake ndizolemba zosasiyanitsa zomwe zimalola kusintha kwa (some), komwe kuyenera kugwiritsidwa ntchito mosamala.
    ///
    /// Zotsatira zake ndizothandiza pokhapokha ngati mtengo walamulidwa ndi kiyi, monga mtengo womwe uli mu `BTreeMap` uli.
    ///
    ///
    /// # Safety
    /// Musagwiritse ntchito zobwereza kuti mupite ku KV yomweyo kawiri.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Amagawa gawo lapadera m'masamba awiri amtundu womwe umasokoneza mtengo wonsewo.
    /// Zotsatirazi ndizofotokozera zomwe sizimaloleza kusintha (kwa mfundo zokha), chifukwa chake ziyenera kugwiritsidwa ntchito mosamala.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Timabwereza muzu wa NodeRef apa-sitidzayendera KV yomweyo kawiri, ndipo sitidzakhala ndi zokumana nazo zofananira.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Amagawa gawo lapadera m'masamba awiri amtundu womwe umasokoneza mtengo wonsewo.
    /// Zotsatirazi ndizofotokozera zapadera zomwe zimalola kusintha kosintha kwakukulu, kotero ziyenera kugwiritsidwa ntchito mosamala kwambiri.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Timabwereza muzu wa NodeRef apa-sitidzaupeza m'njira yoti igwirizane ndi zomwe zatchulidwa muzu.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Popeza adapatsidwa tsamba la edge, amabweza [`Result::Ok`] ndi chogwirizira ku KV yoyandikira kumanja, yomwe ili pamfundo yomweyo kapena mu mfundo ya makolo.
    ///
    /// Ngati tsamba edge ndiye lomaliza mumtengowo, limabwezeretsa [`Result::Err`] ndi mfundo ya mizu.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Popeza adapatsidwa tsamba la edge, amabweza [`Result::Ok`] ndi chogwirizira ku KV yoyandikira kumanzere kwake, yomwe ili pamfundo yomweyo kapena mu mfundo ya makolo.
    ///
    /// Ngati tsamba edge ndilo loyamba mumtengo, limabwezeretsa [`Result::Err`] ndi mfundo ya mizu.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Popeza chiphaso cha mkati cha edge, chimabwezeretsa [`Result::Ok`] ndi chogwirira ku KV yoyandikira kumanja, yomwe ili munjira yomweyo yamkati kapena m'ndondomeko ya makolo.
    ///
    /// Ngati mkati edge ndiye womaliza mumtengowo, imabwezeretsa [`Result::Err`] ndi node ya mizu.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Popeza kuti tsamba la edge limagwirira mumtengo wofa, limabwezeretsa tsamba lotsatira la edge kumanja, ndi awiri ofunikira pakati, omwe ali pamfundo yomweyo, pamfundo ya makolo, kapena kulibe.
    ///
    ///
    /// Njirayi imagwiritsanso ntchito node(s) iliyonse ikafika kumapeto kwa.
    /// Izi zikutanthawuza kuti ngati sipadzakhalanso awiri amtengo wapatali, mtengo wonse wotsalawo udzagawidwa ndipo palibe chomwe chidzabwerere.
    ///
    /// # Safety
    /// edge yopatsidwa siyiyenera kuti idabwezedwa kale ndi mnzake `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Popeza kuti tsamba la edge limagwirira mumtengo wofa, limabweza tsamba lotsatira la edge mbali yakumanzere, ndi mtengo wamtengo wapatali pakati, womwe uli pamfundo yomweyo, pamfundo ya makolo, kapena kulibe.
    ///
    ///
    /// Njirayi imagwiritsanso ntchito node(s) iliyonse ikafika kumapeto kwa.
    /// Izi zikutanthawuza kuti ngati sipadzakhalanso awiri amtengo wapatali, mtengo wonse wotsalawo udzagawidwa ndipo palibe chomwe chidzabwerere.
    ///
    /// # Safety
    /// edge yopatsidwa siyiyenera kuti idabwezedwa kale ndi mnzake `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Amachotsa mulu wa mfundo kuchokera pa tsamba mpaka muzu.
    /// Imeneyi ndi njira yokhayo yokhazikitsira mtengo wotsala pambuyo pa `deallocating_next` ndi `deallocating_next_back` yomwe idakhala ikuzungulira mbali zonse ziwiri za mtengo, ndipo yagunda edge yomweyo.
    /// Monga zimangotchulidwira pamene mafungulo onse ndi zikhulupiliro zabwezedwa, palibe kuyeretsa kumakiyi kapena zofunikira zilizonse.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Imasunthira chogwirira cha tsamba edge kupita patsamba lotsatira edge ndikubwezera zolemba za kiyi ndi mtengo wapakati.
    ///
    ///
    /// # Safety
    /// Payenera kukhala KV ina komwe ikupita.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Imasunthira chogwirira cha tsamba edge kupita patsamba lakale edge ndikubwezeretsanso zolongosoledwa pachinsinsi ndi mtengo wapakati.
    ///
    ///
    /// # Safety
    /// Payenera kukhala KV ina komwe ikupita.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Imasunthira chogwirira cha tsamba edge kupita patsamba lotsatira edge ndikubwezera zolemba za kiyi ndi mtengo wapakati.
    ///
    ///
    /// # Safety
    /// Payenera kukhala KV ina komwe ikupita.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Kuchita izi mwachangu ndikufulumira, malinga ndi ziwonetsero.
        kv.into_kv_valmut()
    }

    /// Imasunthira chogwirira cha tsamba la edge kupita patsamba lakale ndikubwezeretsanso zinsinsi za kiyi ndi mtengo wapakati.
    ///
    ///
    /// # Safety
    /// Payenera kukhala KV ina komwe ikupita.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Kuchita izi mwachangu ndikufulumira, malinga ndi ziwonetsero.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Imasunthira chogwirira cha tsamba edge kupita patsamba lotsatira edge ndikubwezeretsa kiyi ndi mtengo wake pakati, kusunthira mfundo iliyonse yomwe idatsalira ndikusiya edge yofananira nayo pamalingaliro ake ozungulira.
    ///
    /// # Safety
    /// - Payenera kukhala KV ina komwe ikupita.
    /// - KV ija sinabwezeredwenso mnzake `next_back_unchecked` pamtundu uliwonse wazogwiritsira ntchito kuwoloka mtengowo.
    ///
    /// Njira yokhayo yomwe mungapitirire ndi chogwirizira ndikuyerekeza, kusiya, kuyitananso njirayi malinga ndi chitetezo chake, kapena kuyimbira mnzake `next_back_unchecked` malinga ndi chitetezo chake.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Imasunthira chogwirira cha tsamba la edge patsamba lakale la edge ndikubwezeretsa kiyi ndi mtengo wake pakati, kusunthira mfundo iliyonse yomwe idatsalira ndikusiya edge yolingana nayo pamalingaliro ake ozungulira.
    ///
    /// # Safety
    /// - Payenera kukhala KV ina komwe ikupita.
    /// - Tsamba lija edge silinabwerenso m'mbuyomu ndi mnzake `next_unchecked` pamtundu uliwonse wazogwiritsira ntchito kuwoloka mtengowo.
    ///
    /// Njira yokhayo yomwe mungapitirire ndi chogwirizira ndikuyerekeza, kusiya, kuyitananso njirayi malinga ndi chitetezo chake, kapena kuyimbira mnzake `next_unchecked` malinga ndi chitetezo chake.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Imabwezeretsa tsamba lakumanzere la edge mkati kapena pansi pa mfundo, mwanjira ina, edge yomwe mumafunikira poyamba mukamapita kutsogolo (kapena komaliza mukamayang'ana kumbuyo).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Imabwezeretsa tsamba lakumanja la edge mkati kapena pansi pa mfundo, mwanjira ina, edge yomwe mumafunikira pomaliza pamene mukuyenda kutsogolo (kapena choyamba mukamabwerera kumbuyo).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Amayendera masamba am'magawo ndi ma KV amkati mwakulinganiza makiyi, komanso amayendera magawo amkati kwathunthu mozama koyamba, kutanthauza kuti mfundo zamkati zimatsogola ma KV awo ndi mwana wawo.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Ikuwerengetsa kuchuluka kwa zinthu mumtengo (sub).
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Imabwezeretsa tsamba edge loyandikira kwambiri ku KV kuti ipite patsogolo.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Imabwezeretsa tsamba edge loyandikira kwambiri ku KV poyenda kumbuyo.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}