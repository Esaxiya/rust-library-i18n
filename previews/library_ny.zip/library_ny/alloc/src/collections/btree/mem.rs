use core::intrinsics;
use core::mem;
use core::ptr;

/// Izi zimalowetsa mtengo kumbuyo kwa `v` mwapadera poyitanitsa ntchitoyo.
///
///
/// panic ikachitika `change` itatsekedwa, ntchito yonse idzachotsedwa.
#[allow(dead_code)] // sungani monga fanizo ndikugwiritsa ntchito future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Izi zimalowa m'malo mwa mtengo wapaderadera wa `v` poyitanitsa ntchitoyo, ndikubwezera zotsatira zomwe zapezedwa panjira.
///
///
/// panic ikachitika `change` itatsekedwa, ntchito yonse idzachotsedwa.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}