use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::iter::FusedIterator;

/// Chigawo cha iterator chomwe chimaphatikiza kutulutsa kwa owongolera awiri mosamalitsa, mwachitsanzo mgwirizano kapena kusiyana kofananira.
///
pub struct MergeIterInner<I: Iterator> {
    a: I,
    b: I,
    peeked: Option<Peeked<I>>,
}

/// Zikwangwani mwachangu kuposa kukulunga ma iterator onse mu Peekable, mwina chifukwa choti titha kukakamiza FusedIterator.
///
#[derive(Clone, Debug)]
enum Peeked<I: Iterator> {
    A(I::Item),
    B(I::Item),
}

impl<I: Iterator> Clone for MergeIterInner<I>
where
    I: Clone,
    I::Item: Clone,
{
    fn clone(&self) -> Self {
        Self { a: self.a.clone(), b: self.b.clone(), peeked: self.peeked.clone() }
    }
}

impl<I: Iterator> Debug for MergeIterInner<I>
where
    I: Debug,
    I::Item: Debug,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("MergeIterInner").field(&self.a).field(&self.b).field(&self.peeked).finish()
    }
}

impl<I: Iterator> MergeIterInner<I> {
    /// Pangani maziko atsopano kuti iterator iphatikize magwero awiri.
    pub fn new(a: I, b: I) -> Self {
        MergeIterInner { a, b, peeked: None }
    }

    /// Imabwezeretsa zinthu zotsatirazi zochokera pazinthu ziwiri zomwe zaphatikizidwa.
    /// Ngati zosankha zonse ziwiri zobwerera zili ndi mtengo, mtengowo ndi wofanana ndipo umapezeka m'magulu onsewa.
    /// Ngati chimodzi mwanjira zomwe zabwezedwa chili ndi phindu, mtengowo sukuchitika gwero lina (kapena magwero sikukwera kwenikweni).
    ///
    /// Ngati palibe njira yobweretsera yomwe ili ndi phindu, iteration yatha ndipo mayendedwe omwe abwera pambuyo pake abwezeretsanso zopanda kanthu.
    ///
    ///
    pub fn nexts<Cmp: Fn(&I::Item, &I::Item) -> Ordering>(
        &mut self,
        cmp: Cmp,
    ) -> (Option<I::Item>, Option<I::Item>)
    where
        I: FusedIterator,
    {
        let mut a_next;
        let mut b_next;
        match self.peeked.take() {
            Some(Peeked::A(next)) => {
                a_next = Some(next);
                b_next = self.b.next();
            }
            Some(Peeked::B(next)) => {
                b_next = Some(next);
                a_next = self.a.next();
            }
            None => {
                a_next = self.a.next();
                b_next = self.b.next();
            }
        }
        if let (Some(ref a1), Some(ref b1)) = (&a_next, &b_next) {
            match cmp(a1, b1) {
                Ordering::Less => self.peeked = b_next.take().map(Peeked::B),
                Ordering::Greater => self.peeked = a_next.take().map(Peeked::A),
                Ordering::Equal => (),
            }
        }
        (a_next, b_next)
    }

    /// Imabwezeretsa malire apamwamba a `size_hint` omaliza omaliza.
    pub fn lens(&self) -> (usize, usize)
    where
        I: ExactSizeIterator,
    {
        match self.peeked {
            Some(Peeked::A(_)) => (1 + self.a.len(), self.b.len()),
            Some(Peeked::B(_)) => (self.a.len(), 1 + self.b.len()),
            _ => (self.a.len(), self.b.len()),
        }
    }
}