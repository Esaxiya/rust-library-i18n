use core::marker::PhantomData;
use core::ptr::NonNull;

/// Amapereka chitsanzo chobweza mwapadera, mukadziwa kuti kubwezeredwa ndi mbadwa zake zonse (mwachitsanzo, zolozera zonse ndi maumboni omwe achokerako) sizidzagwiritsidwanso ntchito nthawi ina, pambuyo pake mudzafunanso kugwiritsanso ntchito choyambirira chapadera .
///
///
/// Wobwereketsa nthawi zambiri amayang'anira kubwerekana uku kwa inu, koma kuwongolera kwina komwe kumakwaniritsa kusungaku kumakhala kovuta kwambiri kuti wopanga atsatire.
/// `DormantMutRef` imakupatsani mwayi woti mungadzibwereke nokha, kwinaku mukufotokoza momwe zakhalira, ndikuphatikizira chikhomo chobiriwira chofunikira kuti muchite izi popanda kudziwika.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Jambulani ngongole yapadera, ndipo mubwererenso nthawi yomweyo.
    /// Kwa wopangirako, nthawi yonse yomwe ikupezeka pamwambowu ndi yofanana ndi nthawi yaumboni woyambirira, koma iwe promise kuti ugwiritse ntchito kwakanthawi kochepa.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // CHITETEZO: timakhala tikubwereka nthawi yonseyi kudzera pa `_marker`, ndipo timavumbula
        // chongonena ichi, kotero ndichapadera.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Bwererani ku ngongole yapadera yomwe idalandidwa poyamba.
    ///
    /// # Safety
    ///
    /// Kubwezeredwa ndalama kuyenera kuti kunatha, kutanthauza kuti, cholembedwera chobwezeredwa ndi `new` ndi zolemba zonse ndi zolembedwera zochokera pamenepo, siziyenera kugwiritsidwanso ntchito.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // CHITETEZO: chitetezo chathu chimatanthawuza kuti mawuwa ndiopanso.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;